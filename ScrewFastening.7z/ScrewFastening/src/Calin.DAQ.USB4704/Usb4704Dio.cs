﻿using System;
using Automation.BDaq;
using Calin.Logging.Abstractions;
using Microsoft.Extensions.Logging;

namespace Calin.DAQ.USB4704
{
    public class Usb4704Dio : IUsb4704Dio
    {
        private readonly ILogger<Usb4704Dio> _logger = LoggingBridge.CreateLogger<Usb4704Dio>();
        private readonly InstantDiCtrl _instantDiCtrl = new InstantDiCtrl();
        private readonly InstantDoCtrl _instantDoCtrl = new InstantDoCtrl();
        private int _totalPorts;

        public Usb4704Dio()
        {
        }

        #region DIO

        /// <inheritdoc/>
        public bool Usb4704DioInit(string deviceCode = "")
        {
            if (string.IsNullOrWhiteSpace(deviceCode))
                deviceCode = "DemoDevice,BID#0";

            _instantDiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
            if (!_instantDiCtrl.Initialized)
            {
                _logger.LogWarning($"裝置開啟失敗：{nameof(Usb4704DioInit)}");
                return false;
            }

            _instantDoCtrl.SelectedDevice = new DeviceInformation(deviceCode);
            if (!_instantDoCtrl.Initialized)
            {
                _logger.LogWarning($"裝置開啟失敗：{nameof(Usb4704DioInit)}");
                return false;
            }

            _totalPorts = _instantDiCtrl.PortCount;
            return true;
        }

        /// <inheritdoc/>
        public void Dispose()
        {
            _instantDiCtrl.Dispose();
            GC.SuppressFinalize(this);
        }

        #endregion DIO

        #region Digital Input

        /// <inheritdoc/>
        public bool ReadDigital(int port, out byte data)
        {
            ErrorCode errorCode = _instantDiCtrl.Read(port, out data);
            if (errorCode != ErrorCode.Success)
            {
                _logger.LogWarning($"讀取數位輸入失敗：{nameof(ReadDigital)}，錯誤代碼：0x{(int)errorCode:X}");
                return false;
            }
            return true;
        }

        /// <inheritdoc/>
        public bool ReadDigitalBit(int port, int bitPos, out byte bitValue)
        {
            ErrorCode errorCode = _instantDiCtrl.ReadBit(port, bitPos, out bitValue);
            if (errorCode != ErrorCode.Success)
            {
                _logger.LogWarning($"讀取數位輸入位元失敗：{nameof(ReadDigitalBit)}，錯誤代碼：0x{(int)errorCode:X8}");
                return false;
            }
            return true;
        }

        #endregion Digital Input

        #region Digital Output

        /// <inheritdoc/>
        public bool WriteDigital(int port, byte data)
        {
            ErrorCode errorCode = _instantDoCtrl.Write(port, data);
            if (errorCode != ErrorCode.Success)
            {
                _logger.LogWarning($"寫入數位輸出失敗：{nameof(WriteDigital)}，錯誤代碼：0x{(int)errorCode:X8}");
                return false;
            }
            return true;
        }

        /// <inheritdoc/>
        public bool WriteDigitalBit(int port, int bitPos, byte bitValue)
        {
            ErrorCode errorCode = _instantDoCtrl.WriteBit(port, bitPos, bitValue);
            if (errorCode != ErrorCode.Success)
            {
                _logger.LogWarning($"寫入數位輸出位元失敗：{nameof(WriteDigitalBit)}，錯誤代碼：0x{(int)errorCode:X8}");
                return false;
            }
            return true;
        }

        #endregion Digital Output
    }
}
