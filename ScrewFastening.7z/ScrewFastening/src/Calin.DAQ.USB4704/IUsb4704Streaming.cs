﻿using System;
using Automation.BDaq;

namespace Calin.DAQ.USB4704
{
    public interface IUsb4704Streaming
    {
        #region Events

        /// <summary>
        /// 當有新數據可用時觸發的事件。
        /// </summary>
        event EventHandler DataReady;

        #endregion Events

        #region Properties

        /// <summary>
        /// 讀取的數據陣列。
        /// </summary>
        double[] AcquiredDataArray { get; }

        /// <summary>
        /// 讀取的數據數量。
        /// </summary>
        int AcquiredDataCount { get; }

        /// <summary>
        /// 通道數量。
        /// </summary>
        int ChannelCountMax { get; }

        /// <summary>
        /// 數據段長度。
        /// </summary>
        int SectionLength { get; }
        #endregion Properties

        #region Methods

        /// <summary>
        /// 初始化 USB-4704 的串流輸入功能。
        /// </summary>
        /// <param name="deviceCode">USB-4704 設備的代碼。</param>
        /// <returns>初始化是否成功。</returns>
        bool Usb4704StreamingInit(string deviceCode = "");

        /// <summary>
        /// 釋放資源。
        /// </summary>
        void Dispose();

        /// <summary>
        /// 開始數據採集。
        /// </summary>
        void StartAcquisition();

        /// <summary>
        /// 停止數據採集。
        /// </summary>
        void StopAcquisition();

        /// <summary>
        /// 設定取樣頻率。
        /// </summary>
        /// <param name="clockRate">取樣頻率。</param>
        void SetClockRate(double clockRate);

        /// <summary>
        /// 設定數據段長度。
        /// </summary>
        /// <param name="sectionLength">數據段長度。</param>
        void SetSectionLength(int sectionLength);

        /// <summary>
        /// 設定通道的訊號類型。
        /// </summary>
        /// <param name="ch">通道編號。</param>
        /// <param name="signalType">訊號類型。</param>
        void SetSignalType(int ch, AiSignalType signalType);

        /// <summary>
        /// 設定通道的量測範圍。
        /// </summary>
        /// <param name="ch">通道編號。</param>
        /// <param name="valueRange">量測範圍。</param>
        void SetValueRange(int ch, ValueRange valueRange);

        /// <summary>
        /// 設定起始通道。
        /// </summary>
        /// <param name="ch">通道編號。</param>
        void SetChannelStart(int ch);

        #endregion Methods
    }
}
