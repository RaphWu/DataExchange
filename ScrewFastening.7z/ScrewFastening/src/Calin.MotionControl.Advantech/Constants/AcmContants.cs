﻿using System.Collections.Generic;
using Advantech.Motion;
using Calin.MotionControl.Advantech.ViewModels;

namespace Calin.MotionControl.Advantech.Constants
{
    public static class AcmContants
    {
        /// <summary>
        /// 緊急停止邏輯型態選項.
        /// </summary>
        public static readonly List<UintStringPair> EmgLogicList = new List<UintStringPair>()
        {
            new UintStringPair() {Id = (uint)EmgLogic.NOT_SUPPORT, Name = "不使用" },
            new UintStringPair() {Id = (uint)EmgLogic.EMG_ACT_LOW, Name = "低電位作用 (Normal Open)" },
            new UintStringPair() {Id = (uint)EmgLogic.EMG_ACT_HIGH, Name = "高電位作用 (Normal Close)" },
        };


        public static List<UintStringPair> HomeModeList = new List<UintStringPair>()
        {
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 01: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE2_Lmt, Name ="Mode 02: Lmt" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 03: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 04: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 05: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 06: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 07: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 08: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 09: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 10: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 11: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 12: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 13: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 14: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 15: Abs" },
            //new UintStringPair() {Id = (uint)HomeMode.MODE1_Abs, Name ="Mode 16: Abs" },
        };

        public static readonly List<UintStringPair> HomeDirList = new List<UintStringPair>()
        {
            new UintStringPair() { Id = (uint)HomeDir.NegDir, Name = "負方向" },
            new UintStringPair() { Id = (uint)HomeDir.PosiDir, Name = "正方向" },
        };


        public static readonly List<UintStringPair> ExSwitchModeList = new List<UintStringPair>()
        {
            new UintStringPair() { Id =(uint)HomeExSwitchMode.LevelOn, Name="高電位模式" },
            new UintStringPair() { Id =(uint)HomeExSwitchMode.LevelOff, Name="低電位模式" },
            new UintStringPair() { Id =(uint)HomeExSwitchMode.EdgeOn, Name="正緣模式" },
            new UintStringPair() { Id =(uint)HomeExSwitchMode.EdgeOff, Name="負緣模式" },
        };
    }
}
