﻿using System.Collections.Generic;
using Advantech.Motion;
using Calin.MotionControl.Advantech.ViewModels;

namespace Calin.MotionControl.Advantech.Constants
{
    public static class DeviceContants
    {
        /// <summary>
        /// 緊急停止邏輯型態選項.
        /// </summary>
        public static readonly List<UintStringPair> EmgLogicList = new List<UintStringPair>()
        {
            new UintStringPair() {Id = (uint)EmgLogic.NOT_SUPPORT, Name = "不使用" },
            new UintStringPair() {Id = (uint)EmgLogic.EMG_ACT_LOW, Name = "低電位作用 (Normal Open)" },
            new UintStringPair() {Id = (uint)EmgLogic.EMG_ACT_HIGH, Name = "高電位作用 (Normal Close)" },
        };
    }
}
