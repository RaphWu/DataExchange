﻿using System.Collections.ObjectModel;

namespace Calin.MotionControl.Advantech.Models
{
    // xxxConfig, CopyFrom, Applyxxx, Getxxx

    /// <summary>
    /// Advantech ACM 配置。
    /// </summary>
    public class AcmConfig
    {
        /// <summary>
        /// 裝置參數配置。
        /// </summary>
        public DeviceConfig DeviceConfig { get; } = new DeviceConfig();

        /// <summary>
        /// 軸參數配置集合。
        /// </summary>
        public ObservableCollection<AxisConfig> AxisConfigs { get; internal set; } = new ObservableCollection<AxisConfig>();
    }
}
