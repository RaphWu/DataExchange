﻿namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 錯誤訊息結構。
    /// </summary>
    public class AcmResult
    {
        /// <summary>
        /// 錯誤代碼。
        /// </summary>
        public uint ErrCode { get; set; }

        /// <summary>
        /// 錯誤訊息。
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 附加說明。
        /// </summary>
        public string AdditionalMessage { get; set; }

        /// <summary>
        /// 呼叫者名稱。
        /// </summary>
        public string CallerName { get; set; }

        internal AcmResult()
        {
            ErrCode = 0;
            Message = "";
            AdditionalMessage = "";
        }

        internal AcmResult(uint errCode, string errMsg)
        {
            ErrCode = errCode;
            Message = errMsg;
            AdditionalMessage = "";
        }

        internal AcmResult(uint errCode, string errMsg, string additionalMsg)
        {
            ErrCode = errCode;
            Message = errMsg;
            AdditionalMessage = additionalMsg;
        }
    }
}
