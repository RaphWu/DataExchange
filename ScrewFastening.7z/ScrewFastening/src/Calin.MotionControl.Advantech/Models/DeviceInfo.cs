﻿namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 裝置資訊。
    /// </summary>
    public class DeviceInfo
    {
        /// <summary>
        /// 裝置編號。
        /// </summary>
        public uint DeviceNumber;

        /// <summary>
        /// 裝置名稱。
        /// </summary>
        public string DeviceName;

        /// <summary>
        /// 子裝置數量。
        /// </summary>
        public short NumofSubDevice;
    }
}
