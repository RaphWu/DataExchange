﻿namespace Calin.MotionControl.Advantech.ViewModels
{
    /// <summary>
    /// uint-string (Id-Name) 配對結構.
    /// </summary>
    public class UintStringPair
    {
        public uint Id { get; set; }
        public string Name { get; set; }
    }
}
