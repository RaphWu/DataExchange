﻿using System.Windows.Forms;
using Calin.Navigation;

namespace Calin.ScrewFastening.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class ManualPage : UserControl
    {
        public ManualPage()
        {
            InitializeComponent();
        }
    }
}
