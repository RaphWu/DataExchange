﻿using System.Windows.Forms;

namespace Calin.ScrewFastening
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.sbZTitle = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbRTitle = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbTorqueTitle = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbHeightTitle = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.sbMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.sbZ = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbR = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbTorque = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbHeight = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbClock = new System.Windows.Forms.ToolStripStatusLabel();
            this.ClockTimer = new System.Windows.Forms.Timer(this.components);
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.ContentPanel = new System.Windows.Forms.Panel();
            this.MenuPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.rbMenuMain = new System.Windows.Forms.RadioButton();
            this.rbMenuMonitor = new System.Windows.Forms.RadioButton();
            this.rbMenuProcessFlow = new System.Windows.Forms.RadioButton();
            this.rbMenuManul = new System.Windows.Forms.RadioButton();
            this.rbMenuSetup = new System.Windows.Forms.RadioButton();
            this.statusStrip.SuspendLayout();
            this.TLP.SuspendLayout();
            this.MenuPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // sbZTitle
            // 
            this.sbZTitle.AutoSize = false;
            this.sbZTitle.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sbZTitle.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbZTitle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbZTitle.Font = new System.Drawing.Font("Verdana", 9F);
            this.sbZTitle.Name = "sbZTitle";
            this.sbZTitle.Size = new System.Drawing.Size(25, 19);
            this.sbZTitle.Text = "Z:";
            this.sbZTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // sbRTitle
            // 
            this.sbRTitle.AutoSize = false;
            this.sbRTitle.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbRTitle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbRTitle.Font = new System.Drawing.Font("Verdana", 9F);
            this.sbRTitle.Name = "sbRTitle";
            this.sbRTitle.Size = new System.Drawing.Size(25, 19);
            this.sbRTitle.Text = "R:";
            this.sbRTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // sbTorqueTitle
            // 
            this.sbTorqueTitle.AutoSize = false;
            this.sbTorqueTitle.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbTorqueTitle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbTorqueTitle.Name = "sbTorqueTitle";
            this.sbTorqueTitle.Size = new System.Drawing.Size(40, 19);
            this.sbTorqueTitle.Text = "扭力:";
            // 
            // sbHeightTitle
            // 
            this.sbHeightTitle.AutoSize = false;
            this.sbHeightTitle.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbHeightTitle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbHeightTitle.Name = "sbHeightTitle";
            this.sbHeightTitle.Size = new System.Drawing.Size(40, 19);
            this.sbHeightTitle.Text = "高度:";
            this.sbHeightTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sbMessage,
            this.sbProgressBar,
            this.sbZTitle,
            this.sbZ,
            this.sbRTitle,
            this.sbR,
            this.sbTorqueTitle,
            this.sbTorque,
            this.sbHeightTitle,
            this.sbHeight,
            this.sbClock});
            this.statusStrip.Location = new System.Drawing.Point(0, 537);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1008, 24);
            this.statusStrip.TabIndex = 1;
            this.statusStrip.Text = "statusStrip1";
            // 
            // sbMessage
            // 
            this.sbMessage.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbMessage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbMessage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.sbMessage.Name = "sbMessage";
            this.sbMessage.Size = new System.Drawing.Size(329, 19);
            this.sbMessage.Spring = true;
            this.sbMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sbProgressBar
            // 
            this.sbProgressBar.Name = "sbProgressBar";
            this.sbProgressBar.Size = new System.Drawing.Size(150, 18);
            // 
            // sbZ
            // 
            this.sbZ.AutoSize = false;
            this.sbZ.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.sbZ.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbZ.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbZ.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sbZ.Name = "sbZ";
            this.sbZ.Size = new System.Drawing.Size(68, 19);
            this.sbZ.Text = "888.888";
            // 
            // sbR
            // 
            this.sbR.AutoSize = false;
            this.sbR.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.sbR.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbR.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbR.Font = new System.Drawing.Font("Verdana", 9F);
            this.sbR.Name = "sbR";
            this.sbR.Size = new System.Drawing.Size(52, 19);
            this.sbR.Text = "888.8";
            // 
            // sbTorque
            // 
            this.sbTorque.AutoSize = false;
            this.sbTorque.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.sbTorque.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbTorque.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbTorque.Font = new System.Drawing.Font("Verdana", 9F);
            this.sbTorque.Name = "sbTorque";
            this.sbTorque.Size = new System.Drawing.Size(62, 19);
            this.sbTorque.Text = "888.88";
            // 
            // sbHeight
            // 
            this.sbHeight.AutoSize = false;
            this.sbHeight.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.sbHeight.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbHeight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbHeight.Font = new System.Drawing.Font("Verdana", 9F);
            this.sbHeight.Name = "sbHeight";
            this.sbHeight.Size = new System.Drawing.Size(60, 19);
            this.sbHeight.Text = "88.888";
            // 
            // sbClock
            // 
            this.sbClock.AutoSize = false;
            this.sbClock.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.sbClock.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.sbClock.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sbClock.Name = "sbClock";
            this.sbClock.Size = new System.Drawing.Size(140, 19);
            this.sbClock.Text = "8888/88/88 88:88:88";
            // 
            // ClockTimer
            // 
            this.ClockTimer.Enabled = true;
            this.ClockTimer.Interval = 250;
            this.ClockTimer.Tick += new System.EventHandler(this.ClockTimer_Tick);
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 1;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.ContentPanel, 0, 1);
            this.TLP.Controls.Add(this.MenuPanel, 0, 0);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 2;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Size = new System.Drawing.Size(1008, 537);
            this.TLP.TabIndex = 2;
            // 
            // ContentPanel
            // 
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(3, 32);
            this.ContentPanel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.Size = new System.Drawing.Size(1002, 505);
            this.ContentPanel.TabIndex = 0;
            // 
            // MenuPanel
            // 
            this.MenuPanel.Controls.Add(this.rbMenuMain);
            this.MenuPanel.Controls.Add(this.rbMenuMonitor);
            this.MenuPanel.Controls.Add(this.rbMenuProcessFlow);
            this.MenuPanel.Controls.Add(this.rbMenuManul);
            this.MenuPanel.Controls.Add(this.rbMenuSetup);
            this.MenuPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MenuPanel.Location = new System.Drawing.Point(3, 0);
            this.MenuPanel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.MenuPanel.Name = "MenuPanel";
            this.MenuPanel.Padding = new System.Windows.Forms.Padding(15, 3, 0, 0);
            this.MenuPanel.Size = new System.Drawing.Size(1002, 32);
            this.MenuPanel.TabIndex = 1;
            // 
            // rbMenuMain
            // 
            this.rbMenuMain.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbMenuMain.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.rbMenuMain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.rbMenuMain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbMenuMain.Location = new System.Drawing.Point(15, 3);
            this.rbMenuMain.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.rbMenuMain.Name = "rbMenuMain";
            this.rbMenuMain.Size = new System.Drawing.Size(80, 26);
            this.rbMenuMain.TabIndex = 0;
            this.rbMenuMain.TabStop = true;
            this.rbMenuMain.Text = "主控頁";
            this.rbMenuMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbMenuMain.UseVisualStyleBackColor = true;
            this.rbMenuMain.Click += new System.EventHandler(this.rbMenuMain_Click);
            // 
            // rbMenuMonitor
            // 
            this.rbMenuMonitor.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbMenuMonitor.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.rbMenuMonitor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.rbMenuMonitor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbMenuMonitor.Location = new System.Drawing.Point(104, 3);
            this.rbMenuMonitor.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.rbMenuMonitor.Name = "rbMenuMonitor";
            this.rbMenuMonitor.Size = new System.Drawing.Size(80, 26);
            this.rbMenuMonitor.TabIndex = 1;
            this.rbMenuMonitor.TabStop = true;
            this.rbMenuMonitor.Text = "即時監控";
            this.rbMenuMonitor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbMenuMonitor.UseVisualStyleBackColor = true;
            this.rbMenuMonitor.Click += new System.EventHandler(this.rbMenuMonitor_Click);
            // 
            // rbMenuProcessFlow
            // 
            this.rbMenuProcessFlow.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbMenuProcessFlow.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.rbMenuProcessFlow.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.rbMenuProcessFlow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbMenuProcessFlow.Location = new System.Drawing.Point(193, 3);
            this.rbMenuProcessFlow.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.rbMenuProcessFlow.Name = "rbMenuProcessFlow";
            this.rbMenuProcessFlow.Size = new System.Drawing.Size(80, 26);
            this.rbMenuProcessFlow.TabIndex = 2;
            this.rbMenuProcessFlow.TabStop = true;
            this.rbMenuProcessFlow.Text = "工序編輯";
            this.rbMenuProcessFlow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbMenuProcessFlow.UseVisualStyleBackColor = true;
            this.rbMenuProcessFlow.Click += new System.EventHandler(this.rbMenuWorkSetup_Click);
            // 
            // rbMenuManul
            // 
            this.rbMenuManul.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbMenuManul.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.rbMenuManul.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.rbMenuManul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbMenuManul.Location = new System.Drawing.Point(282, 3);
            this.rbMenuManul.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.rbMenuManul.Name = "rbMenuManul";
            this.rbMenuManul.Size = new System.Drawing.Size(80, 26);
            this.rbMenuManul.TabIndex = 3;
            this.rbMenuManul.TabStop = true;
            this.rbMenuManul.Text = "手動";
            this.rbMenuManul.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbMenuManul.UseVisualStyleBackColor = true;
            this.rbMenuManul.CheckedChanged += new System.EventHandler(this.rbMenuManul_CheckedChanged);
            // 
            // rbMenuSetup
            // 
            this.rbMenuSetup.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbMenuSetup.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.rbMenuSetup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.rbMenuSetup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbMenuSetup.Location = new System.Drawing.Point(371, 3);
            this.rbMenuSetup.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.rbMenuSetup.Name = "rbMenuSetup";
            this.rbMenuSetup.Size = new System.Drawing.Size(80, 26);
            this.rbMenuSetup.TabIndex = 4;
            this.rbMenuSetup.TabStop = true;
            this.rbMenuSetup.Text = "設定";
            this.rbMenuSetup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbMenuSetup.UseVisualStyleBackColor = true;
            this.rbMenuSetup.Click += new System.EventHandler(this.rbMenuSetup_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 561);
            this.Controls.Add(this.TLP);
            this.Controls.Add(this.statusStrip);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Locking Machine";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.TLP.ResumeLayout(false);
            this.MenuPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StatusStrip statusStrip;
        private ToolStripStatusLabel sbZ;
        private ToolStripStatusLabel sbClock;
        private System.Windows.Forms.Timer ClockTimer;
        private TableLayoutPanel TLP;
        private Panel ContentPanel;
        private FlowLayoutPanel MenuPanel;
        private RadioButton rbMenuMain;
        private RadioButton rbMenuProcessFlow;
        private RadioButton rbMenuMonitor;
        private RadioButton rbMenuSetup;
        private ToolStripStatusLabel sbR;
        private ToolStripStatusLabel sbTorque;
        private ToolStripStatusLabel sbHeight;
        private ToolStripStatusLabel sbMessage;
        private ToolStripStatusLabel sbZTitle;
        private ToolStripStatusLabel sbRTitle;
        private ToolStripStatusLabel sbTorqueTitle;
        private ToolStripStatusLabel sbHeightTitle;
        private ToolStripProgressBar sbProgressBar;
        private RadioButton rbMenuManul;
    }
}
