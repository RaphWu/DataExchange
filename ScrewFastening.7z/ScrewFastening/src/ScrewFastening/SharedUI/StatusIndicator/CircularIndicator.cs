﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.ScrewFastening.SharedUI.StatusIndicator
{
    [DefaultProperty("IsOn")]
    [DefaultEvent("Click")]
    public class CircularIndicator : Control
    {
        private Color _onColor = Color.Lime;
        [Category("Appearance"), Description("指示燈亮起時的顏色")]
        public Color OnColor
        {
            get => _onColor;
            set { if (_onColor != value) { _onColor = value; Invalidate(); } }
        }

        private Color _offColor = Color.DimGray;
        [Category("Appearance"), Description("指示燈關閉時的顏色")]
        public Color OffColor
        {
            get => _offColor;
            set { if (_offColor != value) { _offColor = value; Invalidate(); } }
        }

        private Color _borderColor = Color.Black;
        [Category("Appearance"), Description("邊框顏色")]
        public Color BorderColor
        {
            get => _borderColor;
            set { if (_borderColor != value) { _borderColor = value; Invalidate(); } }
        }

        private Color _onTextColor = Color.Black;
        [Category("Appearance"), Description("文字亮起時的顏色")]
        public Color OnTextColor
        {
            get => _onTextColor;
            set { if (_onTextColor != value) { _onTextColor = value; Invalidate(); } }
        }

        private Color _offTextColor = Color.White;
        [Category("Appearance"), Description("文字關閉時的顏色")]
        public Color OffTextColor
        {
            get => _offTextColor;
            set { if (_offTextColor != value) { _offTextColor = value; Invalidate(); } }
        }

        private bool _isOn = false;
        [Category("Behavior"), Description("指示燈是否亮起")]
        public bool IsOn
        {
            get => _isOn;
            set { if (_isOn != value) { _isOn = value; Invalidate(); } }
        }

        private string _displayText = "";
        [Category("Appearance"), Description("指示燈顯示文字")]
        public string DisplayText
        {
            get => _displayText;
            set { if (_displayText != value) { _displayText = value; Invalidate(); } }
        }

        private bool _autoScaleText = false;
        [Category("Appearance"), Description("文字自動縮放")]
        public bool AutoScaleText
        {
            get => _autoScaleText;
            set { if (_autoScaleText != value) { _autoScaleText = value; Invalidate(); } }
        }

        [Category("Appearance"), Description("文字字體")]
        public Font DisplayFont
        {
            get => Font;
            set { if (Font != value) { Font = value; Invalidate(); } }
        }

        public CircularIndicator()
        {
            SetStyle(
                ControlStyles.UserPaint |
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.Opaque,
                true);

            Size = new Size(21, 21);
            TabStop = false;
            if (ForeColor == Color.Empty) ForeColor = Color.Black;
        }

        protected override void OnPaintBackground(PaintEventArgs pevent)
        {
            // 不呼叫 base，避免畫出方形背景
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            using (var path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                path.AddEllipse(ClientRectangle);
                Region = new Region(path);
            }
        }


        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
            Rectangle rect = new Rectangle(1, 1, Width - 2, Height - 2);

            using (var brush = new SolidBrush(IsOn ? OnColor : OffColor))
                e.Graphics.FillEllipse(brush, rect);
            using (var pen = new Pen(BorderColor))
                e.Graphics.DrawEllipse(pen, rect);

            if (!string.IsNullOrEmpty(DisplayText))
            {
                Color textColor = IsOn ? OnTextColor : OffTextColor;
                if (AutoScaleText)
                    DrawAutoScaledText(e.Graphics, DisplayText, rect, textColor);
                else
                    DrawCenteredText(e.Graphics, DisplayText, rect, textColor);
            }
        }

        private void DrawCenteredText(Graphics g, string text, Rectangle bounds, Color color)
        {
            Size textSize = TextRenderer.MeasureText(g, text, Font);
            int x = bounds.X + (bounds.Width - textSize.Width) / 2 + 1;
            int y = bounds.Y + (bounds.Height - textSize.Height) / 2 + 1;
            TextRenderer.DrawText(g, text, Font, new Rectangle(x, y, textSize.Width, textSize.Height), color, TextFormatFlags.Left | TextFormatFlags.Top);
        }

        private void DrawAutoScaledText(Graphics g, string text, Rectangle bounds, Color color)
        {
            float minSize = 2f;
            float maxSize = Font.Size;
            float bestSize = minSize;

            while (minSize <= maxSize)
            {
                float mid = (minSize + maxSize) / 2;
                using (var testFont = new Font(Font.FontFamily, mid, Font.Style))
                {
                    Size size = TextRenderer.MeasureText(g, text, testFont);
                    if (size.Width <= bounds.Width && size.Height <= bounds.Height)
                    {
                        bestSize = mid;
                        minSize = mid + 0.5f;
                    }
                    else
                    {
                        maxSize = mid - 0.5f;
                    }
                }
            }

            using (var finalFont = new Font(Font.FontFamily, bestSize, Font.Style))
            {
                Size textSize = TextRenderer.MeasureText(g, text, finalFont);
                int x = bounds.X + (bounds.Width - textSize.Width) / 2 + 1;
                int y = bounds.Y + (bounds.Height - textSize.Height) / 2 + 1;
                TextRenderer.DrawText(g, text, finalFont, new Rectangle(x, y, textSize.Width, textSize.Height), color, TextFormatFlags.Left | TextFormatFlags.Top);
            }
        }
    }
}
