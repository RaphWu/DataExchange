﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.ScrewFastening.SharedUI.StatusIndicator
{
    /// <summary>
    /// 多重圓形指示燈控件。
    /// </summary>
    /// <remarks>TableLayout 思維 + Hover 高亮 + 老舊電腦效能優化。</remarks>
    public class MultiCircularIndicator : Control
    {
        /// <summary>
        /// 表示單一指示燈的項目。
        /// </summary>
        public class IndicatorItem
        {
            /// <summary>
            /// 指示燈是否為開啟狀態。
            /// </summary>
            public bool IsOn;

            /// <summary>
            /// 指示燈的文字描述。
            /// </summary>
            public string Text;
        }

        #region Fields

        private List<IndicatorItem> _indicators = new List<IndicatorItem>();
        private int _updateLockCount = 0;
        private bool _layoutDirty = false;
        private bool _invalidateDirty = false;

        private readonly List<int> _maxTextWidthPerColumn = new List<int>();
        private readonly List<int> _headerTextWidthPerColumn = new List<int>();

        private SolidBrush _onBrush;
        private SolidBrush _offBrush;
        private Pen _borderPen;

        private int _hoverIndex = -1;

        #endregion Fields

        /// <summary>
        /// 取得指示燈的唯讀清單。
        /// </summary>
        public IReadOnlyList<IndicatorItem> Indicators => _indicators.AsReadOnly();

        /// <summary>
        /// 設定每列的指示燈數量。
        /// </summary>
        public List<int> Columns { get; set; } = new List<int>() { 2 };

        /// <summary>
        /// 設定每列的標題文字。
        /// </summary>
        public List<string> ColumnHeaders { get; set; } = new List<string>();

        /// <summary>
        /// 指示燈的大小（直徑）。
        /// </summary>
        public int IndicatorSize { get; set; } = 20;

        /// <summary>
        /// 每列之間的間距。
        /// </summary>
        public int RowSpacing { get; set; } = 4;

        /// <summary>
        /// 指示燈與文字之間的間距。
        /// </summary>
        public int TextSpacing { get; set; } = 5;

        /// <summary>
        /// Column之間的間距。
        /// </summary>
        public int ColumnSpacing { get; set; } = 8;

        /// <summary>
        /// 標題的高度。
        /// </summary>
        public int HeaderHeight { get; set; } = 22;

        /// <summary>
        /// 標題底線與第一顆指示燈的距離。
        /// </summary>
        public int HeaderBottomSpacing { get; set; } = 6;

        /// <summary>
        /// 指示燈亮起時的顏色。
        /// </summary>
        public Color OnColor { get; set; } = Color.Lime;

        /// <summary>
        /// 指示燈熄滅時的顏色。
        /// </summary>
        public Color OffColor { get; set; } = Color.DimGray;

        /// <summary>
        /// 指示燈文字的顏色。
        /// </summary>
        public Color TextColor { get; set; } = Color.Black;

        /// <summary>
        /// 指示燈邊框的顏色。
        /// </summary>
        public Color BorderColor { get; set; } = Color.Black;

        /// <summary>
        /// 標題文字的顏色。
        /// </summary>
        public Color HeaderTextColor { get; set; } = Color.Black;

        /// <summary>
        /// 標題底線的顏色。
        /// </summary>
        public Color HeaderLineColor { get; set; } = Color.DarkGray;

        /// <summary>
        /// 標題底線的粗細。
        /// </summary>
        public int HeaderLineThickness { get; set; } = 2;

        /// <summary>
        /// 滑鼠懸停時的高亮顏色。
        /// </summary>
        public Color HoverColor { get; set; } = Color.Yellow;

        /// <summary>
        /// 標題的字型。
        /// </summary>
        public Font HeaderFont { get; set; }

        /// <summary>
        /// 當指示燈被點擊時觸發的事件。
        /// </summary>
        public event EventHandler<int> IndicatorClick;

        /// <summary>
        /// 初始化 <see cref="MultiCircularIndicator"/> 類別的新執行個體。
        /// </summary>
        public MultiCircularIndicator()
        {
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.UserPaint |
                ControlStyles.SupportsTransparentBackColor, true);

            BackColor = Color.Transparent;
            HeaderFont = new Font(Font, FontStyle.Bold);

            _onBrush = new SolidBrush(OnColor);
            _offBrush = new SolidBrush(OffColor);
            _borderPen = new Pen(BorderColor);

            MouseMove += MultiCircularIndicator_MouseMove;
            MouseLeave += MultiCircularIndicator_MouseLeave;
        }

        #region Public API

        /// <summary>
        /// 設定指示燈的清單。
        /// </summary>
        /// <param name="items">指示燈項目的清單。</param>
        public void SetIndicators(List<IndicatorItem> items)
        {
            _indicators = items ?? new List<IndicatorItem>();
            _layoutDirty = true;
            if (_updateLockCount == 0)
                RecalculateLayout();
        }

        /// <summary>
        /// 設定每列的指示燈數量。
        /// </summary>
        /// <param name="columns">每列的指示燈數量。</param>
        public void SetColumns(List<int> columns)
        {
            Columns = columns ?? new List<int>() { 1 };
            _layoutDirty = true;
            if (_updateLockCount == 0)
                RecalculateLayout();
        }

        /// <summary>
        /// 更新指定索引的指示燈狀態與文字。
        /// </summary>
        /// <param name="index">指示燈的索引。</param>
        /// <param name="isOn">指示燈是否為開啟狀態。</param>
        /// <param name="text">指示燈的文字描述（可選）。</param>
        public void UpdateIndicator(int index, bool isOn, string text = null)
        {
            if (index < 0 || index >= _indicators.Count)
                return;

            var item = _indicators[index];
            bool needLayout = false;

            if (item.IsOn != isOn)
                item.IsOn = isOn;

            if (text != null && item.Text != text)
            {
                item.Text = text;
                needLayout = true;
            }

            if (_updateLockCount > 0)
            {
                if (needLayout)
                    _layoutDirty = true;
                else
                    _invalidateDirty = true;
                return;
            }

            if (needLayout)
                RecalculateLayout();
            else
                Invalidate(GetIndicatorBounds(index));
        }

        /// <summary>
        /// 開始更新指示燈，防止多次重繪。
        /// </summary>
        public void BeginUpdate() => _updateLockCount++;

        /// <summary>
        /// 結束更新指示燈，並執行必要的重繪或佈局。
        /// </summary>
        public void EndUpdate()
        {
            if (_updateLockCount == 0)
                return;

            _updateLockCount--;

            if (_updateLockCount == 0)
            {
                if (_layoutDirty)
                    RecalculateLayout();
                else if (_invalidateDirty)
                    Invalidate();

                _layoutDirty = false;
                _invalidateDirty = false;
            }
        }

        #endregion

        #region Layout

        /// <summary>
        /// 取得指定索引的指示燈範圍。
        /// </summary>
        /// <param name="index">指示燈的索引。</param>
        /// <returns>指示燈的範圍。</returns>
        private Rectangle GetIndicatorBounds(int index)
        {
            int col = 0;
            int row = index;

            foreach (var rows in Columns)
            {
                if (row < rows)
                    break;

                row -= rows;
                col++;
            }

            int x = GetColumnX(col);
            int y = HeaderHeight + HeaderBottomSpacing + row * (IndicatorSize + RowSpacing);

            return new Rectangle(x, y, IndicatorSize, IndicatorSize);
        }

        /// <summary>
        /// 重新計算佈局。
        /// </summary>
        private void RecalculateLayout()
        {
            if (_updateLockCount > 0)
            {
                _layoutDirty = true;
                return;
            }

            UpdateTextMetrics();
            Size = GetPreferredSize();
            Invalidate();
        }

        /// <summary>
        /// 更新文字的度量資訊。
        /// </summary>
        private void UpdateTextMetrics()
        {
            _maxTextWidthPerColumn.Clear();
            _headerTextWidthPerColumn.Clear();

            int index = 0;
            using (Graphics g = CreateGraphics())
            {
                for (int col = 0; col < Columns.Count; col++)
                {
                    int rows = Columns[col];
                    int maxIndicatorText = 0;

                    for (int r = 0; r < rows && index < _indicators.Count; r++, index++)
                    {
                        var t = _indicators[index].Text;
                        if (!string.IsNullOrEmpty(t))
                            maxIndicatorText = Math.Max(
                                maxIndicatorText,
                                TextRenderer.MeasureText(g, t, Font).Width);
                    }

                    _maxTextWidthPerColumn.Add(maxIndicatorText);

                    if (col < ColumnHeaders.Count && !string.IsNullOrEmpty(ColumnHeaders[col]))
                    {
                        _headerTextWidthPerColumn.Add(
                            TextRenderer.MeasureText(g, ColumnHeaders[col], HeaderFont).Width);
                    }
                    else
                    {
                        _headerTextWidthPerColumn.Add(0);
                    }
                }
            }
        }

        /// <summary>
        /// 取得指定列的寬度。
        /// </summary>
        /// <param name="col">列的索引。</param>
        /// <returns>列的寬度。</returns>
        private int GetColumnWidth(int col)
        {
            int indicatorWidth =
                IndicatorSize +
                (_maxTextWidthPerColumn[col] > 0
                    ? TextSpacing + _maxTextWidthPerColumn[col]
                    : 0);

            return Math.Max(indicatorWidth, _headerTextWidthPerColumn[col]);
        }

        /// <summary>
        /// 取得指定列的 X 座標。
        /// </summary>
        /// <param name="col">列的索引。</param>
        /// <returns>列的 X 座標。</returns>
        private int GetColumnX(int col)
        {
            int x = 0;
            for (int i = 0; i < col; i++)
                x += GetColumnWidth(i) + ColumnSpacing;
            return x;
        }

        /// <summary>
        /// 取得建議的控件大小。
        /// </summary>
        /// <returns>建議的控件大小。</returns>
        public Size GetPreferredSize()
        {
            int width = 0;
            int height = HeaderHeight;

            for (int col = 0; col < Columns.Count; col++)
            {
                width += GetColumnWidth(col);
                if (col < Columns.Count - 1)
                    width += ColumnSpacing;

                height = Math.Max(
                    height,
                    HeaderHeight + HeaderBottomSpacing + Columns[col] * (IndicatorSize + RowSpacing));
            }

            return new Size(width, height);
        }

        #endregion

        #region Paint

        /// <summary>
        /// 繪製控件。
        /// </summary>
        /// <param name="pea">繪製事件參數。</param>
        protected override void OnPaint(PaintEventArgs pea)
        {
            base.OnPaint(pea);

            int index = 0;

            for (int col = 0; col < Columns.Count; col++)
            {
                int x = GetColumnX(col);

                // Header
                if (col < ColumnHeaders.Count && !string.IsNullOrEmpty(ColumnHeaders[col]))
                {
                    var headerRect = new Rectangle(x, 0, GetColumnWidth(col), HeaderHeight);

                    TextRenderer.DrawText(
                        pea.Graphics,
                        ColumnHeaders[col],
                        HeaderFont,
                        headerRect,
                        HeaderTextColor,
                        TextFormatFlags.HorizontalCenter |
                        TextFormatFlags.VerticalCenter |
                        TextFormatFlags.SingleLine
                    );

                    // Header bottom line
                    using (Pen pen = new Pen(HeaderLineColor, HeaderLineThickness))
                    {
                        int lineY = HeaderHeight - HeaderLineThickness / 2;
                        pea.Graphics.DrawLine(
                            pen,
                            x,
                            lineY,
                            x + GetColumnWidth(col),
                            lineY
                        );
                    }
                }

                // Indicators
                for (int row = 0; row < Columns[col] && index < _indicators.Count; row++, index++)
                {
                    int y = HeaderHeight + HeaderBottomSpacing + row * (IndicatorSize + RowSpacing);
                    var item = _indicators[index];

                    var circle = new Rectangle(x, y, IndicatorSize, IndicatorSize);

                    var brush = item.IsOn ? _onBrush : _offBrush;

                    // Hover 高亮
                    if (index == _hoverIndex)
                    {
                        using (SolidBrush hoverBrush = new SolidBrush(HoverColor))
                        {
                            pea.Graphics.FillEllipse(hoverBrush, circle);
                        }
                    }
                    else
                    {
                        pea.Graphics.FillEllipse(brush, circle);
                    }

                    pea.Graphics.DrawEllipse(_borderPen, circle);

                    if (!string.IsNullOrEmpty(item.Text))
                    {
                        var textRect = new Rectangle(
                            x + IndicatorSize + TextSpacing,
                            y,
                            _maxTextWidthPerColumn[col],
                            IndicatorSize);

                        TextRenderer.DrawText(
                            pea.Graphics,
                            item.Text,
                            Font,
                            textRect,
                            TextColor,
                            TextFormatFlags.Left |
                            TextFormatFlags.VerticalCenter |
                            TextFormatFlags.SingleLine);
                    }
                }
            }
        }

        #endregion

        #region Mouse Hover

        /// <summary>
        /// 處理滑鼠移動事件，更新懸停的指示燈。
        /// </summary>
        private void MultiCircularIndicator_MouseMove(object sender, MouseEventArgs e)
        {
            int hover = -1;
            for (int i = 0; i < _indicators.Count; i++)
            {
                if (GetIndicatorBounds(i).Contains(e.Location))
                {
                    hover = i;
                    break;
                }
            }

            if (_hoverIndex != hover)
            {
                _hoverIndex = hover;
                Invalidate(); // 只 repaint hover
            }
        }

        /// <summary>
        /// 處理滑鼠離開事件，清除懸停的指示燈。
        /// </summary>
        private void MultiCircularIndicator_MouseLeave(object sender, EventArgs e)
        {
            if (_hoverIndex != -1)
            {
                _hoverIndex = -1;
                Invalidate();
            }
        }

        #endregion

        #region Mouse Click

        /// <summary>
        /// 處理滑鼠點擊事件，觸發指示燈點擊事件。
        /// </summary>
        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);

            for (int i = 0; i < _indicators.Count; i++)
            {
                if (GetIndicatorBounds(i).Contains(e.Location))
                {
                    IndicatorClick?.Invoke(this, i);
                    return;
                }
            }
        }

        #endregion
    }
}
