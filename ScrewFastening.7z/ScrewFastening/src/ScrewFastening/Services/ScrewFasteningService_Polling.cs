﻿using System;
using System.Threading;
using Calin.Extensions;
using Calin.MotionControl.Advantech.Services;

namespace Calin.ScrewFastening.Services
{
    public partial class ScrewFasteningService
    {
        #region Fields

        private CancellationTokenSource _pollingCts;
        private Thread _acquisitionThread;
        private Thread _monitoringThread;
        //private readonly System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();

        private byte diValue = 0;

        #endregion Fields

        #region Methods

        /// <inheritdoc/>
        public void PollingStop()
        {
            // 先發出取消請求
            _pollingCts?.Cancel();

            // 等待執行緒結束（最多等待 2 秒），如果沒結束再嘗試 Interrupt
            if (_acquisitionThread != null)
            {
                try
                {
                    if (!_acquisitionThread.Join(2000))
                    {
                        // 若執行緒在 Sleep/Wait/Join 中，Interrupt 會拋出 ThreadInterruptedException
                        _acquisitionThread.Interrupt();
                        _acquisitionThread.Join(500);
                    }
                }
                catch (ThreadInterruptedException)
                {
                    // 預期可能發生，忽略
                }
                catch (Exception)
                {
                    // Log／忽略其他例外（視需求處理）
                }
                finally
                {
                    _acquisitionThread = null;
                }
            }

            // 等待執行緒結束（最多等待 2 秒），如果沒結束再嘗試 Interrupt
            if (_monitoringThread != null)
            {
                try
                {
                    if (!_monitoringThread.Join(2000))
                    {
                        // 若執行緒在 Sleep/Wait/Join 中，Interrupt 會拋出 ThreadInterruptedException
                        _monitoringThread.Interrupt();
                        _monitoringThread.Join(500);
                    }
                }
                catch (ThreadInterruptedException)
                {
                    // 預期可能發生，忽略
                }
                catch (Exception)
                {
                    // Log／忽略其他例外（視需求處理）
                }
                finally
                {
                    _monitoringThread = null;
                }
            }

            // 釋放 CancellationTokenSource
            _pollingCts?.Dispose();
            _pollingCts = null;

            // 停用並釋放 Timer
            //_timer.Stop();
            //_timer.Tick -= Monitoring_Tick;
            //_timer.Dispose();
        }

        /// <inheritdoc/>
        public void PollingStart()
        {
            _pollingCts = new CancellationTokenSource();

            //_acquisitionThread = new Thread(() => AcquisitionProc(_pollingCts.Token));
            //_acquisitionThread.Name = "Data Acquisition Thread";
            //_acquisitionThread.IsBackground = true;
            //_acquisitionThread.Priority = ThreadPriority.Highest;
            //_acquisitionThread.Start();

            _monitoringThread = new Thread(() => ParseProc(_pollingCts.Token));
            _monitoringThread.Name = "Data Acquisition Thread";
            _monitoringThread.IsBackground = true;
            _monitoringThread.Priority = ThreadPriority.Highest;
            _monitoringThread.Start();

            //_timer.Interval = 50;
            //_timer.Tick += Monitoring_Tick;
            //_timer.Start();
        }

        #endregion Methods

        #region Polling Procedures

        //private void AcquisitionProc(CancellationToken token)
        //{
        //    var sw = Stopwatch.StartNew();
        //    long ticksPerMs = Stopwatch.Frequency / 1000;
        //    long nextTick = sw.ElapsedTicks;
        //    var spin = new SpinWait();

        //    while (!token.IsCancellationRequested)
        //    {
        //        long now = sw.ElapsedTicks;
        //        if (now >= nextTick)
        //        {
        //            nextTick += ticksPerMs;
        //            spin.Reset();

        //            // 用於須快速反應的停止條件
        //            //if (torque >= TorqueLimit)
        //            //{
        //            //    EmergencyStop();
        //            //}
        //        }
        //        else
        //        {
        //            spin.SpinOnce();
        //        }
        //    }
        //}

        private void ParseProc(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                // 高度計
                if (_dlrs1aData.HeightDisplacementActive)
                {
                    // PS:程式啟動時第一次讀取常常沒回應，原因待查
                    if (_rawData.WaitForReceiveHeightDisplacement++ > 0)
                    {
                        // 若50次循環都沒收到回應，重新發出讀取指令
                        if (_rawData.WaitForReceiveHeightDisplacement > 50)
                            _rawData.WaitForReceiveHeightDisplacement = 0;
                    }
                    else
                    {
#if DEBUG
                        _dispStopwatch.Restart();
#endif
                        _lmData.dlrs1a.ReadValue();
                        //ThreadExt.RunOnUiThread(() => { _lmData.dlrs1a.ReadAll(); });
                    }
                }

                // USB4704 DI
                if (_bindingData.DaqIoActive)
                {
                    if (_lmData.dio.ReadDigital(0, out diValue))
                    {
                        ThreadExt.RunOnUiThread(() =>
                        {
                            _rawData.DI0 = (diValue & 0x01) != 0;
                            _rawData.DI1 = (diValue & 0x02) != 0;
                            _rawData.DI2 = (diValue & 0x04) != 0;
                            _rawData.DI3 = (diValue & 0x08) != 0;
                            _rawData.DI4 = (diValue & 0x10) != 0;
                            _rawData.DI5 = (diValue & 0x20) != 0;
                            _rawData.DI6 = (diValue & 0x40) != 0;
                            _rawData.DI7 = (diValue & 0x80) != 0;
                        });
                    }
                }

                try
                {
                    if (token.WaitHandle.WaitOne(25)) break;
                }
                catch (ObjectDisposedException)
                {
                    break; // 若 token 已被處置，則跳出
                }
            }
        }

        /// <summary>
        /// Advantech ACM 狀態更新事件處理程序。
        /// </summary>
        private void OnAcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs asue)
        {
            int axisNo = asue.AxisNo;
            var parsedAxisState = asue.ParsedAxisState;

            // 軸狀態
            var axisState = parsedAxisState.AxisStateFlags;
            if (_mcData.STA_AX_DISABLE[axisNo] != parsedAxisState.STA_AX_DISABLE)
                _mcData.STA_AX_DISABLE[axisNo] = parsedAxisState.STA_AX_DISABLE;

            if (axisNo == 0)
                _mcData.ZAxisActive = !parsedAxisState.STA_AX_DISABLE;
            else
                _mcData.RAxisActive = !parsedAxisState.STA_AX_DISABLE;

            if (_mcData.STA_AX_READY[axisNo] != parsedAxisState.STA_AX_READY)
                _mcData.STA_AX_READY[axisNo] = parsedAxisState.STA_AX_READY;

            if (_mcData.STA_AX_STOPPING[axisNo] != parsedAxisState.STA_AX_STOPPING)
                _mcData.STA_AX_STOPPING[axisNo] = parsedAxisState.STA_AX_STOPPING;

            if (_mcData.STA_AX_ERROR_STOP[axisNo] != parsedAxisState.STA_AX_ERROR_STOP)
                _mcData.STA_AX_ERROR_STOP[axisNo] = parsedAxisState.STA_AX_ERROR_STOP;

            if (_mcData.STA_AX_HOMING[axisNo] != parsedAxisState.STA_AX_HOMING)
                _mcData.STA_AX_HOMING[axisNo] = parsedAxisState.STA_AX_HOMING;

            if (_mcData.STA_AX_PTP_MOTION[axisNo] != parsedAxisState.STA_AX_PTP_MOTION)
                _mcData.STA_AX_PTP_MOTION[axisNo] = parsedAxisState.STA_AX_PTP_MOTION;

            if (_mcData.STA_AX_CONTI_MOTION[axisNo] != parsedAxisState.STA_AX_CONTI_MOTION)
                _mcData.STA_AX_CONTI_MOTION[axisNo] = parsedAxisState.STA_AX_CONTI_MOTION;

            if (_mcData.STA_AX_SYNC_MOTION[axisNo] != parsedAxisState.STA_AX_SYNC_MOTION)
                _mcData.STA_AX_SYNC_MOTION[axisNo] = parsedAxisState.STA_AX_SYNC_MOTION;

            if (_mcData.STA_AX_EXT_JOG[axisNo] != parsedAxisState.STA_AX_EXT_JOG)
                _mcData.STA_AX_EXT_JOG[axisNo] = parsedAxisState.STA_AX_EXT_JOG;

            if (_mcData.STA_AX_EXT_MPG[axisNo] != parsedAxisState.STA_AX_EXT_MPG)
                _mcData.STA_AX_EXT_MPG[axisNo] = parsedAxisState.STA_AX_EXT_MPG;

            if (_mcData.STA_AX_PAUSE[axisNo] != parsedAxisState.STA_AX_PAUSE)
                _mcData.STA_AX_PAUSE[axisNo] = parsedAxisState.STA_AX_PAUSE;

            if (_mcData.STA_AX_BUSY[axisNo] != parsedAxisState.STA_AX_BUSY)
                _mcData.STA_AX_BUSY[axisNo] = parsedAxisState.STA_AX_BUSY;

            if (_mcData.STA_AX_WAIT_DI[axisNo] != parsedAxisState.STA_AX_WAIT_DI)
                _mcData.STA_AX_WAIT_DI[axisNo] = parsedAxisState.STA_AX_WAIT_DI;

            if (_mcData.STA_AX_WAIT_PTP[axisNo] != parsedAxisState.STA_AX_WAIT_PTP)
                _mcData.STA_AX_WAIT_PTP[axisNo] = parsedAxisState.STA_AX_WAIT_PTP;

            if (_mcData.STA_AX_WAIT_VEL[axisNo] != parsedAxisState.STA_AX_WAIT_VEL)
                _mcData.STA_AX_WAIT_VEL[axisNo] = parsedAxisState.STA_AX_WAIT_VEL;

            if (_mcData.STA_AX_EXT_JOG_READY[axisNo] != parsedAxisState.STA_AX_EXT_JOG_READY)
                _mcData.STA_AX_EXT_JOG_READY[axisNo] = parsedAxisState.STA_AX_EXT_JOG_READY;

            // 運動狀態
            var axisMotionState = parsedAxisState.AxisMotionFlags;
            if (_mcData.Stop[axisNo] != parsedAxisState.Stop)
                _mcData.Stop[axisNo] = parsedAxisState.Stop;

            if (_mcData.CorrectBksh[axisNo] != parsedAxisState.CorrectBksh)
                _mcData.CorrectBksh[axisNo] = parsedAxisState.CorrectBksh;

            if (_mcData.InFA[axisNo] != parsedAxisState.InFA)
                _mcData.InFA[axisNo] = parsedAxisState.InFA;

            if (_mcData.InFL[axisNo] != parsedAxisState.InFL)
                _mcData.InFL[axisNo] = parsedAxisState.InFL;

            if (_mcData.InACC[axisNo] != parsedAxisState.InACC)
                _mcData.InACC[axisNo] = parsedAxisState.InACC;

            if (_mcData.InACC[axisNo] != parsedAxisState.InACC)
                _mcData.InACC[axisNo] = parsedAxisState.InACC;

            if (_mcData.InFH[axisNo] != parsedAxisState.InFH)
                _mcData.InFH[axisNo] = parsedAxisState.InFH;

            if (_mcData.InDEC[axisNo] != parsedAxisState.InDEC)
                _mcData.InDEC[axisNo] = parsedAxisState.InDEC;

            if (_mcData.WaitINP[axisNo] != parsedAxisState.WaitINP)
                _mcData.WaitINP[axisNo] = parsedAxisState.WaitINP;

            // I/O
            var axisIoState = parsedAxisState.AxisIoFlags;
            if (_mcData.RDY[axisNo] != parsedAxisState.RDY)
                _mcData.RDY[axisNo] = parsedAxisState.RDY;

            if (_mcData.ALM[axisNo] != parsedAxisState.ALM)
                _mcData.ALM[axisNo] = parsedAxisState.ALM;

            if (_mcData.LMT_Positive[axisNo] != parsedAxisState.LMT_Positive)
                _mcData.LMT_Positive[axisNo] = parsedAxisState.LMT_Positive;

            if (_mcData.LMT_Negative[axisNo] != parsedAxisState.LMT_Negative)
                _mcData.LMT_Negative[axisNo] = parsedAxisState.LMT_Negative;

            if (_mcData.ORG[axisNo] != parsedAxisState.ORG)
                _mcData.ORG[axisNo] = parsedAxisState.ORG;

            if (_mcData.DIR[axisNo] != parsedAxisState.DIR)
                _mcData.DIR[axisNo] = parsedAxisState.DIR;

            if (_mcData.EMG[axisNo] != parsedAxisState.EMG)
                _mcData.EMG[axisNo] = parsedAxisState.EMG;

            if (_mcData.EZ[axisNo] != parsedAxisState.EZ)
                _mcData.EZ[axisNo] = parsedAxisState.EZ;

            if (_mcData.LTC[axisNo] != parsedAxisState.LTC)
                _mcData.LTC[axisNo] = parsedAxisState.LTC;

            if (_mcData.INP[axisNo] != parsedAxisState.INP)
                _mcData.INP[axisNo] = parsedAxisState.INP;

            if (_mcData.SVON[axisNo] != parsedAxisState.SVON)
                _mcData.SVON[axisNo] = parsedAxisState.SVON;

            if (_mcData.ALRM[axisNo] != parsedAxisState.ALRM)
                _mcData.ALRM[axisNo] = parsedAxisState.ALRM;

            if (_mcData.SLMT_Positive[axisNo] != parsedAxisState.SLMT_Positive)
                _mcData.SLMT_Positive[axisNo] = parsedAxisState.SLMT_Positive;

            if (_mcData.SLMT_Negative[axisNo] != parsedAxisState.SLMT_Negative)
                _mcData.SLMT_Negative[axisNo] = parsedAxisState.SLMT_Negative;
        }

        #endregion Polling Procedures
    }
}
