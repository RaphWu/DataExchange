﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using Automation.BDaq;
using Calin.Helpers;
using Calin.ScrewFastening.Models;

namespace Calin.ScrewFastening.Services
{
    public partial class ScrewFasteningService : IScrewFastening_DAQ
    {
        #region Fields

        private readonly string _daqFile = "DAQ.json";
        private double[] _streamingData;
        private double _instantData;

        private Thread _thread;
        private CancellationTokenSource _cts;

#if DEBUG
        private readonly Stopwatch _daqStopwatch = new Stopwatch();
#endif

        #endregion Fields

        /// <inheritdoc/>
        public void DaqInit()
        {
            try
            {
                DaqLoadConfig();

                _daqData.TorqueMeterActive = _lmData.usb4704Instant.Usb4704InstantInit(_daqData.DeviceCode);
                //_bindingData.TorqueMeterActive = _lmData.usb4704Streaming.Usb4704StreamingInit(_daqData.DeviceCode);

                if (_daqData.TorqueMeterActive)
                    for (int ch = 0; ch < _lmData.usb4704Streaming.ChannelCountMax; ch++)
                    {
                        _lmData.usb4704Streaming.SetSignalType(ch, AiSignalType.Differential);
                        _lmData.usb4704Streaming.SetValueRange(ch, ValueRange.V_Neg2To2);
                    }

                _bindingData.DaqIoActive = _lmData.dio.Usb4704DioInit(_daqData.DeviceCode);
            }
            catch (Exception ex)
            {
                _daqData.TorqueMeterActive = false;
            }
        }

        /// <inheritdoc/>
        public void DaqClose()
        {
            _lmData.dio.Dispose();
            _daqData.TorqueMeterActive = false;
        }

        /// <inheritdoc/>
        public void DaqSaveConfig(DaqData config)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _daqFile);
            JsonFileHelper.Save(path, _daqData);
        }

        /// <inheritdoc/>
        public void DaqLoadConfig()
        {
            DaqData config = null;

            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _daqFile);
            if (File.Exists(path))
            {
                try
                {
                    config = JsonFileHelper.Read<DaqData>(path);
                }
                catch (Exception ex)
                {
                    // 讀取失敗：不要立刻覆寫檔案（避免讀取中出錯就覆蓋原始檔）
                    Console.WriteLine($"DaqLoadConfig: failed to read config file '{path}': {ex}");
                    config = null;
                }
            }

            if (config == null)
            {
                config = new DaqData();

                // 只有當檔案原本不存在時才儲存預設檔，若原本有檔但讀取失敗則不立刻覆蓋
                if (!File.Exists(path))
                {
                    DaqSaveConfig(config);
                }
            }

            _daqData.DeviceCode = config.DeviceCode;
            _daqData.TorqueLimitH = config.TorqueLimitH;
            _daqData.TorqueLimitL = config.TorqueLimitL;
            _daqData.GateMarkPort = config.GateMarkPort;

            _rawData.TorqueLimitH = _daqData.TorqueLimitH;
            _rawData.TorqueLimitL = _daqData.TorqueLimitL;
        }

        /// <inheritdoc/>
        public void DaqStartAcquisition()
        {
            _cts = new CancellationTokenSource();
            if (_daqData.TorqueMeterActive)
            {
                _thread = new Thread(() => DaqProc(_cts.Token));
                _thread.Name = "Data Acquisition Thread";
                _thread.IsBackground = true;
                _thread.Priority = ThreadPriority.Highest;
                _thread.Start();
#if DEBUG
                _daqStopwatch.Restart();
#endif
                //_lmData.usb4704Streaming.DataReady += Usb4704Streaming_DataReady;
                //_lmData.usb4704Streaming.SetClockRate(_daqData.ClockRate);
                //_lmData.usb4704Streaming.StartAcquisition();
            }
        }

        private void DaqProc(CancellationToken token)
        {
            var sw = Stopwatch.StartNew();
            long ticksPerMs = Stopwatch.Frequency / 800;
            long nextTick = sw.ElapsedTicks;
            var spin = new SpinWait();

            while (!token.IsCancellationRequested)
            {
                long now = sw.ElapsedTicks;
                if (now >= nextTick)
                {
                    nextTick += ticksPerMs;
                    spin.Reset();

                    if (!_daqData.TorqueMeterActive)
                        token.ThrowIfCancellationRequested();

                    var err = _lmData.usb4704Instant.ReadInstantData(0, out _instantData);
                    if (err == ErrorCode.Success)
                    {
                        _rawData.TorqueValue = _instantData;

                        if (_rawData.TorqueMaxValue < _rawData.TorqueValue)
                            _rawData.TorqueMaxValue = _rawData.TorqueValue;

                        if (_rawData.IsMeasuring && _rawData.TorqueFinalValue < _rawData.TorqueValue)
                            _rawData.TorqueFinalValue = _rawData.TorqueValue;
                    }
                    else
                    {
                        DaqStopAcquisition();
                    }
#if DEBUG
                    _daqStopwatch.Stop();
                    _rawData.TorqueStopwatch = _daqStopwatch.Elapsed.TotalMilliseconds;
                    _daqStopwatch.Restart();
#endif
                }
                else
                {
                    spin.SpinOnce();
                }
            }
        }

        /// <inheritdoc/>
        public void DaqStopAcquisition()
        {
            if (_daqData.TorqueMeterActive)
            {
                _daqData.TorqueMeterActive = false;
                _cts.Cancel();

                //_lmData.usb4704Streaming.StopAcquisition();
                //_lmData.usb4704Streaming.DataReady -= Usb4704Streaming_DataReady;
            }
        }

        //        private void Usb4704Streaming_DataReady(object sender, EventArgs e)
        //        {
        //            var dataCount = _lmData.usb4704Streaming.AcquiredDataCount;
        //            if (dataCount > 0)
        //            {
        //#if DEBUG
        //                _daqStopwatch.Stop();
        //                //_bindingData.TorqueStopwatch = aa++;
        //                _rawData.TorqueStopwatch = _daqStopwatch.Elapsed.TotalMilliseconds;
        //                _daqStopwatch.Restart();
        //#endif
        //                //if (_dataScaled.Length < dataCount)
        //                //    _dataScaled = new double[dataCount];
        //                _streamingData = _lmData.usb4704Streaming.AcquiredDataArray;
        //                foreach (var value in _streamingData)
        //                {
        //                    _rawData.TorqueValue = value;
        //                    //if (value > _daqData.TorqueLimitH)
        //                    //{
        //                    //    int aa = 1;
        //                    //}
        //                }
        //            }
        //        }
    }
}
