﻿using System.Collections.Generic;
using Calin.Comm.DL_RS1A;
using Calin.DAQ.USB4704;

namespace Calin.ScrewFastening.Models
{
    /// <summary>
    /// 全專案共用資料，以及各子系統的實例。
    /// </summary>
    /// <remarks>這裡存放的資料是不存檔的。</remarks>
    public class LmData
    {
        internal readonly int uiScanTimeInterval = 20;

        internal List<string> comPortList = new List<string>();
        internal IDL_RS1A dlrs1a = default;
        internal IUsb4704Dio dio = default;
        internal IUsb4704Streaming usb4704Streaming = default;
        internal IUsb4704Instant usb4704Instant = default;
    }
}
