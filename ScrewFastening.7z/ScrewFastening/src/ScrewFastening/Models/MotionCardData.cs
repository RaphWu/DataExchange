﻿using Calin.MVVM;

namespace Calin.ScrewFastening.Models
{
    /// <summary>
    /// 運動控制卡資料模型。
    /// </summary>
    public class MotionCardData : ObservableObject
    {
        /// <summary>
        /// Z軸是否啟用。
        /// </summary>
        public bool ZAxisActive
        {
            get { return _zAxisActive; }
            set { SetProperty(ref _zAxisActive, value); }
        }
        private bool _zAxisActive;

        /// <summary>
        /// Z軸目前座標。
        /// </summary>
        public double ZAxisCoor
        {
            get { return _zAxisCoor; }
            set { SetProperty(ref _zAxisCoor, value); }
        }
        private double _zAxisCoor;

        /// <summary>
        /// R軸是否啟用。
        /// </summary>
        public bool RAxisActive
        {
            get { return _rAxisActive; }
            set { SetProperty(ref _rAxisActive, value); }
        }
        private bool _rAxisActive;

        /// <summary>
        /// R軸目前轉速(RPM)。
        /// </summary>
        public double RPM
        {
            get { return _rpm; }
            set { SetProperty(ref _rpm, value); }
        }
        private double _rpm;

        /// <summary>
        /// R軸目前角度。
        /// </summary>
        public double Angle
        {
            get { return _angle; }
            set { SetProperty(ref _angle, value); }
        }
        private double _angle;

        #region 信號燈

        // 軸狀態旗標Buffers
        public bool[] STA_AX_DISABLE = new bool[2];
        public bool[] STA_AX_READY = new bool[2];
        public bool[] STA_AX_STOPPING = new bool[2];
        public bool[] STA_AX_ERROR_STOP = new bool[2];
        public bool[] STA_AX_HOMING = new bool[2];
        public bool[] STA_AX_PTP_MOTION = new bool[2];
        public bool[] STA_AX_CONTI_MOTION = new bool[2];
        public bool[] STA_AX_SYNC_MOTION = new bool[2];
        public bool[] STA_AX_EXT_JOG = new bool[2];
        public bool[] STA_AX_EXT_MPG = new bool[2];
        public bool[] STA_AX_PAUSE = new bool[2];
        public bool[] STA_AX_BUSY = new bool[2];
        public bool[] STA_AX_WAIT_DI = new bool[2];
        public bool[] STA_AX_WAIT_PTP = new bool[2];
        public bool[] STA_AX_WAIT_VEL = new bool[2];
        public bool[] STA_AX_EXT_JOG_READY = new bool[2];

        // 軸運動旗標Buffers
        public bool[] Stop = new bool[2];
        public bool[] CorrectBksh = new bool[2];
        public bool[] InFA = new bool[2];
        public bool[] InFL = new bool[2];
        public bool[] InACC = new bool[2];
        public bool[] InFH = new bool[2];
        public bool[] InDEC = new bool[2];
        public bool[] WaitINP = new bool[2];

        // 軸的運動 I/O 旗標Buffers
        public bool[] RDY = new bool[2];
        public bool[] ALM = new bool[2];
        public bool[] LMT_Positive = new bool[2];
        public bool[] LMT_Negative = new bool[2];
        public bool[] ORG = new bool[2];
        public bool[] DIR = new bool[2];
        public bool[] EMG = new bool[2];
        public bool[] EZ = new bool[2];
        public bool[] LTC = new bool[2];
        public bool[] INP = new bool[2];
        public bool[] SVON = new bool[2];
        public bool[] ALRM = new bool[2];
        public bool[] SLMT_Positive = new bool[2];
        public bool[] SLMT_Negative = new bool[2];

        #endregion 信號燈
    }
}
