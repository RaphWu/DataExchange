// ===================================================================
// Calin.Logging.Serilog
// 
// ApplicationNameEnricher - �ۭq Enricher �d��
// ===================================================================

using System;
using Serilog.Core;
using Serilog.Events;

namespace Calin.Logging.Serilog.Enrichers
{
    /// <summary>
    /// �[�J���ε{���W�٪� Enricher�C
    /// </summary>
    /// <remarks>
    /// <b>�����O�u���b App �ϥΡCDevice NuGet ���i�ϥΡC</b>
    /// </remarks>
    public sealed class ApplicationNameEnricher : ILogEventEnricher
    {
        private readonly string _applicationName;
        private readonly LogEventProperty _cachedProperty;

        /// <summary>
        /// ��l�� ApplicationNameEnricher�C
        /// </summary>
        /// <param name="applicationName">���ε{���W�١C</param>
        public ApplicationNameEnricher(string applicationName)
        {
            _applicationName = applicationName ?? throw new ArgumentNullException(nameof(applicationName));
            _cachedProperty = new LogEventProperty("ApplicationName", new ScalarValue(_applicationName));
        }

        /// <inheritdoc />
        public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
        {
            logEvent.AddPropertyIfAbsent(_cachedProperty);
        }
    }
}
