﻿using System;
using System.Collections.Generic;

namespace Calin.SerialPort
{

    /// <summary>
    /// SerialPort 管理器介面。
    /// 此介面設計用於 Autofac 依賴注入。
    /// </summary>
    public interface ISerialPortManager : IDisposable
    {
        #region Events

        /// <summary>
        /// 當任一 SerialPort 狀態改變時觸發。
        /// </summary>
        event EventHandler<SerialPortStateChangedEventArgs> StateChanged;

        /// <summary>
        /// 當任一 SerialPort 接收到資料時觸發。
        /// </summary>
        event EventHandler<SerialPortDataReceivedEventArgs> DataReceived;

        /// <summary>
        /// 當任一 SerialPort 發生錯誤時觸發。
        /// </summary>
        event EventHandler<SerialPortErrorEventArgs> ErrorOccurred;

        #endregion Events

        #region Properties

        /// <summary>
        /// 取得已註冊的 SerialPort 數量。
        /// </summary>
        int PortCount { get; }

        /// <summary>
        /// 取得所有已註冊的 SerialPort 名稱。
        /// </summary>
        IReadOnlyList<string> RegisteredPorts { get; }

        #endregion Properties

        #region Port Management Methods

        /// <summary>
        /// 註冊並開啟一個新的 SerialPort。
        /// </summary>
        /// <param name="config">SerialPort 設定。</param>
        /// <returns>是否成功註冊並開啟。</returns>
        bool RegisterPort(SerialPortConfig config);

        /// <summary>
        /// 取消註冊並關閉指定的 SerialPort。
        /// </summary>
        /// <param name="portName">要取消註冊的 SerialPort 名稱。</param>
        /// <returns>是否成功取消註冊。</returns>
        bool UnregisterPort(string portName);

        /// <summary>
        /// 取得指定的 SerialPort 服務。
        /// </summary>
        /// <param name="portName">SerialPort 名稱。</param>
        /// <returns>SerialPort 服務，如果不存在則返回 null。</returns>
        SerialPortService GetPort(string portName);

        /// <summary>
        /// 檢查指定的 SerialPort 是否已註冊。
        /// </summary>
        /// <param name="portName">SerialPort 名稱。</param>
        /// <returns>是否已註冊。</returns>
        bool IsPortRegistered(string portName);

        /// <summary>
        /// 取得指定 SerialPort 的狀態。
        /// </summary>
        /// <param name="portName">SerialPort 名稱。</param>
        /// <returns>SerialPort 狀態。</returns>
        SerialPortState GetPortState(string portName);

        /// <summary>
        /// 開啟指定的 SerialPort。
        /// </summary>
        /// <param name="portName">SerialPort 名稱。</param>
        /// <returns>是否成功開啟。</returns>
        bool OpenPort(string portName);

        /// <summary>
        /// 關閉指定的 SerialPort。
        /// </summary>
        /// <param name="portName">SerialPort 名稱。</param>
        void ClosePort(string portName);

        /// <summary>
        /// 開啟所有已註冊的 SerialPort。
        /// </summary>
        /// <returns>成功開啟的 SerialPort 數量。</returns>
        int OpenAllPorts();

        /// <summary>
        /// 關閉所有已註冊的 SerialPort。
        /// </summary>
        void CloseAllPorts();

        #endregion Port Management Methods

        #region Data Methods

        /// <summary>
        /// 傳送字串資料到指定的 SerialPort。
        /// </summary>
        /// <param name="portName">SerialPort 名稱。</param>
        /// <param name="data">要傳送的字串資料。</param>
        /// <returns>是否成功傳送。</returns>
        bool SendData(string portName, string data);

        /// <summary>
        /// 傳送位元組資料到指定的 SerialPort。
        /// </summary>
        /// <param name="portName">SerialPort 名稱。</param>
        /// <param name="data">要傳送的位元組陣列。</param>
        /// <returns>是否成功傳送。</returns>
        bool SendData(string portName, byte[] data);

        /// <summary>
        /// 傳送 ASCII 字串資料到指定的 SerialPort（不自動加行結尾）。
        /// </summary>
        bool SendAscii(string portName, string data);

        /// <summary>
        /// 傳送 ASCII 字串資料到指定的 SerialPort，並自動加上行結尾（預設 \r\n，可由設定調整）。
        /// </summary>
        bool SendAsciiLine(string portName, string line);

        /// <summary>
        /// 廣播字串資料到所有已就緒的 SerialPort。
        /// </summary>
        /// <param name="data">要廣播的字串資料。</param>
        /// <returns>成功傳送的 SerialPort 數量。</returns>
        int BroadcastData(string data);

        /// <summary>
        /// 廣播位元組資料到所有已就緒的 SerialPort。
        /// </summary>
        /// <param name="data">要廣播的位元組陣列。</param>
        /// <returns>成功傳送的 SerialPort 數量。</returns>
        int BroadcastData(byte[] data);

        #endregion Data Methods

        #region Utility Methods

        /// <summary>
        /// 取得所有 SerialPort 的狀態摘要。
        /// </summary>
        /// <returns>狀態摘要字典。</returns>
        Dictionary<string, SerialPortState> GetAllPortStates();

        /// <summary>
        /// 取得系統上所有可用的 SerialPort 名稱。
        /// </summary>
        /// <returns>可用的 SerialPort 名稱列表。</returns>
        List<string> GetAvailablePorts();

        /// <summary>
        /// 儲存所有已註冊的 Port 配置到 JSON 檔案。
        /// </summary>
        /// <param name="filePath">檔案路徑。</param>
        /// <returns>是否成功儲存。</returns>
        bool SaveAllConfigs(string filePath);

        /// <summary>
        /// 從 JSON 檔案載入並註冊多個 Port 配置。
        /// </summary>
        /// <param name="filePath">檔案路徑。</param>
        /// <param name="autoOpen">是否自動開啟載入的 Port。預設為 true。</param>
        /// <returns>成功載入並註冊的 Port 數量。</returns>
        int LoadAllConfigs(string filePath, bool autoOpen = true);

        /// <summary>
        /// 儲存特定 Port 的配置到 JSON 檔案。
        /// </summary>
        /// <param name="portName">Port 名稱。</param>
        /// <param name="filePath">檔案路徑。</param>
        /// <returns>是否成功儲存。</returns>
        bool SavePortConfig(string portName, string filePath);

        /// <summary>
        /// 載入特定 Port 的配置並套用。
        /// </summary>
        /// <param name="portName">Port 名稱。</param>
        /// <param name="filePath">檔案路徑。</param>
        /// <returns>是否成功載入。</returns>
        bool LoadPortConfig(string portName, string filePath);

        #endregion
    }
}
