using System;
using System.Text;
using System.Threading;
using Calin.Logging.Abstractions;
using Calin.SerialPort;
using Microsoft.Extensions.Logging;

namespace Calin.Modbus.Transport
{
    /// <summary>
    /// �ϥ� SerialPort �� MODBUS �ǿ�h��@�C
    /// �ϥ� Calin.SerialPort �Ҳնi���ڪ���C��q�T�C
    /// </summary>
    public class SerialPortTransport : IModbusTransport
    {
        private readonly ISerialPortService _serialPortService;
        private readonly ILogger<SerialPortTransport> _logger;
        private readonly object _lockObject = new object();
        private string _receivedData;
        private readonly AutoResetEvent _dataReceivedEvent;
        private bool _disposed;

        /// <summary>
        /// ���o�ǿ�h�O�_�w�}�ҡC
        /// </summary>
        public bool IsOpen => _serialPortService?.IsOpen ?? false;

        /// <summary>
        /// ���o�ǿ����ҬO�_�w�q�L�C
        /// </summary>
        public bool IsTransmissionVerified => _serialPortService?.IsTransmissionVerified ?? false;

        /// <summary>
        /// ���o�γ]�w�q�T�O�ɮɶ��]�@���^�C
        /// </summary>
        public int Timeout { get; set; } = 1000;

        /// <summary>
        /// ���o�γ]�w���զ��ơC
        /// </summary>
        public int RetryCount { get; set; } = 3;

        /// <summary>
        /// ���o�γ]�w���ն��j�]�@���^�C
        /// </summary>
        public int RetryDelay { get; set; } = 100;

        /// <summary>
        /// �إ� SerialPortTransport ��ҡC
        /// </summary>
        /// <param name="serialPortService">SerialPort �A�ȡC</param>
        /// <exception cref="ArgumentNullException">�� serialPortService �� null �ɩߥX�C</exception>
        public SerialPortTransport(ISerialPortService serialPortService)
        {
            _serialPortService = serialPortService ?? throw new ArgumentNullException(nameof(serialPortService));
            _logger = LoggingBridge.CreateLogger<SerialPortTransport>();
            _dataReceivedEvent = new AutoResetEvent(false);

            // �q�\��Ʊ����ƥ�
            _serialPortService.DataReceived += OnDataReceived;
        }

        /// <summary>
        /// �}�Ҷǿ�s�u�C
        /// </summary>
        public bool Open()
        {
            _logger.LogInformation("�}�� SerialPortTransport�APort: {PortName}", _serialPortService.PortName);
            var result = _serialPortService.Open();
            if (result)
            {
                _logger.LogInformation("SerialPortTransport �}�Ҧ��\�C");
            }
            else
            {
                _logger.LogWarning("�L�k�}�� SerialPortTransport�C");
            }
            return result;
        }

        /// <summary>
        /// �����ǿ�s�u�C
        /// </summary>
        public void Close()
        {
            _logger.LogInformation("Closing SerialPortTransport...");
            _serialPortService.Close();
        }

        /// <summary>
        /// �ǰe MODBUS ASCII Frame �õ��ݦ^���C
        /// </summary>
        /// <param name="requestFrame">���㪺 MODBUS ASCII �ШD Frame�C</param>
        /// <returns>���㪺 MODBUS ASCII �^�� Frame�C</returns>
        public string SendAndReceive(string requestFrame)
        {
            if (!IsOpen)
            {
                _logger.LogError("�ǿ饢�ѡGTransport �|���}�ҡC");
                throw new InvalidOperationException("Transport is not open.");
            }

            // �ˬd�ǿ����Ҫ����A
            if (!IsTransmissionVerified)
            {
                _logger.LogError("�ǿ饢�ѡG�ǿ����ҥ��q�L�C");
                throw new InvalidOperationException("Transmission verification failed. Please check serial port parameters.");
            }

            Exception lastException = null;

            for (int attempt = 0; attempt <= RetryCount; attempt++)
            {
                try
                {
                    lock (_lockObject)
                    {
                        // �M�Ť��e�����
                        _receivedData = null;
                        _dataReceivedEvent.Reset();
                        ClearBuffer();

                        // �ǰe�ШD
                        _logger.LogDebug("�o�e MODBUS �ШD�]���� {Attempt}/{RetryCount}�^�G{Frame}",
                            attempt + 1, RetryCount + 1, requestFrame.TrimEnd('\r', '\n'));

                        if (!_serialPortService.SendAscii(requestFrame))
                        {
                            _logger.LogError("Failed to send data.");
                            throw new InvalidOperationException("Failed to send data.");
                        }

                        // ���ݦ^��
                        if (!_dataReceivedEvent.WaitOne(Timeout))
                        {
                            _logger.LogWarning("���ݦ^���O�ɡ]{Timeout}ms�^�C", Timeout);
                            throw new TimeoutException($"No response received within {Timeout}ms.");
                        }

                        // �ˬd�O�_���짹�㪺�^��
                        if (string.IsNullOrEmpty(_receivedData))
                        {
                            _logger.LogWarning("����Ū��^���C�C");
                            throw new TimeoutException("Received empty response.");
                        }

                        // ���Ҧ^���榡
                        if (!_receivedData.StartsWith(":") || !_receivedData.EndsWith("\r\n"))
                        {
                            // ���ݧ�h���
                            Thread.Sleep(50);
                            if (!_receivedData.EndsWith("\r\n"))
                            {
                                _logger.LogWarning("���줣���㪺�^���G{Data}", _receivedData);
                                throw new InvalidOperationException("Incomplete response received.");
                            }
                        }

                        _logger.LogDebug("���� MODBUS �^���G{Frame}", _receivedData.TrimEnd('\r', '\n'));
                        return _receivedData;
                    }
                }
                catch (TimeoutException ex)
                {
                    lastException = ex;
                    if (attempt < RetryCount)
                    {
                        _logger.LogDebug("�O�ɡA�ǳƭ���...");
                        Thread.Sleep(RetryDelay);
                    }
                }
                catch (Exception ex)
                {
                    lastException = ex;
                    if (attempt < RetryCount)
                    {
                        _logger.LogDebug("�o�Ϳ��~�A�ǳƭ��աG{Message}", ex.Message);
                        Thread.Sleep(RetryDelay);
                    }
                }
            }

            _logger.LogError(lastException, "Communication failed after {RetryCount} retries.", RetryCount);
            throw lastException ?? new TimeoutException($"Communication failed after {RetryCount} retries.");
        }

        /// <summary>
        /// �M�ű����w�İϡC
        /// </summary>
        public void ClearBuffer()
        {
            lock (_lockObject)
            {
                _receivedData = null;
            }
        }

        /// <summary>
        /// �B�z��Ʊ����ƥ�C
        /// </summary>
        private void OnDataReceived(object sender, SerialPortDataReceivedEventArgs e)
        {
            lock (_lockObject)
            {
                if (_receivedData == null)
                {
                    _receivedData = string.Empty;
                }

                // �ھڱ����쪺��������B�z
                // �u���ϥΦr���ơA�p�G�S���h�ϥέ�l�줸�ո��
                if (!string.IsNullOrEmpty(e.Data))
                {
                    _receivedData += e.Data;
                }
                else if (e.RawData != null && e.RawData.Length > 0)
                {
                    _receivedData += Encoding.ASCII.GetString(e.RawData);
                }

                // �ˬd�O�_���짹�㪺 MODBUS ASCII Frame
                if (_receivedData.Contains("\r\n"))
                {
                    _dataReceivedEvent.Set();
                }
            }
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _logger.LogDebug("Disposing SerialPortTransport...");
                    if (_serialPortService != null)
                    {
                        _serialPortService.DataReceived -= OnDataReceived;
                    }
                    _dataReceivedEvent?.Dispose();
                }
                _disposed = true;
            }
        }

        /// <summary>
        /// �Ѻc�禡�C
        /// </summary>
        ~SerialPortTransport()
        {
            Dispose(false);
        }
    }
}
