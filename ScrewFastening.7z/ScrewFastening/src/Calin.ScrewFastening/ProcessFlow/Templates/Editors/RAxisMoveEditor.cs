﻿using System;
using Calin.ScrewFastening.ProcessFlow.Editor;
using Calin.ScrewFastening.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.ScrewFastening.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// R軸移動參數編輯器。
    /// </summary>
    public partial class RAxisMoveEditor : ProcessEditorBase
    {
        public override string ProcessId => ProcessIds.R_AXIS_MOVE;

        public RAxisMoveEditor()
        {
            InitializeComponent();

            // 將 UI 事件接到基底的 ParamChanged
            cbHome.CheckedChanged += (s, e) => OnParamChanged();
            rbAbs.CheckedChanged += (s, e) => OnParamChanged();
            rbRes.CheckedChanged += (s, e) => OnParamChanged();
            numTargetAngle.ValueChanged += (s, e) => OnParamChanged();
            numSpeed.ValueChanged += (s, e) => OnParamChanged();
            numAcceleration.ValueChanged += (s, e) => OnParamChanged();
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new RAxisMoveParam()
                : JsonConvert.DeserializeObject<RAxisMoveParam>(paramJson) ?? new RAxisMoveParam();

            cbHome.Checked = param.IsHome;
            if (param.IsAbsolute)
                rbAbs.Checked = true;
            else
                rbRes.Checked = true;
            numTargetAngle.Value = (decimal)param.TargetAngle;
            numSpeed.Value = (decimal)param.Speed;
            numAcceleration.Value = (decimal)param.Acceleration;
        }

        public override string Save()
        {
            var param = new RAxisMoveParam
            {
                AxisId = "R",
                IsHome = cbHome.Checked,
                IsAbsolute = rbAbs.Checked,
                TargetAngle = (double)numTargetAngle.Value,
                Speed = (double)numSpeed.Value,
                Acceleration = (double)numAcceleration.Value
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (numSpeed.Value <= 0)
                return "速度必須大於 0";

            if (numAcceleration.Value <= 0)
                return "加速度必須大於 0";

            return null;
        }

        private void cbHome_CheckedChanged(object sender, EventArgs e)
        {
            gbMoveParams.Enabled = !cbHome.Checked;
        }

        private void RbAbs_CheckedChanged(object sender, EventArgs e)
        {
            numTargetAngle.Minimum = 0;
        }

        private void RbRes_CheckedChanged(object sender, EventArgs e)
        {
            numTargetAngle.Minimum = numTargetAngle.Maximum * -1;
        }
    }
}
