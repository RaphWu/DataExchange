﻿using System.Windows.Forms;

namespace Calin.ScrewFastening.ProcessFlow.Templates.Editors
{
    partial class RAxisMoveEditor
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.numTargetAngle = new System.Windows.Forms.NumericUpDown();
            this.lblTargetPosition = new System.Windows.Forms.Label();
            this.numAcceleration = new System.Windows.Forms.NumericUpDown();
            this.lblAcceleration = new System.Windows.Forms.Label();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.numSpeed = new System.Windows.Forms.NumericUpDown();
            this.gbMoveParams = new System.Windows.Forms.GroupBox();
            this.rbRes = new System.Windows.Forms.RadioButton();
            this.rbAbs = new System.Windows.Forms.RadioButton();
            this.cbHome = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numTargetAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAcceleration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSpeed)).BeginInit();
            this.gbMoveParams.SuspendLayout();
            this.SuspendLayout();
            // 
            // numTargetAngle
            // 
            this.numTargetAngle.DecimalPlaces = 1;
            this.numTargetAngle.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numTargetAngle.Location = new System.Drawing.Point(124, 65);
            this.numTargetAngle.Margin = new System.Windows.Forms.Padding(4);
            this.numTargetAngle.Maximum = new decimal(new int[] {
            3599,
            0,
            0,
            65536});
            this.numTargetAngle.Name = "numTargetAngle";
            this.numTargetAngle.Size = new System.Drawing.Size(135, 23);
            this.numTargetAngle.TabIndex = 3;
            // 
            // lblTargetPosition
            // 
            this.lblTargetPosition.Location = new System.Drawing.Point(24, 63);
            this.lblTargetPosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTargetPosition.Name = "lblTargetPosition";
            this.lblTargetPosition.Size = new System.Drawing.Size(92, 25);
            this.lblTargetPosition.TabIndex = 2;
            this.lblTargetPosition.Text = "目標角度";
            this.lblTargetPosition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numAcceleration
            // 
            this.numAcceleration.DecimalPlaces = 1;
            this.numAcceleration.Location = new System.Drawing.Point(124, 115);
            this.numAcceleration.Margin = new System.Windows.Forms.Padding(4);
            this.numAcceleration.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.numAcceleration.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numAcceleration.Name = "numAcceleration";
            this.numAcceleration.Size = new System.Drawing.Size(135, 23);
            this.numAcceleration.TabIndex = 7;
            this.numAcceleration.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // lblAcceleration
            // 
            this.lblAcceleration.Location = new System.Drawing.Point(24, 113);
            this.lblAcceleration.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAcceleration.Name = "lblAcceleration";
            this.lblAcceleration.Size = new System.Drawing.Size(92, 25);
            this.lblAcceleration.TabIndex = 6;
            this.lblAcceleration.Text = "加速度 (mm/s²)";
            this.lblAcceleration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSpeed
            // 
            this.lblSpeed.Location = new System.Drawing.Point(24, 88);
            this.lblSpeed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(92, 25);
            this.lblSpeed.TabIndex = 4;
            this.lblSpeed.Text = "速度 (mm/s)";
            this.lblSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numSpeed
            // 
            this.numSpeed.DecimalPlaces = 1;
            this.numSpeed.Location = new System.Drawing.Point(124, 90);
            this.numSpeed.Margin = new System.Windows.Forms.Padding(4);
            this.numSpeed.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numSpeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numSpeed.Name = "numSpeed";
            this.numSpeed.Size = new System.Drawing.Size(135, 23);
            this.numSpeed.TabIndex = 5;
            this.numSpeed.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // gbMoveParams
            // 
            this.gbMoveParams.Controls.Add(this.rbRes);
            this.gbMoveParams.Controls.Add(this.rbAbs);
            this.gbMoveParams.Controls.Add(this.numTargetAngle);
            this.gbMoveParams.Controls.Add(this.lblTargetPosition);
            this.gbMoveParams.Controls.Add(this.numAcceleration);
            this.gbMoveParams.Controls.Add(this.lblAcceleration);
            this.gbMoveParams.Controls.Add(this.lblSpeed);
            this.gbMoveParams.Controls.Add(this.numSpeed);
            this.gbMoveParams.Location = new System.Drawing.Point(15, 45);
            this.gbMoveParams.Name = "gbMoveParams";
            this.gbMoveParams.Size = new System.Drawing.Size(290, 160);
            this.gbMoveParams.TabIndex = 14;
            this.gbMoveParams.TabStop = false;
            this.gbMoveParams.Text = "移動參數";
            // 
            // rbRes
            // 
            this.rbRes.AutoSize = true;
            this.rbRes.Location = new System.Drawing.Point(148, 32);
            this.rbRes.Name = "rbRes";
            this.rbRes.Size = new System.Drawing.Size(73, 20);
            this.rbRes.TabIndex = 9;
            this.rbRes.TabStop = true;
            this.rbRes.Text = "相對位置";
            this.rbRes.UseVisualStyleBackColor = true;
            this.rbRes.CheckedChanged += new System.EventHandler(this.RbRes_CheckedChanged);
            // 
            // rbAbs
            // 
            this.rbAbs.AutoSize = true;
            this.rbAbs.Checked = true;
            this.rbAbs.Location = new System.Drawing.Point(49, 32);
            this.rbAbs.Name = "rbAbs";
            this.rbAbs.Size = new System.Drawing.Size(73, 20);
            this.rbAbs.TabIndex = 8;
            this.rbAbs.TabStop = true;
            this.rbAbs.Text = "絕對位置";
            this.rbAbs.UseVisualStyleBackColor = true;
            this.rbAbs.CheckedChanged += new System.EventHandler(this.RbAbs_CheckedChanged);
            // 
            // cbHome
            // 
            this.cbHome.AutoSize = true;
            this.cbHome.Location = new System.Drawing.Point(20, 15);
            this.cbHome.Name = "cbHome";
            this.cbHome.Size = new System.Drawing.Size(62, 20);
            this.cbHome.TabIndex = 13;
            this.cbHome.Text = "回原點";
            this.cbHome.UseVisualStyleBackColor = true;
            this.cbHome.CheckedChanged += new System.EventHandler(this.cbHome_CheckedChanged);
            // 
            // RAxisMoveEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbMoveParams);
            this.Controls.Add(this.cbHome);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "RAxisMoveEditor";
            this.Padding = new System.Windows.Forms.Padding(14, 16, 14, 16);
            this.Size = new System.Drawing.Size(320, 250);
            ((System.ComponentModel.ISupportInitialize)(this.numTargetAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAcceleration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSpeed)).EndInit();
            this.gbMoveParams.ResumeLayout(false);
            this.gbMoveParams.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private NumericUpDown numTargetAngle;
        private Label lblTargetPosition;
        private NumericUpDown numAcceleration;
        private Label lblAcceleration;
        private Label lblSpeed;
        private NumericUpDown numSpeed;
        private GroupBox gbMoveParams;
        private RadioButton rbRes;
        private RadioButton rbAbs;
        private CheckBox cbHome;
    }
}
