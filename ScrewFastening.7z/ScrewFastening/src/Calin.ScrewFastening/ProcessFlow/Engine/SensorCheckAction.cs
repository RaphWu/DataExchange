﻿namespace Calin.ScrewFastening.ProcessFlow.Engine
{
    /// <summary>
    /// 感測器範圍判斷後執行動作類型。
    /// </summary>
    public enum SensorCheckAction
    {
        /// <summary>
        /// 無動作。
        /// </summary>
        None = 0,

        /// <summary>
        /// 停止流程。
        /// </summary>
        StopFlow = 1,

        /// <summary>
        /// 繼續執行。
        /// </summary>
        Continue = 2,

        /// <summary>
        /// 觸發警報。
        /// </summary>
        TriggerAlarm = 3
    }
}
