﻿using System;

namespace Calin.ScrewFastening.Ext
{
    public static class DateTimeExt
    {
        public static string ToString(this DateTime dateTime)
        {
            return dateTime.ToString("yyyy-MM-dd HH:mm:ss");
        }
    }
}
