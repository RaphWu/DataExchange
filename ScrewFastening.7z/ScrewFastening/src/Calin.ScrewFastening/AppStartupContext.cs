﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.Comm.DL_RS1A;
using Calin.DAQ.USB4704;
using Calin.Logging.Abstractions;
using Calin.Logging.Serilog;
using Calin.MotionControl.Advantech;
using Calin.Navigation;
using Calin.ScrewFastening.Models;
using Calin.ScrewFastening.ProcessFlow;
using Calin.ScrewFastening.ProcessFlow.UI;
using Calin.ScrewFastening.Services;
using Calin.ScrewFastening.SharedUI;
using Calin.ScrewFastening.Views;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;

namespace Calin.ScrewFastening
{
    /// <summary>
    /// 表示應用程式的啟動上下文，負責初始化應用程式並管理其生命週期。
    /// </summary>
    public sealed class AppStartupContext : ApplicationContext
    {
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private readonly SplashScreen _splash;
        private IContainer _container = default;
        private ILogger<AppStartupContext> _logger;


        /// <summary>
        /// 初始化 <see cref="ApplicationContext"/> 類別的新執行個體。
        /// </summary>
        public AppStartupContext()
        {
            // 顯示啟動畫面
            _splash = new SplashScreen();
            _splash.AbortClicked += Splash_AbortClicked;
            _splash.Show();
            _splash.Refresh();

            // 初始化日誌服務，必須最先執行
            SplashMessenger.Post("初始化日誌服務...");
            var loggerFactory = new SerilogLoggerFactoryBuilder()
                .SetMinimumLevel(LogEventLevel.Debug)
                .AddDebug()
                .AddFile("logs/ScrewFastening.log")
                .AddJsonFile("logs/ScrewFastening.json")
                .EnableAllEnrichers("ScrewFastening")
                .Build();
            LoggingBridge.Initialize(loggerFactory);
            _logger = LoggingBridge.CreateLogger<AppStartupContext>();

            StartInitialization();
        }

        /// <summary>
        /// 開始初始化應用程式的核心邏輯。
        /// </summary>
        private void StartInitialization()
        {
            // 在背景執行緒中初始化應用程式
            _ = Task.Run(() =>
            {
                try
                {
                    _logger.LogInformation("初始化核心模組");
                    InitializeCore(_cts.Token);

                    if (_cts.IsCancellationRequested)
                        return;

                    SplashMessenger.Post("初始化完成，準備啟動主畫面...");
                    Thread.Sleep(1200);

                    // 回到 UI Thread 顯示 MainForm
                    _splash.BeginInvoke(new Action(() =>
                    {
                        var mainForm = _container.Resolve<MainForm>();
                        mainForm.FormClosed += MainForm_FormClosed;

                        MainForm = mainForm;
                        _splash.Close();
                        mainForm.Show();
                        mainForm.Activate();
                    }));
                }
                catch (OperationCanceledException)
                {
                    _logger.LogInformation("ScrewFastening 由 CancellationTokenSource 結束");
                    ExitOnUiThread();
                }
                catch (Exception ex)
                {
                    _logger.LogInformation($"ScrewFastening異常結束!\n\n{ex.Message}");
                    ShowErrorAndExit(ex.Message);
                }
            }, _cts.Token);
        }

        /// <summary>
        /// 初始化應用程式的核心模組和依賴項。
        /// </summary>
        /// <param name="token">用於取消操作的 <see cref="CancellationToken"/>。</param>
        private void InitializeCore(CancellationToken token)
        {
            token.ThrowIfCancellationRequested();

            // 初始化 DI 容器
            var builder = new ContainerBuilder();

            builder.RegisterType<MainForm>();
            //builder.RegisterModule<LoggingModule>();
            builder.RegisterModule<NavigationModule>();
            builder.RegisterModule<ProcessFlowModule>();

            // 初始化外部 DI 容器
            builder.RegisterModule<AdvantechModule>();
            //builder.RegisterModule<SerialPortModule>();
            builder.RegisterModule<DL_RS1A_Module>();
            builder.RegisterModule<Usb4704Module>();

            // Models
            builder.RegisterType<LmData>().AsSelf().SingleInstance();
            builder.RegisterType<RawData>().AsSelf().SingleInstance();
            builder.RegisterType<MotionCardData>().AsSelf().SingleInstance();
            builder.RegisterType<Dlrs1aData>().AsSelf().SingleInstance();
            builder.RegisterType<DaqData>().AsSelf().SingleInstance();
            builder.RegisterType<BindingData>().AsSelf().SingleInstance();

            // Services
            builder.RegisterType<ScrewFasteningService>().As<IScrewFastening>().SingleInstance();

            // Views
            builder.RegisterType<MainPage>().AsSelf().InstancePerLifetimeScope();
            builder.RegisterType<Views.Monitor>().AsSelf().InstancePerLifetimeScope();
            builder.RegisterType<ProcessFlowMainForm>().AsSelf().InstancePerLifetimeScope();
            builder.RegisterType<ManualPage>().AsSelf().InstancePerLifetimeScope();
            builder.RegisterType<SetupPage>().AsSelf().InstancePerLifetimeScope();

            token.ThrowIfCancellationRequested();

            _container = builder.Build();

            var deviceService = _container.Resolve<IScrewFastening>();
        }

        /// <summary>
        /// 處理啟動退出事件，並執行應用程式的關閉邏輯。
        /// </summary>
        private void Splash_AbortClicked(object sender, EventArgs e)
        {
            _cts.Cancel(); // 如果初始化還在跑，取消它
            Shutdown();
        }

        /// <summary>
        /// 處理主視窗關閉事件，並執行應用程式的關閉邏輯。
        /// </summary>
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            _logger.LogInformation("ScrewFastening正常結束");
            Shutdown();
        }

        /// <summary>
        /// 關閉應用程式，釋放資源並停止所有操作。
        /// </summary>
        private void Shutdown()
        {
            // 取消初始化或背景 Task
            _cts.Cancel();

            _container?.Dispose();
            Log.CloseAndFlush();

            // 解除 Splash
            if (_splash != null && !_splash.IsDisposed)
            {
                _splash.AbortClicked -= Splash_AbortClicked;
                _splash.Close();
                _splash.Dispose();
            }

            // 釋放 CTS
            _cts.Dispose();

            ExitThread();
        }

        /// <summary>
        /// 在 UI 執行緒上退出應用程式。
        /// </summary>
        private void ExitOnUiThread()
        {
            _splash.BeginInvoke(new Action(ExitThread));
        }

#pragma warning disable IDE0060 // 移除未使用的參數
        /// <summary>
        /// 顯示錯誤訊息並退出應用程式。
        /// </summary>
        /// <param name="message">要顯示的錯誤訊息。</param>
        private void ShowErrorAndExit(string message)
        {
            _splash.BeginInvoke(new Action(() =>
            {
                //MessageBox.Show(message, "啟動失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Shutdown();
            }));
        }
#pragma warning restore IDE0060 // 移除未使用的參數
    }
}
