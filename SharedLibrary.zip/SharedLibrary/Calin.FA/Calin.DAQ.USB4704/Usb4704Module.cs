﻿using Autofac;
using Calin.SerialPort;

namespace Calin.DAQ.USB4704
{
    /// <summary>
    /// Autofac 模組，用於註冊 USB4704 DAQ 通訊相關的依賴項。
    /// </summary>
    /// <remarks>
    /// 此模組會註冊：
    /// <list type="bullet">
    /// <item><description><see cref="ISerialPortServiceFactory"/> - SerialPort 服務工廠（SingleInstance）</description></item>
    /// <item><description><see cref="IUsb4704ServiceFactory"/> - USB4704 服務工廠（SingleInstance）</description></item>
    /// </list>
    /// 使用者應透過 <see cref="IUsb4704ServiceFactory"/> 建立 <see cref="IUsb4704"/> 實例。
    /// </remarks>
    public class Usb4704Module : Module
    {
        /// <summary>
        /// 覆寫 Autofac 的 <see cref="Module.Load"/> 方法，註冊 USB4704 的依賴項。
        /// </summary>
        /// <param name="builder">Autofac 的容器建構器，用於註冊依賴項。</param>
        protected override void Load(ContainerBuilder builder)
        {
            // 註冊 SerialPortServiceFactory（如果尚未註冊）
            builder.RegisterType<SerialPortServiceFactory>()
                .As<ISerialPortServiceFactory>()
                .SingleInstance()
                .IfNotRegistered(typeof(ISerialPortServiceFactory));

            // 註冊 Usb4704ServiceFactory
            builder.RegisterType<Usb4704ServiceFactory>()
                .As<IUsb4704ServiceFactory>()
                .SingleInstance();

            builder.RegisterType<Usb4704Dio>()
                .As<IUsb4704Dio>()
                .InstancePerDependency();
        }
    }
}
