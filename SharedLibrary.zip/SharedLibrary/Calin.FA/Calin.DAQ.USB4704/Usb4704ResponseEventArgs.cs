using System;

namespace Calin.DAQ.USB4704
{
    /// <summary>
    /// USB4704 �^�������ƥ�ѼơC
    /// </summary>
    public class Usb4704ResponseEventArgs : EventArgs
    {
        /// <summary>
        /// ���o�^����ơC
        /// </summary>
        public Usb4704Response Response { get; }

        /// <summary>
        /// �إ� Usb4704ResponseEventArgs ��ҡC
        /// </summary>
        /// <param name="response">�^����ơC</param>
        public Usb4704ResponseEventArgs(Usb4704Response response)
        {
            Response = response;
        }
    }
}
