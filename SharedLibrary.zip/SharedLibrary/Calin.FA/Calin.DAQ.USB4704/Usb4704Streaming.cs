﻿namespace Calin.DAQ.USB4704
{
    public class Usb4704Streaming
    {
    }
}
