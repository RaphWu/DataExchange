﻿# Calin.DAQ.USB4704

`Calin.DAQ.USB4704` 是一個用於與 Advantech USB-4704 數據採集設備進行通信和數據處理的庫。該庫提供了簡單易用的接口，允許用戶輕鬆地從設備獲取類比和數位輸入數據，並進行分析和處理。

## 相依套件

### 必要

- `Calin.Abstractions`：提供基礎介面與共用型別。
- `Calin.SerialPort`：提供串列埠通信功能。

### 選用

- `Autofac`：依賴注入容器，用於管理日誌元件的生命週期與解析。
  - 專案有提供模組註冊檔，可透過 `NavigationModule` 快速完成註冊。

## 版本歷史

### v0.0.1

2026.01.

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
