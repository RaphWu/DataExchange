﻿using System;
using Automation.BDaq;
using Calin.Abstractions.Logging;

namespace Calin.DAQ.USB4704
{
    public class Usb4704Dio : IUsb4704Dio
    {
        private readonly ICalinLogger _logger;
        private readonly InstantDiCtrl _instantDiCtrl = new InstantDiCtrl();
        private readonly InstantDoCtrl _instantDoCtrl = new InstantDoCtrl();
        private int _totalPorts;

        public Usb4704Dio(ICalinLogger calinLogger)
        {
            _logger = calinLogger;
        }

        #region DIO

        /// <inheritdoc/>
        public bool Usb4704DioInit(string deviceCode)
        {
            _instantDiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
            if (!_instantDiCtrl.Initialized)
            {
                _logger.Warning($"裝置開啟失敗：{nameof(Usb4704DioInit)}");
                return false;
            }

            _instantDoCtrl.SelectedDevice = new DeviceInformation(deviceCode);
            if (!_instantDoCtrl.Initialized)
            {
                _logger.Warning($"裝置開啟失敗：{nameof(Usb4704DioInit)}");
                return false;
            }

            _totalPorts = _instantDiCtrl.PortCount;
            return true;
        }

        /// <inheritdoc/>
        public void Dispose()
        {
            _instantDiCtrl.Dispose();
            GC.SuppressFinalize(this);
        }

        #endregion DIO

        #region Digital Input

        /// <inheritdoc/>
        public ErrorCode ReadDigital(int port, out byte data)
        {
            ErrorCode errorCode = _instantDiCtrl.Read(port, out data);
            if (errorCode != ErrorCode.Success)
            {
                _logger.Warning($"讀取數位輸入失敗：{nameof(ReadDigital)}，錯誤代碼：0x{errorCode:X8}");
                return errorCode;
            }
            return ErrorCode.Success;
        }

        /// <inheritdoc/>
        public ErrorCode ReadDigitalBit(int port, int bitPos, out byte bitValue)
        {
            ErrorCode errorCode = _instantDiCtrl.ReadBit(port, bitPos, out bitValue);
            if (errorCode != ErrorCode.Success)
            {
                _logger.Warning($"讀取數位輸入位元失敗：{nameof(ReadDigitalBit)}，錯誤代碼：0x{errorCode:X8}");
                return errorCode;
            }
            return ErrorCode.Success;
        }

        #endregion Digital Input

        #region Digital Output

        /// <inheritdoc/>
        public ErrorCode WriteDigital(int port, byte data)
        {
            ErrorCode errorCode = _instantDoCtrl.Write(port, data);
            if (errorCode != ErrorCode.Success)
            {
                _logger.Warning($"寫入數位輸出失敗：{nameof(WriteDigital)}，錯誤代碼：0x{errorCode:X8}");
                return errorCode;
            }
            return ErrorCode.Success;
        }

        /// <inheritdoc/>
        public ErrorCode WriteDigitalBit(int port, int bitPos, byte bitValue)
        {
            ErrorCode errorCode = _instantDoCtrl.WriteBit(port, bitPos, bitValue);
            if (errorCode != ErrorCode.Success)
            {
                _logger.Warning($"寫入數位輸出位元失敗：{nameof(WriteDigitalBit)}，錯誤代碼：0x{errorCode:X8}");
                return errorCode;
            }
            return ErrorCode.Success;
        }

        #endregion Digital Output
    }
}
