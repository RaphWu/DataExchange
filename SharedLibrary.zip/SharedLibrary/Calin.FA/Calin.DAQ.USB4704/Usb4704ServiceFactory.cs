using System;
using Calin.SerialPort;

namespace Calin.DAQ.USB4704
{
    /// <summary>
    /// USB4704 �A�Ȥu�t��@�C
    /// �t�d�إ� USB4704 ��ҡC
    /// </summary>
    /// <remarks>
    /// �����O�� Singleton�A�i�Q Autofac ���U�� SingleInstance�C
    /// �u�t�������������� USB4704 ��Ҫ��ѦҡC
    /// </remarks>
    public class Usb4704ServiceFactory : IUsb4704ServiceFactory
    {
        private readonly ISerialPortServiceFactory _serialPortServiceFactory;

        /// <summary>
        /// �إ� Usb4704ServiceFactory ��ҡC
        /// </summary>
        /// <param name="serialPortServiceFactory">SerialPort �A�Ȥu�t�C</param>
        /// <exception cref="ArgumentNullException">�� serialPortServiceFactory �� null �ɩߥX�C</exception>
        public Usb4704ServiceFactory(ISerialPortServiceFactory serialPortServiceFactory)
        {
            _serialPortServiceFactory = serialPortServiceFactory ?? throw new ArgumentNullException(nameof(serialPortServiceFactory));
        }

        /// <inheritdoc />
        public IUsb4704 Create(Usb4704Config config)
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            var serialPortConfig = new SerialPortConfig
            {
                PortName = config.PortName,
                BaudRate = config.BaudRate,
                DataBits = config.DataBits,
                Parity = config.Parity,
                StopBits = config.StopBits,
                ReadTimeout = config.ReadTimeout,
                WriteTimeout = config.WriteTimeout,
                EnableAsciiLineMode = true,
                AsciiLineTerminator = "\r\n",
                EnableAutoReconnect = false,
                EnableHeartbeat = false,
            };

            var serialPortService = _serialPortServiceFactory.Create(serialPortConfig);

            return new Usb4704Service(config, serialPortService);
        }

        /// <inheritdoc />
        public IUsb4704 CreateAndOpen(Usb4704Config config)
        {
            var usb4704 = Create(config);

            try
            {
                if (!usb4704.Open())
                {
                    usb4704.Dispose();
                    throw new InvalidOperationException($"Failed to open USB4704 on: {config.PortName}");
                }

                return usb4704;
            }
            catch
            {
                usb4704.Dispose();
                throw;
            }
        }
    }
}
