﻿using System;
using System.Collections.Generic;
using Calin.SerialPort;

namespace Calin.DAQ.USB4704
{
    /// <summary>
    /// USB4704 DAQ RS-232 通訊服務。
    /// 使用 SerialPort 進行通訊。
    /// </summary>
    public class Usb4704Service : IUsb4704
    {
        #region Fields

        private readonly Usb4704Config _config;
        private readonly ISerialPortService _serialPortService;
        private bool _disposed;

        private readonly string _productID = "USB-4704";
        private readonly int _boardId = 0;
        private readonly string _deviceCode = "USB-4704,BID#0";

        #endregion Fields

        /// <summary>
        /// 回應接收事件。
        /// </summary>
        public event EventHandler<Usb4704ResponseEventArgs> ResponseReceived;

        /// <summary>
        /// 錯誤發生事件。
        /// </summary>
        public event EventHandler<Usb4704ErrorEventArgs> ErrorOccurred;

        /// <summary>
        /// 建立 Usb4704Service 實例。
        /// </summary>
        /// <param name="config">USB4704 設定。</param>
        /// <param name="serialPortService">SerialPort 服務。</param>
        /// <exception cref="ArgumentNullException">當參數為 null 時拋出。</exception>
        internal Usb4704Service(Usb4704Config config, ISerialPortService serialPortService)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _serialPortService = serialPortService ?? throw new ArgumentNullException(nameof(serialPortService));

            SubscribeEvents();
        }

        /// <summary>
        /// 取得設定。
        /// </summary>
        public Usb4704Config Config => _config;

        /// <inheritdoc />
        public bool IsConnected => _serialPortService?.IsOpen ?? false;

        /// <inheritdoc />
        public bool IsTransmissionVerified => _serialPortService?.IsTransmissionVerified ?? false;

        /// <inheritdoc />
        public bool Open()
        {
            try
            {
                return _serialPortService.Open();
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <inheritdoc />
        public void Close()
        {
            try
            {
                _serialPortService.Close();
            }
            catch (Exception)
            {
                // Ignore
            }
        }

        /// <summary>
        /// 傳送字串資料。
        /// </summary>
        /// <param name="data">要傳送的字串資料。</param>
        /// <returns>是否成功傳送。</returns>
        protected bool SendData(string data)
        {
            try
            {
                return _serialPortService.SendData(data);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 傳送位元組資料。
        /// </summary>
        /// <param name="data">要傳送的位元組資料。</param>
        /// <returns>是否成功傳送。</returns>
        protected bool SendData(byte[] data)
        {
            try
            {
                return _serialPortService.SendData(data);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 訂閱 SerialPort 事件。
        /// </summary>
        private void SubscribeEvents()
        {
            if (_serialPortService is SerialPortService service)
            {
                service.DataReceived += OnSerialPortDataReceived;
                service.ErrorOccurred += OnSerialPortErrorOccurred;
            }
        }

        /// <summary>
        /// 取消訂閱 SerialPort 事件。
        /// </summary>
        private void UnsubscribeEvents()
        {
            if (_serialPortService is SerialPortService service)
            {
                service.DataReceived -= OnSerialPortDataReceived;
                service.ErrorOccurred -= OnSerialPortErrorOccurred;
            }
        }

        private void OnSerialPortDataReceived(object sender, SerialPortDataReceivedEventArgs e)
        {
            if (string.IsNullOrEmpty(e.Data))
                return;

            try
            {
                var response = ParseResponse(e.Data);
                if (response != null)
                {
                    OnResponseReceived(response);
                }
            }
            catch (Exception)
            {
                // 解析失敗，忽略
            }
        }

        /// <summary>
        /// 解析 USB4704 回應資料。
        /// </summary>
        /// <param name="data">原始回應字串。</param>
        /// <returns>解析後的回應物件，解析失敗時回傳 null。</returns>
        private Usb4704Response ParseResponse(string data)
        {
            var trimmedData = data.Trim();

            // 檢查錯誤回應 (例如: ER,01)
            if (trimmedData.StartsWith("ER,", StringComparison.OrdinalIgnoreCase))
            {
                var errorCode = trimmedData.Length > 3 ? trimmedData.Substring(3).Trim() : string.Empty;
                return new Usb4704Response
                {
                    IsSuccess = false,
                    ErrorCode = errorCode,
                    RawData = data
                };
            }

            // 解析正常回應
            var values = trimmedData.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            var parsedValues = new List<double>();

            foreach (var value in values)
            {
                if (TryParseValue(value.Trim(), out double parsedValue))
                {
                    parsedValues.Add(parsedValue);
                }
            }

            return new Usb4704Response
            {
                IsSuccess = true,
                Values = parsedValues.ToArray(),
                RawData = data
            };
        }

        /// <summary>
        /// 嘗試解析數值字串。
        /// </summary>
        /// <param name="valueString">數值字串。</param>
        /// <param name="result">解析結果。</param>
        /// <returns>是否成功解析。</returns>
        private bool TryParseValue(string valueString, out double result)
        {
            result = 0;

            if (string.IsNullOrWhiteSpace(valueString))
                return false;

            return double.TryParse(valueString,
                System.Globalization.NumberStyles.AllowLeadingSign |
                System.Globalization.NumberStyles.AllowDecimalPoint,
                System.Globalization.CultureInfo.InvariantCulture,
                out result);
        }

        /// <summary>
        /// 當回應收到時觸發。
        /// </summary>
        /// <param name="response">回應資料。</param>
        protected virtual void OnResponseReceived(Usb4704Response response)
        {
            ResponseReceived?.Invoke(this, new Usb4704ResponseEventArgs(response));
        }

        private void OnSerialPortErrorOccurred(object sender, SerialPortErrorEventArgs e)
        {
            ErrorOccurred?.Invoke(this, new Usb4704ErrorEventArgs(
                e.PortName,
                e.ErrorType,
                e.ErrorMessage,
                e.Exception,
                e.Timestamp));
        }

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// 釋放資源。
        /// </summary>
        /// <param name="disposing">是否正在釋放。</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;

            if (disposing)
            {
                UnsubscribeEvents();
                _serialPortService?.Dispose();
            }

            _disposed = true;
        }
    }
}
