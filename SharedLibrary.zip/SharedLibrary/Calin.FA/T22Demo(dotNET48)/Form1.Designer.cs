﻿namespace T22Demo
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_Operate = new System.Windows.Forms.Panel();
            this.groupBox_FFT = new System.Windows.Forms.GroupBox();
            this.button_FFT = new System.Windows.Forms.Button();
            this.radioButton_FFT_LPF2_2 = new System.Windows.Forms.RadioButton();
            this.radioButton_FFT_LPF2_1 = new System.Windows.Forms.RadioButton();
            this.radioButton_FFT_LPF1_1 = new System.Windows.Forms.RadioButton();
            this.radioButton_FFT_Kalman = new System.Windows.Forms.RadioButton();
            this.radioButton_FFT_Original = new System.Windows.Forms.RadioButton();
            this.groupBox_Buffer = new System.Windows.Forms.GroupBox();
            this.numericUpDown_BufferTriggerTimes = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.numericUpDown_TimerTick2 = new System.Windows.Forms.NumericUpDown();
            this.comboBox_SectionLength = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.numericUpDown_ClockRate2 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_CutoffFreq = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label_TimeConsumingMin = new System.Windows.Forms.Label();
            this.label_TimeConsumingAvg = new System.Windows.Forms.Label();
            this.label_TriggerTimes = new System.Windows.Forms.Label();
            this.label_TotalData = new System.Windows.Forms.Label();
            this.label_ActualTime = new System.Windows.Forms.Label();
            this.label_TimePerRecord = new System.Windows.Forms.Label();
            this.label_TimeConsumingMax = new System.Windows.Forms.Label();
            this.label_TotalTime = new System.Windows.Forms.Label();
            this.groupBox_InstantParams = new System.Windows.Forms.GroupBox();
            this.numericUpDown_TimeToStop = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label_TimerTick = new System.Windows.Forms.Label();
            this.numericUpDown_TimerTick = new System.Windows.Forms.NumericUpDown();
            this.groupBox_StreamingParams = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.numericUpDown_ClockRate = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDown_StramingTriggerTimes = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox_Mode = new System.Windows.Forms.GroupBox();
            this.radioButton_Buffer = new System.Windows.Forms.RadioButton();
            this.radioButton_Streaming = new System.Windows.Forms.RadioButton();
            this.radioButton_Instant = new System.Windows.Forms.RadioButton();
            this.checkBox_LPF2_2 = new System.Windows.Forms.CheckBox();
            this.checkBox_LPF2_1 = new System.Windows.Forms.CheckBox();
            this.checkBox_LPF1_1 = new System.Windows.Forms.CheckBox();
            this.checkBox_Kalman = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_KalmanQ = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_KalmanR = new System.Windows.Forms.NumericUpDown();
            this.label_KalmanQ = new System.Windows.Forms.Label();
            this.label_KalmanR = new System.Windows.Forms.Label();
            this.button_Reset = new System.Windows.Forms.Button();
            this.button_Stop = new System.Windows.Forms.Button();
            this.button_Start = new System.Windows.Forms.Button();
            this.panel_Plot = new System.Windows.Forms.Panel();
            this.tabControl_View = new System.Windows.Forms.TabControl();
            this.tabPage_MeasureData = new System.Windows.Forms.TabPage();
            this.formsPlot_Measure = new ScottPlot.WinForms.FormsPlot();
            this.tabPage_FFT = new System.Windows.Forms.TabPage();
            this.formsPlot_FFT = new ScottPlot.WinForms.FormsPlot();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.fFTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel_Operate.SuspendLayout();
            this.groupBox_FFT.SuspendLayout();
            this.groupBox_Buffer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_BufferTriggerTimes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TimerTick2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ClockRate2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_CutoffFreq)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox_InstantParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TimeToStop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TimerTick)).BeginInit();
            this.groupBox_StreamingParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ClockRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_StramingTriggerTimes)).BeginInit();
            this.groupBox_Mode.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_KalmanQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_KalmanR)).BeginInit();
            this.panel_Plot.SuspendLayout();
            this.tabControl_View.SuspendLayout();
            this.tabPage_MeasureData.SuspendLayout();
            this.tabPage_FFT.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.form1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Operate
            // 
            this.panel_Operate.Controls.Add(this.groupBox_FFT);
            this.panel_Operate.Controls.Add(this.groupBox_Buffer);
            this.panel_Operate.Controls.Add(this.groupBox3);
            this.panel_Operate.Controls.Add(this.groupBox2);
            this.panel_Operate.Controls.Add(this.groupBox_InstantParams);
            this.panel_Operate.Controls.Add(this.groupBox_StreamingParams);
            this.panel_Operate.Controls.Add(this.groupBox_Mode);
            this.panel_Operate.Controls.Add(this.checkBox_LPF2_2);
            this.panel_Operate.Controls.Add(this.checkBox_LPF2_1);
            this.panel_Operate.Controls.Add(this.checkBox_LPF1_1);
            this.panel_Operate.Controls.Add(this.checkBox_Kalman);
            this.panel_Operate.Controls.Add(this.groupBox1);
            this.panel_Operate.Controls.Add(this.button_Reset);
            this.panel_Operate.Controls.Add(this.button_Stop);
            this.panel_Operate.Controls.Add(this.button_Start);
            this.panel_Operate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_Operate.Location = new System.Drawing.Point(0, 380);
            this.panel_Operate.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.panel_Operate.Name = "panel_Operate";
            this.panel_Operate.Size = new System.Drawing.Size(1275, 196);
            this.panel_Operate.TabIndex = 32;
            // 
            // groupBox_FFT
            // 
            this.groupBox_FFT.Controls.Add(this.button_FFT);
            this.groupBox_FFT.Controls.Add(this.radioButton_FFT_LPF2_2);
            this.groupBox_FFT.Controls.Add(this.radioButton_FFT_LPF2_1);
            this.groupBox_FFT.Controls.Add(this.radioButton_FFT_LPF1_1);
            this.groupBox_FFT.Controls.Add(this.radioButton_FFT_Kalman);
            this.groupBox_FFT.Controls.Add(this.radioButton_FFT_Original);
            this.groupBox_FFT.Location = new System.Drawing.Point(707, 20);
            this.groupBox_FFT.Name = "groupBox_FFT";
            this.groupBox_FFT.Size = new System.Drawing.Size(258, 162);
            this.groupBox_FFT.TabIndex = 47;
            this.groupBox_FFT.TabStop = false;
            this.groupBox_FFT.Text = "快速傅立葉";
            // 
            // button_FFT
            // 
            this.button_FFT.BackColor = System.Drawing.Color.SkyBlue;
            this.button_FFT.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_FFT.Location = new System.Drawing.Point(157, 67);
            this.button_FFT.Margin = new System.Windows.Forms.Padding(4);
            this.button_FFT.Name = "button_FFT";
            this.button_FFT.Size = new System.Drawing.Size(85, 35);
            this.button_FFT.TabIndex = 45;
            this.button_FFT.Text = "快速傅立葉";
            this.button_FFT.UseVisualStyleBackColor = false;
            this.button_FFT.Click += new System.EventHandler(this.button_FFT_Click);
            // 
            // radioButton_FFT_LPF2_2
            // 
            this.radioButton_FFT_LPF2_2.AutoSize = true;
            this.radioButton_FFT_LPF2_2.Location = new System.Drawing.Point(16, 120);
            this.radioButton_FFT_LPF2_2.Name = "radioButton_FFT_LPF2_2";
            this.radioButton_FFT_LPF2_2.Size = new System.Drawing.Size(104, 21);
            this.radioButton_FFT_LPF2_2.TabIndex = 4;
            this.radioButton_FFT_LPF2_2.Text = "原始量測數據";
            this.radioButton_FFT_LPF2_2.UseVisualStyleBackColor = true;
            // 
            // radioButton_FFT_LPF2_1
            // 
            this.radioButton_FFT_LPF2_1.AutoSize = true;
            this.radioButton_FFT_LPF2_1.Location = new System.Drawing.Point(16, 97);
            this.radioButton_FFT_LPF2_1.Name = "radioButton_FFT_LPF2_1";
            this.radioButton_FFT_LPF2_1.Size = new System.Drawing.Size(104, 21);
            this.radioButton_FFT_LPF2_1.TabIndex = 3;
            this.radioButton_FFT_LPF2_1.Text = "原始量測數據";
            this.radioButton_FFT_LPF2_1.UseVisualStyleBackColor = true;
            // 
            // radioButton_FFT_LPF1_1
            // 
            this.radioButton_FFT_LPF1_1.AutoSize = true;
            this.radioButton_FFT_LPF1_1.Location = new System.Drawing.Point(16, 74);
            this.radioButton_FFT_LPF1_1.Name = "radioButton_FFT_LPF1_1";
            this.radioButton_FFT_LPF1_1.Size = new System.Drawing.Size(104, 21);
            this.radioButton_FFT_LPF1_1.TabIndex = 2;
            this.radioButton_FFT_LPF1_1.Text = "原始量測數據";
            this.radioButton_FFT_LPF1_1.UseVisualStyleBackColor = true;
            // 
            // radioButton_FFT_Kalman
            // 
            this.radioButton_FFT_Kalman.AutoSize = true;
            this.radioButton_FFT_Kalman.Location = new System.Drawing.Point(16, 51);
            this.radioButton_FFT_Kalman.Name = "radioButton_FFT_Kalman";
            this.radioButton_FFT_Kalman.Size = new System.Drawing.Size(104, 21);
            this.radioButton_FFT_Kalman.TabIndex = 1;
            this.radioButton_FFT_Kalman.Text = "原始量測數據";
            this.radioButton_FFT_Kalman.UseVisualStyleBackColor = true;
            // 
            // radioButton_FFT_Original
            // 
            this.radioButton_FFT_Original.AutoSize = true;
            this.radioButton_FFT_Original.Checked = true;
            this.radioButton_FFT_Original.Location = new System.Drawing.Point(16, 28);
            this.radioButton_FFT_Original.Name = "radioButton_FFT_Original";
            this.radioButton_FFT_Original.Size = new System.Drawing.Size(104, 21);
            this.radioButton_FFT_Original.TabIndex = 0;
            this.radioButton_FFT_Original.TabStop = true;
            this.radioButton_FFT_Original.Text = "原始量測數據";
            this.radioButton_FFT_Original.UseVisualStyleBackColor = true;
            // 
            // groupBox_Buffer
            // 
            this.groupBox_Buffer.Controls.Add(this.numericUpDown_BufferTriggerTimes);
            this.groupBox_Buffer.Controls.Add(this.label11);
            this.groupBox_Buffer.Controls.Add(this.label14);
            this.groupBox_Buffer.Controls.Add(this.label13);
            this.groupBox_Buffer.Controls.Add(this.label15);
            this.groupBox_Buffer.Controls.Add(this.numericUpDown_TimerTick2);
            this.groupBox_Buffer.Controls.Add(this.comboBox_SectionLength);
            this.groupBox_Buffer.Controls.Add(this.label9);
            this.groupBox_Buffer.Controls.Add(this.numericUpDown_ClockRate2);
            this.groupBox_Buffer.Controls.Add(this.label10);
            this.groupBox_Buffer.Controls.Add(this.label12);
            this.groupBox_Buffer.Location = new System.Drawing.Point(176, 7);
            this.groupBox_Buffer.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_Buffer.Name = "groupBox_Buffer";
            this.groupBox_Buffer.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_Buffer.Size = new System.Drawing.Size(197, 148);
            this.groupBox_Buffer.TabIndex = 46;
            this.groupBox_Buffer.TabStop = false;
            this.groupBox_Buffer.Text = "Buffer";
            // 
            // numericUpDown_BufferTriggerTimes
            // 
            this.numericUpDown_BufferTriggerTimes.Location = new System.Drawing.Point(71, 50);
            this.numericUpDown_BufferTriggerTimes.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numericUpDown_BufferTriggerTimes.Name = "numericUpDown_BufferTriggerTimes";
            this.numericUpDown_BufferTriggerTimes.Size = new System.Drawing.Size(89, 25);
            this.numericUpDown_BufferTriggerTimes.TabIndex = 23;
            this.numericUpDown_BufferTriggerTimes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_BufferTriggerTimes.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(165, 52);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(21, 17);
            this.label11.TabIndex = 22;
            this.label11.Text = "次";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 52);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 17);
            this.label14.TabIndex = 21;
            this.label14.Text = "觸發次數";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(166, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 17);
            this.label13.TabIndex = 20;
            this.label13.Text = "ms";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 17);
            this.label15.TabIndex = 18;
            this.label15.Text = "時間間隔";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericUpDown_TimerTick2
            // 
            this.numericUpDown_TimerTick2.Location = new System.Drawing.Point(71, 19);
            this.numericUpDown_TimerTick2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown_TimerTick2.Name = "numericUpDown_TimerTick2";
            this.numericUpDown_TimerTick2.Size = new System.Drawing.Size(89, 25);
            this.numericUpDown_TimerTick2.TabIndex = 17;
            this.numericUpDown_TimerTick2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_TimerTick2.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown_TimerTick2.ValueChanged += new System.EventHandler(this.numericUpDown_TimerTick2_ValueChanged);
            // 
            // comboBox_SectionLength
            // 
            this.comboBox_SectionLength.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SectionLength.FormattingEnabled = true;
            this.comboBox_SectionLength.Items.AddRange(new object[] {
            "128",
            "256",
            "512",
            "1024",
            "2048"});
            this.comboBox_SectionLength.Location = new System.Drawing.Point(71, 113);
            this.comboBox_SectionLength.Name = "comboBox_SectionLength";
            this.comboBox_SectionLength.Size = new System.Drawing.Size(89, 25);
            this.comboBox_SectionLength.TabIndex = 16;
            this.comboBox_SectionLength.SelectedIndexChanged += new System.EventHandler(this.comboBox_SectionLength_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(166, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(24, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Hz";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericUpDown_ClockRate2
            // 
            this.numericUpDown_ClockRate2.DecimalPlaces = 1;
            this.numericUpDown_ClockRate2.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown_ClockRate2.Location = new System.Drawing.Point(71, 83);
            this.numericUpDown_ClockRate2.Maximum = new decimal(new int[] {
            48000,
            0,
            0,
            0});
            this.numericUpDown_ClockRate2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_ClockRate2.Name = "numericUpDown_ClockRate2";
            this.numericUpDown_ClockRate2.Size = new System.Drawing.Size(89, 25);
            this.numericUpDown_ClockRate2.TabIndex = 14;
            this.numericUpDown_ClockRate2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_ClockRate2.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown_ClockRate2.ValueChanged += new System.EventHandler(this.numericUpDown_ClockRate2_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 17);
            this.label10.TabIndex = 13;
            this.label10.Text = "取樣頻率";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 118);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 17);
            this.label12.TabIndex = 7;
            this.label12.Text = "區段長度";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.numericUpDown_CutoffFreq);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Location = new System.Drawing.Point(1008, 123);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(237, 62);
            this.groupBox3.TabIndex = 45;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "低通濾波";
            // 
            // numericUpDown_CutoffFreq
            // 
            this.numericUpDown_CutoffFreq.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDown_CutoffFreq.Location = new System.Drawing.Point(141, 26);
            this.numericUpDown_CutoffFreq.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown_CutoffFreq.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_CutoffFreq.Name = "numericUpDown_CutoffFreq";
            this.numericUpDown_CutoffFreq.Size = new System.Drawing.Size(85, 25);
            this.numericUpDown_CutoffFreq.TabIndex = 6;
            this.numericUpDown_CutoffFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_CutoffFreq.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_CutoffFreq.ValueChanged += new System.EventHandler(this.numericUpDown_CutoffFreq_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(75, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 17);
            this.label7.TabIndex = 3;
            this.label7.Text = "截止頻率";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label_TimeConsumingMin);
            this.groupBox2.Controls.Add(this.label_TimeConsumingAvg);
            this.groupBox2.Controls.Add(this.label_TriggerTimes);
            this.groupBox2.Controls.Add(this.label_TotalData);
            this.groupBox2.Controls.Add(this.label_ActualTime);
            this.groupBox2.Controls.Add(this.label_TimePerRecord);
            this.groupBox2.Controls.Add(this.label_TimeConsumingMax);
            this.groupBox2.Controls.Add(this.label_TotalTime);
            this.groupBox2.Location = new System.Drawing.Point(512, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(175, 163);
            this.groupBox2.TabIndex = 43;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "量測統計";
            // 
            // label_TimeConsumingMin
            // 
            this.label_TimeConsumingMin.AutoSize = true;
            this.label_TimeConsumingMin.Location = new System.Drawing.Point(19, 118);
            this.label_TimeConsumingMin.Name = "label_TimeConsumingMin";
            this.label_TimeConsumingMin.Size = new System.Drawing.Size(60, 17);
            this.label_TimeConsumingMin.TabIndex = 38;
            this.label_TimeConsumingMin.Text = "每段耗時";
            // 
            // label_TimeConsumingAvg
            // 
            this.label_TimeConsumingAvg.AutoSize = true;
            this.label_TimeConsumingAvg.Location = new System.Drawing.Point(19, 135);
            this.label_TimeConsumingAvg.Name = "label_TimeConsumingAvg";
            this.label_TimeConsumingAvg.Size = new System.Drawing.Size(60, 17);
            this.label_TimeConsumingAvg.TabIndex = 37;
            this.label_TimeConsumingAvg.Text = "每段耗時";
            // 
            // label_TriggerTimes
            // 
            this.label_TriggerTimes.AutoSize = true;
            this.label_TriggerTimes.Location = new System.Drawing.Point(19, 84);
            this.label_TriggerTimes.Name = "label_TriggerTimes";
            this.label_TriggerTimes.Size = new System.Drawing.Size(60, 17);
            this.label_TriggerTimes.TabIndex = 36;
            this.label_TriggerTimes.Text = "觸發次數";
            // 
            // label_TotalData
            // 
            this.label_TotalData.AutoSize = true;
            this.label_TotalData.Location = new System.Drawing.Point(19, 42);
            this.label_TotalData.Name = "label_TotalData";
            this.label_TotalData.Size = new System.Drawing.Size(60, 17);
            this.label_TotalData.TabIndex = 35;
            this.label_TotalData.Text = "數據筆數";
            // 
            // label_ActualTime
            // 
            this.label_ActualTime.AutoSize = true;
            this.label_ActualTime.Location = new System.Drawing.Point(19, 84);
            this.label_ActualTime.Name = "label_ActualTime";
            this.label_ActualTime.Size = new System.Drawing.Size(60, 17);
            this.label_ActualTime.TabIndex = 34;
            this.label_ActualTime.Text = "資料時間";
            // 
            // label_TimePerRecord
            // 
            this.label_TimePerRecord.AutoSize = true;
            this.label_TimePerRecord.Location = new System.Drawing.Point(19, 60);
            this.label_TimePerRecord.Name = "label_TimePerRecord";
            this.label_TimePerRecord.Size = new System.Drawing.Size(60, 17);
            this.label_TimePerRecord.TabIndex = 33;
            this.label_TimePerRecord.Text = "每筆耗時";
            // 
            // label_TimeConsumingMax
            // 
            this.label_TimeConsumingMax.AutoSize = true;
            this.label_TimeConsumingMax.Location = new System.Drawing.Point(19, 101);
            this.label_TimeConsumingMax.Name = "label_TimeConsumingMax";
            this.label_TimeConsumingMax.Size = new System.Drawing.Size(60, 17);
            this.label_TimeConsumingMax.TabIndex = 32;
            this.label_TimeConsumingMax.Text = "每段耗時";
            // 
            // label_TotalTime
            // 
            this.label_TotalTime.AutoSize = true;
            this.label_TotalTime.Location = new System.Drawing.Point(19, 24);
            this.label_TotalTime.Name = "label_TotalTime";
            this.label_TotalTime.Size = new System.Drawing.Size(60, 17);
            this.label_TotalTime.TabIndex = 31;
            this.label_TotalTime.Text = "總計耗時";
            // 
            // groupBox_InstantParams
            // 
            this.groupBox_InstantParams.Controls.Add(this.numericUpDown_TimeToStop);
            this.groupBox_InstantParams.Controls.Add(this.label2);
            this.groupBox_InstantParams.Controls.Add(this.label3);
            this.groupBox_InstantParams.Controls.Add(this.label1);
            this.groupBox_InstantParams.Controls.Add(this.label_TimerTick);
            this.groupBox_InstantParams.Controls.Add(this.numericUpDown_TimerTick);
            this.groupBox_InstantParams.Location = new System.Drawing.Point(176, 7);
            this.groupBox_InstantParams.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_InstantParams.Name = "groupBox_InstantParams";
            this.groupBox_InstantParams.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_InstantParams.Size = new System.Drawing.Size(197, 88);
            this.groupBox_InstantParams.TabIndex = 42;
            this.groupBox_InstantParams.TabStop = false;
            this.groupBox_InstantParams.Text = "Instant";
            // 
            // numericUpDown_TimeToStop
            // 
            this.numericUpDown_TimeToStop.Location = new System.Drawing.Point(72, 54);
            this.numericUpDown_TimeToStop.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.numericUpDown_TimeToStop.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_TimeToStop.Name = "numericUpDown_TimeToStop";
            this.numericUpDown_TimeToStop.Size = new System.Drawing.Size(89, 25);
            this.numericUpDown_TimeToStop.TabIndex = 6;
            this.numericUpDown_TimeToStop.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_TimeToStop.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown_TimeToStop.ValueChanged += new System.EventHandler(this.numericUpDown_TimeToStop_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(167, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "秒";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(167, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "ms";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "量測時間";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_TimerTick
            // 
            this.label_TimerTick.AutoSize = true;
            this.label_TimerTick.Location = new System.Drawing.Point(8, 26);
            this.label_TimerTick.Name = "label_TimerTick";
            this.label_TimerTick.Size = new System.Drawing.Size(60, 17);
            this.label_TimerTick.TabIndex = 1;
            this.label_TimerTick.Text = "時間間隔";
            this.label_TimerTick.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericUpDown_TimerTick
            // 
            this.numericUpDown_TimerTick.Location = new System.Drawing.Point(72, 21);
            this.numericUpDown_TimerTick.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown_TimerTick.Name = "numericUpDown_TimerTick";
            this.numericUpDown_TimerTick.Size = new System.Drawing.Size(89, 25);
            this.numericUpDown_TimerTick.TabIndex = 0;
            this.numericUpDown_TimerTick.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_TimerTick.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown_TimerTick.ValueChanged += new System.EventHandler(this.numericUpDown_TimerTick_ValueChanged);
            // 
            // groupBox_StreamingParams
            // 
            this.groupBox_StreamingParams.Controls.Add(this.label8);
            this.groupBox_StreamingParams.Controls.Add(this.numericUpDown_ClockRate);
            this.groupBox_StreamingParams.Controls.Add(this.label6);
            this.groupBox_StreamingParams.Controls.Add(this.numericUpDown_StramingTriggerTimes);
            this.groupBox_StreamingParams.Controls.Add(this.label4);
            this.groupBox_StreamingParams.Controls.Add(this.label5);
            this.groupBox_StreamingParams.Location = new System.Drawing.Point(176, 7);
            this.groupBox_StreamingParams.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_StreamingParams.Name = "groupBox_StreamingParams";
            this.groupBox_StreamingParams.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_StreamingParams.Size = new System.Drawing.Size(197, 88);
            this.groupBox_StreamingParams.TabIndex = 41;
            this.groupBox_StreamingParams.TabStop = false;
            this.groupBox_StreamingParams.Text = "Straming";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(167, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 17);
            this.label8.TabIndex = 12;
            this.label8.Text = "Hz";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericUpDown_ClockRate
            // 
            this.numericUpDown_ClockRate.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown_ClockRate.Location = new System.Drawing.Point(73, 55);
            this.numericUpDown_ClockRate.Maximum = new decimal(new int[] {
            48000,
            0,
            0,
            0});
            this.numericUpDown_ClockRate.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_ClockRate.Name = "numericUpDown_ClockRate";
            this.numericUpDown_ClockRate.Size = new System.Drawing.Size(89, 25);
            this.numericUpDown_ClockRate.TabIndex = 11;
            this.numericUpDown_ClockRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_ClockRate.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown_ClockRate.ValueChanged += new System.EventHandler(this.numericUpDown_ClockRate_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "取樣頻率";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericUpDown_StramingTriggerTimes
            // 
            this.numericUpDown_StramingTriggerTimes.Location = new System.Drawing.Point(73, 25);
            this.numericUpDown_StramingTriggerTimes.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numericUpDown_StramingTriggerTimes.Name = "numericUpDown_StramingTriggerTimes";
            this.numericUpDown_StramingTriggerTimes.Size = new System.Drawing.Size(89, 25);
            this.numericUpDown_StramingTriggerTimes.TabIndex = 9;
            this.numericUpDown_StramingTriggerTimes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_StramingTriggerTimes.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown_StramingTriggerTimes.ValueChanged += new System.EventHandler(this.numericUpDown_TotalTriggerTimes_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(167, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "次";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "觸發次數";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox_Mode
            // 
            this.groupBox_Mode.Controls.Add(this.radioButton_Buffer);
            this.groupBox_Mode.Controls.Add(this.radioButton_Streaming);
            this.groupBox_Mode.Controls.Add(this.radioButton_Instant);
            this.groupBox_Mode.Location = new System.Drawing.Point(9, 98);
            this.groupBox_Mode.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_Mode.Name = "groupBox_Mode";
            this.groupBox_Mode.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_Mode.Size = new System.Drawing.Size(118, 87);
            this.groupBox_Mode.TabIndex = 40;
            this.groupBox_Mode.TabStop = false;
            this.groupBox_Mode.Text = "模式";
            // 
            // radioButton_Buffer
            // 
            this.radioButton_Buffer.AutoSize = true;
            this.radioButton_Buffer.Location = new System.Drawing.Point(19, 63);
            this.radioButton_Buffer.Name = "radioButton_Buffer";
            this.radioButton_Buffer.Size = new System.Drawing.Size(62, 21);
            this.radioButton_Buffer.TabIndex = 16;
            this.radioButton_Buffer.TabStop = true;
            this.radioButton_Buffer.Text = "Buffer";
            this.radioButton_Buffer.UseVisualStyleBackColor = true;
            this.radioButton_Buffer.CheckedChanged += new System.EventHandler(this.radioButton_Buffer_CheckedChanged);
            // 
            // radioButton_Streaming
            // 
            this.radioButton_Streaming.AutoSize = true;
            this.radioButton_Streaming.Location = new System.Drawing.Point(19, 42);
            this.radioButton_Streaming.Name = "radioButton_Streaming";
            this.radioButton_Streaming.Size = new System.Drawing.Size(88, 21);
            this.radioButton_Streaming.TabIndex = 15;
            this.radioButton_Streaming.TabStop = true;
            this.radioButton_Streaming.Text = "Streaming";
            this.radioButton_Streaming.UseVisualStyleBackColor = true;
            this.radioButton_Streaming.CheckedChanged += new System.EventHandler(this.radioButton_Streaming_CheckedChanged);
            // 
            // radioButton_Instant
            // 
            this.radioButton_Instant.AutoSize = true;
            this.radioButton_Instant.Checked = true;
            this.radioButton_Instant.Location = new System.Drawing.Point(19, 21);
            this.radioButton_Instant.Name = "radioButton_Instant";
            this.radioButton_Instant.Size = new System.Drawing.Size(69, 21);
            this.radioButton_Instant.TabIndex = 14;
            this.radioButton_Instant.TabStop = true;
            this.radioButton_Instant.Text = "Instant";
            this.radioButton_Instant.UseVisualStyleBackColor = true;
            this.radioButton_Instant.CheckedChanged += new System.EventHandler(this.radioButton_Instant_CheckedChanged);
            // 
            // checkBox_LPF2_2
            // 
            this.checkBox_LPF2_2.AutoSize = true;
            this.checkBox_LPF2_2.Checked = true;
            this.checkBox_LPF2_2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_LPF2_2.Location = new System.Drawing.Point(9, 69);
            this.checkBox_LPF2_2.Name = "checkBox_LPF2_2";
            this.checkBox_LPF2_2.Size = new System.Drawing.Size(83, 21);
            this.checkBox_LPF2_2.TabIndex = 39;
            this.checkBox_LPF2_2.Text = "checkBox";
            this.checkBox_LPF2_2.UseVisualStyleBackColor = true;
            this.checkBox_LPF2_2.CheckedChanged += new System.EventHandler(this.checkBox_LPF2_2_CheckedChanged);
            // 
            // checkBox_LPF2_1
            // 
            this.checkBox_LPF2_1.AutoSize = true;
            this.checkBox_LPF2_1.Checked = true;
            this.checkBox_LPF2_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_LPF2_1.Location = new System.Drawing.Point(9, 48);
            this.checkBox_LPF2_1.Name = "checkBox_LPF2_1";
            this.checkBox_LPF2_1.Size = new System.Drawing.Size(83, 21);
            this.checkBox_LPF2_1.TabIndex = 38;
            this.checkBox_LPF2_1.Text = "checkBox";
            this.checkBox_LPF2_1.UseVisualStyleBackColor = true;
            this.checkBox_LPF2_1.CheckedChanged += new System.EventHandler(this.checkBox_LPF2_1_CheckedChanged);
            // 
            // checkBox_LPF1_1
            // 
            this.checkBox_LPF1_1.AutoSize = true;
            this.checkBox_LPF1_1.Checked = true;
            this.checkBox_LPF1_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_LPF1_1.Location = new System.Drawing.Point(9, 27);
            this.checkBox_LPF1_1.Name = "checkBox_LPF1_1";
            this.checkBox_LPF1_1.Size = new System.Drawing.Size(83, 21);
            this.checkBox_LPF1_1.TabIndex = 37;
            this.checkBox_LPF1_1.Text = "checkBox";
            this.checkBox_LPF1_1.UseVisualStyleBackColor = true;
            this.checkBox_LPF1_1.CheckedChanged += new System.EventHandler(this.checkBox_LPF1_1_CheckedChanged);
            // 
            // checkBox_Kalman
            // 
            this.checkBox_Kalman.AutoSize = true;
            this.checkBox_Kalman.Checked = true;
            this.checkBox_Kalman.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_Kalman.Location = new System.Drawing.Point(9, 6);
            this.checkBox_Kalman.Name = "checkBox_Kalman";
            this.checkBox_Kalman.Size = new System.Drawing.Size(83, 21);
            this.checkBox_Kalman.TabIndex = 36;
            this.checkBox_Kalman.Text = "checkBox";
            this.checkBox_Kalman.UseVisualStyleBackColor = true;
            this.checkBox_Kalman.CheckedChanged += new System.EventHandler(this.checkBox_Kalman_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown_KalmanQ);
            this.groupBox1.Controls.Add(this.numericUpDown_KalmanR);
            this.groupBox1.Controls.Add(this.label_KalmanQ);
            this.groupBox1.Controls.Add(this.label_KalmanR);
            this.groupBox1.Location = new System.Drawing.Point(1008, 20);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(237, 95);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "卡爾曼濾波";
            // 
            // numericUpDown_KalmanQ
            // 
            this.numericUpDown_KalmanQ.DecimalPlaces = 3;
            this.numericUpDown_KalmanQ.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown_KalmanQ.Location = new System.Drawing.Point(141, 60);
            this.numericUpDown_KalmanQ.Name = "numericUpDown_KalmanQ";
            this.numericUpDown_KalmanQ.Size = new System.Drawing.Size(85, 25);
            this.numericUpDown_KalmanQ.TabIndex = 7;
            this.numericUpDown_KalmanQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_KalmanQ.ValueChanged += new System.EventHandler(this.numericUpDown_KalmanQ_ValueChanged);
            // 
            // numericUpDown_KalmanR
            // 
            this.numericUpDown_KalmanR.DecimalPlaces = 3;
            this.numericUpDown_KalmanR.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown_KalmanR.Location = new System.Drawing.Point(141, 29);
            this.numericUpDown_KalmanR.Name = "numericUpDown_KalmanR";
            this.numericUpDown_KalmanR.Size = new System.Drawing.Size(85, 25);
            this.numericUpDown_KalmanR.TabIndex = 6;
            this.numericUpDown_KalmanR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_KalmanR.ValueChanged += new System.EventHandler(this.numericUpDown_KalmanR_ValueChanged);
            // 
            // label_KalmanQ
            // 
            this.label_KalmanQ.AutoSize = true;
            this.label_KalmanQ.Location = new System.Drawing.Point(7, 64);
            this.label_KalmanQ.Name = "label_KalmanQ";
            this.label_KalmanQ.Size = new System.Drawing.Size(128, 17);
            this.label_KalmanQ.TabIndex = 5;
            this.label_KalmanQ.Text = "Measurement noise";
            this.label_KalmanQ.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_KalmanR
            // 
            this.label_KalmanR.AutoSize = true;
            this.label_KalmanR.Location = new System.Drawing.Point(46, 33);
            this.label_KalmanR.Name = "label_KalmanR";
            this.label_KalmanR.Size = new System.Drawing.Size(89, 17);
            this.label_KalmanR.TabIndex = 3;
            this.label_KalmanR.Text = "Process noise";
            this.label_KalmanR.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button_Reset
            // 
            this.button_Reset.BackColor = System.Drawing.Color.Coral;
            this.button_Reset.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Reset.Location = new System.Drawing.Point(390, 150);
            this.button_Reset.Margin = new System.Windows.Forms.Padding(4);
            this.button_Reset.Name = "button_Reset";
            this.button_Reset.Size = new System.Drawing.Size(85, 35);
            this.button_Reset.TabIndex = 34;
            this.button_Reset.Text = "Reset";
            this.button_Reset.UseVisualStyleBackColor = false;
            this.button_Reset.Click += new System.EventHandler(this.button_Reset_Click);
            // 
            // button_Stop
            // 
            this.button_Stop.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Stop.Location = new System.Drawing.Point(390, 56);
            this.button_Stop.Margin = new System.Windows.Forms.Padding(4);
            this.button_Stop.Name = "button_Stop";
            this.button_Stop.Size = new System.Drawing.Size(85, 35);
            this.button_Stop.TabIndex = 33;
            this.button_Stop.Text = "Stop";
            this.button_Stop.UseVisualStyleBackColor = true;
            this.button_Stop.Click += new System.EventHandler(this.button_Stop_Click);
            // 
            // button_Start
            // 
            this.button_Start.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Start.Location = new System.Drawing.Point(390, 13);
            this.button_Start.Margin = new System.Windows.Forms.Padding(4);
            this.button_Start.Name = "button_Start";
            this.button_Start.Size = new System.Drawing.Size(85, 35);
            this.button_Start.TabIndex = 32;
            this.button_Start.Text = "Start";
            this.button_Start.UseVisualStyleBackColor = true;
            this.button_Start.Click += new System.EventHandler(this.button_Start_Click);
            // 
            // panel_Plot
            // 
            this.panel_Plot.AutoSize = true;
            this.panel_Plot.Controls.Add(this.tabControl_View);
            this.panel_Plot.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Plot.Location = new System.Drawing.Point(0, 24);
            this.panel_Plot.Name = "panel_Plot";
            this.panel_Plot.Size = new System.Drawing.Size(1275, 356);
            this.panel_Plot.TabIndex = 33;
            // 
            // tabControl_View
            // 
            this.tabControl_View.Controls.Add(this.tabPage_MeasureData);
            this.tabControl_View.Controls.Add(this.tabPage_FFT);
            this.tabControl_View.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_View.Location = new System.Drawing.Point(0, 0);
            this.tabControl_View.Name = "tabControl_View";
            this.tabControl_View.SelectedIndex = 0;
            this.tabControl_View.Size = new System.Drawing.Size(1275, 356);
            this.tabControl_View.TabIndex = 11;
            // 
            // tabPage_MeasureData
            // 
            this.tabPage_MeasureData.Controls.Add(this.formsPlot_Measure);
            this.tabPage_MeasureData.Location = new System.Drawing.Point(4, 26);
            this.tabPage_MeasureData.Name = "tabPage_MeasureData";
            this.tabPage_MeasureData.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_MeasureData.Size = new System.Drawing.Size(1267, 326);
            this.tabPage_MeasureData.TabIndex = 0;
            this.tabPage_MeasureData.Text = "量測數據";
            this.tabPage_MeasureData.UseVisualStyleBackColor = true;
            // 
            // formsPlot_Measure
            // 
            this.formsPlot_Measure.DisplayScale = 0F;
            this.formsPlot_Measure.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formsPlot_Measure.Location = new System.Drawing.Point(3, 3);
            this.formsPlot_Measure.Margin = new System.Windows.Forms.Padding(4);
            this.formsPlot_Measure.Name = "formsPlot_Measure";
            this.formsPlot_Measure.Size = new System.Drawing.Size(1261, 320);
            this.formsPlot_Measure.TabIndex = 11;
            // 
            // tabPage_FFT
            // 
            this.tabPage_FFT.Controls.Add(this.formsPlot_FFT);
            this.tabPage_FFT.Location = new System.Drawing.Point(4, 26);
            this.tabPage_FFT.Name = "tabPage_FFT";
            this.tabPage_FFT.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_FFT.Size = new System.Drawing.Size(1267, 326);
            this.tabPage_FFT.TabIndex = 1;
            this.tabPage_FFT.Text = "快速傅立葉";
            this.tabPage_FFT.UseVisualStyleBackColor = true;
            // 
            // formsPlot_FFT
            // 
            this.formsPlot_FFT.DisplayScale = 0F;
            this.formsPlot_FFT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formsPlot_FFT.Location = new System.Drawing.Point(3, 3);
            this.formsPlot_FFT.Name = "formsPlot_FFT";
            this.formsPlot_FFT.Size = new System.Drawing.Size(1261, 320);
            this.formsPlot_FFT.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1275, 24);
            this.menuStrip1.TabIndex = 34;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.toolStripSeparator2,
            this.fFTToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.saveToolStripMenuItem.Text = "儲存數據為csv檔";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(160, 6);
            // 
            // fFTToolStripMenuItem
            // 
            this.fFTToolStripMenuItem.Name = "fFTToolStripMenuItem";
            this.fFTToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.fFTToolStripMenuItem.Text = "快速傅立葉";
            this.fFTToolStripMenuItem.Click += new System.EventHandler(this.fFTToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(160, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.exitToolStripMenuItem.Text = "結束程式";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // form1BindingSource
            // 
            this.form1BindingSource.DataSource = typeof(USB4704Test_Analyze.Form1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1275, 576);
            this.Controls.Add(this.panel_Plot);
            this.Controls.Add(this.panel_Operate);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USB-4704 & T22";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.panel_Operate.ResumeLayout(false);
            this.panel_Operate.PerformLayout();
            this.groupBox_FFT.ResumeLayout(false);
            this.groupBox_FFT.PerformLayout();
            this.groupBox_Buffer.ResumeLayout(false);
            this.groupBox_Buffer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_BufferTriggerTimes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TimerTick2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ClockRate2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_CutoffFreq)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox_InstantParams.ResumeLayout(false);
            this.groupBox_InstantParams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TimeToStop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_TimerTick)).EndInit();
            this.groupBox_StreamingParams.ResumeLayout(false);
            this.groupBox_StreamingParams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ClockRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_StramingTriggerTimes)).EndInit();
            this.groupBox_Mode.ResumeLayout(false);
            this.groupBox_Mode.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_KalmanQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_KalmanR)).EndInit();
            this.panel_Plot.ResumeLayout(false);
            this.tabControl_View.ResumeLayout(false);
            this.tabPage_MeasureData.ResumeLayout(false);
            this.tabPage_FFT.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.form1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_Operate;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label_TimeConsumingMin;
        private System.Windows.Forms.Label label_TimeConsumingAvg;
        private System.Windows.Forms.Label label_TriggerTimes;
        private System.Windows.Forms.Label label_TotalData;
        private System.Windows.Forms.Label label_ActualTime;
        private System.Windows.Forms.Label label_TimePerRecord;
        private System.Windows.Forms.Label label_TimeConsumingMax;
        private System.Windows.Forms.Label label_TotalTime;
        private System.Windows.Forms.GroupBox groupBox_InstantParams;
        private System.Windows.Forms.NumericUpDown numericUpDown_TimeToStop;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_TimerTick;
        private System.Windows.Forms.NumericUpDown numericUpDown_TimerTick;
        private System.Windows.Forms.GroupBox groupBox_StreamingParams;
        private System.Windows.Forms.NumericUpDown numericUpDown_StramingTriggerTimes;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox_Mode;
        private System.Windows.Forms.RadioButton radioButton_Streaming;
        private System.Windows.Forms.RadioButton radioButton_Instant;
        private System.Windows.Forms.CheckBox checkBox_LPF2_2;
        private System.Windows.Forms.CheckBox checkBox_LPF2_1;
        private System.Windows.Forms.CheckBox checkBox_LPF1_1;
        private System.Windows.Forms.CheckBox checkBox_Kalman;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown_KalmanQ;
        private System.Windows.Forms.NumericUpDown numericUpDown_KalmanR;
        private System.Windows.Forms.Label label_KalmanQ;
        private System.Windows.Forms.Label label_KalmanR;
        private System.Windows.Forms.Button button_Reset;
        private System.Windows.Forms.Button button_Stop;
        private System.Windows.Forms.Button button_Start;
        private System.Windows.Forms.Panel panel_Plot;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl_View;
        private System.Windows.Forms.TabPage tabPage_MeasureData;
        private ScottPlot.WinForms.FormsPlot formsPlot_Measure;
        private System.Windows.Forms.TabPage tabPage_FFT;
        private ScottPlot.WinForms.FormsPlot formsPlot_FFT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem fFTToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown numericUpDown_CutoffFreq;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radioButton_Buffer;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numericUpDown_ClockRate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox_Buffer;
        private System.Windows.Forms.ComboBox comboBox_SectionLength;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown numericUpDown_ClockRate2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown numericUpDown_TimerTick2;
        private System.Windows.Forms.NumericUpDown numericUpDown_BufferTriggerTimes;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.BindingSource form1BindingSource;
        private System.Windows.Forms.GroupBox groupBox_FFT;
        private System.Windows.Forms.Button button_FFT;
        private System.Windows.Forms.RadioButton radioButton_FFT_LPF2_2;
        private System.Windows.Forms.RadioButton radioButton_FFT_LPF2_1;
        private System.Windows.Forms.RadioButton radioButton_FFT_LPF1_1;
        private System.Windows.Forms.RadioButton radioButton_FFT_Kalman;
        private System.Windows.Forms.RadioButton radioButton_FFT_Original;
    }
}
