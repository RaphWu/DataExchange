using System.ComponentModel;
using ScottPlot;
using ScottPlot.Plottables;

namespace T22Demo
{
    public partial class Form1 : Form, Observ
    {
        #region fields

        InstantAiCtrl _plotAiCtrl;
        WaveformAiCtrl _waveformAiCtrl;
        HighAccurateTimer _haTimer = new HighAccurateTimer();
        BindingSource bs = new BindingSource();

        const string deviceCode = "USB-4704,BID#0";
        const int channel = 0;  // �q�D�s���G0~7
        ModeName _modeName;

        // Filter
        FilterKalman _filterKalman;
        const double KALMAN_INIT_R = 0.2;
        const double KALMAN_INIT_Q = 1.0;

        private CancellationTokenSource _cts;

        #endregion

        #region property

        public bool IsRunning
        {
            get { return _isRunning; }
            set
            {
                if (_isRunning != value)
                {
                    _isRunning = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _isRunning = false;

        public bool IsStopped
        {
            get { return _isStopped; }
            set
            {
                if (_isStopped != value)
                {
                    _isStopped = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _isStopped = true;

        const int TIMER_TICK = 5; // ms
        public int TimerTick
        {
            get { return _timerTick; }
            set
            {
                if (_timerTick != value)
                {
                    _timerTick = value;
                    TimerTickSecond = value / 1000.0;
                    //_commonTimer. = TimerTick;
                    _plot.XLabel($"�ɶ��G�C���q���Ȩ��ȶ��j {_timerTick} ms");
                }
            }
        }
        private int _timerTick;

        public double TimerTickSecond
        {
            get { return _timerTickSecond; }
            set
            {
                if (_timerTickSecond != value)
                {
                    _timerTickSecond = value;
                }
            }
        }
        private double _timerTickSecond;

        const int TIME_TO_STOP = 5;
        public int TimeToStop
        {
            get { return _timeToStop; }
            set
            {
                if (_timeToStop != value)
                {
                    _timeToStop = value;
                }
            }
        }
        private int _timeToStop;

        const int TOTAL_TRIGGER_TIMES = 2;
        public int TotalTriggerTimes
        {
            get { return _totalTriggerTimes; }
            set
            {
                if (_totalTriggerTimes != value)
                {
                    _totalTriggerTimes = value;
                }
            }
        }
        private int _totalTriggerTimes;

        const double CLOCK_RATE = 2000.0;
        public double ClockRate
        {
            get { return _clockRate; }
            set
            {
                if (_clockRate != value)
                {
                    _clockRate = value;
                    _waveformAiCtrl.Conversion.ClockRate = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _clockRate;

        const string SECTION_LENGTH = "512";
        public string SectionLengthString
        {
            get { return _sectionLengthString; }
            set
            {
                if (_sectionLengthString != value)
                {
                    _sectionLengthString = value;
                    SectionLength = int.Parse(value);
                    NotifyPropertyChanged();
                }
            }
        }
        private string _sectionLengthString;

        public int SectionLength
        {
            get { return _sectionLength; }
            set
            {
                if (_sectionLength != value)
                {
                    _sectionLength = value;
                    _waveformAiCtrl.Record.SectionLength = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _sectionLength;

        const double CUTOFF_FREQ = 40.0;

        public double CutoffFreq
        {
            get { return _cutoffFreq; }
            set
            {
                if (_cutoffFreq != value)
                {
                    _cutoffFreq = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _cutoffFreq;

        #endregion

        #region ctor

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                _cts = new CancellationTokenSource();

                bs.DataSource = this;

                // Filter
                _filterKalman = new FilterKalman(KALMAN_INIT_R, KALMAN_INIT_Q, 1, 1, 1);

                // ScootPlot
                _plotAiCtrl = new InstantAiCtrl();
                _plotAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
                if (!_plotAiCtrl.Initialized)
                {
                    MessageBox.Show("No device be selected or device open failed!", "InstantAI");
                    Close();
                    return;
                }
                _plotAiCtrl.Channels[0].SignalType = AiSignalType.Differential;

                _waveformAiCtrl = new WaveformAiCtrl();
                _waveformAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
                if (!_waveformAiCtrl.Initialized)
                {
                    MessageBox.Show("No device be selected or device open failed!", "StreamingAI");
                    Close();
                    return;
                }
                _waveformAiCtrl.Channels[0].SignalType = AiSignalType.Differential;
                _waveformAiCtrl.DataReady += _waveformAiCtrl_DataReady;
                _waveformAiCtrl.CacheOverflow += _waveformAiCtrl_CacheOverflow;
                _waveformAiCtrl.Overrun += _waveformAiCtrl_Overrun;

                _plot = formsPlot_Measure.Plot;
                _plot.YLabel("�q�� ( V )");

                _plotAxis = _plot.Axes;
                _plotAxis.Left.Label.FontName = FONT_NAME;
                _plotAxis.Bottom.Label.FontName = FONT_NAME;

                Crosshair MyCrosshair = _plot.Add.Crosshair(0, 0);
                MyCrosshair.IsVisible = false;
                MyCrosshair.MarkerShape = MarkerShape.OpenCircle;
                MyCrosshair.MarkerSize = 15;

                Marker MyHighlightMarker = _plot.Add.Marker(0, 0);
                MyHighlightMarker.Shape = MarkerShape.OpenCircle;
                MyHighlightMarker.Size = 17;
                MyHighlightMarker.LineWidth = 2;

                Text MyHighlightText = _plot.Add.Text("", 0, 0);
                MyHighlightText.LabelAlignment = Alignment.LowerLeft;
                MyHighlightText.LabelBold = true;
                MyHighlightText.OffsetX = 7;
                MyHighlightText.OffsetY = -7;

                formsPlot_Measure.MouseMove += (s, me) =>
                {
                    // determine where the mouse is
                    Pixel mousePixel = new Pixel(me.Location.X, me.Location.Y);
                    Coordinates mouseLocation = formsPlot_Measure.Plot.GetCoordinates(mousePixel);

                    // get the nearest point of each scatter
                    Dictionary<int, DataPoint> nearestPoints = new Dictionary<int, DataPoint>();
                    for (int i = 0; i < _instantPlotList.Count; i++)
                    {
                        DataPoint nearestPoint = _instantPlotList[i].Data.GetNearest(mouseLocation, formsPlot_Measure.Plot.LastRender);
                        nearestPoints.Add(i, nearestPoint);
                    }

                    // determine which scatter's nearest point is nearest to the mouse
                    bool pointSelected = false;
                    int scatterIndex = -1;
                    double smallestDistance = double.MaxValue;
                    for (int i = 0; i < nearestPoints.Count; i++)
                    {
                        if (nearestPoints[i].IsReal)
                        {
                            // calculate the distance of the point to the mouse
                            double distance = nearestPoints[i].Coordinates.Distance(mouseLocation);
                            if (distance < smallestDistance)
                            {
                                // store the index
                                scatterIndex = i;
                                pointSelected = true;
                                // update the smallest distance
                                smallestDistance = distance;
                            }
                        }
                    }

                    // place the crosshair, marker and text over the selected point
                    if (pointSelected)
                    {
                        SignalXY signalXY = _instantPlotList[scatterIndex];
                        DataPoint point = nearestPoints[scatterIndex];

                        MyCrosshair.IsVisible = true;
                        MyCrosshair.Position = point.Coordinates;
                        MyCrosshair.LineColor = signalXY.MarkerStyle.FillColor;

                        MyHighlightMarker.IsVisible = true;
                        MyHighlightMarker.Location = point.Coordinates;
                        MyHighlightMarker.MarkerStyle.LineColor = signalXY.MarkerStyle.FillColor;

                        MyHighlightText.IsVisible = true;
                        MyHighlightText.Location = point.Coordinates;
                        MyHighlightText.LabelText = $"{point.X:0.##}, {point.Y:0.##}";
                        MyHighlightText.LabelFontColor = signalXY.MarkerStyle.FillColor;

                        formsPlot_Measure.Refresh();
                        base.Text = $"�ƾ�={signalXY.LegendText}, �� {point.Index} ��, �ɶ�={point.X:0.##}, �q��={point.Y:0.##}";
                    }

                    // hide the crosshair, marker and text when no point is selected
                    if (!pointSelected && MyCrosshair.IsVisible)
                    {
                        MyCrosshair.IsVisible = false;
                        MyHighlightMarker.IsVisible = false;
                        MyHighlightText.IsVisible = false;
                        formsPlot_Measure.Refresh();
                        base.Text = $"No point selected";
                    }

                    //// determine where the mouse is and get the nearest point
                    //Pixel mousePixel = new Pixel(me.Location.X, me.Location.Y);
                    //Coordinates mouseLocation = formsPlot_Measure.Plot.GetCoordinates(mousePixel);
                    ////DataPoint nearest = rbNearestXY.Checked
                    ////? MyScatter.Data.GetNearest(mouseLocation, formsPlot_Measure.Plot.LastRender)
                    ////: MyScatter.Data.GetNearestX(mouseLocation, formsPlot_Measure.Plot.LastRender);
                    //DataPoint nearest = _instantPlot_Measure.Data.GetNearest(mouseLocation, formsPlot_Measure.Plot.LastRender);

                    //// place the crosshair over the highlighted point
                    //if (nearest.IsReal)
                    //{
                    //    MyCrosshair.IsVisible = true;
                    //    MyCrosshair.Position = nearest.Coordinates;
                    //    formsPlot_Measure.Refresh();
                    //    Text = $"�ĴX���ƾ�: {nearest.Index + 1}, �ɶ�: {nearest.X:0.##}, �q��: {nearest.Y:0.##}";
                    //}

                    //// hide the crosshair when no point is selected
                    //if (!nearest.IsReal && MyCrosshair.IsVisible)
                    //{
                    //    MyCrosshair.IsVisible = false;
                    //    formsPlot_Measure.Refresh();
                    //    Text = $"No point selected";
                    //}
                };

                var leg = _plot.ShowLegend();
                leg.Alignment = Alignment.LowerLeft;
                leg.FontName = FONT_NAME;

                Reset(true);
                radioButton_Instant.Checked = true;
                ModeSelect(ModeName.Instant);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "An error occurred", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            //comboBox_SectionLength.SelectedIndex = comboBox_SectionLength.Items.IndexOf(SECTION_LENGTH.ToString());

            numericUpDown_KalmanR.Value = decimal.Parse(KALMAN_INIT_R.ToString());
            numericUpDown_KalmanQ.Value = decimal.Parse(KALMAN_INIT_Q.ToString());
            numericUpDown_CutoffFreq.Value = decimal.Parse(CUTOFF_FREQ.ToString());

            checkBox_Kalman.Text = PLOT_NAME_KALMAN;
            checkBox_LPF1_1.Text = PLOT_NAME_LPF1_1;
            checkBox_LPF2_1.Text = PLOT_NAME_LPF2_1;
            checkBox_LPF2_2.Text = PLOT_NAME_LPF2_2;

            radioButton_FFT_Kalman.Text = PLOT_NAME_KALMAN;
            radioButton_FFT_LPF1_1.Text = PLOT_NAME_LPF1_1;
            radioButton_FFT_LPF2_1.Text = PLOT_NAME_LPF2_1;
            radioButton_FFT_LPF2_2.Text = PLOT_NAME_LPF2_2;

            button_Start.DataBindings.Add("Enabled", bs, "IsStopped", true, DataSourceUpdateMode.OnPropertyChanged);
            button_Stop.DataBindings.Add("Enabled", bs, "IsRunning", true, DataSourceUpdateMode.OnPropertyChanged);
            button_FFT.DataBindings.Add("Enabled", bs, "IsStopped", true, DataSourceUpdateMode.OnPropertyChanged);
            button_Reset.DataBindings.Add("Enabled", bs, "IsStopped", true, DataSourceUpdateMode.OnPropertyChanged);

            groupBox_Mode.DataBindings.Add("Enabled", bs, "IsStopped", true, DataSourceUpdateMode.OnPropertyChanged);
            groupBox_InstantParams.DataBindings.Add("Enabled", bs, "IsStopped", true, DataSourceUpdateMode.OnPropertyChanged);
            groupBox_StreamingParams.DataBindings.Add("Enabled", bs, "IsStopped", true, DataSourceUpdateMode.OnPropertyChanged);
            groupBox_Buffer.DataBindings.Add("Enabled", bs, "IsStopped", true, DataSourceUpdateMode.OnPropertyChanged);

            numericUpDown_TimerTick.DataBindings.Add("Value", bs, "TimerTick", true, DataSourceUpdateMode.OnPropertyChanged);
            numericUpDown_TimerTick2.DataBindings.Add("Value", bs, "TimerTick", true, DataSourceUpdateMode.OnPropertyChanged);
            numericUpDown_TimeToStop.DataBindings.Add("Value", bs, "TimeToStop", true, DataSourceUpdateMode.OnPropertyChanged);
            numericUpDown_StramingTriggerTimes.DataBindings.Add("Value", bs, "TotalTriggerTimes", true, DataSourceUpdateMode.OnPropertyChanged);
            numericUpDown_BufferTriggerTimes.DataBindings.Add("Value", bs, "TotalTriggerTimes", true, DataSourceUpdateMode.OnPropertyChanged);
            numericUpDown_ClockRate.DataBindings.Add("Value", bs, "ClockRate", true, DataSourceUpdateMode.OnPropertyChanged);
            numericUpDown_ClockRate2.DataBindings.Add("Value", bs, "ClockRate", true, DataSourceUpdateMode.OnPropertyChanged);
            comboBox_SectionLength.DataBindings.Add("SelectedItem", bs, "SectionLengthString", true, DataSourceUpdateMode.OnPropertyChanged);

            TimerTick = TIMER_TICK;
            TimeToStop = TIME_TO_STOP;
            TotalTriggerTimes = TOTAL_TRIGGER_TIMES;
            ClockRate = CLOCK_RATE;
            CutoffFreq = CUTOFF_FREQ;
            SectionLengthString = SECTION_LENGTH;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopAllRunner();

            //_haTimer.Dispose();

            _plotAiCtrl.Dispose();
            _plotAiCtrl = null;

            _waveformAiCtrl.Stop();
            _waveformAiCtrl.DataReady -= _waveformAiCtrl_DataReady;
            _waveformAiCtrl.CacheOverflow -= _waveformAiCtrl_CacheOverflow;
            _waveformAiCtrl.Overrun -= _waveformAiCtrl_Overrun;
            _waveformAiCtrl.Dispose();
            _waveformAiCtrl = null;
        }

        #endregion

        #region �Ҧ����

        #endregion

        #region �Ұ�/����

        private void button_Reset_Click(object sender, EventArgs e)
        {
            StopAllRunner();
            Reset();
        }

        private void button_Stop_Click(object sender, EventArgs e)
        {
            StopAllRunner();
            UpdateScreen();
        }

        private void button_Start_Click(object sender, EventArgs e)
        {
            StopAllRunner();
            Start();
        }

        #endregion
    }
}
