﻿namespace Calin.SignalProcessing.Filters
{
    internal class FilterData
    {
        private FilterData() { }
        private static readonly Lazy<FilterData> _instance = new(() => new FilterData());
        public static FilterData Instance => _instance.Value;

        internal double Const_2pi = Math.PI * 2; // 2π

        // 一階低通濾波器狀態變數
        internal double lpf1_yout = 0.0;
        internal double alpha;
        internal bool fisrt_xin = true; // 讓第一筆濾波值不要從零開始

        // 二階低通濾波器狀態變數
        internal double[] lpf2_yout = new double[3] { 0, 0, 0 };
        internal double[] lpf2_xin = new double[3] { 0, 0, 0 };
    }
}
