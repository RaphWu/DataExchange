﻿namespace Calin.SignalProcessing.Filters
{
    public interface ILowPassFilter
    {
        /// <summary>
        /// 一階低通濾波器。
        /// </summary>
        /// <param name="xin">輸入信號值。</param>
        /// <param name="fc">截止頻率。</param>
        /// <param name="Ts">採樣週期。</param>
        /// <returns>濾波後的信號值。</returns>
        double LPF1(double xin, double fc, double Ts);

        /// <summary>
        /// 二階低通濾波器。
        /// </summary>
        /// <param name="xin">輸入信號值。</param>
        /// <param name="fc">截止頻率。</param>
        /// <param name="Ts">採樣週期。</param>
        /// <returns>濾波後的信號值。</returns>
        double LowPassFilter2(double xin, double fc, double Ts);
    }
}
