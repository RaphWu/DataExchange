﻿using Calin.SignalProcessing.Filters;

namespace Calin.SignalProcessing
{
    public interface IFilter : ILowPassFilter, IKalmanFilter
    {
    }
}
