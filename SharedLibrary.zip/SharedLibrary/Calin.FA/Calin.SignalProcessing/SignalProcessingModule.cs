﻿using Autofac;
using Calin.SignalProcessing.Filters;

namespace Calin.SignalProcessing
{
    public class SignalProcessingModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<FilterService>()
                   .As<IFilter>()
                   .SingleInstance();
        }
    }
}
