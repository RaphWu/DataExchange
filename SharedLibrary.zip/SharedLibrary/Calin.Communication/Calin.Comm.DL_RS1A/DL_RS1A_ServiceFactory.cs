﻿using System;
using Calin.SerialPort;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// DL-RS1A 服務工廠實作。
    /// 負責建立 DL-RS1A 實例。
    /// </summary>
    /// <remarks>
    /// 此類別為 Singleton，可被 Autofac 註冊為 SingleInstance。
    /// 工廠本身不持有任何 DL-RS1A 實例的參考。
    /// </remarks>
    public class DL_RS1A_ServiceFactory : IDL_RS1A_ServiceFactory
    {
        private readonly ISerialPortServiceFactory _serialPortServiceFactory;

        /// <summary>
        /// 建立 DL_RS1A_ServiceFactory 實例。
        /// </summary>
        /// <param name="serialPortServiceFactory">SerialPort 服務工廠。</param>
        /// <exception cref="ArgumentNullException">當 serialPortServiceFactory 為 null 時拋出。</exception>
        public DL_RS1A_ServiceFactory(ISerialPortServiceFactory serialPortServiceFactory)
        {
            _serialPortServiceFactory = serialPortServiceFactory ?? throw new ArgumentNullException(nameof(serialPortServiceFactory));
        }

        /// <inheritdoc />
        public IDL_RS1A Create(DL_RS1A_Config dlrs1aConfig)
        {
            if (dlrs1aConfig == null)
            {
                throw new ArgumentNullException(nameof(dlrs1aConfig));
            }

            var serialPortConfig = new SerialPortConfig
            {
                PortName = dlrs1aConfig.PortName,
                BaudRate = dlrs1aConfig.BaudRate,
                DataBits = dlrs1aConfig.DataBits,
                Parity = dlrs1aConfig.Parity,
                StopBits = dlrs1aConfig.StopBits,
                ReadTimeout = dlrs1aConfig.ReadTimeout,
                WriteTimeout = dlrs1aConfig.WriteTimeout,
                EnableAsciiLineMode = true,
                AsciiLineTerminator = "\r\n",
                EnableAutoReconnect = false,
                EnableHeartbeat = false,
            };

            var serialPortService = _serialPortServiceFactory.Create(serialPortConfig);

            return new DL_RS1A_Service(dlrs1aConfig, serialPortService);
        }

        /// <inheritdoc />
        public IDL_RS1A CreateAndOpen(DL_RS1A_Config dlrs1aConfig)
        {
            var dlRS1A = Create(dlrs1aConfig);

            try
            {
                if (!dlRS1A.Open())
                {
                    dlRS1A.Dispose();
                    throw new InvalidOperationException($"Failed to open DL-RS1A on: {dlrs1aConfig.PortName}");
                }

                return dlRS1A;
            }
            catch
            {
                dlRS1A.Dispose();
                throw;
            }
        }
    }
}
