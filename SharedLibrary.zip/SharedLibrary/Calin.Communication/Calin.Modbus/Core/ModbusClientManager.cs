using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Calin.Logging.Abstractions;
using Calin.Modbus.Models;
using Microsoft.Extensions.Logging;

namespace Calin.Modbus.Core
{
    /// <summary>
    /// MODBUS �Ȥ�ݺ޲z����@�C
    /// �t�d�޲z�h�� ModbusClient ��Ҫ��ͩR�g���C
    /// </summary>
    /// <remarks>
    /// �����O�� Singleton�A�i�Q Autofac ���U�� SingleInstance�C
    /// �޲z�Ҧ��w���U�� ModbusClient�A�æb Dispose ������Ҧ��귽�C
    /// </remarks>
    public class ModbusClientManager : IModbusClientManager
    {
        private readonly ConcurrentDictionary<string, IModbus> _clients;
        private readonly ILogger<ModbusClientManager> _logger;
        private readonly object _lockObject = new object();
        private bool _disposed;

        /// <summary>
        /// �إ� ModbusClientManager ��ҡC
        /// </summary>
        public ModbusClientManager()
        {
            _clients = new ConcurrentDictionary<string, IModbus>(StringComparer.OrdinalIgnoreCase);
            _logger = LoggingBridge.CreateLogger<ModbusClientManager>();
        }

        /// <summary>
        /// ���o�w���U���Ȥ�ݼƶq�C
        /// </summary>
        public int ClientCount => _clients.Count;

        /// <summary>
        /// ���o�Ҧ��w���U���Ȥ�ݦW�١C
        /// </summary>
        public IReadOnlyList<string> RegisteredClients => _clients.Keys.ToList().AsReadOnly();

        /// <summary>
        /// ���U�@�� ModbusClient�C
        /// </summary>
        public bool Register(string name, IModbus client)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                _logger.LogError("���U���ѡG�W�٬��šC");
                throw new ArgumentException("Client name cannot be null or empty.", nameof(name));
            }

            if (client == null)
            {
                _logger.LogError("���U���ѡGclient �� null�AName='{Name}'�C", name);
                throw new ArgumentNullException(nameof(client));
            }

            var result = _clients.TryAdd(name, client);
            if (result)
            {
                _logger.LogInformation("�w���U ModbusClient�G{Name}", name);
            }
            else
            {
                _logger.LogWarning("���U ModbusClient ���ѡG{Name}�]�w�s�b�^", name);
            }
            return result;
        }

        /// <summary>
        /// �������U��������w�� ModbusClient�C
        /// </summary>
        public bool Unregister(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return false;
            }

            if (_clients.TryRemove(name, out IModbus client))
            {
                try
                {
                    _logger.LogInformation("�������U ModbusClient�G{Name}", name);
                    client.Disconnect();
                    if (client is IDisposable disposable)
                    {
                        disposable.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "�������U ModbusClient �ɵo�Ϳ��~�G{Name}", name);
                }

                return true;
            }

            return false;
        }

        /// <summary>
        /// ���o���w�� ModbusClient�C
        /// </summary>
        public IModbus GetClient(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return null;
            }

            _clients.TryGetValue(name, out IModbus client);
            return client;
        }

        /// <summary>
        /// ���ը��o���w�� ModbusClient�C
        /// </summary>
        public bool TryGetClient(string name, out IModbus client)
        {
            client = null;
            if (string.IsNullOrWhiteSpace(name))
            {
                return false;
            }

            return _clients.TryGetValue(name, out client);
        }

        /// <summary>
        /// �ˬd���w���Ȥ�ݬO�_�w���U�C
        /// </summary>
        public bool IsRegistered(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return false;
            }

            return _clients.ContainsKey(name);
        }

        /// <summary>
        /// �s�u���w���Ȥ�ݡC
        /// </summary>
        public bool Connect(string name)
        {
            var client = GetClient(name);
            if (client == null)
            {
                _logger.LogWarning("�s�u���ѡG�䤣�� client '{Name}'�C", name);
                return false;
            }

            try
            {
                _logger.LogInformation("���b�s�u client�G{Name}", name);
                return client.Connect();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "�s�u client �o�Ϳ��~�G{Name}", name);
                return false;
            }
        }

        /// <summary>
        /// ���_���w�Ȥ�ݪ��s�u�C
        /// </summary>
        public void Disconnect(string name)
        {
            var client = GetClient(name);
            if (client != null)
            {
                try
                {
                    _logger.LogInformation("���_ client �s�u�G{Name}", name);
                    client.Disconnect();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "���_ client �s�u�ɵo�Ϳ��~�G{Name}", name);
                }
            }
        }

        /// <summary>
        /// �s�u�Ҧ��w���U���Ȥ�ݡC
        /// </summary>
        public int ConnectAll()
        {
            int successCount = 0;

            _logger.LogInformation("�}�l�s�u�Ҧ��w���U�� client�]�@ {Count} �ӡ^...", _clients.Count);

            foreach (var kvp in _clients)
            {
                try
                {
                    if (kvp.Value.Connect())
                    {
                        successCount++;
                        _logger.LogDebug("�w�s�u client�G{Name}", kvp.Key);
                    }
                    else
                    {
                        _logger.LogWarning("�L�k�s�u client�G{Name}", kvp.Key);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "�s�u client �ɵo�Ϳ��~�G{Name}", kvp.Key);
                }
            }

            _logger.LogInformation("ConnectAll �����G{SuccessCount}/{TotalCount} �� client �w�s�u�C", successCount, _clients.Count);
            return successCount;
        }

        /// <summary>
        /// ���_�Ҧ��Ȥ�ݪ��s�u�C
        /// </summary>
        public void DisconnectAll()
        {
            _logger.LogInformation("���_�Ҧ��w���U client�]�@ {Count} �ӡ^...", _clients.Count);

            foreach (var kvp in _clients)
            {
                try
                {
                    kvp.Value.Disconnect();
                    _logger.LogDebug("�w���_ client�G{Name}", kvp.Key);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "���_ client �ɵo�Ϳ��~�G{Name}", kvp.Key);
                }
            }
        }

        /// <summary>
        /// ���o�Ҧ��Ȥ�ݪ��s�u���A�C
        /// </summary>
        public Dictionary<string, bool> GetAllConnectionStates()
        {
            var states = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

            foreach (var kvp in _clients)
            {
                states[kvp.Key] = kvp.Value.IsConnected;
            }

            return states;
        }

        /// <summary>
        /// Ū���O���Ȧs���C
        /// </summary>
        public ModbusResponse ReadHoldingRegisters(string clientName, byte slaveAddress, ushort startAddress, ushort quantity)
        {
            var client = GetClient(clientName);
            if (client == null)
            {
                _logger.LogError("Ū���O���Ȧs�����ѡG�䤣�� client '{ClientName}'�C", clientName);
                throw new InvalidOperationException($"Client '{clientName}' is not registered.");
            }

            return client.ReadHoldingRegisters(slaveAddress, startAddress, quantity);
        }

        /// <summary>
        /// �g�J��@�Ȧs���C
        /// </summary>
        public ModbusResponse WriteSingleRegister(string clientName, byte slaveAddress, ushort address, ushort value)
        {
            var client = GetClient(clientName);
            if (client == null)
            {
                _logger.LogError("�g�J��@�Ȧs�����ѡG�䤣�� client '{ClientName}'�C", clientName);
                throw new InvalidOperationException($"Client '{clientName}' is not registered.");
            }

            return client.WriteSingleRegister(slaveAddress, address, value);
        }

        /// <summary>
        /// ����Ҧ��귽�C
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _logger.LogInformation("���� ModbusClientManager �P�Ҧ��w���U�� client...");

                    // ���_�Ҧ��s�u������귽
                    foreach (var kvp in _clients)
                    {
                        try
                        {
                            kvp.Value.Disconnect();
                            if (kvp.Value is IDisposable disposable)
                            {
                                disposable.Dispose();
                            }
                            _logger.LogDebug("�w���� client�G{Name}", kvp.Key);
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError(ex, "���� client �ɵo�Ϳ��~�G{Name}", kvp.Key);
                        }
                    }

                    _clients.Clear();
                }

                _disposed = true;
            }
        }

        /// <summary>
        /// �Ѻc�禡�C
        /// </summary>
        ~ModbusClientManager()
        {
            Dispose(false);
        }
    }
}
