using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Calin.Modbus.Models;

namespace Calin.Modbus.Core
{
    /// <summary>
    /// MODBUS �Ȥ�ݺ޲z����@�C
    /// �t�d�޲z�h�� ModbusClient ��Ҫ��ͩR�g���C
    /// </summary>
    /// <remarks>
    /// �����O�� Singleton�A�i�Q Autofac ���U�� SingleInstance�C
    /// �޲z�Ҧ��w���U�� ModbusClient�A�æb Dispose ������Ҧ��귽�C
    /// </remarks>
    public class ModbusClientManager : IModbusClientManager
    {
        private readonly ConcurrentDictionary<string, IModbus> _clients;
        private readonly object _lockObject = new object();
        private bool _disposed;

        /// <summary>
        /// �إ� ModbusClientManager ��ҡC
        /// </summary>
        public ModbusClientManager()
        {
            _clients = new ConcurrentDictionary<string, IModbus>(StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// ���o�w���U���Ȥ�ݼƶq�C
        /// </summary>
        public int ClientCount => _clients.Count;

        /// <summary>
        /// ���o�Ҧ��w���U���Ȥ�ݦW�١C
        /// </summary>
        public IReadOnlyList<string> RegisteredClients => _clients.Keys.ToList().AsReadOnly();

        /// <summary>
        /// ���U�@�� ModbusClient�C
        /// </summary>
        public bool Register(string name, IModbus client)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Client name cannot be null or empty.", nameof(name));
            }

            if (client == null)
            {
                throw new ArgumentNullException(nameof(client));
            }

            return _clients.TryAdd(name, client);
        }

        /// <summary>
        /// �������U��������w�� ModbusClient�C
        /// </summary>
        public bool Unregister(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return false;
            }

            if (_clients.TryRemove(name, out IModbus client))
            {
                try
                {
                    client.Disconnect();
                    if (client is IDisposable disposable)
                    {
                        disposable.Dispose();
                    }
                }
                catch
                {
                    // ��������ɪ����~
                }

                return true;
            }

            return false;
        }

        /// <summary>
        /// ���o���w�� ModbusClient�C
        /// </summary>
        public IModbus GetClient(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return null;
            }

            _clients.TryGetValue(name, out IModbus client);
            return client;
        }

        /// <summary>
        /// ���ը��o���w�� ModbusClient�C
        /// </summary>
        public bool TryGetClient(string name, out IModbus client)
        {
            client = null;
            if (string.IsNullOrWhiteSpace(name))
            {
                return false;
            }

            return _clients.TryGetValue(name, out client);
        }

        /// <summary>
        /// �ˬd���w���Ȥ�ݬO�_�w���U�C
        /// </summary>
        public bool IsRegistered(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return false;
            }

            return _clients.ContainsKey(name);
        }

        /// <summary>
        /// �s�u���w���Ȥ�ݡC
        /// </summary>
        public bool Connect(string name)
        {
            var client = GetClient(name);
            if (client == null)
            {
                return false;
            }

            try
            {
                return client.Connect();
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// ���_���w�Ȥ�ݪ��s�u�C
        /// </summary>
        public void Disconnect(string name)
        {
            var client = GetClient(name);
            if (client != null)
            {
                try
                {
                    client.Disconnect();
                }
                catch
                {
                    // �����_�u�ɪ����~
                }
            }
        }

        /// <summary>
        /// �s�u�Ҧ��w���U���Ȥ�ݡC
        /// </summary>
        public int ConnectAll()
        {
            int successCount = 0;

            foreach (var kvp in _clients)
            {
                try
                {
                    if (kvp.Value.Connect())
                    {
                        successCount++;
                    }
                }
                catch
                {
                    // �����ӧO�s�u���~
                }
            }

            return successCount;
        }

        /// <summary>
        /// ���_�Ҧ��Ȥ�ݪ��s�u�C
        /// </summary>
        public void DisconnectAll()
        {
            foreach (var kvp in _clients)
            {
                try
                {
                    kvp.Value.Disconnect();
                }
                catch
                {
                    // �����_�u�ɪ����~
                }
            }
        }

        /// <summary>
        /// ���o�Ҧ��Ȥ�ݪ��s�u���A�C
        /// </summary>
        public Dictionary<string, bool> GetAllConnectionStates()
        {
            var states = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

            foreach (var kvp in _clients)
            {
                states[kvp.Key] = kvp.Value.IsConnected;
            }

            return states;
        }

        /// <summary>
        /// Ū���O���Ȧs���C
        /// </summary>
        public ModbusResponse ReadHoldingRegisters(string clientName, byte slaveAddress, ushort startAddress, ushort quantity)
        {
            var client = GetClient(clientName);
            if (client == null)
            {
                throw new InvalidOperationException($"Client '{clientName}' is not registered.");
            }

            return client.ReadHoldingRegisters(slaveAddress, startAddress, quantity);
        }

        /// <summary>
        /// �g�J��@�Ȧs���C
        /// </summary>
        public ModbusResponse WriteSingleRegister(string clientName, byte slaveAddress, ushort address, ushort value)
        {
            var client = GetClient(clientName);
            if (client == null)
            {
                throw new InvalidOperationException($"Client '{clientName}' is not registered.");
            }

            return client.WriteSingleRegister(slaveAddress, address, value);
        }

        /// <summary>
        /// ����Ҧ��귽�C
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // ���_�Ҧ��s�u������귽
                    foreach (var kvp in _clients)
                    {
                        try
                        {
                            kvp.Value.Disconnect();
                            if (kvp.Value is IDisposable disposable)
                            {
                                disposable.Dispose();
                            }
                        }
                        catch
                        {
                            // ��������ɪ����~
                        }
                    }

                    _clients.Clear();
                }

                _disposed = true;
            }
        }

        /// <summary>
        /// �Ѻc�禡�C
        /// </summary>
        ~ModbusClientManager()
        {
            Dispose(false);
        }
    }
}
