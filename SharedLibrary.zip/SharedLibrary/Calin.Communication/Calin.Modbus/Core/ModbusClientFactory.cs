using System;
using Calin.Logging.Abstractions;
using Calin.Modbus.Transport;
using Calin.SerialPort;
using Microsoft.Extensions.Logging;

namespace Calin.Modbus.Core
{
    /// <summary>
    /// MODBUS �Ȥ�ݤu�t��@�C
    /// �t�d�إ� ModbusClient ��ҡC
    /// </summary>
    /// <remarks>
    /// �����O�� Singleton�A�i�Q Autofac ���U�� SingleInstance�C
    /// �u�t�������������� ModbusClient ��Ҫ��ѦҡC
    /// </remarks>
    public class ModbusClientFactory : IModbusClientFactory
    {
        private readonly ISerialPortServiceFactory _serialPortServiceFactory;
        private readonly ILogger<ModbusClientFactory> _logger;

        /// <summary>
        /// �إ� ModbusClientFactory ��ҡ]�L�Ѽƫغc�禡�A�Ω�D DI ���ҡ^�C
        /// </summary>
        public ModbusClientFactory() : this(null)
        {
        }

        /// <summary>
        /// �إ� ModbusClientFactory ��ҡC
        /// </summary>
        /// <param name="serialPortServiceFactory">SerialPort �A�Ȥu�t�]�i��^�C</param>
        public ModbusClientFactory(ISerialPortServiceFactory serialPortServiceFactory)
        {
            _serialPortServiceFactory = serialPortServiceFactory;
            _logger = LoggingBridge.CreateLogger<ModbusClientFactory>();
        }

        /// <summary>
        /// �ϥβ{���� Transport �إ� ModbusClient�C
        /// </summary>
        /// <param name="transport">MODBUS �ǿ�h�C</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus Create(IModbusTransport transport, ModbusClientConfig config = null)
        {
            if (transport == null)
            {
                _logger.LogError("�إߥ��ѡGtransport �� null�C");
                throw new ArgumentNullException(nameof(transport));
            }

            config = config ?? ModbusClientConfig.Default;

            _logger.LogInformation("�إ� ModbusClient�ATransport �����G{TransportType}", transport.GetType().Name);

            var client = new ModbusClient(transport)
            {
                RetryCount = config.RetryCount,
                RetryDelay = config.RetryDelay
            };

            if (transport.Timeout == 0)
            {
                transport.Timeout = config.Timeout;
            }

            return client;
        }

        /// <summary>
        /// �ϥ� SerialPortService �إ� ModbusClient�]�ϥ� SerialPortTransport�^�C
        /// </summary>
        /// <param name="serialPortService">SerialPort �A�ȡC</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus CreateWithSerialPort(ISerialPortService serialPortService, ModbusClientConfig config = null)
        {
            if (serialPortService == null)
            {
                _logger.LogError("�إߥ��ѡGserialPortService �� null�C");
                throw new ArgumentNullException(nameof(serialPortService));
            }

            config = config ?? ModbusClientConfig.Default;

            _logger.LogInformation("�ϥ� SerialPortService �إ� ModbusClient�APort: {PortName}", serialPortService.PortName);

            var transport = new SerialPortTransport(serialPortService)
            {
                Timeout = config.Timeout
            };

            return Create(transport, config);
        }

        /// <summary>
        /// �ϥ� SerialPortConfig �إߧ��㪺 ModbusClient�C
        /// </summary>
        /// <param name="serialPortConfig">SerialPort �]�w�C</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus CreateWithSerialPortConfig(SerialPortConfig serialPortConfig, ModbusClientConfig config = null)
        {
            if (serialPortConfig == null)
            {
                _logger.LogError("�إߥ��ѡGserialPortConfig �� null�C");
                throw new ArgumentNullException(nameof(serialPortConfig));
            }

            _logger.LogInformation("�ϥ� SerialPortConfig �إ� ModbusClient�GPortName={PortName}, BaudRate={BaudRate}",
                serialPortConfig.PortName, serialPortConfig.BaudRate);

            ISerialPortService serialPortService;

            if (_serialPortServiceFactory != null)
            {
                serialPortService = _serialPortServiceFactory.Create(serialPortConfig);
            }
            else
            {
                // �D DI ���ҡG�����إ� SerialPortService
                serialPortService = new SerialPortService(serialPortConfig.Clone());
            }

            return CreateWithSerialPort(serialPortService, config);
        }

        /// <summary>
        /// �إߨϥ� MockTransport �� ModbusClient�]�Ω���ա^�C
        /// </summary>
        /// <param name="slaveAddress">������ Slave ��}�C</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus CreateMock(byte slaveAddress = 1, ModbusClientConfig config = null)
        {
            return CreateMock(out _, slaveAddress, config);
        }

        /// <summary>
        /// �إߨϥ� MockTransport �� ModbusClient�A�æ^�� MockTransport ��ҡC
        /// </summary>
        /// <param name="mockTransport">��X�� MockTransport ��ҡC</param>
        /// <param name="slaveAddress">������ Slave ��}�C</param>
        /// <param name="config">�Ȥ�ݳ]�w�]�i��^�C</param>
        /// <returns>�s�إߪ� ModbusClient ��ҡC</returns>
        public IModbus CreateMock(out MockTransport mockTransport, byte slaveAddress = 1, ModbusClientConfig config = null)
        {
            config = config ?? ModbusClientConfig.Default;

            _logger.LogInformation("�إ� MockTransport�ASlaveAddress: {SlaveAddress}", slaveAddress);

            mockTransport = new MockTransport
            {
                SlaveAddress = slaveAddress,
                Timeout = config.Timeout
            };

            return Create(mockTransport, config);
        }
    }
}
