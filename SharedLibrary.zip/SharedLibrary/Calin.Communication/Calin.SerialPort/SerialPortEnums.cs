namespace Calin.SerialPort
{
    /// <summary>
    /// �P��줸�]�w�C
    /// </summary>
    public enum Parity
    {
        /// <summary>
        /// �L�P��줸�C
        /// </summary>
        None = 0,

        /// <summary>
        /// �_�P��줸�C
        /// </summary>
        Odd = 1,

        /// <summary>
        /// ���P��줸�C
        /// </summary>
        Even = 2,

        /// <summary>
        /// �аO�P��줸�C
        /// </summary>
        Mark = 3,

        /// <summary>
        /// �Ŷ��P��줸�C
        /// </summary>
        Space = 4
    }

    /// <summary>
    /// ����줸�]�w�C
    /// </summary>
    public enum StopBits
    {
        /// <summary>
        /// 1 �Ӱ���줸�C
        /// </summary>
        One = 0,

        /// <summary>
        /// 1.5 �Ӱ���줸�C
        /// </summary>
        OnePointFive = 1,

        /// <summary>
        /// 2 �Ӱ���줸�C
        /// </summary>
        Two = 2,
    }

    /// <summary>
    /// �洤�Ҧ��]�w�C
    /// </summary>
    public enum Handshake
    {
        /// <summary>
        /// �L�洤�C
        /// </summary>
        None = 0,

        /// <summary>
        /// �n��洤�C
        /// </summary>
        XOn = 1,

        /// <summary>
        /// �w��洤 (RTS/CTS)�C
        /// </summary>
        Rts = 2,

        /// <summary>
        /// �w��洤 (DTR/DSR) (���`��)�C
        /// </summary>
        Dtr = 4,

        /// <summary>
        /// RTS �M�n��洤�C
        /// </summary>
        RtsXOn = Rts | XOn,

        /// <summary>
        /// DTR �M�n��洤 (���`��)�C
        /// </summary>
        DtrXOn = Dtr | XOn,

        /// <summary>
        /// �w��洤�A�]�t RTS/CTS �M DTR/DSR (���`��)�C
        /// </summary>
        DtrRts = Dtr | Rts,

        /// <summary>
        /// �w��洤�A�]�t RTS/CTS�BDTR/DSR �M�n��洤 (���`��)�C
        /// </summary>
        DtrRtsXOn = Dtr | Rts | XOn
    }

    /// <summary>
    /// ���ѪT�|�ഫ���������U���O�C
    /// </summary>
    internal static class SerialPortEnumConverter
    {
        /// <summary>
        /// �N Calin.SerialPort.Parity �ഫ�� RJCP.IO.Ports.Parity�C
        /// </summary>
        internal static RJCP.IO.Ports.Parity ToRJCP(this Parity parity)
        {
            switch (parity)
            {
                case Parity.None:
                    return RJCP.IO.Ports.Parity.None;
                case Parity.Odd:
                    return RJCP.IO.Ports.Parity.Odd;
                case Parity.Even:
                    return RJCP.IO.Ports.Parity.Even;
                case Parity.Mark:
                    return RJCP.IO.Ports.Parity.Mark;
                case Parity.Space:
                    return RJCP.IO.Ports.Parity.Space;
                default:
                    return RJCP.IO.Ports.Parity.None;
            }
            //return (RJCP.IO.Ports.Parity)(int)parity;
        }

        /// <summary>
        /// �N RJCP.IO.Ports.Parity �ഫ�� Calin.SerialPort.Parity�C
        /// </summary>
        internal static Parity FromRJCP(this RJCP.IO.Ports.Parity parity)
        {
            switch (parity)
            {
                case RJCP.IO.Ports.Parity.None:
                    return Parity.None;
                case RJCP.IO.Ports.Parity.Odd:
                    return Parity.Odd;
                case RJCP.IO.Ports.Parity.Even:
                    return Parity.Even;
                case RJCP.IO.Ports.Parity.Mark:
                    return Parity.Mark;
                case RJCP.IO.Ports.Parity.Space:
                    return Parity.Space;
                default:
                    return Parity.None;
            }
            //return (Parity)(int)parity;
        }

        /// <summary>
        /// �N Calin.SerialPort.StopBits �ഫ�� RJCP.IO.Ports.StopBits�C
        /// </summary>
        internal static RJCP.IO.Ports.StopBits ToRJCP(this StopBits stopBits)
        {
            switch (stopBits)
            {
                case StopBits.One:
                    return RJCP.IO.Ports.StopBits.One;
                case StopBits.OnePointFive:
                    return RJCP.IO.Ports.StopBits.One5;
                case StopBits.Two:
                    return RJCP.IO.Ports.StopBits.Two;
                default:
                    return RJCP.IO.Ports.StopBits.One;
            }
            //return (RJCP.IO.Ports.StopBits)(int)stopBits;
        }

        /// <summary>
        /// �N RJCP.IO.Ports.StopBits �ഫ�� Calin.SerialPort.StopBits�C
        /// </summary>
        internal static StopBits FromRJCP(this RJCP.IO.Ports.StopBits stopBits)
        {
            switch (stopBits)
            {
                case RJCP.IO.Ports.StopBits.One:
                    return StopBits.One;
                case RJCP.IO.Ports.StopBits.One5:
                    return StopBits.OnePointFive;
                case RJCP.IO.Ports.StopBits.Two:
                    return StopBits.Two;
                default:
                    return StopBits.One;
            }
            //return (StopBits)(int)stopBits;
        }

        /// <summary>
        /// �N Calin.SerialPort.Handshake �ഫ�� RJCP.IO.Ports.Handshake�C
        /// </summary>
        internal static RJCP.IO.Ports.Handshake ToRJCP(this Handshake handshake)
        {
            switch (handshake)
            {
                case Handshake.None:
                    return RJCP.IO.Ports.Handshake.None;
                case Handshake.XOn:
                    return RJCP.IO.Ports.Handshake.XOn;
                case Handshake.Rts:
                    return RJCP.IO.Ports.Handshake.Rts;
                case Handshake.Dtr:
                    return RJCP.IO.Ports.Handshake.Dtr;
                case Handshake.RtsXOn:
                    return RJCP.IO.Ports.Handshake.RtsXOn;
                case Handshake.DtrXOn:
                    return RJCP.IO.Ports.Handshake.DtrXOn;
                case Handshake.DtrRts:
                    return RJCP.IO.Ports.Handshake.DtrRts;
                case Handshake.DtrRtsXOn:
                    return RJCP.IO.Ports.Handshake.DtrRtsXOn;
                default:
                    return RJCP.IO.Ports.Handshake.None;
            }
            //return (RJCP.IO.Ports.Handshake)(int)handshake;
        }

        /// <summary>
        /// �N RJCP.IO.Ports.Handshake �ഫ�� Calin.SerialPort.Handshake�C
        /// </summary>
        internal static Handshake FromRJCP(this RJCP.IO.Ports.Handshake handshake)
        {
            switch (handshake)
            {
                case RJCP.IO.Ports.Handshake.None:
                    return Handshake.None;
                case RJCP.IO.Ports.Handshake.XOn:
                    return Handshake.XOn;
                case RJCP.IO.Ports.Handshake.Rts:
                    return Handshake.Rts;
                case RJCP.IO.Ports.Handshake.Dtr:
                    return Handshake.Dtr;
                case RJCP.IO.Ports.Handshake.RtsXOn:
                    return Handshake.RtsXOn;
                case RJCP.IO.Ports.Handshake.DtrXOn:
                    return Handshake.DtrXOn;
                case RJCP.IO.Ports.Handshake.DtrRts:
                    return Handshake.DtrRts;
                case RJCP.IO.Ports.Handshake.DtrRtsXOn:
                    return Handshake.DtrRtsXOn;
                default:
                    return Handshake.None;
            }
            //return (Handshake)(int)handshake;
        }
    }
}
