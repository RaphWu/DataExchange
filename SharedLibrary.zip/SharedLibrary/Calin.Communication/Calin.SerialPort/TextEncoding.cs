namespace Calin.SerialPort
{
    /// <summary>
    /// ��r�q�T�s�X�ﶵ�C
    /// </summary>
    public enum TextEncoding
    {
        Ascii = 0,
        Utf8 = 1
    }
}
