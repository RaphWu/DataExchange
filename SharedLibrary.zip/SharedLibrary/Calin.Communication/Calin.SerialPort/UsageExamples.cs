using System;

namespace Calin.SerialPort.Examples
{
    /// <summary>
    /// Calin.SerialPort �ϥνd�ҡC
    /// </summary>
    public static class UsageExamples
    {
        /// <summary>
        /// �d�� 1: �򥻪���@ SerialPort �ϥΡC
        /// </summary>
        public static void Example1_BasicUsage()
        {
            // �إ߳]�w
            var config = new SerialPortConfig
            {
                PortName = "COM1",
                BaudRate = 9600,
                DataBits = 8,
                Parity = Parity.None,
                StopBits = StopBits.One,
                EnableAutoReconnect = true,
                ReconnectInterval = 5000
            };

            // �إ� SerialPort �A��
            using (var service = new SerialPortService(config))
            {
                // �q�\�ƥ�
                service.StateChanged += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���A�ܧ�: {e.OldState} -> {e.NewState}");
                    if (!string.IsNullOrEmpty(e.ErrorMessage))
                    {
                        Console.WriteLine($"  ���~�T��: {e.ErrorMessage}");
                    }
                };

                service.DataReceived += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] �������: {e.Data}");
                    Console.WriteLine($"  �줸�ռ�: {e.RawData.Length}");
                    Console.WriteLine($"  �ɶ��W�O: {e.Timestamp:yyyy-MM-dd HH:mm:ss.fff}");
                };

                service.ErrorOccurred += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���~ ({e.ErrorType}): {e.ErrorMessage}");
                    if (e.Exception != null)
                    {
                        Console.WriteLine($"  �ҥ~�Ա�: {e.Exception}");
                    }
                };

                // �}�ҳs�u
                if (service.Open())
                {
                    Console.WriteLine("�s�u���\");

                    // �ǰe�r����
                    service.SendData("Hello SerialPort!\r\n");

                    // �ǰe�줸�ո��
                    byte[] data = { 0x01, 0x02, 0x03, 0x04 };
                    service.SendData(data);

                    Console.WriteLine("�����N�䵲��...");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("�s�u����");
                }
            }
        }

        /// <summary>
        /// �d�� 2: �ϥ� SerialPortManager �޲z�h�ӳ]�ơC
        /// </summary>
        public static void Example2_MultipleDevices()
        {
            using (var manager = new SerialPortManager())
            {
                // �q�\����ƥ�
                manager.StateChanged += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���A: {e.NewState}");
                };

                manager.DataReceived += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���: {e.Data}");
                };

                manager.ErrorOccurred += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���~: {e.ErrorMessage}");
                };

                // ���U���X�� (COM1)
                manager.RegisterPort(new SerialPortConfig
                {
                    PortName = "COM1",
                    BaudRate = 9600,
                    EnableAutoReconnect = true,
                    ReconnectInterval = 5000
                });

                // ���U�첾�p (COM2)
                manager.RegisterPort(new SerialPortConfig
                {
                    PortName = "COM2",
                    BaudRate = 115200,
                    EnableAutoReconnect = true,
                    ReconnectInterval = 3000,
                    EnableHeartbeat = true,
                    HeartbeatInterval = 30000,
                    HeartbeatMessage = "PING\r\n",
                    HeartbeatTimeout = 10000
                });

                // ���U��L�]�� (COM3, COM4, COM5)
                for (int i = 3; i <= 5; i++)
                {
                    manager.RegisterPort(new SerialPortConfig
                    {
                        PortName = $"COM{i}",
                        BaudRate = 9600,
                        EnableAutoReconnect = true
                    });
                }

                // �ǰe��ƨ�S�w Port
                manager.SendData("COM1", "SCAN\r\n");
                manager.SendData("COM2", "READ\r\n");

                // �s����ƨ�Ҧ� Port
                int successCount = manager.BroadcastData("STATUS\r\n");
                Console.WriteLine($"�s�����\�ǰe�� {successCount} �ӳ]��");

                // �d�ߩҦ� Port �����A
                var states = manager.GetAllPortStates();
                Console.WriteLine("\n�Ҧ��]�ƪ��A:");
                foreach (var kvp in states)
                {
                    Console.WriteLine($"  {kvp.Key}: {kvp.Value}");
                }

                Console.WriteLine("\n�����N�䵲��...");
                Console.ReadKey();
            }
        }

        /// <summary>
        /// �d�� 3: �ϥΤ߸��˴��C
        /// </summary>
        public static void Example3_HeartbeatMonitoring()
        {
            var config = new SerialPortConfig
            {
                PortName = "COM1",
                BaudRate = 9600,
                EnableAutoReconnect = true,
                EnableHeartbeat = true,
                HeartbeatInterval = 30000,      // 30 ���o�e�@��
                HeartbeatMessage = "PING\r\n",  // �߸��T��
                HeartbeatTimeout = 10000        // 10 �����S����^���������`
            };

            using (var service = new SerialPortService(config))
            {
                service.StateChanged += (sender, e) =>
                {
                    if (e.NewState == SerialPortState.Fault)
                    {
                        Console.WriteLine("������s�u���`�A�N�۰ʭ��s...");
                    }
                    else if (e.NewState == SerialPortState.Ready)
                    {
                        Console.WriteLine("�s�u�w�N��");
                    }
                };

                service.DataReceived += (sender, e) =>
                {
                    // �p�G���� PONG �^���A���ܤ߸����`
                    if (e.Data.Contains("PONG"))
                    {
                        Console.WriteLine("�߸����`");
                    }
                };

                service.Open();

                Console.WriteLine("�߸��ʱ��w�ҰʡA�����N�䵲��...");
                Console.ReadKey();
            }
        }

        /// <summary>
        /// �d�� 4: �B�z�S�w�]�ƪ��q�T��w�]�H���X�����ҡ^�C
        /// </summary>
        public static void Example4_BarcodeScanner()
        {
            var config = new SerialPortConfig
            {
                PortName = "COM3",
                BaudRate = 9600,
                DataBits = 8,
                Parity = Parity.None,
                StopBits = StopBits.One,
                EnableAutoReconnect = true
            };

            using (var service = new SerialPortService(config))
            {
                string receivedData = string.Empty;

                service.DataReceived += (sender, e) =>
                {
                    // �ֿn�����쪺���
                    receivedData += e.Data;

                    // �ˬd�O�_���짹�㪺���X�]�H����Ÿ������^
                    if (receivedData.Contains("\r") || receivedData.Contains("\n"))
                    {
                        var barcode = receivedData.Trim();
                        Console.WriteLine($"���y����X: {barcode}");

                        // ���ұ��X�榡
                        if (ValidateBarcode(barcode))
                        {
                            ProcessBarcode(barcode);
                        }
                        else
                        {
                            Console.WriteLine($"�L�Ī����X�榡: {barcode}");
                        }

                        receivedData = string.Empty;
                    }
                };

                service.ErrorOccurred += (sender, e) =>
                {
                    Console.WriteLine($"���X�����~: {e.ErrorMessage}");
                };

                if (service.Open())
                {
                    Console.WriteLine("���X���w�N��");
                    Console.WriteLine("�б��y���X...");
                    Console.ReadKey();
                }
            }
        }

        /// <summary>
        /// �d�� 5: �B�z�첾�p��ơC
        /// </summary>
        public static void Example5_DisplacementSensor()
        {
            var config = new SerialPortConfig
            {
                PortName = "COM2",
                BaudRate = 115200,
                EnableAutoReconnect = true,
                EnableHeartbeat = false  // �첾�p�q�`����o�e��ơA���ݭn�߸�
            };

            using (var service = new SerialPortService(config))
            {
                service.DataReceived += (sender, e) =>
                {
                    // �ѪR�첾�p��ơ]���]�榡��: "D:1234.56\r\n"�^
                    if (e.Data.StartsWith("D:"))
                    {
                        var valueStr = e.Data.Substring(2).Trim();
                        if (double.TryParse(valueStr, out double displacement))
                        {
                            Console.WriteLine($"�첾�q: {displacement:F2} mm");

                            // �ˬd�O�_�W�X�e�\�d��
                            if (displacement > 100 || displacement < -100)
                            {
                                Console.WriteLine("ĵ�i: �첾�q�W�X�d��I");
                            }
                        }
                    }
                };

                if (service.Open())
                {
                    Console.WriteLine("�첾�p�w�N��");

                    // �o�e�Ұʴ��q�R�O
                    service.SendData("START\r\n");

                    Console.WriteLine("�����N�䰱��...");
                    Console.ReadKey();

                    // �o�e������q�R�O
                    service.SendData("STOP\r\n");
                }
            }
        }

        /// <summary>
        /// �d�� 6: �d�ߥi�Ϊ� SerialPort�C
        /// </summary>
        public static void Example6_ListAvailablePorts()
        {
            Console.WriteLine("�t�Τ��i�Ϊ� SerialPort:");

            var ports = SerialPortService.GetAvailablePorts();

            if (ports.Count == 0)
            {
                Console.WriteLine("  �S���i�Ϊ� SerialPort");
            }
            else
            {
                foreach (var port in ports)
                {
                    Console.WriteLine($"  - {port}");
                }
            }
        }

        #region Helper Methods

        private static bool ValidateBarcode(string barcode)
        {
            // ²�檺���X���ҡ]������ھڨ���ݨD��@�^
            return !string.IsNullOrWhiteSpace(barcode) && barcode.Length >= 8;
        }

        private static void ProcessBarcode(string barcode)
        {
            // �B�z���X�޿�]������ھڨ���ݨD��@�^
            Console.WriteLine($"�B�z���X: {barcode}");
        }

        #endregion
    }
}
