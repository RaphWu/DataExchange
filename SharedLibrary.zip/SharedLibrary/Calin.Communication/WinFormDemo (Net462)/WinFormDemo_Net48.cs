﻿using System.Diagnostics;
using System.Windows.Forms;
using Calin.Comm.DL_RS1A;
using Calin.Extensions;
using Calin.SerialPort;
using Krypton.Toolkit;

namespace WinFormDemo_Net48
{
    public partial class WinFormDemo_Net48 : KryptonForm
    {
        private readonly IDL_RS1A_ServiceFactory _rS1A_ServiceFactory;

        private readonly Stopwatch _stopwatch = new Stopwatch();
        private IDL_RS1A _dlrs1a;
        private int _errCounter;

        public WinFormDemo_Net48(IDL_RS1A_ServiceFactory rS1A_ServiceFactory)
        {
            _rS1A_ServiceFactory = rS1A_ServiceFactory;
            InitializeComponent();
        }

        private void WinFormDemo_Net48_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        private void ResponseReceived(object sender, DL_RS1A_ResponseEventArgs e)
        {
            if (e.Response.IsSuccess)
            {
                var values = e.Response.Values[0];
                ThreadExt.RunOnUiThread(() => { label2.Text = values.ToString("F3"); });
            }
            else
            {
                _errCounter++;
                ThreadExt.RunOnUiThread(() => { label3.Text = $"Error: {e.Response.ErrorCode} ({_errCounter})"; });
            }

            _stopwatch.Stop();
            ThreadExt.RunOnUiThread(() => label4.Text = $"Elapsed: {_stopwatch.ElapsedMilliseconds:F3} ms");
        }

        private void button1_Click_1(object sender, System.EventArgs args)
        {
            var config = new DL_RS1A_Config
            {
                SensorType = KeyenceSensorType.GT2,
                IdNumber = 0,
                PortName = "COM5",
                BaudRate = 19200,
                DataBits = 8,
                Parity = Parity.None,
                StopBits = StopBits.One,
            };

            if (_dlrs1a != null && _dlrs1a.IsConnected)
            {
                _dlrs1a.ResponseReceived -= ResponseReceived;
                _dlrs1a.Close();
                _dlrs1a.Dispose();
            }

            _errCounter = 0;

            _dlrs1a = _rS1A_ServiceFactory.CreateAndOpen(config);
            if (_dlrs1a != null && _dlrs1a.IsTransmissionVerified)
            {
                _dlrs1a.ResponseReceived += ResponseReceived;

                System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
                timer.Interval = 20;
                timer.Tick += (s, e) =>
                {
                    _stopwatch.Restart();

                    //_dlrs1a.ReadRaw(0);
                    _dlrs1a.ReadValue();

                    label1.Text = $"_dlrs1a.IsConnected = {_dlrs1a.IsConnected}\n_dlrs1a.IsTransmissionVerified = {_dlrs1a.IsTransmissionVerified}";
                };
                timer.Start();
            }
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            _dlrs1a.ResponseReceived -= ResponseReceived;
            _dlrs1a.Close();
            _dlrs1a.Dispose();

            label1.Text = $"_dlrs1a.IsConnected = {_dlrs1a.IsConnected}\n_dlrs1a.IsTransmissionVerified = {_dlrs1a.IsTransmissionVerified}";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            //_stopwatch.Restart();
            //_dlrs1a.SendCommand(textBox1.Text);
        }
    }
}
