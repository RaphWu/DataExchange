﻿namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 錯誤訊息結構。
    /// </summary>
    public class ErrMessage
    {
        internal ErrMessage()
        {
            ErrorCode = 0;
            Message = "";
            Description = "";
        }

        internal ErrMessage(uint errCode, string message)
        {
            ErrorCode = errCode;
            Message = message;
            Description = "";
        }

        internal ErrMessage(uint errCode, string message, string description)
        {
            ErrorCode = errCode;
            Message = message;
            Description = description;
        }

        /// <summary>
        /// 錯誤代碼。
        /// </summary>
        public uint ErrorCode { get; set; }

        /// <summary>
        /// 錯誤訊息。
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 說明。
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// 呼叫者名稱。
        /// </summary>
        public string CallerName { get; set; }
    }
}
