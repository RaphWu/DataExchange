﻿using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;

namespace Calin.MotionControl.Advantech.Services
{
    public partial class AcmService : IAcmService_Manual
    {
        #region properties





        #endregion properties

        #region methods

        /// <inheritdoc/>
        public bool SetExtDrive(int axisNo, ushort extDriveMode)
        {
            ErrCode = Motion.mAcm_AxSetExtDrive(m_AxisHandles[axisNo], extDriveMode);
            return !CheckErr($"{nameof(IAcmService_Manual)}.{nameof(SetExtDrive)}", $"軸 {axisNo + 1} 外部驅動模式設定失敗！");
        }

        #endregion methods
    }
}
