﻿using AcmDemo.Constants;
using AcmDemo.Models;
using AcmDemo.Services;
using Calin.MotionControl.Advantech.Contracts;
using Calin.Navigation;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class ManualPage : UserControl, INavigationAware
    {
        #region Fields

        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        private readonly AcmParams _acmParams;

        #endregion Fields

        #region Properties



        #endregion Properties

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            _acm.SetExtDrive(_acmParams.AxisNo, RbJog.Checked
                ? (ushort)ExtDriveMode.Jog
                : (ushort)ExtDriveMode.MPG);
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            _acm.SetExtDrive(_acmParams.AxisNo, (ushort)ExtDriveMode.Disable);
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            return true;
        }

        #endregion INavigationAware

        #region Constructor

        public ManualPage(IDemoService demoService, IAcm acm, AcmParams acmParams)
        {
            _demoService = demoService;
            _acm = acm;
            _acmParams = acmParams;

            InitializeComponent();
        }

        #endregion Constructor

        #region Manual 

        private void BtnStop_Click(object sender, EventArgs e)
        {
            _acm.AxisStop(_acmParams.AxisNo);
        }

        private void BtnMove_Click(object sender, EventArgs e)
        {
            if (_acm.IsBoardInit)
            {
                if (_acmParams.AxisConfigs[_acmParams.AxisNo].AbsOrRel == AxisMovementMode.Absolute)
                {
                    if (!_acm.MoveAbsolute(_acmParams.AxisNo, Convert.ToDouble(NumPosAbs.Text)))
                        _demoService.ShowErrMsg("PTP 絕對位置運動錯誤！");
                }
                else
                {
                    if (!_acm.MoveRelative(_acmParams.AxisNo, Convert.ToDouble(NumPosRel.Text)))
                        _demoService.ShowErrMsg("PTP 相對位置運動錯誤！");
                }
            }
        }

        #endregion Manual

        #region Ext

        private void checkBoxEnExtSel_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxEnExtSel.Checked)
            {
                _acm.SetExtDrive(_acmParams.AxisNo, RbJog.Checked
                    ? (ushort)ExtDriveMode.Jog
                    : (ushort)ExtDriveMode.MPG);
            }
            else
            {
                _acm.SetExtDrive(_acmParams.AxisNo, (ushort)ExtDriveMode.Disable);
            }
        }

        #endregion Ext
    }
}
