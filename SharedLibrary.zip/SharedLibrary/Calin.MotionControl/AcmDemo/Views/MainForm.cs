using System.Diagnostics;
using AcmDemo.Constants;
using AcmDemo.Exts;
using AcmDemo.Models;
using AcmDemo.Services;
using AcmDemo.Views;
using Autofac;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.MotionControl.Advantech.Services;
using Calin.Navigation;

namespace AcmDemo
{
    public partial class MainForm : Form
    {
        #region Fields

        private readonly ILifetimeScope _rootScope;
        private readonly INavigation _nav;
        private readonly IDemoService _demoService;
        private readonly IAcm _acm;
        private readonly AcmParams _acmParams;

        private ToolPanel? _toolPanel = null;
        private readonly string _btnToolPanelOpenCaption = "�}�ұ���O";
        private readonly string _btnToolPanelCloseCaption = "��������O";

        #endregion Fields

        public MainForm(
            ILifetimeScope lifetimeScope,
            INavigation regionNavigation,
            IDemoService demoService,
            IAcm acm,
            AcmParams acmParams)
        {
            _rootScope = lifetimeScope;
            _nav = regionNavigation;
            _demoService = demoService;
            _acm = acm;
            _acmParams = acmParams;

            InitializeComponent();

            CommonStyle.SetMenuRadioButton(MenuManual);
            CommonStyle.SetMenuRadioButton(MenuAxisTest);
            CommonStyle.SetMenuRadioButton(MenuHome);
            CommonStyle.SetMenuRadioButton(MenuIO);

            FlpLeftMenu.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);

            // ���o���Ī���عB�ʱ���d�˸m�ƶq�βM��
            if (_acm.GetAvailableDevs() != 0)
            {
                _acmParams.DeviceEnable = true;
                MenuHome.Checked = true;
            }
            else
            {
                _acmParams.DeviceEnable = false;
                _demoService.ShowErrMsg("�䤣�즳�Ī���عB�ʱ���d�˸m�I");
            }
        }

        private void AcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs e)
        {
            if (_acm.AxisCount > 0)
            {
                var io = _acm.AxisStates[e.AxisNo];
                var axisStatus = _acmParams.AxisStatuses[e.AxisNo];

                axisStatus.ALM = io.IoFlags.HasFlag(IoFlags.ALRM);
                axisStatus.EZ = io.IoFlags.HasFlag(IoFlags.EZ);
                axisStatus.ORG = io.IoFlags.HasFlag(IoFlags.ORG);
                axisStatus.LMT_Positive = io.IoFlags.HasFlag(IoFlags.LMT_Positive);
                axisStatus.LMT_Negative = io.IoFlags.HasFlag(IoFlags.LMT_Negative);
            }
        }

        #region Form Events

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            _acm.AcmStatusUpdated -= AcmStatusUpdated;

            if (_toolPanel != null && !_toolPanel.IsDisposed)
                _toolPanel.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            _nav.RegisterRegion(nameof(ContentPanel), view =>
            {
                ContentPanel.SuspendLayout();
                ContentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    ContentPanel.Controls.Add(control);
                }
                ContentPanel.ResumeLayout();
            });

            if (_acm.IsBoardInit && _acm.AxisCount > 0)
            {
                for (uint i = 0; i < _acm.AxisCount; i++)
                    _acmParams.AxisStatuses.Add(new AxisStatus());

                _acm.AcmStatusUpdated += AcmStatusUpdated;
            }
        }

        #endregion Form Events

        #region Navigation

        private void SwitchPage(PageCode pageCode)
        {
            string regionName = nameof(ContentPanel);
            switch (pageCode)
            {
                case PageCode.Home:
                    _nav.NavigateTo<HomePage>(regionName);
                    break;
                case PageCode.AxisTest:
                    _nav.NavigateTo<ManualPage>(regionName);
                    break;
                case PageCode.IoMonitor:
                    _nav.NavigateTo<IoMonitor>(regionName);
                    break;
                default:
                    throw new NotImplementedException($"�|����@�����N�X {pageCode} �������޿�C");
            }
        }

        #endregion Navigation

        #region Menu Control Events

        private void MenuManual_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.AxisTest);
        }

        private void MenuHome_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Home);
        }

        private void MenuAxisTest_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.AxisTest);
        }

        private void MenuIO_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.IoMonitor);
        }

        #endregion Menu Control Events

        #region Control Events


        #endregion Control Events

        #region �D����O

        private void BtnToolPanel_Click(object sender, EventArgs e)
        {
            if (_toolPanel == null)
            {
                _toolPanel = _rootScope.Resolve<ToolPanel>();
                _toolPanel.Owner = this;

                int left = this.Left - _toolPanel.Width;
                _toolPanel.Show();
                _toolPanel.Top = this.Top;
                _toolPanel.Left = left;

                _toolPanel.ToolPanelHidden += ToolPanel_ToolPanelHidden;
                BtnToolPanel.Text = _btnToolPanelCloseCaption;
                return;
            }

            if (_toolPanel.Visible)
            {
                _toolPanel.Hide();
                BtnToolPanel.Text = _btnToolPanelOpenCaption;
            }
            else
            {
                _toolPanel.Show();
                BtnToolPanel.Text = _btnToolPanelCloseCaption;
            }
        }

        private void ToolPanel_ToolPanelHidden(object sender, EventArgs e)
        {
            BtnToolPanel.Text = _btnToolPanelOpenCaption;
        }

        #endregion �D����O

    }
}
