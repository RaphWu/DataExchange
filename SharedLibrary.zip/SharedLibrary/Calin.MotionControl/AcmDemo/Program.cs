using AcmDemo.Models;
using AcmDemo.Services;
using AcmDemo.Views;
using Autofac;
using Calin.MotionControl.Advantech;
using Calin.Navigation;

namespace AcmDemo
{
    internal static class Program
    {
        /// <summary>
        /// ���ε{�����D�n�i�J�I�C
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var builder = new ContainerBuilder();

            builder.RegisterModule<AdvantechModule>();
            builder.RegisterModule<NavigationModule>();
            //builder.RegisterModule<WinFormModule>();

            // Datas
            builder.RegisterType<AcmParams>().AsSelf().SingleInstance();

            // services
            builder.RegisterType<DemoService>().As<IDemoService>().SingleInstance();

            // views
            builder.RegisterType<ToolPanel>().AsSelf().InstancePerLifetimeScope();
            builder.RegisterType<MainForm>().AsSelf().InstancePerLifetimeScope();
            builder.RegisterType<ManualPage>().AsSelf().InstancePerLifetimeScope();
            builder.RegisterType<HomePage>().AsSelf().InstancePerLifetimeScope();

            var container = builder.Build();

            Application.Run(container.Resolve<MainForm>());
        }
    }
}