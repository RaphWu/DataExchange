﻿using System.Text;
using Newtonsoft.Json;

namespace Calin.Helpers
{
    /// <summary>
    /// JSON 格式檔案的儲存與讀取。
    /// </summary>
    public static class JsonFileHelper
    {
        /// <summary>
        /// 讀取 JSON 格式檔案。
        /// </summary>
        /// <typeparam name="T">資料類型。</typeparam>
        /// <param name="fullFilePath">完整檔案路徑。</param>
        /// <returns>T 類型的資料。</returns>
        public static T? Read<T>(string fullFilePath)
        {
            if (File.Exists(fullFilePath))
            {
                var json = File.ReadAllText(fullFilePath);
                return JsonConvert.DeserializeObject<T>(json, new JsonSerializerSettings
                {
                    DefaultValueHandling = DefaultValueHandling.Populate
                });
            }

            return default;
        }

        /// <summary>
        /// 儲存 JSON 格式檔案。
        /// </summary>
        /// <typeparam name="T">資料類型。</typeparam>
        /// <param name="fullFilePath">完整檔案路徑。</param>
        /// <param name="content">要儲存的資料。</param>
        /// <param name="formatting">格式選項。指定是否以縮排格式化 JSON。預設為 <see cref="Formatting.Indented"/>。</param>
        public static void Save<T>(string fullFilePath, T content, Formatting formatting = Formatting.Indented)
        {
            var directory = Path.GetDirectoryName(fullFilePath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                Directory.CreateDirectory(directory);

            string fileContent = JsonConvert.SerializeObject(content, formatting);
            File.WriteAllText(fullFilePath, fileContent, Encoding.UTF8);
        }

        ///// <summary>
        ///// 讀取JSON格式檔案。
        ///// </summary>
        ///// <typeparam name="T">資料類型。</typeparam>
        ///// <param name="folderPath">目錄位置。</param>
        ///// <param name="fileName">檔案名稱。</param>
        ///// <returns>T類型的資料。</returns>
        //public static T Read<T>(string folderPath, string fileName)
        //{
        //    var path = Path.Combine(folderPath, fileName);
        //    if (File.Exists(path))
        //    {
        //        var json = File.ReadAllText(path);
        //        return JsonConvert.DeserializeObject<T>(json, new JsonSerializerSettings
        //        {
        //            DefaultValueHandling = DefaultValueHandling.Populate
        //        });
        //    }

        //    return default;
        //}

        ///// <summary>
        ///// 儲存 JSON 格式檔案。
        ///// </summary>
        ///// <typeparam name="T">資料類型。</typeparam>
        ///// <param name="folderPath">目錄位置。</param>
        ///// <param name="fileName">檔案名稱。</param>
        ///// <param name="content">要儲存的資料。</param>
        ///// <param name="formatting">格式選項。指定是否以縮排格式化 JSON。預設為 <see cref="Newtonsoft.Json.Formatting.None"/>。參見 <see href="https://www.newtonsoft.com/json/help/html/t_newtonsoft_json_formatting.htm">Json.NET - Formatting Enumeration</see>。</param>
        //public static void Save<T>(string folderPath, string fileName, T content, Formatting formatting = Formatting.None)
        //{
        //    if (!Directory.Exists(folderPath))
        //        Directory.CreateDirectory(folderPath);

        //    string fileContent = JsonConvert.SerializeObject(content, formatting);
        //    File.WriteAllText(Path.Combine(folderPath, fileName), fileContent, Encoding.UTF8);
        //}
    }
}
