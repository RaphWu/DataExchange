﻿using Calin.Logging.Abstractions;
using Microsoft.Extensions.Logging;

namespace Calin.Extensions
{
    /// <summary>
    /// 提供與執行緒相關的擴充方法。
    /// </summary>
    public static class ThreadExt
    {
        // 使用 LoggingBridge 取得 Logger（若未初始化則為 NullLogger，不會拋出例外）
        private static readonly ILogger _logger = LoggingBridge.CreateLogger(typeof(ThreadExt));

        /// <summary>
        /// 如果控制項需要跨執行緒呼叫，則在 UI 執行緒上執行指定的動作。
        /// </summary>
        /// <param name="control">要檢查的 <see cref="Control"/>。</param>
        /// <param name="action">要執行的 <see cref="MethodInvoker"/> 委派。</param>
        public static void InvokeIfRequired(this Control control, MethodInvoker action)
        {
            if (control == null) throw new ArgumentNullException(nameof(control));
            if (action == null) throw new ArgumentNullException(nameof(action));

            try
            {
                if (control.InvokeRequired)
                    control.Invoke(action);
                else
                    action();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "執行跨執行緒操作時發生錯誤。");
                throw new InvalidOperationException("執行跨執行緒操作時發生錯誤。", ex);
            }
        }

        /// <summary>
        /// 在 UI 執行緒上執行指定的動作。
        /// </summary>
        /// <param name="action">要執行的 <see cref="Action"/> 委派。</param>
        /// <remarks>
        /// 如果目前應用程式沒有任何開啟的窗體（例如在測試模式下），
        /// 則直接執行指定的動作。
        /// 否則，會檢查第一個開啟的窗體是否需要跨執行緒呼叫，
        /// 若需要則使用 <see cref="Control.BeginInvoke(Delegate)"/> 執行動作，
        /// 否則直接執行。
        /// </remarks>
        public static void RunOnUiThread(Action action)
        {
            if (action == null) throw new ArgumentNullException(nameof(action));

            try
            {
                if (Application.OpenForms.Count == 0)
                {
                    action(); // 若沒有開啟的窗體（例如測試模式），直接執行
                    return;
                }

                // 使用第一個開啟的窗體作為參考
                var form = Application.OpenForms[0];
                if (form is null)
                {
                    action();
                    return;
                }
                if (form.InvokeRequired)
                    form.BeginInvoke(action);
                else
                    action();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "執行 UI 執行緒操作時發生錯誤。");
                throw new InvalidOperationException("執行 UI 執行緒操作時發生錯誤。", ex);
            }
        }
    }
}
