using Calin.Abstractions.Logging;
using Serilog;

namespace Calin.Logging
{
    /// <summary>
    /// ICalinLogger �� Serilog ��@�C
    /// </summary>
    /// <remarks>
    /// <para>�����O�N ICalinLogger ���I�s�e���� Serilog.ILogger�C</para>
    /// <para>�O�d�{���������B���ѡB��X�榡���\��C</para>
    /// </remarks>
    public sealed class CalinLogger : ICalinLogger
    {
        private readonly ILogger _logger;

        /// <summary>
        /// �ϥΫ��w�� Serilog Logger ��l�� CalinLogger�C
        /// </summary>
        /// <param name="logger">Serilog Logger ��ҡC</param>
        public CalinLogger(ILogger logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// �ϥΥ��� Serilog Logger ��l�� CalinLogger�C
        /// </summary>
        public CalinLogger() : this(Log.Logger)
        {
        }

        /// <inheritdoc/>
        public void Debug(string message)
        {
            _logger.Debug(message);
        }

        /// <inheritdoc/>
        public void Information(string message)
        {
            _logger.Information(message);
        }

        /// <inheritdoc/>
        public void Warning(string message)
        {
            _logger.Warning(message);
        }

        /// <inheritdoc/>
        public void Error(string message, Exception? ex = null)
        {
            if (ex != null)
            {
                _logger.Error(ex, message);
            }
            else
            {
                _logger.Error(message);
            }
        }
    }
}
