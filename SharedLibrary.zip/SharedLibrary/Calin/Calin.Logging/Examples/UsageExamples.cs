// ===================================================================
// Calin.Logging.Samples
// 
// UsageExamples - �ϥνd�ҡ]�ȨѤ��ѦҡA�����sĶ����^
//
// ���ɮ׮i�� App �M Device NuGet �p��ϥ� Logging �[�c�C
// ===================================================================

#if USAGE_EXAMPLES // ���϶��ȨѤ��ѦҡA���|�sĶ

using Autofac;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using Calin.Logging.Abstractions;
using Calin.Logging.Integration;
using Calin.Logging.Serilog;
using Calin.Logging.Serilog.Enrichers;
using Calin.Logging.Serilog.Formatters;
using Calin.Logging.Samples;

namespace Calin.Logging.Examples;

// =====================================================================
// �iAPP �ݵ{���X - �u��s�b�� App�j
// =====================================================================

/// <summary>
/// APP ��l�ƽd�� - �覡�@�G�ϥ� Builder�C
/// </summary>
public class AppStartup_UsingBuilder
{
    public void Initialize()
    {
        // 1. �ϥ� Builder �إ� LoggerFactory
        var loggerFactory = new SerilogLoggerFactoryBuilder()
            .SetMinimumLevel(LogEventLevel.Debug)
            .AddConsole()
            .AddDebug()
            .AddFile("logs/app-.log")
            .AddJsonFile("logs/app-.json")
            .EnableAllEnrichers("MyApp")
            .Build();

        // 2. ��l�� LoggingBridge�]�ѫD DI ���ҨϥΡ^
        LoggingBridge.Initialize(loggerFactory);

        // 3. �]�w Autofac
        var builder = new ContainerBuilder();
        builder.RegisterLogging(loggerFactory);

        // 4. ���U�]�Ƭ����A��
        builder.RegisterType<SampleDeviceController>().AsSelf();
        builder.RegisterType<SampleDeviceFactory>().AsSelf();

        var container = builder.Build();

        // 5. �g�X Startup Log
        var logger = loggerFactory.CreateLogger<AppStartup_UsingBuilder>();
        logger.LogInformation("���ε{���Ұʧ���");
    }
}

/// <summary>
/// APP ��l�ƽd�� - �覡�G�G�����ϥ� Serilog�C
/// </summary>
public class AppStartup_UsingSerilogDirectly
{
    public void Initialize()
    {
        // 1. �����إ� Serilog Logger
        var serilogLogger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
            .Enrich.FromLogContext()
            .Enrich.WithThreadId()
            .Enrich.WithMachineName()
            .Enrich.WithProcessId()
            .Enrich.WithApplicationName("MyApp") // �ϥΦۭq Enricher
            .WriteTo.Console(outputTemplate: OutputTemplates.Standard)
            .WriteTo.File(
                path: "logs/app-.log",
                rollingInterval: RollingInterval.Day,
                outputTemplate: OutputTemplates.Detailed)
            .CreateLogger();

        // 2. �]�w���� Logger
        Log.Logger = serilogLogger;

        // 3. �إ� Microsoft.Extensions.Logging.ILoggerFactory
        var loggerFactory = LoggerFactory.Create(builder =>
        {
            builder.ClearProviders();
            builder.AddSerilog(serilogLogger, dispose: true);
        });

        // 4. ��l�� LoggingBridge
        LoggingBridge.Initialize(loggerFactory);

        // 5. �]�w Autofac
        var containerBuilder = new ContainerBuilder();
        containerBuilder.RegisterLogging(loggerFactory);

        var container = containerBuilder.Build();

        // 6. �g�X Startup Log
        var logger = loggerFactory.CreateLogger<AppStartup_UsingSerilogDirectly>();
        logger.LogInformation("���ε{���Ұʧ���");
    }
}

// =====================================================================
// �iDevice NuGet �ݵ{���X - �i�s�b��]�� NuGet�j
// =====================================================================

/// <summary>
/// �]�Ʊ�� - DI �ϥνd�ҡC
/// </summary>
public class DeviceController_WithDI
{
    private readonly ILogger<DeviceController_WithDI> _logger;

    // DI �`�J Logger
    public DeviceController_WithDI(ILogger<DeviceController_WithDI> logger)
    {
        _logger = logger;
    }

    public void DoSomething()
    {
        // �ϥ� Scope �ǻ��]�Ƹ�T
        using (LoggingScope.BeginDeviceScope(_logger, "Device001", "COM3"))
        {
            _logger.LogInformation("����ާ@");

            try
            {
                // �ާ@...
                _logger.LogDebug("�ާ@�Ӹ`...");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "�ާ@����");
                throw;
            }
        }
    }
}

/// <summary>
/// �]�Ʊ�� - �D DI �ϥνd�ҡC
/// </summary>
public class DeviceController_WithoutDI
{
    private readonly ILogger<DeviceController_WithoutDI> _logger;

    // �D DI�G�z�L LoggingBridge ���o Logger
    public DeviceController_WithoutDI()
    {
        // �Y LoggingBridge ����l�ơA�|�۰ʨϥ� NullLogger
        _logger = LoggingBridge.CreateLogger<DeviceController_WithoutDI>();
    }

    public void DoSomething()
    {
        // �ϥΤ覡�P DI ���ҧ����ۦP
        using (LoggingScope.BeginDeviceScope(_logger, "Device002", "COM4"))
        {
            _logger.LogInformation("����ާ@");
        }
    }
}

/// <summary>
/// �]�Ʊ�� - �P�ɤ䴩 DI �P�D DI�C
/// </summary>
public class DeviceController_Hybrid
{
    private readonly ILogger<DeviceController_Hybrid> _logger;

    // DI ���ҨϥΦ��غc�l
    public DeviceController_Hybrid(ILogger<DeviceController_Hybrid> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    // �D DI ���ҨϥΦ��غc�l
    public DeviceController_Hybrid()
        : this(LoggingBridge.CreateLogger<DeviceController_Hybrid>())
    {
    }

    public void DoSomething()
    {
        _logger.LogInformation("����ާ@");
    }
}

#endif
