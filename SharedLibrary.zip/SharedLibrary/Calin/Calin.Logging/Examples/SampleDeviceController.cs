// ===================================================================
// Calin.Logging.Samples
// 
// SampleDeviceController - �]�Ʊ���d��
//
// �o�O�@�ӥܽd���O�A�i�ܳ]�Ʊ�� NuGet �p�󥿽T�ϥ� Logging�C
// �u��]�� NuGet �N�H�]�ƫ����R�W�]�p Device.XYZ-1000�^�C
//
// �֤ߥܽd�G
//   1. �p��b DI ���ҤU���o Logger
//   2. �p��b�D DI ���ҤU���o Logger
//   3. �p��ϥ� Scope �ǻ��]�Ƹ�T
//   4. �p��O���]�ƾާ@ Log
// ===================================================================

using System.Diagnostics;
using Calin.Logging.Abstractions;
using Microsoft.Extensions.Logging;

namespace Calin.Logging.Examples;

/// <summary>
/// �]�Ʊ���d�ҡC
/// </summary>
/// <remarks>
/// <para>
/// <b>�����O�ȧ@���ܽd�A����@����u��]�Ƴq�T�C</b>
/// </para>
/// <para>
/// �u��]�� NuGet ���ѦҦ��d�Ҩӹ�@ Logging�C
/// </para>
/// </remarks>
public sealed class SampleDeviceController : IDisposable
{
    private readonly ILogger<SampleDeviceController> _logger;
    private readonly string _deviceId;
    private readonly string _portName;
    private bool _isConnected;
    private bool _disposed;

    #region �غc�l

    /// <summary>
    /// �ϥ� DI �`�J Logger�C
    /// </summary>
    /// <param name="logger">Logger ��ҡC</param>
    /// <param name="deviceId">�]�� ID�C</param>
    /// <param name="portName">�s����W�١C</param>
    /// <remarks>
    /// <b>DI ���ҨϥΦ��غc�l�C</b>
    /// </remarks>
    public SampleDeviceController(
        ILogger<SampleDeviceController> logger,
        string deviceId,
        string portName)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _deviceId = deviceId ?? throw new ArgumentNullException(nameof(deviceId));
        _portName = portName ?? throw new ArgumentNullException(nameof(portName));

        _logger.LogDebug("SampleDeviceController �w�إ� | DeviceId: {DeviceId}, PortName: {PortName}", _deviceId, _portName);
    }

    /// <summary>
    /// �D DI ���ҨϥΡ]���� new�^�C
    /// </summary>
    /// <param name="deviceId">�]�� ID�C</param>
    /// <param name="portName">�s����W�١C</param>
    /// <remarks>
    /// <para>
    /// <b>�D DI ���ҨϥΦ��غc�l�C</b>
    /// </para>
    /// <para>
    /// �Y LoggingBridge �|����l�ơA�N�ϥ� NullLogger�]����ҥ~�B���v�T�y�{�^�C
    /// </para>
    /// </remarks>
    public SampleDeviceController(string deviceId, string portName)
        : this(LoggingBridge.CreateLogger<SampleDeviceController>(), deviceId, portName)
    {
    }

    #endregion

    #region ���}�ݩ�

    /// <summary>
    /// ���o�]�� ID�C
    /// </summary>
    public string DeviceId => _deviceId;

    /// <summary>
    /// ���o�s����W�١C
    /// </summary>
    public string PortName => _portName;

    /// <summary>
    /// ���o�O�_�w�s�u�C
    /// </summary>
    public bool IsConnected => _isConnected;

    #endregion

    #region ���}��k

    /// <summary>
    /// �s�u��]�ơC
    /// </summary>
    /// <returns>�O�_�s�u���\�C</returns>
    public bool Connect()
    {
        ThrowIfDisposed();

        // �ϥ� Scope �ǻ��]�Ƹ�T
        using (LoggingScope.BeginDeviceScope(_logger, _deviceId, _portName))
        {
            _logger.LogDeviceOperationStart("Connect", _deviceId);

            var sw = Stopwatch.StartNew();

            try
            {
                // �����s�u�ާ@
                SimulateOperation(500);

                _isConnected = true;
                sw.Stop();

                _logger.LogDeviceConnectionChanged(_deviceId, true, _portName);
                _logger.LogDeviceOperationComplete("Connect", _deviceId, sw.ElapsedMilliseconds);

                return true;
            }
            catch (Exception ex)
            {
                sw.Stop();
                _logger.LogDeviceOperationFailed("Connect", _deviceId, ex);
                return false;
            }
        }
    }

    /// <summary>
    /// �_�}�P�]�ƪ��s�u�C
    /// </summary>
    public void Disconnect()
    {
        ThrowIfDisposed();

        using (LoggingScope.BeginDeviceScope(_logger, _deviceId, _portName))
        {
            _logger.LogDeviceOperationStart("Disconnect", _deviceId);

            var sw = Stopwatch.StartNew();

            try
            {
                // �����_�u�ާ@
                SimulateOperation(100);

                _isConnected = false;
                sw.Stop();

                _logger.LogDeviceConnectionChanged(_deviceId, false, _portName);
                _logger.LogDeviceOperationComplete("Disconnect", _deviceId, sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                sw.Stop();
                _logger.LogDeviceOperationFailed("Disconnect", _deviceId, ex);
            }
        }
    }

    /// <summary>
    /// �o�e���O��]�ơC
    /// </summary>
    /// <param name="command">���O���e�C</param>
    /// <returns>�]�Ʀ^���C</returns>
    public string SendCommand(string command)
    {
        ThrowIfDisposed();

        if (!_isConnected)
        {
            _logger.LogWarning("���յo�e���O���]�ƥ��s�u | DeviceId: {DeviceId}", _deviceId);
            throw new InvalidOperationException("�]�ƥ��s�u");
        }

        using (LoggingScope.BeginDeviceScope(_logger, _deviceId, _portName))
        using (LoggingScope.BeginOperationScope(_logger, "SendCommand"))
        {
            _logger.LogDebug("�o�e���O | Command: {Command}", command);
            _logger.LogDeviceCommunication("Send", _deviceId, command);

            var sw = Stopwatch.StartNew();

            try
            {
                // �����q�T
                SimulateOperation(200);

                var response = $"OK:{command}";
                sw.Stop();

                _logger.LogDeviceCommunication("Receive", _deviceId, response);
                _logger.LogDebug("����^�� | Response: {Response}, ElapsedMs: {ElapsedMs}", response, sw.ElapsedMilliseconds);

                return response;
            }
            catch (Exception ex)
            {
                sw.Stop();
                _logger.LogDeviceOperationFailed("SendCommand", _deviceId, ex);
                throw;
            }
        }
    }

    /// <summary>
    /// ����ۧڶE�_�C
    /// </summary>
    /// <returns>�E�_���G�C</returns>
    public DiagnosticResult RunDiagnostic()
    {
        ThrowIfDisposed();

        using (LoggingScope.BeginDeviceScope(_logger, _deviceId, _portName))
        {
            _logger.LogInformation("�}�l����ۧڶE�_ | DeviceId: {DeviceId}", _deviceId);

            var sw = Stopwatch.StartNew();
            var result = new DiagnosticResult
            {
                DeviceId = _deviceId,
                IsConnected = _isConnected,
                Timestamp = DateTime.Now
            };

            try
            {
                // �����E�_
                SimulateOperation(1000);

                result.IsSuccess = true;
                result.Message = "�E�_�����A�]�ƥ��`";
                sw.Stop();

                _logger.LogInformation("�ۧڶE�_���� | DeviceId: {DeviceId}, IsSuccess: {IsSuccess}, ElapsedMs: {ElapsedMs}",
                    _deviceId, result.IsSuccess, sw.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                sw.Stop();
                result.IsSuccess = false;
                result.Message = $"�E�_����: {ex.Message}";

                _logger.LogError(ex, "�ۧڶE�_���� | DeviceId: {DeviceId}", _deviceId);
            }

            return result;
        }
    }

    #endregion

    #region IDisposable

    /// <inheritdoc />
    public void Dispose()
    {
        if (_disposed) return;

        _logger.LogDebug("���b���� SampleDeviceController | DeviceId: {DeviceId}", _deviceId);

        if (_isConnected)
        {
            Disconnect();
        }

        _disposed = true;

        _logger.LogDebug("SampleDeviceController �w���� | DeviceId: {DeviceId}", _deviceId);
    }

    #endregion

    #region �p����k

    private void ThrowIfDisposed()
    {
        if (_disposed)
        {
            throw new ObjectDisposedException(nameof(SampleDeviceController));
        }
    }

    private static void SimulateOperation(int delayMs)
    {
        // �����ާ@����
        Thread.Sleep(delayMs);
    }

    #endregion
}

/// <summary>
/// �E�_���G�C
/// </summary>
public sealed class DiagnosticResult
{
    /// <summary>
    /// �]�� ID�C
    /// </summary>
    public string DeviceId { get; set; } = string.Empty;

    /// <summary>
    /// �O�_�s�u�C
    /// </summary>
    public bool IsConnected { get; set; }

    /// <summary>
    /// �O�_���\�C
    /// </summary>
    public bool IsSuccess { get; set; }

    /// <summary>
    /// �T���C
    /// </summary>
    public string Message { get; set; } = string.Empty;

    /// <summary>
    /// �ɶ��W�C
    /// </summary>
    public DateTime Timestamp { get; set; }
}
