// ===================================================================
// Calin.Logging.Serilog
// 
// LoggerConfigurationExtensions - Serilog �]�w�X�R��k
// ===================================================================

using Serilog;
using Serilog.Configuration;

namespace Calin.Logging.Serilog.Enrichers;

/// <summary>
/// LoggerConfiguration �X�R��k�C
/// </summary>
/// <remarks>
/// <b>�����O�u���b App �ϥΡCDevice NuGet ���i�ϥΡC</b>
/// </remarks>
public static class LoggerConfigurationExtensions
{
    /// <summary>
    /// �[�J���ε{���W�� Enricher�C
    /// </summary>
    /// <param name="enrichmentConfiguration">Enrichment �]�w�C</param>
    /// <param name="applicationName">���ε{���W�١C</param>
    /// <returns>LoggerConfiguration�C</returns>
    public static LoggerConfiguration WithApplicationName(
        this LoggerEnrichmentConfiguration enrichmentConfiguration,
        string applicationName)
    {
        if (enrichmentConfiguration == null) throw new ArgumentNullException(nameof(enrichmentConfiguration));
        if (string.IsNullOrEmpty(applicationName)) throw new ArgumentNullException(nameof(applicationName));

        return enrichmentConfiguration.With(new ApplicationNameEnricher(applicationName));
    }

    /// <summary>
    /// �[�J�I�s�̸�T Enricher�C
    /// </summary>
    /// <param name="enrichmentConfiguration">Enrichment �]�w�C</param>
    /// <returns>LoggerConfiguration�C</returns>
    /// <remarks>
    /// <b>�`�N�G�� Enricher �|���į�v�T�A�ȫ�ĳ�b Debug ���ҨϥΡC</b>
    /// </remarks>
    public static LoggerConfiguration WithCallerInfo(
        this LoggerEnrichmentConfiguration enrichmentConfiguration)
    {
        if (enrichmentConfiguration == null) throw new ArgumentNullException(nameof(enrichmentConfiguration));

        return enrichmentConfiguration.With<CallerInfoEnricher>();
    }
}
