// ===================================================================
// Calin.Logging.Serilog
// 
// DeviceLogOutputTemplate - �]�� Log ��X�ҪO
// ===================================================================

namespace Calin.Logging.Serilog.Formatters;

/// <summary>
/// �w�w�q�� Log ��X�ҪO�C
/// </summary>
/// <remarks>
/// <b>�����O�u���b App �ϥΡCDevice NuGet ���i�ϥΡC</b>
/// </remarks>
public static class OutputTemplates
{
    /// <summary>
    /// ²��ҪO�]�A�Ω� Console�^�C
    /// </summary>
    public const string Simple = "[{Timestamp:HH:mm:ss.fff} {Level:u3}] {Message:lj}{NewLine}{Exception}";

    /// <summary>
    /// �зǼҪO�]�]�t SourceContext�^�C
    /// </summary>
    public const string Standard = "[{Timestamp:HH:mm:ss.fff} {Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}";

    /// <summary>
    /// �ԲӼҪO�]�]�t Thread�BSourceContext�^�C
    /// </summary>
    public const string Detailed = "[{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} {Level:u3}] [Thread:{ThreadId}] [{SourceContext}] {Message:lj}{NewLine}{Exception}";

    /// <summary>
    /// �]�ƱM�μҪO�]�]�t DeviceId�BPortName�^�C
    /// </summary>
    public const string Device = "[{Timestamp:HH:mm:ss.fff} {Level:u3}] [{SourceContext}] [Device:{DeviceId}] [Port:{PortName}] {Message:lj}{NewLine}{Exception}";

    /// <summary>
    /// ����ҪO�]�]�t�Ҧ���T�^�C
    /// </summary>
    public const string Full = "[{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} {Level:u3}] [App:{ApplicationName}] [Machine:{MachineName}] [Process:{ProcessId}] [Thread:{ThreadId}] [{SourceContext}] {Message:lj}{NewLine}{Properties:j}{NewLine}{Exception}";
}
