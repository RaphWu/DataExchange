﻿# Calin 方案

## 簡介

本方案包含多個專案，每個專案皆為獨立的 NuGet 套件，請參考各專案的 README 文件。

## 目標框架（Target Frameworks）

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

## 目前的專案

- `Calin`：基礎設施與通用擴充方法。
- `Calin.logging`：日誌記錄模組，支援多種日誌目標與格式。
- `Calin.Navigation`：導航管理模組，協助應用程式內的頁面切換與狀態管理。
- `Calin.Coordinator`：工作流程協調器，管理多步驟任務的執行與狀態。
- `Calin.Forms`：針對 Windows Forms 的擴充方法與 Helper。

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
