﻿using Autofac;

namespace Calin.Navigation
{
    /// <summary>
    /// 導航模組的 Autofac 註冊。
    /// </summary>
    /// <remarks>
    /// <para>此 Module 負責註冊導航相關的所有服務。</para>
    /// <para>
    /// 使用方式：
    /// <code>
    /// var builder = new ContainerBuilder();
    /// builder.RegisterModule&lt;NavigationModule&gt;();
    /// var container = builder.Build();
    /// 
    /// // 取得服務
    /// var regionManager = container.Resolve&lt;IRegionManager&gt;();
    /// var navigationService = container.Resolve&lt;INavigationService&gt;();
    /// </code>
    /// </para>
    /// </remarks>
    public class NavigationModule : Module
    {
        /// <summary>
        /// 載入模組並註冊服務。
        /// </summary>
        /// <param name="builder">容器建構器。</param>
        protected override void Load(ContainerBuilder builder)
        {
            // 註冊 RegionManager (SingleInstance)
            // RegionManager 管理所有 Region，應為單例
            builder.RegisterType<RegionManager>()
                .As<IRegionManager>()
                .SingleInstance();

            // 註冊 NavigationService (SingleInstance)
            // NavigationService 協調所有導航操作，應為單例
            builder.RegisterType<NavigationService>()
                .As<INavigationService>()
                .SingleInstance();
        }
    }
}
