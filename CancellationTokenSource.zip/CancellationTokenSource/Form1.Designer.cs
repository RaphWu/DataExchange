﻿namespace CancellationTokenSourceTester
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Proc1Stop = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button_Start = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button_Proc2Stop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_Proc1Stop
            // 
            this.button_Proc1Stop.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Proc1Stop.Location = new System.Drawing.Point(496, 120);
            this.button_Proc1Stop.Name = "button_Proc1Stop";
            this.button_Proc1Stop.Size = new System.Drawing.Size(99, 45);
            this.button_Proc1Stop.TabIndex = 0;
            this.button_Proc1Stop.Text = "Proc1 Stop";
            this.button_Proc1Stop.UseVisualStyleBackColor = true;
            this.button_Proc1Stop.Click += new System.EventHandler(this.button_Proc1Stop_Click);
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 17;
            this.listBox1.Location = new System.Drawing.Point(19, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(222, 412);
            this.listBox1.TabIndex = 1;
            // 
            // button_Start
            // 
            this.button_Start.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Start.Location = new System.Drawing.Point(496, 12);
            this.button_Start.Name = "button_Start";
            this.button_Start.Size = new System.Drawing.Size(99, 45);
            this.button_Start.TabIndex = 2;
            this.button_Start.Text = "Start";
            this.button_Start.UseVisualStyleBackColor = true;
            this.button_Start.Click += new System.EventHandler(this.button_Start_Click);
            // 
            // listBox2
            // 
            this.listBox2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 17;
            this.listBox2.Location = new System.Drawing.Point(256, 12);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(222, 412);
            this.listBox2.TabIndex = 3;
            // 
            // button_Proc2Stop
            // 
            this.button_Proc2Stop.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Proc2Stop.Location = new System.Drawing.Point(496, 185);
            this.button_Proc2Stop.Name = "button_Proc2Stop";
            this.button_Proc2Stop.Size = new System.Drawing.Size(99, 45);
            this.button_Proc2Stop.TabIndex = 4;
            this.button_Proc2Stop.Text = "Proc2 Stop";
            this.button_Proc2Stop.UseVisualStyleBackColor = true;
            this.button_Proc2Stop.Click += new System.EventHandler(this.button_Proc2Stop_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 445);
            this.Controls.Add(this.button_Proc2Stop);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.button_Start);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button_Proc1Stop);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_Proc1Stop;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button_Start;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button button_Proc2Stop;
    }
}

