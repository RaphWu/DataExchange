﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace CancellationTokenSourceTester
//{
//    public partial class Form1
//    {
//        private async void nothing()
//        {
//            try
//            {
//                while (true)
//                {
//                    if (token.IsCancellationRequested)
//                        token.ThrowIfCancellationRequested();

//                    /********************
//                     * 傳送邏輯
//                     ********************/

//                    /********************
//                     * 接收邏輯
//                     ********************/
//                }
//            }
//            catch (OperationCanceledException)
//            {
//                // do nothing for CancellationTokenSource
//            }




//            while (!token.IsCancellationRequested)
//            {
//                try
//                {
//                    /********************
//                     * 傳送邏輯
//                     ********************/

//                    token.ThrowIfCancellationRequested();

//                    /********************
//                     * 接收邏輯
//                     ********************/

//                    token.ThrowIfCancellationRequested();
//                }
//                catch (OperationCanceledException)
//                {
//                    // do nothing for CancellationTokenSource
//                }
//            }
//        }
//    }
//}
