﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PollingTester
{
    public partial class Polling
    {
        private CancellationTokenSource cts2;
        private Thread thread2;
        private PollingData pollingData;

        public Polling()
        {
            pollingData = new PollingData();
        }

        public PollingData PollingData
        {
            get { return pollingData; }
        }

        public void Stop()
        {
            if (cts2 != null)
            {
                if (!cts2.IsCancellationRequested)
                    cts2.Cancel();
                cts2.Dispose();
            }

            if (thread2 != null)
            {
                thread2.Join();
                thread2 = null;
            }
        }

        public void Start()
        {
            if (cts2 != null)
                cts2.Dispose();
            cts2 = new CancellationTokenSource();

            if (thread2 == null || thread2.ThreadState == ThreadState.Stopped)
            {
                thread2 = new Thread(ThreadProc2)
                {
                    Name = "Proc1",
                    IsBackground = true
                };
                thread2.Start(cts2);
            }
        }

        private void ThreadProc2(object param)
        {
            CancellationTokenSource cts = param as CancellationTokenSource;
            CancellationToken token = cts.Token;

            pollingData.Message = "Proc2 Start...";
            pollingData.Updated = true;

            while (!token.IsCancellationRequested)
            {
                try
                {
                    Thread.Sleep(750);
                    pollingData.Message = "Proc2 Tick...";
                    pollingData.Updated = true;
                }
                catch (OperationCanceledException)
                {
                }
            }

            pollingData.Message = "Proc2 Finished...";
            pollingData.Updated = true;
        }
    }
}
