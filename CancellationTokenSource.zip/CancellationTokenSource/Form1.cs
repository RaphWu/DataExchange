﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using PollingTester;

namespace CancellationTokenSourceTester
{
    public partial class Form1 : Form
    {
        private CancellationTokenSource cts1;
        private Thread thread1;
        private Polling polling;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            polling = new Polling();
        }

        private void button_Start_Click(object sender, EventArgs e)
        {
            Start();
        }

        private void button_Proc1Stop_Click(object sender, EventArgs e)
        {
            Stop();
        }

        private void button_Proc2Stop_Click(object sender, EventArgs e)
        {
            polling.Stop();
        }

        public void Stop()
        {
            if (cts1 != null)
            {
                if (!cts1.IsCancellationRequested)
                    cts1.Cancel();
                cts1.Dispose();
            }

            if (thread1 != null)
            {
                thread1.Join();
                thread1 = null;
            }
        }

        public void Start()
        {
            if (cts1 != null)
                cts1.Dispose();
            cts1 = new CancellationTokenSource();

            if (thread1 == null || thread1.ThreadState == ThreadState.Stopped)
            {
                thread1 = new Thread(ThreadProc1)
                {
                    Name = "Proc1",
                    IsBackground = true
                };
                thread1.Start(cts1);
            }

            polling.Start();
            Thread.Sleep(500);
        }

        private void ThreadProc1(object param)
        {
            CancellationTokenSource cts = param as CancellationTokenSource;
            CancellationToken token = cts.Token;

            listBox1.InvokeIfRequired(() =>
            {
                listBox1.Items.Add("Proc1 Start...");
            });

            int counter = 0;
            try
            {
                while (!token.IsCancellationRequested)
                {
                    listBox1.InvokeIfRequired(() =>
                    {
                        if (++counter > 40)
                        {
                            listBox1.Items.Add("Proc1 Tick...");
                            counter = 0;
                        }

                        if (polling.PollingData.Updated)
                        {
                            listBox2.Items.Add(polling.PollingData.Message);
                            polling.PollingData.Updated = false;
                        }
                    });

                    Thread.Sleep(20);
                }


                //listBox_Message.Items.Add("while (true)");
                //counter++;

                //if (counter < 5)
                //    await Task.Delay(1000);
                //else
                //    throw new ApplicationException("ApplicationException");

                //token.ThrowIfCancellationRequested();
            }
            catch (OperationCanceledException oce)
            {
                listBox1.Items.Add(oce.Message);
            }
            catch (ApplicationException ae)
            {
                listBox1.Items.Add(ae.Message);
                //counter = 0;
            }
            catch (Exception ex)
            {
                listBox1.Items.Add(ex.Message);
                //counter = 0;
            }

            listBox1.InvokeIfRequired(() =>
            {
                listBox1.Items.Add("Proc1 Finished...");
            });
        }
    }
}
