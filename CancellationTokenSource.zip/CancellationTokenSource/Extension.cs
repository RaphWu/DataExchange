﻿using System.Windows.Forms;

namespace CancellationTokenSourceTester
{
    public static class Extension
    {
        public static void InvokeIfRequired(this Control control, MethodInvoker action)
        {
            if (control.InvokeRequired)
                control.Invoke(action);
            else
                action();
        }
    }
}
