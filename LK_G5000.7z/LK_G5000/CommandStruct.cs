﻿namespace LK_G5000
{
    /// <summary>
    /// 指令結構。
    /// </summary>
    public class CommandStruct
    {
        public int Id { get; set; } // 編號
        public string CommandName { get; set; } // 指令名稱
        public string CommandHead { get; set; } // 傳入指令頭
        public string SendParams { get; set; } // 傳入參數
        public string ResponseParams { get; set; } // 回傳參數
    }
}
