﻿namespace LK_G5000
{
    partial class LK_G5000
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_SerialPort = new System.Windows.Forms.GroupBox();
            this.cbDataBits = new System.Windows.Forms.ComboBox();
            this.btnUpdatePortNames = new System.Windows.Forms.Button();
            this.label_StopBits = new System.Windows.Forms.Label();
            this.cbStopBits = new System.Windows.Forms.ComboBox();
            this.label_DataBits = new System.Windows.Forms.Label();
            this.label_Parity = new System.Windows.Forms.Label();
            this.cbParity = new System.Windows.Forms.ComboBox();
            this.label_BaudRate = new System.Windows.Forms.Label();
            this.cbBaudRate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbCom = new System.Windows.Forms.ComboBox();
            this.btnDisconnct = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbCommandHead = new System.Windows.Forms.TextBox();
            this.tbResponseCommand = new System.Windows.Forms.TextBox();
            this.tbErrorMessage = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnCopyCommand = new System.Windows.Forms.Button();
            this.tbParams = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lblWaitingForResponse = new System.Windows.Forms.Label();
            this.btnCleanCommand = new System.Windows.Forms.Button();
            this.rbOrderByManual = new System.Windows.Forms.RadioButton();
            this.rbOrderByName = new System.Windows.Forms.RadioButton();
            this.rbOrderByCommand = new System.Windows.Forms.RadioButton();
            this.groupBox_SerialPort.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox_SerialPort
            // 
            this.groupBox_SerialPort.Controls.Add(this.cbDataBits);
            this.groupBox_SerialPort.Controls.Add(this.btnUpdatePortNames);
            this.groupBox_SerialPort.Controls.Add(this.label_StopBits);
            this.groupBox_SerialPort.Controls.Add(this.cbStopBits);
            this.groupBox_SerialPort.Controls.Add(this.label_DataBits);
            this.groupBox_SerialPort.Controls.Add(this.label_Parity);
            this.groupBox_SerialPort.Controls.Add(this.cbParity);
            this.groupBox_SerialPort.Controls.Add(this.label_BaudRate);
            this.groupBox_SerialPort.Controls.Add(this.cbBaudRate);
            this.groupBox_SerialPort.Controls.Add(this.label2);
            this.groupBox_SerialPort.Controls.Add(this.cbCom);
            this.groupBox_SerialPort.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox_SerialPort.Location = new System.Drawing.Point(12, 12);
            this.groupBox_SerialPort.Name = "groupBox_SerialPort";
            this.groupBox_SerialPort.Size = new System.Drawing.Size(173, 231);
            this.groupBox_SerialPort.TabIndex = 76;
            this.groupBox_SerialPort.TabStop = false;
            this.groupBox_SerialPort.Text = "串列埠設定";
            // 
            // cbDataBits
            // 
            this.cbDataBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDataBits.FormattingEnabled = true;
            this.cbDataBits.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbDataBits.Location = new System.Drawing.Point(76, 116);
            this.cbDataBits.Name = "cbDataBits";
            this.cbDataBits.Size = new System.Drawing.Size(82, 25);
            this.cbDataBits.TabIndex = 158;
            this.cbDataBits.SelectedIndexChanged += new System.EventHandler(this.tbDataBits_SelectedIndexChanged);
            // 
            // btnUpdatePortNames
            // 
            this.btnUpdatePortNames.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnUpdatePortNames.Location = new System.Drawing.Point(13, 185);
            this.btnUpdatePortNames.Name = "btnUpdatePortNames";
            this.btnUpdatePortNames.Size = new System.Drawing.Size(145, 31);
            this.btnUpdatePortNames.TabIndex = 157;
            this.btnUpdatePortNames.Text = "更新埠列表";
            this.btnUpdatePortNames.UseVisualStyleBackColor = true;
            this.btnUpdatePortNames.Click += new System.EventHandler(this.btnUpdatePortNames_Click);
            // 
            // label_StopBits
            // 
            this.label_StopBits.AutoSize = true;
            this.label_StopBits.Location = new System.Drawing.Point(10, 150);
            this.label_StopBits.Name = "label_StopBits";
            this.label_StopBits.Size = new System.Drawing.Size(63, 17);
            this.label_StopBits.TabIndex = 156;
            this.label_StopBits.Text = "停止位元:";
            this.label_StopBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbStopBits
            // 
            this.cbStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStopBits.FormattingEnabled = true;
            this.cbStopBits.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbStopBits.Location = new System.Drawing.Point(76, 147);
            this.cbStopBits.Name = "cbStopBits";
            this.cbStopBits.Size = new System.Drawing.Size(82, 25);
            this.cbStopBits.TabIndex = 155;
            this.cbStopBits.SelectedIndexChanged += new System.EventHandler(this.cbStopBits_SelectedIndexChanged);
            // 
            // label_DataBits
            // 
            this.label_DataBits.AutoSize = true;
            this.label_DataBits.Location = new System.Drawing.Point(10, 119);
            this.label_DataBits.Name = "label_DataBits";
            this.label_DataBits.Size = new System.Drawing.Size(63, 17);
            this.label_DataBits.TabIndex = 154;
            this.label_DataBits.Text = "資料位元:";
            this.label_DataBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Parity
            // 
            this.label_Parity.AutoSize = true;
            this.label_Parity.Location = new System.Drawing.Point(10, 88);
            this.label_Parity.Name = "label_Parity";
            this.label_Parity.Size = new System.Drawing.Size(63, 17);
            this.label_Parity.TabIndex = 152;
            this.label_Parity.Text = "同位位元:";
            this.label_Parity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbParity
            // 
            this.cbParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbParity.FormattingEnabled = true;
            this.cbParity.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbParity.Location = new System.Drawing.Point(76, 85);
            this.cbParity.Name = "cbParity";
            this.cbParity.Size = new System.Drawing.Size(82, 25);
            this.cbParity.TabIndex = 151;
            this.cbParity.SelectedIndexChanged += new System.EventHandler(this.cbParity_SelectedIndexChanged);
            // 
            // label_BaudRate
            // 
            this.label_BaudRate.AutoSize = true;
            this.label_BaudRate.Location = new System.Drawing.Point(35, 57);
            this.label_BaudRate.Name = "label_BaudRate";
            this.label_BaudRate.Size = new System.Drawing.Size(37, 17);
            this.label_BaudRate.TabIndex = 150;
            this.label_BaudRate.Text = "鮑率:";
            this.label_BaudRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbBaudRate
            // 
            this.cbBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBaudRate.FormattingEnabled = true;
            this.cbBaudRate.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbBaudRate.Location = new System.Drawing.Point(76, 54);
            this.cbBaudRate.Name = "cbBaudRate";
            this.cbBaudRate.Size = new System.Drawing.Size(82, 25);
            this.cbBaudRate.TabIndex = 149;
            this.cbBaudRate.SelectedIndexChanged += new System.EventHandler(this.cbBaudRate_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 17);
            this.label2.TabIndex = 148;
            this.label2.Text = "Port:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbCom
            // 
            this.cbCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCom.FormattingEnabled = true;
            this.cbCom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbCom.Location = new System.Drawing.Point(76, 23);
            this.cbCom.Name = "cbCom";
            this.cbCom.Size = new System.Drawing.Size(82, 25);
            this.cbCom.TabIndex = 145;
            this.cbCom.SelectedIndexChanged += new System.EventHandler(this.cbCom_SelectedIndexChanged);
            // 
            // btnDisconnct
            // 
            this.btnDisconnct.Enabled = false;
            this.btnDisconnct.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnDisconnct.Location = new System.Drawing.Point(25, 286);
            this.btnDisconnct.Name = "btnDisconnct";
            this.btnDisconnct.Size = new System.Drawing.Size(145, 31);
            this.btnDisconnct.TabIndex = 78;
            this.btnDisconnct.Text = "連線終止";
            this.btnDisconnct.UseVisualStyleBackColor = true;
            this.btnDisconnct.Click += new System.EventHandler(this.btnDisconnct_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnConnect.Location = new System.Drawing.Point(25, 249);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(145, 31);
            this.btnConnect.TabIndex = 77;
            this.btnConnect.Text = "連線";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Location = new System.Drawing.Point(202, 332);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 27);
            this.label1.TabIndex = 84;
            this.label1.Text = "錯誤訊息";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label3.Location = new System.Drawing.Point(202, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 27);
            this.label3.TabIndex = 83;
            this.label3.Text = "傳入指令";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label4.Location = new System.Drawing.Point(202, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 27);
            this.label4.TabIndex = 82;
            this.label4.Text = "響應指令";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbCommandHead
            // 
            this.tbCommandHead.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbCommandHead.Location = new System.Drawing.Point(284, 267);
            this.tbCommandHead.Name = "tbCommandHead";
            this.tbCommandHead.Size = new System.Drawing.Size(159, 27);
            this.tbCommandHead.TabIndex = 85;
            // 
            // tbResponseCommand
            // 
            this.tbResponseCommand.Location = new System.Drawing.Point(284, 300);
            this.tbResponseCommand.Name = "tbResponseCommand";
            this.tbResponseCommand.Size = new System.Drawing.Size(527, 27);
            this.tbResponseCommand.TabIndex = 86;
            // 
            // tbErrorMessage
            // 
            this.tbErrorMessage.Location = new System.Drawing.Point(284, 333);
            this.tbErrorMessage.Name = "tbErrorMessage";
            this.tbErrorMessage.Size = new System.Drawing.Size(527, 27);
            this.tbErrorMessage.TabIndex = 87;
            // 
            // btnSend
            // 
            this.btnSend.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSend.Location = new System.Drawing.Point(730, 221);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(139, 31);
            this.btnSend.TabIndex = 88;
            this.btnSend.Text = "傳送 (自動加CR)";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(217, 12);
            this.dgv.Name = "dgv";
            this.dgv.RowTemplate.Height = 24;
            this.dgv.Size = new System.Drawing.Size(507, 240);
            this.dgv.TabIndex = 89;
            this.dgv.SelectionChanged += new System.EventHandler(this.dgv_SelectionChanged);
            // 
            // btnCopyCommand
            // 
            this.btnCopyCommand.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCopyCommand.Location = new System.Drawing.Point(730, 184);
            this.btnCopyCommand.Name = "btnCopyCommand";
            this.btnCopyCommand.Size = new System.Drawing.Size(139, 31);
            this.btnCopyCommand.TabIndex = 90;
            this.btnCopyCommand.Text = "移至傳入指令";
            this.btnCopyCommand.UseVisualStyleBackColor = true;
            this.btnCopyCommand.Click += new System.EventHandler(this.btnCopyCommand_Click);
            // 
            // tbParams
            // 
            this.tbParams.Location = new System.Drawing.Point(468, 267);
            this.tbParams.Name = "tbParams";
            this.tbParams.Size = new System.Drawing.Size(343, 27);
            this.tbParams.TabIndex = 91;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.Location = new System.Drawing.Point(449, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 27);
            this.label5.TabIndex = 92;
            this.label5.Text = ",";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWaitingForResponse
            // 
            this.lblWaitingForResponse.AutoSize = true;
            this.lblWaitingForResponse.BackColor = System.Drawing.Color.Maroon;
            this.lblWaitingForResponse.ForeColor = System.Drawing.Color.White;
            this.lblWaitingForResponse.Location = new System.Drawing.Point(824, 266);
            this.lblWaitingForResponse.Name = "lblWaitingForResponse";
            this.lblWaitingForResponse.Padding = new System.Windows.Forms.Padding(3);
            this.lblWaitingForResponse.Size = new System.Drawing.Size(45, 44);
            this.lblWaitingForResponse.TabIndex = 93;
            this.lblWaitingForResponse.Text = "等待\r\n接收";
            this.lblWaitingForResponse.Visible = false;
            // 
            // btnCleanCommand
            // 
            this.btnCleanCommand.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCleanCommand.Location = new System.Drawing.Point(730, 147);
            this.btnCleanCommand.Name = "btnCleanCommand";
            this.btnCleanCommand.Size = new System.Drawing.Size(139, 31);
            this.btnCleanCommand.TabIndex = 97;
            this.btnCleanCommand.Text = "清除傳入指令";
            this.btnCleanCommand.UseVisualStyleBackColor = true;
            this.btnCleanCommand.Click += new System.EventHandler(this.btnCleanCommand_Click);
            // 
            // btnOrderByManual
            // 
            this.rbOrderByManual.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbOrderByManual.FlatAppearance.CheckedBackColor = System.Drawing.Color.LightSalmon;
            this.rbOrderByManual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbOrderByManual.Font = new System.Drawing.Font("微軟正黑體", 9.75F);
            this.rbOrderByManual.Location = new System.Drawing.Point(730, 12);
            this.rbOrderByManual.Name = "btnOrderByManual";
            this.rbOrderByManual.Size = new System.Drawing.Size(139, 31);
            this.rbOrderByManual.TabIndex = 98;
            this.rbOrderByManual.TabStop = true;
            this.rbOrderByManual.Text = "按說明書順序";
            this.rbOrderByManual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbOrderByManual.UseVisualStyleBackColor = true;
            this.rbOrderByManual.CheckedChanged += new System.EventHandler(this.OrderManual);
            // 
            // btnOrderByCommand
            // 
            this.rbOrderByName.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbOrderByName.FlatAppearance.CheckedBackColor = System.Drawing.Color.LightSalmon;
            this.rbOrderByName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbOrderByName.Font = new System.Drawing.Font("微軟正黑體", 9.75F);
            this.rbOrderByName.Location = new System.Drawing.Point(730, 49);
            this.rbOrderByName.Name = "btnOrderByCommand";
            this.rbOrderByName.Size = new System.Drawing.Size(139, 31);
            this.rbOrderByName.TabIndex = 99;
            this.rbOrderByName.TabStop = true;
            this.rbOrderByName.Text = "按命令名稱順序";
            this.rbOrderByName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbOrderByName.UseVisualStyleBackColor = true;
            this.rbOrderByName.CheckedChanged += new System.EventHandler(this.OrderManual);
            // 
            // btnOrderByParam
            // 
            this.rbOrderByCommand.Appearance = System.Windows.Forms.Appearance.Button;
            this.rbOrderByCommand.FlatAppearance.CheckedBackColor = System.Drawing.Color.LightSalmon;
            this.rbOrderByCommand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rbOrderByCommand.Font = new System.Drawing.Font("微軟正黑體", 9.75F);
            this.rbOrderByCommand.Location = new System.Drawing.Point(730, 86);
            this.rbOrderByCommand.Name = "btnOrderByParam";
            this.rbOrderByCommand.Size = new System.Drawing.Size(139, 31);
            this.rbOrderByCommand.TabIndex = 100;
            this.rbOrderByCommand.TabStop = true;
            this.rbOrderByCommand.Text = "按傳入指令順序";
            this.rbOrderByCommand.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rbOrderByCommand.UseVisualStyleBackColor = true;
            this.rbOrderByCommand.CheckedChanged += new System.EventHandler(this.OrderManual);
            // 
            // LK_G5000
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 375);
            this.Controls.Add(this.rbOrderByCommand);
            this.Controls.Add(this.rbOrderByName);
            this.Controls.Add(this.rbOrderByManual);
            this.Controls.Add(this.btnCleanCommand);
            this.Controls.Add(this.lblWaitingForResponse);
            this.Controls.Add(this.tbParams);
            this.Controls.Add(this.btnCopyCommand);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.tbErrorMessage);
            this.Controls.Add(this.tbResponseCommand);
            this.Controls.Add(this.tbCommandHead);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnDisconnct);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.groupBox_SerialPort);
            this.Controls.Add(this.label5);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "LK_G5000";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LK_G5000";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LK_G5000_FormClosed);
            this.Load += new System.EventHandler(this.LK_G5000_Load);
            this.groupBox_SerialPort.ResumeLayout(false);
            this.groupBox_SerialPort.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_SerialPort;
        private System.Windows.Forms.Button btnUpdatePortNames;
        private System.Windows.Forms.Label label_StopBits;
        private System.Windows.Forms.ComboBox cbStopBits;
        private System.Windows.Forms.Label label_DataBits;
        private System.Windows.Forms.Label label_Parity;
        private System.Windows.Forms.ComboBox cbParity;
        private System.Windows.Forms.Label label_BaudRate;
        private System.Windows.Forms.ComboBox cbBaudRate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbCom;
        private System.Windows.Forms.Button btnDisconnct;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ComboBox cbDataBits;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbCommandHead;
        private System.Windows.Forms.TextBox tbResponseCommand;
        private System.Windows.Forms.TextBox tbErrorMessage;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnCopyCommand;
        private System.Windows.Forms.TextBox tbParams;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblWaitingForResponse;
        private System.Windows.Forms.Button btnCleanCommand;
        private System.Windows.Forms.RadioButton rbOrderByManual;
        private System.Windows.Forms.RadioButton rbOrderByName;
        private System.Windows.Forms.RadioButton rbOrderByCommand;
    }
}

