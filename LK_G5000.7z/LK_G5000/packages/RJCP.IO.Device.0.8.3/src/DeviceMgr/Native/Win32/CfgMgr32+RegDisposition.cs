﻿namespace RJCP.Native.Win32
{
    internal static partial class CfgMgr32
    {
        public enum RegDisposition
        {
            OpenAlways = 0,
            OpenExisting = 1
        }
    }
}
