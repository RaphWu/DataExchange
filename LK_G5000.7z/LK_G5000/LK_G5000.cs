﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Calin.SerialPort;
using RJCP.IO.Ports;

namespace LK_G5000
{
    public partial class LK_G5000 : Form
    {
        #region Fields

        private SerialPortConfig _config = new SerialPortConfig();
        private ISerialPortService _lkG5000;

        private const string SensorName = "LK-G5000";
        private const string SensorDescription = "LK-G5000 Laser Distance Sensor";
        private readonly System.Windows.Forms.Timer _uiUpdateTimer;

        private bool _dataSended = false;
        private List<CommandStruct> _commandList;
        private CommandStruct _sendCommand = null;
        private List<string> _measuredString = new List<string>();
        private List<double> _measuredValue = new List<double>();
        private int? _selectedId = null;
        private bool _selectionChangedEnabled = true;

        #endregion Fields

        public LK_G5000()
        {
            InitializeComponent();

            var portNameList = SerialPortService.GetAvailablePorts();
            portNameList.Sort();
            cbCom.DataSource = null;
            cbCom.DataSource = portNameList;
            cbCom.SelectedIndex = 0;

            cbBaudRate.DataSource = null;
            cbBaudRate.DataSource = new List<int>() { 2400, 4800, 9600, 19200, 38400, 57600, 115200 };
            cbBaudRate.SelectedItem = _config.BaudRate;

            cbParity.DataSource = null;
            cbParity.DataSource = Enum.GetValues(typeof(Parity)).Cast<Parity>().ToList();
            cbParity.SelectedItem = _config.Parity;

            cbDataBits.DataSource = null;
            cbDataBits.DataSource = new List<int>() { 5, 6, 7, 8 };
            cbDataBits.SelectedItem = _config.DataBits;

            cbStopBits.DataSource = null;
            cbStopBits.DataSource = Enum.GetValues(typeof(StopBits)).Cast<StopBits>().ToList();
            cbStopBits.SelectedItem = _config.StopBits;

            _config.EnableAutoReconnect = false;
            _config.AsciiLineTerminator = "\r";

            _uiUpdateTimer = new System.Windows.Forms.Timer();
            _uiUpdateTimer.Interval = 200;
            _uiUpdateTimer.Tick += (s, e) => UpdateUi();
            _uiUpdateTimer.Start();

            CreateCommandList();

            dgv.AutoGenerateColumns = false;
            dgv.RowHeadersVisible = false;
            dgv.MultiSelect = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.WhiteSmoke;
            dgv.GridColor = Color.LightGray;
            dgv.ReadOnly = true;
            dgv.AllowUserToResizeColumns = true;
            dgv.AllowUserToResizeRows = false;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToOrderColumns = false;

            dgv.DataSource = _commandList;

            //dgv.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = nameof(CommandStruct.Id),
            //    HeaderText = "Id",
            //});

            dgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(CommandStruct.CommandName),
                HeaderText = "命令名稱",
            });

            dgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(CommandStruct.CommandHead),
                HeaderText = "傳入指令",
            });

            dgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(CommandStruct.SendParams),
                HeaderText = "參數",
            });

            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgv.AutoResizeColumns();

            rbOrderByManual.Checked = true;
        }

        #region Form Events

        private void LK_G5000_FormClosed(object sender, FormClosedEventArgs e)
        {
            Close();
        }

        private void LK_G5000_Load(object sender, EventArgs e)
        {
            //UpdateDgv();
        }

        private void btnUpdatePortNames_Click(object sender, EventArgs e)
        {
            var portNameList = SerialPortService.GetAvailablePorts();
            portNameList.Sort();
            cbCom.DataSource = null;
            cbCom.DataSource = portNameList;
        }

        private void btnDisconnct_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            Open();
        }

        private void cbCom_SelectedIndexChanged(object sender, EventArgs e)
        {
            _config.PortName = cbCom.SelectedItem.ToString();
        }

        private void cbBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            _config.BaudRate = (int)cbBaudRate.SelectedItem;
        }

        private void cbParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            _config.Parity = (Parity)cbParity.SelectedItem;
        }

        private void tbDataBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            _config.DataBits = (int)cbDataBits.SelectedItem;
        }

        private void cbStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            _config.StopBits = (StopBits)cbStopBits.SelectedItem;
        }

        #endregion Form Events

        #region Methods

        private void UpdateUi()
        {
            if (_lkG5000 == null || !_lkG5000.IsOpen)
            {
                btnConnect.Enabled = true;
                btnDisconnct.Enabled = false;
                btnSend.Enabled = false;

                cbCom.Enabled = true;
                cbBaudRate.Enabled = true;
                cbParity.Enabled = true;
                cbStopBits.Enabled = true;
                cbDataBits.Enabled = true;
            }
            else
            {
                btnConnect.Enabled = false;
                btnDisconnct.Enabled = true;
                btnSend.Enabled = true;

                cbCom.Enabled = false;
                cbBaudRate.Enabled = false;
                cbParity.Enabled = false;
                cbStopBits.Enabled = false;
                cbDataBits.Enabled = false;
            }

            lblWaitingForResponse.Visible = _dataSended;
        }

        public new void Close()
        {
            if (_lkG5000 != null)
            {
                _lkG5000.Close();
                _lkG5000.Dispose();
                _lkG5000 = null;
            }
        }

        public void Open()
        {
            if (_lkG5000 != null && _lkG5000.IsOpen)
                return;

            _lkG5000 = new SerialPortService(_config);
            _lkG5000.Open();

            _lkG5000.StateChanged += (s, e) =>
            {
                // Handle state changes
                var newState = e.NewState;
                // React to state changes as needed
            };

            _lkG5000.DataReceived += (s, e) =>
            {
                string data = e.Data.Substring(0, e.Data.Length - 1);
                if (tbResponseCommand.InvokeRequired)
                {
                    tbResponseCommand.Invoke(new Action(() =>
                    {
                        tbResponseCommand.Text = data;
                    }));
                }
                else
                {
                    tbResponseCommand.Text = data;
                }
                //ParseData(data);
            };

            _lkG5000.ErrorOccurred += (s, e) =>
            {
                string errorType = e.ErrorType;
                string errorMessage = e.ErrorMessage;
                Exception exception = e.Exception;
                if (tbErrorMessage.InvokeRequired)
                {
                    tbErrorMessage.Invoke(new Action(() =>
                    {
                        tbErrorMessage.Text = $"{errorType}: {errorMessage}";
                    }));
                }
                else
                {
                    tbErrorMessage.Text = $"{errorType}: {errorMessage}";
                }

            };
        }

        private void ParseData(string data)
        {
            // 符號 + 7 bytes
            string resCommand = data;
            tbResponseCommand.Text = data;

            //if (resCommand.EndsWith("\r"))
            //    resCommand = resCommand.Substring(0, resCommand.Length - 1); // 去掉 CR

            //int responseLength = _sendCommand.SendParams.Length;
            //if (resCommand.Substring(0, responseLength) == _sendCommand.SendParams)
            //{
            //    _measuredString = resCommand.Substring(responseLength + 1, resCommand.Length - responseLength)
            //        .Split(',')
            //        .Where(s => !string.IsNullOrWhiteSpace(s))
            //        .ToList();

            //    // 收到回應
            //    _dataSended = false;
            //}
            //else
            //{
            //}
        }

        private void SendCommand(CommandStruct command)
        {
            //if (_dataSended) return;

            if (_lkG5000 != null && _lkG5000.IsOpen)
            {
                _sendCommand = command;
                string cs = command.CommandHead;
                if (!string.IsNullOrWhiteSpace(command.SendParams))
                {
                    cs += "," + tbParams.Text.Trim();
                }
                cs += "\r";
                _lkG5000.SendAscii(cs);
                //_lkG5000.Port.WriteLine(cs);
            }
        }

        #endregion Methods

        private void btnCopyCommand_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count > 0)
            {
                var selectedCommand = dgv.SelectedRows[0].DataBoundItem as CommandStruct;
                if (selectedCommand != null)
                {
                    tbCommandHead.Text = selectedCommand.CommandHead;
                    tbParams.Text = selectedCommand.SendParams;
                }
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string tbIC = tbCommandHead.Text.Trim();
            string tbPm = tbParams.Text.Trim();
            CommandStruct command = _commandList.FirstOrDefault(c => c.CommandHead == tbIC);

            if (command != null)
            {
                SendCommand(command);
                //tbResponseCommand.Clear();
                tbErrorMessage.Clear();
            }
            else
            {
                if (!string.IsNullOrEmpty(tbIC))
                {
                    SendCommand(new CommandStruct()
                    {
                        Id = 0,
                        CommandName = "自訂命令",
                        CommandHead = tbIC,
                        SendParams = tbPm,
                        ResponseParams = "",
                    });
                    //tbResponseCommand.Clear();
                    tbErrorMessage.Clear();
                }
            }
        }

        private void OrderManual(object sender, EventArgs e)
        {
            _selectionChangedEnabled = false;

            if (sender == rbOrderByManual)
            {
                _commandList = _commandList
                    .OrderBy(c => c.Id)
                    .ToList();
            }
            else if (sender == rbOrderByName)
            {
                _commandList = _commandList
                    .OrderBy(c => c.CommandName)
                    .ThenBy(c => c.Id)
                    .ToList();
            }
            else if (sender == rbOrderByCommand)
            {
                _commandList = _commandList
                    .OrderBy(c => c.CommandHead)
                    .ThenBy(c => c.Id)
                    .ToList();
            }

            dgv.DataSource = null;
            dgv.DataSource = _commandList;
            SelectCommandId();

            _selectionChangedEnabled = true;
        }

        private void dgv_SelectionChanged(object sender, EventArgs e)
        {
            if (!_selectionChangedEnabled) return;

            if (dgv.SelectedRows.Count > 0)
            {
                var selectedCommand = dgv.SelectedRows[0].DataBoundItem as CommandStruct;
                if (selectedCommand != null)
                    _selectedId = selectedCommand.Id;
            }
        }

        private void SelectCommandId()
        {
            if (_selectedId != null && _selectedId.HasValue)
            {
                foreach (DataGridViewRow row in dgv.Rows)
                {
                    var command = row.DataBoundItem as CommandStruct;
                    if (command != null && command.Id == _selectedId.Value)
                    {
                        row.Selected = true;
                        dgv.CurrentCell = row.Cells[0]; // 設定游標到該列的第一個儲存格
                        break;
                    }
                }
            }
        }

        private void btnCleanCommand_Click(object sender, EventArgs e)
        {
            CleanCommand();
        }

        private void CleanCommand()
        {
            tbCommandHead.Clear();
            tbParams.Clear();
            tbErrorMessage.Clear();
        }
    }
}
