﻿# Splash Screen

```text
你是WINFORM專業程式設計人員，使用.NET462+AUTOFAC+CommunityToolkit.Mvvm。
設計一個Splash Screen，並可以在APP載入完成之前，動態接收訊息並顯示在ListBix內。在任何地方的CLASS或MODULE都隨時可傳送訊息給Splash Screen。
訊息發送必須要能在builder.Build()之前就能使用，所以必須使用靜態方法來發送訊息，並且要使用非同步方式來更新UI，Splash Screen也必須在Autofac開始註冊之前顯示，顯示主Form之前關閉。
```