﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Krypton.Toolkit;

namespace WinFormDemo_Net48
{
    public partial class WinFormDemo_Net48 : KryptonForm
    {
        public WinFormDemo_Net48()
        {
            InitializeComponent();
        }


    }
}
