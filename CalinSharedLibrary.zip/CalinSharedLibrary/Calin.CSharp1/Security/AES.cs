﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Calin.CSharp.Security
{
    /// <summary>
    /// 進階加密標準（Advanced Encryption Standard，AES），又稱Rijndael加密法。
    /// </summary>
    /// <remarks>公鑰、密鑰最長 16 bytes。<br/>參見: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.security.cryptography.aes">Aes 類別</see>。</remarks>
    public static class AES
    {
        /// <summary>
        /// AES加密。
        /// </summary>
        /// <param name="plainText">待加密字串。</param>
        /// <param name="key">公鑰。</param>
        /// <param name="IV">密鑰。</param>
        /// <returns>加密後的Base64編碼字串。若為空字串表示演算失敗。</returns>
        public static string Encrypt(this string plainText, string key, string IV)
        {
            if (string.IsNullOrEmpty(plainText))
                throw new ArgumentException(null, nameof(plainText));
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException(null, nameof(key));
            if (string.IsNullOrEmpty(IV))
                throw new ArgumentException(null, nameof(IV));

            byte[] inputbyteArray = Encoding.UTF8.GetBytes(plainText);

            byte[] encrypted;
            using (var aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.UTF8.GetBytes(key.PadRight(16, ' ').Substring(0, 16));
                aesAlg.IV = Encoding.UTF8.GetBytes(IV.PadRight(16, ' ').Substring(0, 16));
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(encrypted);
        }

        /// <summary>
        /// AES解密。
        /// </summary>
        /// <param name="cipherText">待解密的Base64編碼字串。</param>
        /// <param name="key">公鑰 (128 bits=16 bytes)。</param>
        /// <param name="IV">密鑰 (128 bits=16 bytes)。</param>
        /// <returns>解密後的字串。若為空字串表示演算失敗。</returns>
        public static string Decrypt(this string cipherText, string key, string IV)
        {
            if (string.IsNullOrEmpty(cipherText))
                throw new ArgumentException(null, nameof(cipherText));
            if (string.IsNullOrEmpty(key))
                throw new ArgumentException(null, nameof(key));
            if (string.IsNullOrEmpty(IV))
                throw new ArgumentException(null, nameof(IV));

            string plaintext = null;
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.UTF8.GetBytes(key.PadRight(16, ' ').Substring(0, 16));
                aesAlg.IV = Encoding.UTF8.GetBytes(IV.PadRight(16, ' ').Substring(0, 16));

                byte[] inputbyteArray = new byte[cipherText.Replace(" ", "+").Length];
                inputbyteArray = Convert.FromBase64String(cipherText.Replace(" ", "+"));
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream msDecrypt = new MemoryStream(inputbyteArray))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
            return plaintext;
        }
    }
}
