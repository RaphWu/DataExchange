﻿using System.Globalization;

namespace Calin.CSharp.Helpers
{
    public static class StringExtensions
    {
        /// <summary>
        /// 字首大寫。
        /// </summary>
        public static string ToTitleCase(this string str)
        {
            if (string.IsNullOrWhiteSpace(str)) return str;
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower());
        }
    }
}
