﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Calin.CSharp.Extensions
{
    /*
     * 優點: 輕巧、簡單、速度比 BinaryFormatter 快上不少
     * 缺點: Private 欄位無法被複製到，遇到循環參考會出錯(解決方式可參考這篇: https://dotblogs.com.tw/wasichris/2015/12/03/152540 )
     */
    /// <summary>
    /// 使用Newtonsoft.Json的深層物件複製。
    /// </summary>
    /// <remarks>程式碼來源: <see href="https://linmasaki09.blogspot.com/2018/07/c-shallow-clonecopydeep-clonecopy.html">C# 建立物件的淺層複製（Shallow Clone/Copy）及深層複製（Deep Clone/Copy） - 2. 使用 Newtonsoft.Json 套件</see><br/>
    /// 參考: <see href="https://dotblogs.com.tw/wasichris/2015/12/03/152540">[C#] 深層複製(Deep Clone)功能實作及應用 - 使用Json.Net複製</see></remarks>
    public static class ObjectCloner
    {
        /// <summary>
        /// 深層複製
        /// </summary>
        /// <typeparam name="T">複製對象類別</typeparam>
        /// <param name="source">複製對象</param>
        /// <returns>複製出的物件。</returns>
        public static T DeepCloneByJson<T>(this T source)
        {
            if (source == null)
            {
                return default;
            }
            var deserializeSettings = new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace };
            return JsonConvert.DeserializeObject<T>(JsonConvert.SerializeObject(source), deserializeSettings);
        }
    }
}
