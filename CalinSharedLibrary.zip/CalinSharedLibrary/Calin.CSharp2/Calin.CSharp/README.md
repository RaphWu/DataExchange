# Calin內部程式庫: C#

## 專案設定

- 程式庫專案 -> 屬性
    - 目標 Framework
        - 為適應公司內部各種等級電腦，
    - 應用程式-> 組件資訊
        - 公司
            - 佳凌科技股份有限公司
        - 著作權
            - Copyright © 2025 Calin Technology Co.,Ltd.
        - 標題、描述、商標、版本...
            - 依需求輸入
    - 建置



|項目|內容|
|:--|:--|
|公司|佳凌科技股份有限公司 Calin Technology Co.,Ltd.|
|輸出路徑<br />Debug|`..\..\bin\x86\Debug\`<br />表示指向: `CalinSharedLibrary\bin\x86\Debug\`|
|輸出路徑<br />Release|`..\..\bin\x86\Release\`|

## 使用方法

請在專案中使用: 加入 -> 參考 -> 
