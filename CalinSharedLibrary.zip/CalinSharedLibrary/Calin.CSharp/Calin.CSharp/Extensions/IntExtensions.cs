﻿using System;

namespace Calin.CSharp.Extensions
{
    /// <summary>
    /// int 擴充功能。
    /// </summary>
    public static class IntExtensions
    {
        /// <summary>
        /// 向上調整到最近的 2 的次方
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        /// <remarks>.NET Core 3.0+ 或 .NET 5+，有內建可以使用: System.Numerics.BitOperations.RoundUpToPowerOf2(n);</remarks>
        public static int RoundUpToPowerOf2(int n)
        {
            if (n < 1)
                throw new ArgumentException("只能處理正整數");

            n--;
            n |= n >> 1;
            n |= n >> 2;
            n |= n >> 4;
            n |= n >> 8;
            n |= n >> 16;
            n++;
            return n;
        }

        /// <summary>
        /// 向下調整為最大小於等於它的 2 的次方
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        public static int RoundDownToPowerOf2(int n)
        {
            if (n < 1) throw new ArgumentException("只能處理正整數");

            int result = 1;
            while (result * 2 <= n)
                result *= 2;

            return result;
        }

        /// <summary>
        /// 四捨五入到最近的 2 的次方
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        public static int RoundToNearestPowerOf2(int n)
        {
            int up = RoundUpToPowerOf2(n);
            int down = RoundDownToPowerOf2(n);

            // 回傳距離最近的那個
            return (up - n) < (n - down) ? up : down;
        }
    }
}
