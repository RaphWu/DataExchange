﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

#pragma warning disable IDE0057 // 使用範圍運算子
#pragma warning disable IDE0028 // 簡化集合初始化
#pragma warning disable IDE0305 // 簡化集合初始化
namespace Calin.CSharp.Extensions
{
    /// <summary>
    /// string 擴充功能。
    /// </summary>
    public static class StringExtensions
    {
        /********************
         * 字串分割並清理空白與空字串
         ********************/
        /// <summary>
        /// Trim 模式。
        /// </summary>
        public enum TrimMode
        {
            None,
            Trim,
            TrimStart,
            TrimEnd
        }

        /// <summary>
        /// 字串分割並清理空白與空字串 (使用多字串分隔符)，能接在 LINQ 鏈式中間。
        /// </summary>
        /// <remarks><code><![CDATA[使用範例：
        /// 1. 支援多字串分隔符
        ///    var result = MachineCode.Text.SplitClean(
        ///        new[] { "»", ";", ",", "||", "--" }
        ///    );
        /// 
        /// 2. 使用 TrimStart（只 trim 左邊）
        ///    var result = MachineCode.Text.SplitClean(
        ///        new[] { ",", ";" },
        ///        StringExtensions.TrimMode.TrimStart
        ///    );
        /// 
        /// 3. 自訂过滤：只保留長度 >= 3 的字串
        ///    var result = MachineCode.Text.SplitClean(
        ///        new[] { ",", ";" },
        ///        StringExtensions.TrimMode.Trim,
        ///        s => s.Length >= 3
        ///    );
        /// ]]></code></remarks>
        public static List<string> SplitClean(this string input,
                                              IEnumerable<string> separators,
                                              TrimMode trimMode = TrimMode.Trim,
                                              Func<string, bool> additionalFilter = null)
        {
            if (input == null)
                return new List<string>();

            // 使用 Regex 支援多字串分隔符
            string pattern = string.Join("|", separators.Select(Regex.Escape));
            string[] parts = Regex.Split(input, pattern);

            var list = new List<string>();

            foreach (var p in parts)
            {
                string s = p;

                // Trim 模式
                switch (trimMode)
                {
                    case TrimMode.Trim:
                        s = s.Trim();
                        break;
                    case TrimMode.TrimStart:
                        s = s.TrimStart();
                        break;
                    case TrimMode.TrimEnd:
                        s = s.TrimEnd();
                        break;
                }

                // 去除空白、空字串
                if (string.IsNullOrWhiteSpace(s))
                    continue;

                // 如果有額外 filter
                if (additionalFilter != null && !additionalFilter(s))
                    continue;

                list.Add(s);
            }

            return list;
        }

        /// <summary>
        /// 字串分割並清理空白與空字串 (使用單一字元分隔符)，能接在 LINQ 鏈式中間。
        /// </summary>
        /// <param name="input"></param>
        /// <param name="separators"></param>
        /// <returns></returns>
        /// <remarks><code><![CDATA[使用範例：
        /// char[] seps = { '»', ';', ',' };
        /// var result = SomeString
        ///     .SplitClean('»', ';', ',')
        ///     .SplitClean(seps)
        ///     .OrderBy(x => x)
        ///     .ToList();
        /// ]]></code></remarks>
        public static List<string> SplitClean(this string input, params char[] separators)
        {
            if (input == null)
                return new List<string>();

            return input
                .Split(separators, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
        }

        /// <summary>
        /// 字串分割並清理空白與空字串 (使用單一字元分隔符)，只能放在 LINQ 鏈式開頭。
        /// </summary>
        /// <param name="input"></param>
        /// <param name="separators"></param>
        /// <returns></returns>
        /// <remarks><code><![CDATA[使用範例：
        /// var result = SplitCleanFast(SomeString, '»', ';', ',')
        ///     .OrderBy(x => x)
        ///     .ToList();
        /// ]]></code></remarks>
        public static List<string> SplitCleanFast(string input, params char[] separators)
        {
            var result = new List<string>();
            if (input == null) return result;

            var parts = input.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            foreach (var part in parts)
            {
                var trimmed = part.Trim();
                if (!string.IsNullOrWhiteSpace(trimmed))
                    result.Add(trimmed);
            }

            return result;
        }

        /// <summary>
        /// 將字串按指定的字元數進行換行。
        /// </summary>
        /// <param name="text">要換行的輸入字串。</param>
        /// <param name="lineWidth">每行的最大字元數。</param>
        /// <returns>換行後的字串。</returns>
        public static string WrapByCharCount(this string text, int lineWidth)
        {
            if (text == null) return "";

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < text.Length; i += lineWidth)
            {
                int len = Math.Min(lineWidth, text.Length - i);
                sb.AppendLine(text.Substring(i, len));
            }

            return sb.ToString();
        }

        /********************
         * 大小寫轉換
         ********************/
        /// <summary>
        /// 將字串改成字首大寫。
        /// </summary>
        /// <param name="str">要轉換的字串。</param>
        /// <returns>轉換後的字串。</returns>
        public static string ToTitleCase(this string str)
        {
            if (string.IsNullOrWhiteSpace(str)) return str;
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower());
        }

        /// <summary>
        /// 將字串改成句首大寫。
        /// </summary>
        /// <param name="str">要轉換的字串。</param>
        /// <returns>轉換後的字串。</returns>
        public static string ToSentenceCase(this string str)
        {
            if (string.IsNullOrWhiteSpace(str)) return str;
            str = str.ToLower();
            return char.ToUpper(str[0]) + str.Substring(1);
        }
    }
}
#pragma warning restore IDE0305 // 簡化集合初始化
#pragma warning restore IDE0028 // 簡化集合初始化
#pragma warning restore IDE0057 // 使用範圍運算子
