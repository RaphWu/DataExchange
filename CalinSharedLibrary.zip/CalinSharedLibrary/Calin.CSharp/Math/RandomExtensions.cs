﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calin.CSharp.Math
{
    /// <summary>
    /// 亂數產生器擴充。
    /// </summary>
    public static class RandomExtensions
    {
        /// <summary>
        /// 產生帶正負號的 64 位元整數亂數。
        /// </summary>
        /// <param name="random">亂數產生器。</param>
        /// <returns>long型態亂數。</returns>
        public static long NextLong(this Random random)
        {
            byte[] bytes = new byte[8];
            random.NextBytes(bytes);
            return BitConverter.ToInt64(bytes, 0);
        }

        /// <summary>
        /// 產生不帶正負號的 64 位元整數亂數。
        /// </summary>
        /// <param name="random">亂數產生器。</param>
        /// <returns>ulong型態亂數。</returns>
        public static ulong NextULong(this Random random)
        {
            byte[] bytes = new byte[8];
            random.NextBytes(bytes);
            return BitConverter.ToUInt64(bytes, 0);
        }
    }
}
