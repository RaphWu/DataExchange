﻿using System;

namespace Calin.Filter
{
    /// <summary>
    /// 低通濾波器。
    /// </summary>
    public class FilterLowPass
    {
        #region fields

        static object _lockLPF1 = new object();
        static object _lockLPF2 = new object();
        static bool fisrt_flag;

        // LPF_1
        static double _lastValue_LPF1;

        //LPF2
        static double[] lpf2_yout = new double[3] { 0, 0, 0 };
        static double[] lpf2_xin = new double[3] { 0, 0, 0 };

        #endregion

        public static void Reset()
        {
            fisrt_flag = true;

            // LPF_1
            _lastValue_LPF1 = 0.0;
        }

        #region 一階低通濾波

        /********************
         * https://blog.csdn.net/qq_37662088/article/details/125075600
         ********************/
        public static double LPF1_1(double xin, double cutoff_freq, double clockRate)
        {
            lock (_lockLPF1)
            {
                double ts = 1 / clockRate;  //取樣週期
                double b = 2.0 * Math.PI * cutoff_freq * ts;
                double alpha = b / (b + 1);

                if (fisrt_flag)
                {
                    fisrt_flag = false;
                    _lastValue_LPF1 = xin;
                }

                double outputValue = _lastValue_LPF1 + alpha * (xin - _lastValue_LPF1);
                _lastValue_LPF1 = outputValue;
                return outputValue;
            }
        }

        #endregion

        #region 二階低通濾波

        // https://blog.csdn.net/wwwyue1985/article/details/133243741

        public static double LPF2_1(double xin, double cutoff_freq, double clockRate)
        {
            lock (_lockLPF2)
            {
                const double Const_2pi = Math.PI * 2;   // 2π

                double wc = Const_2pi * cutoff_freq;    // 2πf
                double dampingRatio = 0.707;            // 阻尼比
                double ts = 1 / clockRate;              // 採樣週期

                double lpf2_b0 = wc * wc * ts * ts;
                double lpf2_a0 = 4 + 4 * dampingRatio * wc * ts + lpf2_b0;
                double lpf2_a1 = -8 + 2 * lpf2_b0;
                //double lpf2_a2 = 4 - 4*dampingRatio*wc*ts  + lpf2_a0; //原始这里应该有误
                double lpf2_a2 = lpf2_b0 + 4 - 4 * dampingRatio * wc * ts;

                lpf2_xin[2] = xin;
                lpf2_yout[2] = (lpf2_b0 * lpf2_xin[2] + 2 * lpf2_b0 * lpf2_xin[1] + lpf2_b0 * lpf2_xin[0] - lpf2_a1 * lpf2_yout[1] - lpf2_a2 * lpf2_yout[0]) / lpf2_a0;
                lpf2_xin[0] = lpf2_xin[1];
                lpf2_xin[1] = lpf2_xin[2];
                lpf2_yout[0] = lpf2_yout[1];
                lpf2_yout[1] = lpf2_yout[2];

                return lpf2_yout[2];
            }
        }

        public static double LPF2_2(double xin, double cutoff_freq, double clockRate)
        {
            lock (_lockLPF2)
            {
                double fr = clockRate / cutoff_freq;

                double ohm = Math.Tan(Math.PI * cutoff_freq / clockRate);
                double c = 1 + 1.414 * ohm + ohm * ohm;

                double b0 = ohm * ohm / c;
                double b1 = 2.0f * b0;
                double b2 = b0;

                double a1 = 2.0f * (ohm * ohm - 1.0f) / c;
                double a2 = (1.0f - 1.414 * ohm + ohm * ohm) / c;

                lpf2_xin[2] = xin;

                lpf2_yout[2] = b0 * lpf2_xin[2] + b1 * lpf2_xin[1] + b2 * lpf2_xin[0] - a1 * lpf2_yout[1] - a2 * lpf2_yout[0];

                lpf2_xin[0] = lpf2_xin[1];
                lpf2_xin[1] = lpf2_xin[2];
                lpf2_yout[0] = lpf2_yout[1];
                lpf2_yout[1] = lpf2_yout[2];

                return lpf2_yout[2];
            }
        }

        #endregion

    }
}
