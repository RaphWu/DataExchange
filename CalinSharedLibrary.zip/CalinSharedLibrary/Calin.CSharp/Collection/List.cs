﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Calin.CSharp.Collection
{
    public static class CollectionExtension
    {
        public static DataTable ToDataTable<T>(List<T> items)
        {
            var dataTable = new DataTable(typeof(T).Name);

            // 建立欄位（根據屬性）
            foreach (var prop in typeof(T).GetProperties())
            {
                var propType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                dataTable.Columns.Add(prop.Name, propType);
            }

            // 加入每一筆資料
            foreach (var item in items)
            {
                var values = new object[typeof(T).GetProperties().Length];
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = typeof(T).GetProperties()[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }
    }
}