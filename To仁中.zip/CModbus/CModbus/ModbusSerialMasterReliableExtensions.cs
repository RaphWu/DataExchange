﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace CModbus
{
    public static class ModbusSerialMasterReliableExtensions
    {
        /// <summary>
        /// 讀取保持暫存器，支援自動重試
        /// </summary>
        public static async Task<ushort[]> ReadHoldingRegistersReliableAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort quantity,
            int maxRetries = 3, int delayMs = 200, CancellationToken token = default)
        {
            int attempt = 0;
            while (true)
            {
                attempt++;
                try
                {
                    return await master.ReadHoldingRegistersBatchAsync(slaveAddress, startAddress, quantity, token);
                }
                catch (Exception ex) when (attempt <= maxRetries)
                {
                    master.OnError?.Invoke(new TimeoutException($"Retry {attempt}/{maxRetries}: {ex.Message}", ex));
                    await Task.Delay(delayMs, token);
                }
            }
        }

        /// <summary>
        /// 寫入多個保持暫存器，支援自動重試
        /// </summary>
        public static async Task WriteMultipleRegistersReliableAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort[] values,
            int maxRetries = 3, int delayMs = 200, CancellationToken token = default)
        {
            int attempt = 0;
            while (true)
            {
                attempt++;
                try
                {
                    await master.WriteMultipleRegistersBatchAsync(slaveAddress, startAddress, values, token);
                    return;
                }
                catch (Exception ex) when (attempt <= maxRetries)
                {
                    master.OnError?.Invoke(new TimeoutException($"Retry {attempt}/{maxRetries}: {ex.Message}", ex));
                    await Task.Delay(delayMs, token);
                }
            }
        }

        /// <summary>
        /// 高階並行讀，支援自動重試
        /// </summary>
        public static async Task<ushort[]> ReadHoldingRegistersParallelReliableAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort totalQuantity,
            int maxConcurrency = 4, int maxRetries = 3, int delayMs = 200,
            CancellationToken token = default)
        {
            int attempt = 0;
            while (true)
            {
                attempt++;
                try
                {
                    return await master.ReadHoldingRegistersParallelAsync(slaveAddress, startAddress, totalQuantity, maxConcurrency, token);
                }
                catch (Exception ex) when (attempt <= maxRetries)
                {
                    master.OnError?.Invoke(new TimeoutException($"Retry {attempt}/{maxRetries}: {ex.Message}", ex));
                    await Task.Delay(delayMs, token);
                }
            }
        }
    }
}
