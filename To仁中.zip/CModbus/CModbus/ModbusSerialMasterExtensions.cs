﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CModbus
{
    public static class ModbusSerialMasterExtensions
    {
        /// <summary>
        /// 讀取保持暫存器
        /// </summary>
        public static Task<ushort[]> ReadHoldingRegistersAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort quantity,
            CancellationToken token = default)
        {
            if (quantity < 1 || quantity > 125) throw new ArgumentOutOfRangeException(nameof(quantity));

            var pdu = EndianBitConverter.GetBytes(startAddress, ByteOrder.BigEndian)
                .Concat(EndianBitConverter.GetBytes(quantity, ByteOrder.BigEndian))
                .ToArray();

            return master.SendRequestAsync<ushort[]>(slaveAddress, 0x03, pdu,
                matchPredicate: frame =>
                {
                    if (frame.Payload.Length < 1) return false;
                    int byteCount = frame.Payload[0];
                    return byteCount == quantity * 2;
                }, userToken: token);
        }

        /// <summary>
        /// 寫入單一暫存器
        /// </summary>
        public static async Task WriteSingleRegisterAsync(this ModbusMaster master,
            byte slaveAddress, ushort address, ushort value,
            CancellationToken token = default)
        {
            var pdu = EndianBitConverter.GetBytes(address, ByteOrder.BigEndian)
                .Concat(EndianBitConverter.GetBytes(value, ByteOrder.BigEndian))
                .ToArray();

            await master.SendRequestAsync<byte[]>(slaveAddress, 0x06, pdu,
                matchPredicate: frame =>
                {
                    // 回應會 echo address+value
                    if (frame.Payload.Length != 4) return false;
                    ushort respAddr = EndianBitConverter.ToUInt16(frame.Payload, 0, ByteOrder.BigEndian);
                    ushort respVal = EndianBitConverter.ToUInt16(frame.Payload, 2, ByteOrder.BigEndian);
                    return respAddr == address && respVal == value;
                }, userToken: token);
        }

        /// <summary>
        /// 寫入多個暫存器
        /// </summary>
        public static async Task WriteMultipleRegistersAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort[] values,
            CancellationToken token = default)
        {
            if (values.Length < 1 || values.Length > 123) throw new ArgumentOutOfRangeException(nameof(values));

            var pdu = EndianBitConverter.GetBytes(startAddress, ByteOrder.BigEndian)
                .Concat(EndianBitConverter.GetBytes((ushort)values.Length, ByteOrder.BigEndian))
                .Concat(new byte[] { (byte)(values.Length * 2) })
                .Concat(values.SelectMany(v => EndianBitConverter.GetBytes(v, ByteOrder.BigEndian)))
                .ToArray();

            await master.SendRequestAsync<byte[]>(slaveAddress, 0x10, pdu,
                matchPredicate: frame =>
                {
                    // 回應會 echo startAddress+quantity
                    if (frame.Payload.Length != 4) return false;
                    ushort respAddr = EndianBitConverter.ToUInt16(frame.Payload, 0, ByteOrder.BigEndian);
                    ushort respQty = EndianBitConverter.ToUInt16(frame.Payload, 2, ByteOrder.BigEndian);
                    return respAddr == startAddress && respQty == values.Length;
                }, userToken: token);
        }
    }
}

/*
使用範例

using ModbusSerialLib;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        using var master = new ModbusMaster("COM3", 19200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);

        // 讀取保持暫存器
        ushort[] values = await master.ReadHoldingRegistersAsync(1, 0x0000, 2);
        Console.WriteLine($"Read: {string.Join(",", values)}");

        // 寫入單一暫存器
        await master.WriteSingleRegisterAsync(1, 0x0000, 1234);

        // 寫入多個暫存器
        await master.WriteMultipleRegistersAsync(1, 0x0001, new ushort[] { 1111, 2222 });
    }
}

這樣你就有一個 完整可用、支援 RTU/ASCII、多請求並行、高階 API 的 Modbus Serial Library 了。

*/