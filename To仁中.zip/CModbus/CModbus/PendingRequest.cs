﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace CModbus
{
    /*
     * 因為 Modbus RTU/ASCII 本身沒有「Transaction Id」欄位（不像 TCP 有），
     * 所以這裡要在 PendingRequest 內保留一個 匹配條件 (predicate)，收到 Frame 後逐一嘗試比對。
     * 這樣就可以在同一 Slave/Function 同時發多個不同範圍的讀取請求，也不會混淆。
     */

    /// <summary>
    /// 待處理的請求。
    /// </summary>
    internal class PendingRequest
    {
        public long RequestId { get; set; }
        public byte Slave { get; set; }
        public byte FunctionCode { get; set; }
        public TaskCompletionSource<byte[]> Completion { get; set; }
        public CancellationTokenSource Cancellation { get; set; }

        /// <summary>
        /// 用來判斷這個 Response 是否符合 Request 的條件
        /// 例如 (frame) => frame.Payload.Length == 預期長度 && frame.Address == Slave ...
        /// </summary>
        public Func<ModbusFrame, bool> MatchPredicate { get; set; }
    }
}
