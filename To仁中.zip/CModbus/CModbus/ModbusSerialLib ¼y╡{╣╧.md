﻿+------------------------+
|  UI / 上層程式呼叫 API |
|  (Read/Write Registers)|
+-----------+------------+
            |
            v
+------------------------+
| 高階 API (ReliableDefaultExtensions) |
| - 自動拆批 / 並行       |
| - 自動重試 / Timeout     |
+-----------+------------+
            |
            v
+------------------------+
| ReliableExtensions / BatchExtensions |
| - 拆分大批量請求        |
| - 併發多個批次          |
| - 重試邏輯              |
+-----------+------------+
            |
            v
+------------------------+
| 核心 ModbusMaster |
| - 建立 RTU/ASCII Frame |
| - 並行請求配對          |
| - CRC / LRC 驗證        |
| - ReadByte() 解析資料   |
+-----------+------------+
            |
            v
+------------------------+
| SerialPort IO (System.IO.Ports) |
| - 寫入 Frame              |
| - 讀取 Frame              |
+-----------+------------+
            |
            v
+------------------------+
| Frame Dispatcher / Parser |
| - 檢查 Slave + FunctionCode |
| - 泛型解析 Payload         |
| - 配對對應的 Pending Request |
+-----------+------------+
            |
            v
+------------------------+
| TaskCompletionSource     |
| - 將解析結果回傳給 UI    |
+------------------------+


說明：

1. UI / 上層程式
    - 呼叫 ReadHoldingRegistersAsync 或 WriteMultipleRegistersAsync
    - 不需要理會拆批、重試或串口細節
1. 高階 API
    - 自動可靠模式（拆批 + 並行 + 重試）
    - 底層呼叫 ReliableExtensions / BatchExtensions
1. 核心 Master
    - 負責 Frame 組裝（RTU/ASCII）、CRC/LRC 驗證
    - 讀取 SerialPort，解析每個 Byte
    - 配對多請求並行場景
1. SerialPort IO
    - 真正對硬體的寫入 / 讀取
    - 使用 ReadByte()，支援長時間運行
1. Frame Dispatcher / Parser
    - 將收到的 Frame 配對到對應的 Pending Request
    - 透過泛型解析 Payload
1. TaskCompletionSource
    - 將結果回傳給 UI
    - 支援 await 語法

這張圖完整涵蓋了：

- 底層通訊
- 多請求配對
- 可靠模式
- 批次拆分 / 並行
- UI 簡單使用