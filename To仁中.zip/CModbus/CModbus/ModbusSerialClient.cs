﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CModbus
{
    public class ModbusMaster : IDisposable
    {
        private readonly SerialPort _port;
        private readonly ModbusMode _mode;
        private readonly ByteOrder _byteOrder;
        private readonly ReusableCancellationTokenSource _readerCts = new ReusableCancellationTokenSource();
        private readonly ConcurrentDictionary<long, PendingRequest> _pending = new ConcurrentDictionary<long, PendingRequest>();
        private readonly ConcurrentDictionary<byte, Func<byte[], object>> _parsers = new ConcurrentDictionary<byte, Func<byte[], object>>();
        private Task _readerTask;
        private bool _disposed = false;
        private int _nextRequestId = 1;
        private readonly object _sendLock = new object();

        public int ReadByteTimeoutMs { get; set; } = 2000;
        public event Action<ModbusFrame> FrameReceived;
        public event Action<Exception> OnError;

        public ModbusMaster(string portName, int baudRate, Parity parity, int dataBits, StopBits stopBits,
            ModbusMode mode = ModbusMode.ASCII, ByteOrder byteOrder = ByteOrder.BigEndian)
        {
            _mode = mode;
            _byteOrder = byteOrder;
            _port = new SerialPort(portName, baudRate, parity, dataBits, stopBits)
            {
                ReadTimeout = ReadByteTimeoutMs,
                WriteTimeout = 2000
            };
            _port.Open();
            StartReaderLoop();
        }

        #region Parser registration
        public void RegisterParser<T>(byte functionCode, Func<byte[], T> parser)
        {
            _parsers[functionCode] = (b) => parser(b);
        }
        #endregion

        #region SendRequest (with stronger match logic)
        public async Task<T> SendRequestAsync<T>(byte slaveAddress, byte functionCode, byte[] pduPayload,
            Func<ModbusFrame, bool> matchPredicate, int timeoutMs = 5000, CancellationToken userToken = default)
        {
            ThrowIfDisposed();
            var reqId = Interlocked.Increment(ref _nextRequestId);
            var tcs = new TaskCompletionSource<byte[]>(TaskCreationOptions.RunContinuationsAsynchronously);
            var pending = new PendingRequest
            {
                RequestId = reqId,
                Slave = slaveAddress,
                FunctionCode = functionCode,
                Completion = tcs,
                Cancellation = new CancellationTokenSource(timeoutMs),
                MatchPredicate = matchPredicate
            };
            _pending[reqId] = pending;

            var linked = CancellationTokenSource.CreateLinkedTokenSource(pending.Cancellation.Token, userToken);
            linked.Token.Register(() =>
            {
                _pending.TryRemove(reqId, out _);
                tcs.TrySetCanceled();
            });

            try
            {
                var frame = BuildRequestFrame(slaveAddress, functionCode, pduPayload);
                lock (_sendLock) { _port.Write(frame, 0, frame.Length); }

                var responseBytes = await tcs.Task.ConfigureAwait(false);
                if (_parsers.TryGetValue(functionCode, out var parser))
                {
                    var obj = parser(responseBytes);
                    if (obj is T t) return t;
                    return (T)obj;
                }
                else
                {
                    if (typeof(T) == typeof(byte[]))
                        return (T)(object)responseBytes;
                    throw new InvalidOperationException($"No parser registered for function code 0x{functionCode:X2}");
                }
            }
            finally
            {
                _pending.TryRemove(reqId, out _);
            }
        }
        #endregion

        #region Reader dispatch
        private void DispatchFrame(ModbusFrame frame)
        {
            FrameReceived?.Invoke(frame);

            foreach (var kv in _pending.ToArray())
            {
                var req = kv.Value;
                if (req.Slave == frame.Address &&
                    req.FunctionCode == frame.FunctionCode &&
                    req.MatchPredicate?.Invoke(frame) == true)
                {
                    req.Completion.TrySetResult(frame.Payload);
                    _pending.TryRemove(req.RequestId, out _);
                }
            }
        }
        #endregion

        #region Build request frame
        private byte[] BuildRequestFrame(byte slave, byte functionCode, byte[] payload)
        {
            byte[] body = new byte[2 + payload.Length];
            body[0] = slave;
            body[1] = functionCode;
            Array.Copy(payload, 0, body, 2, payload.Length);

            if (_mode == ModbusMode.RTU)
            {
                ushort crc = CalcCrc16(body, 0, body.Length);
                var frame = new byte[body.Length + 2];
                Array.Copy(body, 0, frame, 0, body.Length);
                frame[body.Length] = (byte)(crc & 0xFF);
                frame[body.Length + 1] = (byte)(crc >> 8);
                return frame;
            }
            else // ASCII
            {
                byte lrc = CalcLrc(body, 0, body.Length);
                var frame = new List<byte>();
                frame.Add((byte)':');
                foreach (var b in body.Concat(new byte[] { lrc }))
                {
                    frame.AddRange(Encoding.ASCII.GetBytes(b.ToString("X2")));
                }
                frame.AddRange(new byte[] { 0x0D, 0x0A }); // CRLF
                return frame.ToArray();
            }
        }
        #endregion

        #region Reader loop
        private void StartReaderLoop()
        {
            _readerTask = Task.Run(async () =>
            {
                var token = _readerCts.Token;
                try
                {
                    while (!token.IsCancellationRequested)
                    {
                        ModbusFrame frame = null;
                        try
                        {
                            frame = await ReadFrameAsync(token).ConfigureAwait(false);
                        }
                        catch (TimeoutException) { continue; }
                        catch (OperationCanceledException) { break; }
                        catch (Exception ex) { OnError?.Invoke(ex); continue; }

                        if (frame != null) DispatchFrame(frame);
                    }
                }
                catch (Exception ex)
                {
                    OnError?.Invoke(ex);
                }
            }, _readerCts.Token);
        }

        private async Task<ModbusFrame> ReadFrameAsync(CancellationToken token)
        {
            if (_mode == ModbusMode.RTU)
                return await ReadRtuFrameAsync(token).ConfigureAwait(false);
            else
                return await ReadAsciiFrameAsync(token).ConfigureAwait(false);
        }

        private async Task<ModbusFrame> ReadRtuFrameAsync(CancellationToken token)
        {
            byte slave = await ReadByteAsync(token);
            byte func = await ReadByteAsync(token);

            var payload = new List<byte>();
            // 嘗試讀到至少一個 ByteCount / Data 或 ErrorCode
            payload.Add(await ReadByteAsync(token));

            // 暫時假設不知長度 -> 繼續讀到至少 2 bytes CRC
            while (_port.BytesToRead < 2)
            {
                await Task.Delay(1, token);
            }

            while (_port.BytesToRead > 2)
            {
                payload.Add((byte)_port.ReadByte());
            }

            byte crcLo = (byte)_port.ReadByte();
            byte crcHi = (byte)_port.ReadByte();
            ushort recvCrc = (ushort)(crcLo | (crcHi << 8));

            var body = new byte[2 + payload.Count];
            body[0] = slave;
            body[1] = func;
            payload.CopyTo(body, 2);

            ushort calcCrc = CalcCrc16(body, 0, body.Length);
            if (calcCrc != recvCrc)
                throw new InvalidOperationException("CRC check failed");

            return new ModbusFrame { Address = slave, FunctionCode = func, Payload = payload.ToArray(), Raw = body };
        }

        private async Task<ModbusFrame> ReadAsciiFrameAsync(CancellationToken token)
        {
            int start = await ReadByteAsync(token);
            if (start != ':') throw new InvalidOperationException("ASCII frame missing ':'");

            var hex = new List<byte>();
            while (true)
            {
                int b = await ReadByteAsync(token);
                if (b == 0x0D) // CR
                {
                    int lf = await ReadByteAsync(token);
                    if (lf != 0x0A) throw new InvalidOperationException("ASCII frame missing LF");
                    break;
                }
                hex.Add((byte)b);
            }

            byte[] bytes = new byte[hex.Count / 2];
            for (int i = 0; i < bytes.Length; i++)
            {
                string hs = Encoding.ASCII.GetString(hex.Skip(i * 2).Take(2).ToArray());
                bytes[i] = Convert.ToByte(hs, 16);
            }

            byte slave = bytes[0];
            byte func = bytes[1];
            byte[] payload = bytes.Skip(2).Take(bytes.Length - 3).ToArray(); // exclude LRC
            byte recvLrc = bytes.Last();
            byte calcLrc = CalcLrc(bytes, 0, bytes.Length - 1);
            if (recvLrc != calcLrc) throw new InvalidOperationException("LRC check failed");

            return new ModbusFrame { Address = slave, FunctionCode = func, Payload = payload, Raw = bytes };
        }
        #endregion

        #region IO Helpers
        private async Task<byte> ReadByteAsync(CancellationToken token)
        {
            return await Task.Run(() =>
            {
                int b = _port.ReadByte();
                if (b < 0) throw new TimeoutException();
                return (byte)b;
            }, token);
        }

        private static ushort CalcCrc16(byte[] buffer, int offset, int length)
        {
            const ushort poly = 0xA001;
            ushort crc = 0xFFFF;
            for (int i = 0; i < length; i++)
            {
                crc ^= buffer[offset + i];
                for (int j = 0; j < 8; j++)
                {
                    bool lsb = (crc & 1) != 0;
                    crc >>= 1;
                    if (lsb) crc ^= poly;
                }
            }
            return crc;
        }

        private static byte CalcLrc(byte[] buffer, int offset, int length)
        {
            byte lrc = 0;
            for (int i = offset; i < offset + length; i++)
                lrc += buffer[i];
            lrc = (byte)((-(sbyte)lrc) & 0xFF);
            return lrc;
        }
        #endregion

        #region Dispose
        private void ThrowIfDisposed()
        {
            if (_disposed) throw new ObjectDisposedException(nameof(ModbusMaster));
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            _readerCts.Cancel();
            try { _readerTask?.Wait(2000); } catch { }

            _port?.Close();
            _port?.Dispose();
            _readerCts.Dispose();

            foreach (var kv in _pending)
                kv.Value.Completion.TrySetCanceled();
        }
        #endregion
    }
}
