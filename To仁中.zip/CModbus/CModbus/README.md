﻿✅ 支援 RTU/ASCII
✅ 使用 ReusableCancellationTokenSource
✅ 可長時間背景運行
✅ 泛型 Parser
✅ 多請求並行 + 強化配對


使用範例

using ModbusSerialLib;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        using var master = new ModbusMaster("COM3", 19200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);

        // 高階可靠模式讀取大批量寄存器
        ushort[] readValues = await master.ReadHoldingRegistersAsync(1, 0x0000, 500);
        Console.WriteLine($"Reliable read {readValues.Length} registers");

        // 高階可靠模式寫入多個暫存器
        ushort[] writeValues = new ushort[250];
        for (int i = 0; i < 250; i++) writeValues[i] = (ushort)(i + 500);
        await master.WriteMultipleRegistersAsync(1, 0x0000, writeValues);
        Console.WriteLine("Reliable write completed");

        // 單一暫存器寫入也自動可靠
        await master.WriteSingleRegisterAsync(1, 0x0000, 1234);
        Console.WriteLine("Reliable single register write completed");
    }
}


特性總結

- 可靠模式預設：高階 API 自動拆批、並行、重試
- RTU / ASCII 支援
- 底層多請求並行配對
- 自動重試 + Timeout 重送
- 大小端自動處理
- Frame 泛型解析
- TaskCompletionSource 回傳結果，UI 只需 await

