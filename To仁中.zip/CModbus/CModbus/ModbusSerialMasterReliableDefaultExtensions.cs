﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace CModbus
{
    public static class ModbusSerialMasterReliableDefaultExtensions
    {
        private const int DefaultMaxRetries = 3;
        private const int DefaultRetryDelayMs = 200;

        /// <summary>
        /// 可靠模式讀保持暫存器（預設拆批 + 重試）
        /// </summary>
        public static Task<ushort[]> ReadHoldingRegistersAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort quantity,
            CancellationToken token = default)
        {
            return master.ReadHoldingRegistersReliableAsync(slaveAddress, startAddress, quantity,
                DefaultMaxRetries, DefaultRetryDelayMs, token);
        }

        /// <summary>
        /// 可靠模式寫多個暫存器（預設拆批 + 重試）
        /// </summary>
        public static Task WriteMultipleRegistersAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort[] values,
            CancellationToken token = default)
        {
            return master.WriteMultipleRegistersReliableAsync(slaveAddress, startAddress, values,
                DefaultMaxRetries, DefaultRetryDelayMs, token);
        }

        /// <summary>
        /// 可靠模式大批量並行讀（預設拆批 + 重試 + 並行）
        /// </summary>
        public static Task<ushort[]> ReadHoldingRegistersParallelAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort totalQuantity,
            int maxConcurrency = 4, CancellationToken token = default)
        {
            return master.ReadHoldingRegistersParallelReliableAsync(slaveAddress, startAddress, totalQuantity,
                maxConcurrency, DefaultMaxRetries, DefaultRetryDelayMs, token);
        }

        /// <summary>
        /// 單一暫存器寫入保持暫存器也可靠
        /// </summary>
        public static Task WriteSingleRegisterAsync(this ModbusMaster master,
            byte slaveAddress, ushort address, ushort value,
            CancellationToken token = default)
        {
            return master.WriteSingleRegisterReliableAsync(slaveAddress, address, value,
                DefaultMaxRetries, DefaultRetryDelayMs, token);
        }

        /// <summary>
        /// 單一暫存器可靠寫入
        /// </summary>
        public static async Task WriteSingleRegisterReliableAsync(this ModbusMaster master,
            byte slaveAddress, ushort address, ushort value,
            int maxRetries, int delayMs, CancellationToken token = default)
        {
            int attempt = 0;
            while (true)
            {
                attempt++;
                try
                {
                    await master.WriteSingleRegisterAsync(slaveAddress, address, value, token);
                    return;
                }
                catch (Exception ex) when (attempt <= maxRetries)
                {
                    master.OnError?.Invoke(new TimeoutException($"Retry {attempt}/{maxRetries}: {ex.Message}", ex));
                    await Task.Delay(delayMs, token);
                }
            }
        }
    }
}

/*
使用範例

using ModbusSerialLib;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        using var master = new ModbusMaster("COM3", 19200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);

        // 讀取大批量，可靠模式
        ushort[] reliableRead = await master.ReadHoldingRegistersReliableAsync(1, 0x0000, 300, maxRetries: 5, delayMs: 300);
        Console.WriteLine($"Reliable read {reliableRead.Length} registers");

        // 寫入大批量，可靠模式
        ushort[] valuesToWrite = new ushort[250];
        for (int i = 0; i < 250; i++) valuesToWrite[i] = (ushort)(i + 100);
        await master.WriteMultipleRegistersReliableAsync(1, 0x0000, valuesToWrite, maxRetries: 5, delayMs: 300);
        Console.WriteLine("Reliable batch write completed");
    }
}

特點

1. 自動重試：遇到 Timeout、CRC/LRC 錯誤或其它 Exception 都會自動重送
1. 延遲可配置：避免連續重送造成線路塞爆
1. 並行批次也可靠：支援拆分 + 並行 + 重試
1. 錯誤回報：透過 OnError 事件通知使用者


這樣整個 Library 就完整了：

- 底層可靠讀寫（RTU/ASCII）
- 多請求並行 + 泛型解析
- 批次拆分 + 並行
- 自動重試 + Timeout 重送
- 高階 API 統一可靠模式
- 整個 UI 或自動化系統使用起來非常安全且穩定。

*/