﻿UI / 上層程式         高階 API          核心 Master        SerialPort IO       Frame Dispatcher
   |                    |                   |                   |                   |
   | ReadHoldingRegistersAsync()             |                   |                   |
   |--------------------------------------->|                   |                   |
   |                                        |                   |                   |
   |                                        |拆分大批量/併發請求  |                   |
   |                                        |------------------>|                   |
   |                                        |                   | Write Frame       |
   |                                        |                   |----------------->|
   |                                        |                   |                   |
   |                                        |                   | Read Bytes        |
   |                                        |                   |<-----------------|
   |                                        | 收到 Frame        |                   |
   |                                        |<------------------|                   |
   |                                        | 配對 Pending Req   |                   |
   |                                        |                   |                   |
   |                                        | 泛型解析 Payload    |                   |
   |                                        |                   |                   |
   |<---------------------------------------|                   |                   |
   | 回傳解析結果 (TaskCompletionSource.SetResult) |             |                   |
   |                                        |                   |                   |
   |            如果 Timeout/CRC錯誤       |                   |                   |
   |            自動重試                  |------------------>|                   |
   |                                        |                   | 重送 Frame       |
   |                                        |                   |<-----------------|
   |                                        |                   |                   |
   |<---------------------------------------|                   |                   |
   | 回傳解析結果 (最終成功或例外)        |                   |                   |


流程說明

1. UI / 上層程式 呼叫高階 API，底層完全可靠
1. 高階 API 自動拆分大批量寄存器、產生多個並行請求
1. 核心 Master 負責 Frame 組裝（RTU/ASCII）、CRC/LRC 驗證、請求配對
1. SerialPort IO 負責真正的寫入與讀取，使用 ReadByte() 支援長時間運行
1. Frame Dispatcher 將收到的 Frame 配對到對應的 Pending Request，泛型解析 Payload
1. 自動重試機制：遇到 Timeout、CRC/LRC 錯誤，自動重送 Frame
1. TaskCompletionSource 回傳結果給 UI，支援 await

這張序列圖能清楚看到：

- 拆批、並行、重試 流程
- 底層串口讀寫 與 Frame 配對
- UI 層只需 await，高階 API 自動處理可靠性