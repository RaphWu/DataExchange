﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CModbus
{
    public static class ModbusSerialMasterBatchExtensions
    {
        /// <summary>
        /// 讀取大批量保持暫存器，自動拆分每次 <= 125
        /// </summary>
        public static async Task<ushort[]> ReadHoldingRegistersBatchAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort totalQuantity,
            CancellationToken token = default)
        {
            if (totalQuantity < 1) throw new ArgumentOutOfRangeException(nameof(totalQuantity));

            const ushort MaxPerRequest = 125;
            var results = new List<ushort>();
            ushort currentAddr = startAddress;
            int remaining = totalQuantity;

            while (remaining > 0)
            {
                ushort qty = (ushort)Math.Min(MaxPerRequest, remaining);
                ushort[] batch = await master.ReadHoldingRegistersAsync(slaveAddress, currentAddr, qty, token);
                results.AddRange(batch);

                currentAddr += qty;
                remaining -= qty;
            }

            return results.ToArray();
        }

        /// <summary>
        /// 寫入大批量保持暫存器，自動拆分每次 <= 123
        /// </summary>
        public static async Task WriteMultipleRegistersBatchAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort[] values,
            CancellationToken token = default)
        {
            if (values == null || values.Length == 0) throw new ArgumentNullException(nameof(values));

            const int MaxPerRequest = 123;
            ushort currentAddr = startAddress;
            int offset = 0;

            while (offset < values.Length)
            {
                int batchSize = Math.Min(MaxPerRequest, values.Length - offset);
                ushort[] batchValues = values.Skip(offset).Take(batchSize).ToArray();

                await master.WriteMultipleRegistersAsync(slaveAddress, currentAddr, batchValues, token);

                currentAddr += (ushort)batchSize;
                offset += batchSize;
            }
        }

        /// <summary>
        /// 讀取大批量保持暫存器，並行多個批次（例如總數量很大時加速）
        /// </summary>
        public static async Task<ushort[]> ReadHoldingRegistersParallelAsync(this ModbusMaster master,
            byte slaveAddress, ushort startAddress, ushort totalQuantity, int maxConcurrency = 4,
            CancellationToken token = default)
        {
            if (totalQuantity < 1) throw new ArgumentOutOfRangeException(nameof(totalQuantity));
            if (maxConcurrency < 1) maxConcurrency = 1;

            const ushort MaxPerRequest = 125;
            var batches = new List<(ushort start, ushort qty)>();
            ushort currentAddr = startAddress;
            int remaining = totalQuantity;

            while (remaining > 0)
            {
                ushort qty = (ushort)Math.Min(MaxPerRequest, remaining);
                batches.Add((currentAddr, qty));
                currentAddr += qty;
                remaining -= qty;
            }

            var results = new ushort[totalQuantity];
            var tasks = new List<Task>();

            using (var semaphore = new SemaphoreSlim(maxConcurrency))
            {
                int index = 0;
                foreach (var batch in batches)
                {
                    await semaphore.WaitAsync(token);
                    int batchIndex = index;
                    tasks.Add(Task.Run(async () =>
                    {
                        try
                        {
                            var batchResult = await master.ReadHoldingRegistersAsync(slaveAddress, batch.start, batch.qty, token);
                            Array.Copy(batchResult, 0, results, batchIndex, batch.qty);
                        }
                        finally
                        {
                            semaphore.Release();
                        }
                    }, token));
                    index += batch.qty;
                }

                await Task.WhenAll(tasks);
            }

            return results;
        }
    }
}


/*
使用範例

using ModbusSerialLib;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        using var master = new ModbusMaster("COM3", 19200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);

        // 單純拆批順序讀
        ushort[] bigRead = await master.ReadHoldingRegistersBatchAsync(1, 0x0000, 300);
        Console.WriteLine($"Batch read {bigRead.Length} registers");

        // 拆批並行讀
        ushort[] parallelRead = await master.ReadHoldingRegistersParallelAsync(1, 0x0000, 300, maxConcurrency: 4);
        Console.WriteLine($"Parallel read {parallelRead.Length} registers");

        // 大批量寫入
        ushort[] valuesToWrite = new ushort[250];
        for (int i = 0; i < 250; i++) valuesToWrite[i] = (ushort)(i + 100);
        await master.WriteMultipleRegistersBatchAsync(1, 0x0000, valuesToWrite);
        Console.WriteLine("Batch write completed");
    }
}


這樣你就有完整的 高階 API + 大量資料拆批 + 並行處理 的功能了。

*/