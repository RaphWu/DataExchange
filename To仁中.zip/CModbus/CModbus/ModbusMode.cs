﻿namespace CModbus
{
    public enum ModbusMode
    {
        ASCII,
        RTU,
    }
}
