﻿+------------------------------------------------+
|                ModbusMaster             |
|------------------------------------------------|
| - SerialPort _serial                            |
| - ModbusMode Mode                               |
| - Dictionary<PendingRequest> _pendingRequests |
| - ReusableCancellationTokenSource _cts         |
|------------------------------------------------|
| + SendRequestAsync<T>(...)                     |
| + Dispose()                                    |
| + OnError(Event)                               |
+------------------------------------------------+
                ^         ^
                |         |
                |         |
+---------------+         +----------------+
|                                        |
|                                        |
+-----------------------------+  +------------------------------+
| ModbusMaster.Extensions |  | ModbusMaster.BatchExtensions |
|-------------------------------|  |----------------------------------|
| + ReadHoldingRegistersAsync()  |  | + ReadHoldingRegistersBatchAsync() |
| + WriteSingleRegisterAsync()   |  | + WriteMultipleRegistersBatchAsync()|
| + WriteMultipleRegistersAsync()|  | + ReadHoldingRegistersParallelAsync()|
+-------------------------------+  +----------------------------------+
                ^
                |
+-------------------------------+
| ModbusMaster.ReliableExtensions |
|--------------------------------------|
| + ReadHoldingRegistersReliableAsync() |
| + WriteMultipleRegistersReliableAsync()|
| + ReadHoldingRegistersParallelReliableAsync()|
+--------------------------------------+
                ^
                |
+---------------------------------------------+
| ModbusMaster.ReliableDefaultExtensions|
|---------------------------------------------|
| + ReadHoldingRegistersAsync()               |
| + WriteMultipleRegistersAsync()             |
| + WriteSingleRegisterAsync()                |
+---------------------------------------------+

+-----------------+       +------------------+
| EndianBitConverter |    | ReusableCancellationTokenSource |
|------------------|     |---------------------------------|
| + ToBytes(...)    |    | + Token                        |
| + ToUInt16(...)   |    | + Reset()                       |
+-----------------+      +------------------+

+-----------------+
| ModbusFrame     |
|-----------------|
| - SlaveAddress  |
| - FunctionCode  |
| - Payload       |
| - CRC/LRC       |
+-----------------+


說明

1. ModbusMaster
    - 核心類別，負責串口 IO、Frame 組裝、配對請求
    - 持有 ReusableCancellationTokenSource 用於取消任務
    - OnError 提供錯誤回報
1. Extensions 系列
    - Extensions：提供基本高階 API
    - BatchExtensions：拆分大批量 + 並行批次
    - ReliableExtensions：加入自動重試與 Timeout
    - ReliableDefaultExtensions：高階 API 統一可靠模式，UI 可直接使用
1. ModbusFrame
    - 封裝 Modbus Frame，包含 Slave、Function Code、Payload 與 CRC/LRC
1. EndianBitConverter
    - 大小端轉換工具
1. ReusableCancellationTokenSource
    - 可重複使用的 CancellationTokenSource，支援長時間運行



這張圖可以快速理解：

- 誰是核心 Master
- 哪些 class 提供 API 擴充
- 批次/可靠/高階 API 的繼承關係
- 工具類別與資料封裝類別

主要方法名稱與功能

- ModbusMaster
    - SendRequestAsync<T>：發送 Modbus 請求，等待並行配對結果
    - Dispose()：釋放 SerialPort 與資源
    - OnError(Event)：錯誤回報事件

ModbusMaster.Extensions
    - ReadHoldingRegistersAsync()：讀取保持寄存器
    - WriteSingleRegisterAsync()：寫入單一寄存器
    - WriteMultipleRegistersAsync()：寫入多個寄存器

ModbusMaster.BatchExtensions
    - ReadHoldingRegistersBatchAsync()：拆分大批量讀取保持寄存器
    - WriteMultipleRegistersBatchAsync()：拆分大批量寫入多個寄存器
    - ReadHoldingRegistersParallelAsync()：並行讀取多個批次保持寄存器

ModbusMaster.ReliableExtensions
    - ReadHoldingRegistersReliableAsync()：可靠模式讀取保持寄存器（自動重試 + Timeout）
    - WriteMultipleRegistersReliableAsync()：可靠模式寫入多個寄存器
    - ReadHoldingRegistersParallelReliableAsync()：可靠模式並行讀取多個批次保持寄存器

ModbusMaster.ReliableDefaultExtensions
    - ReadHoldingRegistersAsync()：可靠模式讀取保持寄存器（全局或覆寫重試參數）
    - WriteMultipleRegistersAsync()：可靠模式寫入多個寄存器
    - WriteSingleRegisterAsync()：可靠模式寫入單一寄存器
    - EndianBitConverter
    - ToBytes(...)：將 ushort/int 轉為 byte[]，支援大小端
    - ToUInt16(...)：將 byte[] 轉為 ushort，支援大小端
    - ReusableCancellationTokenSource
    - Token：取得 CancellationToken
    - Reset()：重置 CancellationTokenSource，支援重複使用

這些方法名稱與功能可以幫助理解每個類別的責任與用途。
        
