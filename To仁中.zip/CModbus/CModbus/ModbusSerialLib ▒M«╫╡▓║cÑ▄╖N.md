﻿ModbusSerialLib/
│
├─ ModbusMaster.cs          // 核心 Serial Port Modbus Master
│    ├─ RTU/ASCII 支援
│    ├─ Reader Loop
│    ├─ CRC / LRC 計算
│    ├─ IDisposable
│    └─ 多請求並行配對邏輯
│
├─ ModbusMaster.Extensions.cs       // 完整可用、支援 RTU/ASCII、多請求並行、高階 API 的 Modbus Serial Library
│    ├─ ReadHoldingRegistersAsync
│    ├─ WriteSingleRegisterAsync
│    └─ WriteMultipleRegistersAsync
│
├─ ModbusMaster.BatchExtensions.cs  // 高階 API + 大量資料拆批 + 並行處理 的功能
│    ├─ ReadHoldingRegistersBatchAsync
│    ├─ WriteMultipleRegistersBatchAsync
│    └─ ReadHoldingRegistersParallelAsync
│
├─ ModbusMaster.ReliableExtensions.cs      // 自動重試 + Timeout，延遲可配置，並行批次也可靠：支援拆分 + 並行 + 重試，錯誤回報
│    ├─ ReadHoldingRegistersReliableAsync
│    ├─ WriteMultipleRegistersReliableAsync
│    └─ ReadHoldingRegistersParallelReliableAsync
│
├─ ModbusMaster.ReliableDefaultExtensions.cs  // 高階 API 統一可靠模式，可配置重試次數與延遲（全局或覆寫參數），錯誤回報，單一 API
│    ├─ ReadHoldingRegistersAsync  // 現在已經自動可靠
│    ├─ WriteMultipleRegistersAsync
│    └─ WriteSingleRegisterAsync
│
├─ ModbusTypes.cs                  // 小型輔助類別 / enum
│    ├─ ModbusFrame
│    ├─ ModbusMode (RTU / ASCII)
│    └─ ByteOrder (BigEndian / LittleEndian)
│
├─ EndianBitConverter.cs           // 大小端轉換工具
│    ├─ ToBytes(ushort/int, ByteOrder)
│    └─ ToUInt16/UInt32(byte[], ByteOrder)
│
└─ ReusableCancellationTokenSource.cs   // 可重複使用的 CancellationTokenSource


使用建議

1. 核心 Master (ModbusMaster.cs) 負責串口通訊、底層解析、並行配對
1. Extensions 提供常用 Modbus 功能，UI 直接使用，不必自己組 PDU
1. BatchExtensions 負責自動拆分大批量寄存器
1. ReliableExtensions 增加重試 / Timeout 功能
1. ReliableDefaultExtensions 將高階 API 統一成可靠模式，使用者呼叫最簡單


最佳組合使用

```csharp
using ModbusSerialLib;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        using var master = new ModbusMaster("COM3", 19200, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);

        // UI 呼叫高階 API，底層自動可靠 + 拆批 + 並行
        ushort[] readValues = await master.ReadHoldingRegistersAsync(1, 0x0000, 500);
        await master.WriteMultipleRegistersAsync(1, 0x0100, readValues);

        // 單一暫存器寫入也自動可靠
        await master.WriteSingleRegisterAsync(1, 0x0000, 1234);
    }
}
```

這樣整個 Library 結構就清楚了：

- 底層：穩定 RTU/ASCII + 多請求配對
- 中層：批次拆分 + 並行
- 高層：可靠模式 + 高階 API
- 最終使用：UI 或自動化程式只需呼叫 ReadHoldingRegistersAsync / WriteMultipleRegistersAsync 即可



這樣的設計讓使用者只需關注高階 API，底層的可靠性、拆批、並行等細節都由庫自動處理，大大簡化了 Modbus 通訊的使用難度。
