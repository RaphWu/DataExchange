﻿using System.Windows.Forms;

namespace CModbus.Demo
{
    public partial class Form_CModbusDemo : Form
    {
        public Form_CModbusDemo()
        {
            InitializeComponent();
        }
    }
}
