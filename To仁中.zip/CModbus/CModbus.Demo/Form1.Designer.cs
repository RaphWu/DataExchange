﻿namespace CModbus.Demo
{
    partial class Form_CModbusDemo
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label_MotorStatusMonitor = new System.Windows.Forms.Label();
            this.textBox_TotalLaps = new System.Windows.Forms.TextBox();
            this.label_TotalLaps = new System.Windows.Forms.Label();
            this.textBox_SoftwareLimitJudge = new System.Windows.Forms.TextBox();
            this.label_SoftwareLimitJudge = new System.Windows.Forms.Label();
            this.textBox_MotorCurrentPos = new System.Windows.Forms.TextBox();
            this.label_MotorCurrentPos = new System.Windows.Forms.Label();
            this.textBox_MotorCommandPos = new System.Windows.Forms.TextBox();
            this.label_MotorCommandPos = new System.Windows.Forms.Label();
            this.textBox_MotorCurrent = new System.Windows.Forms.TextBox();
            this.label_MotorCurrent = new System.Windows.Forms.Label();
            this.textBox_MotorSpeed = new System.Windows.Forms.TextBox();
            this.label_MotorSpeed = new System.Windows.Forms.Label();
            this.textBox_MotorRPM = new System.Windows.Forms.TextBox();
            this.label_MotorRPM = new System.Windows.Forms.Label();
            this.textBox_MotorAlarm = new System.Windows.Forms.TextBox();
            this.label_MotorAlarm = new System.Windows.Forms.Label();
            this.textBox_MotorStatus = new System.Windows.Forms.TextBox();
            this.label_MotorStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_MotorStatusMonitor
            // 
            this.label_MotorStatusMonitor.AutoSize = true;
            this.label_MotorStatusMonitor.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorStatusMonitor.Location = new System.Drawing.Point(609, 40);
            this.label_MotorStatusMonitor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MotorStatusMonitor.Name = "label_MotorStatusMonitor";
            this.label_MotorStatusMonitor.Size = new System.Drawing.Size(106, 21);
            this.label_MotorStatusMonitor.TabIndex = 56;
            this.label_MotorStatusMonitor.Text = "馬達狀態監看";
            this.label_MotorStatusMonitor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_TotalLaps
            // 
            this.textBox_TotalLaps.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_TotalLaps.Location = new System.Drawing.Point(783, 360);
            this.textBox_TotalLaps.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_TotalLaps.Name = "textBox_TotalLaps";
            this.textBox_TotalLaps.Size = new System.Drawing.Size(220, 25);
            this.textBox_TotalLaps.TabIndex = 55;
            // 
            // label_TotalLaps
            // 
            this.label_TotalLaps.AutoSize = true;
            this.label_TotalLaps.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TotalLaps.Location = new System.Drawing.Point(611, 364);
            this.label_TotalLaps.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_TotalLaps.Name = "label_TotalLaps";
            this.label_TotalLaps.Size = new System.Drawing.Size(86, 17);
            this.label_TotalLaps.TabIndex = 54;
            this.label_TotalLaps.Text = "目前累計圈數";
            this.label_TotalLaps.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_SoftwareLimitJudge
            // 
            this.textBox_SoftwareLimitJudge.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_SoftwareLimitJudge.Location = new System.Drawing.Point(783, 327);
            this.textBox_SoftwareLimitJudge.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_SoftwareLimitJudge.Name = "textBox_SoftwareLimitJudge";
            this.textBox_SoftwareLimitJudge.Size = new System.Drawing.Size(220, 25);
            this.textBox_SoftwareLimitJudge.TabIndex = 53;
            // 
            // label_SoftwareLimitJudge
            // 
            this.label_SoftwareLimitJudge.AutoSize = true;
            this.label_SoftwareLimitJudge.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_SoftwareLimitJudge.Location = new System.Drawing.Point(611, 331);
            this.label_SoftwareLimitJudge.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_SoftwareLimitJudge.Name = "label_SoftwareLimitJudge";
            this.label_SoftwareLimitJudge.Size = new System.Drawing.Size(86, 17);
            this.label_SoftwareLimitJudge.TabIndex = 52;
            this.label_SoftwareLimitJudge.Text = "軟體極限判斷";
            this.label_SoftwareLimitJudge.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorCurrentPos
            // 
            this.textBox_MotorCurrentPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCurrentPos.Location = new System.Drawing.Point(783, 294);
            this.textBox_MotorCurrentPos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_MotorCurrentPos.Name = "textBox_MotorCurrentPos";
            this.textBox_MotorCurrentPos.Size = new System.Drawing.Size(220, 25);
            this.textBox_MotorCurrentPos.TabIndex = 51;
            // 
            // label_MotorCurrentPos
            // 
            this.label_MotorCurrentPos.AutoSize = true;
            this.label_MotorCurrentPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCurrentPos.Location = new System.Drawing.Point(611, 298);
            this.label_MotorCurrentPos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MotorCurrentPos.Name = "label_MotorCurrentPos";
            this.label_MotorCurrentPos.Size = new System.Drawing.Size(92, 17);
            this.label_MotorCurrentPos.TabIndex = 50;
            this.label_MotorCurrentPos.Text = "目前位置(mm)";
            this.label_MotorCurrentPos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorCommandPos
            // 
            this.textBox_MotorCommandPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCommandPos.Location = new System.Drawing.Point(783, 261);
            this.textBox_MotorCommandPos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_MotorCommandPos.Name = "textBox_MotorCommandPos";
            this.textBox_MotorCommandPos.Size = new System.Drawing.Size(220, 25);
            this.textBox_MotorCommandPos.TabIndex = 49;
            // 
            // label_MotorCommandPos
            // 
            this.label_MotorCommandPos.AutoSize = true;
            this.label_MotorCommandPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCommandPos.Location = new System.Drawing.Point(611, 265);
            this.label_MotorCommandPos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MotorCommandPos.Name = "label_MotorCommandPos";
            this.label_MotorCommandPos.Size = new System.Drawing.Size(118, 17);
            this.label_MotorCommandPos.TabIndex = 48;
            this.label_MotorCommandPos.Text = "指令現在位置(mm)";
            this.label_MotorCommandPos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorCurrent
            // 
            this.textBox_MotorCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCurrent.Location = new System.Drawing.Point(783, 228);
            this.textBox_MotorCurrent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_MotorCurrent.Name = "textBox_MotorCurrent";
            this.textBox_MotorCurrent.Size = new System.Drawing.Size(220, 25);
            this.textBox_MotorCurrent.TabIndex = 47;
            // 
            // label_MotorCurrent
            // 
            this.label_MotorCurrent.AutoSize = true;
            this.label_MotorCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCurrent.Location = new System.Drawing.Point(611, 232);
            this.label_MotorCurrent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MotorCurrent.Name = "label_MotorCurrent";
            this.label_MotorCurrent.Size = new System.Drawing.Size(105, 17);
            this.label_MotorCurrent.TabIndex = 46;
            this.label_MotorCurrent.Text = "馬達的電流值(%)";
            this.label_MotorCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorSpeed
            // 
            this.textBox_MotorSpeed.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorSpeed.Location = new System.Drawing.Point(783, 195);
            this.textBox_MotorSpeed.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_MotorSpeed.Name = "textBox_MotorSpeed";
            this.textBox_MotorSpeed.Size = new System.Drawing.Size(220, 25);
            this.textBox_MotorSpeed.TabIndex = 45;
            // 
            // label_MotorSpeed
            // 
            this.label_MotorSpeed.AutoSize = true;
            this.label_MotorSpeed.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorSpeed.Location = new System.Drawing.Point(611, 199);
            this.label_MotorSpeed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MotorSpeed.Name = "label_MotorSpeed";
            this.label_MotorSpeed.Size = new System.Drawing.Size(116, 17);
            this.label_MotorSpeed.TabIndex = 44;
            this.label_MotorSpeed.Text = "行進速度(mm/sec)";
            this.label_MotorSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorRPM
            // 
            this.textBox_MotorRPM.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorRPM.Location = new System.Drawing.Point(783, 162);
            this.textBox_MotorRPM.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_MotorRPM.Name = "textBox_MotorRPM";
            this.textBox_MotorRPM.Size = new System.Drawing.Size(220, 25);
            this.textBox_MotorRPM.TabIndex = 43;
            // 
            // label_MotorRPM
            // 
            this.label_MotorRPM.AutoSize = true;
            this.label_MotorRPM.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorRPM.Location = new System.Drawing.Point(611, 166);
            this.label_MotorRPM.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MotorRPM.Name = "label_MotorRPM";
            this.label_MotorRPM.Size = new System.Drawing.Size(123, 17);
            this.label_MotorRPM.TabIndex = 42;
            this.label_MotorRPM.Text = "馬達的迴轉速(RPM)";
            this.label_MotorRPM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorAlarm
            // 
            this.textBox_MotorAlarm.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorAlarm.Location = new System.Drawing.Point(783, 129);
            this.textBox_MotorAlarm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_MotorAlarm.Name = "textBox_MotorAlarm";
            this.textBox_MotorAlarm.Size = new System.Drawing.Size(220, 25);
            this.textBox_MotorAlarm.TabIndex = 41;
            // 
            // label_MotorAlarm
            // 
            this.label_MotorAlarm.AutoSize = true;
            this.label_MotorAlarm.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorAlarm.Location = new System.Drawing.Point(611, 133);
            this.label_MotorAlarm.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MotorAlarm.Name = "label_MotorAlarm";
            this.label_MotorAlarm.Size = new System.Drawing.Size(60, 17);
            this.label_MotorAlarm.TabIndex = 40;
            this.label_MotorAlarm.Text = "報警狀態";
            this.label_MotorAlarm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorStatus
            // 
            this.textBox_MotorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorStatus.Location = new System.Drawing.Point(783, 96);
            this.textBox_MotorStatus.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox_MotorStatus.Name = "textBox_MotorStatus";
            this.textBox_MotorStatus.Size = new System.Drawing.Size(220, 25);
            this.textBox_MotorStatus.TabIndex = 39;
            // 
            // label_MotorStatus
            // 
            this.label_MotorStatus.AutoSize = true;
            this.label_MotorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorStatus.Location = new System.Drawing.Point(611, 101);
            this.label_MotorStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MotorStatus.Name = "label_MotorStatus";
            this.label_MotorStatus.Size = new System.Drawing.Size(60, 17);
            this.label_MotorStatus.TabIndex = 38;
            this.label_MotorStatus.Text = "馬達狀態";
            this.label_MotorStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form_CModbusDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 405);
            this.Controls.Add(this.label_MotorStatusMonitor);
            this.Controls.Add(this.textBox_TotalLaps);
            this.Controls.Add(this.label_TotalLaps);
            this.Controls.Add(this.textBox_SoftwareLimitJudge);
            this.Controls.Add(this.label_SoftwareLimitJudge);
            this.Controls.Add(this.textBox_MotorCurrentPos);
            this.Controls.Add(this.label_MotorCurrentPos);
            this.Controls.Add(this.textBox_MotorCommandPos);
            this.Controls.Add(this.label_MotorCommandPos);
            this.Controls.Add(this.textBox_MotorCurrent);
            this.Controls.Add(this.label_MotorCurrent);
            this.Controls.Add(this.textBox_MotorSpeed);
            this.Controls.Add(this.label_MotorSpeed);
            this.Controls.Add(this.textBox_MotorRPM);
            this.Controls.Add(this.label_MotorRPM);
            this.Controls.Add(this.textBox_MotorAlarm);
            this.Controls.Add(this.label_MotorAlarm);
            this.Controls.Add(this.textBox_MotorStatus);
            this.Controls.Add(this.label_MotorStatus);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form_CModbusDemo";
            this.Text = "CModbus.Demo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_MotorStatusMonitor;
        private System.Windows.Forms.TextBox textBox_TotalLaps;
        private System.Windows.Forms.Label label_TotalLaps;
        private System.Windows.Forms.TextBox textBox_SoftwareLimitJudge;
        private System.Windows.Forms.Label label_SoftwareLimitJudge;
        private System.Windows.Forms.TextBox textBox_MotorCurrentPos;
        private System.Windows.Forms.Label label_MotorCurrentPos;
        private System.Windows.Forms.TextBox textBox_MotorCommandPos;
        private System.Windows.Forms.Label label_MotorCommandPos;
        private System.Windows.Forms.TextBox textBox_MotorCurrent;
        private System.Windows.Forms.Label label_MotorCurrent;
        private System.Windows.Forms.TextBox textBox_MotorSpeed;
        private System.Windows.Forms.Label label_MotorSpeed;
        private System.Windows.Forms.TextBox textBox_MotorRPM;
        private System.Windows.Forms.Label label_MotorRPM;
        private System.Windows.Forms.TextBox textBox_MotorAlarm;
        private System.Windows.Forms.Label label_MotorAlarm;
        private System.Windows.Forms.TextBox textBox_MotorStatus;
        private System.Windows.Forms.Label label_MotorStatus;
    }
}

