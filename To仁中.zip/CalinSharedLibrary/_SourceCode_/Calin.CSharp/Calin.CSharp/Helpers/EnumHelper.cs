﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace Calin.CSharp.Helpers
{
    /// <summary>
    /// Enum 輔助函數。
    /// </summary>
    public static class EnumHelper
    {
        /// <summary>
        /// 取得 Enum 的 Description。
        /// </summary>
        public static string GetDescription(this Enum enumValue)
        {
            FieldInfo fi = enumValue.GetType().GetField(enumValue.ToString());

            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null && attributes.Length > 0)
                return attributes[0].Description;
            else
                return enumValue.ToString();

            //FieldInfo fi = enumValue.GetType().GetField(enumValue.ToString());

            //DescriptionAttribute[] attributes = fi.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];

            //if (attributes != null && attributes.Any())
            //{
            //    return attributes.First().Description;
            //}

            //return enumValue.ToString();
        }

        /// <summary>
        /// 取得屬性的 Description。
        /// </summary>
        /// <typeparam name="T">資料物件。</typeparam>
        /// <param name="propertyName">屬性名稱。</param>
        public static string GetDescription<T>(string propertyName)
        {
            var prop = typeof(T).GetProperty(propertyName);
            if (prop == null)
                return null;

            var attr = prop.GetCustomAttribute<DescriptionAttribute>();
            return attr?.Description;
        }
    }
}
