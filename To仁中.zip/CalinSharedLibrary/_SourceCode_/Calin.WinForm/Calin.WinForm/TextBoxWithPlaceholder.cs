﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Calin.WinForm
{
    /*
     * .NET 5+ 的 TextBox 有支援 PlaceholderText 屬性，
     * 作用為「當控制項沒有文字且沒有焦點時，所顯示的文字。」
     * https://learn.microsoft.com/zh-tw/dotnet/api/system.windows.forms.textbox.placeholdertext
     * 這裡是為 .NET Framework 實現類似的效果。
     */
    /// <summary>
    /// 使 .Net Framework Winform 的 TextBox 擁有 .NET 5+ 的 PlaceholderText 屬性。
    /// </summary>
    public class TextBoxWithPlaceholder : TextBox
    {
        // WinAPI SendMessage 宣告，用來設定 Placeholder (Cue Banner)
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, string lp);

        private const int EM_SETCUEBANNER = 0x1501;

        private string placeholderText;

        /// <summary>
        /// 當控制項沒有文字且沒有焦點時，所顯示的文字。
        /// </summary>
        public string PlaceholderText
        {
            get => placeholderText;
            set
            {
                placeholderText = value;
                UpdatePlaceholder();
            }
        }

        private void UpdatePlaceholder()
        {
            if (this.IsHandleCreated && placeholderText != null)
            {
                // (IntPtr)1 表示在控制項失焦時顯示 Placeholder
                SendMessage(this.Handle, EM_SETCUEBANNER, (IntPtr)1, placeholderText);
            }
        }

        /// <summary>
        /// 覆寫 OnHandleCreated 以確保在控制項建立後更新 Placeholder。
        /// </summary>
        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            UpdatePlaceholder();
        }
    }
}
