﻿# Calin.Csharp 1.0.2
2025-10-02
- 新增 UISettings 靜態類別。

# Calin.Csharp 1.0.1
2025-09-25
- x86 改回 AnyCPU

# Calin.Csharp 1.0.0
2025-09-25
- 初版
