﻿using System.ComponentModel;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    // 請依執行順序倒序排列

    /// <summary>
    /// 目前維護狀態。
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// 維護結束。
        /// </summary>
        [Description("維護結束")]
        Finished = 1,

        /// <summary>
        /// 維護完成。
        /// </summary>
        [Description("維護完成")]
        MaintenanceCompleted = 2,

        /// <summary>
        /// 委託者確認。
        /// </summary>
        [Description("委託者確認")]
        ClientConfirmed = 4,

        /// <summary>
        /// 接單。
        /// </summary>
        [Description("接單")]
        OrderAccepted = 8,

        /// <summary>
        /// 新工單。
        /// </summary>
        [Description("新工單")]
        NewTaskOrder = 10,
    }
}
