﻿# TaskPulse.MaintiFlow History

---

# 功能

## 修改中

- 新增資料時，總表不會更新
	- 新建Messager，通知資料庫需更新。(試非同步) OK
	- adgv需保留排序過濾條件

## 待新增
