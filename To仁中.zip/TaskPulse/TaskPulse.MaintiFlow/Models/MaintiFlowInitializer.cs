﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using Calin.TaskPulse.Core.Models;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// Code First 初始化類別。
    /// </summary>
    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
    public class MaintiFlowInitializer : SqliteCreateDatabaseIfNotExists<MaintiFlowContext>
    {
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;

        public MaintiFlowInitializer(DbModelBuilder modelBuilder, CoreData coreData, MaintiFlowData flowData) : base(modelBuilder)
        {
            _coreData = coreData;
            _flowData = flowData;
        }

        protected override void Seed(MaintiFlowContext context)
        {
            var st = context.Set<Status>();
            st.Add(new Status() { StatusId = 1, OrderNo = 1, StatusName = "待處理" });
            st.Add(new Status() { StatusId = 2, OrderNo = 2, StatusName = "處理中" });
            st.Add(new Status() { StatusId = 3, OrderNo = 3, StatusName = "完成" });

            var mu = context.Set<MaintenanceUnit>();
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 1, OrderNo = 1, Name = "工具設計" });
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 2, OrderNo = 2, Name = "維護-維小" });
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 3, OrderNo = 3, Name = "維護-製一" });

            var ic = context.Set<IssueCategory>();
            ic.Add(new IssueCategory() { CategoryId = 1, OrderNo = 1, CategoryName = "日常維護" });
            ic.Add(new IssueCategory() { CategoryId = 2, OrderNo = 2, CategoryName = "機台保養" });
            ic.Add(new IssueCategory() { CategoryId = 3, OrderNo = 3, CategoryName = "更換零件" });
            ic.Add(new IssueCategory() { CategoryId = 4, OrderNo = 4, CategoryName = "機台改線" });
            ic.Add(new IssueCategory() { CategoryId = 5, OrderNo = 5, CategoryName = "故障中待協助" });
            ic.Add(new IssueCategory() { CategoryId = 6, OrderNo = 6, CategoryName = "異常排除" });
            ic.Add(new IssueCategory() { CategoryId = 7, OrderNo = 7, CategoryName = "設備功能追加" });
            ic.Add(new IssueCategory() { CategoryId = 8, OrderNo = 8, CategoryName = "機台移動" });

            var ru = context.Set<RequestingUnit>();
            ru.Add(new RequestingUnit() { RequestingUnitId = 1, OrderNo = 1, Name = "組立" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 2, OrderNo = 2, Name = "製技" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 3, OrderNo = 3, Name = "RD" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 4, OrderNo = 4, Name = "試作" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 5, OrderNo = 5, Name = "試作開發" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 6, OrderNo = 6, Name = "品管" });

            //var em = context.Set<Employee>();
            //foreach (var e in _coreData.EmployeeList)
            //{
            //    em.Add(new Employee()
            //    {
            //        EmployeeId = e.EmployeeId,
            //        Name = e.Name,
            //        Department = e.Department,
            //        Title = e.Title,
            //        IsEngineer = e.IsEngineer,
            //    });
            //}

            context.SaveChanges();

            try
            {
                int recCount = 0;
                using (var sr = new StreamReader("設備維修履歷(Sample).txt", Encoding.Default))
                {
                    string[] sList;

                    var tos = context.Set<TaskOrder>();
                    var em = context.Set<Employee>();
                    var ma = context.Set<Machine>();
                    var mo = context.Set<Model>();
                    //var mu = context.Set<MaintenanceUnit>();
                    //var ic = context.Set<IssueCategory>();
                    //var ru = context.Set<RequestingUnit>();

                    try
                    {
                        while (sr.Peek() != -1)
                        {
                            recCount++;
                            string[] data = sr.ReadLine().Split('\t');

                            if (recCount > 1) // 去掉標題
                            {
                                var to = new TaskOrder();
                                string workOrderNo = data[1].Trim();

                                to.OrderNo = int.Parse(data[0]);
                                to.WorkOrderNo = workOrderNo;

                                if (!string.IsNullOrWhiteSpace(data[2]))
                                {
                                    string name = data[2].Trim();
                                    to.Creator = em.FirstOrDefault(x => x.Name == name);
                                }
                                else
                                {
                                    to.Creator = null;
                                }

                                to.CreationDate = DateTime.Parse(data[3]);

                                if (!string.IsNullOrWhiteSpace(data[4]))
                                {
                                    string name = data[4].Trim();
                                    to.MaintenanceUnit = mu.FirstOrDefault(x => x.Name == name);
                                }
                                else
                                {
                                    to.MaintenanceUnit = null;
                                }

                                sList = data[5].Split('/');
                                to.MaintenanceEngineers = new List<TaskOrderEngineer>();
                                foreach (var d5 in sList)
                                {
                                    var e = em.FirstOrDefault(x => x.Name == d5 && x.IsEngineer);
                                    if (e != null)
                                        to.MaintenanceEngineers.Add(new TaskOrderEngineer()
                                        {
                                            WorkOrderNo = workOrderNo,
                                            EmployeeId = e.EmployeeId,
                                            //Engineer = e,
                                        });
                                }

                                // data[6] 可能為「機台名稱_機台名稱_...」
                                var d6 = data[6].Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries)
                                                .Select(x => x.Trim())
                                                .Where(x => !string.IsNullOrWhiteSpace(x))
                                                .Distinct()
                                                .ToList();
                                to.TaskOrderMachines = new List<TaskOrderMachine>();
                                foreach (var d_6 in d6)
                                {
                                    // 先找目前追蹤中的暫存實體，再找資料庫已存在的
                                    var machine = ma.Local.FirstOrDefault(x => x.MachineName == d_6)
                                               ?? ma.FirstOrDefault(x => x.MachineName == d_6);

                                    // 若完全不存在則建立新實體
                                    if (machine == null)
                                    {
                                        machine = new Machine { MachineName = d_6 };
                                        ma.Add(machine);
                                    }

                                    // 使用導航屬性關聯，不要直接操作外鍵ID
                                    to.TaskOrderMachines.Add(new TaskOrderMachine
                                    {
                                        TaskOrder = to,
                                        Machine = machine
                                    });
                                }

                                //var d6 = data[6].Split('_').ToList();
                                //var existingMachines = ma.ToList();
                                //var localMachines = new List<Machine>();
                                //to.TaskOrderMachines = new List<TaskOrderMachine>();
                                //foreach (var d_6 in d6)
                                //{
                                //    if (string.IsNullOrWhiteSpace(d_6)) continue;

                                //    // 先從資料庫找，再從目前追蹤的暫存實體中找
                                //    var machine = ma.Local.FirstOrDefault(x => x.MachineName == d_6)
                                //               ?? existingMachines.FirstOrDefault(x => x.MachineName == d_6);

                                //    if (machine == null)
                                //    {
                                //        machine = new Machine() { MachineName = d_6 };
                                //        ma.Add(machine);
                                //        existingMachines.Add(machine); // 更新快取
                                //    }

                                //    to.TaskOrderMachines.Add(new TaskOrderMachine()
                                //    {
                                //        TaskOrder = to,     // 建議直接設關聯
                                //        Machine = machine,  // 不要用 MachineId（因為還沒存時是0）
                                //    });

                                //    //var existing = existingMachines.FirstOrDefault(x => x.MachineName == d_6)
                                //    //    ?? localMachines.FirstOrDefault(x => x.MachineName == d_6);

                                //    //if (existing == null)
                                //    //{
                                //    //    existing = new Machine() { MachineName = d_6 };
                                //    //    ma.Add(existing);
                                //    //    localMachines.Add(existing);
                                //    //}

                                //    //var d__6 = ma.FirstOrDefault(x => x.MachineName == d_6);
                                //    //if (d__6 == null)
                                //    //    d__6 = ma.Add(new Machine() { MachineName = d_6 });
                                //    //to.TaskOrderMachines.Add(new TaskOrderMachine()
                                //    //{
                                //    //    WorkOrderNo = to.WorkOrderNo,
                                //    //    MachineId = d__6.MachineId,
                                //    //});
                                //}

                                to.AcceptedTime = DateTime.Parse(string.Concat(data[3], " ", data[7]));

                                if (DateTime.TryParse(string.Concat(data[3], " ", data[8]), out DateTime rs))
                                    to.RepairStarted = rs;
                                else
                                    to.RepairStarted = null;

                                if (DateTime.TryParse(string.Concat(data[3], " ", data[9]), out DateTime rc))
                                    to.RepairCompleted = rc;
                                else
                                    to.RepairCompleted = null;

                                if (int.TryParse(data[10], out int rd))
                                    to.RepairDuration = TimeSpan.FromMinutes(rd);
                                else
                                {
                                    if (rs == null || rc == null)
                                        to.RepairDuration = null;
                                    else
                                        to.RepairDuration = rc - rs;
                                }

                                if (DateTime.TryParse(string.Concat(data[3], " ", data[11]), out DateTime os))
                                    to.OutageStarted = os;
                                else
                                    to.OutageStarted = null;

                                if (DateTime.TryParse(string.Concat(data[3], " ", data[12]), out DateTime oe))
                                    to.OutageEnded = oe;
                                else
                                    to.OutageEnded = null;

                                if (int.TryParse(data[13], out int od))
                                    to.OutageDuration = TimeSpan.FromMinutes(od);
                                else
                                {
                                    if (rs == null || rc == null)
                                        to.OutageDuration = null;
                                    else
                                        to.OutageDuration = oe - os;
                                }

                                if (!string.IsNullOrWhiteSpace(data[15]))
                                {
                                    string name = data[15].Trim();
                                    to.Model = mo.FirstOrDefault(x => x.ModelName == name);
                                    if (to.Model == null)
                                    {
                                        var newModel = new Model() { ModelName = name };
                                        mo.Add(newModel);
                                        //context.SaveChanges(); // 確保 ModelId 被產生
                                        //to.Model = newModel;
                                        //to.ModelId = newModel.ModelId;
                                         }
                                }

                                to.Workstation = data[16].Trim().Split(',');

                                if (!string.IsNullOrWhiteSpace(data[17]))
                                {
                                    string name = data[17].Trim();
                                    to.IssueCategory = ic.FirstOrDefault(x => x.CategoryName == name);
                                }
                                else
                                {
                                    to.IssueCategory = null;
                                }

                                to.IssueDescription = data[18].Trim();
                                to.Details = data[19].Trim();

                                if (!string.IsNullOrWhiteSpace(data[20]))
                                {
                                    string name = data[20].Trim();
                                    to.RequestingUnit = ru.FirstOrDefault(x => x.Name == name);
                                }
                                else
                                {
                                    to.RequestingUnit = null;
                                }

                                if (!string.IsNullOrWhiteSpace(data[21]))
                                {
                                    string name = data[21].Trim();
                                    to.RequestingEmployee = em.FirstOrDefault(x => x.Name == name);
                                }
                                else
                                {
                                    to.RequestingEmployee = null;
                                }

                                if (!string.IsNullOrWhiteSpace(data[22]))
                                {
                                    string name = data[22].Trim();
                                    to.Status = st.FirstOrDefault(x => x.StatusName == name);
                                }
                                if (to.Status == null)
                                    to.Status = st.FirstOrDefault(x => x.StatusName == "待處理");

                                to.RequestingUnitResponse = data[23].Trim();

                                tos.Add(to);
                            }
                        }
                        context.SaveChanges();
                    }
                    catch (DbEntityValidationException ex)
                    {
                        foreach (var eve in ex.EntityValidationErrors)
                        {
                            Console.WriteLine($"Entity of type '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

                            foreach (var ve in eve.ValidationErrors)
                            {
                                Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                            }
                        }

                        throw; // 若你要繼續丟出錯誤
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            base.Seed(context);
        }
    }
}
