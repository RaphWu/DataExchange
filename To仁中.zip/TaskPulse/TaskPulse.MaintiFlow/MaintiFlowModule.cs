﻿using Autofac;
using Calin.TaskPulse.MaintiFlow.Models;
using Calin.TaskPulse.MaintiFlow.Utility;
using Calin.TaskPulse.MaintiFlow.Views;

namespace Calin.TaskPulse.MaintiFlow
{
    /// <summary>
    /// 維護工單自定義模組。
    /// </summary>
    public class MaintiFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<MaintiFlowContext>().SingleInstance();
            builder.RegisterType<MaintiFlowInitializer>().As<IStartable>().SingleInstance();
            builder.RegisterType<MaintiFlowData>().SingleInstance();

            builder.RegisterType<MaintiFlowPage>();
            builder.RegisterType<ManitiFlowMain>();
            builder.RegisterType<MaintiFlowSummary>();
            builder.RegisterType<CreateFlow>();

#if DEBUG
            builder.RegisterType<LoadCsv>();
#endif
        }
    }
}
