﻿/*
 * 工程師開單 vs 線上人員開單分開。
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class CreateFlow : UIForm
    {
        private readonly IMaintiFlow _flow;
        private readonly CoreContext _context;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly MaintiFlowFieldName _fieldName;
        private readonly FlowLayoutSelector _flowLayoutSelector;

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 新建工單的工單號。
        /// </summary>
        public List<string> NewWorkOrderNos { get; set; } = new List<string>();

        private string _todayPrefix;
        private int _lastWorkOrderNo;

        public CreateFlow(IMaintiFlow maintiFlow,
                          CoreContext CoreContext,
                          MaintiFlowData maintiFlowData,
                          CoreData coreData,
                          MaintiFlowFieldName maintiFlowFieldName,
                          FlowLayoutSelector flowLayoutSelector)
        {
            InitializeComponent();
            _flow = maintiFlow;
            _context = CoreContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _fieldName = maintiFlowFieldName;
            _flowLayoutSelector = flowLayoutSelector;

            uiButton_OK.FillColor = CommonStyles.BackColor;
            uiButton_OK.FillHoverColor = CommonStyles.Hover;

            this.AcceptButton = uiButton_OK;
            this.CancelButton = uiButton_Cancel;

            /********************
             * Controls
             ********************/
            string caption;
            caption = _fieldName.Creator;
            uiLabel_Creator.Text = caption;
            var employeeList = _coreData.Employees
                .Select(e => new
                {
                    e.EmployeeId,
                    Display = $"{e.EmployeeId}, {e.Department.DepartmentName}, {e.Name}",
                })
                .ToList();
            Creator.DataSource = employeeList;
            Creator.DisplayMember = "Display";
            Creator.ValueMember = "EmployeeId";
            Creator.Watermark = caption;

            caption = _fieldName.Machine;
            uiLabel_MachineList.Text = caption;
            MachineList.Watermark = caption;
            MachineList.ButtonFillColor = CommonStyles.BackColor;
            MachineList.ButtonFillHoverColor = CommonStyles.Hover;

            caption = _fieldName.Model;
            uiLabel_Model.Text = caption;
            Model.Watermark = caption;
            Model.ButtonFillColor = CommonStyles.BackColor;
            Model.ButtonFillHoverColor = CommonStyles.Hover;

            caption = _fieldName.Workstation;
            uiLabel_Workstation.Text = caption;
            Workstation.Watermark = caption;
            Workstation.ButtonFillColor = CommonStyles.BackColor;
            Workstation.ButtonFillHoverColor = CommonStyles.Hover;

            caption = _fieldName.OutageStarted;
            uiLabel_OutageStarted.Text = caption;
            OutageStarted.Watermark = caption;

            caption = _fieldName.IssueDescription;
            uiLabel_IssueDescription.Text = caption;
            IssueDescription.Watermark = caption;
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            // 拆解機台編號
            var machineList = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();

            // 錯誤檢查
            if (string.IsNullOrWhiteSpace(Creator.Text))
            {
                UIMessageBox.ShowError2($"{uiLabel_Creator.Text}必須要選擇一人！");
                return;
            }
            if (string.IsNullOrWhiteSpace(MachineList.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{uiLabel_MachineList.Text}！");
                return;
            }
            else
            {
                foreach (var mId in machineList)
                    if (_coreData.Machines.FindIndex(x => x.MachineId == mId) == -1)
                    {
                        UIMessageBox.ShowError2($"{uiLabel_MachineList.Text}不存在: {mId}");
                        return;
                    }
            }
            if (string.IsNullOrWhiteSpace(Model.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{uiLabel_Model.Text}！");
                return;
            }
            else
            {
                if (_coreData.Models.FindIndex(x => x.ModelName == Model.Text) == -1)
                {
                    UIMessageBox.ShowError2($"{uiLabel_Model.Text}不存在: {Model.Text}");
                    return;
                }
            }

            var deviceList = new List<Machine>();
            var to = _context.TaskOrders;

            // 計算新工單號
            _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
            _lastWorkOrderNo = to
                .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                .AsEnumerable()
                .Select(o => o.WorkOrderNo.Substring(8, 3))
                .Select(s =>
                {
                    bool success = int.TryParse(s, out int val);
                    return success ? val : 0;
                })
                .DefaultIfEmpty(0)
                .Max();

            // 加入資料庫
            NewWorkOrderNos.Clear();
            int lastOrderNo = to.Select(x => x.OrderNo).Max();

            for (int no = 1; no <= machineList.Count; no++)
            {
                string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                to.Add(new TaskOrder()
                {
                    OrderNo = lastOrderNo + no,
                    WorkOrderNo = newWorkOrderNo,
                    Creator = _coreData.Employees.FirstOrDefault(x => x.EmployeeId == (string)Creator.SelectedValue),
                    CreationDate = DateTime.Today,
                    Machine = _coreData.Machines.FirstOrDefault(x => x.MachineId == machineList[no - 1]),
                    Workstation = _coreData.Workstations.FirstOrDefault(w => w.WorkstationName == Workstation.Text),
                    Status = Status.NewTaskOrder,
                    AcceptedTime = DateTime.Now,
                    OutageStarted = OutageStarted.Value,
                });
                NewWorkOrderNos.Add(newWorkOrderNo);
            }
            _context.SaveChanges();
            StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void MachineId_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.HideTabHeaders = false;
            _flowLayoutSelector.Title = $"請選擇{_fieldName.Machine}";
            _flowLayoutSelector.MultiSelection = true;
            _flowLayoutSelector.DefaultChecked = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _flowLayoutSelector.Initialize();

            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                if (_flowLayoutSelector.ResultList.Count > 0)
                {
                    string deviceString = "";
                    foreach (var item in _flowLayoutSelector.ResultList)
                    {
                        if (deviceString != "")
                            deviceString += "; ";
                        deviceString += item;
                    }
                    MachineList.Text = deviceString;
                }
            }
        }

        private void Model_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.HideTabHeaders = true;
            _flowLayoutSelector.Title = $"請選擇{_fieldName.Model}";
            _flowLayoutSelector.MultiSelection = false;
            if (string.IsNullOrWhiteSpace(Model.Text))
                _flowLayoutSelector.DefaultChecked.Clear();
            else
                _flowLayoutSelector.DefaultChecked.Add(Model.Text.Trim());

            _flowLayoutSelector.Initialize();

            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                if (_flowLayoutSelector.ResultList.Count > 0)
                    Model.Text = _flowLayoutSelector.ResultList[0];
            }
        }
    }
}
