﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class ManitiFlowMain
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.uiButton_Summary = new Sunny.UI.UISymbolButton();
            this.uiButton_CreateFlow = new Sunny.UI.UISymbolButton();
            this.SuspendLayout();
            // 
            // uiButton_Summary
            // 
            this.uiButton_Summary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Summary.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Summary.Location = new System.Drawing.Point(54, 38);
            this.uiButton_Summary.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Summary.Name = "uiButton_Summary";
            this.uiButton_Summary.Radius = 20;
            this.uiButton_Summary.Size = new System.Drawing.Size(230, 124);
            this.uiButton_Summary.Symbol = 559936;
            this.uiButton_Summary.SymbolSize = 32;
            this.uiButton_Summary.TabIndex = 17;
            this.uiButton_Summary.Text = "uiButton_Summary";
            this.uiButton_Summary.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Summary.Click += new System.EventHandler(this.uiButton_Summary_Click);
            // 
            // uiButton_CreateFlow
            // 
            this.uiButton_CreateFlow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_CreateFlow.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_CreateFlow.Location = new System.Drawing.Point(54, 223);
            this.uiButton_CreateFlow.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_CreateFlow.Name = "uiButton_CreateFlow";
            this.uiButton_CreateFlow.Radius = 20;
            this.uiButton_CreateFlow.Size = new System.Drawing.Size(230, 124);
            this.uiButton_CreateFlow.Symbol = 559936;
            this.uiButton_CreateFlow.SymbolSize = 32;
            this.uiButton_CreateFlow.TabIndex = 16;
            this.uiButton_CreateFlow.Text = "uiButton_NewFlow";
            this.uiButton_CreateFlow.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_CreateFlow.Click += new System.EventHandler(this.uiButton_CreateFlow_Click);
            // 
            // ManitiFlowMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 608);
            this.Controls.Add(this.uiButton_Summary);
            this.Controls.Add(this.uiButton_CreateFlow);
            this.Name = "ManitiFlowMain";
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UISymbolButton uiButton_Summary;
        private Sunny.UI.UISymbolButton uiButton_CreateFlow;
    }
}
