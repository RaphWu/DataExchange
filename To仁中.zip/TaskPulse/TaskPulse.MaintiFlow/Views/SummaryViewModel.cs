﻿using System;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public class SummaryViewModel : ObservableValidator
    {
        public string WorkOrderNo { get; set; }
        public string Status { get; set; }
        public string MachineId { get; set; }
        public string ModelName { get; set; }
        public string Workstation { get; set; }
        public string CreatorName { get; set; }
        public DateTime? CreationDate { get; set; }

        public string MaintenanceUnit { get; set; }
        public string Engineers { get; set; }
        public DateTime? AcceptedTime { get; set; }
        public string IssueCategory { get; set; }
        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public DateTime? RepairStarted { get; set; }
        public DateTime? RepairCompleted { get; set; }
        public TimeSpan RepairDuration { get; set; }

        public string RequestingUnit { get; set; }
        public string RequestingEmployee { get; set; }
        public string Response { get; set; }
        public DateTime? OutageStarted { get; set; }
        public DateTime? OutageEnded { get; set; }
        public TimeSpan OutageDuration { get; set; }

        public string Responsible { get; set; }
        public int OrderNo { get; set; }
    }
}
