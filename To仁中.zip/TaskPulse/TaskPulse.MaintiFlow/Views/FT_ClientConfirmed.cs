﻿using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_ClientConfirmed : UIPage
    {
        public FT_ClientConfirmed()
        {
            InitializeComponent();
        }
    }
}
