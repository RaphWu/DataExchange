﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Contants;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.MaintiFlow.Events
{
    public class MaintiFlowPageChangedMessage : ValueChangedMessage<PageCode>
    {
        public MaintiFlowPageChangedMessage(PageCode pageCode) : base(pageCode) { }
    }
}
