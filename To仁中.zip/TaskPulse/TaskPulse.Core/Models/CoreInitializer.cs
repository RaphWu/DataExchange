﻿using System.Data.Entity;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.Core.Models
{
    /********************
     * SqliteDropCreateDatabaseAlways // 每次執行都刪除並重建資料庫
     * SqliteCreateDatabaseIfNotExists // 如果資料庫不存在，則建立資料庫並初始化預設資料。
     * SqliteDropCreateDatabaseWhenModelChanges // 如果模型有變更，則刪除並重建資料庫。
     ********************/
    /// <summary>
    /// Code First 初始化類別。
    /// </summary>
    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
    public class CoreInitializer : SqliteCreateDatabaseIfNotExists<CoreContext>
    {
        public CoreInitializer(DbModelBuilder modelBuilder) : base(modelBuilder)
        {
        }

        protected override void Seed(CoreContext context)
        {
            var emp = context.Set<Employee>();
            emp.Add(new Employee() { EmployeeId = "08001", Department = "工具&設計課", Name = "蔡孟堅", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08002", Department = "工具&設計課", Name = "鄭大德", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08003", Department = "工具&設計課", Name = "李起修", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08004", Department = "工具&設計課", Name = "葉柏均", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08005", Department = "工具&設計課", Name = "曾惠鈴", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08006", Department = "第一製造部", Name = "蔡素貞" });
            emp.Add(new Employee() { EmployeeId = "08007", Department = "第一製造部", Name = "張志榮" });
            emp.Add(new Employee() { EmployeeId = "08008", Department = "第一製造部", Name = "賴惠珠" });
            emp.Add(new Employee() { EmployeeId = "08009", Department = "第一製造部", Name = "侯倩玉" });
            emp.Add(new Employee() { EmployeeId = "08010", Department = "第一製造部", Name = "李雅婷" });
            emp.Add(new Employee() { EmployeeId = "08011", Department = "第一製造部", Name = "彭紹軒" });
            emp.Add(new Employee() { EmployeeId = "08012", Department = "第一製造部", Name = "黎氏鳳" });
            emp.Add(new Employee() { EmployeeId = "08013", Department = "第一製造部", Name = "阮碧幸" });
            emp.Add(new Employee() { EmployeeId = "08014", Department = "第一製造部", Name = "盧海燕" });
            emp.Add(new Employee() { EmployeeId = "08015", Department = "第一製造部", Name = "余沂霈" });
            emp.Add(new Employee() { EmployeeId = "08016", Department = "第一製造部", Name = "楊瓊瑛" });
            emp.Add(new Employee() { EmployeeId = "08017", Department = "組裝製造部", Name = "陳寶琴" });
            emp.Add(new Employee() { EmployeeId = "08018", Department = "組裝製造部", Name = "劉名峻" });
            emp.Add(new Employee() { EmployeeId = "08019", Department = "組裝製造部", Name = "黃琪雯" });
            emp.Add(new Employee() { EmployeeId = "08020", Department = "組裝製造部", Name = "黃姿蓉" });
            emp.Add(new Employee() { EmployeeId = "08021", Department = "組裝製造部", Name = "林承翰" });
            emp.Add(new Employee() { EmployeeId = "08022", Department = "組裝製造部", Name = "雷舒涵" });
            emp.Add(new Employee() { EmployeeId = "08023", Department = "組裝製造部", Name = "黃嘉惠" });
            emp.Add(new Employee() { EmployeeId = "08024", Department = "組裝製造部", Name = "蔡素真" });
            emp.Add(new Employee() { EmployeeId = "08025", Department = "組裝製造部", Name = "黃玉紅" });
            emp.Add(new Employee() { EmployeeId = "08026", Department = "組裝製造部", Name = "許凱婷" });
            emp.Add(new Employee() { EmployeeId = "08027", Department = "組裝製造部", Name = "林昆達" });
            emp.Add(new Employee() { EmployeeId = "08028", Department = "組裝製造部", Name = "晉玉樹" });
            emp.Add(new Employee() { EmployeeId = "08029", Department = "工具&設計課", Name = "謝定傑", IsEngineer = true });

            context.SaveChanges();

            base.Seed(context);
        }
    }
}
