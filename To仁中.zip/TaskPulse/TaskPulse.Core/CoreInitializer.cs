﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Models;
using Sunny.UI;

namespace Calin.TaskPulse.Core
{
    /// <summary>
    /// 容器建構完成後啟動。
    /// </summary>
    /// <remarks>參見: <see href="https://docs.autofac.org/en/latest/lifetime/startup.html#startable-components">Startable Components</see>。</remarks>
    public class CoreInitializer : IStartable
    {
        private readonly CoreContext _coreContext;
        private readonly CoreData _coreData;

        public CoreInitializer(CoreContext coreContext, CoreData coreData)
        {
            _coreContext = coreContext;
            _coreData = coreData;
        }

        public void Start()
        {
            try
            {
                _coreContext.Database.Initialize(force: true);
                _coreData.EmployeeList = _coreContext.Employees.ToList();
                _coreData.EmployeeList = _coreContext.Set<Employee>()
                    .OrderBy(m => m.EmployeeId)
                    .ToList();
            }
            catch (IOException ioe)
            {
                UIMessageBox.ShowError(ioe.Message);
                Application.Exit();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
