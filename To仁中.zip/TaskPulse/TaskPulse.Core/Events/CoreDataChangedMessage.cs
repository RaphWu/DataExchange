﻿using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 核心共用資料更新。
    /// </summary>
    public class CoreDataChangedMessage : ValueChangedMessage<CoreData>
    {
        public CoreDataChangedMessage(CoreData coreData) : base(coreData) { }
    }
}
