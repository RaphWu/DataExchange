﻿/*
 * 機台/機種選擇對話框。
 * 
 * 多選：
 *     使用 CoreData.ClassifyMachines 及 CoreData.MachinesTabPageCache。
 *     建立分類TAB，以CheckBox選擇。
 * 單選：
 *     使用 CoreData.Models 及 CoreData.ModelsTabPageCache。
 *     以RadioButton選擇。
 * 下方顯示已選取項目：分類 » 類型 » 項目1,項目2...
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class FlowLayoutSelector : UIForm
    {
        #region fields

        private readonly CoreData _coreData;
        private readonly ICore _core;

        private const int OPTIONAL_WIDTH = 140; // Items寬度
        private bool _preventControlsEvents = false; // 屏蔽Control事件
        private Dictionary<string, (string Category, string Type)> _allSelection
            = new Dictionary<string, (string Category, string Type)>(); // 記錄目前選擇的Items

        #endregion fields

        /********************
         * properties
         ********************/
        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 是否隱藏標籤列。
        /// </summary>
        public bool HideTabHeaders
        {
            get => tabControlTypes.HideTabHeaders;
            set
            {
                if (tabControlTypes.HideTabHeaders != value)
                    tabControlTypes.HideTabHeaders = value;
            }
        }

        /// <summary>
        /// 是否允許多選。
        /// </summary>
        /// <remarks>true=多選 (使用 CheckBox)。<br/>false=單選 (使用 RadioButton)。</remarks>
        public bool MultiSelection { get; set; } = true;

        /// <summary>
        /// 預設值列表。
        /// </summary>
        public List<string> DefaultChecked { get; set; } = new List<string>();

        /// <summary>
        /// 返回的 Items。
        /// </summary>
        public List<string> ResultList { get; set; } = new List<string>();

        /********************
         * ctor
         ********************/
        public FlowLayoutSelector(CoreData coreData, ICore core)
        {
            InitializeComponent();
            _coreData = coreData;
            _core = core;

            label_ResultList.Text = "";
        }

        /********************
         * Form
         ********************/
        private void FlowLayoutSelector_Shown(object sender, EventArgs e)
        {
            if (treeViewCategories.Nodes.Count > 0)
            {
                treeViewCategories.SelectedNode = treeViewCategories.Nodes[0];
                treeViewCategories_AfterSelect(treeViewCategories, new TreeViewEventArgs(treeViewCategories.SelectedNode));
            }
        }

        private void FlowLayoutSelector_FormClosing(object sender, FormClosingEventArgs e)
        {
            RemoveCheckBoxEvent();
            RemoveRadioButtonEvent();
            tabControlTypes.TabPages.Clear(); // 沒清掉的話，裡面的Control會全被釋放掉
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        /********************
         * Initialize
         ********************/
        public void Initialize()
        {
            tabControlTypes.TabPages.Clear();

            if (MultiSelection)
            {
                treeViewCategories.Nodes.Clear();
                foreach (var categoryName in _coreData.MachinesTabPageCache.Keys)
                    treeViewCategories.Nodes.Add(new TreeNode(categoryName));
                treeViewCategories.Visible = true;

                SetMachineListToDefault();
                SetCheckBoxEvent();
            }
            else
            {
                if (DefaultChecked.Count > 1) // 預設值最多只能一個
                    DefaultChecked = new List<string>() { DefaultChecked[0] };

                treeViewCategories.Nodes.Clear();
                treeViewCategories.Visible = false;

                SetModelListToDefault();
                tabControlTypes.TabPages.Add(_coreData.ModelsTabPageCache["SinglePage"][0]);
                SetRadioButtonEvent();
            }

            tabControlTypes.Refresh();
            SetAndShowSelected();
        }

        /********************
         * Utility
         ********************/
        /// <summary>
        /// 
        /// </summary>
        private void SetAndShowSelected()
        {
            ResultList.Clear();
            List<string> showResultList = new List<string>();

            if (MultiSelection)
            {
                var categories = _allSelection
                    .GroupBy(kvp => kvp.Value.Category)
                    .OrderBy(g => g.Key);

                foreach (var categoryGroup in categories)
                {
                    var types = categoryGroup
                        .GroupBy(kvp => kvp.Value.Type)
                        .OrderBy(tg => tg.Key);

                    foreach (var typeGroup in types)
                    {
                        var machineNames = typeGroup.Select(kvp => kvp.Key).ToList();
                        var sortedMachineNames = _core.SortMachineId(machineNames);
                        ResultList.AddRange(sortedMachineNames);

                        string names = string.Join(", ", sortedMachineNames);
                        string line = $"{categoryGroup.Key} » {typeGroup.Key} » {names}";
                        showResultList.Add(line);
                    }
                }
            }
            else
            {
                var modelName = _allSelection.Select(kvp => kvp.Key).FirstOrDefault();
                if (!string.IsNullOrWhiteSpace(modelName))
                {
                    ResultList.Add(modelName);
                    showResultList.Add($"選擇機種：{modelName}");
                }
            }

            label_ResultList.Text = string.Join("\n", showResultList);
        }

        /********************
         * Treeview
         ********************/
        private void treeViewCategories_AfterSelect(object sender, TreeViewEventArgs e)
        {
            _preventControlsEvents = true;
            tabControlTypes.SuspendLayout();

            var categoryName = e.Node.Text;
            tabControlTypes.TabPages.Clear();

            var typeDict = _coreData.MachinesTabPageCache[categoryName];
            foreach (var typePage in typeDict)
                tabControlTypes.TabPages.Add(typePage);

            tabControlTypes.ResumeLayout();
            _preventControlsEvents = false;
        }

        /********************
         * CheckBox
         ********************/
        /// <summary>
        /// 清除全部 CheckBox。
        /// </summary>
        private void uiButton_Clear_Click(object sender, EventArgs e)
        {
            ClearAllChecked();
            SetAndShowSelected();
        }

        ///// <summary>
        ///// 將 Machine Cache 中為 True 的 MachineId 轉存到 ResultList 和 _allSelection，並更新顯示。
        ///// </summary>
        //private void GetMachineListCache()
        //{
        //    _preventControlsEvents = true;
        //    _allSelection.Clear();
        //    var typeList = _coreData.MachinesTabPageCache.Values;
        //    foreach (var typePage in typeList)
        //        foreach (var page in typePage)
        //            GetMachineListCache(page.Controls);
        //    SetAndShowSelected();
        //    _preventControlsEvents = false;
        //}

        ///// <summary>
        ///// 將 Machine Cache 中為 True 的 MachineId 轉存到 _allSelection (遞迴用)。
        ///// </summary>
        ///// <param name="controls">根控制項。</param>
        //private void GetMachineListCache(Control.ControlCollection controls)
        //{
        //    foreach (Control control in controls)
        //    {
        //        if (control is UICheckBox rb)
        //        {
        //            if (rb.Checked)
        //            {
        //                dynamic tag = rb.Tag;
        //                string machineId = tag.MachineId;
        //                string type = tag.Type;
        //                string category = tag.Category;
        //                _allSelection.Add(machineId, (category, type));
        //            }
        //        }
        //        else if (control.HasChildren)
        //        {
        //            GetMachineListCache(control.Controls);
        //        }
        //    }
        //}

        /// <summary>
        /// 清除所有 CheckBox 已勾選項目。
        /// </summary>
        private void ClearAllChecked()
        {
            _preventControlsEvents = true;

            _allSelection.Clear();
            var typeList = _coreData.MachinesTabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    ClearAllChecked(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 清除所有 CheckBox 已勾選項目 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void ClearAllChecked(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (cb.Checked)
                        cb.Checked = false;
                }
                else if (control.HasChildren)
                {
                    ClearAllChecked(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked。
        /// </summary>
        private void SetMachineListToDefault()
        {
            _preventControlsEvents = true;
            _allSelection.Clear();

            var typeList = _coreData.MachinesTabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetMachineListToDefault(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void SetMachineListToDefault(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (DefaultChecked.Contains(cb.Text))
                    {
                        if (!cb.Checked)
                            cb.Checked = true;

                        dynamic tag = cb.Tag;
                        string machineId = tag.MachineId;
                        string type = tag.Type;
                        string category = tag.Category;
                        _allSelection.Add(machineId, (category, type));
                    }
                    else
                    {
                        if (cb.Checked)
                            cb.Checked = false;
                    }
                }
                else if (control.HasChildren)
                {
                    SetMachineListToDefault(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 加入事件。
        /// </summary>
        private void SetCheckBoxEvent()
        {
            _preventControlsEvents = true;
            var typeList = _coreData.MachinesTabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxEvent(page.Controls, true);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 移除所有 CheckBox 事件。
        /// </summary>
        private void RemoveCheckBoxEvent()
        {
            _preventControlsEvents = true;
            var typeList = _coreData.MachinesTabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxEvent(page.Controls, false);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 遍歷所有 CheckBox 並加入或移除事件 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        /// <param name="addOrRemove">加入或移除。</param>
        private void SetCheckBoxEvent(Control.ControlCollection controls, bool addOrRemove)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (addOrRemove)
                        cb.CheckedChanged += CheckBox_CheckedChanged;
                    else
                        cb.CheckedChanged -= CheckBox_CheckedChanged;
                }
                else if (control.HasChildren)
                {
                    SetCheckBoxEvent(control.Controls, addOrRemove);
                }
            }
        }

        /// <summary>
        /// CheckBox 勾選事件。
        /// </summary>
        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (_preventControlsEvents)
                return;
            if (!(sender is UICheckBox cb) || cb.Tag == null)
                return;

            dynamic tag = cb.Tag;
            string machineId = tag.MachineId;
            string type = tag.Type;
            string category = tag.Category;

            if (cb.Checked)
            {
                if (!_allSelection.ContainsKey(machineId))
                    _allSelection.Add(machineId, (category, type));
            }
            else
            {
                if (_allSelection.ContainsKey(machineId))
                    _allSelection.Remove(machineId);
            }
            SetAndShowSelected();
        }

        /********************
         * RadioButton
         ********************/
        /// <summary>
        /// 清除所有 RadioButton 項目。
        /// </summary>
        private void ClearAllSelected()
        {
            _preventControlsEvents = true;

            _allSelection.Clear();
            var typeList = _coreData.ModelsTabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    ClearAllSelected(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 清除所有 RadioButton 項目 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void ClearAllSelected(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (rb.Checked)
                        rb.Checked = false;
                }
                else if (control.HasChildren)
                {
                    ClearAllChecked(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked。
        /// </summary>
        private void SetModelListToDefault()
        {
            _preventControlsEvents = true;
            _allSelection.Clear();

            var typeList = _coreData.ModelsTabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetModelListToDefault(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void SetModelListToDefault(Control.ControlCollection controls)
        {
            bool notyetChecked = true;
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (notyetChecked && DefaultChecked.Contains(rb.Text))
                    {
                        if (!rb.Checked)
                            rb.Checked = true;

                        dynamic tag = rb.Tag;
                        string name = tag.Model;
                        string type = tag.Type;
                        string category = tag.Category;
                        _allSelection.Add(name, (category, type));

                        notyetChecked = false;
                    }
                    else
                    {
                        if (rb.Checked)
                            rb.Checked = false;
                    }
                }
                else if (control.HasChildren)
                {
                    SetMachineListToDefault(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 RadioButton 加入事件。
        /// </summary>
        private void SetRadioButtonEvent()
        {
            _preventControlsEvents = true;
            var typeList = _coreData.ModelsTabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetRadioButtonEvent(page.Controls, true);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 移除所有 RadioButton 事件。
        /// </summary>
        private void RemoveRadioButtonEvent()
        {
            _preventControlsEvents = true;
            var typeList = _coreData.ModelsTabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetRadioButtonEvent(page.Controls, false);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 遍歷所有 RadioButton 並加入或移除事件 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        /// <param name="addOrRemove">加入或移除。</param>
        private void SetRadioButtonEvent(Control.ControlCollection controls, bool addOrRemove)
        {
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (addOrRemove)
                        rb.CheckedChanged += RadioButton_CheckedChanged;
                    else
                        rb.CheckedChanged -= RadioButton_CheckedChanged;
                }
                else if (control.HasChildren)
                {
                    SetRadioButtonEvent(control.Controls, addOrRemove);
                }
            }
        }

        /// <summary>
        /// RadioButton 點選事件。
        /// </summary>
        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (_preventControlsEvents)
                return;
            if (!(sender is UIRadioButton rb) || rb.Tag == null)
                return;

            _allSelection.Clear();

            dynamic tag = rb.Tag;
            string model = tag.Model;
            string type = tag.Type;
            string category = tag.Category;
            _allSelection.Add(model, (category, type));
            label_ResultList.Text = model;

            SetAndShowSelected();
        }
    }
}
