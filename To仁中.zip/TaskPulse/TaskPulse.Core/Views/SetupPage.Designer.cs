﻿namespace Calin.TaskPulse.Core.Views
{
    partial class SetupPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.uiTreeView_SetupMenu = new Sunny.UI.UITreeView();
            this.panel_Setup = new System.Windows.Forms.Panel();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 5;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.uiTreeView_SetupMenu, 0, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.panel_Setup, 2, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 1;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1117, 676);
            this.tableLayoutPanel_Page.TabIndex = 0;
            // 
            // uiTreeView_SetupMenu
            // 
            this.uiTreeView_SetupMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTreeView_SetupMenu.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiTreeView_SetupMenu.Location = new System.Drawing.Point(3, 6);
            this.uiTreeView_SetupMenu.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.uiTreeView_SetupMenu.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTreeView_SetupMenu.Name = "uiTreeView_SetupMenu";
            this.uiTreeView_SetupMenu.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiTreeView_SetupMenu.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiTreeView_SetupMenu.ScrollBarStyleInherited = false;
            this.uiTreeView_SetupMenu.ShowText = false;
            this.uiTreeView_SetupMenu.Size = new System.Drawing.Size(184, 664);
            this.uiTreeView_SetupMenu.TabIndex = 0;
            this.uiTreeView_SetupMenu.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiTreeView_SetupMenu.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.uiTreeView_SetupMenu_AfterSelect);
            this.uiTreeView_SetupMenu.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.uiTreeView_SetupMenu_NodeMouseClick);
            // 
            // panel_Setup
            // 
            this.panel_Setup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Setup.Location = new System.Drawing.Point(202, 3);
            this.panel_Setup.Name = "panel_Setup";
            this.panel_Setup.Size = new System.Drawing.Size(803, 670);
            this.panel_Setup.TabIndex = 1;
            // 
            // SetupPage
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1117, 676);
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "SetupPage";
            this.Text = "";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private Sunny.UI.UITreeView uiTreeView_SetupMenu;
        private System.Windows.Forms.Panel panel_Setup;
    }
}