﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contract
{
    public interface ICore
    {
        /// <summary>
        /// CoreService 初始化。
        /// </summary>
        Task Initialize();

        /// <summary>
        /// 從資料庫更新核心資料。
        /// </summary>
        Task UpdateCoreDataFromDb();

        /// <summary>
        /// 排序機台。
        /// </summary>
        /// <param name="machineIds">機台列表。</param>
        /// <returns>排序完成的機台列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Machines"/></remarks>
        List<string> SortMachineId(IEnumerable<string> machineIds);

        /// <summary>
        /// 排序機種。
        /// </summary>
        /// <param name="machineIds">機種列表。</param>
        /// <returns>排序完成的機種列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Models"/></remarks>
        List<string> SortModelNames(IEnumerable<string> modelNames);

        /// <summary>
        /// 排序工站。
        /// </summary>
        /// <param name="workstations">工站列表。</param>
        /// <returns>排序完成的工站列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Workstations"/></remarks>
        List<Workstation> SortWorkstations(IEnumerable<Workstation> workstations);
    }
}
