﻿using System.Linq;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Service
{
    public class CoreService : ICore
    {
        private readonly CoreContext _coreContext;
        private readonly CoreData _coreData;

        public CoreService(CoreContext coreContext, CoreData coreData)
        {
            _coreContext = coreContext;
            _coreData = coreData;
        }

        /// <inheritdoc/>
        public void UpdateEmplyees()
        {
            var em = _coreContext.Set<Employee>();
            em.Add(new Employee() { EmployeeId = "08001", Name = "蔡孟堅", IsEngineer = true });
            em.Add(new Employee() { EmployeeId = "08002", Name = "鄭大德", IsEngineer = true });
            em.Add(new Employee() { EmployeeId = "08003", Name = "李起修", IsEngineer = true });
            em.Add(new Employee() { EmployeeId = "08004", Name = "葉柏均", IsEngineer = true });
            em.Add(new Employee() { EmployeeId = "08005", Name = "曾惠鈴", IsEngineer = true });
            em.Add(new Employee() { EmployeeId = "08006", Name = "蔡素貞" });
            em.Add(new Employee() { EmployeeId = "08007", Name = "張志榮" });
            em.Add(new Employee() { EmployeeId = "08008", Name = "賴惠珠" });
            em.Add(new Employee() { EmployeeId = "08009", Name = "侯倩玉" });
            em.Add(new Employee() { EmployeeId = "08010", Name = "李雅婷" });
            em.Add(new Employee() { EmployeeId = "08011", Name = "彭紹軒" });
            em.Add(new Employee() { EmployeeId = "08012", Name = "黎氏鳳" });
            em.Add(new Employee() { EmployeeId = "08013", Name = "阮碧幸" });
            em.Add(new Employee() { EmployeeId = "08014", Name = "盧海燕" });
            em.Add(new Employee() { EmployeeId = "08015", Name = "余沂霈" });
            em.Add(new Employee() { EmployeeId = "08016", Name = "楊瓊瑛" });
            em.Add(new Employee() { EmployeeId = "08017", Name = "陳寶琴" });
            em.Add(new Employee() { EmployeeId = "08018", Name = "劉名峻" });
            em.Add(new Employee() { EmployeeId = "08019", Name = "黃琪雯" });
            em.Add(new Employee() { EmployeeId = "08020", Name = "黃姿蓉" });
            em.Add(new Employee() { EmployeeId = "08021", Name = "林承翰" });
            em.Add(new Employee() { EmployeeId = "08022", Name = "雷舒涵" });
            em.Add(new Employee() { EmployeeId = "08023", Name = "黃嘉惠" });
            em.Add(new Employee() { EmployeeId = "08024", Name = "蔡素真" });
            em.Add(new Employee() { EmployeeId = "08025", Name = "黃玉紅" });
            em.Add(new Employee() { EmployeeId = "08026", Name = "許凱婷" });
            em.Add(new Employee() { EmployeeId = "08027", Name = "林昆達" });
            em.Add(new Employee() { EmployeeId = "08028", Name = "晉玉樹" });
            em.Add(new Employee() { EmployeeId = "08029", Name = "謝定傑", IsEngineer = true });

            _coreContext.SaveChanges();
            _coreData.EmployeeList = em.ToList();
            StrongReferenceMessenger.Default.Send(new CoreDataChangedMessage(_coreData));
        }
    }
}
