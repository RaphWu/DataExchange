﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI_InstantAI
{
    public partial class LowPassFilter
    {
        /********************
         * https://blog.csdn.net/wwwyue1985/article/details/133243741
         * 截至频率选择了20hz，阻尼比 选择了0.707. Const_TS就是转为离散化实现的时候，采样的周期。这里按10K来测试，该值就是100us，代码中要用秒单位，因此是0.0001 另一个常量2Pi就不用解释了。
         ********************/

        static double[] lpf2_yout = new double[3] { 0, 0, 0 };
        static double[] lpf2_xin = new double[3] { 0, 0, 0 };

        //二阶低通滤波器
        public static double LPF2_1(double xin)
        {
            const double Const_2pi = Math.PI * 2;   // 2π
            const double Const_TS = 0.0001;         // 採樣週期 1/10k = 100us

            double f = 200;                  // 截止頻率
            double wc = Const_2pi * f;      // 2πf
            double dampingRatio = 0.707;    // 阻尼比

            double lpf2_b0 = wc * wc * Const_TS * Const_TS;
            double lpf2_a0 = 4 + 4 * dampingRatio * wc * Const_TS + lpf2_b0;
            double lpf2_a1 = -8 + 2 * lpf2_b0;
            //double lpf2_a2 = 4 - 4*dampingRatio*wc*Const_TS  + lpf2_a0; //原始这里应该有误
            double lpf2_a2 = lpf2_b0 + 4 - 4 * dampingRatio * wc * Const_TS;

            lpf2_xin[2] = xin;
            lpf2_yout[2] = (lpf2_b0 * lpf2_xin[2] + 2 * lpf2_b0 * lpf2_xin[1] + lpf2_b0 * lpf2_xin[0] - lpf2_a1 * lpf2_yout[1] - lpf2_a2 * lpf2_yout[0]) / lpf2_a0;
            lpf2_xin[0] = lpf2_xin[1];
            lpf2_xin[1] = lpf2_xin[2];
            lpf2_yout[0] = lpf2_yout[1];
            lpf2_yout[1] = lpf2_yout[2];

            return lpf2_yout[2];
        }

        public static double LPF2_2(double xin)
        {
            double sample_freq = 5000;
            double cutoff_freq = 50;
            double fr = sample_freq / cutoff_freq;

            double ohm = Math.Tan(Math.PI * cutoff_freq / sample_freq);
            double c = 1 + 1.414 * ohm + ohm * ohm;

            double b0 = ohm * ohm / c;
            double b1 = 2.0f * b0;
            double b2 = b0;

            double a1 = 2.0f * (ohm * ohm - 1.0f) / c;
            double a2 = (1.0f - 1.414 * ohm + ohm * ohm) / c;

            lpf2_xin[2] = xin;

            lpf2_yout[2] = b0 * lpf2_xin[2] + b1 * lpf2_xin[1] + b2 * lpf2_xin[0] - a1 * lpf2_yout[1] - a2 * lpf2_yout[0];

            lpf2_xin[0] = lpf2_xin[1];
            lpf2_xin[1] = lpf2_xin[2];
            lpf2_yout[0] = lpf2_yout[1];
            lpf2_yout[1] = lpf2_yout[2];

            return lpf2_yout[2];
        }
    }
}