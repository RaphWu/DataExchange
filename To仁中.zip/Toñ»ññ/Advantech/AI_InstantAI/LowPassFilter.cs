﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI_InstantAI
{
    /********************
     * https://blog.csdn.net/anlog/article/details/129701993
     ********************/
    public partial class LowPassFilter
    {
        double alpha_1;       //滤波系数
        double lastValue_LPF1;
        double lastValue_LPF2;

        // LPF_2
        double fc = 2.0;     //截止频率
        double Ts = 0.02;    //采样周期
        double alpha_2;       //滤波系数
        bool fisrt_flag = true;

        public LowPassFilter(double timeConstant, double deltaTime)
        {
            lastValue_LPF1 = 0.0;
            lastValue_LPF2 = 0.0;

            // LPF_1
            alpha_1 = timeConstant / (timeConstant + deltaTime);

            // LPF_2
            double b = 2.0 * Math.PI * fc * Ts;
            alpha_2 = b / (b + 1);
        }

        public double LPF_1(double inputValue)
        {
            if (fisrt_flag)
            {
                fisrt_flag = false;
                lastValue_LPF1 = inputValue;
            }

            double outputValue = lastValue_LPF1 + alpha_1 * (inputValue - lastValue_LPF1);
            lastValue_LPF1 = outputValue;
            return outputValue;
        }

        /********************
         * https://blog.csdn.net/qq_37662088/article/details/125075600
         ********************/
        public double LPF_2(double xin)
        {
            if (fisrt_flag)
            {
                fisrt_flag = false;
                lastValue_LPF2 = xin;
            }

            double outputValue = lastValue_LPF2 + alpha_2 * (xin - lastValue_LPF2);
            lastValue_LPF2 = outputValue;
            return outputValue;
        }
    }
}
