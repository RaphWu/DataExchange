﻿using System;

namespace ToyoSingleCylinder
{
    /********************
     * 開放給外部的變數與函數
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 電動缸是否準備好接收指令？
        /// </summary>
        /// <returns>true=準備好，false=尚未準備好。</returns>
        public bool Ready
        {
            get
            {
                return _sp != null && _sp.IsOpen
                    && _servoStatus             // Servo ON
                    && _statusPortOut.PortOut01 // 原點
                    && _actionStatus == 0       // 動作狀態
                    && _inpStatus == 1          // 到位訊號狀態
                    && !_inMotion;              // 電動缸運動命令已停止
            }
        }

        /// <summary>
        /// 電動缸是否準備好原點復歸？
        /// </summary>
        /// <returns>true=準備好，false=尚未準備好。</returns>
        public bool ReadyToOriginReturn
        {
            get { return _sp != null && _sp.IsOpen && _servoStatus; }
        }

        /// <summary>
        /// 電動缸是否開啟中？
        /// </summary>
        public bool IsOpen
        {
            get { return _sp != null && _sp.IsOpen; }
        }

        /// <summary>
        /// 輸出腳位。
        /// </summary>
        public PortOutStatus PortOutStatus
        {
            get { return _statusPortOut; }
        }

        /// <summary>
        /// 輸入腳位。
        /// </summary>
        public PortInStatus PortInStatus
        {
            get { return _statusPortIn; }
        }

        /// <summary>
        /// 程式庫運行時間。
        /// </summary>
        public TimeSpan ExceuteTime
        {
            get { return _exceuteTime; }
            internal set
            {
                if (_exceuteTime != value)
                {
                    _exceuteTime = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private TimeSpan _exceuteTime;

        /// <summary>
        /// 取得故障狀態說明。
        /// </summary>
        /// <param name="errorStatus">故障狀態代碼。</param>
        /// <returns>故障狀態說明。</returns>
        public string GetErrorStatusMessage(int errorStatus)
        {
            switch (errorStatus)
            {
                case 0:
                    return "沒有錯誤";
                case 1:
                    return "在動作中接收動作指令";
                case 2:
                    return "上下限錯誤";
                case 3:
                    return "位置錯誤";
                case 4:
                    return "格式錯誤";
                case 5:
                    return "控制模式錯誤";
                case 6:
                    return "斷電重開";
                case 7:
                    return "初始化未完成";
                case 8:
                    return "Servo ON/OFF 錯誤";
                case 9:
                    return "LOCK";
                case 10:
                    return "軟體極限";
                case 11:
                    return "參數寫入權限不足";
                case 12:
                    return "原點復歸未完成";
                case 13:
                    return "剎車已解除";
                default:
                    return "不明錯誤";
            }
        }

        /// <summary>
        /// 取得警報狀態說明。
        /// </summary>
        /// <param name="alarmStatus">警報狀態代碼。</param>
        /// <returns>警報狀態說明。</returns>
        public string GetAlarmStatusMessage(int alarmStatus)
        {
            switch (alarmStatus)
            {
                case 0:
                    return "無警報";
                case 1:
                    return "Loop error";
                case 2:
                    return "Full Count";
                case 3:
                    return "過速度";
                case 4:
                    return "增益值調整不良";
                case 5:
                    return "過電壓";
                case 6:
                    return "初期化異常";
                case 7:
                    return "EEPROM 異常";
                case 8:
                    return "主迴路電源電壓不足";
                case 9:
                    return "過電流";
                case 10:
                    return "回生異常";
                case 11:
                    return "緊急停止";
                case 12:
                    return "馬達斷線";
                case 13:
                    return "編碼器斷線";
                case 14:
                    return "保護電流值";
                case 15:
                    return "電源再投入";
                case 16:
                    return "動作超時";
                default:
                    return "不明錯誤";
            }
        }

        //public List<string> GetErrorHistories()
        //{
        //    return _errorHistories;
        //}

#if DEBUG
        /// <summary>
        /// 取得 Debug 用的訊息。
        /// </summary>
        public DebugMessage DebugMessage
        {
            get { return _debugMessage; }
        }
#endif
    }
}
