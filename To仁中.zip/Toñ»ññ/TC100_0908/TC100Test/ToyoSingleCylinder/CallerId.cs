﻿namespace ToyoSingleCylinder
{
    /// <summary>
    /// 命令呼叫者代碼。
    /// </summary>
    internal enum CallerId
    {
        Initializer,
        Command,
        ReadStatus,
        PortOut,
        PortIn,
        ErrorHistories,

        //WatchDog,
    }
}
