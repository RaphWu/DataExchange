﻿namespace USB4704Test
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Measure = new System.Windows.Forms.Label();
            this.label_MaxMeasure = new System.Windows.Forms.Label();
            this.label_MinMeasure = new System.Windows.Forms.Label();
            this.button_Start = new System.Windows.Forms.Button();
            this.label_adjMeasure = new System.Windows.Forms.Label();
            this.formsPlot1 = new ScottPlot.WinForms.FormsPlot();
            this.button_Stop = new System.Windows.Forms.Button();
            this.groupBox_Mode = new System.Windows.Forms.GroupBox();
            this.radioButton_Streaming = new System.Windows.Forms.RadioButton();
            this.radioButton_Instant = new System.Windows.Forms.RadioButton();
            this.button_Reset = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown_KalmanQ = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_KalmanR = new System.Windows.Forms.NumericUpDown();
            this.label_KalmanQ = new System.Windows.Forms.Label();
            this.label_KalmanR = new System.Windows.Forms.Label();
            this.checkBox_Kalman = new System.Windows.Forms.CheckBox();
            this.checkBox_LPF1_1 = new System.Windows.Forms.CheckBox();
            this.checkBox_LPF2_1 = new System.Windows.Forms.CheckBox();
            this.checkBox_LPF2_2 = new System.Windows.Forms.CheckBox();
            this.groupBox_XTimeRange = new System.Windows.Forms.GroupBox();
            this.radioButton_TimeRange2 = new System.Windows.Forms.RadioButton();
            this.radioButton_TimeRange1 = new System.Windows.Forms.RadioButton();
            this.radioButton_TimeRange0 = new System.Windows.Forms.RadioButton();
            this.groupBox_Mode.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_KalmanQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_KalmanR)).BeginInit();
            this.groupBox_XTimeRange.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_Measure
            // 
            this.label_Measure.AutoSize = true;
            this.label_Measure.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Measure.Location = new System.Drawing.Point(1398, 784);
            this.label_Measure.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Measure.Name = "label_Measure";
            this.label_Measure.Size = new System.Drawing.Size(44, 17);
            this.label_Measure.TabIndex = 0;
            this.label_Measure.Text = "label1";
            // 
            // label_MaxMeasure
            // 
            this.label_MaxMeasure.AutoSize = true;
            this.label_MaxMeasure.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MaxMeasure.Location = new System.Drawing.Point(1398, 832);
            this.label_MaxMeasure.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MaxMeasure.Name = "label_MaxMeasure";
            this.label_MaxMeasure.Size = new System.Drawing.Size(44, 17);
            this.label_MaxMeasure.TabIndex = 1;
            this.label_MaxMeasure.Text = "label1";
            // 
            // label_MinMeasure
            // 
            this.label_MinMeasure.AutoSize = true;
            this.label_MinMeasure.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MinMeasure.Location = new System.Drawing.Point(1398, 856);
            this.label_MinMeasure.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_MinMeasure.Name = "label_MinMeasure";
            this.label_MinMeasure.Size = new System.Drawing.Size(44, 17);
            this.label_MinMeasure.TabIndex = 2;
            this.label_MinMeasure.Text = "label1";
            // 
            // button_Start
            // 
            this.button_Start.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Start.Location = new System.Drawing.Point(381, 786);
            this.button_Start.Margin = new System.Windows.Forms.Padding(4);
            this.button_Start.Name = "button_Start";
            this.button_Start.Size = new System.Drawing.Size(111, 42);
            this.button_Start.TabIndex = 4;
            this.button_Start.Text = "Start";
            this.button_Start.UseVisualStyleBackColor = true;
            this.button_Start.Click += new System.EventHandler(this.button_Start_Click);
            // 
            // label_adjMeasure
            // 
            this.label_adjMeasure.AutoSize = true;
            this.label_adjMeasure.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_adjMeasure.Location = new System.Drawing.Point(1398, 808);
            this.label_adjMeasure.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_adjMeasure.Name = "label_adjMeasure";
            this.label_adjMeasure.Size = new System.Drawing.Size(44, 17);
            this.label_adjMeasure.TabIndex = 8;
            this.label_adjMeasure.Text = "label1";
            // 
            // formsPlot1
            // 
            this.formsPlot1.DisplayScale = 0F;
            this.formsPlot1.Location = new System.Drawing.Point(16, 17);
            this.formsPlot1.Margin = new System.Windows.Forms.Padding(4);
            this.formsPlot1.Name = "formsPlot1";
            this.formsPlot1.Size = new System.Drawing.Size(1500, 750);
            this.formsPlot1.TabIndex = 9;
            // 
            // button_Stop
            // 
            this.button_Stop.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Stop.Location = new System.Drawing.Point(381, 843);
            this.button_Stop.Margin = new System.Windows.Forms.Padding(4);
            this.button_Stop.Name = "button_Stop";
            this.button_Stop.Size = new System.Drawing.Size(111, 42);
            this.button_Stop.TabIndex = 10;
            this.button_Stop.Text = "Stop";
            this.button_Stop.UseVisualStyleBackColor = true;
            this.button_Stop.Click += new System.EventHandler(this.button_Stop_Click);
            // 
            // groupBox_Mode
            // 
            this.groupBox_Mode.Controls.Add(this.radioButton_Streaming);
            this.groupBox_Mode.Controls.Add(this.radioButton_Instant);
            this.groupBox_Mode.Location = new System.Drawing.Point(182, 787);
            this.groupBox_Mode.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_Mode.Name = "groupBox_Mode";
            this.groupBox_Mode.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_Mode.Size = new System.Drawing.Size(172, 70);
            this.groupBox_Mode.TabIndex = 11;
            this.groupBox_Mode.TabStop = false;
            this.groupBox_Mode.Text = "模式";
            // 
            // radioButton_Streaming
            // 
            this.radioButton_Streaming.AutoSize = true;
            this.radioButton_Streaming.Location = new System.Drawing.Point(35, 41);
            this.radioButton_Streaming.Name = "radioButton_Streaming";
            this.radioButton_Streaming.Size = new System.Drawing.Size(88, 21);
            this.radioButton_Streaming.TabIndex = 15;
            this.radioButton_Streaming.TabStop = true;
            this.radioButton_Streaming.Text = "Streaming";
            this.radioButton_Streaming.UseVisualStyleBackColor = true;
            this.radioButton_Streaming.CheckedChanged += new System.EventHandler(this.radioButton_Streaming_CheckedChanged);
            // 
            // radioButton_Instant
            // 
            this.radioButton_Instant.AutoSize = true;
            this.radioButton_Instant.Location = new System.Drawing.Point(35, 21);
            this.radioButton_Instant.Name = "radioButton_Instant";
            this.radioButton_Instant.Size = new System.Drawing.Size(69, 21);
            this.radioButton_Instant.TabIndex = 14;
            this.radioButton_Instant.TabStop = true;
            this.radioButton_Instant.Text = "Instant";
            this.radioButton_Instant.UseVisualStyleBackColor = true;
            this.radioButton_Instant.CheckedChanged += new System.EventHandler(this.radioButton_Instant_CheckedChanged);
            // 
            // button_Reset
            // 
            this.button_Reset.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Reset.Location = new System.Drawing.Point(521, 787);
            this.button_Reset.Margin = new System.Windows.Forms.Padding(4);
            this.button_Reset.Name = "button_Reset";
            this.button_Reset.Size = new System.Drawing.Size(111, 42);
            this.button_Reset.TabIndex = 12;
            this.button_Reset.Text = "Reset";
            this.button_Reset.UseVisualStyleBackColor = true;
            this.button_Reset.Click += new System.EventHandler(this.button_Reset_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown_KalmanQ);
            this.groupBox1.Controls.Add(this.numericUpDown_KalmanR);
            this.groupBox1.Controls.Add(this.label_KalmanQ);
            this.groupBox1.Controls.Add(this.label_KalmanR);
            this.groupBox1.Location = new System.Drawing.Point(663, 787);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(237, 95);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kalman";
            // 
            // numericUpDown_KalmanQ
            // 
            this.numericUpDown_KalmanQ.DecimalPlaces = 3;
            this.numericUpDown_KalmanQ.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown_KalmanQ.Location = new System.Drawing.Point(141, 60);
            this.numericUpDown_KalmanQ.Name = "numericUpDown_KalmanQ";
            this.numericUpDown_KalmanQ.Size = new System.Drawing.Size(85, 25);
            this.numericUpDown_KalmanQ.TabIndex = 7;
            this.numericUpDown_KalmanQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_KalmanQ.ValueChanged += new System.EventHandler(this.numericUpDown_KalmanQ_ValueChanged);
            // 
            // numericUpDown_KalmanR
            // 
            this.numericUpDown_KalmanR.DecimalPlaces = 3;
            this.numericUpDown_KalmanR.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDown_KalmanR.Location = new System.Drawing.Point(141, 29);
            this.numericUpDown_KalmanR.Name = "numericUpDown_KalmanR";
            this.numericUpDown_KalmanR.Size = new System.Drawing.Size(85, 25);
            this.numericUpDown_KalmanR.TabIndex = 6;
            this.numericUpDown_KalmanR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown_KalmanR.ValueChanged += new System.EventHandler(this.numericUpDown_KalmanR_ValueChanged);
            // 
            // label_KalmanQ
            // 
            this.label_KalmanQ.AutoSize = true;
            this.label_KalmanQ.Location = new System.Drawing.Point(7, 64);
            this.label_KalmanQ.Name = "label_KalmanQ";
            this.label_KalmanQ.Size = new System.Drawing.Size(128, 17);
            this.label_KalmanQ.TabIndex = 5;
            this.label_KalmanQ.Text = "Measurement noise";
            this.label_KalmanQ.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_KalmanR
            // 
            this.label_KalmanR.AutoSize = true;
            this.label_KalmanR.Location = new System.Drawing.Point(46, 33);
            this.label_KalmanR.Name = "label_KalmanR";
            this.label_KalmanR.Size = new System.Drawing.Size(89, 17);
            this.label_KalmanR.TabIndex = 3;
            this.label_KalmanR.Text = "Process noise";
            this.label_KalmanR.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // checkBox_Kalman
            // 
            this.checkBox_Kalman.AutoSize = true;
            this.checkBox_Kalman.Checked = true;
            this.checkBox_Kalman.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_Kalman.Location = new System.Drawing.Point(31, 788);
            this.checkBox_Kalman.Name = "checkBox_Kalman";
            this.checkBox_Kalman.Size = new System.Drawing.Size(83, 21);
            this.checkBox_Kalman.TabIndex = 17;
            this.checkBox_Kalman.Text = "checkBox";
            this.checkBox_Kalman.UseVisualStyleBackColor = true;
            this.checkBox_Kalman.CheckedChanged += new System.EventHandler(this.checkBox_Kalman_CheckedChanged);
            // 
            // checkBox_LPF1_1
            // 
            this.checkBox_LPF1_1.AutoSize = true;
            this.checkBox_LPF1_1.Checked = true;
            this.checkBox_LPF1_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_LPF1_1.Location = new System.Drawing.Point(31, 812);
            this.checkBox_LPF1_1.Name = "checkBox_LPF1_1";
            this.checkBox_LPF1_1.Size = new System.Drawing.Size(83, 21);
            this.checkBox_LPF1_1.TabIndex = 18;
            this.checkBox_LPF1_1.Text = "checkBox";
            this.checkBox_LPF1_1.UseVisualStyleBackColor = true;
            this.checkBox_LPF1_1.CheckedChanged += new System.EventHandler(this.checkBox_LPF1_1_CheckedChanged);
            // 
            // checkBox_LPF2_1
            // 
            this.checkBox_LPF2_1.AutoSize = true;
            this.checkBox_LPF2_1.Checked = true;
            this.checkBox_LPF2_1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_LPF2_1.Location = new System.Drawing.Point(31, 836);
            this.checkBox_LPF2_1.Name = "checkBox_LPF2_1";
            this.checkBox_LPF2_1.Size = new System.Drawing.Size(83, 21);
            this.checkBox_LPF2_1.TabIndex = 19;
            this.checkBox_LPF2_1.Text = "checkBox";
            this.checkBox_LPF2_1.UseVisualStyleBackColor = true;
            this.checkBox_LPF2_1.CheckedChanged += new System.EventHandler(this.checkBox_LPF2_1_CheckedChanged);
            // 
            // checkBox_LPF2_2
            // 
            this.checkBox_LPF2_2.AutoSize = true;
            this.checkBox_LPF2_2.Checked = true;
            this.checkBox_LPF2_2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_LPF2_2.Location = new System.Drawing.Point(31, 860);
            this.checkBox_LPF2_2.Name = "checkBox_LPF2_2";
            this.checkBox_LPF2_2.Size = new System.Drawing.Size(83, 21);
            this.checkBox_LPF2_2.TabIndex = 20;
            this.checkBox_LPF2_2.Text = "checkBox";
            this.checkBox_LPF2_2.UseVisualStyleBackColor = true;
            this.checkBox_LPF2_2.CheckedChanged += new System.EventHandler(this.checkBox_LPF2_2_CheckedChanged);
            // 
            // groupBox_XTimeRange
            // 
            this.groupBox_XTimeRange.Controls.Add(this.radioButton_TimeRange2);
            this.groupBox_XTimeRange.Controls.Add(this.radioButton_TimeRange1);
            this.groupBox_XTimeRange.Controls.Add(this.radioButton_TimeRange0);
            this.groupBox_XTimeRange.Location = new System.Drawing.Point(182, 865);
            this.groupBox_XTimeRange.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_XTimeRange.Name = "groupBox_XTimeRange";
            this.groupBox_XTimeRange.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_XTimeRange.Size = new System.Drawing.Size(172, 88);
            this.groupBox_XTimeRange.TabIndex = 16;
            this.groupBox_XTimeRange.TabStop = false;
            this.groupBox_XTimeRange.Text = "X軸時間間距";
            // 
            // radioButton_TimeRange2
            // 
            this.radioButton_TimeRange2.AutoSize = true;
            this.radioButton_TimeRange2.Location = new System.Drawing.Point(35, 60);
            this.radioButton_TimeRange2.Name = "radioButton_TimeRange2";
            this.radioButton_TimeRange2.Size = new System.Drawing.Size(58, 21);
            this.radioButton_TimeRange2.TabIndex = 16;
            this.radioButton_TimeRange2.Text = "60 秒";
            this.radioButton_TimeRange2.UseVisualStyleBackColor = true;
            this.radioButton_TimeRange2.CheckedChanged += new System.EventHandler(this.radioButton_TimeRange3_CheckedChanged);
            // 
            // radioButton_TimeRange1
            // 
            this.radioButton_TimeRange1.AutoSize = true;
            this.radioButton_TimeRange1.Location = new System.Drawing.Point(35, 39);
            this.radioButton_TimeRange1.Name = "radioButton_TimeRange1";
            this.radioButton_TimeRange1.Size = new System.Drawing.Size(58, 21);
            this.radioButton_TimeRange1.TabIndex = 15;
            this.radioButton_TimeRange1.Text = "30 秒";
            this.radioButton_TimeRange1.UseVisualStyleBackColor = true;
            this.radioButton_TimeRange1.CheckedChanged += new System.EventHandler(this.radioButton_TimeRange2_CheckedChanged);
            // 
            // radioButton_TimeRange0
            // 
            this.radioButton_TimeRange0.AutoSize = true;
            this.radioButton_TimeRange0.Checked = true;
            this.radioButton_TimeRange0.Location = new System.Drawing.Point(35, 19);
            this.radioButton_TimeRange0.Name = "radioButton_TimeRange0";
            this.radioButton_TimeRange0.Size = new System.Drawing.Size(58, 21);
            this.radioButton_TimeRange0.TabIndex = 14;
            this.radioButton_TimeRange0.TabStop = true;
            this.radioButton_TimeRange0.Text = "10 秒";
            this.radioButton_TimeRange0.UseVisualStyleBackColor = true;
            this.radioButton_TimeRange0.CheckedChanged += new System.EventHandler(this.radioButton_TimeRange1_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1534, 961);
            this.Controls.Add(this.groupBox_XTimeRange);
            this.Controls.Add(this.checkBox_LPF2_2);
            this.Controls.Add(this.checkBox_LPF2_1);
            this.Controls.Add(this.checkBox_LPF1_1);
            this.Controls.Add(this.checkBox_Kalman);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button_Reset);
            this.Controls.Add(this.groupBox_Mode);
            this.Controls.Add(this.button_Stop);
            this.Controls.Add(this.formsPlot1);
            this.Controls.Add(this.label_adjMeasure);
            this.Controls.Add(this.button_Start);
            this.Controls.Add(this.label_MinMeasure);
            this.Controls.Add(this.label_MaxMeasure);
            this.Controls.Add(this.label_Measure);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "USB-4704 & T22";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.groupBox_Mode.ResumeLayout(false);
            this.groupBox_Mode.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_KalmanQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_KalmanR)).EndInit();
            this.groupBox_XTimeRange.ResumeLayout(false);
            this.groupBox_XTimeRange.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Measure;
        private System.Windows.Forms.Label label_MaxMeasure;
        private System.Windows.Forms.Label label_MinMeasure;
        private System.Windows.Forms.Button button_Start;
        private System.Windows.Forms.Label label_adjMeasure;
        private ScottPlot.WinForms.FormsPlot formsPlot1;
        private System.Windows.Forms.Button button_Stop;
        private System.Windows.Forms.GroupBox groupBox_Mode;
        private System.Windows.Forms.RadioButton radioButton_Streaming;
        private System.Windows.Forms.RadioButton radioButton_Instant;
        private System.Windows.Forms.Button button_Reset;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label_KalmanR;
        private System.Windows.Forms.Label label_KalmanQ;
        private System.Windows.Forms.NumericUpDown numericUpDown_KalmanR;
        private System.Windows.Forms.NumericUpDown numericUpDown_KalmanQ;
        private System.Windows.Forms.CheckBox checkBox_Kalman;
        private System.Windows.Forms.CheckBox checkBox_LPF1_1;
        private System.Windows.Forms.CheckBox checkBox_LPF2_1;
        private System.Windows.Forms.CheckBox checkBox_LPF2_2;
        private System.Windows.Forms.GroupBox groupBox_XTimeRange;
        private System.Windows.Forms.RadioButton radioButton_TimeRange2;
        private System.Windows.Forms.RadioButton radioButton_TimeRange1;
        private System.Windows.Forms.RadioButton radioButton_TimeRange0;
    }
}

