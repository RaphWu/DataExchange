﻿namespace ToyoSingleCylinder
{
    /********************
     * 電動缸狀態。(此檔內的屬性直接開放外部讀取)
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 伺服狀態 ON/FF。
        /// </summary>
        public bool ServoStatus
        {
            get { return _servoStatus; }
            private set
            {
                if (_servoStatus != value)
                {
                    _servoStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    //NotifyPropertyChanged(nameof(ServoStatusMessage));
                    NotifyPropertyChanged("Ready");
                    NotifyPropertyChanged("ServoStatusMessage");
                }
            }
        }
        private bool _servoStatus;

        /// <summary>
        /// 伺服狀態 ON/FF 的文字訊息。
        /// </summary>
        public string ServoStatusMessage
        {
            get { return ServoStatus ? "伺服ON" : "伺服OFF"; }
        }

        /// <summary>
        /// 動作狀態。
        /// </summary>
        public int ActionStatus
        {
            get { return _actionStatus; }
            private set
            {
                if (_actionStatus != value)
                {
                    _actionStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private int _actionStatus;

        public string ActionStatusMessage
        {
            get { return ActionStatus == 0 ? "停止" : ActionStatus == 1 ? "動作中" : "異常停止"; }
        }

        /// <summary>
        /// 到位訊號狀態。
        /// </summary>
        public int InpStatus
        {
            get { return _inpStatus; }
            private set
            {
                if (_inpStatus != value)
                {
                    _inpStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private int _inpStatus;

        public string InpStatusMessage
        {
            get { return InpStatus == 1 ? "位置已在設定範圍內" : "尚未到達設定範圍內"; }
        }

        /// <summary>
        /// 扭力極限狀態。
        /// </summary>
        public int TrqLmtStatus
        {
            get { return _trqLmtStatus; }
            private set
            {
                if (_trqLmtStatus != value)
                {
                    _trqLmtStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _trqLmtStatus;

        public string TrqLmtStatusMessage
        {
            get { return TrqLmtStatus == 1 ? "已在設定範圍內" : "未到設定範圍內"; }
        }

        /// <summary>
        /// 警報狀態。
        /// </summary>
        public int AlarmStatus
        {
            get { return _alarmStatus; }
            private set
            {
                if (_alarmStatus != value)
                {
                    _alarmStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _alarmStatus;

        public string AlarmStatusMessage
        {
            get { return GetAlarmStatusMessage(AlarmStatus); }
        }

        /// <summary>
        /// 故障狀態。
        /// </summary>
        public int ErrorStatus
        {
            get { return _errorStatus; }
            private set
            {
                if (_errorStatus != value)
                {
                    _errorStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _errorStatus;

        public string ErrorStatusMessage
        {
            get { return GetErrorStatusMessage(ErrorStatus); }
        }

        /// <summary>
        /// 馬達轉速 RPM。
        /// </summary>
        public int MonRpm
        {
            get { return _monRpm; }
            private set
            {
                if (_monRpm != value)
                {
                    _monRpm = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _monRpm;

        ///// <summary>
        ///// 馬達轉速。
        ///// </summary>
        //[Description("馬達轉速")]
        //public int MonSpeed { get; set; }

        /// <summary>
        /// 馬達電流值。
        /// </summary>
        public double MonCurrent
        {
            get { return _monCurrent; }
            private set
            {
                if (_monCurrent != value)
                {
                    _monCurrent = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _monCurrent;

        /// <summary>
        /// 指令現在位置。
        /// </summary>
        public double CmdNowPos
        {
            get { return _cmdNowPos; }
            private set
            {
                if (_cmdNowPos != value)
                {
                    _cmdNowPos = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _cmdNowPos;

        /// <summary>
        /// 編碼器位置。
        /// </summary>
        public double EcdPos
        {
            get { return _ecdPos; }
            private set
            {
                if (_ecdPos != value)
                {
                    _ecdPos = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _ecdPos;

        /***** 自訂狀態 *****/
        /// <summary>
        /// 電動缸運動命令是否在執行中？
        /// </summary>
        public bool InMotion
        {
            get { return _inMotion; }
            private set
            {
                if (_inMotion != value)
                {
                    _inMotion = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private bool _inMotion;
    }
}
