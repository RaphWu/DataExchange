﻿namespace EF6SQLite
{
    public class Bus
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
    public class Person
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
