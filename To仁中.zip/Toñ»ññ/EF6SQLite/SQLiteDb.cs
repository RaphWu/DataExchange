﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace EF6SQLite
{
    public class SQLiteDb : DbContext
    {
        public SQLiteDb() : base("DefaultConnection")
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<SQLiteDb, Configuration>());
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Configurations.AddFromAssembly(typeof(SQLiteDb).Assembly);
        }
    }
}
