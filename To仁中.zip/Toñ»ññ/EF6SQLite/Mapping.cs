﻿using System.Data.Entity.ModelConfiguration;

namespace EF6SQLite
{
    public class Mapping
    {
        public class BusMap : EntityTypeConfiguration<Bus>
        {
            public BusMap()
            {
            }
        }

        public class PersonMap : EntityTypeConfiguration<Person>
        {
            public PersonMap()
            {
            }
        }
    }
}
