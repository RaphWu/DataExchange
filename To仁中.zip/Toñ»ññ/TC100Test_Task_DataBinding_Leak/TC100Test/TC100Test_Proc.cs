﻿using System;
using System.Linq;
using System.Threading;

namespace TC100Test
{
    public partial class TC100Test
    {
        /// <summary>
        /// 更新 Serial Port 選擇器。
        /// </summary>
        private void UpdateSerialPortParamsSelector()
        {
            System.IO.Ports.SerialPort serial = new System.IO.Ports.SerialPort();

            string[] portNameList = System.IO.Ports.SerialPort.GetPortNames();
            Array.Sort(portNameList);
            comboBox_COM.Items.Clear();
            comboBox_COM.Items.AddRange(portNameList);
            comboBox_COM.SelectedIndex = 0;

            comboBox_BaudRate.Items.Clear();
            comboBox_BaudRate.Items.AddRange((new int[] { 2400, 4800, 9600, 19200, 38400, 57600, 115200 }).Cast<object>().ToArray());
            comboBox_BaudRate.SelectedItem = 19200;

            comboBox_Parity.Items.Clear();
            comboBox_Parity.Items.AddRange(Enum.GetValues(typeof(System.IO.Ports.Parity)).Cast<object>().ToArray());
            comboBox_Parity.SelectedItem = System.IO.Ports.Parity.None;

            textBox_DataBits.Text = "8";

            comboBox_StopBits.Items.Clear();
            comboBox_StopBits.Items.AddRange(Enum.GetValues(typeof(System.IO.Ports.StopBits)).Cast<object>().ToArray());
            comboBox_StopBits.SelectedItem = System.IO.Ports.StopBits.One;
        }

        //static uint cc = 0;
        /// <summary>
        /// 畫面更新。
        /// </summary>
        private void ScreenUpdatePolling(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    // 須隨時檢查電動缸是否仍在開啟狀態
                    if (!_tsc.IsOpen)
                    {
                        Disconnct();
                        break;
                    }

                    //if (++cc % 100000 == 0)
                    //    Console.WriteLine("Memory: {0:n0}%", memory.NextValue());
                }
                catch (OperationCanceledException)
                {
                    // do nothing for CancellationTokenSource
                }
            }
        }
    }
}
