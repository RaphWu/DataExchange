﻿namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        const int ONE_WORD = 4; // 1 Word = 4 bytes
        const int TWO_WORD = 8; // 2 Words = 8 bytes
    }
}
