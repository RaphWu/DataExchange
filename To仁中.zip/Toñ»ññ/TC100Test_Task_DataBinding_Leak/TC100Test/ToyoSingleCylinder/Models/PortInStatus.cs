﻿namespace ToyoSingleCylinder
{
    /// <summary>
    /// 輸入訊號。
    /// </summary>
    public class PortInStatus : BindableBase
    {
        ///// <summary>
        ///// 是否已更新？
        ///// </summary>
        //public bool Updated { get; set; }

        /// <summary>
        /// 輸入訊號 01。
        /// </summary>
        /// <remarks>ORG。</remarks>
        public bool PortIn01
        {
            get { return _PortIn01; }
            set
            {
                if (_PortIn01 != value)
                {
                    _PortIn01 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn01;

        /// <summary>
        /// 輸入訊號 02。
        /// </summary>
        /// <remarks>SERVO ON/OFF。</remarks>
        public bool PortIn02
        {
            get { return _PortIn02; }
            set
            {
                if (_PortIn02 != value)
                {
                    _PortIn02 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn02;

        /// <summary>
        /// 輸入訊號 03。
        /// </summary>
        /// <remarks>ALR_RESET。</remarks>
        public bool PortIn03
        {
            get { return _PortIn03; }
            set
            {
                if (_PortIn03 != value)
                {
                    _PortIn03 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn03;

        /// <summary>
        /// 輸入訊號 04。
        /// </summary>
        /// <remarks>START。</remarks>
        public bool PortIn04
        {
            get { return _PortIn04; }
            set
            {
                if (_PortIn04 != value)
                {
                    _PortIn04 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn04;

        /// <summary>
        /// 輸入訊號 05。
        /// </summary>
        /// <remarks>PRGSEL0。</remarks>
        public bool PortIn05
        {
            get { return _PortIn05; }
            set
            {
                if (_PortIn05 != value)
                {
                    _PortIn05 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn05;

        /// <summary>
        /// 輸入訊號 06。
        /// </summary>
        /// <remarks>PRGSEL1。</remarks>
        public bool PortIn06
        {
            get { return _PortIn06; }
            set
            {
                if (_PortIn06 != value)
                {
                    _PortIn06 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn06;

        /// <summary>
        /// 輸入訊號 07。
        /// </summary>
        /// <remarks>PRGSEL2。</remarks>
        public bool PortIn07
        {
            get { return _PortIn07; }
            set
            {
                if (_PortIn07 != value)
                {
                    _PortIn07 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn07;

        /// <summary>
        /// 輸入訊號 08。
        /// </summary>
        /// <remarks>PRGSEL3。</remarks>
        public bool PortIn08
        {
            get { return _PortIn08; }
            set
            {
                if (_PortIn08 != value)
                {
                    _PortIn08 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn08;

        /// <summary>
        /// 輸入訊號 09。
        /// </summary>
        /// <remarks>LOCK。</remarks>
        public bool PortIn09
        {
            get { return _PortIn09; }
            set
            {
                if (_PortIn09 != value)
                {
                    _PortIn09 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn09;

        /// <summary>
        /// 輸入訊號 10。
        /// </summary>
        /// <remarks>MANUAL。</remarks>
        public bool PortIn10
        {
            get { return _PortIn10; }
            set
            {
                if (_PortIn10 != value)
                {
                    _PortIn10 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn10;

        /// <summary>
        /// 輸入訊號 11。
        /// </summary>
        /// <remarks>IN11。</remarks>
        public bool PortIn11
        {
            get { return _PortIn11; }
            set
            {
                if (_PortIn11 != value)
                {
                    _PortIn11 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn11;

        /// <summary>
        /// 輸入訊號 12。
        /// </summary>
        /// <remarks>IN12。</remarks>
        public bool PortIn12
        {
            get { return _PortIn12; }
            set
            {
                if (_PortIn12 != value)
                {
                    _PortIn12 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn12;

        /// <summary>
        /// 輸入訊號 13。
        /// </summary>
        /// <remarks>IN13。</remarks>
        public bool PortIn13
        {
            get { return _PortIn13; }
            set
            {
                if (_PortIn13 != value)
                {
                    _PortIn13 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn13;

        /// <summary>
        /// 輸入訊號 14。
        /// </summary>
        /// <remarks>IN14。</remarks>
        public bool PortIn14
        {
            get { return _PortIn14; }
            set
            {
                if (_PortIn14 != value)
                {
                    _PortIn14 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _PortIn14;
    }
}
