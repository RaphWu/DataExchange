﻿using System;

namespace ToyoSingleCylinder
{
    public struct FrameStruct
    {
        public CallerId CallerId { get; set; }
        public byte[] ByteArray { get; set; }
        //public DateTime EnqueuedTime { get; set; }
    }
}
