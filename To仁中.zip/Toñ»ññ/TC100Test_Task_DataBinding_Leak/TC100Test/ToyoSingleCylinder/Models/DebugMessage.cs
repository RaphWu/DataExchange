﻿#if DEBUG

namespace ToyoSingleCylinder
{
    /********************
     * DEBUG用訊息存放區。
     ********************/
    public class DebugMessage : BindableBase
    {
        //public bool Updated { get; set; }

        public string RequestFrame
        {
            get { return _RequestFrame; }
            set
            {
                if (_RequestFrame != value)
                {
                    _RequestFrame = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _RequestFrame;

        public string ResponseFrame
        {
            get { return _ResponseFrame; }
            set
            {
                if (_ResponseFrame != value)
                {
                    _ResponseFrame = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _ResponseFrame;

        public string ConsoleMessage
        {
            get { return _ConsoleMessage; }
            set
            {
                if (_ConsoleMessage != value)
                {
                    _ConsoleMessage = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _ConsoleMessage;

        public string ErrorMessage
        {
            get { return _ErrorMessage; }
            set
            {
                if (_ErrorMessage != value)
                {
                    _ErrorMessage = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _ErrorMessage;
    }
}

#endif