﻿namespace ToyoSingleCylinder
{
    /********************
     * 電動缸狀態。(此檔內的屬性直接開放外部讀取)
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 伺服狀態 ON/FF。
        /// </summary>
        public bool ServoStatus
        {
            get { return _ServoStatus; }
            private set
            {
                if (_ServoStatus != value)
                {
                    _ServoStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    //NotifyPropertyChanged(nameof(ServoStatusMessage));
                    NotifyPropertyChanged("Ready");
                    NotifyPropertyChanged("ServoStatusMessage");
                }
            }
        }
        private bool _ServoStatus;

        /// <summary>
        /// 伺服狀態 ON/FF 的文字訊息。
        /// </summary>
        public string ServoStatusMessage
        {
            get { return ServoStatus ? "伺服ON" : "伺服OFF"; }
        }

        /// <summary>
        /// 動作狀態。
        /// </summary>
        public int ActionStatus
        {
            get { return _ActionStatus; }
            private set
            {
                if (_ActionStatus != value)
                {
                    _ActionStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private int _ActionStatus;

        public string ActionStatusMessage
        {
            get { return ActionStatus == 0 ? "停止" : ActionStatus == 1 ? "動作中" : "異常停止"; }
        }

        /// <summary>
        /// 到位訊號目前的狀態。
        /// </summary>
        public int InpStatus
        {
            get { return _InpStatus; }
            private set
            {
                if (_InpStatus != value)
                {
                    _InpStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private int _InpStatus;

        public string InpStatusMessage
        {
            get { return InpStatus == 1 ? "位置已在設定範圍內" : "尚未到達設定範圍內"; }
        }

        /// <summary>
        /// 扭力極限狀態。
        /// </summary>
        public int TrqLmtStatus
        {
            get { return _TrqLmtStatus; }
            private set
            {
                if (_TrqLmtStatus != value)
                {
                    _TrqLmtStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _TrqLmtStatus;

        public string TrqLmtStatusMessage
        {
            get { return TrqLmtStatus == 1 ? "已在設定範圍內" : "未到設定範圍內"; }
        }

        /// <summary>
        /// 警報狀態。
        /// </summary>
        public int AlarmStatus
        {
            get { return _AlarmStatus; }
            private set
            {
                if (_AlarmStatus != value)
                {
                    _AlarmStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _AlarmStatus;

        public string AlarmStatusMessage
        {
            get { return GetAlarmStatusMessage(AlarmStatus); }
        }

        /// <summary>
        /// 故障狀態。
        /// </summary>
        public int ErrorStatus
        {
            get { return _ErrorStatus; }
            private set
            {
                if (_ErrorStatus != value)
                {
                    _ErrorStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _ErrorStatus;

        public string ErrorStatusMessage
        {
            get { return GetErrorStatusMessage(ErrorStatus); }
        }

        /// <summary>
        /// 馬達轉速 RPM。
        /// </summary>
        public int MonRpm
        {
            get { return _MonRpm; }
            private set
            {
                if (_MonRpm != value)
                {
                    _MonRpm = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _MonRpm;

        ///// <summary>
        ///// 馬達轉速。
        ///// </summary>
        //[Description("馬達轉速")]
        //public int MonSpeed { get; set; }

        /// <summary>
        /// 馬達電流值。
        /// </summary>
        public double MonCurrent
        {
            get { return _MonCurrent; }
            private set
            {
                if (_MonCurrent != value)
                {
                    _MonCurrent = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _MonCurrent;

        /// <summary>
        /// 指令現在位置。
        /// </summary>
        public double CmdNowPos
        {
            get { return _CmdNowPos; }
            private set
            {
                if (_CmdNowPos != value)
                {
                    _CmdNowPos = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _CmdNowPos;

        /// <summary>
        /// 編碼器位置。
        /// </summary>
        public double EcdPos
        {
            get { return _EcdPos; }
            private set
            {
                if (_EcdPos != value)
                {
                    _EcdPos = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _EcdPos;

        /***** 自訂狀態 *****/
        /// <summary>
        /// 電動缸是否正在運動中？
        /// </summary>
        public bool InMotion
        {
            get { return _InMotion; }
            private set
            {
                if (_InMotion != value)
                {
                    _InMotion = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private bool _InMotion;
    }
}
