﻿using System;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        private static byte Lrc(byte[] frame)
        {
            byte lrc = 0;
            for (int i = 0; i < frame.Length; i++)
                lrc += frame[i];

            return (byte)((lrc ^ 0xFF) + 1);
        }

        private static byte AsciiLrc(string frame)
        {
            byte lrc = 0;
            if (frame.Substring(0, 1) == ":")
                frame = frame.Substring(1);

            for (int i = 0; i < frame.Length; i += 2)
            {
                int t = Convert.ToInt16(frame.Substring(i, 2), 16);
                lrc += (byte)t;
            }

            return (byte)((lrc ^ 0xFF) + 1);
        }
    }
}
