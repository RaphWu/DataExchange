﻿using System;
using System.Text;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 限制 Queue 最大容量。
        /// </summary>
        const int MAX_QUEUE_CAPACITY = 100;

        private void HighPriorityRequest(CallerId callerId, byte[] requestFrame)
        {
            if (_highPriorityQueue.Count < MAX_QUEUE_CAPACITY)
            {
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                //frame.EnqueuedTime = DateTime.Now;
                _highPriorityQueue.Enqueue(frame);
            }
        }

        private void HighPriorityRequest(CallerId callerId, byte functionCode, int data, int length)
        {
            HighPriorityRequest(callerId, GetRequestFrame(functionCode, data, length));
        }

        private void HighPriorityRequest(CallerId callerId, string requestFrame)
        {
            HighPriorityRequest(callerId, Encoding.ASCII.GetBytes(requestFrame));
        }

        private void ResendFrame(FrameStruct frame)
        {
            if (_retryQueue.Count < MAX_QUEUE_CAPACITY)
                _retryQueue.Enqueue(frame);
        }

        private void SendRequestFrame(CallerId callerId, byte[] requestFrame)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                //frame.EnqueuedTime = DateTime.Now;
                _requestQueue.Enqueue(frame);
            }
        }

        private void SendRequestFrame(CallerId callerId, byte functionCode, int data, int length)
        {
            SendRequestFrame(callerId, GetRequestFrame(functionCode, data, length));
        }

        private void SendRequestFrame(CallerId callerId, string requestString, bool includeLRC = false)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                StringBuilder sb = new StringBuilder(100);
                byte[] requestFrame;
                if (includeLRC)
                {
                    sb.Append(requestString).Append("\r\n");
                    //requestFrame = Encoding.ASCII.GetBytes(string.Concat(requestString, "\r\n"));
                }
                else
                {
                    int lrc = AsciiLrc(requestString);
                    sb.Append(requestString).Append(lrc.ToString("X2")).Append("\r\n");
                }
                requestFrame = Encoding.ASCII.GetBytes(sb.ToString());  

                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                //frame.EnqueuedTime = DateTime.Now;
                _requestQueue.Enqueue(frame);
            }
        }
    }
}
