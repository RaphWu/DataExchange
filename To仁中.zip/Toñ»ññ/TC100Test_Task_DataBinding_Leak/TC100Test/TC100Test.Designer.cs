﻿namespace TC100Test
{
    partial class TC100Test
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label_MotorStatus = new System.Windows.Forms.Label();
            this.textBox_MotorStatus = new System.Windows.Forms.TextBox();
            this.textBox_MotorAlarm = new System.Windows.Forms.TextBox();
            this.label_MotorAlarm = new System.Windows.Forms.Label();
            this.textBox_MotorRPM = new System.Windows.Forms.TextBox();
            this.label_MotorRPM = new System.Windows.Forms.Label();
            this.textBox_MotorCurrent = new System.Windows.Forms.TextBox();
            this.label_MotorCurrent = new System.Windows.Forms.Label();
            this.textBox_MotorCommandPos = new System.Windows.Forms.TextBox();
            this.label_MotorCommandPos = new System.Windows.Forms.Label();
            this.textBox_MotorCurrentPos = new System.Windows.Forms.TextBox();
            this.label_MotorCurrentPos = new System.Windows.Forms.Label();
            this.textBox_InpStatus = new System.Windows.Forms.TextBox();
            this.label_InpStatus = new System.Windows.Forms.Label();
            this.textBox_ServoStatus = new System.Windows.Forms.TextBox();
            this.label_ServoStatus = new System.Windows.Forms.Label();
            this.button_Connect = new System.Windows.Forms.Button();
            this.button_Disconnct = new System.Windows.Forms.Button();
            this.panel_Test = new System.Windows.Forms.Panel();
            this.label_Watchdog = new System.Windows.Forms.Label();
            this.textBox_ExecutionTime = new System.Windows.Forms.TextBox();
            this.button_AlarmReset = new System.Windows.Forms.Button();
            this.button_DeceleratesToStop = new System.Windows.Forms.Button();
            this.button_EmergencyStop = new System.Windows.Forms.Button();
            this.button_OriginReturn = new System.Windows.Forms.Button();
            this.button_ServoSwitch = new System.Windows.Forms.Button();
            this.label_ConsoleMessage = new System.Windows.Forms.Label();
            this.label_RequestMessage = new System.Windows.Forms.Label();
            this.label_ResponseMessage = new System.Windows.Forms.Label();
            this.textBox_ErrorStatus = new System.Windows.Forms.TextBox();
            this.label_ErrorStatus = new System.Windows.Forms.Label();
            this.label_ErrorMessage = new System.Windows.Forms.Label();
            this.label_TrqLmtStatus = new System.Windows.Forms.Label();
            this.textBox_TrqLmtStatus = new System.Windows.Forms.TextBox();
            this.groupBox_SerialPort = new System.Windows.Forms.GroupBox();
            this.button_UpdateSingleCylinderParams = new System.Windows.Forms.Button();
            this.label_StopBits = new System.Windows.Forms.Label();
            this.comboBox_StopBits = new System.Windows.Forms.ComboBox();
            this.label_DataBits = new System.Windows.Forms.Label();
            this.textBox_DataBits = new System.Windows.Forms.TextBox();
            this.label_Parity = new System.Windows.Forms.Label();
            this.comboBox_Parity = new System.Windows.Forms.ComboBox();
            this.label_BaudRate = new System.Windows.Forms.Label();
            this.comboBox_BaudRate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_COM = new System.Windows.Forms.ComboBox();
            this.groupBox_Cylinder = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_MaxStroke = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_MinStroke = new System.Windows.Forms.TextBox();
            this.label_Station = new System.Windows.Forms.Label();
            this.textBox_Station = new System.Windows.Forms.TextBox();
            this.label_TestSpeed = new System.Windows.Forms.Label();
            this.label_TestPos = new System.Windows.Forms.Label();
            this.checkBox_RepeatTest = new System.Windows.Forms.CheckBox();
            this.button_IncMoveM = new System.Windows.Forms.Button();
            this.button_IncMoveP = new System.Windows.Forms.Button();
            this.button_AbsMove = new System.Windows.Forms.Button();
            this.tabControl_Action = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.checkBox_PortIn14 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn13 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn12 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn11 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox_PortIn10 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn09 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn08 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn07 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn06 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn05 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn04 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn03 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn02 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortIn01 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut10 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut09 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut08 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut07 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut06 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut05 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut04 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut03 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut02 = new System.Windows.Forms.CheckBox();
            this.checkBox_PortOut01 = new System.Windows.Forms.CheckBox();
            this.label_PortOut = new System.Windows.Forms.Label();
            this.tabPage_Monitor = new System.Windows.Forms.TabPage();
            this.groupBox_IncMove = new System.Windows.Forms.GroupBox();
            this.groupBox_AbsMove = new System.Windows.Forms.GroupBox();
            this.trackBar_AbsMove = new System.Windows.Forms.TrackBar();
            this.numericUpDown_AbsMove = new System.Windows.Forms.NumericUpDown();
            this.testBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel_Test.SuspendLayout();
            this.groupBox_SerialPort.SuspendLayout();
            this.groupBox_Cylinder.SuspendLayout();
            this.tabControl_Action.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage_Monitor.SuspendLayout();
            this.groupBox_AbsMove.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_AbsMove)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_AbsMove)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label_MotorStatus
            // 
            this.label_MotorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorStatus.Location = new System.Drawing.Point(353, 54);
            this.label_MotorStatus.Name = "label_MotorStatus";
            this.label_MotorStatus.Size = new System.Drawing.Size(126, 17);
            this.label_MotorStatus.TabIndex = 0;
            this.label_MotorStatus.Text = "馬達狀態";
            this.label_MotorStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_MotorStatus
            // 
            this.textBox_MotorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorStatus.Location = new System.Drawing.Point(480, 51);
            this.textBox_MotorStatus.Name = "textBox_MotorStatus";
            this.textBox_MotorStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorStatus.TabIndex = 1;
            this.textBox_MotorStatus.TabStop = false;
            // 
            // textBox_MotorAlarm
            // 
            this.textBox_MotorAlarm.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorAlarm.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorAlarm.Location = new System.Drawing.Point(480, 144);
            this.textBox_MotorAlarm.Name = "textBox_MotorAlarm";
            this.textBox_MotorAlarm.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorAlarm.TabIndex = 3;
            this.textBox_MotorAlarm.TabStop = false;
            // 
            // label_MotorAlarm
            // 
            this.label_MotorAlarm.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorAlarm.Location = new System.Drawing.Point(353, 147);
            this.label_MotorAlarm.Name = "label_MotorAlarm";
            this.label_MotorAlarm.Size = new System.Drawing.Size(126, 17);
            this.label_MotorAlarm.TabIndex = 2;
            this.label_MotorAlarm.Text = "報警狀態";
            this.label_MotorAlarm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_MotorRPM
            // 
            this.textBox_MotorRPM.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorRPM.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorRPM.Location = new System.Drawing.Point(480, 206);
            this.textBox_MotorRPM.Name = "textBox_MotorRPM";
            this.textBox_MotorRPM.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorRPM.TabIndex = 5;
            this.textBox_MotorRPM.TabStop = false;
            // 
            // label_MotorRPM
            // 
            this.label_MotorRPM.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorRPM.Location = new System.Drawing.Point(353, 209);
            this.label_MotorRPM.Name = "label_MotorRPM";
            this.label_MotorRPM.Size = new System.Drawing.Size(126, 17);
            this.label_MotorRPM.TabIndex = 4;
            this.label_MotorRPM.Text = "馬達的迴轉速(RPM)";
            this.label_MotorRPM.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_MotorCurrent
            // 
            this.textBox_MotorCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCurrent.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorCurrent.Location = new System.Drawing.Point(480, 237);
            this.textBox_MotorCurrent.Name = "textBox_MotorCurrent";
            this.textBox_MotorCurrent.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorCurrent.TabIndex = 9;
            this.textBox_MotorCurrent.TabStop = false;
            // 
            // label_MotorCurrent
            // 
            this.label_MotorCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCurrent.Location = new System.Drawing.Point(353, 240);
            this.label_MotorCurrent.Name = "label_MotorCurrent";
            this.label_MotorCurrent.Size = new System.Drawing.Size(126, 17);
            this.label_MotorCurrent.TabIndex = 8;
            this.label_MotorCurrent.Text = "馬達的電流值(%)";
            this.label_MotorCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_MotorCommandPos
            // 
            this.textBox_MotorCommandPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCommandPos.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorCommandPos.Location = new System.Drawing.Point(480, 268);
            this.textBox_MotorCommandPos.Name = "textBox_MotorCommandPos";
            this.textBox_MotorCommandPos.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorCommandPos.TabIndex = 11;
            this.textBox_MotorCommandPos.TabStop = false;
            // 
            // label_MotorCommandPos
            // 
            this.label_MotorCommandPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCommandPos.Location = new System.Drawing.Point(353, 271);
            this.label_MotorCommandPos.Name = "label_MotorCommandPos";
            this.label_MotorCommandPos.Size = new System.Drawing.Size(126, 17);
            this.label_MotorCommandPos.TabIndex = 10;
            this.label_MotorCommandPos.Text = "指令現在位置(mm)";
            this.label_MotorCommandPos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_MotorCurrentPos
            // 
            this.textBox_MotorCurrentPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCurrentPos.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorCurrentPos.Location = new System.Drawing.Point(480, 299);
            this.textBox_MotorCurrentPos.Name = "textBox_MotorCurrentPos";
            this.textBox_MotorCurrentPos.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorCurrentPos.TabIndex = 13;
            this.textBox_MotorCurrentPos.TabStop = false;
            // 
            // label_MotorCurrentPos
            // 
            this.label_MotorCurrentPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCurrentPos.Location = new System.Drawing.Point(353, 302);
            this.label_MotorCurrentPos.Name = "label_MotorCurrentPos";
            this.label_MotorCurrentPos.Size = new System.Drawing.Size(126, 17);
            this.label_MotorCurrentPos.TabIndex = 12;
            this.label_MotorCurrentPos.Text = "目前位置(mm)";
            this.label_MotorCurrentPos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_InpStatus
            // 
            this.textBox_InpStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_InpStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_InpStatus.Location = new System.Drawing.Point(480, 82);
            this.textBox_InpStatus.Name = "textBox_InpStatus";
            this.textBox_InpStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_InpStatus.TabIndex = 15;
            this.textBox_InpStatus.TabStop = false;
            // 
            // label_InpStatus
            // 
            this.label_InpStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_InpStatus.Location = new System.Drawing.Point(353, 85);
            this.label_InpStatus.Name = "label_InpStatus";
            this.label_InpStatus.Size = new System.Drawing.Size(126, 17);
            this.label_InpStatus.TabIndex = 14;
            this.label_InpStatus.Text = "到位訊號";
            this.label_InpStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_ServoStatus
            // 
            this.textBox_ServoStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_ServoStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_ServoStatus.Location = new System.Drawing.Point(480, 20);
            this.textBox_ServoStatus.Name = "textBox_ServoStatus";
            this.textBox_ServoStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_ServoStatus.TabIndex = 17;
            this.textBox_ServoStatus.TabStop = false;
            // 
            // label_ServoStatus
            // 
            this.label_ServoStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ServoStatus.Location = new System.Drawing.Point(353, 23);
            this.label_ServoStatus.Name = "label_ServoStatus";
            this.label_ServoStatus.Size = new System.Drawing.Size(126, 17);
            this.label_ServoStatus.TabIndex = 16;
            this.label_ServoStatus.Text = "伺服狀態";
            this.label_ServoStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button_Connect
            // 
            this.button_Connect.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Connect.Location = new System.Drawing.Point(199, 20);
            this.button_Connect.Name = "button_Connect";
            this.button_Connect.Size = new System.Drawing.Size(140, 31);
            this.button_Connect.TabIndex = 19;
            this.button_Connect.Text = "連線";
            this.button_Connect.UseVisualStyleBackColor = true;
            this.button_Connect.Click += new System.EventHandler(this.button_Connect_Click);
            // 
            // button_Disconnct
            // 
            this.button_Disconnct.Enabled = false;
            this.button_Disconnct.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Disconnct.Location = new System.Drawing.Point(199, 57);
            this.button_Disconnct.Name = "button_Disconnct";
            this.button_Disconnct.Size = new System.Drawing.Size(140, 31);
            this.button_Disconnct.TabIndex = 20;
            this.button_Disconnct.Text = "連線終止";
            this.button_Disconnct.UseVisualStyleBackColor = true;
            this.button_Disconnct.Click += new System.EventHandler(this.button_Disconnct_Click);
            // 
            // panel_Test
            // 
            this.panel_Test.Controls.Add(this.textBox_ExecutionTime);
            this.panel_Test.Controls.Add(this.button_AlarmReset);
            this.panel_Test.Controls.Add(this.button_DeceleratesToStop);
            this.panel_Test.Controls.Add(this.button_EmergencyStop);
            this.panel_Test.Controls.Add(this.button_OriginReturn);
            this.panel_Test.Controls.Add(this.button_ServoSwitch);
            this.panel_Test.Controls.Add(this.label_Watchdog);
            this.panel_Test.Enabled = false;
            this.panel_Test.Location = new System.Drawing.Point(199, 98);
            this.panel_Test.Name = "panel_Test";
            this.panel_Test.Size = new System.Drawing.Size(143, 292);
            this.panel_Test.TabIndex = 30;
            // 
            // label_Watchdog
            // 
            this.label_Watchdog.AutoSize = true;
            this.label_Watchdog.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Watchdog.Location = new System.Drawing.Point(4, 248);
            this.label_Watchdog.Name = "label_Watchdog";
            this.label_Watchdog.Size = new System.Drawing.Size(60, 17);
            this.label_Watchdog.TabIndex = 87;
            this.label_Watchdog.Text = "運行時間";
            // 
            // textBox_ExecutionTime
            // 
            this.textBox_ExecutionTime.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_ExecutionTime.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_ExecutionTime.Location = new System.Drawing.Point(64, 245);
            this.textBox_ExecutionTime.Name = "textBox_ExecutionTime";
            this.textBox_ExecutionTime.Size = new System.Drawing.Size(76, 25);
            this.textBox_ExecutionTime.TabIndex = 86;
            this.textBox_ExecutionTime.TabStop = false;
            this.textBox_ExecutionTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_AlarmReset
            // 
            this.button_AlarmReset.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_AlarmReset.ForeColor = System.Drawing.Color.Green;
            this.button_AlarmReset.Location = new System.Drawing.Point(0, 104);
            this.button_AlarmReset.Name = "button_AlarmReset";
            this.button_AlarmReset.Size = new System.Drawing.Size(140, 31);
            this.button_AlarmReset.TabIndex = 85;
            this.button_AlarmReset.Text = "警報重置";
            this.button_AlarmReset.UseVisualStyleBackColor = false;
            this.button_AlarmReset.Click += new System.EventHandler(this.button_AlarmReset_Click);
            // 
            // button_DeceleratesToStop
            // 
            this.button_DeceleratesToStop.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_DeceleratesToStop.ForeColor = System.Drawing.Color.Red;
            this.button_DeceleratesToStop.Location = new System.Drawing.Point(0, 151);
            this.button_DeceleratesToStop.Name = "button_DeceleratesToStop";
            this.button_DeceleratesToStop.Size = new System.Drawing.Size(140, 31);
            this.button_DeceleratesToStop.TabIndex = 84;
            this.button_DeceleratesToStop.Text = "減速停止";
            this.button_DeceleratesToStop.UseVisualStyleBackColor = false;
            this.button_DeceleratesToStop.Click += new System.EventHandler(this.button_DeceleratesToStop_Click);
            // 
            // button_EmergencyStop
            // 
            this.button_EmergencyStop.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_EmergencyStop.ForeColor = System.Drawing.Color.Red;
            this.button_EmergencyStop.Location = new System.Drawing.Point(0, 188);
            this.button_EmergencyStop.Name = "button_EmergencyStop";
            this.button_EmergencyStop.Size = new System.Drawing.Size(140, 31);
            this.button_EmergencyStop.TabIndex = 83;
            this.button_EmergencyStop.Text = "緊急停止";
            this.button_EmergencyStop.UseVisualStyleBackColor = false;
            this.button_EmergencyStop.Click += new System.EventHandler(this.button_EmergencyStop_Click);
            // 
            // button_OriginReturn
            // 
            this.button_OriginReturn.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_OriginReturn.ForeColor = System.Drawing.Color.Blue;
            this.button_OriginReturn.Location = new System.Drawing.Point(0, 3);
            this.button_OriginReturn.Name = "button_OriginReturn";
            this.button_OriginReturn.Size = new System.Drawing.Size(140, 31);
            this.button_OriginReturn.TabIndex = 82;
            this.button_OriginReturn.Text = "復歸";
            this.button_OriginReturn.UseVisualStyleBackColor = true;
            this.button_OriginReturn.Click += new System.EventHandler(this.button_OriginReturn_Click);
            // 
            // button_ServoSwitch
            // 
            this.button_ServoSwitch.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_ServoSwitch.ForeColor = System.Drawing.Color.Teal;
            this.button_ServoSwitch.Location = new System.Drawing.Point(0, 40);
            this.button_ServoSwitch.Name = "button_ServoSwitch";
            this.button_ServoSwitch.Size = new System.Drawing.Size(140, 31);
            this.button_ServoSwitch.TabIndex = 78;
            this.button_ServoSwitch.Text = "Servo";
            this.button_ServoSwitch.UseVisualStyleBackColor = true;
            this.button_ServoSwitch.Click += new System.EventHandler(this.button_ServoSwitch_Click);
            // 
            // label_ConsoleMessage
            // 
            this.label_ConsoleMessage.AutoSize = true;
            this.label_ConsoleMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ConsoleMessage.Location = new System.Drawing.Point(12, 436);
            this.label_ConsoleMessage.Name = "label_ConsoleMessage";
            this.label_ConsoleMessage.Size = new System.Drawing.Size(62, 17);
            this.label_ConsoleMessage.TabIndex = 31;
            this.label_ConsoleMessage.Text = "Message";
            // 
            // label_RequestMessage
            // 
            this.label_RequestMessage.AutoSize = true;
            this.label_RequestMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_RequestMessage.Location = new System.Drawing.Point(12, 402);
            this.label_RequestMessage.Name = "label_RequestMessage";
            this.label_RequestMessage.Size = new System.Drawing.Size(62, 17);
            this.label_RequestMessage.TabIndex = 32;
            this.label_RequestMessage.Text = "Message";
            // 
            // label_ResponseMessage
            // 
            this.label_ResponseMessage.AutoSize = true;
            this.label_ResponseMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ResponseMessage.Location = new System.Drawing.Point(12, 419);
            this.label_ResponseMessage.Name = "label_ResponseMessage";
            this.label_ResponseMessage.Size = new System.Drawing.Size(62, 17);
            this.label_ResponseMessage.TabIndex = 33;
            this.label_ResponseMessage.Text = "Message";
            // 
            // textBox_ErrorStatus
            // 
            this.textBox_ErrorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_ErrorStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_ErrorStatus.Location = new System.Drawing.Point(480, 175);
            this.textBox_ErrorStatus.Name = "textBox_ErrorStatus";
            this.textBox_ErrorStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_ErrorStatus.TabIndex = 35;
            this.textBox_ErrorStatus.TabStop = false;
            // 
            // label_ErrorStatus
            // 
            this.label_ErrorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ErrorStatus.Location = new System.Drawing.Point(353, 178);
            this.label_ErrorStatus.Name = "label_ErrorStatus";
            this.label_ErrorStatus.Size = new System.Drawing.Size(126, 17);
            this.label_ErrorStatus.TabIndex = 34;
            this.label_ErrorStatus.Text = "故障狀態";
            this.label_ErrorStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_ErrorMessage
            // 
            this.label_ErrorMessage.AutoSize = true;
            this.label_ErrorMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ErrorMessage.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorMessage.Location = new System.Drawing.Point(12, 453);
            this.label_ErrorMessage.Name = "label_ErrorMessage";
            this.label_ErrorMessage.Size = new System.Drawing.Size(92, 17);
            this.label_ErrorMessage.TabIndex = 36;
            this.label_ErrorMessage.Text = "ErrorMessage";
            // 
            // label_TrqLmtStatus
            // 
            this.label_TrqLmtStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TrqLmtStatus.Location = new System.Drawing.Point(353, 116);
            this.label_TrqLmtStatus.Name = "label_TrqLmtStatus";
            this.label_TrqLmtStatus.Size = new System.Drawing.Size(126, 17);
            this.label_TrqLmtStatus.TabIndex = 48;
            this.label_TrqLmtStatus.Text = "扭力極限狀態";
            this.label_TrqLmtStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_TrqLmtStatus
            // 
            this.textBox_TrqLmtStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_TrqLmtStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_TrqLmtStatus.Location = new System.Drawing.Point(480, 113);
            this.textBox_TrqLmtStatus.Name = "textBox_TrqLmtStatus";
            this.textBox_TrqLmtStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_TrqLmtStatus.TabIndex = 49;
            this.textBox_TrqLmtStatus.TabStop = false;
            // 
            // groupBox_SerialPort
            // 
            this.groupBox_SerialPort.Controls.Add(this.button_UpdateSingleCylinderParams);
            this.groupBox_SerialPort.Controls.Add(this.label_StopBits);
            this.groupBox_SerialPort.Controls.Add(this.comboBox_StopBits);
            this.groupBox_SerialPort.Controls.Add(this.label_DataBits);
            this.groupBox_SerialPort.Controls.Add(this.textBox_DataBits);
            this.groupBox_SerialPort.Controls.Add(this.label_Parity);
            this.groupBox_SerialPort.Controls.Add(this.comboBox_Parity);
            this.groupBox_SerialPort.Controls.Add(this.label_BaudRate);
            this.groupBox_SerialPort.Controls.Add(this.comboBox_BaudRate);
            this.groupBox_SerialPort.Controls.Add(this.label2);
            this.groupBox_SerialPort.Controls.Add(this.comboBox_COM);
            this.groupBox_SerialPort.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox_SerialPort.Location = new System.Drawing.Point(12, 13);
            this.groupBox_SerialPort.Name = "groupBox_SerialPort";
            this.groupBox_SerialPort.Size = new System.Drawing.Size(173, 231);
            this.groupBox_SerialPort.TabIndex = 75;
            this.groupBox_SerialPort.TabStop = false;
            this.groupBox_SerialPort.Text = "串列埠設定";
            // 
            // button_UpdateSingleCylinderParams
            // 
            this.button_UpdateSingleCylinderParams.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_UpdateSingleCylinderParams.Location = new System.Drawing.Point(13, 185);
            this.button_UpdateSingleCylinderParams.Name = "button_UpdateSingleCylinderParams";
            this.button_UpdateSingleCylinderParams.Size = new System.Drawing.Size(145, 31);
            this.button_UpdateSingleCylinderParams.TabIndex = 157;
            this.button_UpdateSingleCylinderParams.Text = "更新列表";
            this.button_UpdateSingleCylinderParams.UseVisualStyleBackColor = true;
            this.button_UpdateSingleCylinderParams.Click += new System.EventHandler(this.button_UpdateSerialPortParams_Click);
            // 
            // label_StopBits
            // 
            this.label_StopBits.AutoSize = true;
            this.label_StopBits.Location = new System.Drawing.Point(10, 150);
            this.label_StopBits.Name = "label_StopBits";
            this.label_StopBits.Size = new System.Drawing.Size(63, 17);
            this.label_StopBits.TabIndex = 156;
            this.label_StopBits.Text = "停止位元:";
            this.label_StopBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox_StopBits
            // 
            this.comboBox_StopBits.FormattingEnabled = true;
            this.comboBox_StopBits.Location = new System.Drawing.Point(76, 147);
            this.comboBox_StopBits.Name = "comboBox_StopBits";
            this.comboBox_StopBits.Size = new System.Drawing.Size(82, 25);
            this.comboBox_StopBits.TabIndex = 155;
            this.comboBox_StopBits.Text = "One";
            // 
            // label_DataBits
            // 
            this.label_DataBits.AutoSize = true;
            this.label_DataBits.Location = new System.Drawing.Point(10, 119);
            this.label_DataBits.Name = "label_DataBits";
            this.label_DataBits.Size = new System.Drawing.Size(63, 17);
            this.label_DataBits.TabIndex = 154;
            this.label_DataBits.Text = "資料位元:";
            this.label_DataBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_DataBits
            // 
            this.textBox_DataBits.Location = new System.Drawing.Point(76, 116);
            this.textBox_DataBits.Name = "textBox_DataBits";
            this.textBox_DataBits.Size = new System.Drawing.Size(82, 25);
            this.textBox_DataBits.TabIndex = 153;
            this.textBox_DataBits.Text = "8";
            this.textBox_DataBits.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label_Parity
            // 
            this.label_Parity.AutoSize = true;
            this.label_Parity.Location = new System.Drawing.Point(10, 88);
            this.label_Parity.Name = "label_Parity";
            this.label_Parity.Size = new System.Drawing.Size(63, 17);
            this.label_Parity.TabIndex = 152;
            this.label_Parity.Text = "同位位元:";
            this.label_Parity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox_Parity
            // 
            this.comboBox_Parity.FormattingEnabled = true;
            this.comboBox_Parity.Location = new System.Drawing.Point(76, 85);
            this.comboBox_Parity.Name = "comboBox_Parity";
            this.comboBox_Parity.Size = new System.Drawing.Size(82, 25);
            this.comboBox_Parity.TabIndex = 151;
            this.comboBox_Parity.Text = "None";
            // 
            // label_BaudRate
            // 
            this.label_BaudRate.AutoSize = true;
            this.label_BaudRate.Location = new System.Drawing.Point(35, 57);
            this.label_BaudRate.Name = "label_BaudRate";
            this.label_BaudRate.Size = new System.Drawing.Size(37, 17);
            this.label_BaudRate.TabIndex = 150;
            this.label_BaudRate.Text = "鮑率:";
            this.label_BaudRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox_BaudRate
            // 
            this.comboBox_BaudRate.FormattingEnabled = true;
            this.comboBox_BaudRate.Location = new System.Drawing.Point(76, 54);
            this.comboBox_BaudRate.Name = "comboBox_BaudRate";
            this.comboBox_BaudRate.Size = new System.Drawing.Size(82, 25);
            this.comboBox_BaudRate.TabIndex = 149;
            this.comboBox_BaudRate.Text = "19200";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 17);
            this.label2.TabIndex = 148;
            this.label2.Text = "Port:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBox_COM
            // 
            this.comboBox_COM.FormattingEnabled = true;
            this.comboBox_COM.Location = new System.Drawing.Point(76, 23);
            this.comboBox_COM.Name = "comboBox_COM";
            this.comboBox_COM.Size = new System.Drawing.Size(82, 25);
            this.comboBox_COM.TabIndex = 145;
            this.comboBox_COM.Text = "COMxx";
            // 
            // groupBox_Cylinder
            // 
            this.groupBox_Cylinder.Controls.Add(this.label4);
            this.groupBox_Cylinder.Controls.Add(this.textBox_MaxStroke);
            this.groupBox_Cylinder.Controls.Add(this.label3);
            this.groupBox_Cylinder.Controls.Add(this.textBox_MinStroke);
            this.groupBox_Cylinder.Controls.Add(this.label_Station);
            this.groupBox_Cylinder.Controls.Add(this.textBox_Station);
            this.groupBox_Cylinder.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox_Cylinder.Location = new System.Drawing.Point(12, 250);
            this.groupBox_Cylinder.Name = "groupBox_Cylinder";
            this.groupBox_Cylinder.Size = new System.Drawing.Size(173, 140);
            this.groupBox_Cylinder.TabIndex = 76;
            this.groupBox_Cylinder.TabStop = false;
            this.groupBox_Cylinder.Text = "電動缸設定";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 17);
            this.label4.TabIndex = 153;
            this.label4.Text = "最大行程:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_MaxStroke
            // 
            this.textBox_MaxStroke.Location = new System.Drawing.Point(76, 98);
            this.textBox_MaxStroke.Name = "textBox_MaxStroke";
            this.textBox_MaxStroke.Size = new System.Drawing.Size(82, 25);
            this.textBox_MaxStroke.TabIndex = 152;
            this.textBox_MaxStroke.Text = "100.00";
            this.textBox_MaxStroke.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 17);
            this.label3.TabIndex = 151;
            this.label3.Text = "最小行程:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_MinStroke
            // 
            this.textBox_MinStroke.Location = new System.Drawing.Point(76, 67);
            this.textBox_MinStroke.Name = "textBox_MinStroke";
            this.textBox_MinStroke.Size = new System.Drawing.Size(82, 25);
            this.textBox_MinStroke.TabIndex = 150;
            this.textBox_MinStroke.Text = "0.00";
            this.textBox_MinStroke.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label_Station
            // 
            this.label_Station.AutoSize = true;
            this.label_Station.Location = new System.Drawing.Point(36, 39);
            this.label_Station.Name = "label_Station";
            this.label_Station.Size = new System.Drawing.Size(37, 17);
            this.label_Station.TabIndex = 149;
            this.label_Station.Text = "站號:";
            this.label_Station.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_Station
            // 
            this.textBox_Station.Location = new System.Drawing.Point(76, 36);
            this.textBox_Station.Name = "textBox_Station";
            this.textBox_Station.Size = new System.Drawing.Size(82, 25);
            this.textBox_Station.TabIndex = 148;
            this.textBox_Station.Text = "1";
            this.textBox_Station.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label_TestSpeed
            // 
            this.label_TestSpeed.AutoSize = true;
            this.label_TestSpeed.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TestSpeed.Location = new System.Drawing.Point(385, 428);
            this.label_TestSpeed.Name = "label_TestSpeed";
            this.label_TestSpeed.Size = new System.Drawing.Size(47, 17);
            this.label_TestSpeed.TabIndex = 92;
            this.label_TestSpeed.Text = "SPEED";
            // 
            // label_TestPos
            // 
            this.label_TestPos.AutoSize = true;
            this.label_TestPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TestPos.Location = new System.Drawing.Point(385, 408);
            this.label_TestPos.Name = "label_TestPos";
            this.label_TestPos.Size = new System.Drawing.Size(70, 17);
            this.label_TestPos.TabIndex = 91;
            this.label_TestPos.Text = "POSITION";
            // 
            // checkBox_RepeatTest
            // 
            this.checkBox_RepeatTest.AutoSize = true;
            this.checkBox_RepeatTest.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_RepeatTest.Location = new System.Drawing.Point(365, 384);
            this.checkBox_RepeatTest.Name = "checkBox_RepeatTest";
            this.checkBox_RepeatTest.Size = new System.Drawing.Size(105, 21);
            this.checkBox_RepeatTest.TabIndex = 90;
            this.checkBox_RepeatTest.Text = "重覆運動測試";
            this.checkBox_RepeatTest.UseVisualStyleBackColor = true;
            this.checkBox_RepeatTest.Click += new System.EventHandler(this.checkBox_RepeatTest_CheckedChanged);
            // 
            // button_IncMoveM
            // 
            this.button_IncMoveM.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_IncMoveM.Location = new System.Drawing.Point(480, 428);
            this.button_IncMoveM.Name = "button_IncMoveM";
            this.button_IncMoveM.Size = new System.Drawing.Size(131, 31);
            this.button_IncMoveM.TabIndex = 89;
            this.button_IncMoveM.Text = "INC-10 MOVE";
            this.button_IncMoveM.UseVisualStyleBackColor = false;
            this.button_IncMoveM.Click += new System.EventHandler(this.button_IncMoveM_Click);
            // 
            // button_IncMoveP
            // 
            this.button_IncMoveP.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_IncMoveP.Location = new System.Drawing.Point(480, 389);
            this.button_IncMoveP.Name = "button_IncMoveP";
            this.button_IncMoveP.Size = new System.Drawing.Size(131, 31);
            this.button_IncMoveP.TabIndex = 88;
            this.button_IncMoveP.Text = "INC+10 MOVE";
            this.button_IncMoveP.UseVisualStyleBackColor = false;
            this.button_IncMoveP.Click += new System.EventHandler(this.button_IncMoveP_Click);
            // 
            // button_AbsMove
            // 
            this.button_AbsMove.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_AbsMove.Location = new System.Drawing.Point(480, 349);
            this.button_AbsMove.Name = "button_AbsMove";
            this.button_AbsMove.Size = new System.Drawing.Size(131, 31);
            this.button_AbsMove.TabIndex = 87;
            this.button_AbsMove.Text = "ABS MOVE";
            this.button_AbsMove.UseVisualStyleBackColor = false;
            this.button_AbsMove.Click += new System.EventHandler(this.button_AbsMove_Click);
            // 
            // tabControl_Action
            // 
            this.tabControl_Action.Controls.Add(this.tabPage1);
            this.tabControl_Action.Controls.Add(this.tabPage_Monitor);
            this.tabControl_Action.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl_Action.Location = new System.Drawing.Point(624, 18);
            this.tabControl_Action.Name = "tabControl_Action";
            this.tabControl_Action.SelectedIndex = 0;
            this.tabControl_Action.Size = new System.Drawing.Size(438, 445);
            this.tabControl_Action.TabIndex = 93;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.checkBox_PortIn14);
            this.tabPage1.Controls.Add(this.checkBox_PortIn13);
            this.tabPage1.Controls.Add(this.checkBox_PortIn12);
            this.tabPage1.Controls.Add(this.checkBox_PortIn11);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.checkBox_PortIn10);
            this.tabPage1.Controls.Add(this.checkBox_PortIn09);
            this.tabPage1.Controls.Add(this.checkBox_PortIn08);
            this.tabPage1.Controls.Add(this.checkBox_PortIn07);
            this.tabPage1.Controls.Add(this.checkBox_PortIn06);
            this.tabPage1.Controls.Add(this.checkBox_PortIn05);
            this.tabPage1.Controls.Add(this.checkBox_PortIn04);
            this.tabPage1.Controls.Add(this.checkBox_PortIn03);
            this.tabPage1.Controls.Add(this.checkBox_PortIn02);
            this.tabPage1.Controls.Add(this.checkBox_PortIn01);
            this.tabPage1.Controls.Add(this.checkBox_PortOut10);
            this.tabPage1.Controls.Add(this.checkBox_PortOut09);
            this.tabPage1.Controls.Add(this.checkBox_PortOut08);
            this.tabPage1.Controls.Add(this.checkBox_PortOut07);
            this.tabPage1.Controls.Add(this.checkBox_PortOut06);
            this.tabPage1.Controls.Add(this.checkBox_PortOut05);
            this.tabPage1.Controls.Add(this.checkBox_PortOut04);
            this.tabPage1.Controls.Add(this.checkBox_PortOut03);
            this.tabPage1.Controls.Add(this.checkBox_PortOut02);
            this.tabPage1.Controls.Add(this.checkBox_PortOut01);
            this.tabPage1.Controls.Add(this.label_PortOut);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(430, 415);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "監測";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn14
            // 
            this.checkBox_PortIn14.AutoSize = true;
            this.checkBox_PortIn14.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn14.Location = new System.Drawing.Point(28, 290);
            this.checkBox_PortIn14.Name = "checkBox_PortIn14";
            this.checkBox_PortIn14.Size = new System.Drawing.Size(79, 21);
            this.checkBox_PortIn14.TabIndex = 126;
            this.checkBox_PortIn14.Text = "14: IN14";
            this.checkBox_PortIn14.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn13
            // 
            this.checkBox_PortIn13.AutoSize = true;
            this.checkBox_PortIn13.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn13.Location = new System.Drawing.Point(28, 272);
            this.checkBox_PortIn13.Name = "checkBox_PortIn13";
            this.checkBox_PortIn13.Size = new System.Drawing.Size(79, 21);
            this.checkBox_PortIn13.TabIndex = 125;
            this.checkBox_PortIn13.Text = "13: IN13";
            this.checkBox_PortIn13.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn12
            // 
            this.checkBox_PortIn12.AutoSize = true;
            this.checkBox_PortIn12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn12.Location = new System.Drawing.Point(28, 254);
            this.checkBox_PortIn12.Name = "checkBox_PortIn12";
            this.checkBox_PortIn12.Size = new System.Drawing.Size(79, 21);
            this.checkBox_PortIn12.TabIndex = 124;
            this.checkBox_PortIn12.Text = "12: IN12";
            this.checkBox_PortIn12.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn11
            // 
            this.checkBox_PortIn11.AutoSize = true;
            this.checkBox_PortIn11.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn11.Location = new System.Drawing.Point(28, 236);
            this.checkBox_PortIn11.Name = "checkBox_PortIn11";
            this.checkBox_PortIn11.Size = new System.Drawing.Size(79, 21);
            this.checkBox_PortIn11.TabIndex = 123;
            this.checkBox_PortIn11.Text = "11: IN11";
            this.checkBox_PortIn11.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(24, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 21);
            this.label1.TabIndex = 122;
            this.label1.Text = "輸入";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkBox_PortIn10
            // 
            this.checkBox_PortIn10.AutoSize = true;
            this.checkBox_PortIn10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn10.Location = new System.Drawing.Point(28, 218);
            this.checkBox_PortIn10.Name = "checkBox_PortIn10";
            this.checkBox_PortIn10.Size = new System.Drawing.Size(107, 21);
            this.checkBox_PortIn10.TabIndex = 121;
            this.checkBox_PortIn10.Text = "10: MANUAL";
            this.checkBox_PortIn10.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn09
            // 
            this.checkBox_PortIn09.AutoSize = true;
            this.checkBox_PortIn09.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn09.Location = new System.Drawing.Point(28, 200);
            this.checkBox_PortIn09.Name = "checkBox_PortIn09";
            this.checkBox_PortIn09.Size = new System.Drawing.Size(76, 21);
            this.checkBox_PortIn09.TabIndex = 120;
            this.checkBox_PortIn09.Text = "9: LOCK";
            this.checkBox_PortIn09.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn08
            // 
            this.checkBox_PortIn08.AutoSize = true;
            this.checkBox_PortIn08.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn08.Location = new System.Drawing.Point(28, 182);
            this.checkBox_PortIn08.Name = "checkBox_PortIn08";
            this.checkBox_PortIn08.Size = new System.Drawing.Size(96, 21);
            this.checkBox_PortIn08.TabIndex = 119;
            this.checkBox_PortIn08.Text = "8: PRGSEL3";
            this.checkBox_PortIn08.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn07
            // 
            this.checkBox_PortIn07.AutoSize = true;
            this.checkBox_PortIn07.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn07.Location = new System.Drawing.Point(28, 164);
            this.checkBox_PortIn07.Name = "checkBox_PortIn07";
            this.checkBox_PortIn07.Size = new System.Drawing.Size(96, 21);
            this.checkBox_PortIn07.TabIndex = 118;
            this.checkBox_PortIn07.Text = "7: PRGSEL2";
            this.checkBox_PortIn07.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn06
            // 
            this.checkBox_PortIn06.AutoSize = true;
            this.checkBox_PortIn06.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn06.Location = new System.Drawing.Point(28, 146);
            this.checkBox_PortIn06.Name = "checkBox_PortIn06";
            this.checkBox_PortIn06.Size = new System.Drawing.Size(96, 21);
            this.checkBox_PortIn06.TabIndex = 117;
            this.checkBox_PortIn06.Text = "6: PRGSEL1";
            this.checkBox_PortIn06.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn05
            // 
            this.checkBox_PortIn05.AutoSize = true;
            this.checkBox_PortIn05.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn05.Location = new System.Drawing.Point(28, 128);
            this.checkBox_PortIn05.Name = "checkBox_PortIn05";
            this.checkBox_PortIn05.Size = new System.Drawing.Size(96, 21);
            this.checkBox_PortIn05.TabIndex = 116;
            this.checkBox_PortIn05.Text = "5: PRGSEL0";
            this.checkBox_PortIn05.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn04
            // 
            this.checkBox_PortIn04.AutoSize = true;
            this.checkBox_PortIn04.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn04.Location = new System.Drawing.Point(28, 110);
            this.checkBox_PortIn04.Name = "checkBox_PortIn04";
            this.checkBox_PortIn04.Size = new System.Drawing.Size(79, 21);
            this.checkBox_PortIn04.TabIndex = 115;
            this.checkBox_PortIn04.Text = "4: START";
            this.checkBox_PortIn04.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn03
            // 
            this.checkBox_PortIn03.AutoSize = true;
            this.checkBox_PortIn03.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn03.Location = new System.Drawing.Point(28, 92);
            this.checkBox_PortIn03.Name = "checkBox_PortIn03";
            this.checkBox_PortIn03.Size = new System.Drawing.Size(112, 21);
            this.checkBox_PortIn03.TabIndex = 114;
            this.checkBox_PortIn03.Text = "3: ALM_RESET";
            this.checkBox_PortIn03.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn02
            // 
            this.checkBox_PortIn02.AutoSize = true;
            this.checkBox_PortIn02.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn02.Location = new System.Drawing.Point(28, 74);
            this.checkBox_PortIn02.Name = "checkBox_PortIn02";
            this.checkBox_PortIn02.Size = new System.Drawing.Size(137, 21);
            this.checkBox_PortIn02.TabIndex = 113;
            this.checkBox_PortIn02.Text = "2: SERVO ON/OFF";
            this.checkBox_PortIn02.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortIn01
            // 
            this.checkBox_PortIn01.AutoSize = true;
            this.checkBox_PortIn01.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortIn01.Location = new System.Drawing.Point(28, 56);
            this.checkBox_PortIn01.Name = "checkBox_PortIn01";
            this.checkBox_PortIn01.Size = new System.Drawing.Size(70, 21);
            this.checkBox_PortIn01.TabIndex = 112;
            this.checkBox_PortIn01.Text = "1: ORG";
            this.checkBox_PortIn01.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut10
            // 
            this.checkBox_PortOut10.AutoSize = true;
            this.checkBox_PortOut10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut10.Location = new System.Drawing.Point(183, 218);
            this.checkBox_PortOut10.Name = "checkBox_PortOut10";
            this.checkBox_PortOut10.Size = new System.Drawing.Size(93, 21);
            this.checkBox_PortOut10.TabIndex = 111;
            this.checkBox_PortOut10.Text = "10: OUT10";
            this.checkBox_PortOut10.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut09
            // 
            this.checkBox_PortOut09.AutoSize = true;
            this.checkBox_PortOut09.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut09.Location = new System.Drawing.Point(183, 200);
            this.checkBox_PortOut09.Name = "checkBox_PortOut09";
            this.checkBox_PortOut09.Size = new System.Drawing.Size(77, 21);
            this.checkBox_PortOut09.TabIndex = 110;
            this.checkBox_PortOut09.Text = "9: OUT9";
            this.checkBox_PortOut09.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut08
            // 
            this.checkBox_PortOut08.AutoSize = true;
            this.checkBox_PortOut08.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut08.Location = new System.Drawing.Point(183, 182);
            this.checkBox_PortOut08.Name = "checkBox_PortOut08";
            this.checkBox_PortOut08.Size = new System.Drawing.Size(81, 21);
            this.checkBox_PortOut08.TabIndex = 109;
            this.checkBox_PortOut08.Text = "8: MOVE";
            this.checkBox_PortOut08.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut07
            // 
            this.checkBox_PortOut07.AutoSize = true;
            this.checkBox_PortOut07.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut07.Location = new System.Drawing.Point(183, 164);
            this.checkBox_PortOut07.Name = "checkBox_PortOut07";
            this.checkBox_PortOut07.Size = new System.Drawing.Size(87, 21);
            this.checkBox_PortOut07.TabIndex = 108;
            this.checkBox_PortOut07.Text = "7: ALARM";
            this.checkBox_PortOut07.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut06
            // 
            this.checkBox_PortOut06.AutoSize = true;
            this.checkBox_PortOut06.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut06.Location = new System.Drawing.Point(183, 146);
            this.checkBox_PortOut06.Name = "checkBox_PortOut06";
            this.checkBox_PortOut06.Size = new System.Drawing.Size(109, 21);
            this.checkBox_PortOut06.TabIndex = 107;
            this.checkBox_PortOut06.Text = "6: PRGSEL1-S";
            this.checkBox_PortOut06.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut05
            // 
            this.checkBox_PortOut05.AutoSize = true;
            this.checkBox_PortOut05.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut05.Location = new System.Drawing.Point(183, 128);
            this.checkBox_PortOut05.Name = "checkBox_PortOut05";
            this.checkBox_PortOut05.Size = new System.Drawing.Size(109, 21);
            this.checkBox_PortOut05.TabIndex = 106;
            this.checkBox_PortOut05.Text = "5: PRGSEL0-S";
            this.checkBox_PortOut05.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut04
            // 
            this.checkBox_PortOut04.AutoSize = true;
            this.checkBox_PortOut04.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut04.Location = new System.Drawing.Point(183, 110);
            this.checkBox_PortOut04.Name = "checkBox_PortOut04";
            this.checkBox_PortOut04.Size = new System.Drawing.Size(96, 21);
            this.checkBox_PortOut04.TabIndex = 105;
            this.checkBox_PortOut04.Text = "4: SERVO-S";
            this.checkBox_PortOut04.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut03
            // 
            this.checkBox_PortOut03.AutoSize = true;
            this.checkBox_PortOut03.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut03.Location = new System.Drawing.Point(183, 92);
            this.checkBox_PortOut03.Name = "checkBox_PortOut03";
            this.checkBox_PortOut03.Size = new System.Drawing.Size(83, 21);
            this.checkBox_PortOut03.TabIndex = 104;
            this.checkBox_PortOut03.Text = "3: READY";
            this.checkBox_PortOut03.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut02
            // 
            this.checkBox_PortOut02.AutoSize = true;
            this.checkBox_PortOut02.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut02.Location = new System.Drawing.Point(183, 74);
            this.checkBox_PortOut02.Name = "checkBox_PortOut02";
            this.checkBox_PortOut02.Size = new System.Drawing.Size(117, 21);
            this.checkBox_PortOut02.TabIndex = 103;
            this.checkBox_PortOut02.Text = "2: INPOSITION";
            this.checkBox_PortOut02.UseVisualStyleBackColor = true;
            // 
            // checkBox_PortOut01
            // 
            this.checkBox_PortOut01.AutoSize = true;
            this.checkBox_PortOut01.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_PortOut01.Location = new System.Drawing.Point(183, 56);
            this.checkBox_PortOut01.Name = "checkBox_PortOut01";
            this.checkBox_PortOut01.Size = new System.Drawing.Size(83, 21);
            this.checkBox_PortOut01.TabIndex = 102;
            this.checkBox_PortOut01.Text = "1: ORG-S";
            this.checkBox_PortOut01.UseVisualStyleBackColor = true;
            // 
            // label_PortOut
            // 
            this.label_PortOut.AutoSize = true;
            this.label_PortOut.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_PortOut.Location = new System.Drawing.Point(179, 20);
            this.label_PortOut.Name = "label_PortOut";
            this.label_PortOut.Size = new System.Drawing.Size(42, 21);
            this.label_PortOut.TabIndex = 101;
            this.label_PortOut.Text = "輸出";
            this.label_PortOut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage_Monitor
            // 
            this.tabPage_Monitor.Controls.Add(this.groupBox_IncMove);
            this.tabPage_Monitor.Controls.Add(this.groupBox_AbsMove);
            this.tabPage_Monitor.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabPage_Monitor.Location = new System.Drawing.Point(4, 26);
            this.tabPage_Monitor.Name = "tabPage_Monitor";
            this.tabPage_Monitor.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Monitor.Size = new System.Drawing.Size(430, 415);
            this.tabPage_Monitor.TabIndex = 1;
            this.tabPage_Monitor.Text = "運動";
            this.tabPage_Monitor.UseVisualStyleBackColor = true;
            // 
            // groupBox_IncMove
            // 
            this.groupBox_IncMove.Location = new System.Drawing.Point(15, 104);
            this.groupBox_IncMove.Name = "groupBox_IncMove";
            this.groupBox_IncMove.Size = new System.Drawing.Size(399, 88);
            this.groupBox_IncMove.TabIndex = 4;
            this.groupBox_IncMove.TabStop = false;
            this.groupBox_IncMove.Text = "相對位置移動";
            // 
            // groupBox_AbsMove
            // 
            this.groupBox_AbsMove.Controls.Add(this.trackBar_AbsMove);
            this.groupBox_AbsMove.Controls.Add(this.numericUpDown_AbsMove);
            this.groupBox_AbsMove.Location = new System.Drawing.Point(15, 10);
            this.groupBox_AbsMove.Name = "groupBox_AbsMove";
            this.groupBox_AbsMove.Size = new System.Drawing.Size(399, 88);
            this.groupBox_AbsMove.TabIndex = 2;
            this.groupBox_AbsMove.TabStop = false;
            this.groupBox_AbsMove.Text = "絕對位置移動";
            // 
            // trackBar_AbsMove
            // 
            this.trackBar_AbsMove.Location = new System.Drawing.Point(15, 29);
            this.trackBar_AbsMove.Maximum = 100;
            this.trackBar_AbsMove.Name = "trackBar_AbsMove";
            this.trackBar_AbsMove.Size = new System.Drawing.Size(299, 45);
            this.trackBar_AbsMove.TabIndex = 3;
            // 
            // numericUpDown_AbsMove
            // 
            this.numericUpDown_AbsMove.DecimalPlaces = 2;
            this.numericUpDown_AbsMove.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown_AbsMove.Location = new System.Drawing.Point(320, 39);
            this.numericUpDown_AbsMove.Name = "numericUpDown_AbsMove";
            this.numericUpDown_AbsMove.Size = new System.Drawing.Size(73, 25);
            this.numericUpDown_AbsMove.TabIndex = 2;
            this.numericUpDown_AbsMove.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TC100Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 475);
            this.Controls.Add(this.tabControl_Action);
            this.Controls.Add(this.label_TestSpeed);
            this.Controls.Add(this.label_TestPos);
            this.Controls.Add(this.checkBox_RepeatTest);
            this.Controls.Add(this.button_IncMoveM);
            this.Controls.Add(this.button_IncMoveP);
            this.Controls.Add(this.button_AbsMove);
            this.Controls.Add(this.groupBox_Cylinder);
            this.Controls.Add(this.groupBox_SerialPort);
            this.Controls.Add(this.label_TrqLmtStatus);
            this.Controls.Add(this.textBox_TrqLmtStatus);
            this.Controls.Add(this.label_ErrorMessage);
            this.Controls.Add(this.textBox_ErrorStatus);
            this.Controls.Add(this.label_ErrorStatus);
            this.Controls.Add(this.label_ResponseMessage);
            this.Controls.Add(this.label_RequestMessage);
            this.Controls.Add(this.label_ConsoleMessage);
            this.Controls.Add(this.panel_Test);
            this.Controls.Add(this.label_ServoStatus);
            this.Controls.Add(this.button_Disconnct);
            this.Controls.Add(this.button_Connect);
            this.Controls.Add(this.textBox_ServoStatus);
            this.Controls.Add(this.textBox_InpStatus);
            this.Controls.Add(this.label_InpStatus);
            this.Controls.Add(this.textBox_MotorCurrentPos);
            this.Controls.Add(this.label_MotorCurrentPos);
            this.Controls.Add(this.textBox_MotorCommandPos);
            this.Controls.Add(this.label_MotorCommandPos);
            this.Controls.Add(this.textBox_MotorCurrent);
            this.Controls.Add(this.label_MotorCurrent);
            this.Controls.Add(this.textBox_MotorRPM);
            this.Controls.Add(this.label_MotorRPM);
            this.Controls.Add(this.textBox_MotorAlarm);
            this.Controls.Add(this.label_MotorAlarm);
            this.Controls.Add(this.textBox_MotorStatus);
            this.Controls.Add(this.label_MotorStatus);
            this.Name = "TC100Test";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "難";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TC100Test_FormClosing);
            this.Load += new System.EventHandler(this.TC100Test_Load);
            this.panel_Test.ResumeLayout(false);
            this.panel_Test.PerformLayout();
            this.groupBox_SerialPort.ResumeLayout(false);
            this.groupBox_SerialPort.PerformLayout();
            this.groupBox_Cylinder.ResumeLayout(false);
            this.groupBox_Cylinder.PerformLayout();
            this.tabControl_Action.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage_Monitor.ResumeLayout(false);
            this.groupBox_AbsMove.ResumeLayout(false);
            this.groupBox_AbsMove.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_AbsMove)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_AbsMove)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_MotorStatus;
        private System.Windows.Forms.TextBox textBox_MotorStatus;
        private System.Windows.Forms.TextBox textBox_MotorAlarm;
        private System.Windows.Forms.Label label_MotorAlarm;
        private System.Windows.Forms.TextBox textBox_MotorRPM;
        private System.Windows.Forms.Label label_MotorRPM;
        private System.Windows.Forms.TextBox textBox_MotorCurrent;
        private System.Windows.Forms.Label label_MotorCurrent;
        private System.Windows.Forms.TextBox textBox_MotorCommandPos;
        private System.Windows.Forms.Label label_MotorCommandPos;
        private System.Windows.Forms.TextBox textBox_MotorCurrentPos;
        private System.Windows.Forms.Label label_MotorCurrentPos;
        private System.Windows.Forms.TextBox textBox_InpStatus;
        private System.Windows.Forms.Label label_InpStatus;
        private System.Windows.Forms.TextBox textBox_ServoStatus;
        private System.Windows.Forms.Label label_ServoStatus;
        private System.Windows.Forms.Button button_Connect;
        private System.Windows.Forms.Button button_Disconnct;
        private System.Windows.Forms.Panel panel_Test;
        private System.Windows.Forms.Label label_ConsoleMessage;
        private System.Windows.Forms.Label label_RequestMessage;
        private System.Windows.Forms.Label label_ResponseMessage;
        private System.Windows.Forms.TextBox textBox_ErrorStatus;
        private System.Windows.Forms.Label label_ErrorStatus;
        private System.Windows.Forms.Label label_ErrorMessage;
        private System.Windows.Forms.Label label_TrqLmtStatus;
        private System.Windows.Forms.TextBox textBox_TrqLmtStatus;
        private System.Windows.Forms.GroupBox groupBox_SerialPort;
        private System.Windows.Forms.Button button_UpdateSingleCylinderParams;
        private System.Windows.Forms.Label label_StopBits;
        private System.Windows.Forms.ComboBox comboBox_StopBits;
        private System.Windows.Forms.Label label_DataBits;
        private System.Windows.Forms.TextBox textBox_DataBits;
        private System.Windows.Forms.Label label_Parity;
        private System.Windows.Forms.ComboBox comboBox_Parity;
        private System.Windows.Forms.Label label_BaudRate;
        private System.Windows.Forms.ComboBox comboBox_BaudRate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_COM;
        private System.Windows.Forms.GroupBox groupBox_Cylinder;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_MaxStroke;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_MinStroke;
        private System.Windows.Forms.Label label_Station;
        private System.Windows.Forms.TextBox textBox_Station;
        private System.Windows.Forms.Button button_ServoSwitch;
        private System.Windows.Forms.Label label_Watchdog;
        private System.Windows.Forms.TextBox textBox_ExecutionTime;
        private System.Windows.Forms.Button button_AlarmReset;
        private System.Windows.Forms.Button button_DeceleratesToStop;
        private System.Windows.Forms.Button button_EmergencyStop;
        private System.Windows.Forms.Button button_OriginReturn;
        private System.Windows.Forms.Label label_TestSpeed;
        private System.Windows.Forms.Label label_TestPos;
        private System.Windows.Forms.CheckBox checkBox_RepeatTest;
        private System.Windows.Forms.Button button_IncMoveM;
        private System.Windows.Forms.Button button_IncMoveP;
        private System.Windows.Forms.Button button_AbsMove;
        private System.Windows.Forms.TabControl tabControl_Action;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage_Monitor;
        private System.Windows.Forms.CheckBox checkBox_PortIn14;
        private System.Windows.Forms.CheckBox checkBox_PortIn13;
        private System.Windows.Forms.CheckBox checkBox_PortIn12;
        private System.Windows.Forms.CheckBox checkBox_PortIn11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox_PortIn10;
        private System.Windows.Forms.CheckBox checkBox_PortIn09;
        private System.Windows.Forms.CheckBox checkBox_PortIn08;
        private System.Windows.Forms.CheckBox checkBox_PortIn07;
        private System.Windows.Forms.CheckBox checkBox_PortIn06;
        private System.Windows.Forms.CheckBox checkBox_PortIn05;
        private System.Windows.Forms.CheckBox checkBox_PortIn04;
        private System.Windows.Forms.CheckBox checkBox_PortIn03;
        private System.Windows.Forms.CheckBox checkBox_PortIn02;
        private System.Windows.Forms.CheckBox checkBox_PortIn01;
        private System.Windows.Forms.CheckBox checkBox_PortOut10;
        private System.Windows.Forms.CheckBox checkBox_PortOut09;
        private System.Windows.Forms.CheckBox checkBox_PortOut08;
        private System.Windows.Forms.CheckBox checkBox_PortOut07;
        private System.Windows.Forms.CheckBox checkBox_PortOut06;
        private System.Windows.Forms.CheckBox checkBox_PortOut05;
        private System.Windows.Forms.CheckBox checkBox_PortOut04;
        private System.Windows.Forms.CheckBox checkBox_PortOut03;
        private System.Windows.Forms.CheckBox checkBox_PortOut02;
        private System.Windows.Forms.CheckBox checkBox_PortOut01;
        private System.Windows.Forms.Label label_PortOut;
        private System.Windows.Forms.GroupBox groupBox_AbsMove;
        private System.Windows.Forms.TrackBar trackBar_AbsMove;
        protected System.Windows.Forms.NumericUpDown numericUpDown_AbsMove;
        private System.Windows.Forms.GroupBox groupBox_IncMove;
        private System.Windows.Forms.BindingSource testBindingSource;
    }
}

