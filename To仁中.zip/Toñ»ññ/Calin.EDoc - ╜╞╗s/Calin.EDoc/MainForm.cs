﻿using System;
using System.Collections.Generic;
using Calin.CSharp.Collection;
using System.Text;
using System.Windows.Forms;
using Calin.EDoc.Models;
using Calin.EDoc.Utility;
using Krypton.Toolkit;
using System.Data;
using System.Collections;
using System.ComponentModel;
using Krypton.Toolkit.Suite.Extended.AdvancedDataGridView;
using Krypton.Toolkit.Suite.Extended.Data.Visualisation.ScottPlot;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Linq;

namespace Calin.EDoc
{
    public partial class MainForm : KryptonForm
    {
        #region fields

        BindingSource bs = new BindingSource();

        #endregion

        public MainForm()
        {
            InitializeComponent();

            var form = this;
            form.Text = "維護履歷管理";
        }

        /********************
         * From Event
         ********************/
        private void MainForm_Load(object sender, EventArgs e)
        {

#if DEBUG
            MainDB.maintenanceEngineers.Add(new Employee()
            {
                EmployeeNo = "007271",
                Name = "苗天恆",
            });
            MainDB.maintenanceEngineers.Add(new Employee()
            {
                EmployeeNo = "007484",
                Name = "李啟修",
            });
            MainDB.allCompanyEmployees = MainDB.maintenanceEngineers;

            MainDB.issueCategories.AddRange(new List<IssueCategory>()
            {
                new IssueCategory()
                {
                    CategoryId=0,
                    CategoryName="日常維護",
                },
                new IssueCategory()
                {
                    CategoryId=1,
                    CategoryName="機台保養",
                },
                new IssueCategory()
                {
                    CategoryId=2,
                    CategoryName="更換零件",
                },
                new IssueCategory()
                {
                    CategoryId=3,
                    CategoryName="機台改線",
                },
                new IssueCategory()
                {
                    CategoryId=4,
                    CategoryName="故障中待協助",
                },
                new IssueCategory()
                {
                    CategoryId=5,
                    CategoryName="異常排除",
                },
                new IssueCategory()
                {
                    CategoryId=6,
                    CategoryName="設備功能追加",
                },
                new IssueCategory()
                {
                    CategoryId=7,
                    CategoryName="機台移動",
                },
            });

            MainDB.maintenanceUnits = new List<MaintenanceUnit>()
            {
                new MaintenanceUnit()
                {
                     MaintenanceUnitId=0,
                     Name="工具設計",
                },
                new MaintenanceUnit()
                {
                     MaintenanceUnitId=1,
                     Name="維護-維小",
                },
                new MaintenanceUnit()
                {
                     MaintenanceUnitId=2,
                     Name="維護-製一",
                },
            };
#endif

            kryptonAdvancedDataGridView.FilterAndSortEnabled = true;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        private void toolStripMenuItem_AppExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripMenuItem_Csv_Click(object sender, EventArgs e)
        {
            var (isSuccess, newHistory, newHistorty_MaintenanceEmployee, newHistory_IssueCategory) = Csv.LoadCsv();
            if (isSuccess)
            {
                MainDB.history = newHistory;
                MainDB.historty_MaintenanceEmployees = newHistorty_MaintenanceEmployee;
                MainDB.history_IssueCategories = newHistory_IssueCategory;

                bs = new BindingSource();
                DataTable dt = CollectionExtension.ToDataTable(MainDB.history);
                bs.DataSource = dt;
                kryptonAdvancedDataGridView.DataSource = dt;
                SetDataGridView();
            }
        }


        internal void SetDataGridView()
        {
            DataGridViewColumn col;

            kryptonAdvancedDataGridView.FilterAndSortEnabled = true;
            foreach (DataGridViewColumn column in kryptonAdvancedDataGridView.Columns)
            {
                column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //column.SortMode = DataGridViewColumnSortMode.Programmatic;
            }

            col = kryptonAdvancedDataGridView.Columns["Creator"];
            col.HeaderText = "序號";
            col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            kryptonAdvancedDataGridView.SetSortEnabled(col, true);
            kryptonAdvancedDataGridView.SetFilterEnabled(col, true);
            kryptonAdvancedDataGridView.SortDescending(col);
            col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //kryptonAdvancedDataGridView.Columns["WorkOrderNo 
            //kryptonAdvancedDataGridView.Columns["Creator  
            //kryptonAdvancedDataGridView.Columns["Date 
            //kryptonAdvancedDataGridView.Columns["MaintenanceUnit  
            //kryptonAdvancedDataGridView.Columns["MachineNo 
            //kryptonAdvancedDataGridView.Columns["AcceptedTime  
            //kryptonAdvancedDataGridView.Columns["RepairStarted  
            //kryptonAdvancedDataGridView.Columns["CompletedTime  
            //kryptonAdvancedDataGridView.Columns["OutageStarted  
            //kryptonAdvancedDataGridView.Columns["OutageEnded  
            //kryptonAdvancedDataGridView.Columns["Responsible  
            //kryptonAdvancedDataGridView.Columns["Model 
            //kryptonAdvancedDataGridView.Columns["Workstation 
            //kryptonAdvancedDataGridView.Columns["IssueDescription 
            //kryptonAdvancedDataGridView.Columns["Details 
            //kryptonAdvancedDataGridView.Columns["RequestingUnit  
            //kryptonAdvancedDataGridView.Columns["RequestingEmployee          
            //kryptonAdvancedDataGridView.Columns["RequestingUnitConfirmation  
            //kryptonAdvancedDataGridView.Columns["RequestingUnitResponse      

            //kryptonAdvancedDataGridView.Columns["AcceptedTime"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm";
        }
    }
}
