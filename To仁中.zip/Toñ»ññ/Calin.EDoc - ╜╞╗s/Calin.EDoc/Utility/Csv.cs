﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Calin.EDoc.Models;

namespace Calin.EDoc.Utility
{
    /// <summary>
    /// CSV檔案操作。
    /// </summary>
    internal static class Csv
    {
        /// <summary>
        /// 讀取維護履的CSV格式檔。
        /// </summary>
        /// <returns>isSuccess: 是否讀取成功。<br />newHistory: 讀取的新履歷。</returns>
        internal static (bool isSuccess, List<History> newHistory, List<Historty_MaintenanceEmployee> newHM, List<History_IssueCategory> newHI) LoadCsv()
        {
            bool isSuccess = false;
            var history = new List<History>();
            var hm = new List<Historty_MaintenanceEmployee>();
            var hi = new List<History_IssueCategory>();

            using (OpenFileDialog openDialog = new OpenFileDialog())
            {
                try
                {
                    openDialog.Title = "選取維護履歷csv格式檔";
                    openDialog.Filter = "CSV 檔案 (*.csv)|*.csv|所有檔案 (*.*)|*.*";
                    openDialog.DefaultExt = "csv";
                    openDialog.CheckPathExists = true;
                    openDialog.CheckFileExists = true;
                    openDialog.InitialDirectory = Directory.GetCurrentDirectory();

                    if (openDialog.ShowDialog() == DialogResult.OK)
                    {
                        int recCount = 1;
                        using (var sr = new StreamReader(openDialog.FileName, Encoding.UTF8))
                        {
                            isSuccess = false;

                            while (sr.Peek() != -1)
                            {
                                string[] data = sr.ReadLine().Split(',');

                                if (recCount > 1) // 去掉標題
                                {
                                    var workOrderNo = data[1].Trim();

                                    DateTime date;
                                    bool parseOk_Date = DateTime.TryParse(data[3], out date);
                                    DateTime acceptedTime;
                                    bool parseOk_AcceptedTime = DateTime.TryParse(data[7], out acceptedTime);
                                    DateTime repairStarted;
                                    bool parseOk_RepairStarted = DateTime.TryParse(data[8], out repairStarted);
                                    DateTime completedTime;
                                    bool parseOk_CompletedTime = DateTime.TryParse(data[9], out completedTime);
                                    DateTime outageStarted;
                                    bool parseOk_OutageStarted = DateTime.TryParse(data[11], out outageStarted);
                                    DateTime outageEnded;
                                    bool parseOk_OutageEnded = DateTime.TryParse(data[12], out outageEnded);

                                    // 加入並轉換資料
                                    var rec = new History()
                                    {
                                        SerNo = int.Parse(data[0]),
                                        WorkOrderNo = workOrderNo,
                                        Creator = data[2].Trim(),
                                        Date = date,
                                        MaintenanceUnit = MainDB.maintenanceUnits.FirstOrDefault(u => u.Name.Contains(data[4].Trim()))?.MaintenanceUnitId ?? -1,
                                        MachineNo = data[6].Trim(),
                                        AcceptedTime = acceptedTime,
                                        RepairStarted = repairStarted,
                                        CompletedTime = completedTime,
                                        OutageStarted = outageStarted,
                                        OutageEnded = outageEnded,
                                        Responsible = data[14].Trim(),
                                        Model = data[15].Trim(),
                                        Workstation = data[16].Trim(),
                                        IssueDescription = data[18].Trim(),
                                        Details = data[19].Trim(),
                                        RequestingUnit = MainDB.requestingUnits.FirstOrDefault(u => u.Name == data[20].Trim())?.RequestingUnitId ?? -1,
                                        RequestingEmployee = MainDB.allCompanyEmployees.FirstOrDefault(e => e.Name == data[21].Trim())?.EmployeeNo ?? String.Empty,
                                        RequestingUnitConfirmation = MainDB.confirmations.FirstOrDefault(c => c.Name == data[22].Trim())?.ConfirmationId ?? -1,
                                        RequestingUnitResponse = data[23].Trim(),
                                    };

                                    // 計算類
                                    rec.RepairDuration = completedTime - repairStarted; // 維護工時
                                    rec.OutageDuration = outageEnded - outageStarted;   // 停動工時

                                    history.Add(rec);

                                    // 多對多欄位
                                    // 維護人員
                                    string[] maintenanceEmployee = data[5].Trim().Split(',');
                                    foreach (var me in maintenanceEmployee)
                                    {
                                        string employeeID = MainDB.maintenanceEngineers.FirstOrDefault(e => me.Trim() == e.Name)?.EmployeeNo ?? String.Empty;

                                        if (!string.IsNullOrEmpty(employeeID))
                                        {
                                            hm.Add(new Historty_MaintenanceEmployee()
                                            {
                                                WorkOrderNo = workOrderNo,
                                                EmployeeID = employeeID,
                                            });
                                        }
                                    }

                                    // 維護類型
                                    string[] issueCategory = data[17].Trim().Split(',');
                                    foreach (var ic in issueCategory)
                                    {
                                        int categoryId = MainDB.issueCategories.FirstOrDefault(c => ic == c.CategoryName)?.CategoryId ?? -1;

                                        if (categoryId != -1)
                                        {
                                            hi.Add(new History_IssueCategory()
                                            {
                                                WorkOrderNo = workOrderNo,
                                                CategoryId = categoryId,
                                            });
                                        }
                                    }

                                    //// 問題描述
                                    //string[] issueDescription = data[18].Trim().Split(',');
                                    //foreach (var de in issueDescription)
                                    //    MainDB.history_IssueDescriptions.Add(new History_IssueDescription()
                                    //    {
                                    //        WorkOrderNo = workOrderNo,
                                    //        DescriptionId = MainDB.issueDescriptions.FirstOrDefault(d => d.DescriptionId == de.Trim())?.
                                    //    });
                                }

                                recCount++;
                            }

                            //var csv = new Csv();
                            //var historyCsv = csv.LoadCsv(openDialog.FileName, hasHeader: true);

                            //_history.Clear();
                            //foreach (var rec in historyCsv)
                            //{
                            //    //_history.Add(rec);
                            //}

                            isSuccess = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return (isSuccess, history, hm, hi);
        }

        //        internal List<HistoryCsv> LoadCsv(string fullFileName, bool hasHeader)
        //        {
        //            try
        //            {
        //                using (var sr = new StreamReader(fullFileName, Encoding.UTF8))
        //                {
        //                    var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        //                    {
        //                        HasHeaderRecord = hasHeader
        //                    };

        //                    using (var csv = new CsvReader(sr, config))
        //                    {
        //                        csv.Context.RegisterClassMap<HistoryCsvMap>();
        //                        var data = csv.GetRecords<HistoryCsv>().ToList();
        //                        return data;
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine(ex.Message);
        //            }

        //            return new List<HistoryCsv>();
        //        }
    }
}
