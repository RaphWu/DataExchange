﻿//using CsvHelper.Configuration;
//using CsvHelper.Configuration.Attributes;

//namespace Calin.EDoc.Models
//{
//    /// <summary>
//    /// 設備維護履歷 CsvHelper 用類別映射。
//    /// </summary>
//    [CultureInfo("zh-TW")]
//    public class HistoryCsvMap : ClassMap<HistoryCsv>
//    {
//        public HistoryCsvMap()
//        {
//            Map(m => m.SerNo).Name("序號");
//            Map(m => m.WorkOrderNo).Name("維護工單編號");
//            Map(m => m.Creator).Name("建檔人員");
//            Map(m => m.Date).Name("日期");
//            Map(m => m.MaintenanceUnit).Name("維護單位");
//            Map(m => m.MaintenanceEmployee).Name("維護人員");
//            Map(m => m.MachineNo).Name("機台編號");
//            Map(m => m.AcceptedTime).Name("接收時間(hh：mm)");
//            Map(m => m.RepairStarted).Name("維修開始(hh：mm)");
//            Map(m => m.CompletedTime).Name("完成時間(hh：mm)");
//            Map(m => m.RepairDuration).Name("維修工時(min)");
//            Map(m => m.OutageStarted).Name("停動開始(hh：mm)");
//            Map(m => m.OutageEnded).Name("停動結束(hh：mm)");
//            Map(m => m.OutageDuration).Name("停動工時(min)");
//            Map(m => m.Responsible).Name("責任歸屬");
//            Map(m => m.Model).Name("機種");
//            Map(m => m.Workstation).Name("工站");
//            Map(m => m.MaintenanceType).Name("維修類型");
//            Map(m => m.IssueDescription).Name("問題描述");
//            Map(m => m.Details).Name("維護/維修維護內容");
//            Map(m => m.RequestingUnit).Name("需求單位");
//            Map(m => m.RequestingEmployee).Name("需求單位人員");
//            Map(m => m.RequestingUnitConfirmation).Name("需求單位確認");
//            Map(m => m.RequestingUnitResponse).Name("需求單位回覆");
//        }
//    }
//}
