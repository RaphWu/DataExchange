﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Krypton.Toolkit.Suite.Extended.Data.Visualisation.ScottPlot;

namespace Calin.EDoc.Models
{
    /// <summary>
    /// 資料庫區。
    /// </summary>
    public static class MainDB
    {
        // 主表
        public static DataTable history = new DataTable();

        // 參照表
        public static DataTable allCompanyEmployees = new DataTable();
        public static DataTable maintenanceEngineers = new DataTable();
        public static DataTable maintenanceUnits = new DataTable();
        public static DataTable maintenanceTypes = new DataTable();
        public static DataTable issueCategories = new DataTable();
        public static DataTable requestingUnits = new DataTable();
        public static DataTable confirmations = new DataTable();

        // 中介表
        public static List<Historty_MaintenanceEmployee> historty_MaintenanceEmployees = new List<Historty_MaintenanceEmployee>();
        public static List<History_IssueCategory> history_IssueCategories = new List<History_IssueCategory>();

        public static void Init()
        {
            history.Columns.Add("SerNo", typeof(int));
            history.Columns.Add("WorkOrderNo             ", typeof(string));
            history.Columns.Add("Creator             ", typeof(string));
            history.Columns.Add("Date                ", typeof(int));
            history.Columns.Add("MaintenanceUnit     ", typeof(int));
            // MaintenanceEmployee	維護人員                  
            history.Columns.Add("MachineNo               ", typeof(string));
            history.Columns.Add("AcceptedTime            ", typeof(DateTime));
            history.Columns.Add("RepairStarted           ", typeof(DateTime));
            history.Columns.Add("CompletedTime           ", typeof(DateTime));
            history.Columns.Add("RepairDuration          ", typeof(TimeSpan));
            history.Columns.Add("OutageStarted           ", typeof(DateTime));
            history.Columns.Add("OutageEnded             ", typeof(DateTime));
            history.Columns.Add("OutageDuration          ", typeof(TimeSpan));
            history.Columns.Add("Responsible             ", typeof(string));
            history.Columns.Add("Model                   ", typeof(string));
            history.Columns.Add("Workstation             ", typeof(string));
            // IssueCategory 維護類型                        
            history.Columns.Add("IssueDescription            ", typeof(string));
            history.Columns.Add("Details                     ", typeof(string));
            history.Columns.Add("RequestingUnit              ", typeof(int));
            history.Columns.Add("RequestingEmployee          ", typeof(string));
            history.Columns.Add("RequestingUnitConfirmation  ", typeof(int));
            history.Columns.Add("RequestingUnitResponse     ", typeof(string));
        }
    }
}
