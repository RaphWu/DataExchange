﻿//namespace Calin.EDoc.Models
//{
//    /// <summary>
//    /// 問題描述中介表。
//    /// </summary>
//    public class History_IssueDescription
//    {
//        /// <summary>
//        /// 維護工單編號。
//        /// </summary>
//        public string WorkOrderNo { get; set; }

//        /// <summary>
//        /// 問題描述代號。
//        /// </summary>
//        public int DescriptionId { get; set; }
//    }
//}
