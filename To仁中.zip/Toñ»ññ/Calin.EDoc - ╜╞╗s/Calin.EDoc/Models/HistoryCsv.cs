﻿//namespace Calin.EDoc.Models
//{
//    /// <summary>
//    /// 設備維護履歷主資料表 (csv操作用)。
//    /// </summary>
//    public class HistoryCsv : History
//    {
//        /// <summary>
//        /// 維護人員。
//        /// </summary>
//        public string MaintenanceEmployee { get; set; }

//        /// <summary>
//        /// 問題分類。
//        /// </summary>
//        public int IssueCategory { get; set; }

//        /// <summary>
//        /// 問題描述。
//        /// </summary>
//        public string IssueDescription { get; set; }
//    }
//}
