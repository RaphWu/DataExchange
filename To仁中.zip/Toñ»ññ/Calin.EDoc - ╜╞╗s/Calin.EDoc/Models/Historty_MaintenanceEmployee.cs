﻿namespace Calin.EDoc.Models
{
    /// <summary>
    /// 維護人員中介表。
    /// </summary>
    public class Historty_MaintenanceEmployee
    {
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 維護人員工號。
        /// </summary>
        public string EmployeeID { get; set; }
    }
}
