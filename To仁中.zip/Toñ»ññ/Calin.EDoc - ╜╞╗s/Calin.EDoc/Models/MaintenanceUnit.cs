﻿namespace Calin.EDoc.Models
{
    /// <summary>
    /// 維護單位清單。
    /// </summary>
    public class MaintenanceUnit
    {
        /// <summary>
        /// 單位代號。
        /// </summary>
        public int MaintenanceUnitId { get; set; }

        /// <summary>
        /// 單位名稱。
        /// </summary>
        public string Name { get; set; }
    }
}
