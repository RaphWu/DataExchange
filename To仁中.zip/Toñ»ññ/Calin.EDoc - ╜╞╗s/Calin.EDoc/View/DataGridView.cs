﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Krypton.Toolkit.Suite.Extended.AdvancedDataGridView;

namespace Calin.EDoc.View
{
    internal static class DataGridView
    {
    }
}
