# TOYO 電動缸控制程式庫使用手冊

## 1. 安裝方式

1. 開發環境為 .NET Framework 4.7.1 或以上版本。
1. 在 Visual Studio 中建立或開啟一個 Windows Forms / Console / WPF 專案。
1. 將編譯好的 `CALIN.dll` 加入至專案參考：<br />專案 → 右鍵 → Add Reference → 瀏覽 → 選擇 `CALIN.dll`。
1. 在程式碼檔案中引用命名空間：

```chsarp
using System.IO.Ports;
using CALIN.ToyoCylinder;
using CALIN.ToyoCylinder.ToyoSingleCylinder;
```

## 2. 呼叫方式

以下展示如何建立電動缸的物件：

```chsarp
var cylinder = new ToyoSingleCylinder( // 建立物件
    1,            // 站號
    "COM1",       // 使用的串列埠名稱
    19200,        // BaudRate 鮑率
    Parity.None,  // Parity 同位位元
    8,            // DataBits 資料位元
    StopBits.One, // StopBits 停止位元
    0.0,          // 電動缸最小行程
    100.0         // 電動缸最大行程
    );

cylinder.OpenCylinder(); // 建立連線
cylinder.Disconnect();   // 中斷連線
```

## 3. 若您以 CancellationTokenSource 執行取消動作

這段說明是 [CancellationTokenSource](https://learn.microsoft.com/zh-tw/dotnet/api/system.threading.cancellationtokensource) 的搭配，必須是您會使用 CancellationTokenSource 為前提。若您不打算使用 CancellationTokenSource，請跳過這一段。

## 3. API 說明

以下為程式庫內公開的主要 API，依檔案分類整理。<br />
（此為索引，詳細功能需參考程式碼內 XML 註解或二次開發文件）

CALIN/ObservableProperty.cs

class ObservableProperty<T>

T Value { get; set; }

event PropertyChangedEventHandler PropertyChanged

CALIN/ReusableCancellationTokenSource.cs

class ReusableCancellationTokenSource

CancellationToken Token { get; }

void Cancel()

void Reset()

CALIN/ToyoCylinder/CylinderStatus.cs

enum CylinderStatus { ... }

CALIN/ToyoCylinder/ToyoCylinder.cs

class ToyoCylinder

void Connect()

void Disconnect()

void MoveToPosition(int position)

event EventHandler<CylinderStatusEventArgs> OnStatusChanged

CALIN/ToyoCylinder/ToyoCylinderEvent.cs

class ToyoCylinderEvent

event EventHandler Connected

event EventHandler Disconnected

event EventHandler<CylinderStatusEventArgs> StatusChanged

CALIN/ToyoCylinder/ToyoSingleCylinder/ToyoSingleCylinder.cs

class ToyoSingleCylinder : ToyoCylinder

ToyoSingleCylinder(string portName)

void Connect()

void Disconnect()

void MoveToPosition(int pos)

void Stop()

CylinderParams Parameters { get; set; }

CylinderStatus Status { get; }

（其餘檔案如 Frame.cs、Motion.cs、Polling.cs、Queue.cs、Models/\* 等，提供內部協議處理與狀態模型，通常不需直接呼叫。）

## 4. 事件與回呼

此程式庫採用事件 (Event) 機制通知應用程式，例如：

```charp
var cylinder = new ToyoSingleCylinder("COM1");

cylinder.OnStatusChanged += (s, e) =>
{
    Console.WriteLine("Cylinder status: " + e.Status);
};

cylinder.Connect();
cylinder.MoveToPosition(200);
```

#### 常見事件：

- Connected → 成功連線時觸發
- Disconnected → 中斷連線時觸發
- StatusChanged → 狀態變化時觸發

## 5. 範例程式碼

以下提供一個簡單 Console App 範例：

```charp
using System;
using CALIN.ToyoCylinder.ToyoSingleCylinder;

class Program
{
    static void Main()
    {
        var cylinder = new ToyoSingleCylinder("COM1");

        cylinder.OnStatusChanged += (s, e) =>
        {
            Console.WriteLine("Cylinder status: " + e.Status);
        };

        cylinder.Connect();
        Console.WriteLine("Connected to cylinder.");

        cylinder.MoveToPosition(150);
        Console.WriteLine("Moving to position 150...");

        Console.WriteLine("Press any key to stop...");
        Console.ReadKey();

        cylinder.Stop();
        cylinder.Disconnect();
        Console.WriteLine("Disconnected.");
    }
}
```

📌 提示：

若要多缸控制，可建立多個 ToyoSingleCylinder 物件，分別綁定不同的通訊埠 (COMx)。

如需監控訊號，可透過 PortInStatus 與 PortOutStatus 模型取得。
