﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.Core;
using Calin.ToyoCylinder;
using Calin.ToyoCylinder.ToyoSingleCylinder;

namespace ToyoSingleCylinderTest
{
    public partial class Form_ToyoSingleCylinderTest : Form
    {
        private ReusableCancellationTokenSource _rcts;
        private CancellationToken _token;
        private ToyoSingleCylinder _tsc;
        BindingSource bs = new BindingSource();

        public Form_ToyoSingleCylinderTest()
        {
            InitializeComponent();
        }

        #region Utility

        //private void SetControlEnabled(bool isConnected)
        //{
        //    button_Connect.InvokeIfRequired(() =>
        //    {
        //        button_Connect.Enabled = !isConnected;
        //        groupBox_SerialPort.Enabled = !isConnected;
        //        groupBox_Cylinder.Enabled = !isConnected;

        //        tabControl_Action.Enabled = isConnected;
        //        button_Disconnct.Enabled = isConnected;
        //        panel_Test.Enabled = isConnected;
        //    });
        //}

        /// <summary>
        /// 更新 Serial Port 選擇器。
        /// </summary>
        private void UpdateSerialPortParamsSelector()
        {
            System.IO.Ports.SerialPort serial = new System.IO.Ports.SerialPort();

            string[] portNameList = System.IO.Ports.SerialPort.GetPortNames();
            Array.Sort(portNameList, (a, b) =>
            {
                int numA = int.Parse(Regex.Match(a, @"\d+").Value);
                int numB = int.Parse(Regex.Match(b, @"\d+").Value);
                return numA.CompareTo(numB);
            });
            comboBox_COM.Items.Clear();
            comboBox_COM.Items.AddRange(portNameList);
            comboBox_COM.SelectedIndex = 0;

            comboBox_BaudRate.Items.Clear();
            comboBox_BaudRate.Items.AddRange((new int[] { 2400, 4800, 9600, 19200, 38400, 57600, 115200 }).Cast<object>().ToArray());
            comboBox_BaudRate.SelectedItem = 19200;

            comboBox_Parity.Items.Clear();
            comboBox_Parity.Items.AddRange(Enum.GetValues(typeof(System.IO.Ports.Parity)).Cast<object>().ToArray());
            comboBox_Parity.SelectedItem = System.IO.Ports.Parity.None;

            textBox_DataBits.Text = "8";

            comboBox_StopBits.Items.Clear();
            comboBox_StopBits.Items.AddRange(Enum.GetValues(typeof(System.IO.Ports.StopBits)).Cast<object>().ToArray());
            comboBox_StopBits.SelectedItem = System.IO.Ports.StopBits.One;
        }

        #endregion

        #region Form Event

        private void Form_ToyoSingleCylinderTest_Load(object sender, System.EventArgs e)
        {
            bs.DataSource = typeof(ToyoSingleCylinder);
            _rcts = new ReusableCancellationTokenSource();

            UpdateSerialPortParamsSelector();

            /********************
             * Data Binding
             ********************/
            // Control
            numericUpDown_AbsMove.DataBindings.Add("Minimum", textBox_MinStroke, "Text", true, DataSourceUpdateMode.OnPropertyChanged);
            numericUpDown_AbsMove.DataBindings.Add("Maximum", textBox_MaxStroke, "Text", true, DataSourceUpdateMode.OnPropertyChanged);
            trackBar_AbsMove.DataBindings.Add("Minimum", textBox_MinStroke, "Text", true, DataSourceUpdateMode.OnPropertyChanged);
            trackBar_AbsMove.DataBindings.Add("Maximum", textBox_MaxStroke, "Text", true, DataSourceUpdateMode.OnPropertyChanged);
            numericUpDown_AbsMove.DataBindings.Add("Value", trackBar_AbsMove, "Value", false, DataSourceUpdateMode.OnPropertyChanged);

            button_Connect.DataBindings.Add("Enabled", bs, "IsClose");
            groupBox_SerialPort.DataBindings.Add("Enabled", bs, "IsClose");
            groupBox_Cylinder.DataBindings.Add("Enabled", bs, "IsClose");
            tabControl_Action.DataBindings.Add("Enabled", bs, "IsOpen");
            button_Disconnct.DataBindings.Add("Enabled", bs, "IsOpen");
            panel_Test.DataBindings.Add("Enabled", bs, "IsOpen");

            //// Cylinder狀態
            //textBox_ServoStatus.DataBindings.Add("Text", bs, nameof(_tsc.ServoStatusMessage));
            //button_ServoSwitch.DataBindings.Add("Text", bs, nameof(_tsc.ServoStatusMessage));
            //textBox_MotorStatus.DataBindings.Add("Text", bs, nameof(_tsc.ActionStatusMessage));
            //textBox_InpStatus.DataBindings.Add("Text", bs, nameof(_tsc.InpStatusMessage));
            //textBox_TrqLmtStatus.DataBindings.Add("Text", bs, nameof(_tsc.TrqLmtStatusMessage));
            //textBox_MotorAlarm.DataBindings.Add("Text", bs, nameof(_tsc.AlarmStatusMessage));
            //textBox_ErrorStatus.DataBindings.Add("Text", bs, nameof(_tsc.ErrorStatusMessage));
            //textBox_MotorRPM.DataBindings.Add("Text", bs, nameof(_tsc.MonRpm));
            //textBox_MotorCurrent.DataBindings.Add("Text", bs, nameof(_tsc.MonCurrent), true, DataSourceUpdateMode.OnPropertyChanged, null, "0.0");
            //textBox_MotorCommandPos.DataBindings.Add("Text", bs, nameof(_tsc.CmdNowPos), true, DataSourceUpdateMode.OnPropertyChanged, null, "0.00");
            //textBox_MotorCurrentPos.DataBindings.Add("Text", bs, nameof(_tsc.EcdPos), true, DataSourceUpdateMode.OnPropertyChanged, null, "0.00");

            //// Port Out
            //checkBox_PortOut01.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut01));
            //checkBox_PortOut02.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut02));
            //checkBox_PortOut03.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut03));
            //checkBox_PortOut04.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut04));
            //checkBox_PortOut05.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut05));
            //checkBox_PortOut06.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut06));
            //checkBox_PortOut07.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut07));
            //checkBox_PortOut08.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut08));
            //checkBox_PortOut09.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut09));
            //checkBox_PortOut10.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut10));

            //// Port In
            //checkBox_PortIn01.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn01));
            //checkBox_PortIn02.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn02));
            //checkBox_PortIn03.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn03));
            //checkBox_PortIn04.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn04));
            //checkBox_PortIn05.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn05));
            //checkBox_PortIn06.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn06));
            //checkBox_PortIn07.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn07));
            //checkBox_PortIn08.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn08));
            //checkBox_PortIn09.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn09));
            //checkBox_PortIn10.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn10));
            //checkBox_PortIn11.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn11));
            //checkBox_PortIn12.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn12));
            //checkBox_PortIn13.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn13));
            //checkBox_PortIn14.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn14));

            //// 程式庫運行時間
            //textBox_ExecutionTime.DataBindings.Add("Text", bs, nameof(_tsc.ExecutionTime));

            // Cylinder狀態
            textBox_ServoStatus.DataBindings.Add("Text", bs, "ServoStatusMessage");
            button_ServoSwitch.DataBindings.Add("Text", bs, "ServoStatusMessage");
            textBox_MotorStatus.DataBindings.Add("Text", bs, "ActionStatusMessage");
            textBox_InpStatus.DataBindings.Add("Text", bs, "InpStatusMessage");
            textBox_TrqLmtStatus.DataBindings.Add("Text", bs, "TrqLmtStatusMessage");
            textBox_MotorAlarm.DataBindings.Add("Text", bs, "AlarmStatusMessage");
            textBox_ErrorStatus.DataBindings.Add("Text", bs, "ErrorStatusMessage");
            textBox_MotorRPM.DataBindings.Add("Text", bs, "MonRpm");
            textBox_MotorCurrent.DataBindings.Add("Text", bs, "MonCurrent", true, DataSourceUpdateMode.OnPropertyChanged, null, "0.0");
            textBox_MotorCommandPos.DataBindings.Add("Text", bs, "CmdNowPos", true, DataSourceUpdateMode.OnPropertyChanged, null, "0.00");
            textBox_MotorCurrentPos.DataBindings.Add("Text", bs, "EcdPos", true, DataSourceUpdateMode.OnPropertyChanged, null, "0.00");

            // Port Out
            checkBox_PortOut01.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut01");
            checkBox_PortOut02.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut02");
            checkBox_PortOut03.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut03");
            checkBox_PortOut04.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut04");
            checkBox_PortOut05.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut05");
            checkBox_PortOut06.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut06");
            checkBox_PortOut07.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut07");
            checkBox_PortOut08.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut08");
            checkBox_PortOut09.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut09");
            checkBox_PortOut10.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut10");

            // Port In
            checkBox_PortIn01.DataBindings.Add("Checked", bs, "PortInStatus.PortIn01");
            checkBox_PortIn02.DataBindings.Add("Checked", bs, "PortInStatus.PortIn02");
            checkBox_PortIn03.DataBindings.Add("Checked", bs, "PortInStatus.PortIn03");
            checkBox_PortIn04.DataBindings.Add("Checked", bs, "PortInStatus.PortIn04");
            checkBox_PortIn05.DataBindings.Add("Checked", bs, "PortInStatus.PortIn05");
            checkBox_PortIn06.DataBindings.Add("Checked", bs, "PortInStatus.PortIn06");
            checkBox_PortIn07.DataBindings.Add("Checked", bs, "PortInStatus.PortIn07");
            checkBox_PortIn08.DataBindings.Add("Checked", bs, "PortInStatus.PortIn08");
            checkBox_PortIn09.DataBindings.Add("Checked", bs, "PortInStatus.PortIn09");
            checkBox_PortIn10.DataBindings.Add("Checked", bs, "PortInStatus.PortIn10");
            checkBox_PortIn11.DataBindings.Add("Checked", bs, "PortInStatus.PortIn11");
            checkBox_PortIn12.DataBindings.Add("Checked", bs, "PortInStatus.PortIn12");
            checkBox_PortIn13.DataBindings.Add("Checked", bs, "PortInStatus.PortIn13");
            checkBox_PortIn14.DataBindings.Add("Checked", bs, "PortInStatus.PortIn14");

            // 程式庫運行時間
            textBox_ExecutionTime.DataBindings.Add("Text", bs, "ExecutionTime");

#if DEBUG
            label_RequestMessage.DataBindings.Add("Text", bs, "DebugMessage.RequestFrame");
            label_ResponseMessage.DataBindings.Add("Text", bs, "DebugMessage.ResponseFrame");
            label_ConsoleMessage.DataBindings.Add("Text", bs, "DebugMessage.ConsoleMessage");
            label_ErrorMessage.DataBindings.Add("Text", bs, "DebugMessage.ErrorMessage");
#endif
        }

        #endregion

        #region 事件處理

        private void StatusChangedEvent(object sender, ToyoCylinder.StatusChangedEventArgs e)
        {
            switch (e.CylinderStatus)
            {
                case CylinderStatusType.CylinderClosed:
                    Disconnct();
                    break;
                //case CylinderStatus.CylinderOpened:
                //    break;
                case CylinderStatusType.ServoOff:
                    Disconnct();
                    break;
                    //case CylinderStatus.ServoOn:
                    //    break;
                    //case CylinderStatus.InPosition:
                    //    break;
                    //case CylinderStatus.NotInPosition:
                    //    break;
                    //case CylinderStatus.InMotion:
                    //    break;
            }
        }

        private void ErrorOccurredEvent(object sender, ToyoCylinder.ErrorEventArgs e)
        {
            Disconnct();
            //Console.WriteLine(string.Concat("Error: ", e.Message));
        }

        private void AlarmOccurredEvent(object sender, ToyoCylinder.AlarmEventArgs e)
        {
            Disconnct();
            //Console.WriteLine(string.Concat("Alarm: ", e.Message));
        }

        #endregion

        #region Connect/Disconnct

        /// <summary>
        /// 連線終止。
        /// </summary>
        private void Disconnct()
        {
            _rcts.Cancel();

            if (_tsc != null)
            {
                _tsc.StatusChanged -= StatusChangedEvent;
                _tsc.ErrorOccurred -= ErrorOccurredEvent;
                _tsc.AlarmOccurred -= AlarmOccurredEvent;
                _tsc.CloseCylinder();
            }
        }

        /// <summary>
        /// 連線。
        /// </summary>
        private void Connect()
        {
            _rcts.Reset();
            _token = _rcts.Token;

            _tsc = new ToyoSingleCylinder(
                       byte.Parse(textBox_Station.Text),
                       (string)comboBox_COM.SelectedItem,
                       int.Parse(comboBox_BaudRate.Text),
                       (System.IO.Ports.Parity)comboBox_Parity.SelectedItem,
                       int.Parse(textBox_DataBits.Text),
                       (System.IO.Ports.StopBits)comboBox_StopBits.SelectedItem,
                       double.Parse(textBox_MinStroke.Text),
                       double.Parse(textBox_MaxStroke.Text));
            _tsc.OpenCylinder(_rcts.CreateLinkedToken());

            if (_tsc.IsOpen)
            {
                bs.DataSource = _tsc;

                _tsc.StatusChanged += StatusChangedEvent;
                _tsc.ErrorOccurred += ErrorOccurredEvent;
                _tsc.AlarmOccurred += AlarmOccurredEvent;
            }
        }

        #endregion

        /********************
         * 按鈕
         ********************/
        /// <summary>
        /// 連線終止。
        /// </summary>
        private void button_Disconnct_Click(object sender, EventArgs e)
        {
            Disconnct();
        }

        /// <summary>
        /// 連線。
        /// </summary>
        private void button_Connect_Click(object sender, EventArgs e)
        {
            Connect();
        }

        /// <summary>
        /// 復歸。
        /// </summary>
        private async void button_OriginReturn_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                await _tsc.OriginReturn();
            }
        }

        /// <summary>
        /// 伺服開啟/關閉。
        /// </summary>
        private void button_ServoSwitch_Click(object sender, EventArgs e)
        {
            if (_tsc.ServoStatus)
                _tsc.ServoOff();
            else
                _tsc.ServoOn();
        }

        /// <summary>
        /// 警報復歸。
        /// </summary>
        private void button_AlarmReset_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.AlarmReset();
            }
        }

        /// <summary>
        /// 緊急停止。
        /// </summary>
        private void button_EmergencyStop_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.EmergencyStop();
                checkBox_RepeatTest.Checked = false;
            }
        }

        /// <summary>
        /// 減速停止。
        /// </summary>
        private void button_DeceleratesToStop_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.DeceleratesToStop();
                checkBox_RepeatTest.Checked = false;
            }
        }

        /// <summary>
        /// 重覆運動測試
        /// </summary>
        private async void checkBox_RepeatTest_CheckedChanged(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                Random rnd = new Random(DateTime.Now.Millisecond);
                double minStroke = double.Parse(textBox_MinStroke.Text);
                double maxStroke = double.Parse(textBox_MaxStroke.Text);

                try
                {
                    await Task.Run(async () =>
                    {
                        while (checkBox_RepeatTest.Checked)
                        {
                            double pos = Math.Round((rnd.NextDouble() * (maxStroke - minStroke)) + minStroke, 2);
                            int speed = rnd.Next(15, 60);

                            label_TestPos.InvokeIfRequired(() =>
                            {
                                label_TestPos.Text = string.Concat("位置: ", pos.ToString("N2"));
                                label_TestSpeed.Text = string.Concat("速度: ", speed.ToString(), "%");
                            });

                            await _tsc.AbsMove(pos, speed, 10);
                            await Task.Delay(150);
                        }
                    }, _rcts.Token);
                }
                catch (OperationCanceledException)
                {
                }
                catch (Exception ex)
                {
                    _tsc.CloseCylinder();
                    Console.WriteLine(string.Concat("checkBox_RepeatTest_CheckedChanged Exception: ", ex.Message));
                }
            }

            label_TestPos.InvokeIfRequired(() =>
            {
                checkBox_RepeatTest.Checked = false;
                label_TestPos.Text = "位置: -";
                label_TestSpeed.Text = "速度: -";
            });
        }
    }
}
