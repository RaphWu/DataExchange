﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;

namespace Calin.Core
{
    /********************
     * Data Binding 基底類別。
     ********************/
    public abstract class BindableBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private readonly SynchronizationContext _syncContext;

        public BindableBase()
        {
            _syncContext = SynchronizationContext.Current;
        }

        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            if (_syncContext != null)
            {
                _syncContext.Post(_ =>
                {
                    if (PropertyChanged != null)
                        PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                }, null);
            }
            else
            {
                if (PropertyChanged != null)
                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        //internal void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        //{
        //    if (Application.OpenForms.Count > 0)
        //    {
        //        var form = Application.OpenForms[0];
        //        if (form.InvokeRequired)
        //        {
        //            form.Invoke(new Action(() =>
        //            {
        //                if (PropertyChanged != null)
        //                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
        //            }));
        //        }
        //        else
        //        {
        //            if (PropertyChanged != null)
        //                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
        //        }
        //    }
        //}
    }
}
