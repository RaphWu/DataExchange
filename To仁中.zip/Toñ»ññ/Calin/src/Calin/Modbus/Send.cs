﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Calin.Modbus.Contants;
using Calin.Modbus.Models;

namespace Calin.Modbus
{
    public partial class ModbusMaster
    {
        /// <summary>
        /// 發送 Modbus 請求並等待回應。(強化邏輯配對)
        /// </summary>
        /// <param name="slaveAddress">站號。</param>
        /// <param name="functionCode">功能碼。</param>
        /// <param name="pduPayload"></param>
        public async Task<T> SendRequestAsync<T>(byte slaveAddress,
                                                 byte functionCode,
                                                 byte[] pduPayload,
                                                 Func<ModbusFrame, bool> matchPredicate,
                                                 int timeoutMs = 5000,
                                                 CancellationToken userToken = default)
        {
            ThrowIfDisposed();
            var reqId = Interlocked.Increment(ref _nextRequestId);
            var tcs = new TaskCompletionSource<byte[]>(TaskCreationOptions.RunContinuationsAsynchronously);
            var pending = new PendingRequest
            {
                RequestId = reqId,
                Slave = slaveAddress,
                FunctionCode = functionCode,
                Completion = tcs,
                Cancellation = new CancellationTokenSource(timeoutMs),
                MatchPredicate = matchPredicate
            };
            _pending[reqId] = pending;


            var linked = CancellationTokenSource.CreateLinkedTokenSource(pending.Cancellation.Token, userToken);
            linked.Token.Register(() =>
            {
                _pending.TryRemove(reqId, out _);
                tcs.TrySetCanceled();
            });

            try
            {
                var frame = BuildRequestFrame(slaveAddress, functionCode, pduPayload);
                lock (_sendLock) { _port.Write(frame, 0, frame.Length); }

                var responseBytes = await tcs.Task.ConfigureAwait(false);
                if (_parsers.TryGetValue(functionCode, out var parser))
                {
                    var obj = parser(responseBytes);
                    if (obj is T t) return t;
                    return (T)obj;
                }
                else
                {
                    if (typeof(T) == typeof(byte[]))
                        return (T)(object)responseBytes;
                    throw new InvalidOperationException($"No parser registered for function code 0x{functionCode:X2}");
                }
            }
            finally
            {
                _pending.TryRemove(reqId, out _);
            }
        }

        private byte[] BuildRequestFrame(byte slave, byte functionCode, byte[] payload)
        {
            byte[] body = new byte[2 + payload.Length];
            body[0] = slave;
            body[1] = functionCode;
            Array.Copy(payload, 0, body, 2, payload.Length);

            if (_mode == ModbusMode.RTU)
            {
                ushort crc = CalcCrc16(body, 0, body.Length);
                var frame = new byte[body.Length + 2];
                Array.Copy(body, 0, frame, 0, body.Length);
                frame[body.Length] = (byte)(crc & 0xFF);
                frame[body.Length + 1] = (byte)(crc >> 8);
                return frame;
            }
            else // ASCII
            {
                byte lrc = CalcLrc(body, 0, body.Length);
                var frame = new List<byte>();
                frame.Add((byte)':');
                foreach (var b in body.Concat(new byte[] { lrc }))
                {
                    frame.AddRange(Encoding.ASCII.GetBytes(b.ToString("X2")));
                }
                frame.AddRange(new byte[] { 0x0D, 0x0A }); // CRLF
                return frame.ToArray();
            }
        }
    }
}