﻿namespace Calin.ToyoCylinder
{
    /// <summary>
    /// 電動缸狀態類型。
    /// </summary>
    public enum CylinderStatusType
    {
        // 一般狀態
        CylinderOpened,
        CylinderClosed,
        ServoOn,
        ServoOff,

        // 運動相關
        InMotion,
        InPosition,
        NotInPosition,
    }
}
