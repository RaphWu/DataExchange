﻿using System;
using System.IO.Ports;
using Calin.Core;

namespace Calin.ToyoCylinder
{
    public partial class ToyoCylinder : BindableBase, IDisposable
    {
        private bool _disposed;
        internal ReusableCancellationTokenSource _rcts;
        internal SerialPort _sp;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;

            if (disposing)
            {
                _rcts.Cancel();
                _rcts.Dispose();

                if (_sp != null)
                {
                    if (_sp.IsOpen)
                        _sp.Close();
                    _sp.Dispose();
                }
            }

            _disposed = true;
        }
    }
}
