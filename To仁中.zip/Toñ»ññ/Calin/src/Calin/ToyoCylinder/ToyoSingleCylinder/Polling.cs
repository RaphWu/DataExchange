﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Calin.Core;
using Calin.ToyoCylinder.ToyoSingleCylinder.Constants;
using Calin.ToyoCylinder.ToyoSingleCylinder.Models;

namespace Calin.ToyoCylinder.ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        private async void PortAccessPolling(CancellationToken token)
        {
            const int ONE_WORD = 4; // 1 Word = 4 bytes
            const int TWO_WORD = 8; // 2 Words = 8 bytes

            System.IO.Stream stream = _sp.BaseStream;
            FrameStruct nextRequest = new FrameStruct();
            bool aFrameIsSend = true; // 有訊息幀已被發送
            DateTime timeMark = DateTime.Now; // 時間標記，用於計算逾時

            uint retryCounter = 0; // 指令重送計數器
            uint loopCounter = 0; // Polling 迴圈計數器
            uint readStatusIntervalTimeCounter = 0; // 讀取狀態的間隔計時器

            _pollingIsRunning = true;
            while (!_serialPortCloseRequest && !token.IsCancellationRequested)
            {
                try
                {
                    /***** 傳送邏輯 START *****/
                    if (!_serialPortCloseRequest && !aFrameIsSend)
                    {
                        if (_highPriorityQueue.Count > 0 || _retryQueue.Count > 0 || _requestQueue.Count > 0)
                        {
                            bool dequeueSuccess;
                            if (_highPriorityQueue.Count > 0)
                                dequeueSuccess = _highPriorityQueue.TryDequeue(out nextRequest);
                            else if (_retryQueue.Count > 0)
                                dequeueSuccess = _retryQueue.TryDequeue(out nextRequest);
                            else if (_requestQueue.Count > 0)
                                dequeueSuccess = _requestQueue.TryDequeue(out nextRequest);
                            else
                                dequeueSuccess = false;

                            if (_sp.IsOpen && dequeueSuccess)
                            {
                                await stream.WriteAsync(nextRequest.ByteArray, 0, nextRequest.ByteArray.Length, token);
                                await stream.FlushAsync(token);
                                timeMark = DateTime.Now;
                                Thread.Sleep(10);
#if DEBUG
                                _debugMessage.RequestFrame = Encoding.ASCII.GetString(nextRequest.ByteArray);
#endif
                                aFrameIsSend = true;
                            }
                        }
                    }
                    /***** 傳送邏輯 END *****/

                    token.ThrowIfCancellationRequested();

                    // 檢查是否斷線/空轉
                    if (aFrameIsSend && _sp.BytesToRead == 0)
                    {
                        TimeSpan ts = DateTime.Now - timeMark;
                        if (ts.TotalMilliseconds > 3000)
                            throw new TimeoutException("接收逾時！");
                    }

                    /***** 接收邏輯 START *****/
                    if (!_serialPortCloseRequest && aFrameIsSend && _sp.BytesToRead > 0)
                    {
                        byte[] responseData = null;
                        List<byte> responseByte = new List<byte>();
                        string responseString = string.Empty;

                        /***** 讀取迴圈 START *****/
                        bool started = false;
                        bool endReached = false;

                        while (!endReached && !token.IsCancellationRequested)
                        {
                            int b = _sp.ReadByte();
                            if (b == -1)
                                continue;

                            byte by = (byte)b;

                            if (!started)
                            {
                                if (by == 0x3A) // 等待起始字元
                                {
                                    responseByte.Clear();
                                    started = true;
                                }
                            }
                            else
                            {
                                responseByte.Add(by);

                                // 檢查結尾 CRLF
                                int len = responseByte.Count;
                                if (len >= 2 && responseByte[len - 2] == '\r' && responseByte[len - 1] == '\n')
                                {
                                    responseString = string.Concat(":", Encoding.ASCII.GetString(responseByte.ToArray()));

                                    responseByte.RemoveRange(len - 2, 2); // 去掉結尾 CRLF
                                    responseData = Converter.TowAsciiHexToBytes(responseByte.ToArray(), 0, responseByte.Count); // ASCII HEX 轉 byte[]

                                    // LRC 驗證
                                    int lrc = LRC.Lrc(responseData, true);
                                    if (lrc != responseData[responseData.Length - 1])
                                        throw new InvalidOperationException("LRC 驗證失敗");

                                    endReached = true;
#if DEBUG
                                    _debugMessage.ResponseFrame = responseString;
#endif
                                }
                            }

                            /***** 讀取迴圈 END *****/

                            byte st = responseData[0];    // 站號
                            byte fCode = responseData[1]; // 功能碼

                            if (fCode < 0x80)
                            {
                                if (!_requestHolding)
                                    retryCounter = 0;

                                switch (nextRequest.CallerId)
                                {
                                    case CallerId.ReadStatus:
                                        const int head = 7;
                                        ServoStatus = responseData[0x0C] == 1;
                                        ActionStatus = Convert.ToInt16(responseString.Substring(
                                            head + 0x0 * ONE_WORD, ONE_WORD), 16);
                                        InpStatus = Convert.ToInt16(responseString.Substring(
                                            head + 0x01 * ONE_WORD, ONE_WORD), 16);
                                        TrqLmtStatus = Convert.ToInt16(responseString.Substring(
                                            head + 0x4 * ONE_WORD, ONE_WORD), 16);
                                        AlarmStatus = Convert.ToInt16(responseString.Substring(
                                            head + 0x5 * ONE_WORD, ONE_WORD), 16);
                                        ErrorStatus = Convert.ToInt16(responseString.Substring(
                                            head + 0xD * ONE_WORD, ONE_WORD), 16);
                                        MonRpm = Convert.ToInt16(responseString.Substring(
                                            head + 0x6 * ONE_WORD, ONE_WORD), 16);
                                        MonCurrent = Convert.ToInt16(responseString.Substring(
                                            head + 0x7 * ONE_WORD, ONE_WORD), 16) / 10.0;
                                        CmdNowPos = Convert.ToInt32(responseString.Substring(
                                            head + 0x8 * ONE_WORD, TWO_WORD), 16) / 100.0;
                                        EcdPos = Convert.ToInt32(responseString.Substring(
                                            head + 0xA * ONE_WORD, TWO_WORD), 16) / 100.0;

                                        aFrameIsSend = false;
                                        break;
                                    case CallerId.PortOut:
                                        ushort portOut = Convert.ToUInt16(responseString.Substring(1 + 2 + 2 + 2, 4), 16);
                                        PortOut01 = (portOut & 0x0001) != 0;
                                        PortOut02 = (portOut & 0x0002) != 0;
                                        PortOut03 = (portOut & 0x0004) != 0;
                                        PortOut04 = (portOut & 0x0008) != 0;
                                        PortOut05 = (portOut & 0x0010) != 0;
                                        PortOut06 = (portOut & 0x0020) != 0;
                                        PortOut07 = (portOut & 0x0040) != 0;
                                        PortOut08 = (portOut & 0x0080) != 0;
                                        PortOut09 = (portOut & 0x0100) != 0;
                                        PortOut10 = (portOut & 0x0200) != 0;

                                        aFrameIsSend = false;
                                        break;
                                    case CallerId.PortIn:
                                        ushort data = Convert.ToUInt16(responseString.Substring(1 + 2 + 2 + 2, 4), 16);
                                        PortIn01 = (data & 0x0001) != 0;
                                        PortIn02 = (data & 0x0002) != 0;
                                        PortIn03 = (data & 0x0004) != 0;
                                        PortIn04 = (data & 0x0008) != 0;
                                        PortIn05 = (data & 0x0010) != 0;
                                        PortIn06 = (data & 0x0020) != 0;
                                        PortIn07 = (data & 0x0040) != 0;
                                        PortIn08 = (data & 0x0080) != 0;
                                        PortIn09 = (data & 0x0100) != 0;
                                        PortIn10 = (data & 0x0200) != 0;
                                        PortIn11 = (data & 0x0400) != 0;
                                        PortIn12 = (data & 0x0800) != 0;
                                        PortIn13 = (data & 0x1000) != 0;
                                        PortIn14 = (data & 0x2000) != 0;

                                        aFrameIsSend = false;
                                        break;
                                    case CallerId.Command:
                                        aFrameIsSend = false;
                                        break;
                                    case CallerId.WatchDog:
                                        if (responseString == ":010302544363\r")
                                        {
                                            aFrameIsSend = false;
                                        }
                                        else
                                        {
                                            CloseCylinder();
                                            throw new Exception("電動缸斷線！");
                                        }
                                        break;
                                    case CallerId.ErrorHistories:

                                        break;
                                    case CallerId.Initializer:
                                        if (responseString == ":0110999B0004B7\r")
                                        {
                                            aFrameIsSend = false;
                                        }
                                        else
                                        {
                                            CloseCylinder();
                                            throw new Exception("權限開通異常！");
                                        }
                                        break;
                                    default:
                                        throw new Exception(string.Concat("CallerId錯誤:\n", nextRequest.CallerId, "\nResponse Message: ", responseString));
                                }

                                _requestHolding = false;
                            }
                            else
                            {
                                string msg = string.Concat("CallerID: ", nextRequest.CallerId,
                                                           ", Frame: ", Encoding.ASCII.GetString(nextRequest.ByteArray));
                                if (++retryCounter <= _cp.RetryTimes)
                                {
                                    _requestHolding = true;

                                    string eMsg = string.Concat("重試第 ", retryCounter, " 次, ", msg);
                                    Console.WriteLine(eMsg);
#if DEBUG
                                    _debugMessage.ConsoleMessage = eMsg;
#endif

                                    Thread.Sleep(500);
                                    ResendFrame(nextRequest);
                                }
                                else
                                {
                                    string eMsg = string.Concat("此指令已被放棄: ", msg);
                                    Console.WriteLine(eMsg);
#if DEBUG
                                    _debugMessage.ErrorMessage = eMsg;
#endif
                                    retryCounter = 0;
                                }
                                aFrameIsSend = false;
                            }
                        }
                        /***** 接收邏輯 END *****/

                        token.ThrowIfCancellationRequested();

                        /***** 狀態讀取指令發送 START *****/
                        if (!_requestHolding)
                        {
                            bool isMatch = false;
                            switch (readStatusIntervalTimeCounter)
                            {
                                case 0:
                                    foreach (var rq in _requestQueue)
                                        if (rq.CallerId == CallerId.ReadStatus)
                                        {
                                            isMatch = true;
                                            break;
                                        }
                                    if (!isMatch)
                                        SendRequestFrame(CallerId.ReadStatus, 0x03, 0x1000, 0x0F);
                                    break;
                                case 1:
                                    foreach (var rq in _requestQueue)
                                        if (rq.CallerId == CallerId.PortOut)
                                        {
                                            isMatch = true;
                                            break;
                                        }
                                    if (!isMatch)
                                        SendRequestFrame(CallerId.PortOut, 0x03, 0x1020, 1);
                                    break;
                                case 2:
                                    foreach (var rq in _requestQueue)
                                        if (rq.CallerId == CallerId.PortIn)
                                        {
                                            isMatch = true;
                                            break;
                                        }
                                    if (!isMatch)
                                        SendRequestFrame(CallerId.PortIn, 0x03, 0x1040, 1);
                                    break;
                            }

                            if (++readStatusIntervalTimeCounter % 100 == 0) // 降低讀取頻率
                                readStatusIntervalTimeCounter = 0;
                        }
                        /***** 狀態讀取指令發送 END *****/
                    }

                    if (++loopCounter % 1000 == 0)
                        ExecutionTime = DateTime.Now - StartupTime; // 程式庫運行時間
                }
                catch (OperationCanceledException)
                {
                }
                catch (TimeoutException te)
                {
                    if (_sp.IsOpen)
                        CloseCylinder();
                    aFrameIsSend = false;

                    string eMsg = string.Concat("Timeout逾時: 電動缸斷線或", te.Message);
                    Console.WriteLine(eMsg);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
#endif
                }
                catch (UnauthorizedAccessException uae)
                {
                    if (_sp.IsOpen)
                        CloseCylinder();
                    aFrameIsSend = false;

                    string eMsg = string.Concat("IO異常: ", uae.Message);
                    Console.WriteLine(eMsg);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
#endif
                }
                catch (InvalidOperationException ioe)
                {
                    aFrameIsSend = false;

                    string eMsg = string.Concat("方法呼叫失敗: ", ioe.Message);
                    Console.WriteLine(eMsg);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
#endif
                }
                catch (Exception ex)
                {
                    string eMsg = string.Concat("接收輪詢的執行緒異常: ", ex.Message);
                    Console.WriteLine(eMsg);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
#endif
                }
                finally
                {
                }
            }

            _sp.DiscardInBuffer();
            _sp.DiscardOutBuffer();
            _pollingIsRunning = false;
        }


        //        private void PortAccessPolling(CancellationToken token)
        //        {
        //            const int ONE_WORD = 4; // 1 Word = 4 bytes
        //            const int TWO_WORD = 8; // 2 Words = 8 bytes

        //            FrameStruct nextRequest = new FrameStruct();
        //            bool aFrameIsSend = true; // 有訊息幀已被發送
        //            DateTime timeMark = DateTime.Now; // 時間標記，用於計算逾時

        //            uint retryCounter = 0; // 指令重送計數器
        //            uint loopCounter = 0; // Polling 迴圈計數器
        //            uint readStatusIntervalTimeCounter = 0; // 讀取狀態的間隔計時器

        //            _pollingIsRunning = true;
        //            while (!_serialPortCloseRequest && !token.IsCancellationRequested)
        //            {
        //                try
        //                {
        //                    /***** 傳送邏輯 START *****/
        //                    if (!_serialPortCloseRequest && !aFrameIsSend)
        //                    {
        //                        if (_highPriorityQueue.Count > 0 || _retryQueue.Count > 0 || _requestQueue.Count > 0)
        //                        {
        //                            bool dequeueSuccess;
        //                            if (_highPriorityQueue.Count > 0)
        //                                dequeueSuccess = _highPriorityQueue.TryDequeue(out nextRequest);
        //                            else if (_retryQueue.Count > 0)
        //                                dequeueSuccess = _retryQueue.TryDequeue(out nextRequest);
        //                            else if (_requestQueue.Count > 0)
        //                                dequeueSuccess = _requestQueue.TryDequeue(out nextRequest);
        //                            else
        //                                dequeueSuccess = false;

        //                            if (_sp.IsOpen && dequeueSuccess)
        //                            {
        //                                //_sps.DiscardInBuffer();
        //                                _sp.DiscardOutBuffer();
        //                                _sp.Write(nextRequest.ByteArray, 0, nextRequest.ByteArray.Length);
        //                                timeMark = DateTime.Now;
        //                                Thread.Sleep(10);
        //#if DEBUG
        //                                _debugMessage.RequestFrame = Encoding.ASCII.GetString(nextRequest.ByteArray);
        //#endif
        //                                aFrameIsSend = true;
        //                            }
        //                        }
        //                    }
        //                    /***** 傳送邏輯 END *****/

        //                    token.ThrowIfCancellationRequested();

        //                    // 檢查是否斷線/空轉
        //                    if (aFrameIsSend && _sp.BytesToRead == 0)
        //                    {
        //                        TimeSpan ts = DateTime.Now - timeMark;
        //                        if (ts.TotalMilliseconds > 3000)
        //                            throw new TimeoutException("接收逾時！");
        //                    }

        //                    /***** 接收邏輯 START *****/
        //                    if (!_serialPortCloseRequest && aFrameIsSend && _sp.BytesToRead > 0)
        //                    {
        //                        byte st = 0; // 站號
        //                        byte fCode = 0xFF; // 功能碼

        //                        //Task.Delay(300).Wait();
        //                        //byte[] readBuffer = new byte[_bytesToRead];
        //                        string responseString = _sp.ReadLine();
        //                        int bytesToRead = _sp.BytesToRead;

        //#if DEBUG
        //                        _debugMessage.ResponseFrame = responseString;
        //#endif

        //                        bool validation = ValidFrame(responseString);
        //                        if (validation)
        //                        {
        //                            st = Convert.ToByte(responseString.Substring(1, 2), 16);
        //                            fCode = Convert.ToByte(responseString.Substring(3, 2), 16);
        //                        }

        //                        if (validation && fCode < 0x80)
        //                        {
        //                            if (!_requestHolding)
        //                                retryCounter = 0;

        //                            switch (nextRequest.CallerId)
        //                            {
        //                                case CallerId.ReadStatus:
        //                                    const int head = 7;
        //                                    ServoStatus = Convert.ToBoolean(Convert.ToInt16(responseString.Substring(
        //                                        head + 0xC * ONE_WORD, ONE_WORD)));
        //                                    ActionStatus = Convert.ToInt16(responseString.Substring(
        //                                        head + 0x0 * ONE_WORD, ONE_WORD), 16);
        //                                    InpStatus = Convert.ToInt16(responseString.Substring(
        //                                        head + 0x01 * ONE_WORD, ONE_WORD), 16);
        //                                    TrqLmtStatus = Convert.ToInt16(responseString.Substring(
        //                                        head + 0x4 * ONE_WORD, ONE_WORD), 16);
        //                                    AlarmStatus = Convert.ToInt16(responseString.Substring(
        //                                        head + 0x5 * ONE_WORD, ONE_WORD), 16);
        //                                    ErrorStatus = Convert.ToInt16(responseString.Substring(
        //                                        head + 0xD * ONE_WORD, ONE_WORD), 16);
        //                                    MonRpm = Convert.ToInt16(responseString.Substring(
        //                                        head + 0x6 * ONE_WORD, ONE_WORD), 16);
        //                                    MonCurrent = Convert.ToInt16(responseString.Substring(
        //                                        head + 0x7 * ONE_WORD, ONE_WORD), 16) / 10.0;
        //                                    CmdNowPos = Convert.ToInt32(responseString.Substring(
        //                                        head + 0x8 * ONE_WORD, TWO_WORD), 16) / 100.0;
        //                                    EcdPos = Convert.ToInt32(responseString.Substring(
        //                                        head + 0xA * ONE_WORD, TWO_WORD), 16) / 100.0;

        //                                    aFrameIsSend = false;
        //                                    break;
        //                                case CallerId.PortOut:
        //                                    ushort portOut = Convert.ToUInt16(responseString.Substring(1 + 2 + 2 + 2, 4), 16);
        //                                    PortOut01 = (portOut & 0x0001) != 0;
        //                                    PortOut02 = (portOut & 0x0002) != 0;
        //                                    PortOut03 = (portOut & 0x0004) != 0;
        //                                    PortOut04 = (portOut & 0x0008) != 0;
        //                                    PortOut05 = (portOut & 0x0010) != 0;
        //                                    PortOut06 = (portOut & 0x0020) != 0;
        //                                    PortOut07 = (portOut & 0x0040) != 0;
        //                                    PortOut08 = (portOut & 0x0080) != 0;
        //                                    PortOut09 = (portOut & 0x0100) != 0;
        //                                    PortOut10 = (portOut & 0x0200) != 0;

        //                                    aFrameIsSend = false;
        //                                    break;
        //                                case CallerId.PortIn:
        //                                    ushort data = Convert.ToUInt16(responseString.Substring(1 + 2 + 2 + 2, 4), 16);
        //                                    PortIn01 = (data & 0x0001) != 0;
        //                                    PortIn02 = (data & 0x0002) != 0;
        //                                    PortIn03 = (data & 0x0004) != 0;
        //                                    PortIn04 = (data & 0x0008) != 0;
        //                                    PortIn05 = (data & 0x0010) != 0;
        //                                    PortIn06 = (data & 0x0020) != 0;
        //                                    PortIn07 = (data & 0x0040) != 0;
        //                                    PortIn08 = (data & 0x0080) != 0;
        //                                    PortIn09 = (data & 0x0100) != 0;
        //                                    PortIn10 = (data & 0x0200) != 0;
        //                                    PortIn11 = (data & 0x0400) != 0;
        //                                    PortIn12 = (data & 0x0800) != 0;
        //                                    PortIn13 = (data & 0x1000) != 0;
        //                                    PortIn14 = (data & 0x2000) != 0;

        //                                    aFrameIsSend = false;
        //                                    break;
        //                                case CallerId.Command:
        //                                    aFrameIsSend = false;
        //                                    break;
        //                                case CallerId.WatchDog:
        //                                    if (responseString == ":010302544363\r")
        //                                    {
        //                                        aFrameIsSend = false;
        //                                    }
        //                                    else
        //                                    {
        //                                        CloseCylinder();
        //                                        throw new Exception("電動缸斷線！");
        //                                    }
        //                                    break;
        //                                case CallerId.ErrorHistories:

        //                                    break;
        //                                case CallerId.Initializer:
        //                                    if (responseString == ":0110999B0004B7\r")
        //                                    {
        //                                        aFrameIsSend = false;
        //                                    }
        //                                    else
        //                                    {
        //                                        CloseCylinder();
        //                                        throw new Exception("權限開通異常！");
        //                                    }
        //                                    break;
        //                                default:
        //                                    throw new Exception(string.Concat("CallerId錯誤:\n", nextRequest.CallerId, "\nResponse Message: ", responseString));
        //                            }

        //                            _requestHolding = false;
        //                        }
        //                        else
        //                        {
        //                            string msg = string.Concat("CallerID: ", nextRequest.CallerId,
        //                                                       ", Frame: ", Encoding.ASCII.GetString(nextRequest.ByteArray));
        //                            if (++retryCounter <= _cp.RetryTimes)
        //                            {
        //                                _requestHolding = true;

        //                                string eMsg = string.Concat("重試第 ", retryCounter, " 次, ", msg);
        //                                Console.WriteLine(eMsg);
        //#if DEBUG
        //                                _debugMessage.ConsoleMessage = eMsg;
        //#endif

        //                                Thread.Sleep(500);
        //                                ResendFrame(nextRequest);
        //                            }
        //                            else
        //                            {
        //                                string eMsg = string.Concat("此指令已被放棄: ", msg);
        //                                Console.WriteLine(eMsg);
        //#if DEBUG
        //                                _debugMessage.ErrorMessage = eMsg;
        //#endif
        //                                retryCounter = 0;
        //                            }
        //                            aFrameIsSend = false;
        //                        }
        //                    }
        //                    /***** 接收邏輯 END *****/

        //                    token.ThrowIfCancellationRequested();

        //                    /***** 狀態讀取指令發送 START *****/
        //                    if (!_requestHolding)
        //                    {
        //                        bool isMatch = false;
        //                        switch (readStatusIntervalTimeCounter)
        //                        {
        //                            case 0:
        //                                foreach (var rq in _requestQueue)
        //                                    if (rq.CallerId == CallerId.ReadStatus)
        //                                    {
        //                                        isMatch = true;
        //                                        break;
        //                                    }
        //                                if (!isMatch)
        //                                    SendRequestFrame(CallerId.ReadStatus, 0x03, 0x1000, 0x0F);
        //                                break;
        //                            case 1:
        //                                foreach (var rq in _requestQueue)
        //                                    if (rq.CallerId == CallerId.PortOut)
        //                                    {
        //                                        isMatch = true;
        //                                        break;
        //                                    }
        //                                if (!isMatch)
        //                                    SendRequestFrame(CallerId.PortOut, 0x03, 0x1020, 1);
        //                                break;
        //                            case 2:
        //                                foreach (var rq in _requestQueue)
        //                                    if (rq.CallerId == CallerId.PortIn)
        //                                    {
        //                                        isMatch = true;
        //                                        break;
        //                                    }
        //                                if (!isMatch)
        //                                    SendRequestFrame(CallerId.PortIn, 0x03, 0x1040, 1);
        //                                break;
        //                        }

        //                        if (++readStatusIntervalTimeCounter % 100 == 0) // 降低讀取頻率
        //                            readStatusIntervalTimeCounter = 0;
        //                    }
        //                    /***** 狀態讀取指令發送 END *****/

        //                    if (++loopCounter % 1000 == 0)
        //                        ExecutionTime = DateTime.Now - StartupTime; // 程式庫運行時間
        //                }
        //                catch (OperationCanceledException)
        //                {
        //                }
        //                catch (TimeoutException te)
        //                {
        //                    if (_sp.IsOpen)
        //                        CloseCylinder();
        //                    aFrameIsSend = false;

        //                    string eMsg = string.Concat("Timeout逾時: 電動缸斷線或", te.Message);
        //                    Console.WriteLine(eMsg);
        //#if DEBUG
        //                    _debugMessage.ErrorMessage = eMsg;
        //#endif
        //                }
        //                catch (UnauthorizedAccessException uae)
        //                {
        //                    if (_sp.IsOpen)
        //                        CloseCylinder();
        //                    aFrameIsSend = false;

        //                    string eMsg = string.Concat("IO異常: ", uae.Message);
        //                    Console.WriteLine(eMsg);
        //#if DEBUG
        //                    _debugMessage.ErrorMessage = eMsg;
        //#endif
        //                }
        //                catch (InvalidOperationException ioe)
        //                {
        //                    aFrameIsSend = false;

        //                    string eMsg = string.Concat("方法呼叫失敗: ", ioe.Message);
        //                    Console.WriteLine(eMsg);
        //#if DEBUG
        //                    _debugMessage.ErrorMessage = eMsg;
        //#endif
        //                }
        //                catch (Exception ex)
        //                {
        //                    string eMsg = string.Concat("接收輪詢的執行緒異常: ", ex.Message);
        //                    Console.WriteLine(eMsg);
        //#if DEBUG
        //                    _debugMessage.ErrorMessage = eMsg;
        //#endif
        //                }
        //                finally
        //                {
        //                }
        //            }

        //_sp.DiscardInBuffer();
        //            _sp.DiscardOutBuffer();
        //            _pollingIsRunning = false;
        //        }
    }
}
