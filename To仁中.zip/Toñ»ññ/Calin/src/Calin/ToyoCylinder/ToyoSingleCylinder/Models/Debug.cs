﻿#if DEBUG

using Calin.Core;

namespace Calin.ToyoCylinder.ToyoSingleCylinder
{
    /// <summary>
    /// DEBUG 用訊息。
    /// </summary>
    public class Debug : BindableBase
    {
        public string RequestFrame
        {
            get { return _requestFrame; }
            set
            {
                if (_requestFrame != value)
                {
                    _requestFrame = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _requestFrame;

        public string ResponseFrame
        {
            get { return _responseFrame; }
            set
            {
                if (_responseFrame != value)
                {
                    _responseFrame = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _responseFrame;

        public string ConsoleMessage
        {
            get { return _consoleMessage; }
            set
            {
                if (_consoleMessage != value)
                {
                    _consoleMessage = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _consoleMessage;

        public string ErrorMessage
        {
            get { return _errorMessage; }
            set
            {
                if (_errorMessage != value)
                {
                    _errorMessage = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _errorMessage;
    }
}

#endif