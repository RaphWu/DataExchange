﻿using System.Collections.Generic;

namespace Calin.ToyoCylinder.ToyoSingleCylinder
{
    /********************
     * 公開方法與屬性。
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 電動缸是否準備好接收指令？
        /// </summary>
        /// <returns>true=準備好，false=尚未準備好。</returns>
        public bool Ready()
        {
            return _sp != null && _sp.IsOpen
                    && _servoStatus
                    && _actionStatus == 0
                    && _inpStatus == 1
                    && !_inMotion;
        }

        /// <summary>
        /// 電動缸是否開啟中？
        /// </summary>
        public bool IsOpen
        {
            get { return _sp != null && _sp.IsOpen; }
        }

        /// <summary>
        /// 電動缸是否已關閉？
        /// </summary>
        public bool IsClose
        {
            get { return !IsOpen; }
        }

        public List<string> GetErrorHistories()
        {
            return _errorHistories;
        }
    }
}
