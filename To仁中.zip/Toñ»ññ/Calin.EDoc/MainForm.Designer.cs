﻿namespace Calin.EDoc
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new Krypton.Toolkit.KryptonManager(this.components);
            this.kryptonStatusStrip = new Krypton.Toolkit.KryptonStatusStrip();
            this.kryptonPanel_FuncArea = new Krypton.Toolkit.KryptonPanel();
            this.kryptonPanel_GridViewArera = new Krypton.Toolkit.KryptonPanel();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.kryptonAdvancedDataGridView = new Krypton.Toolkit.Suite.Extended.AdvancedDataGridView.KryptonAdvancedDataGridView();
            this.toolStripMenuItem_File = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_ImportCsv = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_Exit = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel_FuncArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel_GridViewArera)).BeginInit();
            this.kryptonPanel_GridViewArera.SuspendLayout();
            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonAdvancedDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonManager
            // 
            this.kryptonManager.GlobalPaletteMode = Krypton.Toolkit.PaletteMode.Office2010Silver;
            // 
            // kryptonStatusStrip
            // 
            this.kryptonStatusStrip.Font = new System.Drawing.Font("Segoe UI", 8.999999F);
            this.kryptonStatusStrip.Location = new System.Drawing.Point(0, 616);
            this.kryptonStatusStrip.Name = "kryptonStatusStrip";
            this.kryptonStatusStrip.ProgressBars = null;
            this.kryptonStatusStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode;
            this.kryptonStatusStrip.Size = new System.Drawing.Size(1067, 22);
            this.kryptonStatusStrip.TabIndex = 0;
            this.kryptonStatusStrip.Text = "kryptonStatusStrip1";
            // 
            // kryptonPanel_FuncArea
            // 
            this.kryptonPanel_FuncArea.Dock = System.Windows.Forms.DockStyle.Top;
            this.kryptonPanel_FuncArea.Location = new System.Drawing.Point(0, 25);
            this.kryptonPanel_FuncArea.Name = "kryptonPanel_FuncArea";
            this.kryptonPanel_FuncArea.Size = new System.Drawing.Size(1067, 100);
            this.kryptonPanel_FuncArea.TabIndex = 1;
            // 
            // kryptonPanel_GridViewArera
            // 
            this.kryptonPanel_GridViewArera.Controls.Add(this.kryptonAdvancedDataGridView);
            this.kryptonPanel_GridViewArera.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel_GridViewArera.Location = new System.Drawing.Point(0, 125);
            this.kryptonPanel_GridViewArera.Name = "kryptonPanel_GridViewArera";
            this.kryptonPanel_GridViewArera.Size = new System.Drawing.Size(1067, 491);
            this.kryptonPanel_GridViewArera.TabIndex = 2;
            // 
            // menuStrip
            // 
            this.menuStrip.Font = new System.Drawing.Font("Segoe UI", 8.999999F);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_File});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1067, 25);
            this.menuStrip.TabIndex = 3;
            this.menuStrip.Text = "menuStrip";
            // 
            // kryptonAdvancedDataGridView
            // 
            this.kryptonAdvancedDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.kryptonAdvancedDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kryptonAdvancedDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonAdvancedDataGridView.FilterAndSortEnabled = true;
            this.kryptonAdvancedDataGridView.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.kryptonAdvancedDataGridView.Location = new System.Drawing.Point(0, 0);
            this.kryptonAdvancedDataGridView.Name = "kryptonAdvancedDataGridView";
            this.kryptonAdvancedDataGridView.RowTemplate.Height = 24;
            this.kryptonAdvancedDataGridView.Size = new System.Drawing.Size(1067, 491);
            this.kryptonAdvancedDataGridView.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.kryptonAdvancedDataGridView.TabIndex = 1;
            // 
            // toolStripMenuItem_File
            // 
            this.toolStripMenuItem_File.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_ImportCsv,
            this.toolStripSeparator1,
            this.toolStripMenuItem_Exit});
            this.toolStripMenuItem_File.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem_File.Name = "toolStripMenuItem_File";
            this.toolStripMenuItem_File.Size = new System.Drawing.Size(46, 21);
            this.toolStripMenuItem_File.Text = "檔案";
            // 
            // toolStripMenuItem_ImportCsv
            // 
            this.toolStripMenuItem_ImportCsv.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem_ImportCsv.Name = "toolStripMenuItem_ImportCsv";
            this.toolStripMenuItem_ImportCsv.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem_ImportCsv.Text = "匯入csv檔";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
            // 
            // toolStripMenuItem_Exit
            // 
            this.toolStripMenuItem_Exit.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.toolStripMenuItem_Exit.Name = "toolStripMenuItem_Exit";
            this.toolStripMenuItem_Exit.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem_Exit.Text = "結束程式";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 638);
            this.Controls.Add(this.kryptonPanel_GridViewArera);
            this.Controls.Add(this.kryptonPanel_FuncArea);
            this.Controls.Add(this.kryptonStatusStrip);
            this.Controls.Add(this.menuStrip);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel_FuncArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel_GridViewArera)).EndInit();
            this.kryptonPanel_GridViewArera.ResumeLayout(false);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonAdvancedDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Krypton.Toolkit.KryptonManager kryptonManager;
        private Krypton.Toolkit.KryptonStatusStrip kryptonStatusStrip;
        private Krypton.Toolkit.KryptonPanel kryptonPanel_FuncArea;
        private Krypton.Toolkit.KryptonPanel kryptonPanel_GridViewArera;
        private Krypton.Toolkit.Suite.Extended.AdvancedDataGridView.KryptonAdvancedDataGridView kryptonAdvancedDataGridView;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_File;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_ImportCsv;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Exit;
    }
}

