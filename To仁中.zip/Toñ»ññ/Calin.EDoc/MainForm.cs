﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Krypton.Toolkit;

namespace Calin.EDoc
{
    public partial class MainForm : KryptonForm
    {
        public MainForm()
        {
            InitializeComponent();

            var form = this;
            form.Text = "維護履歷管理";
        }
    }
}
