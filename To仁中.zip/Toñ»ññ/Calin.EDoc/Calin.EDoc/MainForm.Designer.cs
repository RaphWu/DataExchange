﻿namespace Calin.EDoc
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new Krypton.Toolkit.KryptonManager(this.components);
            this.mainStatusStrip = new System.Windows.Forms.StatusStrip();
            this.mainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem_File = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_New = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Open = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_Save = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_SaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_Print = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_PreviewPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Edit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Undo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Redo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_Cut = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Copy = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Paste = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_SelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Tool = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Csv = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_Custom = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Option = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Help = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Content = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Index = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_search = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem_About = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_Functions = new System.Windows.Forms.Panel();
            this.panel_GridView = new System.Windows.Forms.Panel();
            this.kadgView = new Krypton.Toolkit.Suite.Extended.AdvancedDataGridView.KryptonAdvancedDataGridView();
            this.mainMenuStrip.SuspendLayout();
            this.panel_GridView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kadgView)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonManager
            // 
            this.kryptonManager.GlobalPaletteMode = Krypton.Toolkit.PaletteMode.Office2010Silver;
            // 
            // mainStatusStrip
            // 
            this.mainStatusStrip.Location = new System.Drawing.Point(0, 541);
            this.mainStatusStrip.Name = "mainStatusStrip";
            this.mainStatusStrip.Size = new System.Drawing.Size(1071, 22);
            this.mainStatusStrip.TabIndex = 0;
            this.mainStatusStrip.Text = "statusStrip1";
            // 
            // mainMenuStrip
            // 
            this.mainMenuStrip.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.mainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_File,
            this.toolStripMenuItem_Edit,
            this.toolStripMenuItem_Tool,
            this.toolStripMenuItem_Help});
            this.mainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.mainMenuStrip.Name = "mainMenuStrip";
            this.mainMenuStrip.Size = new System.Drawing.Size(1071, 24);
            this.mainMenuStrip.TabIndex = 1;
            this.mainMenuStrip.Text = "mainMenuStrip";
            // 
            // toolStripMenuItem_File
            // 
            this.toolStripMenuItem_File.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_New,
            this.toolStripMenuItem_Open,
            this.toolStripSeparator,
            this.toolStripMenuItem_Save,
            this.toolStripMenuItem_SaveAs,
            this.toolStripSeparator1,
            this.toolStripMenuItem_Print,
            this.toolStripMenuItem_PreviewPrint,
            this.toolStripSeparator2,
            this.toolStripMenuItem_Exit});
            this.toolStripMenuItem_File.Name = "toolStripMenuItem_File";
            this.toolStripMenuItem_File.Size = new System.Drawing.Size(59, 20);
            this.toolStripMenuItem_File.Text = "檔案(&F)";
            // 
            // toolStripMenuItem_New
            // 
            this.toolStripMenuItem_New.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripMenuItem_New.Name = "toolStripMenuItem_New";
            this.toolStripMenuItem_New.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.toolStripMenuItem_New.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem_New.Text = "新增(&N)";
            // 
            // toolStripMenuItem_Open
            // 
            this.toolStripMenuItem_Open.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripMenuItem_Open.Name = "toolStripMenuItem_Open";
            this.toolStripMenuItem_Open.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.toolStripMenuItem_Open.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem_Open.Text = "開啟(&O)";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(157, 6);
            // 
            // toolStripMenuItem_Save
            // 
            this.toolStripMenuItem_Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripMenuItem_Save.Name = "toolStripMenuItem_Save";
            this.toolStripMenuItem_Save.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.toolStripMenuItem_Save.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem_Save.Text = "儲存(&S)";
            // 
            // toolStripMenuItem_SaveAs
            // 
            this.toolStripMenuItem_SaveAs.Name = "toolStripMenuItem_SaveAs";
            this.toolStripMenuItem_SaveAs.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem_SaveAs.Text = "另存新檔(&A)";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(157, 6);
            // 
            // toolStripMenuItem_Print
            // 
            this.toolStripMenuItem_Print.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripMenuItem_Print.Name = "toolStripMenuItem_Print";
            this.toolStripMenuItem_Print.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.toolStripMenuItem_Print.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem_Print.Text = "列印(&P)";
            // 
            // toolStripMenuItem_PreviewPrint
            // 
            this.toolStripMenuItem_PreviewPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripMenuItem_PreviewPrint.Name = "toolStripMenuItem_PreviewPrint";
            this.toolStripMenuItem_PreviewPrint.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem_PreviewPrint.Text = "預覽列印(&V)";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(157, 6);
            // 
            // toolStripMenuItem_Exit
            // 
            this.toolStripMenuItem_Exit.Name = "toolStripMenuItem_Exit";
            this.toolStripMenuItem_Exit.Size = new System.Drawing.Size(160, 22);
            this.toolStripMenuItem_Exit.Text = "結束(&X)";
            this.toolStripMenuItem_Exit.Click += new System.EventHandler(this.toolStripMenuItem_AppExit_Click);
            // 
            // toolStripMenuItem_Edit
            // 
            this.toolStripMenuItem_Edit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_Undo,
            this.toolStripMenuItem_Redo,
            this.toolStripSeparator3,
            this.toolStripMenuItem_Cut,
            this.toolStripMenuItem_Copy,
            this.toolStripMenuItem_Paste,
            this.toolStripSeparator4,
            this.toolStripMenuItem_SelectAll});
            this.toolStripMenuItem_Edit.Name = "toolStripMenuItem_Edit";
            this.toolStripMenuItem_Edit.Size = new System.Drawing.Size(59, 20);
            this.toolStripMenuItem_Edit.Text = "編輯(&E)";
            // 
            // toolStripMenuItem_Undo
            // 
            this.toolStripMenuItem_Undo.Name = "toolStripMenuItem_Undo";
            this.toolStripMenuItem_Undo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.toolStripMenuItem_Undo.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem_Undo.Text = "復原(&U)";
            // 
            // toolStripMenuItem_Redo
            // 
            this.toolStripMenuItem_Redo.Name = "toolStripMenuItem_Redo";
            this.toolStripMenuItem_Redo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.toolStripMenuItem_Redo.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem_Redo.Text = "取消復原(&R)";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(179, 6);
            // 
            // toolStripMenuItem_Cut
            // 
            this.toolStripMenuItem_Cut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripMenuItem_Cut.Name = "toolStripMenuItem_Cut";
            this.toolStripMenuItem_Cut.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.toolStripMenuItem_Cut.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem_Cut.Text = "剪下(&T)";
            // 
            // toolStripMenuItem_Copy
            // 
            this.toolStripMenuItem_Copy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripMenuItem_Copy.Name = "toolStripMenuItem_Copy";
            this.toolStripMenuItem_Copy.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.toolStripMenuItem_Copy.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem_Copy.Text = "複製(&C)";
            // 
            // toolStripMenuItem_Paste
            // 
            this.toolStripMenuItem_Paste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripMenuItem_Paste.Name = "toolStripMenuItem_Paste";
            this.toolStripMenuItem_Paste.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.toolStripMenuItem_Paste.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem_Paste.Text = "貼上(&P)";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(179, 6);
            // 
            // toolStripMenuItem_SelectAll
            // 
            this.toolStripMenuItem_SelectAll.Name = "toolStripMenuItem_SelectAll";
            this.toolStripMenuItem_SelectAll.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem_SelectAll.Text = "全選(&A)";
            // 
            // toolStripMenuItem_Tool
            // 
            this.toolStripMenuItem_Tool.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_Csv,
            this.toolStripSeparator6,
            this.toolStripMenuItem_Custom,
            this.toolStripMenuItem_Option});
            this.toolStripMenuItem_Tool.Name = "toolStripMenuItem_Tool";
            this.toolStripMenuItem_Tool.Size = new System.Drawing.Size(59, 20);
            this.toolStripMenuItem_Tool.Text = "工具(&T)";
            // 
            // toolStripMenuItem_Csv
            // 
            this.toolStripMenuItem_Csv.Name = "toolStripMenuItem_Csv";
            this.toolStripMenuItem_Csv.Size = new System.Drawing.Size(134, 22);
            this.toolStripMenuItem_Csv.Text = "CS&V檔讀取";
            this.toolStripMenuItem_Csv.Click += new System.EventHandler(this.toolStripMenuItem_Csv_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(131, 6);
            // 
            // toolStripMenuItem_Custom
            // 
            this.toolStripMenuItem_Custom.Name = "toolStripMenuItem_Custom";
            this.toolStripMenuItem_Custom.Size = new System.Drawing.Size(134, 22);
            this.toolStripMenuItem_Custom.Text = "自訂(&C)";
            // 
            // toolStripMenuItem_Option
            // 
            this.toolStripMenuItem_Option.Name = "toolStripMenuItem_Option";
            this.toolStripMenuItem_Option.Size = new System.Drawing.Size(134, 22);
            this.toolStripMenuItem_Option.Text = "選項(&O)";
            // 
            // toolStripMenuItem_Help
            // 
            this.toolStripMenuItem_Help.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_Content,
            this.toolStripMenuItem_Index,
            this.toolStripMenuItem_search,
            this.toolStripSeparator5,
            this.toolStripMenuItem_About});
            this.toolStripMenuItem_Help.Name = "toolStripMenuItem_Help";
            this.toolStripMenuItem_Help.Size = new System.Drawing.Size(62, 20);
            this.toolStripMenuItem_Help.Text = "說明(&H)";
            // 
            // toolStripMenuItem_Content
            // 
            this.toolStripMenuItem_Content.Name = "toolStripMenuItem_Content";
            this.toolStripMenuItem_Content.Size = new System.Drawing.Size(125, 22);
            this.toolStripMenuItem_Content.Text = "內容(&C)";
            // 
            // toolStripMenuItem_Index
            // 
            this.toolStripMenuItem_Index.Name = "toolStripMenuItem_Index";
            this.toolStripMenuItem_Index.Size = new System.Drawing.Size(125, 22);
            this.toolStripMenuItem_Index.Text = "索引(&I)";
            // 
            // toolStripMenuItem_search
            // 
            this.toolStripMenuItem_search.Name = "toolStripMenuItem_search";
            this.toolStripMenuItem_search.Size = new System.Drawing.Size(125, 22);
            this.toolStripMenuItem_search.Text = "搜尋(&S)";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(122, 6);
            // 
            // toolStripMenuItem_About
            // 
            this.toolStripMenuItem_About.Name = "toolStripMenuItem_About";
            this.toolStripMenuItem_About.Size = new System.Drawing.Size(125, 22);
            this.toolStripMenuItem_About.Text = "關於(&A)...";
            // 
            // panel_Functions
            // 
            this.panel_Functions.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Functions.Location = new System.Drawing.Point(0, 24);
            this.panel_Functions.Name = "panel_Functions";
            this.panel_Functions.Size = new System.Drawing.Size(1071, 84);
            this.panel_Functions.TabIndex = 2;
            // 
            // panel_GridView
            // 
            this.panel_GridView.Controls.Add(this.kadgView);
            this.panel_GridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_GridView.Location = new System.Drawing.Point(0, 108);
            this.panel_GridView.Name = "panel_GridView";
            this.panel_GridView.Size = new System.Drawing.Size(1071, 433);
            this.panel_GridView.TabIndex = 3;
            // 
            // kadgView
            // 
            this.kadgView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.kadgView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kadgView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kadgView.FilterAndSortEnabled = true;
            this.kadgView.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.kadgView.Location = new System.Drawing.Point(0, 0);
            this.kadgView.MultiSelect = false;
            this.kadgView.Name = "kadgView";
            this.kadgView.RowTemplate.Height = 24;
            this.kadgView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.kadgView.Size = new System.Drawing.Size(1071, 433);
            this.kadgView.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.kadgView.StateCommon.BackStyle = Krypton.Toolkit.PaletteBackStyle.GridBackgroundList;
            this.kadgView.StateCommon.DataCell.Content.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kadgView.StateCommon.HeaderColumn.Content.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kadgView.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1071, 563);
            this.Controls.Add(this.panel_GridView);
            this.Controls.Add(this.panel_Functions);
            this.Controls.Add(this.mainStatusStrip);
            this.Controls.Add(this.mainMenuStrip);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.MainMenuStrip = this.mainMenuStrip;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.mainMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.PerformLayout();
            this.panel_GridView.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kadgView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Krypton.Toolkit.KryptonManager kryptonManager;
        private System.Windows.Forms.StatusStrip mainStatusStrip;
        private System.Windows.Forms.MenuStrip mainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_File;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_New;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Open;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Save;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_SaveAs;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Print;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_PreviewPrint;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Exit;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Edit;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Undo;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Redo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Cut;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Copy;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Paste;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_SelectAll;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Tool;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Custom;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Option;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Help;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Content;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Index;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_search;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_About;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Csv;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.Panel panel_Functions;
        private System.Windows.Forms.Panel panel_GridView;
        private Krypton.Toolkit.Suite.Extended.AdvancedDataGridView.KryptonAdvancedDataGridView kadgView;
    }
}

