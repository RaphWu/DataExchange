﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Krypton.Toolkit.Suite.Extended.Data.Visualisation.ScottPlot;

namespace Calin.EDoc.Models
{
    /// <summary>
    /// 資料庫區。
    /// </summary>
    public static class MainDB
    {
        // 主表
        public static DataTable history = new DataTable();

        // 參照表
        public static DataTable allCompanyEmployees = new DataTable();
        public static DataTable maintenanceEngineers = new DataTable();
        public static DataTable maintenanceUnits = new DataTable();
        public static DataTable maintenanceTypes = new DataTable();
        public static DataTable issueCategories = new DataTable();
        public static DataTable requestingUnits = new DataTable();
        public static DataTable confirmations = new DataTable();

        // 中介表
        public static List<Historty_MaintenanceEmployee> historty_MaintenanceEmployees = new List<Historty_MaintenanceEmployee>();
        public static List<History_IssueCategory> history_IssueCategories = new List<History_IssueCategory>();

        public static void Init(DataTable dt)
        {
            dt.Columns.Add("SerNo", typeof(int));
            dt.Columns.Add("WorkOrderNo", typeof(string));
            dt.Columns.Add("Creator", typeof(string));
            dt.Columns.Add("Date", typeof(DateTime));
            dt.Columns.Add("MaintenanceUnit", typeof(int));
            //MaintenanceEmployee	維護人員
            dt.Columns.Add("MachineNo", typeof(string));
            dt.Columns.Add("AcceptedTime", typeof(DateTime));
            dt.Columns.Add("RepairStarted", typeof(DateTime));
            dt.Columns.Add("CompletedTime", typeof(DateTime));
            dt.Columns.Add("RepairDuration", typeof(TimeSpan));
            dt.Columns.Add("OutageStarted", typeof(DateTime));
            dt.Columns.Add("OutageEnded", typeof(DateTime));
            dt.Columns.Add("OutageDuration", typeof(TimeSpan));
            dt.Columns.Add("Responsible", typeof(string));
            dt.Columns.Add("Model", typeof(string));
            dt.Columns.Add("Workstation", typeof(string));
            //IssueCategory維護類型
            dt.Columns.Add("IssueDescription", typeof(string));
            dt.Columns.Add("Details", typeof(string));
            dt.Columns.Add("RequestingUnit", typeof(int));
            dt.Columns.Add("RequestingEmployee", typeof(string));
            dt.Columns.Add("RequestingUnitConfirmation", typeof(int));
            dt.Columns.Add("RequestingUnitResponse", typeof(string));
        }
    }
}
