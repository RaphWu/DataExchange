﻿using System;
using System.Collections.Generic;
using Calin.CSharp.Collection;
using System.Text;
using System.Windows.Forms;
using Calin.EDoc.Models;
using Calin.EDoc.Utility;
using Krypton.Toolkit;
using System.Data;
using System.Collections;
using System.ComponentModel;
using Krypton.Toolkit.Suite.Extended.AdvancedDataGridView;
using Krypton.Toolkit.Suite.Extended.Data.Visualisation.ScottPlot;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Linq;

namespace Calin.EDoc
{
    public partial class MainForm : KryptonForm
    {
        #region fields

        BindingSource bs = new BindingSource();

        #endregion

        public MainForm()
        {
            InitializeComponent();

            var form = this;
            form.Text = "維護履歷管理";
        }

        /********************
         * From Event
         ********************/
        private void MainForm_Load(object sender, EventArgs e)
        {

#if DEBUG
            //MainDB.maintenanceEngineers.Add(new Employee()
            //{
            //    EmployeeNo = "007271",
            //    Name = "苗天恆",
            //});
            //MainDB.maintenanceEngineers.Add(new Employee()
            //{
            //    EmployeeNo = "007484",
            //    Name = "李啟修",
            //});
            //MainDB.allCompanyEmployees = MainDB.maintenanceEngineers;

            //MainDB.issueCategories.AddRange(new List<IssueCategory>()
            //{
            //    new IssueCategory()
            //    {
            //        CategoryId=0,
            //        CategoryName="日常維護",
            //    },
            //    new IssueCategory()
            //    {
            //        CategoryId=1,
            //        CategoryName="機台保養",
            //    },
            //    new IssueCategory()
            //    {
            //        CategoryId=2,
            //        CategoryName="更換零件",
            //    },
            //    new IssueCategory()
            //    {
            //        CategoryId=3,
            //        CategoryName="機台改線",
            //    },
            //    new IssueCategory()
            //    {
            //        CategoryId=4,
            //        CategoryName="故障中待協助",
            //    },
            //    new IssueCategory()
            //    {
            //        CategoryId=5,
            //        CategoryName="異常排除",
            //    },
            //    new IssueCategory()
            //    {
            //        CategoryId=6,
            //        CategoryName="設備功能追加",
            //    },
            //    new IssueCategory()
            //    {
            //        CategoryId=7,
            //        CategoryName="機台移動",
            //    },
            //});

            //MainDB.maintenanceUnits = new List<MaintenanceUnit>()
            //{
            //    new MaintenanceUnit()
            //    {
            //         MaintenanceUnitId=0,
            //         Name="工具設計",
            //    },
            //    new MaintenanceUnit()
            //    {
            //         MaintenanceUnitId=1,
            //         Name="維護-維小",
            //    },
            //    new MaintenanceUnit()
            //    {
            //         MaintenanceUnitId=2,
            //         Name="維護-製一",
            //    },
            //};
#endif

            kadgView.FilterAndSortEnabled = true;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        private void toolStripMenuItem_AppExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripMenuItem_Csv_Click(object sender, EventArgs e)
        {
            var (isSuccess, newHistory, newHistorty_MaintenanceEmployee, newHistory_IssueCategory) = Csv.LoadCsv();
            if (isSuccess)
            {
                MainDB.history = newHistory;
                //MainDB.historty_MaintenanceEmployees = newHistorty_MaintenanceEmployee;
                //MainDB.history_IssueCategories = newHistory_IssueCategory;

                bs = new BindingSource();
                //DataTable dt = CollectionExtension.ToDataTable(MainDB.history);
                //bs.DataSource = dt;
                kadgView.DataSource = MainDB.history;
                SetDataGridView();
            }
        }


        internal void SetDataGridView()
        {
            DataGridViewColumn col;

            //kadgView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            kadgView.FilterAndSortEnabled = true;
            foreach (DataGridViewColumn column in kadgView.Columns)
            {
                column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                column.SortMode = DataGridViewColumnSortMode.Automatic;
                kadgView.SetSortEnabled(column, true);
                kadgView.SetFilterEnabled(column, true);
            }

            col = kadgView.Columns["SerNo"];
            col.HeaderText = "序號";
            kadgView.SortDescending(col);

            col = kadgView.Columns["WorkOrderNo"];
            col.HeaderText = "維護工單";

            col = kadgView.Columns["Creator"];
            col.HeaderText = "建檔人員";

            col = kadgView.Columns["Date"];
            col.HeaderText = "建檔日期";

            col = kadgView.Columns["MaintenanceUnit"];
            col.HeaderText = "維護單位";

            col = kadgView.Columns["MachineNo"];
            col.HeaderText = "機台編號";

            col = kadgView.Columns["AcceptedTime"];
            col.HeaderText = "接收時間";

            col = kadgView.Columns["RepairStarted"];
            col.HeaderText = "維修開始時間";

            col = kadgView.Columns["CompletedTime"];
            col.HeaderText = "完成時間";

            //kadgView.Columns["WorkOrderNo 
            //kadgView.Columns["Creator  
            //kadgView.Columns["Date 
            //kadgView.Columns["MaintenanceUnit  
            //kadgView.Columns["MachineNo 
            //kadgView.Columns["AcceptedTime  
            //kadgView.Columns["RepairStarted  
            //kadgView.Columns["CompletedTime  
            //kadgView.Columns["OutageStarted  
            //kadgView.Columns["OutageEnded  
            //kadgView.Columns["Responsible  
            //kadgView.Columns["Model 
            //kadgView.Columns["Workstation 
            //kadgView.Columns["IssueDescription 
            //kadgView.Columns["Details 
            //kadgView.Columns["RequestingUnit  
            //kadgView.Columns["RequestingEmployee          
            //kadgView.Columns["RequestingUnitConfirmation  
            //kadgView.Columns["RequestingUnitResponse      

            //kadgView.Columns["AcceptedTime"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm";
        }
    }
}
