﻿using System;
using System.Text;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        /********************
         * Frame 相關
         ********************/
        private byte[] GetRequestFrame(byte functionCode, int data, int length)
        {
            int dataHigh = data >> 8;
            int dataLow = data - (dataHigh << 8);
            int lenHigh = length >> 8;
            int lenLow = length - (lenHigh << 8);
            int lrc = ((_cp.Station + functionCode + dataHigh + dataLow + lenHigh + lenLow) ^ 0xFF) + 1;

            byte[] st = _cp.StationByteArray;
            byte[] fCode = Encoding.ASCII.GetBytes(functionCode.ToString("X2"));
            byte[] d = Encoding.ASCII.GetBytes(data.ToString("X4"));
            byte[] len = Encoding.ASCII.GetBytes(length.ToString("X4"));
            byte[] l = Encoding.ASCII.GetBytes(lrc.ToString("X2"));

            byte[] frame = new byte[17];
            frame[00] = 0x3A;
            frame[01] = st[0];
            frame[02] = st[1];
            frame[03] = fCode[0];
            frame[04] = fCode[1];
            frame[05] = d[0];
            frame[06] = d[1];
            frame[07] = d[2];
            frame[08] = d[3];
            frame[09] = len[0];
            frame[10] = len[1];
            frame[11] = len[2];
            frame[12] = len[3];
            frame[13] = l[0];
            frame[14] = l[1];
            frame[15] = 0x0D;
            frame[16] = 0x0A;

            return frame;
        }

        private byte[] GetRequestFrame(string requestFrame)
        {
            byte[] frame = new byte[requestFrame.Length / 2];
            for (int i = 0; i < requestFrame.Length; i += 2)
            {
                frame[i / 2] = Convert.ToByte(requestFrame.Substring(i, 2), 16);
            }
            return frame;
        }

        private bool ValidFrame(string frame)
        {
            int len = frame.Length;

            if (len <= 9) // 9 = ':' + 站號2 + 功能碼2 + LRC 2 + \r\n 2
                return false;

            if (frame.Substring(0, 1) != ":")
                return false;

            if (frame.Substring(len - 2, 1) != "\r" && frame.Substring(len - 1, 1) != "\n")
                return false;

            string lrc = frame.Substring(len - 1 - 2 - 1, 2); // 1 = ':', 2 = "\r\n", 1 = LRC首字元
            frame = frame.Substring(1, len - 1 - 2 - 2);      // 1 = ':', 2 = "\r\n", 2 = LRC
            if (AsciiLrc(frame) != Convert.ToByte(lrc, 16))
                return false;

            return true;
        }

        /********************
         * Queue 相關
         ********************/
        /// <summary>
        /// 限制 Queue 最大容量。
        /// </summary>
        private const int MAX_QUEUE_CAPACITY = 100;

        private void HighPriorityRequest(CallerId callerId, byte[] requestFrame)
        {
            if (_highPriorityQueue.Count < MAX_QUEUE_CAPACITY)
            {
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                _highPriorityQueue.Enqueue(frame);
            }
        }

        private void HighPriorityRequest(CallerId callerId, byte functionCode, int data, int length)
        {
            HighPriorityRequest(callerId, GetRequestFrame(functionCode, data, length));
        }

        private void HighPriorityRequest(CallerId callerId, string requestFrame)
        {
            HighPriorityRequest(callerId, Encoding.ASCII.GetBytes(requestFrame));
        }

        private void ResendFrame(FrameStruct frame)
        {
            if (_retryQueue.Count < MAX_QUEUE_CAPACITY)
                _retryQueue.Enqueue(frame);
        }

        private void SendRequestFrame(CallerId callerId, byte[] requestFrame)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                _requestQueue.Enqueue(frame);
            }
        }

        private void SendRequestFrame(CallerId callerId, byte functionCode, int data, int length)
        {
            SendRequestFrame(callerId, GetRequestFrame(functionCode, data, length));
        }

        private void SendRequestFrame(CallerId callerId, string requestString, bool includeLRC = false)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                StringBuilder sb = new StringBuilder(100);
                byte[] requestFrame;
                if (includeLRC)
                {
                    sb.Append(requestString).Append("\r\n");
                    //requestFrame = Encoding.ASCII.GetBytes(string.Concat(requestString, "\r\n"));
                }
                else
                {
                    int lrc = AsciiLrc(requestString);
                    sb.Append(requestString).Append(lrc.ToString("X2")).Append("\r\n");
                }
                requestFrame = Encoding.ASCII.GetBytes(sb.ToString());

                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                _requestQueue.Enqueue(frame);
            }
        }

        /********************
         * LRC
         ********************/
        private static byte Lrc(byte[] frame)
        {
            byte lrc = 0;
            for (int i = 0; i < frame.Length; i++)
                lrc += frame[i];

            return (byte)((lrc ^ 0xFF) + 1);
        }

        private static byte AsciiLrc(string frame)
        {
            byte lrc = 0;
            if (frame.Substring(0, 1) == ":")
                frame = frame.Substring(1);

            for (int i = 0; i < frame.Length; i += 2)
            {
                int t = Convert.ToInt16(frame.Substring(i, 2), 16);
                lrc += (byte)t;
            }

            return (byte)((lrc ^ 0xFF) + 1);
        }
    }
}
