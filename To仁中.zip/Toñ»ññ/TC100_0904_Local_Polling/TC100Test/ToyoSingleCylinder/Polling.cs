﻿using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        private FrameStruct _nextRequest = new FrameStruct();
        private bool _waitForRespone = false;       // Request已發送，等符接收完成
        private DateTime _timeMark = DateTime.Now;  // 時間標記
        private bool dequeueSuccess = false;        // 是否從 Queue 中取到 Request
        private bool _requestInProgress = false;    // 收到 Request，處理中
        private bool _pollingLoopFinished = true;
        private int _intervalActionCounter = 0;     // 間隔動作的計數器
        private int _retryCounter = 0;              // 指令重送計數器

        // 讀取 Port 用
        private StringBuilder _readBuffer = new StringBuilder();
        private const int BUFFER_SIZE = 1024;
        private string _receiveBuff = string.Empty;
        //private byte[] _receiveBuff = new byte[BUFFER_SIZE];
        private int _receiveLen = 0;
        private int _bytesToRead = 0;
        private bool _hasHead = false;
        private int garbageCounter = 0;

        private byte _station = 0;         // 站號
        private byte _functionCode = 0xFF; // 功能碼
        private bool isMatch;

        private void PortAccessPolling(CancellationToken token)
        {
            _pollingIsRunning = true;
            while (!_serialPortCloseRequest && !token.IsCancellationRequested)
            {
                _pollingLoopFinished = false;

                /***** 傳送邏輯 *****/
                try
                {
                    if (!_serialPortCloseRequest && !_waitForRespone)
                    {
                        if (_highPriorityQueue.Count > 0 || _retryQueue.Count > 0 || _requestQueue.Count > 0)
                        {
                            if (_highPriorityQueue.Count > 0)
                            {
                                while (_highPriorityQueue.TryDequeue(out _nextRequest))
                                {
                                    dequeueSuccess = true;
                                    break;
                                }
                            }
                            else if (_retryQueue.Count > 0)
                            {
                                while (_retryQueue.TryDequeue(out _nextRequest))
                                {
                                    dequeueSuccess = true;
                                    break;
                                }
                            }
                            else if (_requestQueue.Count > 0)
                            {
                                while (_requestQueue.TryDequeue(out _nextRequest))
                                {
                                    dequeueSuccess = true;
                                    break;
                                }
                            }
                            else
                                dequeueSuccess = false;
                        }

                        if (dequeueSuccess)
                        {
                            _timeMark = DateTime.Now;
                            dequeueSuccess = false;

                            //while (true) // 清垃圾
                            //{
                            //    buff = _sp.ReadExisting();
                            //    if (buff.Length == 0 && _sp.BytesToRead == 0)
                            //        break;
                            //    else
                            //    {
                            //        garbageCounter++;
                            //        Console.WriteLine(string.Concat("garbageCounter: ", garbageCounter.ToString()));
                            //        continue;
                            //    }
                            //}

                            /***** 傳送邏輯 *****/
                            //_sp.Write(_nextRequest.ByteArray, 0, _nextRequest.ByteArray.Length);
                            _sp.Write(_nextRequest.ByteArray, 0, _nextRequest.ByteArray.Length);
                            _waitForRespone = true;
#if DEBUG
                            _debugMessage.RequestFrame = Encoding.ASCII.GetString(_nextRequest.ByteArray);
#endif
                            Thread.Sleep(2);

                            /***** 接收邏輯 *****/
                            if (!_serialPortCloseRequest && _waitForRespone)
                            {
                                while (true)
                                {
                                    _receiveBuff = _sp.ReadExisting();
                                    _receiveLen = _receiveBuff.Length;

                                    if (_receiveLen > 0)
                                    {
                                        if (!_hasHead && _receiveBuff[0] == ':')
                                        {
                                            _readBuffer.Clear();
                                            _readBuffer.Append(_receiveBuff);
                                            _bytesToRead = _receiveLen;
                                            _hasHead = true;
                                        }
                                        else if (_hasHead)
                                        {
                                            _readBuffer.Append(_receiveBuff);
                                            _bytesToRead += _receiveLen;
                                        }

                                        if (_readBuffer.Length >= 3
                                            && _readBuffer[_bytesToRead - 2] == '\r'
                                            && _readBuffer[_bytesToRead - 1] == '\n')
                                            break;
                                    }
                                    Thread.Sleep(1);
                                }
                                _hasHead = false;
                                _responseString = _readBuffer.ToString();

#if DEBUG
                                _debugMessage.ResponseFrame = _responseString;
#endif

                                bool validation = ValidFrame(_responseString);
                                if (validation)
                                {
                                    _station = Convert.ToByte(_responseString.Substring(1, 2), 16);
                                    _functionCode = byte.Parse(_responseString.Substring(3, 2), NumberStyles.HexNumber);
                                }

                                if (validation && _station == _cp.Station && _functionCode < 0x80)
                                {
                                    if (!_requestHolding)
                                        _retryCounter = 0;

                                    const int HEAD = 7; // 7 = ':' + 站號2 + 功能碼2 + byte數2
                                    switch (_nextRequest.CallerId)
                                    {
                                        case CallerId.ReadStatus:
                                            //ServoStatus = Convert.ToBoolean(
                                            //    Convert.ToInt16(_responseString.Substring(HEAD + 0x0C * ONE_WORD, ONE_WORD)));
                                            //ActionStatus = Convert.ToInt16(
                                            //    _responseString.Substring(HEAD + 0x00 * ONE_WORD, ONE_WORD), 16);
                                            //InpStatus = Convert.ToInt16(
                                            //    _responseString.Substring(HEAD + 0x01 * ONE_WORD, ONE_WORD), 16);
                                            //TrqLmtStatus = Convert.ToInt16(
                                            //    _responseString.Substring(HEAD + 0x04 * ONE_WORD, ONE_WORD), 16);
                                            //AlarmStatus = Convert.ToInt16(
                                            //    _responseString.Substring(HEAD + 0x05 * ONE_WORD, ONE_WORD), 16);
                                            //ErrorStatus = Convert.ToInt16(
                                            //    _responseString.Substring(HEAD + 0x0D * ONE_WORD, ONE_WORD), 16);
                                            //MonRpm = Convert.ToInt16(
                                            //    _responseString.Substring(HEAD + 0x06 * ONE_WORD, ONE_WORD), 16);
                                            ////_MonSpeed = Convert.ToInt16(
                                            ////_responseString.Substring(HEAD + 0x06 * ONE_WORD, ONE_WORD), 16);
                                            //MonCurrent = Convert.ToInt16(
                                            //    _responseString.Substring(HEAD + 0x07 * ONE_WORD, ONE_WORD), 16) / 10.0;
                                            //CmdNowPos = Convert.ToInt32(
                                            //    _responseString.Substring(HEAD + 0x08 * ONE_WORD, TWO_WORD), 16) / 100.0;
                                            //EcdPos = Convert.ToInt32(
                                            //    _responseString.Substring(HEAD + 0x0A * ONE_WORD, TWO_WORD), 16) / 100.0;
                                            break;
                                        case CallerId.PortOut:
                                            //ushort portOut = Convert.ToUInt16(_responseString.Substring(HEAD, 4), 16);
                                            //_statusPortOut.PortOut01 = (portOut & 0x0001) != 0;
                                            //_statusPortOut.PortOut02 = (portOut & 0x0002) != 0;
                                            //_statusPortOut.PortOut03 = (portOut & 0x0004) != 0;
                                            //_statusPortOut.PortOut04 = (portOut & 0x0008) != 0;
                                            //_statusPortOut.PortOut05 = (portOut & 0x0010) != 0;
                                            //_statusPortOut.PortOut06 = (portOut & 0x0020) != 0;
                                            //_statusPortOut.PortOut07 = (portOut & 0x0040) != 0;
                                            //_statusPortOut.PortOut08 = (portOut & 0x0080) != 0;
                                            //_statusPortOut.PortOut09 = (portOut & 0x0100) != 0;
                                            //_statusPortOut.PortOut10 = (portOut & 0x0200) != 0;
                                            break;
                                        case CallerId.PortIn:
                                            //ushort data = Convert.ToUInt16(_responseString.Substring(HEAD, 4), 16);
                                            //_statusPortIn.PortIn01 = (data & 0x0001) != 0;
                                            //_statusPortIn.PortIn02 = (data & 0x0002) != 0;
                                            //_statusPortIn.PortIn03 = (data & 0x0004) != 0;
                                            //_statusPortIn.PortIn04 = (data & 0x0008) != 0;
                                            //_statusPortIn.PortIn05 = (data & 0x0010) != 0;
                                            //_statusPortIn.PortIn06 = (data & 0x0020) != 0;
                                            //_statusPortIn.PortIn07 = (data & 0x0040) != 0;
                                            //_statusPortIn.PortIn08 = (data & 0x0080) != 0;
                                            //_statusPortIn.PortIn09 = (data & 0x0100) != 0;
                                            //_statusPortIn.PortIn10 = (data & 0x0200) != 0;
                                            //_statusPortIn.PortIn11 = (data & 0x0400) != 0;
                                            //_statusPortIn.PortIn12 = (data & 0x0800) != 0;
                                            //_statusPortIn.PortIn13 = (data & 0x1000) != 0;
                                            //_statusPortIn.PortIn14 = (data & 0x2000) != 0;
                                            break;
                                        case CallerId.Command:
                                            break;
                                        //case CallerId.WatchDog:
                                        //    if (_responseString == ":010302544363\r\n")
                                        //    {
                                        //        requestFinished = true;
                                        //    }
                                        //    else
                                        //    {
                                        //        ClosePort();
                                        //        throw new Exception("電動缸斷線！");
                                        //    }
                                        //    break;
                                        case CallerId.ErrorHistories:

                                            break;
                                        case CallerId.Initializer:
                                            if (_responseString != ":0110999B0004B7\r\n")
                                            {
                                                ClosePort();
                                                throw new Exception("權限開通異常！");
                                            }
                                            break;
                                        default:
                                            throw new Exception(string.Concat("CallerId錯誤:\n", _nextRequest.CallerId, "\nResponse Message: ", _responseString));
                                    }

                                    _requestHolding = false;
                                }
                                else
                                {
                                    string msg = string.Concat("CallerID: ", _nextRequest.CallerId,
                                                               ", Frame: ", Encoding.ASCII.GetString(_nextRequest.ByteArray));
                                    if (++_retryCounter <= _cp.RetryTimes)
                                    {
                                        _requestHolding = true;

                                        string eMsg = string.Concat("重試第 ", _retryCounter, " 次, ", msg);
                                        Console.WriteLine(eMsg);
#if DEBUG
                                        _debugMessage.ConsoleMessage = eMsg;
#endif

                                        Thread.Sleep(500);
                                        ResendFrame(_nextRequest);
                                    }
                                    else
                                    {
                                        string eMsg = string.Concat("此指令已被放棄: ", msg);
                                        Console.WriteLine(eMsg);
#if DEBUG
                                        _debugMessage.ErrorMessage = eMsg;
#endif
                                        _retryCounter = 0;
                                    }
                                    _waitForRespone = true;
                                }
                            }
                            _waitForRespone = false;
                        }

                        // 狀態讀取
                        if (!_requestHolding && !_waitForRespone)
                        {
                            isMatch = false;
                            switch (_intervalActionCounter)
                            {
                                case 0:
                                    foreach (var rq in _requestQueue)
                                        if (rq.CallerId == CallerId.ReadStatus)
                                        {
                                            isMatch = true;
                                            break;
                                        }
                                    if (!isMatch)
                                        SendRequestFrame(CallerId.ReadStatus, 0x03, 0x1000, 0x0F);
                                    break;
                                case 1:
                                    foreach (var rq in _requestQueue)
                                        if (rq.CallerId == CallerId.PortOut)
                                        {
                                            isMatch = true;
                                            break;
                                        }
                                    if (!isMatch)
                                        SendRequestFrame(CallerId.PortOut, 0x03, 0x1020, 1);
                                    break;
                                case 2:
                                    foreach (var rq in _requestQueue)
                                        if (rq.CallerId == CallerId.PortIn)
                                        {
                                            isMatch = true;
                                            break;
                                        }
                                    if (!isMatch)
                                        SendRequestFrame(CallerId.PortIn, 0x03, 0x1040, 1);
                                    break;
                            }

                            if (++_intervalActionCounter > 50)
                            {
                                _intervalActionCounter = 0;
                                ExceuteTime = DateTime.Now - _startRunningTime;
                            }
                        }
                    }

                    // 檢查是否斷線/空轉
                    if (dequeueSuccess && _sp.BytesToRead == 0)
                    {
                        TimeSpan ts = DateTime.Now - _timeMark;
                        if (ts.TotalMilliseconds > 3000)
                            throw new TimeoutException("接收逾時！");
                    }

                    //Task.Delay(1, token).Wait();
                    Thread.Sleep(3);
                }
                catch (OperationCanceledException)
                {
                    // do nothing for CancellationTokenSource
                }
                catch (TimeoutException te)
                {
#if DEBUG
                    _debugMessage.ErrorMessage = string.Concat("Timeout逾時: 電動缸斷線或", te.Message);
#endif
                    _waitForRespone = true;
                    ClosePort();
                }
                catch (UnauthorizedAccessException uae)
                {
                    string eMsg = string.Concat("Port 異常或被其他程式佔用: ", uae.Message);
                    Console.WriteLine(eMsg);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
#endif
                    ClosePort();
                    _waitForRespone = true;
                }
                catch (IOException ie)
                {
                    string eMsg = string.Concat("Port 突然被拔除或中斷: ", ie.Message);
                    Console.WriteLine(eMsg);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
#endif
                    ClosePort();
                    _waitForRespone = true;
                }
                catch (InvalidOperationException ioe)
                {
                    Console.WriteLine(ioe.Message);
                    _waitForRespone = true;
                }
                catch (Exception ex)
                {
                    string eMsg = string.Concat("接收輪詢的執行緒異常: ", ex.Message);
                    Console.WriteLine(eMsg);
#if DEBUG
                    _debugMessage.ErrorMessage = eMsg;
#endif
                }
                finally
                {
                    _pollingLoopFinished = true;
                }
            }

            _sp.DiscardInBuffer();
            _sp.DiscardOutBuffer();
            _pollingIsRunning = false;
            _serialPortCloseRequest = false;
        }
    }
}
