﻿using System.Collections.Generic;
using Autofac;
using Sunny.UI;

namespace Calin.TaskPulse
{
    public class PageManager
    {
        private readonly ILifetimeScope _rootScope;
        private readonly UIForm _form;
        private readonly Dictionary<int, (UIPage Page, ILifetimeScope Scope)> _pages = new Dictionary<int, (UIPage Page, ILifetimeScope Scope)>();

        public PageManager(ILifetimeScope rootScope, UIForm form)
        {
            _rootScope = rootScope;
            _form = form;
        }

        public void AddOrReplacePage<TPage>(int pageIndex) where TPage : UIPage
        {
            // 移除舊頁面（如果有的話）
            if (_pages.TryGetValue(pageIndex, out var existing))
            {
                _form.RemovePage(pageIndex);
                existing.Scope.Dispose();
                _pages.Remove(pageIndex);
            }

            var scope = _rootScope.BeginLifetimeScope();
            var page = scope.Resolve<TPage>();
            page.PageIndex = pageIndex;
            page.Tag = pageIndex;
            _form.AddPage(page, pageIndex);
            _pages[pageIndex] = (page, scope);
        }

        public void RemovePage(int pageIndex)
        {
            if (_pages.TryGetValue(pageIndex, out var entry))
            {
                _form.RemovePage(pageIndex);     // 移除 UI
                entry.Scope.Dispose();           // 釋放資源
                _pages.Remove(pageIndex);
            }
        }

        public void DisposeAll()
        {
            foreach (var (page, scope) in _pages.Values)
                scope.Dispose();
            _pages.Clear();
        }
    }
}
