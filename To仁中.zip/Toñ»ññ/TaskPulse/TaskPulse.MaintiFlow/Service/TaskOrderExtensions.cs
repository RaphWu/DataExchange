﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.MaintiFlow.Models;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public static class TaskOrderExtensions
    {
        public static async Task LoadCoreDataAsync(this List<TaskOrder> taskOrders, CoreContext coreContext)
        {
            if (taskOrders == null || taskOrders.Count == 0) return;

            // --- Machine ---
            var machineIds = taskOrders.Select(t => t.MachineId).Distinct().ToList();
            var machines = await coreContext.Machines
                                            .Where(m => machineIds.Contains(m.Id))
                                            .ToDictionaryAsync(m => m.Id);

            // --- Workstation ---
            var workstationIds = taskOrders.Select(t => t.WorkstationId).Distinct().ToList();
            var workstations = await coreContext.Workstations
                                                .Where(w => workstationIds.Contains(w.WorkstationId))
                                                .ToDictionaryAsync(w => w.WorkstationId);

            // --- CreatedBy (Employee) ---
            var employeeIds = taskOrders.Select(t => t.CreatedById).Distinct().ToList();
            var employees = await coreContext.Employees
                                             .Where(e => employeeIds.Contains(e.Id))
                                             .ToDictionaryAsync(e => e.Id);

            // --- Engineers (多對多) ---
            var workOrderNos = taskOrders.Select(t => t.WorkOrderNo).ToList();
            var taskOrderEngineers = await coreContext.TaskOrderEngineers
                                                      .Where(te => workOrderNos.Contains(te.WorkOrderNo))
                                                      .ToListAsync();

            var engineerIds = taskOrderEngineers.Select(te => te.EmployeeId).Distinct().ToList();
            var engineerDict = await coreContext.Employees
                                                .Where(e => engineerIds.Contains(e.Id))
                                                .ToDictionaryAsync(e => e.EmployeeId);

            var taskDict = taskOrders.ToDictionary(t => t.WorkOrderNo);

            foreach (var te in taskOrderEngineers)
            {
                if (taskDict.TryGetValue(te.WorkOrderNo, out var task))
                {
                    if (task.Engineers == null) task.Engineers = new List<Employee>();
                    if (engineerDict.TryGetValue(te.WorkOrderNo, out var emp))
                        task.Engineers.Add(emp);
                }
            }

            // --- 指派 Machine, Workstation, CreatedBy ---
            foreach (var task in taskOrders)
            {
                machines.TryGetValue(task.MachineId, out var m);
                task.Machine = m;

                workstations.TryGetValue(task.WorkstationId, out var w);
                task.Workstation = w;

                employees.TryGetValue(task.CreatedById, out var emp);
                task.CreatedBy = emp;
            }
        }
    }
}