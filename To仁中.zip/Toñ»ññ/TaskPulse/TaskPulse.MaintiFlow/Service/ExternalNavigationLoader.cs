﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    /// <summary>
    /// 載入外部關聯資料的擴充方法。<br/>針對設定為 [NotMapped] 的導航屬性進行批次載入。
    /// </summary>
    public static class ExternalNavigationLoader
    {
        /// <summary>
        /// 載入外部 Context 的導航屬性，支援多對一/一對一與多對多。
        /// </summary>
        /// <remarks>taskOrders.LoadAllExternal(_coreContext);</remarks>
        public static void LoadAllExternal<T>(
            this IEnumerable<T> entities,
            DbContext externalContext) where T : class
        {
            var entityList = entities.ToList();
            if (!entityList.Any()) return;

            var entityType = typeof(T);

            // 找所有導航屬性
            var navProps = entityType.GetProperties()
                .Where(p => p.GetGetMethod().IsVirtual)
                .ToList();
            if (!navProps.Any()) return;

            // 找主鍵
            var entityKeyProp = entityType.GetProperties().FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);
            if (entityKeyProp == null)
                throw new InvalidOperationException($"Entity {entityType.Name} has no [Key] property.");

            foreach (var navProp in navProps)
            {
                var propType = navProp.PropertyType;

                // 多對多 ICollection<T>
                if (propType.IsGenericType && typeof(IEnumerable<>).IsAssignableFrom(propType.GetGenericTypeDefinition()) == false)
                {
                    var itemType = propType.GetGenericArguments()[0];
                    var dbSetProp = externalContext.GetType().GetProperties()
                        .FirstOrDefault(p => p.PropertyType.IsGenericType && p.PropertyType.GetGenericArguments()[0] == itemType);
                    if (dbSetProp == null) continue;

                    dynamic dbSet = dbSetProp.GetValue(externalContext);

                    // 嘗試自動找 join table 名稱
                    string joinTableName = entityType.Name + itemType.Name + "s"; // e.g., TaskOrderEngineer
                    try
                    {
                        var joinTable = externalContext.Database.SqlQuery<dynamic>($"SELECT * FROM {joinTableName}").ToList();

                        var map = joinTable.GroupBy(j => j[entityKeyProp.Name])
                                            .ToDictionary(
                                                g => g.Key,
                                                g => g.Select(x => x[itemType.Name + "Id"]).ToList()
                                            );

                        foreach (var entity in entityList)
                        {
                            var entityId = entityKeyProp.GetValue(entity);
                            if (entityId == null || !map.TryGetValue(entityId, out var ids)) continue;

                            var collection = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(itemType));
                            foreach (var id in ids)
                            {
                                foreach (var d in (IEnumerable)dbSet)
                                {
                                    var keyProp = d.GetType().GetProperties()
                                        .FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);
                                    if (keyProp == null) continue;

                                    var keyValue = keyProp.GetValue(d);
                                    if (keyValue != null && keyValue.Equals(id))
                                    {
                                        collection.Add(d);
                                        break;
                                    }
                                }
                            }
                            navProp.SetValue(entity, collection);
                        }
                    }
                    catch { continue; } // join table 不存在則跳過

                    continue;
                }

                // 多對一 / 一對一
                var fkNameCandidates = new[] { navProp.Name + "Id", navProp.Name + "ID" };
                PropertyInfo fkProp = null;
                foreach (var candidate in fkNameCandidates)
                {
                    fkProp = entityType.GetProperty(candidate);
                    if (fkProp != null) break;
                }
                if (fkProp == null) continue;

                var navType = navProp.PropertyType;
                var dbSetSingleProp = externalContext.GetType().GetProperties()
                    .FirstOrDefault(p => p.PropertyType.IsGenericType && p.PropertyType.GetGenericArguments()[0] == navType);
                if (dbSetSingleProp == null) continue;

                dynamic dbSetObj = dbSetSingleProp.GetValue(externalContext);
                var fkValues = entityList.Select(e => fkProp.GetValue(e)).Where(v => v != null).Distinct().ToList();

                var navKeyProp = navType.GetProperties().FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);
                if (navKeyProp == null) continue;

                var navData = new Dictionary<object, object>();
                foreach (var d in (IEnumerable)dbSetObj)
                {
                    var key = navKeyProp.GetValue(d);
                    if (key != null && !navData.ContainsKey(key))
                        navData.Add(key, d);
                }

                foreach (var entity in entityList)
                {
                    var fkValue = fkProp.GetValue(entity);
                    if (fkValue != null && navData.TryGetValue(fkValue, out var nav))
                        navProp.SetValue(entity, nav);
                }
            }
        }

        /// <summary>
        /// 遞迴載入外部 Context 的導航屬性，支援多層、多對一、一對一、多對多。
        /// </summary>
        /// <remarks>taskOrders.LoadAllExternalRecursive(_coreContext, maxDepth: 5);</remarks>
        public static void LoadAllExternalRecursive<T>(
            this IEnumerable<T> entities,
            DbContext externalContext,
            int maxDepth = 5) where T : class
        {
            LoadLevel(entities.ToList(), externalContext, 0, maxDepth, new HashSet<object>());
        }

        private static void LoadLevel(
            IList entities,
            DbContext externalContext,
            int depth,
            int maxDepth,
            HashSet<object> visited)
        {
            if (entities.Count == 0 || depth >= maxDepth) return;

            var entityType = entities[0].GetType();
            var entityKeyProp = entityType.GetProperties().FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);
            if (entityKeyProp == null) return;

            var navProps = entityType.GetProperties()
                .Where(p => p.GetGetMethod().IsVirtual)
                .ToList();

            foreach (var navProp in navProps)
            {
                var propType = navProp.PropertyType;

                // 多對多 ICollection<T>
                if (propType.IsGenericType && typeof(IEnumerable<>).IsAssignableFrom(propType.GetGenericTypeDefinition()) == false)
                {
                    var itemType = propType.GetGenericArguments()[0];
                    var dbSetProp = externalContext.GetType().GetProperties()
                        .FirstOrDefault(p => p.PropertyType.IsGenericType && p.PropertyType.GetGenericArguments()[0] == itemType);
                    if (dbSetProp == null) continue;

                    dynamic dbSet = dbSetProp.GetValue(externalContext);
                    string joinTableName = entityType.Name + itemType.Name + "s";

                    try
                    {
                        var joinTable = externalContext.Database.SqlQuery<dynamic>($"SELECT * FROM {joinTableName}").ToList();
                        var map = joinTable.GroupBy(j => j[entityKeyProp.Name])
                                           .ToDictionary(g => g.Key, g => g.Select(x => x[itemType.Name + "Id"]).ToList());

                        foreach (var entity in entities)
                        {
                            var entityId = entityKeyProp.GetValue(entity);
                            if (entityId == null || !map.TryGetValue(entityId, out var ids)) continue;

                            var collection = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(itemType));
                            foreach (var id in ids)
                            {
                                foreach (var d in (IEnumerable)dbSet)
                                {
                                    var keyProp = d.GetType().GetProperties().FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);
                                    if (keyProp == null) continue;

                                    var keyValue = keyProp.GetValue(d);
                                    if (keyValue != null && keyValue.Equals(id))
                                    {
                                        collection.Add(d);
                                        break;
                                    }
                                }
                            }
                            navProp.SetValue(entity, collection);

                            // 遞迴載入下一層
                            LoadLevel(collection, externalContext, depth + 1, maxDepth, visited);
                        }
                    }
                    catch { continue; }

                    continue;
                }

                // 多對一 / 一對一
                var fkNameCandidates = new[] { navProp.Name + "Id", navProp.Name + "ID" };
                PropertyInfo fkProp = null;
                foreach (var candidate in fkNameCandidates)
                {
                    fkProp = entityType.GetProperty(candidate);
                    if (fkProp != null) break;
                }
                if (fkProp == null) continue;

                var navType = navProp.PropertyType;
                var dbSetSingleProp = externalContext.GetType().GetProperties()
                    .FirstOrDefault(p => p.PropertyType.IsGenericType && p.PropertyType.GetGenericArguments()[0] == navType);
                if (dbSetSingleProp == null) continue;

                dynamic dbSetObj = dbSetSingleProp.GetValue(externalContext);
                var fkValues = entities.Cast<object>().Select(e => fkProp.GetValue(e)).Where(v => v != null).Distinct().ToList();

                var navKeyProp = navType.GetProperties().FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);
                if (navKeyProp == null) continue;

                var navData = new Dictionary<object, object>();
                foreach (var d in (IEnumerable)dbSetObj)
                {
                    var key = navKeyProp.GetValue(d);
                    if (key != null && !navData.ContainsKey(key))
                        navData.Add(key, d);
                }

                foreach (var entity in entities)
                {
                    var fkValue = fkProp.GetValue(entity);
                    if (fkValue != null && navData.TryGetValue(fkValue, out var nav))
                    {
                        navProp.SetValue(entity, nav);

                        // 遞迴下一層，避免循環
                        if (!visited.Contains(nav))
                        {
                            visited.Add(nav);
                            LoadLevel(new List<object> { nav }, externalContext, depth + 1, maxDepth, visited);
                        }
                    }
                }
            }
        }

        //public static void LoadAllExternal<T>(
        //    this IEnumerable<T> entities,
        //    DbContext externalContext,
        //    Dictionary<string, string> joinTableMap = null) where T : class
        //{
        //    var entityList = entities.ToList();
        //    if (!entityList.Any()) return;

        //    var entityType = typeof(T);

        //    var navProps = entityType.GetProperties()
        //        .Where(p => p.GetGetMethod().IsVirtual && p.GetCustomAttribute<NotMappedAttribute>() != null)
        //        .ToList();
        //    if (!navProps.Any()) return;

        //    // 找主鍵屬性
        //    var entityKeyProp = entityType.GetProperties().FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);

        //    foreach (var navProp in navProps)
        //    {
        //        var propType = navProp.PropertyType;

        //        // 多對多 ICollection<T>
        //        if (propType.IsGenericType && typeof(IEnumerable<>).IsAssignableFrom(propType.GetGenericTypeDefinition()))
        //        {
        //            var itemType = propType.GetGenericArguments()[0];
        //            var dbSetProp = externalContext.GetType().GetProperties()
        //                .FirstOrDefault(p => p.PropertyType.IsGenericType && p.PropertyType.GetGenericArguments()[0] == itemType);
        //            if (dbSetProp == null) continue;

        //            dynamic dbSet = dbSetProp.GetValue(externalContext);

        //            string key = entityType.Name + navProp.Name;
        //            string joinTableName = joinTableMap != null && joinTableMap.TryGetValue(key, out var jtName)
        //                ? jtName
        //                : entityType.Name + itemType.Name;

        //            var joinTable = externalContext.Database.SqlQuery<dynamic>($"SELECT * FROM {joinTableName}").ToList();

        //            var map = joinTable.GroupBy(j => j[entityKeyProp.Name])
        //                                .ToDictionary(g => g.Key, g => g.Select(x => x[itemType.Name + "Id"]).ToList());

        //            foreach (var entity in entityList)
        //            {
        //                var entityId = entityKeyProp.GetValue(entity);
        //                if (entityId != null && map.TryGetValue(entityId, out var ids))
        //                {
        //                    var collection = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(itemType));
        //                    foreach (var id in ids)
        //                    {
        //                        object nav = null;
        //                        foreach (var d in dbSet) // dbSet 是 dynamic DbSet
        //                        {
        //                            PropertyInfo pkProp = null;
        //                            var props = d.GetType().GetProperties();
        //                            for (int i = 0; i < props.Length; i++)
        //                            {
        //                                var attr = props[i].GetCustomAttributes(typeof(KeyAttribute), true);
        //                                if (attr != null && attr.Length > 0)
        //                                {
        //                                    pkProp = props[i];
        //                                    break;
        //                                }
        //                            }
        //                            if (pkProp == null) continue;

        //                            var pkValue = pkProp.GetValue(d);
        //                            if (pkValue != null && pkValue.Equals(id))
        //                            {
        //                                nav = d;
        //                                break;
        //                            }
        //                        }
        //                        if (nav != null) collection.Add(nav);
        //                    }
        //                    navProp.SetValue(entity, collection);
        //                }
        //            }

        //            continue;
        //        }

        //        // 單對一或多對一
        //        string fkName = navProp.Name + "Id";
        //        var fkProp = entityType.GetProperty(fkName);
        //        if (fkProp == null) continue;

        //        var navType = navProp.PropertyType;
        //        var dbSetSingleProp = externalContext.GetType().GetProperties()
        //            .FirstOrDefault(p => p.PropertyType.IsGenericType && p.PropertyType.GetGenericArguments()[0] == navType);
        //        if (dbSetSingleProp == null) continue;

        //        dynamic dbSetObj = dbSetSingleProp.GetValue(externalContext);

        //        var fkValues = entityList.Select(e => fkProp.GetValue(e)).Distinct().ToList();

        //        // 找導航屬性主鍵
        //        var navKeyProp = navType.GetProperties().FirstOrDefault(p => p.GetCustomAttribute<KeyAttribute>() != null);
        //        var navData = new Dictionary<object, object>();
        //        foreach (var d in (IEnumerable)dbSetObj)
        //        {
        //            var key = navKeyProp.GetValue(d);
        //            if (key != null && !navData.ContainsKey(key))
        //                navData.Add(key, d);
        //        }

        //        foreach (var entity in entityList)
        //        {
        //            var fkValue = fkProp.GetValue(entity);
        //            if (fkValue != null && navData.TryGetValue(fkValue, out var nav))
        //                navProp.SetValue(entity, nav);
        //        }
        //    }
        //}
    }
}
