﻿//using System.Collections.Generic;
//using System.ComponentModel;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace Calin.TaskPulse.MaintiFlow.Models
//{
//    /// <summary>
//    /// 機台編號。
//    /// </summary>
//    public class Machines
//    {
//        /// <summary>
//        /// 機台編號。
//        /// </summary>
//        [Description("機台編號")]
//        [Key]
//        [DatabaseGenerated(DatabaseGeneratedOption.None)]
//        public string MachineId { get; set; }

//        /// <summary>
//        /// 機台名稱。
//        /// </summary>
//        [Description("機台名稱")]
//        public string MachineName { get; set; }

//        public virtual ICollection<TaskOrder> TaskOrders { get; set; }
//    }
//}
