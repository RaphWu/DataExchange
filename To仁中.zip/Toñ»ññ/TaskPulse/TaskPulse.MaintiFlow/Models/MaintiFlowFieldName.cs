﻿namespace Calin.TaskPulse.MaintiFlow.Models
{
    public class MaintiFlowFieldName
    {
        public string WorkOrderNo { get; set; }
        public string OrderNo { get; set; }
        public string CreatedBy { get; set; }
        public string CreationDate { get; set; }
        public string Status { get; set; }
        public string MaintenanceUnit { get; set; }
        public string MaintenanceEngineers { get; set; }
        public string Machine { get; set; }
        public string AcceptedTime { get; set; }
        public string RepairStarted { get; set; }
        public string RepairCompleted { get; set; }
        public string RepairDuration { get; set; }
        public string OutageStarted { get; set; }
        public string OutageEnded { get; set; }
        public string OutageDuration { get; set; }
        public string Responsible { get; set; }
        public string Model { get; set; }
        public string Workstation { get; set; }
        public string IssueCategory { get; set; }
        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public string RequestingUnit { get; set; }
        public string RequestingEmployee { get; set; }
        public string RequestingUnitResponse { get; set; }
    }
}
