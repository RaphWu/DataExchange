﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using Calin.TaskPulse.Core.Models;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// Code First 初始化類別。
    /// </summary>
    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
    public class MaintiFlowInitializer : SqliteDropCreateDatabaseAlways<MaintiFlowContext>
    {
        private readonly CoreContext _coreContext;

        public MaintiFlowInitializer(DbModelBuilder modelBuilder, CoreContext coreContext) : base(modelBuilder)
        {
            _coreContext = coreContext;
        }

        protected override void Seed(MaintiFlowContext context)
        {
            var st = context.Set<Status>();
            st.Add(new Status() { StatusId = 1, OrderNo = 1, StatusName = "待處理" });
            st.Add(new Status() { StatusId = 2, OrderNo = 2, StatusName = "處理中" });
            st.Add(new Status() { StatusId = 3, OrderNo = 3, StatusName = "完成" });

            var mu = context.Set<MaintenanceUnit>();
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 1, OrderNo = 1, Name = "工具設計" });
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 2, OrderNo = 2, Name = "維護-維小" });
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 3, OrderNo = 3, Name = "維護-製一" });

            var ic = context.Set<IssueCategory>();
            ic.Add(new IssueCategory() { CategoryId = 1, OrderNo = 1, CategoryName = "日常維護" });
            ic.Add(new IssueCategory() { CategoryId = 2, OrderNo = 2, CategoryName = "機台保養" });
            ic.Add(new IssueCategory() { CategoryId = 3, OrderNo = 3, CategoryName = "更換零件" });
            ic.Add(new IssueCategory() { CategoryId = 4, OrderNo = 4, CategoryName = "機台改線" });
            ic.Add(new IssueCategory() { CategoryId = 5, OrderNo = 5, CategoryName = "故障中待協助" });
            ic.Add(new IssueCategory() { CategoryId = 6, OrderNo = 6, CategoryName = "異常排除" });
            ic.Add(new IssueCategory() { CategoryId = 7, OrderNo = 7, CategoryName = "機台功能追加" });
            ic.Add(new IssueCategory() { CategoryId = 8, OrderNo = 8, CategoryName = "機台移動" });

            var ru = context.Set<RequestingUnit>();
            ru.Add(new RequestingUnit() { RequestingUnitId = 1, OrderNo = 1, Name = "組立" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 2, OrderNo = 2, Name = "製技" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 3, OrderNo = 3, Name = "RD" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 4, OrderNo = 4, Name = "試作" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 5, OrderNo = 5, Name = "試作開發" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 6, OrderNo = 6, Name = "品管" });

            var empList = _coreContext.Set<Core.Models.Employee>().ToList();
            var employees = context.Set<Employee>();
            foreach (var e in empList)
            {
                employees.Add(new Employee()
                {
                    EmployeeId = e.EmployeeId,
                    Department = e.Department,
                    Title = e.Title,
                    Name = e.Name,
                    IsEngineer = e.IsEngineer,
                });
            }

            var deviceList = _coreContext.Set<Core.Models.Machine>()
                .Include(d => d.MachineName.Type)
                .ToList();
            var device = context.Set<Machine>();
            foreach (var m in deviceList)
            {
                device.Add(new Machine()
                {
                    MachineId = m.MachineId,
                    MachineName = m.MachineName.FullName,
                });
            }

            var modelList = _coreContext.Set<Core.Models.Model>().ToList();
            var model = context.Set<Model>();
            foreach (var m in modelList)
            {
                model.Add(new Model()
                {
                    ModelName = m.ModelName,
                });
            }

            context.SaveChanges();

            try
            {
                int recCount = 0;
                using (var sr = new StreamReader("設備維修履歷_Import.txt", Encoding.Default))
                {
                    string[] sList;
                    
                    var tos = context.Set<TaskOrder>();
                    var mo = context.Set<Model>();
                    //var mu = context.Set<MaintenanceUnit>();
                    //var ic = context.Set<IssueCategory>();
                    //var ru = context.Set<RequestingUnit>();

                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var to = new TaskOrder();
                            string workOrderNo = data[1].Trim();

                            to.OrderNo = int.Parse(data[0]);
                            to.WorkOrderNo = workOrderNo;

                            string empName = data[2].Trim();
                            to.Creator = employees.FirstOrDefault(x => x.Name == empName);
                            to.CreatorId = (to.Creator != null) ? to.Creator.EmployeeId : string.Empty;

                            to.CreationDate = DateTime.Parse(data[3]);

                            string muName = data[4].Trim();
                            to.MaintenanceUnit = mu.FirstOrDefault(x => x.Name == muName);

                            sList = data[5].Split('/');
                            to.MaintenanceEngineers = new List<TaskOrderEngineer>();
                            foreach (var d5 in sList)
                            {
                                var e = employees.FirstOrDefault(x => x.Name == d5 && x.IsEngineer);
                                if (e != null)
                                    to.MaintenanceEngineers.Add(new TaskOrderEngineer()
                                    {
                                        WorkOrderNo = workOrderNo,
                                        EmployeeId = e.EmployeeId,
                                        //Engineer = m,
                                    });
                            }

                            // NewWorkOrderNo[6] 可能為「機台名稱_機台名稱_...」
                            var d6 = data[6].Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries)
                                            .Select(x => x.Trim())
                                            .Where(x => !string.IsNullOrWhiteSpace(x))
                                            .Distinct()
                                            .ToList();
                            to.TaskOrderMachines = new List<TaskOrderMachine>();
                            foreach (var d_6 in d6)
                            {
                                var mch = deviceList.FirstOrDefault(x => x.MachineId == d_6);
                                if (mch != null)
                                    to.TaskOrderMachines.Add(new TaskOrderMachine
                                    {
                                        WorkOrderNo = workOrderNo,
                                        MachineId = mch.MachineId,
                                    });
                            }

                            to.AcceptedTime = DateTime.Parse(string.Concat(data[3], " ", data[7]));

                            if (DateTime.TryParse(string.Concat(data[3], " ", data[8]), out DateTime rs))
                                to.RepairStarted = rs;
                            else
                                to.RepairStarted = null;

                            if (DateTime.TryParse(string.Concat(data[3], " ", data[9]), out DateTime rc))
                                to.RepairCompleted = rc;
                            else
                                to.RepairCompleted = null;

                            if (int.TryParse(data[10], out int rd))
                                to.RepairDuration = TimeSpan.FromMinutes(rd);
                            else
                            {
                                if (rs == null || rc == null)
                                    to.RepairDuration = TimeSpan.Zero;
                                else
                                    to.RepairDuration = rc - rs;
                            }

                            if (DateTime.TryParse(string.Concat(data[3], " ", data[11]), out DateTime os))
                                to.OutageStarted = os;
                            else
                                to.OutageStarted = null;

                            if (DateTime.TryParse(string.Concat(data[3], " ", data[12]), out DateTime oe))
                                to.OutageEnded = oe;
                            else
                                to.OutageEnded = null;

                            if (int.TryParse(data[13], out int od))
                                to.OutageDuration = TimeSpan.FromMinutes(od);
                            else
                            {
                                if (rs == null || rc == null)
                                    to.OutageDuration = TimeSpan.Zero;
                                else
                                    to.OutageDuration = oe - os;
                            }

                            if (!string.IsNullOrWhiteSpace(data[15]))
                            {
                                string name = data[15].Trim();
                                to.Model = mo.FirstOrDefault(x => x.ModelName == name);
                                if (to.Model == null)
                                {
                                    var newModel = new Model() { ModelName = name };
                                    mo.Add(newModel);
                                    context.SaveChanges();
                                    //to.Model = newModel;
                                    //to.Model = newModel.Model;
                                }
                            }

                            to.Workstation = data[16].Trim();

                            if (!string.IsNullOrWhiteSpace(data[17]))
                            {
                                string name = data[17].Trim();
                                to.IssueCategory = ic.FirstOrDefault(x => x.CategoryName == name);
                            }
                            else
                            {
                                to.IssueCategory = null;
                            }

                            to.IssueDescription = data[18].Trim();
                            to.Details = data[19].Trim();

                            if (!string.IsNullOrWhiteSpace(data[20]))
                            {
                                string name = data[20].Trim();
                                to.RequestingUnit = ru.FirstOrDefault(x => x.Name == name);
                            }
                            else
                            {
                                to.RequestingUnit = null;
                            }

                            if (!string.IsNullOrWhiteSpace(data[21]))
                            {
                                string name = data[21].Trim();
                                to.RequestingEmployee = employees.FirstOrDefault(x => x.Name == name);
                            }
                            else
                            {
                                to.RequestingEmployee = null;
                            }

                            if (!string.IsNullOrWhiteSpace(data[22]))
                            {
                                string name = data[22].Trim();
                                to.Status = st.FirstOrDefault(x => x.StatusName == name);
                            }
                            if (to.Status == null)
                                to.Status = st.FirstOrDefault(x => x.StatusName == "待處理");

                            to.RequestingUnitResponse = data[23].Trim();

                            tos.Add(to);
                        }
                    }
                    context.SaveChanges();
                }
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    Console.WriteLine($"Entity of type '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                    }
                }

                throw;
            }
            catch (Exception ex)
            {
                // 檢查 inner exception 是否為 DbEntityValidationException
                var validationException = ex as DbEntityValidationException
                    ?? ex.InnerException as DbEntityValidationException;

                if (validationException != null)
                {
                    foreach (var validationErrors in validationException.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            Console.WriteLine("❌ Entity: " + validationErrors.Entry.Entity.GetType().Name);
                            Console.WriteLine("   Property: " + validationError.PropertyName);
                            Console.WriteLine("   Error: " + validationError.ErrorMessage);
                        }
                    }
                }
                else
                {
                    // 其他例外狀況
                    Console.WriteLine("🔴 一般例外：");
                    Console.WriteLine(ex.ToString());
                }

                throw;
            }

            base.Seed(context);
        }
    }
}
