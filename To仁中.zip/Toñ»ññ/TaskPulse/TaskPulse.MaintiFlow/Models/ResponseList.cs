﻿//using System.Collections.Generic;
//using System.ComponentModel;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace Calin.TaskPulse.MaintiFlow.Models
//{
//    /// <summary>
//    /// 需求單位回覆內容。
//    /// </summary>
//    public class ResponseList
//    {
//        [Key]
//        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
//        public int Id { get; set; }

//        /// <summary>
//        /// 回覆內容。
//        /// </summary>
//        [Description("回覆內容")]
//        [MaxLength(10)]
//        public string Response { get; set; }

//        public virtual ICollection<TaskOrder> TaskOrders { get; set; }
//    }
//}
