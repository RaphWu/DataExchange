﻿using System.Data.Entity;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 資料庫區。
    /// </summary>
    public class MaintiFlowContext : DbContext
    {
        private readonly CoreContext _coreContext;

        public MaintiFlowContext(CoreContext coreContext) : base("name=MaintiFlowContext")
        {
            _coreContext = coreContext;

            //if (System.IO.File.Exists("MaintiFlowDB.db"))
            //    System.IO.File.Delete("MaintiFlowDB.db");

            //Database.SetInitializer(new CreateDatabaseIfNotExists<MaintiFlowContext>());
            //Database.SetInitializer(new DropCreateDatabaseAlways<MaintiFlowContext>());
            //Database.SetInitializer<MaintiFlowContext>(null);
            //Database.CreateIfNotExists();
        }

        ///***** 中介表 *****/
        //public DbSet<TaskOrderEngineer> TaskOrderEngineers { get; set; }

        /***** 需求單位 *****/
        public DbSet<RequestingUnit> RequestingUnits { get; set; }

        /***** 維護單位 *****/
        public DbSet<IssueCategory> IssueCategories { get; set; }
        public DbSet<MaintenanceUnit> MaintenanceUnits { get; set; }

        /***** TaskOrderEngineers *****/
        public DbSet<TaskOrder> TaskOrders { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MaintiFlowInitializer(modelBuilder, _coreContext));

            var taskorder = modelBuilder.Entity<TaskOrder>();
            taskorder.HasKey(t => t.WorkOrderNo);

            /***** 維護單位 *****/
            // 維護類型 一對多: TaskOrderEngineers.IssueCategory → IssueCategory.TaskOrderEngineers
            taskorder.HasRequired(t => t.IssueCategory)
                     .WithMany(ic => ic.TaskOrders)
                     .HasForeignKey(t => t.IssueCategoryId)
                     .WillCascadeOnDelete(false);

            /***** 需求單位 *****/
            // 回覆內容 一對多

            // 回覆人員 一對多

            // 需求單位 一對多: TaskOrderEngineers.RequestingUnit → RequestingUnit.TaskOrderEngineers
            taskorder.HasRequired(t => t.RequestingUnit)
                     .WithMany(ru => ru.TaskOrders)
                     .HasForeignKey(t => t.RequestingUnitId)
                     .WillCascadeOnDelete(false);

            /***** TaskOrderEngineers *****/
            // 維護工程師 多對多

            // 維護單位 一對多: TaskOrderEngineers.MaintenanceUnit → MaintenanceUnit.TaskOrderEngineers
            taskorder.HasRequired(t => t.MaintenanceUnit)
                     .WithMany(mu => mu.TaskOrders)
                     .HasForeignKey(t => t.MaintenanceUnitId)
                     .WillCascadeOnDelete(false);

            //// 建檔人員 一對多

            //// 工站 一對多

            //// 機台 一對多
        }
    }
}
