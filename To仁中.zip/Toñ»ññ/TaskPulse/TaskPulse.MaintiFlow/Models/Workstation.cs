﻿//using System.Collections.Generic;
//using System.ComponentModel;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace Calin.TaskPulse.MaintiFlow.Models
//{
//    public class Workstation
//    {

//        [Key]
//        [DatabaseGenerated(DatabaseGeneratedOption.None)]
//        public int WorkstationId { get; set; }

//        /// <summary>
//        /// 工站名稱。
//        /// </summary>
//        [Description("工站")]
//        [MaxLength(20)]
//        public string WorkstationName { get; set; }

//        public virtual ICollection<TaskOrder> TaskOrders { get; set; }
//    }
//}
