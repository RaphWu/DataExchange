﻿using System;
using System.IO;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow
{
    /// <summary>
    /// 容器建構完成後啟動。
    /// </summary>
    /// <remarks>參見: <see href="https://docs.autofac.org/en/latest/lifetime/startup.html#startable-components">Startable Components</see>。</remarks>
    public class MaintiFlowInitializer : IStartable
    {
        private readonly MaintiFlowContext _context;
        private readonly MaintiFlowData _flowData;

        public MaintiFlowInitializer(MaintiFlowContext context, MaintiFlowData flowData)
        {
            _context = context;
            _flowData = flowData;
        }

        public void Start()
        {
            try
            {
                _context.Database.Initialize(force: true);
            }
            catch (IOException ioe)
            {
                UIMessageBox.ShowError(ioe.Message);
                Application.Exit();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                throw;
            }
        }
    }
}
