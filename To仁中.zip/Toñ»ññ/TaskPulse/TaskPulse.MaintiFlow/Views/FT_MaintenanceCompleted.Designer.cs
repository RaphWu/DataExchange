﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FT_MaintenanceCompleted
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.uiLabel_Responsible = new Sunny.UI.UILabel();
            this.OutageDuration = new Sunny.UI.UITextBox();
            this.Responsible = new Sunny.UI.UITextBox();
            this.RepairDuration = new Sunny.UI.UITextBox();
            this.uiLabel_OutageDuration = new Sunny.UI.UILabel();
            this.uiLabel_RepairDuration = new Sunny.UI.UILabel();
            this.OutageEnded = new Sunny.UI.UITextBox();
            this.uiLabel_OutageEnded = new Sunny.UI.UILabel();
            this.RepairCompleted = new Sunny.UI.UITextBox();
            this.uiLabel_RepairCompleted = new Sunny.UI.UILabel();
            this.RepairStarted = new Sunny.UI.UITextBox();
            this.uiLabel_RepairStarted = new Sunny.UI.UILabel();
            this.MaintenanceEngineer = new Sunny.UI.UITextBox();
            this.uiLabel_MaintenanceEngineer = new Sunny.UI.UILabel();
            this.MaintenanceUnit = new Sunny.UI.UITextBox();
            this.uiLabel_MaintenanceUnit = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UITextBox();
            this.uiLabel_OutageStarted = new Sunny.UI.UILabel();
            this.SuspendLayout();
            // 
            // uiLabel_Responsible
            // 
            this.uiLabel_Responsible.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Responsible.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Responsible.Location = new System.Drawing.Point(33, 342);
            this.uiLabel_Responsible.Name = "uiLabel_Responsible";
            this.uiLabel_Responsible.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Responsible.TabIndex = 81;
            this.uiLabel_Responsible.Text = "責任歸屬";
            this.uiLabel_Responsible.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageDuration
            // 
            this.OutageDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageDuration.FillDisableColor = System.Drawing.Color.White;
            this.OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageDuration.Location = new System.Drawing.Point(160, 303);
            this.OutageDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageDuration.Name = "OutageDuration";
            this.OutageDuration.Padding = new System.Windows.Forms.Padding(5);
            this.OutageDuration.ShowText = false;
            this.OutageDuration.Size = new System.Drawing.Size(200, 29);
            this.OutageDuration.TabIndex = 96;
            this.OutageDuration.TabStop = false;
            this.OutageDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageDuration.Watermark = "";
            // 
            // Responsible
            // 
            this.Responsible.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Responsible.FillDisableColor = System.Drawing.Color.White;
            this.Responsible.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Responsible.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Responsible.Location = new System.Drawing.Point(160, 342);
            this.Responsible.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Responsible.MinimumSize = new System.Drawing.Size(1, 16);
            this.Responsible.Name = "Responsible";
            this.Responsible.Padding = new System.Windows.Forms.Padding(5);
            this.Responsible.ShowText = false;
            this.Responsible.Size = new System.Drawing.Size(200, 29);
            this.Responsible.TabIndex = 80;
            this.Responsible.TabStop = false;
            this.Responsible.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Responsible.Watermark = "";
            // 
            // RepairDuration
            // 
            this.RepairDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairDuration.FillDisableColor = System.Drawing.Color.White;
            this.RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairDuration.Location = new System.Drawing.Point(160, 186);
            this.RepairDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairDuration.Name = "RepairDuration";
            this.RepairDuration.Padding = new System.Windows.Forms.Padding(5);
            this.RepairDuration.ShowText = false;
            this.RepairDuration.Size = new System.Drawing.Size(200, 29);
            this.RepairDuration.TabIndex = 92;
            this.RepairDuration.TabStop = false;
            this.RepairDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairDuration.Watermark = "";
            // 
            // uiLabel_OutageDuration
            // 
            this.uiLabel_OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageDuration.Location = new System.Drawing.Point(33, 303);
            this.uiLabel_OutageDuration.Name = "uiLabel_OutageDuration";
            this.uiLabel_OutageDuration.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OutageDuration.TabIndex = 97;
            this.uiLabel_OutageDuration.Text = "停動工時";
            this.uiLabel_OutageDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RepairDuration
            // 
            this.uiLabel_RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairDuration.Location = new System.Drawing.Point(33, 186);
            this.uiLabel_RepairDuration.Name = "uiLabel_RepairDuration";
            this.uiLabel_RepairDuration.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RepairDuration.TabIndex = 93;
            this.uiLabel_RepairDuration.Text = "維護工時";
            this.uiLabel_RepairDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageEnded
            // 
            this.OutageEnded.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageEnded.FillDisableColor = System.Drawing.Color.White;
            this.OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageEnded.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageEnded.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageEnded.Location = new System.Drawing.Point(160, 264);
            this.OutageEnded.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageEnded.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageEnded.Name = "OutageEnded";
            this.OutageEnded.Padding = new System.Windows.Forms.Padding(5);
            this.OutageEnded.ShowText = false;
            this.OutageEnded.Size = new System.Drawing.Size(200, 29);
            this.OutageEnded.TabIndex = 94;
            this.OutageEnded.TabStop = false;
            this.OutageEnded.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageEnded.Watermark = "";
            // 
            // uiLabel_OutageEnded
            // 
            this.uiLabel_OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageEnded.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageEnded.Location = new System.Drawing.Point(33, 264);
            this.uiLabel_OutageEnded.Name = "uiLabel_OutageEnded";
            this.uiLabel_OutageEnded.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OutageEnded.TabIndex = 95;
            this.uiLabel_OutageEnded.Text = "停動結束時間";
            this.uiLabel_OutageEnded.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RepairCompleted
            // 
            this.RepairCompleted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairCompleted.FillDisableColor = System.Drawing.Color.White;
            this.RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairCompleted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairCompleted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairCompleted.Location = new System.Drawing.Point(160, 147);
            this.RepairCompleted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairCompleted.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairCompleted.Name = "RepairCompleted";
            this.RepairCompleted.Padding = new System.Windows.Forms.Padding(5);
            this.RepairCompleted.ShowText = false;
            this.RepairCompleted.Size = new System.Drawing.Size(200, 29);
            this.RepairCompleted.TabIndex = 90;
            this.RepairCompleted.TabStop = false;
            this.RepairCompleted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairCompleted.Watermark = "";
            // 
            // uiLabel_RepairCompleted
            // 
            this.uiLabel_RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairCompleted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairCompleted.Location = new System.Drawing.Point(33, 147);
            this.uiLabel_RepairCompleted.Name = "uiLabel_RepairCompleted";
            this.uiLabel_RepairCompleted.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RepairCompleted.TabIndex = 91;
            this.uiLabel_RepairCompleted.Text = "維護完成時間";
            this.uiLabel_RepairCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RepairStarted
            // 
            this.RepairStarted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairStarted.FillDisableColor = System.Drawing.Color.White;
            this.RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairStarted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairStarted.Location = new System.Drawing.Point(160, 108);
            this.RepairStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairStarted.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairStarted.Name = "RepairStarted";
            this.RepairStarted.Padding = new System.Windows.Forms.Padding(5);
            this.RepairStarted.ShowText = false;
            this.RepairStarted.Size = new System.Drawing.Size(200, 29);
            this.RepairStarted.TabIndex = 88;
            this.RepairStarted.TabStop = false;
            this.RepairStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairStarted.Watermark = "";
            // 
            // uiLabel_RepairStarted
            // 
            this.uiLabel_RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairStarted.Location = new System.Drawing.Point(33, 108);
            this.uiLabel_RepairStarted.Name = "uiLabel_RepairStarted";
            this.uiLabel_RepairStarted.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RepairStarted.TabIndex = 89;
            this.uiLabel_RepairStarted.Text = "維護開始時間";
            this.uiLabel_RepairStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MaintenanceEngineer
            // 
            this.MaintenanceEngineer.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaintenanceEngineer.FillDisableColor = System.Drawing.Color.White;
            this.MaintenanceEngineer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceEngineer.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaintenanceEngineer.Location = new System.Drawing.Point(160, 69);
            this.MaintenanceEngineer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaintenanceEngineer.MinimumSize = new System.Drawing.Size(1, 16);
            this.MaintenanceEngineer.Name = "MaintenanceEngineer";
            this.MaintenanceEngineer.Padding = new System.Windows.Forms.Padding(5);
            this.MaintenanceEngineer.ShowText = false;
            this.MaintenanceEngineer.Size = new System.Drawing.Size(200, 29);
            this.MaintenanceEngineer.TabIndex = 84;
            this.MaintenanceEngineer.TabStop = false;
            this.MaintenanceEngineer.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceEngineer.Watermark = "";
            // 
            // uiLabel_MaintenanceEngineer
            // 
            this.uiLabel_MaintenanceEngineer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MaintenanceEngineer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MaintenanceEngineer.Location = new System.Drawing.Point(33, 69);
            this.uiLabel_MaintenanceEngineer.Name = "uiLabel_MaintenanceEngineer";
            this.uiLabel_MaintenanceEngineer.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_MaintenanceEngineer.TabIndex = 85;
            this.uiLabel_MaintenanceEngineer.Text = "維護工程師";
            this.uiLabel_MaintenanceEngineer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MaintenanceUnit
            // 
            this.MaintenanceUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaintenanceUnit.FillDisableColor = System.Drawing.Color.White;
            this.MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaintenanceUnit.Location = new System.Drawing.Point(160, 30);
            this.MaintenanceUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaintenanceUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.MaintenanceUnit.Name = "MaintenanceUnit";
            this.MaintenanceUnit.Padding = new System.Windows.Forms.Padding(5);
            this.MaintenanceUnit.ShowText = false;
            this.MaintenanceUnit.Size = new System.Drawing.Size(200, 29);
            this.MaintenanceUnit.TabIndex = 82;
            this.MaintenanceUnit.TabStop = false;
            this.MaintenanceUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceUnit.Watermark = "";
            // 
            // uiLabel_MaintenanceUnit
            // 
            this.uiLabel_MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MaintenanceUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MaintenanceUnit.Location = new System.Drawing.Point(33, 30);
            this.uiLabel_MaintenanceUnit.Name = "uiLabel_MaintenanceUnit";
            this.uiLabel_MaintenanceUnit.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_MaintenanceUnit.TabIndex = 83;
            this.uiLabel_MaintenanceUnit.Text = "維護單位";
            this.uiLabel_MaintenanceUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageStarted.FillDisableColor = System.Drawing.Color.White;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageStarted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageStarted.Location = new System.Drawing.Point(160, 225);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(5);
            this.OutageStarted.ShowText = false;
            this.OutageStarted.Size = new System.Drawing.Size(200, 29);
            this.OutageStarted.TabIndex = 86;
            this.OutageStarted.TabStop = false;
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageStarted.Watermark = "";
            // 
            // uiLabel_OutageStarted
            // 
            this.uiLabel_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageStarted.Location = new System.Drawing.Point(33, 225);
            this.uiLabel_OutageStarted.Name = "uiLabel_OutageStarted";
            this.uiLabel_OutageStarted.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OutageStarted.TabIndex = 87;
            this.uiLabel_OutageStarted.Text = "停動開始時間";
            this.uiLabel_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FT_MaintenanceCompleted
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(802, 460);
            this.Controls.Add(this.uiLabel_Responsible);
            this.Controls.Add(this.OutageDuration);
            this.Controls.Add(this.Responsible);
            this.Controls.Add(this.RepairDuration);
            this.Controls.Add(this.uiLabel_OutageDuration);
            this.Controls.Add(this.uiLabel_RepairDuration);
            this.Controls.Add(this.OutageEnded);
            this.Controls.Add(this.uiLabel_OutageEnded);
            this.Controls.Add(this.RepairCompleted);
            this.Controls.Add(this.uiLabel_RepairCompleted);
            this.Controls.Add(this.RepairStarted);
            this.Controls.Add(this.uiLabel_RepairStarted);
            this.Controls.Add(this.MaintenanceEngineer);
            this.Controls.Add(this.uiLabel_MaintenanceEngineer);
            this.Controls.Add(this.MaintenanceUnit);
            this.Controls.Add(this.uiLabel_MaintenanceUnit);
            this.Controls.Add(this.OutageStarted);
            this.Controls.Add(this.uiLabel_OutageStarted);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "FT_MaintenanceCompleted";
            this.Text = "FT_MaintenanceCompleted";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UILabel uiLabel_Responsible;
        private Sunny.UI.UITextBox OutageDuration;
        private Sunny.UI.UITextBox Responsible;
        private Sunny.UI.UITextBox RepairDuration;
        private Sunny.UI.UILabel uiLabel_OutageDuration;
        private Sunny.UI.UILabel uiLabel_RepairDuration;
        private Sunny.UI.UITextBox OutageEnded;
        private Sunny.UI.UILabel uiLabel_OutageEnded;
        private Sunny.UI.UITextBox RepairCompleted;
        private Sunny.UI.UILabel uiLabel_RepairCompleted;
        private Sunny.UI.UITextBox RepairStarted;
        private Sunny.UI.UILabel uiLabel_RepairStarted;
        private Sunny.UI.UITextBox MaintenanceEngineer;
        private Sunny.UI.UILabel uiLabel_MaintenanceEngineer;
        private Sunny.UI.UITextBox MaintenanceUnit;
        private Sunny.UI.UILabel uiLabel_MaintenanceUnit;
        private Sunny.UI.UITextBox OutageStarted;
        private Sunny.UI.UILabel uiLabel_OutageStarted;
    }
}
