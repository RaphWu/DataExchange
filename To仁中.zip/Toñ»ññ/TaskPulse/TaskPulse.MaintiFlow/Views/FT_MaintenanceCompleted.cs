﻿using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_MaintenanceCompleted : UIPage
    {
        public FT_MaintenanceCompleted()
        {
            InitializeComponent();
        }
    }
}
