﻿using System;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class ManitiFlowMain : UIPage
    {
        private readonly ILifetimeScope _scope;

        public ManitiFlowMain(ILifetimeScope lifetimeScope)
        {
            InitializeComponent();
            _scope = lifetimeScope;

            uiButton_CreateFlow.Text = PageCode.CreateFlow.GetDescription();
            uiButton_CreateFlow.Symbol = 559936;
            uiButton_CreateFlow.FillColor = CommonStyles.BackColor;
            uiButton_CreateFlow.FillHoverColor = CommonStyles.Hover;
        }

        private void uiButton_CreateFlow_Click(object sender, EventArgs e)
        {
            using (var scope = _scope.BeginLifetimeScope())
            {
                var createFlow = scope.Resolve<CreateFlow>();
                createFlow.Title = "新建工單";
                if (createFlow.ShowDialog() == DialogResult.OK)
                {
                    var to = scope.Resolve<MaintiFlowContext>().Set<TaskOrder>().ToList();
                    var tov = scope.Resolve<TaskOrderView>();

                    tov.Title = "工單已建立";
                    tov.NewWorkOrderNos = createFlow.NewWorkOrderNos;
                    tov.Initialize();
                    tov.ShowDialog();
                }
            }
        }
    }
}
