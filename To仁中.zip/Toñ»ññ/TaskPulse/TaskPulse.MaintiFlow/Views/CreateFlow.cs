﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class CreateFlow : UIForm
    {
        private readonly IMaintiFlow _flow;
        private readonly MaintiFlowContext _context;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly MaintiFlowFieldName _fieldName;
        private readonly FlowLayoutSelector _flowLayoutSelector;

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 新建工單的工單號。
        /// </summary>
        public string NewWorkOrderNo { get; set; }

        public CreateFlow(IMaintiFlow maintiFlow,
                          MaintiFlowContext maintiFlowContext,
                          MaintiFlowData maintiFlowData,
                          CoreData coreData,
                          MaintiFlowFieldName maintiFlowFieldName,
                          FlowLayoutSelector flowLayoutSelector)
        {
            InitializeComponent();
            _flow = maintiFlow;
            _context = maintiFlowContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _fieldName = maintiFlowFieldName;
            _flowLayoutSelector = flowLayoutSelector;

            uiButton_OK.FillColor = CommonStyles.BackColor;
            uiButton_OK.FillHoverColor = CommonStyles.Hover;

            this.AcceptButton = uiButton_OK;
            this.CancelButton = uiButton_Cancel;

            /********************
             * Controls
             ********************/
            string caption;
            caption = _fieldName.Creator;
            uiLabel_Creator.Text = caption;
            var employeeList = _flowData.Employees
                .Select(e => new
                {
                    e.EmployeeId,
                    Display = $"{e.EmployeeId}, {e.Department}, {e.Name}",
                })
                .ToList();
            Creator.DataSource = employeeList;
            Creator.DisplayMember = "Display";
            Creator.ValueMember = "EmployeeId";
            Creator.Watermark = caption;

            caption = _fieldName.Machine;
            uiLabel_MachineList.Text = caption;
            MachineList.Watermark = caption;
            MachineList.ButtonFillColor = CommonStyles.BackColor;
            MachineList.ButtonFillHoverColor = CommonStyles.Hover;

            caption = _fieldName.Model;
            uiLabel_Model.Text = caption;
            Model.Watermark = caption;
            Model.ButtonFillColor = CommonStyles.BackColor;
            Model.ButtonFillHoverColor = CommonStyles.Hover;

            caption = _fieldName.Workstation;
            uiLabel_Workstation.Text = caption;
            Workstation.Watermark = caption;
            Workstation.ButtonFillColor = CommonStyles.BackColor;
            Workstation.ButtonFillHoverColor = CommonStyles.Hover;

            caption = _fieldName.OutageStarted;
            uiLabel_OutageStarted.Text = caption;
            OutageStarted.Watermark = caption;

            caption = _fieldName.IssueDescription;
            uiLabel_IssueDescription.Text = caption;
            IssueDescription.Watermark = caption;
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            var deviceList = new List<TaskOrderMachine>();

            var to = _context.TaskOrders;
            var statuses = _context.Statuses;

            // 計算新工單號
            string todayPrefix = DateTime.Today.ToString("yyyyMMdd");
            int maxSerial = to
                .Where(o => o.WorkOrderNo.StartsWith(todayPrefix))
                .AsEnumerable()
                .Select(o => o.WorkOrderNo.Substring(8, 3))
                .Select(s =>
                {
                    bool success = int.TryParse(s, out int val);
                    return success ? val : 0;
                })
                .DefaultIfEmpty(0)
                .Max();
            NewWorkOrderNo = todayPrefix + (maxSerial + 1).ToString("D3");

            // 錯誤檢查
            if (string.IsNullOrWhiteSpace(Creator.Text))
            {
                UIMessageBox.ShowError2($"{uiLabel_Creator.Text}必須要選擇一人！");
                return;
            }
            if (string.IsNullOrWhiteSpace(MachineList.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{uiLabel_MachineList.Text}！");
                return;
            }
            else
            {
                var dList = MachineList.Text
                    .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim())
                    .ToList();
                foreach (var d in dList)
                {
                    if (_coreData.Machines.FindIndex(x => x.MachineId == d) == -1)
                    {
                        UIMessageBox.ShowError2($"{uiLabel_MachineList.Text}不存在: {d}");
                        return;
                    }
                    else
                    {
                        deviceList.Add(new TaskOrderMachine()
                        {
                            WorkOrderNo = NewWorkOrderNo,
                            MachineId = d,
                        });
                    }
                }
            }
            if (string.IsNullOrWhiteSpace(Model.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{uiLabel_Model.Text}！");
                return;
            }
            else
            {
                if (_flowData.ModelList.FindIndex(x => x == Model.Text) == -1)
                {
                    UIMessageBox.ShowError2($"{uiLabel_Model.Text}不存在: {Model.Text}");
                    return;
                }
            }

            // 加入資料庫
            to.Add(new TaskOrder()
            {
                OrderNo = to.Select(x => x.OrderNo).Max() + 1,
                WorkOrderNo = NewWorkOrderNo,
                CreatorId = _flowData.Employees.FirstOrDefault(x => x.EmployeeId == (string)Creator.SelectedValue).EmployeeId,
                CreationDate = DateTime.Today,
                TaskOrderMachines = deviceList,
                ModelName = Model.Text,
                Status = _flow.DefaultStatus,
                AcceptedTime = DateTime.Now,
                OutageStarted = OutageStarted.Value,
            });
            _context.SaveChanges();

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void MachineId_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.HideTabHeaders = false;
            _flowLayoutSelector.Title = _fieldName.Machine;
            _flowLayoutSelector.MultiSelection = true;
            _flowLayoutSelector.ResultList = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();

            Dictionary<string, List<string>> deviceGroip = new Dictionary<string, List<string>>();
            var typeList = _coreData.Machines
                .OrderBy(x => x.MachineName.Type.OrderNo)
                .Select(x => x.MachineName.Type.TypeName)
                .Distinct().ToList();
            foreach (var type in typeList)
            {
                List<string> itemList = new List<string>();
                var Names = _coreData.Machines
                       .Where(x => x.MachineName.Type.TypeName == type)
                       .Select(x => x.MachineId)
                       .ToList();
                if (Names.Count > 0)
                    foreach (var name in Names)
                        itemList.Add(name);
                deviceGroip.Add(type, itemList);
            }
            _flowLayoutSelector.Items = deviceGroip;
            _flowLayoutSelector.Initialize();

            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                if (_flowLayoutSelector.ResultList.Count > 0)
                {
                    string deviceString = "";
                    foreach (var item in _flowLayoutSelector.ResultList)
                    {
                        if (deviceString != "")
                            deviceString += "; ";
                        deviceString += item;
                    }
                    MachineList.Text = deviceString;
                }
            }
        }

        private void Model_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.HideTabHeaders = true;
            _flowLayoutSelector.Title = _fieldName.Model;
            _flowLayoutSelector.MultiSelection = false;
            _flowLayoutSelector.ResultList = new List<string>();
            if (!string.IsNullOrWhiteSpace(Model.Text))
                _flowLayoutSelector.ResultList.Add(Model.Text.Trim());

            Dictionary<string, List<string>> deviceGroip = new Dictionary<string, List<string>>();

            List<string> itemList = new List<string>();
            if (_flowData.ModelList.Count > 0)
                foreach (var name in _flowData.ModelList)
                    itemList.Add(name);
            deviceGroip.Add("", itemList);

            _flowLayoutSelector.Items = deviceGroip;
            _flowLayoutSelector.Initialize();

            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                if (_flowLayoutSelector.ResultList.Count > 0)
                    Model.Text = _flowLayoutSelector.ResultList[0];
            }
        }
    }
}
