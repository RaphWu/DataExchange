﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class CreateFlow
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.uiButton_OK = new Sunny.UI.UISymbolButton();
            this.uiButton_Cancel = new Sunny.UI.UISymbolButton();
            this.IssueDescription = new Sunny.UI.UITextBox();
            this.uiLabel_IssueDescription = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UIDatetimePicker();
            this.uiLabel_OutageStarted = new Sunny.UI.UILabel();
            this.Workstation = new Sunny.UI.UITextBox();
            this.uiLabel_Workstation = new Sunny.UI.UILabel();
            this.Model = new Sunny.UI.UITextBox();
            this.uiLabel_Model = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.uiLabel_MachineList = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UIComboBox();
            this.uiLabel_Creator = new Sunny.UI.UILabel();
            this.SuspendLayout();
            // 
            // uiButton_OK
            // 
            this.uiButton_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.uiButton_OK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_OK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_OK.Location = new System.Drawing.Point(194, 388);
            this.uiButton_OK.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_OK.Name = "uiButton_OK";
            this.uiButton_OK.Radius = 10;
            this.uiButton_OK.Size = new System.Drawing.Size(110, 35);
            this.uiButton_OK.TabIndex = 3;
            this.uiButton_OK.Text = "確定";
            this.uiButton_OK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_OK.Click += new System.EventHandler(this.uiButton_OK_Click);
            // 
            // uiButton_Cancel
            // 
            this.uiButton_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.uiButton_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.uiButton_Cancel.Location = new System.Drawing.Point(324, 388);
            this.uiButton_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Cancel.Name = "uiButton_Cancel";
            this.uiButton_Cancel.Radius = 10;
            this.uiButton_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Size = new System.Drawing.Size(110, 35);
            this.uiButton_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton_Cancel.Symbol = 361453;
            this.uiButton_Cancel.TabIndex = 2;
            this.uiButton_Cancel.Text = "取消";
            this.uiButton_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Cancel.Click += new System.EventHandler(this.uiButton_Cancel_Click);
            // 
            // IssueDescription
            // 
            this.IssueDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(162, 261);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueDescription.Multiline = true;
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(5);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(250, 85);
            this.IssueDescription.TabIndex = 36;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.IssueDescription.Watermark = "";
            // 
            // uiLabel_IssueDescription
            // 
            this.uiLabel_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueDescription.Location = new System.Drawing.Point(37, 261);
            this.uiLabel_IssueDescription.Name = "uiLabel_IssueDescription";
            this.uiLabel_IssueDescription.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_IssueDescription.TabIndex = 37;
            this.uiLabel_IssueDescription.Text = "IssueDescription";
            this.uiLabel_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.DateFormat = "yyyy-MM-dd HH:mm";
            this.OutageStarted.FillColor = System.Drawing.Color.White;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.Location = new System.Drawing.Point(162, 222);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MaxLength = 16;
            this.OutageStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.OutageStarted.Size = new System.Drawing.Size(250, 29);
            this.OutageStarted.SymbolDropDown = 61555;
            this.OutageStarted.SymbolNormal = 61555;
            this.OutageStarted.SymbolSize = 24;
            this.OutageStarted.TabIndex = 35;
            this.OutageStarted.Text = "2025-10-13 10:39";
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.OutageStarted.Value = new System.DateTime(2025, 10, 13, 10, 39, 6, 671);
            this.OutageStarted.Watermark = "";
            // 
            // uiLabel_OutageStarted
            // 
            this.uiLabel_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageStarted.Location = new System.Drawing.Point(37, 222);
            this.uiLabel_OutageStarted.Name = "uiLabel_OutageStarted";
            this.uiLabel_OutageStarted.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_OutageStarted.TabIndex = 34;
            this.uiLabel_OutageStarted.Text = "OutageStarted";
            this.uiLabel_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Workstations
            // 
            this.Workstation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Workstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation.Location = new System.Drawing.Point(162, 183);
            this.Workstation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Workstation.MinimumSize = new System.Drawing.Size(1, 16);
            this.Workstation.Name = "Workstations";
            this.Workstation.Padding = new System.Windows.Forms.Padding(5);
            this.Workstation.ShowText = false;
            this.Workstation.Size = new System.Drawing.Size(250, 29);
            this.Workstation.TabIndex = 32;
            this.Workstation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Workstation.Watermark = "";
            // 
            // uiLabel_Workstation
            // 
            this.uiLabel_Workstation.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Workstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Workstation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Workstation.Location = new System.Drawing.Point(37, 183);
            this.uiLabel_Workstation.Name = "uiLabel_Workstation";
            this.uiLabel_Workstation.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_Workstation.TabIndex = 33;
            this.uiLabel_Workstation.Text = "Workstations";
            this.uiLabel_Workstation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ModelName
            // 
            this.Model.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model.Location = new System.Drawing.Point(162, 144);
            this.Model.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Model.MinimumSize = new System.Drawing.Size(1, 16);
            this.Model.Name = "ModelName";
            this.Model.Padding = new System.Windows.Forms.Padding(5);
            this.Model.ShowButton = true;
            this.Model.ShowText = false;
            this.Model.Size = new System.Drawing.Size(250, 29);
            this.Model.TabIndex = 31;
            this.Model.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Model.Watermark = "";
            this.Model.ButtonClick += new System.EventHandler(this.Model_ButtonClick);
            // 
            // uiLabel_Model
            // 
            this.uiLabel_Model.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Model.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Model.Location = new System.Drawing.Point(37, 144);
            this.uiLabel_Model.Name = "uiLabel_Model";
            this.uiLabel_Model.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_Model.TabIndex = 30;
            this.uiLabel_Model.Text = "ModelName";
            this.uiLabel_Model.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.Location = new System.Drawing.Point(162, 105);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ShowButton = true;
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(250, 29);
            this.MachineList.TabIndex = 29;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            this.MachineList.ButtonClick += new System.EventHandler(this.MachineId_ButtonClick);
            // 
            // uiLabel_MachineList
            // 
            this.uiLabel_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MachineList.Location = new System.Drawing.Point(37, 105);
            this.uiLabel_MachineList.Name = "uiLabel_MachineList";
            this.uiLabel_MachineList.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_MachineList.TabIndex = 28;
            this.uiLabel_MachineList.Text = "MachineList";
            this.uiLabel_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreatedBy
            // 
            this.Creator.DataSource = null;
            this.Creator.FillColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Creator.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Creator.Location = new System.Drawing.Point(162, 66);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MaxDropDownItems = 12;
            this.Creator.MinimumSize = new System.Drawing.Size(63, 0);
            this.Creator.Name = "CreatedBy";
            this.Creator.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Creator.ShowFilter = true;
            this.Creator.Size = new System.Drawing.Size(250, 29);
            this.Creator.SymbolSize = 24;
            this.Creator.TabIndex = 27;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // uiLabel_CreatedBy
            // 
            this.uiLabel_Creator.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Creator.Location = new System.Drawing.Point(37, 66);
            this.uiLabel_Creator.Name = "uiLabel_CreatedBy";
            this.uiLabel_Creator.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_Creator.TabIndex = 26;
            this.uiLabel_Creator.Text = "CreatedBy";
            this.uiLabel_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreateFlow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(462, 449);
            this.Controls.Add(this.IssueDescription);
            this.Controls.Add(this.uiLabel_IssueDescription);
            this.Controls.Add(this.OutageStarted);
            this.Controls.Add(this.uiLabel_OutageStarted);
            this.Controls.Add(this.Workstation);
            this.Controls.Add(this.uiLabel_Workstation);
            this.Controls.Add(this.Model);
            this.Controls.Add(this.uiLabel_Model);
            this.Controls.Add(this.MachineList);
            this.Controls.Add(this.uiLabel_MachineList);
            this.Controls.Add(this.Creator);
            this.Controls.Add(this.uiLabel_Creator);
            this.Controls.Add(this.uiButton_OK);
            this.Controls.Add(this.uiButton_Cancel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateFlow";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 1141, 732);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UISymbolButton uiButton_OK;
        private Sunny.UI.UISymbolButton uiButton_Cancel;
        private Sunny.UI.UITextBox IssueDescription;
        private Sunny.UI.UILabel uiLabel_IssueDescription;
        private Sunny.UI.UIDatetimePicker OutageStarted;
        private Sunny.UI.UILabel uiLabel_OutageStarted;
        private Sunny.UI.UITextBox Workstation;
        private Sunny.UI.UILabel uiLabel_Workstation;
        private Sunny.UI.UITextBox Model;
        private Sunny.UI.UILabel uiLabel_Model;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UILabel uiLabel_MachineList;
        private Sunny.UI.UIComboBox Creator;
        private Sunny.UI.UILabel uiLabel_Creator;
    }
}
