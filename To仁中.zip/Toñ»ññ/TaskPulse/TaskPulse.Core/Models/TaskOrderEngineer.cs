﻿using System.ComponentModel.DataAnnotations;

namespace Calin.TaskPulse.Core.Models
{
    public class TaskOrderEngineer
    {
        [Key]
        public int Id { get; set; }

        public string WorkOrderNo { get; set; }
        public int EmployeeId { get; set; }
    }
}
