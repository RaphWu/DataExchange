﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 員工清單。
    /// </summary>
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 工號。
        /// </summary>
        [Description("工號")]
        [Required]
        [MaxLength(6)]
        public string EmployeeId { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        [Description("姓名")]
        [Required]
        [MaxLength(12)]
        public string Name { get; set; }

        /// <summary>
        /// 部門。
        /// </summary>
        [Description("部門")]
        [Required]
        public int DepartmentId { get; set; } // FK
        public virtual Department Department { get; set; }

        /// <summary>
        /// 職稱。
        /// </summary>
        [Description("職稱")]
        [Required]
        public int TitleId { get; set; } // FK
        public virtual Title Title { get; set; }

        /// <summary>
        /// 是否為維護工程師。
        /// </summary>
        [Description("維護工程師")]
        public bool IsEngineer { get; set; } = false;
    }
}
