﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 機種。
    /// </summary>
    public class Model
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ModelId { get; set; }

        /// <summary>
        /// 機種名稱。
        /// </summary>
        [Description("機種")]
        [MaxLength(10)]
        public string ModelName { get; set; }

        public virtual ICollection<Workstation> Worktations { get; set; } = new List<Workstation>();
    }
}
