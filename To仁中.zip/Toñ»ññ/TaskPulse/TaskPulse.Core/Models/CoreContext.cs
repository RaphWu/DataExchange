﻿using System.Data.Entity;

namespace Calin.TaskPulse.Core.Models
{
    public class CoreContext : DbContext
    {
        public CoreContext() : base("name=CoreContext") { }

        public DbSet<Authorization> AuthorizationTable { get; set; }

        public DbSet<Factory> Factorys { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Model> Models { get; set; }

        public DbSet<MachineCategory> MachineCategorys { get; set; }
        public DbSet<MachineType> MachineTypes { get; set; }
        public DbSet<MachineName> MachineNames { get; set; }
        public DbSet<MachineBrand> MachineBrands { get; set; }
        public DbSet<MachineAssetCode> MachineAssetCodes { get; set; }
        public DbSet<MachineCondition> MachineConditions { get; set; }
        public DbSet<MachineLocation> Locations { get; set; }

        public DbSet<Machine> Machines { get; set; } // 所有機台清單

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new CoreInitializer(modelBuilder));

            //var device = modelBuilder.Entity<Machine>();

            //// MachineNames 一對多
            //device.HasRequired(d => d.MachineNames)
            //      .WithMany(e => e.Machines)
            //      .HasForeignKey(d => d.MachineNameId)
            //      .WillCascadeOnDelete(false);

            //// MachineBrand 一對多
            //device.HasRequired(d => d.MachineBrand)
            //      .WithMany(e => e.MachineBrands)
            //      .HasForeignKey(d => d.BrandId)
            //      .WillCascadeOnDelete(false);

            //// Factory 一對多
            //modelBuilder.Entity<MachineLocation>()
            //    .HasRequired(p => p.Factory)
            //    .WithMany(l => l.Factorys)
            //    .HasForeignKey(p => p.FactoryId)
            //    .WillCascadeOnDelete(false);

            //// Condition 一對多
            //device.HasRequired(d => d.Condition)
            //      .WithMany(c => c.Machines)
            //      .HasForeignKey(d => d.ConditionId)
            //      .WillCascadeOnDelete(false);

            //// Assets 多對一
            //modelBuilder.Entity<MachineAssetCode>()
            //    .HasRequired(a => a.Machine)
            //    .WithMany(d => d.Assets)
            //    .HasForeignKey(a => a.MachineId)
            //    .WillCascadeOnDelete(false);

            //// ===== MachineNames -> MachineTypes 一對多 =====
            //modelBuilder.Entity<MachineNames>()
            //    .HasRequired(d => d.Type)
            //    .WithMany(t => t.MachineTypes)
            //    .HasForeignKey(d => d.TypeId)
            //    .WillCascadeOnDelete(false);

            // 機台類別 一對多: MachineType.Category → MachineCategory.Id
            modelBuilder.Entity<MachineType>()
                .HasRequired(d => d.Category)
                .WithMany(e => e.MachineTypes)
                .HasForeignKey(t => t.CategoryId)
                .WillCascadeOnDelete(false);

            // 機台型式 一對多: MachineNames.MachineTypes → MachineTypes.Id
            modelBuilder.Entity<MachineName>()
                .HasRequired(d => d.Type)
                .WithMany(e => e.MachineNames)
                .HasForeignKey(t => t.TypeId)
                .WillCascadeOnDelete(false);

            // 機台名稱 一對多: Machine.MachineNames → MachineNames.Machines
            modelBuilder.Entity<Machine>()
                .HasRequired(d => d.MachineName)
                .WithMany(e => e.Machines)
                .HasForeignKey(t => t.MachineNameId)
                .WillCascadeOnDelete(false);

            // 廠牌 一對多: Machine.MachineBrand → MachineBrand.MachineBrands
            modelBuilder.Entity<Machine>()
                .HasRequired(d => d.Brand)
                .WithMany(e => e.Machines)
                .HasForeignKey(t => t.BrandId)
                .WillCascadeOnDelete(false);

            // 位置 一對多: MachineLocation.Factory → Factory.Factorys
            modelBuilder.Entity<MachineLocation>()
                .HasRequired(d => d.Factory)
                .WithMany(e => e.Factorys)
                .HasForeignKey(t => t.FactoryId)
                .WillCascadeOnDelete(false);

            // 機台狀態 一對多: Machine.Condition → MachineCondition.Machines
            modelBuilder.Entity<Machine>()
                .HasRequired(d => d.Condition)
                .WithMany(e => e.Machines)
                .HasForeignKey(t => t.ConditionId)
                .WillCascadeOnDelete(false);

            // 資產編號 多對一: Machine.Assets → MachineAssetCode.Machine
            modelBuilder.Entity<MachineAssetCode>()
                .HasRequired(a => a.Machine)
                .WithMany(d => d.Assets)
                .HasForeignKey(a => a.MachineId)
                .WillCascadeOnDelete(false);
        }
    }
}
