﻿using System.Data.Entity;

namespace Calin.TaskPulse.Core.Models
{
    public class CoreContext : DbContext
    {
        public CoreContext() : base("name=CoreContext") { }

        public DbSet<Authorization> AuthorizationTable { get; set; }

        /***** 中介表 *****/
        public DbSet<TaskOrderEngineer> TaskOrderEngineers { get; set; }

        /***** Employee *****/
        public DbSet<Department> Departments { get; set; }
        public DbSet<Title> Titles { get; set; }
        public DbSet<Employee> Employees { get; set; }

        /***** Workstation *****/
        public DbSet<Workstation> Workstations { get; set; }
        public DbSet<Model> Models { get; set; }

        /***** Machines *****/
        public DbSet<MachineStatus> MachineConditions { get; set; }
        public DbSet<MachineLocation> MachineLocations { get; set; }
        public DbSet<MachineAssetCode> MachineAssetCodes { get; set; }
        public DbSet<MachineBrand> MachineBrands { get; set; }
        public DbSet<MachineCategory> MachineCategories { get; set; }
        public DbSet<MachineType> MachineTypes { get; set; }
        public DbSet<MachineName> MachineNames { get; set; }
        public DbSet<Machine> Machines { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new CoreInitializer(modelBuilder));

            /***** Employee *****/
            var employee = modelBuilder.Entity<Employee>();

            // 部門 一對多: Employee.Department → Department.Employees
            employee.HasRequired(d => d.Department)
                    .WithMany(e => e.Employees)
                    .HasForeignKey(t => t.DepartmentId)
                    .WillCascadeOnDelete(false);

            // 職稱 一對多: Employee.Title → Title.Employees
            employee.HasRequired(d => d.Title)
                    .WithMany(e => e.Employees)
                    .HasForeignKey(t => t.TitleId)
                    .WillCascadeOnDelete(false);

            /***** Workstation *****/
            // 工站 多對一: Model.Workstations → Workstation.Model
            modelBuilder.Entity<Workstation>()
                        .HasRequired(d => d.Model)
                        .WithMany(e => e.Worktations)
                        .HasForeignKey(t => t.ModelId)
                        .WillCascadeOnDelete(false);

            /***** Machines *****/
            var machine = modelBuilder.Entity<Machine>();

            // 機台狀態 一對多: Machines.Status → MachineStatus.Machines
            machine.HasRequired(d => d.Status)
                  .WithMany(e => e.Machines)
                  .HasForeignKey(t => t.StatusId)
                  .WillCascadeOnDelete(false);

            // 位置 一對多: Machines.Location → MachineLocation.Location
            machine.HasRequired(d => d.Location)
                   .WithMany(e => e.Machines)
                   .HasForeignKey(t => t.LocationId)
                   .WillCascadeOnDelete(false);

            // 資產編號 多對一: Machines.Assets → MachineAssetCode.Machines
            modelBuilder.Entity<MachineAssetCode>()
                .HasRequired(a => a.Machine)
                .WithMany(d => d.Assets)
                .HasForeignKey(a => a.MachineId)
                .WillCascadeOnDelete(false);

            // 廠牌 一對多: Machines.Brand → MachineBrand.Machines
            machine.HasRequired(d => d.Brand)
                   .WithMany(e => e.Machines)
                   .HasForeignKey(t => t.BrandId)
                   .WillCascadeOnDelete(false);

            // 機台類別 一對多: MachineType.Category → MachineCategory.MachineTypes
            modelBuilder.Entity<MachineType>()
                .HasRequired(d => d.Category)
                .WithMany(e => e.MachineTypes)
                .HasForeignKey(t => t.CategoryId)
                .WillCascadeOnDelete(false);

            // 機台型式 一對多: MachineNames.MachineTypes → MachineTypes.MachineNames
            modelBuilder.Entity<MachineName>()
                .HasRequired(d => d.MachineType)
                .WithMany(e => e.MachineNames)
                .HasForeignKey(t => t.TypeId)
                .WillCascadeOnDelete(false);

            // 機台名稱 一對多: Machines.MachineNames → MachineNames.Machines
            machine.HasRequired(d => d.MachineName)
                   .WithMany(e => e.Machines)
                   .HasForeignKey(t => t.MachineNameId)
                   .WillCascadeOnDelete(false);

            // 工站 多對多: Machines.Workstations ↔ Workstation.Machines
            machine.HasMany(m => m.Worktations)
                   .WithMany(w => w.Machines)
                   .Map(m =>
                   {
                       m.ToTable("MachineWorkstation");
                       m.MapLeftKey("MachineId");
                       m.MapRightKey("WorkstationId");
                   });
        }
    }
}
