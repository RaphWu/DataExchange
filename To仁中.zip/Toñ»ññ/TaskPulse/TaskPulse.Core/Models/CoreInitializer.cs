﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.Core.Models
{
    /********************
     * SqliteDropCreateDatabaseAlways // 每次執行都刪除並重建資料庫
     * SqliteCreateDatabaseIfNotExists // 如果資料庫不存在，則建立資料庫並初始化預設資料。
     * SqliteDropCreateDatabaseWhenModelChanges // 如果模型有變更，則刪除並重建資料庫。
     ********************/
    /// <summary>
    /// Code First 初始化類別。
    /// </summary>
    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
    public class CoreInitializer : SqliteCreateDatabaseIfNotExists<CoreContext>
    {
        public CoreInitializer(DbModelBuilder modelBuilder) : base(modelBuilder)
        {
        }

        protected override void Seed(CoreContext context)
        {
            int orderNo;

            orderNo = 0;
            var dep = context.Set<Department>();
            dep.Add(new Department() { OrderNo = ++orderNo, DepartmentName = "工具&設計課" });
            dep.Add(new Department() { OrderNo = ++orderNo, DepartmentName = "第一製造部" });
            dep.Add(new Department() { OrderNo = ++orderNo, DepartmentName = "組裝製造部" });

            orderNo = 0;
            var title = context.Set<Title>();
            title.Add(new Title() { OrderNo = ++orderNo, TitleName = "副理" });
            title.Add(new Title() { OrderNo = ++orderNo, TitleName = "課長" });
            title.Add(new Title() { OrderNo = ++orderNo, TitleName = "工程師" });
            title.Add(new Title() { OrderNo = ++orderNo, TitleName = "副工程師" });
            title.Add(new Title() { OrderNo = ++orderNo, TitleName = "組長" });
            title.Add(new Title() { OrderNo = ++orderNo, TitleName = "技術員" });

            context.SaveChanges();

            var emp = context.Set<Employee>();
            int empId = 8000;
            List<string> tmpNames = new List<string>() { "蔡孟堅", "鄭大德", "李起修", "葉柏均", "曾惠鈴" };
            foreach (var name in tmpNames)
            {
                emp.Add(new Employee()
                {
                    EmployeeId = empId++.ToString("D5"),
                    Name = name,
                    Department = dep.Local.FirstOrDefault(x => x.DepartmentName == "工具&設計課"),
                    Title = null,
                    IsEngineer = true
                });
            }

            tmpNames = new List<string>() { "蔡素貞", "張志榮", "賴惠珠", "侯倩玉", "李雅婷", "彭紹軒", "黎氏鳳", "阮碧幸", "盧海燕", "余沂霈", "楊瓊瑛" };
            foreach (var name in tmpNames)
            {
                emp.Add(new Employee()
                {
                    EmployeeId = empId++.ToString("D5"),
                    Name = name,
                    Department = dep.Local.FirstOrDefault(x => x.DepartmentName == "第一製造部"),
                    Title = null,
                });
            }

            tmpNames = new List<string>() { "陳寶琴", "劉名峻", "黃琪雯", "黃姿蓉", "林承翰", "雷舒涵", "黃嘉惠", "蔡素真", "黃玉紅", "許凱婷", "林昆達", "晉玉樹" };
            foreach (var name in tmpNames)
            {
                emp.Add(new Employee()
                {
                    EmployeeId = empId++.ToString("D5"),
                    Name = name,
                    Department = dep.Local.FirstOrDefault(x => x.DepartmentName == "組裝製造部"),
                    Title = null,
                });
            }

            context.SaveChanges();

            //var fLoc = context.Set<Factory>();
            //fLoc.Add(new Factory() { FactoryName = "本廠" });
            //fLoc.Add(new Factory() { FactoryName = "區北廠" });
            //fLoc.Add(new Factory() { FactoryName = "嘉義廠" });

            orderNo = 0;
            var dCategory = context.Set<MachineCategory>();
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo, CategoryName = "半自動生產設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo, CategoryName = "全自動生產設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo, CategoryName = "檢測設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo, CategoryName = "其他" });

            orderNo = 0;
            var dType = context.Set<MachineType>();
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "打壓機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "插入機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "斜點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "中壓斜點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "桌上型點膠機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "熔著機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "21039自動線" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "UV照射機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "氣密檢漏儀" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "鎖附機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "PF機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "儀科MTF機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "鬼影機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "鉚合機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo, TypeName = "切割機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "高度量測" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "自動組裝機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "自動整列機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "高速點膠機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "自動鎖附機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "三合一點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "貼膜設備" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "調芯機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo, TypeName = "拆解機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo, TypeName = "成形扭斷" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "氣密自動檢測機台" });

            orderNo = 0;
            var brand = context.Set<MachineBrand>();
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "自製" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "晟普" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "點膠科技" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "稼動科技" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "立璽(LIHSI)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "高興易" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "衫綺" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "勛凱" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "USHIO" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "KGN" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "MUSASHI" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "IEI(iwashitainstrumemt)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "九驊" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "儀科" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "客戶製" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "元利盛(EVEST)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "翔元(SYAUTO)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "瀚升" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, Name = "儀銳" });

            orderNo = 0;
            var cond = context.Set<MachineStatus>();
            cond.Add(new MachineStatus() { OrderNo = ++orderNo, Status = "稼動中" });
            cond.Add(new MachineStatus() { OrderNo = ++orderNo, Status = "停動中" });
            cond.Add(new MachineStatus() { OrderNo = ++orderNo, Status = "檢討室" });
            cond.Add(new MachineStatus() { OrderNo = ++orderNo, Status = "RD檢討室" });
            cond.Add(new MachineStatus() { OrderNo = ++orderNo, Status = "微小倉庫" });
            cond.Add(new MachineStatus() { OrderNo = ++orderNo, Status = "試作線上" });

            var model = context.Set<Model>();
            model.Add(new Model() { ModelName = "其他" });
            model.Add(new Model() { ModelName = "155" });
            model.Add(new Model() { ModelName = "260" });
            model.Add(new Model() { ModelName = "271" });
            model.Add(new Model() { ModelName = "273" });
            model.Add(new Model() { ModelName = "281" });
            model.Add(new Model() { ModelName = "283" });
            model.Add(new Model() { ModelName = "366" });
            model.Add(new Model() { ModelName = "453" });
            model.Add(new Model() { ModelName = "459" });
            model.Add(new Model() { ModelName = "467" });
            model.Add(new Model() { ModelName = "561" });
            model.Add(new Model() { ModelName = "563" });
            model.Add(new Model() { ModelName = "568" });
            model.Add(new Model() { ModelName = "570" });
            model.Add(new Model() { ModelName = "575" });
            model.Add(new Model() { ModelName = "585" });
            model.Add(new Model() { ModelName = "19008" });
            model.Add(new Model() { ModelName = "20006" });
            model.Add(new Model() { ModelName = "20007" });
            model.Add(new Model() { ModelName = "20019" });
            model.Add(new Model() { ModelName = "20056" });
            model.Add(new Model() { ModelName = "21018" });
            model.Add(new Model() { ModelName = "21028" });
            model.Add(new Model() { ModelName = "21039" });
            model.Add(new Model() { ModelName = "22001" });
            model.Add(new Model() { ModelName = "23010" });
            model.Add(new Model() { ModelName = "23021" });
            model.Add(new Model() { ModelName = "23069" });
            model.Add(new Model() { ModelName = "23070" });
            model.Add(new Model() { ModelName = "23071" });
            model.Add(new Model() { ModelName = "23073" });
            model.Add(new Model() { ModelName = "24301" });
            model.Add(new Model() { ModelName = "132-07" });
            model.Add(new Model() { ModelName = "19003-04" });
            model.Add(new Model() { ModelName = "19003-06" });
            model.Add(new Model() { ModelName = "20007-AS2" });
            model.Add(new Model() { ModelName = "20007-AS3" });
            model.Add(new Model() { ModelName = "417-01" });
            model.Add(new Model() { ModelName = "417-02" });
            model.Add(new Model() { ModelName = "568-02" });

            context.SaveChanges();

            try
            {
                var machines = context.Set<Machine>();

                //var machineName = context.Set<MachineNames>();
                var machineName = new HashSet<(string Model, string TypeName)>(context.MachineNames
                    .Include(d => d.MachineType)
                    .Include(d => d.MachineType.Category)
                    .Select(d => new { d.ModelName, d.MachineType.TypeName })
                    .AsEnumerable()
                    .Select(x => (x.ModelName, x.TypeName))
                    );

                //var factory = new HashSet<(string Factory, string Location)>(context.MachineLocations
                //    .Include(d => d.Factory)
                //    .Select(d => new { d.Factory.FactoryName, d.Location })
                //    .AsEnumerable()
                //    .Select(x => (x.FactoryName, x.Location))
                //    );
                ////var factory = context.Set<MachineLocation>();

                var assCode = context.Set<MachineAssetCode>();
                var mLoc = context.Set<MachineLocation>();

                int recCount = 0;
                orderNo = 0;
                // 一對多
                using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                {
                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var type = data[1].Trim();
                            var mName = data[3].Trim();
                            var dKey = (mName, type);
                            if (!machineName.Contains(dKey))
                            {
                                var device = new MachineName
                                {
                                    MachineType = dType.FirstOrDefault(x => x.TypeName == type),
                                    ModelName = mName,
                                };

                                context.MachineNames.Add(device);
                                machineName.Add(dKey);
                            }

                            //if (machineName.Local.FirstOrDefault(x => x.ModelName == mName && x.MachineType.TypeName == type) == null)
                            //{
                            //    machineName.Add(new MachineNames()
                            //    {
                            //        MachineType = dType.FirstOrDefault(x => x.TypeName == type),
                            //        ModelName = mName,
                            //    });
                            //}

                            var loc = $"{data[6].Trim()}, {data[7].Trim()}";
                            var oLoc = mLoc.FirstOrDefault(x => x.Location == loc);
                            if (oLoc == null)
                            {
                                mLoc.Add(new MachineLocation { Location = loc, OrderNo = ++orderNo });
                                context.SaveChanges();
                            }

                            //if (!factory.Contains(fKey))
                            //{
                            //    var newLoc = new MachineLocation
                            //    {
                            //        Factory = fLoc.FirstOrDefault(x => x.FactoryName == fac),
                            //        Location = loc,
                            //    };

                            //    context.MachineLocations.Add(newLoc);
                            //    factory.Add(fKey);
                            //}

                            //if (factory.FirstOrDefault(x => x.Location == loc && x.Factory.FactoryName == fac) == null)
                            //{
                            //    factory.Add(new MachineLocation()
                            //    {
                            //        Factory = fLoc.FirstOrDefault(x => x.FactoryName == fac),
                            //        Location = loc,
                            //    });
                            //}
                        }
                    }
                    context.SaveChanges();
                }

                // Machines
                using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                {
                    recCount = 0;
                    orderNo = 0;
                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var machine = new Machine();

                            string deviceId = data[0].Trim();
                            machine.MachineId = deviceId;

                            var type = data[1].Trim();
                            var mName = data[3].Trim();
                            var mn = context.MachineNames.FirstOrDefault(x => x.ModelName == mName && x.MachineType.TypeName == type);
                            if (mn != null)
                            {
                                machine.MachineName = mn;
                            }

                            var bName = data[2].Trim();
                            machine.Brand = brand.FirstOrDefault(x => x.Name == bName);
                            machine.SerialNumber = data[4].Trim();

                            if (data[5].StartsWith("\""))
                                data[5] = data[5].Substring(1, data[5].Length - 2);
                            var assets = data[5].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                            .Select(x => x.Trim())
                                            .Where(x => x != "無" && !string.IsNullOrWhiteSpace(x))
                                            .Distinct()
                                            .ToList();
                            machine.Assets = new List<MachineAssetCode>();
                            foreach (var a in assets)
                            {
                                machine.Assets.Add(new MachineAssetCode() { Code = a });
                            }

                            var loc = $"{data[6].Trim()}, {data[7].Trim()}";
                            var mmLoc = context.MachineLocations.FirstOrDefault(x => x.Location == loc);
                            if (mmLoc != null)
                            {
                                mmLoc.OrderNo = ++orderNo;
                                machine.Location = mmLoc;
                            }

                            var cnd = data[8].Trim();
                            machine.Status = cond.FirstOrDefault(x => x.Status == cnd);
                            machine.Barcode = data[9].Trim();
                            machine.Connected = !string.IsNullOrWhiteSpace(data[10].Trim());
                            machine.Remark = data[11].Trim();

                            machines.Add(machine);
                        }
                    }

                    var t = machines.FirstOrDefault(x => x.MachineId == "SAL-1");
                    if (t != null)
                        t.Disposal = true;
                    context.SaveChanges();
                }

                var wss = context.Set<Workstation>();
                using (var sr = new StreamReader("設備維修履歷_Import.txt", Encoding.Default))
                {
                    recCount = 0;
                    orderNo = 0;
                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            Model thisModel = null;
                            if (!string.IsNullOrWhiteSpace(data[15]))
                            {
                                string moData = data[15].Trim();
                                thisModel = model.FirstOrDefault(x => x.ModelName == moData);
                            }

                            if (!string.IsNullOrWhiteSpace(data[16]))
                            {
                                var wsData = data[16].Trim();
                                var ws = wss.FirstOrDefault(x => x.WorkstationName == wsData);
                                if (ws == null)
                                {
                                    ws = new Workstation()
                                    {
                                        WorkstationName = wsData,
                                        Model = thisModel,
                                        OrderNo = ++orderNo,
                                    };
                                    wss.Add(ws);
                                    context.SaveChanges();
                                }
                            }
                        }
                    }

                    context.SaveChanges();
                }
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    Console.WriteLine($"Entity of dType '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                    }
                }

                throw; // 若你要繼續丟出錯誤
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            base.Seed(context);
        }
    }
}
