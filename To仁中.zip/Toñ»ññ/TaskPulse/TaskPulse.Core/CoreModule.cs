﻿using Autofac;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Service;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // dialog
            builder.RegisterType<UserLogin>().PropertiesAutowired();
            builder.RegisterType<FlowLayoutSelector>().PropertiesAutowired();

            // views
            builder.RegisterType<SetupPage>().PropertiesAutowired();

            // service
            builder.RegisterType<DialogService>().InstancePerLifetimeScope().SingleInstance();
            builder.RegisterType<CoreService>().As<ICore>().SingleInstance();
            builder.RegisterType<AuthorityService>().As<IAuthority>().SingleInstance();

            // public data
            builder.RegisterType<CoreData>().SingleInstance();
            builder.RegisterType<CurrentAuthority>().SingleInstance();
            builder.RegisterType<AuthorityParameters>().SingleInstance();

            // DbContext
            builder.RegisterType<CoreContext>().InstancePerDependency();
            builder.RegisterType<CoreInitializer>().As<IStartable>().SingleInstance();

            builder.RegisterBuildCallback(c =>
            {
                var core = c.Resolve<ICore>();
                core.Initialize();
            });
        }
    }
}
