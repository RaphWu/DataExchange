﻿using System.Collections.Generic;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Contract
{
    public interface ICore
    {
        /// <summary>
        /// CoreService 初始化。
        /// </summary>
        void Initialize();

        /// <summary>
        /// 從資料庫更新核心資料。
        /// </summary>
        void UpdateCoreDataFromDb();

        /// <summary>
        /// 排序機台編號。
        /// </summary>
        /// <param name="machineIds">機台編號列表。</param>
        /// <returns>排序完成的機台編號。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Machines"/></remarks>
        List<string> SortMachineId(List<string> machineIds);

        /// <summary>
        /// 排序機種編號。
        /// </summary>
        /// <param name="machineIds">機台編種列表。</param>
        /// <returns>排序完成的機種編號。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Models"/></remarks>
        List<string> SortModelNames(List<string> modelNames);
    }
}
