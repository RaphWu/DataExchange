﻿namespace Calin.TaskPulse.Core.Authority
{
    /// <summary>
    /// 使用者資料 (Dialog用)。
    /// </summary>
    public class DialogInfo
    {
        public string Title { get; set; }

        public string OldName { get; set; }
        public string NewName { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }

        public string OldNameCaption { get; set; }
        public string NewNameCaption { get; set; }
        public string OldPasswordCaption { get; set; }
        public string NewPasswordCaption { get; set; }
    }
}
