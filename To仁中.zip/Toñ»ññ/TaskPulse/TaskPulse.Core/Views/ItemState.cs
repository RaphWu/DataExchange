﻿namespace Calin.TaskPulse.Core.Views
{
    public class ItemState
    {
        public bool IsChecked { get; set; }
        public string Name { get; set; }
    }
}
