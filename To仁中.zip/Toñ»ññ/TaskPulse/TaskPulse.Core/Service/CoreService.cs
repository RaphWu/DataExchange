﻿using System.Linq;
using System.Text.RegularExpressions;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Service
{
    public class CoreService : ICore
    {
        private readonly CoreContext _coreContext;
        private readonly CoreData _coreData;
        private bool _isInitialized = false;

        public CoreService(CoreContext coreContext, CoreData coreData)
        {
            _coreContext = coreContext;
            _coreData = coreData;
        }

        public void Initialize()
        {
            if (_isInitialized)
                return;

            UpdateCoreDataFromDb();
            _isInitialized = true;
        }

        /// <inheritdoc/>
        public void UpdateCoreDataFromDb()
        {
            _coreData.Employees = _coreContext.Employees
                .OrderBy(x => x.EmployeeId)
                .ToList();

            _coreData.Machines = _coreContext.Machines
                 .Include("MachineName")
                 .Include("MachineName.Type")
                 .Include("Brand")
                 .Include("Assets")
                 .Include("Location")
                 .Include("Location.Factory")
                 .Include("Condition")
                 .ToList();
            _coreData.Machines = _coreData.Machines
                 .Select(s =>
                 {
                     // 擷取格式：「文字 + 可選 dash + 數字」
                     var match = Regex.Match(s.MachineId, @"^([^\d\-]+)-?(\d+)$", RegexOptions.IgnoreCase);
                     string textPart = match.Success ? match.Groups[1].Value : s.MachineId;
                     int numberPart = (match.Success && int.TryParse(match.Groups[2].Value, out int n)) ? n : int.MaxValue;
                     return new
                     {
                         Original = s,
                         Text = textPart.ToLowerInvariant(), // 忽略大小寫排序
                         Number = numberPart                  // 確保是 int，不是 string
                     };
                 })
                .OrderBy(x => x.Text)
                .ThenBy(x => x.Number)
                .Select(x => x.Original)
                .ToList();

            _coreData.Models = _coreContext
                .Models.OrderBy(x => x.ModelId)
                .ToList();

            StrongReferenceMessenger.Default.Send(CoreDataChangedNotification.Instance);
        }
    }
}
