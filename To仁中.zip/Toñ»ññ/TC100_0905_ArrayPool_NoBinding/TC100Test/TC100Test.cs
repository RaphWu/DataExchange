﻿//using RJCP.IO.Ports;
using System;
using System.IO.Ports;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TC100Test
{
    public partial class TC100Test : Form
    {
        private CancellationTokenSource _cts;
        private ToyoSingleCylinder.ToyoSingleCylinder _tsc;

        public TC100Test()
        {
            InitializeComponent();
        }

        #region Utility

        private void SetControlEnabled(bool isConnected)
        {
            button_Connect.InvokeIfRequired(() =>
            {
                button_Connect.Enabled = !isConnected;
                groupBox_SerialPort.Enabled = !isConnected;
                groupBox_Cylinder.Enabled = !isConnected;

                //tabControl_Action.Enabled = isConnected;
                button_Disconnct.Enabled = isConnected;
                panel_Test.Enabled = isConnected;
            });
        }

        /// <summary>
        /// 更新 Serial Port 選擇器。
        /// </summary>
        private void UpdateSerialPortParamsSelector()
        {
            SerialPort serial = new SerialPort();

            string[] portNameList = SerialPort.GetPortNames();
            Array.Sort(portNameList);
            comboBox_COM.Items.Clear();
            comboBox_COM.Items.AddRange(portNameList);
            comboBox_COM.SelectedIndex = 0;

            comboBox_BaudRate.Items.Clear();
            comboBox_BaudRate.Items.AddRange((new int[] { 2400, 4800, 9600, 19200, 38400, 57600, 115200 }).Cast<object>().ToArray());
            comboBox_BaudRate.SelectedItem = 19200;

            comboBox_Parity.Items.Clear();
            comboBox_Parity.Items.AddRange(Enum.GetValues(typeof(Parity)).Cast<object>().ToArray());
            comboBox_Parity.SelectedItem = Parity.None;

            textBox_DataBits.Text = "8";

            comboBox_StopBits.Items.Clear();
            comboBox_StopBits.Items.AddRange(Enum.GetValues(typeof(StopBits)).Cast<object>().ToArray());
            comboBox_StopBits.SelectedItem = StopBits.One;
        }

        #endregion

        private void TC100Test_Load(object sender, EventArgs e)
        {
            SetControlEnabled(false);
            UpdateSerialPortParamsSelector();
            timer_ScreenUpdate.Start();

            //bs.DataSource = typeof(ToyoSingleCylinder.ToyoSingleCylinder);

            //            /***** Data Binding *****/
            //            // Control
            //            numericUpDown_AbsMove.DataBindings.Add("Minimum", textBox_MinStroke, "Text", true, DataSourceUpdateMode.OnPropertyChanged);
            //            numericUpDown_AbsMove.DataBindings.Add("Maximum", textBox_MaxStroke, "Text", true, DataSourceUpdateMode.OnPropertyChanged);
            //            trackBar_AbsMove.DataBindings.Add("Minimum", textBox_MinStroke, "Text", true, DataSourceUpdateMode.OnPropertyChanged);
            //            trackBar_AbsMove.DataBindings.Add("Maximum", textBox_MaxStroke, "Text", true, DataSourceUpdateMode.OnPropertyChanged);
            //            numericUpDown_AbsMove.DataBindings.Add("Value", trackBar_AbsMove, "Value", false, DataSourceUpdateMode.OnPropertyChanged);

            //            //// Cylinder狀態
            //            //textBox_ServoStatus.DataBindings.Add("Text", bs, nameof(_tsc.ServoStatusMessage));
            //            //button_ServoSwitch.DataBindings.Add("Text", bs, nameof(_tsc.ServoStatusMessage));
            //            //textBox_MotorStatus.DataBindings.Add("Text", bs, nameof(_tsc.ActionStatusMessage));
            //            //textBox_InpStatus.DataBindings.Add("Text", bs, nameof(_tsc.InpStatusMessage));
            //            //textBox_TrqLmtStatus.DataBindings.Add("Text", bs, nameof(_tsc.TrqLmtStatusMessage));
            //            //textBox_MotorAlarm.DataBindings.Add("Text", bs, nameof(_tsc.AlarmStatusMessage));
            //            //textBox_ErrorStatus.DataBindings.Add("Text", bs, nameof(_tsc.ErrorStatusMessage));
            //            //textBox_MotorRPM.DataBindings.Add("Text", bs, nameof(_tsc.MonRpm));
            //            //textBox_MotorCurrent.DataBindings.Add("Text", bs, nameof(_tsc.MonCurrent), true, DataSourceUpdateMode.OnPropertyChanged, null, "0.0");
            //            //textBox_MotorCommandPos.DataBindings.Add("Text", bs, nameof(_tsc.CmdNowPos), true, DataSourceUpdateMode.OnPropertyChanged, null, "0.00");
            //            //textBox_MotorCurrentPos.DataBindings.Add("Text", bs, nameof(_tsc.EcdPos), true, DataSourceUpdateMode.OnPropertyChanged, null, "0.00");

            //            //// Port Out
            //            //checkBox_PortOut01.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut01));
            //            //checkBox_PortOut02.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut02));
            //            //checkBox_PortOut03.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut03));
            //            //checkBox_PortOut04.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut04));
            //            //checkBox_PortOut05.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut05));
            //            //checkBox_PortOut06.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut06));
            //            //checkBox_PortOut07.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut07));
            //            //checkBox_PortOut08.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut08));
            //            //checkBox_PortOut09.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut09));
            //            //checkBox_PortOut10.DataBindings.Add("Checked", bs, nameof(_tsc.PortOutStatus.PortOut10));

            //            //// Port In
            //            //checkBox_PortIn01.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn01));
            //            //checkBox_PortIn02.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn02));
            //            //checkBox_PortIn03.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn03));
            //            //checkBox_PortIn04.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn04));
            //            //checkBox_PortIn05.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn05));
            //            //checkBox_PortIn06.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn06));
            //            //checkBox_PortIn07.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn07));
            //            //checkBox_PortIn08.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn08));
            //            //checkBox_PortIn09.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn09));
            //            //checkBox_PortIn10.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn10));
            //            //checkBox_PortIn11.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn11));
            //            //checkBox_PortIn12.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn12));
            //            //checkBox_PortIn13.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn13));
            //            //checkBox_PortIn14.DataBindings.Add("Checked", bs, nameof(_tsc.PortInStatus.PortIn14));

            //            //// ExceuteTime
            //            //textBox_ExceuteTime.DataBindings.Add("Text", bs, nameof(_tsc.ExceuteTime), true, DataSourceUpdateMode.OnPropertyChanged, null, "0");

            //            // Cylinder狀態
            //            textBox_ServoStatus.DataBindings.Add("Text", bs, "ServoStatusMessage");
            //            button_ServoSwitch.DataBindings.Add("Text", bs, "ServoStatusMessage");
            //            textBox_MotorStatus.DataBindings.Add("Text", bs, "ActionStatusMessage");
            //            textBox_InpStatus.DataBindings.Add("Text", bs, "InpStatusMessage");
            //            textBox_TrqLmtStatus.DataBindings.Add("Text", bs, "TrqLmtStatusMessage");
            //            textBox_MotorAlarm.DataBindings.Add("Text", bs, "AlarmStatusMessage");
            //            textBox_ErrorStatus.DataBindings.Add("Text", bs, "ErrorStatusMessage");
            //            textBox_MotorRPM.DataBindings.Add("Text", bs, "MonRpm");
            //            textBox_MotorCurrent.DataBindings.Add("Text", bs, "MonCurrent", true, DataSourceUpdateMode.OnPropertyChanged, null, "0.0");
            //            textBox_MotorCommandPos.DataBindings.Add("Text", bs, "CmdNowPos", true, DataSourceUpdateMode.OnPropertyChanged, null, "0.00");
            //            textBox_MotorCurrentPos.DataBindings.Add("Text", bs, "EcdPos", true, DataSourceUpdateMode.OnPropertyChanged, null, "0.00");

            //            // Port Out
            //            checkBox_PortOut01.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut01");
            //            checkBox_PortOut02.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut02");
            //            checkBox_PortOut03.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut03");
            //            checkBox_PortOut04.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut04");
            //            checkBox_PortOut05.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut05");
            //            checkBox_PortOut06.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut06");
            //            checkBox_PortOut07.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut07");
            //            checkBox_PortOut08.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut08");
            //            checkBox_PortOut09.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut09");
            //            checkBox_PortOut10.DataBindings.Add("Checked", bs, "PortOutStatus.PortOut10");

            //            // Port In
            //            checkBox_PortIn01.DataBindings.Add("Checked", bs, "PortInStatus.PortIn01");
            //            checkBox_PortIn02.DataBindings.Add("Checked", bs, "PortInStatus.PortIn02");
            //            checkBox_PortIn03.DataBindings.Add("Checked", bs, "PortInStatus.PortIn03");
            //            checkBox_PortIn04.DataBindings.Add("Checked", bs, "PortInStatus.PortIn04");
            //            checkBox_PortIn05.DataBindings.Add("Checked", bs, "PortInStatus.PortIn05");
            //            checkBox_PortIn06.DataBindings.Add("Checked", bs, "PortInStatus.PortIn06");
            //            checkBox_PortIn07.DataBindings.Add("Checked", bs, "PortInStatus.PortIn07");
            //            checkBox_PortIn08.DataBindings.Add("Checked", bs, "PortInStatus.PortIn08");
            //            checkBox_PortIn09.DataBindings.Add("Checked", bs, "PortInStatus.PortIn09");
            //            checkBox_PortIn10.DataBindings.Add("Checked", bs, "PortInStatus.PortIn10");
            //            checkBox_PortIn11.DataBindings.Add("Checked", bs, "PortInStatus.PortIn11");
            //            checkBox_PortIn12.DataBindings.Add("Checked", bs, "PortInStatus.PortIn12");
            //            checkBox_PortIn13.DataBindings.Add("Checked", bs, "PortInStatus.PortIn13");
            //            checkBox_PortIn14.DataBindings.Add("Checked", bs, "PortInStatus.PortIn14");

            //            // ExceuteTime
            //            textBox_ExceuteTime.DataBindings.Add("Text", bs, "ExceuteTime.TotalSeconds", true, DataSourceUpdateMode.OnPropertyChanged, null, "0");

            //#if DEBUG
            //            label_RequestMessage.DataBindings.Add("Text", bs, "DebugMessage.RequestFrame");
            //            label_ResponseMessage.DataBindings.Add("Text", bs, "DebugMessage.ResponseFrame");
            //            label_ConsoleMessage.DataBindings.Add("Text", bs, "DebugMessage.ConsoleMessage");
            //            label_ErrorMessage.DataBindings.Add("Text", bs, "DebugMessage.ErrorMessage");
            //#endif
        }

        private void TC100Test_FormClosing(object sender, FormClosingEventArgs e)
        {
            //            // Cylinder狀態
            //            textBox_ServoStatus.DataBindings.Clear();
            //            button_ServoSwitch.DataBindings.Clear();
            //            textBox_MotorStatus.DataBindings.Clear();
            //            textBox_InpStatus.DataBindings.Clear();
            //            textBox_TrqLmtStatus.DataBindings.Clear();
            //            textBox_MotorAlarm.DataBindings.Clear();
            //            textBox_ErrorStatus.DataBindings.Clear();
            //            textBox_MotorRPM.DataBindings.Clear();
            //            textBox_MotorCurrent.DataBindings.Clear();
            //            textBox_MotorCommandPos.DataBindings.Clear();
            //            textBox_MotorCurrentPos.DataBindings.Clear();

            //            // Port Out
            //            checkBox_PortOut01.DataBindings.Clear();
            //            checkBox_PortOut02.DataBindings.Clear();
            //            checkBox_PortOut03.DataBindings.Clear();
            //            checkBox_PortOut04.DataBindings.Clear();
            //            checkBox_PortOut05.DataBindings.Clear();
            //            checkBox_PortOut06.DataBindings.Clear();
            //            checkBox_PortOut07.DataBindings.Clear();
            //            checkBox_PortOut08.DataBindings.Clear();
            //            checkBox_PortOut09.DataBindings.Clear();
            //            checkBox_PortOut10.DataBindings.Clear();

            //            // Port In
            //            checkBox_PortIn01.DataBindings.Clear();
            //            checkBox_PortIn02.DataBindings.Clear();
            //            checkBox_PortIn03.DataBindings.Clear();
            //            checkBox_PortIn04.DataBindings.Clear();
            //            checkBox_PortIn05.DataBindings.Clear();
            //            checkBox_PortIn06.DataBindings.Clear();
            //            checkBox_PortIn07.DataBindings.Clear();
            //            checkBox_PortIn08.DataBindings.Clear();
            //            checkBox_PortIn09.DataBindings.Clear();
            //            checkBox_PortIn10.DataBindings.Clear();
            //            checkBox_PortIn11.DataBindings.Clear();
            //            checkBox_PortIn12.DataBindings.Clear();
            //            checkBox_PortIn13.DataBindings.Clear();
            //            checkBox_PortIn14.DataBindings.Clear();

            //            // ExceuteTime
            //            textBox_ExceuteTime.DataBindings.Clear();

            //#if DEBUG
            //            label_RequestMessage.DataBindings.Clear();
            //            label_ResponseMessage.DataBindings.Clear();
            //            label_ConsoleMessage.DataBindings.Clear();
            //            label_ErrorMessage.DataBindings.Clear();
            //#endif
        }

        private void timer_ScreenUpdate_Tick(object sender, EventArgs e)
        {
            if (_tsc == null)
                return;

            // Cylinder狀態
            button_ServoSwitch.Text = _tsc.ServoStatusMessage;
            textBox_ServoStatus.Text = _tsc.ServoStatusMessage;
            textBox_MotorStatus.Text = _tsc.ActionStatusMessage;
            textBox_InpStatus.Text = _tsc.InpStatusMessage;
            textBox_TrqLmtStatus.Text = _tsc.TrqLmtStatusMessage;
            textBox_MotorAlarm.Text = _tsc.AlarmStatusMessage;
            textBox_ErrorStatus.Text = _tsc.ErrorStatusMessage;
            textBox_MotorRPM.Text = _tsc.MonRpm.ToString();
            textBox_MotorCurrent.Text = _tsc.MonCurrent.ToString("0.0");
            textBox_MotorCommandPos.Text = _tsc.CmdNowPos.ToString("0.00");
            textBox_MotorCurrentPos.Text = _tsc.EcdPos.ToString("0.00");

            // Port Out
            checkBox_PortOut01.Checked = _tsc.PortOutStatus.PortOut01;
            checkBox_PortOut02.Checked = _tsc.PortOutStatus.PortOut02;
            checkBox_PortOut03.Checked = _tsc.PortOutStatus.PortOut03;
            checkBox_PortOut04.Checked = _tsc.PortOutStatus.PortOut04;
            checkBox_PortOut05.Checked = _tsc.PortOutStatus.PortOut05;
            checkBox_PortOut06.Checked = _tsc.PortOutStatus.PortOut06;
            checkBox_PortOut07.Checked = _tsc.PortOutStatus.PortOut07;
            checkBox_PortOut08.Checked = _tsc.PortOutStatus.PortOut08;
            checkBox_PortOut09.Checked = _tsc.PortOutStatus.PortOut09;
            checkBox_PortOut10.Checked = _tsc.PortOutStatus.PortOut10;

            // Port In
            checkBox_PortIn01.Checked = _tsc.PortInStatus.PortIn01;
            checkBox_PortIn02.Checked = _tsc.PortInStatus.PortIn02;
            checkBox_PortIn03.Checked = _tsc.PortInStatus.PortIn03;
            checkBox_PortIn04.Checked = _tsc.PortInStatus.PortIn04;
            checkBox_PortIn05.Checked = _tsc.PortInStatus.PortIn05;
            checkBox_PortIn06.Checked = _tsc.PortInStatus.PortIn06;
            checkBox_PortIn07.Checked = _tsc.PortInStatus.PortIn07;
            checkBox_PortIn08.Checked = _tsc.PortInStatus.PortIn08;
            checkBox_PortIn09.Checked = _tsc.PortInStatus.PortIn09;
            checkBox_PortIn10.Checked = _tsc.PortInStatus.PortIn10;
            checkBox_PortIn11.Checked = _tsc.PortInStatus.PortIn11;
            checkBox_PortIn12.Checked = _tsc.PortInStatus.PortIn12;
            checkBox_PortIn13.Checked = _tsc.PortInStatus.PortIn13;
            checkBox_PortIn14.Checked = _tsc.PortInStatus.PortIn14;

            // ExceuteTime
            textBox_ExceuteTime.Text = _tsc.ExceuteTime.TotalSeconds.ToString("0");

#if DEBUG
            label_RequestMessage.Text = _tsc.DebugMessage.RequestFrame;
            label_ResponseMessage.Text = _tsc.DebugMessage.ResponseFrame;
            label_ConsoleMessage.Text = _tsc.DebugMessage.ConsoleMessage;
            label_ErrorMessage.Text = _tsc.DebugMessage.ErrorMessage;
#endif
        }

        private void button_UpdateSerialPortParams_Click(object sender, EventArgs e)
        {
            UpdateSerialPortParamsSelector();
        }

        private void button_Disconnct_Click(object sender, EventArgs e)
        {
            Disconnct();
        }

        private void Disconnct()
        {
            if (_tsc != null)
                _tsc.ClosePort();

            if (_cts != null)
            {
                if (!_cts.IsCancellationRequested)
                    _cts.Cancel();
                _cts.Dispose();
            }

            SetControlEnabled(false);
        }

        private void button_Connect_Click(object sender, EventArgs e)
        {
            _tsc = new ToyoSingleCylinder.ToyoSingleCylinder(
                       byte.Parse(textBox_Station.Text),
                       (string)comboBox_COM.SelectedItem,
                       int.Parse(comboBox_BaudRate.Text),
                       (Parity)comboBox_Parity.SelectedItem,
                       int.Parse(textBox_DataBits.Text),
                       (StopBits)comboBox_StopBits.SelectedItem);
            _tsc.OpenPort();
            if (_tsc.IsOpen)
            {
                //bs.DataSource = _tsc;

                if (_cts != null)
                {
                    if (!_cts.IsCancellationRequested)
                        _cts.Cancel();
                    _cts.Dispose();
                }
                _cts = new CancellationTokenSource();

                //_screenUpdateTask = Task.Factory.StartNew(() =>
                //{
                //    ScreenUpdatePolling(_cts.Token);
                //}, _cts.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
            }
            //else // 會遮蓋掉Lib內的訊息，所以先拿掉
            //{
            //    label_ErrorMessage.Text = "連線失敗！";
            //}

            SetControlEnabled(_tsc.IsOpen);
        }

        private async void checkBox_RepeatTest_CheckedChanged(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                Random rnd = new Random(DateTime.Now.Millisecond);
                double minStroke = double.Parse(textBox_MinStroke.Text);
                double maxStroke = double.Parse(textBox_MaxStroke.Text);

                try
                {
                    await Task.Run(async () =>
                    {
                        while (checkBox_RepeatTest.Checked)
                        {
                            double pos = Math.Round((rnd.NextDouble() * (maxStroke - minStroke)) + minStroke, 2);
                            int speed = rnd.Next(15, 50);

                            label_TestPos.InvokeIfRequired(() =>
                            {
                                label_TestPos.Text = string.Concat("位置: ", pos.ToString("N2"));
                                label_TestSpeed.Text = string.Concat("速度: ", speed.ToString(), "%");
                            });

                            await _tsc.AbsMove(pos, speed, 1);
                            await Task.Delay(150);
                        }
                    }, this._cts.Token);
                }
                catch (OperationCanceledException)
                {
                    checkBox_RepeatTest.InvokeIfRequired(() =>
                    {
                        checkBox_RepeatTest.Checked = false;
                    });
                }
                catch (Exception ex)
                {
                    _tsc.ClosePort();
                    Console.WriteLine(string.Concat("checkBox_RepeatTest_CheckedChanged Exception: ", ex.Message));
                }
            }
        }

        /// <summary>
        /// 復歸。
        /// </summary>
        private async void button_OriginReturn_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                await _tsc.OriginReturn();
            }
        }

        private async void checkBox_PortIn01_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                await _tsc.OriginReturn();
            }
        }

        private void checkBox_PortIn02_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                if (_tsc.PortOutStatus.PortOut04)
                    _tsc.ServoOn();
                else
                    _tsc.ServoOff();
            }
        }

        private void checkBox_PortIn03_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                _tsc.AlarmReset();
            }
        }

        private async void button_AbsMove_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                if (_tsc.EcdPos > 50.0)
                    await _tsc.AbsMove(10.0, 50, 1);
                else
                    await _tsc.AbsMove(100.0, 50, 1);
            }
        }

        private async void button_IncMoveP_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                await _tsc.IncMove(10.0, 30, 1);
            }
        }

        private async void button_IncMoveM_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                await _tsc.IncMove(-10.0, 30, 1);
            }
        }

        private void button_AlarmReset_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.AlarmReset();
            }
        }

        private void button_EmergencyStop_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.EmergencyStop();
                checkBox_RepeatTest.Checked = false;
            }
        }

        private void button_DeceleratesToStop_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.DeceleratesToStop();
                checkBox_RepeatTest.Checked = false;
            }
        }

        private void button_ServoSwitch_Click(object sender, EventArgs e)
        {
            if (_tsc.ServoStatus)
                _tsc.ServoOff();
            else
                _tsc.ServoOn();
        }
    }
}
