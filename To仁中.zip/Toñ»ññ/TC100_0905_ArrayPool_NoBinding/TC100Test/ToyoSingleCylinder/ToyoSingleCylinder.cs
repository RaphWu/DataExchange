﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;
using System.Threading.Tasks;
using System.Buffers;
//using RJCP.IO.Ports;

namespace ToyoSingleCylinder
{
    /// <summary>
    /// TOYO電動缸 單缸控制模組。
    /// </summary>
    public partial class ToyoSingleCylinder : BindableBase, IDisposable
    {
        private const int ONE_WORD = 4; // 1 Word = 4 bytes
        private const int TWO_WORD = 8; // 2 Words = 8 bytes

        private CancellationTokenSource _cts;
        private SerialPort _sp;
        //private SerialPortStream _sp;
        private readonly CylinderParams _cp;

        private readonly PortOutStatus _statusPortOut = new PortOutStatus();
        private readonly PortInStatus _statusPortIn = new PortInStatus();
#if DEBUG
        private readonly DebugMessage _debugMessage = new DebugMessage();
#endif

        private ConcurrentQueue<FrameStruct> _highPriorityQueue = new ConcurrentQueue<FrameStruct>(); // 最高優先權指令 Queue
        private ConcurrentQueue<FrameStruct> _retryQueue = new ConcurrentQueue<FrameStruct>();        // 指令重送 Queue
        private ConcurrentQueue<FrameStruct> _requestQueue = new ConcurrentQueue<FrameStruct>();      // 一般指令 Queue
        ArrayPool<byte> _pooledBuffer = ArrayPool<byte>.Shared;

        private Task _portAccessTask = null; // 負責 SerialPort 存取的執行緒
        private bool _pollingIsRunning = false;
        private bool _serialPortCloseRequest = false; // 當下Close指令時，要先等待Polling結束

        private string _requestString = string.Empty;
        private string _responseString = string.Empty;

        private DateTime _startRunningTime;

        private readonly List<string> _errorHistories = null; // 錯誤履歷

        /// <summary>
        /// 請求發送暫停。
        /// </summary>
        /// <remarks>當有指令發送失敗須重送時，此 Flag 會 ON。此時 HighPriorityQueue 仍不會停，但 RequestQueue 會停止發送。</remarks>
        private bool _requestHolding = false;

        #region ctor

        /// <summary>
        /// TOYO 電動缸 (單缸)。
        /// </summary>
        /// <param name="station">站號。</param>
        /// <param name="portName">Serial Port 名稱。</param>
        /// <param name="baudRate">BaudRate 鮑率。</param>
        /// <param name="parity">Parity 同位位元。</param>
        /// <param name="dataBits">DataBits 資料位元。</param>
        /// <param name="stopBits">StopBits 停止位元。</param>
        /// <param name="minStroke">電動缸最小行程。</param>
        /// <param name="maxStroke">電動缸最大行程。</param>
        public ToyoSingleCylinder(byte station,
                                  string portName,
                                  int baudRate,
                                  Parity parity,
                                  int dataBits,
                                  StopBits stopBits)
        {
            _cp = new CylinderParams()
            {
                Station = station,
                RetryTimes = 5,
            };

            _sp = new SerialPort()
            {
                PortName = portName,
                BaudRate = baudRate,
                DataBits = dataBits,
                StopBits = stopBits,
                Parity = parity,
                ReadTimeout = 500,
                WriteTimeout = 500,
            };

            InMotion = false;

#if DEBUG
            _debugMessage.ConsoleMessage = "No Message.";
            _debugMessage.ErrorMessage = "No Error!";
#endif
        }

        #endregion

        #region Serial Port Open/Close

        /// <summary>
        /// 關閉電動缸。
        /// </summary>
        public async void ClosePort()
        {
            try
            {
                _serialPortCloseRequest = true;

                while (_pollingIsRunning)
                    await Task.Delay(5);

                // .net framework 的 ConcurrentQueue 沒有 Clear()，所以改用 new
                //_highPriorityQueue.Clear();
                //_retryQueue.Clear();
                //_requestQueue.Clear();
                _highPriorityQueue = new ConcurrentQueue<FrameStruct>();
                _retryQueue = new ConcurrentQueue<FrameStruct>();
                _requestQueue = new ConcurrentQueue<FrameStruct>();

                if (_cts != null)
                {
                    if (!_cts.IsCancellationRequested)
                        _cts.Cancel();
                    _cts.Dispose();
                }

                _portAccessTask = null;

#if DEBUG
                _debugMessage.ConsoleMessage = "正在關閉電動缸，請稍候再連線！";
#endif
                if (_sp != null)
                {
                    if (_sp.IsOpen)
                        _sp.Close();
                    _sp.Dispose();
                }

                await Task.Delay(500);

#if DEBUG
                _debugMessage.ConsoleMessage = "電動缸已關閉！";
#endif
            }
            catch (Exception ex)
            {
                string eMsg = String.Concat("Serial Port 關閉異常: ", ex.Message);
                Console.WriteLine(eMsg);
#if DEBUG
                _debugMessage.ErrorMessage = eMsg;
#endif
            }
            finally
            {
                //NotifyPropertyChanged(nameof(IsOpen));
                NotifyPropertyChanged("IsOpen");
            }
        }

        /// <summary>
        /// 開啟電動缸。
        /// </summary>
        public void OpenPort()
        {
            try
            {
                _serialPortCloseRequest = false;

                if (!_sp.IsOpen)
                {
                    if (_cts != null)
                    {
                        if (!_cts.IsCancellationRequested)
                            _cts.Cancel();
                        _cts.Dispose();
                    }
                    _cts = new CancellationTokenSource();

                    _sp.Open();
                    if (_sp.IsOpen)
                    {
                        HighPriorityRequest(CallerId.Initializer, ":0110999B0004084C7630315479566702\r\n"); // 開通電動缸權限

                        //_portAccessTask = Task.Factory.StartNew(() =>
                        //{
                        //    try
                        //    {
                        //        PortAccessPolling(_cts.Token).GetAwaiter().GetResult();
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        Console.WriteLine(String.Concat("PortAccessPolling 發生錯誤: ", ex));
                        //    }
                        //}, _cts.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);

                        _portAccessTask = Task.Factory.StartNew(() =>
                        {
                            PortAccessPolling(_cts.Token);
                        }, _cts.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);

                        _startRunningTime = DateTime.Now;
                    }
                }
            }
            catch (Exception ex)
            {
                string eMsg = String.Concat("Serial Port 開啟異常: ", ex.Message);
                Console.WriteLine(eMsg);
#if DEBUG
                _debugMessage.ErrorMessage = eMsg;
#endif
            }
            finally
            {
                //NotifyPropertyChanged(nameof(IsOpen));
                NotifyPropertyChanged("IsOpen");
            }
        }

        #endregion

        public void Dispose()
        {
            if (_cts != null)
            {
                if (!_cts.IsCancellationRequested)
                    _cts.Cancel();
                _cts.Dispose();
            }

            if (_sp.IsOpen)
                _sp.Close();
            _sp.Dispose();
            _sp = null;
        }
    }
}
