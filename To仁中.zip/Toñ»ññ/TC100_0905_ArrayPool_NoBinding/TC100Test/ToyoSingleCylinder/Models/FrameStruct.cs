﻿namespace ToyoSingleCylinder
{
    internal struct FrameStruct
    {
        internal CallerId CallerId { get; set; }
        internal byte[] ByteArray { get; set; }
    }
}
