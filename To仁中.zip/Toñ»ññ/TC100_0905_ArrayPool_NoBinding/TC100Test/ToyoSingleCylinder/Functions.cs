﻿namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 伺服 ON。
        /// </summary>
        public void ServoOn()
        {
            SendRequestFrame(CallerId.Command, GetRequestFrame(0x06, 0x2011, 0));
        }

        /// <summary>                                           
        /// 伺服 OFF。                                          
        /// </summary>                                          
        public void ServoOff()
        {
            SendRequestFrame(CallerId.Command, GetRequestFrame(0x06, 0x2011, 1));
        }

        /// <summary>                                           
        /// 警報重置。                                           
        /// </summary>                                          
        public void AlarmReset()
        {
            SendRequestFrame(CallerId.Command, GetRequestFrame(0x06, 0x201E, 6));
        }
    }
}
