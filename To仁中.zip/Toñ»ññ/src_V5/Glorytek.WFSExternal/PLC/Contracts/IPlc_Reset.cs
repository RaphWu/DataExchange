﻿namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - 復歸與重置處理。
/// </summary>
public interface IPlc_Reset
{
    /// <summary>
    /// 原點復歸。
    /// </summary>
    void HomeReturn();

    /// <summary>
    /// 單軸原點復歸 - X軸。
    /// </summary>
    void HomeReturnXAxis();

    /// <summary>
    /// 單軸原點復歸 - Y軸。
    /// </summary>
    void HomeReturnYAxis();

    /// <summary>
    /// PLC重置。
    /// </summary>
    void PlcReset();
}
