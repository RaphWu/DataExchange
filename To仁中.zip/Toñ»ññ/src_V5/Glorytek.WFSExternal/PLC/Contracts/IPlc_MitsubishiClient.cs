﻿namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - MC協議繼承與擴充。
/// </summary>
public interface IPlc_MitsubishiClient
{
    /****************************************
     * 讀寫主函數
     ****************************************/
    /// <summary>
    /// 連續軟元件的資料讀取。
    /// </summary>
    /// <param name="address">讀取資料的起始軟元件。</param>
    /// <param name="length">讀取的資料長度。<br/>資料為bool: 1個bytes包含2個軟元件，High byte及Low byte各代表一個軟元件。<br/>資料為非bool: 一筆資料以2 bytes為單位的byte[]。</param>
    /// <param name="isBit">資料類型是否以bit為單位？</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, byte[] responseMessages) Read(string address, int length, bool isBit);

    /// <summary>
    /// 連續軟元件的資料讀取 (以Word為單位)。
    /// </summary>
    /// <param name="address">讀取資料的起始軟元件。</param>
    /// <param name="length">讀取的資料長度。<br/>一筆資料以2 bytes為單位的byte[]。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, byte[] responseMessages) Read(string address, int length);

    /// <summary>
    /// 隨機軟元件位址的資料讀取 (以Word為單位)。
    /// </summary>
    /// <param name="wordAddress">Word資料的軟元件列表，列表長度即讀取資料數，每筆資料讀取的byte數為2 bytes。</param>
    /// <param name="dwordAddress">DWord資料的軟元件列表，列表長度即讀取資料數，每筆資料讀取的byte數為4 bytes。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, byte[] responseMessages) Read(string[] wordAddress, string[] dwordAddress);

    /// <summary>
    /// 寫入連續資料至PLC。
    /// </summary>
    /// <param name="address">寫入資料的起始軟元件。</param>
    /// <param name="data">寫入的資料表。<br/>資料為bool: 1個bytes包含2個軟元件，High byte及Low byte各代表一個軟元件。<br/>資料為非bool: 一筆資料以2 bytes為單位的byte[]。</param>
    /// <param name="length">寫入的軟元件數。</param>
    /// <param name="isBit">資料類型是否以bit為單位？</param>
    /// <returns>寫入是否成功。</returns>
    public bool Write(string address, byte[] data, int length, bool isBit);

    /// <summary>
    /// 寫入連續資料至PLC (以Word為單位)。
    /// </summary>
    /// <param name="address">寫入資料的起始軟元件。</param>
    /// <param name="data">寫入的資料表，一筆資料以2 bytes為單位的byte[]。</param>
    /// <param name="length">寫入的軟元件數。</param>
    /// <returns>寫入是否成功。</returns>
    public bool Write(string address, byte[] data, int length);

    /// <summary>
    /// 隨機軟元件位址的資料寫入。
    /// </summary>
    /// <param name="wordAddress">Word資料的軟元件列表。</param>
    /// <param name="wordValues">Word資料表。<br/>byte[]格式，一筆資料占2 bytes。</param>
    /// <param name="dwordAddress">DWord資料的軟元件列表。</param>
    /// <param name="dwordValues">DWord資料表。<br/>byte[]格式，一筆資料占4 bytes。</param>
    /// <param name="isBit">資料類型是否以bit為單位？</param>
    /// <returns>寫入是否成功。</returns>
    public bool Write(string[] wordAddress, byte[] wordValues, string[] dwordAddress, byte[] dwordValues, bool isBit);

    /// <summary>
    /// 隨機軟元件位址的資料寫入 (以Word為單位)。
    /// </summary>
    /// <param name="wordAddress">Word資料的軟元件列表。</param>
    /// <param name="wordValues">Word資料表。<br/>byte[]格式，一筆資料占2 bytes。</param>
    /// <param name="dwordAddress">DWord資料的軟元件列表。</param>
    /// <param name="dwordValues">DWord資料表。<br/>byte[]格式，一筆資料占4 bytes。</param>
    /// <returns>寫入是否成功。</returns>
    public bool Write(string[] wordAddress, byte[] wordValues, string[] dwordAddress, byte[] dwordValues);

    /****************************************
     * 讀寫輔助函數
     ****************************************/
    /********************
     * bool
     ********************/
    /// <summary>
    /// 讀取一個bool資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, bool? result) ReadBool(string address);

    /// <summary>
    /// 批量讀取連續位址的bool資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">連續軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, bool[] results) ReadBool(string address, int readNumber);

    /// <summary>
    /// 寫入一個bool資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteBool(string address, bool value);

    /// <summary>
    /// 寫入連續軟元件位址的bool資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteBool(string address, bool[] values);

    /// <summary>
    /// 隨機軟元件位址寫入bool資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteBool(string[] address, bool[] values);

    /********************
     * int16/short/Word
     ********************/
    /// <summary>
    /// 讀取一個int16資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, short result) ReadInt16(string address);

    /// <summary>
    /// 批量讀取連續軟元件位址的int16資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, short[] results) ReadInt16(string address, int readNumber);

    /// <summary>
    /// 隨機軟元件位址讀取int16資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, short[] results) ReadInt16(string[] address);

    /// <summary>
    /// 寫入一個int16資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteInt16(string address, short value);

    /// <summary>
    /// 寫入連續軟元件位址的int16資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteInt16(string address, short[] values);

    /// <summary>
    /// 隨機連續軟元件位址寫入int16資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteInt16(string[] address, short[] values);

    /********************
     * uint16/ushort/Word
     ********************/
    /// <summary>
    /// 讀取一個uint16資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, ushort result) ReadUInt16(string address);

    /// <summary>
    /// 批量讀取連續軟元件位址的uint16資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, ushort[] results) ReadUInt16(string address, int readNumber);

    /// <summary>
    /// 隨機軟元件位址讀取uint16資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, ushort[] results) ReadUInt16(string[] address);

    /// <summary>
    /// 寫入一個uint16資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUInt16(string address, ushort value);

    /// <summary>
    /// 寫入連續軟元件位址的uint16資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUInt16(string address, ushort[] values);

    /// <summary>
    /// 隨機連續軟元件位址寫入uint16資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUInt16(string[] address, ushort[] values);

    /********************
     * int32/int/DWord
     ********************/
    /// <summary>
    /// 讀取一個int32資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, int result) ReadInt32(string address);

    /// <summary>
    /// 批量讀取連續軟元件位址的int32資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, int[] result) ReadInt32(string address, int readNumber);

    /// <summary>
    /// 隨機軟元件位址讀取int32資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, int[] result) ReadInt32(string[] address);

    /// <summary>
    /// 寫入一個int32資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteInt32(string address, int value);

    /// <summary>
    /// 寫入連續軟元件位址的int32資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteInt32(string address, int[] values);

    /// <summary>
    /// 隨機連續軟元件位址寫入int32資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteInt32(string[] address, int[] values);

    /********************
     * uint32/uint/DWord
     ********************/
    /// <summary>
    /// 讀取一個uint32資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, uint result) ReadUInt32(string address);

    /// <summary>
    /// 批量讀取連續軟元件位址的uint32資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, uint[] result) ReadUInt32(string address, int readNumber);

    /// <summary>
    /// 隨機軟元件位址讀取uint32資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, uint[] result) ReadUInt32(string[] address);

    /// <summary>
    /// 寫入一個uint32資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUInt32(string address, uint value);

    /// <summary>
    /// 寫入連續軟元件位址的uint32資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUInt32(string address, uint[] values);

    /// <summary>
    /// 隨機連續軟元件位址寫入uint32資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUInt32(string[] address, uint[] values);

    /********************
     * int64/long
     ********************/
    /// <summary>
    /// 讀取一個int64資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, long result) ReadInt64(string address);

    /// <summary>
    /// 批量讀取連續軟元件位址的int64資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, long[] result) ReadInt64(string address, int readNumber);

    /// <summary>
    /// 寫入一個int64資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteInt64(string address, long value);

    /// <summary>
    /// 寫入連續軟元件位址的int64資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteInt64(string address, long[] values);

    /********************
     * uint64/ulong
     ********************/
    /// <summary>
    /// 讀取一個uint64資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, ulong result) ReadUInt64(string address);

    /// <summary>
    /// 批量讀取連續軟元件位址的uint64資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, ulong[] result) ReadUInt64(string address, int readNumber);

    /// <summary>
    /// 寫入一個uint64資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUInt64(string address, ulong value);

    /// <summary>
    /// 寫入連續軟元件位址的uint64資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUInt64(string address, ulong[] values);

    /********************
     * float = 4 bytes
     ********************/
    /// <summary>
    /// 讀取一個float資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, float result) ReadFloat(string address);

    /// <summary>
    /// 批量讀取連續軟元件位址的float資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, float[] result) ReadFloat(string address, int readNumber);

    /// <summary>
    /// 隨機軟元件位址讀取float資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, float[] result) ReadFloat(string[] address);

    /// <summary>
    /// 寫入一個float資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteFloat(string address, float value);

    /// <summary>
    /// 寫入連續軟元件位址的float資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteFloat(string address, float[] values);

    /// <summary>
    /// 隨機連續軟元件位址寫入float資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteFloat(string[] address, float[] values);

    /********************
     * double = 8 bytes
     ********************/
    /// <summary>
    /// 讀取一個double資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, double result) ReadDouble(string address);

    /// <summary>
    /// 批量讀取連續軟元件位址的double資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, double[] result) ReadDouble(string address, int readNumber);

    /// <summary>
    /// 寫入一個double資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteDouble(string address, double value);

    /// <summary>
    /// 寫入連續軟元件位址的double資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteDouble(string address, double[] values);

    /********************
     * string
     ********************/
    /// <summary>
    /// 以ASCII格式讀取字串
    /// </summary>
    /// <param name="stringAddress">第一個軟元件位址。</param>
    /// <param name="sizeAddress">儲存字串長度的軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的字串)。</returns>
    public (bool isSucceed, string result) ReadAscii(string stringAddress, string sizeAddress);

    /// <summary>
    /// 以ASCII格式寫入字串
    /// </summary>
    /// <param name="stringAddress">第一個軟元件位址。</param>
    /// <param name="sizeAddress">儲存字串長度的軟元件位址。</param>
    /// <param name="value">寫入的字串。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteAscii(string stringAddress, string sizeAddress, string value);

    /// <summary>
    /// 以UTF-8格式讀取字串
    /// </summary>
    /// <param name="stringAddress">第一個軟元件位址。</param>
    /// <param name="sizeAddress">儲存字串長度的軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的字串)。</returns>
    public (bool isSucceed, string result) ReadUtf8(string stringAddress, string sizeAddress);

    /// <summary>
    /// 以UTF-8格式寫入字串
    /// </summary>
    /// <param name="stringAddress">第一個軟元件位址。</param>
    /// <param name="sizeAddress">儲存字串長度的軟元件位址。</param>
    /// <param name="value">寫入的字串。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteUtf8(string stringAddress, string sizeAddress, string value);

    /********************
     * WFS擴充
     ********************/
    /// <summary>
    /// 以int32格式讀取一個double值。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, double result) ReadDoubleByInt32(string address);

    /// <summary>
    /// 以int32格式批量讀取連續軟元件位址的double資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="readNumber">軟元件數。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, double[] results) ReadDoubleByInt32(string address, int readNumber);

    /// <summary>
    /// 以int32格式隨機軟元件位址讀取double資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <returns>(讀取是否成功, 取得的資料)。</returns>
    public (bool isSucceed, double[] results) ReadDoubleByInt32(string[] address);

    /// <summary>
    /// 以int32格式寫入一個double資料。
    /// </summary>
    /// <param name="address">軟元件位址。</param>
    /// <param name="value">寫入的值。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteDoubleByInt32(string address, double value);

    /// <summary>
    /// 以int32格式寫入連續軟元件位址的double資料。
    /// </summary>
    /// <param name="address">第一個軟元件位址。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteDoubleByInt32(string address, double[] values);

    /// <summary>
    /// 以int32格式隨機連續軟元件位址寫入double資料。
    /// </summary>
    /// <param name="address">軟元件位址列表。</param>
    /// <param name="values">寫入的值陣列。</param>
    /// <returns>寫入是否成功。</returns>
    public bool WriteDoubleByInt32(string[] address, double[] values);

    /********************
     * PLC Command
     ********************/
    /// <summary>
    /// 使用脈波形式傳送指令
    /// </summary>
    /// <param name="deviceName">軟元件位址。</param>
    void SendCommandPulse(string deviceName);
}
