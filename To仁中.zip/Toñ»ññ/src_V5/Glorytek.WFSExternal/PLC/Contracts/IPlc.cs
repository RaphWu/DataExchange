﻿namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面。
/// </summary>
public interface IPlc : IPlc_MitsubishiClient, IPlc_Status, IPlc_Data,
                        IPlc_Position, IPlc_Motion, IPlc_Jog, IPlc_Reset,
                        IPlc_Product, IPlc_System, IPlc_Polling
{
    /********************
     * Database
     ********************/
    /// <summary>
    /// 將Model資料寫入資料庫。
    /// </summary>
    void WriteToDb();

    /// <summary>
    /// 從資料庫讀取資料至Model。
    /// </summary>
    bool ReadFromDb();

    /// <summary>
    /// 參數寫入PLC (非Pallet及Tray)。
    /// </summary>
    void WriteToPlc();

    /// <summary>
    /// 從PLC讀取資料。
    /// </summary>
    void ReadFromPlc();

    /********************
     * Command
     ********************/
    /// <summary>
    /// 關閉PLC連線。
    /// </summary>
    uint Disconnect();

    /// <summary>
    /// 開啟PLC連線。
    /// </summary>
    uint Connect();

    /// <summary>
    /// 重新設定PLC連線參數並重啟連線。
    /// </summary>
    uint Reconnect();
}
