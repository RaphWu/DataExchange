﻿namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - 資料處理。
/// </summary>
public interface IPlc_Data
{
    /********************
     * 資料轉換
     ********************/
    /// <summary>
    /// 將DWord(32 bytes)轉換成兩個Word(16 bytes)。
    /// </summary>
    /// <param name="dword">要轉換的DWord。</param>
    /// <returns>[1]: High word<br/>[0]: Low word。</returns>
    short[] DataConvert_DWordToWord(int dword);

    /// <summary>
    /// 將兩個Word(16 bytes)轉換成DWord(32 bytes)。
    /// </summary>
    /// <param name="word">要轉換的Word。</param>
    /// <returns>轉換後的DWord。</returns>
    int DataConvert_WordToDWord(short[] word);

    /********************
     * PLC座標與PC座標轉換
     ********************/
    /// <summary>
    /// PLC座標值轉PC座標值。
    /// </summary>
    /// <param name="plcCoor">PLC座標值: 長度2的32位元(int)陣列。</param>
    /// <returns>PC座標值: double值。</returns>
    double CoorConvert_PlcToPc(int[] plcCoor);

    /// <summary>
    /// PLC座標值轉PC座標值。
    /// </summary>
    /// <param name="highWord">High Word。</param>
    /// <param name="lowWord">Low Word。</param>
    /// <returns>PC座標值: double值。</returns>
    double CoorConvert_PlcToPc(int highWord, int lowWord);

    /// <summary>
    /// PC座標值轉PLC座標值。
    /// </summary>
    /// <param name="pcCoor">PC座標值: double值。</param>
    /// <returns>PLC座標值: 長度2的32位元(int)陣列。</returns>
    int[] CoorConvert_PcToPlc(double pcCoor);

    /// <summary>
    /// PC角度換算PLC座標。
    /// </summary>
    /// <param name="degree">PC角度。</param>
    /// <returns>PLC座標。</returns>
    int AngleConvert_PcToPlc(double degree);

    /// <summary>
    /// PLC座標換算PC角度。
    /// </summary>
    /// <param name="plcDegree">PLC座標。</param>
    /// <returns>PC角度。</returns>
    double AngleConvert_PlcToPc(int[] plcDegree);
}
