﻿using Glorytek.WFSExternal.PLC.Constants;
using System.Threading.Tasks;

namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - 定點運動。
/// </summary>
public interface IPlc_Motion
{
    /// <summary>
    /// 移動指定機構至指定座標。
    /// </summary>
    /// <param name="target">指定機構。</param>
    /// <param name="x">座標X。</param>
    /// <param name="y">座標Y。</param>
    /// <param name="z">座標Z。</param>
    Task MoveToTarget(MotionTarget target, double x, double y, double z);
}
