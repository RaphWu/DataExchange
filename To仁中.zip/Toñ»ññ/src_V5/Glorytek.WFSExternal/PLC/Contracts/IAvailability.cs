﻿using Glorytek.WFSExternal.PLC.Constants;

namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// 稼動紀錄處理。
/// </summary>
public interface IAvailability
{
    /// <summary>
    /// 依資料庫重建列表。
    /// </summary>
    void Rebuild();

    /// <summary>
    /// 新增時間點紀錄。
    /// </summary>
    /// <param name="type">分類。</param>
    /// <param name="alarmCode">警報代碼。</param>
    void AddNewRecord(AvailabilityType type, int alarmCode);

    /// <summary>
    /// 新增時間點紀錄。
    /// </summary>
    /// <param name="type">分類。</param>
    void AddNewRecord(AvailabilityType type);
}
