﻿using Glorytek.WFSExternal.PLC.Constants;

namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - JOG。
/// </summary>
public interface IPlc_Jog
{
    /********************
     * Jog
     ********************/
    /// <summary>
    /// 全軸JOG停止。
    /// </summary>
    void AllJogStop();

    /// <summary>
    /// X軸正轉啟動。
    /// </summary>
    void XAxisJog_Forward_Start();

    /// <summary>
    /// X軸正轉停止。
    /// </summary>
    void XAxisJog_Forward_Stop();

    /// <summary>
    /// X軸反轉啟動。
    /// </summary>
    void XAxisJog_Reverse_Start();

    /// <summary>
    /// X軸反轉停止。
    /// </summary>
    void XAxisJog_Reverse_Stop();

    /// <summary>
    /// Y軸正轉啟動。
    /// </summary>
    void YAxisJog_Forward_Start();

    /// <summary>
    /// Y軸正轉停止。
    /// </summary>
    void YAxisJog_Forward_Stop();

    /// <summary>
    /// Y軸反轉啟動。
    /// </summary>
    void YAxisJog_Reverse_Start();

    /// <summary>
    /// Y軸反轉停止。
    /// </summary>
    void YAxisJog_Reverse_Stop();

    /// <summary>
    /// Z軸正轉啟動。
    /// </summary>
    void ZAxisJog_Forward_Start();

    /// <summary>
    /// Z軸正轉停止。
    /// </summary>
    void ZAxisJog_Forward_Stop();

    /// <summary>
    /// Z軸反轉啟動。
    /// </summary>
    void ZAxisJog_Reverse_Start();

    /// <summary>
    /// Z軸反轉停止。
    /// </summary>
    void ZAxisJog_Reverse_Stop();

    /// <summary>
    /// R軸正轉啟動。
    /// </summary>
    void RAxisJog_Forward_Start();

    /// <summary>
    /// R軸正轉停止。
    /// </summary>
    void RAxisJog_Forward_Stop();

    /// <summary>
    /// R軸反轉啟動。
    /// </summary>
    void RAxisJog_Reverse_Start();

    /// <summary>
    /// R軸反轉停止。
    /// </summary>
    void RAxisJog_Reverse_Stop();

    /********************
     * Speed
     ********************/

    /// <summary>
    /// 目前JOG速度設定。
    /// </summary>
    JogSpeedList JogSpeed { get; }

    /// <summary>
    /// 設定JOG速度。
    /// </summary>
    void SetJogSpeed(JogSpeedList jogSpeed);
}
