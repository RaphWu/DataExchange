﻿namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - 安全防護。
/// </summary>
public interface IPlc_Safety
{
    ///// <summary>
    ///// 安全高度。(移至MachineDefine)
    ///// </summary>
    //double SaftyHeight { get; set; }

    /// <summary>
    /// 限速啟動。
    /// </summary>
    bool SpeedLimitActivated { get; }
}
