﻿namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - 座標資料。
/// </summary>
public interface IPlc_Position
{
    /********************
     * 目前軸座標
     ********************/
    /// <summary>
    /// X軸目前座標。
    /// </summary>
    double XAxisPosition { get; }

    /// <summary>
    /// Y軸目前座標。
    /// </summary>
    double YAxisPosition { get; }

    /// <summary>
    /// Z軸目前座標。
    /// </summary>
    double ZAxisPosition { get; }

    /// <summary>
    /// R軸目前座標。
    /// </summary>
    double RAxisPosition { get; }

    /********************
     * 軸是否運動中
     ********************/
    /// <summary>
    /// X軸運動中。
    /// </summary>
    bool XAxisInMotion { get; }

    /// <summary>
    /// Y軸運動中。
    /// </summary>
    bool YAxisInMotion { get; }

    /// <summary>
    /// Z軸運動中。
    /// </summary>
    bool ZAxisInMotion { get; }

    /// <summary>
    /// R軸運動中。
    /// </summary>
    bool RAxisInMotion { get; }

    /// <summary>
    /// 任意軸運動中。
    /// </summary>
    bool AnyAxisInMotion { get; }
}
