﻿using Glorytek.WFSCore.Constants;

namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - 與軟體系統相關。
/// </summary>
public interface IPlc_System
{
    /// <summary>
    /// 儲存系統作業模式。
    /// </summary>
    /// <param name="mode">系統作業模式。</param>
    void SetSystemMode(SystemOperateModeType mode);

    /********************
     * Cycle Time碼表
     ********************/
    /// <summary>
    /// Cycle Time碼表開始計時。
    /// </summary>
    void StartCTStopwatch();

    /// <summary>
    /// Cycle Time碼表停止計時。
    /// </summary>
    void StopCTStopwatch();

    /// <summary>
    /// Cycle Time碼表重置。
    /// </summary>
    void ResetCTStopwatch();

    /// <summary>
    /// 將Cycle Time寫入系統變數內。
    /// </summary>
    void WriteCycleTime();

    /// <summary>
    /// Cycle Time觸發事件。
    /// </summary>
    void CycleTimeTrigger(bool signal);
}
