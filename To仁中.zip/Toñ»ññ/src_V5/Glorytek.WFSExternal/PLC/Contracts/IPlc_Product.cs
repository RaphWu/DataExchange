﻿namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - 作業品種處理。
/// </summary>
public interface IPlc_Product
{
    /********************
     * 品種名存取
     ********************/
    /// <summary>
    /// 將品種名稱寫入PLC內。
    /// </summary>
    /// <param name="productName">寫入的品種名稱。</param>
    public void WriteProductName(string productName);

    /// <summary>
    /// 取得PLC內的品種名稱。
    /// </summary>
    /// <returns>讀取出的品種名稱。</returns>
    public (bool isSucceed, string productName) ReadProductName();

    /********************
     * 品種參數
     ********************/
    ///// <summary>
    ///// 系統參數暫存器是否已讀入的有效狀態
    ///// </summary>
    //bool IsProductEffective { get; }

    ///// <summary>
    ///// 系統參數暫存器
    ///// </summary>
    //short[] ParametersRegister { get; }

    /********************
     * Register讀寫
     ********************/
    ///// <summary>
    ///// 將Word寫入[D+0]的位址
    ///// </summary>
    ///// <param name="offset">D+0地址。</param>
    ///// <param name="dword">寫入的Word。</param>
    //void SaveWordToRegister(int offset, params short[] word);

    ///// <summary>
    ///// 將DWord寫入[D+1][D+0]的位址
    ///// </summary>
    ///// <param name="offset">D+0地址。</param>
    ///// <param name="dword">寫入的DWord。</param>
    //void SaveDWordToRegister(int offset, params int[] dword);
}
