﻿namespace Glorytek.WFSExternal.PLC.Contracts;

/// <summary>
/// PLC處理介面 - 狀態偵測。
/// </summary>
public interface IPlc_Status
{
    /// <summary>
    /// PLC已準備好且無警報。
    /// </summary>
    bool Ready { get; }

    /// <summary>
    /// PLC已準備好且在靜止狀態。
    /// </summary>
    bool Stabilized { get; }

    /// <summary>
    /// PLC已準備好且在靜止狀態(非自動模式)。
    /// </summary>
    bool PlcStabilizedExceptAutoMode { get; }

    /// <summary>
    /// 警報。
    /// </summary>
    bool Alarm { get; }

    /// <summary>
    /// PLC是否已連線。
    /// </summary>
    /// <remarks>true: 連線中。<br/>false:未連線。</remarks>
    bool Online { get; }

    /// <summary>
    /// 全部伺服軸是否Ready。
    /// </summary>
    /// <remarks>true=全軸Ready。<br/>false=任意軸異常。</remarks>
    bool AllServoReady { get; }

    /// <summary>
    /// 伺服軸復歸中。
    /// </summary>
    bool HomeReturning { get; }

    /// <summary>
    /// 伺服軸復歸完成。
    /// </summary>
    bool HomeReturnCompleted { get; }

    /********************
     * 氣壓類
     ********************/
    /// <summary>
    /// 吸嘴真空檢知。
    /// </summary>
    bool NozzleVaccumDetector { get; }

    /// <summary>
    /// 吸嘴真空狀態。
    /// </summary>
    bool NozzleVaccum { get; }

    /// <summary>
    /// 吸嘴破真空狀態。
    /// </summary>
    bool NozzleRelief { get; }

    /// <summary>
    /// A1真空檢知。
    /// </summary>
    bool Stage1VaccumDetector { get; }

    /// <summary>
    /// A1真空狀態。
    /// </summary>
    bool Stage1Vaccum { get; }

    /// <summary>
    /// A2破真空狀態。
    /// </summary>
    bool Stage1Relief { get; }

    /// <summary>
    /// A2真空檢知。
    /// </summary>
    bool Stage2VaccumDetector { get; }

    /// <summary>
    /// A2真空狀態。
    /// </summary>
    bool Stage2Vaccum { get; }

    /// <summary>
    /// A2破真空狀態。
    /// </summary>
    bool Stage2Relief { get; }

    /********************
     * IO
     ********************/
    /// <summary>
    /// 光柵信號。
    /// </summary>
    public bool LightCurtain { get; }

    /// <summary>
    /// 照明。
    /// </summary>
    bool Lights { get; }

    /// <summary>
    /// 三色燈 (綠)。
    /// </summary>
    bool StackLightGreen { get; }

    /// <summary>
    /// 三色燈 (綠)。
    /// </summary>
    bool StackLightYellow { get; }

    /// <summary>
    /// 三色燈 (綠)。
    /// </summary>
    bool StackLightRed { get; }

    /// <summary>
    /// 門。
    /// </summary>
    bool Doors { get; }
}
