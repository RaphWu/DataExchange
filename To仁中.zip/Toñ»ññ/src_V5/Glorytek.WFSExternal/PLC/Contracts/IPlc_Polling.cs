﻿using System.Threading.Tasks;

namespace Glorytek.WFSExternal.PLC.Contracts
{
    public interface IPlc_Polling
    {
        /// <summary>
        /// 等待至少完成一個Polling循環。
        /// </summary>
        Task WaitForPollingCycleCompleted();
    }
}
