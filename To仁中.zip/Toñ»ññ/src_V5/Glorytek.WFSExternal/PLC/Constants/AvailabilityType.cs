﻿namespace Glorytek.WFSExternal.PLC.Constants;

/// <summary>
/// 紀錄類型。
/// </summary>
public enum AvailabilityType
{
    Undefine = -1,

    /// <summary>
    /// 啟動作業。
    /// </summary>
    StartOperate = 1,

    /// <summary>
    /// 結束作業。
    /// </summary>
    StopOperate = 2,


    /// <summary>
    /// 暫停作業。
    /// </summary>
    PauseStart = 4,

    /// <summary>
    /// 暫停取消。
    /// </summary>
    PauseCancel = 5,


    /// <summary>
    /// 警報觸發。
    /// </summary>
    AlarmTriggering = 10,

    /// <summary>
    /// 警報解除。
    /// </summary>
    AlarmClear = 11,
}
