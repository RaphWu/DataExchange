﻿using Glorytek.WFSCore.Constants;

namespace Glorytek.WFSExternal.PLC.Constants;

/// <summary>
/// 資料庫定義 - PLC。
/// </summary>
internal class DB_PLC
{
    internal const string PlcParasFileName = "PLC.json";

    internal const string DbName_Availability = $"Availability{DBbase.DB_ExtFileName}";
    internal const string TableName_Availability = "Availability";
    internal const string CreateTableSQL_Availability = @"CREATE TABLE IF NOT EXISTS [Availability](
[Id] INTEGER PRIMARY KEY ASC AUTOINCREMENT NOT NULL UNIQUE,
[TypeId] INTEGER NOT NULL,
[Timestamp] INTEGER NOT NULL,
[AlarmCode] INTEGER DEFAULT (-1));";
}
