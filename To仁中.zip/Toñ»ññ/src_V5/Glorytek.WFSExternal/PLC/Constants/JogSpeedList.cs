﻿namespace Glorytek.WFSExternal.PLC.Constants;

/// <summary>
/// JOG速度。
/// </summary>
public enum JogSpeedList
{
    /// <summary>
    /// 未定義。
    /// </summary>
    Unknown,

    /// <summary>
    /// 慢速。
    /// </summary>
    Slow,

    /// <summary>
    /// 低速。
    /// </summary>
    Low,

    /// <summary>
    /// 中速。
    /// </summary>
    Medium,

    /// <summary>
    /// 高速。
    /// </summary>
    High,

    /// <summary>
    /// 最高速。
    /// </summary>
    Highest,
}
