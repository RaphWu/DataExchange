﻿namespace Glorytek.WFSExternal.PLC.Constants;

/// <summary>
/// 移動機構名稱。
/// </summary>
public enum MotionTarget
{
    /// <summary>
    /// 基準點。
    /// </summary>
    DatumPoint,

    /// <summary>
    /// 黏土座相機位置。
    /// </summary>
    ClayTableByCamera,

    /// <summary>
    /// 黏土座吸嘴位置。
    /// </summary>
    ClayTableByNozzle,

    /// <summary>
    /// 位移計。
    /// </summary>
    Displacement,

    /// <summary>
    /// Stage 1。
    /// </summary>
    Stage1,

    /// <summary>
    /// Stage 2。
    /// </summary>
    Stage2,

    /// <summary>
    /// 虛擬點。
    /// </summary>
    VisualPoint,

    /// <summary>
    /// 虛擬Tray。
    /// </summary>
    VisualTray,
}
