﻿using Prism.Events;

namespace Glorytek.WFSExternal.PLC.Events;

/********************
 * PLC交握
 ********************/
/// <summary>
/// PLC交握事件 - 取料動作信號。
/// </summary>
public class PlcHandshakeEvent : PubSubEvent<string> { }

/// <summary>
/// PLC交握事件 - 放料動作信號。
/// </summary>
public class PlcHandshakeFeedback : PubSubEvent<int> { }

/********************
 * 內部事件
 ********************/
/// <summary>
/// 自動作業結束訊號 (bool: 是否由 Polling 呼叫)。
/// </summary>
public class AutoStopSignal : PubSubEvent<bool> { }
