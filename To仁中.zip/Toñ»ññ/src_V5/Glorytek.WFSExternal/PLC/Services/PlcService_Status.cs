﻿using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - 狀態偵測。
 ********************/
public partial class PlcService : IPlc_Status
{
    /********************
     * PLC
     ********************/
    /// <inheritdoc/>
    public bool Ready => PlcDatas.Instance.Ready;

    /// <inheritdoc/>
    public bool Stabilized => PlcDatas.Instance.Stabilized;

    /// <inheritdoc/>
    public bool PlcStabilizedExceptAutoMode => PlcDatas.Instance.StabilizedExceptAutoMode;

    /// <inheritdoc/>
    public bool Alarm => PlcDatas.Instance.Alarm;

    /// <inheritdoc/>
    public bool Online => PlcDatas.Instance.Online;

    /// <inheritdoc/>
    public bool AllServoReady => PlcDatas.Instance.AllServoReady;

    /// <inheritdoc/>
    public bool HomeReturning => PlcDatas.Instance.HomeReturning;

    /// <inheritdoc/>
    public bool HomeReturnCompleted => PlcDatas.Instance.HomeReturnCompleted;

    /********************
     * 氣壓類
     ********************/
    /// <inheritdoc/>
    public bool NozzleVaccumDetector => PlcDatas.Instance.NozzleVaccumDetector;

    /// <inheritdoc/>
    public bool NozzleVaccum => PlcDatas.Instance.NozzleVaccum;

    /// <inheritdoc/>
    public bool NozzleRelief => PlcDatas.Instance.NozzleRelief;

    /// <inheritdoc/>
    public bool Stage1VaccumDetector => PlcDatas.Instance.Stage1VaccumDetector;

    /// <inheritdoc/>
    public bool Stage1Vaccum => PlcDatas.Instance.Stage1Vaccum;

    /// <inheritdoc/>
    public bool Stage1Relief => PlcDatas.Instance.Stage1Relief;

    /// <inheritdoc/>
    public bool Stage2VaccumDetector => PlcDatas.Instance.Stage2VaccumDetector;

    /// <inheritdoc/>
    public bool Stage2Vaccum => PlcDatas.Instance.Stage2Vaccum;

    /// <inheritdoc/>
    public bool Stage2Relief => PlcDatas.Instance.Stage2Relief;

    /********************
     * IO
     ********************/
    /// <inheritdoc/>
    public bool LightCurtain => PlcDatas.Instance.LightCurtain;

    /// <inheritdoc/>
    public bool Lights => PlcDatas.Instance.Lights;

    /// <inheritdoc/>
    public bool StackLightGreen => PlcDatas.Instance.StackLightGreen;

    /// <inheritdoc/>
    public bool StackLightYellow => PlcDatas.Instance.StackLightYellow;

    /// <inheritdoc/>
    public bool StackLightRed => PlcDatas.Instance.StackLightRed;

    /// <inheritdoc/>
    public bool Doors => PlcDatas.Instance.Doors;
}
