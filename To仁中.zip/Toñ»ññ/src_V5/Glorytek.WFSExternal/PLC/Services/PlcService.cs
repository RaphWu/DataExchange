﻿using Glorytek.CSharp.Data;
using Glorytek.CSharp.IO;
using Glorytek.FA.Mitsubishi;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Events;
using Glorytek.WFSExternal.PLC.Models;
using Prism.Events;
using Serilog;
using System.Threading.Tasks;
using TouchSocket.Core;
using TouchSocket.Sockets;

namespace Glorytek.WFSExternal.PLC.Services;

/// <summary>
/// PLC處理Service。
/// </summary>
public partial class PlcService : IPlc
{
    private static MitsubishiClient _client;

    private static bool _eventNotSubscribed = true;
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;
    private readonly PlcDatas _pd = PlcDatas.Instance;
    private readonly PlcParameters _pp = PlcParameters.Instance;

    private const uint _internalErrorCode = 0xFFFF;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IAvailability _availability;

    public PlcService(IEventAggregator ea, IAvailability availability)
    {
        _ea = ea;
        _availability = availability;

        if (_eventNotSubscribed)
        {
            _eventNotSubscribed = false;
            _ = _ea.GetEvent<PlcHandshakeFeedback>().Subscribe(EventFeedback, keepSubscriberReferenceAlive: true);
            _ = _ea.GetEvent<ApplicationShutdownEvent>().Subscribe(ApplicationShutdown, keepSubscriberReferenceAlive: true);
        }
    }

    /// <summary>
    /// 應用程式結束。
    /// </summary>
    private void ApplicationShutdown(int _)
    {
        Disconnect();
    }

    /********************
     * System Command
     ********************/
    /// <summary>
    /// 模組初始化。
    /// </summary>
    internal void ModuleInit()
    {
        ReadFromDb();
        Reconnect();
    }

    /// <inheritdoc/>
    public uint Reconnect()
    {
        Disconnect();
        _client = null;
        _client = new MitsubishiClient(MitsubishiVersion.Qna_3E, _pp.HostAddress, _pp.Port);

        uint retCode = Connect();
        if (retCode != _internalErrorCode)
            PlcReset();
        return retCode;
    }

    /// <inheritdoc/>
    public uint Disconnect()
    {
        return _client?.Disconnect() ?? _internalErrorCode;
    }

    /// <inheritdoc/>
    public uint Connect()
    {
        return _client?.Connect(ConnectedEvent, DisconnectedEvent, null, _pp.TimeOut) ?? _internalErrorCode;
    }

    /// <summary>
    /// 附加成功連接到Server的事件。
    /// </summary>
    /// <remarks>參見: <see href="https://www.yuque.com/rrqm/touchsocket/436f0f670b44744c9f1082d97ced2613">TouchSocket说明文档：六、支持插件接口</see>。</remarks>
    private void ConnectedEvent(ITcpClient client, MsgEventArgs e)
    {
        PlcDatas.Instance.Online = _client.Online;
        PlcPollingStart();
        ReadFromPlc();
    }

    /// <summary>
    /// 附加斷開連接Server的事件。
    /// </summary>
    /// <remarks>參見: <see href="https://www.yuque.com/rrqm/touchsocket/436f0f670b44744c9f1082d97ced2613">TouchSocket说明文档：六、支持插件接口</see>。</remarks>
    private void DisconnectedEvent(ITcpClientBase client, DisconnectEventArgs e)
    {
        PlcDatas.Instance.Online = _client.Online;
        PlcPollingStop();
    }

    /// <summary>
    /// 附加接收到數據時的事件。
    /// </summary>
    /// <remarks>參見: <see href="https://www.yuque.com/rrqm/touchsocket/436f0f670b44744c9f1082d97ced2613">TouchSocket说明文档：六、支持插件接口</see>。</remarks>
    private void TouchSocketReceived(TcpClient client, ByteBlock byteBlock, IRequestInfo requestInfo)
    {
    }

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public void WriteToDb()
    {
        JsonFileHelper.Save(DBbase.Directory_Base, DB_PLC.PlcParasFileName, new PlcDbDefine()
        {
            HostAddress = _pp.HostAddress,
            Port = _pp.Port,
            TimeOut = _pp.TimeOut,
        });
    }

    /// <inheritdoc/>
    public bool ReadFromDb()
    {
        PlcDbDefine plcDb = JsonFileHelper.Read<PlcDbDefine>(DBbase.Directory_Base, DB_PLC.PlcParasFileName);
        if (plcDb != null)
        {
            _pp.HostAddress = plcDb.HostAddress;
            _pp.Port = plcDb.Port;
            _pp.TimeOut = plcDb.TimeOut;

            return true;
        }
        else
        {
            // default
            _pp.HostAddress = "192.168.1.1";
            _pp.Port = 2000;
            _pp.TimeOut = 1500;

            WriteToDb();
            return false;
        }
    }

    /// <inheritdoc/>
    public void WriteToPlc()
    {
        if (_client != null)
        {
            _ = _client.WriteInt16(DeviceLists.XY_AXIS_INP_DELAY, (short)(_pd.XYAxisInpDelay * 10.0));
            _ = _client.WriteInt16(DeviceLists.XY_AXIS_SLOW_DOWN, new short[] { _pd.XYAxisSlowDown, 0, _pd.XYAxisSlowDownSpeed });
            _ = _client.WriteInt16(DeviceLists.Z_AXIS_SPEED_UP_DOWN, _pd.ZAxisSpeedUpDown);
        }
    }

    /// <inheritdoc/>
    public void ReadFromPlc()
    {
        if (_client != null)
        {
            // D20158
            var (inpDelayOK, inpDelay) = _client.ReadInt16(DeviceLists.XY_AXIS_INP_DELAY);
            if (inpDelayOK)
                _pd.XYAxisInpDelay = (float)(inpDelay / 10.0).Format(1);

            // D20756~D20758
            var (xyAxisSlowDownOK, xyAxisSlowDown) = _client.ReadInt16(DeviceLists.XY_AXIS_SLOW_DOWN, 3);
            if (xyAxisSlowDownOK)
            {
                _pd.XYAxisSlowDown = xyAxisSlowDown[0];
                _pd.XYAxisSlowDownSpeed = xyAxisSlowDown[2];
            }

            // D20700
            var (zAxisSpeedUpDownOK, zAxisSpeedUpDown) = _client.ReadInt16(DeviceLists.Z_AXIS_SPEED_UP_DOWN);
            if (zAxisSpeedUpDownOK)
                _pd.ZAxisSpeedUpDown = zAxisSpeedUpDown;
        }
    }

    /// <summary>
    /// 指令的脈波寬度(ms)。
    /// </summary>
    private const int _COMMAND_PLUSE_WIDTH = 5;

    /// <inheritdoc/>
    public void SendCommandPulse(string deviceName)
    {
        if (_client?.CanSend == true)
        {
            bool isSucceed = _client.WriteBool(deviceName, true);
            if (isSucceed)
            {
                Task.Delay(_COMMAND_PLUSE_WIDTH);
                isSucceed = _client.WriteBool(deviceName, false);
            }

            if (isSucceed)
            {
                /********************
                * 額外動作
                ********************/
                // 啟動時要更新旗標
                if (deviceName == DeviceLists.START_COMMAND)
                {
                    _pp.AutoRunningSignal = true;
                    _pickEventRunning = false;
                    _placeEventRunning = false;
                }
            }
            else
            {
                Log.Error("PLC指令送出失敗！");
            }
        }
    }
}
