﻿using Dapper.Contrib.Extensions;
using Glorytek.CSharp.Data.Converters;
using Glorytek.CSharp.IO;
using Glorytek.SQLite;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * 稼動紀錄。
 ********************/
public partial class AvailabilityService : IAvailability
{
    private static SQLiteConnection connAvailability = null;
    private readonly string AvailabilityDbPath = Path.Combine(DBbase.Directory_Availability, DB_PLC.DbName_Availability);
    private static bool isDataReady = false;

    private readonly PlcParameters _pp = PlcParameters.Instance;
    private readonly AvailabilityDatas _ad = AvailabilityDatas.Instance;

    /********************
     * ctor
     ********************/
    private readonly IPrismMessageBox _prismMessageBox;

    public AvailabilityService(IPrismMessageBox prismMessageBox)
    {
        _prismMessageBox = prismMessageBox;
    }

    /********************
     * common
     ********************/
    /// <summary>
    /// 模組初始化。
    /// </summary>
    internal void ModuleInit()
    {
        ReadAvailabilityFromDb();
        //Rebuild();
    }

    /// <summary>
    /// 取得目前時間戳。
    /// </summary>
    /// <returns>目前時間戳。</returns>
    private long GetTimestampOfNow() => DateTime.Now.ToUnixTimestamp(TimestampType.Seconds, Glorytek.CSharp.Constants.LocalTimeZone);

    /// <inheritdoc/>
    public void Rebuild()
    {
        isDataReady = RebuildAvailabilityList();
    }

    /********************
     * Interface
     ********************/
    /// <inheritdoc/>
    public void AddNewRecord(AvailabilityType type, int alarmCode)
    {
        Task.Run(async () =>
        {
            long thisTimestamp = GetTimestampOfNow();
            await AppendAvailabilityDbAsync(type, thisTimestamp, alarmCode);
            await AppendAvailabilityListAsync(type, thisTimestamp, alarmCode);
            _ad.AvailabilityCollectionView = CollectionViewSource.GetDefaultView(_ad.Availability);
        });
    }

    /// <inheritdoc/>
    public void AddNewRecord(AvailabilityType type)
    {
        Task.Run(async () =>
        {
            long thisTimestamp = GetTimestampOfNow();
            await AppendAvailabilityDbAsync(type, thisTimestamp, -1);
            await AppendAvailabilityListAsync(type, thisTimestamp, -1);
            _ad.AvailabilityCollectionView = CollectionViewSource.GetDefaultView(_ad.Availability);
        });
    }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 稼動資料寫入DB。
    /// </summary>
    private void WriteAvailabilityToDb()
    {
        connAvailability ??= SQLiteHelper.OpenConnection(AvailabilityDbPath);
        if (connAvailability == null)
            return;

        using var tran = connAvailability.BeginTransaction();
        try
        {
            connAvailability.Update<List<AvailabilityDbDefine>>(_pp.AvailabilityDB);
            tran.Commit();
        }
        catch (Exception ex)
        {
            tran.Rollback();
            string msg = $"稼動紀錄資料儲存失敗: {ex}";
            Log.Fatal(ex, msg);
            _ = _prismMessageBox.Show(msg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
        }
    }

    /// <summary>
    /// 從DB讀取稼動資料。
    /// </summary>
    /// <returns>讀取是否成功。</returns>
    private bool ReadAvailabilityFromDb()
    {
        if (!FileHelper.IsDirExist(DBbase.Directory_Availability))
            FileHelper.CreateDirectoy(DBbase.Directory_Availability);

        connAvailability ??= SQLiteHelper.OpenConnection(AvailabilityDbPath);
        if (connAvailability == null)
            return false;

        SQLiteHelper.Vaccum(connAvailability); // 重新排序ID
        using var tran = connAvailability.BeginTransaction();
        try
        {
            if (!SQLiteHelper.IsTableExist(connAvailability, DB_PLC.TableName_Availability))
                SQLiteHelper.CreateTable(connAvailability, DB_PLC.CreateTableSQL_Availability);
            _pp.AvailabilityDB = connAvailability.GetAll<AvailabilityDbDefine>(transaction: tran).ToList();
            tran.Commit();

            Rebuild();
            return true;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            string msg = $"稼動紀錄資料讀取失敗: {ex}";
            Log.Fatal(ex, msg);
            _ = _prismMessageBox.Show(msg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
        }
        return false;
    }

    /// <summary>
    /// 新增一筆稼動紀錄至資料庫。
    /// </summary>
    /// <param name="type">紀錄類型。</param>
    /// <param name="timestamp">紀錄時間戳。</param>
    /// <param name="alarmCode">警報代碼。</param>
    /// <returns>新增紀錄的ID。</returns>
    private async Task AppendAvailabilityDbAsync(AvailabilityType type, long timestamp, int alarmCode)
    {
        if (connAvailability == null)
            return;

        var newItem = new AvailabilityDbDefine
        {
            Type = type,
            Timestamp = timestamp,
            AlarmCode = alarmCode,
        };

        await connAvailability.InsertAsync(newItem);
        _pp.AvailabilityDB.Add(newItem);
    }

    /********************
     * 稼動列表
     ********************/
    internal class AlarmInfo
    {
        internal int Index { get; set; }
        internal int Code { get; set; }
    }
    private static List<AlarmInfo> _alarmList; // 警報列表 
    private static int _indexOperate; // 自動作業index
    private static int _indexEvent; // 事件index
    private static int _indexPause; // 暫停index
    private static int _indexAlarm; // 警報index

    private static bool _hasData; // 是否有資料:有發生事件時設True，執行NewBlock()時設False

    /// <summary>
    /// 設定新Block。
    /// </summary> 
    private int NewBlock()
    {
        _ad.Availability.Add(new AvailabilityDefine());
        int thisIndex = _ad.Availability.Count - 1;

        _ad.Availability[thisIndex].StartOperate = null;
        _ad.Availability[thisIndex].StopOperate = null;
        _ad.Availability[thisIndex].DiffOperate = null;
        _ad.Availability[thisIndex].Availability = null;
        _ad.Availability[thisIndex].EventStart = null;
        _ad.Availability[thisIndex].EventExclude = null;
        _ad.Availability[thisIndex].DiffEvent = null;

        _hasData = true;
        return thisIndex;
    }

    /// <summary>
    /// 新增一筆資料至稼動列表。
    /// </summary>
    /// <param name="type"></param>
    /// <param name="timestamp"></param>
    /// <param name="alarmCode"></param>
    private async Task AppendAvailabilityListAsync(AvailabilityType type, long timestamp, int alarmCode)
    {
        if (timestamp.LocalFromUnixTimestamp(out DateTime time))
        {
            switch (type)
            {
                case AvailabilityType.StartOperate:
                    {
                        _indexOperate = NewBlock();
                        _indexEvent = _indexOperate;
                        _ad.Availability[_indexOperate].StartOperate = time;
                        break;
                    }
                case AvailabilityType.StopOperate:
                    {
                        if (_hasData)
                        {
                            int startIndex = _indexOperate;
                            _indexOperate = _indexEvent;

                            DateTime startTime = (DateTime)_ad.Availability[startIndex].StartOperate!;
                            TimeSpan diffTime = time.Subtract(startTime);
                            TimeSpan lostTime = new TimeSpan();
                            for (int idx = _indexOperate; idx >= startIndex; idx--)
                                if (_ad.Availability[idx].DiffEvent != null)
                                    lostTime = lostTime.Add((TimeSpan)_ad.Availability[idx].DiffEvent!);
                            TimeSpan availability = diffTime.Subtract(lostTime);

                            _ad.Availability[_indexOperate].StopOperate = time;
                            _ad.Availability[_indexOperate].DiffOperate = diffTime;
                            _ad.Availability[_indexOperate].Availability = availability;
                            if (lostTime != TimeSpan.Zero)
                                _ad.Availability[_indexOperate].LostTime = lostTime;
                            _hasData = false;
                        }
                        break;
                    }
                case AvailabilityType.PauseStart:
                    {
                        if (_hasData)
                        {
                            // 暫停必須沒有正在發生
                            if (_indexPause == -1)
                            {
                                if (_ad.Availability[_indexEvent].EventStart != null)
                                    _indexEvent = NewBlock();

                                _indexPause = _indexEvent;
                                _ad.Availability[_indexPause].EventStart = time;
                                _ad.Availability[_indexPause].EventMessage = "暫停";
                            }
                        }
                        break;
                    }
                case AvailabilityType.PauseCancel:
                    {
                        if (_hasData)
                        {
                            // 暫停必須正在發生
                            if (_indexPause >= 0)
                            {
                                _ad.Availability[_indexPause].EventExclude = time;
                                _ad.Availability[_indexPause].DiffEvent = time.Subtract((DateTime)_ad.Availability[_indexPause].EventStart!);
                                _indexPause = -1;
                            }
                        }
                        break;
                    }
                case AvailabilityType.AlarmTriggering:
                    {
                        if (_hasData)
                        {
                            AlarmInfo alarm = null;
                            if (_alarmList.Count > 0)
                                alarm = _alarmList.Find(x => x.Code == alarmCode); // 找列表中的AlarmCode

                            // Alarm必須不在列表中
                            if (alarm == null)
                            {
                                if (_ad.Availability[_indexEvent].EventStart != null)
                                    _indexEvent = NewBlock();

                                _indexAlarm = _indexEvent;
                                _ad.Availability[_indexAlarm].EventStart = time;
                                _ad.Availability[_indexAlarm].EventMessage = $"警報：L{alarmCode}";
                                _alarmList.Add(new AlarmInfo
                                {
                                    Index = _indexEvent,
                                    Code = alarmCode,
                                });
                            }
                        }
                        break;
                    }
                case AvailabilityType.AlarmClear:
                    {
                        if (_hasData)
                        {
                            AlarmInfo alarm = null;
                            if (_alarmList.Count > 0)
                                alarm = _alarmList.Find(x => x.Code == alarmCode); // 找列表中的AlarmCode

                            // Alarm必須在列表中
                            if (alarm != null)
                            {
                                _indexAlarm = alarm.Index;
                                _ad.Availability[_indexAlarm].EventExclude = time;
                                _ad.Availability[_indexAlarm].DiffEvent = time.Subtract((DateTime)_ad.Availability[_indexAlarm].EventStart!);
                                _alarmList.RemoveAll(x => x.Code == alarmCode);
                            }
                        }
                        break;
                    }
            }
        }
        await Task.CompletedTask;
    }

    /// <summary>
    /// 重建稼動紀錄列表。
    /// </summary>
    private bool RebuildAvailabilityList()
    {
        _ad.Availability = new List<AvailabilityDefine>();
        _indexEvent = -1;
        _indexPause = -1;
        _indexAlarm = -1;
        _alarmList = new List<AlarmInfo>();

        if (_pp.AvailabilityDB == null || _pp.AvailabilityDB.Count == 0)
            return false;

        foreach (var field in _pp.AvailabilityDB)
            _ = AppendAvailabilityListAsync(field.Type, field.Timestamp, field.AlarmCode); // sync
        _ad.AvailabilityCollectionView = CollectionViewSource.GetDefaultView(_ad.Availability);

        return true;
    }
}
