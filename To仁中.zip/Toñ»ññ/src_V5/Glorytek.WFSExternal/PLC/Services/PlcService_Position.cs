﻿using Glorytek.WFSExternal.PLC.Contracts;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - 座標資料。
 ********************/
public partial class PlcService : IPlc_Position
{
    /********************
     * 目前軸座標
     ********************/
    /// <inheritdoc/>
    public double XAxisPosition => _pd.XAxisPosition;

    /// <inheritdoc/>
    public double YAxisPosition => _pd.YAxisPosition;

    /// <inheritdoc/>
    public double ZAxisPosition => _pd.ZAxisPosition;

    /// <inheritdoc/>
    public double RAxisPosition => _pd.RAxisPosition;

    /********************
     * 軸是否運動中
     ********************/
    /// <inheritdoc/>
    public bool AnyAxisInMotion => _pd.AnyAxisInMotion;

    /// <inheritdoc/>
    public bool XAxisInMotion => _pd.XAxisInMotion;

    /// <inheritdoc/>
    public bool YAxisInMotion => _pd.YAxisInMotion;

    /// <inheritdoc/>
    public bool ZAxisInMotion => _pd.ZAxisInMotion;

    /// <inheritdoc/>
    public bool RAxisInMotion => _pd.RAxisInMotion;
}
