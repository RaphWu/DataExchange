﻿using Glorytek.WFSCore;
using Glorytek.WFSExternal.PLC.Contracts;
using System;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - 資料處理。
 ********************/
public partial class PlcService : IPlc_Data
{
    /********************
     * 資料轉換
     ********************/
    /// <inheritdoc/>
    public short[] DataConvert_DWordToWord(int dword)
    {
        short[] word = new short[2];
        word[0] = Convert.ToInt16(dword % 0x100);
        word[1] = Convert.ToInt16(dword / 0x100);
        return word;
    }

    /// <inheritdoc/>
    public int DataConvert_WordToDWord(short[] word)
    {
        return Convert.ToInt32(word[1]) * 0x100 + Convert.ToInt32(word[0]);
    }

    /********************
     * PLC座標與PC座標轉換
     ********************/
    /// <inheritdoc/>
    public double CoorConvert_PlcToPc(int[] plcCoor)
    {
        return ((plcCoor[1] * 0x10000 + plcCoor[0]) / 1000.0).WfsFormat();
    }

    /// <inheritdoc/>
    public double CoorConvert_PlcToPc(int highWord, int lowWord)
    {
        return ((highWord * 0x10000 + lowWord) / 1000.0).WfsFormat();
    }

    /// <inheritdoc/>
    public int[] CoorConvert_PcToPlc(double pcCoor)
    {
        // mm轉um
        int val = Convert.ToInt32(pcCoor * 1000.0);

        // 高低WORD切割
        int[] plcCoor = new int[2];
        plcCoor[0] = (int)(val % 0x10000);
        plcCoor[1] = (int)((val & 0xFFFF0000) >> 16);
        if (plcCoor[1] == _internalErrorCode)
            plcCoor[1] = -1;
        return plcCoor;
    }

    /// <summary>
    /// R軸旋轉馬達的座標與角度換算比率。
    /// </summary>
    /// <remarks>因為座標轉換時有除以1000，這裡再除以100，總計是除100000。</remarks>
    private const double ANGLE_CONVERSION = 100.0;

    /// <inheritdoc/>
    public int AngleConvert_PcToPlc(double degree)
    {
        return Convert.ToInt32(degree * ANGLE_CONVERSION);
    }

    /// <inheritdoc/>
    public double AngleConvert_PlcToPc(int[] plcDegree)
    {
        return (CoorConvert_PlcToPc(plcDegree) / ANGLE_CONVERSION).WfsFormat();
    }
}
