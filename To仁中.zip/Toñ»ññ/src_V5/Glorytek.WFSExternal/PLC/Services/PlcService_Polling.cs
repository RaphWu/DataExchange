﻿using Glorytek.WFSCore;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Events;
using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Events;
using Glorytek.WFSExternal.PLC.Models;
using Serilog;
using System;
using System.Threading;
using System.Threading.Tasks;
using ThreadState = System.Threading.ThreadState;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - Polling。
 ********************/
public partial class PlcService : IPlc_Polling
{
    private static CancellationTokenSource _cts;
    private static Thread _plcPollingThread;
    private static bool isAlarmTriggering = false;

    // Polling是否完成一個週期。
    private bool _pollingCycleCompleted = false;
    private bool _slowPollingCycleCompleted = false;

    /// <inheritdoc/>
    public async Task WaitForPollingCycleCompleted()
    {
        _slowPollingCycleCompleted = false;
        _pollingCycleCompleted = false;
        _pd.PollingCycleCompleted = false;

        await Task.Run(() =>
        {
            while (!_pd.PollingCycleCompleted) { }
        });
    }

    /// <summary>
    /// 停止Polling執行。
    /// </summary>
    private void PlcPollingStop()
    {
        if (_cts != null && !_cts.IsCancellationRequested)
            _cts.Cancel();
        _plcPollingThread?.Join();
    }

    /// <summary>
    /// 啟動Polling。
    /// </summary>
    private void PlcPollingStart()
    {
        try
        {
            _cts?.Dispose();
            _cts = new CancellationTokenSource();

            if (_plcPollingThread == null || _plcPollingThread.ThreadState == ThreadState.Stopped)
            {
                _plcPollingThread = new Thread(ListenerProc);
                _plcPollingThread.Name = "ListenerProc";
                _plcPollingThread.IsBackground = true;
                _plcPollingThread.Start(_cts);
            }
        }
        //catch (ThreadStateException)
        //{
        //}
        //catch (InvalidOperationException)
        //{
        //}
        catch (OutOfMemoryException ex)
        {
            Log.Fatal(ex, "記憶體不足: PlcService->PlcPollingStart()");
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, ex.Message);
            throw;
        }
    }

    /********************
     * 即時Monitor
     ********************/
    /// <summary>
    /// PLC Polling 的監聽器。
    /// </summary>
    private void ListenerProc(object param)
    {
        CancellationTokenSource cts = (CancellationTokenSource)param;
        CancellationToken token = cts.Token;
        bool sysModeChanged = true; // 第一次啟動要更新相關內容
        int slowPollingFlag = 0;
        string cycleTimeDevice = "";

        string errorCodeAddress = $"{DeviceLists.ERROR_CODE_DEVICE}{DeviceLists.ERROR_CODE_ADDRESS}";
        string nextPointNoAddress = $"D{DeviceLists.TRAY_NEXT_POINT_NO_01 + 1}";
        string pickPointNoAddress = $"D{DeviceLists.TRAY_PICK_POINT_NO_01 + 1}";

        try
        {
            /********************
             * Polling迴圈 START
             ********************/
            while (_client.CanSend == true)
            {
                if (token.IsCancellationRequested)
                    token.ThrowIfCancellationRequested();

#if DEBUG
                //var sw = new Stopwatch();
                //sw.Restart();
#endif

                /********************
                 * 慢速Scan
                 * 慢速放前面是因為有些參數必須要先讀一次
                 ********************/
                if (slowPollingFlag == 0)
                {
                    /********************
                     * System Mode
                     ********************/
                    // M6006~M6007, M6031~M6035
                    var (sysMode1OK, sysMode1) = _client.ReadBool(DeviceLists.SYSTEM_MODE_LENS_ARRANGE, 2);
                    var (sysMode2OK, sysMode2) = _client.ReadBool(DeviceLists.SYSTEM_MODE_ONLINE_FIX_STAGE, 5);

                    if (sysMode1OK)
                    {
                        if (_pd.SystemMode_LensArrange != sysMode1[0])
                        {
                            _pd.SystemMode_LensArrange = sysMode1[0] == true;
                            sysModeChanged = true;
                        }
                        if (_pd.SystemMode_LensSorting != sysMode1[1])
                        {
                            _pd.SystemMode_LensSorting = sysMode1[1] == true;
                            sysModeChanged = true;
                        }
                    }
                    if (sysMode2OK)
                    {
                        if (_pd.SystemMode_Online_FixStage != sysMode2[0])
                        {
                            _pd.SystemMode_Online_FixStage = sysMode2[0];
                            sysModeChanged = true;
                        }
                        if (_pd.SystemMode_Online_SingleCylinder != sysMode2[1])
                        {
                            _pd.SystemMode_Online_SingleCylinder = sysMode2[1];
                            sysModeChanged = true;
                        }
                        if (_pd.SystemMode_Online_DoubleCylinder != sysMode2[2])
                        {
                            _pd.SystemMode_Online_DoubleCylinder = sysMode2[2];
                            sysModeChanged = true;
                        }
                        if (_pd.SystemMode_Online_Disc != sysMode2[3])
                        {
                            _pd.SystemMode_Online_Disc = sysMode2[3];
                            sysModeChanged = true;
                        }
                        if (_pd.SystemMode_Tray_A1 != sysMode2[4])
                        {
                            _pd.SystemMode_Tray_A1 = sysMode2[4];
                            sysModeChanged = true;
                        }
                    }

                    if (sysModeChanged)
                    {
                        if (_pd.SystemMode_Online_FixStage)
                            _sdi.SystemMode = SystemOperateModeType.Online_FixStage;
                        else if (_pd.SystemMode_LensSorting)
                            _sdi.SystemMode = SystemOperateModeType.LensSorting;
                        else if (_pd.SystemMode_LensArrange)
                            _sdi.SystemMode = SystemOperateModeType.LensArrange;
                        else if (_pd.SystemMode_Online_SingleCylinder)
                            _sdi.SystemMode = SystemOperateModeType.Online_SingleCylinder;
                        else if (_pd.SystemMode_Online_DoubleCylinder)
                            _sdi.SystemMode = SystemOperateModeType.Online_DoubleCylinder;
                        else if (_pd.SystemMode_Online_Disc)
                            _sdi.SystemMode = SystemOperateModeType.Online_Disc;
                        else if (_pd.SystemMode_Tray_A1)
                            _sdi.SystemMode = SystemOperateModeType.Tray_A1;
                        else
                            _sdi.SystemMode = SystemOperateModeType.Undefined;

                        // Cycle Time Trigger
                        if (_pd.SystemMode_Online_FixStage
                            || _pd.SystemMode_Online_DoubleCylinder
                            || _pd.SystemMode_Online_SingleCylinder
                            || _pd.SystemMode_Online_Disc)
                            cycleTimeDevice = DeviceLists.CYCLE_TRIGGER_AUTO;
                        else if (_pd.SystemMode_LensSorting)
                            cycleTimeDevice = DeviceLists.CYCLE_TRIGGER_LENS_SORTING;
                        else if (_pd.SystemMode_LensArrange)
                            cycleTimeDevice = DeviceLists.CYCLE_TRIGGER_LENS_ARRANGE;
                        else
                            cycleTimeDevice = "";

                        _ea.GetEvent<SystemModeChangedEvent>().Publish(0);
                        sysModeChanged = false;
                    }

                    /********************
                     * 軸
                     ********************/
                    // D2700~D2706
                    // 軸座標
                    var (posOK, pos) = ReadDoubleByInt32(DeviceLists.X_AXIS_POSITION, 4);
                    if (posOK)
                    {
                        _pd.XAxisPosition = pos[0];
                        _pd.YAxisPosition = pos[1];
                        _pd.ZAxisPosition = pos[2];
                        _pd.RAxisPosition = (pos[3] / 100.0).WfsFormat();
                    }

                    // X0A48~X0A4B,X0A4C~X0A4F
                    // 異常,BUSY
                    var (axisAbnormalOK, axisAbnormalValues) = ReadBool(DeviceLists.X_AXIS_ABNORMAL, 4);
                    if (axisAbnormalOK)
                    {
                        _pd.XAxisAbnormal = axisAbnormalValues[0];  // X0A88
                        _pd.YAxisAbnormal = axisAbnormalValues[1];  // X0A89
                        _pd.ZAxisAbnormal = axisAbnormalValues[2];  // X0A8A
                        _pd.RAxisAbnormal = axisAbnormalValues[3];  // X0A8B
                    }

                    // D205~D208
                    // 錯誤碼
                    if (_pd.Alarm || slowPollingFlag == 0)
                    {
                        var (axisErrorCodeOK, axisErrorCode) = ReadInt16(DeviceLists.X_AXIS_ERROR_CODE, 4);
                        if (axisErrorCodeOK)
                        {
                            _pd.XAxisErrorCode = axisErrorCode[0];
                            _pd.YAxisErrorCode = axisErrorCode[1];
                            _pd.ZAxisErrorCode = axisErrorCode[2];
                            _pd.RAxisErrorCode = axisErrorCode[3];
                        }
                    }

                    // L1~L4
                    // Error Code
                    var (errorCodeOK, errorCode) = _client.ReadBool(errorCodeAddress, DeviceLists.ERROR_CODE_TOTAL);
                    if (errorCodeOK)
                    {
                        bool alarmTriggered = false;
                        for (int index = 0; index < DeviceLists.ERROR_CODE_TOTAL; index++)
                        {
                            if (_pd.ErrorCodeList[index] != errorCode[index])
                            {
                                _pd.ErrorCodeList[index] = errorCode[index];

                                int code = index + 1;
                                if (errorCode[index])
                                {
                                    // 有警報被觸發
                                    _availability.AddNewRecord(AvailabilityType.AlarmTriggering, code);
                                    alarmTriggered = true;
                                    isAlarmTriggering = true;
                                }
                                else
                                {
                                    // 有警報被解除
                                    _availability.AddNewRecord(AvailabilityType.AlarmClear, code);
                                }
                            }
                        }

                        // 警報排除完畢
                        if (isAlarmTriggering && !alarmTriggered)
                            isAlarmTriggering = false;
                    }

                    /********************
                     * 運轉
                     ********************/
                    // M40~M45
                    var (operationOK, operation) = _client.ReadBool(DeviceLists.AUTO_MODE, 5);
                    if (operationOK)
                    {
                        _pd.AutoMode = operation[0];      // M40
                        _pd.ManualMode = operation[1];    // M41
                                                          // M42
                                                          // M43
                        _pd.MachinePause = operation[4];  // M44
                    }

                    // M20/M40/Y659
                    //aptcRet = ReadBoolFromPlcBit(DeviceLists.AUTO_START_LAMP, out bool autoStartLamp);
                    //_pd.AutoStartLamp = _pd.AutoMode || autoStartLamp;

                    // M6003
                    var (testModeOK, testMode) = _client.ReadBool(DeviceLists.TEST_MODE);
                    if (testModeOK)
                        _pd.TestMode = (bool)testMode;

                    // 監視自動停止信號
                    if (_pd.AutoMode && PlcParameters.Instance.AutoRunningSignal)
                    {
                        // M14500
                        var (autoStopOK, autoStop) = _client.ReadBool(DeviceLists.AUTO_MODE_STOP);
                        if (autoStopOK && (bool)autoStop)
                        {
                            PlcParameters.Instance.AutoRunningSignal = false;
                            _ea.GetEvent<AutoStopSignal>().Publish(true);
                        }
                    }

                    // D6175~D6177
                    var (estimatedQuantitysOK, estimatedQuantitys) = _client.ReadInt16(DeviceLists.ESTIMATED_QUANTITY_SETTING, 3);
                    if (estimatedQuantitysOK)
                    {
                        if (_pd.EstimatedQuantitySetting != estimatedQuantitys[0])
                            _pd.EstimatedQuantitySetting = estimatedQuantitys[0];

                        if (_pd.EstimatedQuantity != estimatedQuantitys[1])
                            _pd.EstimatedQuantity = estimatedQuantitys[1];

                        if (_pd.CurrentSequence != estimatedQuantitys[2])
                            _pd.CurrentSequence = estimatedQuantitys[2];
                    }

                    /********************
                     * 復歸
                     ********************/
                    // M7100
                    var (homeReturningOK, homeReturning) = _client.ReadBool(DeviceLists.HOME_RETURNING);
                    if (homeReturningOK)
                        _pd.HomeReturning = (bool)homeReturning;

                    // M7117
                    var (homeReturnOK, homeReturn) = _client.ReadBool(DeviceLists.HOME_RETURN_COMPLETED);
                    if (homeReturnOK)
                        _pd.HomeReturnCompleted = (bool)homeReturn;

                    /********************
                     * JOG
                     ********************/
                    // L200~L205
                    var (jogSpeedOK, jogSpeed) = _client.ReadBool(DeviceLists.JOG_SPEED_SLOW, 6);
                    if (jogSpeedOK)
                    {
                        if (jogSpeed[0])
                            _pd.JogSpeed = JogSpeedList.Slow;
                        else if (jogSpeed[1])
                            _pd.JogSpeed = JogSpeedList.Low;
                        else if (jogSpeed[2])
                            _pd.JogSpeed = JogSpeedList.Medium;
                        else if (jogSpeed[3])
                            _pd.JogSpeed = JogSpeedList.High;
                        else if (jogSpeed[4])
                            _pd.JogSpeed = JogSpeedList.Highest;
                        else
                            _pd.JogSpeed = JogSpeedList.Unknown;

                        // 限速啟動
                        _pd.SpeedLimitActivated = jogSpeed[5];
                        //var (speedLimitActivatedOK, speedLimitActivated) = ReadBool(PlcDatas.SPEED_LIMIT_ACTIVATED);
                        //if (speedLimitActivatedOK)
                        //    _pd.SpeedLimitActivated = speedLimitActivated;
                    }

                    /********************
                     * STAGE
                     ********************/
                    // X0B~X0D
                    var (vaccumDetectorOK, vaccumDetector) = _client.ReadBool(DeviceLists.NOZZLE_VACCUM_DETECTOR, 3);
                    if (vaccumDetectorOK)
                    {
                        _pd.NozzleVaccumDetector = vaccumDetector[0];
                        _pd.Stage1VaccumDetector = vaccumDetector[1];
                        _pd.Stage2VaccumDetector = vaccumDetector[2];
                    }

                    // Y4F~Y54
                    var (vaccumStatusOK, vaccumStatus) = _client.ReadBool(DeviceLists.NOZZLE_VACCUM, 6);
                    if (vaccumStatusOK)
                    {
                        _pd.NozzleVaccum = vaccumStatus[0];
                        _pd.NozzleRelief = vaccumStatus[1];
                        _pd.Stage1Vaccum = vaccumStatus[2];
                        _pd.Stage1Relief = vaccumStatus[3];
                        _pd.Stage2Vaccum = vaccumStatus[4];
                        _pd.Stage2Relief = vaccumStatus[5];
                    }

                    // X10~X15
                    var (cylinderDataOK, cylinderData) = _client.ReadBool(DeviceLists.STAGE_1_LS_MEASUREMENT, 6);
                    if (cylinderDataOK)
                    {
                        _pd.Cylinder1LsMeasurement = cylinderData[0];
                        _pd.Cylinder1LsSorting = cylinderData[1];
                        _pd.Cylinder2LsMeasurement = cylinderData[2];
                        _pd.Cylinder2LsSorting = cylinderData[3];
                        _pd.Stage1ScrapDetector = cylinderData[4];
                        _pd.Stage2ScrapDetector = cylinderData[5];
                    }

                    /********************
                     * IO
                     ********************/
                    // X0F
                    // 光柵
                    var (lightCurtainOK, lightCurtain) = _client.ReadBool(DeviceLists.LIGHT_CURTAIN);
                    if (lightCurtainOK)
                        _pd.LightCurtain = (bool)lightCurtain;

                    // M21
                    // 靜電消除器
                    var (ionotronOK, ionotron) = _client.ReadBool(DeviceLists.IONOTRON);
                    if (ionotronOK)
                        _pd.Ionotron = (bool)ionotron;

                    // Y55
                    // 照明
                    var (lightsOK, lights) = _client.ReadBool(DeviceLists.LIGHTS);
                    if (lightsOK)
                        _pd.Lights = (bool)lights;

                    // X0E
                    // 門
                    var (doorsOK, doors) = _client.ReadBool(DeviceLists.DOORS);
                    if (doorsOK)
                        _pd.Doors = (bool)doors;

                    // Y4C~Y4D
                    // 三色燈
                    var (stackLightOK, stackLight) = _client.ReadBool(DeviceLists.STACK_LIGHT_GREEN, 2);
                    if (stackLightOK)
                    {
                        _pd.StackLightGreen = stackLight[0];
                        _pd.StackLightYellow = stackLight[0];
                        _pd.StackLightRed = stackLight[1];
                    }

                    /********************
                     * PLC狀態轉給系統
                     ********************/
                    _sdi.MachinePause = _pd.MachinePause;
                    if (_sdi.MachinePause != _pd.MachinePause)
                        _availability.AddNewRecord(_pd.MachinePause ? AvailabilityType.PauseStart : AvailabilityType.PauseCancel);

                    _sdi.AutoMode = _pd.AutoMode;
                    if (_sdi.AutoMode != _pd.AutoMode)
                        _availability.AddNewRecord(_pd.AutoMode ? AvailabilityType.StartOperate : AvailabilityType.StopOperate);

                    //if (_sdi.NonAutoMode != _pd.NonAutoMode)
                    _sdi.NonAutoMode = _pd.NonAutoMode;

                    //if (_sdi.ManualMode != _pd.ManualMode)
                    _sdi.ManualMode = _pd.ManualMode;

                    //if (_sdi.PlcReady != _pd.Ready)
                    _sdi.PlcReady = _pd.Ready;

                    //if (_sdi.PlcStabilized != _pd.Stabilized)
                    _sdi.PlcStabilized = _pd.Stabilized;

                    //if (_sdi.PlcStabilizedExceptAutoMode != _pd.StabilizedExceptAutoMode)
                    _sdi.PlcStabilizedExceptAutoMode = _pd.StabilizedExceptAutoMode;

                    //if (_sdi.TestMode != _pd.TestMode)
                    _sdi.TestMode = _pd.TestMode;

                    //if (_sdi.PlcAlarm != _pd.Alarm)
                    _sdi.PlcAlarm = _pd.Alarm;

                    if (!_slowPollingCycleCompleted)
                        _slowPollingCycleCompleted = true;
                }

                /********************
                 * 異常
                ********************/
                // Y0A80
                var (allAxisReadyOK, allAxisReady) = _client.ReadBool(DeviceLists.ALL_AXIS_READY);
                if (allAxisReadyOK)
                    _pd.AllServoReady = (bool)allAxisReady;

                /********************
                 * 極限
                 ********************/
                // M6950~M6968
                var (allAxisLimitOK, allAxisLimit) = _client.ReadBool(DeviceLists.X_AXIS_RLS, 19);
                if (allAxisLimitOK)
                {
                    _pd.XAxisRLS = allAxisLimit[00];
                    _pd.XAxisFLS = allAxisLimit[01];
                    _pd.XAxisOPG = allAxisLimit[02];
                    _pd.XAxisDOG = allAxisLimit[03];
                    _pd.YAxisRLS = allAxisLimit[05];
                    _pd.YAxisFLS = allAxisLimit[06];
                    _pd.YAxisOPG = allAxisLimit[07];
                    _pd.YAxisDOG = allAxisLimit[08];
                    _pd.ZAxisRLS = allAxisLimit[10];
                    _pd.ZAxisFLS = allAxisLimit[11];
                    _pd.ZAxisOPG = allAxisLimit[12];
                    _pd.ZAxisDOG = allAxisLimit[13];
                    _pd.RAxisRLS = allAxisLimit[15];
                    _pd.RAxisFLS = allAxisLimit[16];
                    _pd.RAxisOPG = allAxisLimit[17];
                    _pd.RAxisDOG = allAxisLimit[18];
                }

                /********************
                 * 運動中
                 ********************/
                // M6980~M6995
                var (axisInMotionOK, axisInMotion) = _client.ReadBool(DeviceLists.X_AXIS_IN_MOTION, 4);
                if (axisInMotionOK)
                {
                    _pd.XAxisInMotion = axisInMotion[0]; // X0A8C
                    _pd.YAxisInMotion = axisInMotion[1]; // X0A8D
                    _pd.ZAxisInMotion = axisInMotion[2]; // X0A8E
                    _pd.RAxisInMotion = axisInMotion[3]; // X0A8F 
                    _pd.AnyAxisInMotion = _pd.XAxisInMotion || _pd.YAxisInMotion || _pd.ZAxisInMotion || _pd.RAxisInMotion;
                }

                /********************
                 * INP
                 ********************/
                //// X0~X6
                //var (inpOK, inp) = ReadBool(DeviceLists.X_AXIS_INP, 7);
                //if (inpOK)
                //{
                //    _pd.XAxisINP = inp[0];
                //    _pd.YAxisINP = inp[2];
                //    _pd.ZAxisINP = inp[4];
                //    _pd.RAxisINP = inp[6];
                //}

                /********************
                 * Pallet & Tray
                 * PLC是以「動作點位」做取放動作。
                 * 動作完後，再將此點位存至「目前點位」，然後「動作點位」+1指向下一個「動作點位」待命
                 ********************/
                bool isPointNoChanged = false;

                // D6101~D6124
                // 動作點位
                var (actionPointNoOK, actionPointNo) = _client.ReadInt16(nextPointNoAddress, 24);
                if (actionPointNoOK)
                    for (int palletIndex = 0; palletIndex < 24; palletIndex++)
                    {
                        if (_pd.NextPointNo[palletIndex] != actionPointNo[palletIndex])
                        {
                            isPointNoChanged = true;
                            _pd.NextPointNo[palletIndex] = actionPointNo[palletIndex];
                        }
                    }

                // D6151~D6174
                // 目前點位
                var (pointNoOK, pointNo) = _client.ReadInt16(pickPointNoAddress, 24);
                if (pointNoOK)
                    for (int palletIndex = 0; palletIndex < 24; palletIndex++)
                    {
                        if (_pd.PickPointNo[palletIndex] != pointNo[palletIndex])
                        {
                            isPointNoChanged = true;
                            _pd.PickPointNo[palletIndex] = pointNo[palletIndex];
                        }
                    }

                if (isPointNoChanged)
                    _ea.GetEvent<PalletInfoChangedEvent>().Publish(false);

                // M7071~M7094
                // 滿/空盤
                var (fullOrEmptyOK, fullOrEmpty) = _client.ReadBool(DeviceLists.TRAY_FULL_EMPTY, 24);
                if (fullOrEmptyOK)
                    _pd.TrayFullOrEmpty = fullOrEmpty;

                /********************
                 * PLC取放料交握
                 ********************/
                // M7165
                var (whenPickOK, whenPick) = _client.ReadBool(DeviceLists.WHEN_PICK);
                if (whenPickOK)
                    WhenPickEventTrigger = (bool)whenPick;

                // M7534
                var (whenPlaceOnlineOK, whenPlaceOnline) = _client.ReadBool(DeviceLists.WHEN_PLACE_ONLINE);
                if (whenPlaceOnlineOK)
                    WhenOnline_PlaceEventTrigger = (bool)whenPlaceOnline;

                // M14049
                var (whenPlaceLensSortingOK, whenPlaceLensSorting) = _client.ReadBool(DeviceLists.WHEN_PLACE_LENS_SORTING);
                if (whenPlaceLensSortingOK)
                    WhenLensSorting_PlaceEventTrigger = (bool)whenPlaceLensSorting;

                /********************
                 * Cycle Time
                 ********************/
                if (cycleTimeDevice != string.Empty)
                {
                    var (cycleTimeTriggerOK, cycleTimeTrigger) = _client.ReadBool(cycleTimeDevice);
                    if (cycleTimeTriggerOK)
                        CycleTimeTrigger((bool)cycleTimeTrigger);
                }

                if (!_pollingCycleCompleted)
                    _pollingCycleCompleted = true;

                if (!_pd.PollingCycleCompleted && _slowPollingCycleCompleted && _pollingCycleCompleted)
                    _pd.PollingCycleCompleted = true;

#if DEBUG
                /* for test */
                //sw.Stop();
                //MessageBox.Show(sw.ElapsedMilliseconds.ToString());
#endif

                Task.Delay(15).Wait(); // 每次Polling的時間間隔(ms)
                if (++slowPollingFlag >= 5) // 每幾次Polling才執行一次慢速Scan
                    slowPollingFlag = 0;
            }
            /********************
             * Polling迴圈 END
             ********************/
        }
        catch (OperationCanceledException)
        {
            // do nothing for Cancellation
        }
        catch (Exception ex)
        {
            Log.Warning(ex, $"ListenerProc()異常: {ex.Message}");
        }
    }
}