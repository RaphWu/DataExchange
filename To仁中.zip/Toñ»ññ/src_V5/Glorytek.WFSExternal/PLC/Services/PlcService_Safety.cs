﻿using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - 安全防護。
 ********************/
public partial class PlcService : IPlc_Safety
{
    ///// <inheritdoc/>(移至MachineDefine)
    //public double SaftyHeight
    //{
    //    get { return PlcDatas.Instance.SaftyHeight; }
    //    set
    //    {
    //        int[] values = CoorConvert_PcToPlc(value);
    //        plcClient.WriteDeviceBlock(PlcDatas.SAFTY_HEIGHT, 1, ref values[0]);
    //    }
    //}

    /// <inheritdoc/>
    public bool SpeedLimitActivated => PlcDatas.Instance.SpeedLimitActivated;
}
