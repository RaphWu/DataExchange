﻿using Glorytek.WFSCore;
using Glorytek.WFSExternal.PLC.Contracts;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - MC協議繼承與擴充。
 ********************/
public partial class PlcService : IPlc_MitsubishiClient
{
    /****************************************
    * 讀寫主函數
    ****************************************/
    /// <inheritdoc/>
    public (bool isSucceed, byte[] responseMessages) Read(string address, int length, bool isBit)
    {
        return _client.Read(address, length, isBit);
    }

    /// <inheritdoc/>
    public (bool isSucceed, byte[] responseMessages) Read(string address, int length)
    {
        return _client.Read(address, length);
    }

    /// <inheritdoc/>
    public (bool isSucceed, byte[] responseMessages) Read(string[] wordAddress, string[] dwordAddress)
    {
        return _client.Read(wordAddress, dwordAddress);
    }

    /// <inheritdoc/>
    public bool Write(string address, byte[] data, int length, bool isBit)
    {
        return _client.Write(address, data, length, isBit);
    }

    /// <inheritdoc/>
    public bool Write(string address, byte[] data, int length)
    {
        return _client.Write(address, data, length);
    }

    /// <inheritdoc/>
    public bool Write(string[] wordAddress, byte[] wordValues, string[] dwordAddress, byte[] dwordValues, bool isBit)
    {
        return _client.Write(wordAddress, wordValues, dwordAddress, dwordValues, isBit);
    }

    /// <inheritdoc/>
    public bool Write(string[] wordAddress, byte[] wordValues, string[] dwordAddress, byte[] dwordValues)
    {
        return _client.Write(wordAddress, wordValues, dwordAddress, dwordValues);
    }

    /****************************************
    * 讀寫輔助函數
    ****************************************/
    /********************
    * bool
    ********************/
    /// <inheritdoc/>
    public (bool isSucceed, bool? result) ReadBool(string address)
    {
        return _client.ReadBool(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, bool[] results) ReadBool(string address, int readNumber)
    {
        return _client.ReadBool(address, readNumber);
    }

    /// <inheritdoc/>
    public bool WriteBool(string address, bool value)
    {
        return _client.WriteBool(address, value);
    }

    /// <inheritdoc/>
    public bool WriteBool(string address, bool[] values)
    {
        return _client.WriteBool(address, values);
    }

    /// <inheritdoc/>
    public bool WriteBool(string[] address, bool[] values)
    {
        return _client.WriteBool(address, values);
    }

    /********************
    * int16
    ********************/
    /// <inheritdoc/>
    public (bool isSucceed, short result) ReadInt16(string address)
    {
        return _client.ReadInt16(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, short[] results) ReadInt16(string address, int readNumber)
    {
        return _client.ReadInt16(address, readNumber);
    }

    /// <inheritdoc/>
    public (bool isSucceed, short[] results) ReadInt16(string[] address)
    {
        return _client.ReadInt16(address);
    }

    /// <inheritdoc/>
    public bool WriteInt16(string address, short value)
    {
        return _client.WriteInt16(address, value);
    }

    /// <inheritdoc/>
    public bool WriteInt16(string address, short[] values)
    {
        return _client.WriteInt16(address, values);
    }

    /// <inheritdoc/>
    public bool WriteInt16(string[] address, short[] values)
    {
        return _client.WriteInt16(address, values);
    }

    /********************
     * uint16
     ********************/
    /// <inheritdoc/>
    public (bool isSucceed, ushort result) ReadUInt16(string address)
    {
        return _client.ReadUInt16(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, ushort[] results) ReadUInt16(string address, int readNumber)
    {
        return _client.ReadUInt16(address, readNumber);
    }

    /// <inheritdoc/>
    public (bool isSucceed, ushort[] results) ReadUInt16(string[] address)
    {
        return _client.ReadUInt16(address);
    }

    /// <inheritdoc/>
    public bool WriteUInt16(string address, ushort value)
    {
        return _client.WriteUInt16(address, value);
    }

    /// <inheritdoc/>
    public bool WriteUInt16(string address, ushort[] values)
    {
        return _client.WriteUInt16(address, values);
    }

    /// <inheritdoc/>
    public bool WriteUInt16(string[] address, ushort[] values)
    {
        return _client.WriteUInt16(address, values);
    }

    /********************
     * 讀取 int32
     ********************/
    /// <inheritdoc/>
    public (bool isSucceed, int result) ReadInt32(string address)
    {
        return _client.ReadInt32(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, int[] result) ReadInt32(string address, int readNumber)
    {
        return _client.ReadInt32(address, readNumber);
    }

    /// <inheritdoc/>
    public (bool isSucceed, int[] result) ReadInt32(string[] address)
    {
        return _client.ReadInt32(address);
    }

    /// <inheritdoc/>
    public bool WriteInt32(string address, int value)
    {
        return _client.WriteInt32(address, value);
    }

    /// <inheritdoc/>
    public bool WriteInt32(string address, int[] values)
    {
        return _client.WriteInt32(address, values);
    }

    /// <inheritdoc/>
    public bool WriteInt32(string[] address, int[] values)
    {
        return _client.WriteInt32(address, values);
    }

    /********************
     * 讀取 uint32
     ********************/
    /// <inheritdoc/>
    public (bool isSucceed, uint result) ReadUInt32(string address)
    {
        return _client.ReadUInt32(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, uint[] result) ReadUInt32(string address, int readNumber)
    {
        return _client.ReadUInt32(address, readNumber);
    }

    /// <inheritdoc/>
    public (bool isSucceed, uint[] result) ReadUInt32(string[] address)
    {
        return _client.ReadUInt32(address);
    }

    /// <inheritdoc/>
    public bool WriteUInt32(string address, uint value)
    {
        return _client.WriteUInt32(address, value);
    }

    /// <inheritdoc/>
    public bool WriteUInt32(string address, uint[] values)
    {
        return _client.WriteUInt32(address, values);
    }

    /// <inheritdoc/>
    public bool WriteUInt32(string[] address, uint[] values)
    {
        return _client.WriteUInt32(address, values);
    }

    /********************
     * int64
     ********************/
    /// <inheritdoc/>
    public (bool isSucceed, long result) ReadInt64(string address)
    {
        return _client.ReadInt64(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, long[] result) ReadInt64(string address, int readNumber)
    {
        return _client.ReadInt64(address, readNumber);
    }

    /// <inheritdoc/>
    public bool WriteInt64(string address, long value)
    {
        return _client.WriteInt64(address, value);
    }

    /// <inheritdoc/>
    public bool WriteInt64(string address, long[] values)
    {
        return _client.WriteInt64(address, values);
    }

    /********************
     * uint64
     ********************/
    /// <inheritdoc/>
    public (bool isSucceed, ulong result) ReadUInt64(string address)
    {
        return _client.ReadUInt64(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, ulong[] result) ReadUInt64(string address, int readNumber)
    {
        return _client.ReadUInt64(address, readNumber);
    }

    /// <inheritdoc/>
    public bool WriteUInt64(string address, ulong value)
    {
        return _client.WriteUInt64(address, value);
    }

    /// <inheritdoc/>
    public bool WriteUInt64(string address, ulong[] values)
    {
        return _client.WriteUInt64(address, values);
    }

    /********************
     * float
     ********************/
    /// <inheritdoc/>
    public (bool isSucceed, float result) ReadFloat(string address)
    {
        return _client.ReadFloat(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, float[] result) ReadFloat(string address, int readNumber)
    {
        return _client.ReadFloat(address, readNumber);
    }

    /// <inheritdoc/>
    public (bool isSucceed, float[] result) ReadFloat(string[] address)
    {
        return _client.ReadFloat(address);
    }

    /// <inheritdoc/>
    public bool WriteFloat(string address, float value)
    {
        return _client.WriteFloat(address, value);
    }

    /// <inheritdoc/>
    public bool WriteFloat(string address, float[] value)
    {
        return _client.WriteFloat(address, value);
    }

    /// <inheritdoc/>
    public bool WriteFloat(string[] address, float[] value)
    {
        return _client.WriteFloat(address, value);
    }

    /********************
     * double
     ********************/
    /// <inheritdoc/>
    public (bool isSucceed, double result) ReadDouble(string address)
    {
        return _client.ReadDouble(address);
    }

    /// <inheritdoc/>
    public (bool isSucceed, double[] result) ReadDouble(string address, int readNumber)
    {
        return _client.ReadDouble(address, readNumber);
    }

    /// <inheritdoc/>
    public bool WriteDouble(string address, double value)
    {
        return _client.WriteDouble(address, value);
    }

    /// <inheritdoc/>
    public bool WriteDouble(string address, double[] value)
    {
        return _client.WriteDouble(address, value);
    }

    /********************
    * string
    ********************/
    /// <inheritdoc/>
    public (bool isSucceed, string result) ReadAscii(string stringAddress, string sizeAddress)
    {
        return _client.ReadAscii(stringAddress, sizeAddress);
    }

    /// <inheritdoc/>
    public bool WriteAscii(string stringAddress, string sizeAddress, string value)
    {
        return _client.WriteAscii(stringAddress, sizeAddress, value);
    }

    /// <inheritdoc/>
    public (bool isSucceed, string result) ReadUtf8(string stringAddress, string sizeAddress)
    {
        return _client.ReadUtf8(stringAddress, sizeAddress);
    }

    /// <inheritdoc/>
    public bool WriteUtf8(string stringAddress, string sizeAddress, string value)
    {
        return _client.WriteUtf8(stringAddress, sizeAddress, value);
    }

    /********************
    * 報文處理
    ********************/
    /// <inheritdoc/>
    public (bool isSucceed, byte[] responseMsg) SendAndReceive(byte[] command)
    {
        return _client.SendAndReceive(command);
    }

    /********************
    * WFS用
    ********************/
    /// <inheritdoc/>
    public (bool isSucceed, double result) ReadDoubleByInt32(string address)
    {
        var (isSucceed, readResult) = _client.ReadInt32(address);
        if (isSucceed)
            return (true, (readResult / 1000.0).WfsFormat());
        else
            return (false, 0);
    }

    /// <inheritdoc/>
    public (bool isSucceed, double[] results) ReadDoubleByInt32(string address, int readNumber)
    {
        double[] result = new double[readNumber];
        var (isSucceed, readResult) = _client.ReadInt32(address, readNumber);
        if (isSucceed)
        {
            for (int index = 0; index < readNumber; index++)
                result[index] = (readResult[index] / 1000.0).WfsFormat();
        }
        return (isSucceed, result);
    }

    /// <inheritdoc/>
    public (bool isSucceed, double[] results) ReadDoubleByInt32(string[] address)
    {
        int readNumber = address.Length;
        double[] result = new double[readNumber];
        var (isSucceed, readResult) = _client.ReadInt32(address);
        if (isSucceed)
        {
            for (int index = 0; index < readNumber; index++)
                result[index] = (readResult[index] / 1000.0).WfsFormat();
        }
        return (isSucceed, result);
    }

    /// <inheritdoc/>
    public bool WriteDoubleByInt32(string address, double value)
    {
        return _client.WriteInt32(address, (int)(value * 1000.0));
    }

    /// <inheritdoc/>
    public bool WriteDoubleByInt32(string address, double[] values)
    {
        int writeNumber = values.Length;
        int[] writeValues = new int[writeNumber];
        for (int index = 0; index < writeNumber; index++)
            writeValues[index] = (int)(values[index] * 1000.0);
        return _client.WriteInt32(address, writeValues);
    }

    /// <inheritdoc/>
    public bool WriteDoubleByInt32(string[] address, double[] values)
    {
        int writeNumber = address.Length;
        int[] writeValues = new int[writeNumber];
        for (int index = 0; index < writeNumber; index++)
            writeValues[index] = (int)(values[index] * 1000.0);
        return _client.WriteInt32(address, writeValues);
    }
}
