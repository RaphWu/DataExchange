﻿using Glorytek.WFSCore.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using System.Diagnostics;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - 與軟體系統相關。
 ********************/
public partial class PlcService : IPlc_System
{
    /// <summary>
    /// Cycle Time碼表。
    /// </summary>
    private static readonly Stopwatch _ctStopwatch = new();

    /// <summary>
    /// 將系統模式寫入PLC。
    /// </summary>
    /// <param name="mode">要切換的模式。參見: <see cref="SystemOperateModeType"/>。</param>
    public void SetSystemMode(SystemOperateModeType mode)
    {
        WriteBool(DeviceLists.SYSTEM_MODE_LENS_ARRANGE, new bool[]
        {
            mode == SystemOperateModeType.LensArrange,
            mode == SystemOperateModeType.LensSorting,
        });
        WriteBool(DeviceLists.SYSTEM_MODE_ONLINE_FIX_STAGE, new bool[]
        {
            mode == SystemOperateModeType.Online_FixStage,
            mode == SystemOperateModeType.Online_SingleCylinder,
            mode == SystemOperateModeType.Online_DoubleCylinder,
            mode == SystemOperateModeType.Online_Disc,
            mode == SystemOperateModeType.Tray_A1,
        });
    }

    /********************
     * Cycle Time碼表
     ********************/
    /// <inheritdoc/>
    public void StartCTStopwatch()
    {
        _ctStopwatch.Start();
    }

    /// <inheritdoc/>
    public void StopCTStopwatch()
    {
        _ctStopwatch.Stop();
    }

    /// <inheritdoc/>
    public void ResetCTStopwatch()
    {
        _ctStopwatch.Reset();
    }

    /// <inheritdoc/>
    public void WriteCycleTime()
    {
        _pd.CycleTime = _ctStopwatch.ElapsedMilliseconds;
    }

    /// <inheritdoc/>
    public void CycleTimeTrigger(bool signal)
    {
        if (signal != _signal)
        {
            _signal = signal;
            if (signal)
            {
                _ctStopwatch.Stop();
                _pd.CycleTime = _ctStopwatch.ElapsedMilliseconds;
                _ctStopwatch.Reset();
                _ctStopwatch.Start();
            }
        }
    }
    private static bool _signal = false;
}
