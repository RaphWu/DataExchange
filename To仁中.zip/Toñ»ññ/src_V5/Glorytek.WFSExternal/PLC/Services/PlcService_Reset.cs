﻿using Glorytek.WFSExternal.PLC.Contracts;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - 復歸與重置處理。
 ********************/
public partial class PlcService : IPlc_Reset
{
    /// <inheritdoc/>
    public void HomeReturn()
    {
        if (!Ready || _pd.HomeReturning)
            return;

        SendCommandPulse(DeviceLists.HOME_RETURN_COMMAND);
    }

    /// <inheritdoc/>
    public void HomeReturnXAxis()
    {
        if (!Ready || _pd.HomeReturning)
            return;

        SendCommandPulse(DeviceLists.HOME_RETURN_X_COMMAND);
    }

    /// <inheritdoc/>
    public void HomeReturnYAxis()
    {
        if (!Ready || _pd.HomeReturning)
            return;

        SendCommandPulse(DeviceLists.HOME_RETURN_Y_COMMAND);
    }

    /// <inheritdoc/>
    public void PlcReset()
    {
        // 重置交握信號
        // 當系統有異常且程式跳出時，PLC不會自動重置這些信號。當程式再開時，將不斷進入交握狀態而無法回正常待機狀態
        _client.WriteBool(DeviceLists.WHEN_PICK, false);
        _client.WriteBool(DeviceLists.WHEN_PLACE_ONLINE, false);
        _client.WriteBool(DeviceLists.WHEN_PLACE_LENS_SORTING, false);

        // 送出停止信號，重置啟動&暫停
        _client.WriteBool(DeviceLists.STOP_COMMAND, false);
        SendCommandPulse(DeviceLists.STOP_COMMAND);

        // 確認停止所有JOG動作(曾發生爆衝疑似是此原因)
        AllJogStop();

        // 警報復歸
        _client.WriteBool(DeviceLists.ALARM_RESET_COMMAND, false);
        SendCommandPulse(DeviceLists.ALARM_RESET_COMMAND);
    }
}
