﻿using Glorytek.WFSExternal.PLC.Events;
using System.Threading.Tasks;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - PLC交握。
 ********************/
public partial class PlcService
{
    /// <summary>
    /// 取料交握處理中。
    /// </summary>
    private static bool _pickEventRunning = false;

    /// <summary>
    /// 放料交握處理中。
    /// </summary>
    private static bool _placeEventRunning = false;

    /// <summary>
    /// 連線模式 取料觸發。
    /// </summary>
    public bool WhenPickEventTrigger
    {
        get { return _whenPickEventTrigger; }
        set
        {
            if (_whenPickEventTrigger != value)
            {
                _whenPickEventTrigger = value;
                if (value && !_pickEventRunning)
                {
                    _pickEventRunning = true;
                    UpdatePickTrayId();
                    _ea.GetEvent<PlcHandshakeEvent>().Publish("PICK");
                }
            }
        }
    }
    private bool _whenPickEventTrigger;

    /// <summary>
    /// 連線模式 放料觸發。
    /// </summary>
    public bool WhenOnline_PlaceEventTrigger
    {
        get { return _whenOnline_PlaceEventTrigger; }
        set
        {
            if (_whenOnline_PlaceEventTrigger != value)
            {
                _whenOnline_PlaceEventTrigger = value;
                if (value && !_placeEventRunning)
                {
                    _placeEventRunning = true;
                    UpdatePickTrayId();
                    _ea.GetEvent<PlcHandshakeEvent>().Publish("PLACE");
                }
            }
        }
    }
    private bool _whenOnline_PlaceEventTrigger;

    /// <summary>
    /// 分檢模式 放料觸發。
    /// </summary>
    public bool WhenLensSorting_PlaceEventTrigger
    {
        get { return _whenOnline_PlaceEventTrigger; }
        set
        {
            if (_whenLensSorting_PlaceEventTrigger != value)
            {
                _whenLensSorting_PlaceEventTrigger = value;
                if (value && !_placeEventRunning)
                {
                    _placeEventRunning = true;
                    UpdatePickTrayId();
                    _ea.GetEvent<PlcHandshakeEvent>().Publish("PLACE");
                }
            }
        }
    }
    private bool _whenLensSorting_PlaceEventTrigger;

    /// <summary>
    /// 更新取料動作的Tray盤號。
    /// </summary>
    private void UpdatePickTrayId()
    {
        Task.Delay(60); // 暫存器讀取是30ms間隔
        var (pickTrayIdOK, pickTrayId) = ReadInt16(DeviceLists.WHEN_PICK_TRAY_ID);
        if (pickTrayIdOK)
            _pd.PickTrayId = pickTrayId;
    }

    /********************
     * Feedback Event
     ********************/
    /// <summary>
    /// 返回PLC的交握。
    /// </summary>
    /// <param name="palletPositionNo">盤號>=1，返回放置的Pallet ID。<br/>盤號==0，僅返回交握訊號。</param>
    private void EventFeedback(int palletPositionNo)
    {
        if (_pd.AutoMode)
        {
            if (palletPositionNo >= 1)
            {
                string posiId = $"M{DeviceLists.PLACE_TRAY + palletPositionNo}";
                SendCommandPulse(posiId);
                _placeEventRunning = false;
            }
            else
            {
                // PICK 
                SendCommandPulse(DeviceLists.WHEN_PICK_FEEDBACK);
                _pickEventRunning = false;
            }
        }
    }
}
