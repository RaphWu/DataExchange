﻿using Glorytek.WFSExternal.PLC.Contracts;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - 作業品種處理。
 ********************/
public partial class PlcService : IPlc_Product
{
    /********************
     * 品種名稱存取
     ********************/
    /// <inheritdoc/>
    public void WriteProductName(string productName)
    {
        if (_client != null && _client.Online)
            _client.WriteUtf8(DeviceLists.PRODUCT_NAME, DeviceLists.PRODUCT_NAME_LENGTH, productName);
    }

    /// <inheritdoc/>
    public (bool isSucceed, string productName) ReadProductName()
    {
        if (_client != null && _client.Online)
        {
            var (lenOk, nameLength) = ReadInt16(DeviceLists.PRODUCT_NAME_LENGTH);
            if (lenOk && nameLength >= DeviceLists.PRODUCT_NAME_MAX_LENGTH)
            {
                //byte[] len = new byte[1] { (byte)(DeviceLists.PRODUCT_NAME_MAX_LENGTH - 1) };
                var OO = WriteInt16(DeviceLists.PRODUCT_NAME_LENGTH, (short)(DeviceLists.PRODUCT_NAME_MAX_LENGTH - 1));
            }
            return _client.ReadUtf8(DeviceLists.PRODUCT_NAME, DeviceLists.PRODUCT_NAME_LENGTH);
        }
        else
        {
            return (false, "");
        }
    }
}
