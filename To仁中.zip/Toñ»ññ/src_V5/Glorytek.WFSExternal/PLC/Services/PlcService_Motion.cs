﻿using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using System;
using System.Threading.Tasks;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC Service - 定點運動。
 ********************/
public partial class PlcService : IPlc_Motion
{
    ///// <inheritdoc/>
    public async Task MoveToTarget(MotionTarget target, double x, double y, double z)
    {
        await Task.Run(() =>
        {
            // 確認軸是靜止狀態
            while (!Stabilized) { Task.Delay(10); }

            if (Stabilized)
            {
                switch (target)
                {
                    case MotionTarget.VisualPoint:
                        WriteDoubleByInt32(DeviceLists.VISUAL_POINT_X, new double[] { x, y, z });
                        SendCommandPulse(DeviceLists.VISUAL_POINT_COMMAND);
                        break;
                    case MotionTarget.DatumPoint:
                        WriteDoubleByInt32(DeviceLists.DATUM_POINT_X, new double[] { x, y, z });
                        SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_DATUM_POINT_COMMAND);
                        break;
                    case MotionTarget.ClayTableByCamera:
                        WriteDoubleByInt32(DeviceLists.CLAY_TABLE_X, new double[] { x, y, z });
                        SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_CLAY_TABLE_COMMAND);
                        break;
                    case MotionTarget.ClayTableByNozzle:
                        WriteDoubleByInt32(DeviceLists.NOZZLE_STAMP_X, new double[] { x, y, z });
                        SendCommandPulse(DeviceLists.MOVE_NOZZLE_TO_CLAY_TABLE_COMMAND);
                        break;
                    case MotionTarget.Displacement:
                        WriteDoubleByInt32(DeviceLists.DISPLACEMENT_X, new double[] { x, y, z });
                        SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_DISPLACEMENT_COMMAND);
                        break;
                    case MotionTarget.Stage1:
                        WriteDoubleByInt32(DeviceLists.STAGE_1_X, new double[] { x, y, z });
                        SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_STAGE_1_COMMAND);
                        break;
                    case MotionTarget.Stage2:
                        WriteDoubleByInt32(DeviceLists.STAGE_2_X, new double[] { x, y, z });
                        SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_STAGE_2_COMMAND);
                        break;
                }
            }
        }).WaitAsync(new TimeSpan(0, 0, 1));

        //await Task.Delay(1);
        //if (Stabilized)
        //{
        //    await Task.Run(() =>
        //    {
        //        switch (target)
        //        {
        //            case MotionTarget.VisualPoint:
        //                WriteDoubleByInt32(DeviceLists.VISUAL_POINT_X, new double[] { x, y, z });
        //                SendCommandPulse(DeviceLists.VISUAL_POINT_COMMAND);
        //                break;
        //            case MotionTarget.DatumPoint:
        //                WriteDoubleByInt32(DeviceLists.DATUM_POINT_X, new double[] { x, y, z });
        //                SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_DATUM_POINT_COMMAND);
        //                break;
        //            case MotionTarget.ClayTableByCamera:
        //                WriteDoubleByInt32(DeviceLists.CLAY_TABLE_X, new double[] { x, y, z });
        //                SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_CLAY_TABLE_COMMAND);
        //                break;
        //            case MotionTarget.ClayTableByNozzle:
        //                WriteDoubleByInt32(DeviceLists.NOZZLE_STAMP_X, new double[] { x, y, z });
        //                SendCommandPulse(DeviceLists.MOVE_NOZZLE_TO_CLAY_TABLE_COMMAND);
        //                break;
        //            case MotionTarget.Displacement:
        //                WriteDoubleByInt32(DeviceLists.DISPLACEMENT_X, new double[] { x, y, z });
        //                SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_DISPLACEMENT_COMMAND);
        //                break;
        //            case MotionTarget.Stage1:
        //                WriteDoubleByInt32(DeviceLists.STAGE_1_X, new double[] { x, y, z });
        //                SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_STAGE_1_COMMAND);
        //                break;
        //            case MotionTarget.Stage2:
        //                WriteDoubleByInt32(DeviceLists.STAGE_2_X, new double[] { x, y, z });
        //                SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_STAGE_2_COMMAND);
        //                break;
        //        }
        //    });
        //}
    }
}
