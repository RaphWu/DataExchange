﻿using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;

namespace Glorytek.WFSExternal.PLC.Services;

/********************
 * PLC作業資料 - JOG。
 ********************/
public partial class PlcService : IPlc_Jog
{
    /// <inheritdoc/>
    public void AllJogStop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.X_AXIS_JOG_FORWARD, new bool[] { false, false, false, false, false, false, false, false });
    }

    // X軸正轉
    /// <inheritdoc/>
    public void XAxisJog_Forward_Start()
    {
        if (Online)
            _client.WriteBool(DeviceLists.X_AXIS_JOG_FORWARD, true);
    }

    /// <inheritdoc/>
    public void XAxisJog_Forward_Stop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.X_AXIS_JOG_FORWARD, false);
    }

    // X軸反轉
    /// <inheritdoc/>
    public void XAxisJog_Reverse_Start()
    {
        if (Online)
            _client.WriteBool(DeviceLists.X_AXIS_JOG_REVERSE, true);
    }

    /// <inheritdoc/>
    public void XAxisJog_Reverse_Stop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.X_AXIS_JOG_REVERSE, false);
    }

    // Y軸正轉
    /// <inheritdoc/>
    public void YAxisJog_Forward_Start()
    {
        if (Online)
            _client.WriteBool(DeviceLists.Y_AXIS_JOG_FORWARD, true);
    }

    /// <inheritdoc/>
    public void YAxisJog_Forward_Stop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.Y_AXIS_JOG_FORWARD, false);
    }

    // Y軸反轉
    /// <inheritdoc/>
    public void YAxisJog_Reverse_Start()
    {
        if (Online)
            _client.WriteBool(DeviceLists.Y_AXIS_JOG_REVERSE, true);
    }

    /// <inheritdoc/>
    public void YAxisJog_Reverse_Stop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.Y_AXIS_JOG_REVERSE, false);
    }

    // Z軸正轉
    /// <inheritdoc/>
    public void ZAxisJog_Forward_Start()
    {
        if (Online)
            _client.WriteBool(DeviceLists.Z_AXIS_JOG_FORWARD, true);
    }

    /// <inheritdoc/>
    public void ZAxisJog_Forward_Stop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.Z_AXIS_JOG_FORWARD, false);
    }

    // Z軸反轉
    /// <inheritdoc/>
    public void ZAxisJog_Reverse_Start()
    {
        if (Online)
            _client.WriteBool(DeviceLists.Z_AXIS_JOG_REVERSE, true);
    }

    /// <inheritdoc/>
    public void ZAxisJog_Reverse_Stop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.Z_AXIS_JOG_REVERSE, false);
    }

    // R軸正轉
    /// <inheritdoc/>
    public void RAxisJog_Forward_Start()
    {
        if (Online)
            _client.WriteBool(DeviceLists.R_AXIS_JOG_FORWARD, true);
    }

    /// <inheritdoc/>
    public void RAxisJog_Forward_Stop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.R_AXIS_JOG_FORWARD, false);
    }

    // R軸反轉
    /// <inheritdoc/>
    public void RAxisJog_Reverse_Start()
    {
        if (Online)
            _client.WriteBool(DeviceLists.R_AXIS_JOG_REVERSE, true);
    }

    /// <inheritdoc/>
    public void RAxisJog_Reverse_Stop()
    {
        if (Online)
            _client.WriteBool(DeviceLists.R_AXIS_JOG_REVERSE, false);
    }

    /********************
     * Speed
     ********************/
    /// <inheritdoc/>
    public JogSpeedList JogSpeed => PlcDatas.Instance.JogSpeed;

    /// <inheritdoc/>
    public void SetJogSpeed(JogSpeedList jogSpeed)
    {
        switch (jogSpeed)
        {
            case JogSpeedList.Slow:
                SendCommandPulse(DeviceLists.JOG_SPEED_SLOW_COMMAND);
                break;
            case JogSpeedList.Low:
                SendCommandPulse(DeviceLists.JOG_SPEED_LOW_COMMAND);
                break;
            case JogSpeedList.Medium:
                SendCommandPulse(DeviceLists.JOG_SPEED_MEDIUM_COMMAND);
                break;
            case JogSpeedList.High:
                SendCommandPulse(DeviceLists.JOG_SPEED_HIGH_COMMAND);
                break;
            case JogSpeedList.Highest:
                SendCommandPulse(DeviceLists.JOG_SPEED_HIGHEST_COMMAND);
                break;
        }
    }
}
