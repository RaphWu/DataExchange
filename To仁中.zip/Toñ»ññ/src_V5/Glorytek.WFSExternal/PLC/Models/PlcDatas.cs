﻿using Prism.Mvvm;
using System;

namespace Glorytek.WFSExternal.PLC.Models;

/// <summary>
/// PLC作業資料。
/// </summary>
public partial class PlcDatas : BindableBase
{
    /********************
     * Singleton
     ********************/
    private PlcDatas() { }
    private static readonly Lazy<PlcDatas> _instance = new(() => new PlcDatas());
    public static PlcDatas Instance => _instance.Value;

    /********************
     * System Mode
     ********************/
    /// <summary>
    /// 連線模式。
    /// </summary>
    public bool SystemMode_Online_FixStage
    {
        get { return _systemMode_Online_FixStage; }
        set { SetProperty(ref _systemMode_Online_FixStage, value); }
    }
    private bool _systemMode_Online_FixStage = false;

    /// <summary>
    /// 分檢模式。
    /// </summary>
    public bool SystemMode_LensSorting
    {
        get { return _systemMode_LensSorting; }
        set { SetProperty(ref _systemMode_LensSorting, value); }
    }
    private bool _systemMode_LensSorting = false;

    /// <summary>
    /// 轉角度模式。
    /// </summary>
    public bool SystemMode_LensArrange
    {
        get { return _systemMode_LensArrange; }
        set { SetProperty(ref _systemMode_LensArrange, value); }
    }
    private bool _systemMode_LensArrange = false;

    /// <summary>
    /// 對接模式(單汽缸)。
    /// </summary>
    public bool SystemMode_Online_SingleCylinder
    {
        get { return _systemMode_Online_SingleCylinder; }
        set { SetProperty(ref _systemMode_Online_SingleCylinder, value); }
    }
    private bool _systemMode_Online_SingleCylinder = false;

    /// <summary>
    /// 對接模式(雙汽缸)。
    /// </summary>
    public bool SystemMode_Online_DoubleCylinder
    {
        get { return _systemMode_Online_DoubleCylinder; }
        set { SetProperty(ref _systemMode_Online_DoubleCylinder, value); }
    }
    private bool _systemMode_Online_DoubleCylinder = false;

    /// <summary>
    /// 對接模式(圓盤)。
    /// </summary>
    public bool SystemMode_Online_Disc
    {
        get { return _systemMode_Online_Disc; }
        set { SetProperty(ref _systemMode_Online_Disc, value); }
    }
    private bool _systemMode_Online_Disc = false;

    /// <summary>
    /// TRAY > A1重複精度。
    /// </summary>
    public bool SystemMode_Tray_A1
    {
        get { return _systemMode_Tray_A1; }
        set { SetProperty(ref _systemMode_Tray_A1, value); }
    }
    private bool _systemMode_Tray_A1 = false;
}
