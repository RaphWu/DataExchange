﻿namespace Glorytek.WFSExternal.PLC.Models;

/********************
 * PLC作業資料 - Pallet資料。
 ********************/
public partial class PlcDatas
{
    /// <summary>
    /// 各Tray是否滿盤或空盤。
    /// </summary>
    public bool[] TrayFullOrEmpty
    {
        get { return _trayFullOrEmpty; }
        set { SetProperty(ref _trayFullOrEmpty, value); }
    }
    private bool[] _trayFullOrEmpty = new bool[24];

    /// <summary>
    /// 各Tray動作點位。
    /// </summary>
    /// <remarks>準備取料的位址，取完料後會+1，所以作業結束後實際值會比最後一顆Lens多1。</remarks>
    public int[] NextPointNo
    {
        get { return _nextPointNo; }
        set { SetProperty(ref _nextPointNo, value); }
    }
    private int[] _nextPointNo = new int[24];

    /// <summary>
    /// 各Tray目前點位(矩陣點位，非取放點位)。
    /// </summary>
    /// <remarks>目前取料的位址，取料後被設定。</remarks>
    public int[] PickPointNo
    {
        get { return _pickPointNo; }
        set { SetProperty(ref _pickPointNo, value); }
    }
    private int[] _pickPointNo = new int[24];

    /// <summary>
    /// 取料動作的Tray盤號。
    /// </summary>
    public int PickTrayId
    {
        get { return _pickTrayId; }
        set { SetProperty(ref _pickTrayId, value); }
    }
    private int _pickTrayId;
}
