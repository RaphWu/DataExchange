﻿using Glorytek.WFSExternal.PLC.Constants;

namespace Glorytek.WFSExternal.PLC.Models;

/********************
 * PLC作業資料 - JOG。
 ********************/
public partial class PlcDatas
{
    /// <summary>
    /// JOG Speed。
    /// </summary>
    public JogSpeedList JogSpeed
    {
        get { return _jogSpeed; }
        set { SetProperty(ref _jogSpeed, value); }
    }
    private JogSpeedList _jogSpeed;
}
