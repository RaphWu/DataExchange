﻿using Prism.Mvvm;
using System;

namespace Glorytek.WFSExternal.PLC.Models;

/// <summary>
/// 稼動紀錄列表。
/// </summary>
public class AvailabilityDefine : BindableBase
{
    /// <summary>
    /// 資料庫ID。
    /// </summary>
    public int RecId
    {
        get { return _recId; }
        set { SetProperty(ref _recId, value); }
    }
    private int _recId;

    /********************
     * 機台作業
     ********************/
    /// <summary>
    /// 機台作業啟動。
    /// </summary>
    public DateTime? StartOperate
    {
        get { return _startOperate; }
        set { SetProperty(ref _startOperate, value); }
    }
    private DateTime? _startOperate;

    /// <summary>
    /// 機台作業結束。
    /// </summary>
    public DateTime? StopOperate
    {
        get { return _stopOperate; }
        set { SetProperty(ref _stopOperate, value); }
    }
    private DateTime? _stopOperate;

    /// <summary>
    /// 機台作業時間。
    /// </summary>
    public TimeSpan? DiffOperate
    {
        get { return _diffOperate; }
        set { SetProperty(ref _diffOperate, value); }
    }
    private TimeSpan? _diffOperate;

    /// <summary>
    /// 除去非稼動時間的稼動時間。
    /// </summary>
    public TimeSpan? Availability
    {
        get { return _availability; }
        set { SetProperty(ref _availability, value); }
    }
    private TimeSpan? _availability;

    /// <summary>
    /// 損耗時間。
    /// </summary>
    public TimeSpan? LostTime
    {
        get { return _lostTime; }
        set { SetProperty(ref _lostTime, value); }
    }
    private TimeSpan? _lostTime;

    /********************
     * 非稼動狀況紀錄。
     ********************/
    /// <summary>
    /// 事件發生時間。
    /// </summary>
    public DateTime? EventStart
    {
        get { return _eventStart; }
        set { SetProperty(ref _eventStart, value); }
    }
    private DateTime? _eventStart;

    /// <summary>
    /// 事件排除時間。
    /// </summary>
    public DateTime? EventExclude
    {
        get { return _eventExclude; }
        set { SetProperty(ref _eventExclude, value); }
    }
    private DateTime? _eventExclude;

    /// <summary>
    /// 耗時。
    /// </summary>
    public TimeSpan? DiffEvent
    {
        get { return _diffEvent; }
        set { SetProperty(ref _diffEvent, value); }
    }
    private TimeSpan? _diffEvent;

    /// <summary>
    /// 事件訊息。
    /// </summary>
    public string EventMessage
    {
        get { return _eventMessage; }
        set { SetProperty(ref _eventMessage, value); }
    }
    private string _eventMessage = "";
}
