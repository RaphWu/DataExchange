﻿using Glorytek.WPF.Helpers;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Glorytek.WFSExternal.PLC.Models;

public class AvailabilityDatas : BindableBase
{
    /********************
     * Singleton & INotifyPropertyChanged
     ********************/
    private AvailabilityDatas() { }
    private static readonly Lazy<AvailabilityDatas> _instance = new(() => new AvailabilityDatas());
    public static AvailabilityDatas Instance => _instance.Value;

    /// <summary>
    /// 稼動紀錄列表。
    /// </summary>
    public List<AvailabilityDefine> Availability
    {
        get { return _availability; }
        set { SetProperty(ref _availability, value); }
    }
    private List<AvailabilityDefine> _availability;

    /// <summary>
    /// 
    /// </summary>
    public ICollectionView AvailabilityCollectionView
    {
        get { return _availabilityCollectionView; }
        set
        {
            SetProperty(ref _availabilityCollectionView, value);

            if (_availabilityCollectionView != null)
            {
                TotalRecord = _availabilityCollectionView.AsList<AvailabilityDefine>().Count;

                _availabilityCollectionView.CollectionChanged += (o, e) =>
                {
                    TotalRecord = AvailabilityCollectionView.AsList<AvailabilityDefine>().Count;
                };

                _availabilityCollectionView.CurrentChanged += (o, e) =>
                {
                    if (_availabilityCollectionView != null && !_availabilityCollectionView.IsEmpty)
                        CurrentRecord = _availabilityCollectionView.CurrentPosition + 1;
                    else
                        CurrentRecord = 0;
                };
            }
        }
    }
    private ICollectionView _availabilityCollectionView;

    /// <summary>
    /// 移動一頁資料筆數。
    /// </summary>
    private const int pageSize = 20;

    /// <summary>
    /// 紀錄顯示。
    /// </summary>
    public string RecordString
    {
        get { return _recordString; }
        set { SetProperty(ref _recordString, value); }
    }
    private string _recordString;

    /// <summary>
    /// 資料筆數。
    /// </summary>
    public int TotalRecord
    {
        get { return _totalRecord; }
        set
        {
            _totalRecord = value;
            RecordString = $"{CurrentRecord} of {_totalRecord}";
        }
    }
    private int _totalRecord;

    /// <summary>
    /// 目前紀錄指標。
    /// </summary>
    public int CurrentRecord
    {
        get { return _currentRecord; }
        set
        {
            _currentRecord = value;
            RecordString = $"{_currentRecord} of {TotalRecord}";
        }
    }
    private int _currentRecord;

    /// <summary>
    /// 第一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToFirstCommand
        => _moveToFirstCommand ??= new DelegateCommand(ExecuteMoveToFirstCommand);
    private void ExecuteMoveToFirstCommand()
    {
        _ = AvailabilityCollectionView.MoveCurrentToFirst();
    }
    private DelegateCommand _moveToFirstCommand;

    /// <summary>
    /// 最後一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToLastCommand
        => _moveToLastCommand ??= new DelegateCommand(ExecuteMoveToLastCommand);
    private void ExecuteMoveToLastCommand()
    {
        _ = AvailabilityCollectionView.MoveCurrentToLast();
    }
    private DelegateCommand _moveToLastCommand;

    /// <summary>
    /// 上一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToPreviousCommand
        => _moveToPreviousCommand ??= new DelegateCommand(ExecuteMoveToPreviousCommand);
    private void ExecuteMoveToPreviousCommand()
    {
        _ = AvailabilityCollectionView.MoveCurrentToPrevious();
        if (AvailabilityCollectionView.IsCurrentBeforeFirst)
            _ = AvailabilityCollectionView.MoveCurrentToLast();
    }
    private DelegateCommand _moveToPreviousCommand;

    /// <summary>
    /// 下一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToNextCommand
        => _moveToNextCommand ??= new DelegateCommand(ExecuteMoveToNextCommand);
    private void ExecuteMoveToNextCommand()
    {
        _ = AvailabilityCollectionView.MoveCurrentToNext();
        if (AvailabilityCollectionView.IsCurrentAfterLast)
            _ = AvailabilityCollectionView.MoveCurrentToFirst();
    }
    private DelegateCommand _moveToNextCommand;

    /// <summary>
    /// 上一頁。
    /// </summary>
    public DelegateCommand MoveToPreviousPageCommand
        => _moveToPreviousPageCommand ??= new DelegateCommand(ExecuteMoveToPreviousPageCommand);
    private void ExecuteMoveToPreviousPageCommand()
    {
        try
        {
            _ = AvailabilityCollectionView.MoveCurrentToPosition(AvailabilityCollectionView.CurrentPosition - pageSize);
        }
        catch
        {
            _ = AvailabilityCollectionView.MoveCurrentToFirst();
        }
    }
    private DelegateCommand _moveToPreviousPageCommand;

    /// <summary>
    /// 下一頁。
    /// </summary>
    public DelegateCommand MoveToNextPageCommand
        => _moveToNextPageCommand ??= new DelegateCommand(ExecuteMoveToNextPageCommand);
    private void ExecuteMoveToNextPageCommand()
    {
        try
        {
            _ = AvailabilityCollectionView.MoveCurrentToPosition(AvailabilityCollectionView.CurrentPosition + pageSize);
        }
        catch
        {
            _ = AvailabilityCollectionView.MoveCurrentToLast();
        }
    }
    private DelegateCommand _moveToNextPageCommand;

}
