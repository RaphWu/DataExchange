﻿using Dapper.Contrib.Extensions;
using Glorytek.CSharp.Data.Converters;
using Glorytek.WFSExternal.PLC.Constants;
using System;

namespace Glorytek.WFSExternal.PLC.Models;

/// <summary>
/// 稼動紀錄資料庫定義。時間紀錄採用Unix時間戳。
/// </summary>
[Table(DB_PLC.TableName_Availability)]
public class AvailabilityDbDefine
{
    [Key]
    public int Id { get; set; }

    /// <summary>
    /// 紀錄類型ID。
    /// </summary>
    public int TypeId { get; set; }

    /// <summary>
    /// 紀錄類型。
    /// </summary>
    [Computed]
    public AvailabilityType Type
    {
        get
        {
            return Enum.TryParse(TypeId.ToString(), out AvailabilityType type)
                ? type : AvailabilityType.Undefine;
        }
        set
        {
            TypeId = (int)value;
        }
    }

    /// <summary>
    /// 紀錄時間戳。
    /// </summary>
    public long Timestamp { get; set; }

    /// <summary>
    /// 紀錄時間。
    /// </summary>
    [Computed]
    public DateTime Time
    {
        get
        {
            return (Timestamp >= 0 && Timestamp.LocalFromUnixTimestamp(TimestampType.Seconds, out DateTime dt))
                ? dt : DateTime.MinValue;
        }
        set
        {
            Timestamp = value != DateTime.MinValue
                ? value.ToUnixTimestamp(TimestampType.Seconds, Glorytek.CSharp.Constants.LocalTimeZone)
                : -1;
        }
    }

    /// <summary>
    /// 警報代碼。
    /// </summary>
    public int AlarmCode { get; set; }
}
