﻿using Glorytek.WPF.Extensions;

namespace Glorytek.WFSExternal.PLC.Models;

/// <summary>
/// 警報訊息列表。
/// </summary>
public static class AlarmList
{
    /// <summary>
    /// 取得警報訊息。
    /// </summary>
    /// <param name="alarmCode">警報代碼。</param>
    /// <returns>警報訊息。</returns>
    public static string GetAlarmMessage(int alarmCode)
    {
        return alarmCode switch
        {
            1 => GetResource.GetValue<string>("AlarmMsg_0001"),
            2 => GetResource.GetValue<string>("AlarmMsg_0002"),
            3 => GetResource.GetValue<string>("AlarmMsg_0003"),
            4 => GetResource.GetValue<string>("AlarmMsg_0004"),
            _ => $"{GetResource.GetValue<string>("AlarmMsg_Undefine")}: {alarmCode}",
        };
    }
}
