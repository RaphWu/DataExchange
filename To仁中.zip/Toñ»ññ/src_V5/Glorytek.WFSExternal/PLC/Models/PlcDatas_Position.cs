﻿namespace Glorytek.WFSExternal.PLC.Models;

/********************
 * PLC作業資料 - 座標資料。
 ********************/
public partial class PlcDatas
{
    /// <summary>
    /// X軸最大位置。
    /// </summary>
    public double XAxisMaxPosition => 750.0;

    /// <summary>
    /// Y軸最大位置。
    /// </summary>
    public double YAxisMaxPosition => 550.0;

    /// <summary>
    /// Z軸最大位置。
    /// </summary>
    public double ZAxisMaxPosition => 45.0;

    /********************
     * 目前軸座標
     ********************/
    /// <summary>
    /// X軸目前座標。
    /// </summary>
    public double XAxisPosition
    {
        get { return _xAxisPosition; }
        set { SetProperty(ref _xAxisPosition, value); }
    }
    private double _xAxisPosition;

    /// <summary>
    /// Y軸目前座標。
    /// </summary>
    public double YAxisPosition
    {
        get { return _yAxisPosition; }
        set { SetProperty(ref _yAxisPosition, value); }
    }
    private double _yAxisPosition;

    /// <summary>
    /// Y軸目前座標。
    /// </summary>
    public double ZAxisPosition
    {
        get { return _zAxisPosition; }
        set { SetProperty(ref _zAxisPosition, value); }
    }
    private double _zAxisPosition;

    /// <summary>
    /// Y軸目前座標。
    /// </summary>
    public double RAxisPosition
    {
        get { return _rAxisPosition; }
        set { SetProperty(ref _rAxisPosition, value); }
    }
    private double _rAxisPosition;

    /********************
     * 軸是否運動中
     ********************/
    /// <summary>
    /// 任意軸運動中。
    /// </summary>
    public bool AnyAxisInMotion
    {
        get { return _anyAxisInMotion; }
        set
        {
            if (_anyAxisInMotion != value)
            {
                SetProperty(ref _anyAxisInMotion, value);
                SetStabilized();
            }
        }
    }
    private bool _anyAxisInMotion;

    /// <summary>
    /// X軸運動中。
    /// </summary>
    public bool XAxisInMotion
    {
        get { return _xAxisInMotion; }
        set { SetProperty(ref _xAxisInMotion, value); }
    }
    private bool _xAxisInMotion;

    /// <summary>
    /// Y軸運動中。
    /// </summary>
    public bool YAxisInMotion
    {
        get { return _yAxisInMotion; }
        set { SetProperty(ref _yAxisInMotion, value); }
    }
    private bool _yAxisInMotion;

    /// <summary>
    /// Z軸運動中。
    /// </summary>
    public bool ZAxisInMotion
    {
        get { return _zAxisInMotion; }
        set { SetProperty(ref _zAxisInMotion, value); }
    }
    private bool _zAxisInMotion;

    /// <summary>
    /// R軸運動中。
    /// </summary>
    public bool RAxisInMotion
    {
        get { return _rAxisInMotion; }
        set { SetProperty(ref _rAxisInMotion, value); }
    }
    private bool _rAxisInMotion;

    /********************
     * INP Positioning Completion Signal
     ********************/
    /// <summary>
    /// X軸INP。
    /// </summary>
    public bool XAxisINP
    {
        get { return _xAxisINP; }
        set { SetProperty(ref _xAxisINP, value); }
    }
    private bool _xAxisINP;

    /// <summary>
    /// Y軸INP。
    /// </summary>
    public bool YAxisINP
    {
        get { return _yAxisINP; }
        set { SetProperty(ref _yAxisINP, value); }
    }
    private bool _yAxisINP;

    /// <summary>
    /// Z軸INP。
    /// </summary>
    public bool ZAxisINP
    {
        get { return _zAxisINP; }
        set { SetProperty(ref _zAxisINP, value); }
    }
    private bool _zAxisINP;

    /// <summary>
    /// R軸INP。
    /// </summary>
    public bool RAxisINP
    {
        get { return _rAxisINP; }
        set { SetProperty(ref _rAxisINP, value); }
    }
    private bool _rAxisINP;

    /// <summary>
    /// XY軸到位後延時。
    /// </summary>
    public float XYAxisInpDelay
    {
        get { return _xYAxisInpDelay; }
        set { SetProperty(ref _xYAxisInpDelay, value); }
    }
    private float _xYAxisInpDelay;

    /// <summary>
    /// XY減速距離。
    /// </summary>
    /// <summary>
    /// 
    /// </summary>
    public short XYAxisSlowDown
    {
        get { return _xYAxisSlowDown; }
        set { SetProperty(ref _xYAxisSlowDown, value); }
    }
    private short _xYAxisSlowDown;

    /// <summary>
    /// XY減速速率。
    /// </summary>
    public short XYAxisSlowDownSpeed
    {
        get { return _xYAxisSlowDownSpeed; }
        set { SetProperty(ref _xYAxisSlowDownSpeed, value); }
    }
    private short _xYAxisSlowDownSpeed;

    /// <summary>
    /// Z加減速距離。
    /// </summary>
    public short ZAxisSpeedUpDown
    {
        get { return _zAxisSpeedUpDown; }
        set { SetProperty(ref _zAxisSpeedUpDown, value); }
    }
    private short _zAxisSpeedUpDown;
}
