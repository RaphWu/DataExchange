﻿using Glorytek.WFSCore;

namespace Glorytek.WFSExternal.PLC.Models;

/********************
 * PLC作業資料 - 與軟體系統相關。
 ********************/
public partial class PlcDatas
{
    /// <summary>
    /// Cycle Time。
    /// </summary>
    public long CycleTime
    {
        get { return _cycleTime; }
        set
        {
            SetProperty(ref _cycleTime, value);
            CycleTimeString = $"{(value / 1000.0).WfsFormat():F3} 秒";
        }
    }
    private long _cycleTime;

    /// <summary>
    /// Cycle Time顯示格式化字串。
    /// </summary>
    public string CycleTimeString
    {
        get { return _cycleTimeString; }
        set { SetProperty(ref _cycleTimeString, value); }
    }
    private string _cycleTimeString;

    /// <summary>
    /// 製作數設定。
    /// </summary>
    public short EstimatedQuantitySetting
    {
        get { return _estimatedQuantitySetting; }
        set { SetProperty(ref _estimatedQuantitySetting, value); }
    }
    private short _estimatedQuantitySetting;

    /// <summary>
    /// 製作數。
    /// </summary>
    public short EstimatedQuantity
    {
        get { return _estimatedQuantity; }
        set { SetProperty(ref _estimatedQuantity, value); }
    }
    private short _estimatedQuantity;

    /// <summary>
    /// 目前取料的序號 (作業啟動時歸零，取料前+1)。
    /// </summary>
    public short CurrentSequence
    {
        get { return _currentSequence; }
        set { SetProperty(ref _currentSequence, value); }
    }
    private short _currentSequence;
}
