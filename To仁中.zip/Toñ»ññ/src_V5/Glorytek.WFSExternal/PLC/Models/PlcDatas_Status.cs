﻿namespace Glorytek.WFSExternal.PLC.Models;

/********************
 * PLC作業資料 - 狀態偵測。
 ********************/
public partial class PlcDatas
{
    /// <summary>
    /// 強制更新燈號。
    /// </summary>
    /// <remarks><list type="bullet">
    /// <item>因為一些功能鍵使用RadioButton，按下時便會亮燈(IsChecked)。<br/>
    /// 但由於某些狀況導致燈號因未呼叫RaisePropertyChanged而不會改變，<br/>
    /// (例如按了啟動作業按鈕，啟動鍵亮；但參數不正確而PLC未進入啟動狀態，啟動燈不會熄滅。)<br/>
    /// 導致畫面中的燈號消不掉，此函數則強迫燈號做一次更新。</item>
    /// <item>因PlcDatas是單例模式，建議此函數不要列入常規使用，還是以Binding為主。</item>
    /// </list></remarks>
    public void UpdateSignalLamp()
    {
        // 需要更新的屬性，則列在下方:
        RaisePropertyChanged(nameof(AutoStartLamp));
    }

    /// <summary>
    /// 自動運轉模式。
    /// </summary>
    public bool AutoMode
    {
        get { return _autoMode; }
        set
        {
            if (_autoMode != value)
            {
                _autoMode = value;
                NonAutoMode = !value;
                SetStabilized();
            }
        }
    }
    private bool _autoMode;

    /// <summary>
    /// 自動運轉模式。
    /// </summary>
    public bool NonAutoMode
    {
        get { return _nonAutoMode; }
        set { _nonAutoMode = value; }
    }
    private bool _nonAutoMode;

    /// <summary>
    /// 自動運轉前閃爍燈號。
    /// </summary>
    public bool AutoStartLamp
    {
        get { return _autoStartLamp; }
        set { SetProperty(ref _autoStartLamp, value); }
    }
    private bool _autoStartLamp;

    /// <summary>
    /// 手動運轉模式。
    /// </summary>
    public bool ManualMode
    {
        get { return _manualMode; }
        set { _manualMode = value; }
    }
    private bool _manualMode;

    /// <summary>
    /// 機台暫停中。
    /// </summary>
    public bool MachinePause
    {
        get { return _machinePause; }
        set { _machinePause = value; }
    }
    private bool _machinePause;

    /// <summary>
    /// 試運轉/空跑。
    /// </summary>
    public bool TestMode
    {
        get { return _testMode; }
        set { _testMode = value; }
    }
    private bool _testMode;

    /// <summary>
    /// PLC已準備好且在穩定狀態。
    /// </summary>
    public bool Stabilized
    {
        get { return _stabilized; }
        set { SetProperty(ref _stabilized, value); }
    }
    private bool _stabilized;

    /// <summary>
    /// PLC已準備好且在穩定狀態(非自動模式)。
    /// </summary>
    public bool StabilizedExceptAutoMode
    {
        get { return _stabilizedExceptAutoMode; }
        set { SetProperty(ref _stabilizedExceptAutoMode, value); }
    }
    private bool _stabilizedExceptAutoMode;

    private void SetStabilized()
    {
        Stabilized = Ready && !AnyAxisInMotion;
        StabilizedExceptAutoMode = Stabilized && !AutoMode;
    }

    /// <summary>
    /// PLC已準備好且無警報。
    /// </summary>
    public bool Ready
    {
        get { return _ready; }
        set { SetProperty(ref _ready, value); }
    }
    private bool _ready;

    private void SetReadyStatus()
    {
        Ready = ManualReady && !Alarm;
        SetStabilized();
    }

    /// <summary>
    /// 警報。
    /// </summary>
    public bool Alarm
    {
        get { return _alarm; }
        set { SetProperty(ref _alarm, value); }
    }
    private bool _alarm;

    private void SetAlarm()
    {
        Alarm = !( // EMS
            XAxisRLS && YAxisRLS && ZAxisRLS && RAxisRLS &&
            XAxisFLS && YAxisFLS && ZAxisFLS && RAxisFLS);
        SetReadyStatus();
    }

    /// <summary>
    /// 
    /// </summary>
    public bool ManualReady
    {
        get { return _manualReady; }
        set
        {
            SetProperty(ref _manualReady, value);
        }
    }
    private bool _manualReady;

    private void SetManualReady()
    {
        ManualReady = Online && !HomeReturning &&
            !XAxisAbnormal && !YAxisAbnormal && !ZAxisAbnormal && !RAxisAbnormal;
        SetReadyStatus();
    }

    /// <summary>
    /// PLC是否已連線。
    /// </summary>
    public bool Online
    {
        get { return _online; }
        set
        {
            if (_online != value)
            {
                SetProperty(ref _online, value);
                SetManualReady();
            }
        }
    }
    private bool _online;

    /// <summary>
    /// 全部伺服軸是否Ready。
    /// </summary>
    public bool AllServoReady
    {
        get { return _allServoReady; }
        set
        {
            if (_allServoReady != value)
            {
                SetProperty(ref _allServoReady, value);
                SetManualReady();
            }
        }
    }
    private bool _allServoReady;

    /// <summary>
    /// 復歸中。
    /// </summary>
    public bool HomeReturning
    {
        get { return _homeReturning; }
        set
        {
            if (_homeReturning != value)
            {
                SetProperty(ref _homeReturning, value);
                SetManualReady();
            }
        }
    }
    private bool _homeReturning;

    /// <summary>
    /// 復歸完成。
    /// </summary>
    public bool HomeReturnCompleted
    {
        get { return _homeReturnCompleted; }
        set { SetProperty(ref _homeReturnCompleted, value); }
    }
    private bool _homeReturnCompleted = false;

    /********************
     * FLS 正轉極限 Forward rotation start
     * RLS 逆轉極限 Reverse rotation start
     * OPG 編碼器零點
     * DOG 近點DOG Proximity dog
     ********************/
    /// <summary>
    /// X軸 正轉極限。
    /// </summary>
    public bool XAxisFLS
    {
        get { return _xAxisFLS; }
        set
        {
            if (_xAxisFLS != value)
            {
                SetProperty(ref _xAxisFLS, value);
                SetAlarm();
            }
        }
    }
    private bool _xAxisFLS;

    /// <summary>
    /// X軸 逆轉極限。
    /// </summary>
    public bool XAxisRLS
    {
        get { return _xAxisRLS; }
        set
        {
            if (_xAxisRLS != value)
            {
                SetProperty(ref _xAxisRLS, value);
                SetAlarm();
            }
        }
    }
    private bool _xAxisRLS;

    /// <summary>
    /// X軸 編碼器零點。
    /// </summary>
    public bool XAxisOPG
    {
        get { return _xAxisOPG; }
        set { SetProperty(ref _xAxisOPG, value); }
    }
    private bool _xAxisOPG;

    /// <summary>
    /// X軸 近點DOG。
    /// </summary>
    public bool XAxisDOG
    {
        get { return _xAxisDOG; }
        set { SetProperty(ref _xAxisDOG, value); }
    }
    private bool _xAxisDOG;

    /// <summary>
    /// Y軸 正轉極限。
    /// </summary>
    public bool YAxisFLS
    {
        get { return _yAxisFLS; }
        set
        {
            if (_yAxisFLS != value)
            {
                SetProperty(ref _yAxisFLS, value);
                SetAlarm();
            }
        }
    }
    private bool _yAxisFLS;

    /// <summary>
    /// Y軸 逆轉極限。
    /// </summary>
    public bool YAxisRLS
    {
        get { return _yAxisRLS; }
        set
        {
            if (_yAxisRLS != value)
            {
                SetProperty(ref _yAxisRLS, value);
                SetAlarm();
            }
        }
    }
    private bool _yAxisRLS;

    /// <summary>
    /// Y軸 編碼器零點。
    /// </summary>
    public bool YAxisOPG
    {
        get { return _yAxisOPG; }
        set { SetProperty(ref _yAxisOPG, value); }
    }
    private bool _yAxisOPG;

    /// <summary>
    /// Y軸 近點DOG。
    /// </summary>
    public bool YAxisDOG
    {
        get { return _yAxisDOG; }
        set { SetProperty(ref _yAxisDOG, value); }
    }
    private bool _yAxisDOG;

    /// <summary>
    /// Z軸 正轉極限。
    /// </summary>
    public bool ZAxisFLS
    {
        get { return _zAxisFLS; }
        set
        {
            if (_zAxisFLS != value)
            {
                SetProperty(ref _zAxisFLS, value);
                SetAlarm();
            }
        }
    }
    private bool _zAxisFLS;

    /// <summary>
    /// Z軸 逆轉極限。
    /// </summary>
    public bool ZAxisRLS
    {
        get { return _zAxisRLS; }
        set
        {
            if (_zAxisRLS != value)
            {
                SetProperty(ref _zAxisRLS, value);
                SetAlarm();
            }
        }
    }
    private bool _zAxisRLS;

    /// <summary>
    /// Z軸 編碼器零點。
    /// </summary>
    public bool ZAxisOPG
    {
        get { return _zAxisOPG; }
        set { SetProperty(ref _zAxisOPG, value); }
    }
    private bool _zAxisOPG;

    /// <summary>
    /// Z軸 近點DOG。
    /// </summary>
    public bool ZAxisDOG
    {
        get { return _zAxisDOG; }
        set { SetProperty(ref _zAxisDOG, value); }
    }
    private bool _zAxisDOG;

    /// <summary>
    /// R軸 正轉極限。
    /// </summary>
    public bool RAxisFLS
    {
        get { return _rAxisFLS; }
        set
        {
            if (_rAxisFLS != value)
            {
                SetProperty(ref _rAxisFLS, value);
                SetAlarm();
            }
        }
    }
    private bool _rAxisFLS;

    /// <summary>
    /// R軸 逆轉極限。
    /// </summary>
    public bool RAxisRLS
    {
        get { return _rAxisRLS; }
        set
        {
            if (_rAxisRLS != value)
            {
                SetProperty(ref _rAxisRLS, value);
                SetAlarm();
            }
        }
    }
    private bool _rAxisRLS;

    /// <summary>
    /// R軸 編碼器零點。
    /// </summary>
    public bool RAxisOPG
    {
        get { return _rAxisOPG; }
        set { SetProperty(ref _rAxisOPG, value); }
    }
    private bool _rAxisOPG;

    /// <summary>
    /// R軸 近點DOG。
    /// </summary>
    public bool RAxisDOG
    {
        get { return _rAxisDOG; }
        set { SetProperty(ref _rAxisDOG, value); }
    }
    private bool _rAxisDOG;

    /********************
     * 吸嘴
     ********************/
    /// <summary>
    /// 吸嘴真空檢知。
    /// </summary>
    public bool NozzleVaccumDetector
    {
        get { return _nozzleVaccumDetector; }
        set { SetProperty(ref _nozzleVaccumDetector, value); }
    }
    private bool _nozzleVaccumDetector;

    /// <summary>
    /// 吸嘴真空狀態。
    /// </summary>
    public bool NozzleVaccum
    {
        get { return _nozzleVaccum; }
        set { SetProperty(ref _nozzleVaccum, value); }
    }
    private bool _nozzleVaccum;

    /// <summary>
    /// 吸嘴破真空狀態。
    /// </summary>
    public bool NozzleRelief
    {
        get { return _nozzleRelief; }
        set { SetProperty(ref _nozzleRelief, value); }
    }
    private bool _nozzleRelief;

    /********************
     * STAGE 1
     ********************/
    /// <summary>
    /// A1真空檢知。
    /// </summary>
    public bool Stage1VaccumDetector
    {
        get { return _stage1VaccumDetector; }
        set { SetProperty(ref _stage1VaccumDetector, value); }
    }
    private bool _stage1VaccumDetector;

    /// <summary>
    /// A1真空狀態。
    /// </summary>
    public bool Stage1Vaccum
    {
        get { return _stage1Vaccum; }
        set { SetProperty(ref _stage1Vaccum, value); }
    }
    private bool _stage1Vaccum;

    /// <summary>
    /// A1破真空狀態。
    /// </summary>
    public bool Stage1Relief
    {
        get { return _stage1Relief; }
        set { SetProperty(ref _stage1Relief, value); }
    }
    private bool _stage1Relief;

    /// <summary>
    /// A1分檢機側檢知。
    /// </summary>
    public bool Cylinder1LsSorting
    {
        get { return _cylinder1LsSorting; }
        set { SetProperty(ref _cylinder1LsSorting, value); }
    }
    private bool _cylinder1LsSorting;

    /// <summary>
    /// A1量測機側檢知。
    /// </summary>
    public bool Cylinder1LsMeasurement
    {
        get { return _cylinder1LsMeasurement; }
        set { SetProperty(ref _cylinder1LsMeasurement, value); }
    }
    private bool _cylinder1LsMeasurement;

    /// <summary>
    /// A1殘料檢知。
    /// </summary>
    public bool Stage1ScrapDetector
    {
        get { return _stage1ScrapDetector; }
        set { SetProperty(ref _stage1ScrapDetector, value); }
    }
    private bool _stage1ScrapDetector;

    /********************
     * STAGE 2
     ********************/
    /// <summary>
    /// A2真空檢知。
    /// </summary>
    public bool Stage2VaccumDetector
    {
        get { return _stage2VaccumDetector; }
        set { SetProperty(ref _stage2VaccumDetector, value); }
    }
    private bool _stage2VaccumDetector;

    /// <summary>
    /// A2真空狀態。
    /// </summary>
    public bool Stage2Vaccum
    {
        get { return _stage2Vaccum; }
        set { SetProperty(ref _stage2Vaccum, value); }
    }
    private bool _stage2Vaccum;

    /// <summary>
    /// A2破真空狀態。
    /// </summary>
    public bool Stage2Relief
    {
        get { return _stage2Relief; }
        set { SetProperty(ref _stage2Relief, value); }
    }
    private bool _stage2Relief;

    /// <summary>
    /// A2分檢機側檢知。
    /// </summary>
    public bool Cylinder2LsSorting
    {
        get { return _cylinder2LsSorting; }
        set { SetProperty(ref _cylinder2LsSorting, value); }
    }
    private bool _cylinder2LsSorting;

    /// <summary>
    /// A2量測機側檢知。
    /// </summary>
    /// <summary>
    /// 
    /// </summary>
    public bool Cylinder2LsMeasurement
    {
        get { return _cylinder2LsMeasurement; }
        set { SetProperty(ref _cylinder2LsMeasurement, value); }
    }
    private bool _cylinder2LsMeasurement;

    /// <summary>
    /// A2殘料檢知。
    /// </summary>
    public bool Stage2ScrapDetector
    {
        get { return _stage2ScrapDetector; }
        set { SetProperty(ref _stage2ScrapDetector, value); }
    }
    private bool _stage2ScrapDetector;

    /********************
     * IO
     ********************/
    /// <summary>
    /// 光柵信號。
    /// </summary>
    public bool LightCurtain
    {
        get { return _lightCurtain; }
        set { SetProperty(ref _lightCurtain, value); }
    }
    private bool _lightCurtain;

    /// <summary>
    /// 靜電消除器。
    /// </summary>
    public bool Ionotron
    {
        get { return _ionotron; }
        set { SetProperty(ref _ionotron, value); }
    }
    private bool _ionotron;

    /// <summary>
    /// 照明。
    /// </summary>
    public bool Lights
    {
        get { return _lights; }
        set { SetProperty(ref _lights, value); }
    }
    private bool _lights;

    /// <summary>
    /// 三色燈 (綠)。
    /// </summary>
    public bool StackLightGreen
    {
        get { return _stackLightGreen; }
        set { SetProperty(ref _stackLightGreen, value); }
    }
    private bool _stackLightGreen;

    /// <summary>
    /// 三色燈 (綠)。
    /// </summary>
    public bool StackLightYellow
    {
        get { return _stackLightYellow; }
        set { SetProperty(ref _stackLightYellow, value); }
    }
    private bool _stackLightYellow;

    /// <summary>
    /// 三色燈 (綠)。
    /// </summary>
    public bool StackLightRed
    {
        get { return _stackLightRed; }
        set { SetProperty(ref _stackLightRed, value); }
    }
    private bool _stackLightRed;

    /// <summary>
    /// 門。
    /// </summary>
    public bool Doors
    {
        get { return _doors; }
        set { SetProperty(ref _doors, value); }
    }
    private bool _doors;

    /********************
     * Error Code
     ********************/
    /// <summary>
    /// X軸 異常。
    /// </summary>
    public bool XAxisAbnormal
    {
        get { return _xAxisAbnormal; }
        set
        {
            if (_xAxisAbnormal != value)
            {
                SetProperty(ref _xAxisAbnormal, value);
                SetManualReady();
            }
        }
    }
    private bool _xAxisAbnormal;

    /// <summary>
    /// Y軸 異常。
    /// </summary>
    public bool YAxisAbnormal
    {
        get { return _yAxisAbnormal; }
        set
        {
            if (_yAxisAbnormal != value)
            {
                SetProperty(ref _yAxisAbnormal, value);
                SetManualReady();
            }
        }
    }
    private bool _yAxisAbnormal;

    /// <summary>
    /// Z軸 異常。
    /// </summary>
    public bool ZAxisAbnormal
    {
        get { return _zAxisAbnormal; }
        set
        {
            if (_zAxisAbnormal != value)
            {
                SetProperty(ref _zAxisAbnormal, value);
                SetManualReady();
            }
        }
    }
    private bool _zAxisAbnormal;

    /// <summary>
    /// R軸 異常。
    /// </summary>
    public bool RAxisAbnormal
    {
        get { return _rAxisAbnormal; }
        set
        {
            if (_rAxisAbnormal != value)
            {
                SetProperty(ref _rAxisAbnormal, value);
                SetManualReady();
            }
        }
    }
    private bool _rAxisAbnormal;

    /// <summary>
    /// X軸 錯誤碼。
    /// </summary>
    public short XAxisErrorCode
    {
        get { return _xAxisErrorCode; }
        set { SetProperty(ref _xAxisErrorCode, value); }
    }
    private short _xAxisErrorCode = 0;

    /// <summary>
    /// Y軸 錯誤碼。
    /// </summary>
    public short YAxisErrorCode
    {
        get { return _yAxisErrorCode; }
        set { SetProperty(ref _yAxisErrorCode, value); }
    }
    private short _yAxisErrorCode = 0;

    /// <summary>
    /// Z軸 錯誤碼。
    /// </summary>
    public short ZAxisErrorCode
    {
        get { return _zAxisErrorCode; }
        set { SetProperty(ref _zAxisErrorCode, value); }
    }
    private short _zAxisErrorCode = 0;

    /// <summary>
    /// R軸 錯誤碼。
    /// </summary>
    public short RAxisErrorCode
    {
        get { return _rAxisErrorCode; }
        set { SetProperty(ref _rAxisErrorCode, value); }
    }
    private short _rAxisErrorCode = 0;

    /// <summary>
    /// 異常碼。
    /// </summary>
    public bool[] ErrorCodeList
    {
        get { return _errorCodeList; }
        set { SetProperty(ref _errorCodeList, value); }
    }
    private bool[] _errorCodeList = new bool[DeviceLists.ERROR_CODE_TOTAL];

    /********************
     * Polling使用
     ********************/
    /// <summary>
    /// Polling是否完成一個週期。
    /// </summary>
    public bool PollingCycleCompleted { get; set; } = false;
}
