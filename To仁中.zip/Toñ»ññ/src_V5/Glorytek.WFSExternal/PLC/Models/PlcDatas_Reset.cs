﻿//namespace Glorytek.WFSExternal.PLC.Models
//{
//    /// <summary>
//    /// PLC作業資料 - 復歸與重置資料。
//    /// </summary>
//    public partial class PlcDatas
//    {
//        /// <summary>
//        /// 伺服軸已復歸
//        /// </summary>
//        public bool AxisHomed
//        {
//            get { return _axisHomed; }
//            set
//            {
//                if (_axisHomed != value)
//                {
//                    _axisHomed = value;
//                    OnPropertyChanged();
//                }
//            }
//        }
//        private bool _axisHomed = false;
//    }
//}
