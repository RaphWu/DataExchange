﻿namespace Glorytek.WFSExternal.PLC.Models;

/********************
 * PLC作業資料 - 安全防護。
 ********************/
public partial class PlcDatas
{
    ///// <summary>
    ///// 安全高度。(移至MachineDefine)
    ///// </summary>
    //public double SaftyHeight
    //{
    //    get { return _saftyHeight; }
    //    set
    //    {
    //        if (_saftyHeight != value)
    //        {
    //            _saftyHeight = value;
    //            OnPropertyChanged();
    //        }
    //    }
    //}
    //private double _saftyHeight;

    /// <summary>
    /// 限速啟動。
    /// </summary>
    public bool SpeedLimitActivated
    {
        get { return _speedLimitActivated; }
        set { SetProperty(ref _speedLimitActivated, value); }
    }
    private bool _speedLimitActivated;
}
