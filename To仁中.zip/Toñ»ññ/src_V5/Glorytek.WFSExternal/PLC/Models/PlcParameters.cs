﻿using System;
using System.Collections.Generic;

namespace Glorytek.WFSExternal.PLC.Models;

/// <summary>
/// PLC參數。
/// </summary>
internal class PlcParameters
{
    private PlcParameters() { }
    private static readonly Lazy<PlcParameters> _instance = new(() => new PlcParameters());
    public static PlcParameters Instance => _instance.Value;

    /********************
     * PLC
     ********************/
    /// <summary>
    /// Host Ip Address。
    /// </summary>
    public string HostAddress { get; set; } = "192.168.1.1";

    /// <summary>
    /// Host Ip Address。
    /// </summary>
    public int Port { get; set; } = 2000;

    /// <summary>
    /// Time Out。
    /// </summary>
    public int TimeOut { get; set; } = 5000;

    /// <summary>
    /// 自動運轉中信號。
    /// </summary>
    /// <remarks>
    /// 自動啟動後 = true，並監視自動停止信號。<br/>
    /// 收到自動停止信號後 = false，觸發Event。<br/>
    /// Event => 大數據需要更新批號列表以加入新批號。
    /// </remarks>
    public bool AutoRunningSignal { get; set; } = false;

    /// <summary>
    /// 稼動紀錄_對應資料庫結構。
    /// </summary>
    public List<AvailabilityDbDefine> AvailabilityDB { get; set; }
}
