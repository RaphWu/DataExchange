﻿namespace Glorytek.WFSExternal.PLC.Models;

/// <summary>
/// PLC儲存在磁碟檔案中的參數。
/// </summary>
internal class PlcDbDefine
{
    ///// <summary>
    ///// CPU Type ID。
    ///// </summary>
    //public int CpuTypeId { get; set; }

    ///// <summary>
    ///// Module Type。
    ///// </summary>
    //public int ModuleTypeId { get; set; }

    ///// <summary>
    ///// Protocal。
    ///// </summary>
    //public int ProtocolTypeId { get; set; }

    /// <summary>
    /// Host Ip Address。
    /// </summary>
    public string HostAddress { get; set; }

    /// <summary>
    /// Port。
    /// </summary>
    public int Port { get; set; }

    /// <summary>
    /// Time Out。
    /// </summary>
    public int TimeOut { get; set; }
}
