﻿namespace Glorytek.WFSExternal.SerialPort;

/// <summary>
/// 資料庫對應類別。
/// </summary>
internal class SerialPortDefine
{
    /// <summary>
    /// SerialPort名稱。
    /// </summary>
    public string PortName { get; set; }

    /// <summary>
    /// 鮑率。
    /// </summary>
    public int BaudRate { get; set; }

    /// <summary>
    /// 同位位元。
    /// </summary>
    public string Parity { get; set; }

    /// <summary>
    /// 資料位元。
    /// </summary>
    public int DataBits { get; set; }

    /// <summary>
    /// 停止位元。
    /// </summary>
    public string StopBits { get; set; }

    /// <summary>
    /// 交握模式。
    /// </summary>
    public string Handshake { get; set; }
}
