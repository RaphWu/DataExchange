﻿using Glorytek.CSharp.IO;
using Glorytek.WFSCore.Constants;
using Glorytek.WPF.PrismMessageBox;
using RJCP.IO.Ports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Glorytek.WFSExternal.SerialPort;

/// <summary>
/// IOPSP實例化。
/// </summary>
/// <remarks>使用套件: <see href="https://github.com/jcurl/serialportstream">Serial Port Stream。</see></remarks>
public class SerialPortService : ISerialPort
{
    private readonly SerialPortParameters _spp = SerialPortParameters.Instance;

    //private const string TIMEOUT_COMMAND = "Timeout";

    //private static bool _cdHolding;
    //private static bool _ctsHolding;
    //private static bool _dsrHolding;

    private static SerialPortStream RjcpSerialPort { get; set; }

    /********************
     * ctor
     ********************/
    private readonly IPrismMessageBox _prismMessageBox;

    public SerialPortService(IPrismMessageBox prismMessageBox)
    {
        _prismMessageBox = prismMessageBox;

        _spp.BaudRateList = new List<int>() { 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200 };
        _spp.DataBitsList = new List<int>() { 5, 6, 7, 8, 9 };
    }

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public bool WriteToDb()
    {
        JsonFileHelper.Save(DBbase.Directory_Base, DB_SerialPort.SerialPortFileName, new SerialPortDefine()
        {
            PortName = _spp.PortName,
            BaudRate = _spp.BaudRate,
            Parity = _spp.Parity.ToString(),
            DataBits = _spp.DataBits,
            StopBits = _spp.StopBits.ToString(),
            Handshake = _spp.Handshake.ToString(),
        });

        return true;
    }

    /// <inheritdoc/>
    public bool ReadFromDb()
    {
        SerialPortDefine spDb = JsonFileHelper.Read<SerialPortDefine>(DBbase.Directory_Base, DB_SerialPort.SerialPortFileName);
        try
        {
            if (spDb != null)
            {
                _spp.PortName = spDb.PortName;
                _spp.BaudRate = spDb.BaudRate;
                _spp.Parity = (Parity)Enum.Parse(typeof(Parity), spDb.Parity);
                _spp.DataBits = spDb.DataBits;
                _spp.StopBits = (StopBits)Enum.Parse(typeof(StopBits), spDb.StopBits);
                _spp.Handshake = (Handshake)Enum.Parse(typeof(Handshake), spDb.Handshake);

                return true;
            }
        }
        catch
        {
            // do nothing
        }

        _spp.PortName = _spp.PortNameList.Count > 0 ? _spp.PortNameList[0] : "";
        _spp.BaudRate = 9600;
        _spp.Parity = Parity.Odd;
        _spp.DataBits = 8;
        _spp.StopBits = StopBits.One;
        _spp.Handshake = Handshake.None;

        return false;
    }

    /********************
     * System Command
     ********************/
    /// <summary>
    /// 模組初始化
    /// </summary>
    internal void ModuleInit()
    {
        RefreshPortNameList();

        /********************
         * 條碼機已切到HID模式，不再需要連接COM Port，故以下不再執行
         ********************/

        //ReadSettingFromDb();

        //// 檢查Port設定是否正確
        //if (!string.IsNullOrWhiteSpace(_spp.PortName)
        //    && _spp.PortNameList.Contains(_spp.PortName)
        //    && _spp.BaudRateList.Contains(_spp.BaudRate)
        //    && _spp.DataBitsList.Contains(_spp.DataBits)
        //    && Enum.IsDefined(typeof(Parity), _spp.Parity)
        //    && Enum.IsDefined(typeof(StopBits), _spp.StopBits)
        //    && Enum.IsDefined(typeof(Handshake), _spp.Handshake))
        //{
        //    // 開啟IO Port
        //    if (Reopen())
        //    {
        //        // TODO: 通訊測試


        //        return;
        //    }
        //}

        //_ = _prismMessageBox.Show("串列通訊設定值異常，請重新檢查參數！", "串列通訊參數錯誤", MessageBoxImage.Error);
    }

    public static void Dispose()
    {
        RjcpSerialPort?.Dispose();
    }

    /********************
     * 內部參數
     ********************/
    public bool IsOpen => RjcpSerialPort != null && RjcpSerialPort.IsOpen;

    /********************
     * common function
     ********************/
    /// <inheritdoc/>
    public bool Reopen()
    {
        // Port Close
        if (IsOpen)
        {
            //_serialPort.DataReceived -= Sp_DataReceived;//new SerialDataReceivedEventHandler(sp_DataReceived);
            RjcpSerialPort.DataReceived -= SerialPort_DataReceived;
            RjcpSerialPort.ErrorReceived -= SerialPort_ErrorReceived;
            RjcpSerialPort.PinChanged -= SerialPort_PinChanged;
            RjcpSerialPort.Close();
        }

        // Port Open
        try
        {
            //if (recviceBuffer == null)
            //{
            //    recviceBuffer = new byte[BufSize];
            //}
            RjcpSerialPort = new SerialPortStream(_spp.PortName,
                                                  _spp.BaudRate,
                                                  _spp.DataBits,
                                                  _spp.Parity,
                                                  _spp.StopBits)
            {
                Handshake = _spp.Handshake
            };
            RjcpSerialPort.Open();

            if (IsOpen)
            {
                _spp.IsOpen = true;
                RjcpSerialPort.DataReceived += SerialPort_DataReceived;
                RjcpSerialPort.ErrorReceived += SerialPort_ErrorReceived;
                RjcpSerialPort.PinChanged += SerialPort_PinChanged;
                return true;
            }
            else
            {
                _spp.IsOpen = false;
                RjcpSerialPort.DataReceived -= SerialPort_DataReceived;
                RjcpSerialPort.ErrorReceived -= SerialPort_ErrorReceived;
                RjcpSerialPort.PinChanged -= SerialPort_PinChanged;
                return false;
            }

        }
        catch
        {
            _spp.IsOpen = false;
            RjcpSerialPort.DataReceived -= SerialPort_DataReceived;
            RjcpSerialPort.ErrorReceived -= SerialPort_ErrorReceived;
            RjcpSerialPort.PinChanged -= SerialPort_PinChanged;
            _ = _prismMessageBox.Show("串列通訊設定值異常，請重新檢查參數！", "串列通訊參數錯誤", MessageBoxImage.Error);
            return false;
        }
    }

    /********************
     * Serial Port Function
     ********************/
    /// <inheritdoc/>
    public List<string> RefreshPortNameList()
    {
        _spp.PortNameList = SerialPortStream.GetPortNames().ToList();
        _spp.PortNameList.Sort();
        return _spp.PortNameList;
    }

    /// <inheritdoc/>
    public void SendData(string data)
    {
        if (RjcpSerialPort != null && RjcpSerialPort.IsOpen)
        {
            try
            {
                RjcpSerialPort.Write(data);
            }
            catch (TimeoutException e)
            {
                throw new Exception($"SendData Timeout: {e.Message}");
            }
        }
    }

    private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
    {
        if (!IsOpen)
            return;

        var sps = sender as SerialPortStream;
        _spp.ReceivedMessages = sps.ReadExisting().Split('\r')[0];
    }

    private void SerialPort_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
    {
        Task.Delay(10);
    }

    private void SerialPort_PinChanged(object sender, SerialPinChangedEventArgs e)
    {
        //UpdatePinState();
    }

    //private void UpdatePinState()
    //{
    //    _ = Task.Run(() =>
    //    {
    //        _ctsHolding = RjcpSerialPort.CtsHolding;
    //        _dsrHolding = RjcpSerialPort.DsrHolding;
    //        _cdHolding = RjcpSerialPort.CDHolding;
    //    });
    //}
}
