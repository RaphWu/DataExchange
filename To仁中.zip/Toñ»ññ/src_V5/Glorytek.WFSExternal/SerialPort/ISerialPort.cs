﻿using System.Collections.Generic;

namespace Glorytek.WFSExternal.SerialPort;

/// <summary>
/// IOPSP實例化。
/// </summary>
/// <remarks>使用套件: <see href="https://github.com/jcurl/serialportstream"/>。</remarks>
public interface ISerialPort
{
    /// <summary>
    /// SerialPort是否開啟。
    /// </summary>
    bool IsOpen { get; }

    /// <summary>
    /// 傳送Data。
    /// </summary>
    void SendData(string data);

    /********************
     * Database
     ********************/
    /// <summary>
    /// 寫入資料庫。
    /// </summary>
    /// <returns>寫入是否成功？</returns>
    bool WriteToDb();

    /// <summary>
    /// 讀取資料庫。
    /// </summary>
    /// <returns>讀取是否成功？</returns>
    bool ReadFromDb();

    /********************
     * common function
     ********************/
    /// <summary>
    /// 依設定的參數重新開啟Port。
    /// </summary>
    bool Reopen();

    /// <summary>
    /// 更新並返回Port Name列表。
    /// </summary>
    List<string> RefreshPortNameList();
}
