﻿using Prism.Mvvm;
using RJCP.IO.Ports;
using System;
using System.Collections.Generic;

namespace Glorytek.WFSExternal.SerialPort;

public class SerialPortParameters : BindableBase
{
    private SerialPortParameters() { }
    private static readonly Lazy<SerialPortParameters> _instance = new(() => new SerialPortParameters());
    public static SerialPortParameters Instance => _instance.Value;

    /********************
     * 基本參數
     ********************/
    /// <summary>
    /// SerialPort名稱。
    /// </summary>
    public string PortName
    {
        get { return _portName; }
        set { SetProperty(ref _portName, value); }
    }
    private string _portName;

    /// <summary>
    /// 鮑率。
    /// </summary>
    public int BaudRate
    {
        get { return _baudRate; }
        set { SetProperty(ref _baudRate, value); }
    }
    private int _baudRate;

    /// <summary>
    /// 同位位元ID。
    /// </summary>
    public int ParityId
    {
        get { return _parityId; }
        set { SetProperty(ref _parityId, value); }
    }
    private int _parityId;

    /// <summary>
    /// 同位位元。
    /// </summary>
    public Parity Parity
    {
        get
        {
            if (Enum.TryParse(ParityId.ToString(), out Parity Parity))
                return Parity;
            else
                return Parity.Odd;
        }
        set
        {
            ParityId = (int)value;
            RaisePropertyChanged();
        }
    }

    /// <summary>
    /// 資料位元
    /// </summary>
    public int DataBits
    {
        get { return _dataBits; }
        set { SetProperty(ref _dataBits, value); }
    }
    private int _dataBits;

    /// <summary>
    /// 停止位元ID。
    /// </summary>
    public int StopBitsId
    {
        get { return _stopBitsId; }
        set { SetProperty(ref _stopBitsId, value); }
    }
    private int _stopBitsId;

    /// <summary>
    /// 停止位元。
    /// </summary>
    public StopBits StopBits
    {
        get
        {
            if (Enum.TryParse(StopBitsId.ToString(), out StopBits StopBits))
                return StopBits;
            else
                return StopBits.One;
        }
        set
        {
            StopBitsId = (int)value;
            RaisePropertyChanged();
        }
    }

    /// <summary>
    /// 交握模式ID。
    /// </summary>
    public int HandshakeId
    {
        get { return _handshakeId; }
        set { SetProperty(ref _handshakeId, value); }
    }
    private int _handshakeId;

    /// <summary>
    /// 交握模式。
    /// </summary>
    public Handshake Handshake
    {
        get
        {
            if (Enum.TryParse(HandshakeId.ToString(), out Handshake Handshake))
                return Handshake;
            else
                return Handshake.None;
        }
        set
        {
            HandshakeId = (int)value;
            RaisePropertyChanged();
        }
    }

    //public bool DtrEnable { get; set; }

    //public bool RtsEnable { get; set; }

    /********************
     * 狀態
     ********************/
    /// <summary>
    /// SerialPort是否開啟。
    /// </summary>
    public bool IsOpen
    {
        get { return _isOpen; }
        set { SetProperty(ref _isOpen, value); }
    }
    private bool _isOpen;

    /********************
     * 列表
     ********************/
    /// <summary>
    /// SerialPort名稱列表。
    /// </summary>
    public List<string> PortNameList
    {
        get { return _portNameList; }
        set { SetProperty(ref _portNameList, value); }
    }
    private List<string> _portNameList;

    /// <summary>
    /// 鮑率列表。
    /// </summary>
    public List<int> BaudRateList
    {
        get { return _baudRateList; }
        set { SetProperty(ref _baudRateList, value); }
    }
    private List<int> _baudRateList;

    /// <summary>
    /// 資料位元列表。
    /// </summary>
    public List<int> DataBitsList
    {
        get { return _dataBitsList; }
        set { SetProperty(ref _dataBitsList, value); }
    }
    private List<int> _dataBitsList;

    /********************
     * 通訊
     ********************/
    /// <summary>
    /// 接收的訊息。
    /// </summary>
    public string ReceivedMessages
    {
        get { return _receivedMessages; }
        set { SetProperty(ref _receivedMessages, value); }
    }
    private string _receivedMessages;
}
