﻿namespace Glorytek.WFSExternal.SerialPort;

/// <summary>
/// 資料庫定義 - RS-232。
/// </summary>
internal class DB_SerialPort
{
    internal const string SerialPortFileName = "SerialPort.json";
}
