﻿namespace Glorytek.WFSExternal.WfsMeasuringMachine;

/// <summary>
/// WFS量測機量測數據。
/// </summary>
public class MeasuringMachineDefine
{
    /// <summary>
    /// 鏡片編號。
    /// </summary>
    public int LensNumber { get; set; }

    /// <summary>
    /// 偏心角。
    /// </summary>
    /// <remarks>由 Decenter_X 及 Decenter_Y 算出的角度。</remarks>
    public double Angle { get; set; }

    /// <summary>
    /// 量測數據。
    /// </summary>
    public double Decenter { get; set; }

    /// <summary>
    /// 量測數據。
    /// </summary>
    public double DecenterX { get; set; }

    /// <summary>
    /// 量測數據。
    /// </summary>
    public double DecenterY { get; set; }

    /// <summary>
    /// 量測數據。
    /// </summary>
    public double Coma { get; set; }

    /// <summary>
    /// 量測數據。
    /// </summary>
    public double Astigmatism { get; set; }

    /// <summary>
    /// 量測數據。
    /// </summary>
    public double Spherical { get; set; }

    /// <summary>
    /// 量測數據。
    /// </summary>
    public double Trefoil { get; set; }
}
