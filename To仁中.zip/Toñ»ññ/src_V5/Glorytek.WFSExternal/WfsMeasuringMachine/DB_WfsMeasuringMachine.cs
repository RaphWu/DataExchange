﻿namespace Glorytek.WFSExternal.WfsMeasuringMachine;

/// <summary>
/// 資料庫定義 - 量測機。
/// </summary>
internal class DB_WfsMeasuringMachine
{
    internal const string WFSMeasuringParasFileName = "MeasuringMachine.json";
}
