﻿using Glorytek.CSharp.Data;
using Glorytek.CSharp.IO;
using Glorytek.WFSCore.Constants;
using System;
using TouchSocket.Core;
using TouchSocket.Sockets;

namespace Glorytek.WFSExternal.WfsMeasuringMachine;

/// <summary>
/// WFS量測機通訊。
/// </summary>
/// <remarks>Note: 量測機是Client端。</remarks>
public class MeasuringService : IMeasuring
{
    private static readonly TcpService _judgementServer = new();
    private readonly MeasuringDatas _md = MeasuringDatas.Instance;

    // 接收的資料與狀況
    private static ReceiveDataDefine _receivedData = default;
    private static bool _dataValid = default;

    /********************
     * Public Datas
     ********************/
    /// <inheritdoc/>
    public ReceiveDataDefine ReceivedData => _receivedData;

    /// <inheritdoc/>
    public bool DataValid => _dataValid;

    /********************
     * ctor
     ********************/
    public MeasuringService()
    {
        _dataValid = false;
    }

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public void WriteToDb()
    {
        JsonFileHelper.Save(DBbase.Directory_Base, DB_WfsMeasuringMachine.WFSMeasuringParasFileName, new WFSMeasuringDefine()
        {
            Port = _md.Port,
        });
    }

    /// <inheritdoc/>
    public void ReadFromDb()
    {
        var measuringDb = JsonFileHelper.Read<WFSMeasuringDefine>(DBbase.Directory_Base,
                                                                  DB_WfsMeasuringMachine.WFSMeasuringParasFileName);
        if (measuringDb == null || !int.TryParse(measuringDb.Port.ToString(), out int port))
        {
            _md.Port = 5050; // default port
            WriteToDb();
        }
        else
        {
            _md.Port = port;
        }
    }

    /********************
     * System Command
     ********************/
    /// <summary>
    /// 模組初始化
    /// </summary>
    internal void ModuleInit()
    {
        ReadFromDb();
        Start();
    }

    /********************
     * 連線
     ********************/
    /// <inheritdoc/>
    public bool Online => _judgementServer.Count > 0;

    /// <inheritdoc/>
    public void Stop()
    {
        _judgementServer?.Stop();
        _md.ServerActivated = _judgementServer.ServerState == ServerState.Running;
    }

    /// <inheritdoc/>
    public void Start()
    {
        try
        {
            _judgementServer?.Stop();
            _judgementServer.Connected += (client, e) =>
            {
                _md.Online = _judgementServer.Count > 0;
            };
            _judgementServer.Disconnected += (client, e) =>
            {
                _md.Online = _judgementServer.Count > 0;
            };
            _judgementServer.Received += (client, byteBlock, requestInfo) =>
            {
                _dataValid = false;
                _receivedData = ParseMessageToWfsDatas(byteBlock.ToString());
                if (_receivedData != null)
                    _dataValid = true;
            };
            _judgementServer.Setup(new TouchSocketConfig()
                .UsePlugin()
                .ConfigurePlugins(x => { _ = x.UseReconnection(-1, true, 2000); })
                .ConfigureContainer(x => { x.SetSingletonLogger<ConsoleLogger>(); })
                .SetListenIPHosts(new IPHost[] { new IPHost(_md.Port) })
                .SetMaxCount(10)
                .SetThreadCount(10)
                ).Start();
        }
        catch
        {
            _md.Online = _judgementServer.Count > 0;
        }
        finally
        {
            _md.ServerActivated = _judgementServer.ServerState == ServerState.Running;
        }
    }

    /// <summary>
    /// 解析訊息字串。
    /// </summary>
    private ReceiveDataDefine ParseMessageToWfsDatas(string msg)
    {
        ReceiveDataDefine mDatas = new();
        string[] msgs = msg.Split(WfsSplitSymbol.DataEnd);

        if (msgs[0] == WfsSplitSymbol.Header)
        {
            mDatas.Header = msgs[0].ToUpper();
            mDatas.LensNumber = int.Parse(msgs[1]);
            mDatas.Result = msgs[2] == "Ok";

            if (mDatas.Result)
            {
                for (int idx = 3; idx < msgs.Length; idx++)
                {
                    string[] datas = msgs[idx].Split(WfsSplitSymbol.ValueSplit);
                    if (datas.Length >= 2 && double.TryParse(datas[1], out double data))
                    {
                        switch (datas[0])
                        {
                            case "Decenter":
                                mDatas.Decenter = data;
                                break;
                            case "DecenterX":
                                mDatas.DecenterX = data;
                                break;
                            case "DecenterY":
                                mDatas.DecenterY = data;
                                break;
                            case "Coma":
                                mDatas.Coma = data;
                                break;
                            case "Astigmatism":
                                mDatas.Astigmatism = data;
                                break;
                            case "Spherical":
                                mDatas.Spherical = data;
                                break;
                            case "Trefoil":
                                mDatas.Trefoil = data;
                                break;
                        }
                    }
                }

                double angle = Math.Atan2(mDatas.DecenterY, mDatas.DecenterX) * 180.0 / Math.PI;
                if (angle < 0.0)
                    angle += 360.0;
                mDatas.Angle = angle.Format(1);
            }
            return mDatas;
        }
        else
        {
            return null;
        }
    }
}
