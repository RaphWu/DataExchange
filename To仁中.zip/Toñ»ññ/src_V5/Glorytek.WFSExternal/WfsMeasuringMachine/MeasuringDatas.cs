﻿using Prism.Mvvm;

namespace Glorytek.WFSExternal.WfsMeasuringMachine;

/// <summary>
/// 給WPF繫結用的資料。
/// </summary>
public class MeasuringDatas : BindableBase
{
    /********************
     * Singleton & INotifyPropertyChanged
     ********************/
    private MeasuringDatas() { }
    private static readonly MeasuringDatas _instance = new();
    public static MeasuringDatas Instance => _instance;

    /// <summary>
    /// 連線狀態。
    /// </summary>
    public bool Online
    {
        get { return _online; }
        set { SetProperty(ref _online, value); }
    }
    private bool _online;

    /// <summary>
    /// 伺服器是否已開啟。
    /// </summary>
    public bool ServerActivated
    {
        get { return _serverActivated; }
        set { SetProperty(ref _serverActivated, value); }
    }
    private bool _serverActivated;

    /// <summary>
    /// 監聽埠。
    /// </summary>
    public int Port
    {
        get { return _port; }
        set { SetProperty(ref _port, value); }
    }
    private int _port;
}
