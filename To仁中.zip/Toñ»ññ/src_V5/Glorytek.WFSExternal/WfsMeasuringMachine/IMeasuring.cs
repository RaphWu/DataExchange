﻿namespace Glorytek.WFSExternal.WfsMeasuringMachine;

/// <summary>
/// WFS量測機。
/// </summary>
public interface IMeasuring
{
    /********************
     * database
     ********************/
    /// <summary>
    /// 儲存參數。
    /// </summary>
    void WriteToDb();

    /// <summary>
    /// 讀取參數。
    /// </summary>
    void ReadFromDb();

    /********************
     * 
     ********************/
    /// <summary>
    /// 最後一次接收的資料。
    /// </summary>
    ReceiveDataDefine ReceivedData { get; }

    /// <summary>
    /// 資料已接收完畢並且是有效的。
    /// </summary>
    bool DataValid { get; }

    /********************
     * 連線
     ********************/
    /// <summary>
    /// 量測機是否已連線。
    /// </summary>
    /// <remarks>true: 連線中<br/>false:未連線</remarks>
    bool Online { get; }

    /// <summary>
    /// 停止監聽器。
    /// </summary>
    void Stop();

    /// <summary>
    /// 啟動監聽器。
    /// </summary>
    void Start();
}
