﻿namespace Glorytek.WFSExternal.WfsMeasuringMachine;

/// <summary>
/// 接收的數據定義。
/// </summary>
public class ReceiveDataDefine : MeasuringMachineDefine
{
    /// <summary>
    /// 幀頭。
    /// </summary>
    public string Header { get; set; }

    /// <summary>
    /// 量測結果。
    /// </summary>
    public bool Result { get; set; }
}
