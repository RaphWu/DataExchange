﻿using Glorytek.CSharp.Data;
using Glorytek.WFSCore;
using Glorytek.WFSExternal.PLC.Contracts;
using System.Threading.Tasks;

namespace Glorytek.WFSExternal.Vision;

/// <summary>
/// PV200視覺系統Service。
/// </summary>
public class VisionService : IVision
{
    /********************
     * ctor
     ********************/
    private readonly IPlc _plc;

    public VisionService(IPlc plc)
    {
        _plc = plc;
    }

    /********************
     * Functions
     ********************/
    /// <inheritdoc/>
    public bool TakePicture(ref VisionData visionData)
    {
        if (_plc.Online)
        {
            _plc.WriteInt32(DeviceLists.CAMERA1_PRODUCT_TYPE, visionData.ProductType);
            _plc.SendCommandPulse(DeviceLists.CAMERA1_TRIGGER_COMMAND);

            bool visionComplete = Task.Run(() =>
            {
                bool isComplete = false;
                while (!isComplete)
                {
                    var (isSucceed, result) = _plc.ReadBool(DeviceLists.CAMERA1_TRIGGER_COMPLETE);
                    isComplete = isSucceed && (bool)result;
                }
            }).Wait(2000);

            if (visionComplete)
            {
                var (cameraTrigger, cameraOk) = _plc.ReadBool(DeviceLists.CAMERA1_RESULT_OK, 2);
                if (cameraTrigger)
                {
                    var (cameraResultOK, cameraResult) = _plc.ReadDoubleByInt32(DeviceLists.CAMERA1_RESULT_X, 3);
                    if (cameraResultOK)
                    {
                        visionData.OK = cameraOk[0];
                        visionData.NG = cameraOk[1];
                        visionData.X = cameraResult[0].WfsFormat();
                        visionData.Y = cameraResult[1].WfsFormat();
                        visionData.R = (cameraResult[2] * 100.0).Format(1);
                        return true;
                    }
                }
            }
        }

        // 拍照失敗
        visionData.OK = false;
        visionData.NG = true;
        visionData.X = 0.0;
        visionData.Y = 0.0;
        visionData.R = 0.0;
        return false;
    }
}