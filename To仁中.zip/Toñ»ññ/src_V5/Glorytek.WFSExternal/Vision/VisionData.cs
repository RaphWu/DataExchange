﻿namespace Glorytek.WFSExternal.Vision;

/// <summary>
/// 拍照交握資料。
/// </summary>
public class VisionData
{
    /// <summary>
    /// 拍照品種。
    /// </summary>
    public int ProductType { get; set; }

    /// <summary>
    /// 拍照結果: OK。
    /// </summary>
    public bool OK { get; set; }

    /// <summary>
    /// 拍照結果: NG。
    /// </summary>
    public bool NG { get; set; }

    /// <summary>
    /// 拍照結果: X。
    /// </summary>
    public double X { get; set; }

    /// <summary>
    /// 拍照結果: Y。
    /// </summary>
    public double Y { get; set; }

    /// <summary>
    /// 拍照結果: R。
    /// </summary>
    public double R { get; set; }
}
