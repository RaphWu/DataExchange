﻿namespace Glorytek.WFSExternal.Vision;

/// <summary>
/// PV200視覺系統。
/// </summary>
public interface IVision
{
    /// <summary>
    /// 拍攝一張照片，並回傳結果值。
    /// </summary>
    /// <param name="visionData"><see cref="VisionData"/>物件。<br/>呼叫前必須事先寫入品種(ProductType)。</param>
    /// <returns>拍照是否完成。</returns>
    bool TakePicture(ref VisionData visionData);
}
