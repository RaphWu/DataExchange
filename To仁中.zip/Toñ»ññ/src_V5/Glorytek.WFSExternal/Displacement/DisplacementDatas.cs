﻿using Prism.Mvvm;
using System;

namespace Glorytek.WFSExternal.Displacement;

/// <summary>
/// 位移計資料。
/// </summary>
public class DisplacementDatas : BindableBase
{
    /********************
     * Singleton & INotifyPropertyChanged
     ********************/
    private DisplacementDatas() { }
    private static readonly Lazy<DisplacementDatas> _instance = new(() => new DisplacementDatas());
    public static DisplacementDatas Instance => _instance.Value;

    /// <summary>
    /// Online狀態。
    /// </summary>
    public bool Online
    {
        get { return _online; }
        set { SetProperty(ref _online, value); }
    }
    private bool _online;

    /// <summary>
    /// IP Address。
    /// </summary>
    public string IpAddress
    {
        get { return _ipAddress; }
        set { SetProperty(ref _ipAddress, value); }
    }
    private string _ipAddress;

    /// <summary>
    /// Port。
    /// </summary>
    public int Port
    {
        get { return _port; }
        set { SetProperty(ref _port, value); }
    }
    private int _port;

    /// <summary>
    /// 讀取值的Buffer。
    /// </summary>
    public double ReadValue
    {
        get { return _readValue; }
        set { SetProperty(ref _readValue, value); }
    }
    private double _readValue;
}
