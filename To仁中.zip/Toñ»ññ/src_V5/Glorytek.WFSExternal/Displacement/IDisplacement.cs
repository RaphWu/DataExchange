﻿namespace Glorytek.WFSExternal.Displacement;

/// <summary>
/// KEYENCE DL-EN1 Ethernet TCPIP Compatible Network Unit 操作。
/// </summary>
public interface IDisplacement
{
    /********************
     * Database
     ********************/
    /// <summary>
    /// 寫入資料庫。
    /// </summary>
    void WriteToDb();

    /// <summary>
    /// 讀取資料庫。
    /// </summary>
    void ReadFromDb();

    /********************
     * Command
     ********************/
    /// <summary>
    /// 開啟連線。
    /// </summary>
    void Open();

    /// <summary>
    /// 斷開連線。
    /// </summary>
    void Close();

    /********************
     * Instance
     ********************/
    /// <summary>
    /// 連線狀態。
    /// </summary>
    bool Online { get; }
}
