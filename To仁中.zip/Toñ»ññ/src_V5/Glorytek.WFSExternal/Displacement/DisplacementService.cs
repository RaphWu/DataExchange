﻿using Glorytek.CSharp.IO;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Events;
using Prism.Events;
using System;
using System.Net;
using System.Text;
using System.Windows.Threading;
using TouchSocket.Core;
using TouchSocket.Sockets;

namespace Glorytek.WFSExternal.Displacement;

/// <summary>
/// KEYENCE DL-EN1 Ethernet TCPIP Compatible Network Unit Service。
/// </summary>
public class DisplacementService : IDisplacement
{
    private readonly DisplacementDatas _dd = DisplacementDatas.Instance;
    private readonly DispatcherTimer _displacementTimer = new();

    private static TcpClient DL_EN1 = null;
    private static IPEndPoint _ipEndPoint;

    private static bool _eventNotSubscribed = true;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;

    public DisplacementService(IEventAggregator ea)
    {
        _ea = ea;

        _displacementTimer.Tick += new EventHandler(OnTimedEvent);
        _displacementTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);

        if (_eventNotSubscribed)
        {
            _eventNotSubscribed = false;
            _ = _ea.GetEvent<ApplicationShutdownEvent>().Subscribe(ApplicationShutdown, keepSubscriberReferenceAlive: true);
        }
    }

    /// <summary>
    /// 應用程式結束。
    /// </summary>
    private void ApplicationShutdown(int _)
    {
        Close();
    }

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public void WriteToDb()
    {
        JsonFileHelper.Save(DBbase.Directory_Base, DB_Displacement.DisplacementParasFileName, new DisplacementDefine()
        {
            IpAddress = _dd.IpAddress,
            Port = _dd.Port,
        });
    }

    /// <inheritdoc/>
    public void ReadFromDb()
    {
        var displacementDb = JsonFileHelper.Read<DisplacementDefine>(DBbase.Directory_Base, DB_Displacement.DisplacementParasFileName);

        IPAddress ipAddress = default;
        bool ipValid = displacementDb != null && IPAddress.TryParse(displacementDb.IpAddress, out ipAddress);

        _ipEndPoint = ipValid
            ? new IPEndPoint(ipAddress, displacementDb.Port)
            : new IPEndPoint(IPAddress.Parse("192.168.1.81"), 64000);

        _dd.IpAddress = _ipEndPoint.Address.ToString();
        _dd.Port = _ipEndPoint.Port;

        if (!ipValid)
            WriteToDb();
    }

    /********************
     * Instance
     ********************/
    /// <inheritdoc/>
    public bool Online => DL_EN1.Online;

    /********************
     * System Command
     ********************/
    /// <summary>
    /// 模組初始化
    /// </summary>
    internal void ModuleInit()
    {
        ReadFromDb();
        Open();
    }

    /********************
     * Socket
     ********************/
    /// <inheritdoc/>
    public void Open()
    {
        try
        {
            DL_EN1?.Close();
            DL_EN1 = new();
            TouchSocketConfig config = new();
            config.SetRemoteIPHost(new IPHost($"{_dd.IpAddress}:{_dd.Port}"))
                .UsePlugin()
                .SetBufferLength(1024 * 10)
                .ConfigureContainer(a =>
                {
                    a.SetSingletonLogger(new LoggerGroup(new ConsoleLogger()));
                })
                .ConfigurePlugins(act =>
                {
                    act.UseReconnection(-1, true, 2000);
                });
            DL_EN1.Setup(config);

            DL_EN1.Connected += (client, e) =>
            {
                _dd.Online = DL_EN1.Online;
                _displacementTimer.Start();
            };
            DL_EN1.Disconnected += (client, e) =>
            {
                _dd.Online = DL_EN1.Online;
                _displacementTimer.Stop();
            };
            DL_EN1.Received += (client, byteBlock, obj) =>
            {
                string mes = Encoding.UTF8.GetString(byteBlock.Buffer, 0, byteBlock.Len);
                string[] mess = mes.Split(',');

                if (mess[0] != "ER" && (mess.Length >= 2 && mess[1] != "-099999999\r\n"))
                {
                    if (double.TryParse(mess[1], out double value))
                        _dd.ReadValue = value / 1000.0;
                }
                else
                {
                    _dd.ReadValue = 0.0;
                }
            };
#if DEBUG
            if (!WFSCore.Models.DEBUG.NoPlcConnected)
                DL_EN1.Connect();
#else
            DL_EN1.Connect();
#endif
        }
        catch (Exception ex)
        {
            DL_EN1.Logger.Error(ex, ex.Message);
            DL_EN1?.Close();
        }
    }

    /// <inheritdoc/>
    public void Close()
    {
        DL_EN1?.Close();
    }

    /********************
     * Timer Event
     ********************/
    private void OnTimedEvent(object sender, EventArgs e)
    {
        try
        {
            if (DL_EN1?.CanSend == true)
                DL_EN1.Send(Encoding.ASCII.GetBytes("M0\r\n"));
        }
        catch (System.Net.Sockets.SocketException se)
        {
            DL_EN1.Logger.Error(se, se.Message);
        }
    }
}
