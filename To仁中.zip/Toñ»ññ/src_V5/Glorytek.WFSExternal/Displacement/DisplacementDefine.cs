﻿namespace Glorytek.WFSExternal.Displacement;

/// <summary>
/// 位移計的資料庫對應類別。
/// </summary>
internal class DisplacementDefine
{
    /// <summary>
    /// IP位址。
    /// </summary>
    public string IpAddress { get; set; }

    /// <summary>
    /// Port號。
    /// </summary>
    public int Port { get; set; }
}
