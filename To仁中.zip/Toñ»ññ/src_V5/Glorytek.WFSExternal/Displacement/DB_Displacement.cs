﻿namespace Glorytek.WFSExternal.Displacement;

/// <summary>
/// 資料庫定義 - 位移計。
/// </summary>
internal class DB_Displacement
{
    internal const string DisplacementParasFileName = "Displacement.json";
}
