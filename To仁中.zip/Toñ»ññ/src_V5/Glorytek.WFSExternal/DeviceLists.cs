﻿namespace Glorytek.WFSExternal;

/// <summary>
/// PLC軟元件列表。
/// </summary>
public static class DeviceLists
{
    /********************
     * System
     ********************/
    /// <summary>
    /// 系統模式 - 轉角度模式。
    /// </summary>
    public static readonly string SYSTEM_MODE_LENS_ARRANGE = "M6006";
    /// <summary>
    /// 系統模式 - 分檢模式。
    /// </summary>
    public static readonly string SYSTEM_MODE_LENS_SORTING = "M6007";
    /// <summary>
    /// 系統模式 - 對接模式(固定平台)。
    /// </summary>
    public static readonly string SYSTEM_MODE_ONLINE_FIX_STAGE = "M6031";
    /// <summary>
    /// 系統模式 - 對接模式(單汽缸)。
    /// </summary>
    public static readonly string SYSTEM_MODE_DOCKING_SINGLE_CYLINDE = "M6032";
    /// <summary>
    /// 系統模式 - 對接模式(雙汽缸)。
    /// </summary>
    public static readonly string SYSTEM_MODE_DOCKING_DOUBLE_CYLINDE = "M6033";
    /// <summary>
    /// 系統模式 - 對接模式(圓盤)。
    /// </summary>
    public static readonly string SYSTEM_MODE_DOCKING_DOUBLE_DISC = "M6034";
    /// <summary>
    /// 系統模式 - TRAY > A1重複精度測試。
    /// </summary>
    public static readonly string SYSTEM_MODE_TRAY_A1 = "M6035";

    /********************
     * 
     ********************/
    /// <summary>
    /// 整體速率。
    /// </summary>
    public static readonly string OVERALL_SPEED = "D20750";

    /// <summary>
    /// XY軸到位後延時。
    /// </summary>
    public static readonly string XY_AXIS_INP_DELAY = "D20158";
    /// <summary>
    /// XY減速距離。
    /// </summary>
    public static readonly string XY_AXIS_SLOW_DOWN = "D20756";
    /// <summary>
    /// XY減速速率。
    /// </summary>
    public static readonly string XY_AXIS_SLOW_DOWN_SPEED = "D20758";
    /// <summary>
    /// Z加減速距離
    /// </summary>
    public static readonly string Z_AXIS_SPEED_UP_DOWN = "D20700";

    // 運轉
    /// <summary>
    /// 自動運轉啟動指令。
    /// </summary>
    public static readonly string START_COMMAND = "M0";
    /// <summary>
    /// 自動運轉暫停指令。
    /// </summary>
    public static readonly string PAUSE_COMMAND = "M4";
    /// <summary>
    /// 自動運轉停止指令。
    /// </summary>
    public static readonly string STOP_COMMAND = "M2";
    /// <summary>
    /// 手動模式指令。
    /// </summary>
    public static readonly string MANUAL_MODE_COMMAND = "M1";
    /// <summary>
    /// 警報解除指令。
    /// </summary>
    public static readonly string ALARM_RESET_COMMAND = "M6";
    /// <summary>
    /// 試運轉指令。
    /// </summary>
    public static readonly string TEST_MODE_COMMAND = "M6002";

    /// <summary>
    /// 自動運轉狀態。
    /// </summary>
    public static readonly string AUTO_MODE = "M40";
    /// <summary>
    /// 手動狀態。
    /// </summary>
    public static readonly string MANUAL_MODE = "M41";
    /// <summary>
    /// 暫停狀態。
    /// </summary>
    public static readonly string MACHINE_PAUSE = "M44";
    /// <summary>
    /// 試運轉狀態。
    /// </summary>
    public static readonly string TEST_MODE = "M6003";
    /// <summary>
    /// 自動運轉停止並開始復歸。
    /// </summary>
    public static readonly string AUTO_MODE_STOP = "M14500";
    /// <summary>
    /// 自動運轉停止並復歸結束。
    /// </summary>
    public static readonly string AUTO_MODE_STOP_AND_HOME = "M14514";

    // 基準點
    /// <summary>
    /// 基準點相機X座標。
    /// </summary>
    public static readonly string DATUM_POINT_X = "D20030";
    /// <summary>
    /// 基準點相機Y座標。
    /// </summary>
    public static readonly string DATUM_POINT_Y = "D20032";
    /// <summary>
    /// 基準點相機Z座標。
    /// </summary>
    public static readonly string DATUM_POINT_CAMERA_Z = "D20034";
    /// <summary>
    /// 基準點高度。
    /// </summary>
    public static readonly string DATUM_POINT_Z = "D20090";
    /// <summary>
    /// 移動相機到基準點指令。
    /// </summary>
    public static readonly string MOVE_CAMERA_TO_DATUM_POINT_COMMAND = "M7880";
    /// <summary>
    /// 基準點畫像品種。
    /// </summary>
    public static readonly string DATUM_POINT_VISION_ID = "D20601";
    /// <summary>
    /// R軸0度補償。
    /// </summary>
    public static readonly string R_AXIS_ZERO_DEGREE_CORRECTION = "D20092";

    // 安全位置、高度
    /// <summary>
    /// 安全位置X座標。
    /// </summary>
    public static readonly string SAFETY_X = "D20084";
    /// <summary>
    /// 安全位置Y座標。
    /// </summary>
    public static readonly string SAFETY_Y = "D20086";
    /// <summary>
    /// 安全高度。
    /// </summary>
    public static readonly string SAFETY_HEIGHT = "D20610";

    // 黏土座(相機)
    /// <summary>
    /// 黏土座畫像品種。
    /// </summary>
    public static readonly string CLAY_TABLE_VISION_ID = "D20602";
    /// <summary>
    /// 黏土座相機X座標。
    /// </summary>
    public static readonly string CLAY_TABLE_X = "D20042";
    /// <summary>
    /// 黏土座相機Y座標。
    /// </summary>
    public static readonly string CLAY_TABLE_Y = "D20044";
    /// <summary>
    /// 黏土座高度。
    /// </summary>
    public static readonly string CLAY_TABLE_Z = "D20046";
    /// <summary>
    /// 移動相機到黏土座指令。
    /// </summary>
    public static readonly string MOVE_CAMERA_TO_CLAY_TABLE_COMMAND = "M7920";

    // 黏土座(吸嘴)
    /// <summary>
    /// 黏土座吸嘴X座標。
    /// </summary>
    public static readonly string NOZZLE_STAMP_X = "D20036";
    /// <summary>
    /// 黏土座吸嘴Y座標。
    /// </summary>
    public static readonly string NOZZLE_STAMP_Y = "D20038";
    /// <summary>
    /// 黏土座吸嘴Z座標。
    /// </summary>
    public static readonly string NOZZLE_STAMP_Z = "D20040";
    /// <summary>
    /// 黏土座吸嘴R座標。
    /// </summary>
    public static readonly string NOZZLE_STAMP_R = "D20048";
    /// <summary>
    /// 移動吸嘴到黏土座指令。
    /// </summary>
    public static readonly string MOVE_NOZZLE_TO_CLAY_TABLE_COMMAND = "M7900";

    //// 黏土座
    //public static readonly string _DISTANCE_FROM_NOZZLE_TO_CAMERA_X = "D20080";
    //public static readonly string _DISTANCE_FROM_NOZZLE_TO_CAMERA_Y = "D20082";

    // 位移計
    /// <summary>
    /// 位移計相機X座標。
    /// </summary>
    public static readonly string DISPLACEMENT_X = "D20098";
    /// <summary>
    /// 位移計相機Y座標。
    /// </summary>
    public static readonly string DISPLACEMENT_Y = "D20100";
    /// <summary>
    /// 位移計高度。
    /// </summary>
    public static readonly string DISPLACEMENT_Z = "D20102";
    /// <summary>
    /// 移動相機到位移計指令。
    /// </summary>
    public static readonly string MOVE_CAMERA_TO_DISPLACEMENT_COMMAND = "M8860";
    /// <summary>
    /// 位移計高度補正。
    /// </summary>
    public static readonly string HEIGHT_CORRECT2ON = "D20096";
    /// <summary>
    /// 位移計上一次量測值。
    /// </summary>
    public static readonly string LAST_MEASURE_HEIGHT = "D20094";

    // 吸嘴
    /// <summary>
    /// 吸嘴真空檢知。
    /// </summary>
    public static readonly string NOZZLE_VACCUM_DETECTOR = "X0B";
    /// <summary>
    /// 吸嘴真空狀態。
    /// </summary>
    public static readonly string NOZZLE_VACCUM = "Y4F";  // M4200
    /// <summary>
    /// 吸嘴真空切換。
    /// </summary>
    public static readonly string NOZZLE_VACCUM_COMMAND = "M4210";
    /// <summary>
    /// 吸嘴破真空狀態。
    /// </summary>
    public static readonly string NOZZLE_RELIEF = "Y50";  // M4250
    /// <summary>
    /// 吸嘴破真空切換。
    /// </summary>
    public static readonly string NOZZLE_RELIEF_COMMAND = "M4260";

    // Stage
    /// <summary>
    /// 移動相機到Stage 1指令。
    /// </summary>
    public static readonly string MOVE_CAMERA_TO_STAGE_1_COMMAND = "M8820";
    /// <summary>
    /// Stage 1畫像品種。
    /// </summary>
    public static readonly string STAGE_1_VISION_ID = "D20604";
    /// <summary>
    /// Stage 1相機X座標。
    /// </summary>
    public static readonly string STAGE_1_X = "D20066";
    /// <summary>
    /// Stage 1相機Y座標。
    /// </summary>
    public static readonly string STAGE_1_Y = "D20068";
    /// <summary>
    /// Stage 1高度。
    /// </summary>
    public static readonly string STAGE_1_Z = "D20070";
    /// <summary>
    /// Stage 1高度補正。
    /// </summary>
    public static readonly string STAGE_1_Z_OFFSET = "D20150";
    /// <summary>
    /// Stage 1下降減速。
    /// </summary>
    public static readonly string STAGE_1_SlowDown = "D20751";
    /// <summary>
    /// Stage 1上升加速。
    /// </summary>
    public static readonly string STAGE_1_SpeedUp = "D20752";
    /// <summary>
    /// Stage 1真空檢知。
    /// </summary>
    public static readonly string STAGE_1_VACCUM_DETECTOR = "X0C";
    /// <summary>
    /// Stage 1真空狀態。
    /// </summary>
    public static readonly string STAGE_1_VACCUM = "Y51";   // M4300
    /// <summary>
    /// Stage 1真空切換。
    /// </summary>
    public static readonly string STAGE_1_VACCUM_COMMAND = "M4310";
    /// <summary>
    /// Stage 1破真空狀態。
    /// </summary>
    public static readonly string STAGE_1_RELIEF = "Y52";   // M4350
    /// <summary>
    /// Stage 1破真空切換。
    /// </summary>
    public static readonly string STAGE_1_RELIEF_COMMAND = "M4360";
    /// <summary>
    /// Stage 1分料機側檢知。
    /// </summary>
    public static readonly string STAGE_1_LS_SORTING = "X11";
    /// <summary>
    /// Stage 1量測機側檢知。
    /// </summary>
    public static readonly string STAGE_1_LS_MEASUREMENT = "X10";
    /// <summary>
    /// Stage 1殘料檢知。
    /// </summary>
    public static readonly string STAGE_1_SCRAP_DETECTOR = "X14";
    /// <summary>
    /// Stage 1側移動氣缸到分料機側指令。
    /// </summary>
    public static readonly string CYLINDER_1_MOVETO_SORTING_COMMAND = "M4600";
    /// <summary>
    /// Stage 1側移動氣缸到量測機側指令。
    /// </summary>
    public static readonly string CYLINDER_1_MOVETO_MEASUREMENT_COMMAND = "M4550";

    /// <summary>
    /// 移動相機到Stage 2指令。
    /// </summary>
    public static readonly string MOVE_CAMERA_TO_STAGE_2_COMMAND = "M8840";
    /// <summary>
    /// Stage 2畫像品種。
    /// </summary>
    public static readonly string STAGE_2_VISION_ID = "D20605";
    /// <summary>
    /// Stage 2相機X座標。
    /// </summary>
    public static readonly string STAGE_2_X = "D20072";
    /// <summary>
    /// Stage 2相機Y座標。
    /// </summary>
    public static readonly string STAGE_2_Y = "D20074";
    /// <summary>
    /// Stage 2高度。
    /// </summary>
    public static readonly string STAGE_2_Z = "D20076";
    /// <summary>
    /// Stage 2高度補正。
    /// </summary>
    public static readonly string STAGE_2_Z_OFFSET = "D20154";
    /// <summary>
    /// Stage 2下降減速。
    /// </summary>
    public static readonly string STAGE_2_SlowDown = "D20753";
    /// <summary>
    /// Stage 2上升加速。
    /// </summary>
    public static readonly string STAGE_2_SpeedUp = "D20754";
    /// <summary>
    /// Stage 2真空檢知。
    /// </summary>
    public static readonly string STAGE_2_VACCUM_DETECTOR = "X0D";
    /// <summary>
    /// Stage 2真空狀態。
    /// </summary>
    public static readonly string STAGE_2_VACCUM = "Y53";   // M4400
    /// <summary>
    /// Stage 2真空切換。
    /// </summary>
    public static readonly string STAGE_2_VACCUM_COMMAND = "M4410";
    /// <summary>
    /// Stage 2破真空狀態。
    /// </summary>
    public static readonly string STAGE_2_RELIEF = "Y54";   // M4450
    /// <summary>
    /// Stage 2破真空切換。
    /// </summary>
    public static readonly string STAGE_2_RELIEF_COMMAND = "M4460";
    /// <summary>
    /// Stage 2分料機側檢知。
    /// </summary>
    public static readonly string STAGE_2_LS_SORTING = "X13";
    /// <summary>
    /// Stage 2量測機側檢知。
    /// </summary>
    public static readonly string STAGE_2_LS_MEASUREMENT = "X12";
    /// <summary>
    /// Stage 2殘料檢知。
    /// </summary>
    public static readonly string STAGE_2_SCRAP_DETECTOR = "X15";
    /// <summary>
    /// Stage 2側移動氣缸到分料機側指令。
    /// </summary>
    public static readonly string CYLINDER_2_MOVETO_SORTING_COMMAND = "M4700";
    /// <summary>
    /// Stage 2側移動氣缸到量測機側指令。
    /// </summary>
    public static readonly string CYLINDER_2_MOVETO_MEASUREMENT_COMMAND = "M4650";

    /********************
     * PLC復歸
     ********************/
    /// <summary>
    /// 機台復歸中。
    /// </summary>
    public static readonly string HOME_RETURNING = "M7100";
    /// <summary>
    /// 機台復歸完畢。
    /// </summary>
    public static readonly string HOME_RETURN_COMPLETED = "M7117";
    /// <summary>
    /// 機台復歸指令。
    /// </summary>
    public static readonly string HOME_RETURN_COMMAND = "M6113";
    /// <summary>
    /// 機台單軸復歸指令 - X軸。
    /// </summary>
    public static readonly string HOME_RETURN_X_COMMAND = "M6300";
    /// <summary>
    /// 機台單軸復歸指令 - Y軸。
    /// </summary>
    public static readonly string HOME_RETURN_Y_COMMAND = "M6302";

    /********************
     * JOG
     ********************/
    /// <summary>
    /// JOG速度-慢速。(脈波切換)
    /// </summary>
    public static readonly string JOG_SPEED_SLOW_COMMAND = "M6090";
    /// <summary>
    /// JOG速度-低速。(脈波切換)
    /// </summary>
    public static readonly string JOG_SPEED_LOW_COMMAND = "M6091";
    /// <summary>
    /// JOG速度-中速。(脈波切換)
    /// </summary>
    public static readonly string JOG_SPEED_MEDIUM_COMMAND = "M6092";
    /// <summary>
    /// JOG速度-高速。(脈波切換)
    /// </summary>
    public static readonly string JOG_SPEED_HIGH_COMMAND = "M6093";
    /// <summary>
    /// JOG速度-最高速。(脈波切換)
    /// </summary>
    public static readonly string JOG_SPEED_HIGHEST_COMMAND = "M6094";

    /// <summary>
    /// JOG速度值-慢速。
    /// </summary>
    public static readonly string JOG_SPEED_SLOW = "L200";
    /// <summary>
    /// JOG速度值-低速。
    /// </summary>
    public static readonly string JOG_SPEED_LOW = "L201";
    /// <summary>
    /// JOG速度值-中速。
    /// </summary>
    public static readonly string JOG_SPEED_MEDIUM = "L202";
    /// <summary>
    /// JOG速度值-高速。
    /// </summary>
    public static readonly string JOG_SPEED_HIGH = "L203";
    /// <summary>
    /// JOG速度值-最高速。
    /// </summary>
    public static readonly string JOG_SPEED_HIGHEST = "L204";

    /// <summary>
    /// 限速啟動。
    /// </summary>
    public static readonly string SPEED_LIMIT_ACTIVATED = "L205";

    /// <summary>
    /// JOG移動 - X軸正轉。
    /// </summary>
    public static readonly string X_AXIS_JOG_FORWARD = "M6120";
    /// <summary>
    /// JOG移動 - X軸反轉。
    /// </summary>
    public static readonly string X_AXIS_JOG_REVERSE = "M6121";
    /// <summary>
    /// JOG移動 - Y軸正轉。
    /// </summary>
    public static readonly string Y_AXIS_JOG_FORWARD = "M6122";
    /// <summary>
    /// JOG移動 - Y軸反轉。
    /// </summary>
    public static readonly string Y_AXIS_JOG_REVERSE = "M6123";
    /// <summary>
    /// JOG移動 - Z軸正轉。
    /// </summary>
    public static readonly string Z_AXIS_JOG_FORWARD = "M6124";
    /// <summary>
    /// JOG移動 - Z軸反轉。
    /// </summary>
    public static readonly string Z_AXIS_JOG_REVERSE = "M6125";
    /// <summary>
    /// JOG移動 - R軸正轉。
    /// </summary>
    public static readonly string R_AXIS_JOG_FORWARD = "M6126";
    /// <summary>
    /// JOG移動 - R軸反轉。
    /// </summary>
    public static readonly string R_AXIS_JOG_REVERSE = "M6127";

    /********************
     * PLC Handshake
     ********************/
    /// <summary>
    /// 取料動作的Tray盤號。
    /// </summary>
    public static readonly string WHEN_PICK_TRAY_ID = "D6150"; // Word、作業模式共用
    /// <summary>
    /// 取料動作信號。
    /// </summary>
    public static readonly string WHEN_PICK = "M7165"; // 取料後讀取1，再讀取目前點位
    /// <summary>
    /// 取料動作回饋PLC的信號。
    /// </summary>
    public static readonly string WHEN_PICK_FEEDBACK = "M150";

    // 放料動作 連線模式: 放料後讀取1，再讀取目前點位
    /// <summary>
    /// 連線模式：取料後放至Stage後信號。
    /// </summary>
    public static readonly string WHEN_PLACE_ONLINE = "M7534";
    /// <summary>
    /// 連線模式：Stage取料後，PLC等待信號；待回饋Tray盤號。
    /// </summary>
    public static readonly string WHEN_PLACEING_ONLINE = "M7535";
    /// <summary>
    /// 分檢模式：放料動作信號。
    /// </summary>
    public static readonly string WHEN_PLACE_LENS_SORTING = "M14049";
    /// <summary>
    /// 分檢模式：放料動作信號。
    /// </summary>
    public static readonly string WHEN_PLACEING_LENS_SORTING = "M14051";

    /// <summary>
    /// 中斷作業: 作業前須設為false，當有異常需提前結束作業時，將其設定為true
    /// </summary>
    public static readonly string INTERRUPT_OPERATION = "M6100";

    //// 重工動作: 放料後讀取1，再讀取目前點位
    //public static readonly string WHEN_REWORK = "";
    //public static readonly string WHEN_REWORK_FEEDBACK = "";

    /********************
     * Tray
     ********************/
    /// <summary>
    /// Tray Word資料。(Pallet 1~24)
    /// </summary>
    /// <remarks>
    /// 依序排列: [00~01]入數XY、[02~06]不使用、[07~09]ABC偏移格數、[10~29]無效點1~20<br/>
    /// 交錯排列: [30~31]入數XY、[32~36]不使用、[37~39]ABC偏移格數、[40~59]無效點1~20
    /// </remarks>
    public static readonly string[] TRAY_WORD = new string[] {
        "D20760", "D24001", "D24067", "D24133", "D24199",
        "D24265", "D24331", "D24397", "D24463", "D24529",
        "D24595", "D24661", "D24727", "D24793", "D24859",
        "D24925", "D24991", "D25057", "D25123", "D25189",
        "D25255", "D25321", "D25387", "D25453"};
    /// <summary>
    /// Tray DWord資料。(Pallet 1~24)
    /// </summary>
    /// <remarks>
    /// 依序排列: [00~01]不使用、[02~07]座標AX,AY,BX,BY,CX,CY<br/>
    /// 交錯排列: [08~09]不使用、[10~15]座標AX,AY,BX,BY,CX,CY
    /// </remarks>
    public static readonly string[] TRAY_DWORD = new string[] {
        "D20614", "D22001", "D22049", "D22097", "D22145",
        "D22193", "D22241", "D22289", "D22337", "D22385",
        "D22433", "D22481", "D22529", "D22577", "D22625",
        "D22673", "D22721", "D22769", "D22817", "D22865",
        "D22913", "D22961", "D23009", "D23057"};
    /// <summary>
    /// Tray取料高度。(Pallet 1~24)
    /// </summary>
    public static readonly string[] TRAY_PICK_HEIGHT = new string[] {
        "D20648", "D22035", "D22083", "D22131", "D22179",
        "D22227", "D22275", "D22323", "D22371", "D22419",
        "D22467", "D22515", "D22563", "D22611", "D22659",
        "D22707", "D22755", "D22803", "D22851", "D22899",
        "D22947", "D22995", "D23043", "D23091"};
    /// <summary>
    /// Tray依序排列/交錯排列。
    /// </summary>
    /// <remarks>實際位址 = "M{TRAY_ORDER_CROSS + PalletID}"。</remarks>
    public static readonly int TRAY_ORDER_CROSS = 100;
    /// <summary>
    /// 取料目標盤。
    /// </summary>
    /// <remarks>實際位址 = "M{PICK_TRAY + PalletID}"。</remarks>
    public static readonly int PICK_TRAY = 300;
    /// <summary>
    /// 分料目標盤。
    /// </summary>
    /// <remarks>實際位址 = "M{PLACE_TRAY + PalletID}"。</remarks>
    public static readonly int PLACE_TRAY = 300;
    /// <summary>
    /// Tray單動取料測試指令。
    /// </summary>
    public static readonly string TRAY_PICK_TEST = "M9000";
    /// <summary>
    /// Tray單動放料測試指令。
    /// </summary>
    public static readonly string TRAY_PLACE_TEST = "M9050";

    /********************
     * Pallet
     ********************/
    /// <summary>
    /// Pallet參數(Word)。(Pallet 1~24)
    /// </summary>
    /// <remarks>[0]取料前吸著延時、[1]取料後上升延時、[2]破真空時間、[3]放置後上升延時、[4]下降減速速率、[5]上升加速速率。</remarks>
    public static readonly string[] PALLET_WORD = new string[] {
        "D20820", "D24061", "D24127", "D24193", "D24259",
        "D24325", "D24391", "D24457", "D24523", "D24589",
        "D24655", "D24721", "D24787", "D24853", "D24919",
        "D24985", "D25051", "D25117", "D25183", "D25249",
        "D25315", "D25381", "D25447", "D25513"};
    /// <summary>
    /// Pallet參數(DWord)。(Pallet 1~24)
    /// </summary>
    /// <remarks>[0~1]依序排列OFFSET X, Y、[2~3]交錯排列OFFSET X, Y、[4]取出Z OFFSET。</remarks>
    public static readonly string[] PALLET_DWORD = new string[] {
        "D20652", "D22039", "D22087", "D22135", "D22183",
        "D22231", "D22279", "D22327", "D22375", "D22423",
        "D22471", "D22519", "D22567", "D22615", "D22663",
        "D22711", "D22759", "D22807", "D22855", "D22903",
        "D22951", "D22999", "D23047", "D23095"};
    /// <summary>
    /// Pallet參數(DWord): 減速Z。(Pallet 1~24)
    /// </summary>
    public static readonly string[] PALLET_DOWN_DEC = new string[] {
        "D20646", "D22033", "D22081", "D22129", "D22177",
        "D22225", "D22273", "D22321", "D22369", "D22417",
        "D22465", "D22513", "D22561", "D22609", "D22657",
        "D22705", "D22753", "D22801", "D22849", "D22897",
        "D22945", "D22993", "D23041", "D23089"};
    /// <summary>
    /// Pallet參數(DWord): 加速Z。(Pallet 1~24)
    /// </summary>
    public static readonly string[] PALLET_UP_ASC = new string[] {
        "D20650", "D22037", "D22085", "D22133", "D22181",
        "D22229", "D22277", "D22325", "D22373", "D22421",
        "D22469", "D22517", "D22565", "D22613", "D22661",
        "D22709", "D22757", "D22805", "D22853", "D22901",
        "D22949", "D22997", "D23045", "D23093"};
    /// <summary>
    /// Pallet模式(Word)。(Pallet 1~24)
    /// </summary>
    /// <remarks>0:未使用 1:重工 2:取料 3:分料。</remarks>
    public static readonly string TRAY_MODE = "D6126";
    /// <summary>
    /// Pallet滿/空盤。(Pallet 1~24)
    /// </summary>
    /// <remarks>1:已滿/空 0:可取放。</remarks>
    public static readonly string TRAY_FULL_EMPTY = "M7071";
    /// <summary>
    /// Pallet動作點位(Word)。(Pallet 1~24)
    /// </summary>
    /// <remarks>準備取料的位址，取完料後會+1。實際位址 = "D{TRAY_NEXT_POINT_NO_01 + PalletID}"。</remarks>
    public static readonly int TRAY_NEXT_POINT_NO_01 = 6100;
    /// <summary>
    /// Pallet目前點位(Word)。(Pallet 1~24)
    /// </summary>
    /// <remarks>目前取料的位址，取料後被設定。實際位址 = "D{TRAY_PICK_POINT_NO_01 + PalletID}"。</remarks>
    public static readonly int TRAY_PICK_POINT_NO_01 = 6150;
    /// <summary>
    /// 動作點位全部歸零指令。
    /// </summary>
    public static readonly string RESET_ALL_POINT_NO_COMMAND = "M15";
    /// <summary>
    /// Pallet安裝點畫像ID
    /// </summary>
    public static readonly string PALLET_DATUM_VISION_ID = "D20606";

    /********************
     * 最後作業品種
     ********************/
    /// <summary>
    /// 品種名長度
    /// </summary>
    public static readonly string PRODUCT_NAME_LENGTH = "D25960";
    /// <summary>
    /// 品種名位址
    /// </summary>
    public static readonly string PRODUCT_NAME = "D25961";
    /// <summary>
    /// 品種名長度限制
    /// </summary>
    public static readonly int PRODUCT_NAME_MAX_LENGTH = 39;

    /********************
     * PV200
     ********************/
    /// <summary>
    /// PV200拍照指令。
    /// </summary>
    public static readonly string CAMERA1_TRIGGER_COMMAND = "M6116";
    /// <summary>
    /// PV200拍照品種。
    /// </summary>
    public static readonly string CAMERA1_PRODUCT_TYPE = "D20603";
    /// <summary>
    /// PV200拍照是否完成？
    /// </summary>
    public static readonly string CAMERA1_TRIGGER_COMPLETE = "M6050";
    /// <summary>
    /// PV200拍照結果：OK。
    /// </summary>
    public static readonly string CAMERA1_RESULT_OK = "M6053";
    /// <summary>
    /// PV200拍照結果：NG。
    /// </summary>
    public static readonly string CAMERA1_RESULT_NG = "M6054";
    /// <summary>
    /// PV200拍照結果：X OFFSET。
    /// </summary>
    public static readonly string CAMERA1_RESULT_X = "D2758";
    /// <summary>
    /// PV200拍照結果：Y OFFSET。
    /// </summary>
    public static readonly string CAMERA1_RESULT_Y = "D2760";
    /// <summary>
    /// PV200拍照結果：R角度。
    /// </summary>
    public static readonly string CAMERA1_RESULT_R = "D2762";

    /********************
     * 作業相關
     ********************/
    // 採用移至拍照位置的指令做為計時觸發
    /// <summary>
    /// CycleTime計時觸發(自動作業)。
    /// </summary>
    public static readonly string CYCLE_TRIGGER_AUTO = "M7131";
    /// <summary>
    /// CycleTime計時觸發(轉角度模式)。
    /// </summary>
    public static readonly string CYCLE_TRIGGER_LENS_ARRANGE = "M12007";
    /// <summary>
    /// CycleTime計時觸發(分檢模式)。
    /// </summary>
    public static readonly string CYCLE_TRIGGER_LENS_SORTING = "M14007";

    /// <summary>
    /// 製作數設定。
    /// </summary>
    public static readonly string ESTIMATED_QUANTITY_SETTING = "D6175";
    /// <summary>
    /// 已製作數。
    /// </summary>
    public static readonly string ESTIMATED_QUANTITY = "D6176";
    /// <summary>
    /// 目前取料位置(含無效點)。
    /// </summary>
    public static readonly string CURRENT_SEQUENCE = "D6177";

    // 重複精度測試測試 Repeatability Test
    /// <summary>
    /// 重複精度測試速度設定。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_SPEED = "D230";

    /// <summary>
    /// X軸重複精度測試啟動指令。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_X_START_COMMAND = "M13100";
    /// <summary>
    /// X軸重複精度測試停止指令。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_X_STOP_COMMAND = "M13109";
    /// <summary>
    /// X軸重複精度測試執行中信號。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_X_IN_RUNNING = "M13102";
    /// <summary>
    /// X軸重複精度測試已測試次數。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_X_TESTED_COUNTER = "D201";
    /// <summary>
    /// X軸重複精度測試測試次數設定。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_X_TEST_TIMES_SETTING = "D202";
    /// <summary>
    /// X軸重複精度測試座標1。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_X_COORDINATE1 = "D204";
    /// <summary>
    /// X軸重複精度測試座標2。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_X_COORDINATE2 = "D206";

    /// <summary>
    /// Y軸重複精度測試啟動指令。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_Y_START_COMMAND = "M13200";
    /// <summary>
    /// Y軸重複精度測試停止指令。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_Y_STOP_COMMAND = "M13209";
    /// <summary>
    /// Y軸重複精度測試執行中信號。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_Y_IN_RUNNING = "M13202";
    /// <summary>
    /// Y軸重複精度測試已測試次數。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_Y_TESTED_COUNTER = "D215";
    /// <summary>
    /// Y軸重複精度測試測試次數設定。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_Y_TEST_TIMES_SETTING = "D216";
    /// <summary>
    /// Y軸重複精度測試座標1。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_Y_COORDINATE1 = "D217";
    /// <summary>
    /// Y軸重複精度測試座標2。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_Y_COORDINATE2 = "D219";

    /// <summary>
    /// 重複精度測試拍照功能開關。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_VISION_SW = "M13160";
    /// <summary>
    /// 重複精度測試X軸拍照補正結果值。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_VISION_RESULT_X = "D12110";
    /// <summary>
    /// 重複精度測試Y軸拍照補正結果值。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_VISION_RESULT_Y = "D12112";
    /// <summary>
    /// 重複精度測試X軸拍照完成。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_VISION_COMPLETE_X = "M13155";
    /// <summary>
    /// 重複精度測試Y軸拍照完成。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_VISION_COMPLETE_Y = "M13255";
    /// <summary>
    /// 重複精度測試X軸交握回傳信號。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_VISION_HANDSHAKE_X = "M13156";
    /// <summary>
    /// 重複精度測試Y軸交握回傳信號。
    /// </summary>
    public static readonly string REPEATABILITY_TEST_VISION_HANDSHAKE_Y = "M13256";

    /********************
     * IO
     ********************/
    /// <summary>
    /// 光柵作動。
    /// </summary>
    public static readonly string LIGHT_CURTAIN = "M233";

    /// <summary>
    /// 靜電消除器開關。
    /// </summary>
    public static readonly string IONOTRON = "M21";

    /// <summary>
    /// 照明開關指令。
    /// </summary>
    public static readonly string LIGHTS_COMMAND = "M4510";
    /// <summary>
    /// 照明狀態。
    /// </summary>
    public static readonly string LIGHTS = "Y56"; // M4500

    /// <summary>
    /// 三色燈(綠)。
    /// </summary>
    public static readonly string STACK_LIGHT_GREEN = "Y4C";
    /// <summary>
    /// 三色燈(黃)。
    /// </summary>
    public static readonly string STACK_LIGHT_YELLOW = "Y4C"; // PLC規劃是GY兩燈用同一個信號
    /// <summary>
    /// 三色燈(紅)。
    /// </summary>
    public static readonly string STACK_LIGHT_RED = "Y4D";

    /// <summary>
    /// 門開啟。
    /// </summary>
    public static readonly string DOORS = "X0E";

    /********************
     * Action
     ********************/
    /// <summary>
    /// 移動相機至吸嘴位置指令。
    /// </summary>
    public static readonly string MOVE_CAMERA_TO_NOZZLE_COMMAND = "M11000";
    /// <summary>
    /// 移動吸嘴至相機位置指令。
    /// </summary>
    public static readonly string MOVE_NOZZLE_TO_CAMERA_COMMAND = "M11050";

    /********************
     * 虛擬座標移動
     ********************/
    /// <summary>
    /// 移動至虛擬點位置指令。
    /// </summary>
    public static readonly string VISUAL_POINT_COMMAND = "M8880";
    /// <summary>
    /// 虛擬點X座標。
    /// </summary>
    public static readonly string VISUAL_POINT_X = "D20116";
    /// <summary>
    /// 虛擬點Y座標。
    /// </summary>
    public static readonly string VISUAL_POINT_Y = "D20118";
    /// <summary>
    /// 虛擬點Y座標。
    /// </summary>
    public static readonly string VISUAL_POINT_Z = "D20120";

    /// <summary>
    /// 虛擬Tray ID。
    /// </summary>
    public static readonly int VISUAL_TRAY_ID = 25;
    /// <summary>
    /// 移動至虛擬Tray位置指令。
    /// </summary>
    public static readonly string VISUAL_TRAY_COMMAND = "M8900";
    /// <summary>
    /// 虛擬Tray參數(Word)。
    /// </summary>
    /// <remarks>
    /// 依序排列: [00~01]入數XY、[02~06]不使用、[07~09]ABC偏移格數、[10~29]無效點1~20<br/>
    /// 交錯排列: [30~31]入數XY、[32~36]不使用、[37~39]ABC偏移格數、[40~59]無效點1~20
    /// </remarks>
    public static readonly string VISUAL_TRAY_WORD = "D25519";
    /// <summary>
    /// 虛擬Tray參數(DWord)。
    /// </summary>
    /// <remarks>
    /// 依序排列: [00~01]不使用、[02~07]座標AX,AY,BX,BY,CX,CY<br/>
    /// 交錯排列: [08~09]不使用、[10~15]座標AX,AY,BX,BY,CX,CY
    /// </remarks>
    public static readonly string VISUAL_TRAY_DWORD = "D23105";
    /// <summary>
    /// 虛擬Tray是依序排列或交錯排列。
    /// </summary>
    public static readonly string VISUAL_TRAY_ORDER_CROSS = "M125";
    /// <summary>
    /// 虛擬Tray點位編號。
    /// </summary>
    public static readonly string VISUAL_TRAY_POINT = "D6125";

    /********************
     * internal內部用
     ********************/
    // 目前軸座標
    internal static readonly string X_AXIS_POSITION = "D2700";
    internal static readonly string Y_AXIS_POSITION = "D2702";
    internal static readonly string Z_AXIS_POSITION = "D2704";
    internal static readonly string R_AXIS_POSITION = "D2706";

    // Busy
    internal static readonly string X_AXIS_IN_MOTION = "X0A8C";
    internal static readonly string Y_AXIS_IN_MOTION = "X0A8D";
    internal static readonly string Z_AXIS_IN_MOTION = "X0A8E";
    internal static readonly string R_AXIS_IN_MOTION = "X0A8F";

    // 軸極限
    internal static readonly string X_AXIS_RLS = "M6950";
    internal static readonly string X_AXIS_FLS = "M6951";
    internal static readonly string X_AXIS_OPG = "M6952";
    internal static readonly string X_AXIS_DOG = "M6953";

    internal static readonly string Y_AXIS_RLS = "M6955";
    internal static readonly string Y_AXIS_FLS = "M6956";
    internal static readonly string Y_AXIS_OPG = "M6957";
    internal static readonly string Y_AXIS_DOG = "M6958";

    internal static readonly string Z_AXIS_RLS = "M6960";
    internal static readonly string Z_AXIS_FLS = "M6961";
    internal static readonly string Z_AXIS_OPG = "M6962";
    internal static readonly string Z_AXIS_DOG = "M6963";

    internal static readonly string R_AXIS_RLS = "M6965";
    internal static readonly string R_AXIS_FLS = "M6966";
    internal static readonly string R_AXIS_OPG = "M6967";
    internal static readonly string R_AXIS_DOG = "M6968";

    // 全軸Ready
    internal static readonly string ALL_AXIS_READY = "Y0A80";

    /// <summary>
    /// X軸異常。
    /// </summary>
    public const string X_AXIS_ABNORMAL = "X0A88";
    /// <summary>
    /// Y軸異常。
    /// </summary>
    public const string Y_AXIS_ABNORMAL = "X0A89";
    /// <summary>
    /// Z軸異常。
    /// </summary>
    public const string Z1_AXIS_ABNORMAL = "X0A8A";
    /// <summary>
    /// R軸異常。
    /// </summary>
    public const string R_AXIS_ABNORMAL = "X0A4B";

    // 異常碼
    /// <summary>
    /// X軸異常碼。
    /// </summary>
    public const string X_AXIS_ERROR_CODE = "D2735";
    /// <summary>
    /// Y軸異常碼。
    /// </summary>
    public const string Y_AXIS_ERROR_CODE = "D2736";
    /// <summary>
    /// Z軸異常碼。
    /// </summary>
    public const string Z_AXIS_ERROR_CODE = "D2737";
    /// <summary>
    /// R軸異常碼。
    /// </summary>
    public const string R_AXIS_ERROR_CODE = "D2738";

    // 異常碼
    internal static readonly string ERROR_CODE_DEVICE = "L";
    internal static readonly int ERROR_CODE_ADDRESS = 1;
    internal static readonly int ERROR_CODE_TOTAL = 4;
}
