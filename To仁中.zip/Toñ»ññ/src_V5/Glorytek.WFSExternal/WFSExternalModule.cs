﻿using Glorytek.WFSCore.Constants;
using Glorytek.WFSExternal.Displacement;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Services;
using Glorytek.WFSExternal.SerialPort;
using Glorytek.WFSExternal.ViewModels;
using Glorytek.WFSExternal.Views;
using Glorytek.WFSExternal.Vision;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using Glorytek.WPF.PrismSplashScreen;
using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;

namespace Glorytek.WFSExternal
{
    public class WFSExternalModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            IEventAggregator ea = containerProvider.Resolve<IEventAggregator>();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "PLC初始化..." });
            var plc = containerProvider.Resolve<PlcService>();
            plc.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "串列埠初始化..." });
            var serialPort = containerProvider.Resolve<SerialPortService>();
            serialPort.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "DL-EN1初始化..." });
            var displacement = containerProvider.Resolve<DisplacementService>();
            displacement.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "稼動紀錄初始化..." });
            var availability = containerProvider.Resolve<AvailabilityService>();
            availability.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "量測機初始化..." });
            var measuring = containerProvider.Resolve<MeasuringService>();
            measuring.ModuleInit();
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.Register<IDisplacement, DisplacementService>();
            containerRegistry.Register<IMeasuring, MeasuringService>();

            containerRegistry.Register<ISerialPort, SerialPortService>();
            containerRegistry.Register<IPlc, PlcService>();
            containerRegistry.Register<IVision, VisionService>();
            containerRegistry.Register<IAvailability, AvailabilityService>();

            containerRegistry.RegisterForNavigation<ConnectionSetting, ConnectionSettingViewModel>(PageKeys.ConnectionSetting);
            containerRegistry.RegisterForNavigation<AvailabilityReport, AvailabilityReportViewModel>(PageKeys.Availability);
            containerRegistry.RegisterForNavigation<OriginalPointReturn, OriginalPointReturnViewModel>(PageKeys.OPR);

            containerRegistry.RegisterSingleton(typeof(TeachingBox));
        }
    }
}