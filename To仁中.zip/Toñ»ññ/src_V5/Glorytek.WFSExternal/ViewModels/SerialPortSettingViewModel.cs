﻿using Glorytek.WFSExternal.SerialPort;
using Prism.Commands;
using Prism.Mvvm;
using System;

namespace Glorytek.WFSExternal.ViewModels;

/// <summary>
/// 條碼機設定畫面的ViewModel。
/// </summary>
public class SerialPortSettingViewModel : BindableBase
{
    /********************
     * ctor
     ********************/
    private readonly ISerialPort _serialPort;

    public SerialPortSettingViewModel(ISerialPort serialPort)
    {
        _serialPort = serialPort;
    }

    /********************
     * Command Binding
     ********************/
    /// <summary>
    /// 
    /// </summary>
    private DelegateCommand _refreshPortListCommand;
    public DelegateCommand RefreshPortListCommand
        => _refreshPortListCommand ??= new DelegateCommand(ExecuteRefreshPortListCommand);
    private void ExecuteRefreshPortListCommand()
    {
        _ = _serialPort.RefreshPortNameList();
    }

    /// <summary>
    /// 
    /// </summary>
    private DelegateCommand _saveAndReopenPortCommand;
    public DelegateCommand SaveAndReopenPortCommand
        => _saveAndReopenPortCommand ??= new DelegateCommand(ExecuteSaveAndReopenPortCommand);
    private void ExecuteSaveAndReopenPortCommand()
    {
        _serialPort.WriteToDb();
        PortStatus = _serialPort.Reopen() ? "Port Start" : "Port Cloes";
    }

    /// <summary>
    /// 
    /// </summary>
    private DelegateCommand _sendCommand;
    public DelegateCommand SendCommand
        => _sendCommand ??= new DelegateCommand(ExecuteSendCommand);
    void ExecuteSendCommand()
    {
        if (_serialPort.IsOpen)
            _serialPort.SendData(DataTransmitted + Environment.NewLine);
    }

    /// <summary>
    /// 
    /// </summary>
    private DelegateCommand _clearDataReceivedCommand;
    public DelegateCommand ClearDataReceivedCommand
        => _clearDataReceivedCommand ??= new DelegateCommand(ExecuteClearDataReceivedCommand);
    private void ExecuteClearDataReceivedCommand()
    {
        SerialPortParameters.Instance.ReceivedMessages = "";
    }

    ///// <summary>
    ///// 
    ///// </summary>
    ///// <param name="dataString">。</param>
    //private void DataReceived(string dataString)
    //{
    //    List<VisionData> dataPrase = _serialPort.ResultParse(dataString);
    //    string showString = dataString;

    //    for (int index = 0; index < dataPrase.Count; index++)
    //    {
    //        var data = dataPrase[index];
    //        showString += $"[ {index + 1} ]{Environment.NewLine}Result: {data.Result}{Environment.NewLine}X: {data.X}{Environment.NewLine}Y: {data.Y}{Environment.NewLine}Angle: {data.Angle}{Environment.NewLine}";
    //    }

    //    DataOfReceived = showString;
    //}

    /********************
     * Data Binding
     ********************/
    /// <summary>
    /// port status
    /// </summary>
    public string PortStatus
    {
        get { return _PortStatus; }
        set { SetProperty(ref _PortStatus, value); }
    }
    private string _PortStatus;

    public bool CtsHolding
    {
        get { return _CtsHolding; }
        set { SetProperty(ref _CtsHolding, value); }
    }
    private bool _CtsHolding;

    public bool DsrHolding
    {
        get { return _DsrHolding; }
        set { SetProperty(ref _DsrHolding, value); }
    }
    private bool _DsrHolding;

    public bool CDHolding
    {
        get { return _CDHolding; }
        set { SetProperty(ref _CDHolding, value); }
    }
    private bool _CDHolding;

    public string DataTransmitted
    {
        get { return _dataTransmitted; }
        set { SetProperty(ref _dataTransmitted, value); }
    }
    private string _dataTransmitted;
}
