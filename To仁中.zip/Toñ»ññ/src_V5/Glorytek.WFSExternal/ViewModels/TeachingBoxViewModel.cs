﻿using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Prism.Commands;
using Prism.Mvvm;

namespace Glorytek.WFSExternal.ViewModels;

/// <summary>
/// 教導盒的ViewModel。
/// </summary>
public class TeachingBoxViewModel : BindableBase
{
    /********************
     * ctor
     ********************/
    private readonly IPlc _plc;

    public TeachingBoxViewModel(IPlc plc)
    {
        _plc = plc;
    }

    /********************
     * Motion
     ********************/
    /// <summary>
    /// 切換JOG速度。
    /// </summary>
    public DelegateCommand<object> JogSpeedChangeCommand
        => _jogSpeedChangeCommand ??= new DelegateCommand<object>(ExecuteJogSpeedChangeCommand);
    private void ExecuteJogSpeedChangeCommand(object jogSpeed)
    {
        _plc.SetJogSpeed((JogSpeedList)jogSpeed);
    }
    private DelegateCommand<object> _jogSpeedChangeCommand;

    /// <summary>
    /// X軸JOG 前進 啟動。
    /// </summary>
    public DelegateCommand XAxisJogForwardStartCommand
        => _xAxisJogForwardStartCommand ??= new DelegateCommand(ExecuteXAxisJogForwardStartCommand);
    private void ExecuteXAxisJogForwardStartCommand()
    {
        _plc.XAxisJog_Forward_Start();
    }
    private DelegateCommand _xAxisJogForwardStartCommand;

    /// <summary>
    /// X軸JOG 前進 停止。
    /// </summary>
    public DelegateCommand XAxisJogForwardStopCommand
        => _xAxisJogForwardStopCommand ??= new DelegateCommand(ExecuteXAxisJogForwardStopCommand);
    private void ExecuteXAxisJogForwardStopCommand()
    {
        _plc.XAxisJog_Forward_Stop();
    }
    private DelegateCommand _xAxisJogForwardStopCommand;

    /// <summary>
    /// X軸JOG 後退 啟動。
    /// </summary>
    public DelegateCommand XAxisJogReverseStartCommand
        => _xAxisJogReverseStartCommand ??= new DelegateCommand(ExecuteXAxisJogReverseStartCommand);
    private void ExecuteXAxisJogReverseStartCommand()
    {
        _plc.XAxisJog_Reverse_Start();
    }
    private DelegateCommand _xAxisJogReverseStartCommand;

    /// <summary>
    /// X軸JOG 前進 停止。
    /// </summary>
    public DelegateCommand XAxisJogReverseStopCommand
        => _xAxisJogReverseStopCommand ??= new DelegateCommand(ExecuteXAxisJogReverseStopCommand);
    private void ExecuteXAxisJogReverseStopCommand()
    {
        _plc.XAxisJog_Reverse_Stop();
    }
    private DelegateCommand _xAxisJogReverseStopCommand;

    /// <summary>
    /// Y軸JOG 前進 啟動。
    /// </summary>
    public DelegateCommand YAxisJogForwardStartCommand
        => _yAxisJogForwardStartCommand ??= new DelegateCommand(ExecuteYAxisJogForwardStartCommand);
    private void ExecuteYAxisJogForwardStartCommand()
    {
        _plc.YAxisJog_Forward_Start();
    }
    private DelegateCommand _yAxisJogForwardStartCommand;

    /// <summary>
    /// Y軸JOG 前進 停止。
    /// </summary>
    public DelegateCommand YAxisJogForwardStopCommand
        => _yAxisJogForwardStopCommand ??= new DelegateCommand(ExecuteYAxisJogForwardStopCommand);
    private void ExecuteYAxisJogForwardStopCommand()
    {
        _plc.YAxisJog_Forward_Stop();
    }
    private DelegateCommand _yAxisJogForwardStopCommand;

    /// <summary>
    /// Y軸JOG 後退 啟動。
    /// </summary>
    public DelegateCommand YAxisJogReverseStartCommand
        => _yAxisJogReverseStartCommand ??= new DelegateCommand(ExecuteYAxisJogReverseStartCommand);
    private void ExecuteYAxisJogReverseStartCommand()
    {
        _plc.YAxisJog_Reverse_Start();
    }
    private DelegateCommand _yAxisJogReverseStartCommand;

    /// <summary>
    /// Y軸JOG 前進 停止。
    /// </summary>
    public DelegateCommand YAxisJogReverseStopCommand
        => _yAxisJogReverseStopCommand ??= new DelegateCommand(ExecuteYAxisJogReverseStopCommand);
    private void ExecuteYAxisJogReverseStopCommand()
    {
        _plc.YAxisJog_Reverse_Stop();
    }
    private DelegateCommand _yAxisJogReverseStopCommand;

    /// <summary>
    /// Z軸JOG 前進 啟動。
    /// </summary>
    public DelegateCommand ZAxisJogForwardStartCommand
        => _zAxisJogForwardStartCommand ??= new DelegateCommand(ExecuteZAxisJogForwardStartCommand);
    private void ExecuteZAxisJogForwardStartCommand()
    {
        _plc.ZAxisJog_Forward_Start();
    }
    private DelegateCommand _zAxisJogForwardStartCommand;

    /// <summary>
    /// Z軸JOG 前進 停止。
    /// </summary>
    public DelegateCommand ZAxisJogForwardStopCommand
        => _zAxisJogForwardStopCommand ??= new DelegateCommand(ExecuteZAxisJogForwardStopCommand);
    private void ExecuteZAxisJogForwardStopCommand()
    {
        _plc.ZAxisJog_Forward_Stop();
    }
    private DelegateCommand _zAxisJogForwardStopCommand;

    /// <summary>
    /// Z軸JOG 後退 啟動。
    /// </summary>
    public DelegateCommand ZAxisJogReverseStartCommand
        => _zAxisJogReverseStartCommand ??= new DelegateCommand(ExecuteZAxisJogReverseStartCommand);
    private void ExecuteZAxisJogReverseStartCommand()
    {
        _plc.ZAxisJog_Reverse_Start();
    }
    private DelegateCommand _zAxisJogReverseStartCommand;

    /// <summary>
    /// Z軸JOG 前進 停止。
    /// </summary>
    public DelegateCommand ZAxisJogReverseStopCommand
        => _zAxisJogReverseStopCommand ??= new DelegateCommand(ExecuteZAxisJogReverseStopCommand);
    private void ExecuteZAxisJogReverseStopCommand()
    {
        _plc.ZAxisJog_Reverse_Stop();
    }
    private DelegateCommand _zAxisJogReverseStopCommand;

    /// <summary>
    /// 移動Z軸至座標0。
    /// </summary>
    public DelegateCommand MoveToZeroHeightCommand
        => _moveToZeroHeightCommand ??= new DelegateCommand(ExecuteMoveToZeroHeightCommand);
    private void ExecuteMoveToZeroHeightCommand()
    {
        _plc.MoveToTarget(MotionTarget.VisualPoint,
                          _plc.XAxisPosition,
                          _plc.YAxisPosition,
                          0.0);
    }
    private DelegateCommand _moveToZeroHeightCommand;

    /// <summary>
    /// R軸JOG 前進 啟動。
    /// </summary>
    public DelegateCommand RAxisJogForwardStartCommand
        => _rAxisJogForwardStartCommand ??= new DelegateCommand(ExecuteRAxisJogForwardStartCommand);
    private void ExecuteRAxisJogForwardStartCommand()
    {
        _plc.RAxisJog_Forward_Start();
    }
    private DelegateCommand _rAxisJogForwardStartCommand;

    /// <summary>
    /// R軸JOG 前進 停止。
    /// </summary>
    public DelegateCommand RAxisJogForwardStopCommand
        => _rAxisJogForwardStopCommand ??= new DelegateCommand(ExecuteRAxisJogForwardStopCommand);
    private void ExecuteRAxisJogForwardStopCommand()
    {
        _plc.RAxisJog_Forward_Stop();
    }
    private DelegateCommand _rAxisJogForwardStopCommand;

    /// <summary>
    /// R軸JOG 後退 啟動。
    /// </summary>
    public DelegateCommand RAxisJogReverseStartCommand
        => _rAxisJogReverseStartCommand ??= new DelegateCommand(ExecuteRAxisJogReverseStartCommand);
    private void ExecuteRAxisJogReverseStartCommand()
    {
        _plc.RAxisJog_Reverse_Start();
    }
    private DelegateCommand _rAxisJogReverseStartCommand;

    /// <summary>
    /// R軸JOG 前進 停止。
    /// </summary>
    public DelegateCommand RAxisJogReverseStopCommand
        => _rAxisJogReverseStopCommand ??= new DelegateCommand(ExecuteRAxisJogReverseStopCommand);
    private void ExecuteRAxisJogReverseStopCommand()
    {
        _plc.RAxisJog_Reverse_Stop();
    }
    private DelegateCommand _rAxisJogReverseStopCommand;

    /********************
     * 混合方向
     ********************/
    /// <summary>
    /// JOG X軸 前進 Y軸 前進 啟動。
    /// </summary>
    public DelegateCommand AxisJogXForwardYForwardStartCommand
        => _axisJogXForwardYForwardStartCommand ??= new DelegateCommand(ExecuteAxisJogXForwardYForwardStartCommand);
    private void ExecuteAxisJogXForwardYForwardStartCommand()
    {
        _plc.XAxisJog_Forward_Start();
        _plc.YAxisJog_Forward_Start();
    }
    private DelegateCommand _axisJogXForwardYForwardStartCommand;

    /// <summary>
    /// JOG X軸 前進 Y軸 前進 停止。
    /// </summary>
    public DelegateCommand AxisJogXForwardYForwardStopCommand
        => _axisJogXForwardYForwardStopCommand ??= new DelegateCommand(ExecuteAxisJogXForwardYForwardStopCommand);
    private void ExecuteAxisJogXForwardYForwardStopCommand()
    {
        _plc.XAxisJog_Forward_Stop();
        _plc.YAxisJog_Forward_Stop();
    }
    private DelegateCommand _axisJogXForwardYForwardStopCommand;

    /// <summary>
    /// JOG X軸 前進 Y軸 後退 啟動。
    /// </summary>
    public DelegateCommand AxisJogXForwardYReverseStartCommand
        => _axisJogXForwardYReverseStartCommand ??= new DelegateCommand(ExecuteAxisJogXForwardYReverseStartCommand);
    private void ExecuteAxisJogXForwardYReverseStartCommand()
    {
        _plc.XAxisJog_Forward_Start();
        _plc.YAxisJog_Reverse_Start();
    }
    private DelegateCommand _axisJogXForwardYReverseStartCommand;

    /// <summary>
    /// JOG X軸 前進 Y軸 後退 停止。
    /// </summary>
    public DelegateCommand AxisJogXForwardYReverseStopCommand
        => _axisJogXForwardYReverseStopCommand ??= new DelegateCommand(ExecuteAxisJogXForwardYReverseStopCommand);
    private void ExecuteAxisJogXForwardYReverseStopCommand()
    {
        _plc.XAxisJog_Forward_Stop();
        _plc.YAxisJog_Reverse_Stop();
    }
    private DelegateCommand _axisJogXForwardYReverseStopCommand;

    /// <summary>
    /// JOG X軸 後退 Y軸 前進 啟動。
    /// </summary>
    public DelegateCommand AxisJogXReverseYForwardStartCommand
        => _axisJogXReverseYForwardStartCommand ??= new DelegateCommand(ExecuteAxisJogXReverseYForwardStartCommand);
    private void ExecuteAxisJogXReverseYForwardStartCommand()
    {
        _plc.XAxisJog_Reverse_Start();
        _plc.YAxisJog_Forward_Start();
    }
    private DelegateCommand _axisJogXReverseYForwardStartCommand;

    /// <summary>
    /// JOG X軸 後退 Y軸 前進 停止。
    /// </summary>
    public DelegateCommand AxisJogXReverseYForwardStopCommand
        => _axisJogXReverseYForwardStopCommand ??= new DelegateCommand(ExecuteAxisJogXReverseYForwardStopCommand);
    private void ExecuteAxisJogXReverseYForwardStopCommand()
    {
        _plc.XAxisJog_Reverse_Stop();
        _plc.YAxisJog_Forward_Stop();
    }
    private DelegateCommand _axisJogXReverseYForwardStopCommand;

    /// <summary>
    /// JOG X軸 後退 Y軸 後退 啟動。
    /// </summary>
    public DelegateCommand AxisJogXReverseYReverseStartCommand
        => _axisJogXReverseYReverseStartCommand ??= new DelegateCommand(ExecuteAxisJogXReverseYReverseStartCommand);
    private void ExecuteAxisJogXReverseYReverseStartCommand()
    {
        _plc.XAxisJog_Reverse_Start();
        _plc.YAxisJog_Reverse_Start();
    }
    private DelegateCommand _axisJogXReverseYReverseStartCommand;

    /// <summary>
    /// JOG X軸 後退 Y軸 後退 停止。
    /// </summary>
    public DelegateCommand AxisJogXReverseYReverseStopCommand
        => _axisJogXReverseYReverseStopCommand ??= new DelegateCommand(ExecuteAxisJogXReverseYReverseStopCommand);
    private void ExecuteAxisJogXReverseYReverseStopCommand()
    {
        _plc.XAxisJog_Reverse_Stop();
        _plc.YAxisJog_Reverse_Stop();
    }
    private DelegateCommand _axisJogXReverseYReverseStopCommand;

    /// <summary>
    /// 擴充選單開關。
    /// </summary>
    private bool _expandMenu;
    public bool ExpandMenu
    {
        get { return _expandMenu; }
        set { SetProperty(ref _expandMenu, value); }
    }

    /********************
     * 吸嘴真空
     ********************/
    /// <summary>
    /// 吸嘴真空開關。
    /// </summary>
    public DelegateCommand NozzleVaccumToggleCommand
        => _nozzleVaccumToggleCommand ??= new DelegateCommand(ExecuteNozzleVaccumToggleCommand);
    private void ExecuteNozzleVaccumToggleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.NOZZLE_VACCUM_COMMAND);
    }
    private DelegateCommand _nozzleVaccumToggleCommand;

    /// <summary>
    /// 吸嘴破真空開關。
    /// </summary>
    public DelegateCommand NozzleReliefToggleCommand
        => _nozzleReliefToggleCommand ??= new DelegateCommand(ExecuteNozzleReliefToggleCommand);
    private void ExecuteNozzleReliefToggleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.NOZZLE_RELIEF_COMMAND);
    }
    private DelegateCommand _nozzleReliefToggleCommand;

    /********************
     * 相機_吸嘴 互動
     ********************/
    /// <summary>
    /// 移動吸嘴至相機。
    /// </summary>
    public DelegateCommand MoveNozzleToCameraCommand
        => _moveNozzleToCameraCommand ??= new DelegateCommand(ExecuteMoveNozzleToCameraCommand);
    private void ExecuteMoveNozzleToCameraCommand()
    {
        _plc.SendCommandPulse(DeviceLists.MOVE_NOZZLE_TO_CAMERA_COMMAND);
    }
    private DelegateCommand _moveNozzleToCameraCommand;

    /// <summary>
    /// 移動相機至吸嘴。
    /// </summary>
    public DelegateCommand MoveCameraToNozzleCommand
        => _moveCameraToNozzleCommand ??= new DelegateCommand(ExecuteMoveCameraToNozzleCommand);
    private void ExecuteMoveCameraToNozzleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.MOVE_CAMERA_TO_NOZZLE_COMMAND);
    }
    private DelegateCommand _moveCameraToNozzleCommand;
}
