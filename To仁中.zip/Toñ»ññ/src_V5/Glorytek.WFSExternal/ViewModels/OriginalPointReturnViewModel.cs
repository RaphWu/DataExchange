﻿using Glorytek.WFSExternal.PLC.Contracts;
using Prism.Commands;
using Prism.Mvvm;

namespace Glorytek.WFSExternal.ViewModels
{
    public class OriginalPointReturnViewModel : BindableBase
    {
        /********************
         * ctor
         ********************/
        private readonly IPlc _plc;

        public OriginalPointReturnViewModel(IPlc plc)
        {
            _plc = plc;
        }

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand HomeReturnAllCommand
            => _homeReturnAllCommand ??= new DelegateCommand(ExecuteHomeReturnAllCommand);
        private void ExecuteHomeReturnAllCommand()
        {
            _plc.StopCTStopwatch();
            _plc.HomeReturn();
        }
        private DelegateCommand _homeReturnAllCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand HomeReturnXCommand
            => _homeReturnXCommand ??= new DelegateCommand(ExecuteHomeReturnXCommand);
        private void ExecuteHomeReturnXCommand()
        {
            _plc.StopCTStopwatch();
            _plc.HomeReturnXAxis();
        }
        private DelegateCommand _homeReturnXCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand HomeReturnYCommand
            => _homeReturnYCommand ??= new DelegateCommand(ExecuteHomeReturnYCommand);
        private void ExecuteHomeReturnYCommand()
        {
            _plc.StopCTStopwatch();
            _plc.HomeReturnYAxis();
        }
        private DelegateCommand _homeReturnYCommand;
    }
}
