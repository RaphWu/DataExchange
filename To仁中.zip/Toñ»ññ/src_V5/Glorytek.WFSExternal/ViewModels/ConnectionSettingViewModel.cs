﻿using Glorytek.WFSCore.Contracts;
using Glorytek.WFSExternal.Displacement;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using Glorytek.WPF.Extensions;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;

namespace Glorytek.WFSExternal.ViewModels;

/// <summary>
/// 連接設定畫面的ViewModel。
/// </summary>
public class ConnectionSettingViewModel : BindableBase, INavigationAware
{
    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
        WriteData();
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IPlc _plc;
    private readonly IDisplacement _displacement;
    private readonly IMeasuring _measuring;

    public ConnectionSettingViewModel(ISystemMessenger sysMessenger,
                                      IPlc plc,
                                      IDisplacement displacement,
                                      IMeasuring measuring)
    {
        _sysMessenger = sysMessenger;
        _plc = plc;
        _displacement = displacement;
        _measuring = measuring;
    }

    /// <summary>
    /// 視窗載入。
    /// </summary>
    public DelegateCommand LoadedCommand
        => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
    private void ExecuteLoadedCommand()
    {
        _sysMessenger.StatusBarMessage(string.Join(" - ", new[] {
                GetResource.GetValue<string>("Glorytek.WFSComponents", "PageTitle_SettingsPage"),
                GetResource.GetValue<string>("Glorytek.WFSComponents", "TabItem_SystemSetting_Connection")
            }));
    }
    private DelegateCommand _loadedCommand;

    /********************
     * Database
     ********************/
    /// <summary>
    /// 將資料或參數寫入資料庫
    /// </summary>
    public void WriteData()
    {
        //PlcParameters.Instance.CpuTypeId = CpuTypeId;
        //PlcParameters.Instance.ModuleTypeId = ModuleTypeId;
        //PlcParameters.Instance.ProtocolTypeId = ProtocolTypeId;
        //PlcParameters.Instance.HostAddress = HostAddress;
        //PlcParameters.Instance.TimeOut = TimeOut;
        //PlcParameters.Instance.Password = Password;

        _plc.WriteToDb();
        _displacement.WriteToDb();
    }

    /// <summary>
    /// 從資料庫讀取資料至Model
    /// </summary>
    public bool ReadFromDb()
    {
        return _plc.ReadFromDb();
    }

    /********************
     * PLC
     ********************/
    /// <summary>
    /// PLC手動連線
    /// </summary>
    public DelegateCommand PlcConnectCommand
        => _plcConnectCommand ??= new DelegateCommand(ExecutePlcConnectCommand);
    private void ExecutePlcConnectCommand()
    {
        _sysMessenger.ShowProgressRing(true);
        _plc.Connect();
        _sysMessenger.ShowProgressRing(false);
    }
    private DelegateCommand _plcConnectCommand;

    /// <summary>
    /// PLC手動離線
    /// </summary>
    public DelegateCommand PlcDisconnectCommand
        => _plcDisconnectCommand ??= new DelegateCommand(ExecutePlcDisconnectCommand);
    private void ExecutePlcDisconnectCommand()
    {
        _sysMessenger.ShowProgressRing(true);
        _plc.Disconnect();
        _sysMessenger.ShowProgressRing(false);
    }
    private DelegateCommand _plcDisconnectCommand;

    /********************
     * 量測機
     ********************/
    /// <summary>
    /// 量測機手動連線
    /// </summary>
    public DelegateCommand MeasuringConnectCommand
        => _MeasuringConnectCommand ??= new DelegateCommand(ExecuteMeasuringConnectCommand);
    private void ExecuteMeasuringConnectCommand()
    {
        _sysMessenger.ShowProgressRing(true);
        _measuring.Start();
        _sysMessenger.ShowProgressRing(false);
    }
    private DelegateCommand _MeasuringConnectCommand;

    /// <summary>
    /// 量測機手動離線
    /// </summary>
    public DelegateCommand MeasuringDisconnectCommand
        => _MeasuringDisconnectCommand ??= new DelegateCommand(ExecuteMeasuringDisconnectCommand);
    private void ExecuteMeasuringDisconnectCommand()
    {
        _sysMessenger.ShowProgressRing(true);
        _measuring.Stop();
        _sysMessenger.ShowProgressRing(false);
    }
    private DelegateCommand _MeasuringDisconnectCommand;

    /********************
     * 位移計
     ********************/
    /// <summary>
    /// 位移計手動連線
    /// </summary>
    public DelegateCommand DisplacementConnectCommand
        => _displacementConnectCommand ??= new DelegateCommand(ExecuteDisplacementConnectCommand);
    private void ExecuteDisplacementConnectCommand()
    {
        _sysMessenger.ShowProgressRing(true);
        _displacement.Open();
        _sysMessenger.ShowProgressRing(false);
    }
    private DelegateCommand _displacementConnectCommand;

    /// <summary>
    /// 位移計手動離線
    /// </summary>

    public DelegateCommand DisplacementDisconnectCommand
        => _displacementDisconnectCommand ??= new DelegateCommand(ExecuteDisplacementDisconnectCommand);
    private void ExecuteDisplacementDisconnectCommand()
    {
        _sysMessenger.ShowProgressRing(true);
        _displacement.Close();
        _sysMessenger.ShowProgressRing(false);
    }
    private DelegateCommand _displacementDisconnectCommand;
}
