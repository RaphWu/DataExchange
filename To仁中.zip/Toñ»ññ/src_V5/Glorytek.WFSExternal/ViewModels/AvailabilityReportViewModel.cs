﻿using Glorytek.WFSCore.Contracts;
using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WPF.Extensions;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;

namespace Glorytek.WFSExternal.ViewModels;

public class AvailabilityReportViewModel : BindableBase, INavigationAware
{
    private readonly AvailabilityDatas _ad = AvailabilityDatas.Instance;

#if DEBUG
    private readonly Random _random = new Random(DateTime.Now.Second);

    private static int cnt1 = 0;
    private static int cnt2 = 0;
    private static bool[] alarmCode = new bool[4];
#endif

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_Availability"));
        _ad.AvailabilityCollectionView.Refresh();
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IAvailability _availability;

    public AvailabilityReportViewModel(ISystemMessenger sysMessenger, IAvailability availability)
    {
        _sysMessenger = sysMessenger;
        _availability = availability;
    }

    /********************
     * Debug Mode
     ********************/
#if DEBUG
    public DelegateCommand Test1Command
        => _test1Command ??= new DelegateCommand(ExecuteTest1Command);
    private void ExecuteTest1Command()
    {
        cnt1 ^= 0x01;
        _availability.AddNewRecord(cnt1 == 1 ? AvailabilityType.StartOperate : AvailabilityType.StopOperate, -1);
    }
    private DelegateCommand _test1Command;

    public DelegateCommand Test2Command
        => _test2Command ??= new DelegateCommand(ExecuteTest2Command);
    private void ExecuteTest2Command()
    {
        cnt2 ^= 0x01;
        _availability.AddNewRecord(cnt2 == 1 ? AvailabilityType.PauseStart : AvailabilityType.PauseCancel, -1);
    }
    private DelegateCommand _test2Command;

    public DelegateCommand Test3Command
        => _test3Command ??= new DelegateCommand(ExecuteTest3Command);
    private void ExecuteTest3Command()
    {
        for (int noAlarm = 0; noAlarm < 4; noAlarm++)
            if (alarmCode[noAlarm] == false)
            {
                alarmCode[noAlarm] = true;
                _availability.AddNewRecord(AvailabilityType.AlarmTriggering, noAlarm + 1);
                break;
            }
    }
    private DelegateCommand _test3Command;

    public DelegateCommand Test4Command
        => _test4Command ??= new DelegateCommand(ExecuteTest4Command);
    private void ExecuteTest4Command()
    {
        for (int noAlarm = 3; noAlarm >= 0; noAlarm--)
            if (alarmCode[noAlarm] == true)
            {
                alarmCode[noAlarm] = false;
                _availability.AddNewRecord(AvailabilityType.AlarmClear, noAlarm + 1);
                break;
            }
    }
    private DelegateCommand _test4Command;
#endif
}
