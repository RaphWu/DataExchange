﻿using System.Windows.Controls;

namespace Glorytek.WFSExternal.Views
{
    /// <summary>
    /// Interaction logic for SerialPortSetting
    /// </summary>
    public partial class SerialPortSetting : UserControl
    {
        public SerialPortSetting()
        {
            InitializeComponent();
        }
    }
}
