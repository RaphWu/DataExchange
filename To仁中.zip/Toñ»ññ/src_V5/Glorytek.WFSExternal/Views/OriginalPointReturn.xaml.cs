﻿using System.Windows.Controls;

namespace Glorytek.WFSExternal.Views
{
    /// <summary>
    /// Interaction logic for OriginalPointReturn
    /// </summary>
    public partial class OriginalPointReturn : UserControl
    {
        public OriginalPointReturn()
        {
            InitializeComponent();
        }
    }
}
