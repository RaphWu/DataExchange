﻿using System.Windows.Controls;

namespace Glorytek.WFSExternal.Views
{
    /// <summary>
    /// Interaction logic for Availability
    /// </summary>
    public partial class AvailabilityReport : UserControl
    {
        public AvailabilityReport()
        {
            InitializeComponent();
        }
    }
}
