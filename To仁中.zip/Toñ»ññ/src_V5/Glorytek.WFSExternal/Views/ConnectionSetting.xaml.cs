﻿using System.Windows.Controls;

namespace Glorytek.WFSExternal.Views
{
    /// <summary>
    /// Interaction logic for ConnectionSetting
    /// </summary>
    public partial class ConnectionSetting : UserControl
    {
        public ConnectionSetting()
        {
            InitializeComponent();
        }
    }
}
