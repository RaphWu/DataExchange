﻿using Glorytek.CSharp.IO;
using Glorytek.WFSCore.Constants;
using MahApps.Metro.Controls;
using System.ComponentModel;
using System.Windows;

namespace Glorytek.WFSExternal.Views;

/// <summary>
/// TeachingBox.xaml 的互動邏輯。
/// </summary>
public partial class TeachingBox : MetroWindow
{
    private const string _TEACHING_BOX_FILE_NAME = "TeachingBox.json";
    private const double _DEFAULT_POSITION = 10.0;

    public TeachingBox()
    {
        InitializeComponent();
    }

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        var windowCoordinate = JsonFileHelper.Read<LastWindowsStatus>(DBbase.Directory_Base, _TEACHING_BOX_FILE_NAME);
        if (windowCoordinate != null)
        {
            SetCurrentValue(LeftProperty, windowCoordinate.Left > 0 ? windowCoordinate.Left : _DEFAULT_POSITION);
            SetCurrentValue(TopProperty, windowCoordinate.Top > 0 ? windowCoordinate.Top : _DEFAULT_POSITION);
        }
    }

    private void OnClosing(object sender, CancelEventArgs e)
    {
        if (this != null)
        {
            Hide();
            if (Owner.IsLoaded)
            {
                Owner.Activate();
                e.Cancel = true;
            }
        }
    }

    private void OnVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (this != null && Visibility != Visibility.Visible && ActualWidth != 0)
        {
            double screeWidth = SystemParameters.FullPrimaryScreenWidth;
            double screeHeight = SystemParameters.FullPrimaryScreenHeight;

            double maxLeft = screeWidth - ActualWidth;
            double maxTop = screeHeight - ActualHeight;

            double winLeft = Left >= 0 && Left <= maxLeft ? Left : _DEFAULT_POSITION;
            double winTop = Top >= 0 && Top <= maxTop ? Top : _DEFAULT_POSITION;

            JsonFileHelper.Save(DBbase.Directory_Base, _TEACHING_BOX_FILE_NAME, new LastWindowsStatus()
            {
                Left = winLeft,
                Top = winTop,
            });
        }
    }
}

internal class LastWindowsStatus
{
    public double Left { get; set; }
    public double Top { get; set; }
}
