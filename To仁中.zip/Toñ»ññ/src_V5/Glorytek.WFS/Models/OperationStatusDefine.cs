﻿using Glorytek.WFSCore.Constants.Tray;
using Prism.Mvvm;

namespace Glorytek.WFS.Models;

/// <summary>
/// 作業狀態的資訊。
/// </summary>
public class OperationStatusDefine : BindableBase
{
    /// <summary>
    /// Tray功能分類名稱。
    /// </summary>
    public TrayFunctionType FunctionName
    {
        get { return _functionName; }
        set { SetProperty(ref _functionName, value); }
    }
    private TrayFunctionType _functionName;

    /// <summary>
    /// Pallet位置編號。
    /// </summary>
    public int Id
    {
        get { return _id; }
        set { SetProperty(ref _id, value); }
    }
    private int _id;

    /// <summary>
    /// 此Pallet是否有安裝Tray。
    /// </summary>
    public bool InstallTray { get; set; }

    /// <summary>
    /// Tray名稱 &amp; 註解。
    /// </summary>
    public string TrayName
    {
        get { return _trayName; }
        set { SetProperty(ref _trayName, value); }
    }
    private string _trayName;

    /// <summary>
    /// 規格名稱。
    /// </summary>
    public string GradeName
    {
        get { return _gradeName; }
        set { SetProperty(ref _gradeName, value); }
    }
    private string _gradeName;

    /// <summary>
    /// 條碼。
    /// </summary>
    public string Barcode
    {
        get { return _barcode; }
        set { SetProperty(ref _barcode, value); }
    }
    private string _barcode;

    /// <summary>
    /// 總點位數(不考慮Mask)。
    /// </summary>
    public short TotalPoints
    {
        get { return _totalPoints; }
        set { SetProperty(ref _totalPoints, value); }
    }
    private short _totalPoints;

    /// <summary>
    /// 總有效點位數。
    /// </summary>
    public short TotalSequences
    {
        get { return _totalSequences; }
        set { SetProperty(ref _totalSequences, value); }
    }
    private short _totalSequences;

    /// <summary>
    /// 目前取料點位序號。
    /// </summary>
    public int PickSequenceNo
    {
        get { return _pickSequenceNo; }
        set { SetProperty(ref _pickSequenceNo, value); }
    }
    private int _pickSequenceNo;

    /// <summary>
    /// 取料高度。
    /// </summary>
    public double PickHeight { get; set; }

    /// <summary>
    /// 取料高度Offset。
    /// </summary>
    public double PickHeightOffset { get; set; }

    /********************
     * 加減速 高度
     ********************/
    /// <summary>
    /// 取料 下降減速 Z。
    /// </summary>
    public int ZAxis_Pick_Height { get; set; }

    /// <summary>
    /// 取料 上昇加速 Z。
    /// </summary>
    public int ZAxis_Place_Height { get; set; }

    /********************
     * 加減速 速率
     ********************/
    /// <summary>
    /// 取料 下降減速。
    /// </summary>
    public short ZAxis_Pick_SpeedRate { get; set; }

    /// <summary>
    /// 取料 上昇加速。
    /// </summary>
    public short ZAxis_Place_SpeedRate { get; set; }

    /********************
     * 加減速 時間
     ********************/
    /// <summary>
    /// 取料前吸著延時。
    /// </summary>
    public float ZAxis_PickDelay_BeforeVacuum { get; set; }

    /// <summary>
    /// 取料後上升延時。
    /// </summary>
    public float ZAxis_UpDelay_AfterPick { get; set; }

    /// <summary>
    /// 破真空時間。
    /// </summary>
    public float ZAxis_Place_VacuumRelief { get; set; }

    /// <summary>
    /// 放置後上升延時。
    /// </summary>
    public float ZAxis_UpDelay_AfterPlace { get; set; }

    ///// <summary>
    ///// 
    ///// </summary>
    //public string Tooltip
    //{
    //    get { return _tooltip; }
    //    set
    //    {
    //        _tooltip = value;
    //        OnPropertyChanged();
    //    }
    //}
    //private string _tooltip;
}
