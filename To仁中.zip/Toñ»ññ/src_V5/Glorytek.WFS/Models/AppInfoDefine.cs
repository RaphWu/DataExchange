﻿namespace Glorytek.WFS.Models;

/// <summary>
/// 應用程式資訊內容定義。
/// </summary>
public class AppInfoDefine
{
    /// <summary>
    /// 資訊名稱。
    /// </summary>
    public string InfoName { get; set; }

    /// <summary>
    /// 資訊描述。
    /// </summary>
    public string InfoDescription { get; set; }
}
