﻿using Glorytek.CSharp.OS;
using Glorytek.WFS.ViewModels;
using Glorytek.WFS.Views;
using Glorytek.WFSCore.Constants;
using Glorytek.WPF.PrismSplashScreen;
using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Unity;
using Serilog;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Glorytek.WFS;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : PrismApplication
{
    protected override Window CreateShell()
    {
        return Container.Resolve<Views.MainWindow>();
    }

    protected override async void OnInitialized()
    {
        IEventAggregator ea = Container.Resolve<IEventAggregator>();
        ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "系統載入完成！" });
        Task.Delay(800).Wait();

        base.OnInitialized();
        MainWindow.Activate(); // PrismSplashWindow關閉後讓主視窗取得焦點
        await Task.CompletedTask;
    }

    protected override void OnStartup(StartupEventArgs e)
    {
        // 擴充功能：註冊TextBox左鍵滑鼠事件，當點選時自動選取所有文字
        // https://dotblogs.com.tw/ouch1978/2011/04/15/sl-wpf-textbox-select-all-on-focus
        // https://stackoverflow.com/questions/660554/how-to-automatically-select-all-text-on-focus-in-wpf-textbox
        EventManager.RegisterClassHandler(typeof(TextBox), UIElement.PreviewMouseLeftButtonDownEvent,
           new MouseButtonEventHandler(TextBox_PreviewMouseLeftButtonDown), true);
        EventManager.RegisterClassHandler(typeof(TextBox), UIElement.GotKeyboardFocusEvent,
          new RoutedEventHandler(TextBox_SelectAllText), true);

        base.OnStartup(e);
    }

    protected override void RegisterTypes(IContainerRegistry containerRegistry)
    {
        // App Services
        containerRegistry.RegisterSingleton<WFSCore.Contracts.IApplicationCommands, WFSCore.Services.ApplicationCommands>();

        // Views
        containerRegistry.RegisterForNavigation<Main, MainViewModel>(PageKeys.Main);
        containerRegistry.RegisterForNavigation<StatusBar, StatusBarViewModel>(PageKeys.StatusBar);

        // 主畫面的SubPage Views
        containerRegistry.RegisterForNavigation<OperationStatus, OperationStatusViewModel>(PageKeys.OperationStatus);
        containerRegistry.RegisterForNavigation<PalletParameters, PalletParametersViewModel>(PageKeys.PalletParameters);
        containerRegistry.RegisterForNavigation<StageParameters, StageParametersViewModel>(PageKeys.StageParameters);
        containerRegistry.RegisterForNavigation<ServoMonitor, ServoMonitorViewModel>(PageKeys.ServoMonitor);
        containerRegistry.RegisterForNavigation<IoMonitor, IoMonitorViewModel>(PageKeys.IoMonitor);
        containerRegistry.RegisterForNavigation<MainConsole, MainConsoleViewModel>(PageKeys.MainConsole);

        containerRegistry.RegisterForNavigation<Report, ReportViewModel>(PageKeys.Report);
        containerRegistry.RegisterForNavigation<AbnormalHistoryReport, AbnormalHistoryReportViewModel>(PageKeys.AbnormalHistory);
        containerRegistry.RegisterForNavigation<SystemLogReport, SystemLogReportViewModel>(PageKeys.SystemLog);
        containerRegistry.RegisterForNavigation<ExceptionLogReport, ExceptionLogReportViewModel>(PageKeys.ExceptionLog);

        // Dialog
        containerRegistry.RegisterDialog<Views.ApplicationInfo, ApplicationInfoViewModel>();
        containerRegistry.RegisterDialog<OPR, OPRViewModel>();
    }

    protected override void ConfigureModuleCatalog(IModuleCatalog moduleCatalog)
    {
        moduleCatalog.AddModule<Glorytek.WPF.WPFModule>();
        moduleCatalog.AddModule<WFSExternal.WFSExternalModule>();
        moduleCatalog.AddModule<WFSCore.WFSCoreModule>();
        moduleCatalog.AddModule<WFSComponents.WFSComponentsModule>();
    }

    //protected override void ConfigureViewModelLocator()
    //{
    //    base.ConfigureViewModelLocator();

    //    ViewModelLocationProvider.Register(typeof(BigDataBrowser).ToString(), typeof(BigDataBrowserViewModel));
    //}

    protected override void InitializeModules()
    {
        // PrismSplashWindow
        //IModuleManager moduleManager = Container.Resolve<IModuleManager>();
        //moduleManager.LoadModuleCompleted += ModuleManager_LoadModuleCompleted;

        IModule splashModule = Container.Resolve<PrismSplashWindowModule>();
        splashModule.OnInitialized(Container);

        IEventAggregator ea = Container.Resolve<IEventAggregator>();
        ea.GetEvent<SplashScreenInit>().Publish(new SplashScreenInit
        {
            MainTitle = "WFS分檢機",
            Subtitle = "WFS Sorting System",
        });

        base.InitializeModules();
    }

    //private void ModuleManager_LoadModuleCompleted(object sender, LoadModuleCompletedEventArgs e)
    //{
    //    // PrismSplashWindow
    //    IEventAggregator ea = Container.Resolve<IEventAggregator>();
    //    ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = $"{e.ModuleInfo.ModuleName} 初始化完成！" });
    //}

    /// <summary>
    /// 應用程式關閉事件。
    /// </summary>
    /// <remarks>參見: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.windows.application.exit">Application.Exit 事件</see>。</remarks>
    private void OnExit(object sender, ExitEventArgs e)
    {
        SystemSleep.RestoreForCurrentThread(); // 復原系統睡眠、螢幕關閉
        Log.CloseAndFlush();
    }

    /********************
     * APP擴充功能
     ********************/
    /// <summary>
    /// 當點選TextBox時，切換焦點至實際的TextBox物件
    /// </summary>
    /// <see href="https://dotblogs.com.tw/ouch1978/2011/04/15/sl-wpf-textbox-select-all-on-focus"/>
    private static void TextBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        var textbox = (sender as TextBox);
        if (textbox != null && textbox.IsKeyboardFocusWithin != true)
        {
            if (e.OriginalSource.GetType().Name == "TextBoxView")
            {
                e.Handled = true;
                textbox.Focus();
            }
        }
    }

    /// <summary>
    /// 點選TextBox時，自動選取所有文字
    /// </summary>
    /// <remarks>事件註冊部分在<see cref="OnStartup"/>。</remarks>
    /// <see href="https://dotblogs.com.tw/ouch1978/2011/04/15/sl-wpf-textbox-select-all-on-focus"/>
    private static void TextBox_SelectAllText(object sender, RoutedEventArgs e)
    {
        if (e.OriginalSource is TextBox textBox)
            textBox.SelectAll();
    }
}
