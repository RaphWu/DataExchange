﻿using Glorytek.WFS.Views;
using Glorytek.WFSCore.Authority;
using Glorytek.WFSCore.Views;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// StatusBar的ViewModel。
/// </summary>
public class StatusBarViewModel : BindableBase
{
    /********************
     * ctor
     ********************/
    private readonly IDialogService _dialog;
    private readonly IAuthority _authority;

    public StatusBarViewModel(IDialogService dialog, IAuthority authority)
    {
        _dialog = dialog;
        _authority = authority;
    }

    /********************
     * Login
     ********************/
    /// <summary>
    /// 開啟登入畫面。
    /// </summary>
    public DelegateCommand PopupLoginScreenCommand
        => _PopupLoginScreenCommand ??= new DelegateCommand(ExecutePopupLoginScreenCommand);
    private void ExecutePopupLoginScreenCommand()
    {
        IDialogResult result = default;
        _dialog.ShowDialog(nameof(LoginScreen), r => { result = r; });

        // Dialog回傳
        //if (result.Parameters.Count > 0)
        //{
        var loginData = JsonConvert.DeserializeObject<LoginDataDefine>(result.Parameters.GetValue<string>("Authority"));

        // 若不是按取消鍵，執行切換權限
        if (!string.IsNullOrWhiteSpace(loginData.UserName))
            _authority.SwitchAuthority(loginData.UserName, loginData.Password);
        else if (loginData.UserId != null)
            _authority.SwitchAuthority((int)loginData.UserId, loginData.Password);
        //}
        //else
        //{
        //    // 登入為作業員
        //    _authority.SwitchAuthority(GetResource.GetValue<string>("Glorytek.WFSCore", "UserTitle_Operator"), _authority.EmptyPassword);
        //}
    }
    private DelegateCommand _PopupLoginScreenCommand;

    /********************
     * Application Information
     ********************/
    /// <summary>
    /// 顯示應用程式資訊的對話框。
    /// </summary>
    public DelegateCommand PopupApplicationInfoCommand
        => _popupApplicationInfoCommand ??= new DelegateCommand(ExecutePopupApplicationInfoCommand);
    private void ExecutePopupApplicationInfoCommand()
    {
        _dialog.ShowDialog(nameof(ApplicationInfo));
    }
    private DelegateCommand _popupApplicationInfoCommand;
}
