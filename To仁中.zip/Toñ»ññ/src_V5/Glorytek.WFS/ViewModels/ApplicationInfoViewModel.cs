﻿using Glorytek.WFS.Models;
using Glorytek.WFSCore.Models.System;
using Glorytek.WPF.Extensions;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// 應用程式資訊的ViewModel。
/// </summary>
public class ApplicationInfoViewModel : BindableBase, IDialogAware
{
    /********************
     * ctor
     ********************/
    public ApplicationInfoViewModel()
    {
    }

    /********************
     * IDialogAware
     ********************/
    public string Title => GetResource.GetValue<string>("ApplicationName");
    public bool ShowTitle => false;
    public event Action<IDialogResult> RequestClose;
    public bool CanCloseDialog() => true;
    public void OnDialogClosed() { }

    public DelegateCommand<object> CloseDialogCommand
        => _closeDialogCommand ??= new DelegateCommand<object>(CloseDialog);
    protected virtual void CloseDialog(object parameter)
    {
        RequestClose?.Invoke(null);
    }
    private DelegateCommand<object> _closeDialogCommand;

    public void OnDialogOpened(IDialogParameters parameters)
    {
        var fileVersionInfo = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
        var fileInfo = new FileInfo(Assembly.GetExecutingAssembly().Location);

        AppInfo = new()
            {
                // 機台名稱
                new AppInfoDefine()
                {
                    InfoName = GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_MachineName"),
                    InfoDescription = SysParameters.Instance.SystemSetting.MachineName,
                },
          
                // 公司名稱
                new AppInfoDefine()
                {
                    InfoName = GetResource.GetValue<string>("Caption_CompanyName"),
                    InfoDescription = fileVersionInfo.CompanyName,
                },
          
                // 版本資訊
                new AppInfoDefine()
                {
                    InfoName = GetResource.GetValue<string>("Caption_ApplicationVersion"),
                    InfoDescription = fileVersionInfo.ProductVersion,
                },

                // 程式日期
                new AppInfoDefine()
                {
                    InfoName = GetResource.GetValue<string>("Caption_LastWriteTime"),
                    InfoDescription = fileInfo.LastWriteTime.ToString("G"),
                },
            };
    }

    /// <summary>
    /// 應用程式資訊內容。
    /// </summary>
    public List<AppInfoDefine> AppInfo
    {
        get { return _appInfo; }
        set { SetProperty(ref _appInfo, value); }
    }
    private List<AppInfoDefine> _appInfo = new();
}
