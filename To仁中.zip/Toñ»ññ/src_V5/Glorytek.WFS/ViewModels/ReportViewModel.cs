﻿using Glorytek.WFSCore.Constants;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// 報表顯示頁的ViewModel。
/// </summary>
public class ReportViewModel : BindableBase
{
    private IRegionNavigationService _navigationService;

    /********************
     * ctor
     ********************/
    private readonly IRegionManager _regionManager;

    public ReportViewModel(IRegionManager regionManager)
    {
        _regionManager = regionManager;
    }

    public DelegateCommand LoadedCommand
        => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
    private void ExecuteLoadedCommand()
    {
        _navigationService = _regionManager.Regions[RegionNames.Report].NavigationService;

        if (ReportSelector == "")
        {
            ReportSelector = PageKeys.AbnormalHistory;
            _navigationService.RequestNavigate(PageKeys.AbnormalHistory);
        }
    }
    private DelegateCommand _loadedCommand;

    public DelegateCommand<string> PageNavigateCommand
        => _pageNavigateCommand ??= new DelegateCommand<string>(ExecutePageNavigateCommand);
    private void ExecutePageNavigateCommand(string pageKey)
    {
        _navigationService.RequestNavigate(pageKey);
    }
    private DelegateCommand<string> _pageNavigateCommand;

    /// <summary>
    /// 
    /// </summary>
    public string ReportSelector
    {
        get { return _reportSelector; }
        set { SetProperty(ref _reportSelector, value); }
    }
    private static string _reportSelector = "";

    ///// <summary>
    ///// 報表頁面選擇。
    ///// </summary>
    //public string ReportSelector
    //{
    //    get { return _reportSelector; }
    //    set
    //    {
    //        SetProperty(ref _reportSelector, value);


    //        try
    //        {
    //            if (value != LogName_AbnormalHistory && value != LogName_SystemLogger && value != LogName_ExceptionLogger)
    //                throw new Exception($"Report parameter error, value={value}");

    //            _sysMessenger.StatusBarMessage(GetResource.GetValue<string>($"PageTitle_Report_{value}"));
    //            SerilogBrowserContent.Instance.ShowExtendData = value != LogName_AbnormalHistory;

    //            _sysMessenger.ShowProgressRing(true);
    //            Task.Run(() =>
    //            {
    //                using var conn = SQLiteHelper.OpenConnection(Path.Combine(DBbase.Directory_Base, "Logs"),
    //                                                             $"{value}{DBbase.DB_ExtFileName}");
    //                using var tran = conn.BeginTransaction();
    //                try
    //                {
    //                    //SerilogBrowserContent.Instance.ReportSource = conn.GetAll<SerilogDefine>().ToList();
    //                    SerilogBrowserContent.Instance.ReportCollectionView
    //                        = CollectionViewSource.GetDefaultView(conn.GetAll<SerilogDefine>(transaction: tran)
    //                                                                  .OrderByDescending(x => x.Timestamp));
    //                    tran.Commit();
    //                }
    //                catch
    //                {
    //                    tran.Rollback();
    //                }
    //            })
    //                .ContinueWith((c) =>
    //                {
    //                    _sysMessenger.ShowProgressRing(false);
    //                }).Wait();
    //        }
    //        catch (Exception ex)
    //        {
    //            Log.Fatal(ex, ex.Message);
    //            throw;
    //        }
    //    }
    //}
    //private string _reportSelector;
}
