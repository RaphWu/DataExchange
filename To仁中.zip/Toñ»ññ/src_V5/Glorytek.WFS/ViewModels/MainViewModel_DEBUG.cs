﻿#if DEBUG

using Glorytek.CSharp.Data.Validation;
using Glorytek.WFSCore.Constants;
using Prism.Commands;

namespace Glorytek.WFS.ViewModels;

/********************
 * 主控頁的ViewModel - Debug測試用功能。
 ********************/
public partial class MainViewModel
{
    public DelegateCommand AdminCommand
        => _adminCommand ??= new DelegateCommand(ExecuteAdminCommand);
    private void ExecuteAdminCommand()
    {
        _authority.SwitchAuthority(UserGroup.Admin, "GloryTek880819".GetMD5Hash());
    }
    private DelegateCommand _adminCommand;

    public DelegateCommand Test1Command
        => _test1Command ??= new DelegateCommand(ExecuteTest1Command);
    private void ExecuteTest1Command()
    {
    }
    private DelegateCommand _test1Command;

    public DelegateCommand Test2Command
        => _test2Command ??= new DelegateCommand(ExecuteTest2Command);
    private void ExecuteTest2Command()
    {
    }
    private DelegateCommand _test2Command;
}

#endif
