﻿using Glorytek.CSharp.OS;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.ProductManager;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Serilog;
using Serilog.Events;
using Serilog.Exceptions;
using System;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// 主畫面的ViewModel。
/// </summary>
public class MainWindowViewModel : BindableBase
{
    private IRegionNavigationService _statusBarService;
    private IRegionNavigationService _navigationService;
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;

    /// <summary>
    /// 主選單頁數。
    /// </summary>
    private const int TotalMainMenuPage = 2;

    /// <summary>
    /// 上一次被按的選單。
    /// </summary>
    private string _lastMainMenuButton = "";

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IRegionManager _regionManager;

    public MainWindowViewModel(IEventAggregator ea,
                               IRegionManager regionManager,
                               IApplicationCommands applicationCommands)
    {
        _ea = ea;
        _regionManager = regionManager;
        ApplicationCommands = applicationCommands;

        /********************
         * Logger
         ********************/
        //string thisMonth = DateTime.Now.ToString("yyyyMM");
        string thisMonth = "";
        Log.Logger = new LoggerConfiguration()
#if DEBUG
            .MinimumLevel.Debug()
#else
            .MinimumLevel.Information()
#endif
            // System Logger
            // 系統執行紀錄
            .WriteTo.SQLite(Path.Combine(DBbase.Directory_Logger, $"SystemLog{thisMonth}{DBbase.DB_ExtFileName}"))
            // 異常履歷
            // Operator用的異常履歷
            .WriteTo.Logger(l => l
                .Filter.ByIncludingOnly(e => e.Level == LogEventLevel.Warning || e.Level == LogEventLevel.Error)
                .WriteTo.SQLite(Path.Combine(DBbase.Directory_Logger, $"AbnormalHistory{thisMonth}{DBbase.DB_ExtFileName}"))
                )
            // Exception Logger
            // 重大異常紀錄、程式跳出
            .WriteTo.Logger(l => l
                .MinimumLevel.Error()
                .Enrich.WithExceptionDetails()
                .WriteTo.SQLite(Path.Combine(DBbase.Directory_Logger, $"ExceptionLog{thisMonth}{DBbase.DB_ExtFileName}"), batchSize: 1)
                )
            .CreateLogger();
    }

    /********************
     * System Commands
     ********************/
    /// <summary>
    /// 應用程式載入。
    /// </summary>
    public DelegateCommand LoadedCommand
        => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
    private void ExecuteLoadedCommand()
    {
        /********************
         * 未捕獲異常
         ********************/
        Application.Current.DispatcherUnhandledException += new System.Windows.Threading.DispatcherUnhandledExceptionEventHandler(Current_DispatcherUnhandledException);
        AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

        /********************
         * Navigation Service
         ********************/
        _statusBarService = _regionManager.Regions[RegionNames.StatusBar].NavigationService;
        _navigationService = _regionManager.Regions[RegionNames.Main].NavigationService;

        /********************
         * 語系設定
        ********************/
        _sdi.LanguageTag = "zh-Hant";

        // CultureInfo
        _sdi.SystemCultureInfo = CultureInfo.CreateSpecificCulture(_sdi.LanguageTag);

        // 設定UI的語系
        System.Threading.Thread.CurrentThread.CurrentUICulture = _sdi.SystemCultureInfo;

        // 設定語系的資料格式
        System.Threading.Thread.CurrentThread.CurrentCulture = _sdi.SystemCultureInfo;

        // 設定目前應用程式所有執行緒的語系
        CultureInfo.DefaultThreadCurrentCulture = _sdi.SystemCultureInfo;
        CultureInfo.DefaultThreadCurrentUICulture = _sdi.SystemCultureInfo;

        // UI切換 (WPFLocalizeExtension)
        //LocalizeDictionary.Instance.SetCurrentThreadCulture = true;
        //LocalizeDictionary.Instance.Culture = new CultureInfo(langTag);

        /********************
         * 開啟後主頁面顯示
         ********************/
        _statusBarService.RequestNavigate(PageKeys.StatusBar);
        //_navigationService.RequestNavigate(PageKeys.Main);
        PageNavigate(PageKeys.Main);
        CurrentMainMenuButton = PageKeys.Main;

        /********************
         * 其他設定
         ********************/
        // 阻止系統睡眠、防止螢幕關閉
        SystemSleep.PreventForCurrentThread();

        // 調整所有ToolTip顯示行為
        ToolTipService.ShowDurationProperty.OverrideMetadata(typeof(DependencyObject), new FrameworkPropertyMetadata(Int32.MaxValue));
        ToolTipService.InitialShowDelayProperty.OverrideMetadata(typeof(DependencyObject), new FrameworkPropertyMetadata(2));
        ToolTipService.BetweenShowDelayProperty.OverrideMetadata(typeof(DependencyObject), new FrameworkPropertyMetadata(0));

        Log.Information("Main window load finished.");
    }

    private DelegateCommand _loadedCommand;

    /// <summary>
    /// 應用程式結束前置作業。
    /// </summary>
    public DelegateCommand ApplicationShutdownCommand
        => _applicationShutdownCommand ??= new DelegateCommand(ApplicationShutdown);
    private void ApplicationShutdown()
    {
        Task.Run(() =>
        {
            // 關閉週邊設備
            _ea.GetEvent<ApplicationShutdownEvent>().Publish(0);

            // Close品種
            if (!ProductDatas.Instance.IsProductActive)
                ProductDatas.Instance.DbConnection?.Close();
        }).Wait();

        // Remove Region
        _regionManager.Regions.Remove(RegionNames.Main);
        _regionManager.Regions.Remove(RegionNames.StatusBar);
    }
    private DelegateCommand _applicationShutdownCommand;

    /// <summary>
    /// 未捕獲異常。
    /// </summary>
    /// <remarks>參見: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.windows.application.dispatcherunhandledexception">Application.DispatcherUnhandledException 事件</see>。</remarks>
    private void Current_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
    {
        // TODO: 未對例外做額外處理
        Log.Fatal(e.Exception, $"Unhandled Exception: {e.Exception.Message}");
        if (e.Exception.InnerException != null)
            Log.Fatal(e.Exception.InnerException, $"Inner Exception: {e.Exception.InnerException.Message}");
        Log.CloseAndFlush();

        MessageBox.Show(e.Exception.Message, "Unhandled Exception", MessageBoxButton.OK, MessageBoxImage.Error);
        ApplicationShutdown(); // 如果不要崩潰，要使用 e.Handled = true;
    }

    /// <summary>
    /// 未攔截到的異常。
    /// </summary>
    /// <remarks>參見: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.appdomain.unhandledexception">AppDomain.UnhandledException 事件</see>。</remarks>
    private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs ex)
    {
        Exception e = (Exception)ex.ExceptionObject;
        Log.Fatal(e, $"Unhandled Exception: {e.Message}");
        if (e.InnerException != null)
            Log.Fatal(e.InnerException, $"Inner Exception: {e.InnerException.Message}");
        Log.CloseAndFlush();

        MessageBox.Show(e.Message, "Unhandled Exception", MessageBoxButton.OK, MessageBoxImage.Error);
        ApplicationShutdown();
    }

    /// <summary>
    /// 主選單按鍵導航。
    /// </summary>
    public DelegateCommand<string> PageNavigateCommand
        => _pageNavigateCommand ??= new DelegateCommand<string>(PageNavigate);
    private void PageNavigate(string pageKey)
    {
        // 特殊狀況判斷
        if (pageKey == "Pallet")
            pageKey = _sdi.SystemMode == SystemOperateModeType.LensArrange
                      ? PageKeys.LensArrange
                      : PageKeys.LensSorting;

        // Navigate to Page
        _navigationService.RequestNavigate(pageKey);
    }
    private DelegateCommand<string> _pageNavigateCommand;

    /// <summary>
    /// 目前頁面的選單按鍵。
    /// </summary>
    public string CurrentMainMenuButton
    {
        get { return _currentMainMenuButton; }
        set
        {
            _lastMainMenuButton = _currentMainMenuButton;
            SetProperty(ref _currentMainMenuButton, value);
        }
    }
    private string _currentMainMenuButton;

    /// <summary>
    /// 改變顯示的選單按鍵為上一次。
    /// </summary>
    public void ShowLastMainMenuButton()
    {
        CurrentMainMenuButton = _lastMainMenuButton;
    }

    /// <summary>
    /// 由 Prism CompositeCommand 實現的應用程式全域命令。
    /// </summary>
    public IApplicationCommands ApplicationCommands
    {
        get { return _applicationCommands; }
        set { SetProperty(ref _applicationCommands, value); }
    }
    private IApplicationCommands _applicationCommands;
}
