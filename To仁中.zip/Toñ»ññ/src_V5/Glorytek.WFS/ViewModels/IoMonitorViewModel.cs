﻿using Glorytek.WFSCore.Contracts;
using Glorytek.WPF.Extensions;
using Prism.Mvvm;
using Prism.Regions;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// IO監看的ViewModel。
/// </summary>
public class IoMonitorViewModel : BindableBase, INavigationAware
{
    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_IoMonitor"));
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;

    public IoMonitorViewModel(ISystemMessenger sysMessenger)
    {
        _sysMessenger = sysMessenger;
    }
}
