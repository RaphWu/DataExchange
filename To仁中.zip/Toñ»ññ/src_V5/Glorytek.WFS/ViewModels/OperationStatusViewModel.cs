﻿using Glorytek.WFS.Models;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WPF.Extensions;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using System.Collections.ObjectModel;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// 作業狀態的ViewModel。
/// </summary>
public class OperationStatusViewModel : BindableBase, INavigationAware
{
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;
    private readonly PlcDatas _pd = PlcDatas.Instance;

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_OperationStatus"));
        ReadDatas();
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly ISystemMessenger _sysMessenger;
    private readonly ITray _tray;
    private readonly IWfs _wfs;
    private readonly IPlc _plc;

    public OperationStatusViewModel(IEventAggregator ea,
                                    ISystemMessenger sysMessenger,
                                    ITray tray,
                                    IWfs wfs,
                                    IPlc plc)
    {
        _ea = ea;
        _sysMessenger = sysMessenger;
        _tray = tray;
        _wfs = wfs;
        _plc = plc;

        _ = _ea.GetEvent<SystemPointNoUpdatedEvent>().Subscribe(UpdateAllPointNoEvent, true);
    }

    private void UpdateAllPointNoEvent(int obj)
    {
        UpdateAllPointNo();
    }

    private void UpdateAllPointNo()
    {
        var palletList = PalletList;
        for (int palletIndex = 0; palletIndex < ITray.MaxPalletId; palletIndex++)
            palletList[palletIndex].PickSequenceNo = _tray.PalletList[palletIndex].PickSequenceNo;
        PalletList = palletList;
    }

    /********************
     * 
     ********************/
    /// <summary>
    /// 讀取資料。
    /// </summary>
    private void ReadDatas()
    {
        var palletInfo = new ObservableCollection<OperationStatusDefine>();

        for (int palletId = 1; palletId <= ITray.MaxPalletId; palletId++)
        {
            int palletIdx = palletId - 1;
            var pallet = _tray.PalletList.Find(x => x.Id == palletId);
            var palletData = _wfs.LensSortingList.Find(x => x.Id == palletId);

            string gradeName = string.Empty;
            //string none = GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_None");

            TrayDefine tray = null;
            TrayFunctionType funcType = TrayFunctionType.Unused;

            if (_sdi.SystemMode_LensArrange)
            {
                var pal = _wfs.LensArrangeList.Find(x => x.Id == palletId);
                if (pal != null)
                    if (pal.Pick)
                    {
                        funcType = TrayFunctionType.Feeder;
                        tray = _tray.TrayList.Find(x => x.Id == pal.PickTrayId);
                    }
                    else if (pal.Place)
                    {
                        funcType = TrayFunctionType.Classified;
                        tray = _tray.TrayList.Find(x => x.Id == pal.PlaceTrayId);
                    }
            }
            else
            {
                int gradeId = palletData.GradeId;
                if (gradeId > 0)
                {
                    var grade = _wfs.GradeList.Find(x => x.Id == gradeId);
                    gradeName = grade != null ? grade.Name : "";
                }
                tray = _tray.TrayList.Find(x => x.Id == palletData.TrayId);
                funcType = palletData.FunctionName;
            }

            OperationStatusDefine osd = new()
            {
                Id = palletId,
                FunctionName = funcType,
            };

            if (tray != null && funcType != TrayFunctionType.Unused)
            {
                osd.InstallTray = funcType != TrayFunctionType.Unused;
                osd.TrayName = tray.Name;
                osd.GradeName = gradeName;
                osd.Barcode = palletData.Barcode;
                osd.TotalPoints = tray.TotalPoints;
                osd.TotalSequences = tray.TotalSequences;

                osd.PickHeight = tray.PickHeight;
                osd.PickHeightOffset = pallet.PickHeightOffset;
                osd.ZAxis_Pick_Height = pallet.ZAxis_Pick_Height;
                osd.ZAxis_Place_Height = pallet.ZAxis_Place_Height;
                osd.ZAxis_Pick_SpeedRate = pallet.ZAxis_Pick_SpeedRate;
                osd.ZAxis_Place_SpeedRate = pallet.ZAxis_Place_SpeedRate;
                osd.ZAxis_PickDelay_BeforeVacuum = pallet.ZAxis_PickDelay_BeforeVacuum;
                osd.ZAxis_UpDelay_AfterPick = pallet.ZAxis_UpDelay_AfterPick;
                osd.ZAxis_Place_VacuumRelief = pallet.ZAxis_Place_VacuumRelief;
                osd.ZAxis_UpDelay_AfterPlace = pallet.ZAxis_UpDelay_AfterPlace;
            }
            else
            {
                osd.TrayName = "";
                osd.TotalPoints = 0;
            }
            palletInfo.Add(osd);
        }

        PalletList = palletInfo;
        UpdateAllPointNo();
    }

    /// <summary>
    /// 暫停。
    /// </summary>
    public DelegateCommand PauseCommand
        => _pauseCommand ??= new DelegateCommand(ExecutePauseCommand);
    private void ExecutePauseCommand()
    {
        _plc.SendCommandPulse(DeviceLists.PAUSE_COMMAND);
    }
    private DelegateCommand _pauseCommand;

    /********************
     * Datas
     ********************/
    /// <summary>
    /// 各Pallet的狀態資料。
    /// </summary>
    public ObservableCollection<OperationStatusDefine> PalletList
    {
        get { return _palletList; }
        set { SetProperty(ref _palletList, value); }
    }
    private ObservableCollection<OperationStatusDefine> _palletList;
}
