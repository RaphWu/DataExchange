﻿//namespace Glorytek.WFS.ViewModels
//{
//    /********************
//     * 主控頁的ViewModel - 連線模式。
//     ********************/
//    public partial class MainConsoleViewModel
//    {
//    }
//}
