﻿using Glorytek.WFSComponents.Stage.Contracts;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Models.Stage;
using Glorytek.WPF.Extensions;
using Prism;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// Stage設定頁面的ViewModel。
/// </summary>
public class StageParametersViewModel : BindableBase, INavigationAware, IActiveAware
{
    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_StageParameters"));
        LoadDatas();
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    private bool _IsActive = false;
    public bool IsActive
    {
        get { return _IsActive; }
        set
        {
            _IsActive = value;
            OnIsActiveChanged();
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IStage _stage;

    public StageParametersViewModel(IApplicationCommands applicationCommands,
                                    ISystemMessenger sysMessenger,
                                    IStage stage)
    {
        _sysMessenger = sysMessenger;
        _stage = stage;

        // TODO: UnregisterCommand
        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 將資料或參數寫入資料庫。
    /// </summary>
    public void ExecuteSaveDataCommand()
    {
        _stage.StageA1 = StageA1;
        _stage.StageA2 = StageA2;
        _stage.WriteToDb();
        _stage.WriteToPlc();
    }

    /// <summary>
    /// 載入資料。
    /// </summary>
    public void LoadDatas()
    {
        StageA1 = _stage.StageA1;
        StageA2 = _stage.StageA2;
    }

    /********************
     * Datas
     ********************/
    /// <summary>
    /// Stage A1。
    /// </summary>
    public StageDefine StageA1
    {
        get { return _stageA1; }
        set { SetProperty(ref _stageA1, value); }
    }
    private StageDefine _stageA1;

    /// <summary>
    /// Stage A2。
    /// </summary>
    public StageDefine StageA2
    {
        get { return _stageA2; }
        set { SetProperty(ref _stageA2, value); }
    }
    private StageDefine _stageA2;
}
