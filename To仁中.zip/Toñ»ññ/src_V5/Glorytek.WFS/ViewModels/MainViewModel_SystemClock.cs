﻿using System;
using System.Timers;

namespace Glorytek.WFS.ViewModels;

/********************
 * 主控頁的ViewModel - 系統時鐘。
 ********************/
public partial class MainViewModel
{
    public const int CLOCK_INTERVAL = 250;  // 時鐘觸發間隔(ms)
    private static Timer _sysClock;
    private static uint _sysClockTriggerTimes = 0;

    /// <summary>
    /// 系統時鐘初始化並啟動。
    /// </summary>
    private void SystemClockInit()
    {
        _sysClock = new Timer();
        _sysClock.Elapsed += SystemClockEvent;
        _sysClock.Interval = CLOCK_INTERVAL;
        _sysClock.Start();
    }

    /// <summary>
    /// 系統時鐘觸發的事件。
    /// </summary>
    private void SystemClockEvent(object sender, EventArgs e)
    {
        DateTime now = DateTime.Now;
        _sdi.Clock = now;

        if (_sdi.AutoMode)
            _sdi.ProductionRunTime = now - _sdi.ProductionStartTime;

        _sysClockTriggerTimes++;

        // 0.5秒
        if ((_sysClockTriggerTimes & 0b0001) == 0)
        {
            _sdi.Flicker500 = !_sdi.Flicker500;
        }
        // 1秒
        if ((_sysClockTriggerTimes & 0b0011) == 0)
        {
            _sdi.MachineRuningTime = now;
            _sdi.Flicker1000 = !_sdi.Flicker1000;
        }
        //// 10秒
        //if (_sysClockTriggerTimes % 40 == 0)
        //{
        //    _ = _sys.WriteToDb(); // 自動存檔(主要是更新開機累計時間)
        //}
    }
}
