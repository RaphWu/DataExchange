﻿//using System.Collections.Generic;
//using WFSComponents.WFS.Models;

//namespace Glorytek.WFS.ViewModels
//{
//    /********************
//     * 主控頁的ViewModel - 轉角度模式。
//     ********************/
//    public partial class MainConsoleViewModel
//    {
//        /// <summary>
//        /// 
//        /// </summary>
//        public List<PickAndPlaceListDefine> PickAndPlaceList
//        {
//            get { return _pickAndPlaceList; }
//            set { SetProperty(ref _pickAndPlaceList, value); }
//        }
//        private List<PickAndPlaceListDefine> _pickAndPlaceList;
//    }
//}
