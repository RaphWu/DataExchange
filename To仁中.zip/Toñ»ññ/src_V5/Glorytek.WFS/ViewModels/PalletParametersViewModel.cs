﻿using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WPF.Extensions;
using Newtonsoft.Json;
using Prism;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using Serilog;
using System;
using System.Collections.Generic;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// Pallet作參數設定的ViewModel。
/// </summary>
public class PalletParametersViewModel : BindableBase, INavigationAware, IActiveAware
{
    private readonly PlcDatas _pd = PlcDatas.Instance;
    private bool _writePointNo = true;
    private static int _lastPalletIndex = -1;
    private TrayDefine _thisTray = null;

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_PalletParameters"));
        ReadData();

        if (_lastPalletIndex >= 0 && PalletList[_lastPalletIndex].InstallTray)
            Pallet = PalletList[_lastPalletIndex];
        else
            Pallet = PalletList.Find(x => x.InstallTray);
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    private bool _IsActive = false;
    public bool IsActive
    {
        get { return _IsActive; }
        set
        {
            _IsActive = value;
            OnIsActiveChanged();
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IDialogService _dialogService;
    private readonly ISystemMessenger _sysMessenger;
    private readonly ITray _tray;
    private readonly IWfs _wfs;
    private readonly IPlc _plc;

    public PalletParametersViewModel(IApplicationCommands applicationCommands,
                                     IEventAggregator ea,
                                     IDialogService dialogService,
                                     ISystemMessenger sysMessenger,
                                     ITray tray,
                                     IWfs wfs,
                                     IPlc plc)
    {
        _ea = ea;
        _dialogService = dialogService;
        _sysMessenger = sysMessenger;
        _tray = tray;
        _wfs = wfs;
        _plc = plc;

        _ = _ea.GetEvent<SystemPointNoUpdatedEvent>().Subscribe(UpdateAllPointNoEvent, true); // 點位有變動時，更新TrayList及TrayData

        // TODO: UnregisterCommand
        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 將資料或參數寫入資料庫。
    /// </summary>
    public void ExecuteSaveDataCommand()
    {
        _tray.WriteTrayToDb();
        foreach (var pallet in PalletList)
            _tray.WritePalletToPlc(pallet);
    }

    private void ReadData()
    {
        PalletList = _tray.PalletList;
        UpdateSequenceNo();
    }

    /********************
     * command
     ********************/
    /// <summary>
    /// 開啟Tray點位選擇器。
    /// </summary>
    public DelegateCommand OpenTrayMatrixSelectorCommand
        => _openTrayMatrixSelectorCommand ??= new DelegateCommand(ExecuteOpenTrayMatrixSelectorCommand);
    private void ExecuteOpenTrayMatrixSelectorCommand()
    {
        TrayDefine tray = null;
        switch (SystemDataInstance.Instance.SystemMode)
        {
            case SystemOperateModeType.Online_FixStage:
            case SystemOperateModeType.Online_DoubleCylinder:
            case SystemOperateModeType.Online_SingleCylinder:
            case SystemOperateModeType.Online_Disc:
            case SystemOperateModeType.LensSorting:
                var palletLensSorting = _wfs.LensSortingList.Find(x => x.Id == Pallet.Id);
                tray = _tray.TrayList.Find(x => x.Id == palletLensSorting.TrayId);
                break;

            case SystemOperateModeType.LensArrange:
                var palletLensArrange = _wfs.LensArrangeList.Find(x => x.Id == Pallet.Id);
                if (palletLensArrange.Pick)
                    tray = _tray.TrayList.Find(x => x.Id == palletLensArrange.PickTrayId);
                if (palletLensArrange.Place)
                    tray = _tray.TrayList.Find(x => x.Id == palletLensArrange.PlaceTrayId);
                break;
        }

        if (tray != null)
        {
            var tmsi = new TrayMatrixSelectorInfo
            {
                TrayId = tray.Id,
                PointNo = -1,
                SequenceNo = Pallet.NextSequenceNo,
            };
            var paras = new DialogParameters()
            {
                {
                    "StatusBarMessage",
                    JsonConvert.SerializeObject(tmsi, new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore
                    })
                }
            };

            IDialogResult _dialogResult = default;
            _dialogService.ShowDialog(nameof(WFSComponents.Views.TrayMatrixSelector), paras, r => { _dialogResult = r; });

            if (_dialogResult.Result == ButtonResult.OK)
            {
                tmsi = JsonConvert.DeserializeObject<TrayMatrixSelectorInfo>(_dialogResult.Parameters.GetValue<string>("StatusBarMessage"));
                if (tmsi.PointNo >= 1)
                {
                    //Pallet.NextPointNo = tmsi.PointNo;
                    //Pallet.SequenceNo = tmsi.SequenceNo;
                    //ThisCurrentSequenceNo = tmsi.SequenceNo;
                    _tray.WriteStartPointNo(Pallet.Id, tmsi.PointNo);
                }
            }
        }
    }
    private DelegateCommand _openTrayMatrixSelectorCommand;

    private void UpdateAllPointNoEvent(int obj)
    {
        UpdateSequenceNo();
    }

    private void UpdateSequenceNo()
    {
        //for (int palletIndex = 0; palletIndex < ITray.MaxPalletId; palletIndex++)
        //{
        //    var pallet = PalletList[palletIndex];

        //    if (pallet.InstallTray)
        //    {
        //        var trayId = _tray.GetTrayId(pallet.Id);
        //        pallet.NextPointNo = _pd.NextPointNo[palletIndex];
        //        pallet.PickPointNo = _pd.PickPointNo[palletIndex];
        //        pallet.SequenceNo = trayId >= 0
        //            ? _tray.ConvertPointNoToSequenceNo(trayId, pallet.NextPointNo)
        //            : pallet.SequenceNo = -1;
        //    }
        //}

        if (Pallet != null)
        {
            _writePointNo = false;
            CurrentSequenceNo = Pallet.NextSequenceNo;
        }
    }

    /// <summary>
    /// 全部點位歸零。
    /// </summary>
    public DelegateCommand ResetAllSequenceCommand
        => _resetAllSequenceCommand ??= new DelegateCommand(ExecuteResetAllSequenceCommand);
    private void ExecuteResetAllSequenceCommand()
    {
        Log.Debug("全部點位歸零");
        _plc.SendCommandPulse(DeviceLists.RESET_ALL_POINT_NO_COMMAND);

        //// 更新
        //foreach (var pallet in _tray.PalletList)
        //{
        //    var palletIndex = pallet.Id - 1;
        //    int pointNo = _tray.ReadStartPointNo(pallet.Id);
        //    //PalletList[palletIndex].NextPointNo = pointNo;
        //}
    }
    private DelegateCommand _resetAllSequenceCommand;

    /********************
     * 
     ********************/
    /// <summary>
    /// 所有Pallet資料列表。
    /// </summary>
    public List<PalletDefine> PalletList
    {
        get { return _palletList; }
        set { SetProperty(ref _palletList, value); }
    }
    private List<PalletDefine> _palletList;

    /// <summary>
    /// 目前編輯的Pallet資料。
    /// </summary>
    public PalletDefine Pallet
    {
        get { return _pallet; }
        set
        {
            SetProperty(ref _pallet, value);

            if (value != null)
            {
                _writePointNo = false;
                CurrentSequenceNo = value.NextSequenceNo;

                int trayId = _tray.GetTrayId(Pallet.Id);
                _thisTray = _tray.GetTray(trayId);

                _lastPalletIndex = value.Id - 1;
                ScreenEnabled = true;
            }
            else
            {
                _thisTray = null;
                ScreenEnabled = false;
            }
        }
    }
    private PalletDefine _pallet;

    /// <summary>
    /// CurrentSequenceNo輸入顯示。
    /// </summary>
    public int CurrentSequenceNo
    {
        get { return _currentSequenceNo; }
        set
        {
            if (_currentSequenceNo != value)
            {
                if (Pallet != null && value > Pallet.TotalSequences)
                    value = Pallet.TotalSequences;

                SetProperty(ref _currentSequenceNo, value);
                if (_writePointNo)
                    _tray.WriteStartPointNo(Pallet.Id, _tray.ConvertSequenceNoToPointNo(_thisTray.Id, value));
            }
            _writePointNo = true;
        }
    }
    private int _currentSequenceNo;

    /// <summary>
    /// 畫面編輯許可。
    /// </summary>
    public bool ScreenEnabled
    {
        get { return _screenEnabled; }
        set { SetProperty(ref _screenEnabled, value); }
    }
    private bool _screenEnabled;
}
