﻿using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Events;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using Serilog;
using System;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// 主控頁的ViewModel。
/// </summary>
public partial class MainConsoleViewModel : BindableBase, INavigationAware
{
    private static bool _eventNotSubscribed = true;
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;
    private readonly WfsParameters _wp = WfsParameters.Instance;
    private readonly WfsDatas _wd = WfsDatas.Instance;

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_Main"));
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IDialogService _dialog;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly ISystemMessenger _sysMessenger;
    private readonly IProductManager _pm;
    private readonly ITray _tray;
    private readonly IPlc _plc;
    private readonly IMeasuring _measuring;
    private readonly IWfs _wfs;

    public MainConsoleViewModel(IEventAggregator ea,
                                IDialogService dialogService,
                                IPrismMessageBox prismMessageBox,
                                ISystemMessenger sysMessenger,
                                IProductManager pm,
                                ITray tray,
                                IPlc plc,
                                IMeasuring measuring,
                                IWfs wfs)
    {
        _ea = ea;
        _dialog = dialogService;
        _prismMessageBox = prismMessageBox;
        _sysMessenger = sysMessenger;
        _pm = pm;
        _tray = tray;
        _plc = plc;
        _wfs = wfs;
        _measuring = measuring;

        // init
        WfsTraySource = null;
        ExcelDataTracking = false;

        _wfs.ReadBigDataFromDb();
        LoadOpticalParams();

        // 製作數
        if (_plc.Online)
        {
            var (_, estimatedQuantity) = _plc.ReadInt16(DeviceLists.ESTIMATED_QUANTITY_SETTING);
            EstimatedQuantitySetting = estimatedQuantity;
        }
        else
        {
            EstimatedQuantitySetting = 1;
        }

        // 系統開啟後，預設模式
        StopButtonLamp = false;

        if (_eventNotSubscribed)
        {
            _eventNotSubscribed = false;
            _ = _ea.GetEvent<ShowOperateMessageEvent>().Subscribe(ShowOperateMessage, keepSubscriberReferenceAlive: true);
            _ = _ea.GetEvent<AutoStopSignal>().Subscribe(WhenOperationStop, keepSubscriberReferenceAlive: true);
        }
    }

    private void ShowOperateMessage(string message) => OperateMessage = message;

    /********************
    * Database
    ********************/
    /// <summary>
    /// 讀取資料庫。
    /// </summary>
    public void ReadFromDb()
    {
        if (!_pm.IsProductActive)
            return;

        _ = _wfs.ReadFromDb();
    }

    /********************
     * 機台作業
     ********************/
    /// <summary>
    /// 自動作業結束的處理。
    /// </summary>
    /// <param name="fromPolling">若由PLC Polling呼叫，有額外處理。</param>
    private void WhenOperationStop(bool fromPolling = false)
    {
        if (fromPolling)
        {
            string stopMsg = $"{GetResource.GetValue<string>("Message_AutoModeStop")}\n{GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_LotNumber")}: {_wp.CurrentLotNumber}";
            _sysMessenger.OperateMessage(stopMsg);
        }

        _plc.StopCTStopwatch();
        _wfs.StopDataCollection();
        _wfs.ResetLot();
        PlcDatas.Instance.UpdateSignalLamp();
    }

    /// <summary>
    /// 啟動。
    /// </summary>
    public DelegateCommand StartCommand
        => _startCommand ??= new DelegateCommand(ExecuteStartCommand);
    private void ExecuteStartCommand()
    {
        StringBuilder errMsg = new();
        bool hasError = false;

        // PLC未連線
        if (!_plc.Online)
        {
            hasError = true;
            errMsg.Append(GetResource.GetValue<string>("ErrorMessage_PlcOffline"));
        }
        // 各連線棤式要檢查量測機是否連線
        if ((_sdi.SystemMode_Online_FixStage || _sdi.SystemMode_Online_DoubleCylinder
            || _sdi.SystemMode_Online_SingleCylinder || _sdi.SystemMode_Online_Disc)
            && !_measuring.Online)
        {
            hasError = true;
            if (errMsg.Length > 0)
                errMsg.Append('\n');
            errMsg.Append(GetResource.GetValue<string>("ErrorMessage_MeasureMachineOffline"));
        }
        // 製作數不能超過Tray總有效點數
        int totalSequence = _tray.GetTotalSequenceOfFeeder();
        if (!_sdi.SystemMode_Tray_A1 && EstimatedQuantitySetting > totalSequence)
        {
            hasError = true;
            if (errMsg.Length > 0)
                errMsg.Append('\n');
            errMsg.Append($"{GetResource.GetValue<string>("ErrorMessage_EQGreaterThanSN")}{totalSequence}");
        }

        if (hasError)
        {
            _ = _prismMessageBox.Show(errMsg.ToString(),
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_SettingError"),
                                      MessageBoxImage.Error);
            WhenOperationStop(false);
            return;
        }

        // EXCEL檢查
        if (_sdi.SystemMode_LensSorting)
        {
            errMsg = new();
            hasError = false;

            // EXCEL檔遇未讀入
            if (!ExcelDataLoaded)
            {
                hasError = true;
                errMsg.Append(GetResource.GetValue<string>("ErrorMessage_ExcelNotLoaded"));
            }
            // 製作數不能超過EXCEL資料數
            else
            {
                if (EstimatedQuantitySetting > RecoderOfExcel)
                {
                    hasError = true;
                    errMsg.Append($"{GetResource.GetValue<string>("ErrorMessage_EQGreaterThanExcelRecords")}{RecoderOfExcel}");
                }
            }

            if (hasError)
            {
                _ = _prismMessageBox.Show(errMsg.ToString(),
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_SettingError"),
                                          MessageBoxImage.Error);
                WhenOperationStop(false);
                return;
            }
        }

        // 各模式相關檢查與PLC寫入
        if (!(_sdi.SystemMode_Tray_A1
            ? _wfs.ConditionCheckAndWriteToPlc(writeToPlc: true, trayId: TrayToA1_SelectedTrayId)
            : _wfs.ConditionCheckAndWriteToPlc(writeToPlc: true)))
        {
            WhenOperationStop(false);
            return;
        }

        // 不執行規格判定 訊息提示
        if (_wfs.DoNotCheckSpecification)
        {
            if (_prismMessageBox.ShowOKCancel(GetResource.GetValue<string>("Caption_ConfirmDoNotCheckSpecification"),
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_ConfirmTheAction"),
                                              MessageBoxImage.Warning,
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "Button_ConfirmAndStartOperate"),
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "Button_CancelOperate"))
                == ButtonResult.Cancel)
            {
                WhenOperationStop(false);
                return;
            }
        }

        // 製作數
        _ = _plc.WriteInt16(DeviceLists.ESTIMATED_QUANTITY_SETTING, EstimatedQuantitySetting);
        if (!_sdi.SystemMode_Tray_A1 && !_wfs.StartDataCollection())
        {
            Log.Warning("批號建立失敗");
            WhenOperationStop(false);
            return;
        }

        // 更新作業需求參數
        if (_sdi.SystemMode_LensSorting)
            LensNumberUpdated();

        // Cycle Time Stopwatch
        _plc.ResetCTStopwatch();
        _plc.StartCTStopwatch();

        // message
        string startMsg = $"{GetResource.GetValue<string>("Message_AutoModeStart")}\n{GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_LotNumber")}: {_wp.CurrentLotNumber}";
        _sysMessenger.OperateMessage(startMsg);
        _sdi.ProductionStartTime = DateTime.Now;
        Log.Information($"{startMsg}:{_sdi.ProductionStartTime}, {GetResource.GetValue<string>("Caption_EstimatedQuantitySetting")}:{EstimatedQuantitySetting}");

        // Start
        _plc.WriteBool(DeviceLists.INTERRUPT_OPERATION, false);
        _plc.SendCommandPulse(DeviceLists.START_COMMAND);
    }
    private DelegateCommand _startCommand;

    /// <summary>
    /// 暫停。
    /// </summary>
    public DelegateCommand PauseCommand
        => _pauseCommand ??= new DelegateCommand(ExecutePauseCommand);
    private void ExecutePauseCommand()
    {
        // PLC是自動模式才會執行暫停指令
        if (_sdi.AutoMode)
            _plc.SendCommandPulse(DeviceLists.PAUSE_COMMAND);
        else
        {
            // 為防止RadioButton因USER按下而亮燈，強迫把燈熄掉
            _sdi.MachinePause = !_sdi.MachinePause;
            _sdi.MachinePause = false;
        }
    }
    private DelegateCommand _pauseCommand;

    /// <summary>
    /// 停止。
    /// </summary>
    public DelegateCommand StopCommand
        => _stopCommand ??= new DelegateCommand(ExecuteStopCommand);
    private void ExecuteStopCommand()
    {
        StopButtonLamp = true;
        _plc.SendCommandPulse(DeviceLists.STOP_COMMAND);
        WhenOperationStop(false);

        string stopMsg;
        if (_sdi.AutoMode &&
            (_sdi.SystemMode == SystemOperateModeType.Online_FixStage
            || _sdi.SystemMode == SystemOperateModeType.Online_DoubleCylinder
            || _sdi.SystemMode == SystemOperateModeType.Online_SingleCylinder
            || _sdi.SystemMode == SystemOperateModeType.Online_Disc))
        {
            stopMsg = $"{GetResource.GetValue<string>("Message_AutoModeBreak")}\n{GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_LotNumber")}: {_wp.CurrentLotNumber}";
        }
        else
        {
            stopMsg = GetResource.GetValue<string>("Caption_Stop");
        }
        Log.Information($"{stopMsg}:{DateTime.Now} ({_sdi.ProductionRunTimeString})");
        _sysMessenger.OperateMessage(stopMsg);

        //// 顯示原批號
        //if (_sysState.SystemMode == SystemOperateModeType.Online_FixStage
        //    || _sysState.SystemMode == SystemOperateModeType.LensSorting
        //    || _sysState.SystemMode == SystemOperateModeType.Online_DoubleCylinder
        //    || _sysState.SystemMode == SystemOperateModeType.Online_SingleCylinder
        //    || _sysState.SystemMode == SystemOperateModeType.Online_Disc)
        //{
        //    _ea.GetEvent<LotNumberChangedEvent>().Publish(_lastLotNumber);
        //}

        _ = Task.Delay(300).ContinueWith((c) => StopButtonLamp = false);
    }
    private DelegateCommand _stopCommand;

    /// <summary>
    /// 停止按鍵燈號。
    /// </summary>
    public bool StopButtonLamp
    {
        get { return _stopButtonLamp; }
        set { SetProperty(ref _stopButtonLamp, value); }
    }
    private bool _stopButtonLamp;

    /// <summary>
    /// 手動模式切換。
    /// </summary>
    public DelegateCommand ManualModeCommand
        => _manualModeCommand ??= new DelegateCommand(ExecuteManualModeCommand);
    private void ExecuteManualModeCommand()
    {
        _plc.StopCTStopwatch();
        _plc.SendCommandPulse(DeviceLists.MANUAL_MODE_COMMAND);
    }
    private DelegateCommand _manualModeCommand;

    /// <summary>
    /// 復歸。
    /// </summary>
    public DelegateCommand HomerReturnCommand
        => _homerReturnCommand ??= new DelegateCommand(ExecuteHomerReturnCommand);
    private void ExecuteHomerReturnCommand()
    {
        // 單軸復歸Dialog
        //_dialog.ShowDialog(nameof(Views.OPR));

        if (!_plc.HomeReturning)
        {
            Log.Information("執行復歸");
            _sysMessenger.OperateMessage(string.Empty);
            _plc.StopCTStopwatch();
            _plc.HomeReturn();
        }
    }
    private DelegateCommand _homerReturnCommand;

    /// <summary>
    /// 警報解除。
    /// </summary>
    public DelegateCommand SystemAlarmResetCommand
        => _systemAlarmResetCommand ??= new DelegateCommand(ExecuteSystemAlarmResetCommand);
    private void ExecuteSystemAlarmResetCommand()
    {
        _plc.PlcReset();
        _plc.StopCTStopwatch();
        _wfs.ResetLot();
    }
    private DelegateCommand _systemAlarmResetCommand;

    /// <summary>
    /// 照明切換。
    /// </summary>
    public DelegateCommand LightsSwitchCommand
        => _lightsSwitchCommand ??= new DelegateCommand(ExecuteLightsSwitchCommand);
    private void ExecuteLightsSwitchCommand()
    {
        _plc.SendCommandPulse(DeviceLists.LIGHTS_COMMAND);
    }
    private DelegateCommand _lightsSwitchCommand;

    /// <summary>
    /// 試運轉。
    /// </summary>
    public DelegateCommand TestModeCommand
        => _testModeCommand ??= new DelegateCommand(ExecuteTestModeCommand);
    private void ExecuteTestModeCommand()
    {
        if (!_plc.Online)
        {
            _prismMessageBox.Show("PLC是離線狀態！", "PLC錯誤", MessageBoxImage.Error);
            return;
        }

        bool mode = !PlcDatas.Instance.TestMode;
        _ = _plc.WriteBool(DeviceLists.TEST_MODE_COMMAND, mode);
        Log.Information(GetResource.GetValue<string>($"Caption_TestMode: {mode}"));
    }
    private DelegateCommand _testModeCommand;

    /// <summary>
    /// 全部點位歸零。
    /// </summary>
    public DelegateCommand ResetAllSequenceCommand
        => _resetAllSequenceCommand ??= new DelegateCommand(ExecuteResetAllSequenceCommand);
    private void ExecuteResetAllSequenceCommand()
    {
        Log.Debug("全部點位歸零");
        _plc.SendCommandPulse(DeviceLists.RESET_ALL_POINT_NO_COMMAND);

        //// 更新
        //foreach (var pallet in _tray.PalletList)
        //    _tray.ReadPalletFromPlc(pallet);

        StartPositionOfExcel = 1;
    }
    private DelegateCommand _resetAllSequenceCommand;

    /// <summary>
    /// 製作數設定。
    /// </summary>
    public short EstimatedQuantitySetting
    {
        get { return _estimatedQuantitySetting; }
        set { SetProperty(ref _estimatedQuantitySetting, value); }
    }
    private static short _estimatedQuantitySetting;

    /// <summary>
    /// 訊息框。
    /// </summary>
    public string OperateMessage
    {
        get { return _operateMessage; }
        set { SetProperty(ref _operateMessage, value); }
    }
    private string _operateMessage;
}
