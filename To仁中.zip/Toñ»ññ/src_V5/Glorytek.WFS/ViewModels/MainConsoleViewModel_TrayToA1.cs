﻿using Prism.Commands;

namespace Glorytek.WFS.ViewModels;

/********************
 * 主控頁的ViewModel - Tray > A1模式。
 ********************/
public partial class MainConsoleViewModel
{
    /// <summary>
    /// 測試的Tray ID。
    /// </summary>
    public int TrayToA1_SelectedTrayId
    {
        get { return _trayToA1_SelectedTrayId; }
        set { SetProperty(ref _trayToA1_SelectedTrayId, value); }
    }
    private int _trayToA1_SelectedTrayId;

    /// <summary>
    /// 繼續鍵指令，回饋PLC信號。
    /// </summary>
    public DelegateCommand TrayToA1_ContinueCommand
        => _trayToA1_ContinueCommand ??= new DelegateCommand(ExecuteTrayToA1_ContinueCommand);
    private void ExecuteTrayToA1_ContinueCommand()
    {
        _plc.SendCommandPulse("M16251");
    }
    private DelegateCommand _trayToA1_ContinueCommand;
}
