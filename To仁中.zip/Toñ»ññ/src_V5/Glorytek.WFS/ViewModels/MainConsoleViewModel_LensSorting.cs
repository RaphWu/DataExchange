﻿using Glorytek.CSharp.Data;
using Glorytek.CSharp.IO;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.WFS;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using Glorytek.WPF.Extensions;
using Microsoft.Win32;
using MiniExcelLibs;
using Newtonsoft.Json;
using Prism.Commands;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Glorytek.WFS.ViewModels
{
    /********************
     * 主控頁的ViewModel - 分檢模式。
     ********************/
    public partial class MainConsoleViewModel
    {
        /// <summary>
        /// 啟始位置。
        /// </summary>
        public int StartPositionOfExcel
        {
            get { return _startPositionOfExcel; }
            set
            {
                SetProperty(ref _startPositionOfExcel, value);
                _wp.StartPositionOfExcel = value;
            }
        }
        private int _startPositionOfExcel = WfsParameters.Instance.StartPositionOfExcel;

        /// <summary>
        /// 數據比對提示。
        /// </summary>
        public bool ExcelDataTracking
        {
            get { return _excelDataTracking; }
            set { SetProperty(ref _excelDataTracking, value); }
        }
        private bool _excelDataTracking;

        /********************
         * Command
         ********************/
        ///// <summary>
        ///// 開啟點位選擇器。
        ///// </summary>
        //public DelegateCommand OpenTrayMatrixSelectorCommand
        //    => _openTrayMatrixSelectorCommand ??= new DelegateCommand(ExecuteOpenTrayMatrixSelectorCommand);
        //private void ExecuteOpenTrayMatrixSelectorCommand()
        //{
        //    if (_sdi.SystemMode != SystemOperateModeType.LensSorting)
        //        return;

        //    var lensSorting = _wfs.LensSortingList.Find(x => x.FunctionName == TrayFunctionType.Feeder);
        //    var tray = _tray.TrayList.Find(x => x.Id == lensSorting.TrayId);

        //    if (tray != null)
        //    {
        //        var tmsi = new TrayMatrixSelectorInfo
        //        {
        //            TrayId = tray.Id,
        //            PointNo = -1,
        //            SequenceNo = StartPositionOfExcel,
        //        };
        //        var paras = new DialogParameters()
        //        {
        //            {
        //                "StatusBarMessage",
        //                JsonConvert.SerializeObject(tmsi, new JsonSerializerSettings
        //                {
        //                    NullValueHandling = NullValueHandling.Ignore
        //                })
        //            }
        //        };

        //        IDialogResult _dialogResult = default;
        //        _dialog.ShowDialog(nameof(WFSComponents.Views.TrayMatrixSelector), paras, r => { _dialogResult = r; });

        //        if (_dialogResult.Result == ButtonResult.OK)
        //        {
        //            tmsi = JsonConvert.DeserializeObject<TrayMatrixSelectorInfo>(_dialogResult.Parameters.GetValue<string>("StatusBarMessage"));
        //            if (tmsi.SequenceNo >= 1)
        //            {
        //                StartPositionOfExcel = tmsi.SequenceNo;
        //                _tray.PalletList.Find(x => x.Id == lensSorting.Id).PickPointNo
        //                    = _tray.ConvertSequenceNoToPointNo(tray.Id, StartPositionOfExcel);
        //            }
        //        }
        //    }
        //}
        //private DelegateCommand _openTrayMatrixSelectorCommand;

        ///// <summary>
        ///// 啟始位置歸零。
        ///// </summary>
        //public DelegateCommand ResetExcelStartTo1Command
        //    => _resetExcelStartTo1Command ??= new DelegateCommand(ExecuteResetExcelStartTo1Command);
        //private void ExecuteResetExcelStartTo1Command()
        //{
        //    StartPositionOfExcel = 1;
        //}
        //private DelegateCommand _resetExcelStartTo1Command;

        ///// <summary>
        ///// 設定EXCEL比對啟始位置與入料托盤相同。
        ///// </summary>
        //public DelegateCommand SetExcelStartFromFeederTrayCommand
        //    => _setExcelStartFromFeederTrayCommand ??= new DelegateCommand(ExecuteSetExcelStartFromFeederTrayCommand);
        //private void ExecuteSetExcelStartFromFeederTrayCommand()
        //{
        //    try
        //    {
        //        var lensSorting = _wfs.LensSortingList.Find(x => x.FunctionName == TrayFunctionType.Feeder);
        //        var tray = _tray.TrayList.Find(x => x.Id == lensSorting.TrayId);
        //        int palletPointNo = _tray.PalletList.Find(x => x.Id == lensSorting.Id).PickPointNo;

        //        if (tray == null || palletPointNo == -1)
        //            throw new ArgumentException(GetResource.GetValue<string>("ErrorMessage_InvalidPointNoOrFeederError"));

        //        var profile = _tray.ProfileList.Find(x => x.TrayId == tray.Id && x.PointNo == palletPointNo);
        //        if (profile != null)
        //        {
        //            if (_prismMessageBox.Show($"目前設定值\n    啟始位置：{StartPositionOfExcel}\n    入料托盤：{palletPointNo}\n\nEXCEL比對啟始位置將變更為：{profile.SequenceNo}",
        //                                      "確定是否變更資料？",
        //                                      MessageBoxImage.Question,
        //                                      PrismMessageBoxButton.YesNo,
        //                                      ButtonResult.No) == ButtonResult.Yes)
        //            {
        //                StartPositionOfExcel = profile.SequenceNo;
        //            }
        //        }
        //    }
        //    catch (ArgumentException ae)
        //    {
        //        Log.Error(ae, ae.Message);
        //        _prismMessageBox.Show(ae.Message,
        //                              GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_OperationError"),
        //                              MessageBoxImage.Error,
        //                              PrismMessageBoxButton.OK);
        //    }
        //}
        //private DelegateCommand _setExcelStartFromFeederTrayCommand;

        ///// <summary>
        ///// 設定入料托盤啟始位置與EXCEL相同。
        ///// </summary>
        //public DelegateCommand SetFeederTrayStartFromExcelCommand
        //    => _setFeederTrayStartFromExcelCommand ??= new DelegateCommand(ExecuteSetFeederTrayStartFromExcelCommand);
        //private void ExecuteSetFeederTrayStartFromExcelCommand()
        //{
        //    try
        //    {
        //        var lensSorting = _wfs.LensSortingList.Find(x => x.FunctionName == TrayFunctionType.Feeder);
        //        var tray = _tray.TrayList.Find(x => x.Id == lensSorting.TrayId);
        //        var pallet = _tray.PalletList.Find(x => x.Id == lensSorting.Id);
        //        var profile = _tray.ProfileList.Find(x => x.TrayId == tray.Id && x.SequenceNo == StartPositionOfExcel);

        //        if (tray == null || pallet == null || profile == null)
        //            throw new ArgumentException(GetResource.GetValue<string>("ErrorMessage_InvalidPointNoOrFeederError"));

        //        if (_prismMessageBox.Show($"目前設定值\n    啟始位置：{StartPositionOfExcel}\n    入料托盤：{pallet.NextSequenceNo}\n\n入料托盤點位將變更為：{profile.PointNo}",
        //                                   "確定是否變更資料？",
        //                                   MessageBoxImage.Question,
        //                                   PrismMessageBoxButton.YesNo,
        //                                   ButtonResult.No) == ButtonResult.Yes)
        //        {
        //            pallet.PickPointNo = profile.PointNo;
        //            pallet.NextSequenceNo = _tray.ConvertPointNoToSequenceNo(tray.Id, profile.PointNo);
        //            _tray.WriteTrayToDb();
        //            _tray.WritePalletToPlc(pallet);
        //        }
        //    }
        //    catch (ArgumentException ae)
        //    {
        //        Log.Error(ae, ae.Message);
        //        _prismMessageBox.Show(ae.Message,
        //                              GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_OperationError"),
        //                              MessageBoxImage.Error,
        //                              PrismMessageBoxButton.OK);
        //    }
        //}
        //private DelegateCommand _setFeederTrayStartFromExcelCommand;

        /********************
         * 光學參數名稱
         ********************/
        /// <summary>
        /// 儲存檔名。
        /// </summary>
        private const string OpticalParamFileName = "OpticalParams.json";

        /// <summary>
        /// 光學參數名稱列表。
        /// </summary>
        private static Dictionary<OpticalParamId, List<string>> OpticalParamNames;

        // 搜尋LensNumber儲存格的範圍格數(從A1開始)
        private const int SEARCHING_HEIGHT = 10;

        /// <summary>
        /// 載入光學參數名稱列表。
        /// </summary>
        private void LoadOpticalParams()
        {
            if (File.Exists(Path.Combine(DBbase.Directory_Base, OpticalParamFileName)))
            {
                OpticalParamNames = JsonFileHelper.Read<Dictionary<OpticalParamId, List<string>>>(DBbase.Directory_Base, OpticalParamFileName);
            }
            else
            {
                OpticalParamNames = new Dictionary<OpticalParamId, List<string>>
                {
                    { OpticalParamId.LensNumber, new List<string> { "Index", "lensnumber" } },
                    { OpticalParamId.Decenter, new List<string> { "Decenter", "Decenter" } },
                    { OpticalParamId.DecenterX, new List<string> { "Decenter X", "Decenter_Xdir_um" } },
                    { OpticalParamId.DecenterY, new List<string> { "Decenter Y", "Decenter_Ydir_um" } },
                    { OpticalParamId.Coma, new List<string> { "Coma", "Coma_nm_RSS" } },
                    { OpticalParamId.Astigmatism, new List<string> { "Astigmatism", "Astigmatism_nm_RSS" } },
                    { OpticalParamId.Spherical, new List<string> { "SA", "Spherical_nm_RSS" } },
                    { OpticalParamId.Trefoil, new List<string> { "Trefoil", "Trefoil_nm_RSS" } }
                };
                JsonFileHelper.Save(DBbase.Directory_Base, OpticalParamFileName, OpticalParamNames, Formatting.Indented);
            }
        }

        /// <summary>
        /// 設定EXCEL檔案，儲存SheetNames。
        /// </summary>
        public DelegateCommand SetExcelFileNameCommand
            => _setExcelFileNameCommand ??= new DelegateCommand(ExecuteSetExcelFileNameCommand);
        private void ExecuteSetExcelFileNameCommand()
        {
            OpenFileDialog ofd = new()
            {
                InitialDirectory = DBbase.Directory_Base,
                Filter = GetResource.GetValue<string>("Caption_WfsDataFileFilter"),
                RestoreDirectory = true,
            };
            bool? result = ofd.ShowDialog();

            if (result == true)
            {
                WfsTraySource = null;
                ActiveWorkSheetName = "";

                // File Name
                _fullFileName = ofd.FileName;
                ExcelFileName = Path.GetFileName(_fullFileName);

                // Sheet params
                _wp.SheetSetting = new List<SheetSettingDefine>();
                List<string> sheetNames = MiniExcel.GetSheetNames(_fullFileName);
                foreach (string sheetName in sheetNames)
                {
                    (string startCell, Dictionary<OpticalParamId, string> opticalParamNameList)
                        = GetStartCell(_fullFileName, sheetName, SEARCHING_HEIGHT);
                    if (!string.IsNullOrEmpty(startCell))
                        _wp.SheetSetting.Add(new SheetSettingDefine()
                        {
                            SheetName = sheetName,
                            StartCell = startCell,
                            PalletPositionId = ITray.MaxPalletId,
                            OpticalParamNameList = opticalParamNameList,
                        });
                }
                SheetSetting = _wp.SheetSetting;
                MaxExcelLensNumber = 0;
                MinExcelLensNumber = 0;
            }
        }
        private DelegateCommand _setExcelFileNameCommand;

        /// <summary>
        /// 取得Sheet有效資料標題的每一個儲存格座標。
        /// </summary>
        /// <param name="fullFileName">EXCEL檔完整名稱。</param>
        /// <param name="sheetName">工作表名稱。</param>
        /// <param name="searchHeight">搜尋高度。</param>
        /// <returns>第一個儲存格座標。空字串=找不到。</returns>
        private (string, Dictionary<OpticalParamId, string>) GetStartCell(string fullFileName, string sheetName, int searchHeight)
        {
            string startCell = null;
            Dictionary<OpticalParamId, string> nameOffset = new()
            {
                { OpticalParamId.LensNumber, "" },
                { OpticalParamId.Decenter, "" },
                { OpticalParamId.DecenterX, "" },
                { OpticalParamId.DecenterY, "" },
                { OpticalParamId.Coma, "" },
                { OpticalParamId.Astigmatism, "" },
                { OpticalParamId.Spherical, "" },
                { OpticalParamId.Trefoil, "" },
            };

            var rows = MiniExcel.Query(fullFileName,
                                       sheetName: sheetName,
                                       excelType: ExcelType.XLSX,
                                       useHeaderRow: false).ToList();

            List<string> firstCellNames = OpticalParamNames[OpticalParamId.LensNumber];

            bool dataFound = false;
            for (int row = 0; row < searchHeight; row++)
            {
                if (dataFound)
                    break;

                if (rows[row] != null)
                {
                    var rowDatas = (rows[row] as IDictionary<string, object>).Values.ToList();

                    for (int nameIndex = 0; nameIndex < firstCellNames.Count; nameIndex++)
                    {
                        if (dataFound)
                            break;

                        int col = rowDatas.FindIndex(x => x != null && x.ToString() == firstCellNames[nameIndex]);
                        if (col >= 0)
                        {
                            startCell = $"{Convert.ToChar('A' + col)}{row + 1}";
                            nameOffset[OpticalParamId.LensNumber] = firstCellNames[nameIndex];

                            foreach (string paramName in OpticalParamNames[OpticalParamId.Decenter])
                            {
                                int offset = rowDatas.FindIndex(x => x != null && x.ToString() == paramName);
                                if (offset >= 0)
                                {
                                    nameOffset[OpticalParamId.Decenter] = paramName;
                                    break;
                                }
                            }

                            foreach (string paramName in OpticalParamNames[OpticalParamId.DecenterX])
                            {
                                int offset = rowDatas.FindIndex(x => x != null && x.ToString() == paramName);
                                if (offset >= 0)
                                {
                                    nameOffset[OpticalParamId.DecenterX] = paramName;
                                    break;
                                }
                            }

                            foreach (string paramName in OpticalParamNames[OpticalParamId.DecenterY])
                            {
                                int offset = rowDatas.FindIndex(x => x != null && x.ToString() == paramName);
                                if (offset >= 0)
                                {
                                    nameOffset[OpticalParamId.DecenterY] = paramName;
                                    break;
                                }
                            }

                            foreach (string paramName in OpticalParamNames[OpticalParamId.Coma])
                            {
                                int offset = rowDatas.FindIndex(x => x != null && x.ToString() == paramName);
                                if (offset >= 0)
                                {
                                    nameOffset[OpticalParamId.Coma] = paramName;
                                    break;
                                }
                            }

                            foreach (string paramName in OpticalParamNames[OpticalParamId.Astigmatism])
                            {
                                int offset = rowDatas.FindIndex(x => x != null && x.ToString() == paramName);
                                if (offset >= 0)
                                {
                                    nameOffset[OpticalParamId.Astigmatism] = paramName;
                                    break;
                                }
                            }

                            foreach (string paramName in OpticalParamNames[OpticalParamId.Spherical])
                            {
                                int offset = rowDatas.FindIndex(x => x != null && x.ToString() == paramName);
                                if (offset >= 0)
                                {
                                    nameOffset[OpticalParamId.Spherical] = paramName;
                                    break;
                                }
                            }

                            foreach (string paramName in OpticalParamNames[OpticalParamId.Trefoil])
                            {
                                int offset = rowDatas.FindIndex(x => x != null && x.ToString() == paramName);
                                if (offset >= 0)
                                {
                                    nameOffset[OpticalParamId.Trefoil] = paramName;
                                    break;
                                }
                            }

                            dataFound = nameOffset[OpticalParamId.LensNumber] != ""
                                && nameOffset[OpticalParamId.Decenter] != ""
                                && nameOffset[OpticalParamId.DecenterX] != ""
                                && nameOffset[OpticalParamId.DecenterY] != ""
                                && nameOffset[OpticalParamId.Coma] != ""
                                && nameOffset[OpticalParamId.Astigmatism] != ""
                                && nameOffset[OpticalParamId.Spherical] != ""
                                && nameOffset[OpticalParamId.Trefoil] != "";
                        }
                    }
                }
            }

            return dataFound ? (startCell, nameOffset) : ("", null);
        }

        /// <summary>
        /// 讀取Sheet Datas。
        /// </summary>
        public DelegateCommand ReadSheetDatasCommand
                    => _readSheetDatasCommand ??= new DelegateCommand(ExecuteReadSheetDatasCommand);
        private void ExecuteReadSheetDatasCommand()
        {
            if (SheetSettingSelected != null && !string.IsNullOrWhiteSpace(SheetSettingSelected.SheetName))
            {
                var rows = MiniExcel.Query(_fullFileName,
                                           sheetName: SheetSettingSelected.SheetName,
                                           excelType: ExcelType.XLSX,
                                           useHeaderRow: true,
                                           startCell: SheetSettingSelected.StartCell)
                                    .ToList();
                _wp.ExcelDatas = new List<MeasuringMachineDefine>();

                if (rows.Count > 0)
                {
                    foreach (var row in rows)
                    {
                        var rowData = row as IDictionary<string, object>;

                        if (int.TryParse(rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.LensNumber]].ToString(), out int lensNumber))
                        {
                            // 若該筆量測失敗，量測機的NG是標註在Coma欄位
                            var coma = rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.Coma]];
                            if (coma != null && double.TryParse(coma.ToString(), out double _))
                                _wp.ExcelDatas.Add(new MeasuringMachineDefine()
                                {
                                    LensNumber = lensNumber,
                                    Decenter = (double)rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.Decenter]],
                                    DecenterX = (double)rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.DecenterX]],
                                    DecenterY = (double)rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.DecenterY]],
                                    Coma = (double)rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.Coma]],
                                    Astigmatism = (double)rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.Astigmatism]],
                                    Spherical = (double)rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.Spherical]],
                                    Trefoil = (double)rowData[SheetSettingSelected.OpticalParamNameList[OpticalParamId.Trefoil]],
                                });
                            else
                                _wp.ExcelDatas.Add(new MeasuringMachineDefine()
                                {
                                    LensNumber = lensNumber,
                                    Decenter = 0.0,
                                    DecenterX = 0.0,
                                    DecenterY = 0.0,
                                    Coma = 0.0,
                                    Astigmatism = 0.0,
                                    Spherical = 0.0,
                                    Trefoil = 0.0,
                                });
                        }
                    }
                    //var dt = MiniExcel.QueryAsDataTable(_fullFileName,
                    //                                    sheetName: SheetNameSelected.SheetName,
                    //                                    useHeaderRow: true,
                    //                                    startCell: "A6");
                    //_wp.ExcelDatas = DataTableExtensions.DataTableToList<MeasuringMachineDefine>(dt);

                    foreach (var item in _wp.ExcelDatas)
                    {
                        item.Angle = Math.Atan2(item.DecenterY, item.DecenterX) * 180.0 / Math.PI;
                        if (item.Angle < 0)
                            item.Angle += 360.0;
                        item.Angle = item.Angle.Format(1);
                    }

                    MaxExcelLensNumber = _wp.ExcelDatas.Max(x => x.LensNumber);
                    MinExcelLensNumber = _wp.ExcelDatas.Min(x => x.LensNumber);
                }
                else
                {
                    MaxExcelLensNumber = 0;
                    MinExcelLensNumber = 0;
                }

                WfsTraySource = _wp.ExcelDatas;
                ActiveWorkSheetName = SheetSettingSelected.SheetName;
                StartingExcelLensNumber = MinExcelLensNumber;
            }
        }
        private DelegateCommand _readSheetDatasCommand;

        /// <summary>
        /// EXCEL檔直接轉換至大數據DB。
        /// </summary>
        public DelegateCommand TransToBigDataCommand
            => _transToBigDataCommand ??= new DelegateCommand(ExecuteTransToBigDataCommand);
        private void ExecuteTransToBigDataCommand()
        {
            _wfs.TransToBigData(_wfs.LensSortingList);

            //if (_prismMessageBox.ShowYesNo(GetResource.GetValue<string>("Message_TransToBigData"),
            //                               GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_FriendlyReminder"),
            //                               GetResource.GetValue<string>("Glorytek.WFSCore", "Button_ContinueOperate"),
            //                               GetResource.GetValue<string>("Glorytek.WFSCore", "Button_CancelOperate"),
            //                               MessageBoxImage.Information) != ButtonResult.Yes)
            //    return;

            //// 轉換
            //var trayFeeder = _wfs.LensSortingList.FindAll(x => x.FunctionName == TrayFunctionType.Feeder);
            //var trayClassified = _wfs.LensSortingList.FindAll(x => x.FunctionName == TrayFunctionType.Classified);
            //var trayRework = _wfs.LensSortingList.FindAll(x => x.FunctionName == TrayFunctionType.Rework);
            //if (trayFeeder.Count == 0 || trayClassified.Count == 0 || trayRework.Count == 0)
            //{
            //    _ = _prismMessageBox.Show("托盤設定數錯誤", MessageBoxImage.Error);
            //    return;
            //}

            //int idNo = 0;
            //string lotNumber = _wfs.GetNewLotNumber();
            //var now = DateTime.Now;

            //_wfs.SetNewLot();
            //var conn = _wd.ConnMeasurementData;
            //using var tran = conn.BeginTransaction();
            //try
            //{
            //    foreach (var data in _wp.ExcelDatas)
            //    {
            //        WfsGradeDefine grade = _wfs.GradeJudgement(data);
            //        var targetTray = grade.Id != -1 ? trayClassified.Find(x => x.GradeId == grade.Id) : trayRework[0];

            //        var newData = new MeasurementDataDefine()
            //        {
            //            Id = ++idNo,
            //            LotNumber = lotNumber,
            //            Time = now,
            //            Judgement = grade.Id != -1,
            //            Grade = grade.Id,
            //            GradeName = grade.Id != -1 ? grade.Name : "",

            //            LensNumber = data.LensNumber,
            //            Decenter = data.Decenter,
            //            DecenterX = data.DecenterX,
            //            DecenterY = data.DecenterY,
            //            Coma = data.Coma,
            //            Astigmatism = data.Astigmatism,
            //            Spherical = data.Spherical,
            //            Trefoil = data.Trefoil,
            //            Angle = data.Angle,

            //            SourcePalletNo = trayFeeder[0].Id,
            //            SourceTrayId = trayFeeder[0].TrayId,
            //            SourceTrayName = trayFeeder[0].TrayName,
            //            SourcePointNo = 1,
            //            TargetPalletNo = targetTray.Id,
            //            TargetTrayId = targetTray.TrayId,
            //            TargetTrayName = targetTray.TrayName,
            //            TargetPointNo = 1,
            //        };

            //        _ = conn.InsertAsync(newData);
            //        _wd.MeasurementDataList.Insert(0, newData);
            //    }
            //    tran.Commit();
            //    _ = _prismMessageBox.Show($"量測數據轉換完成，\n請轉至大數據頁面，選擇批號: {lotNumber}",
            //                              "轉換完成",
            //                              MessageBoxImage.Information);
            //}
            //catch
            //{
            //    tran.Rollback();
            //}
        }
        private DelegateCommand _transToBigDataCommand;

        /// <summary>
        /// 更新鏡片編號演算用差距值。
        /// </summary>
        private void LensNumberUpdated()
        {
            _wp.DiffLensNumber = StartingLensNumber - 1;
            _wp.DiffExcelLensNumber = StartingExcelLensNumber - 1;
        }

        /********************
         * Data
         ********************/
        /// <summary>
        /// UI顯示列表。
        /// </summary>
        public List<MeasuringMachineDefine> WfsTraySource
        {
            get { return _wfsTraySource; }
            set
            {
                SetProperty(ref _wfsTraySource, value);

                ExcelDataLoaded = value != null;
                RecoderOfExcel = ExcelDataLoaded ? value.Count : 0;
            }
        }
        private List<MeasuringMachineDefine> _wfsTraySource;

        /// <summary>
        /// EXCEL資料筆數。
        /// </summary>
        public int RecoderOfExcel
        {
            get { return _recoderOfExcel; }
            set { SetProperty(ref _recoderOfExcel, value); }
        }
        private int _recoderOfExcel;

        /// <summary>
        /// EXCEL表是否已載入。
        /// </summary>
        public bool ExcelDataLoaded
        {
            get { return _excelDataLoaded; }
            set { SetProperty(ref _excelDataLoaded, value); }
        }
        private bool _excelDataLoaded;

        /// <summary>
        /// EXCEL檔 Full FileName。
        /// </summary>
        private string _fullFileName = "";

        /// <summary>
        /// EXCEL檔名。
        /// </summary>
        public string ExcelFileName
        {
            get { return _excelFileName; }
            set { SetProperty(ref _excelFileName, value); }
        }
        private string _excelFileName;

        /// <summary>
        /// 讀入的工作表參數List。
        /// </summary>
        public List<SheetSettingDefine> SheetSetting
        {
            get { return _sheetNames; }
            set { SetProperty(ref _sheetNames, value); }
        }
        private List<SheetSettingDefine> _sheetNames;

        /// <summary>
        /// 選擇的工作表參數。
        /// </summary>
        public SheetSettingDefine SheetSettingSelected
        {
            get { return _sheetSettingSelected; }
            set { SetProperty(ref _sheetSettingSelected, value); }
        }
        private SheetSettingDefine _sheetSettingSelected;

        /// <summary>
        /// 選擇的工作表名稱(顯示用)。
        /// </summary>
        public string ActiveWorkSheetName
        {
            get { return _activeWorkSheetName; }
            set { SetProperty(ref _activeWorkSheetName, value); }
        }
        private string _activeWorkSheetName;

        /// <summary>
        /// 讀入的工作表資料中，最大的LensNumber。
        /// </summary>
        public int MaxExcelLensNumber
        {
            get { return _maxExcelLensNumber; }
            set { SetProperty(ref _maxExcelLensNumber, value); }
        }
        private int _maxExcelLensNumber;

        /// <summary>
        /// 讀入的工作表資料中，最小的LensNumber。
        /// </summary>
        public int MinExcelLensNumber
        {
            get { return _minExcelLensNumber; }
            set { SetProperty(ref _minExcelLensNumber, value); }
        }
        private int _minExcelLensNumber;

        /// <summary>
        /// 工作表資料中，第一筆資料的實際鏡片編號值。
        /// </summary>
        public int StartingExcelLensNumber
        {
            get { return _startingExcelLensNumber; }
            set { SetProperty(ref _startingExcelLensNumber, value); }
        }
        private int _startingExcelLensNumber = 1;

        /// <summary>
        /// 量測資料的啟始鏡片編號。
        /// </summary>
        public int StartingLensNumber
        {
            get { return _startingLensNumber; }
            set { SetProperty(ref _startingLensNumber, value); }
        }
        private int _startingLensNumber = 1;
    }
}
