﻿using Glorytek.WFSCore.Contracts;
using Glorytek.WPF.Extensions;
using Prism.Mvvm;
using Prism.Regions;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// Servo監看的ViewModel。
/// </summary>
public class ServoMonitorViewModel : BindableBase, INavigationAware
{
    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_ServoMonitor"));
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;

    public ServoMonitorViewModel(ISystemMessenger sysMessenger)
    {
        _sysMessenger = sysMessenger;
    }
}
