﻿using Glorytek.WPF.Extensions;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;

namespace Glorytek.WFS.ViewModels
{
    public class OPRViewModel : BindableBase, IDialogAware
    {
        public OPRViewModel()
        {
        }

        /********************
         * IDialogAware
         ********************/
        public string Title => GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_OPR");
        public bool ShowTitle => false;
        public event Action<IDialogResult> RequestClose;
        public bool CanCloseDialog() => true;
        public void OnDialogClosed() { }

        public DelegateCommand<object> CloseDialogCommand
            => _closeDialogCommand ??= new DelegateCommand<object>(CloseDialog);
        protected virtual void CloseDialog(object parameter)
        {
            RequestClose?.Invoke(null);
        }
        private DelegateCommand<object> _closeDialogCommand;

        public void OnDialogOpened(IDialogParameters parameters)
        {
        }
    }
}
