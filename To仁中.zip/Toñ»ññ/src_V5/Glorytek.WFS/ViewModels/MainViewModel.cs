﻿using Glorytek.WFSCore.Authority;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using System;

namespace Glorytek.WFS.ViewModels;

/// <summary>
/// 主控頁的ViewModel。
/// </summary>
public partial class MainViewModel : BindableBase, IConfirmNavigationRequest
{
    private IRegionNavigationService _navigationService;
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;

    /// <summary>
    /// 是否為主控頁第一次啟動；畫面載入後改為false。
    /// </summary>
    private static bool _isBooting = true;

    /// <summary>
    /// 記錄離開主控頁時的分頁。
    /// </summary>
    private static string _lastPageSelector = "";

    /********************
     * IConfirmNavigationRequest
     ********************/
    public void ConfirmNavigationRequest(NavigationContext navigationContext, Action<bool> continuationCallback)
    {
        bool result = true;

        _lastPageSelector = PageSelector;

        //if (!MachineDatas.Equals(SysParameters.Instance.Machine)
        //    || !Stage1A2.Equals(SysParameters.Instance.Stage)
        //    || !PalletPointEqual())
        //{
        //    MessageBoxResult userChoice = CommonFunctions.DataNotSavedWhenLeave();

        //    if (userChoice == MessageBoxResult.Yes)
        //        WriteData();
        //    else if (userChoice == MessageBoxResult.Cancel)
        //    {
        //        _sysMessenger.LightUpPreviousMainMenuButton("");
        //        result = false;
        //    }
        //}

        continuationCallback(result);
    }

    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        SwitchPage(_lastPageSelector);
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    ///********************
    // * IActiveAware & ApplicationCommands
    // ********************/
    //private bool _isActive = false;
    //public bool IsActive
    //{
    //    get { return _isActive; }
    //    set
    //    {
    //        _isActive = value;
    //        OnIsActiveChanged();
    //    }
    //}
    //public event EventHandler IsActiveChanged;
    //public DelegateCommand SaveDataCommand { get; private set; }
    //private void OnIsActiveChanged()
    //{
    //    SaveDataCommand.IsActive = IsActive;
    //    IsActiveChanged?.Invoke(this, new EventArgs());
    //}

    /********************
     * ctor
     ********************/
    private readonly IRegionManager _regionManager;
    private readonly IEventAggregator _ea;
    private readonly IAuthority _authority;

    public MainViewModel(IRegionManager regionManager, IEventAggregator ea, IAuthority authority)
    {
        _regionManager = regionManager;
        _ea = ea;
        _authority = authority;

        /********************
         * 程式啟動後要先跑一遍的程式可以放這邊
         ********************/
        if (_isBooting)
        {
            _isBooting = false;

            // 開機後自動登入的權限
            _authority.SwitchAuthorityToOperator();

            // 防顯示亂碼
            _sdi.ProductionStartTime = DateTime.Now;

            // 啟動系統時鐘
            SystemClockInit();

            _ea.GetEvent<PalletInfoChangedEvent>().Publish(false);
        }

        //// TODO: UnregisterCommand
        //SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        //applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /********************
     * System Commands
     ********************/
    /// <summary>
    /// 視窗載入。
    /// </summary>
    public DelegateCommand LoadedCommand
        => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
    private void ExecuteLoadedCommand()
    {
        _navigationService = _regionManager.Regions[RegionNames.MainPage].NavigationService;
        if (string.IsNullOrEmpty(PageSelector))
            PageSelector = PageKeys.MainConsole;
    }
    private DelegateCommand _loadedCommand;

    /********************
     * Database
     ********************/
    ///// <summary>
    ///// 將資料或參數寫入資料庫。
    ///// </summary>
    //public void ExecuteSaveDataCommand()
    //{
    //    //_tray.WriteToDb();
    //}

    /********************
     * Menu & Page
     ********************/
    /// <summary>
    /// 切換頁面。
    /// </summary>
    /// <param name="pageName">頁面名稱。</param>
    private void SwitchPage(string pageName)
    {
        _navigationService?.RequestNavigate(pageName);
    }

    /// <summary>
    /// 頁面切換。
    /// </summary>
    public string PageSelector
    {
        get { return _pageSelector; }
        set
        {
            SetProperty(ref _pageSelector, value);
            _navigationService.RequestNavigate(value);
        }
    }
    private string _pageSelector = "";
}
