﻿using Dapper.Contrib.Extensions;
using Glorytek.SQLite;
using Glorytek.WFSComponents.SerilogBrowser;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WPF.Extensions;
using Prism.Mvvm;
using Prism.Regions;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Data;

namespace Glorytek.WFS.ViewModels;

public class AbnormalHistoryReportViewModel : BindableBase, INavigationAware
{
    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_AbnormalHistory"));

        _sysMessenger.ShowProgressRing(true);
        Task.Run(() =>
        {
            //string thisMonth = DateTime.Now.ToString("yyyyMM");
            string thisMonth = "";
            using var conn = SQLiteHelper.OpenConnection(Path.Combine(DBbase.Directory_Base, "Logs"),
                                                         $"AbnormalHistory{thisMonth}{DBbase.DB_ExtFileName}");
            using var tran = conn.BeginTransaction();
            try
            {
                SerilogBrowserContent.Instance.ReportCollectionView
                    = CollectionViewSource.GetDefaultView(conn.GetAll<SerilogDefine>(transaction: tran)
                                                              .OrderByDescending(x => x.Timestamp));
                tran.Commit();
            }
            catch
            {
                tran.Rollback();
            }
        })
            .ContinueWith((c) =>
            {
                _sysMessenger.ShowProgressRing(false);
            }).Wait();
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;

    public AbnormalHistoryReportViewModel(ISystemMessenger sysMessenger)
    {
        _sysMessenger = sysMessenger;
    }
}
