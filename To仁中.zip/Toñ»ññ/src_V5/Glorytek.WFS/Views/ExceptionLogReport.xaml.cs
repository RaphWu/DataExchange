﻿using Glorytek.WFSComponents.Views;
using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for ExceptionLog
    /// </summary>
    public partial class ExceptionLogReport : UserControl
    {
        public ExceptionLogReport(RegionManager regionManager)
        {
            InitializeComponent();
            _ = regionManager.RegisterViewWithRegion(RegionNames.ExceptionLog, typeof(SerilogBrowser));
        }
    }
}
