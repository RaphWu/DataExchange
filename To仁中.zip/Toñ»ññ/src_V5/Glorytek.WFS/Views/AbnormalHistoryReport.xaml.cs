﻿using Glorytek.WFSComponents.Views;
using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for AbnormalHistoryReport
    /// </summary>
    public partial class AbnormalHistoryReport : UserControl
    {
        public AbnormalHistoryReport(RegionManager regionManager)
        {
            InitializeComponent();
            _ = regionManager.RegisterViewWithRegion(RegionNames.AbnormalHistory, typeof(SerilogBrowser));
        }
    }
}
