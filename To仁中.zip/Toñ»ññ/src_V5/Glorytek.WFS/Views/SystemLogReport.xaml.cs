﻿using Glorytek.WFSComponents.Views;
using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for SystemLogReport
    /// </summary>
    public partial class SystemLogReport : UserControl
    {
        public SystemLogReport(RegionManager regionManager)
        {
            InitializeComponent();
            _ = regionManager.RegisterViewWithRegion(RegionNames.SystemLog, typeof(SerilogBrowser));
        }
    }
}
