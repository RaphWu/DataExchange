﻿using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for MainConsole
    /// </summary>
    public partial class MainConsole : UserControl
    {
        public MainConsole()
        {
            InitializeComponent();
        }
    }
}
