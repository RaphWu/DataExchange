﻿using Glorytek.WFSCore.Events;
using Glorytek.WFSExternal.Views;
using MahApps.Metro.Controls;
using Prism.Events;
using Prism.Ioc;
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace Glorytek.WFS.Views;

/// <summary>
/// MainWindow.xaml 的互動邏輯。
/// </summary>
public partial class MainWindow : MetroWindow
{
    /********************
     * ctor
     ********************/
    private readonly IContainerProvider _container;
    private readonly IEventAggregator _ea;

    public MainWindow(IContainerProvider container, IEventAggregator ea)
    {
        InitializeComponent();

        _container = container;
        _ea = ea;
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
#if DEBUG
        WindowState = WindowState.Normal;
#else
        Topmost = true;
        WindowState = WindowState.Maximized;
        Left = 0.0;
        Top = 0.0;
        Width = System.Windows.SystemParameters.PrimaryScreenWidth;
        Height = System.Windows.SystemParameters.PrimaryScreenHeight;

        //窗口初始化後指定鉤子函數
        IntPtr hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
        System.Windows.Interop.HwndSource.FromHwnd(hwnd).AddHook(new System.Windows.Interop.HwndSourceHook(WndProc));

        IntPtr handle = new System.Windows.Interop.WindowInteropHelper(this).Handle;
        IntPtr hmenu = GetSystemMenu(handle, 0);
        int cnt = GetMenuItemCount(hmenu);
        for (int i = cnt - 1; i >= 0; i--)
        {
            StringBuilder tmpstr = new StringBuilder(100);
            GetMenuString(hmenu, (uint)i, tmpstr, 255, MF_DISABLED | MF_BYPOSITION);
            if (tmpstr.ToString().Contains("移動"))
            {
                RemoveMenu(hmenu, i, MF_DISABLED | MF_BYPOSITION);
            }
        }
#endif
    }

#if !DEBUG
    /********************
     * 鉤子函數的實現
     * https://blog.51cto.com/u_15296600/3007753
     ********************/
    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        // 攔截標題欄雙擊和窗口移動事件
        if (msg == 0x00A3 || msg == 0x0003 || wParam == (IntPtr)0xF012)
        {
            handled = true;
            wParam = IntPtr.Zero;
        }
        return IntPtr.Zero;
    }

    [DllImport("user32.dll", EntryPoint = "GetSystemMenu")]
    private static extern IntPtr GetSystemMenu(IntPtr hwnd, int revert);

    [DllImport("user32.dll", EntryPoint = "RemoveMenu")]
    private static extern int RemoveMenu(IntPtr hmenu, int npos, int wflags);

    [DllImport("user32.dll", EntryPoint = "GetMenuItemCount")]
    private static extern int GetMenuItemCount(IntPtr hmenu);

    [DllImport("user32.dll", EntryPoint = "GetMenuStringW", CharSet = CharSet.Unicode)]
    private static extern int GetMenuString(IntPtr hMenu, uint uIDItem, StringBuilder lpString, int cchMax, uint flags);

    // 鍵值
    private const int MF_BYPOSITION = 0x0400;
    private const int MF_DISABLED = 0x0002;
#endif

    /********************
     * 彈出視窗
     ********************/
    /// <summary>
    /// TeachingBox
    /// </summary>
    private void TeachingBoxClick(object sender, RoutedEventArgs e)
    {
        TeachingBox _teachingBox = _container.Resolve<TeachingBox>();
        _teachingBox.Owner = this;

        if (_teachingBox.IsVisible)
            _teachingBox.Hide();
        else
            _teachingBox.Show();
    }

    /********************
     * 輸入裝置idle偵測
     ********************/
    private void KeyDownDetector(object sender, KeyEventArgs e)
    {
        // 因主頁面無法從IoC取得ISystem，故改用IEventAggregator
        _ea.GetEvent<ResetInputDetectorTimerEvent>().Publish(-1);
    }

    private void MouseMoveDetector(object sender, MouseEventArgs e)
    {
        _ea.GetEvent<ResetInputDetectorTimerEvent>().Publish(-1);
    }
}
