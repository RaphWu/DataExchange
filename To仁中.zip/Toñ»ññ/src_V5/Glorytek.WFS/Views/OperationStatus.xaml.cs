﻿using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for OperationStatus
    /// </summary>
    public partial class OperationStatus : UserControl
    {
        public OperationStatus()
        {
            InitializeComponent();
        }
    }
}
