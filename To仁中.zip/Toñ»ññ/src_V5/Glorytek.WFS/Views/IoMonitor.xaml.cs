﻿using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for IoMonitor
    /// </summary>
    public partial class IoMonitor : UserControl
    {
        public IoMonitor()
        {
            InitializeComponent();
        }
    }
}
