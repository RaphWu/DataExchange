﻿using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for OPR
    /// </summary>
    public partial class OPR : UserControl
    {
        public OPR(IRegionManager regionManager)
        {
            InitializeComponent();
            _ = regionManager.RegisterViewWithRegion(RegionNames.OPRWindow, typeof(WFSExternal.Views.OriginalPointReturn));
        }
    }
}
