﻿using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for ServoMonitor
    /// </summary>
    public partial class ServoMonitor : UserControl
    {
        public ServoMonitor()
        {
            InitializeComponent();
        }
    }
}
