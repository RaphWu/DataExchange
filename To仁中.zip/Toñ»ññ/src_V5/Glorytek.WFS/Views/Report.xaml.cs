﻿using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for Report
    /// </summary>
    public partial class Report : UserControl
    {
        public Report()
        {
            InitializeComponent();
        }
    }
}
