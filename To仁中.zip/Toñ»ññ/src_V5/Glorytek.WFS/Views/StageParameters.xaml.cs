﻿using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for StageParameters
    /// </summary>
    public partial class StageParameters : UserControl
    {
        public StageParameters()
        {
            InitializeComponent();
        }
    }
}
