﻿using System.Windows.Controls;

namespace Glorytek.WFS.Views
{
    /// <summary>
    /// Interaction logic for PalletParameters
    /// </summary>
    public partial class PalletParameters : UserControl
    {
        public PalletParameters()
        {
            InitializeComponent();
        }
    }
}
