﻿using Glorytek.CSharp.Data.Coordinate;
using Glorytek.WFSComponents.Stage.Contracts;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WPF.Extensions;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;

/// <summary>
/// 手動頁面的ViewModel。
/// </summary>
public class ManualViewModel : BindableBase, INavigationAware
{
    private readonly PointXYZ _dp;

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_Manual"));

        CoorSafetyHeightLine = 150.0;
        CoorSafetyHeightLable = CoorSafetyHeightLine + 95.0;
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IMachine _machine;
    private readonly IStage _stage;
    private readonly IPlc _plc;

    public ManualViewModel(ISystemMessenger sysMessenger,
                           IMachine machine,
                           IStage stage,
                           IPlc plc)
    {
        _sysMessenger = sysMessenger;
        _machine = machine;
        _stage = stage;
        _plc = plc;

        RAxisAngle = 0.0;
        _dp = new PointXYZ(_machine.Machine.DatumPointX,
                           _machine.Machine.DatumPointY,
                           _machine.Machine.DatumPointZ + _machine.Machine.HeightCorrection);
    }

    /********************
     * Z軸
     ********************/
    public double CoorSafetyHeightLine
    {
        get { return _coorSafetyHeightLine; }
        set { SetProperty(ref _coorSafetyHeightLine, value); }
    }
    private double _coorSafetyHeightLine;

    public double CoorSafetyHeightLable
    {
        get { return _coorSafetyHeightLable; }
        set { SetProperty(ref _coorSafetyHeightLable, value); }
    }
    private double _coorSafetyHeightLable;

    /********************
     * R軸
     ********************/
    //private DelegateCommand _rAxisPlusCommand;
    //public DelegateCommand RAxisPlusCommand =>
    //    _rAxisPlusCommand
    //
    //    (_rAxisPlusCommand = new DelegateCommand(ExecuteRAxisPlusCommand));
    //void ExecuteRAxisPlusCommand()
    //{
    //    double angle = RAxisAngle + 15.0;
    //    if (angle >= 360.0)
    //        angle -= 360.0;
    //    RAxisAngle = angle;
    //}

    //private DelegateCommand _rAxisMinusCommand;
    //public DelegateCommand RAxisMinusCommand =>
    //    _rAxisMinusCommand ?? (_rAxisMinusCommand = new DelegateCommand(ExecuteRAxisMinusCommand));
    //void ExecuteRAxisMinusCommand()
    //{
    //    double angle = RAxisAngle - 15.0;
    //    if (angle < 0.0)
    //        angle += 360.0;
    //    RAxisAngle = angle;
    //}

    /// <summary>
    /// R軸角度更新事件。
    /// </summary>
    public DelegateCommand<string> RAxisAngleUpdatedCommand
        => _rAxisAngleUpdatedCommand ??= new DelegateCommand<string>(ExecuteRAxisAngleUpdatedCommand);
    private void ExecuteRAxisAngleUpdatedCommand(string strAngle)
    {
        RAxisAngle = double.Parse(strAngle);
    }
    private DelegateCommand<string> _rAxisAngleUpdatedCommand;

    /// <summary>
    /// R軸角度。
    /// </summary>
    public double RAxisAngle
    {
        get { return _rAxisAngle; }
        set
        {
            SetProperty(ref _rAxisAngle, value);

            double rad = (value + 90.0) % 360.0 * Math.PI / 180.0;
            RAxisX2 = pointerLength - pointerLength * Math.Cos(rad) + 8.0;
            RAxisY2 = pointerLength - pointerLength * Math.Sin(rad) + 12.0;
        }
    }
    private double _rAxisAngle;
    private const double pointerLength = 48.0;

    /// <summary>
    /// 指針X座標。
    /// </summary>
    public double RAxisX2
    {
        get { return _rAxisX2; }
        set { SetProperty(ref _rAxisX2, value); }
    }
    private double _rAxisX2;

    /// <summary>
    /// 指針Y座標。
    /// </summary>
    public double RAxisY2
    {
        get { return _rAxisY2; }
        set { SetProperty(ref _rAxisY2, value); }
    }
    private double _rAxisY2;

    /********************
     * 移動
     ********************/
    /// <summary>
    /// 相機移動至基準點。
    /// </summary>
    public DelegateCommand MoveToDatumPointCommand
    {
        get
        {
            DelegateCommand delegateCommand = _moveToDatumPointCommand ??= new DelegateCommand(ExecuteMoveToDatumPointCommand);
            return delegateCommand;
        }
    }
    private async void ExecuteMoveToDatumPointCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                              _machine.Machine.DatumPointX,
                              _machine.Machine.DatumPointY,
                              0.0);
    }
    private DelegateCommand _moveToDatumPointCommand;

    /// <summary>
    /// 相機移動至黏土座。
    /// </summary>
    public DelegateCommand MoveCameraToClayTableCommand
        => _moveCameraToClayTableCommand ??= new DelegateCommand(ExecuteMoveCameraToClayTableCommand);
    private async void ExecuteMoveCameraToClayTableCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                              _machine.Machine.ClayTableX + _dp.X,
                              _machine.Machine.ClayTableY + _dp.Y,
                              0.0);
    }
    private DelegateCommand _moveCameraToClayTableCommand;

    /// <summary>
    /// 吸嘴移動至黏土座。
    /// </summary>
    public DelegateCommand MoveNozzleToClayTableCommand
        => _moveNozzleToClayTableCommand ??= new DelegateCommand(ExecuteMoveNozzleToClayTableCommand);
    private async void ExecuteMoveNozzleToClayTableCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                              _machine.Machine.NozzleStampX + _dp.X,
                              _machine.Machine.NozzleStampY + _dp.Y,
                              0.0);
    }
    private DelegateCommand _moveNozzleToClayTableCommand;

    /// <summary>
    /// 相機移動至位移計。
    /// </summary>
    public DelegateCommand MoveToDisplacementCommand
        => _moveToDisplacementCommand ??= new DelegateCommand(ExecuteMoveToDisplacementCommand);
    private async void ExecuteMoveToDisplacementCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                              _machine.Machine.DisplacementX + _dp.X,
                              _machine.Machine.DisplacementY + _dp.Y,
                              0.0);
    }
    private DelegateCommand _moveToDisplacementCommand;

    /// <summary>
    /// 相機移動至A1。
    /// </summary>
    public DelegateCommand MoveToStage1Command
        => _moveToStage1Command ??= new DelegateCommand(ExecuteMoveToStage1Command);
    private async void ExecuteMoveToStage1Command()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                _stage.Stages[0].CoorX + _dp.X,
                                _stage.Stages[0].CoorY + _dp.Y,
                                0.0);
    }
    private DelegateCommand _moveToStage1Command;

    /// <summary>
    /// 相機移動至A2。
    /// </summary>
    public DelegateCommand MoveToStage2Command
        => _moveToStage2Command ??= new DelegateCommand(ExecuteMoveToStage2Command);
    private async void ExecuteMoveToStage2Command()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                _stage.Stages[1].CoorX + _dp.X,
                                _stage.Stages[1].CoorY + _dp.Y,
                                0.0);
    }
    private DelegateCommand _moveToStage2Command;

    /********************
     * Cylinder
     ********************/
    /// <summary>
    /// Cylinder1移至分檢機側。
    /// </summary>
    public DelegateCommand Cylinder1MoveToSortingCommand
        => _cylinder1MoveToSortingCommand ??= new DelegateCommand(ExecuteCylinder1MoveToSortingCommand);
    private void ExecuteCylinder1MoveToSortingCommand()
    {
        _plc.SendCommandPulse(DeviceLists.CYLINDER_1_MOVETO_SORTING_COMMAND);
    }
    private DelegateCommand _cylinder1MoveToSortingCommand;

    /// <summary>
    /// Cylinder1移至量測機側。
    /// </summary>
    public DelegateCommand Cylinder1MoveToMeasurementCommand
        => _cylinder1MoveToMeasurementCommand ??= new DelegateCommand(ExecuteCylinder1MoveToMeasurementCommand);
    private void ExecuteCylinder1MoveToMeasurementCommand()
    {
        _plc.SendCommandPulse(DeviceLists.CYLINDER_1_MOVETO_MEASUREMENT_COMMAND);
    }
    private DelegateCommand _cylinder1MoveToMeasurementCommand;

    /// <summary>
    /// Cylinder2移至分檢機側。
    /// </summary>
    public DelegateCommand Cylinder2MoveToSortingCommand
        => _cylinder2MoveToSortingCommand ??= new DelegateCommand(ExecuteCylinder2MoveToSortingCommand);
    private void ExecuteCylinder2MoveToSortingCommand()
    {
        _plc.SendCommandPulse(DeviceLists.CYLINDER_2_MOVETO_SORTING_COMMAND);
    }
    private DelegateCommand _cylinder2MoveToSortingCommand;

    /// <summary>
    /// Cylinder2移至量測機側。
    /// </summary>
    public DelegateCommand Cylinder2MoveToMeasurementCommand
        => _cylinder2MoveToMeasurementCommand ??= new DelegateCommand(ExecuteCylinder2MoveToMeasurementCommand);
    private void ExecuteCylinder2MoveToMeasurementCommand()
    {
        _plc.SendCommandPulse(DeviceLists.CYLINDER_2_MOVETO_MEASUREMENT_COMMAND);
    }
    private DelegateCommand _cylinder2MoveToMeasurementCommand;

    /********************
     * 氣壓
     ********************/
    /// <summary>
    /// R軸真空。
    /// </summary>
    public DelegateCommand NozzleVaccumToggleCommand
        => _nozzleVaccumToggleCommand ??= new DelegateCommand(ExecuteNozzleVaccumToggleCommand);
    private void ExecuteNozzleVaccumToggleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.NOZZLE_VACCUM_COMMAND);
    }
    private DelegateCommand _nozzleVaccumToggleCommand;

    /// <summary>
    /// R軸破真空。
    /// </summary>
    public DelegateCommand NozzleReliefToggleCommand
        => _nozzleReliefToggleCommand ??= new DelegateCommand(ExecuteNozzleReliefToggleCommand);
    private void ExecuteNozzleReliefToggleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.NOZZLE_RELIEF_COMMAND);
    }
    private DelegateCommand _nozzleReliefToggleCommand;

    /// <summary>
    /// Stage1真空。
    /// </summary>
    public DelegateCommand Stage1VaccumToggleCommand
        => _stage1VaccumToggleCommand ??= new DelegateCommand(ExecuteStage1VaccumToggleCommand);
    private void ExecuteStage1VaccumToggleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.STAGE_1_VACCUM_COMMAND);
    }
    private DelegateCommand _stage1VaccumToggleCommand;

    /// <summary>
    /// Stage1破真空。
    /// </summary>
    public DelegateCommand Stage1ReliefToggleCommand
        => _stage1ReliefToggleCommand ??= new DelegateCommand(ExecuteStage1ReliefToggleCommand);
    private void ExecuteStage1ReliefToggleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.STAGE_1_RELIEF_COMMAND);
    }
    private DelegateCommand _stage1ReliefToggleCommand;

    /// <summary>
    /// Stage2真空。
    /// </summary>
    private DelegateCommand _stage2VaccumToggleCommand;
    public DelegateCommand Stage2VaccumToggleCommand
        => _stage2VaccumToggleCommand ??= new DelegateCommand(ExecuteStage2VaccumToggleCommand);
    private void ExecuteStage2VaccumToggleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.STAGE_2_VACCUM_COMMAND);
    }

    /// <summary>
    /// Stage2破真空。
    /// </summary>
    private DelegateCommand _stage2ReliefToggleCommand;
    public DelegateCommand Stage2ReliefToggleCommand
        => _stage2ReliefToggleCommand ??= new DelegateCommand(ExecuteStage2ReliefToggleCommand);
    private void ExecuteStage2ReliefToggleCommand()
    {
        _plc.SendCommandPulse(DeviceLists.STAGE_2_RELIEF_COMMAND);
    }

    /********************
     * IO
     ********************/
    /// <summary>
    /// 靜電消除器開關。
    /// </summary>
    public DelegateCommand SwitchIonotronCommand
        => _switchIonotronCommand ??= new DelegateCommand(ExecuteSwitchIonotronCommand);
    private void ExecuteSwitchIonotronCommand()
    {
        if (_plc.Online)
            _plc.WriteBool(DeviceLists.IONOTRON, !PlcDatas.Instance.Ionotron);
    }
    private DelegateCommand _switchIonotronCommand;

    /// <summary>
    /// 照明開關。
    /// </summary>
    public DelegateCommand SwitchLightsCommand
        => _switchLightsCommand ??= new DelegateCommand(ExecuteSwitchLightsCommand);
    private void ExecuteSwitchLightsCommand()
    {
        _plc.SendCommandPulse(DeviceLists.LIGHTS_COMMAND);
    }
    private DelegateCommand _switchLightsCommand;
}
