﻿using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.ProductManager;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using System;
using System.Threading.Tasks;
using System.Windows;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 
/// </summary>
public class SystemSettingViewModel : BindableBase, INavigationAware, IActiveAware
{
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
        WriteData();
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    private bool _isActive = false;
    public bool IsActive
    {
        get { return _isActive; }
        set
        {
            _isActive = value;
            OnIsActiveChanged();
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly ISystemMessenger _sysMessenger;
    private readonly ISystem _sys;
    private readonly IMachine _machine;
    private readonly IPlc _plc;

    public SystemSettingViewModel(IApplicationCommands applicationCommands,
                                  IEventAggregator ea,
                                  IPrismMessageBox prismMessageBox,
                                  ISystemMessenger sysMessenger,
                                  ISystem sys,
                                  IMachine machine,
                                  IPlc plc)
    {
        _ea = ea;
        _prismMessageBox = prismMessageBox;
        _sysMessenger = sysMessenger;
        _sys = sys;
        _machine = machine;
        _plc = plc;

        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /// <summary>
    /// 視窗載入。
    /// </summary>
    public DelegateCommand LoadedCommand
        => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
    private void ExecuteLoadedCommand()
    {
        _sysMessenger.StatusBarMessage(string.Join(" - ", new[] {
                GetResource.GetValue<string>("PageTitle_SettingsPage"),
                GetResource.GetValue<string>("TabItem_SystemSetting_System")
            }));
    }
    private DelegateCommand _loadedCommand;

    /********************
    * 數據處理
    ********************/
    /// <summary>
    /// 
    /// </summary>
    private void ExecuteSaveDataCommand()
    {
        WriteData();
    }

    /// <summary>
    /// 將View資料寫入Model及資料庫。
    /// </summary>
    public void WriteData()
    {
        _sys.WriteToDb();
        _machine.WriteToPlc();
        _plc.WriteToPlc();
    }

    /********************
     * System
     ********************/
    /// <summary>
    /// 切換系統模式命令。
    /// </summary>
    public DelegateCommand<object> SwitchSystemModeCommand
        => _switchSystemModeCommand ??= new DelegateCommand<object>(ExecuteSwitchSystemModeCommand);
    private void ExecuteSwitchSystemModeCommand(object sysMode)
    {
        SystemOperateModeType mode = (SystemOperateModeType)sysMode;
        _plc.SetSystemMode(mode);

        // 切換系統模式後，更新一次點位及Pallet
        if (ProductDatas.Instance.IsProductActive)
        {
            _plc.WaitForPollingCycleCompleted();
            Task.Delay(800).Wait(); // 因切換系統模式是由PLC執行，目前PLC沒有回饋切換完成的信號，故使用延遲時間來確認PLC切換完成。
            _ea.GetEvent<WriteNewPointNoEvent>().Publish(0);
            //_ea.GetEvent<PalletInfoChangedEvent>().Publish(true);
        }
    }
    private DelegateCommand<object> _switchSystemModeCommand;

    /// <summary>
    /// 開機時間歸零命令。
    /// </summary>
    public DelegateCommand ResetSystemClockCommand
        => _resetSystemClockCommand ??= new DelegateCommand(ExecuteResetSystemClockCommand);
    private void ExecuteResetSystemClockCommand()
    {
        if (_prismMessageBox.ShowOKCancel("確定要將開機時間歸零嗎？", "動作確認", MessageBoxImage.Question, "歸零", "取消") == ButtonResult.Yes)
        {
            _sdi.MachineResetTime = DateTime.Now;
            _sdi.MachineRuningTime = DateTime.Now;
            _ = _sys.WriteToDb();
        }
    }
    private DelegateCommand _resetSystemClockCommand;
}
