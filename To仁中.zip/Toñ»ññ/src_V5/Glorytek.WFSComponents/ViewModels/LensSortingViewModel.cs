﻿using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WPF.Extensions;
using Prism;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 分料模式頁面的ViewModel。
/// </summary>
public class LensSortingViewModel : BindableBase, IConfirmNavigationRequest, IActiveAware
{
    private static int _thisPalletId = -1;
    private static int _thisTrayId = -1;

    /********************
     * IConfirmNavigationRequest
     ********************/
    public void ConfirmNavigationRequest(NavigationContext navigationContext, Action<bool> continuationCallback)
    {
        bool result = true;

        foreach (var item in PalletListsOrderByFunc)
        {
            if (!item.Equals(_wfs.LensSortingList.Find(x => x.Id == item.Id)))
            {
                ButtonResult userChoice = _sys.DataNotSavedWhenLeave(showCancelButton: true);

                if (userChoice == ButtonResult.Yes)
                {
                    WriteToDb();
                }
                else if (userChoice == ButtonResult.Cancel)
                {
                    //_sysMessenger.LightUpPreviousMainMenuButton(string.Empty); // (棄用)
                    result = false;
                }

                break;
            }
        }

        continuationCallback(result);
    }

    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        int lastPalletId = _thisPalletId;

        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_PalletSorting"));
        LoadData();

        if (lastPalletId > 0)
            PalletSelectedItem = _wfs.LensSortingList.Find(x => x.Id == lastPalletId);
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
        _wfs.LensSortingList = PalletListsOrderById.ToList();
        WriteToDb();
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    private bool _isActive = false;
    public bool IsActive
    {
        get { return _isActive; }
        set
        {
            _isActive = value;
            OnIsActiveChanged();
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly ISystem _sys;
    private readonly ISystemMessenger _sysMessenger;
    private readonly ITray _tray;
    private readonly IWfs _wfs;

    public LensSortingViewModel(IApplicationCommands applicationCommands,
                                IEventAggregator ea,
                                ISystem sys,
                                ISystemMessenger sysMessenger,
                                ITray tray,
                                IWfs wfs)
    {
        _ea = ea;
        _sys = sys;
        _sysMessenger = sysMessenger;
        _tray = tray;
        _wfs = wfs;

        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 將資料或參數寫入資料庫。
    /// </summary>
    public void ExecuteSaveDataCommand()
    {
        WriteToDb();
    }

    /// <summary>
    /// 寫入資料庫。
    /// </summary>
    public void WriteToDb()
    {
        if (DataValidation())
        {
            _wfs.LensSortingList = PalletListsOrderById.ToList();
            _wfs.WriteToDb();
            _ea.GetEvent<WriteNewPointNoEvent>().Publish(0);
            //_ea.GetEvent<PalletInfoChangedEvent>().Publish(true);
        }
    }

    /// <summary>
    /// 讀取資料庫。
    /// </summary>
    public void LoadData()
    {
        TraySelector = _tray.TraySelector(true);
        WfsGradeSelector = _wfs.GradeSelector(true);

        UpdateSource();
    }

    /********************
     * Data
     ********************/
    /// <summary>
    /// 參數有效性檢查。
    /// </summary>
    /// <returns>檢查通過=true。</returns>
    private bool DataValidation() => _wfs.ConditionCheckAndWriteToPlc(false, PalletListsOrderById.ToList());

    /// <summary>
    /// 更新右側表格式資料來源。
    /// </summary>
    private void UpdatePalletSortingListsOrderById()
    {
        PalletListsOrderById = new ObservableCollection<LensSortingDefine>(_wfs.LensSortingList.OrderBy(e => e.Id));
    }

    /// <summary>
    /// 更新左側直式資料來源。
    /// </summary>
    private void UpdatePalletSortingListsOrderByFunc()
    {
        PalletListsOrderByFunc = new ObservableCollection<LensSortingDefine>(_wfs.LensSortingList
            .FindAll(x => x.FunctionName != TrayFunctionType.Unused)
            .OrderByDescending(e => e.FunctionId)
            .ThenBy(e => e.Id));

        var judgementList = new List<int>();
        foreach (var item in PalletListsOrderByFunc)
            if (item.FunctionName == TrayFunctionType.Classified && item.GradeId >= 0)
                judgementList.Add(item.GradeId);
        WfsParameters.Instance.JudgementLists = judgementList;
    }

    /// <summary>
    /// 更新全部資料來源。
    /// </summary>
    private void UpdateSource()
    {
        UpdatePalletSortingListsOrderById();
        UpdatePalletSortingListsOrderByFunc();
    }

    /********************
     * Property Changed
     ********************/
    /// <summary>
    /// 用途選擇變更時的動作。
    /// </summary>
    public DelegateCommand PalletFuntionChangedCommand
        => _palletFuntionChangedCommand ??= new DelegateCommand(ExecutePalletFuntionChangedCommand);
    private void ExecutePalletFuntionChangedCommand()
    {
        UpdatePalletSortingListsOrderByFunc();
    }
    private DelegateCommand _palletFuntionChangedCommand;

    /// <summary>
    /// 更新Tray矩陣顯示。
    /// </summary>
    public DelegateCommand RefreshTrayMatrixSourceCommand
        => _refreshTrayMatrixSourceCommand ??= new DelegateCommand(ExecuteRefreshTrayMatrixCommand);
    private void ExecuteRefreshTrayMatrixCommand()
    {
        UpdatePalletSortingListsOrderByFunc();
        UpdateTrayMatrixSource();
    }
    private DelegateCommand _refreshTrayMatrixSourceCommand;

    /// <summary>
    /// 更新Tray矩陣顯示。
    /// </summary>
    private void UpdateTrayMatrixSource()
    {
        ButtonEnabled = TrayEffective && SystemDataInstance.Instance.SystemStabilized;

        if (_thisPalletId >= 0)
        {
            // 見 TrayMatrix.xaml.cs 中 ThisTray_PropertyChanged() 的註解 <see cref="TrayMatrix.TrayMatrix()"/>
            TrayMatrixRegionContext tmrc = new()
            {
                Tray = _tray.TrayList.Find(x => x.Id == _thisTrayId),
                PalletId = _thisPalletId
            };
            TrayMatrixSource = null;
            TrayMatrixSource = tmrc;
        }
    }

    /********************
     * TrayMatrix
     ********************/
    /// <summary>
    /// 傳遞給TrayMatrix的資料。
    /// </summary>
    public TrayMatrixRegionContext TrayMatrixSource
    {
        get { return _trayMatrixSource; }
        set { SetProperty(ref _trayMatrixSource, value); }
    }
    private TrayMatrixRegionContext _trayMatrixSource;

    /********************   
     * Tray Source
     ********************/
    /// <summary>
    /// 左側依功能排序的直式列表。
    /// </summary>
    public ObservableCollection<LensSortingDefine> PalletListsOrderByFunc
    {
        get { return _palletListsOrderByFunc; }
        set { SetProperty(ref _palletListsOrderByFunc, value); }
    }
    private ObservableCollection<LensSortingDefine> _palletListsOrderByFunc;

    /// <summary>
    /// 右側依Pallet ID排序的表格式列表。
    /// </summary>
    public ObservableCollection<LensSortingDefine> PalletListsOrderById
    {
        get { return _palletListsOrderById; }
        set { SetProperty(ref _palletListsOrderById, value); }
    }
    private ObservableCollection<LensSortingDefine> _palletListsOrderById;

    /// <summary>
    /// 選擇的Pallet ID。
    /// </summary>
    public LensSortingDefine PalletSelectedItem
    {
        get { return _palletSelectedItem; }
        set
        {
            SetProperty(ref _palletSelectedItem, value);

            _thisPalletId = value != null ? value.Id : -1;
            _thisTrayId = value != null ? value.TrayId : -1;
            ScreenEnabled = value != null && value.FunctionId > 0 && value.TrayId > 0;

            UpdateTrayMatrixSource();
        }
    }
    private LensSortingDefine _palletSelectedItem;

    /// <summary>
    /// 分頁切換。
    /// </summary>
    public TabItem TrayTabSelection
    {
        get { return _trayTabSelection; }
        set { SetProperty(ref _trayTabSelection, value); }
    }
    private TabItem _trayTabSelection;

    // 啟用
    public bool ScreenEnabled
    {
        get { return _screenEnabled; }
        set { SetProperty(ref _screenEnabled, value); }
    }
    private bool _screenEnabled;

    public bool TrayEffective
    {
        get { return _trayEffective; }
        set { SetProperty(ref _trayEffective, value); }
    }
    private bool _trayEffective;

    public bool ButtonEnabled
    {
        get { return _buttonEnabled; }
        set { SetProperty(ref _buttonEnabled, value); }
    }
    private bool _buttonEnabled;

    /********************
     * ComboBox Source
     ********************/
    /// <summary>
    /// Tray選擇來源。
    /// </summary>
    public Dictionary<int, string> TraySelector
    {
        get { return _traySelector; }
        set { SetProperty(ref _traySelector, value); }
    }
    private Dictionary<int, string> _traySelector;

    /// <summary>
    /// 規格選擇來源。
    /// </summary>
    public Dictionary<int, string> WfsGradeSelector
    {
        get { return _wfsGradeSelector; }
        set { SetProperty(ref _wfsGradeSelector, value); }
    }
    private Dictionary<int, string> _wfsGradeSelector;
}
