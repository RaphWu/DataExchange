﻿using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Views;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Models.ProductManager;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 品種管理頁面的ViewModel。
/// </summary>
public class PmViewModel : BindableBase, INavigationAware
{
    /********************
      * INavigationAware
      ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_ProductManager"));

        SetButtonState();
        ProductSelected = ProductSource.FirstOrDefault(x => x.ProductName == _pm.ActiveProductName);
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly IDialogService _crudService;
    private readonly ISystemMessenger _sysMessenger;
    private readonly IProductManager _pm;
    private readonly IProductCrud _pmCrudDialog;
    private readonly IPlc _plc;

    public PmViewModel(IPrismMessageBox prismMessageBox,
                       IDialogService crudService,
                       ISystemMessenger sysMessenger,
                       IProductManager pm,
                       IProductCrud pmCrudDialog,
                       IPlc plc)
    {
        _prismMessageBox = prismMessageBox;
        _crudService = crudService;
        _sysMessenger = sysMessenger;
        _pm = pm;
        _pmCrudDialog = pmCrudDialog;
        _plc = plc;

        _pm.ReadFromDb();

        RefreshList();
    }

    /********************
     * Command Binding
     ********************/
    /// <summary>
    /// 品種切換。
    /// </summary>
    public DelegateCommand ActiveProductCommand
        => _activeProductCommand ??= new DelegateCommand(ExecuteActiveProductCommand);
    void ExecuteActiveProductCommand()
    {
        _pm.SwitchProduct(ProductSelected.ProductName);
    }
    private DelegateCommand _activeProductCommand;

    /// <summary>
    /// 卸載作業品種。
    /// </summary>
    public DelegateCommand UnloadProductCommand
        => _unloadProductCommand ??= new DelegateCommand(ExecuteUnLoadProductCommand);
    void ExecuteUnLoadProductCommand()
    {
        _pm.SwitchProduct(string.Empty);
    }
    private DelegateCommand _unloadProductCommand;

    /// <summary>
    /// 讀取PLC目前品種。
    /// </summary>
    public DelegateCommand ReadProductFromPlcCommand
        => _readProductFromPlcCommand ??= new DelegateCommand(ExecuteReadProductFromPlcCommand);
    private void ExecuteReadProductFromPlcCommand()
    {
        var (isSuccessed, productName) = _plc.ReadProductName();
        if (isSuccessed && string.IsNullOrEmpty(productName))
        {
            if (_pm.IsProductExist(productName))
            {
                if (_prismMessageBox.Show($"品種名稱為: {productName}\n確定啟用該品種嗎？",
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DatabaseOperation"),
                                          MessageBoxImage.Question,
                                          PrismMessageBoxButton.YesNo) == ButtonResult.Yes)
                {
                    _pm.SwitchProduct(productName);
                    //_sysMessenger.ActiveProduct(productName);
                }
            }
            else
            {
                _ = _prismMessageBox.Show($"品種名稱 {productName} 不存在或讀取失敗！",
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FailedToReadDatabase"),
                                          MessageBoxImage.Error);
            }
        }
        else
        {
            _ = _prismMessageBox.Show($"品種名稱 {productName} 讀取失敗！",
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FailedToReadDatabase"),
                                      MessageBoxImage.Error);
        }
    }
    private DelegateCommand _readProductFromPlcCommand;

    /// <summary>
    /// 更新列表。
    /// </summary>
    public DelegateCommand UpdateListCommand
        => _updateListCommand ??= new DelegateCommand(ExecuteUpdateListCommand);
    void ExecuteUpdateListCommand()
    {
        _pm.ReadFromDb();
        RefreshList();
    }
    private DelegateCommand _updateListCommand;

    /********************
     * CRUD
     ********************/
    /// <summary>
    /// IDialogServer返回結果。
    /// </summary>
    private IDialogResult _dialogResult;

    /// <summary>
    /// IDialogServer操作。
    /// </summary>
    /// <param name="ca">動作名稱。</param>
    /// <returns>品種資料 CrudInfo。</returns>
    private ProductCrudInfo DialogOperate(CrudAction ca)
    {
        string titleKey = default;
        string productName = default;
        string newProductName = default;
        string memo = default;

        if (ca == CrudAction.Create)
        {
            titleKey = "CRUD_DialogTitle_NewProduct";
            productName = "";
            newProductName = "";
            memo = "";
        }
        else if (ca == CrudAction.Copy)
        {
            titleKey = "CRUD_DialogTitle_CopyProduct";
            productName = ProductSelected.ProductName;
            newProductName = ProductSelected.ProductName;
            memo = ProductSelected.Memo;
        }
        else if (ca == CrudAction.Modify)
        {
            titleKey = "CRUD_DialogTitle_ModifyProduct";
            productName = ProductSelected.ProductName;
            newProductName = ProductSelected.ProductName;
            memo = ProductSelected.Memo;
        }

        ProductCrudInfo ci = new()
        {
            Action = ca,
            Title = GetResource.GetValue<string>(titleKey),
            ProductName = productName,
            NewProductName = newProductName,
            Memo = memo,
            ApplyNewProduct = true
        };

        // 序列化
        DialogParameters paras = new DialogParameters
            {
                {
                    "StatusBarMessage",
                    JsonConvert.SerializeObject(ci, new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore
                    })
                }
            };

        // 顯示Dialog
        _crudService.ShowDialog(nameof(PmCrudDialog), paras, r => { _dialogResult = r; });

        if (_dialogResult.Result == ButtonResult.OK)
        {
            // 反序列化
            return JsonConvert.DeserializeObject<ProductCrudInfo>(_dialogResult.Parameters.GetValue<string>("StatusBarMessage"));
        }
        else
        {
            return null;
        }
    }

    /// <summary>
    /// 新增品種。
    /// </summary>
    public DelegateCommand CreateProductCommand
        => _createProductCommand ??= new DelegateCommand(ExecuteCreateProductCommand);
    void ExecuteCreateProductCommand()
    {
        ProductCrudInfo ci = DialogOperate(CrudAction.Create);

        if (ci != null)
        {
            _pmCrudDialog.CreateProduct(ci);
            RefreshList();

            if (ci.ApplyNewProduct)
                _pm.SwitchProduct(ci.NewProductName);
        }
    }
    private DelegateCommand _createProductCommand;

    /// <summary>
    /// 複製品種。
    /// </summary>
    public DelegateCommand CopyProductCommand
        => _copyProductCommand ??= new DelegateCommand(ExecuteCopyProductCommand);
    void ExecuteCopyProductCommand()
    {
        ProductCrudInfo ci = DialogOperate(CrudAction.Copy);

        if (ci != null)
        {
            _pmCrudDialog.CopyProduct(ci);
            RefreshList();
        }
    }
    private DelegateCommand _copyProductCommand;

    /// <summary>
    /// 品種編輯。
    /// </summary>
    public DelegateCommand ModifyProductCommand
        => _modifyProductCommand ??= new DelegateCommand(ExecuteModifyProductCommand);
    void ExecuteModifyProductCommand()
    {
        ProductCrudInfo ci = DialogOperate(CrudAction.Modify);

        if (ci != null)
        {
            _pmCrudDialog.ModifyProduct(ci);
            RefreshList();
        }
    }
    private DelegateCommand _modifyProductCommand;

    /// <summary>
    /// 刪除品種。
    /// </summary>
    public DelegateCommand DeleteProductCommand
        => _deleteProductCommand ??= new DelegateCommand(ExecuteDeleteProductCommand);
    void ExecuteDeleteProductCommand()
    {
        string productName = ProductSelected.ProductName;

        // 刪除確認
        if (_prismMessageBox.Show($"確定刪除嗎？\n品種名稱：{productName}",
                                  "刪除品種",
                                  MessageBoxImage.Question,
                                  PrismMessageBoxButton.YesNo) == ButtonResult.Yes)
        {
            _pmCrudDialog.DeleteProduct(productName);
            RefreshList();
        }
    }
    private DelegateCommand _deleteProductCommand;

    /********************
     * 狀態
     *******************/
    /// <summary>
    /// 更新列表
    /// </summary>
    private void RefreshList()
    {
        ProductDatas.Instance.ProductList.Sort((x, y) => x.ProductName.CompareTo(y.ProductName));
        ProductSource = new ObservableCollection<ProductDefine>(ProductDatas.Instance.ProductList);
    }

    /// <summary>
    /// 按鍵狀態設定
    /// </summary>
    private void SetButtonState()
    {
        bool cond1 = ProductSelected != null;
        //bool cond2 = ()

        ProductEffective = cond1;
        CreateProductEnable = true;
        CopyProductEnable = cond1;
        ModifyProductEnable = cond1;
        DeleteProductEnable = cond1;

        ImportEnabled = true;
        ExportEnabled = cond1;
    }

    /********************
     * Data Binding
     ********************/
    /// <summary>
    /// 
    /// </summary>
    public bool DatabaseReading
    {
        get { return _databaseReading; }
        set { SetProperty(ref _databaseReading, value); }
    }
    private bool _databaseReading;

    // DataGrid
    private ObservableCollection<ProductDefine> _productSource;
    public ObservableCollection<ProductDefine> ProductSource
    {
        get => _productSource;
        set => SetProperty(ref _productSource, value);
    }

    private ProductDefine _productSelected;
    public ProductDefine ProductSelected
    {
        get => _productSelected;
        set
        {
            SetProperty(ref _productSelected, value);
            SetButtonState();
        }
    }

    // Button
    private bool _productEffective;
    public bool ProductEffective
    {
        get => _productEffective;
        set => SetProperty(ref _productEffective, value);
    }

    private bool _createProductEnable;
    public bool CreateProductEnable
    {
        get => _createProductEnable;
        set => SetProperty(ref _createProductEnable, value);
    }

    private bool _copyProductEnable;
    public bool CopyProductEnable
    {
        get => _copyProductEnable;
        set => SetProperty(ref _copyProductEnable, value);
    }

    private bool _renameProductEnable;
    public bool ModifyProductEnable
    {
        get => _renameProductEnable;
        set => SetProperty(ref _renameProductEnable, value);
    }

    private bool _deleteProductEnable;
    public bool DeleteProductEnable
    {
        get => _deleteProductEnable;
        set => SetProperty(ref _deleteProductEnable, value);
    }

    private bool _importEnabled;
    public bool ImportEnabled
    {
        get => _importEnabled;
        set => SetProperty(ref _importEnabled, value);
    }

    private bool _exportEnabled;
    public bool ExportEnabled
    {
        get => _exportEnabled;
        set => SetProperty(ref _exportEnabled, value);
    }
}
