﻿using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using System.Windows;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 系統設定頁面的ViewModel。
/// </summary>
public class SettingsPageViewModel : BindableBase
{
    private IRegionNavigationService _navigationService;

    /********************
     * ctor
     ********************/
    private readonly IRegionManager _regionManager;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly ISystemMessenger _sysMessenger;

    public SettingsPageViewModel(IRegionManager regionManager,
                                 IPrismMessageBox prismMessageBox,
                                 ISystemMessenger sysMessenger)
    {
        _regionManager = regionManager;
        _prismMessageBox = prismMessageBox;
        _sysMessenger = sysMessenger;

        _ = regionManager.RegisterViewWithRegion(RegionNames.SystemSetting, typeof(Views.SystemSetting));
        PageSelector = PageKeys.SystemSetting;
    }

    /// <summary>
    /// 視窗載入。
    /// </summary>
    public DelegateCommand LoadedCommand
        => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
    private void ExecuteLoadedCommand()
    {
        _navigationService = _regionManager.Regions[RegionNames.SystemSetting].NavigationService;
    }
    private DelegateCommand _loadedCommand;

    /********************
     * Pages
     ********************/
    /// <summary>
    /// 頁面切換。
    /// </summary>
    public string PageSelector
    {
        get { return _pageSelector; }
        set
        {
            SetProperty(ref _pageSelector, value);
            _navigationService?.RequestNavigate(value);
        }
    }
    private string _pageSelector;

    /// <summary>
    /// 啟動應用程式結束程序。
    /// </summary>
    public DelegateCommand SystemExit
        => _systemExit ??= new DelegateCommand(ExecuteSystemExit);
    void ExecuteSystemExit()
    {
        if (_prismMessageBox.Show(GetResource.GetValue<string>("Caption_SystemExitConfirm"),
                                  GetResource.GetValue<string>("Glorytek.WFSCore", "Message_SystemMessage"),
                                  MessageBoxImage.Question,
                                  PrismMessageBoxButton.YesNo,
                                  ButtonResult.No) == ButtonResult.Yes)
        {
            _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Message_ApplicationShutdown"));
            _sysMessenger.ShowProgressRing(true);

            /*********************
            * 程式結束流程:
            * 1. 執行 Shutdown() -> 主視窗關閉
            * 2. 觸發主視窗 Closing 事件: 主視窗 ViewModel 的 ApplicationShutdown()
            * 3. ApplicationShutdown() 中先觸發 ApplicationShutdownEvent 事件關閉其他週邊，然後再執行後續作業
            * 4. 最後觸發 App.xaml 中 Exit 指定的函式
            *
            * 注意事項:
            * 1. Shutdown() 會觸發主視窗的 Closing 事件，但不會觸發 Unloaded 事件
            * 2. Environment.Exit() 的結束方式是結束 process (https://learn.microsoft.com/zh-tw/dotnet/api/system.environment.exit)，
            *    經測試均不會觸發 Closing 事件與 Unloaded 事件
            * 3. 未捕獲異常是否會觸發 Closing 事件，尚未測試
            *********************/
            Application.Current.Shutdown(0);
        }
    }
    private DelegateCommand _systemExit;
}
