﻿using Glorytek.CSharp.IO;
using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Models.ProductManager;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Windows;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 品種管理CRUD對話框的ViewModel。
/// </summary>
public class PmCrudDialogViewModel : BindableBase, IDialogAware
{
    /********************
     * ctor
     ********************/
    private readonly IPrismMessageBox _prismMessageBox;
    private CrudAction _action;
    private readonly IProductManager _pm;

    public PmCrudDialogViewModel(IPrismMessageBox prismMessageBox, IProductManager pm)
    {
        _prismMessageBox = prismMessageBox;
        _pm = pm;
    }

    /********************
     * IDialogAware
     ********************/
    public string Title
    {
        get => _title;
        set => SetProperty(ref _title, value);
    }
    private string _title;

    public event Action<IDialogResult> RequestClose;
    public bool CanCloseDialog() => true;
    public void OnDialogClosed() { }

    // Dialog Closed
    public DelegateCommand<string> CloseDialogCommand
        => _closeDialogCommand ??= new DelegateCommand<string>(CloseDialog);
    protected virtual void CloseDialog(string parameter)
    {
        ButtonResult result;

        if (parameter?.ToUpper() == "TRUE")
        {
            result = ButtonResult.OK;

            /***** 資料驗證 *****/
            string fName = MakeFilePathValid.MakeFilenameValid(NewProductName);

            // 品種名稱不合法
            if (fName == null)
                return;

            // 品種名稱已存在
            if (_action != CrudAction.Modify && _pm.IsProductExist(fName))
            {
                _ = _prismMessageBox.Show(GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_ProductNameAlreadyExists"),
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_IncorrectDataEntered"),
                                          MessageBoxImage.Error);
                return;
            }

            /***** 資料處理 *****/
            // 取得資料
            ProductCrudInfo ci = new ProductCrudInfo()
            {
                ProductName = OriProductName,
                NewProductName = fName,
                Memo = Memo,
                ApplyNewProduct = ApplyNewProduct
            };

            // 序列化
            DialogParameters paras = new DialogParameters
                {
                    {
                        "StatusBarMessage",
                        JsonConvert.SerializeObject(ci, new JsonSerializerSettings
                        {
                            NullValueHandling = NullValueHandling.Ignore
                        })
                    }
                };

            RaiseRequestClose(new DialogResult(result, paras));
        }
        else
        {
            result = ButtonResult.Cancel;
            RaiseRequestClose(new DialogResult(result));
        }
    }
    private DelegateCommand<string> _closeDialogCommand;

    public virtual void RaiseRequestClose(IDialogResult dialogResult)
        => RequestClose?.Invoke(dialogResult);

    // Dialog Opened
    public void OnDialogOpened(IDialogParameters parameters)
    {
        // 反序列化，取得資料
        ProductCrudInfo ci = JsonConvert.DeserializeObject<ProductCrudInfo>(parameters.GetValue<string>("StatusBarMessage"));

        _action = ci.Action;
        Title = ci.Title;

        switch (_action)
        {
            case CrudAction.Create:
                // OriProductName : 不可見
                // NewProductName : 可見,可編
                // Memo : 可見,可編
                OriProductNameVisibility = false;

                NewProductName = "";
                NewProductNameVisibility = true;
                NewProductNameEnabled = true;

                Memo = "";
                MemoVisibility = true;
                MemoEnabled = true;

                ApplyNewProduct = ci.ApplyNewProduct;
                ApplyNewProductVisibility = true;
                break;

            case CrudAction.Copy:
                // OriProductName : 可見,唯讀
                // NewProductName : 可見,可編
                // Memo : 可見,可編
                OriProductName = ci.ProductName;
                OriProductNameVisibility = true;
                OriProductNameEnabled = false;

                NewProductName = "";
                NewProductNameVisibility = true;
                NewProductNameEnabled = true;

                Memo = ci.Memo;
                MemoVisibility = true;
                MemoEnabled = true;

                ApplyNewProduct = ci.ApplyNewProduct;
                ApplyNewProductVisibility = true;
                break;

            case CrudAction.Modify:
                // OriProductName : 可見,唯讀
                // NewProductName : 可見,可編
                // Memo : 可見,可編
                OriProductName = ci.ProductName;
                OriProductNameVisibility = true;
                OriProductNameEnabled = false;

                NewProductName = ci.ProductName;
                NewProductNameVisibility = true;
                NewProductNameEnabled = true;

                Memo = ci.Memo;
                MemoVisibility = true;
                MemoEnabled = true;

                ApplyNewProduct = false;
                ApplyNewProductVisibility = false;
                break;
        }
    }

    /********************
    * Data Binding
    ********************/
    // Apply
    public bool ApplyNewProduct
    {
        get => _applyNewProduct;
        set => SetProperty(ref _applyNewProduct, value);
    }
    private bool _applyNewProduct;

    public bool ApplyNewProductVisibility
    {
        get => _applyNewProductVisibility;
        set => SetProperty(ref _applyNewProductVisibility, value);
    }
    private bool _applyNewProductVisibility;

    // OriProductName
    public string OriProductName
    {
        get => _oriProductName;
        set => SetProperty(ref _oriProductName, value.Trim());
    }
    private string _oriProductName;

    public bool OriProductNameVisibility
    {
        get => _oriProductNameVisibility;
        set => SetProperty(ref _oriProductNameVisibility, value);
    }
    private bool _oriProductNameVisibility;

    public bool OriProductNameEnabled
    {
        get => _oriProductNameEnabled;
        set => SetProperty(ref _oriProductNameEnabled, value);
    }
    private bool _oriProductNameEnabled;

    // NewProductName
    public string NewProductName
    {
        get => _newProductName;
        set => SetProperty(ref _newProductName, value.Trim());
    }
    private string _newProductName;

    public bool NewProductNameVisibility
    {
        get => _newProductNameVisibility;
        set => SetProperty(ref _newProductNameVisibility, value);
    }
    private bool _newProductNameVisibility;

    public bool NewProductNameEnabled
    {
        get => _newProductNameEnabled;
        set => SetProperty(ref _newProductNameEnabled, value);
    }
    private bool _newProductNameEnabled;

    // Memo
    public string Memo
    {
        get => _memo;
        set => SetProperty(ref _memo, value.Trim());
    }
    private string _memo;

    public bool MemoVisibility
    {
        get => _memoVisibility;
        set => SetProperty(ref _memoVisibility, value);
    }
    private bool _memoVisibility;

    public bool MemoEnabled
    {
        get => _memoEnabled;
        set => SetProperty(ref _memoEnabled, value);
    }
    private bool _memoEnabled;
}
