﻿using Glorytek.WFSComponents.WFS.Constants;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSComponents.WFS.Models;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WPF.Extensions;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 大數據頁面的ViewModel。
/// </summary>
public class BigDataViewModel : BindableBase, INavigationAware
{
    private readonly BigDataContent _bdContent = BigDataContent.Instance;

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Glorytek.WFSComponents", "PageTitle_BigData"));

        if (!_wfs.IsLotNumberValid(_bdContent.SelectedLotNumber))
            _bdContent.SelectedLotNumber = _wfs.GetLastLotNumber();
        //_ = _ea.GetEvent<LotNumberChangedEvent>().Publish(_bdContent.SelectedLotNumber);

        _wfs.SetBigDataBrowser(sortDirection: SortDirection.Ascending,
                               lotNumberFilter: _bdContent.SelectedLotNumber,
                               pageSize: 20);
        //_bdContent.PageSize = 20;
        //_wfs.LoadDataFromSortingMode();
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IWfs _wfs;

    public BigDataViewModel(ISystemMessenger sysMessenger, IWfs wfs)
    {
        _sysMessenger = sysMessenger;
        _wfs = wfs;

        PageChange(BrowserPageName.SourcePage);
    }

    /********************
     * Function
     ********************/
    ///// <summary>
    ///// 重新整理規格資料
    ///// </summary>
    //private void RefreshGrade()
    //{
    //    BigDataOutputData.SpecificationSetting = new List<SpecificationDefine>();

    //    foreach (var grade in _wfs.GradeList)
    //    {
    //        if (_wfs.PalletSortingList.Exists(x => x.GradeId == grade.Id))
    //        {
    //            var specList = _wfs.SpecificationList.FindAll(x => x.GradeId == grade.Id);
    //            foreach (var spec in specList)
    //            {
    //                BigDataOutputData.SpecificationSetting.Add(new SpecificationDefine()
    //                {
    //                    GradeId = grade.Id,
    //                    GradeName = grade.Name,
    //                    DataName = spec.DataName,
    //                    Relation = spec.Relation.ToString(),
    //                    RelationType = spec.Relation,
    //                    Value = spec.Value,
    //                    Value1 = spec.Value1,
    //                    Value2 = spec.Value2,
    //                });
    //            }
    //        }
    //    }

    //    var querySpecification = from spec in BigDataOutputData.SpecificationSetting
    //                             join grade in _wfs.GradeList on spec.GradeId equals grade.Id
    //                             select new SpecificationLayoutDefine
    //                             {
    //                                 GradeId = grade.Id,
    //                                 GradeName = grade.Name,
    //                                 DataName = spec.DataName,
    //                                 Relation = spec.Relation,
    //                                 RelationType = spec.RelationType,
    //                                 Value = spec.Value,
    //                                 Value1 = spec.Value1,
    //                                 Value2 = spec.Value2,
    //                             };
    //    var tSpecificationList = new List<SpecificationLayoutDefine>();
    //    foreach (var item in querySpecification)
    //        tSpecificationList.Add(item);
    //    SpecificationList = tSpecificationList.OrderBy(x => x.GradeId).ToList();

    //    var sl = CollectionViewSource.GetDefaultView(SpecificationList);
    //    sl.GroupDescriptions.Add(new PropertyGroupDescription("GradeName"));
    //}

    ///// <summary>
    ///// 重新整理資料表
    ///// </summary>
    //private void UpdateTable()
    //{
    //    if (_sysMode != SystemDataInstance.Instance.SystemOperateMode)
    //    {
    //        _sysMode = SystemDataInstance.Instance.SystemOperateMode;
    //        RefreshGrade();
    //    }

    //    if (_sysMode == SystemOperateModeType.Online_FixStage)
    //    {
    //        //_bigData.LoadDataFromOnlineMode();
    //    }
    //    else if (_sysMode == SystemOperateModeType.LensSorting)
    //    {
    //        _bigData.LoadDataFromSortingMode();
    //    }
    //}

    /********************
     * Button
     ********************/
    /// <summary>
    /// 重新讀取資料庫。
    /// </summary>
    public DelegateCommand RereadDataCommand
        => _rereadDataCommand ??= new DelegateCommand(ExecuteRereadDataCommand);
    private void ExecuteRereadDataCommand()
    {
        _wfs.ReadMeasurementDataFileList();
        _wfs.ReadBigDataFromDb();
        _wfs.GetLotNumberDataFromDb(_bdContent.SelectedLotNumber);
        _wfs.UpdateBrowser();
    }
    private DelegateCommand _rereadDataCommand;

    /// <summary>
    /// 大數據導出。
    /// </summary>
    public DelegateCommand BigDataExportCommand
        => _bigDataExportCommand ??= new DelegateCommand(ExecuteBigDataExportCommand);
    private void ExecuteBigDataExportCommand()
    {
        _wfs.ExportBigDataToDb(_bdContent.SelectedLotNumber);
    }
    private DelegateCommand _bigDataExportCommand;

    ////
    //// 清除量測履歷。
    ////
    //public DelegateCommand ClearHistoryCommand
    //    => _clearHistoryCommand ?? (_clearHistoryCommand = new DelegateCommand(ExecuteCommandName));
    //private void ExecuteCommandName()
    //{
    //    if (_prismMessageBox.Show("大數據資料庫將會清空，確定嗎？", "動作確認", PrismMessageBoxButton.YesNo, MessageBoxImage.Question) == ButtonResult.Yes)
    //    {
    //        _bigData.ClearBigDataList();
    //        UpdateTable();
    //    }
    //}
    //private DelegateCommand _clearHistoryCommand;

    /// <summary>
    /// 切換分頁按鈕。
    /// </summary>
    public DelegateCommand<string> PageChangeCommand
        => _pageChangeCommand ??= new DelegateCommand<string>(ExecutePageChangeCommand);
    private void ExecutePageChangeCommand(string pageSelected)
    {
        PageChange(pageSelected);
    }
    private DelegateCommand<string> _pageChangeCommand;

    /// <summary>
    /// 分頁切換及顯示。
    /// </summary>
    private void PageChange(string pageSelected)
    {
        SourceVisibility = pageSelected == BrowserPageName.SourcePage;
        //&& _bdContent.BigDataCollectionView != null && !_bdContent.BigDataCollectionView.IsEmpty;

        TraySettingVisibility = pageSelected == BrowserPageName.TraySettingPage
            && ((_bdContent.LoadTrayLayoutList != null && _bdContent.LoadTrayLayoutList.Count > 0)
            || (_bdContent.ProductTrayLayoutList != null && _bdContent.ProductTrayLayoutList.Count > 0)
            || (_bdContent.ReworkTrayLayoutList != null && _bdContent.ReworkTrayLayoutList.Count > 0));

        SpecSettingVisibility = pageSelected == BrowserPageName.SpecSettingPage
            && _bdContent.SpecificationLayoutList != null && _bdContent.SpecificationLayoutList.Count > 0;

        ProductVisibility = pageSelected == BrowserPageName.ProductPage
            && _bdContent.ProductLayoutList != null && _bdContent.ProductLayoutList.Count > 0;

        ReworkVisibility = pageSelected == BrowserPageName.ReworkPage
            && _bdContent.ReworkLayoutList != null && _bdContent.ReworkLayoutList.Count > 0;

        ShowNoDataMessage = !(SourceVisibility
                           || TraySettingVisibility
                           || SpecSettingVisibility
                           || ProductVisibility
                           || ReworkVisibility);
    }

    /********************
     * 分頁顯示開關
     ********************/
    /// <summary>
    /// 顯示無資料訊息。
    /// </summary>
    public bool ShowNoDataMessage
    {
        get { return _showNoDataMessage; }
        set { SetProperty(ref _showNoDataMessage, value); }
    }
    private bool _showNoDataMessage = false;

    /// <summary>
    /// 顯示量測資料頁。
    /// </summary>
    public bool SourceVisibility
    {
        get { return _sourceVisibility; }
        set { SetProperty(ref _sourceVisibility, value); }
    }
    private bool _sourceVisibility = false;

    /// <summary>
    /// 顯示托盤設定頁。
    /// </summary>
    public bool TraySettingVisibility
    {
        get { return _traySettingVisibility; }
        set { SetProperty(ref _traySettingVisibility, value); }
    }
    private bool _traySettingVisibility = false;

    /// <summary>
    /// 顯示規格設定頁。
    /// </summary>
    public bool SpecSettingVisibility
    {
        get { return _specSettingVisibility; }
        set { SetProperty(ref _specSettingVisibility, value); }
    }
    private bool _specSettingVisibility = false;

    /// <summary>
    /// 顯示分料結果頁。
    /// </summary>
    public bool ProductVisibility
    {
        get { return _productVisibility; }
        set { SetProperty(ref _productVisibility, value); }
    }
    private bool _productVisibility = false;

    /// <summary>
    /// 顯示重工品頁。
    /// </summary>
    public bool ReworkVisibility
    {
        get { return _reworkVisibility; }
        set { SetProperty(ref _reworkVisibility, value); }
    }
    private bool _reworkVisibility = false;
}
