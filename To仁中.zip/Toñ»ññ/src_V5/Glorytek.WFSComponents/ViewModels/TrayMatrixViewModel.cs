﻿using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Prism.Commands;
using Prism.Mvvm;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Input;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// Tray方塊矩陣的ViewModel。
/// </summary>
public class TrayMatrixViewModel : BindableBase
{
    private readonly ZoomAndPanModel _zp = ZoomAndPanModel.Instance;
    private readonly TrayMatrixData _tmd = TrayMatrixData.Instance;

    /// <summary>
    /// 目前的Tray ID。
    /// </summary>
    private int _thisTrayId;

    /// <summary>
    /// 要繪製的Tray。
    /// </summary>
    private TrayDefine _drawTray = null;

    /// <summary>
    /// 所有點位。
    /// </summary>
    private List<TrayProfileDefine> _thisProfile = null;

    /// <summary>
    /// Mask。
    /// </summary>
    private List<TrayMaskDefine> _thisMask = null;

    /// <summary>
    /// 最大無效點數。
    /// </summary>
    private const int _MAX_MASK = 20;

    /********************
     * ctor
     ********************/
    private readonly IMachine _machine;
    private readonly ITray _tray;
    private readonly IPlc _plc;

    public TrayMatrixViewModel(IMachine machine, ITray tray, IPlc plc)
    {
        _machine = machine;
        _tray = tray;
        _plc = plc;
    }

    /********************
     * Mouse
     ********************/
    /// <summary>
    /// 滑鼠左鍵點擊方塊命令。
    /// </summary>
    public DelegateCommand<object> LeftButtonClickOnBlockCommand
        => _leftButtonClickOnBlockCommand ??= new DelegateCommand<object>(ExecuteLeftButtonClickOnBlockCommand);
    private void ExecuteLeftButtonClickOnBlockCommand(object clickedBlock)
    {
        if (_zp.Blocks != null && clickedBlock != null && clickedBlock is MouseButtonEventArgs args)
        {
            int blockId = -1;

            if (args.OriginalSource is Border borderBlock)
                blockId = (int)borderBlock.Tag;
            else if (args.OriginalSource is TextBlock textBlock)
                blockId = (int)textBlock.Tag;

            if (blockId != -1)
            {
                BlockDefine block = _zp.Blocks.First(x => x.Id == blockId);

                if (!block.Mask)
                {
                    _tmd.CurrentPointNo = block.Id;
                    _zp.Blocks = _tray.RedrawBlocks(ThisTray, _thisProfile, _thisMask);
                }

                // 相機跟隨
                if (_plc.Online && TrayParameters.Instance.CameraFollow && SystemDataInstance.Instance.SystemStabilized)
                {
                    _plc.WriteInt16(DeviceLists.VISUAL_TRAY_POINT, (short)block.Id);
                    _plc.SendCommandPulse(DeviceLists.VISUAL_TRAY_COMMAND);
                }
            }
        }
    }
    private DelegateCommand<object> _leftButtonClickOnBlockCommand;

    /// <summary>
    /// 滑鼠右鍵點擊方塊命令。
    /// </summary>
    public DelegateCommand<object> RightButtonClickOnBlockCommand
        => _rightButtonClickOnBlockCommand ??= new DelegateCommand<object>(ExecuteRightButtonClickOnBlockCommand);
    private void ExecuteRightButtonClickOnBlockCommand(object clickedBlock)
    {
        if (clickedBlock != null && clickedBlock is MouseButtonEventArgs args)
        {
            if (args.OriginalSource is TextBlock _clickedBlock && _zp.Blocks != null)
            {
                int blockId = (int)_clickedBlock.Tag;
                BlockDefine block = _zp.Blocks.First(x => x.Id == blockId);
                _tray.ToggleMaskState(ref block, ref _thisMask, _thisTrayId, _thisProfile.Count);
                _thisProfile = _tray.CalculateProfile(_drawTray, _thisMask);
                _zp.Blocks = _tray.RedrawBlocks(_drawTray, _thisProfile, _thisMask);
            }
        }
    }
    private DelegateCommand<object> _rightButtonClickOnBlockCommand;

    /********************
     * Action
     ********************/
    /// <summary>
    /// 移動至Tray基準點命令。
    /// </summary>
    public DelegateCommand MoveToDpCommand
        => _moveToDpCommand ??= new DelegateCommand(ExecuteMoveToDpCommand);
    private async void ExecuteMoveToDpCommand()
    {
        if (ThisTray != null)
            await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                    ThisTray.DatumX,
                                    ThisTray.DatumY,
                                    0.0);
    }
    private DelegateCommand _moveToDpCommand;

    /********************
     * Mask
     ********************/
    ///// <summary>
    ///// 比較兩個TrayMask是否一樣
    ///// </summary>
    ///// <returns>true: 兩者一樣<br/>false: 兩者不相同。</returns>
    //private bool EqualMask(List<TrayMaskDefine> mask1, List<TrayMaskDefine> mask2)
    //{
    //    if (mask1.Count != mask2.Count)
    //        return false;
    //    else if (mask1.Count == 0)
    //        return true;

    //    for (int idx = 0; idx < mask1.Count; idx++)
    //        if (!mask1[idx].Equals(mask2[idx]))
    //            return false;

    //    return true;
    //}

    /********************
     * 從父View接收的Tray資料
     ********************/
    /// <summary>
    /// 傳入要顯示的Tray資料。
    /// </summary>
    public TrayMatrixRegionContext SourceData
    {
        get { return _sourceData; }
        set
        {
            _sourceData = value;
            if (value != null)
            {
                _thisTrayId = value.Tray.Id;
                _thisMask = _tray.MaskList.FindAll(x => x.TrayId == _thisTrayId);
                _thisMask.Sort();

                _drawTray = value.Tray.DeepCopyByExpressionTree();
                var pp = _tray.PalletList.Find(x => x.Id == value.PalletId);

                _drawTray.DatumX = (pp.DatumX + _machine.Machine.DatumPointX).WfsFormat();
                _drawTray.DatumY = (pp.DatumY + _machine.Machine.DatumPointY).WfsFormat();
                _drawTray.Order_PositionA_X = (_drawTray.Order_PositionA_X + _drawTray.DatumX).WfsFormat();
                _drawTray.Order_PositionA_Y = (_drawTray.Order_PositionA_Y + _drawTray.DatumY).WfsFormat();
                _drawTray.Order_PositionB_X = (_drawTray.Order_PositionB_X + _drawTray.DatumX).WfsFormat();
                _drawTray.Order_PositionB_Y = (_drawTray.Order_PositionB_Y + _drawTray.DatumY).WfsFormat();
                _drawTray.Order_PositionC_X = (_drawTray.Order_PositionC_X + _drawTray.DatumX).WfsFormat();
                _drawTray.Order_PositionC_Y = (_drawTray.Order_PositionC_Y + _drawTray.DatumY).WfsFormat();
                _drawTray.Cross_PositionA_X = (_drawTray.Cross_PositionA_X + _drawTray.DatumX).WfsFormat();
                _drawTray.Cross_PositionA_Y = (_drawTray.Cross_PositionA_Y + _drawTray.DatumY).WfsFormat();
                _drawTray.Cross_PositionB_X = (_drawTray.Cross_PositionB_X + _drawTray.DatumX).WfsFormat();
                _drawTray.Cross_PositionB_Y = (_drawTray.Cross_PositionB_Y + _drawTray.DatumY).WfsFormat();
                _drawTray.Cross_PositionC_X = (_drawTray.Cross_PositionC_X + _drawTray.DatumX).WfsFormat();
                _drawTray.Cross_PositionC_Y = (_drawTray.Cross_PositionC_Y + _drawTray.DatumY).WfsFormat();

                ThisTray = _drawTray;
                _tmd.CurrentPointNo = pp.PickPointNo;
                _thisProfile = _tray.CalculateProfile(_drawTray, _thisMask);
                _zp.Blocks = _tray.RedrawBlocks(_drawTray, _thisProfile, _thisMask);
                _tray.WriteTrayToPlc(DeviceLists.VISUAL_TRAY_ID, _drawTray);
            }
            else
            {
                ThisTray = null;
                _thisTrayId = -1;
                //_thisProfile = null;
                _thisMask = null;
            }

        }
    }
    private TrayMatrixRegionContext _sourceData;

    /// <summary>
    /// 
    /// </summary>
    public TrayDefine ThisTray
    {
        get { return _thisTray; }
        set { _thisTray = value; }
    }
    private TrayDefine _thisTray;

    /// <summary>
    /// 取料測試命令。
    /// </summary>
    public DelegateCommand PickTestCommand
        => _pickTestCommand ??= new DelegateCommand(ExecutePickTestCommand);
    private void ExecutePickTestCommand()
    {
        if (_plc.Online && ThisTray != null)
        {
            double zHeight = (ThisTray.PickHeight + _machine.Machine.HeightCorrection + _machine.Machine.DatumPointZ).WfsFormat();
            _plc.WriteDoubleByInt32(DeviceLists.VISUAL_POINT_Z, zHeight); // 送高度給PLC
            _plc.SendCommandPulse(DeviceLists.TRAY_PICK_TEST);
        }
    }
    private DelegateCommand _pickTestCommand;

    /// <summary>
    /// 放料測試命令。
    /// </summary>
    public DelegateCommand PlaceTestCommand
        => _placeTestCommand ??= new DelegateCommand(ExecutePlaceTestCommand);
    private void ExecutePlaceTestCommand()
    {
        if (_plc.Online && ThisTray != null)
        {
            double zHeight = (ThisTray.PickHeight + _machine.Machine.HeightCorrection + _machine.Machine.DatumPointZ).WfsFormat();
            _plc.WriteDoubleByInt32(DeviceLists.VISUAL_POINT_Z, zHeight); // 送高度給PLC
            _plc.SendCommandPulse(DeviceLists.TRAY_PLACE_TEST);
        }
    }
    private DelegateCommand _placeTestCommand;

    /********************
     * Property
     ********************/
    /// <summary>
    /// 
    /// </summary>
    public BlockInformationType BlockInformationSelector
    {
        get { return _blockInformationSelector; }
        set
        {
            SetProperty(ref _blockInformationSelector, value);
            TrayMatrixData.Instance.BlockInformationSelector = value;
            _zp.Blocks = _tray.RedrawBlocks(ThisTray, _thisProfile, _thisMask);
        }
    }
    private BlockInformationType _blockInformationSelector;
}
