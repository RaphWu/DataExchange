﻿using ControlzEx.Standard;
using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSComponents.WFS.Constants;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Newtonsoft.Json;
using Prism;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// Tray設定頁面的ViewModel。
/// </summary>
public class TrayViewModel : BindableBase, IConfirmNavigationRequest, IActiveAware
{
    private readonly PlcDatas _pd = PlcDatas.Instance;

    /// <summary>
    /// 離開頁面前保留Tray ID。
    /// </summary>
    private int _lastTrayId = -1;

    /********************
     * IConfirmNavigationRequest
     ********************/
    public void ConfirmNavigationRequest(NavigationContext navigationContext, Action<bool> continuationCallback)
    {
        bool result = true;
        //MessageBoxResult userChoice = CheckCloneBackup();

        //if (userChoice == MessageBoxResult.Yes)
        //{
        //    WriteToDb();
        //}
        ////else if (userChoice == MessageBoxResult.No)
        ////{
        ////    _noDetectSelectedItemUpdate = true;
        ////    ReadData();
        ////    RaisePropertyChanged(null);
        ////    _noDetectSelectedItemUpdate = false;
        ////}
        //else if (userChoice == MessageBoxResult.Cancel)
        //{
        //    _sysMessenger.LightUpPreviousMainMenuButton("");
        //    result = false;
        //}

        continuationCallback(result);
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
        _lastTrayId = SelectedTrayItem != null ? SelectedTrayItem.Id : -1;
    }

    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Glorytek.WFS", "MainMenu_Tray"));

        //_dontDetectSelectedItemUpdate = true;
        if (_pm.IsProductActive)
        {
            //ReadData();
            RefreshTrayList();
            SelectedTrayIndex = _tray.TrayList.FindIndex(x => x.Id == _lastTrayId);
            //UpdateTrayMatrixSource();
        }
        //_dontDetectSelectedItemUpdate = false;
    }

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    private bool _isActive = false;
    public bool IsActive
    {
        get { return _isActive; }
        set
        {
            _isActive = value;
            OnIsActiveChanged();

            //if (value)
            //    UpdateTrayMatrixSource();
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    private readonly TrayData _td = TrayData.Instance;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IDialogService _dialogService;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly IMachine _machine;
    private readonly IProductManager _pm;
    private readonly ICrudDialog _crudDialog;
    private readonly ISystemMessenger _sysMessenger;
    private readonly ITray _tray;
    private readonly IPlc _plc;

    public TrayViewModel(IApplicationCommands applicationCommands,
                         IEventAggregator ea,
                         IDialogService dialogService,
                         IPrismMessageBox prismMessageBox,
                         IMachine machine,
                         IProductManager pm,
                         ICrudDialog crudDialog,
                         ISystemMessenger mainPageInfo,
                         ITray tray,
                         IPlc plc)
    {
        _ea = ea;
        _dialogService = dialogService;
        _prismMessageBox = prismMessageBox;
        _machine = machine;
        _pm = pm;
        _crudDialog = crudDialog;
        _sysMessenger = mainPageInfo;
        _tray = tray;
        _plc = plc;

        // TODO: UnregisterCommand
        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 將資料或參數寫入資料庫命令。
    /// </summary>
    public void ExecuteSaveDataCommand()
    {
        WriteToDb();
    }

    /// <summary>
    /// 將Model資料寫入資料庫。
    /// </summary>
    public bool WriteToDb()
    {
        if (SelectedTrayItem != null)
        {
            //RedrawTrayMatrix();
            bool ret = _tray.WriteTrayToDb();
            if (ret)
            {
                _ea.GetEvent<WriteNewPointNoEvent>().Publish(0);
                //_ea.GetEvent<PalletInfoChangedEvent>().Publish(true);
            }
            return ret;
        }
        else
        {
            return false;
        }
    }

    ///// <summary>
    ///// 將View資料存回Model
    ///// </summary>
    //private bool SaveData()
    //{
    //    if (SelectedTrayItem != null)
    //    {
    //        var tray = _tray.Tray.Find(x => x.Id == SelectedTrayItem.Id);

    //        return true;
    //    }
    //    else
    //    {
    //        return false;
    //    }
    //}

    /// <summary>
    /// 從資料庫載入資料至Model。
    /// </summary>
    private bool ReadData()
    {
        if (_tray.ReadFromDb())
        {
            RefreshTrayList();
            return true;
        }
        else
        {
            return false;
        }
    }

    /********************
     * Functions
     *******************/
    /// <summary>
    /// 資料順序不變，重新排序全部的OrderNo。
    /// </summary>
    private void ResortingOrderNo()
    {
        int orderNo = 0;
        foreach (TrayDefine item in TrayListSource)
            item.OrderNo = ++orderNo;
    }

    /// <summary>
    /// 更新Tray名稱列表。
    /// </summary>
    private void RefreshTrayList()
    {
        //var trayList = new List<TrayDefine>(_tray.Tray);
        //trayList.Sort((x, y) => x.OrderNo.CompareTo(y.OrderNo));
        TrayListSource = new ObservableCollection<TrayDefine>(_tray.TrayList.OrderBy(x => x.OrderNo));
    }

    /// <summary>
    /// 按鍵狀態設定。
    /// </summary>
    private void SetButtonState()
    {
        if (SelectedTrayItem != null)
        {
            TrayFuncEnabled = true;
            TrayFuncNotFirstEnabled = TrayFuncEnabled && SelectedTrayIndex != 0;
            TrayFuncNotLastEnabled = TrayFuncEnabled && SelectedTrayIndex != (TrayListSource.Count - 1);
        }
    }

    /********************
     * CRUD
     ********************/
    /// <summary>
    /// 新建Tray命令。
    /// </summary>
    public DelegateCommand NewTrayCommand
        => _newTrayCommand ??= new DelegateCommand(ExecuteNewTrayCommand);
    private void ExecuteNewTrayCommand()
    {
        var crudInfo = new CrudInfo()
        {
            Action = CrudAction.Create,
            Title = GetResource.GetValue<string>("CRUD_DialogTitle_NewTray"),
            NewName = "",
            NewTitle = GetResource.GetValue<string>("CRUD_Title_NewTrayName"),
            //Memo = "",
            //MemoTitle = GetLocalizeResource.GetValue<string>("CRUD_Title_Memo"),
        };
        CrudInfo result = _crudDialog.ShowDialog(crudInfo);

        if (result.Result == ButtonResult.OK)
        {
            if (_tray.IsTrayExist(result.NewName))
            {
                // Error
                string msg = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_TrayExist") + result.NewName;
                _prismMessageBox.Show(msg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_Database_Title"),
                                      MessageBoxImage.Error);
            }
            else
            {
                _tray.CreateNewTray(result);
                RefreshTrayList();
                SelectedTrayItem = _tray.TrayList.Find(x => x.Name == result.NewName);
            }
        }
    }
    private DelegateCommand _newTrayCommand;

    /// <summary>
    /// Tray更名命令。
    /// </summary>
    public DelegateCommand RenameTrayCommand
        => _renameTrayCommand ??= new DelegateCommand(ExecuteRenameTrayCommand);
    private void ExecuteRenameTrayCommand()
    {
        if (SelectedTrayItem != null)
        {
            var crudInfo = new CrudInfo()
            {
                Action = CrudAction.Rename,
                Title = GetResource.GetValue<string>("CRUD_DialogTitle_RenameTray"),
                Id = SelectedTrayItem.Id,
                OriginalName = SelectedTrayItem.Name,
                OriginalTitle = GetResource.GetValue<string>("CRUD_Title_OriginalTrayName"),
                NewName = SelectedTrayItem.Name,
                NewTitle = GetResource.GetValue<string>("CRUD_Title_NewTrayName"),
                //Memo = "",
                //MemoTitle = GetLocalizeResource.GetValue<string>("CRUD_Title_Memo"),
            };
            CrudInfo result = _crudDialog.ShowDialog(crudInfo);

            if (result.Result == ButtonResult.OK)
            {
                if (_tray.IsTrayExist(result.NewName))
                {
                    // Error
                    string msg = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_TrayExist") + result.NewName;
                    _prismMessageBox.Show(msg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_Database_Title"),
                                          MessageBoxImage.Error);
                    return;
                }

                _tray.RenameTray(result);
                RefreshTrayList();
                SetButtonState();
            }
        }
    }
    private DelegateCommand _renameTrayCommand;

    /// <summary>
    /// 複製Tray命令。
    /// </summary>
    public DelegateCommand CopyTrayCommand
        => _copyTrayCommand ??= new DelegateCommand(ExecuteCopyTrayCommand);
    private void ExecuteCopyTrayCommand()
    {
        if (SelectedTrayItem != null)
        {
            var crudInfo = new CrudInfo()
            {
                Action = CrudAction.Copy,
                Title = GetResource.GetValue<string>("CRUD_DialogTitle_CopyTray"),
                Id = SelectedTrayItem.Id,
                OriginalName = SelectedTrayItem.Name,
                OriginalTitle = GetResource.GetValue<string>("CRUD_Title_OriginalTrayName"),
                NewName = "",
                NewTitle = GetResource.GetValue<string>("CRUD_Title_NewTrayName"),
                //Memo = "",
                //MemoTitle = GetLocalizeResource.GetValue<string>("CRUD_Title_Memo"),
            };
            CrudInfo result = _crudDialog.ShowDialog(crudInfo);

            if (result.Result == ButtonResult.OK)
            {
                if (_tray.IsTrayExist(result.NewName))
                {
                    // Error
                    string msg = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_TrayExist") + result.NewName;
                    _prismMessageBox.Show(msg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_Error"),
                                          MessageBoxImage.Error);
                    return;
                }

                _tray.CopyTray(result);
                RefreshTrayList();
                SetButtonState();
            }
        }
    }
    private DelegateCommand _copyTrayCommand;

    /// <summary>
    /// 刪除Tray命令。
    /// </summary>
    public DelegateCommand DeleteTrayCommand
        => _deleteTrayCommand ??= new DelegateCommand(ExecuteDeleteTrayCommand);
    private void ExecuteDeleteTrayCommand()
    {
        if (SelectedTrayItem != null)
        {
            // 刪除確認
            if (_prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DeleteConfirmation")}\n{GetResource.GetValue<string>("Glorytek.WFSCore", "TrayName2")}: {SelectedTrayItem.Name}",
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "Message_Delete"),
                                      MessageBoxImage.Question,
                                      PrismMessageBoxButton.YesNo) == ButtonResult.Yes)
            {
                _tray.DeleteTray(SelectedTrayItem.Id);
                RefreshTrayList();
            }

            SetButtonState();
        }
    }
    private DelegateCommand _deleteTrayCommand;

    /// <summary>
    /// Tray排序上移命令。
    /// </summary>
    public DelegateCommand<int?> TrayOrderMoveUpCommand
        => _trayOrderMoveUpCommand ??= new DelegateCommand<int?>(ExecuteTrayOrderMoveUpCommand);
    void ExecuteTrayOrderMoveUpCommand(int? trayId)
    {
        int targetSelectedIndex = SelectedTrayIndex - 1;
        if (_tray.MoveOrderUp((int)trayId))
        {
            RefreshTrayList();
            SelectedTrayIndex = targetSelectedIndex;
        }
    }
    private DelegateCommand<int?> _trayOrderMoveUpCommand;

    /// <summary>
    /// Tray排序下移命令。
    /// </summary>
    public DelegateCommand<int?> TrayOrderMoveDownCommand
        => _trayOrderMoveDownCommand ??= new DelegateCommand<int?>(ExecuteTrayOrderMoveDownCommand);
    void ExecuteTrayOrderMoveDownCommand(int? trayId)
    {
        int targetSelectedIndex = SelectedTrayIndex + 1;
        if (_tray.MoveOrderDown((int)trayId))
        {
            RefreshTrayList();
            SelectedTrayIndex = targetSelectedIndex;
        }
    }
    private DelegateCommand<int?> _trayOrderMoveDownCommand;

    /********************
     * Functions
     ********************/
    /// <summary>
    /// 移動至基準點命令。
    /// </summary>
    public DelegateCommand MoveToDpCommand
        => _moveToDpCommand ??= new DelegateCommand(ExecuteMoveToDpCommand);
    private async void ExecuteMoveToDpCommand()
    {
        //var pallet = _tray.PalletList.Find(x => x.Id == SelectedTrayItem.PositionId);

        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (SelectedTrayItem.DatumX + _machine.Machine.DatumPointX).WfsFormat(),
                                (SelectedTrayItem.DatumY + _machine.Machine.DatumPointY).WfsFormat(),
                                0.0);
    }
    private DelegateCommand _moveToDpCommand;

    /// <summary>
    /// 取得指定點位命令。
    /// </summary>
    public DelegateCommand OpenTrayMatrixSelectorCommand
        => _openTrayMatrixSelectorCommand ??= new DelegateCommand(ExecuteOpenTrayMatrixSelectorCommand);
    private void ExecuteOpenTrayMatrixSelectorCommand()
    {
        var tmsi = new TrayMatrixSelectorInfo
        {
            TrayId = SelectedTrayItem.Id,
            SequenceNo = _pd.PickPointNo[SelectedTrayItem.Id]
        };

        var paras = new DialogParameters()
            {
                {
                    "StatusBarMessage",
                    JsonConvert.SerializeObject(tmsi, new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore
                    })
                }
            };

        IDialogResult _dialogResult = default;
        _dialogService.ShowDialog(nameof(Views.TrayMatrixSelector), paras, r => { _dialogResult = r; });

        if (_dialogResult.Result == ButtonResult.OK)
        {
            tmsi = JsonConvert.DeserializeObject<TrayMatrixSelectorInfo>(_dialogResult.Parameters.GetValue<string>("StatusBarMessage"));
            //if (tmsi.SequenceNo >= 1)
            //    PlcDatas.Instance.PointNo[SelectedTrayItem.Id] = tmsi.SequenceNo;
        }
    }
    private DelegateCommand _openTrayMatrixSelectorCommand;

    /// <summary>
    /// 移動至取料高度命令。
    /// </summary>
    public DelegateCommand MoveToPickHeightCommand
        => _moveToPickHeightCommand ??= new DelegateCommand(ExecuteMoveToPickHeightCommand);
    private async void ExecuteMoveToPickHeightCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                _plc.XAxisPosition,
                                _plc.YAxisPosition,
                                (SelectedTrayItem.PickHeight + _machine.Machine.HeightCorrection + _machine.Machine.DatumPointZ).WfsFormat());
    }
    private DelegateCommand _moveToPickHeightCommand;

    /// <summary>
    /// 取得取料高度命令。
    /// </summary>
    public DelegateCommand GetPickHeightCoordinateCommand
        => _getPickHeightCoordinateCommand ??= new DelegateCommand(ExecuteGetPickHeightCoordinateCommand);
    private void ExecuteGetPickHeightCoordinateCommand()
    {
        SelectedTrayItem.PickHeight = (_plc.ZAxisPosition - _machine.Machine.HeightCorrection - _machine.Machine.DatumPointZ).WfsFormat();
    }
    private DelegateCommand _getPickHeightCoordinateCommand;

    /********************
     * ABC
     ********************/
    /// <summary>
    /// ABC設定Group第一組Header。
    /// </summary>
    public string ArrangeHeader1
    {
        get { return _arrangeHeader1; }
        set { SetProperty(ref _arrangeHeader1, value); }
    }
    private string _arrangeHeader1;

    /// <summary>
    /// 
    /// </summary>
    public TrayArrangementType SelectedArrangement
    {
        get { return _selectedArrangement; }
        set
        {
            SetProperty(ref _selectedArrangement, value);
            SelectedTrayItem.Arrangement = value;

            if (value == TrayArrangementType.ArrangeInOrder)
                ArrangeHeader1 = GetResource.GetValue<string>("Caption_ArrangeInOrder");
            else
                ArrangeHeader1 = GetResource.GetValue<string>("Caption_ArrangeInCross1");
        }
    }
    private TrayArrangementType _selectedArrangement;

    /// <summary>
    /// 移動至Order點位A命令。
    /// </summary>
    public DelegateCommand MoveToOrderACommand
        => _moveToOrderACommand ??= new DelegateCommand(ExecuteMoveToOrderACommand);
    private async void ExecuteMoveToOrderACommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (SelectedTrayItem.Order_PositionA_X + SelectedTrayItem.DatumX + _machine.Machine.DatumPointX).WfsFormat(),
                                (SelectedTrayItem.Order_PositionA_Y + SelectedTrayItem.DatumY + _machine.Machine.DatumPointY).WfsFormat(),
                                0.0);
    }
    private DelegateCommand _moveToOrderACommand;

    /// <summary>
    /// 移動至Order點位B命令。
    /// </summary>
    public DelegateCommand MoveToOrderBCommand
        => _moveToOrderBCommand ??= new DelegateCommand(ExecuteMoveToOrderBCommand);
    private async void ExecuteMoveToOrderBCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (SelectedTrayItem.Order_PositionB_X + SelectedTrayItem.DatumX + _machine.Machine.DatumPointX).WfsFormat(),
                                (SelectedTrayItem.Order_PositionB_Y + SelectedTrayItem.DatumY + _machine.Machine.DatumPointY).WfsFormat(),
                                0.0);
    }
    private DelegateCommand _moveToOrderBCommand;

    /// <summary>
    /// 移動至Order點位C命令。
    /// </summary>
    public DelegateCommand MoveToOrderCCommand
        => _moveToOrderCCommand ??= new DelegateCommand(ExecuteMoveToOrderCCommand);
    private async void ExecuteMoveToOrderCCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (SelectedTrayItem.Order_PositionC_X + SelectedTrayItem.DatumX + _machine.Machine.DatumPointX).WfsFormat(),
                                (SelectedTrayItem.Order_PositionC_Y + SelectedTrayItem.DatumY + _machine.Machine.DatumPointY).WfsFormat(),
                                0.0);
    }
    private DelegateCommand _moveToOrderCCommand;

    /// <summary>
    /// 取得Order點位A座標命令。
    /// </summary>
    public DelegateCommand GetOrderACoordinateCommand
        => _getOrderACoordinateCommand ??= new DelegateCommand(ExecuteGetOrderACoordinateCommand);
    private void ExecuteGetOrderACoordinateCommand()
    {
        SelectedTrayItem.Order_PositionA_X = (_plc.XAxisPosition - SelectedTrayItem.DatumX - _machine.Machine.DatumPointX).WfsFormat();
        SelectedTrayItem.Order_PositionA_Y = (_plc.YAxisPosition - SelectedTrayItem.DatumY - _machine.Machine.DatumPointY).WfsFormat();
    }
    private DelegateCommand _getOrderACoordinateCommand;

    /// <summary>
    /// 取得Order點位B座標命令。
    /// </summary>
    public DelegateCommand GetOrderBCoordinateCommand
        => _getOrderBCoordinateCommand ??= new DelegateCommand(ExecuteGetOrderBCoordinateCommand);
    private void ExecuteGetOrderBCoordinateCommand()
    {
        SelectedTrayItem.Order_PositionB_X = (_plc.XAxisPosition - SelectedTrayItem.DatumX - _machine.Machine.DatumPointX).WfsFormat();
        SelectedTrayItem.Order_PositionB_Y = (_plc.YAxisPosition - SelectedTrayItem.DatumY - _machine.Machine.DatumPointY).WfsFormat();
    }
    private DelegateCommand _getOrderBCoordinateCommand;

    /// <summary>
    /// 取得Order點位C座標命令。
    /// </summary>
    public DelegateCommand GetOrderCCoordinateCommand
        => _getOrderCCoordinateCommand ??= new DelegateCommand(ExecuteGetOrderCCoordinateCommand);
    private void ExecuteGetOrderCCoordinateCommand()
    {
        SelectedTrayItem.Order_PositionC_X = (_plc.XAxisPosition - SelectedTrayItem.DatumX - _machine.Machine.DatumPointX).WfsFormat();
        SelectedTrayItem.Order_PositionC_Y = (_plc.YAxisPosition - SelectedTrayItem.DatumY - _machine.Machine.DatumPointY).WfsFormat();
    }
    private DelegateCommand _getOrderCCoordinateCommand;

    /// <summary>
    /// 移動至Cross點位A命令。
    /// </summary>
    public DelegateCommand MoveToCrossACommand
        => _moveToCrossACommand ??= new DelegateCommand(ExecuteMoveToCrossACommand);
    private async void ExecuteMoveToCrossACommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (SelectedTrayItem.Cross_PositionA_X + SelectedTrayItem.DatumX + _machine.Machine.DatumPointX).WfsFormat(),
                                (SelectedTrayItem.Cross_PositionA_Y + SelectedTrayItem.DatumY + _machine.Machine.DatumPointY).WfsFormat(),
                                0.0);
    }
    private DelegateCommand _moveToCrossACommand;

    /// <summary>
    /// 移動至Cross點位B命令。
    /// </summary>
    public DelegateCommand MoveToCrossBCommand
        => _moveToCrossBCommand ??= new DelegateCommand(ExecuteMoveToCrossBCommand);
    private async void ExecuteMoveToCrossBCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (SelectedTrayItem.Cross_PositionB_X + SelectedTrayItem.DatumX + _machine.Machine.DatumPointX).WfsFormat(),
                                (SelectedTrayItem.Cross_PositionB_Y + SelectedTrayItem.DatumY + _machine.Machine.DatumPointY).WfsFormat(),
                                0.0);
    }
    private DelegateCommand _moveToCrossBCommand;

    /// <summary>
    /// 移動至Cross點位C命令。
    /// </summary>
    public DelegateCommand MoveToCrossCCommand
        => _moveToCrossCCommand ??= new DelegateCommand(ExecuteMoveToCrossCCommand);
    private async void ExecuteMoveToCrossCCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (SelectedTrayItem.Cross_PositionC_X + SelectedTrayItem.DatumX + _machine.Machine.DatumPointX).WfsFormat(),
                                (SelectedTrayItem.Cross_PositionC_Y + SelectedTrayItem.DatumY + _machine.Machine.DatumPointY).WfsFormat(),
                                0.0);
    }
    private DelegateCommand _moveToCrossCCommand;

    /// <summary>
    /// 取得Cross點位A座標命令。
    /// </summary>
    public DelegateCommand GetCrossACoordinateCommand
        => _getCrossACoordinateCommand ??= new DelegateCommand(ExecuteGetCrossACoordinateCommand);
    private void ExecuteGetCrossACoordinateCommand()
    {
        SelectedTrayItem.Cross_PositionA_X = (_plc.XAxisPosition - SelectedTrayItem.DatumX - _machine.Machine.DatumPointX).WfsFormat();
        SelectedTrayItem.Cross_PositionA_Y = (_plc.YAxisPosition - SelectedTrayItem.DatumY - _machine.Machine.DatumPointY).WfsFormat();
    }
    private DelegateCommand _getCrossACoordinateCommand;

    /// <summary>
    /// 取得Cross點位B座標命令。
    /// </summary>
    public DelegateCommand GetCrossBCoordinateCommand
        => _getCrossBCoordinateCommand ??= new DelegateCommand(ExecuteGetCrossBCoordinateCommand);
    private void ExecuteGetCrossBCoordinateCommand()
    {
        SelectedTrayItem.Cross_PositionB_X = (_plc.XAxisPosition - SelectedTrayItem.DatumX - _machine.Machine.DatumPointX).WfsFormat();
        SelectedTrayItem.Cross_PositionB_Y = (_plc.YAxisPosition - SelectedTrayItem.DatumY - _machine.Machine.DatumPointY).WfsFormat();
    }
    private DelegateCommand _getCrossBCoordinateCommand;

    /// <summary>
    /// 取得Cross點位C座標命令。
    /// </summary>
    public DelegateCommand GetCrossCCoordinateCommand
        => _getCrossCCoordinateCommand ??= new DelegateCommand(ExecuteGetCrossCCoordinateCommand);
    private void ExecuteGetCrossCCoordinateCommand()
    {
        SelectedTrayItem.Cross_PositionC_X = (_plc.XAxisPosition - SelectedTrayItem.DatumX - _machine.Machine.DatumPointX).WfsFormat();
        SelectedTrayItem.Cross_PositionC_Y = (_plc.YAxisPosition - SelectedTrayItem.DatumY - _machine.Machine.DatumPointY).WfsFormat();
    }
    private DelegateCommand _getCrossCCoordinateCommand;

    /********************
     * Data Binding
     ********************/
    /// <summary>
    /// 
    /// </summary>
    public ObservableCollection<TrayDefine> TrayListSource
    {
        get { return _trayListSource; }
        set { SetProperty(ref _trayListSource, value); }
    }
    private ObservableCollection<TrayDefine> _trayListSource;

    /// <summary>
    /// 
    /// </summary>
    public int SelectedTrayIndex
    {
        get { return _selectedTrayIndex; }
        set { SetProperty(ref _selectedTrayIndex, value); }
    }
    private int _selectedTrayIndex = -1;

    //
    private bool _editSelectedItemSelf = false;

    /// <summary>
    /// 編輯自己時，跳過觸發繫結更新。
    /// </summary>
    public TrayDefine SelectedTrayItem
    {
        get { return _selectedTrayItem; }
        set
        {
            if (!_editSelectedItemSelf)
            {
                _editSelectedItemSelf = true;
                SetProperty(ref _selectedTrayItem, value);

                if (value != null)
                {
                    UpdateDatumPosition(value.PositionId);
                    SelectedArrangement = value.Arrangement;
                    UpdateTrayMatrixSource();
                }

                ScreenEnabled = value != null;
                SetButtonState();
                _editSelectedItemSelf = false;
            }
        }
    }
    private TrayDefine _selectedTrayItem;

    /// <summary>
    /// 
    /// </summary>
    public DelegateCommand<object> PositionChangedEvent
        => _positionChangedEvent ??= new DelegateCommand<object>(ExecutePositionChangedEvent);
    private void ExecutePositionChangedEvent(object para)
    {
        if (para != null)
            if (int.TryParse(para.ToString(), out int posiId))
                UpdateDatumPosition(posiId);
    }
    private DelegateCommand<object> _positionChangedEvent;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="palletId"></param>
    private void UpdateDatumPosition(int palletId)
    {
        var pallet = _tray.PalletList.Find(x => x.Id == palletId);
        SelectedTrayItem.DatumX = pallet.DatumX;
        SelectedTrayItem.DatumY = pallet.DatumY;
    }

    /// <summary>
    /// 分頁切換。
    /// </summary>
    public TabItem TrayTabSelection
    {
        get { return _trayTabSelection; }
        set
        {
            SetProperty(ref _trayTabSelection, value);

            switch (value.Name)
            {
                //case "HeightCorrection":
                //    break;

                //case "AbcCorrection":
                //    break;

                case "ShowMatrix":
                    UpdateTrayMatrixSource();
                    break;
            }
        }
    }
    private TabItem _trayTabSelection;

    /// <summary>
    /// 更新Tray矩陣顯示。
    /// </summary>
    private void UpdateTrayMatrixSource()
    {
        TrayMatrixRegionContext tmrc = new()
        {
            Tray = SelectedTrayItem.DeepCopyByExpressionTree(),
            PalletId = SelectedTrayItem.PositionId,
        };

        // 見 TrayMatrix.xaml.cs 中 ThisTray_PropertyChanged() 的註解 <see cref="TrayMatrix.TrayMatrix()"/>
        TrayMatrixSource = null;
        TrayMatrixSource = tmrc;
    }

    /********************
     * TrayMatrix
     ********************/
    /// <summary>
    /// 傳遞給TrayMatrix的資料。
    /// </summary>
    public TrayMatrixRegionContext TrayMatrixSource
    {
        get { return _trayMatrixSource; }
        set { SetProperty(ref _trayMatrixSource, value); }
    }
    private TrayMatrixRegionContext _trayMatrixSource;

    /********************
     *
     ********************/
    /// <summary>
    /// 啟用。
    /// </summary>
    public bool ScreenEnabled
    {
        get { return _screenEnabled; }
        set { SetProperty(ref _screenEnabled, value); }
    }
    private bool _screenEnabled;

    /// <summary>
    /// Function Button。
    /// </summary>
    public bool TrayFuncEnabled
    {
        get { return _trayFuncEnabled; }
        set { SetProperty(ref _trayFuncEnabled, value); }
    }
    private bool _trayFuncEnabled;

    public bool TrayFuncNotFirstEnabled
    {
        get { return _trayFuncNotFirstEnabled; }
        set { SetProperty(ref _trayFuncNotFirstEnabled, value); }
    }
    private bool _trayFuncNotFirstEnabled;

    public bool TrayFuncNotLastEnabled
    {
        get { return _trayFuncNotLastEnabled; }
        set { SetProperty(ref _trayFuncNotLastEnabled, value); }
    }
    private bool _trayFuncNotLastEnabled;
}
