﻿using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Stage.Contracts;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Models.Stage;
using Glorytek.WFSCore.Models.System;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSExternal.Displacement;
using Glorytek.WFSExternal.PLC.Constants;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.Vision;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using Serilog;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 教導頁面的ViewModel。
/// </summary>
public class TeachingViewModel : BindableBase, IConfirmNavigationRequest, IActiveAware
{
    private PalletDefine _lastPalletSelection = null;

    /********************
     * IConfirmNavigationRequest
     ********************/
    public void ConfirmNavigationRequest(NavigationContext navigationContext, Action<bool> continuationCallback)
    {
        bool result = true;

        //if (!MachineDatas.Equals(SysParameters.Instance.Machine)
        //    //|| Stages != _stage.Stages
        //    || !PalletPointEqual())
        //{
        //    ButtonResult userChoice = _sys.DataNotSavedWhenLeave();

        //    if (userChoice == ButtonResult.Yes)
        //        WriteData();
        //    else if (userChoice == ButtonResult.Cancel)
        //    {
        //        _sysMessenger.LightUpPreviousMainMenuButton(string.Empty);
        //        result = false;
        //    }
        //}

        //MachineDatas = null;
        //StageA1 = null;
        //StageA2 = null;
        //Pallet = null;
        continuationCallback(result);
    }

    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        LoadData();
        UpdateDistanceFromNozzleToCamera();

        // 更新Title
        TabItemSelected_MachineDatum = TabItemSelected_MachineDatum;
        TabItemSelected_ClayTable = TabItemSelected_ClayTable;
        TabItemSelected_Displacement = TabItemSelected_Displacement;
        TabItemSelected_Stage = TabItemSelected_Stage;
        TabItemSelected_PalletInstallPoints = TabItemSelected_PalletInstallPoints;
        TabItemSelected_RepeatabilityTest = TabItemSelected_RepeatabilityTest;
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    private bool _isActive = false;
    public bool IsActive
    {
        get { return _isActive; }
        set
        {
            _isActive = value;
            OnIsActiveChanged();

            if (_isActive)
                PalletSelection = _lastPalletSelection;
            else
                _lastPalletSelection = PalletSelection;
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    /********************
     * ctor
     ********************/
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly IMachine _machine;
    private readonly ISystemMessenger _sysMessenger;
    private readonly IProductManager _pm;
    private readonly IStage _stage;
    private readonly ITray _tray;
    private readonly IPlc _plc;
    private readonly IVision _vision;

    public TeachingViewModel(IApplicationCommands applicationCommands,
                             IPrismMessageBox prismMessageBox,
                             ISystemMessenger sysMessenger,
                             IMachine machine,
                             IProductManager pm,
                             IStage stage,
                             ITray tray,
                             IPlc plc,
                             IVision vision)
    {
        _prismMessageBox = prismMessageBox;
        _machine = machine;
        _sysMessenger = sysMessenger;
        _pm = pm;
        _stage = stage;
        _tray = tray;
        _plc = plc;
        _vision = vision;

        TabItemSelected_MachineDatum = true;

        // TODO: UnregisterCommand
        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /********************
     * 全域指令
     ********************/
    /// <summary>
    /// 將資料或參數寫入資料庫。
    /// </summary>
    public void ExecuteSaveDataCommand()
    {
        WriteData();
    }

    /********************
    * 數據處理
    ********************/
    /// <summary>
    /// 將View資料寫入Model及資料庫。
    /// </summary>
    public void WriteData()
    {
        string productName = $"[{_pm.ActiveProductName}]  ";

        /********************
         * 基準點
         ********************/
        var mac = SysParameters.Instance.Machine;
        string paraChangeList = "參數變更-基準點";
        bool paraChanged = false;

        if (mac.DatumPointX != MachineDatas.DatumPointX || mac.DatumPointY != MachineDatas.DatumPointY)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_CameraCoordinate")} [X] {mac.DatumPointX:F3} -> {MachineDatas.DatumPointX:F3} [Y] {mac.DatumPointY:F3} -> {MachineDatas.DatumPointY:F3}";
            paraChanged = true;
        }
        //if (_md.DatumPointZ != MachineDatas.DatumPointZ)
        //{
        //}
        if (mac.SafetyHeight != MachineDatas.SafetyHeight)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_SafetyHeight")} [Z] {mac.SafetyHeight:F3} -> {MachineDatas.SafetyHeight:F3}";
            paraChanged = true;
        }
        if (mac.RAxisZeroDegreeCorrection != MachineDatas.RAxisZeroDegreeCorrection)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_RAxisZeroDegreeCorrection")} [R] {mac.RAxisZeroDegreeCorrection:F1} -> {MachineDatas.RAxisZeroDegreeCorrection:F1}";
            paraChanged = true;
        }
        if (mac.DatumPointVisionId != MachineDatas.DatumPointVisionId)
        {
            paraChangeList += $"\n  [{GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_VisionCategory")}] {mac.DatumPointVisionId} -> {MachineDatas.DatumPointVisionId}";
            paraChanged = true;
        }

        // 記錄參數變更
        if (paraChanged)
            Log.Information(paraChangeList);

        /********************
         * 黏土座
         ********************/
        paraChangeList = "參數變更-黏土座";
        paraChanged = false;

        if (mac.NozzleStampX != MachineDatas.NozzleStampX || mac.NozzleStampY != MachineDatas.NozzleStampY)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_NozzleStamp")} [X] {mac.NozzleStampX:F3} -> {MachineDatas.NozzleStampX:F3} [Y] {mac.NozzleStampY:F3} -> {MachineDatas.NozzleStampY:F3}";
            paraChanged = true;
        }
        if (mac.NozzleStampZ != MachineDatas.NozzleStampZ)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_Height_Z")} [Z] {mac.NozzleStampZ:F3} -> {MachineDatas.NozzleStampZ:F3}";
            paraChanged = true;
        }
        if (mac.ClayTableX != MachineDatas.ClayTableX || mac.ClayTableY != MachineDatas.ClayTableY)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_CameraCoordinate")} [X] {mac.ClayTableX:F3} -> {MachineDatas.ClayTableX:F3} [Y] {mac.ClayTableY:F3} -> {MachineDatas.ClayTableY:F3}";
            paraChanged = true;
        }
        //if (  mac.ClayTableZ != MachineDatas.ClayTableZ)
        //{
        //    paraChangeList += $"\n  {GetLocalizeResource.GetValue<string>("WFSCore", "Caption_Height_Z")} [Z] {mac.ClayTableZ:F3} -> {MachineDatas.ClayTableZ:F3}";
        //    paraChanged = true;
        //}
        if (mac.ClayTableVisionId != MachineDatas.ClayTableVisionId)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_VisionCategory")} [ID] {mac.ClayTableVisionId} -> {MachineDatas.ClayTableVisionId}";
            paraChanged = true;
        }

        // 記錄參數變更
        if (paraChanged)
            Log.Information(paraChangeList);

        /********************
         * 測高用位移計
         ********************/
        paraChangeList = "參數變更-測高用位移計";
        paraChanged = false;

        if (mac.DisplacementX != MachineDatas.DisplacementX || mac.DisplacementY != MachineDatas.DisplacementY)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_CameraCoordinate")} [X] {mac.DisplacementX:F3} -> {MachineDatas.DisplacementX:F3} [Y] {mac.DisplacementY:F3} -> {MachineDatas.DisplacementY:F3}";
            paraChanged = true;
        }
        if (mac.DisplacementZ != MachineDatas.DisplacementZ)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_Height")} [Z] {mac.DisplacementZ:F3} -> {MachineDatas.DisplacementZ:F3}";
            paraChanged = true;
        }
        if (mac.HeightCorrection != MachineDatas.HeightCorrection)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_HeightCorrectionValue")} [Z] {mac.HeightCorrection:F3} -> {MachineDatas.HeightCorrection:F3}";
            paraChanged = true;
        }
        if (mac.LastMeasureHeight != MachineDatas.LastMeasureHeight)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_LastMeasureHeight")} [Z] {mac.LastMeasureHeight:F3} -> {MachineDatas.LastMeasureHeight:F3}";
            paraChanged = true;
        }

        // 記錄參數變更
        if (paraChanged)
            Log.Information(paraChangeList);

        /********************e
         * Stage A1
         ********************/
        var stageSource = _stage.StageA1;
        paraChangeList = $"{productName}參數變更 - 取放治具A1";
        paraChanged = false;

        if (StageA1.CoorX != stageSource.CoorX || StageA1.CoorY != stageSource.CoorY)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_CameraCoordinate")} [X] {stageSource.CoorX:F3} -> {StageA1.CoorX:F3} [Y] {stageSource.CoorY:F3} -> {StageA1.CoorY:F3}";
            paraChanged = true;
        }
        if (StageA1.CoorZ != stageSource.CoorZ)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Caption_ZAxisCoor")} [Z] {stageSource.CoorZ:F3} -> {StageA1.CoorZ:F3}";
            paraChanged = true;
        }

        // 記錄參數變更
        if (paraChanged)
            Log.Information(paraChangeList);

        /********************
         * Stage A2
         ********************/
        stageSource = _stage.StageA2;
        paraChangeList = $"{productName}參數變更-取放治具A2";
        paraChanged = false;

        if (StageA2.CoorX != stageSource.CoorX || StageA2.CoorY != stageSource.CoorY)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_CameraCoordinate")} [X] {stageSource.CoorX:F3} -> {StageA2.CoorX:F3} [Y] {stageSource.CoorY:F3} -> {StageA2.CoorY:F3}";
            paraChanged = true;
        }
        if (StageA2.CoorZ != stageSource.CoorZ)
        {
            paraChangeList += $"\n  {GetResource.GetValue<string>("Caption_ZAxisCoor")} [Z] {stageSource.CoorZ:F3} -> {StageA2.CoorZ:F3}";
            paraChanged = true;
        }

        // 記錄參數變更
        if (paraChanged)
            Log.Information(paraChangeList);

        /********************
         * 寫入Database
         ********************/
        SysParameters.Instance.Machine = MachineDatas.DeepCopyByExpressionTree();
        _machine.WriteToPlc();

        _stage.StageA1 = StageA1;
        _stage.StageA2 = StageA2;
        _stage.WriteToDb();
        _stage.WriteToPlc();

        TrayParameters.Instance.PalletList = Pallet.ToList();
        _tray.WriteTrayToDb();
    }

    /// <summary>
    /// 從Model載入資料至View。
    /// </summary>
    public void LoadData()
    {
        MachineDatas = SysParameters.Instance.Machine.DeepCopyByExpressionTree();
        StageA1 = _stage.StageA1;
        StageA2 = _stage.StageA2;
        Pallet = new ObservableCollection<PalletDefine>(TrayParameters.Instance.PalletList);

        // 注意：目前定傑規劃以GT做基準，故基準點直接設0
        MachineDatas.DatumPointZ = 0.0;

        UpdateDistanceFromNozzleToCamera();
    }

    /// <summary>
    /// 重算和吸嘴與相機相對距離相關的數據。
    /// </summary>
    /// <remarks>此數值僅做顯示用，PLC內部另有自行計算。</remarks>
    private void UpdateDistanceFromNozzleToCamera()
    {
        MachineDatas.DistanceFromNozzleToCameraX = (MachineDatas.NozzleStampX - MachineDatas.ClayTableX).WfsFormat();
        MachineDatas.DistanceFromNozzleToCameraY = (MachineDatas.NozzleStampY - MachineDatas.ClayTableY).WfsFormat();

        NozzlePostionInDatumX = (MachineDatas.DatumPointX - _machine.Machine.DatumPointX + MachineDatas.DistanceFromNozzleToCameraX).WfsFormat();
        NozzlePostionInDatumY = (MachineDatas.DatumPointY - _machine.Machine.DatumPointY + MachineDatas.DistanceFromNozzleToCameraY).WfsFormat();
        NozzlePostionInDisplacementX = (MachineDatas.DisplacementX + MachineDatas.DistanceFromNozzleToCameraX).WfsFormat();
        NozzlePostionInDisplacementY = (MachineDatas.DisplacementY + MachineDatas.DistanceFromNozzleToCameraY).WfsFormat();
        NozzlePostionInA1X = (StageA1.CoorX + MachineDatas.DistanceFromNozzleToCameraX).WfsFormat();
        NozzlePostionInA1Y = (StageA1.CoorY + MachineDatas.DistanceFromNozzleToCameraY).WfsFormat();
        NozzlePostionInA2X = (StageA2.CoorX + MachineDatas.DistanceFromNozzleToCameraX).WfsFormat();
        NozzlePostionInA2Y = (StageA2.CoorY + MachineDatas.DistanceFromNozzleToCameraY).WfsFormat();
    }

    /********************
     * Page
     ********************/
    /// <summary>
    /// 機台基準點。
    /// </summary>
    public bool TabItemSelected_MachineDatum
    {
        get { return _tabItemSelected_MachineDatum; }
        set
        {
            SetProperty(ref _tabItemSelected_MachineDatum, value);
            if (value)
                _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Glorytek.WFSComponents", "TabItem_Teaching_MachineDatum"));
        }
    }
    private bool _tabItemSelected_MachineDatum;

    /// <summary>
    /// 黏土座。
    /// </summary>
    public bool TabItemSelected_ClayTable
    {
        get { return _tabItemSelected_ClayTable; }
        set
        {
            SetProperty(ref _tabItemSelected_ClayTable, value);
            if (value)
                _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Glorytek.WFSComponents", "TabItem_Teaching_ClayTable"));
        }
    }
    private bool _tabItemSelected_ClayTable;

    /// <summary>
    /// 測高用位移計。
    /// </summary>
    public bool TabItemSelected_Displacement
    {
        get { return _tabItemSelected_Displacement; }
        set
        {
            SetProperty(ref _tabItemSelected_Displacement, value);
            if (value)
                _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Glorytek.WFSComponents", "TabItem_Teaching_Displacement"));
        }
    }
    private bool _tabItemSelected_Displacement;

    /// <summary>
    /// STAGE。
    /// </summary>
    public bool TabItemSelected_Stage
    {
        get { return _tabItemSelected_Stage; }
        set
        {
            SetProperty(ref _tabItemSelected_Stage, value);
            if (value)
                _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Glorytek.WFSComponents", "TabItem_Teaching_Stage"));
        }
    }
    private bool _tabItemSelected_Stage;

    /// <summary>
    /// Pallet安裝點。
    /// </summary>
    public bool TabItemSelected_PalletInstallPoints
    {
        get { return _tabItemSelected_PalletInstallPoints; }
        set
        {
            SetProperty(ref _tabItemSelected_PalletInstallPoints, value);
            if (value)
                _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Glorytek.WFSComponents", "TabItem_Teaching_PalletInstallPoints"));
        }
    }
    private bool _tabItemSelected_PalletInstallPoints;

    /// <summary>
    /// 重複精度測試。
    /// </summary>
    public bool TabItemSelected_RepeatabilityTest
    {
        get { return _tabItemSelected_RepeatabilityTest; }
        set
        {
            SetProperty(ref _tabItemSelected_RepeatabilityTest, value);
            if (value)
                _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("Glorytek.WFSComponents", "TabItem_Teaching_RepeatabilityTest"));
        }
    }
    private bool _tabItemSelected_RepeatabilityTest;

    /********************
     * 製作參數報表
     ********************/
    /// <summary>
    /// 將參數輸出成EXCEL檔命令。(尚未實現)
    /// </summary>
    public DelegateCommand OutputParametersReportCommand
        => _outputParametersReportCommand ??= new DelegateCommand(ExecuteOutputParametersReportCommand);
    private void ExecuteOutputParametersReportCommand()
    {

    }
    private DelegateCommand _outputParametersReportCommand;

    /********************
     * 基準點
     ********************/
    /// <summary>
    /// 移動至基準點命令。
    /// </summary>
    public DelegateCommand MoveToDpCommand
        => _moveToDpCommand ??= new DelegateCommand(ExecuteMoveToDpCommand);
    private async void ExecuteMoveToDpCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                MachineDatas.DatumPointX,
                                MachineDatas.DatumPointY,
                                0.0);
    }
    private DelegateCommand _moveToDpCommand;

    /// <summary>
    /// 取得基準點座標命令。
    /// </summary>
    public DelegateCommand GetDpCoordinateCommand
        => _getDpCoordinateCommand ??= new DelegateCommand(ExecuteGetDpCoordinateCommand);
    private void ExecuteGetDpCoordinateCommand()
    {
        MachineDatas.DatumPointX = (_plc.XAxisPosition).WfsFormat();
        MachineDatas.DatumPointY = (_plc.YAxisPosition).WfsFormat();
        UpdateDistanceFromNozzleToCamera();
    }
    private DelegateCommand _getDpCoordinateCommand;

    /// <summary>
    /// 取得基準點高度命令。
    /// </summary>
    public DelegateCommand GetDpZCommand
        => _getDpZCommand ??= new DelegateCommand(ExecuteGetDpZCommand);
    private void ExecuteGetDpZCommand()
    {
        MachineDatas.DatumPointZ = (_plc.ZAxisPosition).WfsFormat();
    }
    private DelegateCommand _getDpZCommand;

    /// <summary>
    /// 移至基準點畫像中心命令。
    /// </summary>
    public DelegateCommand MoveToDpVisionCenterCommand
        => _moveToDpVisionCenterCommand ??= new DelegateCommand(ExecuteMoveToDpVisionCenterCommand);
    private async void ExecuteMoveToDpVisionCenterCommand()
    {
        double nowX = (_plc.XAxisPosition - DatumPointVisionX).WfsFormat();
        double nowY = (_plc.YAxisPosition - DatumPointVisionY).WfsFormat();
        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
        MoveToDpCounter++;
    }
    private DelegateCommand _moveToDpVisionCenterCommand;

    /// <summary>
    /// 計算基準點畫像中心命令。
    /// </summary>
    public DelegateCommand CalcDpVisionCenterCommand
        => _calcDpVisionCenterCommand ??= new DelegateCommand(ExecuteCalcDpVisionCenterCommand);
    private void ExecuteCalcDpVisionCenterCommand()
    {
        VisionData vdi = new VisionData()
        {
            ProductType = MachineDatas.DatumPointVisionId,
        };

        if (_vision.TakePicture(ref vdi))
        {
            if (vdi.OK)
            {
                DatumPointVisionX = vdi.X;
                DatumPointVisionY = vdi.Y;
                MoveToDpCounter = 0;
            }
            else if (vdi.NG)
            {
                //_sysMessenger.StatusBarMessage("拍照結果為NG！");
            }
        }
        else
        {
            string errMsg = "拍照失敗或未接收到視覺系統回傳資料！";
            Log.Error($"TeachingViewModel  ->  CalcDpVisionCenterCommand(): {errMsg}");
            _ = _prismMessageBox.Show(errMsg, "視覺系統錯誤", MessageBoxImage.Error);
        }
    }
    private DelegateCommand _calcDpVisionCenterCommand;

    /// <summary>
    /// 移動吸嘴至基準點命令。
    /// </summary>
    public DelegateCommand MoveNozzleToDatumCommand
        => _moveNozzleToDatumCommand ??= new DelegateCommand(ExecuteCommandName);
    private async void ExecuteCommandName()
    {
        double nowX = (NozzlePostionInDatumX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (NozzlePostionInDatumY + MachineDatas.DatumPointY).WfsFormat();

        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
    }
    private DelegateCommand _moveNozzleToDatumCommand;

    /********************
     * 安全位置
     ********************/
    /// <summary>
    /// 移至安全位置命令。
    /// </summary>
    public DelegateCommand MoveToSafetyPositionCommand
        => _moveToSafetyPositionCommand ??= new DelegateCommand(ExecuteMoveToSafetyPositionCommand);
    private async void ExecuteMoveToSafetyPositionCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                MachineDatas.SafetyX + MachineDatas.DatumPointX,
                                MachineDatas.SafetyY + MachineDatas.DatumPointY,
                                0.0);
    }
    private DelegateCommand _moveToSafetyPositionCommand;

    /// <summary>
    /// 取得安全位置命令。
    /// </summary>
    public DelegateCommand GetSafetyPositionCoordinateCommand
        => _getSafetyPositionCoordinateCommand ??= new DelegateCommand(ExecuteGetSafetyPositionCoordinateCommand);
    private void ExecuteGetSafetyPositionCoordinateCommand()
    {
        MachineDatas.SafetyX = (_plc.XAxisPosition - MachineDatas.DatumPointX).WfsFormat();
        MachineDatas.SafetyY = (_plc.YAxisPosition - MachineDatas.DatumPointY).WfsFormat();
    }
    private DelegateCommand _getSafetyPositionCoordinateCommand;

    /// <summary>
    /// 取得安全位置高度命令。
    /// </summary>
    public DelegateCommand GetSafetyHeightCommand
        => _getSafetyHeightCommand ??= new DelegateCommand(ExecuteGetSafetyHeightCommand);
    private void ExecuteGetSafetyHeightCommand()
    {
        MachineDatas.SafetyHeight = (_plc.ZAxisPosition).WfsFormat();
    }
    private DelegateCommand _getSafetyHeightCommand;

    /********************
     * 黏土座
     ********************/
    /// <summary>
    /// 相機移動至黏土座命令。
    /// </summary>
    public DelegateCommand MoveCameraToClayTableCommand
        => _moveCameraToClayTableCommand ??= new DelegateCommand(ExecuteMoveCameraToClayTableCommand);
    private async void ExecuteMoveCameraToClayTableCommand()
    {
        double nowX = (MachineDatas.ClayTableX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (MachineDatas.ClayTableY + MachineDatas.DatumPointY).WfsFormat();

        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
    }
    private DelegateCommand _moveCameraToClayTableCommand;

    /// <summary>
    /// 相機移動至黏土座拍照高度命令。
    /// </summary>
    public DelegateCommand MoveCameraToClayTableHeightCommand
        => _moveCameraToClayTableHeightCommand ??= new DelegateCommand(ExecuteMoveCameraToClayTableHeightCommand);
    private void ExecuteMoveCameraToClayTableHeightCommand()
    {
        double nowX = (MachineDatas.ClayTableX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (MachineDatas.ClayTableY + MachineDatas.DatumPointY).WfsFormat();
        double nowZ = (MachineDatas.ClayTableZ + MachineDatas.DatumPointZ + MachineDatas.HeightCorrection).WfsFormat();

        if (nowX == _plc.XAxisPosition.WfsFormat() && (nowY == _plc.YAxisPosition.WfsFormat()))
            _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, nowZ);
    }
    private DelegateCommand _moveCameraToClayTableHeightCommand;

    /// <summary>
    /// 取得黏土座座標命令。
    /// </summary>
    public DelegateCommand GetClayTableCoordinateCommand
        => _getClayTableCoordinateCommand ??= new DelegateCommand(ExecuteGetClayTableCoordinateCommand);
    private void ExecuteGetClayTableCoordinateCommand()
    {
        MachineDatas.ClayTableX = (_plc.XAxisPosition - MachineDatas.DatumPointX).WfsFormat();
        MachineDatas.ClayTableY = (_plc.YAxisPosition - MachineDatas.DatumPointY).WfsFormat();
        UpdateDistanceFromNozzleToCamera();
    }
    private DelegateCommand _getClayTableCoordinateCommand;

    /// <summary>
    /// 取得黏土座高度命令。
    /// </summary>
    public DelegateCommand GetClayTableZCommand
        => _getClayTableZCommand ??= new DelegateCommand(ExecuteGetClayTableZCommand);
    private void ExecuteGetClayTableZCommand()
    {
        MachineDatas.ClayTableZ = (_plc.ZAxisPosition - MachineDatas.DatumPointZ - MachineDatas.HeightCorrection).WfsFormat();
    }
    private DelegateCommand _getClayTableZCommand;

    /// <summary>
    /// 吸嘴移動至黏土座命令。
    /// </summary>
    public DelegateCommand MoveToNozzleStampCommand
        => _moveToNozzleStampCommand ??= new DelegateCommand(ExecuteMoveToNozzleStampCommand);
    private async void ExecuteMoveToNozzleStampCommand()
    {
        double nowX = (MachineDatas.NozzleStampX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (MachineDatas.NozzleStampY + MachineDatas.DatumPointY).WfsFormat();

        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
    }
    private DelegateCommand _moveToNozzleStampCommand;

    /// <summary>
    /// 吸嘴移動至黏土座壓印高度命令。
    /// </summary>
    public DelegateCommand MoveToNozzleStampHeightCommand
        => _moveToNozzleStampHeightCommand ??= new DelegateCommand(ExecuteMoveToNozzleStampHeightCommand);
    private async void ExecuteMoveToNozzleStampHeightCommand()
    {
        double nowX = (MachineDatas.NozzleStampX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (MachineDatas.NozzleStampY + MachineDatas.DatumPointY).WfsFormat();
        double nowZ = (MachineDatas.NozzleStampZ + MachineDatas.DatumPointZ + MachineDatas.HeightCorrection).WfsFormat();

        if (nowX == _plc.XAxisPosition.WfsFormat() && nowY == _plc.YAxisPosition.WfsFormat())
            await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, nowZ);
    }
    private DelegateCommand _moveToNozzleStampHeightCommand;

    /// <summary>
    /// 取得黏土座吸嘴壓印座標命令。
    /// </summary>
    public DelegateCommand GetNozzleStampCoordinateCommand
        => _getNozzleStampCoordinateCommand ??= new DelegateCommand(ExecuteGetNozzleStampCoordinateCommand);
    private void ExecuteGetNozzleStampCoordinateCommand()
    {
        MachineDatas.NozzleStampX = (_plc.XAxisPosition - MachineDatas.DatumPointX).WfsFormat();
        MachineDatas.NozzleStampY = (_plc.YAxisPosition - MachineDatas.DatumPointY).WfsFormat();
        UpdateDistanceFromNozzleToCamera();
    }
    private DelegateCommand _getNozzleStampCoordinateCommand;

    /// <summary>
    /// 取得黏土座吸嘴壓印命令。
    /// </summary>
    public DelegateCommand GetNozzleStampHeightCommand
        => _getNozzleStampHeightCommand ??= new DelegateCommand(ExecuteGetNozzleStampHeightCommand);
    private void ExecuteGetNozzleStampHeightCommand()
    {
        MachineDatas.NozzleStampZ = (_plc.ZAxisPosition - MachineDatas.DatumPointZ - MachineDatas.HeightCorrection).WfsFormat();
    }
    private DelegateCommand _getNozzleStampHeightCommand;

    /// <summary>
    /// 移至黏土壓印畫像中心命令。
    /// </summary>
    public DelegateCommand MoveToClayTableVisionCenterCommand
        => _moveToClayTableVisionCenterCommand ??= new DelegateCommand(ExecuteMoveToClayTableVisionCenterCommand);
    private async void ExecuteMoveToClayTableVisionCenterCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (_plc.XAxisPosition - ClayTableVisionX).WfsFormat(),
                                (_plc.YAxisPosition - ClayTableVisionY).WfsFormat(),
                                0.0);
        MoveToClayCounter++;
    }
    private DelegateCommand _moveToClayTableVisionCenterCommand;

    /// <summary>
    /// 計算黏土壓印畫像中心命令。
    /// </summary>
    public DelegateCommand CalcClayTableVisionCenterCommand
        => _calcClayTableVisionCenterCommand ??= new DelegateCommand(ExecuteCalcClayTableVisionCenterCommand);
    private void ExecuteCalcClayTableVisionCenterCommand()
    {
        VisionData vdi = new VisionData()
        {
            ProductType = MachineDatas.ClayTableVisionId,
        };

        if (_vision.TakePicture(ref vdi))
        {
            if (vdi.OK)
            {
                ClayTableVisionX = vdi.X;
                ClayTableVisionY = vdi.Y;
                MoveToClayCounter = 0;
            }
            else if (vdi.NG)
            {
                //_sysMessenger.StatusBarMessage("拍照結果為NG！");
            }
        }
        else
        {
            string errMsg = "拍照失敗或未接收到視覺系統回傳資料！";
            Log.Error($"TeachingViewModel  ->  CalcClayTableVisionCenterCommand(): {errMsg}");
            _ = _prismMessageBox.Show(errMsg, "視覺系統錯誤", MessageBoxImage.Error);
        }
    }
    private DelegateCommand _calcClayTableVisionCenterCommand;

    /********************
     * 測高用位移計
     ********************/
    /// <summary>
    /// 移動至測高用位移計命令。
    /// </summary>
    public DelegateCommand MoveToDisplacementCommand
        => _moveToDisplacementCommand ??= new DelegateCommand(ExecuteMoveToDisplacementCommand);
    private async void ExecuteMoveToDisplacementCommand()
    {
        double nowX = (MachineDatas.DisplacementX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (MachineDatas.DisplacementY + MachineDatas.DatumPointY).WfsFormat();

        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
    }
    private DelegateCommand _moveToDisplacementCommand;

    /// <summary>
    /// 取得相機座標命令。
    /// </summary>
    public DelegateCommand GetDisplacementCoordinateCommand
        => _getDisplacementCoordinateCommand ??= new DelegateCommand(ExecuteGetDisplacementCoordinateCommand);
    private void ExecuteGetDisplacementCoordinateCommand()
    {
        MachineDatas.DisplacementX = (_plc.XAxisPosition - MachineDatas.DatumPointX).WfsFormat();
        MachineDatas.DisplacementY = (_plc.YAxisPosition - MachineDatas.DatumPointY).WfsFormat();
        UpdateDistanceFromNozzleToCamera();
    }
    private DelegateCommand _getDisplacementCoordinateCommand;

    /// <summary>
    /// 同步
    /// </summary>
    public DelegateCommand SynchronizeHeightCommand
        => _synchronizeHeightCommand ??= new DelegateCommand(ExecuteSynchronizeDataWithSensorCommand);
    private void ExecuteSynchronizeDataWithSensorCommand()
    {
        MachineDatas.LastMeasureHeight = _plc.ZAxisPosition;
    }
    private DelegateCommand _synchronizeHeightCommand;

    /// <summary>
    /// 將吸嘴移至位移計命令。
    /// </summary>
    public DelegateCommand MoveNozzleToDisplacementCommand
        => _moveNozzleToDisplacementCommand ??= new DelegateCommand(ExecuteMoveNozzleToDisplacementCommand);
    private async void ExecuteMoveNozzleToDisplacementCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (NozzlePostionInDisplacementX + MachineDatas.DatumPointX).WfsFormat(),
                                (NozzlePostionInDisplacementY + MachineDatas.DatumPointY).WfsFormat(),
                                0.0);
    }
    private DelegateCommand _moveNozzleToDisplacementCommand;

    /// <summary>
    /// 移動吸嘴至測高用位移計高度命令。
    /// </summary>
    public DelegateCommand MoveNozzleToDisplacementZCommand
        => _moveNozzleToDisplacementZCommand ??= new DelegateCommand(ExecuteMoveNozzleToDisplacementZCommand);
    private async void ExecuteMoveNozzleToDisplacementZCommand()
    {
        double nowX = (NozzlePostionInDisplacementX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (NozzlePostionInDisplacementY + MachineDatas.DatumPointY).WfsFormat();
        double nowZ = MachineDatas.DisplacementZ.WfsFormat();  // 絕對座標、人工輸入

        if (nowX == _plc.XAxisPosition.WfsFormat() && nowY == _plc.YAxisPosition.WfsFormat())
            await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, nowZ);
    }
    private DelegateCommand _moveNozzleToDisplacementZCommand;

    /// <summary>
    /// 移動吸嘴至基準高度命令。
    /// </summary>
    public DelegateCommand MoveNozzleToDatumZCommand
        => _moveNozzleToDatumZCommand ??= new DelegateCommand(ExecuteMoveNozzleToDatumZCommand);
    private async void ExecuteMoveNozzleToDatumZCommand()
    {
        double nowX = (NozzlePostionInDisplacementX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (NozzlePostionInDisplacementY + MachineDatas.DatumPointY).WfsFormat();

        if (nowX == _plc.XAxisPosition.WfsFormat() && nowY == _plc.YAxisPosition.WfsFormat())
            await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, MachineDatas.DatumPointZ + MachineDatas.HeightCorrection);
    }
    private DelegateCommand _moveNozzleToDatumZCommand;

    /// <summary>
    /// 計算高度補正，將上次量測值更新為目前量測值命令。
    /// </summary>
    public DelegateCommand CalcHeightCorrectionCommand
        => _calcHeightCorrectionCommand ??= new DelegateCommand(ExecuteCalcHeightCorrectionCommand);
    private void ExecuteCalcHeightCorrectionCommand()
    {
        MachineDatas.HeightCorrection += MachineDatas.LastMeasureHeight - DisplacementDatas.Instance.ReadValue;
        MachineDatas.LastMeasureHeight = DisplacementDatas.Instance.ReadValue;
    }
    private DelegateCommand _calcHeightCorrectionCommand;

    /********************
     * Stage
     ********************/
    /// <summary>
    /// 移動至A1命令。
    /// </summary>
    public DelegateCommand MoveToStage1Command
        => _moveToStage1Command ??= new DelegateCommand(ExecuteMoveToStage1Command);
    private async void ExecuteMoveToStage1Command()
    {
        double nowX = (StageA1.CoorX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (StageA1.CoorY + MachineDatas.DatumPointY).WfsFormat();

        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
    }
    private DelegateCommand _moveToStage1Command;

    /// <summary>
    /// 將吸嘴移至A1命令。
    /// </summary>
    public DelegateCommand MoveNozzleToA1Command
        => _moveNozzleToA1Command ??= new DelegateCommand(ExecuteMoveNozzleToA1Command);
    private async void ExecuteMoveNozzleToA1Command()
    {
        double nowX = (NozzlePostionInA1X + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (NozzlePostionInA1Y + MachineDatas.DatumPointY).WfsFormat();

        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
    }
    private DelegateCommand _moveNozzleToA1Command;

    /// <summary>
    /// 將吸嘴移至A1高度命令。
    /// </summary>
    public DelegateCommand MoveToStage1HeightCommand
        => _moveToStage1HeightCommand ??= new DelegateCommand(ExecuteMoveToStage1HeightCommand);
    private async void ExecuteMoveToStage1HeightCommand()
    {
        double nowX = (NozzlePostionInA1X + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (NozzlePostionInA1Y + MachineDatas.DatumPointY).WfsFormat();
        double nowZ = (StageA1.CoorZ + MachineDatas.DatumPointZ + MachineDatas.HeightCorrection).WfsFormat();

        if (nowX == _plc.XAxisPosition.WfsFormat() && nowY == _plc.YAxisPosition.WfsFormat())
            await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, nowZ);
    }
    private DelegateCommand _moveToStage1HeightCommand;

    /// <summary>
    /// 取得A1座標命令。
    /// </summary>
    public DelegateCommand GetStage1CoordinateCommand
        => _getStage1CoordinateCommand ??= new DelegateCommand(ExecuteGetStage1CoordinateCommand);
    private void ExecuteGetStage1CoordinateCommand()
    {
        StageA1.CoorX = (_plc.XAxisPosition - MachineDatas.DatumPointX).WfsFormat();
        StageA1.CoorY = (_plc.YAxisPosition - MachineDatas.DatumPointY).WfsFormat();
        UpdateDistanceFromNozzleToCamera();
    }
    private DelegateCommand _getStage1CoordinateCommand;

    /// <summary>
    /// 移至A1畫像中心命令。
    /// </summary>
    public DelegateCommand MoveToStage1VisionCenterCommand
        => _moveToStage1VisionCenterCommand ??= new DelegateCommand(ExecuteMoveToStage1VisionCenterCommand);
    private async void ExecuteMoveToStage1VisionCenterCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (_plc.XAxisPosition - Stage1VisionX).WfsFormat(),
                                (_plc.YAxisPosition - Stage1VisionY).WfsFormat(),
                                0.0);
        MoveToStage1Counter++;
    }
    private DelegateCommand _moveToStage1VisionCenterCommand;

    /// <summary>
    /// 計算A1畫像中心命令。
    /// </summary>
    public DelegateCommand CalcStage1VisionCenterCommand
        => _calcStage1VisionCenterCommand ??= new DelegateCommand(ExecuteCalcStage1VisionCenterCommand);
    private void ExecuteCalcStage1VisionCenterCommand()
    {
        VisionData vdi = new VisionData()
        {
            ProductType = StageA1.VisionId,
        };

        if (_vision.TakePicture(ref vdi))
        {
            if (vdi.OK)
            {
                Stage1VisionX = vdi.X;
                Stage1VisionY = vdi.Y;
                MoveToStage1Counter = 0;
            }
            else if (vdi.NG)
            {
                //_sysMessenger.StatusBarMessage("拍照結果為NG！");
            }
        }
        else
        {
            string errMsg = "拍照失敗或未接收到視覺系統回傳資料！";
            Log.Error($"TeachingViewModel  ->  CalcStage1VisionCenterCommand(): {errMsg}");
            _ = _prismMessageBox.Show(errMsg, "視覺系統錯誤", MessageBoxImage.Error);
        }
    }
    private DelegateCommand _calcStage1VisionCenterCommand;

    /// <summary>
    /// 
    /// </summary>
    public DelegateCommand GetStage1HeightCommand
        => _getStage1HeightCommand ??= new DelegateCommand(ExecuteGetStage1HeightCommand);
    private void ExecuteGetStage1HeightCommand()
    {
        StageA1.CoorZ = (_plc.ZAxisPosition - MachineDatas.DatumPointZ - MachineDatas.HeightCorrection).WfsFormat();
    }
    private DelegateCommand _getStage1HeightCommand;

    /// <summary>
    /// 移動至A2命令。
    /// </summary>
    public DelegateCommand MoveToStage2Command
        => _moveToStage2Command ??= new DelegateCommand(ExecuteMoveToStage2Command);
    private async void ExecuteMoveToStage2Command()
    {
        double nowX = (StageA2.CoorX + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (StageA2.CoorY + MachineDatas.DatumPointY).WfsFormat();
        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
    }
    private DelegateCommand _moveToStage2Command;

    /// <summary>
    /// 將吸嘴移至A2命令。
    /// </summary>
    public DelegateCommand MoveNozzleToA2Command
        => _moveNozzleToA2Command ??= new DelegateCommand(ExecuteMoveNozzleToA2Command);
    private async void ExecuteMoveNozzleToA2Command()
    {
        double nowX = (NozzlePostionInA2X + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (NozzlePostionInA2Y + MachineDatas.DatumPointY).WfsFormat();
        await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, 0.0);
    }
    private DelegateCommand _moveNozzleToA2Command;

    /// <summary>
    /// 移動至A2高度命令。
    /// </summary>
    public DelegateCommand MoveToStage2HeightCommand
        => _moveToStage2HeightCommand ??= new DelegateCommand(ExecuteMoveToStage2HeightCommand);
    private async void ExecuteMoveToStage2HeightCommand()
    {
        double nowX = (NozzlePostionInA2X + MachineDatas.DatumPointX).WfsFormat();
        double nowY = (NozzlePostionInA2Y + MachineDatas.DatumPointY).WfsFormat();
        double nowZ = (StageA2.CoorZ + MachineDatas.DatumPointZ + MachineDatas.HeightCorrection).WfsFormat();

        if (nowX == _plc.XAxisPosition.WfsFormat() && nowY == _plc.YAxisPosition.WfsFormat())
            await _plc.MoveToTarget(MotionTarget.VisualPoint, nowX, nowY, nowZ);
    }
    private DelegateCommand _moveToStage2HeightCommand;

    /// <summary>
    /// 取得A2座標命令。
    /// </summary>
    public DelegateCommand GetStage2CoordinateCommand
        => _getStage2CoordinateCommand ??= new DelegateCommand(ExecuteGetStage2CoordinateCommand);
    private void ExecuteGetStage2CoordinateCommand()
    {
        StageA2.CoorX = (_plc.XAxisPosition - MachineDatas.DatumPointX).WfsFormat();
        StageA2.CoorY = (_plc.YAxisPosition - MachineDatas.DatumPointY).WfsFormat();
        UpdateDistanceFromNozzleToCamera();
    }
    private DelegateCommand _getStage2CoordinateCommand;

    /// <summary>
    /// 取得A2高度命令。
    /// </summary>
    public DelegateCommand GetStage2HeightCommand
        => _getStage2HeightCommand ??= new DelegateCommand(ExecuteGetStage2HeightCommand);
    private void ExecuteGetStage2HeightCommand()
    {
        StageA2.CoorZ = (_plc.ZAxisPosition - MachineDatas.DatumPointZ - MachineDatas.HeightCorrection).WfsFormat();
    }
    private DelegateCommand _getStage2HeightCommand;

    /// <summary>
    /// 移至A2畫像中心命令。
    /// </summary>
    public DelegateCommand MoveToStage2VisionCenterCommand
        => _moveToStage2VisionCenterCommand ??= new DelegateCommand(ExecuteMoveToStage2VisionCenterCommand);
    private async void ExecuteMoveToStage2VisionCenterCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (_plc.XAxisPosition - Stage2VisionX).WfsFormat(),
                                (_plc.YAxisPosition - Stage2VisionY).WfsFormat(),
                                0.0);
        MoveToStage2Counter++;
    }
    private DelegateCommand _moveToStage2VisionCenterCommand;

    /// <summary>
    /// 計算A2畫像中心命令。
    /// </summary>
    public DelegateCommand CalcStage2VisionCenterCommand
        => _calcStage2VisionCenterCommand ??= new DelegateCommand(ExecuteCalcStage2VisionCenterCommand);
    private void ExecuteCalcStage2VisionCenterCommand()
    {
        VisionData vdi = new()
        {
            ProductType = StageA2.VisionId,
        };

        if (_vision.TakePicture(ref vdi))
        {
            if (vdi.OK)
            {
                Stage2VisionX = vdi.X;
                Stage2VisionY = vdi.Y;
                MoveToStage2Counter = 0;
            }
            else if (vdi.NG)
            {
                //_sysMessenger.StatusBarMessage("拍照結果為NG！");
            }
        }
        else
        {
            string errMsg = "拍照失敗或未接收到視覺系統回傳資料！";
            Log.Error($"TeachingViewModel  ->  CalcStage2VisionCenterCommand(): {errMsg}");
            _ = _prismMessageBox.Show(errMsg, "視覺系統錯誤", MessageBoxImage.Error);
        }
    }
    private DelegateCommand _calcStage2VisionCenterCommand;

    /********************
     * Pallet
     ********************/
    /// <summary>
    /// 移動到Pallet指定基準點命令。
    /// </summary>
    public DelegateCommand<int?> MoveToTrayDatumPositionCommand
        => _moveToTrayDatumPositionCommand ??= new DelegateCommand<int?>(ExecuteMoveToTrayDatumPositionCommand);
    private async void ExecuteMoveToTrayDatumPositionCommand(int? positionId)
    {
        int posId = positionId != null ? positionId.Value : 0;
        if (posId >= 1 && posId <= ITray.MaxPalletId)
        {
            var th = Pallet.First(x => x.Id == posId);
            await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                    th.DatumX + MachineDatas.DatumPointX,
                                    th.DatumY + MachineDatas.DatumPointY,
                                    0.0);
        }
    }
    private DelegateCommand<int?> _moveToTrayDatumPositionCommand;

    /// <summary>
    /// 取得Pallet指定基準點的座標命令。
    /// </summary>
    public DelegateCommand<int?> GetTrayDatumPositionCommand
        => _getTrayDatumPositionCommand ??= new DelegateCommand<int?>(ExecuteGetTrayDatumPositionCommand);
    private void ExecuteGetTrayDatumPositionCommand(int? positionId)
    {
        int posId = positionId != null ? positionId.Value : 0;
        if (posId >= 1 && posId <= ITray.MaxPalletId)
        {
            for (int idx = 0; idx < ITray.MaxPalletId; idx++)
            {
                if (Pallet[idx].Id == posId)
                {
                    Pallet[idx].DatumX = (_plc.XAxisPosition - MachineDatas.DatumPointX).WfsFormat();
                    Pallet[idx].DatumY = (_plc.YAxisPosition - MachineDatas.DatumPointY).WfsFormat();
                    break;
                }
            }
        }
    }
    private DelegateCommand<int?> _getTrayDatumPositionCommand;

    /// <summary>
    /// 移至A2畫像中心命令。
    /// </summary>
    public DelegateCommand MoveToPalletDpVisionCenterCommand
        => _moveToPalletDpVisionCenterCommand ??= new DelegateCommand(ExecuteMoveToPalletDpVisionCenterCommand);
    private async void ExecuteMoveToPalletDpVisionCenterCommand()
    {
        await _plc.MoveToTarget(MotionTarget.VisualPoint,
                                (_plc.XAxisPosition - PalletDpVisionX).WfsFormat(),
                                (_plc.YAxisPosition - PalletDpVisionY).WfsFormat(),
                                0.0);
        MoveToPalletDpCounter++;
    }
    private DelegateCommand _moveToPalletDpVisionCenterCommand;

    /// <summary>
    /// 計算A2畫像中心命令。
    /// </summary>
    public DelegateCommand CalcPalletDpVisionCenterCommand
        => _calcPalletDpVisionCenterCommand ??= new DelegateCommand(ExecuteCalcPalletDpVisionCenterCommand);
    private void ExecuteCalcPalletDpVisionCenterCommand()
    {
        VisionData vdi = new()
        {
            ProductType = MachineDatas.PalletDpVisionId,
        };

        if (_vision.TakePicture(ref vdi))
        {
            PalletDpVisionX = vdi.X;
            PalletDpVisionY = vdi.Y;

            if (vdi.OK)
            {
                MoveToPalletDpCounter = 0;
            }
            else if (vdi.NG)
            {
                //_sysMessenger.StatusBarMessage("拍照結果為NG！");
            }
        }
        else
        {
            string errMsg = "拍照失敗或未接收到視覺系統回傳資料！";
            Log.Error($"TeachingViewModel  ->  CalcPalletDpVisionCenterCommand(): {errMsg}");
            _ = _prismMessageBox.Show(errMsg, "視覺系統錯誤", MessageBoxImage.Error);
        }
    }
    private DelegateCommand _calcPalletDpVisionCenterCommand;

    /********************
     * Data Binding
     ********************/
    /// <summary>
    /// 機台資料。
    /// </summary>
    public MachineDefine MachineDatas
    {
        get { return _machineDatas; }
        set { SetProperty(ref _machineDatas, value); }
    }
    private MachineDefine _machineDatas;

    /// <summary>
    /// Stage A1資料。
    /// </summary>
    public StageDefine StageA1
    {
        get { return _stageA1; }
        set { SetProperty(ref _stageA1, value); }
    }
    private StageDefine _stageA1;

    /// <summary>
    /// Stage A2資料。
    /// </summary>
    public StageDefine StageA2
    {
        get { return _stageA2; }
        set { SetProperty(ref _stageA2, value); }
    }
    private StageDefine _stageA2;

    /// <summary>
    /// Pallet資料。
    /// </summary>
    public ObservableCollection<PalletDefine> Pallet
    {
        get { return _pallet; }
        set { SetProperty(ref _pallet, value); }
    }
    private ObservableCollection<PalletDefine> _pallet;

    /// <summary>
    /// Pallet選擇。
    /// </summary>
    public PalletDefine PalletSelection
    {
        get { return _palletSelection; }
        set
        {
            SetProperty(ref _palletSelection, value);

            if (Pallet == null || value == null)
            {
                foreach (var item in _tray.PalletList)
                    item.Tag = false;
            }
            else
            {
                foreach (var item in Pallet)
                    item.Tag = item.Id == value.Id;
            }
        }
    }
    private PalletDefine _palletSelection;

    /// <summary>
    /// Pallet安裝點編修鎖。
    /// </summary>
    public bool PalletListLock
    {
        get { return _palletListLock; }
        set { SetProperty(ref _palletListLock, value); }
    }
    private bool _palletListLock = true;

    /// <summary>
    /// 基準點 畫像中心 X。
    /// </summary>
    public double DatumPointVisionX
    {
        get { return _datumPointVisionX; }
        set { SetProperty(ref _datumPointVisionX, value); }
    }
    private double _datumPointVisionX;

    /// <summary>
    /// 基準點 畫像中心 Y。
    /// </summary>
    public double DatumPointVisionY
    {
        get { return _datumPointVisionY; }
        set { SetProperty(ref _datumPointVisionY, value); }
    }
    private double _datumPointVisionY;

    /// <summary>
    /// 黏土座 畫像中心 X。
    /// </summary>
    public double ClayTableVisionX
    {
        get { return _clayTableVisionX; }
        set { SetProperty(ref _clayTableVisionX, value); }
    }
    private double _clayTableVisionX;

    /// <summary>
    /// 黏土座 畫像中心 Y。
    /// </summary>
    public double ClayTableVisionY
    {
        get { return _clayTableVisionY; }
        set { SetProperty(ref _clayTableVisionY, value); }
    }
    private double _clayTableVisionY;

    // Stage1 畫像中心
    public double Stage1VisionX
    {
        get { return _stage1VisionX; }
        set { SetProperty(ref _stage1VisionX, value); }
    }
    private double _stage1VisionX;

    public double Stage1VisionY
    {
        get { return _stage1VisionY; }
        set { SetProperty(ref _stage1VisionY, value); }
    }
    private double _stage1VisionY;

    // Stage2 畫像中心
    public double Stage2VisionX
    {
        get { return _stage2VisionX; }
        set { SetProperty(ref _stage2VisionX, value); }
    }
    private double _stage2VisionX;

    public double Stage2VisionY
    {
        get { return _stage2VisionY; }
        set { SetProperty(ref _stage2VisionY, value); }
    }
    private double _stage2VisionY;

    // Pallet基準點畫像中心
    public double PalletDpVisionX
    {
        get { return _palletDpVisionX; }
        set { SetProperty(ref _palletDpVisionX, value); }
    }
    private double _palletDpVisionX;

    public double PalletDpVisionY
    {
        get { return _palletDpVisionY; }
        set { SetProperty(ref _palletDpVisionY, value); }
    }
    private double _palletDpVisionY;

    /********************
     * 吸嘴推算
     ********************/
    public double NozzlePostionInDatumX
    {
        get { return _nozzlePostionInDatumX; }
        set { SetProperty(ref _nozzlePostionInDatumX, value); }
    }
    private double _nozzlePostionInDatumX;

    public double NozzlePostionInDatumY
    {
        get { return _nozzlePostionInDatumY; }
        set { SetProperty(ref _nozzlePostionInDatumY, value); }
    }
    private double _nozzlePostionInDatumY;

    public double NozzlePostionInDisplacementX
    {
        get { return _nozzlePostionInDisplacementX; }
        set { SetProperty(ref _nozzlePostionInDisplacementX, value); }
    }
    private double _nozzlePostionInDisplacementX;

    public double NozzlePostionInDisplacementY
    {
        get { return _nozzlePostionInDisplacementY; }
        set { SetProperty(ref _nozzlePostionInDisplacementY, value); }
    }
    private double _nozzlePostionInDisplacementY;

    public double NozzlePostionInA1X
    {
        get { return _nozzlePostionInA1X; }
        set { SetProperty(ref _nozzlePostionInA1X, value); }
    }
    private double _nozzlePostionInA1X;

    public double NozzlePostionInA1Y
    {
        get { return _nozzlePostionInA1Y; }
        set { SetProperty(ref _nozzlePostionInA1Y, value); }
    }
    private double _nozzlePostionInA1Y;

    public double NozzlePostionInA2X
    {
        get { return _nozzlePostionInA2X; }
        set { SetProperty(ref _nozzlePostionInA2X, value); }
    }
    private double _nozzlePostionInA2X;

    public double NozzlePostionInA2Y
    {
        get { return _nozzlePostionInA2Y; }
        set { SetProperty(ref _nozzlePostionInA2Y, value); }
    }
    private double _nozzlePostionInA2Y;

    /********************
     * 計數器
     ********************/
    public int MoveToDpCounter
    {
        get { return _moveToDpCounter; }
        set { SetProperty(ref _moveToDpCounter, value); }
    }
    private int _moveToDpCounter = 0;

    public int MoveToClayCounter
    {
        get { return _moveToClayCounter; }
        set { SetProperty(ref _moveToClayCounter, value); }
    }
    private int _moveToClayCounter = 0;

    public int MoveToStage1Counter
    {
        get { return _moveToStage1Counter; }
        set { SetProperty(ref _moveToStage1Counter, value); }
    }
    private int _moveToStage1Counter = 0;

    public int MoveToStage2Counter
    {
        get { return _moveToStage2Counter; }
        set { SetProperty(ref _moveToStage2Counter, value); }
    }
    private int _moveToStage2Counter = 0;

    public int MoveToPalletDpCounter
    {
        get { return _moveToPalletDpCounter; }
        set { SetProperty(ref _moveToPalletDpCounter, value); }
    }
    private int _moveToPalletDpCounter;
}
