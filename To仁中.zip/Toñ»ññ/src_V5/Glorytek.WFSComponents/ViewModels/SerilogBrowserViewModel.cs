﻿using Prism.Mvvm;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// Serilog瀏覽器頁面的ViewModel。
/// </summary>
public class SerilogBrowserViewModel : BindableBase
{
    public SerilogBrowserViewModel()
    {
    }
}
