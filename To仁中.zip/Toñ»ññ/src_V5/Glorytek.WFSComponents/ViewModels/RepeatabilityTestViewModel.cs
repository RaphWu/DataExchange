﻿using Glorytek.CSharp.Data;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Contracts;
using Prism;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.ObjectModel;
using System.Windows.Threading;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 重覆精度測試頁面的ViewModel。
/// </summary>
public class RepeatabilityTestViewModel : BindableBase, IActiveAware
{
    private readonly DispatcherTimer _timer = new();

    /********************
     * IActiveAware
     ********************/
    private bool _isActive = false;
    public bool IsActive
    {
        get { return _isActive; }
        set
        {
            _isActive = value;
            OnIsActiveChanged();

            if (value)
            {
                ReadDataFromPlc();
            }
            else
            {
                _timer.Stop();
            }
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IPlc _plc;

    public RepeatabilityTestViewModel(IApplicationCommands applicationCommands, ISystemMessenger sysMessenger, IPlc plc)
    {
        _sysMessenger = sysMessenger;
        _plc = plc;

        if (_plc.Online)
        {
            var (_, visionOnOff) = _plc.ReadBool(DeviceLists.REPEATABILITY_TEST_VISION_SW);
            _visionInRepeatabilityTest = (bool)visionOnOff;
        }

        TestInRunning = false;

        _timer.Tick += new EventHandler(OnTimedEvent);
        _timer.Interval = new TimeSpan(0, 0, 0, 0, 20);
        _timer.Start();

        // TODO: UnregisterCommand
        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /********************
     * System
     ********************/
    /// <summary>
    /// 儲存參數至PLC。
    /// </summary>
    public void ExecuteSaveDataCommand() => SaveDataToPlc();

    /// <summary>
    /// 儲存參數至PLC。
    /// </summary>
    private void SaveDataToPlc()
    {
        if (_plc.Online)
        {
            _ = _plc.WriteInt16(DeviceLists.REPEATABILITY_TEST_SPEED, RepeatabilityTest_Speed);
            _ = _plc.WriteInt16(DeviceLists.REPEATABILITY_TEST_X_TEST_TIMES_SETTING, RepeatabilityTest_X_TestTimesSetting);
            _ = _plc.WriteDoubleByInt32(DeviceLists.REPEATABILITY_TEST_X_COORDINATE1, new double[]
            {
                    RepeatabilityTest_X_Coordinate1,
                    RepeatabilityTest_X_Coordinate2
            });
            _ = _plc.WriteInt16(DeviceLists.REPEATABILITY_TEST_Y_TEST_TIMES_SETTING, RepeatabilityTest_Y_TestTimesSetting);
            _ = _plc.WriteDoubleByInt32(DeviceLists.REPEATABILITY_TEST_Y_COORDINATE1, new double[]
            {
                  RepeatabilityTest_Y_Coordinate1,
                  RepeatabilityTest_Y_Coordinate2
            });
        }
    }

    /// <summary>
    /// 從PLC讀取參數。
    /// </summary>
    private void ReadDataFromPlc()
    {
        if (_plc.Online)
        {
            var (_, counter1) = _plc.ReadInt16(DeviceLists.REPEATABILITY_TEST_X_TESTED_COUNTER, 2);
            RepeatabilityTest_X_TestedCounter = counter1[0];
            RepeatabilityTest_X_TestTimesSetting = counter1[1];

            var (_, coor1) = _plc.ReadDoubleByInt32(DeviceLists.REPEATABILITY_TEST_X_COORDINATE1, 2);
            RepeatabilityTest_X_Coordinate1 = coor1[0];
            RepeatabilityTest_X_Coordinate2 = coor1[1];

            var (_, counter2) = _plc.ReadInt16(DeviceLists.REPEATABILITY_TEST_Y_TESTED_COUNTER, 2);
            RepeatabilityTest_Y_TestedCounter = counter2[0];
            RepeatabilityTest_Y_TestTimesSetting = counter2[1];

            var (_, coor2) = _plc.ReadDoubleByInt32(DeviceLists.REPEATABILITY_TEST_Y_COORDINATE1, 2);
            RepeatabilityTest_Y_Coordinate1 = coor2[0];
            RepeatabilityTest_Y_Coordinate2 = coor2[1];

            var (_, speed) = _plc.ReadInt16(DeviceLists.REPEATABILITY_TEST_SPEED);
            RepeatabilityTest_Speed = speed;
        }
    }

    /********************
     * Status
     ********************/
    //private AxisId _testAxis;       // 測試軸
    private string _strComplete;    // 拍照完成
    private string _strHandshake;   // 交握回傳
    private int _pictureTimes;

    public bool TestInRunning
    {
        get { return _testInRunning; }
        set { SetProperty(ref _testInRunning, value); }
    }
    private bool _testInRunning;

    /********************
     * Commands
     ********************/
    /// <summary>
    /// X軸開始測試。
    /// </summary>
    public DelegateCommand StartXCommand
        => _startXCommand ??= new DelegateCommand(ExecuteStartXCommand);
    private void ExecuteStartXCommand()
    {
        SaveDataToPlc();

        VisionResult = new ObservableCollection<VisionResultDefine>();
        XMaxVisionResult = double.MinValue;
        XMinVisionResult = double.MaxValue;
        XDiffVisionResult = 0.0;
        XSumVisionResult = 0.0;
        XAvgVisionResult = 0.0;
        YMaxVisionResult = double.MinValue;
        YMinVisionResult = double.MaxValue;
        YDiffVisionResult = 0.0;
        YSumVisionResult = 0.0;
        YAvgVisionResult = 0.0;
        RMaxVisionResult = double.MinValue;
        RMinVisionResult = double.MaxValue;
        RDiffVisionResult = 0.0;
        RSumVisionResult = 0.0;
        RAvgVisionResult = 0.0;
        _pictureTimes = 0;

        //ResultList = new PlotModel { Title = "Simple example", Subtitle = "using OxyPlot" };
        //series1 = new LineSeries();

        //_testAxis = AxisId.X;
        _strComplete = DeviceLists.REPEATABILITY_TEST_VISION_COMPLETE_X;
        _strHandshake = DeviceLists.REPEATABILITY_TEST_VISION_HANDSHAKE_X;

        _plc.SendCommandPulse(DeviceLists.REPEATABILITY_TEST_X_START_COMMAND);
    }
    private DelegateCommand _startXCommand;

    /// <summary>
    /// X軸停止測試。
    /// </summary>
    public DelegateCommand StopXCommand
        => _stopXCommand ??= new DelegateCommand(ExecuteStopXCommand);
    private void ExecuteStopXCommand()
    {
        _plc.SendCommandPulse(DeviceLists.REPEATABILITY_TEST_X_STOP_COMMAND);
    }
    private DelegateCommand _stopXCommand;

    /// <summary>
    /// Y軸開始測試。
    /// </summary>
    public DelegateCommand StartYCommand
        => _startYCommand ??= new DelegateCommand(ExecuteStartYCommand);
    private void ExecuteStartYCommand()
    {
        SaveDataToPlc();

        VisionResult = new ObservableCollection<VisionResultDefine>();
        XMaxVisionResult = double.MinValue;
        XMinVisionResult = double.MaxValue;
        XDiffVisionResult = 0.0;
        XSumVisionResult = 0.0;
        XAvgVisionResult = 0.0;
        YMaxVisionResult = double.MinValue;
        YMinVisionResult = double.MaxValue;
        YDiffVisionResult = 0.0;
        YSumVisionResult = 0.0;
        YAvgVisionResult = 0.0;
        RMaxVisionResult = double.MinValue;
        RMinVisionResult = double.MaxValue;
        RDiffVisionResult = 0.0;
        RSumVisionResult = 0.0;
        RAvgVisionResult = 0.0;
        _pictureTimes = 0;

        //ResultList = new PlotModel { Title = "Simple example", Subtitle = "using OxyPlot" };
        //series1 = new LineSeries();

        //_testAxis = AxisId.Y;
        _strComplete = DeviceLists.REPEATABILITY_TEST_VISION_COMPLETE_Y;
        _strHandshake = DeviceLists.REPEATABILITY_TEST_VISION_HANDSHAKE_Y;

        _plc.SendCommandPulse(DeviceLists.REPEATABILITY_TEST_Y_START_COMMAND);
    }
    private DelegateCommand _startYCommand;

    /// <summary>
    /// Y軸停止測試。
    /// </summary>
    public DelegateCommand StopYCommand
        => _stopYCommand ??= new DelegateCommand(ExecuteStopYCommand);
    private void ExecuteStopYCommand()
    {
        _plc.SendCommandPulse(DeviceLists.REPEATABILITY_TEST_Y_STOP_COMMAND);
    }
    private DelegateCommand _stopYCommand;

    /********************
     * 座標取得
     ********************/
    /// <summary>
    /// X軸1。
    /// </summary>
    public DelegateCommand GetCoorForX1
        => _getCoorForX1 ??= new DelegateCommand(ExecuteGetCoorForX1);
    private void ExecuteGetCoorForX1()
    {
        RepeatabilityTest_X_Coordinate1 = _plc.XAxisPosition;
    }
    private DelegateCommand _getCoorForX1;

    /// <summary>
    /// X軸2。
    /// </summary>
    public DelegateCommand GetCoorForX2
        => _getCoorForX2 ??= new DelegateCommand(ExecuteGetCoorForX2);
    private void ExecuteGetCoorForX2()
    {
        RepeatabilityTest_X_Coordinate2 = _plc.XAxisPosition;
    }
    private DelegateCommand _getCoorForX2;

    /// <summary>
    /// Y軸1。
    /// </summary>
    public DelegateCommand GetCoorForY1
        => _getCoorForY1 ??= new DelegateCommand(ExecuteGetCoorForY1);
    private void ExecuteGetCoorForY1()
    {
        RepeatabilityTest_Y_Coordinate1 = _plc.YAxisPosition;
    }
    private DelegateCommand _getCoorForY1;

    /// <summary>
    /// Y軸2。
    /// </summary>
    public DelegateCommand GetCoorForY2
        => _getCoorForY2 ??= new DelegateCommand(ExecuteGetCoorForY2);
    private void ExecuteGetCoorForY2()
    {
        RepeatabilityTest_Y_Coordinate2 = _plc.YAxisPosition;
    }
    private DelegateCommand _getCoorForY2;

    /********************
     * Data
     ********************/
    /// <summary>
    /// 拍照結果列表。
    /// </summary>
    public ObservableCollection<VisionResultDefine> VisionResult
    {
        get { return _visionResult; }
        set { SetProperty(ref _visionResult, value); }
    }
    private ObservableCollection<VisionResultDefine> _visionResult;

    /// <summary>
    /// 測試速度。
    /// </summary>
    public short RepeatabilityTest_Speed
    {
        get { return _repeatabilityTest_Speed; }
        set { SetProperty(ref _repeatabilityTest_Speed, value); }
    }
    private short _repeatabilityTest_Speed;

    /********************
     * X軸
     ********************/
    /// <summary>
    /// X軸重複精度測試執行中。
    /// </summary>
    private bool _repeatabilityTest_X_TestInRunning;
    public bool RepeatabilityTest_X_TestInRunning
    {
        get { return _repeatabilityTest_X_TestInRunning; }
        set { SetProperty(ref _repeatabilityTest_X_TestInRunning, value); }
    }

    /// <summary>
    /// X軸已測試次數。
    /// </summary>
    private short _repeatabilityTest_X_TestedCounter;
    public short RepeatabilityTest_X_TestedCounter
    {
        get { return _repeatabilityTest_X_TestedCounter; }
        set { SetProperty(ref _repeatabilityTest_X_TestedCounter, value); }
    }

    /// <summary>
    /// X軸測試次數設定。
    /// </summary>
    private short _repeatabilityTest_X_TestTimesSetting;
    public short RepeatabilityTest_X_TestTimesSetting
    {
        get { return _repeatabilityTest_X_TestTimesSetting; }
        set { SetProperty(ref _repeatabilityTest_X_TestTimesSetting, value); }
    }

    /// <summary>
    /// X軸座標1。
    /// </summary>
    private double _repeatabilityTest_X_Coordinate1;
    public double RepeatabilityTest_X_Coordinate1
    {
        get { return _repeatabilityTest_X_Coordinate1; }
        set { SetProperty(ref _repeatabilityTest_X_Coordinate1, value); }
    }

    /// <summary>
    /// X軸座標2。
    /// </summary>
    private double _repeatabilityTest_X_Coordinate2;
    public double RepeatabilityTest_X_Coordinate2
    {
        get { return _repeatabilityTest_X_Coordinate2; }
        set { SetProperty(ref _repeatabilityTest_X_Coordinate2, value); }
    }

    /********************
     * Y軸
     ********************/
    /// <summary>
    /// Y軸重複精度測試執行中。
    /// </summary>
    private bool _repeatabilityTest_Y_TestInRunning;
    public bool RepeatabilityTest_Y_TestInRunning
    {
        get { return _repeatabilityTest_Y_TestInRunning; }
        set { SetProperty(ref _repeatabilityTest_Y_TestInRunning, value); }
    }

    /// <summary>
    /// Y軸已測試次數。
    /// </summary>
    private short _repeatabilityTest_Y_TestedCounter;
    public short RepeatabilityTest_Y_TestedCounter
    {
        get { return _repeatabilityTest_Y_TestedCounter; }
        set { SetProperty(ref _repeatabilityTest_Y_TestedCounter, value); }
    }

    /// <summary>
    /// Y軸測試次數設定。
    /// </summary>
    private short _repeatabilityTest_Y_TestTimesSetting;
    public short RepeatabilityTest_Y_TestTimesSetting
    {
        get { return _repeatabilityTest_Y_TestTimesSetting; }
        set { SetProperty(ref _repeatabilityTest_Y_TestTimesSetting, value); }
    }

    /// <summary>
    /// Y軸座標1。
    /// </summary>
    private double _repeatabilityTest_Y_Coordinate1;
    public double RepeatabilityTest_Y_Coordinate1
    {
        get { return _repeatabilityTest_Y_Coordinate1; }
        set { SetProperty(ref _repeatabilityTest_Y_Coordinate1, value); }
    }

    /// <summary>
    /// Y軸座標2。
    /// </summary>
    private double _repeatabilityTest_Y_Coordinate2;
    public double RepeatabilityTest_Y_Coordinate2
    {
        get { return _repeatabilityTest_Y_Coordinate2; }
        set { SetProperty(ref _repeatabilityTest_Y_Coordinate2, value); }
    }

    /********************
     * 統計用
     ********************/

    private double _xMaxVisionResult;
    public double XMaxVisionResult
    {
        get { return _xMaxVisionResult; }
        set { SetProperty(ref _xMaxVisionResult, value); }
    }

    private double _xMinVisionResult;
    public double XMinVisionResult
    {
        get { return _xMinVisionResult; }
        set { SetProperty(ref _xMinVisionResult, value); }
    }

    private double _xDiffVisionResult;
    public double XDiffVisionResult
    {
        get { return _xDiffVisionResult; }
        set { SetProperty(ref _xDiffVisionResult, value); }
    }

    private double _xSumVisionResult;
    public double XSumVisionResult
    {
        get { return _xSumVisionResult; }
        set { SetProperty(ref _xSumVisionResult, value); }
    }

    private double _xAvgVisionResult;
    public double XAvgVisionResult
    {
        get { return _xAvgVisionResult; }
        set { SetProperty(ref _xAvgVisionResult, value); }
    }

    private double _yMaxVisionResult;
    public double YMaxVisionResult
    {
        get { return _yMaxVisionResult; }
        set { SetProperty(ref _yMaxVisionResult, value); }
    }

    private double _yMinVisionResult;
    public double YMinVisionResult
    {
        get { return _yMinVisionResult; }
        set { SetProperty(ref _yMinVisionResult, value); }
    }

    private double _yDiffVisionResult;
    public double YDiffVisionResult
    {
        get { return _yDiffVisionResult; }
        set { SetProperty(ref _yDiffVisionResult, value); }
    }

    private double _ySumVisionResult;
    public double YSumVisionResult
    {
        get { return _ySumVisionResult; }
        set { SetProperty(ref _ySumVisionResult, value); }
    }

    private double _yAvgVisionResult;
    public double YAvgVisionResult
    {
        get { return _yAvgVisionResult; }
        set { SetProperty(ref _yAvgVisionResult, value); }
    }

    private double _rMaxVisionResult;
    public double RMaxVisionResult
    {
        get { return _rMaxVisionResult; }
        set { SetProperty(ref _rMaxVisionResult, value); }
    }

    private double _rMinVisionResult;
    public double RMinVisionResult
    {
        get { return _rMinVisionResult; }
        set { SetProperty(ref _rMinVisionResult, value); }
    }

    private double _rDiffVisionResult;
    public double RDiffVisionResult
    {
        get { return _rDiffVisionResult; }
        set { SetProperty(ref _rDiffVisionResult, value); }
    }

    private double _rSumVisionResult;
    public double RSumVisionResult
    {
        get { return _rSumVisionResult; }
        set { SetProperty(ref _rSumVisionResult, value); }
    }

    private double _rAvgVisionResult;
    public double RAvgVisionResult
    {
        get { return _rAvgVisionResult; }
        set { SetProperty(ref _rAvgVisionResult, value); }
    }

    /********************
     * Vision
     ********************/
    /// <summary>
    /// 拍照功能。
    /// </summary>
    public bool VisionInRepeatabilityTest
    {
        get { return _visionInRepeatabilityTest; }
        set
        {
            SetProperty(ref _visionInRepeatabilityTest, value);
            if (_plc.Online)
                _plc.WriteBool(DeviceLists.REPEATABILITY_TEST_VISION_SW, value);
        }
    }
    private bool _visionInRepeatabilityTest = true;

    private void OnTimedEvent(object sender, EventArgs e)
    {
        if (_plc.Online)
        {
            // 重複精度測試
            var (_, repeatabilityXTestInRunning) = _plc.ReadBool(DeviceLists.REPEATABILITY_TEST_X_IN_RUNNING);
            RepeatabilityTest_X_TestInRunning = (bool)repeatabilityXTestInRunning;
            if (RepeatabilityTest_X_TestInRunning)
            {
                var (_, repeatabilityTest_TestedCounter) = _plc.ReadInt16(DeviceLists.REPEATABILITY_TEST_X_TESTED_COUNTER);
                RepeatabilityTest_X_TestedCounter = repeatabilityTest_TestedCounter;
            }

            var (_, repeatabilityYTestInRunning) = _plc.ReadBool(DeviceLists.REPEATABILITY_TEST_Y_IN_RUNNING);
            RepeatabilityTest_Y_TestInRunning = (bool)repeatabilityYTestInRunning;
            if (RepeatabilityTest_Y_TestInRunning)
            {
                var (_, repeatabilityTest_TestedCounter) = _plc.ReadInt16(DeviceLists.REPEATABILITY_TEST_Y_TESTED_COUNTER);
                RepeatabilityTest_Y_TestedCounter = repeatabilityTest_TestedCounter;
            }

            if ((bool)repeatabilityXTestInRunning || (bool)repeatabilityYTestInRunning)
            {
                var (_, complete) = _plc.ReadBool(_strComplete);
                if ((bool)complete)
                {
                    var (_, coor) = _plc.ReadDoubleByInt32(DeviceLists.REPEATABILITY_TEST_VISION_RESULT_X, 2);
                    double x = (coor[0] * 1000.0).Format(3);
                    double y = (coor[1] * 1000.0).Format(3);
                    double r = Math.Sqrt(x * x + y * y).WfsFormat();

                    VisionResult.Insert(0, new VisionResultDefine()
                    {
                        No = ++_pictureTimes,
                        X = x,
                        Y = y,
                    });

                    double diff;

                    // X
                    if (XMaxVisionResult < x)
                        XMaxVisionResult = x;
                    if (XMinVisionResult > x)
                        XMinVisionResult = x;

                    diff = Math.Abs(XMaxVisionResult - XMinVisionResult);
                    if (XDiffVisionResult < diff)
                        XDiffVisionResult = diff;

                    XSumVisionResult += Math.Abs(x);
                    XAvgVisionResult = _pictureTimes > 0 ? XSumVisionResult / _pictureTimes : 0.0;

                    // Y
                    if (YMaxVisionResult < y)
                        YMaxVisionResult = y;
                    if (YMinVisionResult > y)
                        YMinVisionResult = y;

                    diff = Math.Abs(YMaxVisionResult - YMinVisionResult);
                    if (YDiffVisionResult < diff)
                        YDiffVisionResult = diff;

                    YSumVisionResult += Math.Abs(y);
                    YAvgVisionResult = _pictureTimes > 0 ? YSumVisionResult / _pictureTimes : 0.0;

                    // R
                    if (RMaxVisionResult < r)
                        RMaxVisionResult = r;
                    if (RMinVisionResult > r)
                        RMinVisionResult = r;

                    diff = Math.Abs(RMaxVisionResult - RMinVisionResult);
                    if (RDiffVisionResult < diff)
                        RDiffVisionResult = diff;

                    RSumVisionResult += Math.Abs(r);
                    RAvgVisionResult = _pictureTimes > 0 ? RSumVisionResult / _pictureTimes : 0.0;

                    //ElementCollection<Series> tmp = ResultList.Series;
                    //tmp.Add(new DataPoint(coor[0], coor[1]));
                    //tmp.Add(series1);

                    _plc.SendCommandPulse(_strHandshake);
                }
            }
        }
    }
}

/// <summary>
/// 重覆精度測試拍照結果資料定義。
/// </summary>
public class VisionResultDefine
{
    /// <summary>
    /// 拍照序號。
    /// </summary>
    public double No { get; set; }

    /// <summary>
    /// X軸偏移值。
    /// </summary>
    public double X { get; set; }

    /// <summary>
    /// Y軸偏移值。
    /// </summary>
    public double Y { get; set; }

    /// <summary>
    /// 角度。
    /// </summary>
    public double R => Math.Sqrt(X * X + Y * Y);
}
