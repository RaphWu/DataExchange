﻿using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WPF.Extensions;
using Prism;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 轉角度模式頁面的ViewModel。
/// </summary>
public class LensArrangeViewModel : BindableBase, IConfirmNavigationRequest, IActiveAware
{
    /********************
     * IConfirmNavigationRequest
     ********************/
    public void ConfirmNavigationRequest(NavigationContext navigationContext, Action<bool> continuationCallback)
    {
        bool result = true;

        //foreach (var item in PalletListsOrderByFunc)
        //{
        //    if (!item.Equals(_wfs.PalletArrangeList.Find(x => x.Id == item.Id)))
        //    {
        //        MessageBoxResult userChoice = CommonFunctions.DataNotSavedWhenLeave(showCancelButton: true);

        //        if (userChoice == MessageBoxResult.Yes)
        //        {
        //            WriteToDb();
        //        }
        //        else if (userChoice == MessageBoxResult.Cancel)
        //        {
        //            _sysMessenger.LightUpPreviousMainMenuButton(string.Empty);
        //            result = false;
        //        }

        //        break;
        //    }
        //}

        continuationCallback(result);
    }

    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_PalletArrange"));

        UpdateTrayList();
        UpdateTraySelected();
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
        _wfs.LensArrangeList = LensArrangeList.ToList();
        WriteToDb();
        //_ea.GetEvent<WriteNewPointNoEvent>().Publish(0);
        //_ea.GetEvent<PalletInfoChangedEvent>().Publish(true);
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    private bool _isActive = false;
    public bool IsActive
    {
        get { return _isActive; }
        set
        {
            _isActive = value;
            OnIsActiveChanged();

            if (value)
                UpdateTrayMatrixSource(TrayMatrixId);
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly ISystemMessenger _sysMessenger;
    private readonly ITray _tray;
    private readonly IWfs _wfs;

    public LensArrangeViewModel(IApplicationCommands applicationCommands,
                                IEventAggregator ea,
                                ISystemMessenger sysMessenger,
                                ITray tray,
                                IWfs wfs)
    {
        _ea = ea;
        _sysMessenger = sysMessenger;
        _tray = tray;
        _wfs = wfs;

        ReadFromDb();

        // TODO: UnregisterCommand
        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /// <summary>
    /// 將資料或參數寫入資料庫。
    /// </summary>
    public void ExecuteSaveDataCommand()
    {
        WriteToDb();
    }

    /// <summary>
    /// 寫入資料庫。
    /// </summary>
    public bool WriteToDb()
    {
        // 更新TrayMode
        foreach (var pallet in LensArrangeList)
        {
            if (pallet.Pick)
            {
                pallet.TrayMode = PlcTrayFunctionType.Feeder;
                //_tray.WriteTrayToPlc(pallet.Id, _tray.GetTray(pallet.PickTrayId));
            }
            else if (pallet.Place)
            {
                pallet.TrayMode = PlcTrayFunctionType.AngleArrange;
                //_tray.WriteTrayToPlc(pallet.Id, _tray.GetTray(pallet.PlaceTrayId));
            }
            else
            {
                pallet.TrayMode = PlcTrayFunctionType.Unused;
            }
        }

        _wfs.LensArrangeList = LensArrangeList.ToList();
        _wfs.WriteToDb();
        _ea.GetEvent<WriteNewPointNoEvent>().Publish(0);
        //_ea.GetEvent<PalletInfoChangedEvent>().Publish(true);
        return DataValidation();

        //if (DataValidation())
        //{
        //    _wfs.LensArrangeList = LensArrangeList.ToList();
        //    _wfs.WriteToDb();
        //    //UpdateListOrder();
        //    return true;
        //}
        //else
        //{
        //    return false;
        //}
    }

    /// <summary>
    /// 讀取資料庫。
    /// </summary>
    public void ReadFromDb()
    {
        _wfs.ReadFromDb();
        UpdateTrayList();
        UpdateTraySelected();
    }

    /// <summary>
    /// 參數有效性檢查。
    /// </summary>
    private bool DataValidation() => _wfs.ConditionCheckAndWriteToPlc(false, LensArrangeList.ToList());

    /// <summary>
    /// 更新Tray選擇器。
    /// </summary>
    private void UpdateTrayList()
    {
        PickPlaceTrayList = _tray.TraySelector(true);

        // note: 原分成二個，但不知為何資料已更新，但畫面顯示卻沒update？
        //       合併使用同一個後顯示就穩定了。
        //PickTrayList = _tray.TraySelector(true);
        //PlaceTrayList = _tray.TraySelector(true);
    }

    /// <summary>
    /// 從資料來源更新資料。
    /// </summary>
    private void UpdateTraySelected()
    {
        _wfs.UpdateRelationList();
        LensArrangeList = new ObservableCollection<LensArrangeDefine>(_wfs.LensArrangeList.DeepCopyByExpressionTree()
                                                                                          .OrderBy(x => x.Id));

        var pick = _wfs.LensArrangeList.Find(x => x.PickTrayId >= 0);
        PickTraySelected = pick != null ? pick.PickTrayId : -1;

        var place = _wfs.LensArrangeList.Find(x => x.PlaceTrayId >= 0);
        PlaceTraySelected = place != null ? place.PlaceTrayId : -1;
    }

    /// <summary>
    /// 更新Tray矩陣顯示。
    /// </summary>
    private void UpdateTrayMatrixSource(int palletId)
    {
        if (palletId >= 0)
        {
            //var pallet = _tray.PalletList.Find(x => x.Id == palletId);
            var pa = LensArrangeList.First(x => x.Id == palletId);
            TrayDefine td;

            if (pa.Pick)
                td = _tray.TrayList.Find(x => x.Id == pa.PickTrayId).DeepCopyByExpressionTree();
            else if (pa.Place)
                td = _tray.TrayList.Find(x => x.Id == pa.PlaceTrayId).DeepCopyByExpressionTree();
            else
                td = null;

            // 見 TrayMatrix.xaml.cs 中 ThisTray_PropertyChanged() 的註解 <see cref="TrayMatrix.TrayMatrix()"/>
            TrayMatrixRegionContext tmrc = new()
            {
                Tray = td,
                PalletId = palletId
            };
            TrayMatrixSource = null;
            TrayMatrixSource = tmrc;
        }
    }

    /********************
     * TrayMatrix
     ********************/
    /// <summary>
    /// 傳遞給TrayMatrix的資料。
    /// </summary>
    public TrayMatrixRegionContext TrayMatrixSource
    {
        get { return _trayMatrixSource; }
        set { SetProperty(ref _trayMatrixSource, value); }
    }
    private TrayMatrixRegionContext _trayMatrixSource;

    /********************   
     * Tray Source
     ********************/
    /// <summary>
    /// 
    /// </summary>
    public ObservableCollection<LensArrangeDefine> LensArrangeList
    {
        get { return _lensArrangeList; }
        set { SetProperty(ref _lensArrangeList, value); }
    }
    private ObservableCollection<LensArrangeDefine> _lensArrangeList;

    /// <summary>
    /// 
    /// </summary>
    public DelegateCommand<object> UpdateRelationListCommand
       => _updateRelationListCommand ??= new DelegateCommand<object>(ExecuteUpdateRelationList);
    private void ExecuteUpdateRelationList(object para)
    {
        if (para != null)
        {
            if (int.TryParse(para.ToString(), out int palletId))
            {
                var pl = LensArrangeList[palletId - 1];
                pl.PickTrayId = pl.Pick ? PickTraySelected : -1;
                pl.PlaceTrayId = pl.Place ? PlaceTraySelected : -1;

                _wfs.UpdateRelationList(LensArrangeList.ToList());
            }
        }
    }
    private DelegateCommand<object> _updateRelationListCommand;

    /// <summary>
    /// 清除指定Pallet的設定資料。
    /// </summary>
    public DelegateCommand<object> ClearPickAndPlaceCommand
        => _clearPickAndPlaceCommand ??= new DelegateCommand<object>(ExecuteClearPickAndPlace);
    private void ExecuteClearPickAndPlace(object para)
    {
        if (para != null)
        {
            if (int.TryParse(para.ToString(), out int palletId))
            {
                var pallets = LensArrangeList;
                var pallet = pallets[palletId - 1];
                pallet.Pick = false;
                pallet.Place = false;
                LensArrangeList = pallets;
                _wfs.UpdateRelationList(LensArrangeList.ToList());
            }
        }
    }
    private DelegateCommand<object> _clearPickAndPlaceCommand;

    /// <summary>
    /// 清除全部Pallet的設定資料。
    /// </summary>
    public DelegateCommand ClearAllPickAndPlaceCommand
          => _clearAllPickAndPlaceCommand ??= new DelegateCommand(ExecuteClearAllPickAndPlaceCommand);
    private void ExecuteClearAllPickAndPlaceCommand()
    {
        var pallets = LensArrangeList;
        for (int palletIdx = 0; palletIdx < ITray.MaxPalletId; palletIdx++)
        {
            var pallet = pallets[palletIdx];
            pallet.Pick = false;
            pallet.Place = false;
        }
        LensArrangeList = pallets;
        _wfs.UpdateRelationList(LensArrangeList.ToList());
    }
    private DelegateCommand _clearAllPickAndPlaceCommand;

    /// <summary>
    /// Tray選擇有更動時，更新Tray矩陣的顯示。
    /// </summary>
    public DelegateCommand<object> UpdateMatrixSourceCommand
        => _updateMatrixSourceCommand ??= new DelegateCommand<object>(ExecuteUpdateMatrixSourceCommand);
    private void ExecuteUpdateMatrixSourceCommand(object para)
    {
        if (para != null)
        {
            if (int.TryParse(para.ToString(), out int palletId))
            {
                // 更新全部Tray
                foreach (var pallet in LensArrangeList)
                {
                    pallet.PickTrayId = pallet.Pick ? PickTraySelected : -1;
                    pallet.PlaceTrayId = pallet.Place ? PlaceTraySelected : -1;
                }

                // TrayMatrix
                if (palletId >= 0)
                {
                    TrayMatrixId = palletId;
                    TrayMatrixEnabled = true;
                }
                UpdateTrayMatrixSource(TrayMatrixId);
            }
        }
    }
    private DelegateCommand<object> _updateMatrixSourceCommand;

    /********************
     * Combobox Source
     ********************/
    /// <summary>
    /// 取放料列表。
    /// </summary>
    public Dictionary<int, string> PickPlaceTrayList
    {
        get { return _pickPlaceTrayList; }
        set { SetProperty(ref _pickPlaceTrayList, value); }
    }
    private Dictionary<int, string> _pickPlaceTrayList;

    ///// <summary>
    ///// 取料列表。
    ///// </summary>
    //public Dictionary<int, string> PickTrayList
    //{
    //    get { return _pickTrayList; }
    //    set { SetProperty(ref _pickTrayList, value); }
    //}
    //private Dictionary<int, string> _pickTrayList;

    /// <summary>
    /// 選擇的取料Tray ID。
    /// </summary>
    public int PickTraySelected
    {
        get { return _pickTraySelected; }
        set { SetProperty(ref _pickTraySelected, value); }
    }
    private int _pickTraySelected;

    ///// <summary>
    ///// 放料列表。
    ///// </summary>
    //public Dictionary<int, string> PlaceTrayList
    //{
    //    get { return _placeTrayList; }
    //    set { SetProperty(ref _placeTrayList, value); }
    //}
    //private Dictionary<int, string> _placeTrayList;

    /// <summary>
    /// 選擇的放料Tray ID。
    /// </summary>
    public int PlaceTraySelected
    {
        get { return _placeTraySelected; }
        set { SetProperty(ref _placeTraySelected, value); }
    }
    private int _placeTraySelected;

    /********************
     * TrayMatrix
     ********************/
    /// <summary>
    /// TrayMatrix顯示的Tray ID
    /// </summary>
    public int TrayMatrixId
    {
        get { return _trayMatrixId; }
        set { SetProperty(ref _trayMatrixId, value); }
    }
    private static int _trayMatrixId = -1;

    /// <summary>
    /// TrayMatrix是否有效
    /// </summary>
    public bool TrayMatrixEnabled
    {
        get { return _trayMatrixEnabled; }
        set { SetProperty(ref _trayMatrixEnabled, value); }
    }
    private bool _trayMatrixEnabled = false;
}
