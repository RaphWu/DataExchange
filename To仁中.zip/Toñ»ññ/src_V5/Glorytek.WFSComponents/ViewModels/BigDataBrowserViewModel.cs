﻿using Glorytek.WFSComponents.Events;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSComponents.WFS.Models;
using Glorytek.WFSCore.Contracts;
using Prism.Events;
using Prism.Mvvm;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 大數據瀏覽器的ViewModel。
/// </summary>
public class BigDataBrowserViewModel : BindableBase
{
    private readonly BigDataContent _bdContent = BigDataContent.Instance;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly ISystemMessenger _sysMessenger;
    private readonly IWfs _wfs;

    public BigDataBrowserViewModel(IEventAggregator ea, ISystemMessenger sysMessenger, IWfs wfs)
    {
        _ea = ea;
        _sysMessenger = sysMessenger;
        _wfs = wfs;

        _ = _ea.GetEvent<LotNumberChangedEvent>().Subscribe(LotNumberChanged);
    }

    /********************
     * Event
     ********************/
    private void LotNumberChanged(string lotNumber)
    {
        SelectedLotNumber = lotNumber;
    }

    /********************
     * Property
     ********************/
    /// <summary>
    /// 選擇的LotNumber。
    /// </summary>
    public string SelectedLotNumber
    {
        get { return _selectedLotNumber; }
        set
        {
            if (_wfs.IsLotNumberValid(value) && !_bdContent.LotNumberList.Contains(value))
                _bdContent.LotNumberList.Add(value);

            _wfs.GetLotNumberDataFromDb(value);
            _wfs.UpdateBrowser();

            _bdContent.SelectedLotNumber = value;  // 只保持數值同步
            SetProperty(ref _selectedLotNumber, value);
        }
    }
    private string _selectedLotNumber = string.Empty;
}
