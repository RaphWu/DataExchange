﻿using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.WFS;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.Helpers;
using Glorytek.WPF.PrismMessageBox;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 
/// </summary>
public class WfsSpecificationViewModel : BindableBase, INavigationAware
{
    //private int _thisGradeId = -1;

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        _sysMessenger.StatusBarMessage(GetResource.GetValue<string>("PageTitle_WFS_SpecificationSetting"));

        WfsDataNameListSource = _wfs.DataNameList.OrderBy(x => x.OrderNo).ToList();
        RefreshDataNameList();

        UpdateDataSource();
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
        WriteSpecificationToDb();
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    //private bool _isActive = false;
    //public bool IsActive
    //{
    //    get { return _isActive; }
    //    set
    //    {
    //        _isActive = value;
    //        OnIsActiveChanged();
    //    }
    //}
    //public event EventHandler IsActiveChanged;
    //public DelegateCommand SaveDataCommand { get; private set; }
    //private void OnIsActiveChanged()
    //{
    //    SaveDataCommand.IsActive = IsActive;
    //    IsActiveChanged?.Invoke(this, new EventArgs());
    //}

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly ICrudDialog _crudDialog;
    private readonly IWfs _wfs;

    public WfsSpecificationViewModel(ISystemMessenger sysMessenger,
                                     IPrismMessageBox prismMessageBox,
                                     ICrudDialog crudDialog,
                                     IWfs wfs)
    {
        _sysMessenger = sysMessenger;
        _prismMessageBox = prismMessageBox;
        _crudDialog = crudDialog;
        _wfs = wfs;

        //// TODO: UnregisterCommand
        //SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        //applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 將資料或參數寫入資料庫
    /// </summary>
    public void ExecuteSaveDataCommand()
    {
        WriteToDb();
    }

    /// <summary>
    /// 將Model資料寫入資料庫
    /// </summary>
    private void WriteToDb()
    {
        if (WfsGradeListSource != null)
            _wfs.GradeList = WfsGradeListSource.ToList();

        _wfs.WriteToDb();
    }

    private void WriteSpecificationToDb()
    {
        _wfs.WriteSpecificationToDb();
    }

    /// <summary>
    /// 更新等級及規格的來源
    /// </summary>
    public void UpdateDataSource()
    {
        WfsGradeListSource = new ObservableCollectionWithItemNotify<WfsGradeDefine>(_wfs.GradeList.OrderBy(x => x.OrderNo));
        UpdateSpecificationListSource();
    }

    /// <summary>
    /// 只更新規格來源
    /// </summary>
    private void UpdateSpecificationListSource()
    {
        if (GradeSelected)
        {
            WfsSpecificationListSource = new ObservableCollectionWithItemNotify<WfsSpecificationDefine>(_wfs.SpecificationList
                .FindAll(x => x.GradeId == WfsGradeListItem.Id)
                .OrderBy(x => x.OrderNo));
        }
        else
        {
            WfsSpecificationListSource = new ObservableCollectionWithItemNotify<WfsSpecificationDefine>();
        }
    }

    ///// <summary>
    ///// 將View資料存回Model
    ///// </summary>
    //private bool SaveData()
    //{
    //    try
    //    {
    //        _wfs.DataNameList = WfsDataNameListSource;
    //        //_wfs.GradeList = WfsGradeListSource;
    //        //return SaveSpecification();
    //    }
    //    catch
    //    {
    //        return false;
    //    }
    //}

    //private bool SaveSpecification()
    //{
    //    if (WfsSpecificationListSource != null)
    //    {
    //        try
    //        {
    //            foreach (var item in WfsSpecificationListSource)
    //            {
    //                int idx = _wfs.SpecificationList.FindIndex(x => x.Id == item.Id);
    //                _wfs.SpecificationList[idx] = item;
    //            }
    //            return true;
    //        }
    //        catch
    //        {
    //        }
    //    }
    //    return false;
    //}

    //private void LoadData()
    //{
    //    WfsDataNameListSource = _wfs.DataNameList.OrderBy(x => x.OrderNo).ToList();
    //    RefreshDataNameList();

    //    WfsGradeListSource = _wfs.GradeList;
    //    RefreshSpecificationListSource();
    //}

    //private void UpdateDataSource()()
    //{
    //    //var gradeBackup = WfsGradeListItem;
    //    //var specBackup = WfsSpecificationItem;

    //    WfsGradeListSource = null;
    //    WfsGradeListSource = new ObservableCollection(_wfs.GradeList);

    //    //if (_wfs.GradeList != null && gradeBackup != null)
    //    //    if (_wfs.GradeList.FindIndex(x => x.Id == gradeBackup.Id) >= 0)
    //    //        WfsGradeListItem = gradeBackup;

    //    WfsSpecificationListSource = null;
    //    if (WfsGradeListItem != null)
    //    {
    //        GradeSelected = true;
    //        _thisGradeId = WfsGradeListItem.Id;
    //        WfsSpecificationListSource = _wfs.SpecificationList
    //            .FindAll(x => x.GradeId == WfsGradeListItem.Id)
    //            .OrderBy(x => x.OrderNo)
    //            .ToList();
    //    }
    //    else
    //    {
    //        GradeSelected = false;
    //        _thisGradeId = -1;
    //        WfsSpecificationListSource = new List<WfsSpecificationDefine>();
    //    }

    //    //if (_wfs.SpecificationList != null && specBackup != null)
    //    //    if (_wfs.SpecificationList.FindIndex(x => x.Id == specBackup.Id) >= 0)
    //    //        WfsSpecificationItem = specBackup;

    //    WriteToDb();

    //    RefreshGradeDisplay();
    //    RefreshSpecificationDisplay();
    //}

    /********************
     * System
     ********************/
    /// <summary>
    /// 按鍵狀態設定
    /// </summary>
    private void SetButtonState()
    {
        if (WfsDataNameListItem != null)
        {
            DataNameListHasItem = WfsDataNameListItem != null;
            DataNameItemMoveUpEnabled = DataNameListHasItem && WfsDataNameListIndex != 0;
            DataNameItemMoveDownEnabled = DataNameListHasItem && WfsDataNameListIndex != (WfsDataNameListSource.Count - 1);
        }
    }

    /********************
     * Data Name List
     ********************/
    public List<WfsDataNameListDefine> WfsDataNameListSource
    {
        get { return _wfsDataNameListSource; }
        set { SetProperty(ref _wfsDataNameListSource, value); }
    }
    private List<WfsDataNameListDefine> _wfsDataNameListSource;

    public WfsDataNameListDefine WfsDataNameListItem
    {
        get { return _wfsDataNameListItem; }
        set
        {
            SetProperty(ref _wfsDataNameListItem, value);
            DataNameListChanged();
        }
    }
    private WfsDataNameListDefine _wfsDataNameListItem;

    public int WfsDataNameListIndex
    {
        get { return _wfsDataNameListIndex; }
        set { SetProperty(ref _wfsDataNameListIndex, value); }
    }
    private int _wfsDataNameListIndex;

    private void DataNameListChanged()
    {
        SetButtonState();
    }

    public Dictionary<int, string> WfsDataNameList
    {
        get { return _wfsDataNameList; }
        set { SetProperty(ref _wfsDataNameList, value); }
    }
    private Dictionary<int, string> _wfsDataNameList;

    public int WfsDataNameSelected
    {
        get { return _wfsDataNameSelected; }
        set { _wfsDataNameSelected = value; }
    }
    private int _wfsDataNameSelected;

    private void RefreshDataNameList()
    {
        if (WfsDataNameListSource.Count > 0)
        {
            WfsDataNameListSource = WfsDataNameListSource.OrderBy(x => x.OrderNo).ToList();
            _wfs.DataNameList = WfsDataNameListSource;
            _wfs.WriteDataNameListToDb();

            WfsDataNameList = WfsDataNameListSource.ToDictionary(
                WfsDataNameListDefine => WfsDataNameListDefine.Id,
                WfsDataNameListDefine => WfsDataNameListDefine.Name);
        }
        else
        {
            WfsDataNameList = new Dictionary<int, string>();
        }

        //DataNameListChanged();
    }

    /*****
     * Button Enabled
     *****/
    public bool DataNameListHasItem
    {
        get { return _dataNameListHasItem; }
        set { SetProperty(ref _dataNameListHasItem, value); }
    }
    private bool _dataNameListHasItem;

    public bool DataNameItemMoveUpEnabled
    {
        get { return _dataNameItemMoveUpEnabled; }
        set { SetProperty(ref _dataNameItemMoveUpEnabled, value); }
    }
    private bool _dataNameItemMoveUpEnabled;

    public bool DataNameItemMoveDownEnabled
    {
        get { return _dataNameItemMoveDownEnabled; }
        set { SetProperty(ref _dataNameItemMoveDownEnabled, value); }
    }
    private bool _dataNameItemMoveDownEnabled;

    /*****
     * Command
     *****/
    /// <summary>
    /// DataName順序上移命令。
    /// </summary>
    public DelegateCommand<WfsDataNameListDefine> WfsDataNameMoveUpCommand
        => _wfsDataNameMoveUpCommand ??= new DelegateCommand<WfsDataNameListDefine>(ExecuteWfsDataNameMoveUpCommand);
    private void ExecuteWfsDataNameMoveUpCommand(WfsDataNameListDefine dn1)
    {
        int dnOrder1 = dn1.OrderNo;

        int dnIndex2 = WfsDataNameListIndex - 1;
        WfsDataNameListDefine dn2 = WfsDataNameListSource[dnIndex2];
        int dnOrder2 = dn2.OrderNo;

        dn1.OrderNo = dnOrder2;
        dn2.OrderNo = dnOrder1;
        RefreshDataNameList();
        SetButtonState();
    }
    private DelegateCommand<WfsDataNameListDefine> _wfsDataNameMoveUpCommand;

    /// <summary>
    /// DataName順序下移命令。
    /// </summary>
    public DelegateCommand<WfsDataNameListDefine> WfsDataNameMoveDownCommand
         => _wfsDataNameMoveDownCommand ??= new DelegateCommand<WfsDataNameListDefine>(ExecuteWfsDataNameMoveDownCommand);
    private void ExecuteWfsDataNameMoveDownCommand(WfsDataNameListDefine dn1)
    {
        int dnOrder1 = dn1.OrderNo;

        int dnIndex2 = WfsDataNameListIndex + 1;
        WfsDataNameListDefine dn2 = WfsDataNameListSource[dnIndex2];
        int dnOrder2 = dn2.OrderNo;

        dn1.OrderNo = dnOrder2;
        dn2.OrderNo = dnOrder1;
        RefreshDataNameList();
        SetButtonState();
    }
    private DelegateCommand<WfsDataNameListDefine> _wfsDataNameMoveDownCommand;

    /********************
     * Grade List
     ********************/
    public ObservableCollectionWithItemNotify<WfsGradeDefine> WfsGradeListSource
    {
        get { return _wfsGradeListSource; }
        set { SetProperty(ref _wfsGradeListSource, value); }
    }
    private ObservableCollectionWithItemNotify<WfsGradeDefine> _wfsGradeListSource;

    public WfsGradeDefine WfsGradeListItem
    {
        get { return _wfsGradeListItem; }
        set
        {
            SetProperty(ref _wfsGradeListItem, value);
            GradeSelected = value != null;

            WriteToDb();
            UpdateSpecificationListSource();
        }
    }
    private WfsGradeDefine _wfsGradeListItem;

    /// <summary>
    /// 新增等級
    /// </summary>
    public DelegateCommand NewGradeCommand
        => _newGradeCommand ??= new DelegateCommand(ExecuteNewGradeCommand);
    private void ExecuteNewGradeCommand()
    {
        CrudInfo crudInfo = new CrudInfo()
        {
            Action = CrudAction.Append,
            Title = "新增等級",
            NewTitle = "等級名稱",
            NewName = "",
            OriginalTitle = "",
            MemoTitle = "",
            PasswordTitle = "",
        };
        CrudInfo result = _crudDialog.ShowDialog(crudInfo);

        if (result.Result == ButtonResult.OK)
        {
            _wfs.CreateNewGrade(result);
            UpdateDataSource();
            WfsGradeListItem = WfsGradeListSource.First(x => x.Name == result.NewName);
        }
    }
    private DelegateCommand _newGradeCommand;

    /// <summary>
    /// 等級更名命令。
    /// </summary>
    public DelegateCommand<WfsGradeDefine> RenameGradeCommand
        => _renameGradeCommand ??= new DelegateCommand<WfsGradeDefine>(ExecuteRenameGradeCommand);
    private void ExecuteRenameGradeCommand(WfsGradeDefine item)
    {
        if (item != null)
        {
            CrudInfo crudInfo = new CrudInfo()
            {
                Action = CrudAction.Rename,
                Id = item.Id,
                Title = "變更等級名稱",
                NewTitle = "新名稱",
                NewName = "",
                OriginalTitle = "原名稱",
                OriginalName = item.Name,
                MemoTitle = "",
                PasswordTitle = "",
            };
            CrudInfo result = _crudDialog.ShowDialog(crudInfo);

            if (result.Result == ButtonResult.OK)
            {
                _wfs.RenameGradeName(result);
                UpdateDataSource();
                WfsGradeListItem = WfsGradeListSource.First(x => x.Name == result.NewName);
            }
        }
    }
    private DelegateCommand<WfsGradeDefine> _renameGradeCommand;

    /// <summary>
    /// 刪除等級命令。
    /// </summary>
    public DelegateCommand<WfsGradeDefine> DeleteGradeCommand
       => _deleteGradeCommand ??= new DelegateCommand<WfsGradeDefine>(ExecuteDeleteGradeCommand);
    private void ExecuteDeleteGradeCommand(WfsGradeDefine item)
    {
        if (item != null)
        {
            // 刪除確認
            if (_prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DeleteConfirmation")}\n{GetResource.GetValue<string>("Glorytek.WFSCore", "GradeName2")}: {item.Name}",
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "Message_Delete"),
                                      MessageBoxImage.Question,
                                      PrismMessageBoxButton.YesNo) == ButtonResult.Yes)
            {
                _wfs.DeleteGrade(item.Id);
                UpdateDataSource();
            }
        }
    }
    private DelegateCommand<WfsGradeDefine> _deleteGradeCommand;

    /// <summary>
    /// 等級排序上移命令。
    /// </summary>
    public DelegateCommand<WfsGradeDefine> MoveGradeUpCommand
        => _moveGradeUpCommand ??= new DelegateCommand<WfsGradeDefine>(ExecuteMoveGradeUpCommand);
    private void ExecuteMoveGradeUpCommand(WfsGradeDefine item)
    {
        if (item != null)
        {
            var item2 = WfsGradeListSource.FirstOrDefault(x => x.OrderNo == item.OrderNo - 1);
            if (item2 != null)
            {
                (item.OrderNo, item2.OrderNo) = (item2.OrderNo, item.OrderNo);
                WriteToDb();
                UpdateDataSource();
                WfsGradeListItem = WfsGradeListSource.First(x => x.Id == item.Id);
            }
        }
    }
    private DelegateCommand<WfsGradeDefine> _moveGradeUpCommand;

    /// <summary>
    /// 等級排序下移命令。
    /// </summary>
    public DelegateCommand<WfsGradeDefine> MoveGradeDownCommand
        => _moveGradeDownCommand ??= new DelegateCommand<WfsGradeDefine>(ExecuteMoveGradeDownCommand);
    private void ExecuteMoveGradeDownCommand(WfsGradeDefine item)
    {
        if (item != null)
        {
            var item2 = WfsGradeListSource.FirstOrDefault(x => x.OrderNo == item.OrderNo + 1);
            if (item2 != null)
            {
                (item.OrderNo, item2.OrderNo) = (item2.OrderNo, item.OrderNo);
                WriteToDb();
                UpdateDataSource();
                WfsGradeListItem = WfsGradeListSource.First(x => x.Id == item.Id);
            }
        }
    }
    private DelegateCommand<WfsGradeDefine> _moveGradeDownCommand;

    /********************
     * Specification
     ********************/
    public ObservableCollection<WfsSpecificationDefine> WfsSpecificationListSource
    {
        get { return _wfsSpecificationListSource; }
        set { SetProperty(ref _wfsSpecificationListSource, value); }
    }
    private ObservableCollection<WfsSpecificationDefine> _wfsSpecificationListSource;

    public WfsSpecificationDefine WfsSpecificationItem
    {
        get { return _wfsSpecificationItem; }
        set
        {
            SetProperty(ref _wfsSpecificationItem, value);
            SpecificationSelected = value != null;
            WriteSpecificationToDb();
        }
    }
    private WfsSpecificationDefine _wfsSpecificationItem;

    //private void SpecificationListChanged()
    //{
    //    SpecificationSelected = WfsSpecificationItem != null;
    //}

    //private void RefreshSpecificationDisplay()
    //{
    //    var specListBackup = _wfs.SpecificationList.OrderBy(x => x.OrderNo).ToList();
    //    _wfs.SpecificationList = null;
    //    _wfs.SpecificationList = specListBackup;
    //}

    //public string RelationSelectionChanged
    //{
    //    get { return _RelationSelectionChanged; }
    //    set { SetProperty(ref _RelationSelectionChanged, value); }
    //}
    //private string _RelationSelectionChanged;

    //private void SetSpecificationItemVisibility(InequalityRelationType relation)
    //{
    //    BetweenOperator = relation == InequalityRelationType.Between;
    //    NotBetweenOperator = relation == InequalityRelationType.NotBetween;
    //    UnaryOperator = !BetweenOperator && !NotBetweenOperator;
    //}

    /// <summary>
    /// 關係變更處理。
    /// </summary>
    public DelegateCommand<object[]> RelationChangedCommand
        => _relationChangedCommand ??= new DelegateCommand<object[]>(ExecuteRelationChangedCommand);
    private void ExecuteRelationChangedCommand(object[] item)
    {
        if (item != null && item[0] is InequalityRelationType arg)
        {
            WfsSpecificationItem.Relation = arg;
            UpdateSpecificationListSource();
        }
    }
    private DelegateCommand<object[]> _relationChangedCommand;

    ///// <summary>
    ///// 
    ///// </summary>
    //public DelegateCommand<object> SpecificationItemRowEditEndingCommand
    //    => _specificationItemRowEditEndingCommand ??= new DelegateCommand<object>(ExecuteSpecificationItemRowEditEndingCommand);
    //void ExecuteSpecificationItemRowEditEndingCommand(object parameter)
    //{
    //    if (parameter != null && parameter is DataGridRowEditEndingEventArgs row)
    //    {
    //        DataGridRow thisRow = row.Row;
    //        WfsSpecificationDefine item = (WfsSpecificationDefine)thisRow.Item;

    //        //RefreshSpecificationListSource();
    //        //SetSpecificationItemVisibility(item.Relation);

    //        //if (thisRow.IsNewItem)
    //        //{

    //        //}
    //        //else
    //        //{

    //        //}

    //        //ExecuteShowDatas();
    //    }
    //}
    //private DelegateCommand<object> _specificationItemRowEditEndingCommand;

    /// <summary>
    /// 新增一個規格設定。
    /// </summary>
    public DelegateCommand NewSpecCommand
       => _newSpecCommand ??= new DelegateCommand(ExecuteNewSpecCommand);
    private void ExecuteNewSpecCommand()
    {
        if (WfsGradeListItem != null)
        {
            _wfs.CreateNewSpecification(WfsGradeListItem.Id);
            UpdateSpecificationListSource();
        }
    }
    private DelegateCommand _newSpecCommand;

    /// <summary>
    /// 刪除一個規格設定。
    /// </summary>
    public DelegateCommand<WfsSpecificationDefine> DeleteSpecCommand
        => _deleteSpecCommand ??= new DelegateCommand<WfsSpecificationDefine>(ExecuteDeleteSpecCommand);
    private void ExecuteDeleteSpecCommand(WfsSpecificationDefine item)
    {
        if (item != null)
        {
            if (_prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DeleteConfirmation")}\n{GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_No")}: {item.OrderNo}",
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "Message_Delete"),
                                      MessageBoxImage.Question,
                                      PrismMessageBoxButton.YesNo) == ButtonResult.Yes)
            {
                _wfs.DeleteSpecification(item.Id);
                UpdateSpecificationListSource();

                //var specSourceBackup = WfsSpecificationListSource.OrderBy(x => x.OrderNo).ToList();

                //int orderNo = 0;
                //foreach (var spec in specSourceBackup)
                //    spec.OrderNo = ++orderNo;

                //WfsSpecificationListSource = null;
                //WfsSpecificationListSource = specSourceBackup;
            }
        }
    }
    private DelegateCommand<WfsSpecificationDefine> _deleteSpecCommand;

    /// <summary>
    /// 提升規格的比較順序。
    /// </summary>
    public DelegateCommand<WfsSpecificationDefine> MoveSpecUpCommand
       => _moveSpecUpCommand ??= new DelegateCommand<WfsSpecificationDefine>(ExecuteMoveSpecUpCommand);
    private void ExecuteMoveSpecUpCommand(WfsSpecificationDefine item)
    {
        if (item != null)
        {
            var item2 = WfsSpecificationListSource.FirstOrDefault(x => x.OrderNo == item.OrderNo - 1 && x.GradeId == item.GradeId);
            if (item2 != null)
            {
                (item.OrderNo, item2.OrderNo) = (item2.OrderNo, item.OrderNo);
                WriteSpecificationToDb();
                UpdateSpecificationListSource();
                WfsSpecificationItem = WfsSpecificationListSource.First(x => x.Id == item.Id);
            }
        }
    }
    private DelegateCommand<WfsSpecificationDefine> _moveSpecUpCommand;

    /// <summary>
    /// 降低規格的比較順序。
    /// </summary>
    public DelegateCommand<WfsSpecificationDefine> MoveSpecDownCommand
        => _moveSpecDownCommand ??= new DelegateCommand<WfsSpecificationDefine>(ExecuteMoveSpecDownCommand);
    private void ExecuteMoveSpecDownCommand(WfsSpecificationDefine item)
    {
        if (item != null)
        {
            var item2 = WfsSpecificationListSource.FirstOrDefault(x => x.OrderNo == item.OrderNo + 1 && x.GradeId == item.GradeId);
            if (item2 != null)
            {
                (item.OrderNo, item2.OrderNo) = (item2.OrderNo, item.OrderNo);
                WriteSpecificationToDb();
                UpdateSpecificationListSource();
                WfsSpecificationItem = WfsSpecificationListSource.First(x => x.Id == item.Id);
            }
        }
    }
    private DelegateCommand<WfsSpecificationDefine> _moveSpecDownCommand;

    /********************
     * Button Enable
     ********************/
    /// <summary>
    /// 是否有選擇Grade。
    /// </summary>
    public bool GradeSelected
    {
        get { return _gradeSelected; }
        set { SetProperty(ref _gradeSelected, value); }
    }
    private bool _gradeSelected;

    /// <summary>
    /// 是否有選擇Specification。
    /// </summary>
    public bool SpecificationSelected
    {
        get { return _specificationSelected; }
        set { SetProperty(ref _specificationSelected, value); }
    }
    private bool _specificationSelected;
}
