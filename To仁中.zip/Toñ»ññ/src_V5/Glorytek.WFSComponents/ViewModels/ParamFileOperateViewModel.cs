﻿using Glorytek.CSharp.Helpers;
using Glorytek.CSharp.IO;
using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Stage.Contracts;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.WFS;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Models;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using MiniExcelLibs;
using MiniExcelLibs.OpenXml;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using Serilog;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 參數備份作業的ViewModel。
/// </summary>
public class ParamFileOperateViewModel : BindableBase
{
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;
    private readonly PlcDatas _plc = PlcDatas.Instance;

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly ISystem _sys;
    private readonly IMachine _machine;
    private readonly IProductManager _pm;
    private readonly IStage _stage;
    private readonly ITray _tray;
    private readonly IWfs _wfs;

    public ParamFileOperateViewModel(ISystemMessenger sysMessenger,
                                     IPrismMessageBox prismMessageBox,
                                     ISystem sys,
                                     IMachine machine,
                                     IProductManager pm,
                                     IStage stage,
                                     ITray tray,
                                     IWfs wfs)
    {
        _sysMessenger = sysMessenger;
        _prismMessageBox = prismMessageBox;
        _sys = sys;
        _machine = machine;
        _pm = pm;
        _stage = stage;
        _tray = tray;
        _wfs = wfs;

        if (!FileHelper.IsDirExist(DBbase.Directory_Export))
            FileHelper.CreateDirectoy(DBbase.Directory_Export);

        SetDefaultDirectory();
        SetDefaultFileName();
    }

    /// <summary>
    /// 視窗載入。
    /// </summary>
    public DelegateCommand LoadedCommand
        => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
    private void ExecuteLoadedCommand()
    {
        _sysMessenger.StatusBarMessage(string.Join(" - ", new[] {
                GetResource.GetValue<string>("PageTitle_SettingsPage"),
                GetResource.GetValue<string>("TabItem_SystemSetting_ParamFileOperate")
            }));

        UpdateFileList();
    }
    private DelegateCommand _loadedCommand;

    /********************
     * Command
     ********************/
    /// <summary>
    /// 滙出參數至EXCEL檔。
    /// </summary>
    public DelegateCommand ExportParamToFileCommand
        => _exportParamToFileCommand ??= new DelegateCommand(ExecuteExportParamToFileCommand);
    private void ExecuteExportParamToFileCommand()
    {
        // 模版檔
        string templateFileName = Path.Combine(DBbase.WorkPath, "ParamTemplate.xlsx");
        if (!FileHelper.IsFileExist(templateFileName))
        {
            _prismMessageBox.Show($"模版檔案不存在，匯出動作中斷！\n{templateFileName}",
                                  GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FileError"),
                                  MessageBoxImage.Error);
            return;
        }
        else if (FileHelper.IsFileLocked(templateFileName))
        {
            _prismMessageBox.Show($"模版檔案正被其他程式開啟，請將檔案關閉後再重新執行匯出。\n{templateFileName}",
                                  GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FileError"),
                                  MessageBoxImage.Error);
            return;
        }

        // 輸出檔
        if (!FileHelper.IsDirExist(DBbase.Directory_Export))
            FileHelper.CreateDirectoy(DBbase.Directory_Export);
        string exportFileName = Path.Combine(DBbase.Directory_Export, $"{ExportFileName}.xlsx");
        if (FileHelper.IsFileExist(exportFileName))
        {
            if (FileHelper.IsFileLocked(exportFileName))
            {
                _prismMessageBox.Show($"指定的參數匯出檔正被其他程式開啟，請將檔案關閉後再重新執行匯出。\n{exportFileName}",
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FileError"),
                                      MessageBoxImage.Error);
                return;
            }

            if (_prismMessageBox.Show($"是否要覆蓋參數匯出檔？\n{exportFileName}",
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "Message_FileOperation"),
                                      MessageBoxImage.Question,
                                      PrismMessageBoxButton.YesNo,
                                      ButtonResult.No) != ButtonResult.Yes)
                return;

            File.Delete(exportFileName);
        }

        /********************
         * 讀取匯出資料
         ********************/
        // 基本資訊
        var info = new[]
        {
            new
            {
                // 機台名稱
                Name_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_MachineName"),
                Name_Content = _sys.SystemSetting.MachineName,
                // 建檔日期
                Date_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_FileDate"),
                Date_Content = DateTime.Now,
                // 作業模式
                SysMode_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_SystemMode"),
                SysMode_Content = _sdi.SystemMode.GetDescription(),
                // 品種名稱
                ProductName_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_ProductName"),
                ProductName_Content = _pm.ActiveProductName,
            },
        };

        // 整機參數
        var machine = new[]
        {
            new
            {
                // 整體速度
                OverallSpeed_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_OverallSpeedRate"),
                OverallSpeed_Content = _machine.Machine.OverallSpeed,
                // X/Y軸到位後延時
                DelayAfterXYOnPosition_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_DelayAfterXYOnPosition"),
                DelayAfterXYOnPosition_Content = _plc.XYAxisInpDelay.ToString("F1"),
                // X/Y軸減速距離
                XYAxisSlowDown_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_XYAxisSlowDown"),
                XYAxisSlowDown_Content = _plc.XYAxisSlowDown,
                // X/Y軸減速速率
                XYAxisSlowDownSpeed_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_XYAxisSlowDownSpeed"),
                XYAxisSlowDownSpeed_Content = _plc.XYAxisSlowDownSpeed,
                // Z加減速距離
                ZAxisSpeedUpDown_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_ZAxisSpeedUpDown"),
                ZAxisSpeedUpDown_Content = _plc.ZAxisSpeedUpDown,
                // 條碼輸入檢查
                AllowBarcodeCheck_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_AllowBarcodeCheck"),
                AllowBarcodeCheck_Content = _sys.SystemSetting.AllowBarcodeCheck ? GetResource.GetValue<string>("Glorytek.WFSCore","Message_Enable") : GetResource.GetValue<string>("Glorytek.WFSCore", "Message_Ignore"),
                },
        };

        // 機台基準點
        var datum = new[]
        {
            new
            {
                // 相機座標
                CameraCoordinate_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_CameraCoordinate"),
                CameraCoordinateX_Content = _machine.Machine.DatumPointX.ToString("F3"),
                CameraCoordinateY_Content = _machine.Machine.DatumPointY.ToString("F3"),
                // 畫像品種
                VisionCategory_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_VisionCategory"),
                VisionCategory_Content = _machine.Machine.DatumPointVisionId,
                // 安全位置
                SafetyPosition_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_SafetyPosition"),
                SafetyPositionX_Content = _machine.Machine.SafetyX.ToString("F3"),
                SafetyPositionY_Content = _machine.Machine.SafetyY.ToString("F3"),
                // 安全高度
                SafetyHeight_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_SafetyHeight"),
                SafetyHeight_Content = _machine.Machine.SafetyHeight.ToString("F3"),
                // R軸0度補償
                RAxisZeroDegreeCorrection_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_RAxisZeroDegreeCorrection"),
                RAxisZeroDegreeCorrection_Content = _machine.Machine.RAxisZeroDegreeCorrection.ToString("F1"),
                },
        };

        // 黏土座
        var clay = new[]
        {
            new
            {
                // 吸嘴壓印座標
                NozzleStamp_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_NozzleStamp"),
                NozzleStampX_Content = _machine.Machine.NozzleStampX.ToString("F3"),
                NozzleStampY_Content = _machine.Machine.NozzleStampY.ToString("F3"),
                // 吸嘴壓印高度
                NozzleStampZ_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_Height_Z"),
                NozzleStampZ_Content = _machine.Machine.NozzleStampZ.ToString("F3"),
                // 相機座標
                CameraCoordinate_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_CameraCoordinate"),
                CameraCoordinateX_Content = _machine.Machine.ClayTableX.ToString("F3"),
                CameraCoordinateY_Content = _machine.Machine.ClayTableY.ToString("F3"),
                // 畫像品種
                VisionCategory_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_VisionCategory"),
                VisionCategory_Content = _machine.Machine.ClayTableVisionId,
            }
        };

        // 測高用位移計
        var displacement = new[]
        {
            new
            {
                // 相機座標
                CameraCoordinate_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_CameraCoordinate"),
                CameraCoordinateX_Content = _machine.Machine.DisplacementX.ToString("F3"),
                CameraCoordinateY_Content = _machine.Machine.DisplacementY.ToString("F3"),
                // 高度
                DisplacementZ_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_Height_Z"),
                DisplacementZ_Content = _machine.Machine.DisplacementZ.ToString("F3"),
                // 高度補正值
                HeightCorrectionValue_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_HeightCorrectionValue"),
                HeightCorrectionValue_Content = _machine.Machine.HeightCorrection.ToString("F3"),
                // 上次量測值
                LastMeasureHeight_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_LastMeasureHeight"),
                LastMeasureHeight_Content = _machine.Machine.LastMeasureHeight.ToString("F3"),
            }
        };

        // Stage
        var stage = new[]
        {
            new
            {
                // 相機座標
                CameraCoordinate_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_CameraCoordinate"),
                CameraCoordinate1X_Content = _stage.StageA1.CoorX.ToString("F3"),
                CameraCoordinate1Y_Content = _stage.StageA1.CoorY.ToString("F3"),
                CameraCoordinate2X_Content = _stage.StageA2.CoorX.ToString("F3"),
                CameraCoordinate2Y_Content = _stage.StageA2.CoorY.ToString("F3"),
                // 畫像品種
                VisionCategory_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_VisionCategory"),
                VisionCategory1_Content = _stage.StageA1.VisionId,
                VisionCategory2_Content = _stage.StageA2.VisionId,
                // 高度
                ZAxisCoor_Title = GetResource.GetValue<string>("Caption_ZAxisCoor"),
                ZAxisCoor1_Content = _stage.StageA1.CoorZ.ToString("F3"),
                ZAxisCoor2_Content = _stage.StageA2.CoorZ.ToString("F3"),
            }
        };

        // Pallet安裝點
        var palletInstall = new[]
        {
            new
            {
                // 畫像品種
                VisionCategory_Title = GetResource.GetValue<string>("Glorytek.WFSCore","Caption_VisionCategory"),
                VisionCategory_Content = _machine.Machine.PalletDpVisionId,
                // 座標
                Pallet01X_Content = _tray.PalletList[00].DatumX.ToString("F3"),
                Pallet01Y_Content = _tray.PalletList[00].DatumY.ToString("F3"),
                Pallet02X_Content = _tray.PalletList[01].DatumX.ToString("F3"),
                Pallet02Y_Content = _tray.PalletList[01].DatumY.ToString("F3"),
                Pallet03X_Content = _tray.PalletList[02].DatumX.ToString("F3"),
                Pallet03Y_Content = _tray.PalletList[02].DatumY.ToString("F3"),
                Pallet04X_Content = _tray.PalletList[03].DatumX.ToString("F3"),
                Pallet04Y_Content = _tray.PalletList[03].DatumY.ToString("F3"),
                Pallet05X_Content = _tray.PalletList[04].DatumX.ToString("F3"),
                Pallet05Y_Content = _tray.PalletList[04].DatumY.ToString("F3"),
                Pallet06X_Content = _tray.PalletList[05].DatumX.ToString("F3"),
                Pallet06Y_Content = _tray.PalletList[05].DatumY.ToString("F3"),
                Pallet07X_Content = _tray.PalletList[06].DatumX.ToString("F3"),
                Pallet07Y_Content = _tray.PalletList[06].DatumY.ToString("F3"),
                Pallet08X_Content = _tray.PalletList[07].DatumX.ToString("F3"),
                Pallet08Y_Content = _tray.PalletList[07].DatumY.ToString("F3"),
                Pallet09X_Content = _tray.PalletList[08].DatumX.ToString("F3"),
                Pallet09Y_Content = _tray.PalletList[08].DatumY.ToString("F3"),
                Pallet10X_Content = _tray.PalletList[09].DatumX.ToString("F3"),
                Pallet10Y_Content = _tray.PalletList[09].DatumY.ToString("F3"),
                Pallet11X_Content = _tray.PalletList[10].DatumX.ToString("F3"),
                Pallet11Y_Content = _tray.PalletList[10].DatumY.ToString("F3"),
                Pallet12X_Content = _tray.PalletList[11].DatumX.ToString("F3"),
                Pallet12Y_Content = _tray.PalletList[11].DatumY.ToString("F3"),
                Pallet13X_Content = _tray.PalletList[12].DatumX.ToString("F3"),
                Pallet13Y_Content = _tray.PalletList[12].DatumY.ToString("F3"),
                Pallet14X_Content = _tray.PalletList[13].DatumX.ToString("F3"),
                Pallet14Y_Content = _tray.PalletList[13].DatumY.ToString("F3"),
                Pallet15X_Content = _tray.PalletList[14].DatumX.ToString("F3"),
                Pallet15Y_Content = _tray.PalletList[14].DatumY.ToString("F3"),
                Pallet16X_Content = _tray.PalletList[15].DatumX.ToString("F3"),
                Pallet16Y_Content = _tray.PalletList[15].DatumY.ToString("F3"),
                Pallet17X_Content = _tray.PalletList[16].DatumX.ToString("F3"),
                Pallet17Y_Content = _tray.PalletList[16].DatumY.ToString("F3"),
                Pallet18X_Content = _tray.PalletList[17].DatumX.ToString("F3"),
                Pallet18Y_Content = _tray.PalletList[17].DatumY.ToString("F3"),
                Pallet19X_Content = _tray.PalletList[18].DatumX.ToString("F3"),
                Pallet19Y_Content = _tray.PalletList[18].DatumY.ToString("F3"),
                Pallet20X_Content = _tray.PalletList[19].DatumX.ToString("F3"),
                Pallet20Y_Content = _tray.PalletList[19].DatumY.ToString("F3"),
                Pallet21X_Content = _tray.PalletList[20].DatumX.ToString("F3"),
                Pallet21Y_Content = _tray.PalletList[20].DatumY.ToString("F3"),
                Pallet22X_Content = _tray.PalletList[21].DatumX.ToString("F3"),
                Pallet22Y_Content = _tray.PalletList[21].DatumY.ToString("F3"),
                Pallet23X_Content = _tray.PalletList[22].DatumX.ToString("F3"),
                Pallet23Y_Content = _tray.PalletList[22].DatumY.ToString("F3"),
                Pallet24X_Content = _tray.PalletList[23].DatumX.ToString("F3"),
                Pallet24Y_Content = _tray.PalletList[23].DatumY.ToString("F3"),
            }
        };

        // Tray
        var tray = new List<ExportTray>();
        foreach (var t in _tray.TrayList)
            tray.Add(new ExportTray
            {
                Name = t.Name,
                VisionId = t.VisionId,
                PositionId = t.PositionId,
                PickHeight = t.PickHeight,
                Arrangement = t.Arrangement.GetDescription(),
                Order_GridNumberX = t.Order_GridNumberX,
                Order_GridNumberY = t.Order_GridNumberY,
                Order_PositionA_X = t.Order_PositionA_X.ToString("F3"),
                Order_PositionA_Y = t.Order_PositionA_Y.ToString("F3"),
                Order_PositionB_X = t.Order_PositionB_X.ToString("F3"),
                Order_PositionB_Y = t.Order_PositionB_Y.ToString("F3"),
                Order_PositionC_X = t.Order_PositionC_X.ToString("F3"),
                Order_PositionC_Y = t.Order_PositionC_Y.ToString("F3"),
                Order_OffsetA = t.Order_OffsetA,
                Order_OffsetB = t.Order_OffsetB,
                Order_OffsetC = t.Order_OffsetC,
                Cross_GridNumberX = t.Cross_GridNumberX,
                Cross_GridNumberY = t.Cross_GridNumberY,
                Cross_PositionA_X = t.Cross_PositionA_X.ToString("F3"),
                Cross_PositionA_Y = t.Cross_PositionA_Y.ToString("F3"),
                Cross_PositionB_X = t.Cross_PositionB_X.ToString("F3"),
                Cross_PositionB_Y = t.Cross_PositionB_Y.ToString("F3"),
                Cross_PositionC_X = t.Cross_PositionC_X.ToString("F3"),
                Cross_PositionC_Y = t.Cross_PositionC_Y.ToString("F3"),
                Cross_OffsetA = t.Cross_OffsetA,
                Cross_OffsetB = t.Cross_OffsetB,
                Cross_OffsetC = t.Cross_OffsetC,
            });

        // 規格
        var spec = new List<ExportSpec>();
        foreach (var g in _wfs.GradeList.OrderBy(x => x.OrderNo))
        {
            foreach (var s in _wfs.SpecificationList.FindAll(x => x.GradeId == g.Id).OrderBy(x => x.OrderNo))
            {
                string dataName = _wfs.DataNameList.Find(x => x.Id == s.DataNameId).Name;
                string cond;
                if (s.UnaryOperator)
                    cond = $"{dataName} {s.Relation.GetDescription()} {s.Value}";
                else if (s.BetweenOperator)
                    cond = $"{s.Value1} {InequalityRelationType.LessThanOrEqualTo.GetDescription()} {dataName} {InequalityRelationType.LessThan.GetDescription()} {s.Value2}";
                else
                    cond = $"{dataName} {InequalityRelationType.LessThanOrEqualTo.GetDescription()} {s.Value1}, {s.Value2} {InequalityRelationType.LessThanOrEqualTo.GetDescription()} {dataName}";

                spec.Add(new ExportSpec
                {
                    GradeName = g.Name,
                    OrderNo = s.OrderNo,
                    Relation = s.Relation.GetDescription(),
                    Condition = cond,
                });
            }
        }

        var exportData = new
        {
            Info = info,
            Machine = machine,
            Datum = datum,
            Clay = clay,
            Displacement = displacement,
            Stage = stage,
            PalletInstall = palletInstall,
            Tray = tray,
            Spec = spec,
        };

        // 存檔
        MiniExcel.SaveAsByTemplate(exportFileName, templateFileName, exportData,
            configuration: new OpenXmlConfiguration()
            {
                AutoFilter = false,
            });

        _prismMessageBox.Show($"參數檔已匯出完成。\n{exportFileName}",
                              GetResource.GetValue<string>("Glorytek.WFSCore", "Message_OperationCompleted"),
                              MessageBoxImage.Information);
        UpdateFileList();
    }
    private DelegateCommand _exportParamToFileCommand;

    /// <summary>
    /// 選擇目錄位置。
    /// </summary>
    public DelegateCommand OpenFolderDialogCommand
        => _openFolderDialogCommand ??= new DelegateCommand(ExecuteOpenFolderDialogCommand);
    private void ExecuteOpenFolderDialogCommand()
    {
        var dialog = new System.Windows.Forms.FolderBrowserDialog
        {
            SelectedPath = DBbase.Directory_Export,
            Description = "請選擇匯出目錄位置：",
            UseDescriptionForTitle = true,
            ShowNewFolderButton = true,
        };

        if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        {
            DirectoryPath = dialog.SelectedPath;
        }
    }
    private DelegateCommand _openFolderDialogCommand;

    /// <summary>
    /// 將目錄位置設定為預設位置。
    /// </summary>
    /// <remarks>預設位置 = 我的文件夾\WFS\Export</remarks>
    public DelegateCommand SetDefaultDirectoryCommand
        => _setDefaultDirectoryCommand ??= new DelegateCommand(SetDefaultDirectory);
    private void SetDefaultDirectory()
    {
        DirectoryPath = DBbase.Directory_Export;
    }
    private DelegateCommand _setDefaultDirectoryCommand;

    /// <summary>
    /// 將匯出檔案名稱設定為預設檔名。
    /// </summary>
    /// <remarks>預設檔名 = 機台名稱_今天日期.xlsx</remarks>
    public DelegateCommand SetDefaultFileNameCommand
        => _setDefaultFileNameCommand ??= new DelegateCommand(SetDefaultFileName);
    private void SetDefaultFileName()
    {
        ExportFileName = $"{_sys.SystemSetting.MachineName}_{DateTime.Now:yyyyMMddHHmmss}";
    }
    private DelegateCommand _setDefaultFileNameCommand;

    /********************
     * 檔案列表
     ********************/
    /// <summary>
    /// 更新檔案列表。
    /// </summary>
    private void UpdateFileList()
    {
        try
        {
            ExportFileList = new();
            foreach (var path in Directory.EnumerateFiles(DirectoryPath, $"*{DBbase.Excel_ExtFileName}"))
                ExportFileList.Add(Path.GetFileNameWithoutExtension(path));
        }
        catch
        {
            // do nothing
        }
    }

    ///// <summary>
    ///// 
    ///// </summary>
    //public DelegateCommand SelectAllCommand
    //    => _selectAllCommand ??= new DelegateCommand(ExecuteSelectAllCommand);
    //private void ExecuteSelectAllCommand()
    //{
    //    ExportFileList.
    //}
    //private DelegateCommand _selectAllCommand;

    ///// <summary>
    ///// 
    ///// </summary>
    //public DelegateCommand UnselectAllCommand
    //    => _unselectAllCommand ??= new DelegateCommand(ExecuteUnselectAllCommand);
    //private void ExecuteUnselectAllCommand()
    //{

    //}
    //private DelegateCommand _unselectAllCommand;

    /// <summary>
    /// 將選取的參數檔複製到指定位置。
    /// </summary>
    public DelegateCommand<IList> CopyToCommand
        => _copyToCommand ??= new DelegateCommand<IList>(ExecuteCopyToCommand);
    private void ExecuteCopyToCommand(IList fileList)
    {
        if (fileList.Count > 0)
        {
            string sourcePath = default;
            string targetPath = default;

            var dialog = new System.Windows.Forms.FolderBrowserDialog
            {
                SelectedPath = DirectoryPath,
                Description = "請選擇目標目錄位置：",
                UseDescriptionForTitle = true,
                ShowNewFolderButton = false,
            };

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    foreach (var file in fileList)
                    {
                        string fileName = $"{file}{DBbase.Excel_ExtFileName}";
                        sourcePath = Path.Combine(DirectoryPath, fileName);
                        targetPath = Path.Combine(dialog.SelectedPath, fileName);

                        File.Copy(sourcePath, targetPath);
                    }
                    _ = _prismMessageBox.Show($"檔案複製完成。\n\n來源目錄: {DirectoryPath}\n目標目錄: {dialog.SelectedPath}",
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "Message_FileOperation"),
                                              MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    string errorMsg = $"檔案複製發生錯誤：{ex.Message}\n\n來源檔案: {sourcePath}\n目標檔案: {targetPath}";
                    Log.Error(ex, errorMsg);
                    _ = _prismMessageBox.Show(errorMsg,
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FileOperationException"),
                                              MessageBoxImage.Error);
                }
            }
        }
    }
    private DelegateCommand<IList> _copyToCommand;

    /// <summary>
    /// 刪除選取的參數檔。
    /// </summary>
    public DelegateCommand<IList> DeleteFileCommand
        => _deleteFileCommand ??= new DelegateCommand<IList>(ExecuteDeleteFileCommand);
    private void ExecuteDeleteFileCommand(IList fileList)
    {
        if (fileList.Count > 0)
        {
            // 刪除確認
            if (_prismMessageBox.Show($"確定刪除選擇的參數檔嗎？",
                                      "刪除檔案",
                                      MessageBoxImage.Question,
                                      PrismMessageBoxButton.YesNo) == ButtonResult.Yes)
            {
                string fullName = default;

                try
                {
                    foreach (var selectedFiles in fileList)
                    {
                        fullName = Path.Combine(DirectoryPath, $"{selectedFiles}{DBbase.Excel_ExtFileName}");
                        File.Delete(fullName);
                    }
                    _ = _prismMessageBox.Show($"檔案刪除完成。",
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "Message_FileOperation"),
                                              MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    string errorMsg = $"檔案刪除發生錯誤：{ex.Message}\n\n檔案：{fullName}";
                    Log.Error(ex, errorMsg);
                    _ = _prismMessageBox.Show(errorMsg,
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FileOperationException"),
                                              MessageBoxImage.Error);
                }

                UpdateFileList();
            }
        }
    }
    private DelegateCommand<IList> _deleteFileCommand;

    /********************
     * Data
     ********************/
    /// <summary>
    /// 目錄位置。
    /// </summary>
    public string DirectoryPath
    {
        get { return _directoryPath; }
        set
        {
            SetProperty(ref _directoryPath, value);
            UpdateFileList();
        }
    }
    private string _directoryPath;

    /// <summary>
    /// 匯出檔案名稱。
    /// </summary>
    public string ExportFileName
    {
        get { return _exportFileName; }
        set { SetProperty(ref _exportFileName, value); }
    }
    private string _exportFileName;

    /// <summary>
    /// 檔案列表。
    /// </summary>
    public ObservableCollection<string> ExportFileList
    {
        get { return _exportFileList; }
        set { SetProperty(ref _exportFileList, value); }
    }
    private ObservableCollection<string> _exportFileList;

    ///// <summary>
    ///// 選擇的操作檔案。
    ///// </summary>
    //public IList SelectedFiles
    //{
    //    get { return _selectedFiles; }
    //    set { SetProperty(ref _selectedFiles, value); }
    //}
    //private IList _selectedFiles;
}

public class ExportTray
{
    public string Name { get; set; }
    public int VisionId { get; set; }
    public int PositionId { get; set; }
    public double PickHeight { get; set; }
    public string Arrangement { get; set; }
    public short Order_GridNumberX { get; set; }
    public short Order_GridNumberY { get; set; }
    public string Order_PositionA_X { get; set; }
    public string Order_PositionA_Y { get; set; }
    public string Order_PositionB_X { get; set; }
    public string Order_PositionB_Y { get; set; }
    public string Order_PositionC_X { get; set; }
    public string Order_PositionC_Y { get; set; }
    public short Order_OffsetA { get; set; }
    public short Order_OffsetB { get; set; }
    public short Order_OffsetC { get; set; }
    public short Cross_GridNumberX { get; set; }
    public short Cross_GridNumberY { get; set; }
    public string Cross_PositionA_X { get; set; }
    public string Cross_PositionA_Y { get; set; }
    public string Cross_PositionB_X { get; set; }
    public string Cross_PositionB_Y { get; set; }
    public string Cross_PositionC_X { get; set; }
    public string Cross_PositionC_Y { get; set; }
    public short Cross_OffsetA { get; set; }
    public short Cross_OffsetB { get; set; }
    public short Cross_OffsetC { get; set; }
}

public class ExportSpec
{
    public string GradeName { get; set; }
    public int OrderNo { get; set; }
    public string Relation { get; set; }
    public string Condition { get; set; }
}
