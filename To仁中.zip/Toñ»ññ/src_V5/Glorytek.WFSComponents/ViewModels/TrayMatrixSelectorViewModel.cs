﻿using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WPF.Extensions;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Input;

namespace Glorytek.WFSComponents.ViewModels;

/// <summary>
/// 點位選擇器頁面的ViewModel。
/// </summary>
public class TrayMatrixSelectorViewModel : BindableBase, IDialogAware
{
    private readonly ZoomAndPanModel _zp = ZoomAndPanModel.Instance;
    private readonly TrayMatrixData _tmd = TrayMatrixData.Instance;
    private TrayMatrixSelectorInfo _tmsi;

    private int _thisTrayId;
    private TrayDefine _drawTray = null;
    private List<TrayProfileDefine> _thisProfile = null;
    private List<TrayMaskDefine> _thisMask = null;

    /********************
     * ctor
     ********************/
    private readonly IMachine _machine;
    private readonly ITray _tray;

    public TrayMatrixSelectorViewModel(IMachine machine, ITray tray)
    {
        _machine = machine;
        _tray = tray;
    }

    /********************
     * IDialogAware
     ********************/
    public string Title => GetResource.GetValue<string>("Title_TrayMatrixSelector");
    public bool ShowTitle => false;

    public event Action<IDialogResult> RequestClose;
    public bool CanCloseDialog() => true;
    public void OnDialogClosed() { }

    // Dialog Closed
    private DelegateCommand<string> _CloseDialogCommand;
    public DelegateCommand<string> CloseDialogCommand
        => _CloseDialogCommand ??= new DelegateCommand<string>(ExecuteCloseDialogCommand);
    private void ExecuteCloseDialogCommand(string parameter)
    {
        if (parameter?.ToUpper() == "TRUE")
        {
            var profile = _thisProfile.Find(x => x.PointNo == _tmd.CurrentPointNo);
            _tmsi.Result = ButtonResult.OK;
            _tmsi.PointNo = profile.PointNo;
            _tmsi.SequenceNo = profile.SequenceNo;
        }
        else
        {
            _tmsi.Result = ButtonResult.Cancel;
            _tmsi.PointNo = -1;
            _tmsi.SequenceNo = -1;
        }

        // 序列化
        var paras = new DialogParameters()
            {
                {
                    "StatusBarMessage",
                    JsonConvert.SerializeObject(_tmsi, new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore
                    })
                }
            };

        RaiseRequestClose(new DialogResult(_tmsi.Result, paras));
    }

    public virtual void RaiseRequestClose(IDialogResult dialogResult)
        => RequestClose?.Invoke(dialogResult);

    // Dialog Opened
    public void OnDialogOpened(IDialogParameters parameters)
    {
        try
        {
            _tmsi = JsonConvert.DeserializeObject<TrayMatrixSelectorInfo>(parameters.GetValue<string>("StatusBarMessage"));
            _thisTrayId = _tmsi.TrayId;
            _drawTray = _tray.TrayList.Find(x => x.Id == _thisTrayId).DeepCopyByExpressionTree();
            if (_drawTray == null)
                throw new Exception("開啟TrayMatrixSelector Dialog時，參數傳遞錯誤！");

            int posId = _drawTray.PositionId;
            var pp = _tray.PalletList.Find(x => x.Id == posId);

            _drawTray.DatumX = (pp.DatumX + _machine.Machine.DatumPointX).WfsFormat();
            _drawTray.DatumY = (pp.DatumY + _machine.Machine.DatumPointY).WfsFormat();
            _drawTray.Order_PositionA_X = (_drawTray.Order_PositionA_X + _drawTray.DatumX).WfsFormat();
            _drawTray.Order_PositionA_Y = (_drawTray.Order_PositionA_Y + _drawTray.DatumY).WfsFormat();
            _drawTray.Order_PositionB_X = (_drawTray.Order_PositionB_X + _drawTray.DatumX).WfsFormat();
            _drawTray.Order_PositionB_Y = (_drawTray.Order_PositionB_Y + _drawTray.DatumY).WfsFormat();
            _drawTray.Order_PositionC_X = (_drawTray.Order_PositionC_X + _drawTray.DatumX).WfsFormat();
            _drawTray.Order_PositionC_Y = (_drawTray.Order_PositionC_Y + _drawTray.DatumY).WfsFormat();
            _drawTray.Cross_PositionA_X = (_drawTray.Cross_PositionA_X + _drawTray.DatumX).WfsFormat();
            _drawTray.Cross_PositionA_Y = (_drawTray.Cross_PositionA_Y + _drawTray.DatumY).WfsFormat();
            _drawTray.Cross_PositionB_X = (_drawTray.Cross_PositionB_X + _drawTray.DatumX).WfsFormat();
            _drawTray.Cross_PositionB_Y = (_drawTray.Cross_PositionB_Y + _drawTray.DatumY).WfsFormat();
            _drawTray.Cross_PositionC_X = (_drawTray.Cross_PositionC_X + _drawTray.DatumX).WfsFormat();
            _drawTray.Cross_PositionC_Y = (_drawTray.Cross_PositionC_Y + _drawTray.DatumY).WfsFormat();

            _thisMask = _tray.MaskList.FindAll(x => x.TrayId == _thisTrayId);
            _thisProfile = _tray.CalculateProfile(_drawTray, _thisMask);

            if (_tmsi.PointNo > 0)
            {
                _tmd.CurrentPointNo = _tmsi.PointNo;
            }
            else if (_tmsi.SequenceNo > 0)
            {
                var profile = _thisProfile.Find(x => x.SequenceNo == _tmsi.SequenceNo);
                if (profile == null)
                    throw new Exception("取得Profile錯誤！");
                _tmd.CurrentPointNo = profile.PointNo;
            }
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, ex.Message);
        }

        _zp.Blocks = _tray.RedrawBlocks(_drawTray, _thisProfile, _thisMask);
    }

    /********************
     * Mouse
     ********************/
    /// <summary>
    /// 滑鼠左鍵點擊方塊命令。
    /// </summary>
    public DelegateCommand<object> LeftButtonClickOnBlockCommand
        => _leftButtonClickOnBlockCommand ??= new DelegateCommand<object>(ExecuteLeftButtonClickOnBlockCommand);
    private void ExecuteLeftButtonClickOnBlockCommand(object clickedBlock)
    {
        if (_zp.Blocks != null && clickedBlock != null && clickedBlock is MouseButtonEventArgs args)
        {
            int blockId = -1;

            if (args.OriginalSource is Border borderBlock)
                blockId = (int)borderBlock.Tag;
            else if (args.OriginalSource is TextBlock textBlock)
                blockId = (int)textBlock.Tag;

            if (blockId != -1)
            {
                BlockDefine block = _zp.Blocks.First(x => x.Id == blockId);

                if (!block.Mask)
                {
                    _tmd.CurrentPointNo = block.Id;
                    _zp.Blocks = _tray.RedrawBlocks(_drawTray, _thisProfile, _thisMask);
                }
            }
        }
    }
    private DelegateCommand<object> _leftButtonClickOnBlockCommand;
}
