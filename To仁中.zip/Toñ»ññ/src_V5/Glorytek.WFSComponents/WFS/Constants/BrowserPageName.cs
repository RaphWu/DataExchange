﻿namespace Glorytek.WFSComponents.WFS.Constants;

/// <summary>
/// 大數據各分頁名稱。
/// </summary>
public static class BrowserPageName
{
    internal const string SourcePage = "SOURCE";
    internal const string TraySettingPage = "TRAY";
    internal const string SpecSettingPage = "SPECIFICATION";
    internal const string ProductPage = "PRODUCT";
    internal const string ReworkPage = "REWORK";
}
