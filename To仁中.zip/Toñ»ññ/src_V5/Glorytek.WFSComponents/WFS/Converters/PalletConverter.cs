﻿//using Glorytek.WFSComponents.Tray.Models;
//using Glorytek.WFSComponents.WFS.Models;
//using System;
//using System.Globalization;
//using System.Windows.Data;

//namespace Glorytek.WFSComponents.WFS.Converters;

///// <summary>   
///// 
///// </summary>
//[ValueConversion(typeof(int), typeof(PalletDefine))]
//internal class PalletConverter : IValueConverter
//{
//    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
//    {
//        if (value == null)
//            return null;

//        int posId = (int)value;
//        return WfsParameters.Instance.LensSortingList.Find(x => x.Id == posId);
//    }

//    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
//    {
//        throw new NotSupportedException();
//    }
//}
