﻿using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Constants.WFS;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - 規格判定。
 ********************/
public partial class WfsService : IWfs_Judgement
{
    /// <inheritdoc/>
    public WfsGradeDefine GradeJudgement(MeasuringMachineDefine data)
    {
        // 量測失敗的鏡片數據，除了LensNumber外全部為0
        if (data.Decenter > 0.0 && data.Angle > 0.0)
        {
            var grades = _wp.JudgementLists;

            // 規格比對
            for (int gradeIdx = 0; gradeIdx < grades.Count; gradeIdx++)
            {
                int grade = grades[gradeIdx];
                var specs = _wp.SpecificationList.FindAll(x => x.GradeId == grade)
                                                                .OrderBy(x => x.OrderNo)
                                                                .ToList();

                // 必須合部條件均符合
                bool match = true;

                foreach (WfsSpecificationDefine spec in specs)
                {
                    double lenValue = default;
                    switch (Enum.Parse(typeof(OpticalParamId), spec.DataNameId.ToString()))
                    {
                        case OpticalParamId.Decenter:
                            lenValue = data.Decenter;
                            break;

                        case OpticalParamId.DecenterX:
                            lenValue = data.DecenterX;
                            break;

                        case OpticalParamId.DecenterY:
                            lenValue = data.DecenterY;
                            break;

                        case OpticalParamId.Coma:
                            lenValue = data.Coma;
                            break;

                        case OpticalParamId.Astigmatism:
                            lenValue = data.Astigmatism;
                            break;

                        case OpticalParamId.Spherical:
                            lenValue = data.Spherical;
                            break;

                        case OpticalParamId.Trefoil:
                            lenValue = data.Trefoil;
                            break;

                        case OpticalParamId.Angle:
                            lenValue = data.Angle;
                            break;
                    }

                    // 量測值為0的鏡片
                    if (lenValue == 0)
                    {
                        match = false;
                        break;
                    }

                    switch (spec.Relation)
                    {
                        // value == Spec
                        case InequalityRelationType.Equalto:
                            if (lenValue != spec.Value)
                                match = false;
                            break;

                        // value != Spec
                        case InequalityRelationType.NotEqualTo:
                            if (lenValue == spec.Value)
                                match = false;
                            break;

                        // value > Spec
                        case InequalityRelationType.GreaterThan:
                            if (lenValue <= spec.Value)
                                match = false;
                            break;

                        // value >= Spec
                        case InequalityRelationType.GreaterThanOrEqualTo:
                            if (lenValue < spec.Value)
                                match = false;
                            break;

                        // value < Spec
                        case InequalityRelationType.LessThan:
                            if (lenValue >= spec.Value)
                                match = false;
                            break;

                        // value <= Spec
                        case InequalityRelationType.LessThanOrEqualTo:
                            if (lenValue > spec.Value)
                                match = false;
                            break;

                        // Spec1 <= value < Spec2
                        case InequalityRelationType.Between:
                            if (lenValue < spec.Value1 || lenValue >= spec.Value2)
                                match = false;
                            break;

                        // value <= Spec1 && value >= Spec2
                        case InequalityRelationType.NotBetween:
                            if (lenValue > spec.Value1 && lenValue < spec.Value2)
                                match = false;
                            break;
                    }

                    // 任一條件不符，換下一規格
                    if (!match)
                        break;
                }

                // 比對符合規格，結束比對
                if (match)
                    return _wp.GradeList.Find(x => x.Id == grade);
            }
        }

        return new WfsGradeDefine() { Id = -1 };
    }

    /// <summary>
    /// 取得符合規格、最小未滿/空盤的Tray。傳入-1表示放重工Tray。
    /// </summary>
    /// <param name="gradeId">規格ID<br/>-1=不符合規格，重工。</param>
    /// <returns>Tray資訊。</returns>
    private LensSortingDefine MatchPalletPosition(int gradeId)
    {
        int posId = -1;
        List<LensSortingDefine> palletList;

        // 搜尋符合規格的盤位 
        if (gradeId >= 1)
        {
            palletList = LensSortingList.FindAll(x => x.FunctionName == TrayFunctionType.Classified
                                                      && x.GradeId == gradeId)
                                        .OrderBy(x => x.Id)
                                        .ToList();

            // 返回沒有滿/空盤的盤號
            foreach (var pallet in palletList)
            {
                if (!_pd.TrayFullOrEmpty[pallet.Id - 1])
                    return pallet;
            }

            // TODO: 沒有空的盤
        }

        // 重工Tray
        palletList = LensSortingList.FindAll(x => x.FunctionName == TrayFunctionType.Rework)
                                    .OrderBy(x => x.Id)
                                    .ToList();

        foreach (var pallet in palletList)
        {
            // 搜尋有空位的重工Tray
            if (!_pd.TrayFullOrEmpty[pallet.Id - 1])
            {
                posId = pallet.Id;
                return pallet;
            }

            // TODO: 沒有空的盤.
        }

        return null;
    }
}
