﻿using Dapper.Contrib.Extensions;
using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.WFS.Models;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Events;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using Prism.Services.Dialogs;
using Serilog;
using System;
using System.Collections.Generic;
using System.Windows;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - 分檢模式。
 ********************/
public partial class WfsService
{
    ///// <inheritdoc/>
    //private string LoadData_LensSorting(string lotNumber)
    //{
    //    if (!_pm.IsProductActive)
    //        return string.Empty;

    //    if (lotNumber != string.Empty)
    //        lotNumber = GetLastLotNumber();
    //    SetBigDataBrowser(sortDirection: SortDirection.Descending,
    //                      lotNumberFilter: lotNumber,
    //                      pageSize: 10);
    //    return lotNumber;
    //}

    /// <summary>
    /// 條件設定檢查
    /// </summary>
    /// <returns>檢查通過=true。</returns>
    private bool ConditionCheck_LensSorting(List<LensSortingDefine> palletData)
    {
        return ConditionCheck_Online(palletData);
    }

    /// <summary>
    /// 參數寫入PLC
    /// </summary>
    /// <returns>寫入成功=true。</returns>
    private bool WriteToPlc_LensSorting(List<LensSortingDefine> palletData) => WriteToPlc_Online(palletData);

    /// <summary>
    /// 開始此批號的資料收集
    /// </summary>
    private bool StartDataCollection_LensSorting() => StartDataCollection_Online();

    /// <summary>
    /// 悙止此批號的資料收集
    /// </summary>
    private void StopDataCollection_LensSorting() => StopDataCollection_Online();

    /********************
     * PLC交握
     ********************/
    /// <summary>
    /// PLC交握 - 分檢模式 - 放料
    /// </summary>
    private void PlcHandshake_LensSorting_Place()
    {
        string errMsg = default;
        WfsGradeDefine grade = default;
        LensSortingDefine placePallet = null;
        MeasuringMachineDefine data = default;

        int palletId = _pd.PickTrayId;
        int pointNo = _pd.PickPointNo[palletId - 1];
        //int sequenceNo = _tray.ConvertPointNoToSequenceNo(_tray.GetTrayId(palletId), pointNo);
        int lensNumber = _pd.CurrentSequence + _wp.DiffLensNumber;
        int sequenceNo = _pd.CurrentSequence + _wp.DiffExcelLensNumber;
        string resultMessage = $"盤號: {palletId}, 點位: {pointNo}";

        if (pointNo >= 1 && lensNumber <= _wp.ExcelDatas.Count)
        {
            // 規格判定
            //data = _wp.ExcelDatas[sequenceNo - 1];
            data = _wp.ExcelDatas.Find(x => x.LensNumber == sequenceNo).DeepCopyByExpressionTree();
            if (data != null)
            {
                grade = GradeJudgement(data);

                if (grade.Id != -1)
                {
                    placePallet = MatchPalletPosition(grade.Id);
                    resultMessage += $"\n規格判定: {grade.Name}\n放置盤號: {placePallet.Id}";
                }
                else
                {
                    placePallet = MatchPalletPosition(-1);
                    resultMessage += $"\n規格判定: NG\n放置盤號: {placePallet.Id}";
                }
            }
            else
            {
                errMsg = $"鏡片編號 {lensNumber} 相對EXCEL編號 {sequenceNo} 找不到！";
                Log.Error(errMsg);
            }
        }
        else
        {
            errMsg = $"目前取料盤號: {palletId}, 點位: {pointNo}, 序號: {lensNumber}\nEXCEL資料筆數: {_wp.ExcelDatas.Count}\n數量不符合，請確認後再繼續作業！";
            Log.Error(errMsg);
        }

        // NG
        if (placePallet == null)
        {
            placePallet = MatchPalletPosition(-1);
            grade = new WfsGradeDefine() { Id = -1 };
            data = new MeasuringMachineDefine() { LensNumber = lensNumber };

            if (_prismMessageBox.ShowOKCancel($"{errMsg}\n請確認物料與機台狀況！\n\n此鏡片將放至重工，請選擇後續作業：",
                                              "資料異常",
                                              MessageBoxImage.Error,
                                              "繼續",
                                              "結束作業") == ButtonResult.Cancel)
            {
                _plc.WriteBool(DeviceLists.INTERRUPT_OPERATION, true);
            }
        }

        // 空盤
        if (_pd.TrayFullOrEmpty[palletId - 1])
        {
            _plc.WriteBool(DeviceLists.INTERRUPT_OPERATION, true);
        }

        _ea.GetEvent<PlcHandshakeFeedback>().Publish(placePallet.Id);
        _sysMessenger.OperateMessage(resultMessage);

        // 取得放料點位
        short targetPointNo = GetPalletPointNo(DeviceLists.WHEN_PLACEING_LENS_SORTING, placePallet.Id);

        // 判定結果與數據儲存
        var newData = new MeasurementDataDefine()
        {
            Time = DateTime.Now,
            LotNumber = _lotNumber,
            LensNumber = lensNumber,
            Judgement = grade.Id != -1,
            Grade = grade.Id,
            GradeName = grade.Id != -1 ? grade.Name : "",
            SourcePalletNo = palletId,
            SourcePointNo = pointNo,
            SourceTrayId = LensSortingList[palletId - 1].TrayId,
            SourceTrayName = LensSortingList[palletId - 1].TrayName,
            TargetPalletNo = placePallet.Id,
            TargetPointNo = targetPointNo,
            TargetTrayId = LensSortingList[placePallet.Id - 1].TrayId,
            TargetTrayName = LensSortingList[placePallet.Id - 1].TrayName,
            Angle = data.Angle,
            DecenterX = data.DecenterX,
            DecenterY = data.DecenterY,
            Decenter = data.Decenter,
            Coma = data.Coma,
            Astigmatism = data.Astigmatism,
            Spherical = data.Spherical,
            Trefoil = data.Trefoil,
        };

        _ = _wd.ConnMeasurementData.InsertAsync(newData);
        _wd.MeasurementDataList.Insert(0, newData);
        Application.Current.Dispatcher.Invoke(new Action(() => { UpdateBrowser(newData); }));
    }
}
