﻿using Dapper.Contrib.Extensions;
using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.Events;
using Glorytek.WFSComponents.WFS.Models;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Models.System;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Events;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism.Services.Dialogs;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - 連線模式。
 ********************/
public partial class WfsService
{
    /// <summary>
    /// 條件設定檢查
    /// </summary>
    /// <returns>檢查通過=true。</returns>
    private bool ConditionCheck_Online(List<LensSortingDefine> palletData)
    {
        if (!_pm.IsProductActive)
            return false;

        try
        {
            bool paramsNotOk = false;
            bool barcodeNotOk = false;
            StringBuilder errMsgParams = new();
            StringBuilder errMsgBarcode = new();
            bool firstError;

            /********************
             * 基本設定檢查
             ********************/
            var palletListsOrderById = palletData.OrderBy(x => x.Id).ToList();
            List<LensSortingDefine> palletList = palletListsOrderById.FindAll(x => x.FunctionName != TrayFunctionType.Unused);

            // Tray
            firstError = true;
            foreach (var pallet in palletList)
            {
                if (!_tray.TrayList.Any(x => x.Id == pallet.TrayId))
                {
                    paramsNotOk = true;
                    pallet.TrayMode = PlcTrayFunctionType.Unused;

                    if (firstError)
                    {
                        firstError = false;
                        if (errMsgParams.Length > 0)
                            errMsgParams.Append('\n');
                        errMsgParams.Append($"{GetResource.GetValue<string>("ErrorMessage_TraySettingError")}: ");
                    }
                    else
                    {
                        errMsgParams.Append(", ");
                    }
                    errMsgParams.Append($"[{pallet.Id}]");
                }
            }

            // Barcode
            firstError = true;
            foreach (var pallet in palletList)
            {
                if (SysParameters.Instance.SystemSetting.AllowBarcodeCheck && string.IsNullOrWhiteSpace(pallet.Barcode))
                {
                    barcodeNotOk = true;
                    pallet.TrayMode = PlcTrayFunctionType.Unused;

                    if (firstError)
                    {
                        firstError = false;
                        errMsgBarcode = new StringBuilder($"{GetResource.GetValue<string>("ErrorMessage_BarcodeNotEntered")}: ");
                    }
                    else
                    {
                        errMsgBarcode.Append(", ");
                    }
                    errMsgBarcode.Append($"[{pallet.Id}]");
                }
            }

            /********************
             * 入料
             ********************/
            firstError = true;
            palletList = palletListsOrderById.FindAll(x => x.FunctionName == TrayFunctionType.Feeder);
            if (palletList.Count == 0)
            {
                paramsNotOk = true;
                if (errMsgParams.Length > 0)
                    errMsgParams.Append('\n');
                errMsgParams.Append($"{GetResource.GetValue<string>("ErrorMessage_FeederTrayNotSet")}");
            }
            else if (palletList.Count > 1)
            {
                paramsNotOk = true;
                if (errMsgParams.Length > 0)
                    errMsgParams.Append('\n');
                errMsgParams.Append($"{GetResource.GetValue<string>("ErrorMessage_UpTo1FeederTrayCanBeSet")}");
            }
            //else if (palletList.Count)
            //{

            //}
            else
            {
                foreach (var pallet in palletList)
                    pallet.TrayMode = PlcTrayFunctionType.Feeder;
            }

            /********************
             * 收料
             ********************/
            palletList = palletListsOrderById.FindAll(x => x.FunctionName == TrayFunctionType.Classified);
            if (palletList.Count == 0)
            {
                paramsNotOk = true;
                if (errMsgParams.Length > 0)
                    errMsgParams.Append('\n');
                errMsgParams.Append($"{GetResource.GetValue<string>("ErrorMessage_ClassifiedTrayNotSet")}");
            }
            else
            {
                // 規格
                firstError = true;
                foreach (var pallet in palletList)
                {
                    if (pallet.GradeId == -1 || _wp.GradeList.FindIndex(x => x.Id == pallet.GradeId) == -1)
                    {
                        paramsNotOk = true;
                        pallet.TrayMode = PlcTrayFunctionType.Unused;

                        if (firstError)
                        {
                            firstError = false;
                            if (errMsgParams.Length > 0)
                                errMsgParams.Append('\n');
                            errMsgParams.Append($"{GetResource.GetValue<string>("ErrorMessage_GradeSettingError")}: ");
                        }
                        else
                        {
                            errMsgParams.Append($", ");
                        }
                        errMsgParams.Append($"[{pallet.Id}]");
                    }
                    else
                    {
                        pallet.TrayMode = PlcTrayFunctionType.Classified;
                    }
                }

                // Vision ID
                firstError = true;
                int visionId = -1;
                foreach (var pallet in palletList)
                {
                    var tray = _tray.TrayList.Find(x => x.Id == pallet.TrayId);
                    if (tray != null)
                    {
                        if (visionId == -1)
                        {
                            visionId = tray.VisionId;
                        }
                        else
                        {
                            if (visionId != tray.VisionId)
                            {
                                paramsNotOk = true;
                                if (errMsgParams.Length > 0)
                                    errMsgParams.Append('\n');
                                errMsgParams.Append($"{GetResource.GetValue<string>("ErrorMessage_ClassifiedTrayVisionIdNotMatch")}");
                                break;
                            }
                        }
                    }
                }
            }

            /********************
             * 重工
             ********************/
            firstError = true;
            palletList = palletListsOrderById.FindAll(x => x.FunctionName == TrayFunctionType.Rework);
            // 沒設定重工Tray
            if (palletList.Count == 0)
            {
                paramsNotOk = true;
                if (errMsgParams.Length > 0)
                    errMsgParams.Append('\n');
                errMsgParams.Append($"{GetResource.GetValue<string>("ErrorMessage_ReworkTrayNotSet")}");
            }
            // 重工Tray超過1盤
            else if (palletList.Count > 1)
            {
                paramsNotOk = true;
                if (errMsgParams.Length > 0)
                    errMsgParams.Append('\n');
                errMsgParams.Append($"{GetResource.GetValue<string>("ErrorMessage_UpTo1ReworkTrayCanBeSet")}");
            }
            else
            {
                foreach (var pallet in palletList)
                    pallet.TrayMode = PlcTrayFunctionType.Rework;
            }

            /********************
             * 整合錯誤訊息並發出
             ********************/
            if (paramsNotOk)
            {
                if (barcodeNotOk)
                    errMsgParams.Append($"\n{errMsgBarcode}");

                throw new Exception(errMsgParams.ToString());
            }
            else if (barcodeNotOk)
            {
                throw new Exception(errMsgBarcode.ToString());
            }

            return true;
        }
        //catch (ArgumentException ae)
        //{
        //    Log.Fatal(ae, ae.Message);
        //    _ = _prismMessageBox.Show(ae.Message,
        //                              GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_System_InternalError"),
        //                              MessageBoxImage.Error);
        //}
        catch (Exception ex)
        {
            Log.Error(ex, ex.Message);
            _ = _prismMessageBox.Show(ex.Message,
                                      GetResource.GetValue<string>("ErrorMessage_ParametersError"),
                                      MessageBoxImage.Error);
            return false;
        }
    }

    /// <summary>
    /// 參數寫入PLC
    /// </summary>
    /// <returns>寫入成功=true。</returns>
    private bool WriteToPlc_Online(List<LensSortingDefine> palletData)
    {
        if (!_plc.Online || !_pm.IsProductActive)
            return false;

        try
        {
            int visionId = -1;
            foreach (var pallet in palletData)
            {
                int palletIdx = pallet.Id - 1;
                int trayId = -1;

                // 找出第一個入料盤並記錄視覺ID
                if (pallet.FunctionName != TrayFunctionType.Unused)
                {
                    trayId = pallet.TrayId;
                    if (pallet.FunctionName == TrayFunctionType.Feeder && visionId == -1)
                    {
                        var tray = _tray.TrayList.Find(x => x.Id == trayId);
                        if (tray != null)
                            visionId = tray.VisionId;
                    }
                }

                // 寫入PLC
                if (trayId >= 0)
                {
                    // 註記Pallet模式
                    _wp.PalletMode[palletIdx] = pallet.TrayMode;

                    PalletDefine pd = _tray.PalletList.Find(x => x.Id == pallet.Id);
                    TrayDefine td = _tray.TrayList.Find(x => x.Id == trayId).DeepCopyByExpressionTree();

                    if (pd != null && td != null)
                    {
                        td.DatumX = (pd.DatumX + _machine.Machine.DatumPointX).WfsFormat();
                        td.DatumY = (pd.DatumY + _machine.Machine.DatumPointY).WfsFormat();
                        td.Order_PositionA_X += td.DatumX;
                        td.Order_PositionA_Y += td.DatumY;
                        td.Order_PositionB_X += td.DatumX;
                        td.Order_PositionB_Y += td.DatumY;
                        td.Order_PositionC_X += td.DatumX;
                        td.Order_PositionC_Y += td.DatumY;
                        td.Cross_PositionA_X += td.DatumX;
                        td.Cross_PositionA_Y += td.DatumY;
                        td.Cross_PositionB_X += td.DatumX;
                        td.Cross_PositionB_Y += td.DatumY;
                        td.Cross_PositionC_X += td.DatumX;
                        td.Cross_PositionC_Y += td.DatumY;

                        _tray.WriteTrayToPlc(pallet.Id, td);
                    }
                }
                else
                {
                    _wp.PalletMode[palletIdx] = PlcTrayFunctionType.Unused;
                }
            }

            // 寫入Tray模式
            _ = _plc.WriteInt16(DeviceLists.TRAY_MODE, new short[]
            {
                (short)_wp.PalletMode[00], (short)_wp.PalletMode[01], (short)_wp.PalletMode[02],
                (short)_wp.PalletMode[03], (short)_wp.PalletMode[04], (short)_wp.PalletMode[05],
                (short)_wp.PalletMode[06], (short)_wp.PalletMode[07], (short)_wp.PalletMode[08],
                (short)_wp.PalletMode[09], (short)_wp.PalletMode[10], (short)_wp.PalletMode[11],
                (short)_wp.PalletMode[12], (short)_wp.PalletMode[13], (short)_wp.PalletMode[14],
                (short)_wp.PalletMode[15], (short)_wp.PalletMode[16], (short)_wp.PalletMode[17],
                (short)_wp.PalletMode[18], (short)_wp.PalletMode[19], (short)_wp.PalletMode[20],
                (short)_wp.PalletMode[21], (short)_wp.PalletMode[22], (short)_wp.PalletMode[23]
            });

            // 寫入視覺品種
            if (visionId >= 0)
                _ = _plc.WriteInt16(DeviceLists.CAMERA1_PRODUCT_TYPE, (short)visionId);

            return true;
        }
        catch (Exception ex)
        {
            string errTitle = $"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_System_InternalError")}";
            Log.Fatal(ex, errTitle);
            _prismMessageBox.Show($"{ex.Message}，{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}",
                                  errTitle,
                                  MessageBoxImage.Error);
            return false;
        }
    }

    /// <summary>
    /// 開始此批號的資料收集
    /// </summary>
    private bool StartDataCollection_Online()
    {
        //if (_collectingData)
        //    throw new Exception("Flag Error!");

        if (SetNewLot())
        {
            string lotNumber = _wp.CurrentLotNumber;
            //_wp.CurrentLotNumber = lotNumber;
            SetBigDataBrowser(sortDirection: SortDirection.Descending,
                              lotNumberFilter: lotNumber,
                              pageSize: 10);

            //_collectingData = true;
            return true;
        }
        else
        {
            return false;
        }
    }

    /// <summary>
    /// 悙止此批號的資料收集
    /// </summary>
    private void StopDataCollection_Online()
    {
        if (_wp.LastLotNumber != null)
        {
            // 顯示原批號
            _ea.GetEvent<LotNumberChangedEvent>().Publish(_wp.LastLotNumber);
            //_collectingData = false;
        }
    }

    /********************
     * PLC交握
     ********************/
    /// <summary>
    /// PLC交握 - 連線模式 - 取料
    /// </summary>
    private void PlcHandshake_Online_Pick()
    {
        // 讀取盤號 & 點位 & 無效點修正
        int palletId = _pd.PickTrayId;
        int pointNo = _pd.PickPointNo[palletId - 1];

        _wd.LensQueue.Enqueue(new LensQueueDefine()
        {
            PalletId = palletId,
            PointNo = pointNo,
            LenNumber = _tray.ConvertPointNoToSequenceNo(_tray.GetTrayId(palletId), pointNo),
        });

        _ea.GetEvent<PlcHandshakeFeedback>().Publish(0);
    }

    /// <summary>
    /// PLC交握 - 連線模式 - 放料
    /// </summary>
    private void PlcHandshake_Online_Place()
    {
        try
        {
            // 接收資料
            bool dataReceived = false;
            ReceiveDataDefine data = default;
            WfsGradeDefine grade = default;

            // Tray
            LensSortingDefine placePallet = default;

            // 異常檢查
            if (_wd.LensQueue.Count == 0)
                throw new Exception(GetResource.GetValue<string>("ErrorMessage_System_QueueException"));

            // 取回點位資訊
            var lenQueue = _wd.LensQueue.Dequeue();
            string msgResult = $"{GetResource.GetValue<string>("Glorytek.WFSCore", "PalletNo")}: {lenQueue.PalletId}, {GetResource.GetValue<string>("Glorytek.WFSCore", "ActionPointNo")}: {lenQueue.PointNo}";

            while (!dataReceived)
            {
                dataReceived = Task.Run(async () =>
                {
                    while (!_measuring.DataValid)
                    {
                        await Task.Delay(1);
                    }
                }).Wait(5000);

                if (!dataReceived)
                {
                    var result = _prismMessageBox.ShowYesNoCancel(GetResource.GetValue<string>("ErrorMessage_Measuring_MeasurementDataTimedOut"),
                                                                  GetResource.GetValue<string>("ErrorMessage_Measuring_DataException_Title"),
                                                                  MessageBoxImage.Error,
                                                                  GetResource.GetValue<string>("Glorytek.WFSCore", "Button_Retry"),
                                                                  GetResource.GetValue<string>("Glorytek.WFSCore", "Button_Discard"),
                                                                  GetResource.GetValue<string>("Glorytek.WFSCore", "Button_Interrupt"));
                    if (result == ButtonResult.No)
                    {
                        break;
                    }
                    else if (result == ButtonResult.Cancel)
                    {
                        if (_prismMessageBox.Show(GetResource.GetValue<string>("Glorytek.WFSCore", "Message_TheOperationWillStop"),
                                                  GetResource.GetValue<string>("Glorytek.WFSCore", "Message_OperationConfirmation_Title"),
                                                  MessageBoxImage.Question,
                                                  PrismMessageBoxButton.YesNo) == ButtonResult.Yes)
                            _plc.SendCommandPulse(DeviceLists.STOP_COMMAND);
                        break;
                    }
                }
            }

            if (dataReceived)
            {
                if (_wd.DoNotCheckSpecification)
                {
                    data = null;
                    // 不執行規格判定，鏡片放回原Tray原位
                    placePallet = new LensSortingDefine() { Id = lenQueue.PalletId };
                    msgResult += $"\n不執行規格判定。\n返回盤號: {placePallet.Id}";
                }
                else
                {
                    data = _measuring.ReceivedData;
                    grade = _measuring.DataValid
                        ? GradeJudgement(data)
                        : new WfsGradeDefine() { Id = -1 };
                    placePallet = MatchPalletPosition(grade.Id);

                    if (grade.Id == -1)
                        msgResult += $"\n規格判定: NG\n放置盤號: {placePallet.Id}";
                    else
                        msgResult += $"\n規格判定: {grade.Name}\n放置盤號: {placePallet.Id}";
                }
                _ea.GetEvent<PlcHandshakeFeedback>().Publish(placePallet != null ? placePallet.Id : -1);
            }
            else
            {
                msgResult += "資料無效！";
            }

            _sysMessenger.OperateMessage(msgResult);
            short targetPointNo = GetPalletPointNo(DeviceLists.WHEN_PLACEING_ONLINE, placePallet.Id);

            // 判定結果與數據儲存
            var newData = new MeasurementDataDefine()
            {
                LotNumber = _lotNumber,
                Time = DateTime.Now,
                Judgement = grade.Id != -1,
                Grade = grade.Id,
                GradeName = grade.Id != -1 ? grade.Name : "",
                LensNumber = data != null ? data.LensNumber : 0,
                SourcePalletNo = lenQueue.PalletId,
                SourcePointNo = lenQueue.PointNo,
                SourceTrayId = LensSortingList[lenQueue.PalletId - 1].TrayId,
                SourceTrayName = LensSortingList[lenQueue.PalletId - 1].TrayName,
                TargetPalletNo = placePallet.Id,
                TargetPointNo = targetPointNo,
                TargetTrayId = LensSortingList[placePallet.Id - 1].TrayId,
                TargetTrayName = LensSortingList[placePallet.Id - 1].TrayName,
                Angle = data != null ? data.Angle : 0.0,
                DecenterX = data != null ? data.DecenterX : 0.0,
                DecenterY = data != null ? data.DecenterY : 0.0,
                Decenter = data != null ? data.Decenter : 0.0,
                Coma = data != null ? data.Coma : 0.0,
                Astigmatism = data != null ? data.Astigmatism : 0.0,
                Spherical = data != null ? data.Spherical : 0.0,
                Trefoil = data != null ? data.Trefoil : 0.0,
            };

            _ = _wd.ConnMeasurementData.InsertAsync(newData);
            _wd.MeasurementDataList.Insert(0, newData);
            Application.Current.Dispatcher.Invoke(new Action(() => { UpdateBrowser(newData); }));
        }
        catch (Exception ex)
        {
            string errTitle = $"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_System_InternalError")}";
            Log.Fatal(ex, errTitle);
            _prismMessageBox.Show($"{ex.Message}，{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}",
                                  errTitle,
                                  MessageBoxImage.Error);
        }
    }
}
