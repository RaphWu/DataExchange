﻿using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Models.Tray;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - Tray作業。
 ********************/
public partial class WfsService : IWfs_Tray
{
    /// <inheritdoc/>
    public bool GetTray(int palletId, out TrayDefine tray)
    {
        tray = GetTray(palletId);
        return tray != null;
    }

    /// <inheritdoc/>
    public TrayDefine GetTray(int palletId)
    {
        int palletIndex = palletId - 1;
        var palletInfo = _tray.PalletList[palletIndex];
        var palletData = LensSortingList.Find(x => x.Id == palletId);

        TrayDefine tray = _tray.GetTray(palletId);
        if (_sdi.SystemMode_Online_FixStage || _sdi.SystemMode_Online_DoubleCylinder
            || _sdi.SystemMode_Online_SingleCylinder || _sdi.SystemMode_Online_Disc
            || _sdi.SystemMode_LensSorting)
        {
            tray = _tray.TrayList.Find(x => x.Id == palletData.TrayId);
        }
        else if (_sdi.SystemMode_LensArrange)
        {
            var pal = LensArrangeList.Find(x => x.Id == palletId);
            if (pal != null)
                if (pal.Pick)
                {
                    tray = _tray.TrayList.Find(x => x.Id == pal.PickTrayId);
                }
                else if (pal.Place)
                {
                    tray = _tray.TrayList.Find(x => x.Id == pal.PlaceTrayId);
                }
        }
        return tray;
    }

    /// <inheritdoc/>
    public (int CurrentPointNo, int CurrentSequenceNo) GetCurrentNo(int palletId)
    {
        if (GetTray(palletId, out TrayDefine tray))
        {
            int currentPointNo = _pd.NextPointNo[palletId - 1];
            if (currentPointNo != -1)
            {
                int currentSequenceNo = _tray.ConvertPointNoToSequenceNo(tray.Id, currentPointNo);
                return (currentPointNo, currentSequenceNo);
            }
        }
        return (0, 0);
    }
}
