﻿using Dapper;
using Dapper.Contrib.Extensions;
using Glorytek.SQLite;
using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSComponents.WFS.Models;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Constants.WFS;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Events;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism.Events;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows;

namespace Glorytek.WFSComponents.WFS.Services;

/// <summary>
/// WFS Service。
/// </summary>
public partial class WfsService : IWfs
{
    private static bool _eventNotSubscribed = true;
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;
    private readonly TrayParameters _tp = TrayParameters.Instance;
    private readonly WfsParameters _wp = WfsParameters.Instance;
    private readonly WfsDatas _wd = WfsDatas.Instance;
    private readonly PlcDatas _pd = PlcDatas.Instance;
    private readonly BigDataContent _bd = BigDataContent.Instance;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly ISystemMessenger _sysMessenger;
    private readonly IProductManager _pm;
    private readonly IMachine _machine;
    private readonly ITray _tray;
    private readonly IPlc _plc;
    private readonly IMeasuring _measuring;

    public WfsService(IEventAggregator ea,
                      IPrismMessageBox prismMessageBox,
                      ISystemMessenger sysMessenger,
                      IProductManager pm,
                      IMachine machine,
                      ITray tray,
                      IPlc plc,
                      IMeasuring measuring)
    {
        _ea = ea;
        _prismMessageBox = prismMessageBox;
        _sysMessenger = sysMessenger;
        _pm = pm;
        _machine = machine;
        _tray = tray;
        _plc = plc;
        _measuring = measuring;

        ReadMeasurementDataFileList();
    }

    /********************
     * Get Instance
     ********************/
    /// <inheritdoc/>
    public List<WfsDataNameListDefine> DataNameList
    {
        get { return _wp.DataNameList; }
        set { _wp.DataNameList = value; }
    }

    /// <inheritdoc/>
    public List<WfsGradeDefine> GradeList
    {
        get { return _wp.GradeList; }
        set { _wp.GradeList = value; }
    }

    /// <inheritdoc/>
    public List<WfsSpecificationDefine> SpecificationList
    {
        get { return _wp.SpecificationList; }
        set { _wp.SpecificationList = value; }
    }

    /// <inheritdoc/>
    public List<LensSortingDefine> LensSortingList
    {
        get { return _wp.LensSortingList; }
        set { _wp.LensSortingList = value; }
    }

    /// <inheritdoc/>
    public List<LensArrangeDefine> LensArrangeList
    {
        get { return _wp.LensArrangeList; }
        set { _wp.LensArrangeList = value; }
    }

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public bool WriteToDb()
    {
        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            _ = conn.UpdateAsync(_wp.DataNameList, transaction: tran);
            _ = conn.UpdateAsync(_wp.GradeList, transaction: tran);
            _ = conn.UpdateAsync(_wp.SpecificationList, transaction: tran);
            _ = conn.UpdateAsync(_wp.LensSortingList, transaction: tran);
            _ = conn.UpdateAsync(_wp.LensArrangeList, transaction: tran);
            tran.Commit();
            UpdateTrayList();
            return true;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            string errorMsg = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FailedToWriteDatabase");
            Log.Fatal(ex, errorMsg);
            _ = _prismMessageBox.Show(errorMsg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
            return false;
        }
    }

    /// <inheritdoc/>
    public bool WriteDataNameListToDb()
    {
        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            _ = conn.UpdateAsync(_wp.DataNameList, transaction: tran);
            tran.Commit();
            return true;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            string errorMsg = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FailedToWriteDatabase");
            Log.Fatal(ex, errorMsg);
            _ = _prismMessageBox.Show(errorMsg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
            return false;
        }
    }

    /// <inheritdoc/>
    public bool WriteSpecificationToDb()
    {
        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            _ = conn.UpdateAsync(_wp.SpecificationList, transaction: tran);
            tran.Commit();
            return true;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            string errorMsg = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FailedToWriteDatabase");
            Log.Fatal(ex, errorMsg);
            _ = _prismMessageBox.Show(errorMsg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
            return false;
        }
    }

    /// <inheritdoc/>
    public bool ReadFromDb()
    {
        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            // Data Name List
            if (!SQLiteHelper.IsTableExist(conn, DB_WFS.TableName_DataNameList))
            {
                SQLiteHelper.CreateTable(conn, DB_WFS.CreateTableSQL_DataNameList);
                string sql = $@"INSERT INTO {DB_WFS.TableName_DataNameList} (Id, OrderNo, Name) VALUES (@Id, @OrderNo, @Name);";
                //foreach (var item in OpticalParamId)
                _ = conn.Execute(sql, new { Id = OpticalParamId.LensNumber, OrderNo = OpticalParamId.LensNumber, Name = OpticalParamId.LensNumber.ToString() }, transaction: tran);
                _ = conn.Execute(sql, new { Id = OpticalParamId.Decenter, OrderNo = OpticalParamId.Decenter, Name = OpticalParamId.Decenter.ToString() }, transaction: tran);
                _ = conn.Execute(sql, new { Id = OpticalParamId.DecenterX, OrderNo = OpticalParamId.DecenterX, Name = OpticalParamId.DecenterX.ToString() }, transaction: tran);
                _ = conn.Execute(sql, new { Id = OpticalParamId.DecenterY, OrderNo = OpticalParamId.DecenterY, Name = OpticalParamId.DecenterY.ToString() }, transaction: tran);
                _ = conn.Execute(sql, new { Id = OpticalParamId.Coma, OrderNo = OpticalParamId.Coma, Name = OpticalParamId.Coma.ToString() }, transaction: tran);
                _ = conn.Execute(sql, new { Id = OpticalParamId.Astigmatism, OrderNo = OpticalParamId.Astigmatism, Name = OpticalParamId.Astigmatism.ToString() }, transaction: tran);
                _ = conn.Execute(sql, new { Id = OpticalParamId.Spherical, OrderNo = OpticalParamId.Spherical, Name = OpticalParamId.Spherical.ToString() }, transaction: tran);
                _ = conn.Execute(sql, new { Id = OpticalParamId.Trefoil, OrderNo = OpticalParamId.Trefoil, Name = OpticalParamId.Trefoil.ToString() }, transaction: tran);
                _ = conn.Execute(sql, new { Id = OpticalParamId.Angle, OrderNo = OpticalParamId.Angle, Name = OpticalParamId.Angle.ToString() }, transaction: tran);
            }
            _wp.DataNameList = conn.GetAll<WfsDataNameListDefine>(transaction: tran).ToList();
            _wp.DataNameList.Sort();

            // Grade List
            if (!SQLiteHelper.IsTableExist(conn, DB_WFS.TableName_Grade))
                SQLiteHelper.CreateTable(conn, DB_WFS.CreateTableSQL_Grade);
            _wp.GradeList = conn.GetAll<WfsGradeDefine>(transaction: tran).ToList();

            // Specification
            if (!SQLiteHelper.IsTableExist(conn, DB_WFS.TableName_Specification))
                SQLiteHelper.CreateTable(conn, DB_WFS.CreateTableSQL_Specification);
            _wp.SpecificationList = conn.GetAll<WfsSpecificationDefine>(transaction: tran).ToList();

            // PalletSorting
            if (!SQLiteHelper.IsTableExist(conn, DB_WFS.TableName_LensSorting))
            {
                SQLiteHelper.CreateTable(conn, DB_WFS.CreateTableSQL_LensSorting);
                for (int palletId = 1; palletId <= ITray.MaxPalletId; palletId++)
                {
                    string sql = $@"INSERT INTO {DB_WFS.TableName_LensSorting} (Id) VALUES (@Id);";
                    _ = conn.Execute(sql, new { Id = palletId }, transaction: tran);
                }
            }
            _wp.LensSortingList = conn.GetAll<LensSortingDefine>(transaction: tran).ToList();

            var judgementList = new List<int>();
            foreach (var item in _wp.LensSortingList)
                if (item.FunctionName == TrayFunctionType.Classified && item.GradeId >= 0)
                    judgementList.Add(item.GradeId);
            _wp.JudgementLists = judgementList;

            // PalletArrange
            if (!SQLiteHelper.IsTableExist(conn, DB_WFS.TableName_LensArrange))
            {
                SQLiteHelper.CreateTable(conn, DB_WFS.CreateTableSQL_LensArrange);
                for (int id = 1; id <= ITray.MaxPalletId; id++)
                {
                    string sql = $@"INSERT INTO {DB_WFS.TableName_LensArrange} (Id) VALUES (@Id);";
                    _ = conn.Execute(sql, new { Id = id }, transaction: tran);
                }
            }
            _wp.LensArrangeList = conn.GetAll<LensArrangeDefine>(transaction: tran).OrderBy(x => x.Id).ToList();
            tran.Commit();

            UpdateTrayList();
            RebuildTraySelector();
            UpdateRelationList();
            return true;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            string errorMsg = "資料庫讀取失敗";
            Log.Fatal(ex, errorMsg);
            _ = _prismMessageBox.Show(errorMsg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
            return false;
        }
    }

    ///// <inheritdoc/>
    //public void LoadData()
    //{
    //    //try
    //    //{
    //    switch (_sdi.SystemMode)
    //    {
    //        case SystemOperateModeType.Online_FixStage:
    //        case SystemOperateModeType.Online_DoubleCylinder:
    //        case SystemOperateModeType.Online_SingleCylinder:
    //        case SystemOperateModeType.Online_Disc:
    //            LoadData_Online(_wfsParas.LastLotNumber);
    //            break;

    //        case SystemOperateModeType.LensSorting:
    //            LoadData_LensSorting(_wfsParas.LastLotNumber);
    //            break;

    //        case SystemOperateModeType.LensArrange:
    //            LoadData_LensArrange();
    //            break;

    //        case SystemOperateModeType.Tray_A1:
    //            break;

    //        default:
    //            break;  // do nothing
    //            //throw new Exception($"SystemMode Error: {_sdi.SystemMode}");
    //    }
    //    //}
    //    //catch (Exception ex)
    //    //{
    //    //    string errTitle = $"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_System_InternalError")}";
    //    //    Log.Fatal(ex, errTitle);
    //    //    _prismMessageBox.Show($"{ex.Message}，{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}",
    //    //                          errTitle,
    //    //                          MessageBoxImage.Error);
    //    //}
    //}

    /********************
     * 作業條件檢查 & 參數寫入PLC
     ********************/
    /// <inheritdoc/>
    public bool ConditionCheckAndWriteToPlc(bool writeToPlc)
    {
        return _sdi.SystemMode switch
        {
            SystemOperateModeType.Online_FixStage
                or SystemOperateModeType.Online_DoubleCylinder
                or SystemOperateModeType.Online_SingleCylinder
                or SystemOperateModeType.Online_Disc
                => ConditionCheckAndWriteToPlc(writeToPlc, _wp.LensSortingList),
            SystemOperateModeType.LensSorting => ConditionCheckAndWriteToPlc(writeToPlc, _wp.LensSortingList),
            SystemOperateModeType.LensArrange => ConditionCheckAndWriteToPlc(writeToPlc, _wp.LensArrangeList),
            _ => false,
        };
    }

    /// <inheritdoc/>
    public bool ConditionCheckAndWriteToPlc(bool writeToPlc, List<LensSortingDefine> lensSortingData)
    {
        bool chcekResult;
        switch (_sdi.SystemMode)
        {
            case SystemOperateModeType.Online_FixStage:
            case SystemOperateModeType.Online_DoubleCylinder:
            case SystemOperateModeType.Online_SingleCylinder:
            case SystemOperateModeType.Online_Disc:
                chcekResult = ConditionCheck_Online(lensSortingData);
                if (chcekResult && writeToPlc)
                    return WriteToPlc_Online(lensSortingData);
                return chcekResult;

            case SystemOperateModeType.LensSorting:
                chcekResult = ConditionCheck_LensSorting(lensSortingData);
                if (chcekResult && writeToPlc)
                    return WriteToPlc_LensSorting(lensSortingData);
                return chcekResult;

                // do nothing
                //case SystemOperateModeType.LensArrange:
                //case SystemOperateModeType.Tray_A1: 
        }
        return false;
    }

    /// <inheritdoc/>
    public bool ConditionCheckAndWriteToPlc(bool writeToPlc, List<LensArrangeDefine> lensArrangeData)
    {
        bool chcekResult;
        switch (_sdi.SystemMode)
        {
            case SystemOperateModeType.LensArrange:
                chcekResult = ConditionCheck_LensArrange(lensArrangeData);
                if (chcekResult && writeToPlc)
                    return WriteToPlc_LensArrange(lensArrangeData);
                return chcekResult;

                // do nothing
                //case SystemOperateModeType.Online_FixStage:
                //case SystemOperateModeType.Online_DoubleCylinder:
                //case SystemOperateModeType.Online_SingleCylinder:
                //case SystemOperateModeType.Online_Disc:
                //case SystemOperateModeType.LensSorting:
                //case SystemOperateModeType.Tray_A1: 
        }
        return false;
    }

    /// <summary>
    /// 參數寫入PLC
    /// </summary>
    /// <returns>寫入成功=true。</returns>
    private bool WriteToPlc()
    {
        return _sdi.SystemMode switch
        {
            SystemOperateModeType.Online_FixStage
                or SystemOperateModeType.Online_DoubleCylinder
                or SystemOperateModeType.Online_SingleCylinder
                or SystemOperateModeType.Online_Disc
                => WriteToPlc_Online(_wp.LensSortingList),
            SystemOperateModeType.LensSorting => WriteToPlc_LensSorting(_wp.LensSortingList),
            SystemOperateModeType.LensArrange => WriteToPlc_LensArrange(_wp.LensArrangeList),
            _ => false,
        };
    }

    /// <inheritdoc/>
    public bool ConditionCheckAndWriteToPlc(bool writeToPlc, int trayId)
    {
        return _sdi.SystemMode switch
        {
            SystemOperateModeType.Tray_A1 => writeToPlc && WriteToPlc_TrayToA1(trayId),
            _ => false,
        };
    }

    /// <summary>
    /// 非連線模式時，不執行規格判定強制設定為false。
    /// </summary>
    private void WhenSystemModeChanged(int _)
    {
        if (!(_sdi.SystemMode_Online_FixStage
            || _sdi.SystemMode_Online_DoubleCylinder
            || _sdi.SystemMode_Online_SingleCylinder
            || _sdi.SystemMode_Online_Disc))
            _wd.DoNotCheckSpecification = false;
    }

    /********************
     * 自動作業
     ********************/
    /// <inheritdoc/>
    public bool StartDataCollection()
    {
        _wd.LensQueue.Clear();

        switch (_sdi.SystemMode)
        {
            case SystemOperateModeType.Online_FixStage:
            case SystemOperateModeType.Online_DoubleCylinder:
            case SystemOperateModeType.Online_SingleCylinder:
            case SystemOperateModeType.Online_Disc:
                return StartDataCollection_Online();

            case SystemOperateModeType.LensSorting:
                return StartDataCollection_LensSorting();

            case SystemOperateModeType.LensArrange:
                return StartDataCollection_LensArrange();

            // do nothing
            //case SystemOperateModeType.Tray_A1: 

            default:
                return false;
        }
    }

    /// <inheritdoc/>
    public void StopDataCollection()
    {
        switch (_sdi.SystemMode)
        {
            case SystemOperateModeType.Online_FixStage:
            case SystemOperateModeType.Online_DoubleCylinder:
            case SystemOperateModeType.Online_SingleCylinder:
            case SystemOperateModeType.Online_Disc:
                StopDataCollection_Online();
                break;

            case SystemOperateModeType.LensSorting:
                StopDataCollection_LensSorting();
                break;

            case SystemOperateModeType.LensArrange:
                StopDataCollection_LensArrange();
                break;

                // do nothing
                //case SystemOperateModeType.Tray_A1: 
        }
    }

    /********************
     * 
     ********************/
    /// <summary>
    /// 更新Tray列表。
    /// </summary>
    private void UpdateTrayList()
    {
        _wp.FeederTrayList = new Dictionary<int, string>();
        _wp.ClassifiedTrayList = new Dictionary<int, string>();
        _wp.ReworkTrayList = new Dictionary<int, string>();
        _wp.UnusedTrayList = new Dictionary<int, string>();

        foreach (var tray in _wp.LensSortingList)
        {
            switch (tray.FunctionName)
            {
                case TrayFunctionType.Feeder:
                    _wp.FeederTrayList.Add(tray.Id, tray.TrayName);
                    break;
                case TrayFunctionType.Classified:
                    _wp.ClassifiedTrayList.Add(tray.Id, tray.TrayName);
                    break;
                case TrayFunctionType.Rework:
                    _wp.ReworkTrayList.Add(tray.Id, tray.TrayName);
                    break;
                default:
                    _wp.UnusedTrayList.Add(tray.Id, tray.TrayName);
                    break;
            }
        }
    }

    /********************
     * System Command
     ********************/
    /// <summary>
    /// 模組初始化。
    /// </summary>
    internal void ModuleInit()
    {
        if (_eventNotSubscribed)
        {
            _eventNotSubscribed = false;
            _ = _ea.GetEvent<OnProductChangeover1>().Subscribe(ProductChangeover1, true);
            _ = _ea.GetEvent<OnProductChangeover2>().Subscribe(ProductChangeover2, true);
            _ = _ea.GetEvent<PlcHandshakeEvent>().Subscribe(PlcHandshake, keepSubscriberReferenceAlive: true);
            _ = _ea.GetEvent<SystemModeChangedEvent>().Subscribe(WhenSystemModeChanged, keepSubscriberReferenceAlive: true);
            _ = _ea.GetEvent<PalletInfoChangedEvent>().Subscribe(UpdatePalletInfo, true); // 點位有變動時，更新TrayList及TrayData
        }

        WfsDatas.Instance.Online = false;
    }

    /// <summary>
    /// 第一階段品種切換。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    private void ProductChangeover1(string productName)
    {
        if (productName != string.Empty)
        {
            ReadFromDb();
            //UpdatePalletInfo(0);
        }
        _pm.Datas.ProductChangedRunning_Wfs = false;
    }

    /// <summary>
    /// 第二階段品種切換。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    private void ProductChangeover2(string productName)
    {
        if (productName != string.Empty)
            WriteToPlc();
        _pm.Datas.ProductChangedRunning_Wfs = false;
    }

    /********************
     * Grade
     ********************/
    /// <inheritdoc/>
    public int CreateNewGrade(CrudInfo crudInfo)
    {
        if (!_pm.IsProductActive)
            return -1;

        if (_wp.GradeList.Any(x => x.Name == crudInfo.NewName))
        {
            _prismMessageBox.Show($"名稱 \"{crudInfo.NewName}\" 已存在！", MessageBoxImage.Error);
            return -1;
        }

        var conn = _pm.DbConnection;
        var newGrade = new WfsGradeDefine
        {
            Id = SQLiteHelper.GetMaxValue(conn, DB_WFS.TableName_Grade, "Id") + 1,
            OrderNo = SQLiteHelper.GetMaxValue(conn, DB_WFS.TableName_Grade, "OrderNo") + 1,
            Name = crudInfo.NewName,
        };
        using (var tran = conn.BeginTransaction())
        {
            try
            {
                _wp.GradeList.Add(newGrade);
                conn.InsertAsync(newGrade, transaction: tran);
                tran.Commit();
            }
            catch
            {
                tran.Rollback();
            }
        }

        return newGrade.OrderNo;
    }

    /// <inheritdoc/>
    public bool RenameGradeName(CrudInfo crudInfo)
    {
        if (!_pm.IsProductActive)
            return false;

        var grade = _wp.GradeList.Find(x => x.Id == crudInfo.Id);
        if (grade == null)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            grade.Name = crudInfo.NewName;
            conn.Update<WfsGradeDefine>(grade, transaction: tran);
            tran.Commit();
            return true;
        }
        catch
        {
            tran.Rollback();
            return false;
        }
    }

    /// <inheritdoc/>
    public bool DeleteGrade(int gradeId)
    {
        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            // 刪除規格內的條件
            conn.Delete(_wp.SpecificationList.FindAll(x => x.GradeId == gradeId), transaction: tran);
            _wp.SpecificationList.RemoveAll(x => x.GradeId == gradeId);

            // 刪除規格
            conn.Delete(new WfsGradeDefine() { Id = gradeId }, transaction: tran);
            _wp.GradeList.RemoveAll(x => x.Id == gradeId);
            ResortGradeOrderNo();
            conn.Update<List<WfsGradeDefine>>(_wp.GradeList, transaction: tran);

            // 將Pallet內有關GradeId的設定，全部改成無設定狀態
            LensSortingList.FindAll(x => x.GradeId == gradeId).ForEach(x =>
            {
                x.GradeId = -1;
            });
            conn.Update<List<LensSortingDefine>>(LensSortingList, transaction: tran);

            tran.Commit();
            return true;
        }
        catch
        {
            tran.Rollback();
            return false;
        }
    }

    /********************
     * SpecificationSelector
     ********************/
    /// <inheritdoc/>
    public Dictionary<int, string> GradeSelector(bool includeUnused = false)
    {
        return includeUnused
             ? _wp.GradeSelectorIncludeUnused
             : _wp.GradeSelector;
    }

    /// <summary>
    /// 重建Tray選擇清單
    /// </summary>
    internal Dictionary<int, string> RebuildTraySelector()
    {
        Dictionary<int, string> wSelector = new Dictionary<int, string>();
        Dictionary<int, string> wSelectorIncludeUnused = new Dictionary<int, string>();

        if (_pm.IsProductActive)
        {
            wSelectorIncludeUnused.Add(0, GetResource.GetValue<string>("Glorytek.WFSCore", "Message_Unused"));
            foreach (WfsGradeDefine item in _wp.GradeList)
            {
                wSelector.Add(item.Id, item.Name);
                wSelectorIncludeUnused.Add(item.Id, item.Name);
            }
        }

        _wp.GradeSelector = wSelector;
        _wp.GradeSelectorIncludeUnused = wSelectorIncludeUnused;

        return wSelector;
    }

    /// <inheritdoc/>
    public int CreateNewSpecification(int gradeId)
    {
        if (!_pm.IsProductActive)
            return -1;

        var tmpSpecs = _wp.SpecificationList.FindAll(x => x.GradeId == gradeId);
        int newOrderNo = tmpSpecs.Count > 0 ? tmpSpecs.Max(x => x.OrderNo) + 1 : 1;

        var conn = _pm.DbConnection;
        using (var tran = conn.BeginTransaction())
        {
            try
            {
                var spec = new WfsSpecificationDefine
                {
                    GradeId = gradeId,
                    OrderNo = newOrderNo,
                };

                _wp.SpecificationList.Add(spec);
                conn.InsertAsync(spec, transaction: tran);
                tran.Commit();
            }
            catch
            {
                tran.Rollback();
            }
        }

        return newOrderNo;
    }

    /// <inheritdoc/>
    public bool DeleteSpecification(int specId)
    {
        if (!_pm.IsProductActive)
            return false;

        var grade = _wp.SpecificationList.Find(x => x.Id == specId);
        int gradeId = grade.GradeId;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            _wp.SpecificationList.Remove(grade);
            ResortSpecificationOrderNo(gradeId);
            conn.Delete(grade, transaction: tran);
            tran.Commit();
            return true;
        }
        catch
        {
            tran.Rollback();
            return false;
        }
    }

    /********************
     * 排序
     ********************/
    /// <summary>
    /// 重新排序Grade的OrderNo。
    /// </summary>
    private void ResortGradeOrderNo()
    {
        if (!_pm.IsProductActive)
            return;

        _wp.GradeList.Sort((x, y) => x.OrderNo.CompareTo(y.OrderNo));
        for (int idx = 0; idx < _wp.GradeList.Count; idx++)
            _wp.GradeList[idx].OrderNo = idx + 1;
    }

    /// <summary>
    /// 重新排序規格算式。
    /// </summary>
    /// <param name="gradeId">排序的規格ID。</param>
    private void ResortSpecificationOrderNo(int gradeId)
    {
        if (!_pm.IsProductActive)
            return;

        var spec = _wp.SpecificationList.FindAll(x => x.GradeId == gradeId).OrderBy(x => x.OrderNo).ToList();
        for (int idx = 0; idx < spec.Count; idx++)
            spec[idx].OrderNo = idx + 1;
    }

    /********************
     * 量測機
     ********************/
    /// <summary>
    /// 不執行規格判定。(暫不使用)
    /// </summary>
    public bool DoNotCheckSpecification => WfsDatas.Instance.DoNotCheckSpecification;
}
