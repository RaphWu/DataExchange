﻿using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal;
using Glorytek.WPF.Extensions;
using Serilog;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - 轉角度模式。
 ********************/
public partial class WfsService
{
    ///// <inheritdoc/>
    //private List<PickAndPlaceListDefine> LoadData_LensArrange()
    //{
    //    if (!_pm.IsProductActive)
    //        return null;

    //    var picks = PalletArrangeList.FindAll(x => x.Pick).OrderBy(x => x.Id).ToList();
    //    var places = PalletArrangeList.FindAll(x => x.Place).OrderBy(x => x.Id).ToList();
    //    int count = Math.Max(picks.Count, places.Count);

    //    var papl = new List<PickAndPlaceListDefine>();
    //    for (int idx = 0; idx < count; idx++)
    //    {
    //        papl.Add(new PickAndPlaceListDefine()
    //        {
    //            PickPalletInfo = idx < picks.Count ? $"[ {picks[idx].Id,2} ] {picks[idx].PickTrayName}" : string.Empty,
    //            PlacePalletInfo = idx < places.Count ? $"[ {places[idx].Id,2} ] {places[idx].PlaceTrayName}" : string.Empty,
    //        });
    //    }
    //    return papl;
    //}

    /// <summary>
    /// 條件設定檢查
    /// </summary>
    /// <returns>檢查通過=true。</returns>
    private bool ConditionCheck_LensArrange(List<LensArrangeDefine> lensArrangeData)
    {
        if (!_pm.IsProductActive)
            return false;

        try
        {
            bool paramsNotOk = false;
            var errMsgParams = new StringBuilder();

            int pickTrayId = -1;
            int placeTrayId = -1;
            PlcTrayFunctionType[] pickTrayMode = new PlcTrayFunctionType[ITray.MaxPalletId];
            PlcTrayFunctionType[] placeTrayMode = new PlcTrayFunctionType[ITray.MaxPalletId];

            int pickCounter = 0;
            int placeCounter = 0;

            // 判斷
            foreach (var pallet in lensArrangeData)
            {
                int palletIndex = pallet.Id - 1;

                // Pick
                bool isPick = false;
                bool isPickTrayOk = false;
                if (pallet.Pick && pallet.PickTrayId >= 0)
                {
                    isPick = true;
                    pickCounter++;

                    if (pickTrayId == -1)
                    {
                        if (_tray.TrayList.Any(x => x.Id == pallet.PickTrayId))
                        {
                            isPickTrayOk = true;
                            pickTrayId = pallet.PickTrayId;
                        }
                    }
                    else
                    {
                        isPickTrayOk = true;
                    }
                }
                pickTrayMode[palletIndex] = isPick && isPickTrayOk ? PlcTrayFunctionType.Feeder : PlcTrayFunctionType.Unused;

                // Place
                bool isPlace = false;
                bool isPlaceTrayOk = false;
                if (pallet.Place && pallet.PlaceTrayId >= 0)
                {
                    isPlace = true;
                    placeCounter++;

                    if (placeTrayId == -1)
                    {
                        if (_tray.TrayList.Any(x => x.Id == pallet.PlaceTrayId))
                        {
                            isPlaceTrayOk = true;
                            placeTrayId = pallet.PlaceTrayId;
                        }
                    }
                    else
                    {
                        isPlaceTrayOk = true;
                    }
                }
                placeTrayMode[palletIndex] = isPlace && isPlaceTrayOk ? PlcTrayFunctionType.AngleArrange : PlcTrayFunctionType.Unused;
            }

            // 訊息
            if (pickTrayId == -1 || pickCounter == 0)
            {
                paramsNotOk = true;
                errMsgParams.Append(GetResource.GetValue<string>("ErrorMessage_PickTrayNotSet"));
            }
            if (placeTrayId == -1 || placeCounter == 0)
            {
                paramsNotOk = true;
                if (errMsgParams.Length > 0)
                    errMsgParams.Append('\n');
                errMsgParams.Append(GetResource.GetValue<string>("ErrorMessage_PlaceTrayNotSet"));
            }
            if (pickCounter > 0 && placeCounter > 0 && pickCounter != placeCounter)
            {
                paramsNotOk = true;
                if (errMsgParams.Length > 0)
                    errMsgParams.Append('\n');
                errMsgParams.Append(GetResource.GetValue<string>("ErrorMessage_PickAndPlaceMustBeTheSame"));
            }

            // 發出
            if (paramsNotOk)
                throw new Exception(errMsgParams.ToString());

            return true;
        }
        catch (Exception ex)
        {
            Log.Error(ex, ex.Message);
            _ = _prismMessageBox.Show(ex.Message,
                                      GetResource.GetValue<string>("ErrorMessage_ParametersError"),
                                      MessageBoxImage.Error);
            return false;
        }
    }

    /// <summary>
    /// 參數寫入PLC
    /// </summary>
    /// <returns>寫入成功=true。</returns>
    private bool WriteToPlc_LensArrange(List<LensArrangeDefine> lensArrangeData)
    {
        if (!_plc.Online || !_pm.IsProductActive)
            return false;

        try
        {
            int visionId = -1;

            foreach (var pallet in lensArrangeData)
            {
                int palletIdx = pallet.Id - 1;
                int trayId = -1;

                if (pallet.Pick)
                {
                    trayId = pallet.PickTrayId;
                    if (visionId == -1)
                        visionId = _tray.TrayList.Find(x => x.Id == trayId).VisionId;
                }
                else if (pallet.Place)
                {
                    trayId = pallet.PlaceTrayId;
                }

                // 寫入PLC
                if (trayId >= 0)
                {
                    // 註記Pallet Mode
                    _wp.PalletMode[palletIdx] = pallet.TrayMode;

                    PalletDefine pd = _tray.PalletList.Find(x => x.Id == pallet.Id);
                    TrayDefine td = _tray.TrayList.Find(x => x.Id == trayId).DeepCopyByExpressionTree();

                    if (pd != null && td != null)
                    {
                        td.DatumX = (pd.DatumX + _machine.Machine.DatumPointX).WfsFormat();
                        td.DatumY = (pd.DatumY + _machine.Machine.DatumPointY).WfsFormat();
                        td.Order_PositionA_X += td.DatumX;
                        td.Order_PositionA_Y += td.DatumY;
                        td.Order_PositionB_X += td.DatumX;
                        td.Order_PositionB_Y += td.DatumY;
                        td.Order_PositionC_X += td.DatumX;
                        td.Order_PositionC_Y += td.DatumY;
                        td.Cross_PositionA_X += td.DatumX;
                        td.Cross_PositionA_Y += td.DatumY;
                        td.Cross_PositionB_X += td.DatumX;
                        td.Cross_PositionB_Y += td.DatumY;
                        td.Cross_PositionC_X += td.DatumX;
                        td.Cross_PositionC_Y += td.DatumY;

                        _tray.WriteTrayToPlc(pallet.Id, td);
                    }
                }
                else
                {
                    _wp.PalletMode[palletIdx] = PlcTrayFunctionType.Unused;
                }
            }

            // 寫入Tray模式
            _ = _plc.WriteInt16(DeviceLists.TRAY_MODE, new short[]
            {
                (short)_wp.PalletMode[00], (short)_wp.PalletMode[01], (short)_wp.PalletMode[02],
                (short)_wp.PalletMode[03], (short)_wp.PalletMode[04], (short)_wp.PalletMode[05],
                (short)_wp.PalletMode[06], (short)_wp.PalletMode[07], (short)_wp.PalletMode[08],
                (short)_wp.PalletMode[09], (short)_wp.PalletMode[10], (short)_wp.PalletMode[11],
                (short)_wp.PalletMode[12], (short)_wp.PalletMode[13], (short)_wp.PalletMode[14],
                (short)_wp.PalletMode[15], (short)_wp.PalletMode[16], (short)_wp.PalletMode[17],
                (short)_wp.PalletMode[18], (short)_wp.PalletMode[19], (short)_wp.PalletMode[20],
                (short)_wp.PalletMode[21], (short)_wp.PalletMode[22], (short)_wp.PalletMode[23]
            });

            // 寫入視覺品種
            if (visionId >= 0)
                _ = _plc.WriteInt16(DeviceLists.CAMERA1_PRODUCT_TYPE, (short)visionId);

            return true;
        }
        catch (Exception ex)
        {
            string errTitle = $"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_System_InternalError")}";
            Log.Fatal(ex, errTitle);
            _prismMessageBox.Show($"{ex.Message}，{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}",
                                  errTitle,
                                  MessageBoxImage.Error);
            return false;
        }
    }

    /********************
     * 
     ********************/
    /// <inheritdoc/>
    public void UpdateRelationList(List<LensArrangeDefine> lensArrangeList)
    {
        var picks = lensArrangeList.FindAll(x => x.Pick).OrderBy(x => x.Id).ToList();
        var places = lensArrangeList.FindAll(x => x.Place).OrderBy(x => x.Id).ToList();
        int count = Math.Max(picks.Count, places.Count);

        var papl = new List<PickAndPlaceListDefine>();
        for (int idx = 0; idx < count; idx++)
        {
            papl.Add(new PickAndPlaceListDefine()
            {
                PickPalletId = idx < picks.Count ? picks[idx].Id.ToString() : string.Empty,
                PlacePalletId = idx < places.Count ? places[idx].Id.ToString() : string.Empty,
            });
        }
        _wd.PickAndPlaceList = new ObservableCollection<PickAndPlaceListDefine>(papl);
    }

    /// <inheritdoc/>
    public void UpdateRelationList()
    {
        UpdateRelationList(LensArrangeList);
    }

    /********************
     * 自動作業
     ********************/
    /// <summary>
    /// 開始此批號的資料收集
    /// </summary>
    private bool StartDataCollection_LensArrange()
    {
        return true;
    }

    /// <summary>
    /// 悙止此批號的資料收集
    /// </summary>
    private void StopDataCollection_LensArrange()
    {
    }
}
