﻿using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.WFS.Constants;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models.Tray;

namespace Glorytek.WFSComponents.WFS.Services
{
    public partial class WfsService
    {
        /// <summary>
        /// 點位更新函數，設定點位相關資訊，及某些UI需要的資訊。
        /// </summary>
        private void UpdatePalletInfo(bool checkAllNextPointNo)
        {
            if (_tp.PalletList.Count > 0)
            {
                // TODO: 有些資料可以不用在這裡更新，會占用一些資源
                // 只不過這個函數觸發間隔都至少半秒以上，故沒有再修改了
                for (int palletId = 1; palletId <= ITray.MaxPalletId; palletId++)
                {
                    int palletIndex = palletId - 1;

                    var trayFuncType = TrayFunctionType.Unused;
                    if (_sdi.SystemMode_LensArrange)
                    {
                        var pallet = LensArrangeList[palletIndex];
                        if (pallet.Pick)
                            trayFuncType = TrayFunctionType.Feeder;
                        else if (pallet.Place)
                            trayFuncType = TrayFunctionType.Classified;
                    }
                    else
                    {
                        trayFuncType = LensSortingList[palletIndex].FunctionName;
                    }
                    bool trayInstall = trayFuncType != TrayFunctionType.Unused;
                    _tp.PalletList[palletIndex].InstallTray = trayInstall;
                    _tp.PalletList[palletIndex].FunctionName = trayFuncType;

                    int trayId = _tray.GetTrayId(palletId);
                    if (trayInstall && trayId >= 1)
                    {
                        var tray = _tray.TrayList.Find(x => x.Id == trayId);
                        if (tray != null)
                        {
                            if (_tray.ConvertPointNoToSequenceNo(trayId, _pd.NextPointNo[palletIndex]) == 0)
                            {
                                _pd.NextPointNo[palletIndex] = 1;
                                _tray.WriteStartPointNo(palletId, _pd.NextPointNo[palletIndex]);
                            }

                            _tp.PalletList[palletIndex].TotalSequences = tray.TotalSequences;
                            _tp.PalletList[palletIndex].TrayName = tray.Name;
                            _tp.PalletList[palletIndex].NextSequenceNo = _tray.ConvertPointNoToSequenceNo(trayId, _pd.NextPointNo[palletIndex]);
                            _tp.PalletList[palletIndex].PickSequenceNo = _tray.ConvertPointNoToSequenceNo(trayId, _pd.PickPointNo[palletIndex]);
                        }
                        else
                        {
                            _tp.PalletList[palletIndex].TotalSequences = 0;
                            _tp.PalletList[palletIndex].TrayName = "";
                        }
                    }
                    else
                    {
                        _tp.PalletList[palletIndex].TotalSequences = 0;
                        _tp.PalletList[palletIndex].NextSequenceNo = 0;
                        _tp.PalletList[palletIndex].PickSequenceNo = 0;
                    }

                    _tp.PalletList[palletIndex].NextPointNo = _pd.NextPointNo[palletIndex];
                    _tp.PalletList[palletIndex].PickPointNo = _pd.PickPointNo[palletIndex];
                }

                _ea.GetEvent<SystemPointNoUpdatedEvent>().Publish(0);
            }

            /*
             * 因取放點位的演算法由PLC處理，故要呼叫PLC以確認點位合法性。呼叫時機：
             * 1. 切換品種。
             * 2. 切換模式。
             * 3. 更改Pallet套用的Tray。
             * 4. Tray設定變更後。
             */
            if (checkAllNextPointNo)
            {
                for (int palletIndex = 0; palletIndex < 24; palletIndex++)
                {
                    var pallet = _tray.PalletList[palletIndex];
                    if (pallet.InstallTray && GetTray(pallet.Id, out TrayDefine tray))
                    {
                        int sequence = _tray.ConvertPointNoToSequenceNo(tray.Id, pallet.NextPointNo);
                        if (sequence < 1 || sequence > tray.TotalSequences)
                            _tray.WriteStartPointNo(pallet.Id, 1);
                    }
                }
            }

            //_td.PointNo = _pd.PointNo;
            //_td.ActionPointNo = _pd.ActionPointNo;

            //var sequecneNo = new int[ITray.MaxPalletId];
            //for (int palletId = 1; palletId <= ITray.MaxPalletId; palletId++)
            //{
            //    int palletIndex = palletId - 1;
            //    sequecneNo[palletIndex] = ConvertPointNoToSequenceNo(GetTrayId(palletId), _td.ActionPointNo[palletIndex]);
            //}
            //_td.SequecneNo = sequecneNo;
        }
    }
}
