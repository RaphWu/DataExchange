﻿using Glorytek.CSharp.Extensions;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSExternal;
using Serilog;
using System.Windows;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - TrayToA1模式。
 ********************/
public partial class WfsService
{
    /// <summary>
    /// 參數寫入PLC
    /// </summary>
    private bool WriteToPlc_TrayToA1(int trayId)
    {
        if (_plc.Online)
        {
            // 此模式使用固定位置
            const int palletId = 24;

            var tray = _tray.TrayList.Find(x => x.Id == trayId).DeepCopyByExpressionTree();
            if (tray == null)
            {
                string errMsg = "托盤找不到！";
                Log.Error($"{errMsg}\r\nMainConsoleViewModel->WriteToPlc_TrayToA1()");
                _ = _prismMessageBox.Show(errMsg, "參數錯誤", MessageBoxImage.Error);

                return false;
            }

            PalletDefine pd = _tray.PalletList.Find(x => x.Id == palletId);
            tray.DatumX = (pd.DatumX + _machine.Machine.DatumPointX).WfsFormat();
            tray.DatumY = (pd.DatumY + _machine.Machine.DatumPointY).WfsFormat();
            tray.Order_PositionA_X += tray.DatumX;
            tray.Order_PositionA_Y += tray.DatumY;
            tray.Order_PositionB_X += tray.DatumX;
            tray.Order_PositionB_Y += tray.DatumY;
            tray.Order_PositionC_X += tray.DatumX;
            tray.Order_PositionC_Y += tray.DatumY;
            tray.Cross_PositionA_X += tray.DatumX;
            tray.Cross_PositionA_Y += tray.DatumY;
            tray.Cross_PositionB_X += tray.DatumX;
            tray.Cross_PositionB_Y += tray.DatumY;
            tray.Cross_PositionC_X += tray.DatumX;
            tray.Cross_PositionC_Y += tray.DatumY;

            _tray.WriteTrayToPlc(palletId, tray);
            _ = _plc.WriteInt16(DeviceLists.CAMERA1_PRODUCT_TYPE, (short)tray.VisionId);

            return true;
        }
        else
        {
            return false;
        }
    }
}
