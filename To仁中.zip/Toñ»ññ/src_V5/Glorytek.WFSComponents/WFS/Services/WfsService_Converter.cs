﻿//using Serilog;
//using System;

//namespace Glorytek.WFSComponents.WFS.Services;

//public partial class WfsService
//{
//    /// <summary>
//    /// 點位編號 轉換成 取放點序號
//    /// </summary>
//    /// <param name="palletId">Pallet編號。</param>
//    /// <param name="pointNo">點位編號。</param>
//    /// <returns>取放點序號<br/>返回0表示該點為Mask。</returns>
//    private int PointNo2SequenceNo(int palletId, int pointNo)
//    {
//        try
//        {
//            var trayId = LensSortingList.Find(x => x.Id == palletId).TrayId;
//            var profile = _tray.ProfileList.Find(x => x.TrayId == trayId && x.PointNo == pointNo);
//            return profile.SequenceNo;
//        }
//        catch (Exception ex)
//        {
//            Log.Fatal(ex, $"Tray座標轉換異常: PointNo2SequenceNo(palletId={palletId}, pointNo={pointNo})");
//            return -1;
//        }
//    }

//    /// <summary>
//    /// 取放點序號 轉換成 點位編號
//    /// </summary>
//    /// <param name="palletId">Pallet編號。</param>
//    /// <param name="sequenceNo">取放點序號。</param>
//    /// <returns>點位編號。</returns>
//    private int SequenceNo2PointNo(int palletId, int sequenceNo)
//    {
//        try
//        {
//            var trayId = LensSortingList.Find(x => x.Id == palletId).TrayId;
//            var profile = _tray.ProfileList.Find(x => x.TrayId == trayId && x.SequenceNo == sequenceNo);
//            return profile.PointNo;
//        }
//        catch (Exception ex)
//        {
//            Log.Fatal(ex, $"Tray座標轉換異常: SequenceNo2PointNo(palletId={palletId}, sequenceNo={sequenceNo})");
//            return -1;
//        }
//    }
//}
