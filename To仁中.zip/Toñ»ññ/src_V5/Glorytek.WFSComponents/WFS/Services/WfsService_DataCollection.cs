﻿using Dapper.Contrib.Extensions;
using Glorytek.SQLite;
using Glorytek.WFSComponents.WFS.Constants;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WPF.Extensions;
using Serilog;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - 量測資料操作。
 ********************/
public partial class WfsService : IWfs_DataCollection
{
    private const int LOT_NUMBER_LENGTH = 11;
    private static string _lotNumber = string.Empty;

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public bool OpenMeasurementDb(string dbPathName)
    {
        if (!CloseMeasurementDb())
            return false;

        try
        {
            _wd.ConnMeasurementData = SQLiteHelper.OpenConnection(dbPathName);

            if (!SQLiteHelper.IsTableExist(_wd.ConnMeasurementData, DB_WFS.TableName_LensSorting))
                SQLiteHelper.CreateTable(_wd.ConnMeasurementData, DB_WFS.CreateTableSQL_LensSorting);

            if (!SQLiteHelper.IsTableExist(_wd.ConnMeasurementData, DB_Tray.TableName_Tray))
                SQLiteHelper.CreateTable(_wd.ConnMeasurementData, DB_Tray.CreateTableSQL_Tray);

            if (!SQLiteHelper.IsTableExist(_wd.ConnMeasurementData, DB_Tray.TableName_Tray_Profile))
                SQLiteHelper.CreateTable(_wd.ConnMeasurementData, DB_Tray.CreateTableSQL_Tray_Profile);

            if (!SQLiteHelper.IsTableExist(_wd.ConnMeasurementData, DB_WFS.TableName_DataNameList))
                SQLiteHelper.CreateTable(_wd.ConnMeasurementData, DB_WFS.CreateTableSQL_DataNameList);

            if (!SQLiteHelper.IsTableExist(_wd.ConnMeasurementData, DB_WFS.TableName_Grade))
                SQLiteHelper.CreateTable(_wd.ConnMeasurementData, DB_WFS.CreateTableSQL_Grade);

            if (!SQLiteHelper.IsTableExist(_wd.ConnMeasurementData, DB_WFS.TableName_Specification))
                SQLiteHelper.CreateTable(_wd.ConnMeasurementData, DB_WFS.CreateTableSQL_Specification);

            if (!SQLiteHelper.IsTableExist(_wd.ConnMeasurementData, DB_WFS.TableName_MeasurementData))
                SQLiteHelper.CreateTable(_wd.ConnMeasurementData, DB_WFS.CreateTableSQL_MeasurementData);

            return true;
        }
        catch (Exception ex)
        {
            _ = CloseMeasurementDb();

            string errorMsg = $"資料庫開啟失敗: {dbPathName}";
            Log.Error(ex, errorMsg);
            _ = _prismMessageBox.Show($"{errorMsg}\n{ex}", "資料庫錯誤！", MessageBoxImage.Error);

            return false;
        }
    }

    /// <inheritdoc/>
    public bool CloseMeasurementDb()
    {
        try
        {
            if (_wd.ConnMeasurementData != null && _wd.ConnMeasurementData.State == ConnectionState.Open)
                _wd.ConnMeasurementData.Close();

            return true;
        }
        catch (Exception ex)
        {
            string errorMsg = $"資料庫關閉失敗: {_wd.ConnMeasurementData.FileName}";
            Log.Error(ex, errorMsg);
            _ = _prismMessageBox.Show($"{errorMsg}\n{ex}", "資料庫錯誤！", MessageBoxImage.Error);

            return false;
        }
    }

    /********************
     * Lot Number
     ********************/
    /// <inheritdoc/>
    public bool IsLotNumberValid(string lotNumber)
    {
        return !string.IsNullOrWhiteSpace(lotNumber) && lotNumber.Length == LOT_NUMBER_LENGTH;
    }

    /// <inheritdoc/>
    public bool SetNewLot()
    {
        //if (!_pm.IsProductActive)
        //    return false;

        var ssh = SystemDataInstance.Instance;
        _lotNumber = string.Empty;
        _wd.MeasurementDataList = new List<MeasurementDataDefine>();

        if (ssh.SystemMode_LensSorting
            || ssh.SystemMode_Online_FixStage
            || ssh.SystemMode_Online_SingleCylinder
            || ssh.SystemMode_Online_DoubleCylinder)
        {
            _lotNumber = GetNewLotNumber();
            _wd.CurrentMeasurementDataFileName = GetMeasurementDataFullFileName(_lotNumber);

            if (OpenMeasurementDb(_wd.CurrentMeasurementDataFileName))
            {
                try
                {
                    var palletList = _wp.LensSortingList.FindAll(x => x.FunctionName != TrayFunctionType.Unused);
                    var profileList = new List<TrayProfileDefine>();
                    foreach (var pallet in palletList)
                        profileList.AddRange(_tray.ProfileList.FindAll(x => x.TrayId == pallet.TrayId));

                    // 儲存DB
                    var conn = _wd.ConnMeasurementData;
                    using (var tran = conn.BeginTransaction())
                    {
                        try
                        {
                            _ = conn.Insert(_wp.DataNameList, transaction: tran);
                            _ = conn.Insert(palletList, transaction: tran);
                            _ = conn.Insert(_tray.TrayList, transaction: tran);
                            _ = conn.Insert(profileList, transaction: tran);
                            _ = conn.Insert(_wp.GradeList, transaction: tran);
                            _ = conn.Insert(_wp.SpecificationList, transaction: tran);
                            tran.Commit();
                        }
                        catch
                        {
                            tran.Rollback();
                        }
                    }

                    ReadMeasurementDataFileList();
                    // 下面這方法竟然無法更新!?
                    //var mdfl = _wfsDatas.MeasurementDataFileList;
                    //mdfl.Add(_lotNumber);
                    //_wfsDatas.MeasurementDataFileList = mdfl;
                }
                catch (Exception ex)
                {
                    string errorMsg = $"資料新增失敗！資料庫: {_wd.CurrentMeasurementDataFileName}";
                    Log.Fatal(ex, errorMsg);
                    _ = _prismMessageBox.Show($"{errorMsg}\n{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}",
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                              MessageBoxImage.Error);
                    return false;
                }
            }
            else
            {
                string errorMsg = $"批號建立失敗: {_lotNumber}";
                Log.Fatal(errorMsg);
                _ = _prismMessageBox.Show($"{errorMsg}，{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}",
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_System_InternalError"),
                                          MessageBoxImage.Error);
                return false;
            }
        }

        _wp.CurrentLotNumber = _lotNumber;
        return true;
    }

    /// <inheritdoc/>
    public void ResetLot()
    {
        //if (!_pm.IsProductActive)
        //    return;

        _ = CloseMeasurementDb();

        _wd.CurrentMeasurementDataFileName = string.Empty;
        _lotNumber = string.Empty;
    }

    /// <inheritdoc/>
    public string GetLastLotNumber()
    {
        return _wd.MeasurementDataFileList.Count > 0
            ? _wd.MeasurementDataFileList[0]
            : string.Empty;
    }

    /// <inheritdoc/>
    public string GetNewLotNumber()
    {
        _lotNumber = "";
        string today = DateTime.Now.ToString("yyyyMMdd");
        List<string> listOfToday = _wd.MeasurementDataFileList.Where(x => IsLotNumberValid(x) && x.Substring(0, 8) == today).ToList();

        if (listOfToday.Count == 0)
        {
            _lotNumber = $"{today}001";
        }
        else
        {
            int maxNo = 0;
            foreach (var lotNumber in listOfToday)
            {
                int serialNo = int.Parse(lotNumber.Substring(8));
                if (maxNo < serialNo)
                    maxNo = serialNo;
            }

            _lotNumber = maxNo > 0
                ? $"{today}{maxNo + 1,3:D3}"
                : $"{today}001";
        }

        return _lotNumber;
    }

    /********************
     * 檔案操作
     ********************/
    /// <inheritdoc/>
    public void ReadMeasurementDataFileList()
    {
        string dir = Path.Combine(DBbase.Directory_Base, DB_WFS.Directory_MeasurementData);
        if (!Directory.Exists(dir))
            _ = Directory.CreateDirectory(dir);

        var fileList = new List<string>();
        foreach (string fileName in Directory.EnumerateFiles(dir, $"*{DBbase.DB_ExtFileName}"))
        {
            string lotNumber = Path.GetFileNameWithoutExtension(fileName);
            if (IsLotNumberValid(lotNumber))
                fileList.Add(lotNumber);
        }
        _wd.MeasurementDataFileList = fileList.OrderByDescending(x => x).ToList();
        _bd.LotNumberList = new ObservableCollection<string>(_wd.MeasurementDataFileList);
    }

    /// <inheritdoc/>
    public string GetMeasurementDataFullFileName(string lotNumber)
        => Path.Combine(DBbase.Directory_Base,
                        DB_WFS.Directory_MeasurementData,
                        $"{lotNumber}{DBbase.DB_ExtFileName}");
}
