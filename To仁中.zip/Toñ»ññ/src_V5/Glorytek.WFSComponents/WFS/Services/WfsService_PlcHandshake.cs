﻿using Glorytek.WFSExternal;
using Serilog;
using System.Threading.Tasks;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - PLC交握動作。
 ********************/
public partial class WfsService
{
    /// <summary>
    /// PLC交握分支判定。
    /// </summary>
    /// <param name="para">交握前動作。</param>
    private void PlcHandshake(string para)
    {
        if (_sdi.SystemMode_Online_FixStage || _sdi.SystemMode_Online_DoubleCylinder
            || _sdi.SystemMode_Online_SingleCylinder | _sdi.SystemMode_Online_Disc)
        {
            if (para == "PICK")
                PlcHandshake_Online_Pick();
            else if (para == "PLACE")
                PlcHandshake_Online_Place();
        }
        else if (_sdi.SystemMode_LensSorting && para == "PLACE")
        {
            PlcHandshake_LensSorting_Place();
        }
    }

    /// <summary>
    /// 等待PLC的「等待放置」訊號，然後由PLC讀取指定Pallet的目前動作點位。
    /// </summary>
    /// <param name="monitorSignal">交握訊號的軟元件。</param>
    /// <param name="palletId">Pallet ID。</param>
    /// <returns>動作點位。讀取失敗則回傳-1。</returns>
    private short GetPalletPointNo(string monitorSignal, int palletId)
    {
        short targetPointNo = -1;
        bool hasResult = Task.Run(async () =>
        {
            while (true)
            {
                var (whenPlaceingOK, whenPlaceing) = _plc.ReadBool(monitorSignal);
                if (whenPlaceingOK && (bool)whenPlaceing)
                {
                    var (apOK, ap) = _plc.ReadInt16($"D{DeviceLists.TRAY_NEXT_POINT_NO_01 + palletId}");
                    if (apOK)
                        targetPointNo = ap;
                    break;
                }
                else
                {
                    await Task.Delay(1);
                }
            }
        }).Wait(10000);

        if (!hasResult)
            Log.Warning("Pallet點位讀取逾時.");
        return targetPointNo;
    }
}
