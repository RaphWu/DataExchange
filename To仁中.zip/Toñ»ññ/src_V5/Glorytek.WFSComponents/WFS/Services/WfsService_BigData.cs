﻿using Dapper.Contrib.Extensions;
using Glorytek.SQLite;
using Glorytek.WFSComponents.Events;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSComponents.WFS.Models;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Constants.WFS;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WPF.Extensions;
using Prism.Services.Dialogs;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace Glorytek.WFSComponents.WFS.Services;

/********************
 * WFS Service - 大數據。
 ********************/
public partial class WfsService : IWfs_BigData
{
    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public void GetLotNumberDataFromDb(string lotNumber)
    {
        if (OpenMeasurementDb(GetMeasurementDataFullFileName(lotNumber)))
        {
            var conn = _wd.ConnMeasurementData;
            using (var tran = conn.BeginTransaction())
            {
                string errorMsg;
                try
                {
                    _wd.LotPalletSortingList = conn.GetAll<LensSortingDefine>(transaction: tran).ToList();
                    _wd.LotTrayList = conn.GetAll<TrayDefine>(transaction: tran).ToList();
                    _wd.LotProfileList = conn.GetAll<TrayProfileDefine>(transaction: tran).ToList();
                    _wd.LotDataNameList = conn.GetAll<WfsDataNameListDefine>(transaction: tran).ToList();
                    _wd.LotGradeList = conn.GetAll<WfsGradeDefine>(transaction: tran).ToList();
                    _wd.LotSpecificationList = conn.GetAll<WfsSpecificationDefine>(transaction: tran).ToList();
                    _wd.MeasurementDataList = conn.GetAll<MeasurementDataDefine>(transaction: tran).ToList();
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    errorMsg = GetResource.GetValue<string>("ErrorMessage_BigData_ExportFailure");
                    Log.Error(ex, errorMsg);
                    _ = _prismMessageBox.Show($"{errorMsg}\n{ex.Message}",
                                              GetResource.GetValue<string>("ErrorMessage_BigData_DataError_Title"),
                                              MessageBoxImage.Error);
                    return;
                }
            }
            _ = CloseMeasurementDb();
            IntegrateDataToBigData(_wd.MeasurementDataList);
        }
    }

    /// <inheritdoc/>
    public void ReadBigDataFromDb()
    {
        if (!_pm.IsProductActive)
            return;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            if (!SQLiteHelper.IsTableExist(conn, DB_WFS.TableName_MeasurementData))
            {
                SQLiteHelper.CreateTable(conn, DB_WFS.CreateTableSQL_MeasurementData);
                SaveMeasurementData(conn.GetAll<MeasurementDataDefine>(transaction: tran).ToList());
            }
            _wd.MeasurementDataList = conn.GetAll<MeasurementDataDefine>(transaction: tran).ToList();
            tran.Commit();
        }
        catch (Exception ex)
        {
            tran.Rollback();
            string errorMsg = GetResource.GetValue<string>("ErrorMessage_BigData_DbReadFailure");
            Log.Error(ex, errorMsg);
            _ = _prismMessageBox.Show($"{errorMsg}\n{ex}",
                                      GetResource.GetValue<string>("ErrorMessage_BigData_Exception_Title"),
                                      MessageBoxImage.Error);
            return;
        }
    }

    /// <summary>
    /// 依格式儲存數據。
    /// </summary>
    /// <param name="data">待儲存的量測資料。</param>
    private void SaveMeasurementData(List<MeasurementDataDefine> data)
    {
        _wd.MeasurementDataList = data;
        _bd.UpdateBrowserParameters(MeasurementDataList);
        UpdateBrowser();
    }

    /********************
     * BigData
     ********************/
    /// <inheritdoc/>
    public void IntegrateDataToBigData(List<MeasurementDataDefine> measurementDataList)
    {
        if (measurementDataList == null || _wd.LotPalletSortingList == null || _wd.LotPalletSortingList.Count == 0)
            return;

        try
        {
            _sysMessenger.ShowProgressRing(true);
            Task.Run(() =>
            {
                BigDataOutputData.LoadTraySetting = new();
                BigDataOutputData.ProductTraySetting = new();
                BigDataOutputData.ReworkTraySetting = new();
                BigDataOutputData.SpecificationSetting = new();
                BigDataOutputData.OutputProduct = new();
                BigDataOutputData.OutputRework = new();

                // 載入基本資料
                foreach (var item in _wd.LotPalletSortingList)
                {
                    //var tray = _tray.TrayList.Find(x => x.Id == item.TrayId);
                    var tray = _wd.LotTrayList.Find(x => x.Id == item.TrayId);
                    if (tray == null)
                        throw new Exception("tray == null!");

                    if (item.FunctionName == TrayFunctionType.Classified)
                    {
                        //var grade = GradeList.Find(x => x.Id == item.GradeId);
                        var grade = _wd.LotGradeList.Find(x => x.Id == item.GradeId);
                        BigDataOutputData.ProductTraySetting.Add(new ProductTraySettingDefine()
                        {
                            TrayId = tray.Id,
                            TrayName = tray.Name,
                            Barcode = item.Barcode,
                            GradeId = grade.Id,
                            PalletNo = item.Id,
                        });
                    }
                    else if (item.FunctionName == TrayFunctionType.Rework)
                    {
                        BigDataOutputData.ReworkTraySetting.Add(new ReworkTraySettingDefine()
                        {
                            TrayId = tray.Id,
                            TrayName = tray.Name,
                            Barcode = item.Barcode,
                            PalletNo = item.Id,
                        });
                    }
                    else if (item.FunctionName == TrayFunctionType.Feeder)
                    {
                        BigDataOutputData.LoadTraySetting.Add(new LoadTraySettingDefine()
                        {
                            TrayId = tray.Id,
                            TrayName = tray.Name,
                            Barcode = item.Barcode,
                            PalletNo = item.Id,
                        });
                    }
                }

                // 更新顯示輸入Tray
                var queryLoadTray = from load in BigDataOutputData.LoadTraySetting
                                    join tray in _wd.LotTrayList on load.TrayId equals tray.Id
                                    select new LoadTrayLayoutDefine
                                    {
                                        TrayId = load.TrayId,
                                        TrayName = tray.Name,
                                        Barcode = load.Barcode,
                                        PalletNo = load.PalletNo,
                                    };
                var tLoadTrayList = new List<LoadTrayLayoutDefine>();
                foreach (var item in queryLoadTray)
                    tLoadTrayList.Add(item);
                _bd.LoadTrayLayoutList = tLoadTrayList;

                // 更新顯示量測成品Tray
                var queryProductTray = from product in BigDataOutputData.ProductTraySetting
                                       join tray in _wd.LotTrayList on product.TrayId equals tray.Id
                                       join grade in _wd.LotGradeList on product.GradeId equals grade.Id
                                       select new ProductTrayLayoutDefine
                                       {
                                           TrayId = tray.Id,
                                           TrayName = tray.Name,
                                           Barcode = product.Barcode,
                                           GradeId = grade.Id,
                                           GradeName = grade.Name,
                                           PalletNo = product.PalletNo,
                                       };
                var tProductTrayList = new List<ProductTrayLayoutDefine>();
                foreach (var item in queryProductTray)
                    tProductTrayList.Add(item);
                _bd.ProductTrayLayoutList = tProductTrayList;

                // 更新顯示重工品Tray
                var queryReworkTray = from rework in BigDataOutputData.ReworkTraySetting
                                      join tray in _wd.LotTrayList on rework.TrayId equals tray.Id
                                      select new ReworkTrayLayoutDefine
                                      {
                                          TrayId = tray.Id,
                                          TrayName = tray.Name,
                                          Barcode = rework.Barcode,
                                          PalletNo = rework.PalletNo,
                                      };
                var tReworkTrayList = new List<ReworkTrayLayoutDefine>();
                foreach (var item in queryReworkTray)
                    tReworkTrayList.Add(item);
                _bd.ReworkTrayLayoutList = tReworkTrayList;

                // 規格
                foreach (var grade in _wd.LotGradeList)
                {
                    if (_wd.LotPalletSortingList.Exists(x => x.GradeId == grade.Id))
                    {
                        var specList = SpecificationList.FindAll(x => x.GradeId == grade.Id);
                        foreach (var spec in specList)
                        {
                            // 用不到的值顯示歸零避免混淆
                            if (spec.Relation == InequalityRelationType.Between || spec.Relation == InequalityRelationType.NotBetween)
                            {
                                spec.Value = 0.0;
                            }
                            else
                            {
                                spec.Value1 = 0.0;
                                spec.Value2 = 0.0;
                            }

                            BigDataOutputData.SpecificationSetting.Add(new SpecificationDefine()
                            {
                                GradeId = grade.Id,
                                GradeName = grade.Name,
                                DataName = spec.DataName,
                                Relation = spec.Relation.ToString(),
                                RelationType = spec.Relation,
                                Value = spec.Value,
                                Value1 = spec.Value1,
                                Value2 = spec.Value2,
                            });
                        }
                    }
                }

                var querySpecification = from spec in BigDataOutputData.SpecificationSetting
                                         join grade in _wd.LotGradeList on spec.GradeId equals grade.Id
                                         select new SpecificationLayoutDefine
                                         {
                                             GradeId = grade.Id,
                                             GradeName = grade.Name,
                                             DataName = spec.DataName,
                                             Relation = spec.Relation,
                                             RelationType = spec.RelationType,
                                             Value = spec.Value,
                                             Value1 = spec.Value1,
                                             Value2 = spec.Value2,
                                         };
                var tSpecificationList = new List<SpecificationLayoutDefine>();
                foreach (var item in querySpecification)
                    tSpecificationList.Add(item);
                _bd.SpecificationLayoutList = tSpecificationList.OrderBy(x => x.GradeId).ToList();

                var sl = CollectionViewSource.GetDefaultView(_bd.SpecificationLayoutList);
                sl.GroupDescriptions.Add(new PropertyGroupDescription("GradeName"));

                // 建立成品Tray數
                foreach (var bData in measurementDataList)
                {
                    var sourcePofile = _wd.LotProfileList.Find(x => x.TrayId == bData.SourceTrayId && x.PointNo == bData.SourcePointNo);
                    var targetPofile = _wd.LotProfileList.Find(x => x.TrayId == bData.TargetTrayId && x.PointNo == bData.TargetPointNo);
                    var pallet = _wd.LotPalletSortingList.Find(x => x.Id == bData.TargetPalletNo);

                    // 下列null異常會發生在Tray空盤/滿盤又持續取放料的情況，點位資料會超出Tray範圍而null
                    // 目前似乎只發生在分檢模式，暫時用if跳過
                    if (sourcePofile != null && targetPofile != null)
                    {
                        if (bData.Judgement)
                        {
                            int productTrayIdx = _bd.ProductTrayLayoutList.FindIndex(x => x.GradeName == bData.GradeName);
                            BigDataOutputData.OutputProduct.Add(new OutputProductDefine()
                            {
                                LotNumber = bData.LotNumber,
                                Time = bData.Time,
                                GradeId = bData.Grade,
                                Barcode = pallet.Barcode,
                                TrayId = pallet.TrayId,
                                X = targetPofile.Column,
                                Y = targetPofile.Row,
                                SourceTrayId = bData.SourceTrayId,
                                SourceX = sourcePofile.Column,
                                SourceY = sourcePofile.Row,
                                Angle = bData.Angle,
                                Decenter = bData.Decenter,
                            });
                        }
                        else
                        {
                            BigDataOutputData.OutputRework.Add(new OutputReworkDefine()
                            {
                                LotNumber = bData.LotNumber,
                                Time = bData.Time,
                                Barcode = pallet.Barcode,
                                TrayId = pallet.TrayId,
                                X = targetPofile != null ? targetPofile.Column : 0,
                                Y = targetPofile != null ? targetPofile.Row : 0,
                                SourceTrayId = bData.SourceTrayId,
                                SourceX = sourcePofile != null ? sourcePofile.Column : 0,
                                SourceY = sourcePofile != null ? sourcePofile.Row : 0,
                                Angle = bData.Angle,
                                Decenter = bData.Decenter,
                            });
                        }
                    }
                }

                // 更新顯示量測成品資料
                var tProduct = new List<OutputProductLayoutDefine>();
                foreach (var product in BigDataOutputData.OutputProduct)
                {
                    //var grade = GradeList.Find(x => x.Id == product.GradeId);
                    //var sourceTray = _tray.TrayList.Find(x => x.Id == product.SourceTrayId);
                    //var targetTray = _tray.TrayList.Find(x => x.Id == product.TrayId);

                    var grade = _wd.LotGradeList.Find(x => x.Id == product.GradeId);
                    var sourceTray = _wd.LotTrayList.Find(x => x.Id == product.SourceTrayId);
                    var targetTray = _wd.LotTrayList.Find(x => x.Id == product.TrayId);

                    tProduct.Add(new OutputProductLayoutDefine()
                    {
                        LotNumber = product.LotNumber,
                        Time = product.Time,
                        GradeId = product.GradeId,
                        GradeName = grade != null ? grade.Name : "",
                        Barcode = product.Barcode,
                        TrayId = product.TrayId,
                        TargetTrayName = targetTray.Name,
                        X = product.X,
                        Y = product.Y,
                        SourceTrayId = product.SourceTrayId,
                        SourceTrayName = sourceTray.Name,
                        SourceX = product.SourceX,
                        SourceY = product.SourceY,
                        Angle = product.Angle,
                        Decenter = product.Decenter,
                    });
                }
                _bd.ProductLayoutList = tProduct.OrderBy(x => x.LotNumber).ThenBy(x => x.GradeId).ThenBy(x => x.Time).ToList();
                var pl = CollectionViewSource.GetDefaultView(_bd.ProductLayoutList);
                pl.GroupDescriptions.Add(new PropertyGroupDescription("GradeName"));

                // 更新顯示重工品資料
                var tReworkList = new List<OutputReworkLayoutDefine>();
                foreach (var rework in BigDataOutputData.OutputRework)
                {
                    var sourceTray = _wd.LotTrayList.Find(x => x.Id == rework.SourceTrayId);
                    var targetTray = _wd.LotTrayList.Find(x => x.Id == rework.TrayId);

                    tReworkList.Add(new OutputReworkLayoutDefine()
                    {
                        LotNumber = rework.LotNumber,
                        Time = rework.Time,
                        Barcode = rework.Barcode,
                        TrayId = rework.TrayId,
                        TargetTrayName = targetTray.Name,
                        X = rework.X,
                        Y = rework.Y,
                        SourceTrayId = rework.SourceTrayId,
                        SourceTrayName = sourceTray.Name,
                        SourceX = rework.SourceX,
                        SourceY = rework.SourceY,
                        Angle = rework.Angle,
                        Decenter = rework.Decenter,
                    });
                }
                _bd.ReworkLayoutList = tReworkList.OrderBy(x => x.LotNumber).ThenBy(x => x.Time).ToList();
            }).Wait();
        }
        catch (Exception ex)
        {
            Log.Fatal("Source data error!", ex);
        }

        _sysMessenger.ShowProgressRing(false);
    }

    /// <inheritdoc/>
    public void ExportBigDataToDb(string lotNumber)
    {
        if (!Directory.Exists(DB_BigData.Directory_BigData))
            _ = Directory.CreateDirectory(DB_BigData.Directory_BigData);

        if (IsLotNumberValid(lotNumber))
        {
            var saveFileDialog = new Microsoft.Win32.SaveFileDialog
            {
                Title = GetResource.GetValue<string>("BigData_ExportDialog_Title"),
                DefaultExt = DBbase.DB_ExtFileName,
                Filter = $"{GetResource.GetValue<string>("Caption_ExportDatabaseFilter")}|*{DBbase.DB_ExtFileName}",
                InitialDirectory = DB_BigData.Directory_BigData,
                AddExtension = true,
                OverwritePrompt = true,
                ValidateNames = true,
                FileName = $"{DateTime.Now:yyyyMMdd}_{lotNumber}",
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                using var conn = SQLiteHelper.OpenConnection(saveFileDialog.FileName);
                if (conn != null)
                {
                    using var tran = conn.BeginTransaction();
                    string errorMsg;
                    try
                    {
                        // 輸入Tray
                        if (!SQLiteHelper.IsTableExist(conn, DB_BigData.TableName_LoadTraySetting))
                            SQLiteHelper.CreateTable(conn, DB_BigData.CreateTableSQL_LoadTraySetting);
                        else
                            _ = conn.DeleteAll<LoadTraySettingDefine>(transaction: tran);
                        _ = conn.Insert(BigDataOutputData.LoadTraySetting, transaction: tran);

                        // 量測成品Tray
                        if (!SQLiteHelper.IsTableExist(conn, DB_BigData.TableName_ProductTraySetting))
                            SQLiteHelper.CreateTable(conn, DB_BigData.CreateTableSQL_ProductTraySetting);
                        else
                            _ = conn.DeleteAll<ProductTraySettingDefine>(transaction: tran);
                        _ = conn.Insert(BigDataOutputData.ProductTraySetting, transaction: tran);

                        // 重工品Tray
                        if (!SQLiteHelper.IsTableExist(conn, DB_BigData.TableName_ReworkTraySetting))
                            SQLiteHelper.CreateTable(conn, DB_BigData.CreateTableSQL_ReworkTraySetting);
                        else
                            _ = conn.DeleteAll<ReworkTraySettingDefine>(transaction: tran);
                        _ = conn.Insert(BigDataOutputData.ReworkTraySetting, transaction: tran);

                        // 規格資料
                        if (!SQLiteHelper.IsTableExist(conn, DB_BigData.TableName_SpecificationSetting))
                            SQLiteHelper.CreateTable(conn, DB_BigData.CreateTableSQL_SpecificationSetting);
                        else
                            _ = conn.DeleteAll<SpecificationDefine>(transaction: tran);
                        _ = conn.Insert(BigDataOutputData.SpecificationSetting, transaction: tran);

                        // 量測成品資料
                        if (!SQLiteHelper.IsTableExist(conn, DB_BigData.TableName_Product))
                            SQLiteHelper.CreateTable(conn, DB_BigData.CreateTableSQL_Product);
                        else
                            _ = conn.DeleteAll<OutputProductDefine>(transaction: tran);
                        _ = conn.Insert(BigDataOutputData.OutputProduct, transaction: tran);

                        // 重工品資料
                        if (!SQLiteHelper.IsTableExist(conn, DB_BigData.TableName_Rework))
                            SQLiteHelper.CreateTable(conn, DB_BigData.CreateTableSQL_Rework);
                        else
                            _ = conn.DeleteAll<OutputReworkDefine>(transaction: tran);
                        _ = conn.Insert(BigDataOutputData.OutputRework, transaction: tran);
                        tran.Commit();
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        errorMsg = $"{GetResource.GetValue<string>("ErrorMessage_BigData_ExportFailure")} -> BigDataViewModel -> ExportBigDataToDb()";
                        Log.Error(ex, errorMsg);
                        _ = _prismMessageBox.Show($"{errorMsg}\n{ex.Message}",
                                                  GetResource.GetValue<string>("ErrorMessage_BigData_DataError_Title"),
                                                  MessageBoxImage.Error);
                        return;
                    }

                    _ = _prismMessageBox.Show(GetResource.GetValue<string>("Message_BigData_ExportFinished"),
                                              GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DatabaseOperation"),
                                              MessageBoxImage.Information);
                }
            }
        }
    }

    /********************
     * Models
     ********************/
    /// <inheritdoc/>
    public List<MeasurementDataDefine> MeasurementDataList
    {
        get { return _wd.MeasurementDataList; }
        set { _wd.MeasurementDataList = value; }
    }

    /// <inheritdoc/>
    public void SetBigDataBrowser(List<MeasurementDataDefine> data,
                                  SortDirection sortDirection,
                                  string lotNumberFilter,
                                  int pageSize)
    {
        _wd.MeasurementDataList = data;
        SetBigDataBrowser(sortDirection, lotNumberFilter, pageSize);
    }

    /// <inheritdoc/>
    public void SetBigDataBrowser(SortDirection sortDirection,
                                  string lotNumberFilter,
                                  int pageSize)
    {
        _ea.GetEvent<LotNumberChangedEvent>().Publish(lotNumberFilter);
        _bd.PageSize = _bd.RowDetailsVisibilityMode
            ? pageSize - BigDataContent.RowDetailHeight
            : pageSize;
        BrowserSortDirection = sortDirection;
    }

    /// <inheritdoc/>
    public SortDirection BrowserSortDirection { get; set; } = SortDirection.Ascending;

    /// <inheritdoc/>
    public void UpdateBrowser(MeasurementDataDefine moveTo)
    {
        if (_wd.MeasurementDataList != null)
        {
            var dataList = _wd.MeasurementDataList.OrderBy(x => x.LotNumber);
            dataList = BrowserSortDirection == SortDirection.Ascending
                ? dataList.OrderBy(x => x.Time)
                : dataList.OrderByDescending(x => x.Time);

            _bd.BigDataCollectionView = CollectionViewSource.GetDefaultView(dataList);
            if (moveTo != null)
                _bd.BigDataCollectionView.MoveCurrentTo(moveTo);
        }
        else
        {
            _bd.BigDataCollectionView = null;
        }
    }

    /// <inheritdoc/>
    public void UpdateBrowser() => UpdateBrowser(null);

    /********************
     * EXCEL檔直接轉檔
     ********************/
    /// <inheritdoc/>
    public void TransToBigData(List<LensSortingDefine> datas)
    {
        if (_wp.ExcelDatas == null)
            return;

        if (_prismMessageBox.ShowOKCancel(GetResource.GetValue<string>("Message_TransToBigData"),
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "Caption_FriendlyReminder"),
                                          MessageBoxImage.Information,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "Button_ContinueOperate"),
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "Button_CancelOperate"))
            != ButtonResult.OK)
            return;

        // 轉換
        var trayFeeder = datas.FindAll(x => x.FunctionName == TrayFunctionType.Feeder);
        var trayClassified = datas.FindAll(x => x.FunctionName == TrayFunctionType.Classified);
        var trayRework = datas.FindAll(x => x.FunctionName == TrayFunctionType.Rework);
        if (trayFeeder.Count == 0 || trayClassified.Count == 0 || trayRework.Count == 0)
        {
            _ = _prismMessageBox.Show("托盤設定數錯誤", MessageBoxImage.Error);
            return;
        }

        int idNo = 0;
        string lotNumber = GetNewLotNumber();
        var now = DateTime.Now;

        SetNewLot();
        //var conn = _wd.ConnMeasurementData;
        using var conn = SQLiteHelper.OpenConnection($"{Path.Combine(DBbase.Directory_Base,
                                                                     DB_WFS.Directory_MeasurementData,
                                                                     $"{lotNumber}{DBbase.DB_ExtFileName}")}");
        using var tran = conn.BeginTransaction();
        try
        {
            foreach (var data in _wp.ExcelDatas)
            {
                WfsGradeDefine grade = GradeJudgement(data);
                var targetTray = grade.Id != -1 ? trayClassified.Find(x => x.GradeId == grade.Id) : trayRework[0];

                var newData = new MeasurementDataDefine()
                {
                    Id = ++idNo,
                    LotNumber = lotNumber,
                    Time = now,
                    Judgement = grade.Id != -1,
                    Grade = grade.Id,
                    GradeName = grade.Id != -1 ? grade.Name : "",

                    LensNumber = data.LensNumber,
                    Decenter = data.Decenter,
                    DecenterX = data.DecenterX,
                    DecenterY = data.DecenterY,
                    Coma = data.Coma,
                    Astigmatism = data.Astigmatism,
                    Spherical = data.Spherical,
                    Trefoil = data.Trefoil,
                    Angle = data.Angle,

                    SourcePalletNo = trayFeeder[0].Id,
                    SourceTrayId = trayFeeder[0].TrayId,
                    SourceTrayName = trayFeeder[0].TrayName,
                    SourcePointNo = 1,
                    TargetPalletNo = targetTray.Id,
                    TargetTrayId = targetTray.TrayId,
                    TargetTrayName = targetTray.TrayName,
                    TargetPointNo = 1,
                };

                _ = conn.InsertAsync(newData, transaction: tran);
                _wd.MeasurementDataList.Insert(0, newData);
            }
            tran.Commit();
            _ = _prismMessageBox.Show($"量測數據轉換完成，\n請轉至大數據頁面，選擇批號: {lotNumber}",
                                      "轉換完成",
                                      MessageBoxImage.Information);
        }
        catch
        {
            tran.Rollback();
        }
    }
}
