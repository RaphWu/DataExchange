﻿using Glorytek.WFSCore.Models.WFS;
using System.Collections.Generic;

namespace Glorytek.WFSComponents.WFS.Contracts;

/// <summary>
/// 轉角度模式介面。
/// </summary>
public interface IWfs_LensArrange
{
    /// <summary>
    /// 更新關係表。
    /// </summary>
    /// <param name="lensArrangeList">外部導入的資料列表。</param>
    void UpdateRelationList(List<LensArrangeDefine> lensArrangeList);

    /// <summary>
    /// 更新關係表。
    /// </summary>
    void UpdateRelationList();
}
