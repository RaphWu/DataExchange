﻿using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal.WfsMeasuringMachine;

namespace Glorytek.WFSComponents.WFS.Contracts;

/// <summary>
/// 規格判定介面。
/// </summary>
public interface IWfs_Judgement
{
    /// <summary>
    /// 規格判定。
    /// </summary>
    /// <param name="data">待判定量測數據。</param>
    /// <returns>符合的規格<br/>Id=-1: 沒有符合的規格。</returns>
    WfsGradeDefine GradeJudgement(MeasuringMachineDefine data);
}
