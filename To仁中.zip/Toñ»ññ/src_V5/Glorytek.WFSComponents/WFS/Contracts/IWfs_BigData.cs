﻿using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Models.WFS;
using System.Collections.Generic;

namespace Glorytek.WFSComponents.WFS.Contracts;

/// <summary>
/// 大數據處理介面。
/// </summary>
public interface IWfs_BigData
{
    /// <summary>
    /// 從資料庫取得批號資料。
    /// </summary>
    void GetLotNumberDataFromDb(string lotNumber);

    /// <summary>
    /// 從資料庫讀取量測紀錄。
    /// </summary>
    void ReadBigDataFromDb();

    ///// <summary>
    ///// 新增量測紀錄。
    ///// </summary>
    //void InsertMeasurementData(List<MeasurementDataDefine> mdd);

    ///// <summary>
    ///// 清空量測紀錄。
    ///// </summary>
    //void EmptyBigDataList();

    /********************
     * 數據處理
     ********************/
    ///// <summary>
    ///// 
    ///// </summary>
    //void LoadDataFromOnlineMode();

    /// <summary>
    /// 整合量測數據、規格設定、托盤設定至大數據格式。
    /// </summary>
    void IntegrateDataToBigData(List<MeasurementDataDefine> measurementDataList);

    /// <summary>
    /// 大數據資料導出。
    /// </summary>
    /// <param name="lotNumber">導出的批號。</param>
    void ExportBigDataToDb(string lotNumber);

    /********************
     * Browser
     ********************/
    /// <summary>
    /// 本次量測數據。
    /// </summary>
    List<MeasurementDataDefine> MeasurementDataList { get; set; }

    /// <summary>
    /// 設定大數據瀏覽器。
    /// </summary>
    /// <param name="data">輸入的數據。</param> 
    /// <param name="sortDirection">排序方式。</param>
    /// <param name="lotNumberFilter">批號過濾器。</param>
    /// <param name="pageSize">一頁的筆數(不含詳細資訊欄)。</param>
    void SetBigDataBrowser(List<MeasurementDataDefine> data,
                           SortDirection sortDirection,
                           string lotNumberFilter,
                           int pageSize);

    /// <summary>
    /// 設定大數據瀏覽器 (以內部原有數據更新)。
    /// </summary> 
    /// <param name="sortDirection">排序方式。</param>
    /// <param name="lotNumberFilter">批號過濾器。</param>
    /// <param name="pageSize">一頁的筆數(不含詳細資訊欄)。</param>
    void SetBigDataBrowser(SortDirection sortDirection,
                           string lotNumberFilter,
                           int pageSize);

    /// <summary>
    /// 資料排序方式。
    /// </summary>
    SortDirection BrowserSortDirection { get; set; }

    /// <summary>
    /// 更新大數據瀏覽器資料來源。
    /// </summary>
    /// <param name="moveTo">更新後指定檢視中的資料。null表示不移動。</param>
    void UpdateBrowser(MeasurementDataDefine moveTo);

    /// <summary>
    /// 更新大數據瀏覽器資料來源。
    /// </summary>
    void UpdateBrowser();

    /********************
     * EXCEL檔直接轉檔
     ********************/
    /// <summary>
    /// 將指定資料直接轉換成大數據DB。
    /// </summary>
    void TransToBigData(List<LensSortingDefine> datas);
}
