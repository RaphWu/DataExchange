﻿using Glorytek.WFSCore.Models.WFS;

namespace Glorytek.WFSComponents.WFS.Contracts;

/// <summary>
/// 量測資料操作介面。
/// </summary>
public interface IWfs_DataCollection
{
    /********************
     * Database
     ********************/
    /// <summary>
    /// 開啟量測數據資料檔。
    /// </summary>
    /// <param name="dbPathName">資料檔名稱。</param>
    /// <returns>開啟是否成功。</returns>
    bool OpenMeasurementDb(string dbPathName);

    /// <summary>
    /// 關閉量測數據資料檔。
    /// </summary>
    /// <returns>關閉是否成功。</returns>
    bool CloseMeasurementDb();

    /********************
     * Lot Number
     ********************/
    /// <summary>
    /// 檢查批號是否合法。
    /// </summary>
    bool IsLotNumberValid(string lotNumber);

    /// <summary>
    /// 建立新的量測批號。
    /// </summary>
    /// <returns>建立批號是否成功。<br/><see cref="WfsParameters.CurrentLotNumber"/> = 建立的批號。</returns>
    bool SetNewLot();

    /// <summary>
    /// 重置目前的量測批號。
    /// </summary>
    void ResetLot();

    /// <summary>
    /// 取得最後一筆批號。
    /// </summary>
    string GetLastLotNumber();

    /// <summary>
    /// 取得新的批號。
    /// </summary>
    /// <returns>LotNumber。</returns>
    string GetNewLotNumber();

    /********************
     * 檔案資訊
     ********************/
    /// <summary>
    /// 讀取所有量測資料檔列表。
    /// </summary>
    void ReadMeasurementDataFileList();

    /// <summary>
    /// 取得量測資料夾的檔案路徑。
    /// </summary>
    string GetMeasurementDataFullFileName(string lotNumber);
}
