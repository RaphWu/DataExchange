﻿using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.WFS;
using System.Collections.Generic;

namespace Glorytek.WFSComponents.WFS.Contracts;

/// <summary>
/// WFS量測與大數據處理介面。
/// </summary>
public interface IWfs : IWfs_DataCollection, IWfs_Tray, IWfs_BigData, IWfs_Judgement, IWfs_LensArrange
{
    /********************
     * Database
     ********************/
    /// <summary>
    /// 儲存WFS資料至資料庫。
    /// </summary>
    /// <returns>寫入成功=true。</returns>
    bool WriteToDb();

    /// <summary>
    /// 儲存WFS資料名稱列表。
    /// </summary>
    /// <returns>寫入成功=true。</returns>
    bool WriteDataNameListToDb();

    /// <summary>
    /// 儲存WFS規格列表。
    /// </summary>
    /// <returns>寫入成功=true。</returns>
    bool WriteSpecificationToDb();

    /// <summary>
    /// 從資料庫讀取WFS資料。
    /// </summary>
    /// <returns>是否讀取成功。</returns>
    bool ReadFromDb();

    //// 系統模式切換、參數修改後
    ///// <summary>
    ///// 以WFS資料更新UI及PLC
    ///// </summary>
    //void LoadData();

    /********************
     * 作業條件檢查 & 參數寫入PLC
     ********************/
    /// <summary>
    /// 使用Model資料執行作業條件檢查。
    /// </summary>
    /// <param name="writeToPlc">若參數正確時，是否要寫入PLC。</param>
    /// <returns>檢查通過=true。</returns>
    bool ConditionCheckAndWriteToPlc(bool writeToPlc);

    /// <summary>
    /// 使用外部傳入的資料執行作業條件檢查。
    /// </summary>
    /// <param name="writeToPlc">若參數正確時，是否要寫入PLC。</param>
    /// <param name="lensSortingData">LensSorting資料。</param>
    /// <returns>檢查通過=true。</returns>
    bool ConditionCheckAndWriteToPlc(bool writeToPlc, List<LensSortingDefine> lensSortingData);

    /// <summary>
    /// 使用外部傳入的資料執行作業條件檢查。
    /// </summary>
    /// <param name="writeToPlc">若參數正確時，是否要寫入PLC。</param>
    /// <param name="lensArrangeData">LensArrange資料。</param>
    /// <returns>檢查通過=true。</returns>
    bool ConditionCheckAndWriteToPlc(bool writeToPlc, List<LensArrangeDefine> lensArrangeData);

    /// <summary>
    /// 使用外部傳入的資料執行作業條件檢查 (TrayToA1模式專用)。
    /// </summary>
    /// <param name="writeToPlc">若參數正確時，是否要寫入PLC。</param>
    /// <param name="trayId">Tray ID。</param>
    /// <returns>檢查通過=true。</returns>
    bool ConditionCheckAndWriteToPlc(bool writeToPlc, int trayId);

    /********************
     * 自動作業
     ********************/
    /// <summary>
    /// 開始此批號的資料收集。
    /// </summary>
    bool StartDataCollection();

    /// <summary>
    /// 姞束此批號的資料收集。
    /// </summary>
    void StopDataCollection();

    /********************
     * 取得物件
     ********************/
    /// <summary>
    /// 參數名稱列表。
    /// </summary>
    List<WfsDataNameListDefine> DataNameList { get; set; }

    /// <summary>
    /// 等級列表。
    /// </summary>
    List<WfsGradeDefine> GradeList { get; set; }

    /// <summary>
    /// 規格列表。
    /// </summary>
    List<WfsSpecificationDefine> SpecificationList { get; set; }

    /// <summary>
    /// 連線/分料Pallet排列。
    /// </summary>
    List<LensSortingDefine> LensSortingList { get; set; }

    /// <summary>
    /// 轉角度Pallet排列。
    /// </summary>
    List<LensArrangeDefine> LensArrangeList { get; set; }

    /********************
     * functions
     ********************/
    /// <summary>
    /// 讀取規格等級選擇清單。
    /// </summary>
    Dictionary<int, string> GradeSelector(bool includeUnused = false);

    /********************
     * Grade
     ********************/
    /// <summary>
    /// 新建等級。
    /// </summary>
    /// <param name="crudInfo">CRUD資料。</param>
    /// <returns>等級ID。</returns>
    int CreateNewGrade(CrudInfo crudInfo);

    /// <summary>
    /// 變更等級名稱。
    /// </summary>
    /// <param name="crudInfo">CRUD資料。</param>
    /// <returns>更名是否成功。</returns>
    bool RenameGradeName(CrudInfo crudInfo);

    /// <summary>
    /// 刪除等級。
    /// </summary>
    /// <param name="gradeId">等級ID。</param>
    /// <returns>刪除是否成功。</returns>
    bool DeleteGrade(int gradeId);

    /********************
     * Specification
     ********************/
    /// <summary>
    /// 新建規格。
    /// </summary>
    /// <param name="gradeId">等級ID。</param>
    /// <returns>規格ID。</returns>
    int CreateNewSpecification(int gradeId);

    /// <summary>
    /// 刪除規格。
    /// </summary>
    /// <param name="specId">規格ID。</param>
    /// <returns>。</returns>
    bool DeleteSpecification(int specId);

    /********************
     * 量測機
     ********************/
    /// <summary>
    /// 不執行規格檢查。(功能暫時移除)
    /// </summary>
    bool DoNotCheckSpecification { get; }
}
