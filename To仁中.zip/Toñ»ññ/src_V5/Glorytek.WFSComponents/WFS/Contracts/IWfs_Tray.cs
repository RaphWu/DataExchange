﻿using Glorytek.WFSCore.Models.Tray;

namespace Glorytek.WFSComponents.WFS.Contracts;

/// <summary>
/// Tray作業介面。
/// </summary>
public interface IWfs_Tray
{
    /// <summary>
    /// 取得Tray。
    /// </summary>
    /// <param name="palletId">欲取得的Tray ID。</param>
    /// <param name="tray">取得的Tray。</param>
    /// <returns>取得是否完成。若為false，表示取得的Tray為null。</returns>
    bool GetTray(int palletId, out TrayDefine tray);

    /// <summary>
    /// 取得Tray。
    /// </summary>
    /// <param name="palletId">欲取得的Tray ID。</param>
    /// <returns>取得是否完成。若為false，表示取得的Tray為null。</returns>
    TrayDefine GetTray(int palletId);

    /// <summary>
    /// 取得指定Pallet的點位資料。
    /// </summary>
    /// <param name="palletId">Pallet ID。</param>
    /// <returns>(點位序號, 取放點編號)。</returns>
    (int CurrentPointNo, int CurrentSequenceNo) GetCurrentNo(int palletId);
}
