﻿using System.Collections.Generic;

namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據導出用資料。
/// </summary>
internal class BigDataOutputData
{
    /// <summary>
    /// 大數據入料Tray。
    /// </summary>
    internal static List<LoadTraySettingDefine> LoadTraySetting { get; set; }

    /// <summary>
    /// 大數據量測成品Tray。
    /// </summary>
    internal static List<ProductTraySettingDefine> ProductTraySetting { get; set; }

    /// <summary>
    /// 大數據重工品Tray。
    /// </summary>
    internal static List<ReworkTraySettingDefine> ReworkTraySetting { get; set; }

    /// <summary>
    /// 大數據規格。
    /// </summary>
    internal static List<SpecificationDefine> SpecificationSetting { get; set; }

    /// <summary>
    /// 大數據量測成品。
    /// </summary>
    internal static List<OutputProductDefine> OutputProduct { get; set; }

    /// <summary>
    /// 大數據量測重工品。
    /// </summary>
    internal static List<OutputReworkDefine> OutputRework { get; set; }
}
