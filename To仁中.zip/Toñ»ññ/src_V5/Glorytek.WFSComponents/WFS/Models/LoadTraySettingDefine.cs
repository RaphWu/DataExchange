﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSComponents.WFS.Constants;
using Glorytek.WFSCore.Models.WFS;

namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據入料Tray資料庫定義。
/// </summary>
[Table(DB_BigData.TableName_LoadTraySetting)]
public class LoadTraySettingDefine : TraySettingDefine
{
    /// <inheritdoc/>
    [ExplicitKey]
    public override int TrayId { get; set; }
    /// <inheritdoc/>
    public override string Barcode { get; set; }
    /// <inheritdoc/>
    public override int PalletNo { get; set; }

    /// <summary>
    /// 來源Tray名稱。
    /// </summary>
    public string TrayName { get; set; }
}
