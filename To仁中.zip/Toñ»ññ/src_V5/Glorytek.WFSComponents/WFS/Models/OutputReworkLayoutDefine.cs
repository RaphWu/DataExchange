﻿namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據量測重工品Query用資料。
/// </summary>
public class OutputReworkLayoutDefine : OutputReworkDefine
{
    /// <summary>
    /// 放置Tray的名稱。
    /// </summary>
    public string TargetTrayName { get; set; }

    /// <summary>
    /// 來源Tray的名稱。
    /// </summary>
    public string SourceTrayName { get; set; }
}
