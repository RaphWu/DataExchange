﻿namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據量測成品Query用資料。
/// </summary>
public class OutputProductLayoutDefine : OutputProductDefine
{
    /// <summary>
    /// 此鏡片的量測規格名稱。
    /// </summary>
    public string GradeName { get; set; }

    /// <summary>
    /// 放置Tray的名稱。
    /// </summary>
    public string TargetTrayName { get; set; }

    /// <summary>
    /// 來源Tray的名稱。
    /// </summary>
    public string SourceTrayName { get; set; }
}
