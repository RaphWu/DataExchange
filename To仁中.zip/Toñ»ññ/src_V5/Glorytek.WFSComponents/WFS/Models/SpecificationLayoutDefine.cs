﻿using Glorytek.WFSCore.Constants.WFS;

namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據規格Query用資料。
/// </summary>
public class SpecificationLayoutDefine : SpecificationDefine
{
    /// <summary>
    /// 運算式為二元運算式。
    /// </summary>
    public bool BinaryOperator => RelationType == InequalityRelationType.Between || RelationType == InequalityRelationType.NotBetween;

    /// <summary>
    /// 運算式為一元運算式。
    /// </summary>
    public bool UnaryOperator => !BinaryOperator;
}
