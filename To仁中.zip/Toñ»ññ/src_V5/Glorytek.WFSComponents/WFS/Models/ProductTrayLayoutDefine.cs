﻿namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據量測成品Tray Query用資料。
/// </summary>
public class ProductTrayLayoutDefine : ProductTraySettingDefine
{
    /// <summary>
    /// 此鏡片的量測規格名稱。
    /// </summary>
    public string GradeName { get; set; }
}