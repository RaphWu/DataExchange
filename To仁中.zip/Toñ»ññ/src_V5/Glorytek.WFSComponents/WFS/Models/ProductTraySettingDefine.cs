﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSComponents.WFS.Constants;
using Glorytek.WFSCore.Models.WFS;

namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據量測成品Tray資料庫定義。
/// </summary>
[Table(DB_BigData.TableName_ProductTraySetting)]
public class ProductTraySettingDefine : TraySettingDefine
{
    /// <inheritdoc/>
    public override int TrayId { get; set; }
    /// <inheritdoc/>
    public override string Barcode { get; set; }
    /// <inheritdoc/>
    public override int PalletNo { get; set; }

    /// <summary>
    /// 來源Tray名稱。
    /// </summary>
    public string TrayName { get; set; }

    /// <summary>
    /// 此鏡片的量測規格ID。
    /// </summary>
    public int GradeId { get; set; }
}
