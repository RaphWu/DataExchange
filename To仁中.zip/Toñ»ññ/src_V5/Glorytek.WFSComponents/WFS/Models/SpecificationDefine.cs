﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSCore.Constants.WFS;

namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據規格資料庫定義。
/// </summary>
[Table(DB_BigData.TableName_SpecificationSetting)]
public class SpecificationDefine
{
    /// <summary>
    /// 此鏡片的量測規格ID。
    /// </summary>
    public int GradeId { get; set; }

    /// <summary>
    /// 此鏡片的量測規格名稱。
    /// </summary>
    public string GradeName { get; set; }

    /// <summary>
    /// 光學參數名稱。
    /// </summary>
    public string DataName { get; set; }

    /// <summary>
    /// 闗係式ID。
    /// </summary>
    public string Relation { get; set; }

    /// <summary>
    /// 闗係式。
    /// </summary>
    [Computed]
    public InequalityRelationType RelationType { get; set; }

    /// <summary>
    /// 一元運算式的比較值。
    /// </summary>
    public double Value { get; set; }

    /// <summary>
    /// 二元運算式小於側的比較值。
    /// </summary>
    public double Value1 { get; set; }

    /// <summary>
    /// 二元運算式大於側的比較值。
    /// </summary>
    public double Value2 { get; set; }
}
