﻿using System;

namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據資料定義 - 產出Tray資料的抽象類。
/// </summary>
public abstract class OutputTrayDefine
{
    /// <summary>
    /// SQLite Index。
    /// </summary>
    public abstract int RowId { get; set; }

    /// <summary>
    /// 批號。
    /// </summary>
    public abstract string LotNumber { get; set; }

    /// <summary>
    /// 資料時間。
    /// </summary>
    public abstract DateTime Time { get; set; }

    /// <summary>
    /// 條碼。
    /// </summary>
    public abstract string Barcode { get; set; }

    /// <summary>
    /// 放置Tray的ID。
    /// </summary>
    public abstract int TrayId { get; set; }

    /// <summary>
    /// 放置Tray的點位X座標。
    /// </summary>
    public abstract int X { get; set; }

    /// <summary>
    /// 放置Tray的點位Y座標。
    /// </summary>
    public abstract int Y { get; set; }

    /// <summary>
    /// 取料Tray的ID。
    /// </summary>
    public abstract int SourceTrayId { get; set; }

    /// <summary>
    /// 取料Tray的點位X座標。
    /// </summary>
    public abstract int SourceX { get; set; }

    /// <summary>
    /// 取料Tray的點位Y座標。
    /// </summary>
    public abstract int SourceY { get; set; }

    /********************
     * 量測資料(僅正葳需要部分)
     ********************/
    /// <summary>
    /// 偏心值。
    /// </summary>
    public abstract double Decenter { get; set; }

    /// <summary>
    /// 偏心角度。
    /// </summary>
    public abstract double Angle { get; set; }
}
