﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSComponents.WFS.Constants;
using System;

namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據量測成品資料庫定義。
/// </summary>
[Table(DB_BigData.TableName_Product)]
public class OutputProductDefine : OutputTrayDefine
{
    /// <inheritdoc/>
    [Key]
    public override int RowId { get; set; }
    /// <inheritdoc/>
    public override string LotNumber { get; set; }
    /// <inheritdoc/>
    public override DateTime Time { get; set; }
    /// <inheritdoc/>
    public override string Barcode { get; set; }
    /// <inheritdoc/>
    public override int TrayId { get; set; }
    /// <inheritdoc/>
    public override int X { get; set; }
    /// <inheritdoc/>
    public override int Y { get; set; }
    /// <inheritdoc/>
    public override int SourceTrayId { get; set; }
    /// <inheritdoc/>
    public override int SourceX { get; set; }
    /// <inheritdoc/>
    public override int SourceY { get; set; }
    /// <inheritdoc/>
    public override double Decenter { get; set; }
    /// <inheritdoc/>
    public override double Angle { get; set; }

    /// <summary>
    /// 此鏡片的量測規格ID。
    /// </summary>
    public int GradeId { get; set; }
}
