﻿namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據重工品Tray Query用資料。
/// </summary>
public class ReworkTrayLayoutDefine : ReworkTraySettingDefine
{
}
