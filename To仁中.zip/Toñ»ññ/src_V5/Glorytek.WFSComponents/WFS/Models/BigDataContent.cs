﻿using Glorytek.WFSCore.Models.WFS;
using Glorytek.WPF.Helpers;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據瀏覽器資料源及功能函數。
/// </summary>
public class BigDataContent : BindableBase
{
    private BigDataContent() { }
    private static readonly Lazy<BigDataContent> _instance = new(() => new BigDataContent());
    public static BigDataContent Instance => _instance.Value;

    /********************
     * Internal Data
     ********************/
    /// <summary>
    /// 更新瀏覽器參數。
    /// </summary>
    /// <param name="dataList">參數計算資料來源。</param>
    public void UpdateBrowserParameters(List<MeasurementDataDefine> dataList)
    {
        //var tempList = new ObservableSortedDictionary<string, string>(new LotNumberKeyComparer())
        //{
        //    { LotNumberFilterType.ShowNewestLotNumberOnly, "只顯示最新批號" },
        //    { LotNumberFilterType.ShowAllLotNumber, "顯示全部" }
        //};

        List<string> tempList = new();
        if (dataList != null)
        {
            foreach (var item in dataList)
            {
                string lotNum = item.LotNumber;
                if (!tempList.Contains(lotNum))
                    tempList.Add(lotNum);
            }

            LotNumberList = new ObservableCollection<string>(tempList.OrderBy(x => x));
            NewestLotNumber = dataList.Max(x => x.LotNumber);
        }
        else
        {
            LotNumberList.Clear();
            NewestLotNumber = "";
        }
    }

    /// <summary>
    /// 批號ComboBox排序規則。
    /// </summary>
    private class LotNumberKeyComparer : IComparer<DictionaryEntry>
    {
        public int Compare(DictionaryEntry x, DictionaryEntry y)
        {
            return x.Key.ToString().CompareTo(y.Key.ToString());
        }
    }

    /// <summary>
    /// 主顯示資料列表。
    /// </summary>
    public ICollectionView BigDataCollectionView
    {
        get { return _bigDataCollectionView; }
        set
        {
            if (_bigDataCollectionView != null)
            {
                TotalRecord = _bigDataCollectionView.AsList<MeasurementDataDefine>().Count;

                _bigDataCollectionView.CollectionChanged += (o, e) =>
                {
                    TotalRecord = BigDataCollectionView.AsList<MeasurementDataDefine>().Count;
                };

                _bigDataCollectionView.CurrentChanged += (o, e) =>
                {
                    if (_bigDataCollectionView != null && !_bigDataCollectionView.IsEmpty)
                        CurrentRecord = _bigDataCollectionView.CurrentPosition + 1;
                    else
                        CurrentRecord = 0;
                };
            }

            SetProperty(ref _bigDataCollectionView, value);
        }
    }
    private ICollectionView _bigDataCollectionView;

    /// <summary>
    /// 是否顯示導航條。
    /// </summary>
    public bool NavigationBarVisibility
    {
        get { return _navigationBarVisibility; }
        set { SetProperty(ref _navigationBarVisibility, value); }
    }
    private bool _navigationBarVisibility;

    /// <summary>
    /// 是否顯示過濾器。
    /// </summary>
    public bool FilterVisibility
    {
        get { return _filterVisibility; }
        set { SetProperty(ref _filterVisibility, value); }
    }
    private bool _filterVisibility = true;

    /// <summary>
    /// 資料筆數。
    /// </summary>
    public int TotalRecord
    {
        get { return _totalRecord; }
        set { SetProperty(ref _totalRecord, value); }
    }
    private int _totalRecord;

    /// <summary>
    /// 目前紀錄指標。
    /// </summary>
    public int CurrentRecord
    {
        get { return _currentRecord; }
        set
        {
            _currentRecord = value;
            RecordString = $"{_currentRecord} of {TotalRecord}";
        }
    }
    private int _currentRecord;

    /// <summary>
    /// 紀錄顯示。
    /// </summary>
    /// <summary>
    /// 
    /// </summary>
    public string RecordString
    {
        get { return _recordString; }
        set { SetProperty(ref _recordString, value); }
    }
    private string _recordString;

    /********************
     * 批號
     ********************/
    /// <summary>
    /// LotNumber列表。
    /// </summary>
    public ObservableCollection<string> LotNumberList
    {
        get { return _lotNumberList; }
        set { SetProperty(ref _lotNumberList, value); }
    }
    private ObservableCollection<string> _lotNumberList = new();

    /// <summary>
    /// 選擇的LotNumber，由BigDataBrowser維護內容，這裡僅提供讀取值的管道。
    /// </summary>
    public string SelectedLotNumber { get; set; } = string.Empty;

    /// <summary>
    /// 最新的LotNumber。
    /// </summary>
    public string NewestLotNumber
    {
        get { return _newestLotNumber; }
        set { SetProperty(ref _newestLotNumber, value); }
    }
    private string _newestLotNumber;

    ///// <summary>
    ///// Filter - 最新的LotNumber
    ///// </summary>
    //private bool Filter_SelectNewest(object obj)
    //{
    //    var item = obj as MeasurementDataDefine;
    //    return item.LotNumber == NewestLotNumber;
    //}

    ///// <summary>
    ///// Filter - 指定批號
    ///// </summary>
    //private bool Filter_SpecifyLotNumber(object obj)
    //{
    //    var item = obj as MeasurementDataDefine;
    //    return item.LotNumber == SelectedLotNumber;
    //}

    /********************
     * Record Navigation Bar
     ********************/
    /// <summary>
    /// 移動一頁資料筆數。
    /// </summary>
    public int PageSize { get; set; } = 20;

    /// <summary>
    /// RowDetail列數。
    /// </summary>
    public const int RowDetailHeight = 3;

    /// <summary>
    /// 顯示RowDetails。
    /// </summary>
    public bool RowDetailsVisibilityMode
    {
        get { return _rowDetailsVisibilityMode; }
        set
        {
            SetProperty(ref _rowDetailsVisibilityMode, value);

            if (_rowDetailsVisibilityMode)
                PageSize -= RowDetailHeight;
            else
                PageSize += RowDetailHeight;
        }
    }
    private bool _rowDetailsVisibilityMode = false;

    /// <summary>
    /// 移動至第一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToFirstCommand
        => _moveToFirstCommand ??= new DelegateCommand(ExecuteMoveToFirstCommand);
    private void ExecuteMoveToFirstCommand()
    {
        _ = BigDataCollectionView.MoveCurrentToFirst();
    }
    private DelegateCommand _moveToFirstCommand;

    /// <summary>
    /// 移動至最後一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToLastCommand
        => _moveToLastCommand ??= new DelegateCommand(ExecuteMoveToLastCommand);
    private void ExecuteMoveToLastCommand()
    {
        _ = BigDataCollectionView.MoveCurrentToLast();
    }
    private DelegateCommand _moveToLastCommand;

    /// <summary>
    /// 移動至上一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToPreviousCommand
        => _moveToPreviousCommand ??= new DelegateCommand(ExecuteMoveToPreviousCommand);
    private void ExecuteMoveToPreviousCommand()
    {
        _ = BigDataCollectionView.MoveCurrentToPrevious();
        if (BigDataCollectionView.IsCurrentBeforeFirst)
            _ = BigDataCollectionView.MoveCurrentToLast();
    }
    private DelegateCommand _moveToPreviousCommand;

    /// <summary>
    /// 移動至下一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToNextCommand
        => _moveToNextCommand ??= new DelegateCommand(ExecuteMoveToNextCommand);
    private void ExecuteMoveToNextCommand()
    {
        _ = BigDataCollectionView.MoveCurrentToNext();
        if (BigDataCollectionView.IsCurrentAfterLast)
            _ = BigDataCollectionView.MoveCurrentToFirst();
    }
    private DelegateCommand _moveToNextCommand;

    /// <summary>
    /// 移動至上一頁。
    /// </summary>
    public DelegateCommand MoveToPreviousPageCommand
        => _moveToPreviousPageCommand ??= new DelegateCommand(ExecuteMoveToPreviousPageCommand);
    private void ExecuteMoveToPreviousPageCommand()
    {
        try
        {
            _ = BigDataCollectionView.MoveCurrentToPosition(BigDataCollectionView.CurrentPosition - PageSize);
        }
        catch
        {
            _ = BigDataCollectionView.MoveCurrentToFirst();
        }
    }
    private DelegateCommand _moveToPreviousPageCommand;

    /// <summary>
    /// 移動至下一頁。
    /// </summary>
    public DelegateCommand MoveToNextPageCommand
        => _moveToNextPageCommand ??= new DelegateCommand(ExecuteMoveToNextPageCommand);
    private void ExecuteMoveToNextPageCommand()
    {
        try
        {
            _ = BigDataCollectionView.MoveCurrentToPosition(BigDataCollectionView.CurrentPosition + PageSize);
        }
        catch
        {
            _ = BigDataCollectionView.MoveCurrentToLast();
        }
    }
    private DelegateCommand _moveToNextPageCommand;

    /********************
     * 顯示用資料
     ********************/
    /// <summary>
    /// 大數據入料Tray。
    /// </summary>
    public List<LoadTrayLayoutDefine> LoadTrayLayoutList
    {
        get { return _loadTrayLayoutList; }
        set { SetProperty(ref _loadTrayLayoutList, value); }
    }
    private List<LoadTrayLayoutDefine> _loadTrayLayoutList;

    /// <summary>
    /// 大數據量測成品Tray。
    /// </summary>
    public List<ProductTrayLayoutDefine> ProductTrayLayoutList
    {
        get { return _productTrayLayoutList; }
        set { SetProperty(ref _productTrayLayoutList, value); }
    }
    private List<ProductTrayLayoutDefine> _productTrayLayoutList;

    /// <summary>
    /// 大數據重工品Tray。
    /// </summary>
    public List<ReworkTrayLayoutDefine> ReworkTrayLayoutList
    {
        get { return _reworkTrayLayoutList; }
        set { SetProperty(ref _reworkTrayLayoutList, value); }
    }
    private List<ReworkTrayLayoutDefine> _reworkTrayLayoutList;

    /// <summary>
    /// 大數據規格。
    /// </summary>
    public List<SpecificationLayoutDefine> SpecificationLayoutList
    {
        get { return _specificationLayoutList; }
        set { SetProperty(ref _specificationLayoutList, value); }
    }
    private List<SpecificationLayoutDefine> _specificationLayoutList;

    /// <summary>
    /// 大數據量測成品Query用資料。
    /// </summary>
    public List<OutputProductLayoutDefine> ProductLayoutList
    {
        get { return _productLayoutList; }
        set { SetProperty(ref _productLayoutList, value); }
    }
    private List<OutputProductLayoutDefine> _productLayoutList;

    /// <summary>
    /// 大數據量測重工品Query用資料。
    /// </summary>
    public List<OutputReworkLayoutDefine> ReworkLayoutList
    {
        get { return _reworkLayoutList; }
        set { SetProperty(ref _reworkLayoutList, value); }
    }
    private List<OutputReworkLayoutDefine> _reworkLayoutList;
}
