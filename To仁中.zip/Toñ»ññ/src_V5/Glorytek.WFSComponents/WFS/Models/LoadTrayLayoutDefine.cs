﻿namespace Glorytek.WFSComponents.WFS.Models;

/// <summary>
/// 大數據入料Tray Query用資料。
/// </summary>
public class LoadTrayLayoutDefine : LoadTraySettingDefine
{
}
