﻿using Dapper;
using Dapper.Contrib.Extensions;
using Glorytek.SQLite;
using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Stage.Constants;
using Glorytek.WFSComponents.Stage.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models.Stage;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism.Events;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Glorytek.WFSComponents.Stage.Services;

/// <summary>
/// Stage處理Service。
/// </summary>
public class StageService : IStage
{
    /// <summary>
    /// 實驗功能: DB是否需要同步。
    /// </summary>
    /// <remarks>若偵測到參數有變動需要寫入DB時為treu。</remarks>
    private static bool _dbNeedToSync = false;

    private readonly StageDatas _sd = StageDatas.Instance;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly IProductManager _pm;
    private readonly IPlc _plc;

    public StageService(IEventAggregator ea,
                        IPrismMessageBox prismMessageBox,
                        IProductManager pm,
                        IPlc plc)
    {
        _ea = ea;
        _prismMessageBox = prismMessageBox;
        _pm = pm;
        _plc = plc;
    }

    /********************
     * Get Instant
     ********************/
    /// <inheritdoc/>
    public List<StageDefine> Stages
    {
        get { return _sd.Stages; }
        set { _sd.Stages = value; }
    }

    /// <inheritdoc/>
    public StageDefine StageA1
    {
        get { return _sd.Stages.Find(x => x.Id == 1); }
        set
        {
            var stage = _sd.Stages.Find(x => x.Id == 1);
            stage = value;
        }
    }

    /// <inheritdoc/>
    public StageDefine StageA2
    {
        get { return _sd.Stages.Find(x => x.Id == 2); }
        set
        {
            var stage = _sd.Stages.Find(x => x.Id == 2);
            stage = value;
        }
    }

    /********************
     * System
     ********************/
    /// <summary>
    /// 模組初始化。
    /// </summary>
    internal void ModuleInit()
    {
        _ea.GetEvent<OnProductChangeover1>().Subscribe(OnProductChangeover1, true);
        _ea.GetEvent<OnProductChangeover2>().Subscribe(OnProductChangeover2, true);
    }

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public bool WriteToDb()
    {
        string errorMsg;
        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using (var tran = conn.BeginTransaction())
        {
            try
            {
                _ = conn.UpdateAsync(_sd.Stages, transaction: tran);
                tran.Commit();
                WriteToPlc();
            }
            catch (Exception ex)
            {
                tran.Rollback();
                errorMsg = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FailedToWriteDatabase");
                Log.Fatal(ex, errorMsg);
                _ = _prismMessageBox.Show(errorMsg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                          MessageBoxImage.Error);
                return false;
            }
        }

        _dbNeedToSync = false;
        return true;
    }

    /// <inheritdoc/>
    public bool ReadFromDb()
    {
        string errorMsg;
        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using (var tran = conn.BeginTransaction())
        {
            try
            {
                if (!SQLiteHelper.IsTableExist(conn, DB_Stage.TableName_Stage))
                {
                    SQLiteHelper.CreateTable(conn, DB_Stage.CreateTableSQL_Stage);

                    // 目前暫時是寫死只有2個Stages
                    string sql = $@"INSERT INTO {DB_Stage.TableName_Stage} (Id) VALUES (@Id);";
                    conn.Execute(sql, new { Id = 1 }, transaction: tran);
                    conn.Execute(sql, new { Id = 2 }, transaction: tran);
                }
                _sd.Stages = conn.GetAll<StageDefine>(transaction: tran).ToList();
                tran.Commit();
            }
            catch (Exception ex)
            {
                tran.Rollback();
                errorMsg = GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FailedToReadDatabase");
                Log.Fatal(ex, errorMsg);
                _ = _prismMessageBox.Show(errorMsg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                          MessageBoxImage.Error);
                return false;
            }
        }

        _dbNeedToSync = false;
        return true;
    }

    /********************
     * PLC
     ********************/
    /// <inheritdoc/>
    public bool ReadFromPlc()
    {
        if (_sd.Stages == null || _sd.Stages.Count == 0)
            return false;

        // D20066~D20076
        var (D20066OK, D20066) = _plc.ReadDoubleByInt32(DeviceLists.STAGE_1_X, 6);
        if (D20066OK)
        {
            StageA1.CoorX = D20066[0];
            StageA1.CoorY = D20066[1];
            StageA1.CoorZ = D20066[2];
            StageA2.CoorX = D20066[3];
            StageA2.CoorY = D20066[4];
            StageA2.CoorZ = D20066[5];
        }

        // D20150
        var (D20150OK, D20150) = _plc.ReadDoubleByInt32(DeviceLists.STAGE_1_Z_OFFSET);
        if (D20150OK)
            StageA1.ZOffset = D20150;

        // D20154                                                    
        var (D20154OK, D20154) = _plc.ReadDoubleByInt32(DeviceLists.STAGE_2_Z_OFFSET);
        if (D20154OK)
            StageA2.ZOffset = D20154;

        // D20751~D20754
        var (D20751OK, D20751) = _plc.ReadInt16(DeviceLists.STAGE_1_SlowDown, 4);
        if (D20751OK)
        {
            StageA1.SpeedRateWhenDown = D20751[0];
            StageA1.SpeedRateWhenUp = D20751[1];
            StageA2.SpeedRateWhenDown = D20751[2];
            StageA2.SpeedRateWhenUp = D20751[3];
        }

        // D20604~D20605
        var (D20604OK, D20604) = _plc.ReadInt16(DeviceLists.STAGE_1_VISION_ID, 2);
        if (D20604OK)
        {
            StageA1.VisionId = D20604[0];
            StageA2.VisionId = D20604[1];
        }

        _dbNeedToSync = true;
        return true;
    }

    /// <inheritdoc/>
    public void WriteToPlc()
    {
        if (_sd.Stages == null || _sd.Stages.Count == 0)
            return;

        if (_plc.Online)
        {
            // D20066~D20076
            _plc.WriteDoubleByInt32(DeviceLists.STAGE_1_X, new double[]
            {
                    StageA1.CoorX, StageA1.CoorY, StageA1.CoorZ,
                    StageA2.CoorX, StageA2.CoorY, StageA2.CoorZ,
            });

            // D20150
            _plc.WriteDoubleByInt32(DeviceLists.STAGE_1_Z_OFFSET, StageA1.ZOffset);
            // D20154
            _plc.WriteDoubleByInt32(DeviceLists.STAGE_2_Z_OFFSET, StageA2.ZOffset);

            // D20751~D20754
            _plc.WriteInt16(DeviceLists.STAGE_1_SlowDown, new short[]
            {
                    StageA1.SpeedRateWhenDown, StageA1.SpeedRateWhenUp,
                    StageA2.SpeedRateWhenDown, StageA2.SpeedRateWhenUp
            });

            // D20604~D20605
            _plc.WriteInt16(DeviceLists.STAGE_1_VISION_ID, new short[]
            {
                    (short)StageA1.VisionId,
                    (short)StageA2.VisionId
            });
        }
    }

    /********************
     * 品種更換事件
     ********************/
    /// <summary>
    /// 第一階段品種切換。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    private void OnProductChangeover1(string productName)
    {
        if (ReadFromDb())
            if ((StageA1.CoorX + StageA1.CoorY == 0.0) || (StageA2.CoorX + StageA2.CoorY == 0.0))
            {
                ReadFromPlc();
                _dbNeedToSync = true;
            }
        _pm.Datas.ProductChangedRunning_Stage = false;
    }

    /// <summary>
    /// 第二階段品種切換。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    private void OnProductChangeover2(string productName)
    {
        if (productName != "")
            WriteToPlc();

        if (_dbNeedToSync)
            WriteToDb();

        _pm.Datas.ProductChangedRunning_Stage = false;
    }
}
