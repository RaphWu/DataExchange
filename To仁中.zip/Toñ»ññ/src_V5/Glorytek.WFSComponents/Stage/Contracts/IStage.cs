﻿using Glorytek.WFSCore.Models.Stage;
using System.Collections.Generic;

namespace Glorytek.WFSComponents.Stage.Contracts;

/// <summary>
/// Stage處理介面。
/// </summary>
public interface IStage
{
    /// <summary>
    /// Stage列表。
    /// </summary>
    List<StageDefine> Stages { get; set; }

    /// <summary>
    /// Stage A1。
    /// </summary>
    StageDefine StageA1 { get; set; }

    /// <summary>
    /// Stage A2。
    /// </summary>
    StageDefine StageA2 { get; set; }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 將Model資料寫入資料庫。
    /// </summary>
    bool WriteToDb();

    /// <summary>
    /// 從資料庫讀取資料至Model。
    /// </summary>
    bool ReadFromDb();

    /// <summary>
    /// 寫入Stage參數到PLC。
    /// </summary>
    void WriteToPlc();
}
