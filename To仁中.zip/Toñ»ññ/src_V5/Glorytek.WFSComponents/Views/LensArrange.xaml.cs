﻿using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for LensArrange
    /// </summary>
    public partial class LensArrange : UserControl
    {
        public LensArrange(IRegionManager regionManager)
        {
            InitializeComponent();
            regionManager.RegisterViewWithRegion(RegionNames.TrayMatrixRegionInArrange, typeof(TrayMatrix));
        }
    }
}
