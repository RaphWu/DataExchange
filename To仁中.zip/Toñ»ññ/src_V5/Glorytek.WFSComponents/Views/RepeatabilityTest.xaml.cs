﻿using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for RepeatabilityTest
    /// </summary>
    public partial class RepeatabilityTest : UserControl
    {
        public RepeatabilityTest()
        {
            InitializeComponent();
        }
    }
}
