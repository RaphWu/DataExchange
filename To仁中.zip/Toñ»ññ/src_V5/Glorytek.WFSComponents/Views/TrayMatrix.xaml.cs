﻿using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSComponents.ViewModels;
using Prism.Common;
using Prism.Regions;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for TrayMatrix
    /// </summary>
    public partial class TrayMatrix : UserControl
    {
        public TrayMatrix()
        {
            InitializeComponent();
            RegionContext.GetObservableContext(this).PropertyChanged += ThisTray_PropertyChanged;
        }

        private void ThisTray_PropertyChanged(object sender, PropertyChangedEventArgs args)
        {
            if (args.PropertyName == "Value")
            {
                // 如果 TrayMatrixSource 是 null 或與原本值一樣時，PropertyChanged 不會觸發，(內部機制？)
                // 由於 TrayMatrix 有多個 Region 共用，若沒觸發時會殘留上一個 Region 的 View，
                // 故在 Region Navigation 時，切換兩次 TrayMatrixSource 的值，以強迫觸發更新，(尚未找到更好辦法)
                // 一次是 null，一次是空 TrayDefine 物件，所以 sourceContext 有兩種狀態要判斷。
                // 後遺症是 Profile、Mask、Blocks 及 TrayMatrix 會多1~2次無用的計算。
                if (sender is ObservableObject<object> context && context.Value is TrayMatrixRegionContext sourceContext)
                {
                    (DataContext as TrayMatrixViewModel).SourceData =
                        sourceContext.Tray != null && sourceContext.Tray.Id > 0 && sourceContext.PalletId > 0
                            ? sourceContext
                            : null;
                }
                else
                {
                    (DataContext as TrayMatrixViewModel).SourceData = null;
                }
            }
        }

        private void actualContent_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            zoomAndPanControl.AnimatedZoomToCentered(zoomAndPanControl.InternalViewportZoom);
        }
    }
}
