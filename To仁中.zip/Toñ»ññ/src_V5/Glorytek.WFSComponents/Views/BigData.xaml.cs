﻿using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for BigData
    /// </summary>
    public partial class BigData : UserControl
    {
        public BigData(RegionManager regionManager)
        {
            InitializeComponent();
            _ = regionManager.RegisterViewWithRegion(RegionNames.BigDataBrowser, typeof(BigDataBrowser));
        }
    }
}
