﻿using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for Teaching
    /// </summary>
    public partial class Teaching : UserControl
    {
        public Teaching(IRegionManager regionManager)
        {
            InitializeComponent();
            regionManager.RegisterViewWithRegion(RegionNames.RepeatabilityTest, typeof(RepeatabilityTest));
        }
    }
}
