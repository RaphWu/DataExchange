﻿using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for SystemSetting
    /// </summary>
    public partial class SystemSetting : UserControl
    {
        public SystemSetting()
        {
            InitializeComponent();
        }
    }
}
