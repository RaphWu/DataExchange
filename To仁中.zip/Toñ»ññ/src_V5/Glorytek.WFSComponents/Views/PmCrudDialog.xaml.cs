﻿using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for PmCrudDialog
    /// </summary>
    public partial class PmCrudDialog : UserControl
    {
        public PmCrudDialog()
        {
            InitializeComponent();
        }
    }
}
