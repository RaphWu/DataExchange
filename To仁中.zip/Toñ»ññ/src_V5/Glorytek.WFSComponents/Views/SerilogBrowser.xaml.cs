﻿using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for SerilogBrowser
    /// </summary>
    public partial class SerilogBrowser : UserControl
    {
        public SerilogBrowser()
        {
            InitializeComponent();
        }
    }
}
