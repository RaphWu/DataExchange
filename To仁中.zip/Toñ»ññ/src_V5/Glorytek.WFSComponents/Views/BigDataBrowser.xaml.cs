﻿using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for BigDataBrowser
    /// </summary>
    public partial class BigDataBrowser : UserControl
    {
        public BigDataBrowser()
        {
            InitializeComponent();
        }
    }
}
