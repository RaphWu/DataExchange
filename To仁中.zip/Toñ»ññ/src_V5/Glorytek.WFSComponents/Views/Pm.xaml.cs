﻿using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for Pm
    /// </summary>
    public partial class Pm : UserControl
    {
        public Pm()
        {
            InitializeComponent();
        }
    }
}
