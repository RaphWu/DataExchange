﻿using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for LensSorting
    /// </summary>
    public partial class LensSorting : UserControl
    {
        public LensSorting(IRegionManager regionManager)
        {
            InitializeComponent();
            regionManager.RegisterViewWithRegion(RegionNames.TrayMatrixRegionInSorting, typeof(TrayMatrix));
        }
    }
}
