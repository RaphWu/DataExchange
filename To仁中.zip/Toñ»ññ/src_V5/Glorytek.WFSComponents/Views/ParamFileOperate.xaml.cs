﻿using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for ParamFileOperate
    /// </summary>
    public partial class ParamFileOperate : UserControl
    {
        public ParamFileOperate()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 選擇全部。
        /// </summary>
        private void SelectAllCommand(object sender, System.Windows.RoutedEventArgs e)
        {
            exportFileList.SelectAll();
        }

        /// <summary>
        /// 取消全部。
        /// </summary>
        private void UnselectAllCommand(object sender, System.Windows.RoutedEventArgs e)
        {
            exportFileList.UnselectAll();
        }
    }
}
