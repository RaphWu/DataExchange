﻿using Glorytek.WFSCore.Constants;
using Prism.Regions;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for Tray
    /// </summary>
    public partial class Tray : UserControl
    {
        public Tray(IRegionManager regionManager)
        {
            InitializeComponent();
            _ = regionManager.RegisterViewWithRegion(RegionNames.TrayMatrix, typeof(TrayMatrix));
        }
    }
}
