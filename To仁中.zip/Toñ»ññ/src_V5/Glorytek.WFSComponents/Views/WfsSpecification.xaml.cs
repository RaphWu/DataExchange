﻿using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for WfsSpecification
    /// </summary>
    public partial class WfsSpecification : UserControl
    {
        public WfsSpecification()
        {
            InitializeComponent();
        }
    }
}
