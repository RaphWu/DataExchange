﻿using System.Windows;
using System.Windows.Controls;

namespace Glorytek.WFSComponents.Views
{
    /// <summary>
    /// Interaction logic for TrayMatrixSelector
    /// </summary>
    public partial class TrayMatrixSelector : UserControl
    {
        public TrayMatrixSelector()
        {
            InitializeComponent();
        }

        private void actualContent_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            zoomAndPanControl.AnimatedZoomToCentered(zoomAndPanControl.InternalViewportZoom);
        }
    }
}
