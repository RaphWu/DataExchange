﻿using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSCore.Models.System;
using Glorytek.WFSExternal;
using Glorytek.WFSExternal.PLC.Contracts;

namespace Glorytek.WFSComponents.Systems.Services;

/// <summary>
/// 機台硬體參數處理Service。
/// </summary>
public class MachineService : IMachine
{
    /********************
     * ctor
     ********************/
    private readonly IPlc _plc;

    public MachineService(IPlc plc)
    {
        _plc = plc;
    }

    /********************
     * Get Instants
     ********************/
    /// <inheritdoc/>
    public MachineDefine Machine => SysParameters.Instance.Machine;

    /********************
     * System
     ********************/
    /// <summary>
    /// 模組初始化。
    /// </summary>
    internal void ModuleInit()
    {
        ReadFromPlc();
    }

    /********************
     * Database
     * Machine的參數不跟隨品種而變更，所以只存於PLC，不存於Database
     ********************/
    /// <inheritdoc/>
    public void WriteToPlc()
    {
        if (_plc.Online)
        {
            var machine = SysParameters.Instance.Machine;

            // D20030~D20048
            _ = _plc.WriteDoubleByInt32(DeviceLists.DATUM_POINT_X, new double[]
            {
                machine.DatumPointX,
                machine.DatumPointY,
                machine.DatumPointCameraZ,
                machine.NozzleStampX,
                machine.NozzleStampY,
                machine.NozzleStampZ,
                machine.ClayTableX,
                machine.ClayTableY,
                machine.ClayTableZ,
                machine.NozzleStampR
            });

            //// D20080~D20082
            //_plc.WriteDoubleByInt32(_DISTANCE_FROM_NOZZLE_TO_CAMERA_X,
            //    machine.DistanceFromNozzleToCameraX, machine.DistanceFromNozzleToCameraY);

            // D20084~D20086
            _ = _plc.WriteDoubleByInt32(DeviceLists.SAFETY_X, new double[]
            {
                machine.SafetyX,
                machine.SafetyY,
            });

            // D20090~D20102
            _ = _plc.WriteDoubleByInt32(DeviceLists.DATUM_POINT_Z, new double[]
            {
                machine.DatumPointZ,
                machine.RAxisZeroDegreeCorrection,
                machine.LastMeasureHeight,
                machine.HeightCorrection,
                machine.DisplacementX,
                machine.DisplacementY,
                machine.DisplacementZ,
            });

            // D20601~D20602
            _ = _plc.WriteInt16(DeviceLists.DATUM_POINT_VISION_ID, new short[]
            {
                machine.DatumPointVisionId,
                machine.ClayTableVisionId,
            });

            // D20606
            _ = _plc.WriteInt16(DeviceLists.PALLET_DATUM_VISION_ID, machine.PalletDpVisionId);

            // D20610
            _ = _plc.WriteDoubleByInt32(DeviceLists.SAFETY_HEIGHT, machine.SafetyHeight);

            // D20750~D20754
            _ = _plc.WriteInt16(DeviceLists.OVERALL_SPEED, machine.OverallSpeed);
        }
    }

    /// <inheritdoc/>
    public bool ReadFromPlc()
    {
        if (_plc.Online)
        {
            var machine = SysParameters.Instance.Machine;

            // D20030~D20048 
            var (D20030OK, D20030) = _plc.ReadDoubleByInt32(DeviceLists.DATUM_POINT_X, 10);
            if (D20030OK)
            {
                machine.DatumPointX = D20030[0];        // D20030
                machine.DatumPointY = D20030[1];        // D20032
                machine.DatumPointCameraZ = D20030[2];  // D20034 
                machine.NozzleStampX = D20030[3];       // D20036
                machine.NozzleStampY = D20030[4];       // D20038
                machine.NozzleStampZ = D20030[5];       // D20040
                machine.ClayTableX = D20030[6];         // D20042
                machine.ClayTableY = D20030[7];         // D20044
                machine.ClayTableZ = D20030[8];         // D20046
                machine.NozzleStampR = D20030[9];       // D20048
            }

            //// D20080~D20082
            //double[] data3 = _plc.ReadDoubleFromPlcDWord(_DISTANCE_FROM_NOZZLE_TO_CAMERA_X, 2);
            //machine.DistanceFromNozzleToCameraX = data3[0];
            //machine.DistanceFromNozzleToCameraY = data3[1];

            // D20084~D20102
            var (D20084OK, D20084) = _plc.ReadDoubleByInt32(DeviceLists.SAFETY_X, 10);
            if (D20084OK)
            {
                machine.SafetyX = D20084[0];                    // D20084
                machine.SafetyY = D20084[1];                    // D20086
                                                                // D20088
                machine.DatumPointZ = D20084[3];                // D20090
                machine.RAxisZeroDegreeCorrection = D20084[4];  // D20092
                machine.LastMeasureHeight = D20084[5];          // D20094
                machine.HeightCorrection = D20084[6];           // D20096
                machine.DisplacementX = D20084[7];              // D20098
                machine.DisplacementY = D20084[8];              // D20100
                machine.DisplacementZ = D20084[9];              // D20102
            }

            // D20601~D20606
            var (D20601OK, D20601) = _plc.ReadInt16(DeviceLists.DATUM_POINT_VISION_ID, 6);
            if (D20601OK)
            {
                machine.DatumPointVisionId = D20601[0]; // D20601
                machine.ClayTableVisionId = D20601[1];  // D20602
                                                        // D20603
                                                        // D20604
                                                        // D20605
                machine.PalletDpVisionId = D20601[5];   // D20606
            }

            // D20610
            var (D20610OK, D20610) = _plc.ReadDoubleByInt32(DeviceLists.SAFETY_HEIGHT);
            if (D20610OK)
                machine.SafetyHeight = D20610;

            // D20750
            var (D20750OK, D20750) = _plc.ReadInt16(DeviceLists.OVERALL_SPEED);
            if (D20750OK)
                machine.OverallSpeed = D20750;

            return true;
        }
        else
        {
            return false;
        }
    }
}
