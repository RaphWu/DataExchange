﻿using Dapper;
using Dapper.Contrib.Extensions;
using Glorytek.SQLite;
using Glorytek.WFSComponents.Systems.Constants;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.System;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism.Services.Dialogs;
using Serilog;
using System;
using System.Windows;

namespace Glorytek.WFSComponents.Systems.Services;

/// <summary>
/// 軟體系統參數處理Service。
/// </summary>
public class SystemService : ISystem
{
    private readonly SysParameters _sys = SysParameters.Instance;

    /********************
     * ctor
     ********************/
    private readonly IPrismMessageBox _prismMessageBox;

    public SystemService(IPrismMessageBox prismMessageBox)
    {
        _prismMessageBox = prismMessageBox;
    }

    /********************
     * Get Instants
     ********************/
    /// <inheritdoc/>
    public SystemSettingDefine SystemSetting => _sys.SystemSetting;

    /********************
     * System Command
     ********************/
    /// <summary>
    /// 模組初始化。
    /// </summary>
    internal void ModuleInit()
    {
        ReadFromDb();
    }

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public bool WriteToDb()
    {
        using var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System);
        if (conn != null)
        {
            using var tran = conn.BeginTransaction();
            try
            {
                _sys.SystemSetting.MachineResetTime = SystemDataInstance.Instance.MachineResetTime;
                conn.Update<SystemSettingDefine>(_sys.SystemSetting, transaction: tran);
                tran.Commit();
                return true;
            }
            catch (Exception ex)
            {
                tran.Rollback();
                string errMsg = $"系統資料寫入失敗: {DBbase.DbName_System}";
                Log.Fatal(ex, errMsg);
                _ = _prismMessageBox.Show(errMsg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                          MessageBoxImage.Error);
            }
        }
        return false;
    }

    /// <inheritdoc/>
    public bool ReadFromDb()
    {
        using var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System);
        if (conn != null)
        {
            using var tran = conn.BeginTransaction();
            try
            {
                if (!SQLiteHelper.IsTableExist(conn, DB_System.TableName_SystemSetting))
                {
                    SQLiteHelper.CreateTable(conn, DB_System.CreateTableSQL_SystemSetting);

                    string sql = $@"INSERT INTO {DB_System.TableName_SystemSetting} (Id, MachineResetTime, AppThemeId)
VALUES (@Id, @MachineResetTime, @AppThemeId);";
                    conn.Execute(sql, new SystemSettingDefine()
                    {
                        Id = 1,
                        MachineResetTime = DateTime.Now,
                    }, transaction: tran);
                }
                _sys.SystemSetting = conn.Get<SystemSettingDefine>(1);
                SystemDataInstance.Instance.MachineResetTime = _sys.SystemSetting.MachineResetTime;
                SystemDataInstance.Instance.MachineRuningTime = DateTime.Now;
                tran.Commit();

                SystemDataInstance.Instance.AppConfigReady = true;
                return true;
            }
            catch (Exception ex)
            {
                tran.Rollback();
                SystemDataInstance.Instance.AppConfigReady = false;

                string errMsg = $"機台資料載入失敗: {DBbase.DbName_System}";
                Log.Fatal(ex, errMsg);
                _ = _prismMessageBox.Show(errMsg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                          MessageBoxImage.Error);
            }
        }
        return false;
    }

    /********************
     * 頁面資料變更檢查
     ********************/
    /// <inheritdoc/>
    public ButtonResult DataNotSavedWhenLeave(string extMessage, bool showCancelButton)
    {
        string message = GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DataNotSavedWhenChangePage");

        if (showCancelButton)
            message += GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DataNotSavedWhenChangePageWithCancel");

        if (extMessage != "")
            message += $"\n\n{extMessage}";

        if (showCancelButton)
        {
            return _prismMessageBox.ShowYesNoCancel(message,
                                                    GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DatabaseOperation"),
                                                    MessageBoxImage.Warning,
                                                    GetResource.GetValue<string>("Glorytek.WFSCore", "CRUD_Action_Save"),
                                                    GetResource.GetValue<string>("Glorytek.WFSCore", "Button_Discard"),
                                                    GetResource.GetValue<string>("Glorytek.WFSCore", "Button_Cancel"));
        }
        else
        {
            return _prismMessageBox.ShowOKCancel(message,
                                                 GetResource.GetValue<string>("Glorytek.WFSCore", "Message_DatabaseOperation"),
                                                 MessageBoxImage.Warning,
                                                 GetResource.GetValue<string>("Glorytek.WFSCore", "CRUD_Action_Save"),
                                                 GetResource.GetValue<string>("Glorytek.WFSCore", "Button_Discard"));
        }
    }

    /// <inheritdoc/>
    public ButtonResult DataNotSavedWhenLeave()
    {
        return DataNotSavedWhenLeave("", false);
    }

    /// <inheritdoc/>
    public ButtonResult DataNotSavedWhenLeave(string extMessage)
    {
        return DataNotSavedWhenLeave(extMessage, false);
    }

    /// <inheritdoc/>
    public ButtonResult DataNotSavedWhenLeave(bool showCancelButton)
    {
        return DataNotSavedWhenLeave("", showCancelButton);
    }
}
