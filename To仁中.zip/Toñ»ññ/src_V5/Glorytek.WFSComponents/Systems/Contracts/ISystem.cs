﻿using Glorytek.WFSCore.Models.System;
using Prism.Services.Dialogs;

namespace Glorytek.WFSComponents.Systems.Contracts;

/// <summary>
/// 軟體系統參數處理介面。
/// </summary>
public interface ISystem
{
    /********************
     * Database
     ********************/
    /// <summary>
    /// 寫入資料庫。
    /// </summary>
    /// <returns>是否寫入成功。</returns>
    bool WriteToDb();

    /// <summary>
    /// 從資料庫讀取。
    /// </summary>
    /// <returns>是否讀取成功。</returns>
    bool ReadFromDb();

    /// <summary>
    /// 應用程式系統參數。
    /// </summary>
    SystemSettingDefine SystemSetting { get; }

    /********************
     * 頁面資料變更檢查
     ********************/
    /// <summary>
    /// 詢問使用者：更換頁面時，但資料有修改但未儲存。
    /// </summary>
    /// <param name="extMessage">附加訊息。</param>
    /// <param name="showCancelButton">是否顯示"取消"鍵。</param>
    /// <returns>ButtonResult.Yes/No/Cancel。</returns>
    ButtonResult DataNotSavedWhenLeave(string extMessage, bool showCancelButton);

    /// <summary>
    /// 詢問使用者：更換頁面時，但資料有修改但未儲存。
    /// </summary>
    /// <returns>ButtonResult.Yes/No。</returns>
    ButtonResult DataNotSavedWhenLeave();

    /// <summary>
    /// 詢問使用者：更換頁面時，但資料有修改但未儲存。
    /// </summary>
    /// <param name="extMessage">附加訊息。</param>
    /// <returns>ButtonResult.Yes/No。</returns>
    ButtonResult DataNotSavedWhenLeave(string extMessage);

    /// <summary>
    /// 詢問使用者：更換頁面時，但資料有修改但未儲存。
    /// </summary>
    /// <param name="showCancelButton">是否顯示"取消"鍵。</param>
    /// <returns>ButtonResult.Yes/No/Cancel。</returns>
    ButtonResult DataNotSavedWhenLeave(bool showCancelButton);
}
