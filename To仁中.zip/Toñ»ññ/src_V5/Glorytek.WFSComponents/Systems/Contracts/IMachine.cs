﻿using Glorytek.WFSCore.Models.System;

namespace Glorytek.WFSComponents.Systems.Contracts;

/// <summary>
/// 機台硬體參數處理介面。
/// </summary>
public interface IMachine
{
    /********************
     * Database
     ********************/
    /// <summary>
    /// 寫入資料庫。
    /// </summary>
    void WriteToPlc();

    /// <summary>
    /// 從資料庫讀取。
    /// </summary>
    /// <returns>讀取是否成功。</returns>
    bool ReadFromPlc();

    /********************
     * Object
     ********************/
    /// <summary>
    /// 機台硬體參數。
    /// </summary>
    MachineDefine Machine { get; }
}
