﻿using Prism.Events;

namespace Glorytek.WFSComponents.Events;

/// <summary>
/// 批號變更事件。
/// </summary>
public class LotNumberChangedEvent : PubSubEvent<string> { }
