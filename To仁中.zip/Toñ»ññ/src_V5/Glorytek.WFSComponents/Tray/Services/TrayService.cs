﻿using Dapper;
using Dapper.Contrib.Extensions;
using Glorytek.SQLite;
using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.PLC.Models;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Prism.Events;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Glorytek.WFSComponents.Tray.Services;

/// <summary>
/// Tray 和 Pallet Service。
/// </summary>
public partial class TrayService : ITray
{
    private static bool _eventNotSubscribed = true;
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;
    private readonly TrayParameters _tp = TrayParameters.Instance;
    private readonly TrayData _td = TrayData.Instance;
    private readonly TrayMatrixData _tmd = TrayMatrixData.Instance;
    private readonly WfsParameters _wp = WfsParameters.Instance;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly IProductManager _pm;
    private readonly IPlc _plc;

    public TrayService(IEventAggregator ea,
                       IPrismMessageBox prismMessageBox,
                       IProductManager pm,
                       IPlc plc)
    {
        _ea = ea;
        _prismMessageBox = prismMessageBox;
        _pm = pm;
        _plc = plc;
    }

    /********************
     * Get Instance
     ********************/
    /// <inheritdoc/>
    public List<TrayDefine> TrayList => _tp.TrayList;

    /// <inheritdoc/>
    public List<TrayProfileDefine> ProfileList => _tp.ProfileList;

    /// <inheritdoc/>
    public List<TrayMaskDefine> MaskList => _tp.MaskList;

    /// <inheritdoc/>
    public string TableName_Tray => DB_Tray.TableName_Tray;

    /// <inheritdoc/>
    public List<PalletDefine> PalletList => _tp.PalletList;

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public bool WriteTrayToDb()
    {
        string msg;

        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            conn.UpdateAsync(_tp.TrayList, transaction: tran);
            conn.UpdateAsync(_tp.PalletList, transaction: tran);
            tran.Commit();

            RebuildTraySelector();
            //_ea.GetEvent<WriteNewPointNoEvent>().Publish(0);
            return true;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            msg = $"Tray資料寫入失敗 : {ex}";
            Log.Fatal(ex, msg);
            _ = _prismMessageBox.Show(msg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
        }
        return false;
    }

    /// <inheritdoc/>
    public bool WriteTrayToDb(TrayDefine tray)
    {
        string msg;

        if (!_pm.IsProductActive)
            return false;

        int index = _tp.TrayList.FindIndex(x => x.Id == tray.Id);
        if (index != -1)
        {
            _tp.TrayList[index] = tray;

            var conn = _pm.DbConnection;
            using var tran = conn.BeginTransaction();
            try
            {
                conn.UpdateAsync(_tp.TrayList, transaction: tran);
                tran.Commit();
                return true;
            }
            catch (Exception ex)
            {
                tran.Rollback();
                msg = $"Tray資料寫入失敗 : {ex}";
                Log.Fatal(ex, msg);
                _ = _prismMessageBox.Show(msg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                          MessageBoxImage.Error);
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    /// <inheritdoc/>
    public void WriteProfileAndMaskToDb(int trayId, List<TrayProfileDefine> profiles, List<TrayMaskDefine> masks)
    {
        string sql;

        if (!_pm.IsProductActive)
            return;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            sql = $"DELETE FROM {DB_Tray.TableName_Tray_Profile} WHERE TrayId = @TrayId";
            conn.Execute(sql, new { TrayId = trayId }, transaction: tran);
            if (profiles != null && profiles.Count > 0)
                conn.Insert(profiles, transaction: tran);

            sql = $"DELETE FROM {DB_Tray.TableName_Tray_Mask} WHERE TrayId = @TrayId";
            conn.Execute(sql, new { TrayId = trayId }, transaction: tran);
            if (masks != null && masks.Count > 0)
                conn.Insert(masks, transaction: tran);

            tran.Commit();
            ReadProfileAndMaskFromDb();
            return;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            string msg = $"Tray資料寫入失敗: {ex}";
            Log.Fatal(ex, msg);
            _ = _prismMessageBox.Show(msg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
            return;
        }
    }

    /// <inheritdoc/>
    public bool ReadFromDb()
    {
        string msg;

        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            /********************
             * Tray
             ********************/
            if (!SQLiteHelper.IsTableExist(conn, DB_Tray.TableName_Tray))
                SQLiteHelper.CreateTable(conn, DB_Tray.CreateTableSQL_Tray);
            _tp.TrayList = conn.GetAll<TrayDefine>(transaction: tran).OrderBy(x => x.OrderNo).ToList();

            /********************
             * Profile
             ********************/
            if (!SQLiteHelper.IsTableExist(conn, DB_Tray.TableName_Tray_Profile))
                SQLiteHelper.CreateTable(conn, DB_Tray.CreateTableSQL_Tray_Profile);
            _tp.ProfileList = conn.GetAll<TrayProfileDefine>(transaction: tran).ToList();

            /********************
             * Mask
             ********************/
            if (!SQLiteHelper.IsTableExist(conn, DB_Tray.TableName_Tray_Mask))
                SQLiteHelper.CreateTable(conn, DB_Tray.CreateTableSQL_Tray_Mask);
            _tp.MaskList = conn.GetAll<TrayMaskDefine>(transaction: tran).ToList();

            /********************
             * Pallet
             ********************/
            if (!SQLiteHelper.IsTableExist(conn, DB_Tray.TableName_Pallet))
            {
                SQLiteHelper.CreateTable(conn, DB_Tray.CreateTableSQL_Pallet);
                string sql = $@"INSERT INTO {DB_Tray.TableName_Pallet} (Id) VALUES (@Id);";
                for (int palletId = 1; palletId <= ITray.MaxPalletId; palletId++)
                    conn.Execute(sql, new { Id = palletId }, transaction: tran);
            }
            _tp.PalletList = conn.GetAll<PalletDefine>().ToList();
            tran.Commit();

            // 讀完DB再讀一次PLC，以PLC資料為主
            foreach (var item in _tp.PalletList)
                ReadPalletFromPlc(item);

            RebuildTraySelector();
            return true;
        }
        catch (Exception ex)
        {
            tran.Rollback();
            msg = $"Tray資料讀取失敗: {ex}";
            Log.Fatal(ex, msg);
            _ = _prismMessageBox.Show(msg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
        }
        return false;
    }

    /// <summary>
    /// 從DB讀取點位及無效點資料。
    /// </summary>
    private void ReadProfileAndMaskFromDb()
    {
        string msg;

        if (!_pm.IsProductActive)
            return;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            if (!SQLiteHelper.IsTableExist(conn, DB_Tray.TableName_Tray_Profile))
                SQLiteHelper.CreateTable(conn, DB_Tray.CreateTableSQL_Tray_Profile);
            _tp.ProfileList = conn.GetAll<TrayProfileDefine>(transaction: tran).ToList();

            if (!SQLiteHelper.IsTableExist(conn, DB_Tray.TableName_Tray_Mask))
                SQLiteHelper.CreateTable(conn, DB_Tray.CreateTableSQL_Tray_Mask);
            _tp.MaskList = conn.GetAll<TrayMaskDefine>(transaction: tran).ToList();

            tran.Commit();
        }
        catch (Exception ex)
        {
            tran.Rollback();
            msg = $"Tray資料讀取失敗 -> TrayService -> ReadProfileAndMaskFromDb() : {ex}";
            Log.Fatal(ex, msg);
            _ = _prismMessageBox.Show(msg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
                                      MessageBoxImage.Error);
        }
    }

    /********************
     * System Command
     ********************/
    /// <summary>
    /// 模組初始化。
    /// </summary>
    internal void ModuleInit()
    {
        if (_eventNotSubscribed)
        {
            _eventNotSubscribed = false;
            _ = _ea.GetEvent<OnProductChangeover1>().Subscribe(ProductChangeover1, true);
            _ = _ea.GetEvent<WriteNewPointNoEvent>().Subscribe(WriteAllTraySettingToPlcEvent, 0);
        }
    }

    /// <summary>
    /// 第一階段品種切換。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    private void ProductChangeover1(string productName)
    {
        if (productName != string.Empty)
        {
            ReadFromDb();
        }
        _pm.Datas.ProductChangedRunning_Tray = false;
    }

    /// <inheritdoc/>
    public int GetTrayId(int palletId)
    {
        switch (_sdi.SystemMode)
        {
            case SystemOperateModeType.Online_FixStage:
            case SystemOperateModeType.Online_DoubleCylinder:
            case SystemOperateModeType.Online_SingleCylinder:
            case SystemOperateModeType.Online_Disc:
            case SystemOperateModeType.LensSorting:
                return _wp.LensSortingList != null ? _wp.LensSortingList[palletId - 1].TrayId : -1;

            case SystemOperateModeType.LensArrange:
                if (_wp.LensArrangeList != null)
                {
                    var pallet = _wp.LensArrangeList[palletId - 1];
                    if (pallet.Pick)
                        return pallet.PickTrayId;
                    else if (pallet.Place)
                        return pallet.PlaceTrayId;
                    else
                        return -1;
                }
                else
                {
                    return -1;
                }

            default:
                return -1;
        }
    }

    /// <inheritdoc/>
    public int GetPalletId(int trayId)
    {
        int index;
        switch (_sdi.SystemMode)
        {
            case SystemOperateModeType.Online_FixStage:
            case SystemOperateModeType.Online_DoubleCylinder:
            case SystemOperateModeType.Online_SingleCylinder:
            case SystemOperateModeType.Online_Disc:
            case SystemOperateModeType.LensSorting:
                index = _wp.LensSortingList.FindIndex(x => x.TrayId == trayId);
                return index != -1 ? index + 1 : -1;

            case SystemOperateModeType.LensArrange:
                index = _wp.LensArrangeList.FindIndex(x => x.PickTrayId == trayId);
                if (index == -1)
                    index = _wp.LensArrangeList.FindIndex(x => x.PlaceTrayId == trayId);
                return index != -1 ? index + 1 : -1;

            default:
                return -1;
        }
    }

    /// <inheritdoc/>
    public int GetTotalSequenceOfFeeder()
    {
        switch (_sdi.SystemMode)
        {
            case SystemOperateModeType.Online_FixStage:
            case SystemOperateModeType.Online_DoubleCylinder:
            case SystemOperateModeType.Online_SingleCylinder:
            case SystemOperateModeType.Online_Disc:
            case SystemOperateModeType.LensSorting:
                int trayId = _wp.LensSortingList.Find(x => x.FunctionName == TrayFunctionType.Feeder).TrayId;
                return trayId != -1 ? TrayList.Find(x => x.Id == trayId).TotalSequences : 0;

            case SystemOperateModeType.LensArrange:
                int totalSequence = 0;
                foreach (var pallet in _wp.LensArrangeList)
                {
                    if (pallet.PickTrayId != -1)
                        totalSequence += TrayList.Find(x => x.Id == pallet.PickTrayId).TotalSequences;
                }
                return totalSequence;

            default:
                return 0;
        }
    }
}
