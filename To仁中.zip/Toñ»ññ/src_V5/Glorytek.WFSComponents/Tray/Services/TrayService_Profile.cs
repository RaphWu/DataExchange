﻿using Glorytek.CSharp.Data.Coordinate;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Models.Tray;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Glorytek.WFSComponents.Tray.Services;

/********************
 * Tray 和 Pallet Service - Tray點位計算。
 ********************/
public partial class TrayService : ITray_Profile
{
    /// <summary>
    /// 最多布局數。(目前Tray設定只有一般和S型兩種，只有S型布局數是2)
    /// </summary> 
    private const int _MAX_LAYOUT = 2;

    /// <inheritdoc/>
    public bool GetProfile(int trayId, out List<TrayProfileDefine> profileList, out List<TrayMaskDefine> maskList)
    {
        bool ret = true;

        profileList = _tp.ProfileList.FindAll(x => x.TrayId == trayId);
        if (profileList == null)
        {
            profileList = null;
            ret = false;
        }

        maskList = _tp.MaskList.FindAll(x => x.TrayId == trayId);
        if (maskList == null)
        {
            maskList = null;
            ret = false;
        }

        return ret;
    }

    /// <inheritdoc/>
    public bool IsMask(int trayId, int sequenceNo)
    {
        var masks = _tp.MaskList.FindAll(x => x.TrayId == trayId);
        return masks != null && masks.Exists(x => x.PointNo == sequenceNo);
    }

    /// <inheritdoc/>
    public List<TrayProfileDefine> CalculateProfile(TrayDefine tray, List<TrayMaskDefine> mask)
    {
        int trayId = tray.Id;
        var profile = new List<TrayProfileDefine>();
        short maskCounter = 0;

        // 需要合併的Layout數: 順序=1, 交錯=2
        int totalLayout = tray.Arrangement == TrayArrangementType.ArrangeInOrder ? 1 : 2;

        /********************
         * 基本參數計算
         ********************/
        // 格數
        int[] gridNumberX = new int[_MAX_LAYOUT];
        int[] gridNumberY = new int[_MAX_LAYOUT];

        // ABC點座標
        double[] datumA_X = new double[_MAX_LAYOUT];
        double[] datumA_Y = new double[_MAX_LAYOUT];
        double[] datumB_X = new double[_MAX_LAYOUT];
        double[] datumB_Y = new double[_MAX_LAYOUT];
        double[] datumC_X = new double[_MAX_LAYOUT];
        double[] datumC_Y = new double[_MAX_LAYOUT];

        // ABC偏移格數
        int[] gridOffsetA = new int[_MAX_LAYOUT];
        int[] gridOffsetB = new int[_MAX_LAYOUT];
        int[] gridOffsetC = new int[_MAX_LAYOUT];

        // 總點數
        int[] totalPoints = new int[_MAX_LAYOUT];

        // 取得設定資料 依序排列
        gridNumberX[0] = tray.Order_GridNumberX;
        gridNumberY[0] = tray.Order_GridNumberY;
        datumA_X[0] = tray.Order_PositionA_X;
        datumA_Y[0] = tray.Order_PositionA_Y;
        datumB_X[0] = tray.Order_PositionB_X;
        datumB_Y[0] = tray.Order_PositionB_Y;
        datumC_X[0] = tray.Order_PositionC_X;
        datumC_Y[0] = tray.Order_PositionC_Y;
        gridOffsetA[0] = tray.Order_OffsetA;
        gridOffsetB[0] = tray.Order_OffsetB;
        gridOffsetC[0] = tray.Order_OffsetC;
        totalPoints[0] = gridNumberX[0] * gridNumberY[0];

        // 取得設定資料 交錯排列
        gridNumberX[1] = tray.Cross_GridNumberX;
        gridNumberY[1] = tray.Cross_GridNumberY;
        datumA_X[1] = tray.Cross_PositionA_X;
        datumA_Y[1] = tray.Cross_PositionA_Y;
        datumB_X[1] = tray.Cross_PositionB_X;
        datumB_Y[1] = tray.Cross_PositionB_Y;
        datumC_X[1] = tray.Cross_PositionC_X;
        datumC_Y[1] = tray.Cross_PositionC_Y;
        gridOffsetA[1] = tray.Cross_OffsetA;
        gridOffsetB[1] = tray.Cross_OffsetB;
        gridOffsetC[1] = tray.Cross_OffsetC;
        totalPoints[1] = gridNumberX[1] * gridNumberY[1];

        /********************
         * 排列前資料計算
         ********************/
        // 是否轉90度
        bool[] layoutRotate = new bool[2] { false, false };

        // 步進值
        PointXY[] gapLine = new PointXY[_MAX_LAYOUT] { new PointXY(0.0, 0.0), new PointXY(0.0, 0.0) };
        PointXY[] gapPoint = new PointXY[_MAX_LAYOUT] { new PointXY(0.0, 0.0), new PointXY(0.0, 0.0) };

        for (int layout = 0; layout < totalLayout; layout++)
        {
            layoutRotate[layout] = Math.Abs(datumB_X[layout] - datumA_X[layout]) < Math.Abs(datumB_Y[layout] - datumA_Y[layout]);

            int totalPoint = gridNumberX[layout];
            int totalLine = gridNumberY[layout];

            if (layoutRotate[layout])
            {
                // 計算步進值
                gapPoint[layout].X = ((datumB_X[layout] - datumA_X[layout]) / (totalPoint - 1 - gridOffsetA[layout] - gridOffsetB[layout] + gridOffsetC[layout])).WfsFormat();
                gapPoint[layout].Y = ((datumB_Y[layout] - datumA_Y[layout]) / (totalPoint - 1 - gridOffsetA[layout] - gridOffsetB[layout] + gridOffsetC[layout])).WfsFormat();
                gapLine[layout].X = ((datumC_X[layout] - gridOffsetC[layout] * gapPoint[layout].X - datumA_X[layout]) / (totalLine - 1)).WfsFormat();
                gapLine[layout].Y = ((datumC_Y[layout] - gridOffsetC[layout] * gapPoint[layout].Y - datumA_Y[layout]) / (totalLine - 1)).WfsFormat();

                // 調整ABC點座標至角落點位
                datumA_X[layout] = (datumA_X[layout] - gridOffsetA[layout] * gapPoint[layout].X).WfsFormat();
                datumA_Y[layout] = (datumA_Y[layout] - gridOffsetA[layout] * gapPoint[layout].Y).WfsFormat();

                datumB_X[layout] = (datumB_X[layout] + gridOffsetB[layout] * gapPoint[layout].X).WfsFormat();
                datumB_Y[layout] = (datumB_Y[layout] + gridOffsetB[layout] * gapPoint[layout].Y).WfsFormat();

                datumC_X[layout] = (datumC_X[layout] - (gridOffsetA[layout] + gridOffsetC[layout]) * gapPoint[layout].X).WfsFormat();
                datumC_Y[layout] = (datumC_Y[layout] - (gridOffsetA[layout] + gridOffsetC[layout]) * gapPoint[layout].Y).WfsFormat();
            }
            else
            {
                // 計算步進值
                gapPoint[layout].X = ((datumB_X[layout] - datumA_X[layout]) / (totalPoint - 1 - gridOffsetA[layout] - gridOffsetB[layout])).WfsFormat();
                gapPoint[layout].Y = ((datumB_Y[layout] - datumA_Y[layout]) / (totalPoint - 1 - gridOffsetA[layout] - gridOffsetB[layout])).WfsFormat();
                gapLine[layout].X = ((datumC_X[layout] - gridOffsetC[layout] * gapLine[layout].X - datumA_X[layout]) / (totalLine - 1)).WfsFormat();
                gapLine[layout].Y = ((datumC_Y[layout] - gridOffsetC[layout] * gapLine[layout].Y - datumA_Y[layout]) / (totalLine - 1)).WfsFormat();

                // 調整ABC點座標至角落點位
                datumA_X[layout] = (datumA_X[layout] - gridOffsetA[layout] * gapLine[layout].X).WfsFormat();
                datumA_Y[layout] = (datumA_Y[layout] - gridOffsetA[layout] * gapLine[layout].Y).WfsFormat();

                datumB_X[layout] = (datumB_X[layout] + gridOffsetB[layout] * gapLine[layout].X).WfsFormat();
                datumB_Y[layout] = (datumB_Y[layout] + gridOffsetB[layout] * gapLine[layout].Y).WfsFormat();

                datumC_X[layout] = (datumC_X[layout] - (gridOffsetA[layout] + gridOffsetC[layout]) * gapLine[layout].X).WfsFormat();
                datumC_Y[layout] = (datumC_Y[layout] - (gridOffsetA[layout] + gridOffsetC[layout]) * gapLine[layout].Y).WfsFormat();
            }
        }

        /********************
         * 計算各組Layout
         ********************/
        PointXY[][,] mergeList = new PointXY[_MAX_LAYOUT][,];
        TrayArrangementType[] arrangementList = new TrayArrangementType[_MAX_LAYOUT];

        for (int layout = 0; layout < totalLayout; layout++)
        {
            mergeList[layout] = new PointXY[gridNumberY[layout], gridNumberX[layout]];
            arrangementList[layout] = layout == 0 ? TrayArrangementType.ArrangeInOrder : TrayArrangementType.ArrangeInCross;

            // 基準點(A點位)
            double trayDatumX;
            double trayDatumY;
            if (layout == 0)
            {
                trayDatumX = datumA_X[layout].WfsFormat(); // +tray.Order_OffsetX
                trayDatumY = datumA_Y[layout].WfsFormat(); // +tray.Order_OffsetY
            }
            else
            {
                trayDatumX = datumA_X[layout].WfsFormat(); // +tray.Cross_OffsetX
                trayDatumY = datumA_Y[layout].WfsFormat(); // +tray.Cross_OffsetY
            }

            // 計算與儲存
            for (int loopLine = 0; loopLine < gridNumberY[layout]; loopLine++)
            {
                for (int loopPoint = 0; loopPoint < gridNumberX[layout]; loopPoint++)
                {
                    mergeList[layout][loopLine, loopPoint] = new PointXY()
                    {
                        X = (trayDatumX + (loopLine * gapLine[layout].X) + (loopPoint * gapPoint[layout].X)).WfsFormat(),
                        Y = (trayDatumY + (loopLine * gapLine[layout].Y) + (loopPoint * gapPoint[layout].Y)).WfsFormat(),
                    };
                }
            }
        }

        /********************
         * Layout合併
         ********************/
        bool[] layoutCompletedFlag = new bool[2] { false, false };  // 各Layout是否合併完成
        int completedCounter = 0;                   // 合併已完成數
        int mergeLayout = 0;                        // 目前合併的是那組Layout
        int[] finishedLines = new int[2] { 0, 0 };  // 完成行數
        int pointNo = 1;                            // 點位編號
        int sequenceNo = 0;                         // 取放點序號
        int lineCounter = 0;                        // 列計數器

        while (completedCounter < totalLayout)
        {
            // 此組合併未完成
            if (!layoutCompletedFlag[mergeLayout])
            {
                lineCounter++;

                // 合併一列
                for (int pointCounter = 0; pointCounter < gridNumberX[mergeLayout]; pointCounter++)
                {
                    PointXY coor = mergeList[mergeLayout][finishedLines[mergeLayout], pointCounter];
                    int numRow;
                    int numColumn;

                    if (layoutRotate[mergeLayout])
                    {
                        numRow = pointCounter + 1;
                        numColumn = lineCounter;
                    }
                    else
                    {
                        numRow = lineCounter;
                        numColumn = pointCounter + 1;
                    }

                    // mask
                    bool isMask = mask.Any(x => x.PointNo == pointNo);
                    if (isMask)
                        maskCounter++;

                    profile.Add(new TrayProfileDefine()
                    {
                        TrayId = trayId,
                        PointNo = pointNo++,
                        SequenceNo = isMask ? -1 : ++sequenceNo,
                        Arrangement = arrangementList[mergeLayout],
                        PositionX = coor.X,
                        PositionY = coor.Y,
                        Row = numRow,
                        Column = numColumn,
                    });
                }

                finishedLines[mergeLayout]++;
                if (finishedLines[mergeLayout] >= gridNumberY[mergeLayout])
                {
                    layoutCompletedFlag[mergeLayout] = true;
                    completedCounter++;
                }
            }

            // 換組
            mergeLayout++;
            if (mergeLayout >= totalLayout)
                mergeLayout = 0;
        }

        // 更新Tray
        var thisTray = TrayList.Find(x => x.Id == tray.Id);
        if (thisTray != null)
        {
            thisTray.TotalPoints = (short)profile.Count;
            thisTray.TotalSequences = (short)(tray.TotalPoints - maskCounter);
            WriteTrayToDb(thisTray);
        }

        // 更新DB
        WriteProfileAndMaskToDb(tray.Id, profile, mask);
        return profile;
    }

    /********************
     * 點位序號轉換
     ********************/
    /// <inheritdoc/>
    public int ConvertPointNoToSequenceNo(int trayId, int pointNo)
    {
        if (ProfileList == null)
            return 0;

        var index = ProfileList.FindIndex(x => x.TrayId == trayId && x.PointNo == pointNo);
        return index != -1 ? ProfileList[index].SequenceNo : 0;
    }

    /// <inheritdoc/>
    public int ConvertSequenceNoToPointNo(int trayId, int sequenceNo)
    {
        if (ProfileList == null)
            return 0;

        var index = ProfileList.FindIndex(x => x.TrayId == trayId && x.SequenceNo == sequenceNo);
        return index != -1 ? ProfileList[index].PointNo : 0;
    }
}
