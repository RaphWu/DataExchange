﻿using Dapper;
using Dapper.Contrib.Extensions;
using Glorytek.CSharp.Extensions;
using Glorytek.WFSComponents.Tray.Constants;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSCore.Models.WFS;
using Glorytek.WPF.Extensions;
using System.Collections.Generic;
using System.Linq;

namespace Glorytek.WFSComponents.Tray.Services;

/********************
 * Tray 和 Pallet Service - Tray作業。
 ********************/
public partial class TrayService : ITray_Tray
{
    /********************
     * CRUD
     ********************/
    /// <inheritdoc/>
    public int CreateNewTray(CrudInfo crudInfo)
    {
        if (!_pm.IsProductActive)
            return -1;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            string sql = $"INSERT INTO {DB_Tray.TableName_Tray} (Name, OrderNo) VALUES (@Name, @OrderNo);";
            conn.Execute(sql, new
            {
                Name = crudInfo.NewName,
                //Memo = crudInfo.Memo,
                OrderNo = _tp.TrayList.Max(x => x.OrderNo) + 1,
            }, transaction: tran);
            tran.Commit();
            ReadFromDb();
            RebuildTraySelector();
        }
        catch
        {
            tran.Rollback();
        }
        //string msg = GetLocalizeResource.GetValue<string>("Msg_WritingToDatabaseHasBeenCompleted");
        //_sysMessenger.PageTitle(msg);
        return _tp.TrayList.FindIndex(x => x.Id == crudInfo.Id);
    }

    /// <inheritdoc/>
    public bool RenameTray(CrudInfo crudInfo)
    {
        if (!_pm.IsProductActive)
            return false;

        var tray = _tp.TrayList.Find(x => x.Id == crudInfo.Id);
        if (tray == null)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            tray.Name = crudInfo.NewName;
            conn.Update<TrayDefine>(tray, transaction: tran);
            tran.Commit();
            ReadFromDb();
            RebuildTraySelector();
            return true;
        }
        catch
        {
            tran.Rollback();
            return false;
        }
        //string msg = GetLocalizeResource.GetValue<string>("Msg_WritingToDatabaseHasBeenCompleted");
        //_sysMessenger.PageTitle(msg);
    }

    /// <inheritdoc/>
    public int CopyTray(CrudInfo crudInfo)
    {
        if (!_pm.IsProductActive)
            return -1;

        int oldTrayId = crudInfo.Id;
        int newTrayId = _tp.TrayList.Max(x => x.Id) + 1;
        int newOrderNo = _tp.TrayList.Max(x => x.OrderNo) + 1;

        // 複製Tray
        TrayDefine newTray = _tp.TrayList.Find(x => x.Id == oldTrayId).DeepCopyByExpressionTree();
        if (newTray == null)
            return -1;

        newTray.Id = newTrayId;
        newTray.Name = crudInfo.NewName;
        newTray.OrderNo = newOrderNo;

        // db
        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            conn.Insert(newTray, transaction: tran);

            // 複製Profile
            List<TrayProfileDefine> profiles = _tp.ProfileList.FindAll(x => x.TrayId == oldTrayId).DeepCopyByExpressionTree();
            if (profiles != null)
            {
                foreach (var profile in profiles)
                    profile.TrayId = newTrayId;
                conn.Insert(profiles, transaction: tran);
            }

            // 複製Mask
            List<TrayMaskDefine> masks = _tp.MaskList.FindAll(x => x.TrayId == oldTrayId).DeepCopyByExpressionTree();
            if (masks != null)
            {
                foreach (var mask in masks)
                    mask.TrayId = newTrayId;
                conn.Insert(masks, transaction: tran);
            }

            tran.Commit();

            ReadFromDb();
            ResortOrderNo();
            conn.UpdateAsync(_tp.TrayList);
            RebuildTraySelector();
        }
        catch
        {
            tran.Rollback();
        }

        return newTrayId;
    }

    /// <inheritdoc/>
    public bool DeleteTray(int trayId)
    {
        string sql;

        if (!_pm.IsProductActive)
            return false;

        var conn = _pm.DbConnection;
        using var tran = conn.BeginTransaction();
        try
        {
            // 刪除Tray
            _tp.TrayList.RemoveAll(x => x.Id == trayId);
            sql = $"DELETE FROM {DB_Tray.TableName_Tray} WHERE Id = @TrayId";
            conn.ExecuteAsync(sql, new { TrayId = trayId }, transaction: tran);

            // 刪除Profile
            _tp.ProfileList.RemoveAll(x => x.TrayId == trayId);
            sql = $"DELETE FROM {DB_Tray.TableName_Tray_Profile} WHERE TrayId = @TrayId";
            conn.ExecuteAsync(sql, new { TrayId = trayId }, transaction: tran);

            // 刪除Mask
            _tp.MaskList.RemoveAll(x => x.TrayId == trayId);
            sql = $"DELETE FROM {DB_Tray.TableName_Tray_Mask} WHERE TrayId = @TrayId";
            conn.ExecuteAsync(sql, new { TrayId = trayId }, transaction: tran);

            // 將Pallet內有關GradeId的設定，全部改成無設定狀態(小心：直接修改WfsParameters)
            WfsParameters.Instance.LensSortingList.FindAll(x => x.TrayId == trayId).ForEach(x =>
            {
                x.TrayId = -1;
            });
            conn.UpdateAsync(WfsParameters.Instance.LensSortingList, transaction: tran);
            WfsParameters.Instance.LensArrangeList.FindAll(x => x.PickTrayId == trayId).ForEach(x =>
            {
                x.PickTrayId = -1;
            });
            WfsParameters.Instance.LensArrangeList.FindAll(x => x.PlaceTrayId == trayId).ForEach(x =>
            {
                x.PlaceTrayId = -1;
            });
            conn.UpdateAsync(WfsParameters.Instance.LensArrangeList, transaction: tran);

            tran.Commit();
            ReadFromDb();
            ResortOrderNo();
            conn.UpdateAsync(_tp.TrayList, transaction: tran);
            RebuildTraySelector();
            return true;
        }
        catch
        {
            tran.Rollback();
            return false;
        }
    }

    /********************
     * Tabel
     ********************/
    /// <inheritdoc/>
    public bool IsTrayExist(int trayId)
        => _tp.TrayList.Any(x => x.Id == trayId);

    /// <inheritdoc/>
    public bool IsTrayExist(string trayName)
        => _tp.TrayList.Any(x => x.Name == trayName);

    /********************
     * ID與Name轉換
     ********************/
    /// <inheritdoc/>
    public int GetIdFromName(string name)
        => _tp.TrayList.Find(x => x.Name == name).Id;

    /// <inheritdoc/>
    public string GetNameFromId(int id) => GetTray(id, out TrayDefine tray) ? tray.Name : string.Empty;

    /********************
     * Tray作業
     ********************/
    /// <inheritdoc/>
    public bool GetTray(int trayId, out TrayDefine tray)
    {
        tray = null;
        if (_tp.TrayList != null)
            tray = _tp.TrayList.Find(x => x.Id == trayId);
        return tray != null;
    }

    /// <inheritdoc/>
    public TrayDefine GetTray(int trayId)
    {
        return _tp.TrayList.Find(x => x.Id == trayId);
    }

    ///// <inheritdoc/>
    //public bool MoveToNextSequenceNo(TrayDefine tray)
    //{
    //    int sequenceNo = tray.CurrentSequence + 1;
    //    while (sequenceNo <= tray.TotalPoints)
    //    {
    //        if (IsMask(tray.Id, sequenceNo))
    //            sequenceNo++;
    //        else
    //        {
    //            tray.CurrentSequence = sequenceNo;
    //            return true;
    //        }
    //    }
    //    return false;
    //}

    ///// <inheritdoc/>
    //public bool MoveToNextSequenceNo(int trayId)
    //{
    //    if (GetTray(trayId, out TrayDefine tray))
    //        return MoveToNextSequenceNo(tray);
    //    return false;
    //}

    /********************
     * OrderNo操作
     ********************/
    /// <inheritdoc/>
    public bool MoveOrderUp(int trayId)
    {
        var thisTray = _tp.TrayList.Find(x => x.Id == trayId);
        if (thisTray != null)
        {
            int thisOrderNo = thisTray.OrderNo;
            int targetOrderNo = thisOrderNo - 1;
            var targetTray = _tp.TrayList.Find(x => x.OrderNo == targetOrderNo);

            if (targetTray != null)
            {
                (thisTray.OrderNo, targetTray.OrderNo) = (targetTray.OrderNo, thisTray.OrderNo);
                ResortOrderNo();
                return true;
            }
        }
        return false;
    }

    /// <inheritdoc/>
    public bool MoveOrderDown(int trayId)
    {
        var thisTray = _tp.TrayList.Find(x => x.Id == trayId);
        if (thisTray != null)
        {
            int thisOrderNo = thisTray.OrderNo;
            int targetOrderNo = thisOrderNo + 1;
            var targetTray = _tp.TrayList.Find(x => x.OrderNo == targetOrderNo);

            if (targetTray != null)
            {
                (thisTray.OrderNo, targetTray.OrderNo) = (targetTray.OrderNo, thisTray.OrderNo);
                ResortOrderNo();
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// 對OrderNo重新排序。
    /// </summary>
    private void ResortOrderNo()
    {
        int orderNo = 0;
        var orderTray = _tp.TrayList.OrderBy(x => x.OrderNo);
        foreach (var tray in orderTray)
            tray.OrderNo = ++orderNo;
        WriteTrayToDb();
    }

    /********************
     * TraySelector
     ********************/
    /// <inheritdoc/>
    public Dictionary<int, string> TraySelector(bool includeUnused = false)
    {
        return includeUnused
            ? _td.TraySelectorIncludeUnused
            : _td.TraySelector;
    }

    /// <summary>
    /// 重建Tray選擇清單
    /// </summary>
    internal Dictionary<int, string> RebuildTraySelector()
    {
        Dictionary<int, string> fSelector = new Dictionary<int, string>();
        Dictionary<int, string> fSelectorIncludeUnused = new Dictionary<int, string>();

        if (_pm.IsProductActive)
        {
            fSelectorIncludeUnused.Add(-1, GetResource.GetValue<string>("Glorytek.WFSCore", "Message_Unused"));
            foreach (TrayDefine item in _tp.TrayList)
            {
                fSelector.Add(item.Id, item.Name);
                fSelectorIncludeUnused.Add(item.Id, item.Name);
            }
        }

        _td.TraySelector = fSelector;
        _td.TraySelectorIncludeUnused = fSelectorIncludeUnused;

        return fSelector;
    }
}
