﻿using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Models.Tray;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;

namespace Glorytek.WFSComponents.Tray.Services;

/********************
 * Tray 和 Pallet Service - Tray矩陣作業。
 ********************/
public partial class TrayService : ITray_TrayMatrix
{
    /********************
     * 方塊
     ********************/
    /// <summary>
    /// 方塊ID。
    /// </summary>
    private static int _blockId;

    /// <summary>
    /// 方塊邊長。
    /// </summary>
    private const double _BLOCK_SIDE_LENGTH = 56.0;

    /// <summary>
    /// 方塊邊長/2。
    /// </summary>
    private const double _BLOCK_SIDE_LENGTH_2 = _BLOCK_SIDE_LENGTH / 2;

    /// <summary>
    /// 方塊間隔。
    /// </summary>
    private const double _BLOCK_GAP = 10.0;

    /// <summary>
    /// 四週留邊。
    /// </summary>
    private const double _MARGIN = 40.0;

    /// <summary>
    /// 方塊一般顏色。
    /// </summary>
    private const string _BLOCK_FG = "Black";
    private const string _BLOCK_BG = "WhiteSmoke";

    ///// <summary>
    ///// Auto Mask顏色。
    ///// </summary>
    //private const string _AUTO_MASK_FG = "Black";
    //private const string _AUTO_MASK_BG = "SandyBrown";

    /// <summary>
    /// Mask顏色。
    /// </summary>
    private const string _MASK_FG = "White";
    private const string _MASK_BG = "DimGray";

    /// <summary>
    /// Current ID顏色。
    /// </summary>
    private const string _this_ID_FG = "White";
    private const string _this_ID_BG = "Maroon";

    /********************
     * Command
     ********************/
    /// <inheritdoc/>
    public ObservableCollection<BlockDefine> RedrawBlocks(TrayDefine drawTray,
                                                          List<TrayProfileDefine> profile,
                                                          List<TrayMaskDefine> mask)
    {
        var blocks = new List<BlockDefine>();
        if (profile == null || profile.Count == 0)
            return new ObservableCollection<BlockDefine>(blocks);

        /********************
         * 推算繪製放大率
         ********************/
        double minGap = double.MaxValue;
        double gap;
        for (int index = 0; index < profile.Count - 1; index++)
        {
            gap = Math.Abs(profile[index].PositionX - profile[index + 1].PositionX);
            if (gap > 1.0 && minGap > gap) // 若間距不足1 mm，視為同座標
                minGap = gap;

            gap = Math.Abs(profile[index].PositionY - profile[index + 1].PositionY);
            if (gap > 1.0 && minGap > gap)
                minGap = gap;
        }

        // 放大率=(方塊邊長+方塊間隔)/點位資料中最小座標間隔
        double drawingMagnification = ((_BLOCK_SIDE_LENGTH + _BLOCK_GAP) / minGap).WfsFormat();

        /********************
         * 計算方塊占用區域大小及四角座標點
         ********************/
        // 四角座標
        double cornerLeft = double.MaxValue;
        double cornerRight = double.MinValue;
        double cornerTop = double.MaxValue;
        double cornerBottom = double.MinValue;

        for (int blockNo = 0; blockNo < profile.Count; blockNo++)
        {
            TrayProfileDefine tpd = profile[blockNo];

            Rect blockArea = new((tpd.PositionX * drawingMagnification - _BLOCK_SIDE_LENGTH_2).WfsFormat(),
                                 (tpd.PositionY * drawingMagnification - _BLOCK_SIDE_LENGTH_2).WfsFormat(),
                                 _BLOCK_SIDE_LENGTH,
                                 _BLOCK_SIDE_LENGTH);

            if (cornerLeft > blockArea.Left)
                cornerLeft = blockArea.Left;

            if (cornerRight < blockArea.Right)
                cornerRight = blockArea.Right;

            if (cornerTop > blockArea.Top)
                cornerTop = blockArea.Top;

            if (cornerBottom < blockArea.Bottom)
                cornerBottom = blockArea.Bottom;
        }

        /********************
         * 將四角座標移至與(0,0)對齊
         ********************/
        double drawingOffsetX;
        double drawingOffsetY;

        drawingOffsetX = cornerLeft;
        cornerLeft = 0.0;
        cornerRight -= drawingOffsetX;

        drawingOffsetY = cornerTop;
        cornerTop = 0.0;
        cornerBottom -= drawingOffsetY;

        /********************
         * 顯示區邊界
         ********************/
        double borderLeft = (cornerLeft - _MARGIN).WfsFormat();
        double borderRight = (cornerRight + _MARGIN).WfsFormat();
        double borderTop = (cornerTop - _MARGIN).WfsFormat();
        double borderBottom = (cornerBottom + _MARGIN).WfsFormat();

        // 定義顯示區
        Rect contentArea = new(new Point(borderLeft, borderTop),
                               new Point(borderRight, borderBottom));

        // 變更顯示區
        ZoomAndPanModel.Instance.ContentWidth = contentArea.Width;
        ZoomAndPanModel.Instance.ContentHeight = contentArea.Height;

        /********************
         * 繪製方塊
         ********************/
        for (int blockIndex = 0; blockIndex < profile.Count; blockIndex++)
        {
            int blockId = blockIndex + 1;
            TrayProfileDefine tpd = profile[blockIndex];

            Rect blockArea = new(
                (tpd.PositionX * drawingMagnification - drawingOffsetX + _MARGIN - _BLOCK_SIDE_LENGTH_2).WfsFormat(),
                (tpd.PositionY * drawingMagnification - drawingOffsetY + _MARGIN - _BLOCK_SIDE_LENGTH_2).WfsFormat(),
                _BLOCK_SIDE_LENGTH,
                _BLOCK_SIDE_LENGTH);

            // 方塊中間顯示的文字
            string title = "";
            if (_tmd.BlockInformationSelector == BlockInformationType.ID)
            {
                string strSequ = tpd.SequenceNo > 0 ? $"[{tpd.SequenceNo}]" : "";
                title = $"{blockId}\n{strSequ}\n({tpd.Row},{tpd.Column})";
            }
            else if (_tmd.BlockInformationSelector == BlockInformationType.COOR)
            {
                title = $"{blockId}\n{tpd.PositionX:F3}\n{tpd.PositionY:F3}";
            }

            // 加入列表
            blocks.Add(new BlockDefine(
                id: blockId,
                trayId: tpd.TrayId,
                arrangementId: tpd.ArrangementId,
                title: title,
                positionX: blockArea.Left,
                positionY: blockArea.Top,
                width: _BLOCK_SIDE_LENGTH,
                height: _BLOCK_SIDE_LENGTH,
                fgColor: _BLOCK_FG,
                bgColor: _BLOCK_BG,
                mask: false));

            // 在第一格繪製軸線
            if (blockIndex == 0)
            {
                const double AXIS_LENGTH = 2000.0;
                double xAxis = blockArea.Top + _BLOCK_SIDE_LENGTH_2;
                double yAxis = blockArea.Left + _BLOCK_SIDE_LENGTH_2;

                _tmd.XAxisX1 = xAxis - AXIS_LENGTH;
                _tmd.XAxisY1 = xAxis;
                _tmd.XAxisX2 = xAxis + AXIS_LENGTH;
                _tmd.XAxisY2 = xAxis;

                _tmd.YAxisX1 = yAxis;
                _tmd.YAxisY1 = yAxis - AXIS_LENGTH;
                _tmd.YAxisX2 = yAxis;
                _tmd.YAxisY2 = yAxis + AXIS_LENGTH;
            }
        }

        /********************
         * 設定顏色
         ********************/
        if (blocks.Count > 0)
        {
            foreach (BlockDefine block in blocks)
            {
                _blockId = block.Id;
                bool colorHasBeenSet = false;

                if (mask?.Find(x => x.PointNo == _blockId
                                    && x.TrayId == drawTray.Id
                                    && x.ArrangementId == block.ArrangementId) != null)
                {
                    block.Mask = true;
                    block.FgColor = _MASK_FG;
                    block.BgColor = _MASK_BG;
                    colorHasBeenSet = true;
                }

                // 座標底色
                if (_blockId == _tmd.CurrentPointNo && !colorHasBeenSet)
                {
                    block.FgColor = _this_ID_FG;
                    block.BgColor = _this_ID_BG;
                    colorHasBeenSet = true;
                }

                //// 布局底色
                //if (!colorHasBeenSet && MarkLayout && _thisProfile.Count > 0)
                //{
                //    if (profile != default && profile.LayoutId == ThisTray.LayoutOnDisplay)
                //    {
                //        block.FgColor = LAYOUT_FG;
                //        block.BgColor = LAYOUT_BG;
                //        colorHasBeenSet = true;
                //    }
                //}
            }
        }

        return new ObservableCollection<BlockDefine>(blocks);
    }

    /// <inheritdoc/>
    public void ToggleMaskState(ref BlockDefine block, ref List<TrayMaskDefine> mask, int trayId, int totalPoint)
    {
        int blockId = block.Id;

        // 先刪除大於總點位數的資料
        mask.RemoveAll(x => x.TrayId == trayId && x.PointNo > totalPoint);

        int maskIndex = mask.FindIndex(x => x.TrayId == trayId && x.PointNo == blockId);
        if (maskIndex >= 0)
        {
            mask.RemoveAll(x => x.TrayId == trayId && x.PointNo == blockId);
            block.Mask = false;
            block.FgColor = _BLOCK_FG;
            block.BgColor = _BLOCK_BG;
        }
        else
        {
            if (mask.FindAll(x => x.TrayId == trayId && x.PointNo == blockId).Count == ITray.MaxMask)
            {
                _prismMessageBox.Show($"無效點位最多設定數: {ITray.MaxMask}", "設定錯誤", MessageBoxImage.Error);
            }
            else
            {
                mask.Add(new TrayMaskDefine()
                {
                    PointNo = (short)blockId,
                    TrayId = trayId,
                    ArrangementId = block.ArrangementId,
                });
                block.Mask = true;
                block.FgColor = _MASK_FG;
                block.BgColor = _MASK_BG;
            }
        }

        mask.Sort();

        //if (blockId == _tmd.CurrentId)
        //    ExecuteMoveToPreviousIdCommand();

        // update database
        //WriteProfileAndMaskToDb(_tp.ProfileList, mask);
    }
}
