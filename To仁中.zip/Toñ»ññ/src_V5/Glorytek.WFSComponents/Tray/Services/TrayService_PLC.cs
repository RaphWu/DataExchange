﻿using Glorytek.CSharp.Data;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSCore;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models.Tray;
using Glorytek.WFSExternal;
using System;
using System.Collections.Generic;

namespace Glorytek.WFSComponents.Tray.Services;

/********************
 * Tray 和 Pallet Service - PLC讀寫。
 ********************/
public partial class TrayService : ITray_PLC
{
    /// <inheritdoc/>
    public void WriteTrayToPlc(int palletId, TrayDefine tray)
    {
        if (_plc.Online && tray != null)
        {
            string trayStartWordDevice;
            string trayStartDWordDevice;
            string trayOrderCross;

            int palletIndex = palletId - 1;

            // 確認寫入PLC的軟元件位址
            if (palletId >= 1 && palletId <= ITray.MaxPalletId)
            {
                trayStartWordDevice = DeviceLists.TRAY_WORD[palletIndex];
                trayStartDWordDevice = DeviceLists.TRAY_DWORD[palletIndex];
                trayOrderCross = $"M{DeviceLists.TRAY_ORDER_CROSS + palletId}";
            }
            else if (palletId == DeviceLists.VISUAL_TRAY_ID)
            {
                trayStartWordDevice = DeviceLists.VISUAL_TRAY_WORD;
                trayStartDWordDevice = DeviceLists.VISUAL_TRAY_DWORD;
                trayOrderCross = DeviceLists.VISUAL_TRAY_ORDER_CROSS;
            }
            else
            {
                // TODO: log
                return;
            }

            // 取出無效點資料
            List<TrayMaskDefine> maskListOrder = _tp.MaskList.FindAll(x =>
                x.TrayId == tray.Id && x.Arrangement == TrayArrangementType.ArrangeInOrder);
            List<TrayMaskDefine> maskListCross = _tp.MaskList.FindAll(x =>
                x.TrayId == tray.Id && x.Arrangement == TrayArrangementType.ArrangeInCross);

            short[] maskOrder = new short[ITray.MaxMask];
            short[] maskCross = new short[ITray.MaxMask];
            for (int idx = 0; idx < ITray.MaxMask; idx++)
            {
                maskOrder[idx] = (short)(idx < maskListOrder.Count ? maskListOrder[idx].PointNo : 0);
                maskCross[idx] = (short)(idx < maskListCross.Count ? maskListCross[idx].PointNo : 0);
            }

            // 寫入Word部分
            short[] trayWord = new short[]
            {
                tray.Order_GridNumberX, tray.Order_GridNumberY,
                0, 0, 0, 0, 0,
                tray.Order_OffsetA, tray.Order_OffsetB, tray.Order_OffsetC,
                maskOrder[00], maskOrder[01], maskOrder[02], maskOrder[03], maskOrder[04],
                maskOrder[05], maskOrder[06], maskOrder[07], maskOrder[08], maskOrder[09],
                maskOrder[10], maskOrder[11], maskOrder[12], maskOrder[13], maskOrder[14],
                maskOrder[15], maskOrder[16], maskOrder[17], maskOrder[18], maskOrder[19],
                tray.Cross_GridNumberX, tray.Cross_GridNumberY,
                0, 0, 0, 0, 0,
                tray.Cross_OffsetA, tray.Cross_OffsetB, tray.Cross_OffsetC,
                maskCross[00], maskCross[01], maskCross[02], maskCross[03], maskCross[04],
                maskCross[05], maskCross[06], maskCross[07], maskCross[08], maskCross[09],
                maskCross[10], maskCross[11], maskCross[12], maskCross[13], maskCross[14],
                maskCross[15], maskCross[16], maskCross[17], maskCross[18], maskCross[19],
            };
            _ = _plc.WriteInt16(trayStartWordDevice, trayWord);

            // 寫入DWord部分
            if (tray.Arrangement == TrayArrangementType.ArrangeInCross)
            {
                double[] trayCross = new double[]
                {
                    0.0, 0.0,
                    tray.Order_PositionA_X.WfsFormat(), tray.Order_PositionA_Y.WfsFormat(),
                    tray.Order_PositionB_X.WfsFormat(), tray.Order_PositionB_Y.WfsFormat(),
                    tray.Order_PositionC_X.WfsFormat(), tray.Order_PositionC_Y.WfsFormat(),
                    0.0, 0.0,
                    tray.Cross_PositionA_X.WfsFormat(), tray.Cross_PositionA_Y.WfsFormat(),
                    tray.Cross_PositionB_X.WfsFormat(), tray.Cross_PositionB_Y.WfsFormat(),
                    tray.Cross_PositionC_X.WfsFormat(), tray.Cross_PositionC_Y.WfsFormat(),
                };
                _ = _plc.WriteDoubleByInt32(trayStartDWordDevice, trayCross);
            }
            else
            {
                double[] trayOrder = new double[]
                {
                    0.0, 0.0,
                    tray.Order_PositionA_X.WfsFormat(), tray.Order_PositionA_Y.WfsFormat(),
                    tray.Order_PositionB_X.WfsFormat(), tray.Order_PositionB_Y.WfsFormat(),
                    tray.Order_PositionC_X.WfsFormat(), tray.Order_PositionC_Y.WfsFormat(),
                    0.0, 0.0,
                    0.0, 0.0,
                    0.0, 0.0,
                    0.0, 0.0,
                };
                _ = _plc.WriteDoubleByInt32(trayStartDWordDevice, trayOrder);
            }

            // 寫入依序/交錯 (方格/千鳥)
            _ = _plc.WriteBool(trayOrderCross, tray.Arrangement == TrayArrangementType.ArrangeInCross);

            // 寫入取料高度
            if (palletId >= 1 && palletId <= ITray.MaxPalletId)
                _ = _plc.WriteDoubleByInt32(DeviceLists.TRAY_PICK_HEIGHT[palletIndex], tray.PickHeight);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    private void WriteAllTraySettingToPlcEvent(int _)
    {
        WriteAllTraySettingToPlc();
    }

    /// <inheritdoc/>
    public void WriteAllTraySettingToPlc()
    {
        for (int palletIndex = 0; palletIndex < 24; palletIndex++)
        {
            var pallet = PalletList[palletIndex];
            if (pallet.InstallTray && GetTray(GetTrayId(pallet.Id), out TrayDefine tray))
                WriteTrayToPlc(pallet.Id, tray);
        }
        //_ea.GetEvent<PalletInfoChangedEvent>().Publish(true);
    }

    ///// <inheritdoc/>
    //public void ReadTrayFromPlc(int trayPosition, TrayDefine tray)
    //{
    //    string trayStartWordDevice;
    //    string trayStartDWordDevice;

    //    if (trayPosition >= MinTrayId && trayPosition <= MaxTrayId)
    //    {
    //        trayStartWordDevice = DeviceLists.TRAY_WORD[trayPosition - 1];
    //        trayStartDWordDevice = DeviceLists.TRAY_DWORD[trayPosition - 1];
    //    }
    //    else if (trayPosition == DeviceLists.VISUAL_TRAY_ID)
    //    {
    //        trayStartWordDevice = DeviceLists.VISUAL_TRAY_WORD;
    //        trayStartDWordDevice = DeviceLists.VISUAL_TRAY_DWORD;
    //    }
    //    else
    //    {
    //        new Exception("無效Tray ID");
    //    }
    //}

    /********************
     * Pallet
     ********************/
    /// <inheritdoc/>
    public void WritePalletToPlc(PalletDefine pallet)
    {
        if (_plc.Online)
        {
            int paramIndex = pallet.Id - 1;

            // D20820
            short[] palletWord = new short[]
            {
                (short)(pallet.ZAxis_PickDelay_BeforeVacuum * 10.0), (short)(pallet.ZAxis_UpDelay_AfterPick * 10.0),
                (short)(pallet.ZAxis_Place_VacuumRelief * 10.0), (short)(pallet.ZAxis_UpDelay_AfterPlace * 10.0),
                pallet.ZAxis_Pick_SpeedRate, pallet.ZAxis_Place_SpeedRate,
            };
            _ = _plc.WriteInt16(DeviceLists.PALLET_WORD[paramIndex], palletWord);

            // D20646、D20650
            _ = _plc.WriteInt32(DeviceLists.PALLET_DOWN_DEC[paramIndex], pallet.ZAxis_Pick_Height);
            _ = _plc.WriteInt32(DeviceLists.PALLET_UP_ASC[paramIndex], pallet.ZAxis_Place_Height);

            // D20652
            double[] palletDouble = new double[]
            {
                pallet.Order_OffsetX, pallet.Order_OffsetY,
                pallet.Cross_OffsetX, pallet.Cross_OffsetY,
                pallet.PickHeightOffset,
            };
            _ = _plc.WriteDoubleByInt32(DeviceLists.PALLET_DWORD[paramIndex], palletDouble);

            // D6101
            WriteStartPointNo(pallet);
            //_ = _plc.WriteInt32($"D{DeviceLists.TRAY_NEXT_POINT_NO_01 + pallet.Id}", pallet.PointNo);
        }
    }

    /// <inheritdoc/>
    public void ReadPalletFromPlc(PalletDefine pallet)
    {
        if (_plc.Online)
        {
            int paramIndex = pallet.Id - 1;

            // D20820
            var (wordParamsOK, wordParams) = _plc.ReadInt16(DeviceLists.PALLET_WORD[paramIndex], 6);
            if (wordParamsOK)
            {
                pallet.ZAxis_PickDelay_BeforeVacuum = (float)(wordParams[0] / 10.0).Format(1);
                pallet.ZAxis_UpDelay_AfterPick = (float)(wordParams[1] / 10.0).Format(1);
                pallet.ZAxis_Place_VacuumRelief = (float)(wordParams[2] / 10.0).Format(1);
                pallet.ZAxis_UpDelay_AfterPlace = (float)(wordParams[3] / 10.0).Format(1);
                pallet.ZAxis_Pick_SpeedRate = wordParams[4];
                pallet.ZAxis_Place_SpeedRate = wordParams[5];
            }

            // D20646
            var (slowDownOK, slowDown) = _plc.ReadInt32(DeviceLists.PALLET_DOWN_DEC[paramIndex]);
            if (slowDownOK)
                pallet.ZAxis_Pick_Height = slowDown;

            // D20650
            var (speedUpOK, speedUp) = _plc.ReadInt32(DeviceLists.PALLET_UP_ASC[paramIndex]);
            if (speedUpOK)
                pallet.ZAxis_Place_Height = speedUp;

            // D20652
            var (offsetsOK, offsets) = _plc.ReadDoubleByInt32(DeviceLists.PALLET_DWORD[paramIndex], 5);
            if (offsetsOK)
            {
                pallet.Order_OffsetX = offsets[0];
                pallet.Order_OffsetY = offsets[1];
                pallet.Cross_OffsetX = offsets[2];
                pallet.Cross_OffsetY = offsets[3];
                pallet.PickHeightOffset = offsets[4];
            }

            // D6101
            //var (currentPointNoOK, currentPointNo) = _plc.ReadInt16($"D{DeviceLists.TRAY_NEXT_POINT_NO_01 + pallet.Id}");
            //if (currentPointNoOK)
            //    pallet.PointNo = currentPointNo;
        }
    }

    /********************
     * Pallet
     ********************/
    /// <inheritdoc/>
    public void WriteStartPointNo(int palletId, int pointNo)
    {
        if (_plc.Online)
        {
            // D6101
            _ = _plc.WriteInt16($"D{DeviceLists.TRAY_NEXT_POINT_NO_01 + palletId}", (short)pointNo);
        }
    }

    /// <inheritdoc/>
    public void WriteStartPointNo(PalletDefine pallet)
    {
        if (_plc.Online)
        {
            // D6101
            _ = _plc.WriteInt16($"D{DeviceLists.TRAY_NEXT_POINT_NO_01 + pallet.Id}", (short)pallet.NextPointNo);
        }
    }

    /// <inheritdoc/>
    public int ReadStartPointNo(int palletId)
    {
        if (_plc.Online)
        {
            // D6101
            var (currentPointNoOK, currentPointNo) = _plc.ReadInt16($"D{DeviceLists.TRAY_NEXT_POINT_NO_01 + palletId}");
            return currentPointNoOK ? currentPointNo : -1;
        }
        return -1;
    }
}
