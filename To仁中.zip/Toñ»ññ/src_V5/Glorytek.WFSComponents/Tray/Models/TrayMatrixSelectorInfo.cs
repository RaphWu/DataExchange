﻿using Prism.Services.Dialogs;

namespace Glorytek.WFSComponents.Tray.Models;

/// <summary>
/// 點位選擇器資料。
/// </summary>
public class TrayMatrixSelectorInfo
{
    /// <summary>
    /// 返回按鍵。
    /// </summary>
    public ButtonResult Result { get; set; }

    /// <summary>
    /// Tray ID。
    /// </summary>
    public int TrayId { get; set; }

    /// <summary>
    /// 選擇的取放料編號。
    /// </summary>
    public int SequenceNo { get; set; }

    /// <summary>
    /// 選擇的點位序號。
    /// </summary>
    public int PointNo { get; set; }
}
