﻿using Prism.Mvvm;
using System;

namespace Glorytek.WFSComponents.Tray.Models;

/// <summary>
/// Tray矩陣方塊顯示用資料。
/// </summary>
public class TrayMatrixData : BindableBase
{
    private TrayMatrixData() { }
    private static readonly Lazy<TrayMatrixData> _instance = new(() => new TrayMatrixData());
    public static TrayMatrixData Instance => _instance.Value;

    /// <summary>
    /// 目前點位。
    /// </summary>
    public int CurrentPointNo
    {
        get { return _currentPointNo; }
        set { SetProperty(ref _currentPointNo, value); }
    }
    private int _currentPointNo = -1;

    /********************
     * 座標
     ********************/
    /// <summary>
    /// X軸 第一點X座標。
    /// </summary>
    public double XAxisX1
    {
        get { return _xAxisX1; }
        set { SetProperty(ref _xAxisX1, value); }
    }
    private double _xAxisX1;

    /// <summary>
    /// X軸 第二點X座標。
    /// </summary>
    public double XAxisX2
    {
        get { return _xAxisX2; }
        set { SetProperty(ref _xAxisX2, value); }
    }
    private double _xAxisX2;

    /// <summary>
    /// X軸 第一點Y座標。
    /// </summary>
    public double XAxisY1
    {
        get { return _xAxisY1; }
        set { SetProperty(ref _xAxisY1, value); }
    }
    private double _xAxisY1;

    /// <summary>
    /// X軸 第二點Y座標。
    /// </summary>
    public double XAxisY2
    {
        get { return _xAxisY2; }
        set { SetProperty(ref _xAxisY2, value); }
    }
    private double _xAxisY2;

    /// <summary>
    /// Y軸 第一點X座標。
    /// </summary>
    public double YAxisX1
    {
        get { return _yAxisX1; }
        set { SetProperty(ref _yAxisX1, value); }
    }
    private double _yAxisX1;

    /// <summary>
    /// Y軸 第二點X座標。
    /// </summary>
    public double YAxisX2
    {
        get { return _yAxisX2; }
        set { SetProperty(ref _yAxisX2, value); }
    }
    private double _yAxisX2;

    /// <summary>
    /// Y軸 第一點Y座標。
    /// </summary>
    public double YAxisY1
    {
        get { return _yAxisY1; }
        set { SetProperty(ref _yAxisY1, value); }
    }
    private double _yAxisY1;

    /// <summary>
    /// Y軸 第二點Y座標。
    /// </summary>
    public double YAxisY2
    {
        get { return _yAxisY2; }
        set { SetProperty(ref _yAxisY2, value); }
    }
    private double _yAxisY2;

    /********************
     * 
     ********************/
    /// <summary>
    /// 方塊顯示的訊息種類
    /// </summary>
    public BlockInformationType BlockInformationSelector { get; set; } = BlockInformationType.ID;
}
