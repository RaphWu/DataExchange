﻿namespace Glorytek.WFSComponents.Tray.Models;

/// <summary>
/// 方塊內顯示的訊息種類。
/// </summary>
public enum BlockInformationType
{
    ID,
    COOR,
}