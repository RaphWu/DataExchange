﻿namespace Glorytek.WFSComponents.Tray.Models;

/// <summary>
/// 顯示方塊的定義。
/// </summary>
public class BlockDefine
{
    /// <summary>
    /// 方塊順序編號。
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// 所屬Tray ID。
    /// </summary>
    public int TrayId { get; set; }

    /// <summary>
    /// 所屬排列方式。
    /// </summary>
    public int ArrangementId { get; set; }

    /// <summary>
    /// 顯示在方塊內的文字。
    /// </summary>
    public string Title { get; set; }

    /// <summary>
    /// 方塊顯示的左上角X座標。
    /// </summary>
    public double PositionX { get; set; }

    /// <summary>
    /// 方塊顯示的左上角Y座標。
    /// </summary>
    public double PositionY { get; set; }

    /// <summary>
    /// 方塊寬度。
    /// </summary>
    public double Width { get; set; }

    /// <summary>
    /// 方塊高度。
    /// </summary>
    public double Height { get; set; }

    /// <summary>
    /// 方塊前景顏色。
    /// </summary>
    public string FgColor { get; set; }

    /// <summary>
    /// 方塊背景景顏色。
    /// </summary>
    public string BgColor { get; set; }

    /// <summary>
    /// 是否為遮罩?
    /// </summary>
    public bool Mask { get; set; }

    /// <summary>
    /// 滑鼠點擊時回傳給ViewModel的值。
    /// </summary>
    public int Tag { get; set; }

    /// <summary>
    /// 方塊初始化。
    /// </summary>
    /// <param name="id">方塊順序編號。</param>
    /// <param name="trayId">所屬Tray ID。</param>
    /// <param name="arrangementId">所屬排列方式。</param>
    /// <param name="title">顯示在方塊內的文字。</param>
    /// <param name="positionX">方塊顯示的左上角X座標。</param>
    /// <param name="positionY">方塊顯示的左上角Y座標。</param>
    /// <param name="width">方塊寬度。</param>
    /// <param name="height">方塊高度。</param>
    /// <param name="fgColor">方塊前景顏色。</param>
    /// <param name="bgColor">方塊背景景顏色。</param>
    /// <param name="mask">是否為遮罩?</param>
    public BlockDefine(int id,
                       int trayId,
                       int arrangementId,
                       string title,
                       double positionX,
                       double positionY,
                       double width,
                       double height,
                       string fgColor,
                       string bgColor,
                       bool mask)
    {
        Id = id;
        TrayId = trayId;
        ArrangementId = arrangementId;
        Title = title;
        PositionX = positionX;
        PositionY = positionY;
        Width = width;
        Height = height;
        FgColor = fgColor;
        BgColor = bgColor;
        Mask = mask;
    }
}
