﻿using Glorytek.WFSCore.Models.Tray;

namespace Glorytek.WFSComponents.Tray.Models;

/// <summary>
/// 傳遞給TrayMatrix的RegionContext。
/// </summary>
public class TrayMatrixRegionContext
{
    /// <summary>
    /// Tray物件
    /// </summary>
    public TrayDefine Tray { get; set; }

    /// <summary>
    /// 此Tray所在Pallet位置
    /// </summary>
    public int PalletId { get; set; }
}
