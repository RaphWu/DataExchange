﻿using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Glorytek.WFSComponents.Tray.Models;

/// <summary>
/// ZoomAndPan資料。
/// </summary>
/// <remarks>因為此Model需要讓相關模組取用，故從ZoomAndPan移過來。</remarks>
public class ZoomAndPanModel : INotifyPropertyChanged
{
    /// <summary>
    /// The singleton instance.
    /// This is a singleton for convenience.
    /// </summary>
    private static readonly ZoomAndPanModel _instance = new ZoomAndPanModel();

    /// <summary>
    /// The list of rectangles that is displayed both in the main window and in the overview window.
    /// </summary>
    private ObservableCollection<BlockDefine> _blocks = new ObservableCollection<BlockDefine>();

    ///
    /// The current scale at which the content is being viewed.
    /// 
    private double _contentScale = 1;

    ///
    /// The X coordinate of the offset of the viewport onto the content (in content coordinates).
    /// 
    private double _contentOffsetX = 0;

    ///
    /// The Y coordinate of the offset of the viewport onto the content (in content coordinates).
    /// 
    private double _contentOffsetY = 0;

    ///
    /// The width of the content (in content coordinates).
    /// 
    private double _contentWidth = 0;

    ///
    /// The heigth of the content (in content coordinates).
    /// 
    private double _contentHeight = 0;

    ///
    /// The width of the viewport onto the content (in content coordinates).
    /// The value for this is actually computed by the main window's ZoomAndPanControl and update in the
    /// data model so that the value can be shared with the overview window.
    /// 
    private double _contentViewportWidth = 0;

    ///
    /// The heigth of the viewport onto the content (in content coordinates).
    /// The value for this is actually computed by the main window's ZoomAndPanControl and update in the
    /// data model so that the value can be shared with the overview window.
    /// 
    private double _contentViewportHeight = 0;

    /////
    ///// 方塊顯示的訊息種類
    ///// 
    //private BlockInformationType _blockInformationSelector = BlockInformationType.ID;

    /// <summary>
    /// Retreive the singleton instance.
    /// </summary>
    public static ZoomAndPanModel Instance => _instance;

    // ctor
    public ZoomAndPanModel()
    {
        //
        // Populate the data model with some example data.
        //
        //_rectangles.Add(new RectangleData(50, 50, 80, 150, Colors.Blue));
        //_rectangles.Add(new RectangleData(550, 350, 80, 150, Colors.Green));
        //_rectangles.Add(new RectangleData(850, 850, 30, 20, Colors.Purple));
        //_rectangles.Add(new RectangleData(1200, 1200, 80, 150, Colors.Red));
    }

    /// <summary>
    /// The list of rectangles that is displayed both in the main window and in the overview window.
    /// </summary>
    public ObservableCollection<BlockDefine> Blocks
    {
        get { return _blocks; }
        set
        {
            _blocks = value;
            OnPropertyChanged(nameof(Blocks));
        }
    }

    ///
    /// The current scale at which the content is being viewed.
    /// 
    public double ContentScale
    {
        get { return _contentScale; }
        set
        {
            _contentScale = value;
            OnPropertyChanged("ContentScale");
        }
    }

    ///
    /// The X coordinate of the offset of the viewport onto the content (in content coordinates).
    /// 
    public double ContentOffsetX
    {
        get { return _contentOffsetX; }
        set
        {
            _contentOffsetX = value;
            OnPropertyChanged("ContentOffsetX");
        }
    }

    ///
    /// The Y coordinate of the offset of the viewport onto the content (in content coordinates).
    /// 
    public double ContentOffsetY
    {
        get { return _contentOffsetY; }
        set
        {
            _contentOffsetY = value;
            OnPropertyChanged("ContentOffsetY");
        }
    }

    ///
    /// The width of the content (in content coordinates).
    /// 
    public double ContentWidth
    {
        get { return _contentWidth; }
        set
        {
            _contentWidth = value;
            OnPropertyChanged("ContentWidth");
        }
    }

    ///
    /// The heigth of the content (in content coordinates).
    /// 
    public double ContentHeight
    {
        get { return _contentHeight; }
        set
        {
            _contentHeight = value;
            OnPropertyChanged("ContentHeight");
        }
    }

    ///
    /// The width of the viewport onto the content (in content coordinates).
    /// The value for this is actually computed by the main window's ZoomAndPanControl and update in the
    /// data model so that the value can be shared with the overview window.
    /// 
    public double ContentViewportWidth
    {
        get { return _contentViewportWidth; }
        set
        {
            _contentViewportWidth = value;
            OnPropertyChanged("ContentViewportWidth");
        }
    }

    ///
    /// The heigth of the viewport onto the content (in content coordinates).
    /// The value for this is actually computed by the main window's ZoomAndPanControl and update in the
    /// data model so that the value can be shared with the overview window.
    /// 
    public double ContentViewportHeight
    {
        get { return _contentViewportHeight; }
        set
        {
            _contentViewportHeight = value;
            OnPropertyChanged("ContentViewportHeight");
        }
    }

    /// <summary>
    /// Raises the 'PropertyChanged' event when the value of a property of the data model has changed.
    /// </summary>
    private void OnPropertyChanged(string name)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    /// <summary>
    /// 'PropertyChanged' event that is raised when the value of a property of the data model has changed.
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;
}
