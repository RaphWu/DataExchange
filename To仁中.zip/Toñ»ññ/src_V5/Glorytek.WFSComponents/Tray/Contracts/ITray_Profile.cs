﻿using Glorytek.WFSCore.Models.Tray;
using System.Collections.Generic;

namespace Glorytek.WFSComponents.Tray.Contracts;

/// <summary>
/// Tray和Pallet處理介面 - Tray點位計算。
/// </summary>
public interface ITray_Profile
{
    /// <summary>
    /// 取得所有的點位及遮罩。
    /// </summary>
    /// <param name="trayId">Feeder ID。</param>
    /// <param name="profileList">接收所有點位的List。</param>
    /// <param name="maskList">接收所有Mask的List。</param>
    /// <returns>點位及遮罩是否都有資料。</returns>
    bool GetProfile(int trayId, out List<TrayProfileDefine> profileList, out List<TrayMaskDefine> maskList);

    /// <summary>
    /// 檢查SequenceNo是否為Mask。
    /// </summary>
    /// <param name="trayId">Feeder ID。</param>
    /// <param name="sequenceNo">Sequence No。</param>
    /// <returns>true: 此點位被標記為Mask。</returns>
    bool IsMask(int trayId, int sequenceNo);

    /// <summary>
    /// 計算所有點位資料。
    /// </summary>
    /// <param name="tray">Tray資料複本(ABC點已轉。</param>
    /// <param name="mask">。</param>
    /// <returns>所有點位的List。</returns>
    /// <remarks>基準點及ABC須先算好絕對值。</remarks>
    List<TrayProfileDefine> CalculateProfile(TrayDefine tray, List<TrayMaskDefine> mask);

    /********************
     * 轉換
     ********************/
    /// <summary>
    /// 將 點位序號 轉換為 取放點編號。
    /// </summary>
    /// <param name="trayId">Tray盤ID。</param>
    /// <param name="pointNo">點位序號。</param>
    /// <returns>取放點編號。若轉換失敗則回傳0。</returns>
    int ConvertPointNoToSequenceNo(int trayId, int pointNo);

    /// <summary>
    /// 將 取放點編號 轉換為 點位序號。
    /// </summary>
    /// <param name="trayId">Tray盤ID。</param>
    /// <param name="sequenceNo">取放點編號。</param>
    /// <returns>點位序號。若轉換失敗則回傳0。</returns>
    int ConvertSequenceNoToPointNo(int trayId, int sequenceNo);
}