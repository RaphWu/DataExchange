﻿using Glorytek.WFSComponents.Tray.Models;
using Glorytek.WFSCore.Models.Tray;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Glorytek.WFSComponents.Tray.Contracts;

/// <summary>
/// Tray和Pallet處理介面 - Tray矩陣作業。
/// </summary>
public interface ITray_TrayMatrix
{
    /// <summary>
    /// 重繪方塊矩陣。
    /// </summary>
    /// <param name="drawTray">要繪製的Tray，基準點須已經換算至相對Pallet位置。</param>
    /// <param name="profile">Tray點位資料。</param>
    /// <param name="mask">Tray無效點資料。</param>
    /// <returns>ZoomAndPanModel 物件。</returns>
    ObservableCollection<BlockDefine> RedrawBlocks(TrayDefine drawTray,
                                                   List<TrayProfileDefine> profile,
                                                   List<TrayMaskDefine> mask);

    /// <summary>
    /// 切換Mask狀態。
    /// </summary> 
    /// <param name="block">要切換的方塊資料。</param>
    /// <param name="mask">Tray無效點資料。</param>
    /// <param name="trayId">Tray ID。</param>
    /// <param name="totalPoint">總點位數。</param>
    void ToggleMaskState(ref BlockDefine block, ref List<TrayMaskDefine> mask, int trayId, int totalPoint);
}
