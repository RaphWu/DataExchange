﻿using Glorytek.WFSCore.Models.Tray;

namespace Glorytek.WFSComponents.Tray.Contracts;

/// <summary>
/// Tray和Pallet處理介面 - PLC讀寫。
/// </summary>
public interface ITray_PLC
{
    /********************
     * Tray
     ********************/
    /// <summary>
    /// 將Tray參數寫入PLC。
    /// </summary>
    /// <param name="palletId">PLC中的Tray定位編號<br/>工作Tray: 1~24<br/>虛擬Tray: DeviceLists.VISUAL_TRAY_ID。</param>
    /// <param name="tray">Tray物件。</param>
    void WriteTrayToPlc(int palletId, TrayDefine tray);

    /// <summary>
    /// 將所有Tray參數寫入PLC。
    /// </summary>
    void WriteAllTraySettingToPlc();

    ///// <summary>
    ///// 從PLC讀取Tray參數。
    ///// </summary>
    ///// <param name="trayPosition">PLC中的Tray定位編號(1~24)。</param>
    ///// <param name="tray">Tray物件。</param>
    //void ReadTrayFromPlc(int trayPosition, TrayDefine tray);

    /********************
     * Pallet
     ********************/
    /// <summary>
    /// 將Pallet寫入PLC。
    /// </summary>
    void WritePalletToPlc(PalletDefine pallet);

    /// <summary>
    /// 從PLC讀取Pallet。
    /// </summary>
    void ReadPalletFromPlc(PalletDefine pallet);

    /********************
     * Pallet
     ********************/
    /// <summary>
    /// 
    /// </summary>
    /// <param name="palletId"></param>
    /// <param name="pointNo"></param>
    void WriteStartPointNo(int palletId, int pointNo);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="pallet"></param>
    void WriteStartPointNo(PalletDefine pallet);

    /// <summary>
    /// 
    /// </summary>
    /// <param name="pallet"></param>
    int ReadStartPointNo(int palletId);
}
