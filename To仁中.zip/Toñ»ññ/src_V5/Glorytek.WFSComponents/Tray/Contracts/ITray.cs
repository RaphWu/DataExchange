﻿using Glorytek.WFSCore.Models.Tray;
using System.Collections.Generic;

namespace Glorytek.WFSComponents.Tray.Contracts;

/// <summary>
/// Tray和Pallet處理介面。
/// </summary>
public interface ITray : ITray_Tray, ITray_Profile, ITray_PLC, ITray_TrayMatrix
{
    /// <summary>
    /// 最大Pallet ID編號。
    /// </summary>
    public const int MaxPalletId = 24;

    /// <summary>
    /// 最多無效點數。
    /// </summary>
    public const int MaxMask = 20;

    /********************
     * Database
     ********************/
    /// <summary>
    /// 儲存Tray資料至資料庫。
    /// </summary>
    /// <returns>儲存是否成功。</returns>
    // Tray由TrayViewModel管理
    bool WriteTrayToDb();

    /// <summary>
    /// 儲存Tray資料至資料庫。
    /// </summary>
    /// <param name="tray">更新的Tray。</param>
    /// <returns>儲存是否成功。</returns>
    bool WriteTrayToDb(TrayDefine tray);

    /// <summary>
    /// 儲存單一Profile及Mask。
    /// </summary>
    // Profile及Mask由TrayMatrixViewModel管理
    void WriteProfileAndMaskToDb(int trayId, List<TrayProfileDefine> profiles, List<TrayMaskDefine> masks);

    /// <summary>
    /// 從資料庫讀取Tray資料。
    /// </summary>
    /// <returns>讀取是否成功。</returns>
    bool ReadFromDb();

    /********************
     * 取得物件
     ********************/
    /// <summary>
    /// Tray主資料表。
    /// </summary>
    List<TrayDefine> TrayList { get; }

    /// <summary>
    /// 所有點位座標。
    /// </summary>
    List<TrayProfileDefine> ProfileList { get; }

    /// <summary>
    /// Tray無效點位。
    /// </summary>
    List<TrayMaskDefine> MaskList { get; }

    /// <summary>
    /// Tray資料庫名稱。
    /// </summary>
    string TableName_Tray { get; }

    /// <summary>
    /// Pallet資料。
    /// </summary>
    List<PalletDefine> PalletList { get; }

    /// <summary>
    /// 取得指定Pallet上所設定的Tray ID。
    /// </summary>
    /// <param name="palletId">Pallet ID。</param>
    /// <returns>安裝Tray的ID；若未安裝Tray則返回-1。</returns>
    int GetTrayId(int palletId);

    /// <summary>
    /// 取得那個Pallet上設定的Tray是指定的ID。
    /// </summary>
    /// <param name="trayId">指定的Tray ID。</param>
    /// <returns>所安裝的Pallet位置ID；若找不到則返回-1。</returns>
    int GetPalletId(int trayId);

    /// <summary>
    /// 取得全部入料Tray的總點位數。
    /// </summary>
    /// <returns>入料Tray的總點位數；若無設定入料Tray則返回0。</returns>
    int GetTotalSequenceOfFeeder();
}
