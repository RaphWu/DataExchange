﻿using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.Tray;
using System.Collections.Generic;

namespace Glorytek.WFSComponents.Tray.Contracts;

/// <summary>
/// Tray和Pallet處理介面 - Tray作業。
/// </summary>
public interface ITray_Tray
{
    /********************
     * TraySelector
     ********************/
    /// <summary>
    /// 讀取Tray選擇清單。
    /// </summary>
    /// <param name="includeUnused">是否包含Unused。</param>
    Dictionary<int, string> TraySelector(bool includeUnused = false);

    ///// <summary>
    ///// 選擇用的Tray列表
    ///// </summary>
    //Dictionary<int, string> GetFeederList();

    /********************
     * CRUD
     ********************/
    /// <summary>
    /// 建立新Tray資料。
    /// </summary>
    /// <param name="crudInfo">CrudInfo物件。</param>
    /// <returns>新Tray的ID。</returns>
    int CreateNewTray(CrudInfo crudInfo);

    /// <summary>
    /// 複製Tray。
    /// </summary>
    /// <param name="crudInfo">CrudInfo物件。</param>
    /// <returns>新Tray的ID。</returns>
    int CopyTray(CrudInfo crudInfo);

    /// <summary>
    /// 變更Tray名稱。
    /// </summary>
    /// <param name="crudInfo">CrudInfo物件。</param>
    /// <returns>名稱是否變更完成。</returns>
    bool RenameTray(CrudInfo crudInfo);

    /// <summary>
    /// 刪除Tray。
    /// </summary>
    /// <param name="feederId">要刪除的Tray ID。</param>
    /// <returns>刪除是否完成。</returns>
    bool DeleteTray(int feederId);

    /********************
     * Table
     ********************/
    /// <summary>
    /// 檢查Tray ID是否已存在資料庫。
    /// </summary>
    /// <param name="trayId">Tray Id。</param>
    /// <returns>true: Tray Id已存在<br/>false: Tray Id不存在。</returns>
    bool IsTrayExist(int trayId);

    /// <summary>
    /// 檢查Tray Name是否已存在資料庫。
    /// </summary>
    /// <param name="trayName">Tray Name。</param>
    /// <returns>true: Tray Name已存在<br/>false: Tray Name不存在。</returns>
    bool IsTrayExist(string trayName);

    /********************
     * ID與Name轉換
     ********************/
    /// <summary>
    /// 以Tray名稱取得Tray ID。
    /// </summary>
    /// <param name="name">Tray名稱。</param>
    /// <returns>Tray Id。</returns>
    int GetIdFromName(string name);

    /// <summary>
    /// 以Tray ID取得Tray名稱。
    /// </summary>
    /// <param name="id">Tray Id。</param>
    /// <returns>Tray名稱。</returns>
    string GetNameFromId(int id);

    /********************
     * Tray作業
     ********************/
    /// <summary>
    /// 取得Tray物件。
    /// </summary>
    /// <param name="trayId">欲取得的Tray ID。</param>
    /// <param name="tray">取得的Tray。</param>
    /// <returns>取得是否完成。若為false，表示取得的Tray為null。</returns>
    bool GetTray(int trayId, out TrayDefine tray);

    /// <summary>
    /// 取得Tray物件。
    /// </summary>
    /// <param name="trayId">欲取得的Tray ID。</param>
    /// <returns>取得是否完成。若為false，表示取得的Tray為null。</returns>
    TrayDefine GetTray(int trayId);

    /********************
     * OrderNo操作
     ********************/
    /// <summary>
    /// 將指定ID的Tray排序往上移。
    /// </summary>
    /// <param name="trayId">指定Tray的ID。</param>
    /// <returns>移動是否完成。</returns>
    bool MoveOrderUp(int trayId);

    /// <summary>
    /// 將指定ID的Tray排序往下移。
    /// </summary>
    /// <param name="trayId">指定Tray的ID。</param>
    /// <returns>移動是否完成。</returns>
    bool MoveOrderDown(int trayId);
}
