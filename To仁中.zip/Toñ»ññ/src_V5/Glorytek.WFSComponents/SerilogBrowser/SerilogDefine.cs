﻿using Dapper.Contrib.Extensions;
using System;
using System.Globalization;

namespace Glorytek.WFSComponents.SerilogBrowser;

/// <summary>
/// Serilog報表資料定義。
/// </summary>
[Table("Logs")]
public class SerilogDefine
{
    /// <summary>
    /// Key。
    /// </summary>
    [Key]
    public int id { get; set; }

    /// <summary>
    /// 時間戳。
    /// </summary>
    public string Timestamp { get; set; }

    /// <summary>
    /// 警報等級。
    /// </summary>
    public string Level { get; set; }

    /// <summary>
    /// 異常訊息。
    /// </summary>
    public string RenderedMessage { get; set; }

    /// <summary>
    /// 例外訊息。
    /// </summary>
    public string Exception { get; set; }

    /// <summary>
    /// 屬性。
    /// </summary>
    public string Properties { get; set; }

    /// <summary>
    /// 時間戳顯示格式。
    /// </summary>
    [Computed]
    public DateTime TimeStamp => DateTime.Parse(Timestamp, new CultureInfo("zh-Hant"));
}
