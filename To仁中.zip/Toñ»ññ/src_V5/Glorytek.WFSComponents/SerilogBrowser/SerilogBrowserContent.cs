﻿using Glorytek.WPF.Helpers;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.ComponentModel;

namespace Glorytek.WFSComponents.SerilogBrowser;

/// <summary>
/// Serilog報表瀏覽器繫結資料。
/// </summary>
public class SerilogBrowserContent : BindableBase
{
    private static readonly Lazy<SerilogBrowserContent> _instance = new(() => new SerilogBrowserContent());
    public static SerilogBrowserContent Instance => _instance.Value;

    /********************
     * External Data
     ********************/
    ///// <summary>
    ///// 報表內容。
    ///// </summary>
    //public List<SerilogDefine> ReportSource
    //{
    //    get { return _reportSource; }
    //    set
    //    {
    //        _reportSource = value;
    //        ReportCollectionView = CollectionViewSource.GetDefaultView(value.OrderByDescending(x => x.TimeStamp));
    //    }
    //}
    //private List<SerilogDefine> _reportSource;

    /********************
     * View's Data
     ********************/
    /// <summary>
    /// 顯示的資料。
    /// </summary>
    public ICollectionView ReportCollectionView
    {
        get { return _reportCollectionView; }
        set
        {
            SetProperty(ref _reportCollectionView, value);

            if (_reportCollectionView != null)
            {
                TotalRecord = _reportCollectionView.AsList<SerilogDefine>().Count;

                _reportCollectionView.CollectionChanged += (o, e) =>
                {
                    TotalRecord = ReportCollectionView.AsList<SerilogDefine>().Count;
                };

                _reportCollectionView.CurrentChanged += (o, e) =>
                {
                    if (_reportCollectionView != null && !_reportCollectionView.IsEmpty)
                        CurrentRecord = _reportCollectionView.CurrentPosition + 1;
                    else
                        CurrentRecord = 0;
                };
            }
        }
    }
    private ICollectionView _reportCollectionView;

    /// <summary>
    /// 紀錄顯示。
    /// </summary>
    public string RecordString
    {
        get { return _recordString; }
        set { SetProperty(ref _recordString, value); }
    }
    private string _recordString;

    /// <summary>
    /// 資料筆數。
    /// </summary>
    public int TotalRecord
    {
        get { return _totalRecord; }
        set
        {
            _totalRecord = value;
            RecordString = $"{CurrentRecord} of {_totalRecord}";
        }
    }
    private int _totalRecord;

    /// <summary>
    /// 目前紀錄指標。
    /// </summary>
    public int CurrentRecord
    {
        get { return _currentRecord; }
        set
        {
            _currentRecord = value;
            RecordString = $"{_currentRecord} of {TotalRecord}";
        }
    }
    private int _currentRecord;

    /// <summary>
    /// 是否顯示ExceptionLog欄位。
    /// </summary>
    public bool ShowExtendData
    {
        get { return _showExtendData; }
        set { SetProperty(ref _showExtendData, value); }
    }
    private bool _showExtendData;

    /********************
     * Record Navigation Bar
     ********************/
    /// <summary>
    /// 移動一頁資料筆數。
    /// </summary>
    public int PageSize { get; set; } = 20;

    public const int RowDetailHeight = 3;
    /// <summary>
    /// 顯示RowDetails。
    /// </summary>
    /// <summary>
    /// 
    /// </summary>
    public bool RowDetailsVisibilityMode
    {
        get { return _rowDetailsVisibilityMode; }
        set
        {
            SetProperty(ref _rowDetailsVisibilityMode, value);

            if (_rowDetailsVisibilityMode)
                PageSize -= RowDetailHeight;
            else
                PageSize += RowDetailHeight;
        }
    }
    private bool _rowDetailsVisibilityMode = false;

    /// <summary>
    /// 第一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToFirstCommand
        => _moveToFirstCommand ??= new DelegateCommand(ExecuteMoveToFirstCommand);
    private void ExecuteMoveToFirstCommand()
    {
        _ = ReportCollectionView.MoveCurrentToFirst();
    }
    private DelegateCommand _moveToFirstCommand;

    /// <summary>
    /// 最後一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToLastCommand
        => _moveToLastCommand ??= new DelegateCommand(ExecuteMoveToLastCommand);
    private void ExecuteMoveToLastCommand()
    {
        _ = ReportCollectionView.MoveCurrentToLast();
    }
    private DelegateCommand _moveToLastCommand;

    /// <summary>
    /// 上一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToPreviousCommand
        => _moveToPreviousCommand ??= new DelegateCommand(ExecuteMoveToPreviousCommand);
    private void ExecuteMoveToPreviousCommand()
    {
        _ = ReportCollectionView.MoveCurrentToPrevious();
        if (ReportCollectionView.IsCurrentBeforeFirst)
            _ = ReportCollectionView.MoveCurrentToLast();
    }
    private DelegateCommand _moveToPreviousCommand;

    /// <summary>
    /// 下一筆紀錄。
    /// </summary>
    public DelegateCommand MoveToNextCommand
        => _moveToNextCommand ??= new DelegateCommand(ExecuteMoveToNextCommand);
    private void ExecuteMoveToNextCommand()
    {
        _ = ReportCollectionView.MoveCurrentToNext();
        if (ReportCollectionView.IsCurrentAfterLast)
            _ = ReportCollectionView.MoveCurrentToFirst();
    }
    private DelegateCommand _moveToNextCommand;

    /// <summary>
    /// 上一頁。
    /// </summary>
    public DelegateCommand MoveToPreviousPageCommand
        => _moveToPreviousPageCommand ??= new DelegateCommand(ExecuteMoveToPreviousPageCommand);
    private void ExecuteMoveToPreviousPageCommand()
    {
        try
        {
            _ = ReportCollectionView.MoveCurrentToPosition(ReportCollectionView.CurrentPosition - PageSize);
        }
        catch
        {
            _ = ReportCollectionView.MoveCurrentToFirst();
        }
    }
    private DelegateCommand _moveToPreviousPageCommand;

    /// <summary>
    /// 下一頁。
    /// </summary>
    public DelegateCommand MoveToNextPageCommand
        => _moveToNextPageCommand ??= new DelegateCommand(ExecuteMoveToNextPageCommand);
    private void ExecuteMoveToNextPageCommand()
    {
        try
        {
            _ = ReportCollectionView.MoveCurrentToPosition(ReportCollectionView.CurrentPosition + PageSize);
        }
        catch
        {
            _ = ReportCollectionView.MoveCurrentToLast();
        }
    }
    private DelegateCommand _moveToNextPageCommand;
}
