﻿using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.ProductManager.Services;
using Glorytek.WFSComponents.Stage.Contracts;
using Glorytek.WFSComponents.Stage.Services;
using Glorytek.WFSComponents.Systems.Contracts;
using Glorytek.WFSComponents.Systems.Services;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Services;
using Glorytek.WFSComponents.ViewModels;
using Glorytek.WFSComponents.Views;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSComponents.WFS.Services;
using Glorytek.WFSCore.Constants;
using Glorytek.WPF.PrismSplashScreen;
using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;

namespace Glorytek.WFSComponents
{
    public class WFSComponentsModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            IEventAggregator ea = containerProvider.Resolve<IEventAggregator>();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "機台參數初始化..." });
            var machine = containerProvider.Resolve<MachineService>();
            machine.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "軟體參數初始化..." });
            var sys = containerProvider.Resolve<SystemService>();
            sys.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "Tray初始化..." });
            var tray = containerProvider.Resolve<TrayService>();
            tray.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "Stage初始化..." });
            var stage = containerProvider.Resolve<StageService>();
            stage.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "WFS參數初始化..." });
            var wfs = containerProvider.Resolve<WfsService>();
            wfs.ModuleInit();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "品種管理員初始化..." });
            var pm = containerProvider.Resolve<ProductManagerService>();
            pm.ModuleInit();
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.Register<IProductManager, ProductManagerService>();
            containerRegistry.Register<IProductCrud, ProductCrudService>();
            containerRegistry.Register<ITray, TrayService>();
            containerRegistry.Register<IWfs, WfsService>();

            containerRegistry.Register<ISystem, SystemService>();
            containerRegistry.Register<IMachine, MachineService>();
            containerRegistry.Register<IStage, StageService>();

            containerRegistry.RegisterForNavigation<Pm, PmViewModel>(PageKeys.ProductManager);
            containerRegistry.RegisterForNavigation<Manual, ManualViewModel>(PageKeys.Manual);
            containerRegistry.RegisterForNavigation<Teaching, TeachingViewModel>(PageKeys.Teaching);
            containerRegistry.RegisterForNavigation<Views.Tray, TrayViewModel>(PageKeys.Tray);
            containerRegistry.RegisterForNavigation<WfsSpecification, WfsSpecificationViewModel>(PageKeys.WfsSpecification);
            containerRegistry.RegisterForNavigation<LensSorting, LensSortingViewModel>(PageKeys.LensSorting);
            containerRegistry.RegisterForNavigation<LensArrange, LensArrangeViewModel>(PageKeys.LensArrange);
            containerRegistry.RegisterForNavigation<BigData, BigDataViewModel>(PageKeys.BigData);

            containerRegistry.RegisterForNavigation<SettingsPage, SettingsPageViewModel>(PageKeys.SettingsPage);
            containerRegistry.RegisterForNavigation<SystemSetting, SystemSettingViewModel>(PageKeys.SystemSetting);
            containerRegistry.RegisterForNavigation<ParamFileOperate, ParamFileOperateViewModel>(PageKeys.ParamFileOperate);

            containerRegistry.RegisterForNavigation<RepeatabilityTest, RepeatabilityTestViewModel>(PageKeys.RepeatabilityTest);

            // Dialog
            containerRegistry.RegisterDialog<PmCrudDialog, PmCrudDialogViewModel>();
            containerRegistry.RegisterDialog<TrayMatrixSelector, TrayMatrixSelectorViewModel>();
        }
    }
}