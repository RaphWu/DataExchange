﻿using Glorytek.WFSCore.Models.ProductManager;
using System.Data.SQLite;

namespace Glorytek.WFSComponents.ProductManager.Contracts;

/// <summary>
/// 品種管理介面。
/// </summary>
public interface IProductManager
{
    /// <summary>
    /// 目前開啟的品種DB連線。
    /// </summary>
    SQLiteConnection DbConnection { get; }

    /// <summary>
    /// 產品的資料庫檔案名稱。
    /// </summary>
    string DB_NAME_PRODUCT { get; }

    /// <summary>
    /// 作業品種名稱是否有效。
    /// </summary>
    bool IsProductActive { get; }

    /// <summary>
    /// 目前有效品種名稱。
    /// </summary>
    string ActiveProductName { get; }

    ///// <summary>
    ///// 最後啟用的品種。
    ///// </summary>
    //string LastActiveProduct { get; }

    /// <summary>
    /// 目前品種的狀態資料。
    /// </summary>
    ProductDatas Datas { get; }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 將品種資訊寫回Database。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    /// <returns>寫入是否成功。</returns>
    bool WriteToDb(string productName);

    /// <summary>
    /// 將品種資訊寫回Database，並變更品種名稱。
    /// </summary>
    /// <param name="newProductName">新品種名稱。</param>
    /// <param name="oriProductName">原品種名稱。</param>
    /// <returns>寫入是否成功。</returns>
    /// <remarks>此寫回方法不自動建立資料表</remarks>
    bool WriteToDb(string newProductName, string oriProductName);

    /// <summary>
    /// 從Database重建ProductList。
    /// </summary>
    /// <returns>重建是否成功。</returns>
    bool ReadFromDb();

    /********************
     * 共用函式
     ********************/
    /// <summary>
    /// 品種ID是否存在列表中。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    /// <returns>true: 存在<br/>false: 不存在。</returns>
    bool IsProductExist(string productName);

    /// <summary>
    /// 檢查該品種名稱是否正在啟用中？
    /// </summary>
    /// <param name="productName">要檢查的品種名稱。</param>
    /// <returns>true: 正在啟用中<br/>false: 不在啟用中。</returns>
    bool IsActiveProduct(string productName);

    /// <summary>
    /// 取得品種名稱在列表中的Index位址。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    /// <returns>Index位址。</returns>
    int GetIndex(string productName);

    /********************
     * 品種作業
     ********************/
    /// <summary>
    /// 切換作業品種。
    /// </summary>
    /// <param name="productName">作業品種名稱。<br/>空字串表示系統將切換至無作業品種狀態。</param>
    /// <returns>切換是否成功。<br/>會同時設置 IsProductActive。</returns>
    bool SwitchProduct(string productName);
}
