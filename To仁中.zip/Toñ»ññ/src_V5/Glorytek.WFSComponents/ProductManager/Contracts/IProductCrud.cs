﻿using Glorytek.WFSCore.Models.ProductManager;

namespace Glorytek.WFSComponents.ProductManager.Contracts;

/// <summary>
/// 品種CRUD操作介面。
/// </summary>
/// <remarks>此介面勿在ProductManager之外引用操作。</remarks>
public interface IProductCrud
{
    /// <summary>
    /// 建立新品種。
    /// </summary>
    /// <param name="productCrudInfo">品種CRUD資訊。</param>
    /// <returns>true: 資料庫檔案已新建。<br/>false: 資料庫檔案原已存在、新增失敗、或名稱重複。</returns>
    bool CreateProduct(ProductCrudInfo productCrudInfo);

    /// <summary>
    /// 複製品種。
    /// </summary>
    /// <param name="productCrudInfo">品種CRUD資訊。</param>
    /// <returns>是否複製成功。</returns>
    bool CopyProduct(ProductCrudInfo productCrudInfo);

    /// <summary>
    /// 品種編輯。
    /// </summary>
    /// <param name="productCrudInfo">品種CRUD資訊。</param>
    /// <returns>是否編輯成功。</returns>
    bool ModifyProduct(ProductCrudInfo productCrudInfo);

    /// <summary>
    /// 刪除符合的品種名稱。
    /// </summary>
    /// <param name="productName">品種名稱。</param>
    /// <returns>是否刪除成功。</returns>
    bool DeleteProduct(string productName);
}
