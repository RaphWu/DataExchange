﻿using Dapper;
using Glorytek.SQLite;
using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSComponents.Tray.Contracts;
using Glorytek.WFSComponents.Tray.Services;
using Glorytek.WFSComponents.WFS.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Models.ProductManager;
using Glorytek.WFSExternal.PLC.Contracts;
using Glorytek.WFSExternal.Views;
using Prism.Events;
using Prism.Ioc;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Glorytek.WFSComponents.ProductManager.Services;

/// <summary>
/// 品種管理Service。
/// </summary>
public class ProductManagerService : IProductManager
{
    private readonly SystemDataInstance _sdi = SystemDataInstance.Instance;
    private readonly ProductDatas _pd = ProductDatas.Instance;

    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;
    private readonly ISystemMessenger _sysMessenger;
    private readonly IPlc _plc;

    public ProductManagerService(IEventAggregator ea,
                                 ISystemMessenger sysMessenger,
                                 IPlc plc)
    {
        _ea = ea;
        _sysMessenger = sysMessenger;
        _plc = plc;

        if (_pd.ProductList == null)
        {
            _pd.ProductList = new List<ProductDefine>();
            ReadFromDb();
        }

        //_ea.GetEvent<OnProductChangeover>().Subscribe(ShowProductInformation);
        //_ea.GetEvent<LanguageChanged>().Subscribe(ShowProductInformation);
    }

    /// <inheritdoc/>
    public SQLiteConnection DbConnection => _pd.DbConnection;

    /// <inheritdoc/>
    public string DB_NAME_PRODUCT => DB_ProductManager.DbName_Product;

    /// <inheritdoc/>
    public string ActiveProductName => _pd.ActiveProductName;

    /// <inheritdoc/>
    public bool IsProductActive => _pd.IsProductActive;

    /// <inheritdoc/>
    public ProductDatas Datas => ProductDatas.Instance;

    /********************
     * Database
     ********************/
    /// <inheritdoc/>
    public bool WriteToDb(string productName)
    {
        ProductDefine product = _pd.ProductList.Find(x => x.ProductName == productName);
        if (product == null)
        {
            string errMsg = "品種列表讀取錯誤: ProductManagerService->WriteToDb()";
            Log.Fatal(errMsg);
            throw new Exception(errMsg);
        }

        return Writing(product);
    }

    /// <inheritdoc/>
    public bool WriteToDb(string newProductName, string oriProductName)
    {
        // Note: objProduct內已是newProductName內容
        ProductDefine product = _pd.ProductList.Find(x => x.ProductName == newProductName);
        if (product == null)
        {
            Log.Error("ProductManagerService->WriteToDb(string newProductName, string oriProductName)");
            throw new Exception("品種列表讀取錯誤: WriteToDb()");
        }

        // 更名
        if (newProductName != oriProductName)
        {
            string oriFilePath = Path.Combine(DBbase.Directory_Product, $"{oriProductName}{DBbase.DB_ExtFileName}");
            string newFilePath = Path.Combine(DBbase.Directory_Product, $"{newProductName}{DBbase.DB_ExtFileName}");
            File.Move(oriFilePath, newFilePath);
        }

        return Writing(product);
    }

    /// <summary>
    /// 寫入DB。
    /// </summary>
    private bool Writing(ProductDefine product)
    {
        string dbFilePath = Path.Combine(DBbase.Directory_Product, $"{product.ProductName}{DBbase.DB_ExtFileName}");
        using (var conn = SQLiteHelper.OpenConnection(dbFilePath))
        {
            if (conn != null)
            {
                using var tran = conn.BeginTransaction();
                try
                {
                    string sql;
                    if (SQLiteHelper.IsTableExist(conn, DB_ProductManager.TableName_Information))
                    {
                        // 僅更新
                        sql = $@"UPDATE {DB_ProductManager.TableName_Information}
SET ProductName = @ProductName, Memo = @Memo;";
                    }
                    else
                    {
                        // 新品種資料
                        SQLiteHelper.CreateTable(conn, DB_ProductManager.CreateTableSQL_Information);
                        sql = $@"INSERT INTO {DB_ProductManager.TableName_Information}
(ProductName, Memo) VALUES (@ProductName, @Memo);";
                    }

                    conn.ExecuteAsync(sql, new
                    {
                        product.ProductName,
                        product.Memo,
                    }, transaction: tran);
                    tran.Commit();
                }
                catch
                {
                    tran.Rollback();
                }
            }
        }
        return true;
    }

    /// <inheritdoc/>
    public bool ReadFromDb()
    {
        _pd.ProductList.Clear();

        try
        {
            // 取得品種資料庫檔案列表
            IEnumerable<string> fileList = Directory.EnumerateFiles(DBbase.Directory_Product, $"*{DBbase.DB_ExtFileName}");
            foreach (string path in fileList)
            {
                // 讀取DB中的品種資訊
                using var conn = SQLiteHelper.OpenConnection(path);
                if (conn != null)
                {
                    using var tran = conn.BeginTransaction();
                    try
                    {
                        string sql = $"SELECT * FROM {DB_ProductManager.TableName_Information};";
                        ProductDefine obj = conn.QueryFirst<ProductDefine>(sql, transaction: tran);
                        if (obj == null)
                            return false;

                        tran.Commit();

                        // 記錄到List
                        _pd.ProductList.Add(new ProductDefine()
                        {
                            ProductName = Path.GetFileNameWithoutExtension(path),
                            Memo = obj.Memo
                        });
                    }
                    catch
                    {
                        tran.Rollback();
                    }
                }
            }
        }
        catch (DirectoryNotFoundException)
        {
            // 品種資料夾不存在 => 建立資料夾、品種列表為空
            Directory.CreateDirectory(DBbase.Directory_Product);
        }

        return true;
    }

    /// <summary>
    /// 模組初始化。
    /// </summary>
    internal void ModuleInit()
    {
        //LastProductName lastProductName = _ioService.Read<LastProductName>(DBbase.Directory_Product, _LAST_PRODUCT_FILENAME);

        var (isSuccessed, _lastProductName) = _plc.ReadProductName();
        if (isSuccessed && _lastProductName != "")
        {
            SwitchProduct(_lastProductName);
            //_sysMessenger.ActiveProduct(_lastProductName);
        }
        else
        {
            SwitchProduct("");
        }
    }

    /********************
     * 共用函式
     ********************/
    /// <inheritdoc/>
    public bool IsProductExist(string productName)
        => _pd.ProductList.Exists(x => x.ProductName == productName);

    /// <inheritdoc/>
    public bool IsActiveProduct(string productName) => productName == _pd.ActiveProductName;

    /// <inheritdoc/>
    public int GetIndex(string productName)
        => _pd.ProductList.FindIndex(x => x.ProductName == productName);

    /********************
     * 品種作業
     ********************/
    /// <inheritdoc/>
    public bool SwitchProduct(string productName)
    {
        SQLiteHelper.Vaccum(_pd.DbConnection);
        SQLiteHelper.Close(_pd.DbConnection);

        int productIndex = string.IsNullOrWhiteSpace(productName.Trim()) ? -1 : GetIndex(productName);
        if (productIndex >= 0)
        {
            _pd.ActiveProductName = productName;
            _pd.IsProductActive = true;
            _sdi.ProductLoaded = true;
            DB_ProductManager.DbName_Product = Path.Combine(DBbase.Directory_Product, $"{productName}{DBbase.DB_ExtFileName}");
            _pd.DbConnection = SQLiteHelper.OpenConnection(DB_ProductManager.DbName_Product);
            _plc.WriteProductName(productName);

            //if (_lastProductName != productName)
            //{
            //    _lastProductName = productName;
            //    _ioService.Save(DBbase.Directory_Product, _LAST_PRODUCT_FILENAME, new LastProductName()
            //    {
            //        ProductName = productName,
            //    });
            //}

            //_authority.ProductReady = true;
        }
        else
        {
            if (_pd.DbConnection != null)
            {
                SQLiteHelper.Close(_pd.DbConnection);

                _pd.ActiveProductName = string.Empty;
                _pd.IsProductActive = false;
                _sdi.ProductLoaded = false;
                DB_ProductManager.DbName_Product = string.Empty;
                _pd.DbConnection = null;
                //_plc.WriteProductName(""); // 關閉品種後仍保留PLC中最後一個品種名稱的紀錄

                //_lastProductName = string.Empty;

                //_authority.ProductReady = false;
            }
        }

        // 發佈品種更換事件
        _sysMessenger.ShowProgressRing(true);
        Task.Run(() =>
        {
            _pd.ProductChangedRunning_Tray = true;
            _pd.ProductChangedRunning_Wfs = true;
            _pd.ProductChangedRunning_Stage = true;

            _ea.GetEvent<OnProductChangeover1>().Publish(_pd.ActiveProductName); // 第一階段事件
            while (_pd.ProductChangedRunning_Tray || _pd.ProductChangedRunning_Wfs || _pd.ProductChangedRunning_Stage)
            { }
        })
            .ContinueWith((c) =>
            {
                _pd.ProductChangedRunning_Wfs = true;
                _pd.ProductChangedRunning_Stage = true;

                _ea.GetEvent<OnProductChangeover2>().Publish(_pd.ActiveProductName); // 第二階段事件
                while (_pd.ProductChangedRunning_Wfs || _pd.ProductChangedRunning_Stage)
                { }
                _sysMessenger.ShowProgressRing(false);

                // 切換完品種，更新一次點位及Pallet
                if (_pd.IsProductActive)
                {
                    _plc.WaitForPollingCycleCompleted();
                    _ea.GetEvent<WriteNewPointNoEvent>().Publish(0);
                    //_ea.GetEvent<PalletInfoChangedEvent>().Publish(true);
                }
            });

        return productIndex >= 0;
    }

    //private void ShowProductInformation(string obj)
    //{
    //    string msgProductName = string.IsNullOrEmpty(_productDatas.ActiveProduct.ProductName)
    //        ? GetLocalizeResource.GetValue<string>("WFSCore", "Message_None")
    //        : _productDatas.ActiveProduct.ProductName;

    //    //_sysMessenger.PageTitle($"{GetLocalizeResource.GetValue<string>("Message_ActiveProductChangeoverTo")}: {msgProductName}");
    //    _sysMessenger.ActiveProduct(msgProductName);
    //}
}
