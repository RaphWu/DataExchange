﻿using Glorytek.WFSComponents.ProductManager.Contracts;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Models.ProductManager;
using Glorytek.WPF.Extensions;
using Glorytek.WPF.PrismMessageBox;
using Serilog;
using System;
using System.IO;
using System.Windows;

namespace Glorytek.WFSComponents.ProductManager.Services;

/// <summary>
/// 品種CRUD Service。
/// </summary>
public class ProductCrudService : IProductCrud
{
    /********************
     * ctor
     ********************/
    private readonly IPrismMessageBox _prismMessageBox;
    private readonly IProductManager _pm;

    public ProductCrudService(IPrismMessageBox prismMessageBox, IProductManager pm)
    {
        _prismMessageBox = prismMessageBox;
        _pm = pm;
    }

    /// <inheritdoc/>
    public bool CreateProduct(ProductCrudInfo productCrudInfo)
    {
        string newProdName = productCrudInfo.NewProductName;

        if (!_pm.IsProductExist(newProdName))
        {
            // 將資訊加入列表
            ProductDatas.Instance.ProductList.Add(new ProductDefine()
            {
                ProductName = productCrudInfo.NewProductName,
                Memo = productCrudInfo.Memo
            });

            // 寫回DB
            _pm.WriteToDb(newProdName);
            return true;
        }
        else
        {
            _ = _prismMessageBox.Show($"品種名稱({newProdName})重複，請重新輸入！",
                                      GetResource.GetValue<string>("ErrorMessage_IO_DataEntryError"),
                                      MessageBoxImage.Error);
            return false;
        }
    }

    /// <inheritdoc/>
    public bool CopyProduct(ProductCrudInfo productCrudInfo)
    {
        string sourcePath = default;
        string targetPath = default;

        if (!_pm.IsProductExist(productCrudInfo.NewProductName))
        {
            try
            {
                sourcePath = Path.Combine(DBbase.Directory_Product, $"{productCrudInfo.ProductName}{DBbase.DB_ExtFileName}");
                targetPath = Path.Combine(DBbase.Directory_Product, $"{productCrudInfo.NewProductName}{DBbase.DB_ExtFileName}");
                File.Copy(sourcePath, targetPath);

                ProductDatas.Instance.ProductList.Add(new ProductDefine()
                {
                    ProductName = productCrudInfo.NewProductName,
                    Memo = productCrudInfo.Memo
                });

                _pm.WriteToDb(productCrudInfo.NewProductName);

                if (productCrudInfo.ApplyNewProduct)
                    _pm.SwitchProduct(productCrudInfo.NewProductName);

                return true;
            }
            catch (Exception ex)
            {
                string errorMsg = $"品種複製失敗: {ex.Message}\n\n來源檔案: {sourcePath}\n目標檔案: {targetPath}";
                Log.Error(ex, errorMsg);
                _ = _prismMessageBox.Show(errorMsg,
                                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FileOperationException"),
                                          MessageBoxImage.Error);
                return false;
            }
        }
        else
        {
            _ = _prismMessageBox.Show("品種名稱重複，請重新輸入！",
                                      GetResource.GetValue<string>("ErrorMessage_IO_DataEntryError"),
                                      MessageBoxImage.Error);
            _pm.ReadFromDb();   // 重讀DB
            return false;
        }
    }

    /// <inheritdoc/>
    public bool ModifyProduct(ProductCrudInfo productCrudInfo)
    {
        bool modifyActiveProduct = false;   // 修改的是目前作業品種

        if (productCrudInfo.NewProductName != productCrudInfo.ProductName
            && _pm.IsProductExist(productCrudInfo.NewProductName))
        {
            _ = _prismMessageBox.Show($"新品種名稱({productCrudInfo.NewProductName})己存在，請輸入不同名稱。",
                                      GetResource.GetValue<string>("ErrorMessage_IO_DataEntryError"),
                                      MessageBoxImage.Error);
            return false;
        }

        // 此品種啟用中
        if (_pm.IsActiveProduct(productCrudInfo.ProductName))
        {
            _pm.SwitchProduct(string.Empty);
            modifyActiveProduct = true;
        }

        // 切換作業
        try
        {
            var product = ProductDatas.Instance.ProductList.Find(x => x.ProductName == productCrudInfo.ProductName);
            product.ProductName = productCrudInfo.NewProductName;
            product.Memo = productCrudInfo.Memo;

            _pm.WriteToDb(productCrudInfo.NewProductName, productCrudInfo.ProductName);

            if (modifyActiveProduct)
                _pm.SwitchProduct(productCrudInfo.NewProductName);

            return true;
        }
        catch (Exception ex)
        {
            string errorMsg = $"檔案編輯失敗: {productCrudInfo.ProductName} -> {productCrudInfo.NewProductName}";
            Log.Fatal(ex, errorMsg);
            _ = _prismMessageBox.Show(errorMsg,
                                      GetResource.GetValue<string>("ErrorMessage_IO_DataEntryError"),
                                      MessageBoxImage.Error);
            return false;
        }
    }

    /// <inheritdoc/>
    public bool DeleteProduct(string productName)
    {
        string filePath = Path.Combine(DBbase.Directory_Product, $"{productName}{DBbase.DB_ExtFileName}");
        if (!_pm.IsProductExist(productName) || !File.Exists(filePath))
        {
            string errorMsg = $"品種名稱({productName})或檔案({filePath})不存在！";
            Log.Error(errorMsg);
            _ = _prismMessageBox.Show(errorMsg,
                                      GetResource.GetValue<string>("ErrorMessage_IO_DataEntryError"),
                                      MessageBoxImage.Error);
            return false;
        }

        // 品種名稱啟用中
        if (_pm.IsActiveProduct(productName))
        {
            string errorMsg = $"品種名稱({productName})正在啟用中，請先卸載後再刪除。";
            Log.Error(errorMsg);
            _ = _prismMessageBox.Show(errorMsg,
                                      GetResource.GetValue<string>("ErrorMessage_IO_DataEntryError"),
                                      MessageBoxImage.Error);
            return false;
        }

        try
        {
            File.Delete(filePath);
            int removeCount = ProductDatas.Instance.ProductList.RemoveAll(x => x.ProductName == productName);
        }
        catch (Exception ex)
        {
            string errorMsg = $"檔案刪除失敗！{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}";
            Log.Fatal(ex, errorMsg);
            _ = _prismMessageBox.Show(errorMsg,
                                      GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_FileOperationException"),
                                      MessageBoxImage.Error);

            _pm.ReadFromDb();
            return false;
        }

        return true;
    }
}
