﻿using Prism.Commands;

namespace Glorytek.WFSCore.Contracts;

/// <summary>
/// 由 Prism CompositeCommand 實現的應用程式全域命令。
/// </summary>
public interface IApplicationCommands
{
    /// <summary>
    /// 儲存參數命令。
    /// </summary>
    CompositeCommand SaveDataCommand { get; }
}

/********************
 * 共用命令 - 使用Prism的Composite Command定義全域共用函數
 * 文件參考: https://prismlibrary.com/docs/composite-commands.html
 ********************/

/********************
 * 全域指令：存檔
 * 定義存檔命令，讓所有須做存檔作業的物件註冊。
 * 執行時，會呼叫全部有註冊的物件各自執行存檔動作。
 * 在需要註冊的物件中(通常是ViewModel)，使用以下方式：
 *
 * public DelegateCommand ApplyDataCommand { get; private set; }
 * public xxxViewModel(IApplicationCommands applicationCommands)
 * {
 *    ApplyDataCommand = new DelegateCommand(ExecuteApplyDataCommand);
 *    applicationCommands.ApplyDataCommand.RegisterCommand(ApplyDataCommand);
 * }
 *
 * /********************
 * * 全域指令
 * ********************
 * /// <summary>
 * /// 將資料或參數寫入資料庫
 * /// </summary>
 * public void ExecuteApplyDataCommand()
 * {
 *    ...
 * }
 ********************/
