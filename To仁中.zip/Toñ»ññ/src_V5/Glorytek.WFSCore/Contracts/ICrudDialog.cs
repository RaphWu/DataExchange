﻿using Glorytek.WFSCore.Models;

namespace Glorytek.WFSCore.Contracts;

/// <summary>
/// CRUD Dialog介面。
/// </summary>
public interface ICrudDialog
{
    /// <summary>
    /// 顯示CRUD Dialog。
    /// </summary>
    /// <param name="crudInfo">CRUD資訊。</param>
    /// <returns>返回的CRUD值。</returns>
    CrudInfo ShowDialog(CrudInfo crudInfo);

    /**************************************************
     1. 如欲使用 CRUD對話框，請依下列操作：(以變更名稱為例)

        using WFSCore.Constants;
        using WFSCore.Contracts;
        using WFSCore.Models;
        using Prism.Services.Dialogs;

        private readonly ICrudDialog _crudDialog;

        public xxxViewModel(ICrudDialog crudDialog)
        {
            _crudDialog = crudDialog;
        }

        void ButtonCommand()
        {
            CrudInfo crudInfo = new CrudInfo()
            {
                Action = CrudAction.xxx,   // 執行動作
                Title = "變更名稱",          // 對話框標題
                Id = id,                   // 資料ID
                OriginalName = "",         // 原資料(若有需要)
                OriginalTitle = "原名稱",
                NewName = "",              // 新資料
                NewTitle = "變更後名稱",
                Memo = "",                 // 註解
                MemoTitle = "註解",
            };
            CrudInfo result = _crudDialog.ShowDialog(crudInfo);

            if (result.Result == ButtonResult.OK)
            {
                // 按OK鍵後的動作
            }
        }

     2. 若不使用 ICrudDialog 介面，想直接控制 Dialog，
        請參考 CrudDialogService.cs 中 ShowDialog() 的作法。
     **************************************************/
}
