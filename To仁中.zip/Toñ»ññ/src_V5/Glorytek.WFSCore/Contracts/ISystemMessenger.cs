﻿namespace Glorytek.WFSCore.Contracts;

/// <summary>
/// 主頁面訊息處理介面。
/// </summary>
public interface ISystemMessenger
{
    /// <summary>
    /// 進度條顯示。
    /// </summary>
    /// <param name="visibility">true=顯示, false=不顯示。</param>
    void ShowProgressRing(bool visibility);

    /// <summary>
    /// 在StatusBar的訊息區顯示message。
    /// </summary>
    /// <param name="message">頁標題。</param>
    void StatusBarMessage(string message);

    ///// <summary>
    ///// 在主頁面顯示權限資訊。
    ///// </summary>
    ///// <param name="message">。</param>
    //void Authorization(string message);

    ///// <summary>
    ///// 切回上一個顯示的主選單鍵。(棄用)
    ///// </summary>
    //void LightUpPreviousMainMenuButton(string empty);

    /// <summary>
    /// 在主控頁訊息框顯示訊息。
    /// </summary>
    /// <param name="message">訊息。</param>
    void OperateMessage(string message);
}
