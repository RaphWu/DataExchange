﻿using Glorytek.WPF.Converters;
using System.ComponentModel;

namespace Glorytek.WFSCore.Constants;

/// <summary>
/// 系統操作模式代碼。
/// </summary>
[TypeConverter(typeof(EnumDescriptionTypeConverter))]
public enum SystemOperateModeType
{
    /// <summary>
    /// 未定義。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Caption_Undefined")]
    Undefined,

    /********************
     * 連線模式
     ********************/
    /// <summary>
    /// 對接模式(固定平台)。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Caption_SystemMode_Online_FixStage")]
    Online_FixStage,

    /// <summary>
    /// 對接模式(單汽缸)。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Caption_SystemMode_Online_SingleCylinder")]
    Online_SingleCylinder,

    /// <summary>
    /// 對接模式(雙汽缸)。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Caption_SystemMode_Online_DoubleCylinder")]
    Online_DoubleCylinder,

    /// <summary>
    /// 對接模式(圓盤)。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Caption_SystemMode_Online_Disc")]
    Online_Disc,

    /********************
     * 單機模式
     ********************/
    /// <summary>
    /// 分檢模式。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Caption_SystemMode_LensSorting")]
    LensSorting,

    /// <summary>
    /// 轉角度模式。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Caption_SystemMode_LensArragne")]
    LensArrange,

    /// <summary>
    /// TRAY > A1重複精度。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Caption_SystemMode_Tray_A1")]
    Tray_A1,
}
