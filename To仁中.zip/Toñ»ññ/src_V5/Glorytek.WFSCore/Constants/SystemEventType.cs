﻿namespace Glorytek.WFSCore.Constants;

/// <summary>
/// 系統事件識別字。
/// </summary>
public enum SystemEventType
{
    LightUpPreviousMainMenuButton,
}
