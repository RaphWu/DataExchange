﻿namespace Glorytek.WFSCore.Constants.WFS;

// 勿更動順序，否則已存在的資料庫ID會比對錯誤。

/// <summary>
/// 光學參數名稱代碼。
/// </summary>
public enum OpticalParamId
{
    /// <summary>
    /// 鏡片編號。
    /// </summary>
    LensNumber = 0,

    /// <summary>
    /// 偏心值。
    /// </summary>
    Decenter,

    /// <summary>
    /// X軸偏心值。
    /// </summary>
    DecenterX,

    /// <summary>
    /// Y軸偏心值。
    /// </summary>
    DecenterY,

    /// <summary>
    /// 彗星像差。
    /// </summary>
    Coma,

    /// <summary>
    /// 像散。
    /// </summary>
    Astigmatism,

    /// <summary>
    /// 球面像差。
    /// </summary>
    Spherical,

    /// <summary>
    /// 三葉像差。
    /// </summary>
    Trefoil,

    /// <summary>
    /// 偏心角度。
    /// </summary>
    Angle,
}
