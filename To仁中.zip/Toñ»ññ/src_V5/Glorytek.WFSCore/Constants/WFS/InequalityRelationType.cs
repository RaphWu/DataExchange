﻿using Glorytek.WPF.Converters;
using System.ComponentModel;

namespace Glorytek.WFSCore.Constants.WFS;

/// <summary>
/// 不等式關係類型。
/// </summary>
[TypeConverter(typeof(EnumDescriptionTypeConverter))]
public enum InequalityRelationType
{
    /// <summary>
    /// 大於。
    /// </summary>
    [Description(">")]
    [LocalizedDescription("Glorytek.WFSCore", "Caption_GreaterThan")]
    GreaterThan,

    /// <summary>
    /// 大於等於。
    /// </summary>
    [Description("≥")]
    [LocalizedDescription("Glorytek.WFSCore", "Caption_GreaterThanOrEqualTo")]
    GreaterThanOrEqualTo,

    /// <summary>
    /// 小於。
    /// </summary>
    [Description("<")]
    [LocalizedDescription("Glorytek.WFSCore", "Caption_LessThan")]
    LessThan,

    /// <summary>
    /// 小於等於。
    /// </summary>
    [Description("≤")]
    [LocalizedDescription("Glorytek.WFSCore", "Caption_LessThanOrEqualTo")]
    LessThanOrEqualTo,

    /// <summary>
    /// 相等。
    /// </summary>
    [Description("=")]
    [LocalizedDescription("Glorytek.WFSCore", "Caption_Equalto")]
    Equalto,

    /// <summary>
    /// 不相等。
    /// </summary>
    [Description("≠")]
    [LocalizedDescription("Glorytek.WFSCore", "Caption_NotEqualTo")]
    NotEqualTo,

    /// <summary>
    /// 介於。
    /// </summary>
    [Description("介於")]
    [LocalizedDescription("Glorytek.WFSCore", "Caption_Between")]
    Between,

    /// <summary>
    /// 不介於。
    /// </summary>
    [Description("不介於")]
    [LocalizedDescription("Glorytek.WFSCore", "Caption_NotBetween")]
    NotBetween,
}
