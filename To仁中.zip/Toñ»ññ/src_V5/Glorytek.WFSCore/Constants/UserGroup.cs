﻿using Glorytek.WPF.Converters;
using System.ComponentModel;

namespace Glorytek.WFSCore.Constants;

/// <summary>
/// 使用者群組分類。
/// </summary>
[TypeConverter(typeof(EnumDescriptionTypeConverter))]
public enum UserGroup
{
    [LocalizedDescription("Glorytek.WFSCore", "UserTitle_Guest")]
    Guest = -1,

    [LocalizedDescription("Glorytek.WFSCore", "UserTitle_Admin")]
    Admin = 0,

    //[LocalizedDescription("Glorytek.WFSCore", "UserTitle_TeamLeader")]
    //TeamLeader = 1,

    //[LocalizedDescription("Glorytek.WFSCore", "UserTitle_Manager")]
    //Manager = 2,

    //[LocalizedDescription("Glorytek.WFSCore", "UserTitle_Engineer")]
    //Engineer = 3,

    [LocalizedDescription("Glorytek.WFSCore", "UserTitle_Operator")]
    Operator = 1,
}
