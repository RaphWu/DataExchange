﻿using System;
using System.IO;

namespace Glorytek.WFSCore.Constants;

/// <summary>
/// 資料庫定義 - 基本資訊。
/// </summary>
public static class DBbase
{
    /// <summary>
    /// 資料庫檔案的副檔名。
    /// </summary>
    public const string DB_ExtFileName = ".db";

    /// <summary>
    /// EXCEL檔案的副檔名。
    /// </summary>
    public const string Excel_ExtFileName = ".xlsx";

    /// <summary>
    /// 目前工作目錄。
    /// </summary>
    public static readonly string WorkPath = Environment.CurrentDirectory;
    //public static string WorkPath = AppDomain.CurrentDomain.BaseDirectory;
    //public static string WorkPath = System.AppContext.BaseDirectory;

    /// <summary>
    /// 資料存放的根位置。
    /// </summary>
    public static readonly string Directory_Base = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "WFS");

    /********************
     * 資料夾
     ********************/
    /// <summary>
    /// System與Macine共用資料庫檔名。
    /// </summary>
    public static string DbName_System = $"System{DB_ExtFileName}";

    /// <summary>
    /// 產品參數資料夾。
    /// </summary>
    public static readonly string Directory_Product = Path.Combine(Directory_Base, "Products");

    /// <summary>
    /// Logger。
    /// </summary>
    public static readonly string Directory_Logger = Path.Combine(Directory_Base, "Logs");

    /// <summary>
    /// 備份資料夾。
    /// </summary>
    public static readonly string Directory_Export = Path.Combine(Directory_Base, "Export");

    /// <summary>
    /// 稼動紀錄資料夾。
    /// </summary>
    public static readonly string Directory_Availability = Path.Combine(Directory_Base, "Availability");

    /********************
     * 資料庫
     ********************/
    ///// <summary>
    ///// 大數據資料檔 = ?
    ///// </summary>
    //public const string DbName_BigDatas = "WFS";

    /********************
     * SQLite
     ********************/
    ///// <summary>
    ///// C# DateTime 轉 SQLite字串。
    ///// </summary>
    //public const string SQLite_DateTimeFormating = "YYYY-MM-DD HH:MM:SS.SSS";
}
