﻿namespace Glorytek.WFSCore.Constants;

/// <summary>
/// 導航用各頁面代碼。
/// </summary>
public class PageKeys
{
    public const string MainWindow = "MainWindow";
    public const string Manual = "Manual";
    public const string StatusBar = "StatusBar";
    public const string Main = "Main";
    public const string TeachingBox = "TeachingBox";

    // Core
    public const string ProductManager = "ProductManager";

    // Teaching
    public const string Teaching = "Teaching";
    public const string Tray = "Tray";
    public const string TrayProfile = "TrayProfile";
    public const string RepeatabilityTest = "RepeatabilityTest";
    public const string OPR = "OriginalPointReturn";

    // WFS
    public const string WfsSpecification = "WfsSpecification";
    public const string Pallet = "Pallet";
    public const string LensSorting = "LensSorting";
    public const string LensArrange = "LensArrange";

    // Main的次頁面
    public const string MainConsole = "MainConsole";
    public const string OperationStatus = "OperationStatus";
    public const string PalletParameters = "PalletParameters";
    public const string StageParameters = "StageParameters";
    public const string ServoMonitor = "ServoMonitor";
    public const string IoMonitor = "IoMonitor";

    // 大數據
    public const string BigData = "BigData";

    // 報表
    public const string Report = "Report";
    public const string AbnormalHistory = "AbnormalHistoryReport";
    public const string SystemLog = "SystemLogReport";
    public const string ExceptionLog = "ExceptionLogReport";
    public const string Availability = "AvailabilityReport";

    // 設定
    public const string SettingsPage = "SettingsPage";
    public const string SystemSetting = "SystemSetting";
    public const string ConnectionSetting = "Connection";
    public const string AuthoritySetting = "Authority";
    public const string ParamFileOperate = "ParamFileOperate";
}
