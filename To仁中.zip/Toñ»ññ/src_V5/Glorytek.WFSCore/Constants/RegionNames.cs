﻿namespace Glorytek.WFSCore.Constants;

/// <summary>
/// Region代碼。
/// </summary>
public static class RegionNames
{
    // WFS
    public const string Main = "MainRegion";
    public const string RightPane = "RightPaneRegion";
    public const string StatusBar = "StatusBarRegion";
    public const string MainPage = "MainPageRegion";
    public const string SystemSetting = "SystemSettingRegion";

    public const string AuthoritySetting = "AuthoritySettingRegion";
    public const string ParamFileOperate = "ParamFileOperateRegion";

    public const string BigDataBrowserInOnlineRegion = "BigDataBrowserInOnlineRegion";
    public const string BigDataBrowserInLensSortingRegion = "BigDataBrowserInLensSortingRegion";

    public const string OPRWindow = "OPRWindowRegion";
    public const string OPRMainConsole = "OPRMainConsoleRegion";
    public const string RepeatabilityTest = "RepeatabilityTestRegion";

    // WFSComponents
    public const string TrayMatrix = "TrayMatrixRegion";
    public const string TrayMatrixRegionInSorting = "TrayMatrixRegionInSortingRegion";
    public const string TrayMatrixRegionInArrange = "TrayMatrixRegionInArrangeRegion";

    public const string BigDataBrowser = "BigDataBrowserRegion";

    // WFS External
    public const string ExternalEquipmentConnectionSetting = "ExternalEquipmentConnectionSettingRegion";
    public const string SerialPortSetting = "SerialPortSettingRegion";

    // Report
    public const string Report = "ReportRegion";
    public const string AbnormalHistory = "AbnormalHistoryRegion";
    public const string SystemLog = "SystemLogRegion";
    public const string ExceptionLog = "ExceptionLogRegion";
    public const string Availability = "AvailabilityRegion";
}
