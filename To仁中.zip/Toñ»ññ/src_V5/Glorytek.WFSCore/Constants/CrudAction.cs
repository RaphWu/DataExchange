﻿namespace Glorytek.WFSCore.Constants;

/// <summary>
/// CRUD動作代碼。
/// </summary>
public enum CrudAction
{
    /// <summary>
    /// 無動作。
    /// </summary>
    None = 0,

    /*** 新增 ***/
    /// <summary>
    /// 建立。
    /// </summary>
    Create,
    /// <summary>
    /// 新增。
    /// </summary>
    Append,
    /// <summary>
    /// 插入。
    /// </summary>
    Insert,

    /// <summary>
    /// 讀取。
    /// </summary>
    Read,

    /*** 編修 ***/
    /// <summary>
    /// 更新。
    /// </summary>
    Update,
    /// <summary>
    /// 修改。
    /// </summary>
    Modify,
    /// <summary>
    /// 更名。
    /// </summary>
    Rename,

    /// <summary>
    /// 刪除。
    /// </summary>
    Delete,

    /// <summary>
    /// 複製。
    /// </summary>
    Copy,

    //// 數字變更，無註解(暫借介面)。
    //ChangeNumber,
}
