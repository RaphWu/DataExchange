﻿using Glorytek.WPF.Converters;
using System.ComponentModel;

namespace Glorytek.WFSCore.Constants.Tray;

/// <summary>
/// Tray排列方式。
/// </summary>
[TypeConverter(typeof(EnumDescriptionTypeConverter))]
public enum TrayArrangementType : short
{
    /// <summary>
    /// 依序排列。
    /// </summary>
    [Description("依序排列")]
    [LocalizedDescription("Glorytek.WFSCore", "ArrangeInOrder")]
    ArrangeInOrder,

    /// <summary>
    /// 交錯排列。
    /// </summary>
    [Description("交錯排列")]
    [LocalizedDescription("Glorytek.WFSCore", "ArrangeInCross")]
    ArrangeInCross,
}
