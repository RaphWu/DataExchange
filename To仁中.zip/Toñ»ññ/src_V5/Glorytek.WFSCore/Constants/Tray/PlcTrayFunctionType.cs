﻿using Glorytek.WPF.Converters;
using System.ComponentModel;

namespace Glorytek.WFSCore.Constants.Tray;

/// <summary>
/// PLC的Tray功能代碼。
/// </summary>
[TypeConverter(typeof(EnumDescriptionTypeConverter))]
public enum PlcTrayFunctionType
{
    /// <summary>
    /// 未使用。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Message_Unused")]
    Unused = 0,

    /// <summary>
    /// 重工用。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Message_Rework")]
    Rework = 1,

    /// <summary>
    /// 待分檢入料用。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSComponents", "Message_Feeder")]
    Feeder = 2,

    /// <summary>
    /// 已分檢收料用 (連線/分檢模式)。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSComponents", "Message_Classified")]
    Classified = 3,

    /// <summary>
    /// 已分檢收料用 (轉角度模式)。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSComponents", "Message_Classified")]
    AngleArrange = 4,
}
