﻿using Glorytek.WPF.Converters;
using System.ComponentModel;

namespace Glorytek.WFSCore.Constants.Tray;

/// <summary>
/// Tray功能分類。
/// </summary>
[TypeConverter(typeof(EnumDescriptionTypeConverter))]
public enum TrayFunctionType
{
    /// <summary>
    /// 未使用。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Message_Unused")]
    Unused = 0,

    /// <summary>
    /// 待分檢入料用。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSComponents", "Message_Feeder")]
    Feeder = 10,

    /// <summary>
    /// 已分檢收料用。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSComponents", "Message_Classified")]
    Classified = 11,

    /// <summary>
    /// 重工用。
    /// </summary>
    [LocalizedDescription("Glorytek.WFSCore", "Message_Rework")]
    Rework = 1,
}