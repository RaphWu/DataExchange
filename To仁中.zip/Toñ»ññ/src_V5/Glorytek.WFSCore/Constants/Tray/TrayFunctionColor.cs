﻿using System.Windows.Media;

namespace Glorytek.WFSCore.Constants.Tray;

/// <summary>
/// Tray顯示顏色設定。
/// </summary>
public static class TrayFunctionColor
{
    /// <summary>
    /// 未使用。
    /// </summary>
    public static SolidColorBrush Unused = Brushes.Transparent;

    /// <summary>
    /// 重工用。
    /// </summary>
    public static SolidColorBrush Rework = Brushes.Gray;

    /// <summary>
    /// 待分檢入料用。
    /// </summary>
    public static SolidColorBrush Feeder = Brushes.IndianRed;

    /// <summary>
    /// 已分檢收料用 (連線/分檢模式)。
    /// </summary>
    public static SolidColorBrush Classified = Brushes.Teal;

    /// <summary>
    /// 已分檢收料用 (轉角度模式)。
    /// </summary>
    public static SolidColorBrush AngleArrange = Brushes.Teal;
}
