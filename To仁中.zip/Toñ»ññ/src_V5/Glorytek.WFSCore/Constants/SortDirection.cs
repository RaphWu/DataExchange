﻿namespace Glorytek.WFSCore.Constants;

/// <summary>
/// 排序方向。
/// </summary>
public enum SortDirection
{
    /// <summary>
    /// 依遞增順序排序。
    /// </summary>
    Ascending = 0,

    /// <summary>
    /// 依遞減順序排序。
    /// </summary>
    Descending = 1,
}
