﻿using Prism.Events;

namespace Glorytek.WFSCore.Events;

/// <summary>
/// 品種更換事件 - 第一階段：當作業品種有更換時，會發佈此事件。
/// </summary>
/// <remarks>string=新品種ID。</remarks>
public class OnProductChangeover1 : PubSubEvent<string> { }

/// <summary>
/// 品種更換事件 - 第二階段：當第一階段的程序都回報完成後，再次發佈事件給有第二階段需求的程序。
/// </summary>
/// <remarks>string=新品種ID。</remarks>
public class OnProductChangeover2 : PubSubEvent<string> { }
