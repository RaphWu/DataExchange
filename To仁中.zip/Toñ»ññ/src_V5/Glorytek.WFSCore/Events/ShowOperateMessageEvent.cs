﻿using Prism.Events;

namespace Glorytek.WFSCore.Events;

/// <summary>
/// 傳送訊息至主控頁訊息顯示區事件。
/// </summary>
public class ShowOperateMessageEvent : PubSubEvent<string> { }
