﻿using Prism.Events;

namespace Glorytek.WFSCore.Events;

/// <summary>
/// 系統點位更新事件
/// </summary>
public class WriteNewPointNoEvent : PubSubEvent<int> { }

/// <summary>
/// PLC輪詢的點位更新事件，只給WfsService_PLC.cs，由UpdatedAllPointNo()接收。
/// </summary>
/// <remarks>bool參數<list type="bullet"><item>true：要檢查各Pallet的動作點位是否在各Tray合法範圍</item><item>false：不檢查</item></list></remarks>
public class PalletInfoChangedEvent : PubSubEvent<bool> { }

/// <summary>
/// 點位更新事件，會在PLC輪詢更新事件後由WfsService_PLC.cs的UpdatedAllPointNo()觸發。
/// </summary>
public class SystemPointNoUpdatedEvent : PubSubEvent<int> { }
