﻿using Prism.Events;

namespace Glorytek.WFSCore.Events;

/// <summary>
/// 切換權限至作業員(應以使用IOC優先，此為IEventAggregator版本)。
/// </summary>
public class SwitchAuthorityToOperatorEvent : PubSubEvent<string> { }

/// <summary>
/// 重置輸入裝置閒置偵測的Timer計時到達事件。
/// </summary>
public class ResetInputDetectorTimerEvent : PubSubEvent<int> { }

/// <summary>
/// 系統模式切換事件。
/// </summary>
public class SystemModeChangedEvent : PubSubEvent<int> { }

/// <summary>
/// 應用程式結束事件。
/// </summary>
public class ApplicationShutdownEvent : PubSubEvent<int> { }
