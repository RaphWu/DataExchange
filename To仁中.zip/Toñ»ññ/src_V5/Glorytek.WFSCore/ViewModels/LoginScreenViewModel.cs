﻿using Glorytek.CSharp.Data.Validation;
using Glorytek.WFSCore.Authority;
using Glorytek.WFSCore.Constants;
using Glorytek.WPF.Extensions;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Windows.Controls;

namespace Glorytek.WFSCore.ViewModels;

/// <summary>
/// 登入對話框的 ViewModel。
/// </summary>
public class LoginScreenViewModel : BindableBase, IDialogAware
{
    private readonly string _paramIdentifier = "Authority";

    /********************
     * ctor
     ********************/
    public LoginScreenViewModel()
    {
        LoginUserId = (int)UserGroup.Operator;
    }

    /********************
     * IDialogAware
     ********************/
    public string Title => GetResource.GetValue<string>("Title_LoginScreen");
    public bool ShowTitle => false;

    public event Action<IDialogResult> RequestClose;
    public bool CanCloseDialog() => true;
    public void OnDialogClosed() { }

    public DelegateCommand<object> CloseDialogCommand
        => _closeDialogCommand ??= new DelegateCommand<object>(CloseDialog);
    protected virtual void CloseDialog(object parameter)
    {
        if (parameter != null)
        {
            ButtonResult result = ButtonResult.OK;
            DialogParameters paras = new()
                {
                    {
                        _paramIdentifier,
                        JsonConvert.SerializeObject(new LoginDataDefine()
                        {
                            UserId = EnterUsernameUsingKeyboard ? -1 : LoginUserId,
                            UserName = EnterUsernameUsingKeyboard ? LoginUserName : "",
                            Password = (parameter as PasswordBox).Password.GetMD5Hash(),
                        }, new JsonSerializerSettings())
                    }
                };
            RaiseRequestClose(new DialogResult(result, paras));
        }
        else
        {
            // 作業員
            LoginAsOperator();
        }
    }
    private DelegateCommand<object> _closeDialogCommand;

    /// <summary>
    /// 取消鍵。
    /// </summary>
    public DelegateCommand CancelDialogCommand
        => _CancelDialogCommand ??= new DelegateCommand(ExecuteCancelDialogCommand);
    private void ExecuteCancelDialogCommand()
    {
        ButtonResult result = ButtonResult.Cancel;
        DialogParameters paras = new()
            {
                {
                    _paramIdentifier,
                    JsonConvert.SerializeObject(new LoginDataDefine()
                    {
                        UserId = null,
                        UserName = "",
                        Password = "",
                    }, new JsonSerializerSettings())
                }
            };
        RaiseRequestClose(new DialogResult(result, paras));
    }
    private DelegateCommand _CancelDialogCommand;

    public virtual void RaiseRequestClose(IDialogResult dialogResult)
        => RequestClose?.Invoke(dialogResult);

    public void OnDialogOpened(IDialogParameters parameters)
    {
    }

    /********************
     * 
     ********************/
    /// <summary>
    /// 以作業員登入鍵。
    /// </summary>
    public DelegateCommand LoginAsOperatorCommand
        => _LoginAsOperatorCommand ??= new DelegateCommand(ExecuteLoginAsOperatorCommand);
    private void ExecuteLoginAsOperatorCommand()
    {
        LoginAsOperator();
    }
    private DelegateCommand _LoginAsOperatorCommand;

    /// <summary>
    /// 使用作業員帳號登入。
    /// </summary>
    private void LoginAsOperator()
    {
        ButtonResult result = ButtonResult.OK;
        DialogParameters paras = new()
            {
                    {
                        _paramIdentifier,
                        JsonConvert.SerializeObject(new LoginDataDefine()
                        {
                            UserId = (int)UserGroup.Operator,
                            Password = "".GetMD5Hash(),
                        }, new JsonSerializerSettings())
                }
            };
        RaiseRequestClose(new DialogResult(result, paras));
    }

    /********************
     * 
     ********************/
    /// <summary>
    /// 登入的使用者ID。
    /// </summary>
    public int LoginUserId
    {
        get { return _loginUserId; }
        set { SetProperty(ref _loginUserId, value); }
    }
    private int _loginUserId;

    /// <summary>
    /// 登入的使用者名稱。
    /// </summary>
    public string LoginUserName
    {
        get { return _loginUserName; }
        set { SetProperty(ref _loginUserName, value); }
    }
    private string _loginUserName;

    /********************
     * 
     ********************/
    /// <summary>
    /// ComboBox &lt;-&gt; TextBox。
    /// </summary>
    public DelegateCommand SwitchEntryTypeCommand
        => _SwitchEntryTypeCommand ??= new DelegateCommand(ExecuteSwitchEntryTypeCommand);
    private void ExecuteSwitchEntryTypeCommand()
    {
        EnterUsernameUsingKeyboard = !EnterUsernameUsingKeyboard;
    }
    private DelegateCommand _SwitchEntryTypeCommand;

    /// <summary>
    /// Visibility of ComboBox and TextBox。
    /// </summary>
    public bool EnterUsernameUsingKeyboard
    {
        get { return _enterUsernameUsingKeyboard; }
        set { SetProperty(ref _enterUsernameUsingKeyboard, value); }
    }
    private bool _enterUsernameUsingKeyboard = false;
}
