﻿using Glorytek.WFSCore.Authority;
using Glorytek.WFSCore.Contracts;
using Glorytek.WPF.Extensions;
using Prism;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.Collections.Generic;

namespace Glorytek.WFSCore.ViewModels;

/// <summary>
/// 權限管理畫面的 ViewModel。
/// </summary>
public class AuthoritySettingViewModel : BindableBase, INavigationAware, IActiveAware
{
    private readonly AuthorityData _ad = AuthorityData.Instance;

    /********************
     * INavigationAware
     ********************/
    public void OnNavigatedTo(NavigationContext navigationContext)
    {
        LoadSysData();
        UserNameList = _ad.UserNameList;
    }

    public void OnNavigatedFrom(NavigationContext navigationContext)
    {
        WriteData();
    }

    public bool IsNavigationTarget(NavigationContext navigationContext) => true;

    /********************
     * IActiveAware & ApplicationCommands
     ********************/
    private bool _isActive = false;
    public bool IsActive
    {
        get { return _isActive; }
        set
        {
            _isActive = value;
            OnIsActiveChanged();
        }
    }
    public event EventHandler IsActiveChanged;
    public DelegateCommand SaveDataCommand { get; private set; }
    private void OnIsActiveChanged()
    {
        SaveDataCommand.IsActive = IsActive;
        IsActiveChanged?.Invoke(this, new EventArgs());
    }

    /********************
     * ctor
     ********************/
    private readonly ISystemMessenger _sysMessenger;
    private readonly IAuthority _authority;

    public AuthoritySettingViewModel(IApplicationCommands applicationCommands,
                                     ISystemMessenger sysMessenger,
                                     IAuthority authority)
    {
        _sysMessenger = sysMessenger;
        _authority = authority;

        SaveDataCommand = new DelegateCommand(ExecuteSaveDataCommand);
        applicationCommands.SaveDataCommand.RegisterCommand(SaveDataCommand);
    }

    /// <summary>
    /// 視窗載入。
    /// </summary>
    public DelegateCommand LoadedCommand
        => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
    private void ExecuteLoadedCommand()
    {
        _sysMessenger.StatusBarMessage(string.Join(" - ", new[] {
                GetResource.GetValue<string>("Glorytek.WFSComponents", "PageTitle_SettingsPage"),
                GetResource.GetValue<string>("Glorytek.WFSComponents", "TabItem_SystemSetting_Authority")
            }));
    }
    private DelegateCommand _loadedCommand;

    /********************
     * System Commands
     ********************/
    /// <summary>
    /// 將資料寫入資料庫
    /// 將Model資料寫入資料庫
    /// 將View資料寫入Model及資料庫
    /// </summary>
    public void ExecuteSaveDataCommand() => WriteData();

    /// <summary>
    /// 將資料寫入資料庫。
    /// </summary>
    public void WriteData()
    {
        _ad.Params.InputDetectInterval = InputDetectInterval;
        if (SelectedUser != null)
            _authority.WriteToDb(SaveUserAuthorizationTable(SelectedUser.Id), true);
        _authority.ResetInputDetectorTimer(InputDetectInterval);
    }

    /********************
     * Database
     ********************/
    /// <summary>
    /// 讀入系統設定值。
    /// </summary>
    private void LoadSysData()
    {
        InputDetectInterval = _ad.Params.InputDetectInterval;
    }

    /// <summary>
    /// 將指定使用者的權限設定存入Model。
    /// </summary>
    private bool SaveUserAuthorizationTable(int userId)
    {
        if (!_authority.IsUserIdExist(userId))
            return false;

        return _authority.SetUserAuthorizationTable(userId, new AuthorizationTable
        {
            Menu_MainConsole = Menu_MainConsole,
            Menu_PalletParameters = Menu_PalletParameters,
            Menu_StageParameters = Menu_StageParameters,
            Menu_Manual = Menu_Manual,
            Menu_Pallet = Menu_Pallet,
            Menu_WFS_Specification = Menu_WFS_Specification,
            Menu_Tray = Menu_Tray,

            Menu_MachineDatum = Menu_MachineDatum,
            Menu_ClayTable = Menu_ClayTable,
            Menu_Displacement = Menu_Displacement,
            Menu_Stage = Menu_Stage,
            Menu_PalletInstallPoints = Menu_PalletInstallPoints,
            Menu_RepeatabilityTest = Menu_RepeatabilityTest,
            Func_ReportOutput = Func_ReportOutput,

            Menu_BigData = Menu_BigData,
            Report_AbnormalHistory = Report_AbnormalHistory,
            Report_SystemLogger = Report_SystemLogger,
            Report_ExceptionLogger = Report_ExceptionLogger,
            Menu_Product_Switch = Menu_Product_Switch,
            Menu_Product_Manager = Menu_Product_Manager,
            Menu_System = Menu_System,
            Menu_Connection = Menu_Connection,
            Menu_Authority = Menu_Authority,
        });
    }

    /// <summary>
    /// 從Model的載入指定使用者的權限設定。
    /// </summary>
    /// <returns>載入是否完成。</returns>
    private bool LoadUserAuthorizationTable(int userId)
    {
        if (!_authority.IsUserIdExist(userId))
            return false;

        var at = _authority.GetUserAuthorizationTable(userId);
        at ??= new AuthorizationTable();

        Menu_MainConsole = at.Menu_MainConsole;
        Menu_PalletParameters = at.Menu_PalletParameters;
        Menu_StageParameters = at.Menu_StageParameters;
        Menu_Manual = at.Menu_Manual;
        Menu_Pallet = at.Menu_Pallet;
        Menu_WFS_Specification = at.Menu_WFS_Specification;
        Menu_Tray = at.Menu_Tray;

        Menu_MachineDatum = at.Menu_MachineDatum;
        Menu_ClayTable = at.Menu_ClayTable;
        Menu_Displacement = at.Menu_Displacement;
        Menu_Stage = at.Menu_Stage;
        Menu_PalletInstallPoints = at.Menu_PalletInstallPoints;
        Menu_RepeatabilityTest = at.Menu_RepeatabilityTest;
        Func_ReportOutput = at.Func_ReportOutput;

        Menu_BigData = at.Menu_BigData;
        Report_AbnormalHistory = at.Report_AbnormalHistory;
        Report_SystemLogger = at.Report_SystemLogger;
        Report_ExceptionLogger = at.Report_ExceptionLogger;
        Menu_Product_Switch = at.Menu_Product_Switch;
        Menu_Product_Manager = at.Menu_Product_Manager;
        Menu_System = at.Menu_System;
        Menu_Connection = at.Menu_Connection;
        Menu_Authority = at.Menu_Authority;

        return true;
    }

    /********************
     * Binding
     ********************/
    /// <summary>
    /// 使用者名稱列表。
    /// </summary>
    public List<UserNameListDefine> UserNameList
    {
        get { return _userNameList; }
        set { SetProperty(ref _userNameList, value); }
    }
    private List<UserNameListDefine> _userNameList;

    /// <summary>
    /// 選擇的使用者。
    /// </summary>
    public UserNameListDefine SelectedUser
    {
        get { return _selectedUser; }
        set
        {
            SetProperty(ref _selectedUser, value);
            if (value != null)
                LoadUserAuthorizationTable(value.Id);
        }
    }
    private UserNameListDefine _selectedUser;

    /// <summary>
    /// 用來判斷是否有選擇使用者。
    /// </summary>
    public int SelectedUserIndex
    {
        get { return _selectedUserIndex; }
        set
        {
            SetProperty(ref _selectedUserIndex, value);

            if (UserNameList != null)
            {
                int selectedNo = value + 1;
                FuncButtonEnabled = value >= 0;
                ButtonUpEnabled = selectedNo > 1 && FuncButtonEnabled;
                ButtonDownEnabled = selectedNo < UserNameList.Count && FuncButtonEnabled;
            }
            else
            {
                FuncButtonEnabled = false;
                ButtonUpEnabled = false;
                ButtonDownEnabled = false;
            }
        }
    }
    private int _selectedUserIndex;

    /// <summary>
    /// 按鍵Enabled。
    /// </summary>
    public bool FuncButtonEnabled
    {
        get { return _funcButtonEnabled; }
        set { SetProperty(ref _funcButtonEnabled, value); }
    }
    private bool _funcButtonEnabled = false;

    /// <summary>
    /// 上移按鍵Enabled。
    /// </summary>
    public bool ButtonUpEnabled
    {
        get { return _buttonUpEnabled; }
        set { SetProperty(ref _buttonUpEnabled, value); }
    }
    private bool _buttonUpEnabled;

    /// <summary>
    /// 下移按鍵Enabled。
    /// </summary>
    public bool ButtonDownEnabled
    {
        get { return _buttonDownEnabled; }
        set { SetProperty(ref _buttonDownEnabled, value); }
    }
    private bool _buttonDownEnabled;

    /// <summary>
    /// 排列上移。
    /// </summary>
    public DelegateCommand<object> MoveUpCommand
        => _moveUpCommand ??= new DelegateCommand<object>(ExecuteMoveUpCommand);
    private void ExecuteMoveUpCommand(object obj)
    {
        int userId = (int)obj;
        int targetIndex = SelectedUserIndex - 1;
        if (_authority.MoveOrderUp(userId))
        {
            UserNameList = _ad.UserNameList;
            SelectedUserIndex = targetIndex;
        }
    }
    private DelegateCommand<object> _moveUpCommand;

    /// <summary>
    /// 排列下移。
    /// </summary>
    public DelegateCommand<object> MoveDownCommand
        => _moveDownCommand ??= new DelegateCommand<object>(ExecuteMoveDownCommand);
    private void ExecuteMoveDownCommand(object obj)
    {
        int userId = (int)obj;
        int targetIndex = SelectedUserIndex + 1;
        if (_authority.MoveOrderDown(userId))
        {
            UserNameList = _ad.UserNameList;
            SelectedUserIndex = targetIndex;
        }
    }
    private DelegateCommand<object> _moveDownCommand;

    /********************
     * CRUD
     ********************/
    /// <summary>
    /// 新增使用者。
    /// </summary>
    public DelegateCommand NewUserCommand
        => _newUserCommand ??= new DelegateCommand(ExecuteNewUserCommand);
    private void ExecuteNewUserCommand()
    {
        _authority.NewUser();
    }
    private DelegateCommand _newUserCommand;

    /// <summary>
    /// 修改使用者名稱。
    /// </summary>
    public DelegateCommand<int?> ModifyUserNameCommand
        => _modifyUserNameCommand ??= new DelegateCommand<int?>(ExecuteModifyUserNameCommand);
    private void ExecuteModifyUserNameCommand(int? userId)
    {
        if (userId != null)
            _authority.ModifyUserName((int)userId);
    }
    private DelegateCommand<int?> _modifyUserNameCommand;

    /// <summary>
    /// 變更使用者密碼。
    /// </summary>
    public DelegateCommand<int?> ChangePasswordCommand
        => _changePasswordCommand ??= new DelegateCommand<int?>(ExecuteChangePasswordCommand);
    private void ExecuteChangePasswordCommand(int? userId)
    {
        if (userId != null)
            _authority.ChangePassword((int)userId);
    }
    private DelegateCommand<int?> _changePasswordCommand;

    /// <summary>
    /// 刪除使用者。
    /// </summary>
    public DelegateCommand<int?> DeleteUserCommand
        => _deleteUserCommand ??= new DelegateCommand<int?>(ExecuteDeleteUserCommand);
    private void ExecuteDeleteUserCommand(int? userId)
    {
        if (userId != null)
            _authority.DeleteUser((int)userId);
    }
    private DelegateCommand<int?> _deleteUserCommand;

    /********************
     * 主畫面
     ********************/
    /// <summary>
    /// 主控頁。
    /// </summary>
    public bool Menu_MainConsole
    {
        get { return _menu_MainConsole; }
        set { SetProperty(ref _menu_MainConsole, value); }
    }
    private bool _menu_MainConsole;

    /// <summary>
    /// 托盤參數。
    /// </summary>
    public bool Menu_PalletParameters
    {
        get { return _menu_PalletParameters; }
        set { SetProperty(ref _menu_PalletParameters, value); }
    }
    private bool _menu_PalletParameters;

    /// <summary>
    /// 取放治具參數。
    /// </summary>
    public bool Menu_StageParameters
    {
        get { return _menu_StageParameters; }
        set { SetProperty(ref _menu_StageParameters, value); }
    }
    private bool _menu_StageParameters;

    /********************
     * 
     ********************/
    /// <summary>
    /// 手動畫面。
    /// </summary>
    public bool Menu_Manual
    {
        get { return _menu_Manual; }
        set { SetProperty(ref _menu_Manual, value); }
    }
    private bool _menu_Manual;

    /// <summary>
    /// 大托盤設定。
    /// </summary>
    public bool Menu_Pallet
    {
        get { return _menu_Pallet; }
        set { SetProperty(ref _menu_Pallet, value); }
    }
    private bool _menu_Pallet;

    /// <summary>
    /// WFS規格設定。
    /// </summary>
    public bool Menu_WFS_Specification
    {
        get { return _menu_WFS_Specification; }
        set { SetProperty(ref _menu_WFS_Specification, value); }
    }
    private bool _menu_WFS_Specification;

    /// <summary>
    /// 托盤設定。
    /// </summary>
    public bool Menu_Tray
    {
        get { return _menu_Tray; }
        set { SetProperty(ref _menu_Tray, value); }
    }
    private bool _menu_Tray;

    /********************
     * 教導
     ********************/
    /// <summary>
    /// 機台基準點。
    /// </summary>
    public bool Menu_MachineDatum
    {
        get { return _menu_MachineDatum; }
        set { SetProperty(ref _menu_MachineDatum, value); }
    }
    private bool _menu_MachineDatum;

    /// <summary>
    /// 黏土座。
    /// </summary>
    public bool Menu_ClayTable
    {
        get { return _menu_ClayTable; }
        set { SetProperty(ref _menu_ClayTable, value); }
    }
    private bool _menu_ClayTable;

    /// <summary>
    /// 測高用位移計。
    /// </summary>
    public bool Menu_Displacement
    {
        get { return _menu_Displacement; }
        set { SetProperty(ref _menu_Displacement, value); }
    }
    private bool _menu_Displacement;

    /// <summary>
    /// STAGE。
    /// </summary>
    public bool Menu_Stage
    {
        get { return _menu_Stage; }
        set { SetProperty(ref _menu_Stage, value); }
    }
    private bool _menu_Stage;

    /// <summary>
    /// Pallet安裝點。
    /// </summary>
    public bool Menu_PalletInstallPoints
    {
        get { return _menu_PalletInstallPoints; }
        set { SetProperty(ref _menu_PalletInstallPoints, value); }
    }
    private bool _menu_PalletInstallPoints;

    /// <summary>
    /// 重複精度測試。
    /// </summary>
    public bool Menu_RepeatabilityTest
    {
        get { return _menu_RepeatabilityTest; }
        set { SetProperty(ref _menu_RepeatabilityTest, value); }
    }
    private bool _menu_RepeatabilityTest;

    /// <summary>
    /// 輸出參數報表。
    /// </summary>
    public bool Func_ReportOutput
    {
        get { return _func_ReportOutput; }
        set { SetProperty(ref _func_ReportOutput, value); }
    }
    private bool _func_ReportOutput;

    /********************
     * 
     ********************/
    /// <summary>
    /// 大數據。
    /// </summary>
    public bool Menu_BigData
    {
        get { return _menu_BigData; }
        set { SetProperty(ref _menu_BigData, value); }
    }
    private bool _menu_BigData;

    /// <summary>
    /// 異常履歷。
    /// </summary>
    public bool Report_AbnormalHistory
    {
        get { return _report_AbnormalHistory; }
        set { SetProperty(ref _report_AbnormalHistory, value); }
    }
    private bool _report_AbnormalHistory;

    /// <summary>
    /// 系統紀錄。
    /// </summary>
    public bool Report_SystemLogger
    {
        get { return _report_SystemLogger; }
        set { SetProperty(ref _report_SystemLogger, value); }
    }
    private bool _report_SystemLogger;

    /// <summary>
    /// 重大事件紀錄。
    /// </summary>
    public bool Report_ExceptionLogger
    {
        get { return _report_ExceptionLogger; }
        set { SetProperty(ref _report_ExceptionLogger, value); }
    }
    private bool _report_ExceptionLogger;

    /********************
     * 品種
     ********************/
    /// <summary>
    /// 品種切換。
    /// </summary>
    public bool Menu_Product_Switch
    {
        get { return _menu_Product_Switch; }
        set { SetProperty(ref _menu_Product_Switch, value); }
    }
    private bool _menu_Product_Switch;

    /// <summary>
    /// 品種管理。
    /// </summary>
    public bool Menu_Product_Manager
    {
        get { return _menu_Product_Manager; }
        set { SetProperty(ref _menu_Product_Manager, value); }
    }
    private bool _menu_Product_Manager;

    /********************
     * 系統
     ********************/
    /// <summary>
    /// System。
    /// </summary>
    public bool Menu_System
    {
        get { return _menu_System; }
        set { SetProperty(ref _menu_System, value); }
    }
    private bool _menu_System;

    /// <summary>
    /// 連線設定。
    /// </summary>
    public bool Menu_Connection
    {
        get { return _menu_Connection; }
        set { SetProperty(ref _menu_Connection, value); }
    }
    private bool _menu_Connection;

    /// <summary>
    /// 權限設定。
    /// </summary>
    public bool Menu_Authority
    {
        get { return _menu_Authority; }
        set { SetProperty(ref _menu_Authority, value); }
    }
    private bool _menu_Authority;

    /// <summary>
    /// 
    /// </summary>
    public int InputDetectInterval
    {
        get { return _inputDetectInterval; }
        set { SetProperty(ref _inputDetectInterval, value); }
    }
    private int _inputDetectInterval;
}
