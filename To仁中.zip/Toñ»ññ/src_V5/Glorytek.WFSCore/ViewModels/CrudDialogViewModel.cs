﻿using Glorytek.CSharp.Data.Validation;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Models;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System;
using System.Collections.Generic;
using System.Windows.Controls;

namespace Glorytek.WFSCore.ViewModels;

/// <summary>
/// CRUD Dialog 的 ViewModel。
/// </summary>
public class CrudDialogViewModel : BindableBase, IDialogAware
{
    private CrudAction _action; // 要求的動作
    private bool _hasOriName;   // 是否有傳入原名稱
    private bool _hasNewName;   // 是否有傳入新名稱
    private bool _hasPassword;  // 是否有傳入密碼
    private bool _hasMemo;      // 是否有傳入備註

    CrudInfo _ci; // 備份傳入的Info，回傳也是用這個Info

    /********************
     * IDialogAware
     ********************/
    public event Action<IDialogResult> RequestClose;
    public bool CanCloseDialog() => true;
    public void OnDialogClosed() { }

    public DelegateCommand<object> CloseDialogCommand
        => _closeDialogCommand ??= new DelegateCommand<object>(ExecuteCloseDialogCommand);
    protected virtual void ExecuteCloseDialogCommand(object parameter)
    {
        if (parameter != null)
        {
            _ci.Result = ButtonResult.OK;
            if (_hasNewName)
                _ci.NewName = NewName.Trim();
            if (_hasPassword)
                _ci.Password = (parameter as PasswordBox).Password.GetMD5Hash();
            if (_hasMemo)
                _ci.Memo = Memo.Trim();
        }
        else
        {
            _ci.Result = ButtonResult.Cancel;
            _ci.NewName = string.Empty;
            _ci.Password = string.Empty;
            _ci.Memo = string.Empty;
        }

        // 序列化
        var paras = new DialogParameters()
            {
                {
                    "StatusBarMessage",
                    JsonConvert.SerializeObject(_ci, new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore
                    })
                }
            };

        RaiseRequestClose(new DialogResult(_ci.Result, paras));
    }
    private DelegateCommand<object> _closeDialogCommand;

    public virtual void RaiseRequestClose(IDialogResult dialogResult)
        => RequestClose?.Invoke(dialogResult);

    public void OnDialogOpened(IDialogParameters parameters)
    {
        // 反序列化，取得資料
        _ci = JsonConvert.DeserializeObject<CrudInfo>(parameters.GetValue<string>("StatusBarMessage"));

        Title = _ci.Title;
        _action = _ci.Action;

        // 檢查傳入資料
        _hasOriName = !string.IsNullOrWhiteSpace(_ci.OriginalTitle);
        _hasNewName = !string.IsNullOrWhiteSpace(_ci.NewTitle);
        _hasPassword = !string.IsNullOrWhiteSpace(_ci.PasswordTitle);
        _hasMemo = !string.IsNullOrWhiteSpace(_ci.MemoTitle);

        switch (_action)
        {
            case CrudAction.Create:
            case CrudAction.Append:
            case CrudAction.Delete:
                if (_hasOriName)    // 無原名稱
                {
                    OriginalName = "";
                    OriginalNameTitle = "";
                    OriginalNameVisibility = false;
                    OriginalNameEnabled = false;
                }
                else
                {
                    OriginalNameVisibility = false;
                }

                if (_hasNewName)    // 空白
                {
                    NewName = "";
                    NewNameTitle = _ci.NewTitle;
                    NewNameVisibility = true;
                    NewNameEnabled = true;
                }
                else
                {
                    NewNameVisibility = false;
                }

                if (_hasPassword)
                {
                    PasswordTitle = _ci.PasswordTitle;
                    PasswordMaxLength = _ci.PasswordMaxLength;
                    PasswordWatermark = _ci.PasswordWatermark;
                    PasswordVisibility = true;
                    PasswordEnabled = true;
                }
                else
                {
                    PasswordVisibility = false;
                }

                if (_hasMemo)
                {
                    Memo = "";
                    MemoTitle = _ci.MemoTitle;
                    MemoVisibility = true;
                    MemoEnabled = true;
                }
                else
                {
                    MemoVisibility = false;
                }
                break;

            case CrudAction.Insert:
            case CrudAction.Modify:
            case CrudAction.Copy:
                if (_hasOriName)
                {
                    OriginalName = _ci.OriginalName;
                    OriginalNameTitle = _ci.OriginalTitle;
                    OriginalNameVisibility = true;
                    OriginalNameEnabled = false;
                }
                else
                {
                    OriginalNameVisibility = false;
                }

                if (_hasNewName)    // 同原名稱
                {
                    NewName = _ci.NewName;
                    NewNameTitle = _ci.NewTitle;
                    NewNameVisibility = true;
                    NewNameEnabled = true;
                }
                else
                {
                    NewNameVisibility = false;
                }

                if (_hasPassword)
                {
                    PasswordTitle = _ci.PasswordTitle;
                    PasswordMaxLength = _ci.PasswordMaxLength;
                    PasswordWatermark = _ci.PasswordWatermark;
                    PasswordVisibility = true;
                    PasswordEnabled = true;
                }
                else
                {
                    PasswordVisibility = false;
                }

                if (_hasMemo)
                {
                    Memo = _ci.Memo;
                    MemoTitle = _ci.MemoTitle;
                    MemoVisibility = true;
                    MemoEnabled = true;
                }
                else
                {
                    MemoVisibility = false;
                }
                break;

            case CrudAction.Rename:
                if (_hasOriName)
                {
                    OriginalName = _ci.OriginalName;
                    OriginalNameTitle = _ci.OriginalTitle;
                    OriginalNameVisibility = true;
                    OriginalNameEnabled = false;
                }
                else
                {
                    OriginalNameVisibility = false;
                }

                if (_hasNewName)
                {
                    NewName = _ci.NewName;
                    NewNameTitle = _ci.NewTitle;
                    NewNameVisibility = true;
                    NewNameEnabled = true;
                }
                else
                {
                    NewNameVisibility = false;
                }

                PasswordVisibility = false; // 無密碼

                if (_hasMemo)
                {
                    Memo = _ci.Memo;
                    MemoTitle = _ci.MemoTitle;
                    MemoVisibility = true;
                    MemoEnabled = true;
                }
                else
                {
                    MemoVisibility = false;
                }
                break;
            case CrudAction.None:
                break;
            case CrudAction.Read:
                break;
            case CrudAction.Update:
                break;
                //case CrudAction.ChangeNumber:
                //    OriginalName = _ci.OriginalName;
                //    OriginalNameTitle = _ci.OriginalTitle;
                //    OriginalNameVisibility = true;
                //    OriginalNameEnabled = false;

                //    NewName = _ci.NewName;
                //    NewNameTitle = _ci.NewTitle;
                //    NewNameVisibility = true;
                //    NewNameEnabled = true;

                //    MemoVisibility = false;
                //    break;
        }

        NewNameFocus = true;
    }

    /********************
    * Data
    ********************/
    public string Title
    {
        get { return _title; }
        set { SetProperty(ref _title, value); }
    }
    private string _title;

    // OriginalName
    public string OriginalName
    {
        get { return _originalName; }
        set { SetProperty(ref _originalName, value); }
    }
    private string _originalName;

    public string OriginalNameTitle
    {
        get { return _originalNameTitle; }
        set { SetProperty(ref _originalNameTitle, value); }
    }
    private string _originalNameTitle;

    public bool OriginalNameVisibility
    {
        get { return _originalNameVisibility; }
        set { SetProperty(ref _originalNameVisibility, value); }
    }
    private bool _originalNameVisibility;

    public bool OriginalNameEnabled
    {
        get { return _originalNameEnabled; }
        set { SetProperty(ref _originalNameEnabled, value); }
    }
    private bool _originalNameEnabled;

    // NewName
    public string NewName
    {
        get { return _newName; }
        set { SetProperty(ref _newName, value); }
    }
    private string _newName;

    public string NewNameTitle
    {
        get { return _newNameTitle; }
        set { SetProperty(ref _newNameTitle, value); }
    }
    private string _newNameTitle;

    public bool NewNameVisibility
    {
        get { return _newNameVisibility; }
        set { SetProperty(ref _newNameVisibility, value); }
    }
    private bool _newNameVisibility;

    public bool NewNameEnabled
    {
        get { return _newNameEnabled; }
        set { SetProperty(ref _newNameEnabled, value); }
    }
    private bool _newNameEnabled;

    public bool NewNameFocus
    {
        get { return _newNameFocus; }
        set { SetProperty(ref _newNameFocus, value); }
    }
    private bool _newNameFocus;

    // Password
    public string PasswordTitle
    {
        get { return _passwordTitle; }
        set { SetProperty(ref _passwordTitle, value); }
    }
    private string _passwordTitle;

    public bool PasswordVisibility
    {
        get { return _passwordVisibility; }
        set { SetProperty(ref _passwordVisibility, value); }
    }
    private bool _passwordVisibility;

    public bool PasswordEnabled
    {
        get { return _passwordEnabled; }
        set { SetProperty(ref _passwordEnabled, value); }
    }
    private bool _passwordEnabled;

    public int PasswordMaxLength
    {
        get { return _passwordMaxLength; }
        set { SetProperty(ref _passwordMaxLength, value); }
    }
    private int _passwordMaxLength;

    public string PasswordWatermark
    {
        get { return _passwordWatermark; }
        set { SetProperty(ref _passwordWatermark, value); }
    }
    private string _passwordWatermark;

    // Memo
    public string Memo
    {
        get { return _memo; }
        set { SetProperty(ref _memo, value.Trim()); }
    }
    private string _memo;

    public string MemoTitle
    {
        get { return _memoTitle; }
        set { SetProperty(ref _memoTitle, value); }
    }
    private string _memoTitle;

    public bool MemoVisibility
    {
        get { return _memoVisibility; }
        set { SetProperty(ref _memoVisibility, value); }
    }
    private bool _memoVisibility;

    public bool MemoEnabled
    {
        get { return _memoEnabled; }
        set { SetProperty(ref _memoEnabled, value); }
    }
    private bool _memoEnabled;

    // SelectionList
    public List<string> SelectionList
    {
        get { return _selectionList; }
        set { SetProperty(ref _selectionList, value); }
    }
    private List<string> _selectionList;

    public string SelectionItem
    {
        get { return _selectionItem; }
        set { SetProperty(ref _selectionItem, value); }
    }
    private string _selectionItem;

    public string SelectionListTitle
    {
        get { return _selectionListTitle; }
        set { SetProperty(ref _selectionListTitle, value); }
    }
    private string _selectionListTitle;

    public bool SelectionListVisibility
    {
        get { return _selectionListVisibility; }
        set { SetProperty(ref _selectionListVisibility, value); }
    }
    private bool _selectionListVisibility;

    public bool SelectionListEnabled
    {
        get { return _selectionListEnabled; }
        set { SetProperty(ref _selectionListEnabled, value); }
    }
    private bool _selectionListEnabled;
}
