﻿using Glorytek.WFS.Authority.Views;
using Glorytek.WFSCore.Authority;
using Glorytek.WFSCore.Constants;
using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Services;
using Glorytek.WFSCore.ViewModels;
using Glorytek.WFSCore.Views;
using Glorytek.WPF.PrismSplashScreen;
using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;

namespace Glorytek.WFSCore
{
    public class WFSCoreModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            IEventAggregator ea = containerProvider.Resolve<IEventAggregator>();

            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "權限系統初始化..." });
            var authority = containerProvider.Resolve<AuthorityService>();
            authority.ModuleInit();
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.Register<IAuthority, AuthorityService>();
            containerRegistry.Register<ISystemMessenger, SystemMessengerService>();
            containerRegistry.Register<ICrudDialog, CrudDialogService>();

            containerRegistry.RegisterForNavigation<AuthoritySetting, AuthoritySettingViewModel>(PageKeys.AuthoritySetting);

            containerRegistry.RegisterDialog<CrudDialog, CrudDialogViewModel>();
            containerRegistry.RegisterDialog<LoginScreen, LoginScreenViewModel>();
        }
    }
}