﻿using System.Windows.Controls;

namespace Glorytek.WFSCore.Views
{
    /// <summary>
    /// Interaction logic for CrudDialog
    /// </summary>
    public partial class CrudDialog : UserControl
    {
        public CrudDialog()
        {
            InitializeComponent();
        }
    }
}
