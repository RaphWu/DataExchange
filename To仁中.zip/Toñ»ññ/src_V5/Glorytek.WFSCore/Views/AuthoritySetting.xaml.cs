﻿using System.Windows.Controls;

namespace Glorytek.WFS.Authority.Views;

/// <summary>
/// Interaction logic for AuthoritySetting
/// </summary>
public partial class AuthoritySetting : UserControl
{
    public AuthoritySetting()
    {
        InitializeComponent();
    }
}
