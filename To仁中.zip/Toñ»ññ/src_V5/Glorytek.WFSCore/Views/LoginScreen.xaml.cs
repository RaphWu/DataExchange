﻿using System.Windows.Controls;

namespace Glorytek.WFSCore.Views
{
    /// <summary>
    /// Interaction logic for LoginScreen
    /// </summary>
    public partial class LoginScreen : UserControl
    {
        public LoginScreen()
        {
            InitializeComponent();
        }
    }
}
