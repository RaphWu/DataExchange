﻿using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Events;
using Glorytek.WFSCore.Models;
using Prism.Events;

namespace Glorytek.WFSCore.Services;

/// <summary>
/// 系統訊息管理，主頁面訊息顯示讀取。
/// </summary>
public class SystemMessengerService : ISystemMessenger
{
    /********************
     * ctor
     ********************/
    private readonly IEventAggregator _ea;

    public SystemMessengerService(IEventAggregator ea)
    {
        _ea = ea;
    }

    /// <inheritdoc/>
    public void ShowProgressRing(bool visibility)
    {
        SystemDataInstance.Instance.ProgressRingVisibility = visibility;
    }

    /********************
     * Status Bar
     ********************/
    /// <inheritdoc/>
    public void StatusBarMessage(string message)
    {
        SystemDataInstance.Instance.StatusBarMessage = message;
    }

    ///// <inheritdoc/>
    //public void Authorization(string message)
    //{
    //    SystemDataInstance.Instance.Authorization = message;
    //}

    ///// <inheritdoc/>
    //public void LightUpPreviousMainMenuButton(string empty)
    //{
    //    _ea.GetEvent<SystemEvent>().Publish(new SystemEventInfo
    //    {
    //        Classification = SystemEventType.LightUpPreviousMainMenuButton,
    //        Message = string.Empty,
    //    });
    //}

    /// <inheritdoc/>
    public void OperateMessage(string message)
    {
        _ea.GetEvent<ShowOperateMessageEvent>().Publish(message);
    }
}
