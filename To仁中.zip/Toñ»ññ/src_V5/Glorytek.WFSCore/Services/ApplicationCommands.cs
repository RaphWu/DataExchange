﻿using Glorytek.WFSCore.Contracts;
using Prism.Commands;

namespace Glorytek.WFSCore.Services;

/// <summary>
/// 由 Prism CompositeCommand 實現的應用程式全域命令。
/// </summary>
public class ApplicationCommands : IApplicationCommands
{
    private readonly CompositeCommand _saveDataCommand = new(true);
    public CompositeCommand SaveDataCommand => _saveDataCommand;
}
