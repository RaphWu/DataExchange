﻿using Glorytek.WFSCore.Contracts;
using Glorytek.WFSCore.Models;
using Glorytek.WFSCore.Views;
using Newtonsoft.Json;
using Prism.Services.Dialogs;

namespace Glorytek.WFSCore.Services;

/// <summary>
/// CRUD Service。<br/>
/// 使用Prism Dialog Service實現。
/// </summary>
public class CrudDialogService : ICrudDialog
{
    private readonly IDialogService _dialog;

    /********************
     * ctor
     ********************/
    public CrudDialogService(IDialogService dialog)
    {
        _dialog = dialog;
    }

    /// <inheritdoc/>
    public CrudInfo ShowDialog(CrudInfo crudInfo)
    {
        IDialogResult result = default;

        // 序列化
        var paras = new DialogParameters
            {
                {
                    "StatusBarMessage",
                    JsonConvert.SerializeObject(crudInfo, new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore
                    })
                }
            };

        // 顯示Dialog
        _dialog.ShowDialog(nameof(CrudDialog), paras, r => { result = r; });
        return result.Parameters.Count > 0
            ? JsonConvert.DeserializeObject<CrudInfo>(result.Parameters.GetValue<string>("StatusBarMessage"))
            : new CrudInfo() { Result = ButtonResult.Abort };
    }
}
