﻿using Glorytek.WFSCore.Constants;
using Prism.Services.Dialogs;

namespace Glorytek.WFSCore.Models;

/// <summary>
/// CRUD交握資料。
/// </summary>
public class CrudInfo
{
    /// <summary>
    /// CRUD動作識別碼。
    /// </summary>
    public CrudAction Action { get; set; }

    /// <summary>
    /// Dialog返回的按鍵。
    /// </summary>
    public ButtonResult Result { get; set; }

    /// <summary>
    /// CRUD視窗的標題。
    /// </summary>
    public string Title { get; set; }

    /// <summary>
    /// 資料ID。
    /// </summary>
    public int Id { get; set; }

    /********************
     * Original
     ********************/
    /// <summary>
    /// 原資料。
    /// </summary>
    public string OriginalName { get; set; }

    /// <summary>
    /// 原資料名稱。
    /// </summary>
    public string OriginalTitle { get; set; }

    /********************
     * New
     ********************/
    /// <summary>
    /// 新資料。
    /// </summary>
    public string NewName { get; set; }

    /// <summary>
    /// 新資料名稱。
    /// </summary>
    public string NewTitle { get; set; }

    /********************
     * Password
     ********************/
    /// <summary>
    /// 密碼。
    /// </summary>
    public string Password { get; set; }

    /// <summary>
    /// 密碼名稱。
    /// </summary>
    public string PasswordTitle { get; set; }

    /// <summary>
    /// 密碼最大長度。
    /// </summary>
    public int PasswordMaxLength { get; set; } = -1;

    /// <summary>
    /// 密碼框浮水印字串。
    /// </summary>
    public string PasswordWatermark { get; set; }

    /********************
     * Memo
     ********************/
    /// <summary>
    /// 註解。
    /// </summary>
    public string Memo { get; set; }

    /// <summary>
    /// 註解名稱。
    /// </summary>
    public string MemoTitle { get; set; }
}
