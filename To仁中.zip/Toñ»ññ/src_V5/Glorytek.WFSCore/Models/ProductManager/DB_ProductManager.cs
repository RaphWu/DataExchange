﻿namespace Glorytek.WFSCore.Models.ProductManager;

/// <summary>
/// 資料庫定義 - 品種管理。
/// </summary>
internal class DB_ProductManager
{
    /// <summary>
    /// 產品的資料庫檔案名稱。
    /// </summary>
    /// <remarks>
    /// 1. 內容 = Path.Combine(DBbase.DIRECTORY_PRODUCT, $"{品種名稱}{DBbase.DB_EXT_FILE_NAME}");<br/>
    /// 2. 內容由 ProductManager 管理。
    /// </remarks>
    internal static string DbName_Product { get; set; } = string.Empty;

    /// <summary>
    /// 品種資訊。
    /// </summary>
    internal const string TableName_Information = "Information";
    internal const string CreateTableSQL_Information = @"CREATE TABLE IF NOT EXISTS [Information](
[ProductName] TEXT NOT NULL UNIQUE,
[Memo] TEXT);";
}
