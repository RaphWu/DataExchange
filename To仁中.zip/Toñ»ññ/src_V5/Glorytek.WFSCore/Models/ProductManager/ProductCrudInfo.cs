﻿using Glorytek.WFSCore.Constants;

namespace Glorytek.WFSCore.Models.ProductManager;

/// <summary>
/// 品種CRUD資料定義。
/// </summary>
public class ProductCrudInfo
{
    /// <summary>
    /// CRUD動作分類。
    /// </summary>
    public CrudAction Action { get; set; }

    /// <summary>
    /// CRUD動作的標題。
    /// </summary>
    public string Title { get; set; }

    /// <summary>
    /// 原品種名稱。
    /// </summary>
    public string ProductName { get; set; }

    /// <summary>
    /// 新品種名稱。
    /// </summary>
    public string NewProductName { get; set; }

    /// <summary>
    /// 註解。
    /// </summary>
    public string Memo { get; set; }

    /// <summary>
    /// 儲存後立即切換至新品種。
    /// </summary>
    public bool ApplyNewProduct { get; set; }
}
