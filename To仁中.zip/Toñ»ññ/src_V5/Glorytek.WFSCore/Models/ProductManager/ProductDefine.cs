﻿namespace Glorytek.WFSCore.Models.ProductManager;

/// <summary>
/// 品種資訊。
/// </summary>
public class ProductDefine
{
    /// <summary>
    /// 品種名稱。
    /// </summary>
    public string ProductName { get; set; }

    /// <summary>
    /// 品種註解。
    /// </summary>
    public string Memo { get; set; }
}
