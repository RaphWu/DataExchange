﻿using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace Glorytek.WFSCore.Models.ProductManager;

/// <summary>
/// 目前品種的狀態資料。
/// </summary>
public class ProductDatas : BindableBase
{
    private ProductDatas() { }
    private static readonly Lazy<ProductDatas> _instance = new(() => new ProductDatas());
    public static ProductDatas Instance => _instance.Value;

    /// <summary>
    /// 目前開啟的品種DB連線。
    /// </summary>
    public SQLiteConnection DbConnection { get; set; } = null;

    /// <summary>
    /// 品種名稱是否有效。
    /// </summary>
    public bool IsProductActive
    {
        get { return _isProductActive; }
        set { SetProperty(ref _isProductActive, value); }
    }
    private bool _isProductActive = false;

    /// <summary>
    /// 目前有效品種名稱。
    /// </summary>
    public string ActiveProductName
    {
        get { return _activeProductName; }
        set { SetProperty(ref _activeProductName, value); }
    }
    private string _activeProductName = string.Empty;

    /// <summary>
    /// 品種列表。
    /// </summary>
    public List<ProductDefine> ProductList
    {
        get { return _productList; }
        set { SetProperty(ref _productList, value); }
    }
    private List<ProductDefine> _productList = null;

    /********************
     * ProductChanged回饋信號
     * 註：原是用IEventAggregator，才能完全解耦
     * 但WFS有一個參數寫入PLC動作，必須確認所有組件的品種更換完成後才能執行，
     * 因此才改為回饋信號的方式。
     * 發出品種更換事件前，先將全部回饋信號設為true表示該作業仍執行中，
     * 再檢查若為false時，表示該作業完成。
     ********************/
    /// <summary>
    /// 品種更換作業Tray回饋信號。
    /// </summary>
    public bool ProductChangedRunning_Tray { get; set; } = false;

    /// <summary>
    /// 品種更換作業WFS回饋信號。
    /// </summary>
    public bool ProductChangedRunning_Wfs { get; set; } = false;

    /// <summary>
    /// 品種更換作業Stage回饋信號。
    /// </summary>
    public bool ProductChangedRunning_Stage { get; set; } = false;
}
