﻿using Glorytek.WFSCore.Constants;
using Prism.Mvvm;
using System;
using System.Globalization;

namespace Glorytek.WFSCore.Models;

/// <summary>
/// 系統狀態監控。
/// </summary>
public class SystemDataInstance : BindableBase
{
    private SystemDataInstance() { }
    private static readonly Lazy<SystemDataInstance> _instance = new(() => new SystemDataInstance());
    public static SystemDataInstance Instance => _instance.Value;

    /********************
     * 內部屬性
     ********************/
#if DEBUG
    /// <summary>
    /// 由於改用SetProperty()後，設定變數會引發遞迴呼叫而堆疊溢位，故多加_forcedMode避免遞迴
    /// </summary>
    private static bool _forcedMode = false;
#endif

    /// <summary>
    /// 更新內部屬性。
    /// </summary>
    private void UpdateSystemStatus()
    {
        SystemAlarm = PlcAlarm;
        HardwareReady = !EMS && !SystemAlarm && PlcReady;

        SystemReady = HardwareReady && AppConfigReady;
        SystemStabilized = SystemReady && PlcStabilized;
        SystemStabilizedExceptAutoMode = SystemReady && PlcStabilizedExceptAutoMode;

        ProductReady = SystemReady && ProductLoaded;
        ProductStabilized = SystemStabilized && ProductLoaded;
        ProductStabilizedExceptAutoMode = SystemStabilizedExceptAutoMode && ProductLoaded;

#if DEBUG
        /********************
         * 在DEBUG時，須依有無連接網路線，變更 NoPlcConnected 的值
         ********************/
        if (DEBUG.NoPlcConnected && !_forcedMode)
        {
            _forcedMode = true;

            EMS = false;
            SystemAlarm = false;
            PlcReady = true;
            HardwareReady = true;
            SystemReady = true;
            PlcStabilized = true;
            ProductReady = true;
            PlcStabilizedExceptAutoMode = true;
            SystemStabilized = true;
            ProductStabilized = true;
            ProductStabilizedExceptAutoMode = true;

            SystemMode = SystemOperateModeType.LensSorting;

            _forcedMode = false;
        }
#endif
    }

    /// <summary>
    /// 應用程式語系。
    /// </summary>
    public CultureInfo SystemCultureInfo;
    public string LanguageTag;

    /********************
     * 作業模式(從PlcDatas複製)
     ********************/
    /// <summary>
    /// 系統作業模式。
    /// </summary>
    public SystemOperateModeType SystemMode
    {
        get { return _systemMode; }
        set
        {
            SetProperty(ref _systemMode, value);

            SystemMode_Online_FixStage = value == SystemOperateModeType.Online_FixStage;
            SystemMode_Online_DoubleCylinder = value == SystemOperateModeType.Online_DoubleCylinder;
            SystemMode_Online_SingleCylinder = value == SystemOperateModeType.Online_SingleCylinder;
            SystemMode_Online_Disc = value == SystemOperateModeType.Online_Disc;
            SystemMode_LensSorting = value == SystemOperateModeType.LensSorting;
            SystemMode_LensArrange = value == SystemOperateModeType.LensArrange;
            SystemMode_Tray_A1 = value == SystemOperateModeType.Tray_A1;
        }
    }
    private SystemOperateModeType _systemMode;

    /// <summary>
    /// 連線模式。
    /// </summary>
    /// <summary>
    /// 
    /// </summary>
    public bool SystemMode_Online_FixStage
    {
        get { return _systemMode_Online_FixStage; }
        set { SetProperty(ref _systemMode_Online_FixStage, value); }
    }
    private bool _systemMode_Online_FixStage;

    /// <summary>
    /// 分檢模式。
    /// </summary>
    public bool SystemMode_LensSorting
    {
        get { return _systemMode_LensSorting; }
        set { SetProperty(ref _systemMode_LensSorting, value); }
    }
    private bool _systemMode_LensSorting;

    /// <summary>
    /// 轉角度模式。
    /// </summary>
    public bool SystemMode_LensArrange
    {
        get { return _systemMode_LensArrange; }
        set { SetProperty(ref _systemMode_LensArrange, value); }
    }
    private bool _systemMode_LensArrange;

    /// <summary>
    /// 對接模式(單汽缸)。
    /// </summary>
    public bool SystemMode_Online_SingleCylinder
    {
        get { return _systemMode_Online_SingleCylinder; }
        set { SetProperty(ref _systemMode_Online_SingleCylinder, value); }
    }
    private bool _systemMode_Online_SingleCylinder;

    /// <summary>
    /// 對接模式(雙汽缸)。
    /// </summary>
    public bool SystemMode_Online_DoubleCylinder
    {
        get { return _systemMode_Online_DoubleCylinder; }
        set { SetProperty(ref _systemMode_Online_DoubleCylinder, value); }
    }
    private bool _systemMode_Online_DoubleCylinder;

    /// <summary>
    /// 對接模式(圓盤)。
    /// </summary>
    public bool SystemMode_Online_Disc
    {
        get { return _systemMode_Online_Disc; }
        set { SetProperty(ref _systemMode_Online_Disc, value); }
    }
    private bool _systemMode_Online_Disc;

    /// <summary>
    /// TRAY > A1重複精度。
    /// </summary>
    public bool SystemMode_Tray_A1
    {
        get { return _systemMode_Tray_A1; }
        set { SetProperty(ref _systemMode_Tray_A1, value); }
    }
    private bool _systemMode_Tray_A1;

    /********************
     * 系統屬性 (由ISystem設定)
     ********************/
    /// <summary>
    /// AppConfig設定讀取完成。
    /// </summary>
    public bool AppConfigReady
    {
        get { return _appConfigReady; }
        set
        {
            SetProperty(ref _appConfigReady, value);
            UpdateSystemStatus();
        }
    }
    private bool _appConfigReady = false;

    /// <summary>
    /// 品種已載入。
    /// </summary>
    /// <remarks>由 ProductManagerService.SwitchProduct() 設定，僅供SystemDataInstance更新狀態用。</remarks>
    public bool ProductLoaded
    {
        get { return _productLoaded; }
        set
        {
            SetProperty(ref _productLoaded, value);
            UpdateSystemStatus();
        }
    }
    private bool _productLoaded = false;

    /********************
     * 操作
     ********************/
    /// <summary>
    /// 自動運轉模式。
    /// </summary>
    public bool AutoMode
    {
        get { return _autoMode; }
        set { SetProperty(ref _autoMode, value); }
    }
    private bool _autoMode;

    /// <summary>
    /// 自動運轉模式。
    /// </summary>
    public bool NonAutoMode
    {
        get { return _nonAutoMode; }
        set { SetProperty(ref _nonAutoMode, value); }
    }
    private bool _nonAutoMode;

    /// <summary>
    /// 手動運轉模式。
    /// </summary>
    public bool ManualMode
    {
        get { return _manualMode; }
        set { SetProperty(ref _manualMode, value); }
    }
    private bool _manualMode;

    /// <summary>
    /// 機台暫停中。
    /// </summary>
    public bool MachinePause
    {
        get { return _machinePause; }
        set { SetProperty(ref _machinePause, value); }
    }
    private bool _machinePause;

    /// <summary>
    /// 試運轉/空跑。
    /// </summary>
    public bool TestMode
    {
        get { return _testMode; }
        set { SetProperty(ref _testMode, value); }
    }
    private bool _testMode;

    /// <summary>
    /// 是否顯示 Progress。
    /// </summary>
    public bool ProgressRingVisibility
    {
        get { return _progressRingVisibility; }
        set { SetProperty(ref _progressRingVisibility, value); }
    }
    private bool _progressRingVisibility = false;

    /********************
     * Status Bar
     ********************/
    /// <summary>
    /// 在 Status Bar 的 Message 區要顯示的字串。
    /// </summary>
    public string StatusBarMessage
    {
        get { return _statusBarMessage; }
        set { SetProperty(ref _statusBarMessage, value); }
    }
    private string _statusBarMessage = "";

    ///// <summary>
    ///// 
    ///// </summary>
    //public string Authorization
    //{
    //    get { return _authorization; }
    //    set
    //    {
    //        _authorization = value;
    //        OnPropertyChanged();
    //    }
    //}
    //private string _authorization;

    /********************
     * Clock & Time
     ********************/
    /// <summary>
    /// 重置開機時間的日期時間。
    /// </summary>
    public DateTime MachineResetTime { get; set; }

    /// <summary>
    /// 機台開機累計運轉時間。
    /// </summary>
    public DateTime MachineRuningTime
    {
        get { return _machineRuningTime; }
        set
        {
            _machineRuningTime = value;
            TimeSpan ts = value - MachineResetTime;
            MachineRunTimeString = $"{ts.Days} 天 {ts.Hours} 時 {ts.Minutes} 分 {ts.Seconds} 秒";
        }
    }
    private DateTime _machineRuningTime;

    /// <summary>
    /// 機台運轉時間。
    /// </summary>
    public string MachineRunTimeString
    {
        get { return _machineRunTimeString; }
        set { SetProperty(ref _machineRunTimeString, value); }
    }
    private string _machineRunTimeString;

    /// <summary>
    /// 生產啟動時間。
    /// </summary>
    public DateTime ProductionStartTime
    {
        get { return _productionStartTime; }
        set { SetProperty(ref _productionStartTime, value); }
    }
    private DateTime _productionStartTime;

    /// <summary>
    /// 生產運轉時間。
    /// </summary>
    public TimeSpan ProductionRunTime
    {
        get { return _productionRunTime; }
        set
        {
            SetProperty(ref _productionRunTime, value);
            ProductionRunTimeString = $"{ProductionRunTime.Days} 天 {ProductionRunTime.Hours} 時 {ProductionRunTime.Minutes} 分 {ProductionRunTime.Seconds} 秒";
        }
    }
    private TimeSpan _productionRunTime;

    /// <summary>
    /// 生產運轉時間。
    /// </summary>
    public string ProductionRunTimeString
    {
        get { return _productionRunTimeString; }
        set { SetProperty(ref _productionRunTimeString, value); }
    }
    private string _productionRunTimeString;

    /// <summary>
    /// 500ms閃爍。
    /// </summary>
    public bool Flicker500
    {
        get { return _flicker500; }
        set { SetProperty(ref _flicker500, value); }
    }
    private bool _flicker500;

    /// <summary>
    /// 1秒閃爍。
    /// </summary>
    public bool Flicker1000
    {
        get { return _flicker1000; }
        set { SetProperty(ref _flicker1000, value); }
    }
    private bool _flicker1000;

    /// <summary>
    /// 時鐘。
    /// </summary>
    public DateTime Clock
    {
        get { return _clock; }
        set
        {
            SetProperty(ref _clock, value);
            ClockString = $"{value:yyyy/MM/dd HH:mm}";
        }
    }
    private DateTime _clock;

    /// <summary>
    /// 時鐘的格式化字串。
    /// </summary>
    public string ClockString
    {
        get { return _clockString; }
        set { SetProperty(ref _clockString, value); }
    }
    private string _clockString;

    /********************
     * Hardware
     ********************/
    /// <summary>
    /// 硬體設備Ready。
    /// </summary>
    public bool HardwareReady
    {
        get { return _hardwareReady; }
        set { SetProperty(ref _hardwareReady, value); }
    }
    private bool _hardwareReady;

    /// <summary>
    /// 系統是否在警報中。
    /// </summary>
    public bool SystemAlarm
    {
        get { return _systemAlarm; }
        set { SetProperty(ref _systemAlarm, value); }
    }
    private bool _systemAlarm;

    /// <summary>
    /// 系統Ready。
    /// </summary>
    public bool SystemReady
    {
        get { return _systemReady; }
        set { SetProperty(ref _systemReady, value); }
    }
    private bool _systemReady;

    /// <summary>
    /// 系統Ready且在穩定狀態。
    /// </summary>
    public bool SystemStabilized
    {
        get { return _systemStabilized; }
        set { SetProperty(ref _systemStabilized, value); }
    }
    private bool _systemStabilized = false;

    /// <summary>
    /// 系統Ready且在穩定狀態(非自動模式)。
    /// </summary>
    public bool SystemStabilizedExceptAutoMode
    {
        get { return _systemStabilizedExceptAutoMode; }
        set { SetProperty(ref _systemStabilizedExceptAutoMode, value); }
    }
    private bool _systemStabilizedExceptAutoMode;

    /// <summary>
    /// 品種備便。
    /// </summary>
    public bool ProductReady
    {
        get { return _productReady; }
        set { SetProperty(ref _productReady, value); }
    }
    private bool _productReady = false;

    /// <summary>
    /// 系統Ready、品種已載入且在穩定狀態。
    /// </summary>
    public bool ProductStabilized
    {
        get { return _productStabilized; }
        set { SetProperty(ref _productStabilized, value); }
    }
    private bool _productStabilized;

    /// <summary>
    /// 系統Ready、品種已載入且在穩定狀態(非自動模式)。
    /// </summary>
    public bool ProductStabilizedExceptAutoMode
    {
        get { return _productStabilizedExceptAutoMode; }
        set { SetProperty(ref _productStabilizedExceptAutoMode, value); }
    }
    private bool _productStabilizedExceptAutoMode;

    /********************
     * 內部設備
     ********************/
    /// <summary>
    /// 緊急停止開關。
    /// </summary>
    public bool EMS
    {
        get { return _ems; }
        set
        {
            SetProperty(ref _ems, value);
            UpdateSystemStatus();
        }
    }
    private bool _ems;

    ///// <summary>
    ///// 氣壓源壓力
    ///// </summary>
    //public bool AirSourcePressure
    //{
    //    get { return _airSourcePressure; }
    //    set
    //    {
    //        _airSourcePressure = value;
    //        OnPropertyChanged();
    //    }
    //}
    //private bool _airSourcePressure;

    /********************
     * 外部設備
     ********************/
    /// <summary>
    /// PLC Alert。
    /// </summary>
    public bool PlcAlarm
    {
        get { return _plcAlarm; }
        set
        {
            SetProperty(ref _plcAlarm, value);
            UpdateSystemStatus();
        }
    }
    private bool _plcAlarm;

    /// <summary>
    /// PLC備便。
    /// </summary>
    public bool PlcReady
    {
        get { return _plcReady; }
        set
        {
            SetProperty(ref _plcReady, value);
            UpdateSystemStatus();
        }
    }
    private bool _plcReady;

    /// <summary>
    /// PLC已準備好且在靜止狀態。
    /// </summary>
    public bool PlcStabilized
    {
        get { return _plcStabilized; }
        set
        {
            SetProperty(ref _plcStabilized, value);
            UpdateSystemStatus();
        }
    }
    private bool _plcStabilized;

    /// <summary>
    /// PLC已準備好且在靜止狀態(非自動模式)。
    /// </summary>
    public bool PlcStabilizedExceptAutoMode
    {
        get { return _plcStabilizedExceptAutoMode; }
        set
        {
            SetProperty(ref _plcStabilizedExceptAutoMode, value);
            UpdateSystemStatus();
        }
    }
    private bool _plcStabilizedExceptAutoMode;

    /// <summary>
    /// WFS量測機備便。
    /// </summary>
    public bool WfsReady
    {
        get { return _wfsReady; }
        set
        {
            SetProperty(ref _wfsReady, value);
            UpdateSystemStatus();
        }
    }
    private bool _wfsReady;

    /// <summary>
    /// 警報燈 紅。
    /// </summary>
    public bool StackLight_Red
    {
        get { return _stackLight_Red; }
        set { SetProperty(ref _stackLight_Red, value); }
    }
    private bool _stackLight_Red;

    /// <summary>
    /// 警報燈 黃。
    /// </summary>
    public bool StackLight_Yellow
    {
        get { return _stackLight_Yellow; }
        set { SetProperty(ref _stackLight_Yellow, value); }
    }
    private bool _stackLight_Yellow;

    /// <summary>
    /// 警報燈 綠。
    /// </summary>
    public bool StackLight_Green
    {
        get { return _stackLight_Green; }
        set { SetProperty(ref _stackLight_Green, value); }
    }
    private bool _stackLight_Green;
}
