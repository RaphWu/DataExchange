﻿namespace Glorytek.WFSCore.Models.Stage;

/// <summary>
/// Stage資料庫。
/// </summary>
internal class DB_Stage
{
    internal const string TableName_Stage = "Stage";
    internal const string CreateTableSQL_Stage = @"CREATE TABLE IF NOT EXISTS [Stage](
[Id] INTEGER NOT NULL,
[CoorX] DOUBLE DEFAULT (0.0),
[CoorY] DOUBLE DEFAULT (0.0),
[CoorZ] DOUBLE DEFAULT (0.0),
[ZOffset] DOUBLE DEFAULT (0.0),
[SpeedRateWhenDown] INTEGER DEFAULT 20,
[SpeedRateWhenUp] INTEGER DEFAULT 20,
[VisionId] INTEGER DEFAULT 1);";
}
