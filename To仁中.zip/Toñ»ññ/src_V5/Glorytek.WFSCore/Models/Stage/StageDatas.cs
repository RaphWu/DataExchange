﻿using System;
using System.Collections.Generic;

namespace Glorytek.WFSCore.Models.Stage;

/// <summary>
/// Stage繫結用資料。
/// </summary>
public class StageDatas
{
    private StageDatas() { }
    private static readonly Lazy<StageDatas> _instance = new(() => new StageDatas());
    public static StageDatas Instance => _instance.Value;

    /// <summary>
    /// 所有Stage資料。
    /// </summary>
    public List<StageDefine> Stages { get; set; } = new List<StageDefine>();
}
