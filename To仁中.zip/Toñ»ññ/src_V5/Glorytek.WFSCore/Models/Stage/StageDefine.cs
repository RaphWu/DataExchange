﻿using Dapper.Contrib.Extensions;
using Prism.Mvvm;

namespace Glorytek.WFSCore.Models.Stage;

/// <summary>
/// Stage資料庫定義。
/// </summary>
[Table(DB_Stage.TableName_Stage)]
public class StageDefine : BindableBase
{
    /// <summary>
    /// Key。
    /// </summary>
    [ExplicitKey]
    public int Id { get; set; }

    /// <summary>
    /// 座標 X。
    /// </summary>
    public double CoorX
    {
        get { return _coorX; }
        set { SetProperty(ref _coorX, value); }
    }
    private double _coorX;

    /// <summary>
    /// 座標 Y。
    /// </summary>
    public double CoorY
    {
        get { return _coorY; }
        set { SetProperty(ref _coorY, value); }
    }
    private double _coorY;

    /// <summary>
    /// 座標 Z。
    /// </summary>
    public double CoorZ
    {
        get { return _coorZ; }
        set { SetProperty(ref _coorZ, value); }
    }
    private double _coorZ;

    /// <summary>
    /// 取放Z Offset。
    /// </summary>
    public double ZOffset
    {
        get { return _zOffset; }
        set { SetProperty(ref _zOffset, value); }
    }
    private double _zOffset;

    /// <summary>
    /// 下降減速。
    /// </summary>
    public short SpeedRateWhenDown
    {
        get { return _speedRateWhenDown; }
        set { SetProperty(ref _speedRateWhenDown, value); }
    }
    private short _speedRateWhenDown;

    /// <summary>
    /// 上升減速。
    /// </summary>
    public short SpeedRateWhenUp
    {
        get { return _speedRateWhenUp; }
        set { SetProperty(ref _speedRateWhenUp, value); }
    }
    private short _speedRateWhenUp;

    /// <summary>
    /// 視覺ID。
    /// </summary>
    public int VisionId
    {
        get { return _visionId; }
        set { SetProperty(ref _visionId, value); }
    }
    private int _visionId;
}
