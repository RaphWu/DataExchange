﻿namespace Glorytek.WFSCore.Models;

/// <summary>
/// Debug測試用。
/// </summary>
public static class DEBUG
{
#if DEBUG
    /// <summary>
    /// 是否運行在DEBUG模式。
    /// </summary>
    public static bool DebugMode => true;

    /// <summary>
    /// 是否未連接網路做測試。
    /// </summary>
    public static bool NoPlcConnected => false;
#else
    public static bool DebugMode => false;
#endif
}
