﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSCore.Constants.WFS;
using Prism.Mvvm;
using System;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 大數據資料庫定義 - 規格。
/// </summary>
[Table(DB_WFS.TableName_Specification)]
public class WfsSpecificationDefine : BindableBase
{
    [Key]
    public int Id { get; set; }

    /// <summary>
    /// 等級。
    /// </summary>
    public int GradeId { get; set; }

    /// <summary>
    /// 顯示順序。
    /// </summary>
    public int OrderNo { get; set; }

    /// <summary>
    /// 關係式ID。
    /// </summary>
    public int RelationId { get; set; }

    /// <summary>
    /// 關係式。
    /// </summary>
    [Computed]
    public InequalityRelationType Relation
    {
        get
        {
            _ = Enum.TryParse(RelationId.ToString(), out InequalityRelationType id);
            return id;
        }
        set
        {
            RelationId = (int)value;
        }
    }

    /// <summary>
    /// 參數名稱ID。
    /// </summary>
    public int DataNameId { get; set; }

    /// <summary>
    /// 參數名稱。
    /// </summary>
    [Computed]
    public string DataName
    {
        get
        {
            return WfsParameters.Instance.DataNameList.Find(x => x.Id == DataNameId).Name;
        }
        set
        {
            DataNameId = WfsParameters.Instance.DataNameList.Find(x => x.Name == value).Id;
        }
    }

    /// <summary>
    /// 一元運算的運算元。
    /// </summary>
    public double Value { get; set; }

    /// <summary>
    /// 二元運算的第1個運算元。
    /// </summary>
    public double Value1 { get; set; }

    /// <summary>
    /// 二元運算的第2個運算元。
    /// </summary>
    public double Value2 { get; set; }

    /// <summary>
    /// 是否為一元運算子。
    /// </summary>
    [Computed]
    public bool UnaryOperator => Relation != InequalityRelationType.Between && Relation != InequalityRelationType.NotBetween;

    /// <summary>
    /// 是否為介於運算子。
    /// </summary>
    [Computed]
    public bool BetweenOperator => Relation == InequalityRelationType.Between;

    /// <summary>
    /// 是否為不介於運算子。
    /// </summary>
    [Computed]
    public bool NotBetweenOperator => Relation == InequalityRelationType.NotBetween;
}
