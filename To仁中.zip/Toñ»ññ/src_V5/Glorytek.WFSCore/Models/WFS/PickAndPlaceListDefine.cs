﻿using Prism.Mvvm;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 轉角度模式，取料至放料的Pallet列表。
/// </summary>
public class PickAndPlaceListDefine : BindableBase
{
    /// <summary>
    /// 取料Pallet ID。
    /// </summary>
    public string PickPalletId
    {
        get { return _pickPalletId; }
        set { SetProperty(ref _pickPalletId, value); }
    }
    private string _pickPalletId;

    /// <summary>
    /// 放料Pallet ID。
    /// </summary>
    public string PlacePalletId
    {
        get { return _placePalletId; }
        set { SetProperty(ref _placePalletId, value); }
    }
    private string _placePalletId;
}
