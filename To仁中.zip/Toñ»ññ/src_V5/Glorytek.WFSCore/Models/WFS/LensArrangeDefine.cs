﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Models.Tray;
using Prism.Mvvm;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 轉角度模式資料庫定義。
/// </summary>
[Table(DB_WFS.TableName_LensArrange)]
public class LensArrangeDefine : BindableBase
{
    /// <summary>
    /// 大托盤定位編號。
    /// </summary>
    [Key]
    public int Id { get; set; }

    /********************
     * 取料Tray
     ********************/
    /// <summary>
    /// 取料Tray。
    /// </summary>
    public bool Pick
    {
        get { return _pick; }
        set { SetProperty(ref _pick, value); }
    }
    private bool _pick;

    /// <summary>
    /// 取料Tray ID。
    /// </summary>
    public int PickTrayId
    {
        get { return _pickTrayId; }
        set
        {
            SetProperty(ref _pickTrayId, value);
            RaisePropertyChanged(nameof(PickTrayName));
        }
    }
    private int _pickTrayId;

    /// <summary>
    /// 取料Tray名稱。
    /// </summary>
    [Computed]
    public string PickTrayName
    {
        get
        {
            var tray = TrayParameters.Instance.TrayList.Find(x => x.Id == PickTrayId);
            return tray != null ? tray.Name : string.Empty;
        }
    }

    /********************
     * 放料Tray
     ********************/
    /// <summary>
    /// 放料Tray。
    /// </summary>
    public bool Place
    {
        get { return _place; }
        set { SetProperty(ref _place, value); }
    }
    private bool _place;

    /// <summary>
    /// 放料Tray ID。
    /// </summary>
    public int PlaceTrayId
    {
        get { return _placeTrayId; }
        set
        {
            SetProperty(ref _placeTrayId, value);
            RaisePropertyChanged(nameof(PlaceTrayName));
        }
    }
    private int _placeTrayId;

    /// <summary>
    /// 放料Tray名稱。
    /// </summary>
    [Computed]
    public string PlaceTrayName
    {
        get
        {
            var tray = TrayParameters.Instance.TrayList.Find(x => x.Id == PlaceTrayId);
            return tray != null ? tray.Name : string.Empty;
        }
    }

    /********************
     * PLC參數
     ********************/
    /// <summary>
    /// 該Tray的功能代碼。
    /// </summary>
    public PlcTrayFunctionType TrayMode
    {
        get { return _trayMode; }
        set { SetProperty(ref _trayMode, value); }
    }
    private PlcTrayFunctionType _trayMode;
}
