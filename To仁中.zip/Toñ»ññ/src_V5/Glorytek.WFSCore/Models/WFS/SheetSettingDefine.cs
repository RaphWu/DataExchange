﻿using Glorytek.WFSCore.Constants.WFS;
using System.Collections.Generic;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 工作表的參數資料。
/// </summary>
public class SheetSettingDefine
{
    /// <summary>
    /// 工作表名稱。
    /// </summary>
    public string SheetName { get; set; }

    /// <summary>
    /// 有效資料的起始格。
    /// </summary>
    public string StartCell { get; set; }

    /// <summary>
    /// 最大Pallet ID編號。
    /// </summary>
    public int PalletPositionId { get; set; }

    /// <summary>
    /// 光學參數列表的名稱索引。
    /// </summary>
    public Dictionary<OpticalParamId, string> OpticalParamNameList { get; set; }
}
