﻿namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 大數據資料定義 - 鏡片來源Tray設定的抽象類。
/// </summary>
public abstract class TraySettingDefine
{
    /// <summary>
    /// Tray ID。
    /// </summary>
    public abstract int TrayId { get; set; }

    /// <summary>
    /// 條碼。
    /// </summary>
    public abstract string Barcode { get; set; }

    /// <summary>
    /// 大托盤定位編號。
    /// </summary>
    public abstract int PalletNo { get; set; }
}
