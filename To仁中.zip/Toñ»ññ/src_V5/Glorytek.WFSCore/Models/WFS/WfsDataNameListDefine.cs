﻿using Dapper.Contrib.Extensions;
using System;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 大數據資料庫定義 - 光學參數列表。
/// </summary>
/// <remarks>目前僅儲存用，未提供修改介面。</remarks>
[Table(DB_WFS.TableName_DataNameList)]
public class WfsDataNameListDefine : IComparable<WfsDataNameListDefine>
{
    /// <summary>
    /// Key。
    /// </summary>
    [Key]
    public int Id { get; set; }

    /// <summary>
    /// 顯示排序大數據資料定義。
    /// </summary>
    public int OrderNo { get; set; }

    /// <summary>
    /// 資料名稱大數據資料定義。
    /// </summary>
    public string Name { get; set; }

    /// <summary>
    /// 自定義排序。
    /// </summary>
    public int CompareTo(WfsDataNameListDefine other)
    {
        return OrderNo.CompareTo(other.OrderNo);
    }
}
