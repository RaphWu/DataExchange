﻿namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// PLC取料後，托盤資料的儲存buffer。
/// </summary>
public class LensQueueDefine
{
    /// <summary>
    /// Pallet編號。
    /// </summary>
    public int PalletId { get; set; }

    /// <summary>
    /// 矩陣點位編號(PLC編號)。
    /// </summary>
    public int PointNo { get; set; }

    /// <summary>
    /// 鏡片編號 (不含無效點的取放料點編號)。
    /// </summary>
    public int LenNumber { get; set; }
}
