﻿using Glorytek.WFSCore.Constants;
using System.IO;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 資料庫定義 - 大數據。
/// </summary>
internal class DB_BigData
{
    /// <summary>
    /// 大數據資料夾。
    /// </summary>
    public static readonly string Directory_BigData = Path.Combine(DBbase.Directory_Base, "BigData");

    /********************
     * 導出Database
     ********************/
    internal const string TableName_LoadTraySetting = "LoadTraySetting";
    internal const string CreateTableSQL_LoadTraySetting = @"CREATE TABLE IF NOT EXISTS [LoadTraySetting](
[TrayId] INTEGER,
[TrayName] NTEXT DEFAULT '',
[Barcode] TEXT,
[PalletNo] INTEGER);";

    internal const string TableName_ProductTraySetting = "ProductTraySetting";
    internal const string CreateTableSQL_ProductTraySetting = @"CREATE TABLE IF NOT EXISTS [ProductTraySetting](
[TrayId] INTEGER,
[TrayName] NTEXT DEFAULT '',
[Barcode] TEXT,
[PalletNo] INTEGER,
[GradeId] INTEGER);";

    internal const string TableName_ReworkTraySetting = "ReworkTraySetting";
    internal const string CreateTableSQL_ReworkTraySetting = @"CREATE TABLE IF NOT EXISTS [ReworkTraySetting](
[TrayId] INTEGER,
[TrayName] NTEXT DEFAULT '',
[Barcode] TEXT,
[PalletNo] INTEGER);";

    internal const string TableName_SpecificationSetting = "SpecificationSetting";
    internal const string CreateTableSQL_SpecificationSetting = @"CREATE TABLE IF NOT EXISTS [SpecificationSetting](
[GradeId] INTEGER NOT NULL,
[GradeName] NTEXT NOT NULL,
[DataName] NTEXT NOT NULL,
[Relation] TEXT NOT NULL,
[Value] DOUBLE,
[Value1] DOUBLE,
[Value2] DOUBLE);";

    internal const string TableName_Product = "Product";
    internal const string CreateTableSQL_Product = @"CREATE TABLE IF NOT EXISTS [Product](
[LotNumber] TEXT NOT NULL,
[GradeId] INTEGER NOT NULL,
[Barcode] TEXT,
[Time] DATETIME,
[TrayId] INTEGER,
[X] INTEGER,
[Y] INTEGER,
[SourceTrayId] INTEGER,
[SourceX] INTEGER,
[SourceY] INTEGER,
[Decenter] DOUBLE,
[Angle] DOUBLE);";

    internal const string TableName_Rework = "Rework";
    internal const string CreateTableSQL_Rework = @"CREATE TABLE IF NOT EXISTS [Rework](
[LotNumber] TEXT NOT NULL,
[Time] DATETIME,
[Barcode] TEXT,
[TrayId] INTEGER,
[X] INTEGER,
[Y] INTEGER,
[SourceTrayId] INTEGER,
[SourceX] INTEGER,
[SourceY] INTEGER,
[Decenter] DOUBLE,
[Angle] DOUBLE);";
}
