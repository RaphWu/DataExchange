﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSCore.Models.Tray;
using Prism.Mvvm;
using System;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 連線模式及分檢模式的資料庫定義。
/// </summary>
[Table(DB_WFS.TableName_LensSorting)]
public class LensSortingDefine : BindableBase
{
    /// <summary>
    /// 大托盤定位編號。
    /// </summary>
    [ExplicitKey] // 因為此資料庫要複製到量測資料庫，ID不能被SQLite重排，故不使用[Key]。
    public int Id { get; set; }

    /********************
     * Tray資訊
     ********************/
    /// <summary>
    /// Tray功能分類ID。
    /// </summary>
    public int FunctionId
    {
        get { return _functionId; }
        set
        {
            SetProperty(ref _functionId, value);
            RaisePropertyChanged(nameof(TraySelectorVisibility));
            RaisePropertyChanged(nameof(GradeSelectorVisibility));
        }
    }
    private int _functionId;

    /// <summary>
    /// Tray功能分類。
    /// </summary>
    [Computed]
    public TrayFunctionType FunctionName
    {
        get
        {
            _ = Enum.TryParse(FunctionId.ToString(), out TrayFunctionType id);
            return id;
        }
        set
        {
            FunctionId = (int)value;
            RaisePropertyChanged();
        }
    }

    /********************
     * Barcode
     ********************/
    /// <summary>
    /// 條碼。
    /// </summary>
    public string Barcode
    {
        get { return _barcode; }
        set { SetProperty(ref _barcode, value); }
    }
    private string _barcode;

    /********************
     * ComboBox顯示判斷
     ********************/
    /// <summary>
    /// 此Pallet是否需要Tray資料。
    /// </summary>
    [Computed]
    public bool TraySelectorVisibility => FunctionName != TrayFunctionType.Unused;

    /// <summary>
    /// 此Pallet是否需要規格資料。
    /// </summary>
    [Computed]
    public bool GradeSelectorVisibility => FunctionName == TrayFunctionType.Classified;

    /********************
     * Tray
     ********************/
    /// <summary>
    /// 安裝在此 Pallet 的 Tray ID。
    /// </summary>
    public int TrayId
    {
        get { return _trayId; }
        set
        {
            SetProperty(ref _trayId, value);
            RaisePropertyChanged(nameof(TrayName));
        }
    }
    private int _trayId;

    /// <summary>
    /// 安裝在此 Pallet 的 Tray名稱。
    /// </summary>
    [Computed]
    public string TrayName
    {
        get
        {
            var tray = TrayParameters.Instance.TrayList.Find(x => x.Id == TrayId);
            return tray != null ? tray.Name : string.Empty;
        }
    }

    /********************
     * WFS規格資訊
     ********************/
    /// <summary>
    /// 規格ID。
    /// </summary>
    public int GradeId
    {
        get { return _gradeId; }
        set
        {
            SetProperty(ref _gradeId, value);
            RaisePropertyChanged(nameof(GradeName));
        }
    }
    private int _gradeId;

    /// <summary>
    /// 規格名稱。
    /// </summary>
    [Computed]
    public string GradeName
    {
        get
        {
            var grade = WfsParameters.Instance.GradeList.Find(x => x.Id == GradeId);
            return grade != null ? grade.Name : string.Empty;
        }
    }

    /********************
     * PLC參數
     ********************/
    /// <summary>
    /// PLC的Tray功能代碼。
    /// </summary>
    public PlcTrayFunctionType TrayMode
    {
        get { return _trayMode; }
        set { SetProperty(ref _trayMode, value); }
    }
    private PlcTrayFunctionType _trayMode;
}
