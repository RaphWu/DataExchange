﻿using Glorytek.WFSCore.Constants.Tray;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using System;
using System.Collections.Generic;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// WFS參數資料。
/// </summary>
public sealed class WfsParameters
{
    private WfsParameters() { }
    private static readonly Lazy<WfsParameters> _instance = new(() => new WfsParameters());
    public static WfsParameters Instance => _instance.Value;

    /// <summary>
    /// 參數名稱列表。
    /// </summary>
    internal List<WfsDataNameListDefine> DataNameList { get; set; }

    /// <summary>
    /// 等級列表。
    /// </summary>
    internal List<WfsGradeDefine> GradeList { get; set; }

    /// <summary>
    /// 規格列表。
    /// </summary>
    internal List<WfsSpecificationDefine> SpecificationList { get; set; }

    /// <summary>
    /// 作業判斷的等級列表。
    /// </summary>
    internal List<int> JudgementLists { get; set; }

    /// <summary>
    /// WFS規格等級清單。
    /// </summary>
    internal Dictionary<int, string> GradeSelector { get; set; } = new Dictionary<int, string>();

    /// <summary>
    /// WFS規格等級清單(含未使用)。
    /// </summary>
    internal Dictionary<int, string> GradeSelectorIncludeUnused { get; set; } = new Dictionary<int, string>();

    /********************
     * Pallet - 連線模式/分檢模式
     ********************/
    /// <summary>
    /// 連線模式及分檢模式的Pallet排列。
    /// </summary>
    public List<LensSortingDefine> LensSortingList { get; set; }

    /// <summary>
    /// 轉角度模式的Pallet排列。
    /// </summary>
    public List<LensArrangeDefine> LensArrangeList { get; set; }

    /********************
     * Tray List
     ********************/
    /// <summary>
    /// 入料Tray列表。
    /// </summary>
    public Dictionary<int, string> FeederTrayList { get; set; }
    /// <summary>
    /// 收料Tray列表。
    /// </summary>
    public Dictionary<int, string> ClassifiedTrayList { get; set; }
    /// <summary>
    /// 重工Tray列表。
    /// </summary>
    public Dictionary<int, string> ReworkTrayList { get; set; }
    /// <summary>
    /// 不使用Tray列表。
    /// </summary>
    public Dictionary<int, string> UnusedTrayList { get; set; }

    /// <summary>
    /// 各Pallet的PLC Tray功能代碼。
    /// </summary>
    public PlcTrayFunctionType[] PalletMode { get; set; } = new PlcTrayFunctionType[24];

    /// <summary>
    /// 目前批號。
    /// </summary>
    public string CurrentLotNumber { get; set; }

    /// <summary>
    /// 上一個批號。
    /// </summary>
    public string LastLotNumber { get; set; }

    /********************
     * Pallet - 轉角度模式
     ********************/

    /********************
     * 分檢模式 - EXCEL
     ********************/
    /// <summary>
    /// 從EXCEL檔讀取的WFS量測數據。
    /// </summary>
    public List<MeasuringMachineDefine> ExcelDatas { get; set; }

    /// <summary>
    /// 讀入的EXCEL檔中，每個工作表的參數資料。
    /// </summary>
    public List<SheetSettingDefine> SheetSetting { get; set; }

    /// <summary>
    /// 啟始鏡片編號 與 取料流水號 的差距值。
    /// </summary>
    public int DiffLensNumber { get; set; }

    /// <summary>
    /// EXCEL鏡片編號 與 取料流水號 的差距值。
    /// </summary>
    public int DiffExcelLensNumber { get; set; }

    /// <summary>
    /// EXCEL數據抓取起始Row位址。
    /// </summary>
    public int StartPositionOfExcel { get; set; } = 3;
}
