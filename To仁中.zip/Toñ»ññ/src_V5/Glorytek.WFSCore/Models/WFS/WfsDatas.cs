﻿using Glorytek.WFSCore.Models.Tray;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SQLite;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// WFS資料。
/// </summary>
public class WfsDatas : BindableBase
{
    /********************
     * Singleton & INotifyPropertyChanged
     ********************/
    private WfsDatas() { }
    private static readonly Lazy<WfsDatas> _instance = new(() => new WfsDatas());
    public static WfsDatas Instance => _instance.Value;

    /// <summary>
    /// WFS是否已連線。
    /// </summary>
    public bool Online
    {
        get { return _online; }
        set { SetProperty(ref _online, value); }
    }
    private bool _online;

    /// <summary>
    /// PLC取料後，托盤資料的儲存buffer。
    /// </summary>
    public Queue<LensQueueDefine> LensQueue
    {
        get { return _lensQueue; }
        set { SetProperty(ref _lensQueue, value); }
    }
    private Queue<LensQueueDefine> _lensQueue = new Queue<LensQueueDefine>();

    /********************
     * 
     ********************/
    /// <summary>
    /// 轉角度模式，取料至放料的Pallet列表。
    /// </summary>
    public ObservableCollection<PickAndPlaceListDefine> PickAndPlaceList
    {
        get { return _pickAndPlaceList; }
        set { SetProperty(ref _pickAndPlaceList, value); }
    }
    private ObservableCollection<PickAndPlaceListDefine> _pickAndPlaceList;

    /********************
     * database
     ********************/
    /// <summary>
    /// 目前量測檔名稱。
    /// </summary>
    public string CurrentMeasurementDataFileName { get; set; } = string.Empty;

    /// <summary>
    /// 目前量測檔的SQLite連接。
    /// </summary>
    public SQLiteConnection ConnMeasurementData { get; set; } = null;

    /********************
     * 設定資料
     ********************/
    /// <summary>
    /// Tray設定。
    /// </summary>
    public List<TrayDefine> LotTrayList { get; set; }

    /// <summary>
    /// 所有點位座標。
    /// </summary>
    public List<TrayProfileDefine> LotProfileList { get; set; }

    /// <summary>
    /// 連線/分檢Pallet排列。
    /// </summary>
    public List<LensSortingDefine> LotPalletSortingList { get; set; }

    /// <summary>
    /// 參數名稱列表。
    /// </summary>
    public List<WfsDataNameListDefine> LotDataNameList { get; set; }

    /// <summary>
    /// 等級列表。
    /// </summary>
    public List<WfsGradeDefine> LotGradeList { get; set; }

    /// <summary>
    /// 規格列表。
    /// </summary>
    public List<WfsSpecificationDefine> LotSpecificationList { get; set; }

    /********************
     * 量測資料
     ********************/
    /// <summary>
    /// 量測資料檔案列表。
    /// </summary>
    public List<string> MeasurementDataFileList
    {
        get { return _measurementDataFileList; }
        set { SetProperty(ref _measurementDataFileList, value); }
    }
    private List<string> _measurementDataFileList = new();

    /// <summary>
    /// 目前量測中的量測紀錄。
    /// </summary>
    public List<MeasurementDataDefine> MeasurementDataList { get; set; }

    /********************
     * 
     ********************/
    /// <summary>
    /// 不執行規格判定。(暫不使用)
    /// </summary>
    public bool DoNotCheckSpecification
    {
        get { return _doNotCheckSpecification; }
        set { SetProperty(ref _doNotCheckSpecification, value); }
    }
    private bool _doNotCheckSpecification;
}
