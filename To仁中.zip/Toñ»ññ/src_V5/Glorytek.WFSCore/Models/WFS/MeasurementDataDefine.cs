﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSExternal.WfsMeasuringMachine;
using System;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 量測數據的資料庫定義。
/// </summary>
[Table(DB_WFS.TableName_MeasurementData)]
public class MeasurementDataDefine : MeasuringMachineDefine
{
    /// <summary>
    /// Key。
    /// </summary>
    [Key]
    public int Id { get; set; }

    /// <summary>
    /// 量測時間。
    /// </summary>
    public DateTime Time { get; set; }

    /// <summary>
    /// 量測批號。
    /// </summary>
    public string LotNumber { get; set; }

    /********************
     * 來源Tray
     * 大托盤定位/Tray品種ID/Tray名稱/取料點位
     ********************/
    /// <summary>
    /// 來源Pallet編號。
    /// </summary>
    public int SourcePalletNo { get; set; }

    /// <summary>
    /// 來源Tray ID。
    /// </summary>
    public int SourceTrayId { get; set; }

    /// <summary>
    /// 來源Tray名稱。
    /// </summary>
    public string SourceTrayName { get; set; }

    /// <summary>
    /// 來源Tray的取放料點位。
    /// </summary>
    public int SourcePointNo { get; set; }

    /********************
     * 分料/重工Tray
     * 大托盤定位/Tray品種ID/Tray名稱/放料點位
     ********************/
    /// <summary>
    /// 目標Pallet編號。
    /// </summary>
    public int TargetPalletNo { get; set; }

    /// <summary>
    /// 目標Tray ID。
    /// </summary>
    public int TargetTrayId { get; set; }

    /// <summary>
    /// 目標Tray名稱。
    /// </summary>
    public string TargetTrayName { get; set; }

    /// <summary>
    /// 目標Tray的取放料點位。
    /// </summary>
    public int TargetPointNo { get; set; }

    /********************
     * 判定資料
     * 判定結果/判定結果顯示文字
     * 分頪規格/規格名稱
     ********************/
    /// <summary>
    /// 規格判定。true: 合格；false: 不合格。
    /// </summary>
    public bool Judgement { get; set; }

    /// <summary>
    /// 規格判定的顯示訊息。
    /// </summary>
    [Computed]
    public string JudgementText
    {
        get { return Judgement ? "Ok" : "NG"; }
        set { Judgement = value == "Ok"; }
    }

    /// <summary>
    /// 判定的規格ID。
    /// </summary>
    public int Grade { get; set; }

    /// <summary>
    /// 判定的規格名稱。
    /// </summary>
    public string GradeName { get; set; }
}
