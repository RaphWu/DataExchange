﻿namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 資料庫定義 - WFS量測。
/// </summary>
internal class DB_WFS
{
    /// <summary>
    /// 量測數據資料夾。
    /// </summary>
    public const string Directory_MeasurementData = "MeasurementData";

    internal const string TableName_DataNameList = "WfsDataNameList";
    internal const string CreateTableSQL_DataNameList = @"CREATE TABLE IF NOT EXISTS [WfsDataNameList](
[Id] INTEGER PRIMARY KEY,
[OrderNo] INTEGER,
[Name] TEXT);";

    internal const string TableName_Grade = "WfsGrade";
    internal const string CreateTableSQL_Grade = @"CREATE TABLE IF NOT EXISTS [WfsGrade](
[Id] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE,
[OrderNo] INTEGER,
[Name] TEXT UNIQUE);";

    internal const string TableName_Specification = "WfsSpecification";
    internal const string CreateTableSQL_Specification = @"CREATE TABLE IF NOT EXISTS [WfsSpecification](
[Id] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE,
[GradeId] INTEGER,
[OrderNo] INTEGER,
[DataNameId] INTEGER DEFAULT 1,
[RelationId] INTEGER DEFAULT 1,
[Value] DOUBLE DEFAULT (0.0),
[Value1] DOUBLE DEFAULT (0.0),
[Value2] DOUBLE DEFAULT (0.0));";

    internal const string TableName_LensSorting = "LensSorting";
    internal const string CreateTableSQL_LensSorting = @"CREATE TABLE IF NOT EXISTS [LensSorting](
[Id] INTEGER PRIMARY KEY ASC DEFAULT 1,
[FunctionId] INTEGER DEFAULT 0,
[Barcode] TEXT DEFAULT '',
[TrayId] INTEGER DEFAULT (- 1),
[GradeId] INTEGER DEFAULT (- 1),
[TrayMode] INTEGER DEFAULT 0);";

    internal const string TableName_LensArrange = "LensArrange";
    internal const string CreateTableSQL_LensArrange = @"CREATE TABLE IF NOT EXISTS [LensArrange](
[Id] INTEGER PRIMARY KEY ASC DEFAULT 1,
[Pick] BOOLEAN DEFAULT False,
[PickTrayId] INTEGER DEFAULT (- 1),
[Place] BOOLEAN DEFAULT False,
[PlaceTrayId] INTEGER DEFAULT (- 1),
[TrayMode] INTEGER DEFAULT 0);";

    internal const string TableName_MeasurementData = "MeasurementData";
    internal const string CreateTableSQL_MeasurementData = @"CREATE TABLE IF NOT EXISTS [MeasurementData](
[Time] DATETIME,
[LotNumber] TEXT,
[LensNumber] INTEGER,
[SourcePalletNo] INTEGER,
[SourcePointNo] INTEGER,
[SourceTrayId] INTEGER,
[SourceTrayName] TEXT,
[TargetPalletNo] INTEGER,
[TargetPointNo] INTEGER,
[TargetTrayId] INTEGER,
[TargetTrayName] TEXT,
[Judgement] BOOLEAN DEFAULT False,
[Grade] INTEGER DEFAULT (- 1),
[GradeName] TEXT,
[Angle] DOUBLE DEFAULT (0.0),
[DecenterX] DOUBLE DEFAULT (0.0),
[DecenterY] DOUBLE DEFAULT (0.0),
[Decenter] DOUBLE DEFAULT (0.0),
[Coma] DOUBLE DEFAULT (0.0),
[Astigmatism] DOUBLE DEFAULT (0.0),
[Spherical] DOUBLE DEFAULT (0.0),
[Trefoil] DOUBLE DEFAULT (0.0));";
}
