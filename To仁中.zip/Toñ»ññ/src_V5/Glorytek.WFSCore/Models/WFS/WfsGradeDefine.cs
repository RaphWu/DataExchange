﻿using Dapper.Contrib.Extensions;
using Prism.Mvvm;

namespace Glorytek.WFSCore.Models.WFS;

/// <summary>
/// 大數據資料庫定義 - 規格等級。
/// </summary>
[Table(DB_WFS.TableName_Grade)]
public class WfsGradeDefine : BindableBase
{
    /// <summary>
    /// Key。
    /// </summary>
    [ExplicitKey]
    public int Id { get; set; }

    /// <summary>
    /// 顯示順序。
    /// </summary>
    public int OrderNo { get; set; }

    /// <summary>
    /// 規格等級。
    /// </summary>
    public string Name { get; set; }
}
