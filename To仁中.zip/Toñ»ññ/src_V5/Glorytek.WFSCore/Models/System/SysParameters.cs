﻿using System;

namespace Glorytek.WFSCore.Models.System;

/// <summary>
/// 系統參數。
/// </summary>
public class SysParameters
{
    /********************
     * Singleton
     ********************/
    private SysParameters() { }
    private static readonly Lazy<SysParameters> _instance = new(() => new SysParameters());
    public static SysParameters Instance => _instance.Value;

    /********************
     * Content
     ********************/
    /// <summary>
    /// 軟體系統參數。
    /// </summary>
    public SystemSettingDefine SystemSetting { get; set; } = new SystemSettingDefine();

    /// <summary>
    /// 機台參數。
    /// </summary>
    public MachineDefine Machine { get; set; } = new MachineDefine();
}
