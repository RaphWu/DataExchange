﻿namespace Glorytek.WFSCore.Models.System;

/// <summary>
/// System資料庫定義。
/// </summary>
internal class DB_System
{
    // 系統設定
    internal const string TableName_SystemSetting = "SystemSetting";
    internal const string CreateTableSQL_SystemSetting = @"CREATE TABLE IF NOT EXISTS [SystemSetting](
[Id] INTEGER DEFAULT 1,
[MachineName] TEXT,
[AppThemeId] INTEGER DEFAULT 0,
[AllowBarcodeCheck] BOOLEAN DEFAULT True,
[MachineResetTime] DATETIME);";

    //        // 硬體
    //        internal const string TableName_Machine = "Machine";
    //        internal const string CreateTableSQL_Machine = @"CREATE TABLE IF NOT EXISTS [Machine](
    //[Id] INTEGER PRIMARY KEY ASC NOT NULL UNIQUE,
    //[DatumPointX] DOUBLE DEFAULT (0.0),
    //[DatumPointY] DOUBLE DEFAULT (0.0),
    //[DatumPointZ] DOUBLE DEFAULT (0.0),
    //[DatumPointVisionId] INTEGER DEFAULT 0,
    //[RAxisZeroDegreeCorrection] DOUBLE DEFAULT (0.0),
    //[SafetyHeight] DOUBLE DEFAULT (0.0),
    //[ClayTableX] DOUBLE DEFAULT (0.0),
    //[ClayTableY] DOUBLE DEFAULT (0.0),
    //[ClayTableZ] DOUBLE DEFAULT (0.0),
    //[ClayTableVisionId] INTEGER DEFAULT 0,
    //[NozzleStampX] DOUBLE DEFAULT (0.0),
    //[NozzleStampY] DOUBLE DEFAULT (0.0),
    //[NozzleStampZ] DOUBLE DEFAULT (0.0),
    //[NozzleStampR] DOUBLE DEFAULT (0.0),
    //[DistanceFromNozzleToCameraX] DOUBLE DEFAULT (0.0),
    //[DistanceFromNozzleToCameraY] DOUBLE DEFAULT (0.0),
    //[DisplacementX] DOUBLE DEFAULT (0.0),
    //[DisplacementY] DOUBLE DEFAULT (0.0),
    //[DisplacementZ] DOUBLE DEFAULT (0.0),
    //[HeightCorrection] DOUBLE DEFAULT (0.0),
    //[LastMeasureHeight] DOUBLE DEFAULT (0.0)) WITHOUT ROWID;";
}
