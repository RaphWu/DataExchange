﻿using Prism.Mvvm;

namespace Glorytek.WFSCore.Models.System;

//#pragma warning disable CS0659 // 類型會覆寫 Object.Equals(object o)，但不會覆寫 Object.GetHashCode()

/// <summary>
/// 機台參數定義。
/// </summary>
/// <remarks>這裡的參數直接儲存在PLC內。</remarks>
public class MachineDefine : BindableBase
{
    /********************
     * 機台基準點
     ********************/
    /// <summary>
    /// 機台基準點 X (絕對值)。
    /// </summary>
    public double DatumPointX
    {
        get { return _datumPointX; }
        set { SetProperty(ref _datumPointX, value); }
    }
    private double _datumPointX;

    /// <summary>
    /// 機台基準點 Y (絕對值)。
    /// </summary>
    public double DatumPointY
    {
        get { return _datumPointY; }
        set { SetProperty(ref _datumPointY, value); }
    }
    private double _datumPointY;

    /// <summary>
    /// 機台基準點 Z (絕對值)。
    /// </summary>
    public double DatumPointZ
    {
        get { return _datumPointZ; }
        set { SetProperty(ref _datumPointZ, value); }
    }
    private double _datumPointZ;

    /// <summary>
    /// 機台基準點 相機高度 (PLC預留功能，目前未使用)。
    /// </summary>
    public double DatumPointCameraZ
    {
        get { return _datumPointCameraZ; }
        set { SetProperty(ref _datumPointCameraZ, value); }
    }
    private double _datumPointCameraZ;

    /// <summary>
    /// 機台基準點畫像ID。
    /// </summary>
    public short DatumPointVisionId
    {
        get { return _datumPointVisionId; }
        set { SetProperty(ref _datumPointVisionId, value); }
    }
    private short _datumPointVisionId;

    /// <summary>
    /// R軸0度補償 (絕對值)。
    /// </summary>
    public double RAxisZeroDegreeCorrection
    {
        get { return _rAxisZeroDegreeCorrection; }
        set { SetProperty(ref _rAxisZeroDegreeCorrection, value); }
    }
    private double _rAxisZeroDegreeCorrection;

    /// <summary>
    /// 吸嘴到相機的距離 X。
    /// </summary>
    public double DistanceFromNozzleToCameraX
    {
        get { return _distanceFromNozzleToCameraX; }
        set { SetProperty(ref _distanceFromNozzleToCameraX, value); }
    }
    private double _distanceFromNozzleToCameraX;

    /// <summary>
    /// 吸嘴到相機的距離 Y。
    /// </summary>
    public double DistanceFromNozzleToCameraY
    {
        get { return _distanceFromNozzleToCameraY; }
        set { SetProperty(ref _distanceFromNozzleToCameraY, value); }
    }
    private double _distanceFromNozzleToCameraY;

    /********************
     * 安全位置
     ********************/
    /// <summary>
    /// 安全位置 X (絕對值)。
    /// </summary>
    public double SafetyX
    {
        get { return _safetyX; }
        set { SetProperty(ref _safetyX, value); }
    }
    private double _safetyX;

    /// <summary>
    /// 安全位置 Y (絕對值)。
    /// </summary>
    public double SafetyY
    {
        get { return _safetyY; }
        set { SetProperty(ref _safetyY, value); }
    }
    private double _safetyY;

    /// <summary>
    /// 安全高度 (絕對值)。
    /// </summary>
    public double SafetyHeight
    {
        get { return _safetyHeight; }
        set { SetProperty(ref _safetyHeight, value); }
    }
    private double _safetyHeight;

    /********************
     * 黏土座基準點
     ********************/
    /// <summary>
    /// 黏土座基準點 X (相機)。
    /// </summary>
    public double ClayTableX
    {
        get { return _clayTableX; }
        set { SetProperty(ref _clayTableX, value); }
    }
    private double _clayTableX;

    /// <summary>
    /// 黏土座基準點 Y (相機)。
    /// </summary>
    public double ClayTableY
    {
        get { return _clayTableY; }
        set { SetProperty(ref _clayTableY, value); }
    }
    private double _clayTableY;

    /// <summary>
    /// 黏土座基準點 Z (相機)(目前相機為固定高度)。
    /// </summary>
    public double ClayTableZ
    {
        get { return _clayTableZ; }
        set { SetProperty(ref _clayTableZ, value); }
    }
    private double _clayTableZ;

    /// <summary>
    /// 黏土座基準點 X (顯示用)。
    /// </summary> 
    public double ClayTableX_Display
    {
        get { return _clayTableX_Display; }
        set { SetProperty(ref _clayTableX_Display, value); }
    }
    private double _clayTableX_Display;

    /// <summary>
    /// 黏土座基準點 Y (顯示用)。
    /// </summary> 
    public double ClayTableY_Display
    {
        get { return _clayTableY_Display; }
        set { SetProperty(ref _clayTableY_Display, value); }
    }
    private double _clayTableY_Display;

    /// <summary>
    /// 黏土座基準點 Z (顯示用)。
    /// </summary> 
    public double ClayTableZ_Display
    {
        get { return _clayTableZ_Display; }
        set { SetProperty(ref _clayTableZ_Display, value); }
    }
    private double _clayTableZ_Display;

    /// <summary>
    /// 黏土座基準點畫像ID。
    /// </summary>
    public short ClayTableVisionId
    {
        get { return _clayTableVisionId; }
        set { SetProperty(ref _clayTableVisionId, value); }
    }
    private short _clayTableVisionId;

    /********************
     * 黏土座吸嘴壓印
     ********************/
    /// <summary>
    /// 黏土座吸嘴壓印 X (絕對值，僅用於計算相機-吸嘴距離用)。
    /// </summary>
    public double NozzleStampX
    {
        get { return _nozzleStampX; }
        set { SetProperty(ref _nozzleStampX, value); }
    }
    private double _nozzleStampX;

    /// <summary>
    /// 黏土座吸嘴壓印 Y (絕對值，僅用於計算相機-吸嘴距離用)。
    /// </summary>
    public double NozzleStampY
    {
        get { return _nozzleStampY; }
        set { SetProperty(ref _nozzleStampY, value); }
    }
    private double _nozzleStampY;

    /// <summary>
    /// 黏土座吸嘴壓印 Z (絕對值)。
    /// </summary>
    public double NozzleStampZ
    {
        get { return _nozzleStampZ; }
        set { SetProperty(ref _nozzleStampZ, value); }
    }
    private double _nozzleStampZ;

    /// <summary>
    /// 黏土座吸嘴壓印 R (絕對值)。
    /// </summary>
    public double NozzleStampR
    {
        get { return _nozzleStampR; }
        set { SetProperty(ref _nozzleStampR, value); }
    }
    private double _nozzleStampR;

    /// <summary>
    /// 黏土座吸嘴壓印 X (絕對值，僅用於計算相機-吸嘴距離用)。
    /// </summary>
    public double NozzleStampX_Display
    {
        get { return _nozzleStampX_Display; }
        set { SetProperty(ref _nozzleStampX_Display, value); }
    }
    private double _nozzleStampX_Display;

    /// <summary>
    /// 黏土座吸嘴壓印 Y (絕對值，僅用於計算相機-吸嘴距離用)。
    /// </summary>
    public double NozzleStampY_Display
    {
        get { return _nozzleStampY_Display; }
        set { SetProperty(ref _nozzleStampY_Display, value); }
    }
    private double _nozzleStampY_Display;

    /// <summary>
    /// 黏土座吸嘴壓印 Z (絕對值)。
    /// </summary>
    public double NozzleStampZ_Display
    {
        get { return _nozzleStampZ_Display; }
        set { SetProperty(ref _nozzleStampZ_Display, value); }
    }
    private double _nozzleStampZ_Display;

    /********************
     * 測高用位移計
     ********************/
    /// <summary>
    /// 高度補正值。
    /// </summary>
    public double HeightCorrection
    {
        get { return _heightCorrection; }
        set { SetProperty(ref _heightCorrection, value); }
    }
    private double _heightCorrection;

    /// <summary>
    /// 上次量測值。
    /// </summary>
    public double LastMeasureHeight
    {
        get { return _lastMeasureHeight; }
        set { SetProperty(ref _lastMeasureHeight, value); }
    }
    private double _lastMeasureHeight;

    /// <summary>
    /// 測高用位移計 X。
    /// </summary>
    public double DisplacementX
    {
        get { return _displacementX; }
        set { SetProperty(ref _displacementX, value); }
    }
    private double _displacementX;

    /// <summary>
    /// 測高用位移計 Y。
    /// </summary>
    public double DisplacementY
    {
        get { return _displacementY; }
        set { SetProperty(ref _displacementY, value); }
    }
    private double _displacementY;

    /// <summary>
    /// 測高用位移計 Z。
    /// </summary>
    public double DisplacementZ
    {
        get { return _displacementZ; }
        set { SetProperty(ref _displacementZ, value); }
    }
    private double _displacementZ;

    /// <summary>
    /// 測高用位移計 X。
    /// </summary> 
    public double DisplacementX_Display
    {
        get { return _displacementX_Display; }
        set { SetProperty(ref _displacementX_Display, value); }
    }
    private double _displacementX_Display;

    /// <summary>
    /// 測高用位移計 Y。
    /// </summary> 
    public double DisplacementY_Display
    {
        get { return _displacementY_Display; }
        set { SetProperty(ref _displacementY_Display, value); }
    }
    private double _displacementY_Display;

    /// <summary>
    /// 測高用位移計 Z。
    /// </summary>
    public double DisplacementZ_Display
    {
        get { return _displacementZ_Display; }
        set { SetProperty(ref _displacementZ_Display, value); }
    }
    private double _displacementZ_Display;

    /********************
     * A1A2
     ********************/
    ///// <summary>
    ///// 機台基準點畫像ID
    ///// </summary>
    //public short Stage1VisionId
    //{
    //    get { return _stage1VisionId; }
    //    set
    //    {
    //        _stage1VisionId = value;
    //        OnPropertyChanged();
    //    }
    //}
    //private short _stage1VisionId;

    ///// <summary>
    ///// 機台基準點畫像ID
    ///// </summary>
    //public short Stage2VisionId
    //{
    //    get { return _stage2VisionId; }
    //    set
    //    {
    //        _stage2VisionId = value;
    //        OnPropertyChanged();
    //    }
    //}
    //private short _stage2VisionId;

    /// <summary>
    /// Pallet基準點的相機品種ID。
    /// </summary>
    public short PalletDpVisionId
    {
        get { return _palletDpVisionId; }
        set { SetProperty(ref _palletDpVisionId, value); }
    }
    private short _palletDpVisionId;

    /********************
     * 速率
     ********************/
    /// <summary>
    /// 各軸整體速率。
    /// </summary>
    public short OverallSpeed
    {
        get { return _overallSpeed; }
        set { SetProperty(ref _overallSpeed, value); }
    }
    private short _overallSpeed;

    public override bool Equals(object obj)
    {
        return obj is MachineDefine define &&
            DatumPointX == define.DatumPointX &&
            DatumPointY == define.DatumPointY &&
            DatumPointZ == define.DatumPointZ &&
            DatumPointVisionId == define.DatumPointVisionId &&
            RAxisZeroDegreeCorrection == define.RAxisZeroDegreeCorrection &&
            SafetyHeight == define.SafetyHeight &&
            ClayTableX == define.ClayTableX &&
            ClayTableY == define.ClayTableY &&
            ClayTableZ == define.ClayTableZ &&
            ClayTableVisionId == define.ClayTableVisionId &&
            NozzleStampX == define.NozzleStampX &&
            NozzleStampY == define.NozzleStampY &&
            NozzleStampZ == define.NozzleStampZ &&
            HeightCorrection == define.HeightCorrection &&
            LastMeasureHeight == define.LastMeasureHeight &&
            DisplacementX == define.DisplacementX &&
            DisplacementY == define.DisplacementY &&
            DisplacementZ == define.DisplacementZ;
    }
}
