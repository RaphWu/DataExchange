﻿using Dapper.Contrib.Extensions;
using Prism.Mvvm;
using System;

namespace Glorytek.WFSCore.Models.System;

/// <summary>
/// 軟體系統參數的資料庫定義。
/// </summary>
[Table(DB_System.TableName_SystemSetting)]
public class SystemSettingDefine : BindableBase
{
    /// <summary>
    /// Key。
    /// </summary>
    [ExplicitKey]
    public int Id { get; set; }

    /// <summary>
    /// 機台名稱。
    /// </summary>
    public string MachineName { get; set; }

    /********************
     * System
     ********************/
    /// <summary>
    /// 允許條碼檢查。
    /// </summary>
    public bool AllowBarcodeCheck
    {
        get { return _allowBarcodeCheck; }
        set { SetProperty(ref _allowBarcodeCheck, value); }
    }
    private bool _allowBarcodeCheck;

    /********************
     * Time
     ********************/
    /// <summary>
    /// 重置開機時間的日期時間。
    /// </summary>
    public DateTime MachineResetTime { get; set; }
}
