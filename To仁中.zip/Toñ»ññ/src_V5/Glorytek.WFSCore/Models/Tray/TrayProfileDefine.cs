﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSCore.Constants.Tray;
using System;

namespace Glorytek.WFSCore.Models.Tray;

/// <summary>
/// Tray點位資料庫定義。
/// </summary>
[Table(DB_Tray.TableName_Tray_Profile)]
public class TrayProfileDefine
{
    /********************
     * 基本資料
     ********************/
    /// <summary>
    /// SQLite Index。
    /// </summary>
    [Key]
    public int RowId { get; set; }

    /// <summary>
    /// 所屬Tray ID。
    /// </summary>
    public int TrayId { get; set; }

    /// <summary>
    /// 排列方式ID。
    /// </summary>
    public short ArrangementId { get; set; }

    /// <summary>
    /// 排列方式。
    /// </summary>
    [Computed]
    public TrayArrangementType Arrangement
    {
        get
        {
            _ = Enum.TryParse(ArrangementId.ToString(), out TrayArrangementType id);
            return id;
        }
        set
        {
            ArrangementId = (short)value;
        }
    }

    /// <summary>
    /// 點位序號。
    /// </summary>
    public int PointNo { get; set; }

    /// <summary>
    /// 取放點編號。
    /// </summary>
    public int SequenceNo { get; set; }

    /********************
     * 相對於Tray基準點的相對位置
     ********************/
    /// <summary>
    /// 點位實際軸座標X。
    /// </summary>
    public double PositionX { get; set; }

    /// <summary>
    /// 點位實際軸座標Y。
    /// </summary>
    public double PositionY { get; set; }

    /********************
     * 行列座標
     * 目前僅顯示用
     ********************/
    /// <summary>
    /// Row位置。
    /// </summary>
    public int Row { get; set; }

    /// <summary>
    /// Column位置。
    /// </summary>
    public int Column { get; set; }
}
