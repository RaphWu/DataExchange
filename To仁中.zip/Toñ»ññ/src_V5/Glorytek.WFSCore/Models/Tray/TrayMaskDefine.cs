﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSCore.Constants.Tray;
using System;

namespace Glorytek.WFSCore.Models.Tray;

/// <summary>
/// Tray無效點位資料庫定義。
/// </summary>
[Table(DB_Tray.TableName_Tray_Mask)]
public class TrayMaskDefine : IComparable<TrayMaskDefine>
{
    /// <summary>
    /// SQLite Index。
    /// </summary>
    [Key]
    public int RowId { get; set; }

    /// <summary>
    /// 所屬Tray ID。
    /// </summary>
    public int TrayId { get; set; }

    /// <summary>
    /// Mask點位。
    /// </summary>
    public short PointNo { get; set; }

    /// <summary>
    /// 排列方式ID。
    /// </summary>
    public int ArrangementId { get; set; }

    /// <summary>
    /// 排列方式。
    /// </summary>
    [Computed]
    public TrayArrangementType Arrangement
    {
        get
        {
            _ = Enum.TryParse(ArrangementId.ToString(), out TrayArrangementType id);
            return id;
        }
        set
        {
            ArrangementId = (short)value;
        }
    }

    /// <summary>
    /// 排序。
    /// </summary>
    public int CompareTo(TrayMaskDefine other)
    {
        if (TrayId != other.TrayId)
            return TrayId.CompareTo(other.TrayId);
        else if (ArrangementId != other.ArrangementId)
            return ArrangementId.CompareTo(other.ArrangementId);
        else
            return PointNo.CompareTo(other.PointNo);
    }
}
