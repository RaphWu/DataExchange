﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSCore.Constants.Tray;
using Prism.Mvvm;
using System;

namespace Glorytek.WFSCore.Models.Tray;

/// <summary>
/// Tray資料庫定義。
/// </summary>
[Table(DB_Tray.TableName_Tray)]
public class TrayDefine : BindableBase
{
    /********************
     * 基本資料
     ********************/
    [ExplicitKey]
    public int Id { get; set; }

    /// <summary>
    /// 排列順序(顯示用)。
    /// </summary>
    public int OrderNo
    {
        get { return _orderNo; }
        set { SetProperty(ref _orderNo, value); }
    }
    private int _orderNo;

    /// <summary>
    /// Tray名稱 &amp; 註解。
    /// </summary>
    public string Name
    {
        get { return _name; }
        set { SetProperty(ref _name, value); }
    }
    private string _name;

    /// <summary>
    /// 總點位數(不計算Mask)。
    /// </summary>
    public short TotalPoints
    {
        get { return _totalPoints; }
        set { SetProperty(ref _totalPoints, value); }
    }
    private short _totalPoints;

    /// <summary>
    /// 總有效點位數。
    /// </summary>
    public short TotalSequences
    {
        get { return _totalSequences; }
        set { SetProperty(ref _totalSequences, value); }
    }
    private short _totalSequences;

    /// <summary>
    /// 套用視覺的品種ID。
    /// </summary>
    // 此參數只存DB，不存入PLC
    public int VisionId
    {
        get { return _visionId; }
        set { SetProperty(ref _visionId, value); }
    }
    private int _visionId;

    /********************
     * 座標
     ********************/
    /// <summary>
    /// 做教導時，Tray放置的位置。
    /// </summary>
    public int PositionId
    {
        get { return _positionId; }
        set { SetProperty(ref _positionId, value); }
    }
    private int _positionId;

    // 基準點注意: 僅供傳遞用，此值會變動，資料庫也不儲存此值
    // 取用前仍需從Pallet取得最新值
    /// <summary>
    /// TRAY基準點X。
    /// </summary>
    [Computed]
    public double DatumX
    {
        get { return _datumX; }
        set { SetProperty(ref _datumX, value); }
    }
    private double _datumX;

    /// <summary>
    /// TRAY基準點Y。
    /// </summary>
    [Computed]
    public double DatumY
    {
        get { return _datumY; }
        set { SetProperty(ref _datumY, value); }
    }
    private double _datumY;

    /// <summary>
    /// 取料高度。
    /// </summary>
    public double PickHeight
    {
        get { return _pickHeight; }
        set { SetProperty(ref _pickHeight, value); }
    }
    private double _pickHeight;

    /********************
     * 排列
     ********************/
    /// <summary>
    /// 排列方式ID。
    /// </summary>
    public short ArrangementId { get; set; }

    /// <summary>
    /// 排列方式。
    /// </summary>
    [Computed]
    public TrayArrangementType Arrangement
    {
        get
        {
            _ = Enum.TryParse(ArrangementId.ToString(), out TrayArrangementType id);
            return id;
        }
        set
        {
            ArrangementId = (short)value;
        }
    }

    /********************
     * 依序排列
     ********************/
    /// <summary>
    /// 依序排列 - X軸格數。
    /// </summary>
    public short Order_GridNumberX
    {
        get { return _order_GridNumberX; }
        set { SetProperty(ref _order_GridNumberX, value); }
    }
    private short _order_GridNumberX;

    /// <summary>
    /// 依序排列 - Y軸格數。
    /// </summary>
    public short Order_GridNumberY
    {
        get { return _order_GridNumberY; }
        set { SetProperty(ref _order_GridNumberY, value); }
    }
    private short _order_GridNumberY;

    /// <summary>
    /// 依序排列 - 座標點 A X。
    /// </summary>
    public double Order_PositionA_X
    {
        get { return _order_PositionA_X; }
        set { SetProperty(ref _order_PositionA_X, value); }
    }
    private double _order_PositionA_X;

    /// <summary>
    /// 依序排列 - 座標點 A Y。
    /// </summary>
    public double Order_PositionA_Y
    {
        get { return _order_PositionA_Y; }
        set { SetProperty(ref _order_PositionA_Y, value); }
    }
    private double _order_PositionA_Y;

    /// <summary>
    /// 依序排列 - 座標點 B X。
    /// </summary>
    public double Order_PositionB_X
    {
        get { return _Order_PositionB_X; }
        set { SetProperty(ref _Order_PositionB_X, value); }
    }
    private double _Order_PositionB_X;

    /// <summary>
    /// 依序排列 - 座標點 B Y。
    /// </summary>
    public double Order_PositionB_Y
    {
        get { return _order_PositionB_Y; }
        set { SetProperty(ref _order_PositionB_Y, value); }
    }
    private double _order_PositionB_Y;

    /// <summary>
    /// 依序排列 - 座標點 C X。
    /// </summary>
    public double Order_PositionC_X
    {
        get { return _order_PositionC_X; }
        set { SetProperty(ref _order_PositionC_X, value); }
    }
    private double _order_PositionC_X;

    /// <summary>
    /// 依序排列 - 座標點 C Y。
    /// </summary>
    public double Order_PositionC_Y
    {
        get { return _order_PositionC_Y; }
        set { SetProperty(ref _order_PositionC_Y, value); }
    }
    private double _order_PositionC_Y;

    /// <summary>
    /// 依序排列 - 座標點 A偏移格數。
    /// </summary>
    public short Order_OffsetA
    {
        get { return _order_OffsetA; }
        set { SetProperty(ref _order_OffsetA, value); }
    }
    private short _order_OffsetA;

    /// <summary>
    /// 依序排列 - 座標點 B偏移格數。
    /// </summary>
    public short Order_OffsetB
    {
        get { return _order_OffsetB; }
        set { SetProperty(ref _order_OffsetB, value); }
    }
    private short _order_OffsetB;

    /// <summary>
    /// 依序排列 - 座標點 C偏移格數。
    /// </summary>
    public short Order_OffsetC
    {
        get { return _order_OffsetC; }
        set { SetProperty(ref _order_OffsetC, value); }
    }
    private short _order_OffsetC;

    /********************
     * 交錯排列
     ********************/
    /// <summary>
    /// 交錯排列 - X軸格數。
    /// </summary>
    public short Cross_GridNumberX
    {
        get { return _cross_GridNumberX; }
        set { SetProperty(ref _cross_GridNumberX, value); }
    }
    private short _cross_GridNumberX;

    /// <summary>
    /// 交錯排列 - 緦排數。
    /// </summary>
    public short Cross_GridNumberY
    {
        get { return _cross_GridNumberY; }
        set { SetProperty(ref _cross_GridNumberY, value); }
    }
    private short _cross_GridNumberY;

    /// <summary>
    /// 交錯排列 - 座標點 A X。
    /// </summary>
    public double Cross_PositionA_X
    {
        get { return _cross_PositionA_X; }
        set { SetProperty(ref _cross_PositionA_X, value); }
    }
    private double _cross_PositionA_X;

    /// <summary>
    /// 交錯排列 - 座標點 A Y。
    /// </summary>
    public double Cross_PositionA_Y
    {
        get { return _cross_PositionA_Y; }
        set { SetProperty(ref _cross_PositionA_Y, value); }
    }
    private double _cross_PositionA_Y;

    /// <summary>
    /// 交錯排列 - 座標點 B X。
    /// </summary>
    public double Cross_PositionB_X
    {
        get { return _cross_PositionB_X; }
        set { SetProperty(ref _cross_PositionB_X, value); }
    }
    private double _cross_PositionB_X;

    /// <summary>
    /// 交錯排列 - 座標點 B Y。
    /// </summary>
    public double Cross_PositionB_Y
    {
        get { return _cross_PositionB_Y; }
        set { SetProperty(ref _cross_PositionB_Y, value); }
    }
    private double _cross_PositionB_Y;

    /// <summary>
    /// 交錯排列 - 座標點 C X。
    /// </summary>
    public double Cross_PositionC_X
    {
        get { return _cross_PositionC_X; }
        set { SetProperty(ref _cross_PositionC_X, value); }
    }
    private double _cross_PositionC_X;

    /// <summary>
    /// 交錯排列 - 座標點 C Y。
    /// </summary>
    public double Cross_PositionC_Y
    {
        get { return _cross_PositionC_Y; }
        set { SetProperty(ref _cross_PositionC_Y, value); }
    }
    private double _cross_PositionC_Y;

    /// <summary>
    /// 交錯排列 - 座標點 A偏移格數。
    /// </summary>
    public short Cross_OffsetA
    {
        get { return _cross_OffsetA; }
        set { SetProperty(ref _cross_OffsetA, value); }
    }
    private short _cross_OffsetA;

    /// <summary>
    /// 交錯排列 - 座標點 B偏移格數。
    /// </summary>
    public short Cross_OffsetB
    {
        get { return _cross_OffsetB; }
        set { SetProperty(ref _cross_OffsetB, value); }
    }
    private short _cross_OffsetB;

    /// <summary>
    /// 交錯排列 - 座標點 C偏移格數。
    /// </summary>
    public short Cross_OffsetC
    {
        get { return _cross_OffsetC; }
        set { SetProperty(ref _cross_OffsetC, value); }
    }
    private short _cross_OffsetC;
}
