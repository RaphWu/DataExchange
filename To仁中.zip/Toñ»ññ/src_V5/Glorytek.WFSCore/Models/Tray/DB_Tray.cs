﻿namespace Glorytek.WFSCore.Models.Tray;

/// <summary>
/// 資料庫定義 - Tray。
/// </summary>
internal class DB_Tray
{
    internal const string TableName_Tray = "Tray";
    internal const string CreateTableSQL_Tray = @"CREATE TABLE IF NOT EXISTS [Tray](
[Id] INTEGER PRIMARY KEY AUTOINCREMENT,
[OrderNo] INTEGER,
[Name] TEXT,
[TotalPoints] INTEGER DEFAULT 0,
[TotalSequences] INTEGER DEFAULT 1,
[VisionId] INTEGER DEFAULT 1,
[PositionId] INTEGER DEFAULT 24,
[PickHeight] DOUBLE DEFAULT (0.0),
[ArrangementId] INTEGER DEFAULT 0,
[Order_GridNumberX] INTEGER DEFAULT 7,
[Order_GridNumberY] INTEGER DEFAULT 7,
[Order_PositionA_X] DOUBLE DEFAULT (0.0),
[Order_PositionA_Y] DOUBLE DEFAULT (0.0),
[Order_PositionB_X] DOUBLE DEFAULT (0.0),
[Order_PositionB_Y] DOUBLE DEFAULT (0.0),
[Order_PositionC_X] DOUBLE DEFAULT (0.0),
[Order_PositionC_Y] DOUBLE DEFAULT (0.0),
[Order_OffsetA] INTEGER DEFAULT (0.0),
[Order_OffsetB] INTEGER DEFAULT (0.0),
[Order_OffsetC] INTEGER DEFAULT (0.0),
[Cross_GridNumberX] INTEGER DEFAULT 7,
[Cross_GridNumberY] INTEGER DEFAULT 7,
[Cross_PositionA_X] DOUBLE DEFAULT (0.0),
[Cross_PositionA_Y] DOUBLE DEFAULT (0.0),
[Cross_PositionB_X] DOUBLE DEFAULT (0.0),
[Cross_PositionB_Y] DOUBLE DEFAULT (0.0),
[Cross_PositionC_X] DOUBLE DEFAULT (0.0),
[Cross_PositionC_Y] DOUBLE DEFAULT (0.0),
[Cross_OffsetA] INTEGER DEFAULT (0.0),
[Cross_OffsetB] INTEGER DEFAULT (0.0),
[Cross_OffsetC] INTEGER DEFAULT (0.0));";

    internal const string TableName_Tray_Profile = "TrayProfile";
    internal const string CreateTableSQL_Tray_Profile = @"CREATE TABLE IF NOT EXISTS [TrayProfile](
[TrayId] INTEGER NOT NULL,
[ArrangementId] INTEGER,
[PointNo] INTEGER NOT NULL DEFAULT 0,
[SequenceNo] INTEGER DEFAULT 1,
[PositionX] DOUBLE DEFAULT (0.0),
[PositionY] DOUBLE DEFAULT (0.0),
[Row] INTEGER DEFAULT 0,
[Column] INTEGER DEFAULT 0);";

    internal const string TableName_Tray_Mask = "TrayMask";
    internal const string CreateTableSQL_Tray_Mask = @"CREATE TABLE IF NOT EXISTS [TrayMask](
[TrayId] INTEGER,
[PointNo] INTEGER,
[ArrangementId] INTEGER);";

    internal const string TableName_Pallet = "Pallet";
    internal const string CreateTableSQL_Pallet = @"CREATE TABLE IF NOT EXISTS [Pallet](
[Id] INTEGER PRIMARY KEY ASC NOT NULL UNIQUE,
[DatumX] DOUBLE DEFAULT (0.0),
[DatumY] DOUBLE DEFAULT (0.0),
[OffsetX] DOUBLE DEFAULT (0.0),
[OffsetY] DOUBLE DEFAULT (0.0),
[Order_OffsetX] DOUBLE DEFAULT (0.0),
[Order_OffsetY] DOUBLE DEFAULT (0.0),
[Cross_OffsetX] DOUBLE DEFAULT (0.0),
[Cross_OffsetY] DOUBLE DEFAULT (0.0),
[PickHeightOffset] DOUBLE DEFAULT (0.0),
[ZAxis_Pick_Height] INTEGER DEFAULT 0,
[ZAxis_Place_Height] INTEGER DEFAULT 0,
[ZAxis_Pick_SpeedRate] INTEGET DEFAULT 80,
[ZAxis_Place_SpeedRate] INTEGET DEFAULT 80,
[ZAxis_PickDelay_BeforeVacuum] FLOAT DEFAULT 0,
[ZAxis_UpDelay_AfterPick] FLOAT DEFAULT 0,
[ZAxis_Place_VacuumRelief] FLOAT DEFAULT 0,
[ZAxis_UpDelay_AfterPlace] FLOAT DEFAULT 0,
[CurrentPointNo] INTEGER,
[CurrentSequenceNo] INTEGER) WITHOUT ROWID;";
}
