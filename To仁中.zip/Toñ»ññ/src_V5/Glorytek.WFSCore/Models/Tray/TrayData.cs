﻿using Prism.Mvvm;
using System;
using System.Collections.Generic;

namespace Glorytek.WFSCore.Models.Tray;

/// <summary>
/// Tray繫結用資料。
/// </summary>
public class TrayData : BindableBase
{
    private TrayData() { }
    private static readonly Lazy<TrayData> _instance = new(() => new TrayData());
    public static TrayData Instance => _instance.Value;

    /// <summary>
    /// Tray選擇列表。
    /// </summary>
    public Dictionary<int, string> TraySelector
    {
        get { return _traySelector; }
        set { SetProperty(ref _traySelector, value); }
    }
    private Dictionary<int, string> _traySelector = new();

    /// <summary>
    /// Tray選擇列表(含"不使用")。
    /// </summary>
    public Dictionary<int, string> TraySelectorIncludeUnused
    {
        get { return _traySelectorIncludeUnused; }
        set { SetProperty(ref _traySelectorIncludeUnused, value); }
    }
    private Dictionary<int, string> _traySelectorIncludeUnused = new();

    ///********************
    // * Pallet
    // ********************/
    ///// <summary>
    ///// 各Tray目前點位(矩陣點位，非取放點位)。
    ///// </summary>
    //public int[] PointNo
    //{
    //    get { return _pointNo; }
    //    set { SetProperty(ref _pointNo, value); }
    //}
    //private int[] _pointNo = new int[ITray.MaxPalletId];

    ///// <summary>
    ///// 各Tray動作點位。
    ///// </summary>
    //public int[] ActionPointNo
    //{
    //    get { return _actionPointNo; }
    //    set { SetProperty(ref _actionPointNo, value); }
    //}
    //private int[] _actionPointNo = new int[ITray.MaxPalletId];

    ///// <summary>
    ///// 取放點編號。
    ///// </summary>
    //public int[] SequecneNo
    //{
    //    get { return _sequecneNo; }
    //    set { SetProperty(ref _sequecneNo, value); }
    //}
    //private int[] _sequecneNo = new int[ITray.MaxPalletId];
}
