﻿using System;
using System.Collections.Generic;

namespace Glorytek.WFSCore.Models.Tray;

/// <summary>
/// Tray和Pallet參數。
/// </summary>
public sealed class TrayParameters
{
    private TrayParameters() { }
    private static readonly Lazy<TrayParameters> _instance = new(() => new TrayParameters());
    public static TrayParameters Instance => _instance.Value;

    /// <summary>
    /// 所有Tray的基本資料。
    /// </summary>
    public List<TrayDefine> TrayList { get; set; } = new List<TrayDefine>();

    /// <summary>
    /// 所有Tray的每個點位資料。
    /// </summary>
    public List<TrayProfileDefine> ProfileList { get; set; } = new List<TrayProfileDefine>();

    /// <summary>
    /// 所有Tray的全部無效點位資料。
    /// </summary>
    public List<TrayMaskDefine> MaskList { get; set; } = new List<TrayMaskDefine>();

    /// <summary>
    /// 所有Pallet的基本資料。
    /// </summary>
    public List<PalletDefine> PalletList { get; set; } = new List<PalletDefine>();

    /// <summary>
    /// 相機跟隨。
    /// </summary>
    public bool CameraFollow { get; set; } = false;
}
