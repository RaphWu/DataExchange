﻿using Dapper.Contrib.Extensions;
using Glorytek.WFSCore.Constants.Tray;
using Prism.Mvvm;

namespace Glorytek.WFSCore.Models.Tray;

/// <summary>
/// Pallet的資料庫定義。
/// </summary>
[Table(DB_Tray.TableName_Pallet)]
public class PalletDefine : BindableBase
{
    /// <summary>
    /// Pallet定位編號。
    /// </summary>
    [ExplicitKey]
    public int Id { get; set; }

    /// <summary>
    /// 此Pallet是否有安裝Tray。(僅UI使用)
    /// </summary>
    [Computed]
    public bool InstallTray
    {
        get { return _installTray; }
        set { SetProperty(ref _installTray, value); }
    }
    private bool _installTray = false;

    /// <summary>
    /// Tray功能分類。(僅UI使用)
    /// </summary>
    [Computed]
    public TrayFunctionType FunctionName
    {
        get { return _functionName; }
        set { SetProperty(ref _functionName, value); }
    }
    private TrayFunctionType _functionName;

    /// <summary>
    /// Tray名稱 &amp; 註解。(僅UI使用)
    /// </summary>
    [Computed]
    public string TrayName
    {
        get { return _trayName; }
        set { SetProperty(ref _trayName, value); }
    }
    private string _trayName;

    /// <summary>
    /// 安裝在此Pallet的Tray總共點位數。(僅UI使用)
    /// </summary>
    [Computed]
    public int TotalSequences
    {
        get { return _totalSequences; }
        set { SetProperty(ref _totalSequences, value); }
    }
    private int _totalSequences;

    /// <summary>
    /// Tray安裝在Pallet的基準點 X。
    /// </summary>
    public double DatumX
    {
        get { return _datumX; }
        set { SetProperty(ref _datumX, value); }
    }
    private double _datumX;

    /// <summary>
    /// Tray安裝在Pallet的基準點 Y。
    /// </summary>
    public double DatumY
    {
        get { return _datumY; }
        set { SetProperty(ref _datumY, value); }
    }
    private double _datumY;

    /// <summary>
    /// 基準點偏移 X。
    /// </summary>
    public double OffsetX
    {
        get { return _offsetX; }
        set { SetProperty(ref _offsetX, value); }
    }
    private double _offsetX;

    /// <summary>
    /// 基準點偏移 Y。
    /// </summary>
    public double OffsetY
    {
        get { return _offsetY; }
        set { SetProperty(ref _offsetY, value); }
    }
    private double _offsetY;

    /// <summary>
    /// 依序排列 - 偏移 X。
    /// </summary>
    public double Order_OffsetX
    {
        get { return _order_OffsetX; }
        set { SetProperty(ref _order_OffsetX, value); }
    }
    private double _order_OffsetX;

    /// <summary>
    /// 依序排列 - 偏移 Y。
    /// </summary>
    public double Order_OffsetY
    {
        get { return _order_OffsetY; }
        set { SetProperty(ref _order_OffsetY, value); }
    }
    private double _order_OffsetY;

    /// <summary>
    /// 依序排列 - 偏移 X。
    /// </summary>
    public double Cross_OffsetX
    {
        get { return _cross_OffsetX; }
        set { SetProperty(ref _cross_OffsetX, value); }
    }
    private double _cross_OffsetX;

    /// <summary>
    /// 依序排列 - 偏移 Y。
    /// </summary>
    public double Cross_OffsetY
    {
        get { return _cross_OffsetY; }
        set { SetProperty(ref _cross_OffsetY, value); }
    }
    private double _cross_OffsetY;

    //[Computed]
    //public int Row => (PositionId - 1) / WfsService.MAX_TRAY_HANDLINGS * 2;

    //[Computed]
    //public int Column => (PositionId - 1) % WfsService.MAX_TRAY_HANDLINGS * 2;

    /// <summary>
    /// 取料高度Offset。
    /// </summary>
    public double PickHeightOffset
    {
        get { return _pickHeightOffset; }
        set { SetProperty(ref _pickHeightOffset, value); }
    }
    private double _pickHeightOffset;

    /********************
     * 加減速 高度
     ********************/
    /// <summary>
    /// 取料 下降減速 Z。
    /// </summary>
    public int ZAxis_Pick_Height
    {
        get { return _zAxis_Pick_Height; }
        set { SetProperty(ref _zAxis_Pick_Height, value); }
    }
    private int _zAxis_Pick_Height;

    /// <summary>
    /// 取料 上昇加速 Z。
    /// </summary>
    public int ZAxis_Place_Height
    {
        get { return _zAxis_Place_Height; }
        set { SetProperty(ref _zAxis_Place_Height, value); }
    }
    private int _zAxis_Place_Height;

    /********************
     * 加減速 速率
     ********************/
    /// <summary>
    /// 取料 下降減速。
    /// </summary>
    public short ZAxis_Pick_SpeedRate
    {
        get { return _zAxis_Pick_SpeedRate; }
        set { SetProperty(ref _zAxis_Pick_SpeedRate, value); }
    }
    private short _zAxis_Pick_SpeedRate;

    /// <summary>
    /// 取料 上昇加速。
    /// </summary>
    public short ZAxis_Place_SpeedRate
    {
        get { return _zAxis_Place_SpeedRate; }
        set { SetProperty(ref _zAxis_Place_SpeedRate, value); }
    }
    private short _zAxis_Place_SpeedRate;

    /********************
     * 加減速 時間
     ********************/
    /// <summary>
    /// 取料前吸著延時。
    /// </summary>
    public float ZAxis_PickDelay_BeforeVacuum
    {
        get { return _zAxis_PickDelay_BeforeVacuum; }
        set { SetProperty(ref _zAxis_PickDelay_BeforeVacuum, value); }
    }
    private float _zAxis_PickDelay_BeforeVacuum;

    /// <summary>
    /// 取料後上升延時。
    /// </summary>
    public float ZAxis_UpDelay_AfterPick
    {
        get { return _zAxis_UpDelay_AfterPick; }
        set { SetProperty(ref _zAxis_UpDelay_AfterPick, value); }
    }
    private float _zAxis_UpDelay_AfterPick;

    /// <summary>
    /// 破真空時間。
    /// </summary>
    public float ZAxis_Place_VacuumRelief
    {
        get { return _zAxis_Place_VacuumRelief; }
        set { SetProperty(ref _zAxis_Place_VacuumRelief, value); }
    }
    private float _zAxis_Place_VacuumRelief;

    /// <summary>
    /// 放置後上升延時。
    /// </summary>
    public float ZAxis_UpDelay_AfterPlace
    {
        get { return _zAxis_UpDelay_AfterPlace; }
        set { SetProperty(ref _zAxis_UpDelay_AfterPlace, value); }
    }
    private float _zAxis_UpDelay_AfterPlace;

    /********************
     * 點位資訊(用於設定並寫入用，實際值要讀取TrayData內的點位)
     ********************/
    /// <summary>
    /// 準備取料點位編號。
    /// </summary>
    [Computed]
    public int NextPointNo
    {
        get { return _nextPointNo; }
        set { SetProperty(ref _nextPointNo, value); }
    }
    private int _nextPointNo;

    /// <summary>
    /// 準備取料點位序號。
    /// </summary>
    [Computed]
    public int NextSequenceNo
    {
        get { return _nextSequenceNo; }
        set { SetProperty(ref _nextSequenceNo, value); }
    }
    private int _nextSequenceNo;

    /// <summary>
    /// 目前取料點位編號。
    /// </summary>
    [Computed]
    public int PickPointNo
    {
        get { return _pickPointNo; }
        set { SetProperty(ref _pickPointNo, value); }
    }
    private int _pickPointNo;

    /// <summary>
    /// 目前取料點位序號。
    /// </summary>
    [Computed]
    public int PickSequenceNo
    {
        get { return _pickSequenceNo; }
        set { SetProperty(ref _pickSequenceNo, value); }
    }
    private int _pickSequenceNo;

    ///// <summary>
    ///// 目前取放點編號。
    ///// </summary>
    //[Computed]
    //public int CurrentSequenceNo
    //{
    //    get { return _currentSequenceNo; }
    //    set { SetProperty(ref _currentSequenceNo, value); }
    //}
    //private int _currentSequenceNo;

    ///// <summary>
    ///// 目前點位序號。
    ///// </summary> 
    //public int CurrentPointNo
    //{
    //    get { return _currentPointNo; }
    //    set { SetProperty(ref _currentPointNo, value); }
    //}
    //private int _currentPointNo;

    ///// <summary>
    ///// 目前取放點編號。
    ///// </summary>
    //public int CurrentSequenceNo
    //{
    //    get { return _currentSequenceNo; }
    //    set { SetProperty(ref _currentSequenceNo, value); }
    //}
    //private int _currentSequenceNo;

    /********************************************************************************
     * 自動量測作業
     ********************************************************************************/
    /// <summary>
    /// 
    /// </summary>
    [Computed]
    public bool Tag
    {
        get { return _tag; }
        set { SetProperty(ref _tag, value); }
    }
    private bool _tag;
}
