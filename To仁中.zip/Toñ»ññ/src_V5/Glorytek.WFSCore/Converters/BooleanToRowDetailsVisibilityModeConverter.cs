﻿using System;
using System.Windows.Data;

namespace Glorytek.WFSCore.Converters
{
    /// <summary>
    /// bool 與 DataGrid.RowDetailsVisibilityMode 互轉。
    /// </summary>
    [ValueConversion(typeof(bool), typeof(string))]
    public class BooleanToRowDetailsVisibilityModeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => (bool)value ? "VisibleWhenSelected" : "Collapsed";

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => (string)value == "VisibleWhenSelected" ? true : false;
    }
}
