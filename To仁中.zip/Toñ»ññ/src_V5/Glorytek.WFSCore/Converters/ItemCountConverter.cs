﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Markup;

namespace Glorytek.WFSCore.Converters
{
    /// <summary>
    /// 用於列表中，項目數量顯示的格式化
    /// </summary>
    // 取自 MahApps.Metro.Demo
    [ValueConversion(typeof(int), typeof(string))]
    [MarkupExtensionReturnType(typeof(ItemCountConverter))]
    public class ItemCountConverter : MarkupExtension, IValueConverter
    {
        /// <inheritdoc />
        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return this;
        }

        /// <inheritdoc />
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int itemCount)
            {
                if (itemCount > 1)
                {
                    return $"({itemCount} 項目)";
                }

                if (itemCount == 1)
                {
                    return $"({itemCount} 項目)";
                }
            }

            return string.Empty;
        }

        /// <inheritdoc />
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Binding.DoNothing;
        }
    }
}
