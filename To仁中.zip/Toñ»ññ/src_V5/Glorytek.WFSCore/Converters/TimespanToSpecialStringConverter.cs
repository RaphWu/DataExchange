﻿using System;
using System.Windows.Data;

namespace Glorytek.WFSCore.Converters
{
    [ValueConversion(typeof(TimeSpan), typeof(string))]
    public class TimespanToSpecialStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter,
        System.Globalization.CultureInfo culture)
        {
            if (targetType != typeof(string))
                throw new InvalidOperationException("The target must be a string");

            if (value == null)
            {
                return "";
            }
            else
            {
                var timeSpan = (TimeSpan)value;
                return $"{timeSpan.Hours:D2}:{timeSpan.Minutes:D2}:{timeSpan.Seconds:D2}";
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (targetType != typeof(TimeSpan))
                throw new InvalidOperationException("The target must be a TimeSpan");
            return TimeSpan.Zero;
        }
    }
}
