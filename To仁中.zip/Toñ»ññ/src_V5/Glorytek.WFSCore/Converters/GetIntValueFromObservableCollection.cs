﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows.Data;

namespace Glorytek.WFSCore.Converters
{
    public class GetIntValueFromObservableCollection : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values.Length != 2 || values[0] is not ObservableCollection<int> || values[1] is not int)
                return "-";
            //throw new ArgumentException("given values not correct");

            int no = ((ObservableCollection<int>)values[0])[(int)values[1] - 1];
            return no >= 0 ? no.ToString() : "0";
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
