﻿using Prism.Mvvm;

namespace Glorytek.WFSCore.Authority;

/// <summary>
/// 權限表。
/// </summary>
public class AuthorizationTable : BindableBase
{
    /********************
     * 主畫面
     ********************/
    /// <summary>
    /// 主控頁。
    /// </summary>
    public bool Menu_MainConsole
    {
        get { return _menu_MainConsole; }
        set { SetProperty(ref _menu_MainConsole, value); }
    }
    private bool _menu_MainConsole;

    /// <summary>
    /// 托盤參數。
    /// </summary>
    public bool Menu_PalletParameters
    {
        get { return _menu_PalletParameters; }
        set { SetProperty(ref _menu_PalletParameters, value); }
    }
    private bool _menu_PalletParameters;

    /// <summary>
    /// 取放治具參數。
    /// </summary>
    public bool Menu_StageParameters
    {
        get { return _menu_StageParameters; }
        set { SetProperty(ref _menu_StageParameters, value); }
    }
    private bool _menu_StageParameters;

    /********************
     * 
     ********************/
    /// <summary>
    /// 手動畫面。
    /// </summary>
    public bool Menu_Manual
    {
        get { return _menu_Manual; }
        set { SetProperty(ref _menu_Manual, value); }
    }
    private bool _menu_Manual;

    /// <summary>
    /// 大托盤設定。
    /// </summary>
    public bool Menu_Pallet
    {
        get { return _menu_Pallet; }
        set { SetProperty(ref _menu_Pallet, value); }
    }
    private bool _menu_Pallet;

    /// <summary>
    /// WFS規格設定。
    /// </summary>
    public bool Menu_WFS_Specification
    {
        get { return _menu_WFS_Specification; }
        set { SetProperty(ref _menu_WFS_Specification, value); }
    }
    private bool _menu_WFS_Specification;

    /// <summary>
    /// 托盤設定。
    /// </summary>
    public bool Menu_Tray
    {
        get { return _menu_Tray; }
        set { SetProperty(ref _menu_Tray, value); }
    }
    private bool _menu_Tray;

    /********************
     * 教導
     ********************/
    /// <summary>
    /// 機台基準點。
    /// </summary>
    public bool Menu_MachineDatum
    {
        get { return _menu_MachineDatum; }
        set { SetProperty(ref _menu_MachineDatum, value); }
    }
    private bool _menu_MachineDatum;

    /// <summary>
    /// 黏土座。
    /// </summary>
    public bool Menu_ClayTable
    {
        get { return _menu_ClayTable; }
        set { SetProperty(ref _menu_ClayTable, value); }
    }
    private bool _menu_ClayTable;

    /// <summary>
    /// 測高用位移計。
    /// </summary>
    public bool Menu_Displacement
    {
        get { return _menu_Displacement; }
        set { SetProperty(ref _menu_Displacement, value); }
    }
    private bool _menu_Displacement;

    /// <summary>
    /// STAGE。
    /// </summary>
    public bool Menu_Stage
    {
        get { return _menu_Stage; }
        set { SetProperty(ref _menu_Stage, value); }
    }
    private bool _menu_Stage;

    /// <summary>
    /// Pallet安裝點。
    /// </summary>
    public bool Menu_PalletInstallPoints
    {
        get { return _menu_PalletInstallPoints; }
        set { SetProperty(ref _menu_PalletInstallPoints, value); }
    }
    private bool _menu_PalletInstallPoints;

    /// <summary>
    /// 重複精度測試。
    /// </summary>
    public bool Menu_RepeatabilityTest
    {
        get { return _menu_RepeatabilityTest; }
        set { SetProperty(ref _menu_RepeatabilityTest, value); }
    }
    private bool _menu_RepeatabilityTest;

    /// <summary>
    /// 輸出參數報表。
    /// </summary>
    public bool Func_ReportOutput
    {
        get { return _func_ReportOutput; }
        set { SetProperty(ref _func_ReportOutput, value); }
    }
    private bool _func_ReportOutput;

    /********************
     * 
     ********************/
    /// <summary>
    /// 大數據。
    /// </summary>
    public bool Menu_BigData
    {
        get { return _menu_BigData; }
        set { SetProperty(ref _menu_BigData, value); }
    }
    private bool _menu_BigData;

    /// <summary>
    /// 異常履歷。
    /// </summary>
    public bool Report_AbnormalHistory
    {
        get { return _report_AbnormalHistory; }
        set { SetProperty(ref _report_AbnormalHistory, value); }
    }
    private bool _report_AbnormalHistory;

    /// <summary>
    /// 系統紀錄。
    /// </summary>
    public bool Report_SystemLogger
    {
        get { return _report_SystemLogger; }
        set { SetProperty(ref _report_SystemLogger, value); }
    }
    private bool _report_SystemLogger;

    /// <summary>
    /// 重大事件紀錄。
    /// </summary>
    public bool Report_ExceptionLogger
    {
        get { return _report_ExceptionLogger; }
        set { SetProperty(ref _report_ExceptionLogger, value); }
    }
    private bool _report_ExceptionLogger;

    /********************
     * 
     ********************/
    /// <summary>
    /// 品種切換。
    /// </summary>
    public bool Menu_Product_Switch
    {
        get { return _menu_Product_Switch; }
        set { SetProperty(ref _menu_Product_Switch, value); }
    }
    private bool _menu_Product_Switch;

    /// <summary>
    /// 品種管理。
    /// </summary>
    public bool Menu_Product_Manager
    {
        get { return _menu_Product_Manager; }
        set { SetProperty(ref _menu_Product_Manager, value); }
    }
    private bool _menu_Product_Manager;

    /********************
     * 系統
     ********************/
    /// <summary>
    /// System。
    /// </summary>
    public bool Menu_System
    {
        get { return _menu_System; }
        set { SetProperty(ref _menu_System, value); }
    }
    private bool _menu_System;

    /// <summary>
    /// 連線設定。
    /// </summary>
    public bool Menu_Connection
    {
        get { return _menu_Connection; }
        set { SetProperty(ref _menu_Connection, value); }
    }
    private bool _menu_Connection;

    /// <summary>
    /// 權限設定。
    /// </summary>
    public bool Menu_Authority
    {
        get { return _menu_Authority; }
        set { SetProperty(ref _menu_Authority, value); }
    }
    private bool _menu_Authority;
}
