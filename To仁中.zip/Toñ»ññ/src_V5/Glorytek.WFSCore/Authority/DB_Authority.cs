﻿namespace Glorytek.WFSCore.Authority;

/// <summary>
/// 資料庫名稱與定義 - 權限系統。
/// </summary>
internal class DB_Authority
{
    internal const string TableName_Authorization = "Authorization";
    internal const string CreateTableSQL_Authorization = @"CREATE TABLE IF NOT EXISTS [Authorization](
[Id] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
[OrderNo] INTEGER,
[UserName] TEXT NOT NULL DEFAULT 'Unknown',
[Password] TEXT NOT NULL,
[Authorization] TEXT NOT NULL);";

    internal const string TableName_Authority = "Authority";
    internal const string CreateTableSQL_Authority = @"CREATE TABLE IF NOT EXISTS [Authority](
[Id] INTEGER,
[InputDetectInterval] INTEGER DEFAULT 5);";
}
