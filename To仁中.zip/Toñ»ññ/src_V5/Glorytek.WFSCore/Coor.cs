﻿using Glorytek.CSharp.Data;

namespace Glorytek.WFSCore;

/// <summary>
/// 座標值處理
/// </summary>
public static class Coor
{
    /// <summary>
    /// 座標小數有效位數
    /// </summary>
    /// <remarks>座標的單位均為mm，小數3位則為µm，故小數抓位6位數即可避免算術誤差累積。</remarks>
    private const int _SIGNIFICANT_FIGURES = 6;

    /// <summary>
    /// 有效位數修正為WFS系統需求
    /// </summary>
    /// <param name="coordinate">待格式化的座標值。</param>
    /// <returns>格式化完成後的座標值。</returns>
    public static double WfsFormat(this double coordinate)
    {
        return coordinate.Format(_SIGNIFICANT_FIGURES);
    }
}
