﻿namespace USB4704Test
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Measure = new System.Windows.Forms.Label();
            this.label_MaxMeasure = new System.Windows.Forms.Label();
            this.label_MinMeasure = new System.Windows.Forms.Label();
            this.label_kVal = new System.Windows.Forms.Label();
            this.button_Reset = new System.Windows.Forms.Button();
            this.label_MinFilter = new System.Windows.Forms.Label();
            this.label_MaxFilter = new System.Windows.Forms.Label();
            this.label_adjKVal = new System.Windows.Forms.Label();
            this.label_adjMeasure = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_Measure
            // 
            this.label_Measure.AutoSize = true;
            this.label_Measure.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Measure.Location = new System.Drawing.Point(70, 38);
            this.label_Measure.Name = "label_Measure";
            this.label_Measure.Size = new System.Drawing.Size(44, 17);
            this.label_Measure.TabIndex = 0;
            this.label_Measure.Text = "label1";
            // 
            // label_MaxMeasure
            // 
            this.label_MaxMeasure.AutoSize = true;
            this.label_MaxMeasure.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MaxMeasure.Location = new System.Drawing.Point(70, 55);
            this.label_MaxMeasure.Name = "label_MaxMeasure";
            this.label_MaxMeasure.Size = new System.Drawing.Size(44, 17);
            this.label_MaxMeasure.TabIndex = 1;
            this.label_MaxMeasure.Text = "label1";
            // 
            // label_MinMeasure
            // 
            this.label_MinMeasure.AutoSize = true;
            this.label_MinMeasure.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MinMeasure.Location = new System.Drawing.Point(70, 72);
            this.label_MinMeasure.Name = "label_MinMeasure";
            this.label_MinMeasure.Size = new System.Drawing.Size(44, 17);
            this.label_MinMeasure.TabIndex = 2;
            this.label_MinMeasure.Text = "label1";
            // 
            // label_kVal
            // 
            this.label_kVal.AutoSize = true;
            this.label_kVal.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_kVal.Location = new System.Drawing.Point(70, 123);
            this.label_kVal.Name = "label_kVal";
            this.label_kVal.Size = new System.Drawing.Size(44, 17);
            this.label_kVal.TabIndex = 3;
            this.label_kVal.Text = "label1";
            // 
            // button_Reset
            // 
            this.button_Reset.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Reset.Location = new System.Drawing.Point(73, 220);
            this.button_Reset.Name = "button_Reset";
            this.button_Reset.Size = new System.Drawing.Size(83, 30);
            this.button_Reset.TabIndex = 4;
            this.button_Reset.Text = "歸零";
            this.button_Reset.UseVisualStyleBackColor = true;
            this.button_Reset.Click += new System.EventHandler(this.button_Reset_Click);
            // 
            // label_MinFilter
            // 
            this.label_MinFilter.AutoSize = true;
            this.label_MinFilter.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MinFilter.Location = new System.Drawing.Point(70, 157);
            this.label_MinFilter.Name = "label_MinFilter";
            this.label_MinFilter.Size = new System.Drawing.Size(44, 17);
            this.label_MinFilter.TabIndex = 6;
            this.label_MinFilter.Text = "label1";
            // 
            // label_MaxFilter
            // 
            this.label_MaxFilter.AutoSize = true;
            this.label_MaxFilter.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MaxFilter.Location = new System.Drawing.Point(70, 140);
            this.label_MaxFilter.Name = "label_MaxFilter";
            this.label_MaxFilter.Size = new System.Drawing.Size(44, 17);
            this.label_MaxFilter.TabIndex = 5;
            this.label_MaxFilter.Text = "label1";
            // 
            // label_adjKVal
            // 
            this.label_adjKVal.AutoSize = true;
            this.label_adjKVal.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_adjKVal.Location = new System.Drawing.Point(70, 174);
            this.label_adjKVal.Name = "label_adjKVal";
            this.label_adjKVal.Size = new System.Drawing.Size(44, 17);
            this.label_adjKVal.TabIndex = 7;
            this.label_adjKVal.Text = "label1";
            this.label_adjKVal.Visible = false;
            // 
            // label_adjMeasure
            // 
            this.label_adjMeasure.AutoSize = true;
            this.label_adjMeasure.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_adjMeasure.Location = new System.Drawing.Point(70, 89);
            this.label_adjMeasure.Name = "label_adjMeasure";
            this.label_adjMeasure.Size = new System.Drawing.Size(44, 17);
            this.label_adjMeasure.TabIndex = 8;
            this.label_adjMeasure.Text = "label1";
            this.label_adjMeasure.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 287);
            this.Controls.Add(this.label_adjMeasure);
            this.Controls.Add(this.label_adjKVal);
            this.Controls.Add(this.label_MinFilter);
            this.Controls.Add(this.label_MaxFilter);
            this.Controls.Add(this.button_Reset);
            this.Controls.Add(this.label_kVal);
            this.Controls.Add(this.label_MinMeasure);
            this.Controls.Add(this.label_MaxMeasure);
            this.Controls.Add(this.label_Measure);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Measure;
        private System.Windows.Forms.Label label_MaxMeasure;
        private System.Windows.Forms.Label label_MinMeasure;
        private System.Windows.Forms.Label label_kVal;
        private System.Windows.Forms.Button button_Reset;
        private System.Windows.Forms.Label label_MinFilter;
        private System.Windows.Forms.Label label_MaxFilter;
        private System.Windows.Forms.Label label_adjKVal;
        private System.Windows.Forms.Label label_adjMeasure;
    }
}

