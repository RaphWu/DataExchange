Run the following command line:

```bash
cd nuget/
nuget pack cs-kalman-filters.nuspec
```