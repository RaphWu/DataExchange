﻿using Automation.BDaq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace USB4704Test
{
    // https://www.cnblogs.com/EasonDongH/p/8818829.html

    public partial class Form1 : Form
    {
        const string deviceCode = "USB-4704,BID#0";
        const int channel = 0;  // 通道編號：0~7
        InstantAiCtrl instantAiCtrl = new InstantAiCtrl();
        double[] dataScaled = new double[1];

        double maxMeasure = double.MinValue;
        double minMeasure = double.MaxValue;

        double kVal = 0.0;
        double maxFilter = double.MinValue;
        double minFilter = double.MaxValue;

        Timer timer = new Timer();
        FilterKalman filterKalman;

        public Form1()
        {
            InitializeComponent();

            instantAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
        }

        //private void Init()
        //{
        //    InstantAiCtrl device = new InstantAiCtrl();

        //    int val;
        //    device.Read(0, out val);
        //    label_AI.Text = val.ToString();
        //}

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!instantAiCtrl.Initialized)
            {
                MessageBox.Show("No device be selected or device open failed!", "AI_InstantAI");
                this.Close();
                return;
            }

            filterKalman = new FilterKalman(0.008, 0.2, 1, 1, 1);

            timer.Interval = 100;
            timer.Tick += tick;
            timer.Start();
        }

        double avgMeasure = 0.0;
        double adjMeasure = 0.0;
        double avgKVal = 0.0;
        double adjKVal = 0.0;

        private void tick(object sender, EventArgs e)
        {
            var err = instantAiCtrl.Read(channel, 1, dataScaled);
            if (err == ErrorCode.Success)
            {
                double measure = dataScaled[0];
                adjMeasure = measure * 0.7 + avgMeasure * 0.3;
                if (measure > maxMeasure) maxMeasure = measure;
                if (measure < minMeasure) minMeasure = measure;

                kVal = filterKalman.Filter(measure, 0.0);
                adjKVal = kVal * 0.7 + avgKVal * 0.3;
                if (kVal > maxFilter) maxFilter = kVal;
                if (kVal < minFilter) minFilter = kVal;

                label_Measure.Text = String.Concat("取值: ", measure.ToString());
                label_adjMeasure.Text = String.Concat("平均: ", adjMeasure.ToString());
                label_MaxMeasure.Text = String.Concat("最大: ", maxMeasure.ToString());
                label_MinMeasure.Text = String.Concat("最小: ", minMeasure.ToString());

                label_kVal.Text = String.Concat("濾波後值: ", kVal.ToString());
                label_adjKVal.Text = String.Concat("權值平均: ", adjKVal.ToString());
                label_MaxFilter.Text = String.Concat("濾波最大: ", maxFilter.ToString());
                label_MinFilter.Text = String.Concat("濾波最小: ", minFilter.ToString());
            }
        }

        private void button_Reset_Click(object sender, EventArgs e)
        {
            maxMeasure = double.MinValue;
            minMeasure = double.MaxValue;
            kVal = 0.0;
            maxFilter = double.MinValue;
            minFilter = double.MaxValue;
        }
    }
}
