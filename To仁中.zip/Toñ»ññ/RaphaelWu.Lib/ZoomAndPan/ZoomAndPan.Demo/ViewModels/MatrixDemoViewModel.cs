﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ZoomAndPan.Demo.ViewModels
{
    public class MatrixDemoViewModel : BindableBase, INavigationAware
    {
        private const int SIZE_X = 6;           // X軸方塊數
        private const int SIZE_Y = 7;           // Y軸方塊數
        private const double BLOCK_SIDE = 40.0; // 方塊邊長(此範例的方塊均為正方形)
        private const double BLOCK_GAP = 10.0;  // 方塊與方塊間的間距
        private const double MARGIN = 40.0;     // 方塊與視區間的留白區域寬度

        private const string BLOCK_FG = "Black";        // 方塊內容顏色
        private const string BLOCK_BG = "WhiteSmoke";   // 方塊底色
        private const string MASK_FG = "White";         // MASK內容顏色
        private const string MASK_BG = "DimGray";       // MASK底色

        private List<BlockDefine> _allBlocks;

        /********************
         * INavigationAware
         ********************/
        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            RebuildBlocks();
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
        }

        public bool IsNavigationTarget(NavigationContext navigationContext) => true;

        /********************
         * ctor
         ********************/
        public MatrixDemoViewModel()
        {
        }

        /// <summary>
        /// 重建所有方塊資訊。
        /// </summary>
        public void RebuildBlocks()
        {
            _allBlocks = new List<BlockDefine>();

            // 視區四邊座標
            double cornerLeft = double.MaxValue;
            double cornerRight = double.MinValue;
            double cornerTop = double.MaxValue;
            double cornerBottom = double.MinValue;

            /********************
             * 計算所有方塊
             ********************/
            for (int y = 0; y < SIZE_Y; y++)
                for (int x = 0; x < SIZE_X; x++)
                {
                    // 方塊ID與座標
                    int blockId = y * SIZE_X + x + 1;
                    double displayX = x * (BLOCK_SIDE + BLOCK_GAP);
                    double displayY = y * (BLOCK_SIDE + BLOCK_GAP);

                    // 方塊尺寸資料
                    Rect blockArea = new(displayX, displayY, BLOCK_SIDE, BLOCK_SIDE);

                    // 抓取視區四邊位置
                    if (cornerLeft > blockArea.Left)
                        cornerLeft = blockArea.Left;

                    if (cornerRight < blockArea.Right)
                        cornerRight = blockArea.Right;

                    if (cornerTop > blockArea.Top)
                        cornerTop = blockArea.Top;

                    if (cornerBottom < blockArea.Bottom)
                        cornerBottom = blockArea.Bottom;

                    // 建立方塊
                    _allBlocks.Add(new BlockDefine(
                        id: blockId,
                        title: blockId.ToString(),
                        displayX: displayX,
                        displayY: displayY,
                        width: BLOCK_SIDE,
                        height: BLOCK_SIDE,
                        fgColor: BLOCK_FG,
                        bgColor: BLOCK_BG,
                        mask: false));
                }

            /********************
             * 將視區左上角移至(0,0)
             ********************/
            // 與(0,0)偏移量
            double drawingOffsetX;
            double drawingOffsetY;

            drawingOffsetX = cornerLeft;
            cornerLeft = 0.0;
            cornerRight -= drawingOffsetX;

            drawingOffsetY = cornerTop;
            cornerTop = 0.0;
            cornerBottom -= drawingOffsetY;

            // 修正所有方塊位置(含留白)
            foreach (var block in _allBlocks)
            {
                block.DisplayX -= drawingOffsetX - MARGIN;
                block.DisplayY -= drawingOffsetY - MARGIN;
            }

            // 套用所有方塊資料給ZoomAndPan
            Blocks = new ObservableCollection<BlockDefine>(_allBlocks);

            /********************
             * 視區修正
             ********************/
            // 視區邊緣與方塊間留白
            double borderLeft = (cornerLeft - MARGIN);
            double borderRight = (cornerRight + MARGIN);
            double borderTop = (cornerTop - MARGIN);
            double borderBottom = (cornerBottom + MARGIN);

            // 定義視區
            Rect contentArea = new(new Point(borderLeft, borderTop),
                                   new Point(borderRight, borderBottom));

            // 設定視區寬高
            ViewportWidth = contentArea.Width;
            ViewportHeight = contentArea.Height;
        }

        /// <summary>
        /// 滑鼠右鍵
        /// </summary>
        public DelegateCommand<object> RightButtonClickOnBlockCommand
            => _rightButtonClickOnBlockCommand ??= new DelegateCommand<object>(ExecuteRightButtonClickOnBlockCommand);
        private void ExecuteRightButtonClickOnBlockCommand(object clickedBlock)
        {
            if (clickedBlock != null && _allBlocks != null && clickedBlock is MouseButtonEventArgs args)
            {
                int blockId = -1;

                if (args.OriginalSource is Border _clickedBorder)
                    blockId = (int)_clickedBorder.Tag;
                else if (args.OriginalSource is TextBlock _clickedBlock)
                    blockId = (int)_clickedBlock.Tag;

                if (blockId != -1)
                {
                    int idx = blockId - 1;
                    if (Blocks[idx].Mask)
                    {
                        Blocks[idx].Mask = false;
                        Blocks[idx].FgColor = BLOCK_FG;
                        Blocks[idx].BgColor = BLOCK_BG;
                    }
                    else
                    {
                        Blocks[idx].Mask = true;
                        Blocks[idx].FgColor = MASK_FG;
                        Blocks[idx].BgColor = MASK_BG;
                    }
                }
            }
        }
        private DelegateCommand<object> _rightButtonClickOnBlockCommand;

        /********************/
        /// <summary>
        /// 所有顯示方塊
        /// </summary>
        public ObservableCollection<BlockDefine> Blocks
        {
            get { return _blocks; }
            set { SetProperty(ref _blocks, value); }
        }
        private ObservableCollection<BlockDefine> _blocks;

        /// <summary>
        /// 視區寬
        /// </summary>
        public double ViewportWidth
        {
            get { return _viewportWidth; }
            set { SetProperty(ref _viewportWidth, value); }
        }
        private double _viewportWidth;

        /// <summary>
        /// 視區高
        /// </summary>
        public double ViewportHeight
        {
            get { return _viewportHeight; }
            set { SetProperty(ref _viewportHeight, value); }
        }
        private double _viewportHeight;
    }
}
