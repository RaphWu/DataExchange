﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System.Windows;

namespace ZoomAndPan.Demo.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private IRegionNavigationService _navigationService;

        /********************
         * ctor
         ********************/
        private readonly IRegionManager _regionManager;

        public MainWindowViewModel(IRegionManager regionManager)
        {
            _regionManager = regionManager;
        }

        /********************
         * System Commands
         ********************/
        /// <summary>
        /// 視窗載入。
        /// </summary>
        public DelegateCommand LoadedCommand
            => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
        private void ExecuteLoadedCommand()
        {
            _navigationService = _regionManager.Regions["ContentRegion"].NavigationService;

        }
        private DelegateCommand _loadedCommand;

        /// <summary>
        /// 結束程式。
        /// </summary>
        public DelegateCommand ExitCommand
            => _exitCommand ??= new DelegateCommand(ExecuteExitCommand);
        private void ExecuteExitCommand()
        {
            Application.Current.Shutdown();
        }
        private DelegateCommand _exitCommand;

        /// <summary>
        /// 切換頁面。
        /// </summary>
        public DelegateCommand<string> NavigationCommand
            => _navigationCommand ??= new DelegateCommand<string>(ExecuteNavigationCommand);
        private void ExecuteNavigationCommand(string pageName)
        {
            _navigationService.RequestNavigate(pageName);
        }
        private DelegateCommand<string> _navigationCommand;
    }
}
