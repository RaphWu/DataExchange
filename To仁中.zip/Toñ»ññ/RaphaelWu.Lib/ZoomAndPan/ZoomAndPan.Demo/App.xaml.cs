﻿using Prism.Ioc;
using System.Windows;
using ZoomAndPan.Demo.ViewModels;
using ZoomAndPan.Demo.Views;

namespace ZoomAndPan.Demo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        protected override Window CreateShell()
        {
            return Container.Resolve<MainWindow>();
        }

        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<MatrixDemo, MatrixDemoViewModel>("MatrixDemo");
            containerRegistry.RegisterForNavigation<ScrollViewerDemo>("ScrollViewerDemo");
            containerRegistry.RegisterForNavigation<ColorPicDemo>("ColorPicDemo");
        }
    }
}
