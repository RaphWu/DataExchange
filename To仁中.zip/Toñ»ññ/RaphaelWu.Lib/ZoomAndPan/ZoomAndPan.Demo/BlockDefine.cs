﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ZoomAndPan.Demo
{
    public class BlockDefine : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        /// <summary>
        /// 方塊順序編號。
        /// </summary>
        public int Id
        {
            get { return _id; }
            set
            {
                _id = value;
                OnPropertyChanged();
            }
        }
        private int _id;

        /// <summary>
        /// 顯示在方塊內的文字。
        /// </summary>
        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
                OnPropertyChanged();
            }
        }
        private string _title;

        /// <summary>
        /// 方塊顯示的左上角X座標。
        /// </summary>
        public double DisplayX
        {
            get { return _displayX; }
            set
            {
                _displayX = value;
                OnPropertyChanged();
            }
        }
        private double _displayX;

        /// <summary>
        /// 方塊顯示的左上角Y座標。
        /// </summary>
        public double DisplayY
        {
            get { return _displayY; }
            set
            {
                _displayY = value;
                OnPropertyChanged();
            }
        }
        private double _displayY;

        /// <summary>
        /// 方塊寬度。
        /// </summary>
        public double Width
        {
            get { return _width; }
            set
            {
                _width = value;
                OnPropertyChanged();
            }
        }
        private double _width;

        /// <summary>
        /// 方塊高度。
        /// </summary>
        public double Height
        {
            get { return _height; }
            set
            {
                _height = value;
                OnPropertyChanged();
            }
        }
        private double _height;

        /// <summary>
        /// 方塊前景顏色。
        /// </summary>
        public string FgColor
        {
            get { return _fgColor; }
            set
            {
                _fgColor = value;
                OnPropertyChanged();
            }
        }
        private string _fgColor;

        /// <summary>
        /// 方塊背景景顏色。
        /// </summary>
        public string BgColor
        {
            get { return _bgColor; }
            set
            {
                _bgColor = value;
                OnPropertyChanged();
            }
        }
        private string _bgColor;

        /// <summary>
        /// 是否為遮罩?
        /// </summary>
        public bool Mask
        {
            get { return _mask; }
            set
            {
                _mask = value;
                OnPropertyChanged();
            }
        }
        private bool _mask;

        /// <summary>
        /// 滑鼠點擊時回傳給ViewModel的值。
        /// </summary>
        public int Tag
        {
            get { return _tag; }
            set
            {
                _tag = value;
                OnPropertyChanged();
            }
        }
        private int _tag;

        /// <summary>
        /// 方塊初始化。
        /// </summary>
        /// <param name="id">方塊順序編號。</param>
        /// <param name="title">顯示在方塊內的文字。</param>
        /// <param name="displayX">方塊顯示的左上角X座標。</param>
        /// <param name="displayY">方塊顯示的左上角Y座標。</param>
        /// <param name="width">方塊寬度。</param>
        /// <param name="height">方塊高度。</param>
        /// <param name="fgColor">方塊前景顏色。</param>
        /// <param name="bgColor">方塊背景景顏色。</param>
        /// <param name="mask">是否為遮罩?</param>
        public BlockDefine(int id,
                           string title,
                           double displayX,
                           double displayY,
                           double width,
                           double height,
                           string fgColor,
                           string bgColor,
                           bool mask)
        {
            Id = id;
            Title = title;
            DisplayX = displayX;
            DisplayY = displayY;
            Width = width;
            Height = height;
            FgColor = fgColor;
            BgColor = bgColor;
            Mask = mask;
        }
    }
}
