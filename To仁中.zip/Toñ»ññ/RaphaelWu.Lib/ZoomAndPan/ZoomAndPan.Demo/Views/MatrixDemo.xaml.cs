﻿using System.Windows.Controls;

namespace ZoomAndPan.Demo.Views
{
    /// <summary>
    /// Interaction logic for MatrixDemo
    /// </summary>
    public partial class MatrixDemo : UserControl
    {
        public MatrixDemo()
        {
            InitializeComponent();
        }
    }
}
