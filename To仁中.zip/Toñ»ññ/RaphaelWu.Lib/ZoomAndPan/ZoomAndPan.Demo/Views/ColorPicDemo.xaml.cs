﻿using System.Windows.Controls;

namespace ZoomAndPan.Demo.Views
{
    /// <summary>
    /// ColorPicDemo.xaml 的互動邏輯
    /// </summary>
    public partial class ColorPicDemo : UserControl
    {
        public ColorPicDemo()
        {
            InitializeComponent();
        }
    }
}
