﻿namespace ZoomAndPan
{
    public enum MinimumZoomTypeEnum
    {
        FitScreen, FillScreen, MinimumZoom
    }
}