﻿namespace ZoomAndPan
{
    public enum ZoomAndPanInitialPositionEnum
    {
        Default, FitScreen, FillScreen, OneHundredPercentCentered
    }
}