﻿using System.Data;
using System.Reflection;

namespace RaphaelWu.CSharp.Helpers
{
    /// <summary>
    /// DataTable輔助函數。
    /// </summary>
    public static class DataTableHelper
    {
        /// <summary>
        /// 將DataTable轉換成List&lt;T&gt;。
        /// </summary>
        /// <param name="dt">待轉換的DataTable。</param>
        /// <returns>轉換後的List&lt;T&gt;。</returns>
        /// <remarks>程式碼來源: <see href="https://stackoverflow.com/questions/1427484/convert-datatable-to-listt">Convert DataTable to List&lt;T&gt;</see>。</remarks>
        public static List<T> DataTableToList<T>(DataTable dt)
        {
            List<string> columnNames = dt.Columns.Cast<DataColumn>()
                                                 .Select(c => c.ColumnName)
                                                 .ToList();
            var properties = typeof(T).GetProperties();

            return dt.AsEnumerable().Select(row =>
            {
                var objT = Activator.CreateInstance<T>();
                foreach (var pro in properties)
                {
                    if (columnNames.Contains(pro.Name))
                    {
                        PropertyInfo pI = objT.GetType().GetProperty(pro.Name);
                        pro.SetValue(objT, row[pro.Name] == DBNull.Value ? null : Convert.ChangeType(row[pro.Name], pI.PropertyType));
                    }
                }
                return objT;
            }).ToList();
        }
    }
}
