﻿using System.ComponentModel;
using System.Reflection;

namespace RaphaelWu.CSharp.Helpers
{
    /// <summary>
    /// Enum輔助函數。
    /// </summary>
    public static class EnumHelper
    {
        /// <summary>
        /// 取得Enum的Description。
        /// </summary>
        public static string GetDescription(this Enum enumValue)
        {
            FieldInfo fi = enumValue.GetType().GetField(enumValue.ToString());

            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null && attributes.Length > 0)
                return attributes[0].Description;
            else
                return enumValue.ToString();

            //FieldInfo fi = enumValue.GetType().GetField(enumValue.ToString());

            //DescriptionAttribute[] attributes = fi.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];

            //if (attributes != null && attributes.Any())
            //{
            //    return attributes.First().Description;
            //}

            //return enumValue.ToString();
        }
    }
}
