﻿namespace RaphaelWu.CSharp.OS
{
    /// <summary>
    /// SetThreadExecutionState函數使用。<br/>
    /// 參考來源：<see href="https://blog.walterlv.com/post/set-thread-execution-state.html">.NET/C# 阻止屏幕关闭，阻止系统进入睡眠状态</see>。<br/>
    /// 參數說明：<see href="https://docs.microsoft.com/zh-tw/windows/win32/api/winbase/nf-winbase-setthreadexecutionstate">SetThreadExecutionState function (winbase.h)</see>。
    /// </summary>
    [Flags]
    public enum ThreadExecutionState : uint
    {
        /// <summary>
        /// 通過重置系統空閒計時器來強制系統進入工作狀態。
        /// </summary>
        SystemRequired = 0x01,

        /// <summary>
        /// 通過重置顯示器空閒計時器來強制顯示器開啟。
        /// </summary>
        DisplayRequired = 0x02,

        /// <summary>
        /// 不支持該值。 如果<see cref="UserPresent"/>與其他esFlags值結合使用，則調用將失敗，並且不會設置任何指定狀態。
        /// </summary>
        [Obsolete("This value is not supported.")]
        UserPresent = 0x04,

        /// <summary>
        /// 啟用離開模式。 必須使用<see cref="Continuous"/>指定此值。
        /// <para />
        /// 離開模式僅應由必須在台式計算機上執行關鍵後台處理的媒體記錄和媒體分發應用程序使用，而計算機似乎正在休眠。
        /// </summary>
        AwaymodeRequired = 0x40,

        /// <summary>
        /// 通知系統所設置的狀態應保持有效，直到使用<see cref="Continuous"/>的下一次調用和其他狀態標誌之一被清除為止。
        /// </summary>
        Continuous = 0x80000000,
    }
}
