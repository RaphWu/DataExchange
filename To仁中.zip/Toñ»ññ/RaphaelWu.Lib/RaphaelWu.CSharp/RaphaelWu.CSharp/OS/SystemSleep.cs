﻿using System.Runtime.InteropServices;

namespace RaphaelWu.CSharp.OS
{
    /// <summary>
    /// 包含控制螢幕關閉以及系統休眠相關的方法。
    /// </summary>
    /// <remarks>程式碼來源：<see href="https://blog.walterlv.com/post/set-thread-execution-state.html">.NET/C# 阻止屏幕关闭，阻止系统进入睡眠状态</see>。</remarks>
    public static class SystemSleep
    {
        /// <summary>
        /// 使應用程序能夠通知系統它正在使用中，從而防止系統在應用程序運行時進入睡眠狀態或關閉顯示器。
        /// </summary>
        /// <see href="https://docs.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-setthreadexecutionstate"/>
        [DllImport("kernel32")]
        private static extern ThreadExecutionState SetThreadExecutionState(ThreadExecutionState esFlags);

        /// <summary>
        /// 設置此線程從現在開始將一直處於運行狀態，不應該進入睡眠狀態。<br/>
        /// 此線程退出後，設置將失效。<br/>
        /// 如果需要恢復，請調用 <see cref="RestoreForCurrentThread"/> 方法。
        /// </summary>
        /// <param name="keepDisplayOn">表示是否應該同時保持螢幕不關閉。<br/>
        /// 對於遊戲、視頻和演示相關的任務需要保持螢幕不關閉；而對於後台服務、下載和監控等任務則不需要。</param>
        public static void PreventForCurrentThread(bool keepDisplayOn = true)
        {
            SetThreadExecutionState(keepDisplayOn
                ? ThreadExecutionState.Continuous | ThreadExecutionState.SystemRequired | ThreadExecutionState.DisplayRequired
                : ThreadExecutionState.Continuous | ThreadExecutionState.SystemRequired);
        }

        /// <summary>
        /// 恢復此線程的運行狀態，操作系統現在可以正常進入睡眠狀態和關閉螢幕。
        /// </summary>
        public static void RestoreForCurrentThread()
        {
            SetThreadExecutionState(ThreadExecutionState.Continuous);
        }

        /// <summary>
        /// 重置系統睡眠或者關閉螢幕的計時器，這樣系統睡眠或者螢幕能夠繼續持續工作設定的超時時間。
        /// </summary>
        /// <param name="keepDisplayOn">表示是否應該同時保持螢幕不關閉。<br/>
        /// 對於遊戲、視頻和演示相關的任務需要保持螢幕不關閉；而對於後台服務、下載和監控等任務則不需要。</param>
        public static void ResetIdle(bool keepDisplayOn = true)
        {
            SetThreadExecutionState(keepDisplayOn
                ? ThreadExecutionState.SystemRequired | ThreadExecutionState.DisplayRequired
                : ThreadExecutionState.SystemRequired);
        }
    }
}
