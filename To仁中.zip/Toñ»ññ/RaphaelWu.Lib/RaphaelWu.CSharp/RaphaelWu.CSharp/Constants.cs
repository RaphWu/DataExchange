﻿namespace RaphaelWu.CSharp
{
    public static class Constants
    {
        /// <summary>
        /// 本地時區。
        /// </summary>
        public static TimeSpan LocalTimeZone = TimeZoneInfo.Local.BaseUtcOffset;
    }
}
