﻿using RaphaelWu.CSharp.Data.Validation;
using System.Runtime.InteropServices;

namespace RaphaelWu.CSharp.IO
{
    /// <summary>
    /// 目錄及檔案相關操作。
    /// </summary>
    public class FileHelper
    {
        /// <summary>
        /// 錯誤訊息。
        /// </summary>
        private static string _errorMessage = "";

        /// <summary>
        /// 
        /// </summary>
        public static string DiskTypeInfo = "Disk";

        /// <summary>
        /// 記錄例外。
        /// </summary>
        /// <param name="ex">例外物件。</param>
        /// <param name="errorMsgs">錯誤訊息。</param>
        private static void PrintExcetpion(Exception ex, string errorMsgs)
        {
            _errorMessage = errorMsgs;
            //Log.Error(ex, errorMsgs);
        }

        /// <summary>
        /// 取得暫存檔的檔案名稱。
        /// </summary>
        /// <param name="fileName">指定的檔案名稱。未指定時預設為~temp.tmp。</param>
        /// <returns>暫存檔的完整路徑及檔案名稱。</returns>
        public static string GetTempFileName(string fileName)
        {
            string defaultTempFileName = "~temp.tmp";   // 預設暫存檔名
            return Path.Combine(Path.GetTempPath(), string.IsNullOrEmpty(fileName) ? defaultTempFileName : fileName);
        }

        /********************
         * 檔案基本操作
         ********************/
        /********************
         * 目錄基本操作
         ********************/
        /// <summary>
        /// 清除或建立新目錄。
        /// </summary>
        /// <param name="targetDir">目標目錄的路徑。</param>
        public static void ClearOrCreateDir(string targetDir)
        {
            if (Directory.Exists(targetDir))
                ClearDir(targetDir);
            else
                CreateDirectoy(targetDir);
        }

        /// <summary>
        /// 清除目錄內所有內容。
        /// </summary>
        /// <param name="targetDir">目標目錄的路徑。</param>
        public static void ClearDir(string targetDir)
        {
            try
            {
                if (!new DirectoryInfo(targetDir).Exists)
                    return;

                foreach (string d in Directory.GetFileSystemEntries(targetDir))
                {
                    if (File.Exists(d))
                    {
                        var fi = new FileInfo(d);
                        DeleteFile(fi); // 直接刪除其中的檔案
                    }
                    else
                    {
                        var di = new DirectoryInfo(d);
                        DeleteDir(di.FullName); // 刪除子目錄   
                    }
                }
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"清除目錄失敗。{ex.Message}: {targetDir}");
            }
        }

        /// <summary>
        /// 刪除目錄下的所有檔案(只刪除檔案)。
        /// </summary>
        /// <param name="targetDir">目標目錄的路徑。</param>
        public static void DeleteFiles(string targetDir)
        {
            try
            {
                if (!new DirectoryInfo(targetDir).Exists)
                    return;

                foreach (string d in Directory.GetFiles(targetDir))
                {
                    if (File.Exists(d))
                    {
                        var fi = new FileInfo(d);
                        DeleteFile(fi); // 直接刪除其中的檔案
                    }
                }
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"檔案刪除失敗。{ex.Message}: {targetDir}");
            }
        }

        /// <summary>
        /// 刪除目錄。
        /// </summary>
        /// <param name="targetDir">目標目錄的路徑。</param>
        public static void DeleteDir(string targetDir)
        {
            try
            {
                if (!Directory.Exists(targetDir))
                    return;

                foreach (string dir in Directory.GetFileSystemEntries(targetDir))
                {
                    if (File.Exists(dir))
                    {
                        var fi = new FileInfo(dir);
                        DeleteFile(fi); // 直接刪除其中的檔案
                    }
                    else
                        DeleteDir(dir); // 遞迴刪除子目錄   
                }

                Directory.Delete(targetDir); // 刪除已空目錄
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"目錄刪除失敗。{ex.Message}: {targetDir}");
            }
        }

        /// <summary>
        /// 複製檔案。
        /// </summary>
        /// <param name="sourceFileName">要移動的檔案名稱。</param>
        /// <param name="destFileName">檔案的新路徑和名稱。</param>
        /// <param name="overwrite">是否可以覆寫目的檔案？可=true；否=false。</param>
        public static void CopyFile(string sourceFileName, string destFileName, bool overwrite)
        {
            try
            {
                if (sourceFileName.ToLower() == destFileName.ToLower())
                    return;

                if (!File.Exists(sourceFileName))
                    return;

                DeleteFile(destFileName);
                CreateDirectoy(Path.GetDirectoryName(destFileName));

                File.Copy(sourceFileName, destFileName, overwrite);
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"複製檔案失敗。{ex.Message}: {sourceFileName} to {destFileName}");
            }
        }

        /// <summary>
        /// 複製檔案。
        /// </summary>
        /// <param name="sourceFileName">要移動的檔案名稱。</param>
        /// <param name="destFileName">檔案的新路徑和名稱。</param>
        public static void CopyFile(string sourceFileName, string destFileName)
        {
            CopyFile(sourceFileName, destFileName, false);
        }

        /// <summary>
        /// 檢查檔案是否存在。
        /// </summary>
        /// <param name="fileName">檔案名稱。</param>
        /// <returns>存在=true；不存在或檔案名稱錯誤=false。</returns>
        public static bool IsFileExist(string fileName)
        {
            return !string.IsNullOrEmpty(fileName) && File.Exists(fileName);
        }

        /// <inheritdoc/>
        public static bool IsFileLocked(string fileName)
        {
            const int ERROR_SHARING_VIOLATION = 32;
            const int ERROR_LOCK_VIOLATION = 33;

            try
            {
                using (File.Open(fileName, FileMode.Open, FileAccess.Write, FileShare.None))
                {
                    return false;
                }
            }
            catch (IOException ex)
            {
                int errorCode = Marshal.GetHRForException(ex) & 0xFFFF;
                return errorCode == ERROR_SHARING_VIOLATION || errorCode == ERROR_LOCK_VIOLATION;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 檢查目錄是否存在。
        /// </summary>
        /// <param name="folderPath">目錄路徑。</param>
        /// <returns>存在=true；不存在或目錄路徑錯誤=false。</returns>
        public static bool IsDirExist(string folderPath)
        {
            return !string.IsNullOrEmpty(folderPath) && Directory.Exists(folderPath);
        }

        /// <summary>
        /// 移動指定的檔案至新的位置。
        /// </summary>
        /// <param name="sourceFileName">要移動的檔案名稱。</param>
        /// <param name="destFileName">檔案的新路徑和名稱。</param>
        ///// <param name="overwrite">是否可以覆寫目的檔案？可=true；否=false。</param>
        public static void MoveFile(string sourceFileName, string destFileName)
        {
            try
            {
                if (string.Equals(sourceFileName, destFileName, StringComparison.CurrentCultureIgnoreCase))
                    return;

                if (!File.Exists(sourceFileName))
                    return;

                DeleteFile(destFileName);
                CreateDirectoy(Path.GetDirectoryName(destFileName));

                File.Move(sourceFileName, destFileName);
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"移動檔案失敗。{ex.Message}: {sourceFileName} to {destFileName}");
            }
        }

        ///// <summary>
        ///// 移動指定的檔案至新的位置。
        ///// </summary>
        ///// <param name="sourceFileName">要移動的檔案名稱。</param>
        ///// <param name="destFileName">檔案的新路徑和名稱。</param>
        //public static void MoveFile(string sourceFileName, string destFileName)
        //{
        //    MoveFile(sourceFileName, destFileName, false);
        //}

        /// <summary>
        /// 移動檔案或目錄和其內容到新位置。
        /// </summary>
        /// <param name="sourceDirName">要移動的檔案或目錄的路徑。</param>
        /// <param name="destDirName">目標目錄的檔案或目錄的路徑。</param>
        public static void MovePath(string sourceDirName, string destDirName)
        {
            try
            {
                if (sourceDirName.ToLower() == destDirName.ToLower())
                    return;

                if (!Directory.Exists(sourceDirName))
                    return;

                ClearOrCreateDir(destDirName);

                Directory.Move(sourceDirName, destDirName);
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"複製檔案失敗。{ex.Message}: {sourceDirName} to {destDirName}");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceDirName"></param>
        /// <param name="destDirName">目標目錄的路徑。</param>
        public static void MovePath_copy_delete(string sourceDirName, string destDirName)
        {
            try
            {
                if (sourceDirName.ToLower() == destDirName.ToLower())
                    return;

                if (!Directory.Exists(sourceDirName))
                    return;

                ClearOrCreateDir(destDirName);

                MoveDirectory(sourceDirName, destDirName);
                if (DiskTypeInfo == "Disk")
                    DeleteDir(sourceDirName);
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"複製刪除檔案失敗-{sourceDirName}:{destDirName}");
            }
        }

        /// <summary>
        /// 移動整個目錄。
        /// </summary>
        /// <param name="sourceDirName"></param>
        /// <param name="destDirName"></param>
        public static void MoveDirectory(string sourceDirName, string destDirName)
        {
            if (string.Equals(sourceDirName, destDirName, StringComparison.CurrentCultureIgnoreCase))
                return;

            if (!Directory.Exists(sourceDirName))
                return;

            var source = new DirectoryInfo(sourceDirName);
            var target = new DirectoryInfo(destDirName);

            if (target.FullName.StartsWith(source.FullName, StringComparison.CurrentCultureIgnoreCase))
                throw new Exception("父目錄不能複製到子目錄！");

            if (!source.Exists)
                return;

            if (!target.Exists)
                target.Create();

            FileInfo[] files = source.GetFiles();
            foreach (var file in files)
            {
                if (DiskTypeInfo == "Disk")
                    File.Move(file.FullName, target.FullName + @"\" + file.Name);
                else
                    File.Copy(file.FullName, target.FullName + @"\" + file.Name);
            }

            DirectoryInfo[] dirs = source.GetDirectories();
            foreach (var dir in dirs)
                MoveDirectory(dir.FullName, target.FullName + @"\" + dir.Name);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="srcDir"></param>
        /// <param name="tgtDir"></param>
        /// <exception cref="Exception"></exception>
        public static void CopyDirectory(string srcDir, string tgtDir)
        {
            if (srcDir.ToLower() == tgtDir.ToLower())
                return;

            if (!Directory.Exists(srcDir))
                return;

            var source = new DirectoryInfo(srcDir);
            var target = new DirectoryInfo(tgtDir);

            if (target.FullName.StartsWith(source.FullName, StringComparison.CurrentCultureIgnoreCase))
                throw new Exception("父目錄不能複製到子目錄！");

            if (!source.Exists)
                return;

            if (!target.Exists)
                target.Create();

            FileInfo[] files = source.GetFiles();

            foreach (var file in files)
                File.Copy(file.FullName, target.FullName + @"\" + file.Name, true);

            DirectoryInfo[] dirs = source.GetDirectories();

            foreach (var dir in dirs)
                CopyDirectory(dir.FullName, target.FullName + @"\" + dir.Name);
        }

        /// <summary>
        /// 刪除指定的檔案。
        /// </summary>
        /// <param name="fileName"></param>
        public static void DeleteFile(string fileName)
        {
            try
            {
                DeleteFile(new FileInfo(fileName));
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"檔案刪除失敗。{ex.Message}: {fileName}");
            }
        }

        /// <summary>
        /// 刪除指定的檔案。
        /// </summary>
        /// <param name="fi">FileInfo物件。</param>
        public static void DeleteFile(FileInfo fi)
        {
            try
            {
                if (fi.Exists)
                {
                    if (fi.Attributes.ToString().IndexOf("ReadOnly") != -1)
                        fi.Attributes = FileAttributes.Normal;
                    File.Delete(fi.FullName);

                    fi.Delete();
                }
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"檔案刪除失敗。{ex.Message}: {fi.FullName}");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        public static void CreateDirectoyFromFileName(string fileName)
        {
            try
            {
                string path = Path.GetDirectoryName(fileName);
                if (!new DirectoryInfo(path).Exists)
                    Directory.CreateDirectory(path);
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"目錄建立失敗。{ex.Message}: {fileName}");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileName"></param>
        public static void CreateDirectoyByFileName(string fileName)
        {
            try
            {
                string dir = Path.GetDirectoryName(fileName);
                CreateDirectoy(dir);
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"由檔案建立目錄失敗。{ex.Message}: {fileName}");
            }
        }

        /// <summary>
        /// 建立目錄。
        /// </summary>
        /// <param name="dirPath">要建立的目錄。</param>
        public static void CreateDirectoy(string dirPath)
        {
            try
            {
                if (!new DirectoryInfo(dirPath).Exists)
                    Directory.CreateDirectory(dirPath);
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"目錄建立失敗。{ex.Message}: {dirPath}");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        /// <param name="searchOption"></param>
        /// <returns></returns>
        public static string[] GetAllSubDirs(string path, SearchOption searchOption)
        {
            string[] all = null;
            try
            {
                all = Directory.GetDirectories(path, "*", searchOption);
            }
            catch
            {
                // ignored
            }

            return all;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="root"></param>
        /// <returns></returns>
        public static List<string> GetAllPureSubDirs(string root)
        {
            var list = new List<string>();
            try
            {
                string[] all = Directory.GetDirectories(root, "*", SearchOption.TopDirectoryOnly);
                foreach (string path in all)
                {
                    string s = Path.GetFileName(path);
                    list.Add(s);
                }
            }
            catch
            {
                // ignored
            }

            return list;
        }

        /// <summary>
        /// 計算指定的所有檔案，其檔案大小的總和。
        /// </summary>
        /// <param name="fileNames">指定的所有檔案列表。</param>
        /// <returns>檔案的總和大小，單位為 bytes。</returns>
        public static long GetFilesSize(string[] fileNames)
        {
            return fileNames.Sum(GetFileSize);
        }

        /// <summary>
        /// 取檔指定檔案的大小。
        /// </summary>
        /// <param name="fileName">指定的檔案。</param>
        /// <returns>檔案的大小，單位為 bytes。</returns>
        public static long GetFileSize(string fileName)
        {
            if (!string.IsNullOrEmpty(fileName) && File.Exists(fileName))
                return new FileInfo(fileName).Length;
            return 0;
        }

        /// <summary>
        /// 讀取檔案內容。
        /// </summary>
        /// <param name="fileName">檔案名稱。</param>
        /// <returns>讀取的byte陣列。</returns>
        public static byte[] FileContent(string fileName)
        {
            var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            try
            {
                byte[] buffur = new byte[fs.Length];
                _ = fs.Read(buffur, 0, (int)fs.Length);

                return buffur;
            }
            catch (Exception ex)
            {
                //Log.Error(ex, $"讀取檔案位元組流失敗。{ex.Message}");
                return null;
            }
            finally
            {
                //關閉資源
                fs?.Close();
            }
        }

        /// <summary>
        /// 儲存一列文字到指定檔案。
        /// </summary>
        /// <param name="content">要儲存至檔案的內容。</param>
        /// <param name="fileName">檔案名稱。</param>
        /// <returns>儲存是否成功。</returns>
        public static bool SaveString2File(string content, string fileName)
        {
            StreamWriter sw;
            try
            {
                CreateDirectoyFromFileName(fileName);

                sw = new StreamWriter(fileName);
                sw.WriteLine(content);
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"儲存內容錯誤。{ex.Message}: {fileName}");
                return false;
            }

            sw?.Close();
            return true;
        }

        /// <summary>
        /// 從檔案讀取內容。
        /// </summary>
        /// <param name="fileName">檔案名稱。</param>
        /// <returns>讀入的內容。</returns>
        public static string LoadStringFromFile(string fileName)
        {
            string content = string.Empty;
            StreamReader sr = null;
            try
            {
                sr = new StreamReader(fileName, System.Text.Encoding.UTF8);
                content = sr.ReadToEnd();
            }
            catch (Exception ex)
            {
                PrintExcetpion(ex, $"讀取內容錯誤-{fileName}");
            }

            sr?.Close();
            return content;
        }

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="lastPath"></param>
        ///// <param name="displayName"></param>
        ///// <param name="typeNames"></param>
        ///// <returns></returns>
        //public static string GetLocalFileName(string lastPath, string displayName, string[] typeNames)
        //{
        //    // "動畫(.flc;.fli;.gif;.swf)|*.flc;*.fli;*.gif;*.swf|Animation(.flc,.fli)|*.flc;*.fli|Gif89a(.gif)|*.gif|SWF(*.swf)|*.swf|"
        //    // displayName + "(*.epub|All files (*.*)|*.*";
        //    string filter = displayName + "(";
        //    filter = typeNames.Aggregate(filter, (current, ext) => current + ("." + ext + ";"));
        //    filter += ")|";
        //    for (int i = 0; i < typeNames.Length; i++)
        //    {
        //        filter += "*." + typeNames[i];
        //        if (i < typeNames.Length - 1)
        //            filter += ";";
        //    }

        //    OpenFileDialog ofd = new()
        //    {
        //        InitialDirectory = lastPath,
        //        Filter = filter,
        //        RestoreDirectory = true,
        //    };

        //    return (bool)ofd.ShowDialog() ? string.Empty : ofd.FileName;
        //}

        /// <summary>
        /// 獲取差異的檔案列表。
        /// </summary>
        /// <param name="sourceDir"></param>
        /// <param name="destDir"></param>
        /// <returns></returns>
        public static List<string> GetNotSameFiles(string sourceDir, string destDir)
        {
            var oldData = new List<string>();
            var newData = new List<string>();
            new DirectoryInfo(sourceDir).GetFiles().ToList().ForEach((f) =>
            {
                newData.Add(f.Name);
            });

            new DirectoryInfo(destDir).GetFiles().ToList().ForEach((f) =>
            {
                oldData.Add(f.Name);
            });

            //求交集
            var dupComparer = new InlineComparer<string>((i1, i2) => i1.Equals(i2), i => i.GetHashCode());
            var _IntersectData = oldData.Intersect(newData, dupComparer);

            if (_IntersectData == null || !_IntersectData.Any())
                return null;

            // 處理交集檔案里可能有差異的內容。
            var _files = new List<string>();

            // 通過md5先過濾一部分數據 然後找到有差異的檔案列表
            _IntersectData.ToList().ForEach((s) =>
            {
                var omd5 = Path.Combine(destDir, s).GetMD5Hash();
                var nmd5 = Path.Combine(sourceDir, s).GetMD5Hash();

                if (!omd5.Equals(nmd5))
                    _files.Add(s);
            });

            return _files;
        }

        /// <summary>
        /// 獲取root目錄下所有的檔案,包含子目錄中的檔案。
        /// </summary>
        /// <param name="root">目錄路徑</param>
        /// <param name="extension">副檔名,預設為所有檔案</param>
        /// <returns>root目錄下所有的檔案的列表</returns>
        public static List<string> GetAllFileList(string root, string extension = "")
        {
            if (Directory.Exists(root))
            {
                var dirList = GetAllSubDirs(root, SearchOption.AllDirectories).ToList();
                dirList.Add(root);

                var list = new List<string>();

                foreach (var dir in dirList)
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(dir);
                    dirInfo.GetFiles().ToList().ForEach(f =>
                    {
                        if (!string.IsNullOrWhiteSpace(extension))
                        {
                            if (f.Extension == (extension.Contains(".") ? extension : "." + extension))
                                list.Add(f.FullName);
                        }
                        else
                        {
                            list.Add(f.FullName);
                        }
                    });
                }

                return list;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        public class InlineComparer<T> : IEqualityComparer<T>
        {
            private readonly Func<T, T, bool> getEquals;
            private readonly Func<T, int> getHashCode;

            public InlineComparer(Func<T, T, bool> equals, Func<T, int> hashCode)
            {
                getEquals = equals;
                getHashCode = hashCode;
            }

            public bool Equals(T x, T y)
            {
                return getEquals(x, y);
            }

            public int GetHashCode(T obj)
            {
                return getHashCode(obj);
            }
        }
    }
}
