﻿using System.Text.RegularExpressions;

namespace RaphaelWu.CSharp.IO
{
    /// <summary>
    /// 檔案名稱或資料夾名稱有效化。
    /// </summary>
    /// <remarks>程式碼來源: <see href="https://blog.miniasp.com/post/2009/10/19/How-to-ensure-filename-and-foldername-is-valid">如何確保寫入檔案時「檔案名稱」與「目錄名稱」正確無誤</see>。</remarks>
    public static class MakeFilePathValid
    {
        /// <summary>
        /// 檔案名稱有效化。
        /// </summary>
        /// <param name="filename">待有效化的檔案名稱。</param>
        /// <param name="assemblyName">。</param>
        /// <returns>有效化後的檔案名稱。</returns>
        public static string MakeFilenameValid(string filename, string assemblyName = "")
        {
            List<char> invalidFileChars = new List<char>();

            if (string.IsNullOrWhiteSpace(filename))
                throw new ArgumentNullException(filename);

            if (filename.EndsWith("."))
                filename = Regex.Replace(filename, @"\.+$", "");

            if (filename.Length > 245)
                throw new PathTooLongException(filename);

            foreach (char c in Path.GetInvalidFileNameChars())
            {
                int idx = filename.IndexOf(c);
                if (idx >= 0)
                    invalidFileChars.Add(filename[idx]);
            }
            if (invalidFileChars.Count > 0)
                throw new ArgumentException(filename);

            return filename;
        }

        /// <summary>
        /// 資料夾名稱有效化。
        /// </summary>
        /// <param name="foldername">待有效化的資料夾名稱。</param>
        /// <param name="assemblyName">。</param>
        /// <returns>有效化後的資料夾名稱。</returns>
        public static string MakeFoldernameValid(string foldername, string assemblyName = "")
        {
            List<char> invalidFileChars = new List<char>();

            if (string.IsNullOrWhiteSpace(foldername))
                throw new ArgumentNullException(foldername);

            if (foldername.EndsWith("."))
                foldername = Regex.Replace(foldername, @"\.+$", "");

            if (foldername.Length > 245)
                throw new PathTooLongException(foldername);

            foreach (char c in Path.GetInvalidPathChars())
            {
                int idx = foldername.IndexOf(c);
                if (idx >= 0)
                    invalidFileChars.Add(foldername[idx]);
            }
            if (invalidFileChars.Count > 0)
                throw new ArgumentException(foldername);

            return foldername;
        }
    }
}
