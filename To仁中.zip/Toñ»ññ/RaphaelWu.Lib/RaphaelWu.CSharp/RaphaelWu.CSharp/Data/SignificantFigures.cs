﻿namespace RaphaelWu.CSharp.Data
{
    // 座標值在浮點運算後，小數部分因為二進制運算的關係，會有精度誤差產生，這裡採取自訂小數有效位數再四捨五入做法
    // 不考慮使用decimal，因其為128位元資料(double為64位元資料)，佔用太大儲存空間；
    // 而且它是十進位運算(使用Decimal結構 https://docs.microsoft.com/zh-tw/dotnet/api/system.decimal) ，效率較差，較適用10 base算術

    // 從 IEEE 754 標準來看為什麼浮點誤差是無法避免的: https://medium.com/starbugs/see-why-floating-point-error-can-not-be-avoided-from-ieee-754-809720b32175
    // IEEE-754 與浮點數運算: https://ithelp.ithome.com.tw/m/articles/10266532
    // 妥协与取舍，解构C#中的小数运算: https://www.cnblogs.com/murongxiaopifu/p/4869193.html
    // 没有神话，聊聊decimal的“障眼法”: https://www.cnblogs.com/murongxiaopifu/p/4915215.html
    // decimal 详解: https://www.jianshu.com/p/09da34ffd73f
    // C#的無條件進入、無條件捨去、跟你想的不一樣的四捨五入: https://ithelp.ithome.com.tw/articles/10213221
    // 我會呼叫何種方法？: https://learn.microsoft.com/zh-tw/dotnet/api/system.math.round?view=net-7.0#remarks
    // Banker's rounding: http://www.xbeat.net/vbspeed/i_BankersRounding.htm

    // 黑大關於decimal的文章：算錢用浮點，遲早被人扁
    // CODE-分贓程式的寫法: https://blog.darkthread.net/blog/about-money-distribution/
    // CODE-分贓程式的寫法(LINQ進化版): https://blog.darkthread.net/blog/perfect-linq-divider
    // 無尾差分贓法崩壞記: https://blog.darkthread.net/blog/perfect-divide-fixing
    // 浮點數計算結果更接近正解？: https://blog.darkthread.net/blog/float-vs-decimal-case/
    // 關於 Decimal 小數尾數零: https://blog.darkthread.net/blog/decimal-trailing-zeros/

    /// <summary>
    /// 小數的有效位數處理。
    /// </summary>
    public static class SignificantFigures
    {
        /// <summary>
        /// 有效位數格式化處理。
        /// </summary>
        /// <param name="value">待格式化的double值。</param>
        /// <param name="digit">小數點有效位數。</param>
        /// <returns>格式化完成後的double值。</returns>
        public static double Format(this double value, int digit)
        {
            return double.IsNaN(value)
                ? double.NaN
                : Math.Round(value, digit, MidpointRounding.AwayFromZero);
        }

        //// 顯示小數點時，過多整數或小數位數會自動被轉成科學記號表示，
        //// 如果不想
        //// https://www.cnblogs.com/OpenCoder/p/10938017.html

        ///// <summary>
        ///// 避免使用科學記號表示的格式字串。
        ///// </summary>
        ///// <remarks>
        ///// 用法: double.ToString(Coor.DoubleFixedPoint)<br/>
        ///// 範例: <see href="https://dotnetfiddle.net/gRUBdA"/>
        ///// </remarks>
        //public const string DoubleFixedPoint = "0.########################################";
    }
}
