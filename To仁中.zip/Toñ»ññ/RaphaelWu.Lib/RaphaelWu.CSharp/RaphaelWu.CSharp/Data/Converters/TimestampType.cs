﻿namespace RaphaelWu.CSharp.Data.Converters
{
    /// <summary>
    /// 時間戳分類。
    /// </summary>
    public enum TimestampType
    {
        Seconds,        // 以秒為計算基準
        Milliseconds    // 以毫秒為計算基準
    }
}
