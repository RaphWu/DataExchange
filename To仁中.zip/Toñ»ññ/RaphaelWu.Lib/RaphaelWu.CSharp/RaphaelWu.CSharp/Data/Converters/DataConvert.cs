﻿using System.Text;

namespace RaphaelWu.CSharp.Data.Converters
{
    /// <summary>
    /// 數據格式轉換。
    /// </summary>
    /// <remarks>參考自: <see href="https://github.com/zhaopeiym/IoTClient">zhaopeiym/IoTClient</see></remarks>
    public static class DataConvert
    {
        /// <summary>
        /// 位元組陣列 =&gt; 16進制字符，中間以指定分隔符號隔開。
        /// </summary>
        /// <param name="byteArray">要轉換的byte陣列。</param>
        /// <param name="connectString">分隔符號。</param>
        /// <returns>轉換後的十六進位字串。</returns>
        public static string ByteArrayToString(this byte[] byteArray, string connectString)
        {
            return string.Join(connectString, byteArray.Select(x => x.ToString("X2")));
        }

        /// <summary>
        /// 位元組陣列 =&gt; 16進制字符，中間以一個空白隔開。
        /// </summary>
        /// <param name="byteArray">要轉換的byte陣列。</param>
        /// <returns>轉換後的十六進位字串。</returns>
        public static string ByteArrayToString(this byte[] byteArray)
        {
            return string.Join(" ", byteArray.Select(t => t.ToString("X2")));
        }

        /// <summary>
        /// 16進制字串 =&gt; 位元組陣列。
        /// </summary>
        /// <param name="str">要轉換的字串。</param>
        /// <param name="strict">嚴格模式（嚴格按兩個字母間隔一個空格）。</param>
        /// <returns>轉換後的byte陣列。</returns>
        public static byte[] StringToByteArray(this string str, bool strict = true)
        {
            if (string.IsNullOrWhiteSpace(str) || str.Trim().Replace(" ", "").Length % 2 != 0)
                throw new ArgumentException("請傳入有效的參數");

            if (strict)
            {
                return str.Split(' ').Where(t => t?.Length == 2).Select(t => Convert.ToByte(t, 16)).ToArray();
            }
            else
            {
                str = str.Trim().Replace(" ", "");
                var list = new List<byte>();
                for (int i = 0; i < str.Length; i++)
                {
                    var string16 = str[i].ToString() + str[++i].ToString();
                    list.Add(Convert.ToByte(string16, 16));
                }
                return list.ToArray();
            }
        }

        /// <summary>
        /// ASCII字串陣列字串 =&gt; 位元組陣列。
        /// </summary>
        /// <param name="str">要轉換的字串。</param>
        /// <param name="strict">嚴格模式（嚴格按兩個字母間隔一個空格）。</param>
        /// <returns>轉換後的byte陣列。</returns>
        public static byte[] AsciiStringToByteArray(this string str, bool strict = true)
        {
            if (string.IsNullOrWhiteSpace(str) || str.Trim().Replace(" ", "").Length % 2 != 0)
                throw new ArgumentException("請傳入有效的參數");

            if (strict)
            {
                List<string> stringList = new List<string>();
                foreach (var item in str.Split(' '))
                {
                    stringList.Add(((char)Convert.ToByte(item, 16)).ToString());
                }
                return string.Join("", stringList).StringToByteArray(false);
            }
            else
            {
                str = str.Trim().Replace(" ", "");
                var stringList = new List<string>();
                for (int i = 0; i < str.Length; i++)
                {
                    var stringAscii = str[i].ToString() + str[++i].ToString();
                    stringList.Add(((char)Convert.ToByte(stringAscii, 16)).ToString());
                }
                return string.Join("", stringList).StringToByteArray(false);
            }
        }

        /// <summary>
        /// ASCII陣列字串 =&gt; 位元組陣列。<br/>
        /// 如：30 31 =&gt; 00 01
        /// </summary>
        /// <param name="strict">嚴格模式（嚴格按兩個字母間隔一個空格）。</param>
        /// <param name="str">要轉換的字串陣列。</param>
        /// <returns>轉換後的byte陣列。</returns>
        public static byte[] AsciiArrayToByteArray(this byte[] str)
        {
            if (!str?.Any() ?? true)
                throw new ArgumentException("請傳入有效的參數");

            List<string> stringList = new List<string>();
            foreach (var item in str)
            {
                stringList.Add(((char)item).ToString());
            }
            return string.Join("", stringList).StringToByteArray(false);
        }

        /// <summary>
        /// 位元組陣列 =&gt; ASCII位元組陣列。<br/>
        /// 如：00 01 =&gt; 30 31
        /// </summary>
        /// <param name="str">要轉換的byte陣列。</param>
        /// <returns>將每個byte以ASCII表示後的byte陣列。</returns>
        public static byte[] ByteArrayToAsciiArray(this byte[] str)
        {
            return Encoding.ASCII.GetBytes(string.Join("", str.Select(t => t.ToString("X2"))));
        }

        /// <summary>
        /// Int =&gt; 二進制。
        /// </summary>
        /// <param name="value">要轉換的整數。</param>
        /// <returns>轉換後的二進制值(以字串表示)。</returns>
        public static string IntToBinaryArray(this int value)
        {
            //Convert.ToString(12,2); // 將12 => 為2進制字串，結果 “1100”
            return Convert.ToString(value, 2);
        }

        /// <summary>
        /// 二進制 =&gt; Int。
        /// </summary>
        /// <param name="value">要轉換的二進制值(以字串表示)。</param>
        /// <returns>轉換後的整數。</returns>
        public static int BinaryArrayToInt(this string value)
        {
            //Convert.ToInt("1100",2); // 將2進制字串 => 為整數，結果 12
            return Convert.ToInt32(value, 2);
        }
    }
}
