﻿namespace RaphaelWu.CSharp.Data.Converters
{
    /// <summary>
    /// 日期時間轉換。
    /// </summary>
    /// <remarks>
    /// 參考資料：<br/>
    /// <see href="https://learn.microsoft.com/zh-tw/dotnet/standard/datetime/choosing-between-datetime">選擇 DateTime、DateOnly、DateTimeOffset、TimeSpan、TimeOnly 和 TimeZoneInfo</see>。<br/>
    /// <see href="https://learn.microsoft.com/zh-tw/dotnet/standard/datetime/converting-between-time-zones">在各時區間轉換時間</see>。<br/>
    /// </remarks>
    public static class DateTimeConvert
    {
        //private const string UnixTimestampFormatError = "Unix時間戳格式錯誤！";
        //private const string LinuxTimestampFormatError = "Linux時間戳格式錯誤！";
        //private const string DateTimeFormatError = "日間/時間格式錯誤！";

        /********************
         * 國際標準時間 (UTC)
         ********************/





        /********************
         * Unix時間戳
         ********************/
        /// <summary>
        /// 取得目前的Unix時間戳。
        /// </summary>
        /// <param name="type">時間戳分類。</param>
        /// <returns>Unix時間戳。</returns>
        public static long GetUnixTimestamp(TimestampType type)
        {
            if (type == TimestampType.Seconds)
                return DateTimeOffset.Now.ToUnixTimeSeconds();
            else if (type == TimestampType.Milliseconds)
                return DateTimeOffset.Now.ToUnixTimeMilliseconds();
            else
                return -1;
        }

        /// <summary>
        /// 取得目前的Unix時間戳。
        /// </summary>
        /// <returns>Unix時間戳(秒)。</returns>
        public static long GetUnixTimestamp()
        {
            return DateTimeOffset.Now.ToUnixTimeSeconds();
        }

        /// <summary>
        /// 將Local DateTime轉換成Unix時間戳。
        /// </summary>
        /// <param name="time">Local DateTime。</param>
        /// <param name="type">時間戳分類。</param>
        /// <returns>Unix時間戳。</returns>
        public static long ToUnixTimestamp(this DateTime time, TimestampType type, TimeSpan timeZone)
        {
            try
            {
                var dto = new DateTimeOffset(time, timeZone);
                if (type == TimestampType.Seconds)
                    return dto.ToUnixTimeSeconds();
                else if (type == TimestampType.Milliseconds)
                    return dto.ToUnixTimeMilliseconds();
                else
                    return -1;
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// 將DateTimeOffset轉換成Unix時間戳。
        /// </summary>
        /// <param name="time">DateTimeOffset。</param>
        /// <returns>Unix時間戳(秒)。</returns>
        public static long ToUnixTimestamp(this DateTime time, TimeSpan timeZone)
        {
            try
            {
                var offnd = new DateTimeOffset(time, timeZone);
                return offnd.ToUnixTimeSeconds();
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// 將Unix時間戳轉換成Local DateTime。
        /// </summary>
        /// <param name="timeStamp">Unix時間戳。</param>
        /// <param name="type">時間戳分類。</param>
        /// <param name="time">Local DateTime。</param>
        /// <returns>轉換是否成功。</returns>
        public static bool LocalFromUnixTimestamp(this long timeStamp, TimestampType type, out DateTime time)
        {
            bool success = timeStamp.UnixTimestampToDateTime(type, out DateTimeOffset dto);
            time = success ? dto.LocalDateTime : DateTime.MinValue;
            return success;
        }

        /// <summary>
        /// 將Unix時間戳轉換成Local DateTime。
        /// </summary>
        /// <param name="timeStamp">Unix時間戳(秒)。</param>
        /// <param name="time">Local DateTime(秒)。</param>
        /// <returns>轉換是否成功。</returns>
        public static bool LocalFromUnixTimestamp(this long timeStamp, out DateTime time)
        {
            bool success = timeStamp.UnixTimestampToDateTime(TimestampType.Seconds, out DateTimeOffset dto);
            time = success ? dto.LocalDateTime : DateTime.MinValue;
            return success;
        }

        /// <summary>
        /// 將Unix時間戳轉換成UTC DateTime。
        /// </summary>
        /// <param name="timeStamp">Unix時間戳。</param>
        /// <param name="type">時間戳分類。</param>
        /// <param name="time">UTC DateTime。</param>
        /// <returns>轉換是否成功。</returns>
        public static bool UtcFromUnixTimestamp(this long timeStamp, TimestampType type, out DateTime time)
        {
            bool success = timeStamp.UnixTimestampToDateTime(type, out DateTimeOffset dto);
            time = success ? dto.UtcDateTime : DateTime.MinValue;
            return success;
        }

        /// <summary>
        /// 將Unix時間戳轉換成UTC DateTime。
        /// </summary>
        /// <param name="timeStamp">Unix時間戳(秒)。</param>
        /// <param name="time">UTC DateTime(秒)。</param>
        /// <returns>轉換是否成功。</returns>
        public static bool UtcFromUnixTimestamp(this long timeStamp, out DateTime time)
        {
            bool success = timeStamp.UnixTimestampToDateTime(TimestampType.Seconds, out DateTimeOffset dto);
            time = success ? dto.UtcDateTime : DateTime.MinValue;
            return success;
        }

        /// <summary>
        /// 時間戳轉時間。
        /// </summary>
        /// <param name="timeStamp">時間戳。</param>
        /// <param name="type">時間戳分類。</param>
        /// <param name="time">DateTimeOffset。</param>
        /// <returns>轉換是否成功。</returns>
        private static bool UnixTimestampToDateTime(this long timeStamp, TimestampType type, out DateTimeOffset time)
        {
            try
            {
                if (type == TimestampType.Seconds)
                {
                    time = DateTimeOffset.FromUnixTimeSeconds(timeStamp);
                    return true;
                }
                else if (type == TimestampType.Milliseconds)
                {
                    time = DateTimeOffset.FromUnixTimeMilliseconds(timeStamp);
                    return true;
                }
                else
                {
                    time = default;
                    return false;
                }
            }
            catch
            {
                time = default;
                return false;
            }
        }

        /********************
         * Linux時間戳
         ********************/
        /// <summary>
        /// 將Local DateTime轉換成Linux時間戳。
        /// </summary>
        /// <param name="time">要轉換的Local DateTime。</param>
        /// <returns>Linux時間戳。</returns>
        public static long LocalToLinuxTimestamp(this DateTime time)
        {
            DateTime dtStart = new DateTime(1970, 1, 1);
            TimeSpan ts = time - dtStart;
            return (long)ts.TotalMilliseconds;
        }

        /// <summary>
        /// 將Linux時間戳轉換成Local DateTime。
        /// </summary>
        /// <param name="totalMilliseconds">要轉換的Linux時間戳。</param>
        /// <returns>Local DateTime。</returns>
        public static DateTime LocalFromLinuxTimestamp(this long totalMilliseconds)
        {
            DateTime dtStart = new DateTime(1970, 1, 1);
            return dtStart.AddMilliseconds(totalMilliseconds);
        }

        /// <summary>
        /// 將UTC DateTime轉換成Linux時間戳。
        /// </summary>
        /// <param name="time">要轉換的UTC DateTime。</param>
        /// <returns>Linux時間戳。</returns>
        public static long UtcToLinuxTimestamp(this DateTime time)
        {
            DateTime dtStart = new DateTime(1970, 1, 1);
            TimeSpan ts = time.Add(Constants.LocalTimeZone) - dtStart;
            return (long)ts.TotalMilliseconds;
        }

        /// <summary>
        /// 將Linux時間戳轉換成UTC DateTime。
        /// </summary>
        /// <param name="totalMilliseconds">要轉換的Linux時間戳。</param>
        /// <returns>UTC DateTime。</returns>
        public static DateTime UtcFromLinuxTimestamp(this long totalMilliseconds)
        {
            DateTime dtStart = new DateTime(1970, 1, 1);
            return dtStart.AddMilliseconds(totalMilliseconds).ToUniversalTime();
        }
    }
}
