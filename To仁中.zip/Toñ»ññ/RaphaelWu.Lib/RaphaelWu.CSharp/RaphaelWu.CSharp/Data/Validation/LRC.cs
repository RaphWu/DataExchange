﻿namespace RaphaelWu.CSharp.Data.Validation
{
    /// <summary>
    /// 縱向冗餘校驗（Longitudinal Redundancy Check，LRC）
    /// </summary>
    /// <remarks>程式碼來源: <see href="https://github.com/zhaopeiym/IoTClient/blob/master/IoTClient/Common/Helpers/LRC.cs">IoTClient/IoTClient/Common/Helpers/LRC.cs</see></remarks>
    public static class LRC
    {
        /// <summary>
        /// 取得LRC值。
        /// </summary>
        /// <param name="value">。</param>
        /// <returns>LRC校驗值。</returns>
        public static byte[] GetLRC(byte[] value)
        {
            if (value == null) return null;

            int sum = 0;
            for (int i = 0; i < value.Length; i++)
            {
                sum += value[i];
            }

            sum %= 256;
            sum = 256 - sum;

            byte[] LRC = new byte[] { (byte)sum };
            return value.Concat(LRC).ToArray();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value">。</param>
        /// <returns>。</returns>
        public static bool CheckLRC(byte[] value)
        {
            if (value == null)
                throw new ArgumentNullException(null, "參數為null");

            int length = value.Length;
            byte[] buffer = new byte[length - 1];
            Array.Copy(value, 0, buffer, 0, buffer.Length);

            byte[] LRCbuf = GetLRC(buffer);
            if (LRCbuf[length - 1] == value[length - 1])
            {
                return true;
            }
            return false;
        }
    }
}
