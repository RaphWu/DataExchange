﻿namespace RaphaelWu.CSharp.Data.Validation
{
    /// <summary>
    /// 循環冗餘校驗（Cyclic redundancy check，CRC）
    /// </summary>
    /// <remarks>版權聲明: 此CRC.cs中的程式碼版權屬於作者 <see href="https://blog.csdn.net/qq_40374647?type=blog">若汝棋茗</see> 所有。<br/>
    /// 程式碼來源: <see href="https://github.com/RRQM/TouchSocket/blob/master/src/TouchSocket/Core/Data/Crc.cs">TouchSocket/src/TouchSocket/Core/Data/Crc.cs</see><br/>
    /// 參考資料: <see href="https://en.wikipedia.org/wiki/Cyclic_redundancy_check">Cyclic redundancy check</see>。
    /// </remarks>
    public static class CRC
    {
        /// <summary>
        /// Name: CRC-4/ITU : x4+x+1<br/>
        /// Poly: 0x03<br/>
        /// Init: 0x00<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x00
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC1(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0;
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (byte)(crc >> 1 ^ 0x0C);    // 0x0C = (reverse 0x03)>>(8-4)
                    else
                        crc = (byte)(crc >> 1);
                }
            }
            return new byte[] { crc };
        }

        /// <summary>
        /// Name: CRC-5/EPC : x5+x3+1<br/>
        /// Poly: 0x09<br/>
        /// Init: 0x09<br/>
        /// Refin: false<br/>
        /// Refout: false<br/>
        /// Xorout: 0x00
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC2(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0x48;// Initial value: 0x48 = 0x09<<(8-5)
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x80) > 0)
                        crc = (byte)(crc << 1 ^ 0x48);// 0x48 = 0x09<<(8-5)
                    else
                        crc = (byte)(crc << 1);
                }
            }
            return new byte[] { (byte)(crc >> 3) };
        }

        /// <summary>
        /// Name: CRC-5/ITU : x5+x4+x2+1<br/>
        /// Poly: 0x15<br/>
        /// Init: 0x00<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x00
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC3(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (byte)(crc >> 1 ^ 0x15);// 0x15 = (reverse 0x15)>>(8-5)
                    else
                        crc = (byte)(crc >> 1);
                }
            }
            return new byte[] { crc };
        }

        /// <summary>
        /// Name: CRC-5/USB : x5+x2+1<br/>
        /// Poly: 0x05<br/>
        /// Init: 0x1F<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x1F
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC4(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0x1F;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (byte)(crc >> 1 ^ 0x14);// 0x14 = (reverse 0x05)>>(8-5)
                    else
                        crc = (byte)(crc >> 1);
                }
            }
            return new byte[] { (byte)(crc ^ 0x1F) };
        }

        /// <summary>
        /// Name: CRC-6/ITU : x6+x+1<br/>
        /// Poly: 0x03<br/>
        /// Init: 0x00<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x00
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC5(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (byte)(crc >> 1 ^ 0x30);// 0x30 = (reverse 0x03)>>(8-6)
                    else
                        crc = (byte)(crc >> 1);
                }
            }
            return new byte[] { crc };
        }

        /// <summary>
        /// Name: CRC-7/MMC : x7+x3+1<br/>
        /// Poly: 0x09<br/>
        /// Init: 0x00<br/>
        /// Refin: false<br/>
        /// Refout: false<br/>
        /// Xorout: 0x00
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC6(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x80) > 0)
                        crc = (byte)(crc << 1 ^ 0x12);// 0x12 = 0x09<<(8-7)
                    else
                        crc = (byte)(crc << 1);
                }
            }
            return new byte[] { (byte)(crc >> 1) };
        }

        /// <summary>
        /// Name: CRC8 : x8+x2+x+1<br/>
        /// Poly: 0x07<br/>
        /// Init: 0x00<br/>
        /// Refin: false<br/>
        /// Refout: false<br/>
        /// Xorout: 0x00
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC7(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x80) > 0)
                        crc = (byte)(crc << 1 ^ 0x07);
                    else
                        crc = (byte)(crc << 1);
                }
            }
            return new byte[] { crc };
        }

        /// <summary>
        /// Name: CRC-8/ITU : x8+x2+x+1<br/>
        /// Poly: 0x07<br/>
        /// Init: 0x00<br/>
        /// Refin: false<br/>
        /// Refout: false<br/>
        /// Xorout: 0x55
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC8(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x80) > 0)
                        crc = (byte)(crc << 1 ^ 0x07);
                    else
                        crc = (byte)(crc << 1);
                }
            }
            return new byte[] { (byte)(crc ^ 0x55) };
        }

        /// <summary>
        /// Name: CRC-8/MAXIM : x8+x5+x4+1<br/>
        /// Poly: 0x31<br/>
        /// Init: 0x00<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x00
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC9(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (byte)(crc >> 1 ^ 0x8C);// 0x8C = reverse 0x31
                    else
                        crc = (byte)(crc >> 1);
                }
            }
            return new byte[] { crc };
        }

        /// <summary>
        /// Name: CRC-8/ROHC : x8+x2+x+1<br/>
        /// Poly: 0x07<br/>
        /// Init: 0xFF<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x00
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC10(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            byte crc = 0xFF;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (byte)(crc >> 1 ^ 0xE0);// 0xE0 = reverse 0x07
                    else
                        crc = (byte)(crc >> 1);
                }
            }
            return new byte[] { crc };
        }

        /// <summary>
        /// Z1協議校驗碼計算
        /// </summary>
        private static readonly byte[] table = { 0x00, 0x1C, 0x38, 0x24, 0x70, 0x6C, 0x48, 0x54, 0xE0, 0xFC,
                                             0xD8, 0xC4, 0x90, 0x8C, 0xA8, 0xB4, 0xDC, 0xC0, 0xE4, 0xF8,
                                             0xAC, 0xB0, 0x94, 0x88, 0x3C, 0x20, 0x04, 0x18, 0x4C, 0x50,
                                             0x74, 0x68, 0xA4, 0xB8, 0x9C, 0x80, 0xD4, 0xC8, 0xEC, 0xF0,
                                             0x44, 0x58, 0x7C, 0x60, 0x34, 0x28, 0x0C, 0x10, 0x78, 0x64,
                                             0x40, 0x5C, 0x08, 0x14, 0x30, 0x2C, 0x98, 0x84, 0xA0, 0xBC,
                                             0xE8, 0xF4, 0xD0, 0xCC, 0x54, 0x48, 0x6C, 0x70, 0x24, 0x38,
                                             0x1C, 0x00, 0xB4, 0xA8, 0x8C, 0x90, 0xC4, 0xD8, 0xFC, 0xE0,
                                             0x88, 0x94, 0xB0, 0xAC, 0xF8, 0xE4, 0xC0, 0xDC, 0x68, 0x74,
                                             0x50, 0x4C, 0x18, 0x04, 0x20, 0x3C, 0xF0, 0xEC, 0xC8, 0xD4,
                                             0x80, 0x9C, 0xB8, 0xA4, 0x10, 0x0C, 0x28, 0x34, 0x60, 0x7C,
                                             0x58, 0x44, 0x2C, 0x30, 0x14, 0x08, 0x5C, 0x40, 0x64, 0x78,
                                             0xCC, 0xD0, 0xF4, 0xE8, 0xBC, 0xA0, 0x84, 0x98, 0xA8, 0xB4,
                                             0x90, 0x8C, 0xD8, 0xC4, 0xE0, 0xFC, 0x48, 0x54, 0x70, 0x6C,
                                             0x38, 0x24, 0x00, 0x1C, 0x74, 0x68, 0x4C, 0x50, 0x04, 0x18,
                                             0x3C, 0x20, 0x94, 0x88, 0xAC, 0xB0, 0xE4, 0xF8, 0xDC, 0xC0,
                                             0x0C, 0x10, 0x34, 0x28, 0x7C, 0x60, 0x44, 0x58, 0xEC, 0xF0,
                                             0xD4, 0xC8, 0x9C, 0x80, 0xA4, 0xB8, 0xD0, 0xCC, 0xE8, 0xF4,
                                             0xA0, 0xBC, 0x98, 0x84, 0x30, 0x2C, 0x08, 0x14, 0x40, 0x5C,
                                             0x78, 0x64, 0xFC, 0xE0, 0xC4, 0xD8, 0x8C, 0x90, 0xB4, 0xA8,
                                             0x1C, 0x00, 0x24, 0x38, 0x6C, 0x70, 0x54, 0x48, 0x20, 0x3C,
                                             0x18, 0x04, 0x50, 0x4C, 0x68, 0x74, 0xC0, 0xDC, 0xF8, 0xE4,
                                             0xB0, 0xAC, 0x88, 0x94, 0x58, 0x44, 0x60, 0x7C, 0x28, 0x34,
                                             0x10, 0x0C, 0xB8, 0xA4, 0x80, 0x9C, 0xC8, 0xD4, 0xF0, 0xEC,
                                             0x84, 0x98, 0xBC, 0xA0, 0xF4, 0xE8, 0xCC, 0xD0, 0x64, 0x78,
                                             0x5C, 0x40, 0x14, 0x08, 0x2C, 0x30
                                             };

        /// <summary>
        /// CRC11
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC11(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            int i;
            byte crc = 0x00;
            int tableIndex;
            for (i = start; i < length; i++)
            {
                tableIndex = crc ^ buffer[i] & 0xFF;
                crc = table[tableIndex];
            }
            return new byte[] { crc };
        }

        /// <summary>
        /// Name: CRC-12 : x16+x12+x5+1<br/>
        /// Poly: 0x80<br/>
        /// Init: 0x0000<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x0000
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC12(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0;// Initial value
            short iQ = 0, iR = 0;
            for (int i = start; i < length; i++)
            {
                // 多项式除法
                // 如果该位为1
                if ((buffer[i] & 0x80 >> iR) > 0)
                {
                    // 则在余数尾部添1否则添0
                    crc |= 0x01;
                }
                // 如果12位除数中的最高位为1，则够除
                if (crc >= 0x1000)
                {
                    crc ^= 0x180D;
                }
                crc <<= 1;
                iR++;
                if (8 == iR)
                {
                    iR = 0;
                    iQ++;
                }
            }
            // 对后面添加的12个0做处理
            for (int i = 0; i < 12; i++)
            {
                if (crc >= 0x1000)
                {
                    crc ^= 0x180D;
                }
                crc <<= 1;
            }
            crc >>= 1;
            byte[] ret = BitConverter.GetBytes(crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/CCITT : x16+x12+x5+1<br/>
        /// Poly: 0x1021<br/>
        /// Init: 0x0000<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x0000
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC13(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (ushort)(crc >> 1 ^ 0x8408);// 0x8408 = reverse 0x1021
                    else
                        crc = (ushort)(crc >> 1);
                }
            }
            byte[] ret = BitConverter.GetBytes(crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/CCITT FALSE : x16+x12+x5+1<br/>
        /// Poly: 0x1021<br/>
        /// Init: 0xFFFF<br/>
        /// Refin: false<br/>
        /// Refout: false<br/>
        /// Xorout: 0x0000
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC14(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0xFFFF;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= (ushort)(buffer[i] << 8);
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x8000) > 0)
                        crc = (ushort)(crc << 1 ^ 0x1021);
                    else
                        crc = (ushort)(crc << 1);
                }
            }
            byte[] ret = BitConverter.GetBytes(crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/DNP : x16+x13+x12+x11+x10+x8+x6+x5+x2+1<br/>
        /// Poly: 0x3D65<br/>
        /// Init: 0x0000<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0xFFFF
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC15(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (ushort)(crc >> 1 ^ 0xA6BC);// 0xA6BC = reverse 0x3D65
                    else
                        crc = (ushort)(crc >> 1);
                }
            }
            byte[] ret = BitConverter.GetBytes((ushort)~crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/IBM : x16+x15+x2+1<br/>
        /// Poly: 0x8005<br/>
        /// Init: 0x0000<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x0000
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC16(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (ushort)(crc >> 1 ^ 0xA001);// 0xA001 = reverse 0x8005
                    else
                        crc = (ushort)(crc >> 1);
                }
            }
            byte[] ret = BitConverter.GetBytes(crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/MAXIM : x16+x15+x2+1<br/>
        /// Poly: 0x8005<br/>
        /// Init: 0x0000<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0xFFFF
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC17(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (ushort)(crc >> 1 ^ 0xA001);// 0xA001 = reverse 0x8005
                    else
                        crc = (ushort)(crc >> 1);
                }
            }
            byte[] ret = BitConverter.GetBytes((ushort)~crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/MODBUS : x16+x15+x2+1<br/>
        /// Poly: 0x8005<br/>
        /// Init: 0xFFFF<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0x0000
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC18(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0xFFFF;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (ushort)(crc >> 1 ^ 0xA001);// 0xA001 = reverse 0x8005
                    else
                        crc = (ushort)(crc >> 1);
                }
            }
            byte[] ret = BitConverter.GetBytes(crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/USB : x16+x15+x2+1<br/>
        /// Poly: 0x8005<br/>
        /// Init: 0xFFFF<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0xFFFF
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC19(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0xFFFF;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (ushort)(crc >> 1 ^ 0xA001);// 0xA001 = reverse 0x8005
                    else
                        crc = (ushort)(crc >> 1);
                }
            }
            byte[] ret = BitConverter.GetBytes((ushort)~crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/X25 : x16+x12+x5+1<br/>
        /// Poly: 0x1021<br/>
        /// Init: 0xFFFF<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0xFFFF
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC20(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0xFFFF;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = (ushort)(crc >> 1 ^ 0x8408);// 0x8408 = reverse 0x1021
                    else
                        crc = (ushort)(crc >> 1);
                }
            }
            byte[] ret = BitConverter.GetBytes((ushort)~crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC-16/XMODEM : x16+x12+x5+1<br/>
        /// Poly: 0x1021<br/>
        /// Init: 0x0000<br/>
        /// Refin: false<br/>
        /// Refout: false<br/>
        /// Xorout: 0x0000
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC21(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            ushort crc = 0;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= (ushort)(buffer[i] << 8);
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x8000) > 0)
                        crc = (ushort)(crc << 1 ^ 0x1021);
                    else
                        crc = (ushort)(crc << 1);
                }
            }
            byte[] ret = BitConverter.GetBytes(crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC32 : x32+x26+x23+x22+x16+x12+x11+x10+x8+x7+x5+x4+x2+x+1<br/>
        /// Poly: 0x04C11DB7<br/>
        /// Init: 0xFFFFFFFF<br/>
        /// Refin: true<br/>
        /// Refout: true<br/>
        /// Xorout: 0xFFFFFFFF
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC22(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            uint crc = 0xFFFFFFFF;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= buffer[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) > 0)
                        crc = crc >> 1 ^ 0xEDB88320;// 0xEDB88320= reverse 0x04C11DB7
                    else
                        crc = crc >> 1;
                }
            }
            byte[] ret = BitConverter.GetBytes(~crc);
            Array.Reverse(ret);
            return ret;
        }

        /// <summary>
        /// Name: CRC32/MPEG-2 : x32+x26+x23+x22+x16+x12+x11+x10+x8+x7+x5+x4+x2+x+1<br/>
        /// Poly: 0x04C11DB7<br/>
        /// Init: 0xFFFFFFFF<br/>
        /// Refin: false<br/>
        /// Refout: false<br/>
        /// Xorout: 0x00000000
        /// </summary>
        /// <param name="buffer">。</param>
        /// <param name="start">。</param>
        /// <param name="len">。</param>
        /// <returns>CRC校驗值。</returns>
        public static byte[] CRC23(byte[] buffer, int start = 0, int len = 0)
        {
            if (buffer == null || buffer.Length == 0) return null;
            if (start < 0) return null;
            if (len == 0) len = buffer.Length - start;
            int length = start + len;
            if (length > buffer.Length) return null;
            uint crc = 0xFFFFFFFF;// Initial value
            for (int i = start; i < length; i++)
            {
                crc ^= (uint)(buffer[i] << 24);
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x80000000) > 0)
                        crc = crc << 1 ^ 0x04C11DB7;
                    else
                        crc = crc << 1;
                }
            }
            byte[] ret = BitConverter.GetBytes(crc);
            Array.Reverse(ret);
            return ret;
        }
    }
}
