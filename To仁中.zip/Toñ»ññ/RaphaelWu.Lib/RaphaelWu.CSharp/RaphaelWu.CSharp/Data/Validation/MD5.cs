﻿using System.Text;

namespace RaphaelWu.CSharp.Data.Validation
{
    /// <summary>
    /// MD5訊息摘要演算法 (MD5 Message-Digest Algorithm)。
    /// </summary>
    public static class MD5
    {
        /// <summary>
        /// MD5加密。
        /// </summary>
        /// <param name="textToEncrypt">待加密字串。</param>
        /// <returns>加密後字串。若為空字串表示演算失敗。</returns>
        public static string GetMD5Hash(this string textToEncrypt)
        {
            using var cryptoMD5 = System.Security.Cryptography.MD5.Create();
            var bytes = Encoding.UTF8.GetBytes(textToEncrypt);                  //將字串編碼成 UTF8 位元組陣列
            var hash = cryptoMD5.ComputeHash(bytes);                            //取得雜湊值位元組陣列
            var md5 = BitConverter.ToString(hash).Replace("-", string.Empty);   //取得 MD5
            return md5;
        }

        /// <summary>
        /// 驗證MD5值。
        /// </summary>
        /// <param name="str">待比較的值。</param>
        /// <param name="hash">被比較的MD5 Hash字串。</param>
        /// <returns>驗證結果。</returns>
        public static bool VerifyMD5Hash(string str, string hash)
        {
            string hashOfInput = str.GetMD5Hash();
            return hashOfInput.CompareTo(hash) == 0;
        }
    }
}
