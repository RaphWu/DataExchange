﻿namespace RaphaelWu.CSharp.Data.Coordinate
{
    /// <summary>
    /// 座標表示 - 長整數XYZ。
    /// </summary>
    public struct LongPointXYZ
    {
        /// <summary>
        /// X座標值。
        /// </summary>
        public long X { get; set; }

        /// <summary>
        /// Y座標值。
        /// </summary>
        public long Y { get; set; }

        /// <summary>
        /// Z座標值。
        /// </summary>
        public long Z { get; set; }

        public LongPointXYZ(long x, long y, long z)
        {
            X = x;
            Y = y;
            Z = z;
        }
    }
}
