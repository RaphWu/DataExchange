﻿namespace RaphaelWu.CSharp.Data.Coordinate
{
    /// <summary>
    /// 座標表示 - 雙精確度XYR。
    /// </summary>
    public struct PointXYR
    {
        /// <summary>
        /// X座標值。
        /// </summary>
        public double X { get; set; }

        /// <summary>
        /// Y座標值。
        /// </summary>
        public double Y { get; set; }

        /// <summary>
        /// R座標值。
        /// </summary>
        public double R { get; set; }

        public PointXYR(double x, double y, double r)
        {
            X = x;
            Y = y;
            R = r;
        }
    }
}
