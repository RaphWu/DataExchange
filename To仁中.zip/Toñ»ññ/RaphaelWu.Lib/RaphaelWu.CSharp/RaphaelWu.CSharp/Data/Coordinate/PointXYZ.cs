﻿namespace RaphaelWu.CSharp.Data.Coordinate
{
    /// <summary>
    /// 座標表示 - 雙精確度XYZ。
    /// </summary>
    public struct PointXYZ
    {
        /// <summary>
        /// X座標值。
        /// </summary>
        public double X { get; set; }

        /// <summary>
        /// Y座標值。
        /// </summary>
        public double Y { get; set; }

        /// <summary>
        /// Z座標值。
        /// </summary>
        public double Z { get; set; }

        public PointXYZ(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }
    }
}
