﻿namespace RaphaelWu.CSharp.Data.Coordinate
{
    /// <summary>
    /// 座標表示 - 雙精確度XY。
    /// </summary>
    public struct PointXY
    {
        /// <summary>
        /// X座標值。
        /// </summary>
        public double X { get; set; }

        /// <summary>
        /// Y座標值。
        /// </summary>
        public double Y { get; set; }

        public PointXY(double x, double y)
        {
            X = x;
            Y = y;
        }
    }
}
