﻿namespace RaphaelWu.CSharp.Data.Coordinate
{
    /// <summary>
    /// 座標表示 - 長整數XY。
    /// </summary>
    public struct LongPointXY
    {
        /// <summary>
        /// X座標值。
        /// </summary>
        public long X { get; set; }

        /// <summary>
        /// Y座標值。
        /// </summary>
        public long Y { get; set; }

        public LongPointXY(long x, long y)
        {
            X = x;
            Y = y;
        }
    }
}
