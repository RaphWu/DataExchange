﻿namespace RaphaelWu.CSharp.Data.Coordinate
{
    /// <summary>
    /// 座標表示 - 整數XY。
    /// </summary>
    public struct IntPointXY
    {
        /// <summary>
        /// X座標值。
        /// </summary>
        public int X { get; set; }

        /// <summary>
        /// Y座標值。
        /// </summary>
        public int Y { get; set; }

        public IntPointXY(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
