﻿using System.Diagnostics;

namespace RaphaelWu.CSharp.Diagnostics
{
    /// <summary>
    /// 時間測量器。
    /// </summary>
    public class TimeMeasurer
    {
        /// <summary>
        /// 開始運行。
        /// </summary>
        /// <param name="action">。</param>
        /// <returns>。</returns>
        public static TimeSpan Run(Action action)
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            action?.Invoke();
            stopwatch.Stop();
            return stopwatch.Elapsed;
        }

        /// <summary>
        /// 異步執行。
        /// </summary>
        /// <param name="action">。</param>
        /// <returns>。</returns>
        public static Task<TimeSpan> RunAsync(Action action)
        {
            return Task.Run(() =>
            {
                return Run(action);
            });
        }
    }
}
