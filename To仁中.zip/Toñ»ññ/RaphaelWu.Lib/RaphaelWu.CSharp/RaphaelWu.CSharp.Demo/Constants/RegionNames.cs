﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaphaelWu.CSharp.Demo.Constants
{
    public class RegionNames
    {
        public const string MainRegion = "MainRegion";
    }
}
