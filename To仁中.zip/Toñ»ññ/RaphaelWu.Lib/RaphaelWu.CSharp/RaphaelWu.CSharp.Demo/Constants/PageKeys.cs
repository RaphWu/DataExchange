﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaphaelWu.CSharp.Demo.Constants
{
    public class PageKeys
    {
        public const string DateAndTime = "DateAndTime";
    }
}
