﻿using Microsoft.VisualBasic;
using Prism.Ioc;
using Prism.Unity;
using RaphaelWu.CSharp.Demo.Constants;
using RaphaelWu.CSharp.Demo.Services;
using RaphaelWu.CSharp.Demo.ViewModels;
using RaphaelWu.CSharp.Demo.Views;
using System.Windows;
using DateAndTime = RaphaelWu.CSharp.Demo.Views.DateAndTime;

namespace RaphaelWu.CSharp.Demo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : PrismApplication
    {
        protected override Window CreateShell()
        {
            return Container.Resolve<MainWindow>();
        }

        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.Register<IThemeSelectorService, ThemeSelectorService>();

            containerRegistry.RegisterForNavigation<DateAndTime, DateAndTimeViewModel>(PageKeys.DateAndTime);
        }
    }
}
