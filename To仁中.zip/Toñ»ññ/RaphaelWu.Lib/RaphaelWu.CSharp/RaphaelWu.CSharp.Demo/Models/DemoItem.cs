﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaphaelWu.CSharp.Demo.Models
{
    public class DemoItem
    {
        public DemoItem(string name, string pageKey)
        {
            Name = name;
            PageKey = pageKey;
        }

        public string Name { get; }
        public string PageKey { get; }
    }
}
