﻿using System.Windows.Controls;

namespace RaphaelWu.CSharp.Demo.Views
{
    /// <summary>
    /// Interaction logic for DateAndTime
    /// </summary>
    public partial class DateAndTime : UserControl
    {
        public DateAndTime()
        {
            InitializeComponent();
        }
    }
}
