﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using RaphaelWu.CSharp.Demo.Constants;
using RaphaelWu.CSharp.Demo.Models;
using RaphaelWu.CSharp.Demo.Services;
using System.Collections.ObjectModel;
using System.Linq;

namespace RaphaelWu.CSharp.Demo.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private IRegionNavigationService _naviService;
        private readonly IRegionManager _regionManager;
        private readonly IThemeSelectorService _themeSelectorService;

        public MainWindowViewModel(IRegionManager regionManager, IThemeSelectorService themeSelectorService)
        {
            _regionManager = regionManager;
            _themeSelectorService = themeSelectorService;

            DemoItems = new ObservableCollection<DemoItem>(new[]
            {
                new DemoItem("Date & Time", PageKeys.DateAndTime),
            });
        }

        public DelegateCommand LoadedCommand
            => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
        private void ExecuteLoadedCommand()
        {
            _naviService = _regionManager.Regions[RegionNames.MainRegion].NavigationService;
            SelectedItem = DemoItems.First();
            ExecuteLightThemeCommand();
        }
        private DelegateCommand _loadedCommand;

        /********************
         * Command
         ********************/
        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand LightThemeCommand
            => _lightThemeCommand ??= new DelegateCommand(ExecuteLightThemeCommand);
        private void ExecuteLightThemeCommand()
        {
            _themeSelectorService.SetTheme(AppTheme.Light);
        }
        private DelegateCommand _lightThemeCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand DarkThemeCommand
            => _darkThemeCommand ??= new DelegateCommand(ExecuteDarkThemeCommand);
        private void ExecuteDarkThemeCommand()
        {
            _themeSelectorService.SetTheme(AppTheme.Dark);
        }
        private DelegateCommand _darkThemeCommand;

        /********************
         * Property
         ********************/
        public ObservableCollection<DemoItem> DemoItems { get; }

        public DemoItem? SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                SetProperty(ref _selectedItem, value);
                if (value != null)
                    _naviService.RequestNavigate(value.PageKey);
            }
        }
        private DemoItem? _selectedItem;

        public int SelectedIndex
        {
            get { return _selectedIndex; }
            set { SetProperty(ref _selectedIndex, value); }
        }
        private int _selectedIndex;
    }
}
