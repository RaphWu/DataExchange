﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using RaphaelWu.CSharp.Data.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Threading;

namespace RaphaelWu.CSharp.Demo.ViewModels
{
    public class DateAndTimeViewModel : BindableBase, INavigationAware
    {
        private DispatcherTimer _timer;

        /********************
         * INavigationAware
         ********************/
        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            _timer = new DispatcherTimer();
            _timer.Tick += new EventHandler(OnTimedEvent);
            _timer.Interval = new TimeSpan(0, 0, 0, 0, 200);
            _timer.Start();
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
            _timer.Stop();
        }

        public bool IsNavigationTarget(NavigationContext navigationContext) => true;


        /********************
         * ctor
         ********************/
        public DateAndTimeViewModel()
        {
            SelectDate = DateTime.Now;
        }

        /********************
         * Timer
         ********************/
        private void OnTimedEvent(object sender, EventArgs e)
        {
            var timestampUnit = TimestampUnit ? TimestampType.Milliseconds : TimestampType.Seconds;
            LocalDateTime = DateTime.Now;
            UtcDateTime = DateTime.UtcNow;

            /* Local Column */
            UnixTimestampFromLocal = LocalDateTime.ToUnixTimestamp(timestampUnit, RaphaelWu.CSharp.Constants.LocalTimeZone);
            LinuxTimestampFromLocal = LocalDateTime.LocalToLinuxTimestamp();

            LocalFromUnixTimestamp_Local = UnixTimestampFromLocal.LocalFromUnixTimestamp(timestampUnit, out DateTime dtLocal_Local)
                ? dtLocal_Local : DateTime.MinValue;
            UtcFromUnixTimestamp_Local = UnixTimestampFromLocal.UtcFromUnixTimestamp(timestampUnit, out DateTime dtUtc_Local)
                ? dtUtc_Local : DateTime.MinValue;
            LocalFromLinuxTimestamp_Local = LinuxTimestampFromLocal.LocalFromLinuxTimestamp();
            UtcFromLinuxTimestamp_Local = LinuxTimestampFromLocal.UtcFromLinuxTimestamp();

            /* UTC Column */
            UnixTimestampFromUtc = UtcDateTime.ToUnixTimestamp(timestampUnit, TimeSpan.Zero);
            LinuxTimestampFromUtc = UtcDateTime.UtcToLinuxTimestamp();

            LocalFromUnixTimestamp_UTC = UnixTimestampFromUtc.LocalFromUnixTimestamp(timestampUnit, out DateTime dtLocal_UTC)
                ? dtLocal_UTC : DateTime.MinValue;
            UtcFromUnixTimestamp_UTC = UnixTimestampFromUtc.UtcFromUnixTimestamp(timestampUnit, out DateTime dtUtc_UTC)
                ? dtUtc_UTC : DateTime.MinValue;
            LocalFromLinuxTimestamp_UTC = LinuxTimestampFromUtc.LocalFromLinuxTimestamp();
            UtcFromLinuxTimestamp_UTC = LinuxTimestampFromUtc.UtcFromLinuxTimestamp();
        }

        /********************
         * Property
         ********************/
        public bool TimestampUnit
        {
            get { return _timestampUnit; }
            set { SetProperty(ref _timestampUnit, value); }
        }
        private bool _timestampUnit = false;

        /* Local Column */
        public DateTime LocalDateTime
        {
            get { return _localDateTime; }
            set { SetProperty(ref _localDateTime, value); }
        }
        private DateTime _localDateTime;

        public long UnixTimestampFromLocal
        {
            get { return _unixTimestampFromLocal; }
            set { SetProperty(ref _unixTimestampFromLocal, value); }
        }
        private long _unixTimestampFromLocal;

        public long LinuxTimestampFromLocal
        {
            get { return _linuxTimestampFromLocal; }
            set { SetProperty(ref _linuxTimestampFromLocal, value); }
        }
        private long _linuxTimestampFromLocal;

        public DateTime LocalFromUnixTimestamp_Local
        {
            get { return _localFromUnixTimestamp_Local; }
            set { SetProperty(ref _localFromUnixTimestamp_Local, value); }
        }
        private DateTime _localFromUnixTimestamp_Local;

        public DateTime UtcFromUnixTimestamp_Local
        {
            get { return _utcFromUnixTimestamp_Local; }
            set { SetProperty(ref _utcFromUnixTimestamp_Local, value); }
        }
        private DateTime _utcFromUnixTimestamp_Local;

        public DateTime LocalFromLinuxTimestamp_Local
        {
            get { return _localFromLinuxTimestamp_Local; }
            set { SetProperty(ref _localFromLinuxTimestamp_Local, value); }
        }
        private DateTime _localFromLinuxTimestamp_Local;

        public DateTime UtcFromLinuxTimestamp_Local
        {
            get { return _utcFromLinuxTimestamp_Local; }
            set { SetProperty(ref _utcFromLinuxTimestamp_Local, value); }
        }
        private DateTime _utcFromLinuxTimestamp_Local;

        /* UTC Column */
        public DateTime UtcDateTime
        {
            get { return _utcDateTime; }
            set { SetProperty(ref _utcDateTime, value); }
        }
        private DateTime _utcDateTime;

        public long UnixTimestampFromUtc
        {
            get { return _unixTimestampFromUtc; }
            set { SetProperty(ref _unixTimestampFromUtc, value); }
        }
        private long _unixTimestampFromUtc;

        public long LinuxTimestampFromUtc
        {
            get { return _linuxTimestampFromUtc; }
            set { SetProperty(ref _linuxTimestampFromUtc, value); }
        }
        private long _linuxTimestampFromUtc;

        public DateTime LocalFromUnixTimestamp_UTC
        {
            get { return _localFromUnixTimestamp_UTC; }
            set { SetProperty(ref _localFromUnixTimestamp_UTC, value); }
        }
        private DateTime _localFromUnixTimestamp_UTC;

        public DateTime UtcFromUnixTimestamp_UTC
        {
            get { return _utcFromUnixTimestamp_UTC; }
            set { SetProperty(ref _utcFromUnixTimestamp_UTC, value); }
        }
        private DateTime _utcFromUnixTimestamp_UTC;

        public DateTime LocalFromLinuxTimestamp_UTC
        {
            get { return _localFromLinuxTimestamp_UTC; }
            set { SetProperty(ref _localFromLinuxTimestamp_UTC, value); }
        }
        private DateTime _localFromLinuxTimestamp_UTC;

        public DateTime UtcFromLinuxTimestamp_UTC
        {
            get { return _utcFromLinuxTimestamp_UTC; }
            set { SetProperty(ref _utcFromLinuxTimestamp_UTC, value); }
        }
        private DateTime _utcFromLinuxTimestamp_UTC;

        /// <summary>
        /// 
        /// </summary>
        public DateTime SelectDate
        {
            get { return _selectDate; }
            set { SetProperty(ref _selectDate, value); }
        }
        private DateTime _selectDate;
    }
}
