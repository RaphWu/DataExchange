﻿using ControlzEx.Theming;
using MahApps.Metro.Theming;
using MaterialDesignThemes.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Theme = MaterialDesignThemes.Wpf.Theme;

namespace RaphaelWu.CSharp.Demo.Services
{
    // 修改自Template Studio for WPF
    /// <summary>
    /// 佈景主題服務。
    /// </summary>
    public class ThemeSelectorService : IThemeSelectorService
    {
        private const string HcDarkTheme = "pack://application:,,,/RaphaelWu.WPF;component/Styles/HC.Dark.Blue.xaml";
        private const string HcLightTheme = "pack://application:,,,/RaphaelWu.WPF;component/Styles/HC.Light.Blue.xaml";

        public ThemeSelectorService()
        {
        }

        public void InitializeTheme()
        {
            // TODO: Mahapps.Metro supports syncronization with high contrast but you have to provide custom high contrast themes
            // We've added basic high contrast dictionaries for Dark and Light themes
            // Please complete these themes following the docs on https://mahapps.com/docs/themes/thememanager#creating-custom-themes
            ThemeManager.Current.AddLibraryTheme(new LibraryTheme(new Uri(HcDarkTheme), MahAppsLibraryThemeProvider.DefaultInstance));
            ThemeManager.Current.AddLibraryTheme(new LibraryTheme(new Uri(HcLightTheme), MahAppsLibraryThemeProvider.DefaultInstance));

            var theme = GetCurrentTheme();
            SetTheme(theme);
        }

        public void SetTheme(AppTheme theme)
        {
            // MaterialDesignThemes
            var paletteHelper = new PaletteHelper();
            Theme mdTheme = paletteHelper.GetTheme();
            if (theme == AppTheme.Light)
                mdTheme.SetLightTheme();
            else if (theme == AppTheme.Dark)
                mdTheme.SetDarkTheme();
            paletteHelper.SetTheme(mdTheme);

            // MahApps.Metro
            if (theme == AppTheme.Default)
            {
                ThemeManager.Current.ThemeSyncMode = ThemeSyncMode.SyncAll;
                ThemeManager.Current.SyncTheme();
            }
            else
            {
                ThemeManager.Current.ThemeSyncMode = ThemeSyncMode.SyncWithHighContrast;
                ThemeManager.Current.SyncTheme();
                ThemeManager.Current.ChangeTheme(Application.Current, $"{theme}.Blue", SystemParameters.HighContrast);
            }

            // System
            App.Current.Properties["Theme"] = theme.ToString();
        }

        public AppTheme GetCurrentTheme()
        {
            if (App.Current.Properties.Contains("Theme"))
            {
                var themeName = App.Current.Properties["Theme"].ToString();
                Enum.TryParse(themeName, out AppTheme theme);
                return theme;
            }

            return AppTheme.Default;
        }
    }
}
