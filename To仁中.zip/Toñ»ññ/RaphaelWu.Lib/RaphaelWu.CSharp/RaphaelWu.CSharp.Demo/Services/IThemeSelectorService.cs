﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaphaelWu.CSharp.Demo.Services
{
    // 修改自Template Studio for WPF
    /// <summary>
    /// 佈景主題服務介面。
    /// </summary>
    public interface IThemeSelectorService
    {
        void InitializeTheme();

        void SetTheme(AppTheme theme);

        AppTheme GetCurrentTheme();
    }
}
