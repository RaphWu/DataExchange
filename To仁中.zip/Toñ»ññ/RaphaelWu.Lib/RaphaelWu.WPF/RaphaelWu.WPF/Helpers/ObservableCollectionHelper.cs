﻿using System.Collections.ObjectModel;
using System.Windows.Data;

namespace RaphaelWu.WPF.Helpers
{
    /// <summary>
    /// ObservableCollection輔助函式。
    /// </summary>
    public static class ObservableCollectionHelper
    {
        /// <summary>
        /// 用於ObservableCollection在螢幕上的刷新。
        /// </summary>
        /// <typeparam name="T">Collection型別。</typeparam>
        /// <param name="collectionName">Collection名稱。</param>
        /// <remarks>參考自: <see href="https://stackoverflow.com/a/67314794">Stack Overflow by James Westgate</see>。</remarks>
        public static void Refresh<T>(this ObservableCollection<T> collectionName)
        {
            CollectionViewSource.GetDefaultView(collectionName).Refresh();
        }
    }
}
