﻿using System.Windows.Markup;

namespace RaphaelWu.WPF.Markup
{
    /// <summary>
    /// 使用 enum 做為 ComboBox 的 ItemsSource
    /// </summary>
    /// <remarks>參考自: <see href="https://stackoverflow.com/questions/6145888/how-to-bind-an-enum-to-a-combobox-control-in-wpf/17405771#17405771">How to bind an enum to a combobox control in WPF?</see></remarks>
    public class EnumToItemsSourceExtension : MarkupExtension
    {
        private readonly Type _type;

        public EnumToItemsSourceExtension(Type type)
        {
            _type = type;
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return Enum.GetValues(_type)
                .Cast<object>()
                .Select(e => new { Value = (int)e, DisplayName = e.ToString() });
        }
    }
}
