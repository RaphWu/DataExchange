﻿using System.Globalization;
using System.Windows.Controls;

namespace RaphaelWu.WPF.Validation
{
    public class TextBoxEmptyValidation : ValidationRule
    {
        public string ErrorMessage { get; set; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            ValidationResult result = new(true, null);
            string inputString = (value ?? string.Empty).ToString();

            if (string.IsNullOrEmpty(inputString))
                result = new ValidationResult(false, ErrorMessage);

            return result;
        }
    }
}
