﻿using Microsoft.Xaml.Behaviors;
using System.Windows.Controls;

namespace RaphaelWu.WPF.Behaviors
{
    /// <summary>
    /// 自動捲動到選擇列 for DataGrid。
    /// </summary>
    /// <remarks>參考資料:<br/>
    /// <see href="https://stackoverflow.com/questions/10135850/how-do-i-scrollintoview-after-changing-the-filter-on-a-listview-in-a-mvvm-wpf">Stack Overflow。</see><br/>
    /// <see href="https://www.cnblogs.com/pasoraku/p/15132997.html">WPF中ListView滚动到当前行的几种方法。</see>
    /// </remarks>
    // 另一方案參考: https://stackoverflow.com/questions/2946954/make-listview-scrollintoview-scroll-the-item-into-the-center-of-the-listview-c
    public class ScrollIntoViewForDataGrid : Behavior<DataGrid>
    {
        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.SelectionChanged += new SelectionChangedEventHandler(AssociatedObject_SelectionChanged);
        }

        private void AssociatedObject_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is DataGrid)
            {
                DataGrid grid = sender as DataGrid;
                if (grid.SelectedItem != null)
                {
                    grid.Dispatcher.BeginInvoke((Action)delegate
                    {
                        grid.UpdateLayout();
                        if (grid.SelectedItem != null)
                            grid.ScrollIntoView(grid.SelectedItem, null);
                    });
                }
            }
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
            AssociatedObject.SelectionChanged -= new SelectionChangedEventHandler(AssociatedObject_SelectionChanged);
        }
    }
}
