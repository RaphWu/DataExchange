﻿using System.Windows;

namespace RaphaelWu.WPF.PrismSplashScreen.Views
{
    /// <summary>
    /// Interaction logic for SplashWindow
    /// </summary>
    public partial class SplashWindow : Window
    {
        public SplashWindow()
        {
            InitializeComponent();
        }
    }
}
