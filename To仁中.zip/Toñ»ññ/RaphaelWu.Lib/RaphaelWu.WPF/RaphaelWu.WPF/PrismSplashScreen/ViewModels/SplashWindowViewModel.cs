﻿using Prism.Events;
using Prism.Mvvm;
using System.Windows.Media.Imaging;

namespace RaphaelWu.WPF.PrismSplashScreen.ViewModels
{
    public class SplashWindowViewModel : BindableBase
    {
        public SplashWindowViewModel(IEventAggregator eventAggregator)
        {
            eventAggregator.GetEvent<UpdateSplashMessageEvent>().Subscribe(e => UpdateMessage(e.Message));
            eventAggregator.GetEvent<SplashScreenInit>().Subscribe(e => Init(e.MainTitle, e.Subtitle, e.MainImage));

            CompanyLogo = new BitmapImage(new Uri("pack://application:,,,/RaphaelWu.WPF;component/Images/GlorytekLogo.png"));
            MainImage = new BitmapImage(new Uri("pack://application:,,,/RaphaelWu.WPF;component/Images/GlorytekBuilding.png"));
        }

        public string ProgressText
        {
            get { return _progressText; }
            set { SetProperty(ref _progressText, value); }
        }
        private string _progressText;

        public string MainTitle
        {
            get { return _mainTitle; }
            set { SetProperty(ref _mainTitle, value); }
        }
        private string _mainTitle;

        public string Subtitle
        {
            get { return _subtitle; }
            set { SetProperty(ref _subtitle, value); }
        }
        private string _subtitle;

        public BitmapImage CompanyLogo
        {
            get { return _companyLogo; }
            set { SetProperty(ref _companyLogo, value); }
        }
        private BitmapImage _companyLogo;

        public BitmapImage MainImage
        {
            get { return _mainImage; }
            set { SetProperty(ref _mainImage, value); }
        }
        private BitmapImage _mainImage;

        /********************
         * Event mothod
         ********************/
        private void UpdateMessage(string message)
        {
            if (string.IsNullOrEmpty(message))
                return;

            ProgressText = string.Concat(message, Environment.NewLine, ProgressText);
        }

        private void Init(string maintitle, string subtitle, string mainImage)
        {
            if (!string.IsNullOrEmpty(maintitle))
                MainTitle = maintitle;

            if (!string.IsNullOrEmpty(subtitle))
                Subtitle = subtitle;

            if (!string.IsNullOrEmpty(mainImage))
                MainImage = new BitmapImage(new Uri(mainImage));
        }
    }
}
