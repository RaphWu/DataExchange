﻿using Prism.Events;

namespace RaphaelWu.WPF.PrismSplashScreen
{
    /// <summary>
    /// 更新訊息事件。
    /// </summary>
    public class UpdateSplashMessageEvent : PubSubEvent<UpdateSplashMessageEvent>
    {
        /// <summary>
        /// 顯示的訊息。
        /// </summary>
        public string Message { get; set; }
    }

    /// <summary>
    /// 關閉SplashWindow事件。
    /// </summary>
    public class CloseSplashEvent : PubSubEvent<CloseSplashEvent> { }

    /// <summary>
    /// SplashWindow訊息初始化事件。
    /// </summary>
    public class SplashScreenInit : PubSubEvent<SplashScreenInit>
    {
        /// <summary>
        /// 主標題。
        /// </summary>
        public string MainTitle { get; set; }

        /// <summary>
        /// 副標題。
        /// </summary>
        public string Subtitle { get; set; }

        /// <summary>
        /// 主圖片。
        /// </summary>
        /// <remarks>預設圖片尺寸 270x350。</remarks>
        public string MainImage { get; set; }
    }
}
