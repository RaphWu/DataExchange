﻿using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;
using RaphaelWu.WPF.PrismSplashScreen.Views;
using System.Windows.Threading;

namespace RaphaelWu.WPF.PrismSplashScreen
{
    public class PrismSplashWindowModule : IModule
    {
        private readonly IEventAggregator _ea;
        private AutoResetEvent WaitForCreation { get; set; }

        public PrismSplashWindowModule(IEventAggregator eventAggregator)
        {
            _ea = eventAggregator;
        }

        public void OnInitialized(IContainerProvider containerProvider)
        {
            // PrismSplash: https://github.com/oslaval/PrismSplash
            Dispatcher.CurrentDispatcher.BeginInvoke(() =>
            {
                _ea.GetEvent<CloseSplashEvent>().Publish(new CloseSplashEvent());
            });

            WaitForCreation = new AutoResetEvent(false);

            void showSplash()
            {
                Dispatcher.CurrentDispatcher.BeginInvoke(() =>
                {
                    SplashWindow splash = containerProvider.Resolve<SplashWindow>();

                    _ea.GetEvent<CloseSplashEvent>().Subscribe(e =>
                    {
                        Task.Delay(1000).Wait();
                        splash.Dispatcher.BeginInvoke(splash.Close);
                    }, ThreadOption.PublisherThread, true);

                    splash.Show();
                    WaitForCreation.Set();
                });

                Dispatcher.Run();
            }

            Thread thread = new Thread(showSplash) { Name = "SplashThread", IsBackground = true };
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();

            WaitForCreation.WaitOne();

            // 原作者程式沒有Delay這一行
            // 但有時視窗顯示時Module都載入完了，變成螢幕看到時訊息都已經跑完，沒有一個一個載入的視覺效果
            // 故加了一個Delay，先讓視窗顯示出來，然後再開始顯示訊息
            Task.Delay(1000).Wait();
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
        }
    }
}
