﻿using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// enum 與 bool 互轉。
    /// </summary>
    /// <remarks>參考自: <see href="https://stackoverflow.com/questions/397556/how-to-bind-radiobuttons-to-an-enum">How to bind RadioButtons to an enum?</see></remarks>
    public class EnumToBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value != null && value.Equals(parameter);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value != null && value.Equals(true) ? parameter : Binding.DoNothing;
        }

        //public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        //{
        //    string parameterString = parameter as string;
        //    if (parameterString == null)
        //        return DependencyProperty.UnsetValue;

        //    if (Enum.IsDefined(value.GetType(), value) == false)
        //        return Binding.DoNothing;

        //    object parameterValue = Enum.Parse(value.GetType(), parameterString);

        //    return parameterValue.Equals(value);
        //}

        //public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        //{
        //    string parameterString = parameter as string;
        //    if (parameterString == null)
        //        return Binding.DoNothing;

        //    return Enum.Parse(targetType, parameterString);
        //}

        //public Type EnumType { get; set; }

        //public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        //{
        //    if (parameter is string enumString)
        //    {
        //        if (Enum.IsDefined(EnumType, value))
        //        {
        //            var enumValue = Enum.Parse(EnumType, enumString);
        //            return enumValue.Equals(value);
        //        }
        //    }

        //    return Binding.DoNothing;
        //}

        //public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        //{
        //    if (parameter is string enumString)
        //        return Enum.Parse(EnumType, enumString);

        //    return Binding.DoNothing;
        //}
    }
}
