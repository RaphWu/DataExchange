﻿using RaphaelWu.WPF.Extensions;
using System.ComponentModel;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// 繫結 ComboBox 的 ItemsSource 到多語言版本 enum 的 Description。
    /// </summary>
    /// <remarks>修改自 <see href="https://brianlagunas.com/localize-enum-descriptions-in-wpf/"/>。</remarks>
    public class LocalizedDescriptionAttribute : DescriptionAttribute
    {
        //ResourceManager _resourceManager;
        private readonly string _assemblyName;
        private readonly string _resourceKey;

        public LocalizedDescriptionAttribute(string assemblyName, string resourceKey)
        {
            _assemblyName = assemblyName;
            _resourceKey = resourceKey;
        }

        public override string Description
        {
            get
            {
                if (_resourceKey != "")
                    return GetResource.GetValue<string>(_assemblyName, _resourceKey);
                else
                    return "";
            }
        }

        //public LocalizedDescriptionAttribute(string resourceKey, Type resourceType)
        //{
        //    _resourceManager = new ResourceManager(resourceType);
        //    _resourceKey = resourceKey;
        //}

        //public override string Description
        //{
        //    get
        //    {
        //        string description = _resourceManager.GetString(_resourceKey);
        //        return string.IsNullOrWhiteSpace(description) ? string.Format("[[{0}]]", _resourceKey) : description;
        //    }
        //}
    }
}
