﻿using System.Globalization;
using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// 擷取int陣列內的元素。<br/>
    /// 第一個參數為short[]；第二個參數為index。<br/>
    /// 返回該short陣列指定的元素。<br/>
    /// 因為要用於點位的讀取，故有下列設置：若值為-1(沒有設置)，則返回0(顯示考量)；若參數不符規範則返回"-"。
    /// </summary>
    /// <remarks>參考自: <see href="https://stackoverflow.com/questions/41386047/wpf-xaml-binding-array-with-variable-index"/>。</remarks>
    public class GetIntValueFromArray : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values.Length != 2 || values[0] is not int[] || values[1] is not int)
                return "-";
            //throw new ArgumentException("given values not correct");

            int no = ((int[])values[0])[(int)values[1] - 1];
            return no >= 0 ? no.ToString() : "0";
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
