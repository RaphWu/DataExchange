﻿using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// 將 Color 轉換成 Brush。
    /// </summary>
    public class ColorToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return new SolidColorBrush((Color)value);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // 將Brush轉成SolidColorBrush，再取Color。
            return ((SolidColorBrush)value).Color;

            // 先將Brush轉成string，再轉成Color。
            //return (Color)ColorConverter.ConvertFromString(value.ToString());
        }
    }
}
