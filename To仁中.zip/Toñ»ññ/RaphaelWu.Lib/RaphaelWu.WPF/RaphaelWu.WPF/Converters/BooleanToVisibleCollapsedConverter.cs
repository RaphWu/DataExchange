﻿using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// bool 與 Visibility屬性: "Visible"/"Collapsed" 互轉。
    /// </summary>
    [ValueConversion(typeof(bool), typeof(string))]
    public class BooleanToVisibleCollapsedConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => (bool)value ? "Visible" : "Collapsed";

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => (string)value == "Visible";
    }
}
