﻿using System.Globalization;
using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// IsEnabled 的 MultiBinding Converter。
    /// </summary>
    [ValueConversion(typeof(bool), typeof(bool))]
    public class IsEnabledForMultiBinding : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            string logicOp = parameter as string;
            if (string.IsNullOrWhiteSpace(logicOp))
                return false;

            int countTrue = 0;
            switch (logicOp.ToUpper())
            {
                case "AND":
                    foreach (object item in values)
                    {
                        if (item == null || item is not bool)
                            return false;

                        if (!(bool)item)
                            return false;
                    }
                    return true;

                case "OR":
                    foreach (object item in values)
                    {
                        if ((bool)item)
                            return true;
                    }
                    return false;

                case "NAND":
                    foreach (object item in values)
                    {
                        if (item == null || item is not bool)
                            return true;

                        if (!(bool)item)
                            return true;
                    }
                    return false;

                case "NOR":
                    foreach (object item in values)
                    {
                        if ((bool)item)
                            return false;
                    }
                    return true;

                case "XOR":
                    foreach (object item in values)
                    {
                        if ((bool)item)
                            countTrue++;
                    }
                    return countTrue % 2 == 1;

                case "XNOR":
                    foreach (object item in values)
                    {
                        if ((bool)item)
                            countTrue++;
                    }
                    return countTrue % 2 == 0;

                default:
                    return false;
            }
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
