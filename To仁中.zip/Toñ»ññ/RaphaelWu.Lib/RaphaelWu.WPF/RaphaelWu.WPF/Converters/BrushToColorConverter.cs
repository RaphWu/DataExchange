﻿using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// 將 Brush 轉換成 Color。
    /// </summary>
    [ValueConversion(typeof(SolidColorBrush), typeof(Color))]
    public class BrushToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (!(value is SolidColorBrush)) return null;
            var result = (SolidColorBrush)value;
            return result.Color;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
