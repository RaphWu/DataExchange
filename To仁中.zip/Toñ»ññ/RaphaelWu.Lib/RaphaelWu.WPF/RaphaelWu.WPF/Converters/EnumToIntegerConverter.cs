﻿using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// 將enum轉換為int。
    /// </summary>
    public class EnumToIntegerConverter : IValueConverter
    {
        //public Type EnumType { get; set; }

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            int retValue = -1;
            if (parameter is Type)
            {
                retValue = (int)Enum.Parse((Type)parameter, value.ToString());
            }

            //if (parameter is string enumString)
            //{
            //    if (Enum.IsDefined(EnumType, value))
            //    {
            //        var enumValue = Enum.Parse(EnumType, enumString);
            //        return (int)enumValue;
            //    }
            //}

            return retValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            Enum enumValue = default;
            if (parameter is Type)
            {
                enumValue = (Enum)Enum.Parse((Type)parameter, value.ToString());
            }
            return enumValue;

            //if (parameter is string enumString)
            //    return Enum.Parse(EnumType, enumString);

            //return null;
        }
    }
}
