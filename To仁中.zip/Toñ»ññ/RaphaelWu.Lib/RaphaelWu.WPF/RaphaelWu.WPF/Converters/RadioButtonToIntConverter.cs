﻿using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// RadioButton用，將ConverterParameter的設定值以int存入IsChecked繫結的變數。
    /// </summary>
    public class RadioButtonToIntConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //value是radiobutton接到binding變數的值後，來呼叫converter
            //converter負責判定接到的值是代表true還是false
            if (value == null || parameter == null)
                return null;

            return value.ToString().Equals(parameter.ToString(), StringComparison.InvariantCultureIgnoreCase);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //value是目前radiobutton的true/false
            //在這裡把parameter傳回ViewModel
            if (value == null || parameter == null)
                return null;

            return (bool)value ? int.Parse(parameter.ToString()) : -1;
        }
    }
}
