﻿using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// Visibility 的 MultiBinding Converter。
    /// </summary>
    public class VisibilityForMultiBinding : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            string logicOp = parameter as string;
            if (string.IsNullOrWhiteSpace(logicOp))
                return Visibility.Collapsed;

            int countTrue = 0;
            switch (logicOp.ToUpper())
            {
                case "AND":
                    foreach (object item in values)
                    {
                        if (!(bool)item)
                            return Visibility.Collapsed;
                    }
                    return Visibility.Visible;

                case "OR":
                    foreach (object item in values)
                    {
                        if ((bool)item)
                            return Visibility.Visible;
                    }
                    return Visibility.Collapsed;

                case "NAND":
                    foreach (object item in values)
                    {
                        if (!(bool)item)
                            return Visibility.Visible;
                    }
                    return Visibility.Collapsed;

                case "NOR":
                    foreach (object item in values)
                    {
                        if ((bool)item)
                            return Visibility.Collapsed;
                    }
                    return Visibility.Visible;

                case "XOR":
                    foreach (object item in values)
                    {
                        if ((bool)item)
                            countTrue++;
                    }
                    return countTrue % 2 == 1 ? Visibility.Visible : Visibility.Collapsed;

                case "XNOR":
                    foreach (object item in values)
                    {
                        if ((bool)item)
                            countTrue++;
                    }
                    return countTrue % 2 == 0 ? Visibility.Visible : Visibility.Collapsed;

                default:
                    return Visibility.Collapsed;
            }
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
