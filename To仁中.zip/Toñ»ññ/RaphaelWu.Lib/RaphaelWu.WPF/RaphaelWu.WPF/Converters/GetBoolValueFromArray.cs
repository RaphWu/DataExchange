﻿using System.Globalization;
using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// 擷取bool陣列內的元素。<br/>
    /// 第一個參數為bool[]；第二個參數為index。<br/>
    /// 返回該陣列指定的元素。
    /// </summary>
    public class GetBoolValueFromArray : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values.Length != 2 || values[0] is not bool[] || values[1] is not int)
                return false;
            //throw new ArgumentException("given values not correct");

            bool result = ((bool[])values[0])[(int)values[1] - 1];
            return result;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
