﻿using RaphaelWu.CSharp.Helpers;
using System.Windows;
using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// 取得 enum 的 Description。
    /// </summary>
    public class EnumDescriptionConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value is Enum myEnum ? myEnum.GetDescription() : "";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return DependencyProperty.UnsetValue;
        }
    }
}
