﻿using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// bool與”False”/”True”文字互轉(反相)。
    /// </summary>
    [ValueConversion(typeof(bool), typeof(string))]
    public class BooleanToTrueFalseInvertConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => (bool)value ? "False" : "True";

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => value.ToString() != "True";
    }
}
