﻿using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// int 與 string 互轉。
    /// </summary>
    [ValueConversion(typeof(int), typeof(string))]
    public class IntToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => value.ToString();

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
            => (int)value;
    }
}
