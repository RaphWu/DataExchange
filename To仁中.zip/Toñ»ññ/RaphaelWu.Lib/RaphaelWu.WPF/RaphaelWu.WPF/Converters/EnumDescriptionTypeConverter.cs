﻿using System.ComponentModel;
using System.Reflection;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// 繫結 ComboBox 的 ItemsSource 到 enum 的 Description。
    /// </summary>
    /// <remarks>參考自: <see href="https://brianlagunas.com/a-better-way-to-data-bind-enums-in-wpf/">A Better Way to Data Bind Enums in WPF</see>。</remarks>
    public class EnumDescriptionTypeConverter : EnumConverter
    {
        public EnumDescriptionTypeConverter(Type type) : base(type)
        {
        }

        public override object ConvertTo(ITypeDescriptorContext context,
                                         System.Globalization.CultureInfo culture,
                                         object value,
                                         Type destinationType)
        {
            if (destinationType == typeof(string))
            {
                if (value != null)
                {
                    FieldInfo fi = value.GetType().GetField(value.ToString());
                    if (fi != null)
                    {
                        var attributes = fi.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];
                        return attributes.Length > 0 && !string.IsNullOrEmpty(attributes[0].Description)
                            ? attributes[0].Description
                            : string.Empty;
                    }
                }

                return string.Empty;
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
    }
}
