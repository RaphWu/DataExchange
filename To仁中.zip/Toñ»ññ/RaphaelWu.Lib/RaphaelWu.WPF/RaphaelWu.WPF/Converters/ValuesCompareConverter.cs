﻿namespace RaphaelWu.WPF.Converters
{
    ///// <summary>
    ///// 
    ///// </summary>
    //public class ValuesCompareConverter : IMultiValueConverter
    //{
    //    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
    //    {
    //        string logicOp = parameter as string;
    //        if (string.IsNullOrWhiteSpace(logicOp))
    //            logicOp = "==";

    //        double val1;
    //        double val2 = default;

    //        for (int idx = 0; idx < values.Length - 1; idx++)
    //        {
    //            if (idx > 0)
    //                val1 = val2;
    //            else
    //            {
    //                if (!double.TryParse(values[idx].ToString(), out val1))
    //                    return false;
    //            }
    //            if (!double.TryParse(values[idx + 1].ToString(), out val2))
    //                return false;

    //            if (values[idx] != values[idx + 1])
    //                return false;

    //            switch (logicOp)
    //            {
    //                case "==":
    //                    if (val1 != val2)
    //                        return false;
    //                    break;

    //                case "!=":
    //                    if (val1 == val2)
    //                        return false;
    //                    break;

    //                case ">":
    //                    if (val1 <= val2)
    //                        return false;
    //                    break;

    //                case ">=":
    //                    if (val1 < val2)
    //                        return false;
    //                    break;

    //                case "<":
    //                    if (val1 >= val2)
    //                        return false;
    //                    break;

    //                case "<=":
    //                    if (val1 > val2)
    //                        return false;
    //                    break;
    //            }
    //        }
    //        return true;
    //    }

    //    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}
}
