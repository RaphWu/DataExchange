﻿using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// enum 與 bool 反相互轉。
    /// </summary>
    public class EnumToBooleanInvertConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value != null && !value.Equals(parameter);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value != null && value.Equals(false) ? parameter : Binding.DoNothing;
        }
    }
}
