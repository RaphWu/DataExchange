﻿using System.Windows;
using System.Windows.Data;

namespace RaphaelWu.WPF.Converters
{
    /// <summary>
    /// bool反相。
    /// </summary>
    [ValueConversion(typeof(bool), typeof(bool))]
    public class BooleanInvertConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (!(value is bool))
                throw new InvalidOperationException("Value is not bool");

            return !(bool)value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return DependencyProperty.UnsetValue;
        }
    }
}
