﻿using Prism.Ioc;
using Prism.Regions;

namespace RaphaelWu.WPF.PrismExtensions
{
    public class ScopedRegionNavigationContentLoader : RegionNavigationContentLoader, IRegionNavigationContentLoader
    {
        public ScopedRegionNavigationContentLoader(IContainerExtension container) : base(container)
        {
        }

        protected override void AddViewToRegion(IRegion region, object view)
        {
            region.Add(view, null, CreateRegionManagerScope(view));
        }

        private bool CreateRegionManagerScope(object view)
        {
            bool createRegionManagerScope = false;

            var viewHasScopedRegions = view as ICreateRegionManagerScope;
            if (viewHasScopedRegions != null)
                createRegionManagerScope = viewHasScopedRegions.CreateRegionManagerScope;

            return createRegionManagerScope;
        }
    }
}
