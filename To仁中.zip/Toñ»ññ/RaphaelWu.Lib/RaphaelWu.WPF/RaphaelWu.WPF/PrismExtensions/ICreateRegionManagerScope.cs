﻿namespace RaphaelWu.WPF.PrismExtensions
{
    public interface ICreateRegionManagerScope
    {
        bool CreateRegionManagerScope { get; }
    }
}
