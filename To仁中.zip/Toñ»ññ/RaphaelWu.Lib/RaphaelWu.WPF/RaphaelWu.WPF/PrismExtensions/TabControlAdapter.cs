﻿using Prism.Regions;
using System.Collections.Specialized;
using System.Windows.Controls;

namespace RaphaelWu.WPF.PrismExtensions
{
    /// <summary>
    /// 在 WPF 的 TabControl 控制項中使用 Prism Region。
    /// </summary>
    /// <remarks>說明與用法:<br/>
    /// <see href="https://wpfcsharpmetroui.blogspot.com/2019/11/how-to-create-custom-adapter-for-using.html#gsc.tab=0">How to Create TabControl using Prism Region</see><br/>
    /// <see href="https://www.youtube.com/watch?v=BXeIZgssP0A">YouTube影片：How to Create TabControl using Prism Region in wpf (Create a custom Prism RegionAdapter)</see><br/>
    /// </remarks>
    public class TabControlAdapter : RegionAdapterBase<TabControl>
    {
        public TabControlAdapter(IRegionBehaviorFactory regionBehaviorFactory) : base(regionBehaviorFactory)
        {
        }

        protected override void Adapt(IRegion region, TabControl regionTarget)
        {
            region.Views.CollectionChanged += (s, e) =>
            {
                if (e.Action == NotifyCollectionChangedAction.Add)
                    foreach (UserControl item in e.NewItems)
                    {
                        regionTarget.Items.Add(new TabItem { Header = item.Name, Content = item });
                    }
                else if (e.Action == NotifyCollectionChangedAction.Remove)
                    foreach (UserControl item in e.OldItems)
                    {
                        var tabTodelete = regionTarget.Items.OfType<TabItem>().FirstOrDefault(n => n.Content == item);
                        regionTarget.Items.Remove(tabTodelete);
                    }

            };
        }

        protected override IRegion CreateRegion()
        {
            return new SingleActiveRegion();
        }
    }
}
