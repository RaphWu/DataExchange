﻿using Prism.Regions;

namespace RaphaelWu.WPF.PrismExtensions
{
    public interface IRegionManagerAware
    {
        IRegionManager RegionManager { get; set; }
    }
}
