﻿using Prism.Mvvm;
using System.Runtime.CompilerServices;

namespace RaphaelWu.WPF.PrismExtensions
{
    /// <summary>
    /// <see cref="BindableBase"/> 的功能擴充。
    /// </summary>
    public abstract class BindableBaseExt : BindableBase
    {
        /// <summary>
        /// 設置屬性並通知偵聽器。
        /// </summary>
        /// <typeparam name="T">屬性的型別。</typeparam>
        /// <param name="storage">參考至具有 getter 和 setter 方法的屬性。</param>
        /// <param name="value">屬性的期望值。</param>
        /// <param name="propertyName">用於通知偵聽器的屬性名稱。</param>
        protected void SetPropertyAlways<T>(ref T storage, T value, [CallerMemberName] string propertyName = null)
        {
            storage = value;
            RaisePropertyChanged(propertyName);
        }

        /// <summary>
        /// 設置屬性並通知偵聽器。
        /// </summary>
        /// <typeparam name="T">屬性的型別。</typeparam>
        /// <param name="storage">參考至具有 getter 和 setter 方法的屬性。</param>
        /// <param name="value">屬性的期望值。</param>
        /// <param name="onChanged">更改屬性值後調用的操作。</param>
        /// <param name="propertyName">用於通知偵聽器的屬性名稱。</param>
        protected void SetPropertyAlways<T>(ref T storage, T value, Action onChanged, [CallerMemberName] string propertyName = null)
        {
            storage = value;
            onChanged?.Invoke();
            RaisePropertyChanged(propertyName);
        }
    }
}
