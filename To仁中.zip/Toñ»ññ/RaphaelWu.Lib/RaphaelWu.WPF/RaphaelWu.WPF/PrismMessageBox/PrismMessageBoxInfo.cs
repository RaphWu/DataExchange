﻿using Prism.Services.Dialogs;
using System.Windows;

namespace RaphaelWu.WPF.PrismMessageBox
{
    /// <summary>
    /// 與Prism IDialogService交換數據用。
    /// </summary>
    public class PrismMessageBoxInfo
    {
        /// <summary>
        /// 返回的按鍵值。
        /// </summary>
        public ButtonResult Result { get; set; }

        /// <summary>
        /// 對話框標題。
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 顯示的訊息。
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 訊息前的提示圖示。
        /// </summary>
        public MessageBoxImage Image { get; set; }

        /// <summary>
        /// 預設返回的按鍵值。
        /// </summary>
        public ButtonResult DefaultResult { get; set; }

        /********************
         * 各按鍵，空字串=不顯示
         ********************/
        public string OK { get; set; }
        public string Cancel { get; set; }
        public string Abort { get; set; }
        public string Retry { get; set; }
        public string Ignore { get; set; }
        public string Yes { get; set; }
        public string No { get; set; }
    }
}
