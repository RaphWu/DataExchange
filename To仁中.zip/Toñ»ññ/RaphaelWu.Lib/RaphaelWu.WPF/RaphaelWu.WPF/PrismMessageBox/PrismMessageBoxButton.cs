﻿namespace RaphaelWu.WPF.PrismMessageBox
{
    /// <summary>
    /// 指定定義那個按鈕要顯示在 PrismMessageBox 上的常數。
    /// </summary>
    /// <remarks>複製自: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.windows.forms.messageboxbuttons">System.Windows.Forms.MessageBoxButtons</see>。</remarks>
    public enum PrismMessageBoxButton
    {
        /// <summary>
        /// 訊息方塊包含 [確定] 按鈕。
        /// </summary>
        OK = 0,

        /// <summary>
        /// 訊息方塊包含 [確定] 和 [取消] 按鈕。
        /// </summary>
        OkCancel = 1,

        /// <summary>
        /// 訊息方塊包含 [是]、[否] 和 [取消] 按鈕。
        /// </summary>
        YesNoCancel = 3,

        /// <summary>
        /// 訊息方塊包含 [是] 和 [否] 按鈕。
        /// </summary>
        YesNo = 4,

        /// <summary>
        /// 訊息方塊包含 [重試]、[忽略] 和 [中止] 按鈕。
        /// </summary>
        RetryIgnoreAbort = 2,

        /// <summary>
        /// 訊息方塊包含 [重試] 和 [取消] 按鈕。
        /// </summary>
        RetryCancel = 5,

        /// <summary>
        /// 指定訊息方塊包含 [繼續]、[重試] 和 [取消] 按鈕。
        /// </summary>
        ContinueTryCancel = 6,
    }
}
