﻿using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using System.Drawing;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Brushes = System.Windows.Media.Brushes;

namespace RaphaelWu.WPF.PrismMessageBox.ViewModels
{
    /// <summary>
    /// PrismMessageBox 的 ViewModel。
    /// </summary>
    public class PrismMessageBoxViewModel : BindableBase, IDialogAware
    {
        private PrismMessageBoxInfo _pmbi = new PrismMessageBoxInfo();
        private readonly string _stringVisible = Visibility.Visible.ToString();
        private readonly string _stringCollapsed = Visibility.Collapsed.ToString();

        /********************
         * IDialogAware
         ********************/
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }
        private string _title;

        public bool ShowTitle
        {
            get { return _showTitle; }
            set { SetProperty(ref _showTitle, value); }
        }
        private bool _showTitle;

        public SolidColorBrush TitleBackground
        {
            get { return _titleBackground; }
            set { SetProperty(ref _titleBackground, value); }
        }
        private SolidColorBrush _titleBackground;

        public event Action<IDialogResult> RequestClose;
        public virtual void RaiseRequestClose(IDialogResult dialogResult)
            => RequestClose?.Invoke(dialogResult);
        public bool CanCloseDialog() => true;
        public void OnDialogClosed() { }

        /// <summary>
        /// 確認並打包傳回值，關閉Dialog
        /// </summary>
        public DelegateCommand<string> CloseDialogCommand
            => _closeDialogCommand ??= new DelegateCommand<string>(ExecuteCloseDialogCommand);
        protected virtual void ExecuteCloseDialogCommand(string parameter)
        {
            switch (parameter)
            {
                case "OK":
                    _pmbi.Result = ButtonResult.OK;
                    break;

                case "Yes":
                    _pmbi.Result = ButtonResult.Yes;
                    break;

                case "No":
                    _pmbi.Result = ButtonResult.No;
                    break;

                case "Retry":
                    _pmbi.Result = ButtonResult.Retry;
                    break;

                case "Ignore":
                    _pmbi.Result = ButtonResult.Ignore;
                    break;

                case "Abort":
                    _pmbi.Result = ButtonResult.Abort;
                    break;

                case "Cancel":
                    _pmbi.Result = ButtonResult.Cancel;
                    break;

                default:
                    _pmbi.Result = ButtonResult.Abort;
                    break;
            }

            DialogParameters paras = new()
            {
                {
                    "Message",
                    JsonConvert.SerializeObject(_pmbi, new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore
                    })
                }
            };

            RaiseRequestClose(new DialogResult(_pmbi.Result, paras));
        }
        private DelegateCommand<string> _closeDialogCommand;

        /// <summary>
        /// 解開傳入的參數，並確認需要那些輸入框
        /// </summary>
        /// <param name="parameters">。</param>
        public void OnDialogOpened(IDialogParameters parameters)
        {
            _pmbi = JsonConvert.DeserializeObject<PrismMessageBoxInfo>(parameters.GetValue<string>("Message"));
            Title = _pmbi.Title;
            Message = _pmbi.Message;
            ImageType = _pmbi.Image;

            ShowTitle = Title != "";

            // OK
            if (!string.IsNullOrEmpty(_pmbi.OK))
            {
                OkCaption = _pmbi.OK;
                OkVisibility = _stringVisible;
                //OkFocusable = true;
            }
            else
            {
                OkVisibility = _stringCollapsed;
                //OkFocusable = false;
            }

            // Cancel
            if (!string.IsNullOrEmpty(_pmbi.Cancel))
            {
                CancelCaption = _pmbi.Cancel;
                CancelVisibility = _stringVisible;
                //CancelFocusable = true;
            }
            else
            {
                CancelVisibility = _stringCollapsed;
                //CancelFocusable = false;
            }

            // Yes
            if (!string.IsNullOrEmpty(_pmbi.Yes))
            {
                YesCaption = _pmbi.Yes;
                YesVisibility = _stringVisible;
                //YesFocusable = true;
            }
            else
            {
                YesVisibility = _stringCollapsed;
                //YesFocusable = false;
            }

            // No
            if (!string.IsNullOrEmpty(_pmbi.No))
            {
                NoCaption = _pmbi.No;
                NoVisibility = _stringVisible;
                //NoFocusable = true;
            }
            else
            {
                NoVisibility = _stringCollapsed;
                //NoFocusable = false;
            }

            // Retry
            if (!string.IsNullOrEmpty(_pmbi.Retry))
            {
                RetryCaption = _pmbi.Retry;
                RetryVisibility = _stringVisible;
                //RetryFocusable = true;
            }
            else
            {
                RetryVisibility = _stringCollapsed;
                //RetryFocusable = false;
            }

            // Ignore
            if (!string.IsNullOrEmpty(_pmbi.Ignore))
            {
                IgnoreCaption = _pmbi.Ignore;
                IgnoreVisibility = _stringVisible;
                //IgnoreFocusable = true;
            }
            else
            {
                IgnoreVisibility = _stringCollapsed;
                //IgnoreFocusable = false;
            }

            // Abort
            if (!string.IsNullOrEmpty(_pmbi.Abort))
            {
                AbortCaption = _pmbi.Abort;
                AbortVisibility = _stringVisible;
                //AbortFocusable = true;
            }
            else
            {
                AbortVisibility = _stringCollapsed;
                //AbortFocusable = false;
            }

            // Image
            Icon icon;
            switch (_pmbi.Image)
            {
                // 16 (X), Hand, Stop
                case MessageBoxImage.Error:
                    icon = SystemIcons.Hand;
                    TitleBackground = Brushes.Firebrick;
                    break;

                // 48 (!) - Exclamation
                case MessageBoxImage.Warning:
                    icon = SystemIcons.Warning;
                    TitleBackground = Brushes.Sienna;
                    break;

                // 32 (?)
                case MessageBoxImage.Question:
                    icon = SystemIcons.Question;
                    TitleBackground = Brushes.DarkGreen;
                    break;

                // 64 (i) - Information
                case MessageBoxImage.Information:
                default:
                    icon = SystemIcons.Information;
                    TitleBackground = Brushes.Navy;
                    break;

                    //default:
                    //    icon = null;
                    //    TitleBackground = Brushes.SlateGray;
                    //    break;
            }

            if (icon != null)
            {
                ImageSource = Imaging.CreateBitmapSourceFromHIcon(icon.Handle,
                                                                  Int32Rect.Empty,
                                                                  BitmapSizeOptions.FromEmptyOptions());
                ImageVisibility = _stringVisible;
            }
            else
            {
                ImageVisibility = _stringCollapsed;
            }
        }

        /********************
         * Datas
         ********************/
        public string Message
        {
            get { return _message; }
            set { SetProperty(ref _message, value); }
        }
        private string _message;

        // Image
        public ImageSource ImageSource
        {
            get { return _imageSource; }
            set { SetProperty(ref _imageSource, value); }
        }
        private ImageSource _imageSource;

        public string ImageVisibility
        {
            get { return _imageVisibility; }
            set { SetProperty(ref _imageVisibility, value); }
        }
        private string _imageVisibility;

        public MessageBoxImage ImageType
        {
            get { return _imageType; }
            set { SetProperty(ref _imageType, value); }
        }
        private MessageBoxImage _imageType;

        // OK
        public string OkCaption
        {
            get { return _okCaption; }
            set { SetProperty(ref _okCaption, value); }
        }
        private string _okCaption;

        public string OkVisibility
        {
            get { return _okVisibility; }
            set { SetProperty(ref _okVisibility, value); }
        }
        private string _okVisibility;

        public bool OkFocusable
        {
            get { return _okFocusable; }
            set { SetProperty(ref _okFocusable, value); }
        }
        private bool _okFocusable;

        // Yes
        public string YesCaption
        {
            get { return _yesCaption; }
            set { SetProperty(ref _yesCaption, value); }
        }
        private string _yesCaption;

        public string YesVisibility
        {
            get { return _yesVisibility; }
            set { SetProperty(ref _yesVisibility, value); }
        }
        private string _yesVisibility;

        public bool YesFocusable
        {
            get { return _yesFocusable; }
            set { SetProperty(ref _yesFocusable, value); }
        }
        private bool _yesFocusable;

        // No
        public string NoCaption
        {
            get { return _noCaption; }
            set { SetProperty(ref _noCaption, value); }
        }
        private string _noCaption;

        public string NoVisibility
        {
            get { return _noVisibility; }
            set { SetProperty(ref _noVisibility, value); }
        }
        private string _noVisibility;

        public bool NoFocusable
        {
            get { return _noFocusable; }
            set { SetProperty(ref _noFocusable, value); }
        }
        private bool _noFocusable;

        // Retry
        public string RetryCaption
        {
            get { return _retryCaption; }
            set { SetProperty(ref _retryCaption, value); }
        }
        private string _retryCaption;

        public string RetryVisibility
        {
            get { return _retryVisibility; }
            set { SetProperty(ref _retryVisibility, value); }
        }
        private string _retryVisibility;

        public bool RetryFocusable
        {
            get { return _retryFocusable; }
            set { SetProperty(ref _retryFocusable, value); }
        }
        private bool _retryFocusable;

        // Ignore
        public string IgnoreCaption
        {
            get { return _ignoreCaption; }
            set { SetProperty(ref _ignoreCaption, value); }
        }
        private string _ignoreCaption;

        public string IgnoreVisibility
        {
            get { return _ignoreVisibility; }
            set { SetProperty(ref _ignoreVisibility, value); }
        }
        private string _ignoreVisibility;

        public bool IgnoreFocusable
        {
            get { return _ignoreFocusable; }
            set { SetProperty(ref _ignoreFocusable, value); }
        }
        private bool _ignoreFocusable;

        // Abort
        public string AbortCaption
        {
            get { return _abortCaption; }
            set { SetProperty(ref _abortCaption, value); }
        }
        private string _abortCaption;

        public string AbortVisibility
        {
            get { return _abortVisibility; }
            set { SetProperty(ref _abortVisibility, value); }
        }
        private string _abortVisibility;

        public bool AbortFocusable
        {
            get { return _abortFocusable; }
            set { SetProperty(ref _abortFocusable, value); }
        }
        private bool _abortFocusable;

        // Cancel
        public string CancelCaption
        {
            get { return _cancelCaption; }
            set { SetProperty(ref _cancelCaption, value); }
        }
        private string _cancelCaption;

        public string CancelVisibility
        {
            get { return _cancelVisibility; }
            set { SetProperty(ref _cancelVisibility, value); }
        }
        private string _cancelVisibility;

        public bool CancelFocusable
        {
            get { return _cancelFocusable; }
            set { SetProperty(ref _cancelFocusable, value); }
        }
        private bool _cancelFocusable;
    }
}
