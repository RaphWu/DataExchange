﻿using Prism.Services.Dialogs;
using System.Windows;

namespace RaphaelWu.WPF.PrismMessageBox
{
    /// <summary>
    /// 以Prism IDialogService封裝的自訂對話框介面。
    /// </summary>
    public interface IPrismMessageBox
    {
        /********************
         * 主Functions
         ********************/
        /// <summary>
        /// 顯示對話框 - 以PrismMessageBoxInfo物件做為參數及傳回值。
        /// </summary>
        /// <param name="prismMessageBoxInfo"><see cref="PrismMessageBoxInfo"/>物件。</param>
        /// <returns><see cref="PrismMessageBoxInfo"/>物件。</returns>
        PrismMessageBoxInfo Show(PrismMessageBoxInfo prismMessageBoxInfo);

        /********************
         * 仿MessageBox
         ********************/
        /// <summary>
        /// 顯示對話框。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="button"><see cref="PrismMessageBoxButton"/>值，顯示的按鍵組合。</param>
        /// <param name="icon"><see cref="MessageBoxImage"/>值，顯示的圖示。</param>
        /// <param name="defaultResult"><see cref="ButtonResult"/>值，預設鍵。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult Show(string message,
                          string title,
                          MessageBoxImage icon,
                          PrismMessageBoxButton button,
                          ButtonResult defaultResult);

        /// <summary>
        /// 顯示對話框。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult Show(string message);

        /// <summary>
        /// 顯示對話框。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult Show(string message, string title);

        /// <summary>
        /// 顯示對話框。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="icon"><see cref="MessageBoxImage"/>值，顯示的圖示。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult Show(string message, MessageBoxImage icon);

        /// <summary>
        /// 顯示對話框。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="icon"><see cref="MessageBoxImage"/>值，顯示的圖示。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult Show(string message, string title, MessageBoxImage icon);

        /// <summary>
        /// 顯示對話框。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="button"><see cref="PrismMessageBoxButton"/>值，顯示的按鍵組合。</param>
        /// <param name="icon"><see cref="MessageBoxImage"/>值，顯示的圖示。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult Show(string message, string title, MessageBoxImage icon, PrismMessageBoxButton button);

        /********************
         * 擴充MessageBox
         ********************/
        /// <summary>
        /// 顯示對話框，包含一個可替換文字的OK鍵。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="okButtonText">OK鍵的替代文字。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult ShowOK(string message, string title, string okButtonText);

        /// <summary>
        /// 顯示對話框，包含一個可替換文字的OK鍵，並顯示一個圖示。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="icon"><see cref="MessageBoxImage"/>值，顯示的圖示。</param>
        /// <param name="okButtonText">OK鍵的替代文字。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult ShowOK(string message, string title, MessageBoxImage icon, string okButtonText);

        /// <summary>
        /// 顯示對話框，包含二個可替換文字的OK鍵及Cancel鍵。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="okButtonText">OK鍵的替代文字。</param>
        /// <param name="cancelButtonText">Cancenl鍵的替代文字。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult ShowOKCancel(string message, string title, string okButtonText, string cancelButtonText);

        /// <summary>
        /// 顯示對話框，包含二個可替換文字的OK鍵及Cancel鍵，並顯示一個圖示。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="icon"><see cref="MessageBoxImage"/>值，顯示的圖示。</param>
        /// <param name="okButtonText">OK鍵的替代文字。</param>
        /// <param name="cancelButtonText">Cancenl鍵的替代文字。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult ShowOKCancel(string message, string title, MessageBoxImage icon, string okButtonText, string cancelButtonText);

        ///// <summary>
        ///// 顯示對話框，包含二個可替換文字的Yes鍵及No鍵。
        ///// </summary>
        ///// <param name="message">顯示的訊息。</param>
        ///// <param name="title">對話框標題。</param>
        ///// <param name="yesButtonText">Yes鍵的替代文字。</param>
        ///// <param name="noButtonText">No鍵的替代文字。</param>
        ///// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        //ButtonResult ShowYesNo(string message, string title, string yesButtonText, string noButtonText);

        ///// <summary>
        ///// 顯示對話框，包含二個可替換文字的Yes鍵及No鍵，並顯示一個圖示。
        ///// </summary>
        ///// <param name="message">顯示的訊息。</param>
        ///// <param name="title">對話框標題。</param>
        ///// <param name="icon"><see cref="MessageBoxImage"/>值，顯示的圖示。</param>
        ///// <param name="yesButtonText">Yes鍵的替代文字。</param>
        ///// <param name="noButtonText">No鍵的替代文字。</param>
        ///// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        //ButtonResult ShowYesNo(string message, string title, MessageBoxImage icon, string yesButtonText, string noButtonText);

        /// <summary>
        /// 顯示對話框，包含三個可替換文字的Yes鍵、No鍵及Cancel鍵。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="yesButtonText">Yes鍵的替代文字。</param>
        /// <param name="noButtonText">No鍵的替代文字。</param>
        /// <param name="cancelButtonText">Cancenl鍵的替代文字。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult ShowYesNoCancel(string message, string title, string yesButtonText, string noButtonText, string cancelButtonText);

        /// <summary>
        /// 顯示對話框，包含三個可替換文字的Yes鍵、No鍵及Cancel鍵，並顯示一個圖示。
        /// </summary>
        /// <param name="message">顯示的訊息。</param>
        /// <param name="title">對話框標題。</param>
        /// <param name="icon"><see cref="MessageBoxImage"/>值，顯示的圖示。</param>
        /// <param name="yesButtonText">Yes鍵的替代文字。</param>
        /// <param name="noButtonText">No鍵的替代文字。</param>
        /// <param name="cancelButtonText">Cancenl鍵的替代文字。</param>
        /// <returns><see cref="ButtonResult"/>值，表示返回的按鍵。</returns>
        ButtonResult ShowYesNoCancel(string message, string title, MessageBoxImage icon, string yesButtonText, string noButtonText, string cancelButtonText);
    }
}
