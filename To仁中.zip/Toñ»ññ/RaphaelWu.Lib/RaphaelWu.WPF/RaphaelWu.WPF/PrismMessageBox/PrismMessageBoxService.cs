﻿using Newtonsoft.Json;
using Prism.Services.Dialogs;
using RaphaelWu.WPF.Extensions;
using System.Windows;

namespace RaphaelWu.WPF.PrismMessageBox
{
    /// <summary>
    /// PrismMessageBox Service
    /// </summary>
    public class PrismMessageBoxService : IPrismMessageBox
    {
        /********************
         * ctor
         ********************/
        private readonly IDialogService _dialog;

        public PrismMessageBoxService(IDialogService dialog)
        {
            _dialog = dialog;
        }

        /********************
         * 主Functions
         ********************/
        /// <inheritdoc/>
        public PrismMessageBoxInfo Show(PrismMessageBoxInfo pmbi)
        {
            IDialogResult result = default;
            DialogParameters paras = new()
            {
                {
                    "Message",
                    JsonConvert.SerializeObject(pmbi, new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore
                    })
                }
            };

            // 避免從不同執行緒呼叫時發生異常 (比如由PLC Polling呼叫時)
            System.Windows.Application.Current.Dispatcher.Invoke(() =>
            {
                _dialog.ShowDialog(nameof(PrismMessageBox), paras, r => { result = r; });
            });

            return result.Parameters.Count > 0
                ? JsonConvert.DeserializeObject<PrismMessageBoxInfo>(result.Parameters.GetValue<string>("Message"))
                : new() { Result = ButtonResult.Abort };
        }

        /********************
         * 仿MessageBox
         ********************/
        /// <inheritdoc/>
        public ButtonResult Show(string message,
                                 string title,
                                 MessageBoxImage icon,
                                 PrismMessageBoxButton button,
                                 ButtonResult defaultResult)
        {
            string ok = "";
            string yes = "";
            string no = "";
            string retry = "";
            string ignore = "";
            string abort = "";
            string cancel = "";

            switch (button)
            {
                case PrismMessageBoxButton.OK:
                    ok = GetResource.GetValue<string>("Button_OK");
                    break;

                case PrismMessageBoxButton.OkCancel:
                    ok = GetResource.GetValue<string>("Button_OK");
                    cancel = GetResource.GetValue<string>("Button_Cancel");
                    break;

                case PrismMessageBoxButton.YesNoCancel:
                    yes = GetResource.GetValue<string>("Button_Yes");
                    no = GetResource.GetValue<string>("Button_No");
                    cancel = GetResource.GetValue<string>("Button_Cancel");
                    break;

                case PrismMessageBoxButton.YesNo:
                    yes = GetResource.GetValue<string>("Button_Yes");
                    no = GetResource.GetValue<string>("Button_No");
                    break;

                case PrismMessageBoxButton.RetryCancel:
                    retry = GetResource.GetValue<string>("Button_Retry");
                    cancel = GetResource.GetValue<string>("Button_Cancel");
                    break;

                case PrismMessageBoxButton.RetryIgnoreAbort:
                    retry = GetResource.GetValue<string>("Button_Retry");
                    ignore = GetResource.GetValue<string>("Button_Ignore");
                    cancel = GetResource.GetValue<string>("Button_Abort");
                    break;

                case PrismMessageBoxButton.ContinueTryCancel:
                    yes = GetResource.GetValue<string>("Button_Continue");
                    retry = GetResource.GetValue<string>("Button_Retry");
                    cancel = GetResource.GetValue<string>("Button_Cancel");
                    break;

                default:
                    ok = GetResource.GetValue<string>("Button_OK");
                    break;
            }

            PrismMessageBoxInfo pmbi = new()
            {
                Message = message,
                Title = title,
                OK = ok,
                Yes = yes,
                No = no,
                Retry = retry,
                Ignore = ignore,
                Abort = abort,
                Cancel = cancel,
                Image = icon,
                DefaultResult = defaultResult,
            };
            pmbi = Show(pmbi);

            if (pmbi.Result == ButtonResult.Abort || pmbi.Result == ButtonResult.None)
                return pmbi.Result;

            switch (button)
            {
                case PrismMessageBoxButton.OK:
                    return ButtonResult.OK;

                case PrismMessageBoxButton.OkCancel:
                    return pmbi.Result == ButtonResult.OK ? ButtonResult.OK : ButtonResult.Cancel;

                case PrismMessageBoxButton.YesNo:
                    return pmbi.Result == ButtonResult.Yes ? ButtonResult.Yes : ButtonResult.No;

                case PrismMessageBoxButton.YesNoCancel:
                    if (pmbi.Result == ButtonResult.Yes)
                        return ButtonResult.Yes;
                    else if (pmbi.Result == ButtonResult.No)
                        return ButtonResult.No;
                    else
                        return ButtonResult.Cancel;

                case PrismMessageBoxButton.RetryCancel:
                    return pmbi.Result == ButtonResult.Retry ? ButtonResult.Retry : ButtonResult.Cancel;

                case PrismMessageBoxButton.RetryIgnoreAbort:
                    if (pmbi.Result == ButtonResult.Retry)
                        return ButtonResult.Retry;
                    else if (pmbi.Result == ButtonResult.Ignore)
                        return ButtonResult.Ignore;
                    else
                        return ButtonResult.Abort;

                case PrismMessageBoxButton.ContinueTryCancel:
                    if (pmbi.Result == ButtonResult.Yes)
                        return ButtonResult.Yes;
                    else if (pmbi.Result == ButtonResult.Retry)
                        return ButtonResult.No;
                    else
                        return ButtonResult.Cancel;

                default:
                    return ButtonResult.None;
            }
        }

        /// <inheritdoc/>
        public ButtonResult Show(string message)
        {
            return Show(message, string.Empty, MessageBoxImage.None, PrismMessageBoxButton.OK, ButtonResult.OK);
        }

        /// <inheritdoc/>
        public ButtonResult Show(string message, string title)
        {
            return Show(message, title, MessageBoxImage.None, PrismMessageBoxButton.OK, ButtonResult.OK);
        }

        /// <inheritdoc/>
        public ButtonResult Show(string message, MessageBoxImage icon)
        {
            if (icon == MessageBoxImage.Question)
                return Show(message, string.Empty, icon, PrismMessageBoxButton.YesNo, ButtonResult.No);
            else
                return Show(message, string.Empty, icon, PrismMessageBoxButton.OK, ButtonResult.OK);
        }

        /// <inheritdoc/>
        public ButtonResult Show(string message, string title, MessageBoxImage icon)
        {
            if (icon == MessageBoxImage.Question)
                return Show(message, title, icon, PrismMessageBoxButton.YesNo, ButtonResult.OK);
            else
                return Show(message, title, icon, PrismMessageBoxButton.OK, ButtonResult.OK);
        }

        /// <inheritdoc/>
        public ButtonResult Show(string message, string title, MessageBoxImage icon, PrismMessageBoxButton button)
        {
            return Show(message, title, icon, button, ButtonResult.OK);
        }

        /********************
         * 擴充MessageBox
         ********************/
        /// <inheritdoc/>
        public ButtonResult ShowOK(string message, string title, string okButtonText)
        {
            PrismMessageBoxInfo pmbi = new()
            {
                Message = message,
                Title = title,
                OK = okButtonText,
            };
            pmbi = Show(pmbi);

            return pmbi.Result == ButtonResult.OK ? ButtonResult.OK : ButtonResult.Abort;
        }

        /// <inheritdoc/>
        public ButtonResult ShowOK(string message, string title, MessageBoxImage icon, string okButtonText)
        {
            PrismMessageBoxInfo pmbi = new()
            {
                Message = message,
                Title = title,
                OK = okButtonText,
                Image = icon,
            };
            pmbi = Show(pmbi);

            return pmbi.Result == ButtonResult.OK ? ButtonResult.OK : ButtonResult.Abort;
        }

        /// <inheritdoc/>
        public ButtonResult ShowOKCancel(string message, string title, string okButtonText, string cancelButtonText)
        {
            PrismMessageBoxInfo pmbi = new()
            {
                Message = message,
                Title = title,
                OK = okButtonText,
                Cancel = cancelButtonText,
            };
            pmbi = Show(pmbi);

            if (pmbi.Result == ButtonResult.OK)
                return ButtonResult.OK;
            else if (pmbi.Result == ButtonResult.Cancel)
                return ButtonResult.Cancel;
            else
                return ButtonResult.Abort;
        }

        /// <inheritdoc/>
        public ButtonResult ShowOKCancel(string message, string title, MessageBoxImage icon, string okButtonText, string cancelButtonText)
        {
            PrismMessageBoxInfo pmbi = new()
            {
                Message = message,
                Title = title,
                OK = okButtonText,
                Cancel = cancelButtonText,
                Image = icon,
            };
            pmbi = Show(pmbi);

            if (pmbi.Result == ButtonResult.OK)
                return ButtonResult.OK;
            else if (pmbi.Result == ButtonResult.Cancel)
                return ButtonResult.Cancel;
            else
                return ButtonResult.Abort;
        }

        ///// <inheritdoc/>
        //public ButtonResult ShowYesNo(string message, string title, string yesButtonText, string noButtonText)
        //{
        //    PrismMessageBoxInfo pmbi = new()
        //    {
        //        Message = message,
        //        Title = title,
        //        Yes = yesButtonText,
        //        No = noButtonText,
        //    };
        //    pmbi = Show(pmbi);

        //    if (pmbi.Result == ButtonResult.Yes)
        //        return ButtonResult.Yes;
        //    else if (pmbi.Result == ButtonResult.No)
        //        return ButtonResult.No;
        //    else
        //        return ButtonResult.Abort;
        //}

        ///// <inheritdoc/>
        //public ButtonResult ShowYesNo(string message, string title, MessageBoxImage icon, string yesButtonText, string noButtonText)
        //{
        //    PrismMessageBoxInfo pmbi = new()
        //    {
        //        Message = message,
        //        Title = title,
        //        Yes = yesButtonText,
        //        No = noButtonText,
        //        Image = icon,
        //    };
        //    pmbi = Show(pmbi);

        //    if (pmbi.Result == ButtonResult.Yes)
        //        return ButtonResult.Yes;
        //    else if (pmbi.Result == ButtonResult.No)
        //        return ButtonResult.No;
        //    else
        //        return ButtonResult.Abort;
        //}

        /// <inheritdoc/>
        public ButtonResult ShowYesNoCancel(string message, string title, string yesButtonText, string noButtonText, string cancelButtonText)
        {
            PrismMessageBoxInfo pmbi = new()
            {
                Message = message,
                Title = title,
                Yes = yesButtonText,
                No = noButtonText,
                Cancel = cancelButtonText,
            };
            pmbi = Show(pmbi);

            if (pmbi.Result == ButtonResult.Yes)
                return ButtonResult.Yes;
            else if (pmbi.Result == ButtonResult.No)
                return ButtonResult.No;
            else if (pmbi.Result == ButtonResult.Cancel)
                return ButtonResult.Cancel;
            else
                return ButtonResult.Abort;
        }

        /// <inheritdoc/>
        public ButtonResult ShowYesNoCancel(string message, string title, MessageBoxImage icon, string yesButtonText, string noButtonText, string cancelButtonText)
        {
            PrismMessageBoxInfo pmbi = new()
            {
                Message = message,
                Title = title,
                Yes = yesButtonText,
                No = noButtonText,
                Cancel = cancelButtonText,
                Image = icon,
            };
            pmbi = Show(pmbi);

            if (pmbi.Result == ButtonResult.Yes)
                return ButtonResult.Yes;
            else if (pmbi.Result == ButtonResult.No)
                return ButtonResult.No;
            else if (pmbi.Result == ButtonResult.Cancel)
                return ButtonResult.Cancel;
            else
                return ButtonResult.Abort;
        }
    }
}
