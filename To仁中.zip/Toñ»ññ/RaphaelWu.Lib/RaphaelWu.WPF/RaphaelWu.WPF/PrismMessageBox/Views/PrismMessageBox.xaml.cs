﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.PrismMessageBox.Views
{
    /// <summary>
    /// Interaction logic for PrismMessageBox
    /// </summary>
    public partial class PrismMessageBox : UserControl
    {
        public PrismMessageBox()
        {
            InitializeComponent();
        }
    }
}
