﻿using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;
using RaphaelWu.WPF.PrismExtensions;
using RaphaelWu.WPF.PrismSplashScreen;

namespace RaphaelWu.WPF
{
    public class WPFModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            IEventAggregator ea = containerProvider.Resolve<IEventAggregator>();
            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "RaphaelWu.WPF初始化..." });
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterDialog<PrismMessageBox.Views.PrismMessageBox, PrismMessageBox.ViewModels.PrismMessageBoxViewModel>();
            containerRegistry.Register<PrismMessageBox.IPrismMessageBox, PrismMessageBox.PrismMessageBoxService>();

            // TabControlRegion
            containerRegistry.Register<IRegionNavigationContentLoader, ScopedRegionNavigationContentLoader>();
        }
    }
}