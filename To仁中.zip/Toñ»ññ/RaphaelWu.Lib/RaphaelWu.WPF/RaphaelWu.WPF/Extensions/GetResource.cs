﻿using System.Reflection;
using WPFLocalizeExtension.Engine;

namespace RaphaelWu.WPF.Extensions
{
    /// <summary>
    /// 取得目前語系的Resources。
    /// </summary>
    /// <remarks>參考: <see href="https://stackoverflow.com/questions/28137882/how-to-use-wpflocalizeextension-in-code-behind">Use WPFLocalizeExtension in Code-Behind</see>。</remarks>
    public static class GetResource
    {
        /// <summary>
        /// 取得資源檔內本地化的值。
        /// </summary>
        /// <typeparam name="T">資源的型別。</typeparam>
        /// <param name="assemblyName">Assembly名稱。</param>
        /// <param name="dictionaryName">Dictionary名稱。</param>
        /// <param name="key">Key。</param>
        /// <returns>型別為 T 的資源。</returns>
        public static T GetValue<T>(string assemblyName, string dictionaryName, string key)
        {
            return (T)LocalizeDictionary.Instance.GetLocalizedObject(assemblyName,
                                                                     dictionaryName,
                                                                     key,
                                                                     LocalizeDictionary.Instance.Culture);
        }

        /// <summary>
        /// 由指定的Assembly，且資源檔名稱為Resources中取得值。
        /// </summary>
        /// <typeparam name="T">資源的型別。</typeparam>
        /// <param name="assemblyName">Assembly名稱。</param>
        /// <param name="key">Key。</param>
        /// <returns>型別為 T 的資源。</returns>
        public static T GetValue<T>(string assemblyName, string key)
        {
            return (T)LocalizeDictionary.Instance.GetLocalizedObject(assemblyName,
                                                                     "Resources",
                                                                     key,
                                                                     LocalizeDictionary.Instance.Culture);
        }

        /// <summary>
        /// 在目前Assembly，且資源檔名稱為Resources中取得值。
        /// </summary>
        /// <typeparam name="T">資源的型別。</typeparam>
        /// <param name="key">Key。</param>
        /// <returns>型別為 T 的資源。</returns>
        public static T GetValue<T>(string key)
        {
            //return LocExtension.GetLocalizedValue<T>(Assembly.GetCallingAssembly().GetName().Name + ":Resources:" + key);
            return (T)LocalizeDictionary.Instance.GetLocalizedObject(Assembly.GetCallingAssembly().GetName().Name,
                                                                     "Resources",
                                                                     key,
                                                                     LocalizeDictionary.Instance.Culture);
        }
    }
}
