﻿namespace RaphaelWu.WPF.Demo.Constants
{
    public enum AppTheme
    {
        Default,
        Light,
        Dark
    }
}
