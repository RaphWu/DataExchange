﻿namespace RaphaelWu.WPF.Demo.Constants
{
    public enum logicalSymbol
    {
        AND, OR, NAND, NOR, XOR, XNOR
    }
}
