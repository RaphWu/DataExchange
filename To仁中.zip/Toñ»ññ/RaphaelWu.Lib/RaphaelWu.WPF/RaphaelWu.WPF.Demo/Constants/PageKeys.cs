﻿namespace RaphaelWu.WPF.Demo.Constants
{
    public class PageKeys
    {
        public const string Basic = nameof(Views.Basic);
        public const string Button = nameof(Views.Button);
        public const string TabControl = nameof(Views.TabControl);
        public const string GroupBox = nameof(Views.GroupBox);
        public const string DataGrid = nameof(Views.DataGrid);
        public const string FilterDataGrid = nameof(Views.FilterDataGrid);
        //public const string ZoomAndPan = nameof(Views.ZoomAndPan);
        public const string PrismMsgBox = nameof(Views.PrismMsgBox);

        public const string Converter1 = nameof(Views.Converter1);
        public const string Converter2 = nameof(Views.Converter2);
        public const string Behaviors = nameof(Views.Behaviors);
        public const string Extensions = nameof(Views.Extensions);
        public const string Effects = nameof(Views.Effects);

        // ZoomAndPan
        //public const string ColorPicDemo = nameof(Demo.ZoomAndPan.Views.ColorPicDemo);
        //public const string ScrollViewerDemo = nameof(Demo.ZoomAndPan.Views.ScrollViewerDemo);
        //public const string MatrixDemo = nameof(Demo.ZoomAndPan.Views.MatrixDemo);

        // TabControl SubPage
        public const string ViewA = nameof(Views.ViewA);
        public const string ViewB = nameof(Views.ViewB);
        public const string ViewC = nameof(Views.ViewC);

        // TEST
        public const string Other = nameof(Views.Other);
    }
}
