﻿namespace RaphaelWu.WPF.Demo.Constants
{
    public class RegionNames
    {
        public const string MainRegion = "MainRegion";
        public const string TabRegion_TabControlAdapter = "TabRegion_TabControlAdapter";
        public const string TabRegion_TabControlRegion = "TabRegion_TabControlRegion";
        public const string ZoomAndPanRegion = "ZoomAndPanRegion";
    }
}
