﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for Effects
    /// </summary>
    public partial class Effects : UserControl
    {
        public Effects()
        {
            InitializeComponent();
        }
    }
}
