﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for Other
    /// </summary>
    public partial class Other : UserControl
    {
        public Other()
        {
            InitializeComponent();
        }
    }
}
