﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for Extensions
    /// </summary>
    public partial class Extensions : UserControl
    {
        public Extensions()
        {
            InitializeComponent();
        }

        /********************
         * Set Focus on View
         ********************/
        private void Focus1Click(object sender, System.Windows.RoutedEventArgs e)
        {
            TextBox1.Focus();
        }

        private void Focus2Click(object sender, System.Windows.RoutedEventArgs e)
        {
            TextBox2.Focus();
        }

        private void Focus3Click(object sender, System.Windows.RoutedEventArgs e)
        {
            TextBox3.Focus();
        }
    }
}
