﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for Behaviors
    /// </summary>
    public partial class Behaviors : UserControl
    {
        public Behaviors()
        {
            InitializeComponent();
        }
    }
}
