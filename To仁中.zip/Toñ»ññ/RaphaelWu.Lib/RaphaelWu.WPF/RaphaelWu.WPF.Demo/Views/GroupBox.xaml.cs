﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for GroupBox
    /// </summary>
    public partial class GroupBox : UserControl
    {
        public GroupBox()
        {
            InitializeComponent();
        }
    }
}
