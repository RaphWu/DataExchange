﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for Converter2
    /// </summary>
    public partial class Converter2 : UserControl
    {
        public Converter2()
        {
            InitializeComponent();
        }
    }
}
