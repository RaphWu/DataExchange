﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for ViewC
    /// </summary>
    public partial class ViewC : UserControl
    {
        public ViewC()
        {
            InitializeComponent();
        }
    }
}
