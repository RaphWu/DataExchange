﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for Basic
    /// </summary>
    public partial class Basic : UserControl
    {
        public Basic()
        {
            InitializeComponent();
        }
    }
}
