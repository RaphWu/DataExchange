﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for DataGrid
    /// </summary>
    public partial class DataGrid : UserControl
    {
        public DataGrid()
        {
            InitializeComponent();

            IsEnabled.IsChecked = true;
            IsReadOnly.IsChecked = true;
            SelectionUnit.SelectedValue = DataGridSelectionUnit.FullRow;
            GridLinesVisibility.SelectedValue = DataGridGridLinesVisibility.All;
            HeadersVisibility.SelectedValue = DataGridHeadersVisibility.Column;
            RowHeaderWidth.Value = 20;

            CanUserResizeColumns.IsChecked = false;
            CanUserResizeRows.IsChecked = false;
            CanUserSortColumns.IsChecked = false;
            CanUserReorderColumns.IsChecked = false;
            CanUserAddRows.IsChecked = false;
            CanUserDeleteRows.IsChecked = false;
        }
    }
}
