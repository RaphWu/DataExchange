﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for Button
    /// </summary>
    public partial class Button : UserControl
    {
        public Button()
        {
            InitializeComponent();
        }
    }
}
