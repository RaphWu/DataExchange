﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for PrismMsgBox
    /// </summary>
    public partial class PrismMsgBox : UserControl
    {
        public PrismMsgBox()
        {
            InitializeComponent();
        }
    }
}
