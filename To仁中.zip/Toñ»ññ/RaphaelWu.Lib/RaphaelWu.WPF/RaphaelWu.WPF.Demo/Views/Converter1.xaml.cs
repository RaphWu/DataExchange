﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for Converter1
    /// </summary>
    public partial class Converter1 : UserControl
    {
        public Converter1()
        {
            InitializeComponent();
        }
    }
}
