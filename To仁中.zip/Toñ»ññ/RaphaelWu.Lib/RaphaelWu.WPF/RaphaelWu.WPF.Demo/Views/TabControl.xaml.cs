﻿using System.Windows.Controls;

namespace RaphaelWu.WPF.Demo.Views
{
    /// <summary>
    /// Interaction logic for TabControl
    /// </summary>
    public partial class TabControl : UserControl
    {
        public TabControl()
        {
            InitializeComponent();
        }

        /********************
         * TabControlRegion
         ********************/
        private void NaviView_TabControlRegion_Minus(object sender, System.Windows.RoutedEventArgs e)
        {
            int prevTabIndex = tabControlRegion.SelectedIndex - 1;
            if (prevTabIndex < 0)
                prevTabIndex = tabControlRegion.Items.Count - 1;
            tabControlRegion.SelectedIndex = prevTabIndex;
        }

        private void NaviView_TabControlRegion_Plus(object sender, System.Windows.RoutedEventArgs e)
        {
            int nextTabIndex = tabControlRegion.SelectedIndex + 1;
            if (nextTabIndex >= tabControlRegion.Items.Count)
                nextTabIndex = 0;
            tabControlRegion.SelectedIndex = nextTabIndex;
        }

        /********************
         * TabControlAdapter
         ********************/
        //private void NaviView_TabControlAdapter_Minus(object sender, System.Windows.RoutedEventArgs e)
        //{
        //    int prevTabIndex = tabControlAdapter.SelectedIndex - 1;
        //    if (prevTabIndex < 0)
        //        prevTabIndex = tabControlAdapter.Items.Count - 1;
        //    tabControlAdapter.SelectedIndex = prevTabIndex;
        //}

        //private void NaviView_TabControlAdapter_Plus(object sender, System.Windows.RoutedEventArgs e)
        //{
        //    int nextTabIndex = tabControlAdapter.SelectedIndex + 1;
        //    if (nextTabIndex >= tabControlAdapter.Items.Count)
        //        nextTabIndex = 0;
        //    tabControlAdapter.SelectedIndex = nextTabIndex;
        //}
    }
}
