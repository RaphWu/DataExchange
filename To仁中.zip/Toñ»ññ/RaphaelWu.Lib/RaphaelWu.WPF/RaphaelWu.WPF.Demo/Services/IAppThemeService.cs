﻿using RaphaelWu.WPF.Demo.Constants;

namespace RaphaelWu.WPF.Demo.Services
{
    // 修改自Template Studio for WPF
    /// <summary>
    /// 佈景主題服務介面。
    /// </summary>
    public interface IAppThemeService
    {
        void InitializeTheme();

        void SetTheme(AppTheme theme);

        AppTheme GetCurrentTheme();
    }
}
