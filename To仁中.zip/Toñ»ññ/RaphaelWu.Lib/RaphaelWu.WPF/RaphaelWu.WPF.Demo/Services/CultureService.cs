﻿using RaphaelWu.WPF.Demo.Models;
using System.Globalization;
using WPFLocalizeExtension.Engine;

namespace RaphaelWu.WPF.Demo.Services
{
    public class CultureService : ICultureService
    {
        private readonly SystemModel _sm = SystemModel.Instance;

        /// <inheritdoc/>
        public void SetAppCulture(string cultureTag)
        {
            try
            {
                SetAppCulture(CultureInfo.CreateSpecificCulture(cultureTag));
            }
            catch
            {
                // do nothing
            }
        }

        /// <inheritdoc/>
        public void SetAppCulture(CultureInfo cultureInfo)
        {
            _sm.SystemCultureInfo = cultureInfo;

            // 設定UI的語系
            System.Threading.Thread.CurrentThread.CurrentUICulture = _sm.SystemCultureInfo;

            // 設定語系的資料格式
            System.Threading.Thread.CurrentThread.CurrentCulture = _sm.SystemCultureInfo;

            // 設定目前應用程式所有執行緒的語系
            CultureInfo.DefaultThreadCurrentCulture = _sm.SystemCultureInfo;
            CultureInfo.DefaultThreadCurrentUICulture = _sm.SystemCultureInfo;

            // UI切換 (WPFLocalizeExtension)
            LocalizeDictionary.Instance.SetCurrentThreadCulture = true;
            LocalizeDictionary.Instance.Culture = cultureInfo;
        }
    }
}
