﻿using System.Globalization;

namespace RaphaelWu.WPF.Demo.Services
{
    public interface ICultureService
    {
        /// <summary>
        /// 設定語系。
        /// </summary>
        /// <param name="cultureTag">語系標籤。參考文檔:<br/>
        /// <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.globalization.cultureinfo?view=net-7.0#CultureNames">文化特性名稱和識別碼</see>。<br/>
        /// <see href="https://learn.microsoft.com/zh-tw/openspecs/windows_protocols/ms-lcid/a9eac961-e77d-41a6-90a5-ce1a8b0cdb9c">Product Behavior</see>。
        /// </param>
        void SetAppCulture(string cultureTag);

        /// <summary>
        /// 設定語系。
        /// </summary>
        /// <param name="cultureInfo">文化特性的資訊。官方文檔: <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.globalization.cultureinfo?view=net-7.0">CultureInfo 類別</see>。</param>
        void SetAppCulture(CultureInfo cultureInfo);
    }
}
