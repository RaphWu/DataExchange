﻿using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;
using RaphaelWu.WPF.Demo.Constants;
using RaphaelWu.WPF.Demo.Views;
using RaphaelWu.WPF.PrismSplashScreen;

namespace RaphaelWu.WPF.Demo
{
    public class MainModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            var regionManager = containerProvider.Resolve<IRegionManager>();

            // PrismSplashWindow
            IEventAggregator ea = containerProvider.Resolve<IEventAggregator>();
            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "MainModule初始化..." });

            // TabControlAdapter
            regionManager.RegisterViewWithRegion(RegionNames.TabRegion_TabControlAdapter, typeof(ViewA));
            regionManager.RegisterViewWithRegion(RegionNames.TabRegion_TabControlAdapter, typeof(ViewB));
            regionManager.RegisterViewWithRegion(RegionNames.TabRegion_TabControlAdapter, typeof(ViewC));
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
        }
    }
}
