﻿using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;
using Prism.Unity;
using RaphaelWu.WPF.Demo.Constants;
using RaphaelWu.WPF.Demo.Services;
using RaphaelWu.WPF.Demo.ViewModels;
using RaphaelWu.WPF.Demo.Views;
using RaphaelWu.WPF.PrismExtensions;
using RaphaelWu.WPF.PrismSplashScreen;
using ShowMeTheXAML;
using System.Threading.Tasks;
using System.Windows;

namespace RaphaelWu.WPF.Demo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : PrismApplication
    {
        protected override Window CreateShell()
        {
            return Container.Resolve<MainWindow>();
        }

        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.Register<ICultureService, CultureService>();
            containerRegistry.Register<IAppThemeService, AppThemeService>();

            containerRegistry.RegisterForNavigation<Views.Basic, BasicViewModel>(PageKeys.Basic);
            containerRegistry.RegisterForNavigation<Views.Button, ButtonViewModel>(PageKeys.Button);
            containerRegistry.RegisterForNavigation<Views.DataGrid, DataGridViewModel>(PageKeys.DataGrid);
            containerRegistry.RegisterForNavigation<Views.FilterDataGrid, FilterDataGridViewModel>(PageKeys.FilterDataGrid);
            containerRegistry.RegisterForNavigation<Views.GroupBox, GroupBoxViewModel>(PageKeys.GroupBox);
            containerRegistry.RegisterForNavigation<Views.TabControl, TabControlViewModel>(PageKeys.TabControl);
            //containerRegistry.RegisterForNavigation<Views.ZoomAndPan, ZoomAndPanViewModel>(PageKeys.ZoomAndPan);
            containerRegistry.RegisterForNavigation<Views.PrismMsgBox, PrismMsgBoxViewModel>(PageKeys.PrismMsgBox);

            containerRegistry.RegisterForNavigation<Views.Converter1, Converter1ViewModel>(PageKeys.Converter1);
            containerRegistry.RegisterForNavigation<Views.Converter2, Converter2ViewModel>(PageKeys.Converter2);
            containerRegistry.RegisterForNavigation<Views.Behaviors, BehaviorsViewModel>(PageKeys.Behaviors);
            containerRegistry.RegisterForNavigation<Views.Extensions, ExtensionsViewModel>(PageKeys.Extensions);
            containerRegistry.RegisterForNavigation<Views.Effects, ExtensionsViewModel>(PageKeys.Effects);

            // ZoomAndPan
            //containerRegistry.RegisterForNavigation<ZoomAndPan.Views.ColorPicDemo>(PageKeys.ColorPicDemo);
            //containerRegistry.RegisterForNavigation<ZoomAndPan.Views.ScrollViewerDemo>(PageKeys.ScrollViewerDemo);
            //containerRegistry.RegisterForNavigation<ZoomAndPan.Views.MatrixDemo, ZoomAndPan.ViewModels.MatrixDemoViewModel>(PageKeys.MatrixDemo);

            // TabControlRegion
            containerRegistry.RegisterForNavigation<Views.ViewA>(nameof(ViewA));
            containerRegistry.RegisterForNavigation<Views.ViewB>(nameof(ViewB));
            containerRegistry.RegisterForNavigation<Views.ViewC>(nameof(ViewC));

            // Test
            containerRegistry.RegisterForNavigation<Views.Other>(nameof(Other));
        }

        protected override void ConfigureModuleCatalog(IModuleCatalog moduleCatalog)
        {
            moduleCatalog.AddModule<MainModule>(); // TabControlAdapter
            moduleCatalog.AddModule<WPFModule>();
        }

        protected override async void OnInitialized()
        {
            var themeSelectorService = Container.Resolve<IAppThemeService>();
            themeSelectorService.InitializeTheme();

            // PrismSplashWindow
            IEventAggregator ea = Container.Resolve<IEventAggregator>();
            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent { Message = "系統載入完成." });
            Task.Delay(2000).Wait();

            base.OnInitialized();
            MainWindow.Activate(); // PrismSplashWindow關閉後讓主視窗取得焦點
            await Task.CompletedTask;
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            XamlDisplay.Init();
            base.OnStartup(e);
        }

        protected override void InitializeModules()
        {
            // PrismSplashWindow
            IModuleManager moduleManager = Container.Resolve<IModuleManager>();
            moduleManager.LoadModuleCompleted += ModuleManager_LoadModuleCompleted;

            IModule splashModule = Container.Resolve<PrismSplashWindowModule>();
            splashModule.OnInitialized(Container);

            IEventAggregator ea = Container.Resolve<IEventAggregator>();
            ea.GetEvent<SplashScreenInit>().Publish(new SplashScreenInit
            {
                MainTitle = "RaphaelWu.WPF 動態展示",
                Subtitle = "Second line test.",
                MainImage = "",
            });

            base.InitializeModules();
        }

        private void ModuleManager_LoadModuleCompleted(object? sender, LoadModuleCompletedEventArgs e)
        {
            // PrismSplashWindow，顯示Module運行完成訊息
            IEventAggregator ea = Container.Resolve<IEventAggregator>();
            ea.GetEvent<UpdateSplashMessageEvent>().Publish(new UpdateSplashMessageEvent
            {
                Message = $"{e.ModuleInfo.ModuleName} - {e.ModuleInfo.State}"
            });
        }

        protected override void ConfigureDefaultRegionBehaviors(IRegionBehaviorFactory regionBehaviors)
        {
            // TabControlRegion
            regionBehaviors.AddIfMissing(RegionManagerAwareBehavior.BehaviorKey, typeof(RegionManagerAwareBehavior));
            base.ConfigureDefaultRegionBehaviors(regionBehaviors);
        }

        protected override void ConfigureRegionAdapterMappings(RegionAdapterMappings regionAdapterMappings)
        {
            // TabControlAdapter
            base.ConfigureRegionAdapterMappings(regionAdapterMappings);
            regionAdapterMappings.RegisterMapping(typeof(TabControl), Container.Resolve<TabControlAdapter>());
        }
    }
}
