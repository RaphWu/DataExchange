﻿using Bogus;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Data;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class FilterDataGridViewModel : BindableBase, INavigationAware
    {
        private ICollectionView collView = null;

        /********************
         * INavigationAware
         ********************/
        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            if (NumberItems <= 0)
                NumberItems = NumberItemList[0];
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
        }

        public bool IsNavigationTarget(NavigationContext navigationContext) => true;

        /********************
         * ctor
         ********************/
        public FilterDataGridViewModel()
        {
        }

        //public DelegateCommand LoadedCommand
        //    => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
        //private void ExecuteLoadedCommand()
        //{
        //    if (SelectedMenu == -1)
        //        SelectedMenu = NumberItems[0];
        //}
        //private DelegateCommand _loadedCommand;

        public ObservableCollection<DataDefine> DataSource
        {
            get { return _dataSource; }
            set
            {
                SetProperty(ref _dataSource, value);
                collView = CollectionViewSource.GetDefaultView(value);
            }
        }
        private ObservableCollection<DataDefine> _dataSource = new();

        /// <summary>
        /// 
        /// </summary>
        public string Search
        {
            get { return _search; }
            set
            {
                SetProperty(ref _search, value);

                collView.Filter = e =>
                {
                    var item = (DataDefine)e;
                    return item != null &&
                        (item.LastName != null && item.LastName.StartsWith(value, StringComparison.OrdinalIgnoreCase)
                        || item.FirstName != null && item.FirstName.StartsWith(value, StringComparison.OrdinalIgnoreCase));
                };

                if (collView != null)
                {
                    DataSource = new ObservableCollection<DataDefine>(collView.OfType<DataDefine>());
                    //collView.Refresh();
                }
            }
        }
        private string _search;

        public int[] NumberItemList { get; } = { 10_000, 100_000, 500_000, 1_000_000 };

        public int NumberItems
        {
            get { return _numberItems; }
            set
            {
                SetProperty(ref _numberItems, value);
                Task.Run(FillData);
            }
        }
        private int _numberItems = -1;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand RefreshCommand
            => _refreshCommand ??= new DelegateCommand(ExecuteRefreshCommand);
        private void ExecuteRefreshCommand()
        {
            Task.Run(FillData);
        }
        private DelegateCommand _refreshCommand;

        /// <summary>
        /// Fill data
        /// </summary>
        private async void FillData()
        {
            var dummy = new Faker<DataDefine>()
                .RuleFor(u => u.FirstName, f => f.Name.FirstName())
                .RuleFor(u => u.LastName, f => f.Name.LastName())
                .RuleFor(u => u.Age, f => f.Random.Number(18, 50))
                .RuleFor(u => u.Salary, f => f.Random.Number(26000, 35000))
                .RuleFor(u => u.Manager, f => f.Random.Bool())
                .RuleFor(u => u.StartDate, f => f.Date.Recent(days: 100))
                .Generate(NumberItems);

            DataSource = new ObservableCollection<DataDefine>(dummy);
            Search = "";
            await Task.CompletedTask;
        }
    }

    public class DataDefine
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public double Salary { get; set; }
        public bool Manager { get; set; }
        public DateTime StartDate { get; set; }
    }
}
