﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using RaphaelWu.WPF.Demo.Constants;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class TabControlViewModel : BindableBase
    {
        private readonly IRegionManager _regionManager;

        public TabControlViewModel(IRegionManager regionManager)
        {
            _regionManager = regionManager;
        }

        /********************
         * TabControlRegion
         ********************/
        public DelegateCommand<string> NaviView_TabControlRegion
            => _naviView_TabControlRegion ??= new DelegateCommand<string>(ExecuteNaviView_TabControlRegion);
        private void ExecuteNaviView_TabControlRegion(string pageKey)
        {
            _regionManager.RequestNavigate(RegionNames.TabRegion_TabControlRegion, pageKey);
        }
        private DelegateCommand<string> _naviView_TabControlRegion;

        /********************
         * TabControlAdapter
         ********************/
        public DelegateCommand<string> NaviView_TabControlAdapter
            => _naviView_TabControlAdapter ??= new DelegateCommand<string>(ExecuteNaviView_TabControlAdapter);
        private void ExecuteNaviView_TabControlAdapter(string pageKey)
        {
            _regionManager.RequestNavigate(RegionNames.TabRegion_TabControlAdapter, pageKey);
        }
        private DelegateCommand<string> _naviView_TabControlAdapter;
    }
}
