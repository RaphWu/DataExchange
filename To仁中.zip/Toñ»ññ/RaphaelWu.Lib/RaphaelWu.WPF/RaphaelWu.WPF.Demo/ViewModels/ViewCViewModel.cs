﻿using Prism.Mvvm;
using Prism.Regions;
using RaphaelWu.WPF.PrismExtensions;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class ViewCViewModel : BindableBase, IRegionManagerAware
    {
        public string TabItemHeader
        {
            get { return _tabItemHeader; }
            set { SetProperty(ref _tabItemHeader, value); }
        }
        private string _tabItemHeader;

        public IRegionManager RegionManager { get; set; }

        public ViewCViewModel()
        {
            TabItemHeader = "TabItem C";
        }
    }
}
