﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using RaphaelWu.WPF.Demo.Constants;
using RaphaelWu.WPF.Demo.Models;
using RaphaelWu.WPF.Demo.Services;
using System.Collections.ObjectModel;
using System.Linq;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private IRegionNavigationService _navigationService;

        /********************
         * ctor
         ********************/
        private readonly IRegionManager _regionManager;
        private readonly ICultureService _cultureService;
        private readonly IAppThemeService _themeSelectorService;

        public MainWindowViewModel(IRegionManager regionManager,
                                   ICultureService cultureService,
                                   IAppThemeService themeSelectorService)
        {
            _regionManager = regionManager;
            _cultureService = cultureService;
            _themeSelectorService = themeSelectorService;

            MenuList = new ObservableCollection<MenuItemDefine>(new[]
            {
                new MenuItemDefine("Basic", PageKeys.Basic),
                new MenuItemDefine("Button & Menu", PageKeys.Button),
                new MenuItemDefine("TabControl", PageKeys.TabControl),
                new MenuItemDefine("GroupBox", PageKeys.GroupBox),
                new MenuItemDefine("DataGrid", PageKeys.DataGrid),
                new MenuItemDefine("FilterDataGrid", PageKeys.FilterDataGrid),
                //new MenuItemDefine("ZoomAndPan", PageKeys.ZoomAndPan),
                new MenuItemDefine("PrismMessageBox", PageKeys.PrismMsgBox),

                new MenuItemDefine("Converter1 & Markup", PageKeys.Converter1),
                new MenuItemDefine("Converter2", PageKeys.Converter2),
                new MenuItemDefine("Behaviors", PageKeys.Behaviors),
                new MenuItemDefine("Extensions", PageKeys.Extensions),
                new MenuItemDefine("Effects", PageKeys.Effects),
                new MenuItemDefine("Other", PageKeys.Other),
            });
        }

        public DelegateCommand LoadedCommand
            => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
        private void ExecuteLoadedCommand()
        {
            /********************
             * Navigation Service
             ********************/
            _navigationService = _regionManager.Regions[RegionNames.MainRegion].NavigationService;

            /********************
             * system
             ********************/
            CultureSelected = CultureList.Hant; // 語系設定
            //ExecuteLightThemeCommand(); // AppTheme

            /********************
             * init
             ********************/
            SelectedMenu = MenuList.First();
        }
        private DelegateCommand _loadedCommand;

        /********************
         * Theme
         ********************/
        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand LightThemeCommand
            => _lightThemeCommand ??= new DelegateCommand(ExecuteLightThemeCommand);
        private void ExecuteLightThemeCommand()
        {
            _themeSelectorService.SetTheme(AppTheme.Light);
        }
        private DelegateCommand _lightThemeCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand DarkThemeCommand
            => _darkThemeCommand ??= new DelegateCommand(ExecuteDarkThemeCommand);
        private void ExecuteDarkThemeCommand()
        {
            _themeSelectorService.SetTheme(AppTheme.Dark);
        }
        private DelegateCommand _darkThemeCommand;

        /********************
         * 
         ********************/
        /// <summary>
        /// 
        /// </summary>
        public CultureList CultureSelected
        {
            get { return _cultureSelected; }
            set
            {
                SetProperty(ref _cultureSelected, value);

                string cultureTag;
                switch (value)
                {
                    case CultureList.Hant:
                        cultureTag = "zh-Hant";
                        break;
                    case CultureList.Hans:
                        cultureTag = "zh-Hans";
                        break;
                    case CultureList.en:
                        cultureTag = "en";
                        break;
                    case CultureList.jp:
                        cultureTag = "ja-JP";
                        break;
                    default:
                        return;
                }
                _cultureService.SetAppCulture(cultureTag);
            }
        }
        private CultureList _cultureSelected;

        /********************
         * Menu
         ********************/
        public ObservableCollection<MenuItemDefine> MenuList { get; }

        public MenuItemDefine? SelectedMenu
        {
            get { return _selectedMenu; }
            set
            {
                SetProperty(ref _selectedMenu, value);
                if (value != null)
                    _navigationService.RequestNavigate(value.PageKey);
            }
        }
        private MenuItemDefine? _selectedMenu;

        public int SelectedMenuIndex
        {
            get { return _selectedMenuIndex; }
            set { SetProperty(ref _selectedMenuIndex, value); }
        }
        private int _selectedMenuIndex;
    }
}
