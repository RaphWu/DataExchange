﻿using Prism.Mvvm;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class EffectsViewModel : BindableBase
    {
        public EffectsViewModel()
        {

        }
    }
}
