﻿using Prism.Mvvm;
using RaphaelWu.WPF.Demo.Constants;
using RaphaelWu.WPF.Demo.Models;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class Converter2ViewModel : BindableBase
    {
        public Converter2ViewModel()
        {
            //DemoDictionary = new Dictionary<DemoEnum, string>
            //{
            //    [DemoEnum.Monday] = GetResource.GetValue<string>("Monday"),
            //    [DemoEnum.Tuesday] = GetResource.GetValue<string>("Tuesday"),
            //    [DemoEnum.Wednesday] = GetResource.GetValue<string>("Wednesday"),
            //    [DemoEnum.Thursday] = GetResource.GetValue<string>("Thursday"),
            //    [DemoEnum.Friday] = GetResource.GetValue<string>("Friday"),
            //    [DemoEnum.Saturday] = GetResource.GetValue<string>("Saturday"),
            //    [DemoEnum.Sunday] = GetResource.GetValue<string>("Sunday")
            //};

            EnumBindingSourceSelected = DemoEnum.Monday;
            EnumToBooleanSelected = DemoEnum.Monday;
            EnumDescriptionConverterSelected = DemoEnum.Monday;
            //DemoDictionarySelected = DemoEnum.Monday;
        }

        public string SelectedPageKey
        {
            get { return _selectedPageKey; }
            set { SetProperty(ref _selectedPageKey, value); }
        }
        private string _selectedPageKey = PageKeys.Basic;

        public DemoEnum EnumToBooleanSelected
        {
            get { return _enumToBooleanSelected; }
            set
            {
                SetProperty(ref _enumToBooleanSelected, value);
                EnumToBooleanSelectedId = (int)value;
            }
        }
        private DemoEnum _enumToBooleanSelected;

        public int EnumToBooleanSelectedId
        {
            get { return _enumToBooleanSelectedId; }
            set { SetProperty(ref _enumToBooleanSelectedId, value); }
        }
        private int _enumToBooleanSelectedId;

        public int EnumToIntegerConverterSelectedId
        {
            get { return _enumToIntegerConverterSelectedId; }
            set { SetProperty(ref _enumToIntegerConverterSelectedId, value); }
        }
        private int _enumToIntegerConverterSelectedId;

        public DemoEnum EnumBindingSourceSelected
        {
            get { return _enumBindingSourceSelected; }
            set
            {
                SetProperty(ref _enumBindingSourceSelected, value);
                EnumBindingSourceSelectedId = (int)value;
            }
        }
        private DemoEnum _enumBindingSourceSelected;

        public int EnumBindingSourceSelectedId
        {
            get { return _enumBindingSourceSelectedId; }
            set { SetProperty(ref _enumBindingSourceSelectedId, value); }
        }
        private int _enumBindingSourceSelectedId;

        public DemoEnum EnumDescriptionConverterSelected
        {
            get { return _enumDescriptionConverterSelected; }
            set
            {
                SetProperty(ref _enumDescriptionConverterSelected, value);
                EnumDescriptionConverterSelectedId = (int)EnumDescriptionConverterSelected;
            }
        }
        private DemoEnum _enumDescriptionConverterSelected;

        public int EnumDescriptionConverterSelectedId
        {
            get { return _enumDescriptionConverterSelectedId; }
            set { SetProperty(ref _enumDescriptionConverterSelectedId, value); }
        }
        private int _enumDescriptionConverterSelectedId;

        /********************
         * DictionaryValueConverter
         ********************/
        //public Dictionary<DemoEnum, string> DemoDictionary
        //{
        //    get { return _demoDictionary; }
        //    set { SetProperty(ref _demoDictionary, value); }
        //}
        //private Dictionary<DemoEnum, string> _demoDictionary;

        //public DemoEnum DemoDictionarySelected
        //{
        //    get { return _demoDictionarySelected; }
        //    set
        //    {
        //        SetProperty(ref _demoDictionarySelected, value);
        //        DemoDictionarySelectedId = (int)value;
        //    }
        //}
        //private DemoEnum _demoDictionarySelected;

        //public int DemoDictionarySelectedId
        //{
        //    get { return _demoDictionarySelectedId; }
        //    set { SetProperty(ref _demoDictionarySelectedId, value); }
        //}
        //private int _demoDictionarySelectedId;
    }
}
