﻿using Prism.Mvvm;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class ViewBViewModel : BindableBase
    {
        public string TabItemHeader
        {
            get { return _tabItemHeader; }
            set { SetProperty(ref _tabItemHeader, value); }
        }
        private string _tabItemHeader;

        public bool CloseButtonHidden
        {
            get { return _closeButtonHidden; }
            set { SetProperty(ref _closeButtonHidden, value); }
        }
        private bool _closeButtonHidden;

        public ViewBViewModel()
        {
            TabItemHeader = "TabItem B";
            CloseButtonHidden = true;
        }
    }
}
