﻿using Bogus;
using Prism.Commands;
using Prism.Mvvm;
using System.Collections.ObjectModel;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class DataGridViewModel : BindableBase
    {
        public DataGridViewModel()
        {
        }

        public DelegateCommand LoadedCommand
            => _loadedCommand ??= new DelegateCommand(ExecuteLoadedCommand);
        private void ExecuteLoadedCommand()
        {
            var dummy = new Faker<Dummy>()
                .RuleFor(u => u.ID, f => f.IndexFaker)
                .RuleFor(u => u.UserName, f => f.Name.FullName())
                .RuleFor(u => u.Money, f => f.Random.Number(26000, 35000))
                .RuleFor(u => u.Phone, f => f.Phone.PhoneNumberFormat())
                .RuleFor(u => u.Check, f => f.Random.Bool())
                .Generate(100);

            SampleData = new ObservableCollection<Dummy>(dummy);
        }
        private DelegateCommand _loadedCommand;

        public ObservableCollection<Dummy> SampleData
        {
            get { return _sampleData; }
            set { SetProperty(ref _sampleData, value); }
        }
        private ObservableCollection<Dummy> _sampleData;
    }

    public class Dummy
    {
        public int ID { get; set; }
        public string UserName { get; set; }
        public int Money { get; set; }
        public string Phone { get; set; }
        public bool Check { get; set; }
    }
}
