﻿using Prism.Mvvm;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class BasicViewModel : BindableBase
    {
        public BasicViewModel()
        {

        }
    }
}
