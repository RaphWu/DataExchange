﻿using Prism.Mvvm;
using System.Windows.Media;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class Converter1ViewModel : BindableBase
    {
        public Converter1ViewModel()
        {
            ColorA = 255;
            ColorR = 70;
            ColorG = 145;
            ColorB = 200;
            SetColorBlock();
        }

        /********************
         * MultiBinding
         ********************/
        private void CalcMultiBindingLogical()
        {
        }

        /// <summary>
        /// Input
        /// </summary>
        public bool MultiBindingSource1
        {
            get { return _multiBindingSource1; }
            set { SetProperty(ref _multiBindingSource1, value); }
        }
        private bool _multiBindingSource1;

        public bool MultiBindingSource2
        {
            get { return _multiBindingSource2; }
            set { SetProperty(ref _multiBindingSource2, value); }
        }
        private bool _multiBindingSource2;

        public bool MultiBindingSource3
        {
            get { return _multiBindingSource3; }
            set { SetProperty(ref _multiBindingSource3, value); }
        }
        private bool _multiBindingSource3;

        public bool MultiBindingSource4
        {
            get { return _multiBindingSource4; }
            set { SetProperty(ref _multiBindingSource4, value); }
        }
        private bool _multiBindingSource4;

        /// <summary>
        /// AND
        /// </summary>
        public bool IsEnabled_AND
        {
            get { return _isEnabled_AND; }
            set { SetProperty(ref _isEnabled_AND, value); }
        }
        private bool _isEnabled_AND;

        public bool Visibility_AND
        {
            get { return _visibility_AND; }
            set { SetProperty(ref _visibility_AND, value); }
        }
        private bool _visibility_AND;

        /// <summary>
        /// OR
        /// </summary>
        public bool IsEnabled_OR
        {
            get { return _isEnabled_OR; }
            set { SetProperty(ref _isEnabled_OR, value); }
        }
        private bool _isEnabled_OR;

        public bool Visibility_OR
        {
            get { return _visibility_OR; }
            set { SetProperty(ref _visibility_OR, value); }
        }
        private bool _visibility_OR;

        /// <summary>
        /// NAND
        /// </summary>
        public bool IsEnabled_NAND
        {
            get { return _isEnabled_NAND; }
            set { SetProperty(ref _isEnabled_NAND, value); }
        }
        private bool _isEnabled_NAND;

        public bool Visibility_NAND
        {
            get { return _visibility_NAND; }
            set { SetProperty(ref _visibility_NAND, value); }
        }
        private bool _visibility_NAND;

        /// <summary>
        /// NOR
        /// </summary>
        public bool IsEnabled_NOR
        {
            get { return _isEnabled_NOR; }
            set { SetProperty(ref _isEnabled_NOR, value); }
        }
        private bool _isEnabled_NOR;

        public bool Visibility_NOR
        {
            get { return _visibility_NOR; }
            set { SetProperty(ref _visibility_NOR, value); }
        }
        private bool _visibility_NOR;

        /// <summary>
        /// XOR
        /// </summary>
        public bool IsEnabled_XOR
        {
            get { return _isEnabled_XOR; }
            set { SetProperty(ref _isEnabled_XOR, value); }
        }
        private bool _isEnabled_XOR;

        public bool Visibility_XOR
        {
            get { return _visibility_XOR; }
            set { SetProperty(ref _visibility_XOR, value); }
        }
        private bool _visibility_XOR;

        /// <summary>
        /// XNOR
        /// </summary>
        public bool IsEnabled_XNOR
        {
            get { return _isEnabled_XNOR; }
            set { SetProperty(ref _isEnabled_XNOR, value); }
        }
        private bool _isEnabled_XNOR;

        public bool Visibility_XNOR
        {
            get { return _visibility_XNOR; }
            set { SetProperty(ref _visibility_XNOR, value); }
        }
        private bool _visibility_XNOR;

        /********************
         * Color轉Brush
         ********************/

        private void SetColorBlock()
        {
            BlockColor = Color.FromArgb(ColorA, ColorR, ColorG, ColorB);
        }

        /// <summary>
        /// 
        /// </summary>
        public Color BlockColor
        {
            get { return _blockColor; }
            set { SetProperty(ref _blockColor, value); }
        }
        private Color _blockColor;

        public byte ColorA
        {
            get { return _colorA; }
            set
            {
                SetProperty(ref _colorA, value);
                SetColorBlock();
            }
        }
        private byte _colorA;

        public byte ColorR
        {
            get { return _colorR; }
            set
            {
                SetProperty(ref _colorR, value);
                SetColorBlock();
            }
        }
        private byte _colorR;

        public byte ColorG
        {
            get { return _colorG; }
            set
            {
                SetProperty(ref _colorG, value);
                SetColorBlock();
            }
        }
        private byte _colorG;

        public byte ColorB
        {
            get { return _colorB; }
            set
            {
                SetProperty(ref _colorB, value);
                SetColorBlock();
            }
        }
        private byte _colorB;
    }
}
