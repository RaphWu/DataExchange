﻿using Prism.Commands;
using RaphaelWu.WPF.PrismExtensions;
using System;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class OtherViewModel : BindableBaseExt
    {
        private readonly Random random = new Random();

        public OtherViewModel()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand CreateNumber
            => _createNumber ??= new DelegateCommand(ExecuteCreateNumber);
        private void ExecuteCreateNumber()
        {
            int newValue = random.Next(5);

            var ooa = OOAText.Split();
            ooa[2] = ooa[1];
            ooa[1] = newValue.ToString();
            OOAText = string.Join(' ', ooa);

            var oo = OOText.Split();
            oo[2] = oo[1];
            oo[1] = newValue.ToString();
            OOText = string.Join(' ', oo);
        }
        private DelegateCommand _createNumber;

        public string OOAText
        {
            get { return _ooaText; }
            set { SetPropertyAlways(ref _ooaText, value); }
        }
        private string _ooaText = "0 0";

        public string OOText
        {
            get { return _ooText; }
            set { SetProperty(ref _ooText, value); }
        }
        private string _ooText = "0 0";
    }
}
