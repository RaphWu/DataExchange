﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Services.Dialogs;
using RaphaelWu.WPF.PrismMessageBox;
using System.Collections.Generic;
using System.Windows;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class PrismMsgBoxViewModel : BindableBase
    {
        private readonly IPrismMessageBox _prismMsgBox;

        private readonly string captionTitle = "標題";
        private readonly string captionMsg = "訊息";

        public PrismMsgBoxViewModel(IPrismMessageBox prismMessageBox)
        {
            _prismMsgBox = prismMessageBox;

            MsgBoxTypes = new Dictionary<MessageBoxImage, string>
            {
                { MessageBoxImage.Information, "訊息對話框" },
                { MessageBoxImage.Question, "詢問對話框" },
                { MessageBoxImage.Warning, "警告對話框" },
                { MessageBoxImage.Error, "異常對話框" },
            };
            SelectedType = MessageBoxImage.Information;
        }

        /// <summary>
        /// 對話框種類列表
        /// </summary>
        public Dictionary<MessageBoxImage, string> MsgBoxTypes
        {
            get { return _msgBoxTypes; }
            set { SetProperty(ref _msgBoxTypes, value); }
        }
        private Dictionary<MessageBoxImage, string> _msgBoxTypes;

        /// <summary>
        /// 選擇的對話框種類
        /// </summary>
        public MessageBoxImage SelectedType
        {
            get { return _selectedType; }
            set { SetProperty(ref _selectedType, value); }
        }
        private MessageBoxImage _selectedType;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="icon"></param>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        /// <returns></returns>
        private string GetMsg(MessageBoxImage icon, string str1, string str2)
        {
            string msg = default!;
            switch (SelectedType)
            {
                case MessageBoxImage.Error:
                    msg = @", """", MessageBoxImage.Error";
                    break;
                case MessageBoxImage.Warning:
                    msg = @", """", MessageBoxImage.Warning";
                    break;
                case MessageBoxImage.Question:
                    msg = @", """", MessageBoxImage.Question";
                    break;
                case MessageBoxImage.Information:
                    msg = @", """", MessageBoxImage.Informatio]";
                    break;
            };
            return $"{str1}{msg}{str2}";
        }

        private void ShowResult(ButtonResult result)
        {
            _prismMsgBox.Show($"按下的按鍵為：ButtonResult.{result}", "顯示按鍵", MessageBoxImage.Information);
        }

        /********************
         * 最簡訊息
         ********************/
        /// <summary>
        /// 無標題
        /// </summary>
        public DelegateCommand SimpleInfoCommand
            => _simpleInfoCommand ??= new DelegateCommand(ExecuteSimpleInfoCommand);
        private void ExecuteSimpleInfoCommand()
        {
            string msg = @"_prismMsgBox.Show(""最簡訊息(無標題)""";
            switch (SelectedType)
            {
                case MessageBoxImage.Error:
                    msg += @", """", MessageBoxImage.Error";
                    break;
                case MessageBoxImage.Warning:
                    msg += @", """", MessageBoxImage.Warning";
                    break;
                case MessageBoxImage.Question:
                    msg += @", """", MessageBoxImage.Question";
                    break;
                case MessageBoxImage.Information:
                    msg += @", """"[, MessageBoxImage.Information]";
                    break;
            };
            msg += ");";
            var result = _prismMsgBox.Show(msg, "", SelectedType);
            ShowResult(result);
        }
        private DelegateCommand _simpleInfoCommand;

        /// <summary>
        /// 帶標題
        /// </summary>
        public DelegateCommand SimpleInfoWithTitleCommand
            => _simpleInfoWithTitleCommand ??= new DelegateCommand(ExecuteSimpleInfoWithTitleCommand);
        private void ExecuteSimpleInfoWithTitleCommand()
        {
            string msg = $@"_prismMsgBox.Show(""最簡訊息(帶標題)"", ""{captionTitle}""";
            switch (SelectedType)
            {
                case MessageBoxImage.Error:
                    msg += @", """", MessageBoxImage.Error";
                    break;
                case MessageBoxImage.Warning:
                    msg += @", """", MessageBoxImage.Warning";
                    break;
                case MessageBoxImage.Question:
                    msg += @", """", MessageBoxImage.Question";
                    break;
                case MessageBoxImage.Information:
                    msg += @", """"[, MessageBoxImage.Information]";
                    break;
            };
            msg += ");";
            var result = _prismMsgBox.Show(msg, captionTitle, SelectedType);
            ShowResult(result);
        }
        private DelegateCommand _simpleInfoWithTitleCommand;

        /********************
         * 組合鍵
         ********************/
        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand OkCommand
            => _okCommand ??= new DelegateCommand(ExecuteOkCommand);
        private void ExecuteOkCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.Show(""{captionMsg}"", ""{captionTitle}""",
                                ", PrismMessageBoxButton.OK);");
            var result = _prismMsgBox.Show(msg, captionTitle, SelectedType, PrismMessageBoxButton.OK);
            ShowResult(result);
        }
        private DelegateCommand _okCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand OkCancelCommand
            => _okCancelCommand ??= new DelegateCommand(ExecuteOkCancelCommand);
        private void ExecuteOkCancelCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.Show(""{captionMsg}"", ""{captionTitle}""",
                                ", PrismMessageBoxButton.OkCancel);");
            var result = _prismMsgBox.Show(msg, captionTitle, SelectedType, PrismMessageBoxButton.OkCancel);
            ShowResult(result);
        }
        private DelegateCommand _okCancelCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand YesNoCommand
            => _yesNoCommand ??= new DelegateCommand(ExecuteYesNoCommand);
        private void ExecuteYesNoCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.Show(""{captionMsg}"", ""{captionTitle}""",
                                ", PrismMessageBoxButton.YesNo);");
            var result = _prismMsgBox.Show(msg, captionTitle, SelectedType, PrismMessageBoxButton.YesNo);
            ShowResult(result);
        }
        private DelegateCommand _yesNoCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand YesNoCancelCommand
            => _yesNoCancelCommand ??= new DelegateCommand(ExecuteYesNoCancelCommand);
        private void ExecuteYesNoCancelCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.Show(""{captionMsg}"", ""{captionTitle}""",
                                ", PrismMessageBoxButton.YesNoCancel);");
            var result = _prismMsgBox.Show(msg, captionTitle, SelectedType, PrismMessageBoxButton.YesNoCancel);
            ShowResult(result);
        }
        private DelegateCommand _yesNoCancelCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand RetryCancelCommand
            => _retryCancelCommand ??= new DelegateCommand(ExecuteRetryCancelCommand);
        private void ExecuteRetryCancelCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.Show(""{captionMsg}"", ""{captionTitle}""",
                                ", PrismMessageBoxButton.RetryCancel);");
            var result = _prismMsgBox.Show(msg, captionTitle, SelectedType, PrismMessageBoxButton.RetryCancel);
            ShowResult(result);
        }
        private DelegateCommand _retryCancelCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand RetryIgnoreAbortCommand
            => _retryIgnoreAbortCommand ??= new DelegateCommand(ExecuteRetryIgnoreAbortCommand);
        private void ExecuteRetryIgnoreAbortCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.Show(""{captionMsg}"", ""{captionTitle}""",
                                ", PrismMessageBoxButton.RetryIgnoreAbort);");
            var result = _prismMsgBox.Show(msg, captionTitle, SelectedType, PrismMessageBoxButton.RetryIgnoreAbort);
            ShowResult(result);
        }
        private DelegateCommand _retryIgnoreAbortCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand ContinueTryCancelCommand
            => _continueTryCancelCommand ??= new DelegateCommand(ExecuteContinueTryCancelCommand);
        private void ExecuteContinueTryCancelCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.Show(""{captionMsg}"", ""{captionTitle}""",
                                ", PrismMessageBoxButton.ContinueTryCancel);");
            var result = _prismMsgBox.Show(msg, captionTitle, SelectedType, PrismMessageBoxButton.ContinueTryCancel);
            ShowResult(result);
        }
        private DelegateCommand _continueTryCancelCommand;

        /********************
         * 自訂按鍵文字
         ********************/
        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand CustomOKCommand
            => _customOKCommand ??= new DelegateCommand(ExecuteCustomOKCommand);
        private void ExecuteCustomOKCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.ShowOK(""{captionMsg}"", ""{captionTitle}""",
                                @", ""自訂OK按鍵的文字"");");
            var result = _prismMsgBox.ShowOK(msg, captionTitle, SelectedType, "自訂OK按鍵的文字");
            ShowResult(result);
        }
        private DelegateCommand _customOKCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand CustomOKCancelCommand
            => _customOKCancelCommand ??= new DelegateCommand(ExecuteCustomOKCancelCommand);
        private void ExecuteCustomOKCancelCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.ShowOKCancel(""{captionMsg}"", ""{captionTitle}""",
                                @", ""自訂OK按鍵的文字"", ""自訂Cancel按鍵的文字"");");
            var result = _prismMsgBox.ShowOKCancel(msg, captionTitle, SelectedType, "自訂OK按鍵的文字", "自訂Cancel按鍵的文字");
            ShowResult(result);
        }
        private DelegateCommand _customOKCancelCommand;

        /// <summary>
        /// 
        /// </summary>
        public DelegateCommand CustomYesNoCancelCommand
            => _customYesNoCancelCommand ??= new DelegateCommand(ExecuteCustomYesNoCancelCommand);
        private void ExecuteCustomYesNoCancelCommand()
        {
            string msg = GetMsg(SelectedType,
                                $@"_prismMsgBox.ShowYesNoCancel(""{captionMsg}"", ""{captionTitle}""",
                                @", ""自訂Yes按鍵的文字"", ""自訂No按鍵的文字"", ""自訂Cancel按鍵的文字"");");
            var result = _prismMsgBox.ShowYesNoCancel(msg, captionTitle, SelectedType, "自訂Yes按鍵的文字", "自訂No按鍵的文字", "自訂Cancel按鍵的文字");
            ShowResult(result);
        }
        private DelegateCommand _customYesNoCancelCommand;
    }
}
