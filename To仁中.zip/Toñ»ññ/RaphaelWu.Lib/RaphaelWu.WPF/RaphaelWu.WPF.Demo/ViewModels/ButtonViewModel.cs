﻿using Prism.Mvvm;
using System.Collections.Generic;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class ButtonViewModel : BindableBase
    {
        public ButtonViewModel()
        {
            var source = new List<string>()
            {
                "Menu Item 1",
                "Menu Item 2",
                "Menu Item 3",
                "Menu Item 4",
                "Menu Item 5",
            };

            ListMenuSource = source;
            SelectedMenuItem = source[0];
        }

        public List<string> ListMenuSource
        {
            get { return _listMenuSource; }
            set { SetProperty(ref _listMenuSource, value); }
        }
        private List<string> _listMenuSource;

        public string SelectedMenuItem
        {
            get { return _selectedMenuItem; }
            set { SetProperty(ref _selectedMenuItem, value); }
        }
        private string _selectedMenuItem;
    }
}
