﻿using Prism.Mvvm;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class GroupBoxViewModel : BindableBase
    {
        public GroupBoxViewModel()
        {

        }
    }
}
