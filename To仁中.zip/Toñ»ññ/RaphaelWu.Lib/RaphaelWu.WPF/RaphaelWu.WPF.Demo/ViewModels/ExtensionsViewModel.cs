﻿using Prism.Commands;
using Prism.Mvvm;
using RaphaelWu.WPF.Demo.Models;
using RaphaelWu.WPF.Extensions;
using System;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class ExtensionsViewModel : BindableBase
    {
        public ExtensionsViewModel()
        {
        }

        /********************
         * GetResource
         ********************/
        public DelegateCommand<object> GetResourceCommand
            => _getResourceCommand ??= new DelegateCommand<object>(ExecuteGetResourceCommand);
        private void ExecuteGetResourceCommand(object obj)
        {
            if (obj != null && obj is DemoEnum day)
            {
                ResourceText = Enum.IsDefined(typeof(DemoEnum), day) ? GetResource.GetValue<string>(day.ToString()) : "";
            }
            else
            {
                ResourceText = "";
            }
        }
        private DelegateCommand<object> _getResourceCommand;

        public string ResourceText
        {
            get { return _resourceText; }
            set { SetProperty(ref _resourceText, value); }
        }
        private string _resourceText;

        /********************
         * FocusExtension
         ********************/
        public DelegateCommand Focus4Command
            => _focus4Command ??= new DelegateCommand(ExecuteFocus4Command);
        private void ExecuteFocus4Command()
        {
            IsFocused4 = true;
        }
        private DelegateCommand _focus4Command;

        public DelegateCommand Focus5Command
            => _focus5Command ??= new DelegateCommand(ExecuteFocus5Command);
        private void ExecuteFocus5Command()
        {
            IsFocused5 = true;
        }
        private DelegateCommand _focus5Command;

        public DelegateCommand Focus6Command
            => _focus6Command ??= new DelegateCommand(ExecuteFocus6Command);
        private void ExecuteFocus6Command()
        {
            IsFocused6 = true;
        }
        private DelegateCommand _focus6Command;

        public bool IsFocused4
        {
            get { return _isFocused4; }
            set { SetProperty(ref _isFocused4, value); }
        }
        private bool _isFocused4;

        public bool IsFocused5
        {
            get { return _isFocused5; }
            set { SetProperty(ref _isFocused5, value); }
        }
        private bool _isFocused5;

        public bool IsFocused6
        {
            get { return _isFocused6; }
            set { SetProperty(ref _isFocused6, value); }
        }
        private bool _isFocused6;
    }
}
