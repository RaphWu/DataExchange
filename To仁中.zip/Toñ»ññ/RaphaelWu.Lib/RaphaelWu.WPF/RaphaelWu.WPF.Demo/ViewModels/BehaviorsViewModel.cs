﻿using Bogus;
using Prism.Commands;
using Prism.Mvvm;
using System.Collections.ObjectModel;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class BehaviorsViewModel : BindableBase
    {
        private readonly Faker dummy = new();
        private static int _indexLB = -1;
        private static int _indexDG = -1;

        /// <summary>
        /// 
        /// </summary>
        public ObservableCollection<ScrollIntoViewForDataGridDemoData> ListBoxDemo
        {
            get { return _listBoxDemo; }
            set { SetProperty(ref _listBoxDemo, value); }
        }
        private ObservableCollection<ScrollIntoViewForDataGridDemoData> _listBoxDemo = new();

        public ScrollIntoViewForDataGridDemoData ListBoxDemoItem
        {
            get { return _listBoxDemoItem; }
            set { SetProperty(ref _listBoxDemoItem, value); }
        }
        private ScrollIntoViewForDataGridDemoData _listBoxDemoItem;

        /// <summary>
        /// 
        /// </summary>
        public ObservableCollection<ScrollIntoViewForDataGridDemoData> ListBoxDemoWithBehaviors
        {
            get { return _listBoxDemoWithBehaviors; }
            set { SetProperty(ref _listBoxDemoWithBehaviors, value); }
        }
        private ObservableCollection<ScrollIntoViewForDataGridDemoData> _listBoxDemoWithBehaviors = new();

        public ScrollIntoViewForDataGridDemoData ListBoxDemoWithBehaviorsItem
        {
            get { return _listBoxDemoWithBehaviorsItem; }
            set { SetProperty(ref _listBoxDemoWithBehaviorsItem, value); }
        }
        private ScrollIntoViewForDataGridDemoData _listBoxDemoWithBehaviorsItem;

        public int ListBoxDemoWithBehaviorsIndex
        {
            get { return _listBoxDemoWithBehaviorsIndex; }
            set { SetProperty(ref _listBoxDemoWithBehaviorsIndex, value); }
        }
        private int _listBoxDemoWithBehaviorsIndex;

        public DelegateCommand AddDemoData_ListBox
            => _addDemoData_ListBox ??= new DelegateCommand(ExecuteAddDemoData_ListBox);
        private void ExecuteAddDemoData_ListBox()
        {
            //string name = dummy.Name.FirstName();
            var dummy = new Faker<ScrollIntoViewForDataGridDemoData>()
                .RuleFor(u => u.FirstName, f => f.Name.FirstName())
                .RuleFor(u => u.LastName, f => f.Name.LastName())
                .Generate(10);

            foreach (var dy in dummy)
            {
                dy.Index = ++_indexLB;
                ListBoxDemo.Add(dy);
                ListBoxDemoItem = dy;

                ListBoxDemoWithBehaviors.Add(dy);
                ListBoxDemoWithBehaviorsItem = dy;
            }
        }
        private DelegateCommand _addDemoData_ListBox;

        /// <summary>
        /// 
        /// </summary>
        public ObservableCollection<ScrollIntoViewForDataGridDemoData> DataGridDemo
        {
            get { return _dataGridDemo; }
            set { SetProperty(ref _dataGridDemo, value); }
        }
        private ObservableCollection<ScrollIntoViewForDataGridDemoData> _dataGridDemo = new();

        public ScrollIntoViewForDataGridDemoData DataGridDemoItem
        {
            get { return _dataGridDemoItem; }
            set { SetProperty(ref _dataGridDemoItem, value); }
        }
        private ScrollIntoViewForDataGridDemoData _dataGridDemoItem;

        public ObservableCollection<ScrollIntoViewForDataGridDemoData> DataGridDemoWithBehaviors
        {
            get { return _dataGridDemoWithBehaviors; }
            set { SetProperty(ref _dataGridDemoWithBehaviors, value); }
        }
        private ObservableCollection<ScrollIntoViewForDataGridDemoData> _dataGridDemoWithBehaviors = new();

        public ScrollIntoViewForDataGridDemoData DataGridDemoItemWithBehaviorsItem
        {
            get { return _dataGridDemoItemWithBehaviorsItem; }
            set { SetProperty(ref _dataGridDemoItemWithBehaviorsItem, value); }
        }
        private ScrollIntoViewForDataGridDemoData _dataGridDemoItemWithBehaviorsItem;

        /// <summary>
        /// 
        /// </summary>
        public int DataGridDemoItemWithBehaviorsIndex
        {
            get { return _dataGridDemoItemWithBehaviorsIndex; }
            set { SetProperty(ref _dataGridDemoItemWithBehaviorsIndex, value); }
        }
        private int _dataGridDemoItemWithBehaviorsIndex;

        public DelegateCommand AddDemoData_DataGrid
            => _addDemoData_DataGrid ??= new DelegateCommand(ExecuteAddDemoData_DataGrid);
        private void ExecuteAddDemoData_DataGrid()
        {
            var dummy = new Faker<ScrollIntoViewForDataGridDemoData>()
                .RuleFor(u => u.FirstName, f => f.Name.FirstName())
                .RuleFor(u => u.LastName, f => f.Name.LastName())
                .Generate(10);

            foreach (var dy in dummy)
            {
                dy.Index = ++_indexDG;
                DataGridDemo.Add(dy);
                DataGridDemoItem = dy;

                DataGridDemoWithBehaviors.Add(dy);
                DataGridDemoItemWithBehaviorsItem = dy;
            }
        }
        private DelegateCommand _addDemoData_DataGrid;
    }

    public class ScrollIntoViewForDataGridDemoData
    {
        public int Index { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
