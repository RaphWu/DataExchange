﻿using Prism.Mvvm;

namespace RaphaelWu.WPF.Demo.ViewModels
{
    public class ViewAViewModel : BindableBase
    {
        public string TabItemHeader
        {
            get { return _tabItemHeader; }
            set { SetProperty(ref _tabItemHeader, value); }
        }
        private string _tabItemHeader;

        public ViewAViewModel()
        {
            TabItemHeader = "TabItem A";
        }
    }
}
