﻿using System;
using System.Globalization;

namespace RaphaelWu.WPF.Demo.Models
{
    public class SystemModel
    {
        private SystemModel() { }
        private static readonly Lazy<SystemModel> _instance = new(() => new SystemModel());
        public static SystemModel Instance => _instance.Value;

        /********************
         * 目前的語系
         ********************/
        public CultureInfo SystemCultureInfo { get; set; }
    }
}
