﻿namespace RaphaelWu.WPF.Demo.Models
{
    public class MenuItemDefine
    {
        public MenuItemDefine(string name, string pageKey)
        {
            Name = name;
            PageKey = pageKey;
        }

        public string Name { get; }
        public string PageKey { get; }
    }
}
