﻿using RaphaelWu.WPF.Converters;
using System.ComponentModel;

namespace RaphaelWu.WPF.Demo.Models
{
    [TypeConverter(typeof(EnumDescriptionTypeConverter))]
    public enum CultureList
    {
        //[Description("繁")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Culture_Hant")]
        Hant,

        //[Description("簡")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Culture_Hans")]
        Hans,

        //[Description("英")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Culture_en")]
        en,

        //[Description("日")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Culture_jp")]
        jp,
    }
}
