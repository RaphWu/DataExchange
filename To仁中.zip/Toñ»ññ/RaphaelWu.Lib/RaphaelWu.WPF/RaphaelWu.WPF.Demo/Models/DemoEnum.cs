﻿using RaphaelWu.WPF.Converters;

namespace RaphaelWu.WPF.Demo.Models
{
    public enum DemoEnum
    {
        //[Description("週一")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Monday")]
        Monday = 1,

        //[Description("週二")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Tuesday")]
        Tuesday = 2,

        //[Description("週三")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Wednesday")]
        Wednesday = 3,

        //[Description("週四")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Thursday")]
        Thursday = 4,

        //[Description("週五")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Friday")]
        Friday = 5,

        //[Description("週六")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Saturday")]
        Saturday = 6,

        //[Description("週日")]
        [LocalizedDescription("RaphaelWu.WPF.Demo", "Sunday")]
        Sunday = 7,
    }
}
