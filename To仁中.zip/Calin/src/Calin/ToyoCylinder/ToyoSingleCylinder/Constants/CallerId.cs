﻿namespace Calin.ToyoCylinder.ToyoSingleCylinder.Constants
{
    public enum CallerId
    {
        Initializer,
        Command,
        ReadStatus,
        PortOut,
        PortIn,
        ErrorHistories,

        WatchDog,
    }
}
