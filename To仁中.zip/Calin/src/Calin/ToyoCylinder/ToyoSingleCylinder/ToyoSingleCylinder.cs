﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;
using System.Threading.Tasks;
using Calin.ToyoCylinder.ToyoSingleCylinder.Constants;
using Calin.ToyoCylinder.ToyoSingleCylinder.Models;

namespace Calin.ToyoCylinder.ToyoSingleCylinder
{
    /// <summary>
    /// TOYO電動缸 單缸控制模組。
    /// </summary>
    public partial class ToyoSingleCylinder : ToyoCylinder
    {
        private CancellationToken _token;
        private bool _useExternalCTS = false; // CancellationTokenSource 是否由外部傳入
        private CylinderParams _cp;

#if DEBUG
        private Debug _debugMessage = new Debug();
#endif

        private ConcurrentQueue<FrameStruct> _highPriorityQueue = new ConcurrentQueue<FrameStruct>(); // 最高優先權指令 Queue
        private ConcurrentQueue<FrameStruct> _retryQueue = new ConcurrentQueue<FrameStruct>(); // 重送指令 Queue
        private ConcurrentQueue<FrameStruct> _requestQueue = new ConcurrentQueue<FrameStruct>(); // 一般指令 Queue

        private bool _serialPortCloseRequest = false; // Serial Port 關閉請求，用於結束 Polling 迴圈
        private bool _pollingIsRunning = false; // Polling 迴圈是否正在執行中，用於 ClosePort 時等待

        private List<string> _errorHistories = null; // 錯誤履歷

        /// <summary>
        /// 請求發送暫停。
        /// </summary>
        /// <remarks>當有指令發送失敗須重送時，此 Flag 會 ON。此時 HighPriorityQueue 仍不會停，但 RequestQueue 會停止發送。</remarks>
        private bool _requestHolding = false;

        #region ctor

        /// <summary>
        /// TOYO 電動缸 (單缸)。
        /// </summary>
        /// <param name="station">站號。</param>
        /// <param name="portName">Serial Port 名稱。</param>
        /// <param name="baudRate">BaudRate 鮑率。</param>
        /// <param name="parity">Parity 同位位元。</param>
        /// <param name="dataBits">DataBits 資料位元。</param>
        /// <param name="stopBits">StopBits 停止位元。</param>
        /// <param name="minStroke">電動缸最小行程。</param>
        /// <param name="maxStroke">電動缸最大行程。</param>
        /// <param name="cts">CancellationTokenSource 物件。請參考 <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.threading.cancellationtokensource">CancellationTokenSource Class</see>。</param>
        public ToyoSingleCylinder(byte station,
                                  string portName,
                                  int baudRate,
                                  Parity parity,
                                  int dataBits,
                                  StopBits stopBits,
                                  double minStroke,
                                  double maxStroke)
        {
            _cp = new CylinderParams()
            {
                Station = station,
                MinStroke = minStroke,
                MaxStroke = maxStroke,
                RetryTimes = 5,
            };

            _sp = new SerialPort()
            {
                PortName = portName,
                BaudRate = baudRate,
                DataBits = dataBits,
                StopBits = stopBits,
                Parity = parity,
                ReadTimeout = 500,
                WriteTimeout = 500,
            };

            InMotion = false;

#if DEBUG
            _debugMessage.ConsoleMessage = "No Message.";
            _debugMessage.ErrorMessage = "No Error!";
#endif
        }

        #endregion

        #region Cylinder Open/Close

        /// <summary>
        /// 關閉電動缸。
        /// </summary>
        public async void CloseCylinder()
        {
            try
            {
#if DEBUG
                _debugMessage.ConsoleMessage = "正在關閉電動缸，請稍候再連線！";
#endif
                _serialPortCloseRequest = true;

                /***** .net framework 的 ConcurrentQueue 沒有 Clear()，所以改用 new 來清除沒執行完的訊息幀 *****/
                //_highPriorityQueue.Clear();
                //_retryQueue.Clear();
                //_requestQueue.Clear();
                _highPriorityQueue = new ConcurrentQueue<FrameStruct>();
                _retryQueue = new ConcurrentQueue<FrameStruct>();
                _requestQueue = new ConcurrentQueue<FrameStruct>();

                while (_pollingIsRunning)
                    await Task.Delay(5);

                if (_sp.IsOpen)
                    _sp.Close();

                await Task.Delay(500);

#if DEBUG
                _debugMessage.ConsoleMessage = "電動缸已關閉！";
#endif
                _serialPortCloseRequest = false;
                OnStatusChanged(new StatusChangedEventArgs(CylinderStatusType.CylinderClosed));
            }
            catch (Exception ex)
            {
                string eMsg = String.Concat("電動缸關閉異常: ", ex.Message);
                Console.WriteLine(eMsg);
                OnErrorOccurred(new ErrorEventArgs(eMsg));
#if DEBUG
                _debugMessage.ErrorMessage = eMsg;
#endif
            }
            finally
            {
                //NotifyPropertyChanged(nameof(IsOpen));
                //NotifyPropertyChanged(nameof(IsClose));
                NotifyPropertyChanged("IsOpen");
                NotifyPropertyChanged("IsClose");
            }
        }

        /// <summary>
        /// 開啟電動缸。
        /// </summary>
        public void OpenCylinder(object param)
        {
            try
            {
                if (param is CancellationToken token)
                {
                    _token = token;
                    _useExternalCTS = true;
                }
                else
                {
                    _rcts.Reset();
                    _token = _rcts.Token;
                    _useExternalCTS = false;
                }

                if (!_sp.IsOpen)
                {
                    _sp.Open();
                    if (_sp.IsOpen)
                    {
                        HighPriorityRequest(CallerId.Initializer, ":0110999B0004084C7630315479566702\r\n"); // 開通電動缸權限

                        Task.Factory.StartNew(() =>
                        {
                            PortAccessPolling(_token);
                        }, _token, TaskCreationOptions.LongRunning, TaskScheduler.Default);

                        StartupTime = DateTime.Now;
                        OnStatusChanged(new StatusChangedEventArgs(CylinderStatusType.CylinderOpened));
                    }
                }
            }
            catch (Exception ex)
            {
                string eMsg = String.Concat("Serial Port 開啟異常: ", ex.Message);
                Console.WriteLine(eMsg);
#if DEBUG
                _debugMessage.ErrorMessage = eMsg;
#endif
            }
            finally
            {
                //NotifyPropertyChanged(nameof(IsOpen));
                //NotifyPropertyChanged(nameof(IsClose));
                NotifyPropertyChanged("IsOpen");
                NotifyPropertyChanged("IsClose");
            }
        }

        #endregion

        #region Dispose

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
            }

            base.Dispose(disposing);
        }

        #endregion

    }
}
