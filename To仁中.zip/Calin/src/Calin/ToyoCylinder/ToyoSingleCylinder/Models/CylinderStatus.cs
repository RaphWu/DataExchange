﻿using System;

namespace Calin.ToyoCylinder.ToyoSingleCylinder
{
    /********************
     * 電動缸狀態。
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 伺服狀態 ON/FF。
        /// </summary>
        public bool ServoStatus
        {
            get { return _servoStatus; }
            private set
            {
                if (_servoStatus != value)
                {
                    _servoStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    //NotifyPropertyChanged(nameof(ServoStatusMessage));
                    NotifyPropertyChanged("Ready");
                    NotifyPropertyChanged("ServoStatusMessage");

                    if (_servoStatus)
                        OnStatusChanged(new StatusChangedEventArgs(CylinderStatusType.ServoOn));
                    else
                        OnStatusChanged(new StatusChangedEventArgs(CylinderStatusType.ServoOff));
                }
            }
        }
        private bool _servoStatus;

        /// <summary>
        /// 伺服狀態 ON/FF 的文字訊息。
        /// </summary>
        public string ServoStatusMessage
        {
            get { return Messages.GetMessage_ServoStatus(_servoStatus); }
        }

        /// <summary>
        /// 動作狀態。
        /// </summary>
        public int ActionStatus
        {
            get { return _actionStatus; }
            private set
            {
                if (_actionStatus != value)
                {
                    _actionStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private int _actionStatus;

        /// <summary>
        /// 動作狀態的文字訊息。
        /// </summary>
        public string ActionStatusMessage
        {
            get { return Messages.GetMessage_ActionStatus(_actionStatus); }
        }

        /// <summary>
        /// 到位訊號目前的狀態。
        /// </summary>
        public int InpStatus
        {
            get { return _inpStatus; }
            private set
            {
                if (_inpStatus != value)
                {
                    _inpStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private int _inpStatus;

        /// <summary>
        /// 到位訊號目前狀態的文字訊息。
        /// </summary>
        public string InpStatusMessage
        {
            get { return Messages.GetMessage_InpStatus(_inpStatus); }
        }

        /// <summary>
        /// 扭力極限狀態。
        /// </summary>
        public int TrqLmtStatus
        {
            get { return _trqLmtStatus; }
            private set
            {
                if (_trqLmtStatus != value)
                {
                    _trqLmtStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _trqLmtStatus;

        /// <summary>
        /// 扭力極限狀態的文字訊息。
        /// </summary>
        public string TrqLmtStatusMessage
        {
            get { return Messages.GetMessage_TrqLmtStatus(_trqLmtStatus); }
        }

        /// <summary>
        /// 警報狀態。
        /// </summary>
        public int AlarmStatus
        {
            get { return _alarmStatus; }
            private set
            {
                if (_alarmStatus != value)
                {
                    _alarmStatus = value;
                    NotifyPropertyChanged();

                    if (_alarmStatus != 0)
                        OnAlarmOccurred(new AlarmEventArgs(_alarmStatus));
                }
            }
        }
        private int _alarmStatus;

        /// <summary>
        /// 警報狀態的文字訊息。
        /// </summary>
        public string AlarmStatusMessage
        {
            get { return Messages.GetMessage_AlarmStatus(_alarmStatus); }
        }

        /// <summary>
        /// 故障狀態。
        /// </summary>
        public int ErrorStatus
        {
            get { return _errorStatus; }
            private set
            {
                if (_errorStatus != value)
                {
                    _errorStatus = value;
                    NotifyPropertyChanged();

                    if (_errorStatus != 0)
                        OnErrorOccurred(new ErrorEventArgs(_errorStatus));
                }
            }
        }
        private int _errorStatus;

        /// <summary>
        /// 故障狀態的文字訊息。
        /// </summary>
        public string ErrorStatusMessage
        {
            get { return Messages.GetMessage_ErrorStatus(_errorStatus); }
        }

        /// <summary>
        /// 馬達轉速 RPM。
        /// </summary>
        public int MonRpm
        {
            get { return _monRpm; }
            private set
            {
                if (_monRpm != value)
                {
                    _monRpm = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _monRpm;

        ///// <summary>
        ///// 馬達轉速。
        ///// </summary>
        //[Description("馬達轉速")]
        //public int MonSpeed { get; set; }

        /// <summary>
        /// 馬達電流值。
        /// </summary>
        public double MonCurrent
        {
            get { return _monCurrent; }
            private set
            {
                if (_monCurrent != value)
                {
                    _monCurrent = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _monCurrent;

        /// <summary>
        /// 指令現在位置。
        /// </summary>
        public double CmdNowPos
        {
            get { return _cmdNowPos; }
            private set
            {
                if (_cmdNowPos != value)
                {
                    _cmdNowPos = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _cmdNowPos;

        /// <summary>
        /// 編碼器位置。
        /// </summary>
        public double EcdPos
        {
            get { return _ecdPos; }
            private set
            {
                if (_ecdPos != value)
                {
                    _ecdPos = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _ecdPos;

        /***** 自訂狀態 *****/
        /// <summary>
        /// 電動缸是否正在運動中？
        /// </summary>
        public bool InMotion
        {
            get { return _inMotion; }
            private set
            {
                if (_inMotion != value)
                {
                    _inMotion = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");

                    if (_inMotion)
                        OnStatusChanged(new StatusChangedEventArgs(CylinderStatusType.InMotion));
                }
            }
        }
        private bool _inMotion;

        /// <summary>
        /// 程式庫啟動時間。
        /// </summary>
        public DateTime StartupTime
        {
            get { return _startupTime; }
            set
            {
                if (_startupTime != value)
                {
                    _startupTime = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private DateTime _startupTime;

        /// <summary>
        /// 程式庫運行時間。
        /// </summary>
        public TimeSpan ExecutionTime
        {
            get { return _executionTime; }
            set
            {
                if (_executionTime != value)
                {
                    _executionTime = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private TimeSpan _executionTime;
    }
}
