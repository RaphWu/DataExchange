﻿using Calin.ToyoCylinder.ToyoSingleCylinder.Constants;

namespace Calin.ToyoCylinder.ToyoSingleCylinder.Models
{
    /// <summary>
    /// 訊息幀結構。
    /// </summary>
    public struct FrameStruct
    {
        public CallerId CallerId { get; set; }
        public byte[] ByteArray { get; set; }
    }
}
