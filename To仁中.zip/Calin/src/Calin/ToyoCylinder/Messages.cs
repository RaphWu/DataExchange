﻿namespace Calin.ToyoCylinder
{
    public static class Messages
    {
        public static string GetMessage_ServoStatus(bool _servoStatus)
        {
            return _servoStatus ? "伺服ON" : "伺服OFF";
        }

        public static string GetMessage_ActionStatus(int _actionStatus)
        {
            return _actionStatus == 0 ? "停止" : _actionStatus == 1 ? "動作中" : "異常停止";
        }

        public static string GetMessage_InpStatus(int _inpStatus)
        {
            return _inpStatus == 1 ? "位置已在設定範圍內" : "尚未到達設定範圍內";
        }

        public static string GetMessage_TrqLmtStatus(int _trqLmtStatus)
        {
            return _trqLmtStatus == 1 ? "已在設定範圍內" : "未到設定範圍內";
        }

        /// <summary>
        /// 取得 AlarmStatus 的訊息對照。
        /// </summary>
        /// <param name="alarmStatus">AlarmStatus 碼。</param>
        /// <returns>相對應的訊息。</returns>
        public static string GetMessage_AlarmStatus(int alarmStatus)
        {
            switch (alarmStatus)
            {
                case 0:
                    return "無警報";
                case 1:
                    return "Loop error";
                case 2:
                    return "Full Count";
                case 3:
                    return "過速度";
                case 4:
                    return "增益值調整不良";
                case 5:
                    return "過電壓";
                case 6:
                    return "初期化異常";
                case 7:
                    return "EEPROM 異常";
                case 8:
                    return "主迴路電源電壓不足";
                case 9:
                    return "過電流";
                case 10:
                    return "回生異常";
                case 11:
                    return "緊急停止";
                case 12:
                    return "馬達斷線";
                case 13:
                    return "編碼器斷線";
                case 14:
                    return "保護電流值";
                case 15:
                    return "電源再投入";
                case 16:
                    return "動作超時";
                default:
                    return "不明錯誤";
            }
        }

        /// <summary>
        /// 取得 ErrorStatus 的訊息對照。
        /// </summary>
        /// <param name="alarmStatus">ErrorStatus 碼。</param>
        /// <returns>相對應的訊息。</returns>
        internal static string GetMessage_ErrorStatus(int errorStatus)
        {
            switch (errorStatus)
            {
                case 0:
                    return "沒有錯誤";
                case 1:
                    return "在動作中接收動作指令";
                case 2:
                    return "上下限錯誤";
                case 3:
                    return "位置錯誤";
                case 4:
                    return "格式錯誤";
                case 5:
                    return "控制模式錯誤";
                case 6:
                    return "斷電重開";
                case 7:
                    return "初始化未完成";
                case 8:
                    return "Servo ON/OFF 錯誤";
                case 9:
                    return "LOCK";
                case 10:
                    return "軟體極限";
                case 11:
                    return "參數寫入權限不足";
                case 12:
                    return "原點復歸未完成";
                case 13:
                    return "剎車已解除";
                default:
                    return "不明錯誤";
            }
        }
    }
}
