﻿using System;

namespace Calin.ToyoCylinder
{
    /// <summary>
    /// TOYO 電動缸事件。
    /// </summary>
    public partial class ToyoCylinder
    {
        /********************
         * 參數
         ********************/
        /// <summary>
        /// 狀態改變事件參數。
        /// </summary>
        public class StatusChangedEventArgs : EventArgs
        {
            public StatusChangedEventArgs(CylinderStatusType id)
            {
                CylinderStatus = id;
            }

            public CylinderStatusType CylinderStatus { get; }
        }

        /// <summary>
        /// 警告事件參數。
        /// </summary>
        public class AlarmEventArgs : EventArgs
        {
            public AlarmEventArgs(int alarmCode)
            {
                Message = Messages.GetMessage_AlarmStatus(alarmCode);
                AlarmCode = alarmCode;
            }

            public AlarmEventArgs(string message)
            {
                Message = message;
                AlarmCode = -1;
            }

            public int AlarmCode { get; }
            public string Message { get; }
        }

        /// <summary>
        /// 錯誤事件參數。
        /// </summary>
        public class ErrorEventArgs : EventArgs
        {
            public ErrorEventArgs(int errorCode)
            {
                Message = Messages.GetMessage_ErrorStatus(errorCode);
                ErrorCode = errorCode;
            }

            public ErrorEventArgs(string message)
            {
                Message = message;
                ErrorCode = -1;
            }

            public int ErrorCode { get; }
            public string Message { get; }
        }

        /********************
         * 事件定義
         ********************/
        /// <summary>
        /// 狀態改變事件。
        /// </summary>
        public event EventHandler<StatusChangedEventArgs> StatusChanged;

        /// <summary>
        /// 警告事件。
        /// </summary>
        public event EventHandler<AlarmEventArgs> AlarmOccurred;

        /// <summary>
        /// 錯誤事件。
        /// </summary>
        public event EventHandler<ErrorEventArgs> ErrorOccurred;

        /********************
         * 事件觸發
         ********************/
        protected virtual void OnStatusChanged(StatusChangedEventArgs e)
        {
            if (StatusChanged != null)
                StatusChanged.Invoke(this, e);
        }

        protected virtual void OnAlarmOccurred(AlarmEventArgs e)
        {
            if (AlarmOccurred != null)
                AlarmOccurred.Invoke(this, e);
        }

        protected virtual void OnErrorOccurred(ErrorEventArgs e)
        {
            if (ErrorOccurred != null)
                ErrorOccurred.Invoke(this, e);
        }
    }
}
