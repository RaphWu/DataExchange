﻿using System;

namespace Calin.ToyoCylinder
{
    public static class LRC
    {
        /// <summary>
        /// 計算 LRC。
        /// </summary>
        /// <param name="frame">要計算的訊息幀。</param>
        /// <returns>計算的 LRC 值。</returns>
        public static byte Lrc(byte[] frame)
        {
            byte lrc = 0;
            for (int i = 0; i < frame.Length; i++)
                lrc += frame[i];

            return (byte)((~lrc + 1) & 0xFF);
            //return (byte)((lrc ^ 0xFF) + 1);
        }

        /// <summary>
        /// 計算 LRC。
        /// </summary>
        /// <param name="frame">要計算的訊息幀。</param>
        /// <param name="fullFrame">是否為完整訊息幀？<br/>true: 訊息幀末端有包含 LRC。<br/>false: 訊息幀末端末包含 LRC。</param>
        /// <returns>計算的 LRC 值。</returns>
        public static byte Lrc(byte[] frame, bool fullFrame)
        {
            if (fullFrame && frame.Length > 1)
                Array.Resize(ref frame, frame.Length - 1);

            return Lrc(frame);
        }

        public static byte AsciiLrc(string frame)
        {
            byte lrc = 0;
            if (frame.Substring(0, 1) == ":")
                frame = frame.Substring(1);

            for (int i = 0; i < frame.Length; i += 2)
            {
                int t = Convert.ToInt16(frame.Substring(i, 2), 16);
                lrc += (byte)t;
            }

            return (byte)((lrc ^ 0xFF) + 1);
        }
    }
}
