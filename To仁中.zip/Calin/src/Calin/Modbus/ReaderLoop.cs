﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Calin.Modbus.Contants;
using Calin.Modbus.Models;

namespace Calin.Modbus
{
    public partial class ModbusMaster
    {
        /// <summary>
        /// 啟動讀取迴圈。
        /// </summary>
        private void StartReaderLoop()
        {
            _readerTask = Task.Run(async () =>
            {
                var token = _readerCts.Token;
                try
                {
                    while (!token.IsCancellationRequested)
                    {
                        ModbusFrame frame = null;
                        try
                        {
                            frame = await ReadFrameAsync(token).ConfigureAwait(false);
                        }
                        catch (TimeoutException)
                        {
                            continue;
                        }
                        catch (OperationCanceledException)
                        {
                            break;
                        }
                        catch (Exception ex)
                        {
                            OnError?.Invoke(ex);
                            continue;
                        }

                        if (frame != null)
                            DispatchFrame(frame);
                    }
                }
                catch (Exception ex)
                {
                    OnError?.Invoke(ex);
                }
            }, _readerCts.Token);
        }

        /// <summary>
        /// 讀取一個 Modbus 幀。
        /// </summary>
        /// <param name="token">取消標記。</param>
        /// <returns>讀取到的 Modbus 幀。</returns>
        private async Task<ModbusFrame> ReadFrameAsync(CancellationToken token)
        {
            if (_mode == ModbusMode.RTU)
                return await ReadRtuFrameAsync(token).ConfigureAwait(false);
            else
                return await ReadAsciiFrameAsync(token).ConfigureAwait(false);
        }

        /// <summary>
        /// 讀取一個 Modbus RTU 幀。
        /// </summary>
        /// <param name="token">取消標記。</param>
        /// <returns>讀取到的 Modbus RTU 幀。</returns>
        private async Task<ModbusFrame> ReadRtuFrameAsync(CancellationToken token)
        {
            byte slave = await ReadByteAsync(token);
            byte func = await ReadByteAsync(token);

            var payload = new List<byte>();
            // 嘗試讀到至少一個 ByteCount / Data 或 ErrorCode
            payload.Add(await ReadByteAsync(token));

            // 暫時假設不知長度 -> 繼續讀到至少 2 bytes CRC
            while (_port.BytesToRead < 2)
            {
                await Task.Delay(1, token);
            }

            while (_port.BytesToRead > 2)
            {
                payload.Add((byte)_port.ReadByte());
            }

            byte crcLo = (byte)_port.ReadByte();
            byte crcHi = (byte)_port.ReadByte();
            ushort recvCrc = (ushort)(crcLo | (crcHi << 8));

            var body = new byte[2 + payload.Count];
            body[0] = slave;
            body[1] = func;
            payload.CopyTo(body, 2);

            ushort calcCrc = CalcCrc16(body, 0, body.Length);
            if (calcCrc != recvCrc)
                throw new InvalidOperationException("CRC check failed");

            return new ModbusFrame { Address = slave, FunctionCode = func, Payload = payload.ToArray(), Raw = body };
        }

        /// <summary>
        /// 讀取一個 Modbus ASCII 幀。
        /// </summary>
        /// <param name="token">取消標記。</param>
        /// <returns>讀取到的 Modbus ASCII 幀。</returns>
        private async Task<ModbusFrame> ReadAsciiFrameAsync(CancellationToken token)
        {
            int start = await ReadByteAsync(token);
            if (start != ':') throw new InvalidOperationException("ASCII frame missing ':'");

            var hex = new List<byte>();
            while (true)
            {
                int b = await ReadByteAsync(token);
                if (b == 0x0D) // CR
                {
                    int lf = await ReadByteAsync(token);
                    if (lf != 0x0A) throw new InvalidOperationException("ASCII frame missing LF");
                    break;
                }
                hex.Add((byte)b);
            }

            byte[] bytes = new byte[hex.Count / 2];
            for (int i = 0; i < bytes.Length; i++)
            {
                string hs = Encoding.ASCII.GetString(hex.Skip(i * 2).Take(2).ToArray());
                bytes[i] = Convert.ToByte(hs, 16);
            }

            byte slave = bytes[0];
            byte func = bytes[1];
            byte[] payload = bytes.Skip(2).Take(bytes.Length - 3).ToArray(); // exclude LRC
            byte recvLrc = bytes.Last();
            byte calcLrc = CalcLrc(bytes, 0, bytes.Length - 1);
            if (recvLrc != calcLrc) throw new InvalidOperationException("LRC check failed");

            return new ModbusFrame { Address = slave, FunctionCode = func, Payload = payload, Raw = bytes };
        }

        /// <summary>
        /// 讀取一個 byte，若逾時則拋出 TimeoutException。
        /// </summary>
        /// <param name="token">取消標記。</param>
        /// <returns>讀取到的 byte。</returns>
        private async Task<byte> ReadByteAsync(CancellationToken token)
        {
            return await Task.Run(() =>
            {
                int b = _port.ReadByte();
                if (b < 0)
                    throw new TimeoutException();
                return (byte)b;
            }, token);
        }

        /// <summary>
        /// 分派讀取到的 Modbus 幀給等待的請求。
        /// </summary>
        /// <param name="frame">讀取到的 Modbus 幀。</param>
        private void DispatchFrame(ModbusFrame frame)
        {
            FrameReceived?.Invoke(frame);

            foreach (var kv in _pending.ToArray())
            {
                var req = kv.Value;
                if (req.Slave == frame.Address &&
                    req.FunctionCode == frame.FunctionCode &&
                    req.MatchPredicate?.Invoke(frame) == true)
                {
                    req.Completion.TrySetResult(frame.Payload);
                    _pending.TryRemove(req.RequestId, out _);
                }
            }
        }
    }
}
