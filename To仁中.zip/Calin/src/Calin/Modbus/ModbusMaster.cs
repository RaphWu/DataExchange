﻿using System;
using System.Collections.Concurrent;
using System.IO.Ports;
using System.Threading.Tasks;
using Calin.Core;
using Calin.Modbus.Contants;
using Calin.Modbus.Models;

namespace Calin.Modbus
{
    public partial class ModbusMaster : IDisposable
    {
        private readonly SerialPort _port;
        private readonly ModbusMode _mode;
        private readonly ByteOrder _byteOrder;
        private readonly ReusableCancellationTokenSource _readerCts = new ReusableCancellationTokenSource();
        private readonly ConcurrentDictionary<long, PendingRequest> _pending = new ConcurrentDictionary<long, PendingRequest>();
        private readonly ConcurrentDictionary<byte, Func<byte[], object>> _parsers = new ConcurrentDictionary<byte, Func<byte[], object>>();
        private Task _readerTask;
        private bool _disposed = false;
        private int _nextRequestId = 1;
        private readonly object _sendLock = new object();

        public int ReadByteTimeoutMs { get; set; } = 2000;
        public event Action<ModbusFrame> FrameReceived;
        public event Action<Exception> OnError;

        public ModbusMaster(string portName,
                            int baudRate,
                            Parity parity,
                            int dataBits,
                            StopBits stopBits,
                            ModbusMode mode = ModbusMode.ASCII,
                            ByteOrder byteOrder = ByteOrder.BigEndian)
        {
            _mode = mode;
            _byteOrder = byteOrder;
            _port = new SerialPort(portName, baudRate, parity, dataBits, stopBits)
            {
                ReadTimeout = ReadByteTimeoutMs,
                WriteTimeout = 2000
            };
            _port.Open();
            StartReaderLoop();
        }

        #region Parser registration
        public void RegisterParser<T>(byte functionCode, Func<byte[], T> parser)
        {
            _parsers[functionCode] = (b) => parser(b);
        }
        #endregion

        #region Dispose

        private void ThrowIfDisposed()
        {
            if (_disposed) throw new ObjectDisposedException(nameof(ModbusMaster));
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            _readerCts.Cancel();
            try { _readerTask?.Wait(2000); } catch { }

            _port?.Close();
            _port?.Dispose();
            _readerCts.Dispose();

            foreach (var kv in _pending)
                kv.Value.Completion.TrySetCanceled();
        }

        #endregion
    }
}
