﻿namespace Calin.Modbus
{
    public partial class ModbusMaster
    {
        private static ushort CalcCrc16(byte[] buffer, int offset, int length)
        {
            const ushort poly = 0xA001;
            ushort crc = 0xFFFF;
            for (int i = 0; i < length; i++)
            {
                crc ^= buffer[offset + i];
                for (int j = 0; j < 8; j++)
                {
                    bool lsb = (crc & 1) != 0;
                    crc >>= 1;
                    if (lsb) crc ^= poly;
                }
            }
            return crc;
        }

        private static byte CalcLrc(byte[] buffer, int offset, int length)
        {
            byte lrc = 0;
            for (int i = offset; i < offset + length; i++)
                lrc += buffer[i];
            lrc = (byte)((-(sbyte)lrc) & 0xFF);
            return lrc;
        }
    }
}
