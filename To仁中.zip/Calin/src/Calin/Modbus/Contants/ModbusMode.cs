﻿namespace Calin.Modbus.Contants
{
    public enum ModbusMode
    {
        ASCII,
        RTU,
    }
}
