﻿namespace Calin.Modbus.Models
{
    public class ModbusFrame
    {
        public byte Address { get; set; }
        public byte FunctionCode { get; set; }
        public byte[] Payload { get; set; } = new byte[0];
        public byte[] Raw { get; set; } = new byte[0];
    }
}
