﻿using System;
using System.Threading;

namespace Calin.Core
{
    /// <summary>
    /// 線程安全、多任務共用及可重用的 CancellationTokenSource 封裝。
    /// </summary>
    public class ReusableCancellationTokenSource : IDisposable
    {
        private CancellationTokenSource _cts = new CancellationTokenSource();
        private readonly object _lock = new object();
        private bool _disposed = false;

        public CancellationToken Token
        {
            get
            {
                lock (_lock)
                {
                    ThrowIfDisposed();
                    return _cts.Token;
                }
            }
        }

        public void Cancel()
        {
            lock (_lock)
            {
                if (_disposed)
                    return;
                try
                {
                    _cts.Cancel();
                }
                catch
                {
                }
            }
        }

        public void Reset()
        {
            lock (_lock)
            {
                ThrowIfDisposed();
                if (!_cts.IsCancellationRequested)
                    return;
                _cts.Dispose();
                _cts = new CancellationTokenSource();
            }
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(nameof(ReusableCancellationTokenSource));
        }

        public void Dispose()
        {
            lock (_lock)
            {
                if (_disposed)
                    return;
                _cts.Cancel();
                _cts.Dispose();
                _disposed = true;
            }
        }
    }
}