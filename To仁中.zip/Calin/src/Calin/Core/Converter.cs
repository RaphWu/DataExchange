﻿using System;
using System.Collections.Generic;

namespace Calin.Core
{
    public static class Converter
    {
        public static int GetTypeSize(Type type)
        {
            if (type == typeof(byte) || type == typeof(sbyte)) return 1;
            if (type == typeof(ushort) || type == typeof(short)) return 2;
            if (type == typeof(uint) || type == typeof(int) || type == typeof(float)) return 4;
            if (type == typeof(double) || type == typeof(ulong) || type == typeof(long)) return 8;
            return -1;
        }

        /********************
         * 整數處理
         ********************/
        public static short ToInt16(byte[] data, int startIndex)
        {
            return unchecked((short)ToUInt16(data, startIndex));
        }

        public static ushort ToUInt16(byte[] data, int startIndex)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (data.Length < startIndex + 2) throw new ArgumentOutOfRangeException(nameof(startIndex));
            return (ushort)(data[startIndex] | (data[startIndex + 1] << 8));
        }

        public static int ToInt32(byte[] data, int startIndex)
        {
            return unchecked((int)ToUInt32(data, startIndex));
        }

        public static uint ToUInt32(byte[] data, int startIndex)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (data.Length < startIndex + 4) throw new ArgumentOutOfRangeException(nameof(startIndex));
            return (uint)(data[startIndex] | (data[startIndex + 1] << 8) | (data[startIndex + 2] << 16) | (data[startIndex + 3] << 24));
        }

        public static byte[] FromInt16(short value)
        {
            return FromUInt16(unchecked((ushort)value));
        }

        public static byte[] FromUInt16(ushort value)
        {
            return new byte[] { (byte)(value & 0xFF), (byte)((value >> 8) & 0xFF) };
        }

        public static byte[] FromInt32(int value)
        {
            return FromUInt32(unchecked((uint)value));
        }

        public static byte[] FromUInt32(uint value)
        {
            return new byte[] { (byte)(value & 0xFF), (byte)((value >> 8) & 0xFF), (byte)((value >> 16) & 0xFF), (byte)((value >> 24) & 0xFF) };
        }

        /********************
         * 浮點處理
         ********************/
        public static byte[] FromFloat(float value)
        {
            byte[] bytes = BitConverter.GetBytes(value);
            if (!BitConverter.IsLittleEndian)
                Array.Reverse(bytes);
            return bytes;
        }

        public static float ToFloat(byte[] data, int startIndex)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (data.Length < startIndex + 4) throw new ArgumentOutOfRangeException(nameof(startIndex));
            byte[] bytes = new byte[4];
            Array.Copy(data, startIndex, bytes, 0, 4);
            if (!BitConverter.IsLittleEndian)
                Array.Reverse(bytes);
            return BitConverter.ToSingle(bytes, 0);
        }

        public static byte[] FromDouble(double value)
        {
            byte[] bytes = BitConverter.GetBytes(value);
            if (!BitConverter.IsLittleEndian)
                Array.Reverse(bytes);
            return bytes;
        }

        public static double ToDouble(byte[] data, int startIndex)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (data.Length < startIndex + 8) throw new ArgumentOutOfRangeException(nameof(startIndex));
            byte[] bytes = new byte[8];
            Array.Copy(data, startIndex, bytes, 0, 8);
            if (!BitConverter.IsLittleEndian)
                Array.Reverse(bytes);
            return BitConverter.ToDouble(bytes, 0);
        }

        /********************
         * 16進制字串處理
         ********************/
        public static string ToHexString(byte[] data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            return BitConverter.ToString(data).Replace("-", "");
        }


        public static string ToHexString(byte[] data, int startIndex, int length)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (data.Length < startIndex + length) throw new ArgumentOutOfRangeException(nameof(startIndex));
            byte[] bytes = new byte[length];
            Array.Copy(data, startIndex, bytes, 0, length);
            return BitConverter.ToString(bytes).Replace("-", "");
        }

        /********************
         * ASCII處理
         ********************/
        /// <summary>
        /// 將 byte[] 解析成 List<T>。
        /// </summary>
        public static List<T> ParseArray<T>(byte[] data, int startIndex = 0, ByteOrder endian = ByteOrder.LittleEndian) where T : struct
        {
            if (data == null) throw new ArgumentNullException("data");

            List<T> result = new List<T>();
            int size = Converter.GetTypeSize(typeof(T));
            if (size <= 0) throw new NotSupportedException("不支援的型別: " + typeof(T).Name);

            if (data.Length < startIndex + size)
                throw new ArgumentOutOfRangeException("startIndex");

            for (int i = startIndex; i <= data.Length - size; i += size)
            {
                byte[] slice = new byte[size];
                Array.Copy(data, i, slice, 0, size);

                if ((BitConverter.IsLittleEndian && endian == ByteOrder.BigEndian) ||
                    (!BitConverter.IsLittleEndian && endian == ByteOrder.LittleEndian))
                {
                    Array.Reverse(slice);
                }

                object value = null;
                Type t = typeof(T);

                if (t == typeof(ushort))
                    value = BitConverter.ToUInt16(slice, 0);
                else if (t == typeof(short))
                    value = BitConverter.ToInt16(slice, 0);
                else if (t == typeof(uint))
                    value = BitConverter.ToUInt32(slice, 0);
                else if (t == typeof(int))
                    value = BitConverter.ToInt32(slice, 0);
                else if (t == typeof(float))
                    value = BitConverter.ToSingle(slice, 0);
                else if (t == typeof(double))
                    value = BitConverter.ToDouble(slice, 0);
                else
                    throw new NotSupportedException("不支援的型別: " + t.Name);

                result.Add((T)value);
            }

            return result;
        }

        /// <summary>
        /// ASCII HEX 轉 byte[]，每兩個 ASCII 字元轉換成一個 byte。
        /// </summary>
        /// <param name="ascii">ASCII HEX 陣列。</param>
        /// <param name="startIndex">起始索引。</param>
        /// <param name="length">長度。</param>
        /// <returns>轉換後的 byte[]。</returns>
        public static byte[] TowAsciiHexToBytes(byte[] ascii, int startIndex, int length)
        {
            if ((length - startIndex) % 2 != 0)
                throw new ArgumentException("待轉換的陣列長度不是偶數！");

            int endIndex = startIndex + length;
            byte[] result = new byte[ascii.Length / 2];

            for (int i = startIndex; i < endIndex; i++)
                result[i] = (byte)((HexCharToByte(ascii[i * 2]) << 4) | HexCharToByte(ascii[i * 2 + 1]));

            return result;
        }

        /// <summary>
        /// 16進制字元轉數值。
        /// </summary>
        public static byte HexCharToByte(byte c)
        {
            if (c >= '0' && c <= '9') return (byte)(c - '0');
            if (c >= 'A' && c <= 'F') return (byte)(c - 'A' + 10);
            if (c >= 'a' && c <= 'f') return (byte)(c - 'a' + 10);
            throw new ArgumentException(string.Concat("不是合法 HEX 字元: ", (char)c));
        }
    }
}
