﻿namespace Calin.Core
{
    public static class EndianBitConverter
    {
        public static ushort ToUInt16(byte[] bytes, int startIndex, ByteOrder order)
        {
            return order == ByteOrder.BigEndian
                ? (ushort)(bytes[startIndex] << 8 | bytes[startIndex + 1])
                : (ushort)(bytes[startIndex + 1] << 8 | bytes[startIndex]);
        }

        public static byte[] GetBytes(ushort value, ByteOrder order)
        {
            return order == ByteOrder.BigEndian
                ? new byte[] { (byte)(value >> 8), (byte)(value & 0xFF) }
                : new byte[] { (byte)(value & 0xFF), (byte)(value >> 8) };
        }
    }
}
