﻿namespace Calin.Core
{
    /// <summary>
    /// 指定資料的位元組順序。
    /// </summary>
    public enum ByteOrder
    {
        BigEndian,
        LittleEndian,
    }
}
