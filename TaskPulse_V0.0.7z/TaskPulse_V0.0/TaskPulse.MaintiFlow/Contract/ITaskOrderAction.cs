﻿using System.Threading.Tasks;

namespace Calin.TaskPulse.MaintiFlow.Contract
{
    public interface ITaskOrderAction
    {
        /// <summary>
        /// 建立新工單。
        /// </summary>
        /// <returns>操作是否完成。</returns>
        Task<bool> CreateNewFlow();

        /// <summary>
        /// 取消工單。
        /// </summary>
        /// <param name="orderId">工單代號。</param>
        /// <returns>操作是否完成。</returns>
        Task<bool> CancelFlow();

        /// <summary>
        /// 接單。
        /// </summary>
        /// <param name="orderId">工單代號。</param>
        /// <returns>操作是否完成。</returns>
        Task<bool> AcceptFlow();

        /// <summary>
        /// 維護完成。
        /// </summary>
        /// <param name="orderId">工單代號。</param>
        /// <returns>操作是否完成。</returns>
        Task<bool> MaintiWork();

        /// <summary>
        /// 工單確認。
        /// </summary>
        /// <param name="orderId">工單代號。</param>
        /// <returns>操作是否完成。</returns>
        Task<bool> FlowConfirmed();
    }
}
