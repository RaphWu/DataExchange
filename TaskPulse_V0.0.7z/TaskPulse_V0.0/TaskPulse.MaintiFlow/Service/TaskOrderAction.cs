﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Views;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public partial class MaintiFlowService : ITaskOrderAction
    {
        /// <inheritdoc/>
        public async Task<bool> CreateNewFlow()
        {
            using (var createFlow = _scope.Resolve<MF_CreateFlow>())
            {
                createFlow.Title = "新建工單";
                if (createFlow.ShowDialog() == DialogResult.OK)
                {
                    _cacheManager.RequestTaskOrderUpdate();
                    await _cacheManager.WaitForTaskOrderAvailableAsync();
                    //_ = WeakReferenceMessenger.Default.Send(RequestTaskOrderDataUpdate.Instance);

                    using (var taskOrderView = _scope.Resolve<NewTaskOrderViewer>())
                    {
                        taskOrderView.Title = "工單已建立";
                        taskOrderView.NewWorkOrderNos = createFlow.NewWorkOrderNos;
                        taskOrderView.Initialize();
                        MyFormEx.ShowDialogWithMask(taskOrderView);
                        return true;
                    }
                }
            }
            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> CancelFlow()
        {
            var notAccepted = _flowData.TaskOrders.Where(t => t.Status == FlowStatus.NewTaskOrder).ToList();
            if (notAccepted.Any())
            {
                using (var acceptFlow = _scope.Resolve<MF_AcceptFlow>())
                {
                    acceptFlow.Title = "取消工單";
                    acceptFlow.OkCaption = "取消工單";
                    acceptFlow.Orders = notAccepted;
                    if (MyFormEx.ShowDialogWithMask(acceptFlow) == DialogResult.OK)
                    {
                        if (MessageBox.Show($"確定要取消工單？\n維護工單：\n{string.Join(Environment.NewLine, acceptFlow.SelectedOrder)}",
                             "取消工單確認",
                             MessageBoxButtons.OKCancel,
                             MessageBoxIcon.Question) == DialogResult.OK)
                        {
                            try
                            {
                                List<TaskOrder> tos = new List<TaskOrder>();
                                foreach (string orderId in acceptFlow.SelectedOrder)
                                {
                                    TaskOrder to = _context.TaskOrders.FirstOrDefault(t => t.WorkOrderNo == orderId);
                                    to.Status = FlowStatus.Completed;
                                    to.FillingTime = DateTime.Now;
                                    tos.Add(to);
                                }
                                await _context.SaveChangesAsync();
                                _cacheManager.RequestTaskOrderUpdate();
                                //_ = WeakReferenceMessenger.Default.Send(RequestTaskOrderDataUpdate.Instance);

                                // send email
                                StringBuilder mail = new StringBuilder();
                                var employee = _coreData.Employees.FirstOrDefault(e => e.Id == _user.UserId);
                                mail.Append("<table><caption>取消工單</caption>");
                                mail.Append("<tr>");
                                mail.Append($"<td>{PropertyText.Title.Performer}</td>");
                                mail.Append($"<td>{_user.UserName}</td>");
                                mail.Append("</tr>");

                                mail.Append("<tr>");
                                mail.Append("<td>取消時間</td>");
                                mail.Append($"<td>{tos[0].FillingTimeString}</td>");
                                mail.Append("</tr>");
                                mail.Append("</table>");

                                mail.Append("<table><caption>工單列表</caption>");
                                mail.Append("<tr>");
                                mail.Append("<th>工單編號</th>");
                                mail.Append("<th>建檔人員</th>");
                                mail.Append("<th>建檔日期</th>");
                                mail.Append("</tr>");

                                mail.Append("<tr>");
                                foreach (var to in tos)
                                {
                                    mail.Append($"<td>{to.WorkOrderNo}</td>");
                                    mail.Append("<th>{to.CreatorNameWithId}</td>");
                                    mail.Append("<td>{to.CreationDateString}</td>");
                                }
                                mail.Append("</tr>");
                                mail.Append("</table>");

                                List<string> orderInfo = tos
                                    .OrderBy(t => t.WorkOrderNo)
                                    .Select(t =>
                                    {
                                        var machine = _coreData.Machines.FirstOrDefault(m => m.Id == t.MachineId);
                                        return $"{t.WorkOrderNo}: {machine.MachineCode} » {machine.ModelName}";
                                    }).ToList();

                                //var mailList = new HashSet<int>() { 19 };
                                var mailList = new HashSet<int>() { _user.UserId };
                                _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                                               $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][取消工單] {_user.UserName} 取消 {orderInfo.Count} 張維護工單。",
                                               mail.ToString());

                                MessageBox.Show($"{_user.UserName} 已取消工單:\n{string.Join("\n", orderInfo.ToArray())}",
                                                "提示",
                                                MessageBoxButtons.OK,
                                                MessageBoxIcon.Information);

                            }
                            catch (Exception ex)
                            {
                                string errMsg = "取消工單時發生錯誤：MaintiFlowService -> CancelFlow()";
                                using (LogContext.PushProperty("Category", "Database"))
                                {
                                    _logger.Fatal(ex, errMsg);
                                }
                                MessageBox.Show(errMsg, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    return true;
                }
            }
            else
            {
                MessageBox.Show("無可取消的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> AcceptFlow()
        {
            var notAccepted = _flowData.TaskOrders
                .OrderBy(t => t.WorkOrderNo)
                .Where(t => t.Status == FlowStatus.NewTaskOrder)
                .ToList();
            if (notAccepted.Any())
            {
                using (var acceptFlow = _scope.Resolve<MF_AcceptFlow>())
                {
                    acceptFlow.Title = "接單";
                    acceptFlow.OkCaption = "接單";
                    acceptFlow.Orders = notAccepted;
                    if (MyFormEx.ShowDialogWithMask(acceptFlow) == DialogResult.OK)
                    {
                        try
                        {
                            var taskOrders = await _context.TaskOrders
                                .Include(t => t.Creator)
                                .Include(t => t.TaskOrderEngineers.Select(te => te.Engineer))
                                .Include(t => t.Machine)
                                .Include(t => t.Workstation)
                                .Include(t => t.RequestingUnit)
                                .Include(t => t.MaintenanceUnit)
                                .ToListAsync();
                            List<TaskOrder> tos = new List<TaskOrder>();
                            foreach (string orderId in acceptFlow.SelectedOrder)
                            {
                                TaskOrder to = taskOrders.FirstOrDefault(t => t.WorkOrderNo == orderId);
                                to.Status = FlowStatus.InProgress;
                                to.AcceptedTime = DateTime.Now;
                                to.Engineers = _user.CurrentUser != null
                                    ? new HashSet<Employee>() { _context.Employees.FirstOrDefault(e => e.EmployeeId == _user.EmployeeId) }
                                    : new HashSet<Employee>();
                                to.MaintenanceUnitId = _user.CurrentUser?.DepartmentId;
                                tos.Add(to);
                            }
                            await _context.SaveChangesAsync();
                            _cacheManager.RequestTaskOrderUpdate();
                            //_ = WeakReferenceMessenger.Default.Send(RequestTaskOrderDataUpdate.Instance);

                            // send email
                            StringBuilder mail = new StringBuilder();
                            mail.Append("<table><caption>接單</caption>");
                            mail.Append("<tr>");
                            mail.Append("<td>接單人員</td>");
                            mail.Append($"<td>{_user.UserName}</td>");
                            mail.Append("</tr>");

                            mail.Append("<tr>");
                            mail.Append("<td>接單時間</td>");
                            mail.Append($"<td>{tos[0].AcceptedTimeString}</td>");
                            mail.Append("</tr>");
                            mail.Append("</table>");

                            mail.Append("<table><caption>承接工單列表</caption>");
                            mail.Append("<tr>");
                            mail.Append("<th>工單編號</th>");
                            mail.Append("<th>需求單位</th>");
                            mail.Append("<th>機台</th>");
                            mail.Append("<th>機種 » 工站</th>");
                            mail.Append("<th>停動時間</th>");
                            mail.Append("<th>建檔人員</th>");
                            mail.Append("<th>建檔日期</th>");
                            mail.Append("</tr>");

                            foreach (var to in tos)
                            {
                                mail.Append("<tr>");
                                mail.Append($"<td>{to.WorkOrderNo}</td>");
                                mail.Append($"<td>{to.RequestingUnitString}</td>");
                                mail.Append($"<td>{to.FullMachineName}</td>");
                                mail.Append($"<td>{to.ModelWsName}</td>");
                                mail.Append($"<td>{to.OutageStartedString}</td>");
                                mail.Append($"<td>{to.CreatorNameWithId}</td>");
                                mail.Append($"<td>{to.CreationDateString}</td>");
                                mail.Append("</tr>");
                            }
                            mail.Append("</table>");

                            List<string> orderInfo = new List<string>();
                            foreach (var to in tos)
                            {
                                var machine = _coreData.Machines.FirstOrDefault(m => m.Id == to.MachineId);
                                orderInfo.Add($"{to.WorkOrderNo}: {machine.MachineCode} » {machine.ModelName}");
                            }

                            var mailList = new HashSet<int>() { _user.UserId };
                            foreach (var to in tos)
                            {
                                var creator = _coreData.Employees.FirstOrDefault(e => e.Id == to.CreatorId);
                                if (creator != null)
                                    mailList.Add(creator.Id);
                            }
                            _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                                           $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][接單] {_user.UserName} 承接 {orderInfo.Count} 張維護工單。",
                                           mail.ToString());

                            MessageBox.Show($"{_user.UserName} 已接單:\n{string.Join("\n", orderInfo.ToArray())}",
                                            "提示",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            string errMsg = "接單時發生錯誤：MaintiFlowService -> AcceptFlow()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有新的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> MaintiWork()
        {
            using (var maintiWork = _scope.Resolve<MF_MaintiWork>())
            {
                var tos = _flowData.TaskOrders
                    .Where(t => t.Status == FlowStatus.InProgress
                        && (_user.IsAdmin
                            || (t.Creator != null && t.Creator.Id == _user.UserId)
                            || (t.Engineers != null && t.Engineers.Any(eg => eg.Id == _user.UserId))
                        ))
                    .ToList();

                if (tos.Any())
                {
                    //maintiWork._orders = new BindingList<TaskOrder>(tos);
                    maintiWork.Initialize();

                    var engs = tos
                        .SelectMany(t => new[] { t.CreatorId }
                            .Concat(t.Engineers?.Select(e => e.Id) ?? Enumerable.Empty<int>()))
                        .Distinct()
                        .ToList();

                    //if (Core.Views.MyFormEx.ShowDialogWithMask(maintiWork) == DialogResult.OK)
                    if (maintiWork.ShowDialog() == DialogResult.OK)
                    {
                        //var to = _context.TaskOrders.FirstOrDefault(t => t.Id == acceptFlow.SelectedOrder.Id);
                        //if (to != null)
                        //{
                        //    to.StatusString = FlowStatus.InProgress;
                        //    var empId = _coreData.Employees.FirstOrDefault(e => e.Id == to.CreatorId)?.Id;
                        //    if (empId != null)
                        //    {
                        //        var t = _context.Employees.Find(empId);
                        //        if (t != null)
                        //            to.Engineer = new List<User> { t };
                        //    }
                        //    await _context.SaveChangesAsync();
                        //_ = WeakReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
                        //    MessageBox.Show($"{to.CreatorName.Name} 已接單: {to.WorkOrderNo}", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //}
                    }
                    return true;
                }
                else
                {
                    if (_user.IsAdmin || _user.IsEngineer)
                    {
                        using (var qc = _scope.Resolve<MF_QuickCreate>())
                        {
                            qc.ShowDialog();
                            return qc.DialogResult == DialogResult.OK;
                        }
                    }
                    else
                    {
                        MessageBox.Show("沒有維護中的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                }
            }
        }

        /// <inheritdoc/>
        public async Task<bool> FlowConfirmed()
        {
            var to = _flowData.TaskOrders.FirstOrDefault(t => t.Status == FlowStatus.Pending);
            if (to != null)
            {
                try
                {
                    using (var flowConfirmed = _scope.Resolve<MF_FlowConfirmed>())
                    {
                        //flowConfirmed.LoadData(to);
                        if (flowConfirmed.ShowDialog() == DialogResult.OK)
                        {
                            to = flowConfirmed.TaskOrder;
                            await _context.SaveChangesAsync();
                        }
                        _cacheManager.RequestTaskOrderUpdate();
                        //_ = WeakReferenceMessenger.Default.Send(RequestTaskOrderDataUpdate.Instance);
                    }
                }
                catch (Exception ex)
                {
                    string errMsg = "工單確認時發生錯誤：MaintiFlowService -> FlowConfirmed()";
                    using (LogContext.PushProperty("Category", "Database"))
                    {
                        _logger.Fatal(ex, errMsg);
                    }
                    MessageBox.Show(errMsg, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("沒有待確認的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return false;
        }
    }
}
