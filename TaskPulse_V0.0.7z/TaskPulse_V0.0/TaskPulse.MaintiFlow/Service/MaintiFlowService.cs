﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    /// <summary>
    /// 維護工單服務。
    /// </summary>
    public partial class MaintiFlowService : IDisposable, IMaintiFlow
    {
        #region fields

        private ILifetimeScope _rootScope;
        private ILifetimeScope _currentScope;
        private UIForm _currentForm;

        private readonly CoreContext _context;
        private readonly IEntityCacheManager _cacheManager;
        private readonly IMail _mail;
        private readonly CurrentUserContext _user;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;

        private bool _isInitialized = false;

        #endregion fields

        public MaintiFlowService(
            ILifetimeScope lifetimeScope,
            IEntityCacheManager entityCacheManager,
            CoreContext coreContext,
            CurrentUserContext currentUserContext,
            IMail mail,
            CoreData coreData,
            MaintiFlowData maintiFlowData)
        {
            _rootScope = lifetimeScope;
            _cacheManager = entityCacheManager;
            _context = coreContext;
            _user = currentUserContext;
            _mail = mail;
            _coreData = coreData;
            _flowData = maintiFlowData;

#if DEBUG
            // 在建構式或 UpdateCache 前加入（僅開發時使用）
            _context.Database.Log = s => System.Diagnostics.Debug.WriteLine(s);
#endif
        }

        /// <summary>
        /// 釋放註冊的事件。
        /// </summary>
        public void Dispose()
        {
            _currentScope?.Dispose();
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        /// <inheritdoc/>
        public async Task Initialize()
        {
            if (_isInitialized)
                return;

            //UpdateModelsCache();

            //_flowData.Engineer = _coreData.Employees
            //    .Where(e => e.IsEngineer)
            //    .Select(e => new Engineer
            //    {
            //        Id = e.Id,
            //        UnitName = e.UnitName,
            //        Department = e.Department,
            //        Title = e.Title
            //    })
            //    .ToList();

            SplashMessenger.Post("維護工單模組: 初始化內部訊息");

            PropertyText.Name.TaskOrderId = nameof(TaskOrder.Id);
            PropertyText.Name.WorkOrderNo = nameof(TaskOrder.WorkOrderNo);
            PropertyText.Name.OrderStatus = nameof(TaskOrder.Status);
            PropertyText.Name.OrderStatusId = nameof(TaskOrder.StatusId);
            PropertyText.Name.OrderStatusString = nameof(TaskOrder.StatusString);
            PropertyText.Name.Machine = nameof(TaskOrder.Machine);
            PropertyText.Name.MachineCode = nameof(TaskOrder.MachineCode);
            PropertyText.Name.FullMachineName = nameof(TaskOrder.FullMachineName);
            PropertyText.Name.ModelName = nameof(Model.ModelName);
            PropertyText.Name.ModelStatus = nameof(Model.ModelStatus);
            PropertyText.Name.Workstation = nameof(TaskOrder.Workstation);
            PropertyText.Name.WorkstationName = nameof(TaskOrder.WorkstationName);
            PropertyText.Name.ModelWsName = nameof(TaskOrder.ModelWsName);
            PropertyText.Name.Creator = nameof(TaskOrder.Creator);
            PropertyText.Name.CreatorName = nameof(TaskOrder.CreatorName);
            PropertyText.Name.CreatorNameWithDepartment = nameof(TaskOrder.CreatorNameWithDepartment);
            PropertyText.Name.FullCreatorName = nameof(TaskOrder.FullCreatorName);
            PropertyText.Name.CreationDateTime = nameof(TaskOrder.CreationDateTime);
            PropertyText.Name.CreationDateTimeString = nameof(TaskOrder.CreationDateTimeString);
            PropertyText.Name.CreationDateString = nameof(TaskOrder.CreationDateString);

            PropertyText.Name.MaintenanceUnit = nameof(TaskOrder.MaintenanceUnit);
            PropertyText.Name.MaintenanceUnitId = nameof(TaskOrder.MaintenanceUnitId);
            PropertyText.Name.MaintenanceUnitString = nameof(TaskOrder.MaintenanceUnitString);
            PropertyText.Name.UnitString = nameof(TaskOrder.MaintenanceUnitString);
            PropertyText.Name.Engineers = nameof(TaskOrder.Engineers);
            PropertyText.Name.EngineerString = nameof(TaskOrder.EngineerString);
            PropertyText.Name.EngineerMultiString = nameof(TaskOrder.EngineerMultiString);
            PropertyText.Name.AcceptedTime = nameof(TaskOrder.AcceptedTime);
            PropertyText.Name.AcceptedTimeString = nameof(TaskOrder.AcceptedTimeString);
            PropertyText.Name.IssueCategory = nameof(TaskOrder.IssueCategory);
            PropertyText.Name.IssueCategoryId = nameof(TaskOrder.IssueCategoryId);
            PropertyText.Name.IssueCategoryString = nameof(TaskOrder.IssueCategoryString);
            PropertyText.Name.IssueDescription = nameof(TaskOrder.IssueDescription);
            PropertyText.Name.Details = nameof(TaskOrder.Details);
            PropertyText.Name.RepairStarted = nameof(TaskOrder.RepairStarted);
            PropertyText.Name.RepairStartedString = nameof(TaskOrder.RepairStartedString);
            PropertyText.Name.RepairCompleted = nameof(TaskOrder.RepairCompleted);
            PropertyText.Name.RepairCompletedString = nameof(TaskOrder.RepairCompletedString);
            PropertyText.Name.RepairDurationTick = nameof(TaskOrder.RepairDurationTick);
            PropertyText.Name.RepairDuration = nameof(TaskOrder.RepairDuration);
            PropertyText.Name.RepairDurationString = nameof(TaskOrder.RepairDurationString);
            PropertyText.Name.FillingTime = nameof(TaskOrder.FillingTime);
            PropertyText.Name.FillingTimeString = nameof(TaskOrder.FillingTimeString);

            PropertyText.Name.RequestingUnit = nameof(TaskOrder.RequestingUnit);
            PropertyText.Name.RequestingUnitId = nameof(TaskOrder.RequestingUnitId);
            PropertyText.Name.RequestingUnitString = nameof(TaskOrder.RequestingUnitString);
            PropertyText.Name.FeedbackEmployee = nameof(TaskOrder.FeedbackEmployee);
            PropertyText.Name.FeedbackEmployeeString = nameof(TaskOrder.FeedbackEmployeeString);
            PropertyText.Name.Feedback = nameof(TaskOrder.Feedback);
            PropertyText.Name.OutageStarted = nameof(TaskOrder.OutageStarted);
            PropertyText.Name.OutageStartedString = nameof(TaskOrder.OutageStartedString);
            PropertyText.Name.OutageEnded = nameof(TaskOrder.OutageEnded);
            PropertyText.Name.OutageEndedString = nameof(TaskOrder.OutageEndedString);
            PropertyText.Name.OutageDurationTick = nameof(TaskOrder.OutageDurationTick);
            PropertyText.Name.OutageDuration = nameof(TaskOrder.OutageDuration);
            PropertyText.Name.OutageDurationString = nameof(TaskOrder.OutageDurationString);

            PropertyText.Name.Responsible = nameof(TaskOrder.Responsible);

            PropertyText.Title.TaskOrderId = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.TaskOrderId);
            PropertyText.Title.WorkOrderNo = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.WorkOrderNo);
            PropertyText.Title.Status = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.OrderStatus);
            PropertyText.Title.Machine = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.Machine);
            PropertyText.Title.ModelName = EnumHelper.GetDescription<Model>(PropertyText.Name.ModelName);
            PropertyText.Title.ModelStatus = EnumHelper.GetDescription<Model>(PropertyText.Name.ModelStatus);
            PropertyText.Title.Workstation = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.Workstation);
            PropertyText.Title.ModelWsName = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.ModelWsName);
            PropertyText.Title.Creator = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.Creator);
            PropertyText.Title.CreationDateTime = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.CreationDateTime);

            PropertyText.Title.MaintenanceUnit = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.MaintenanceUnit);
            PropertyText.Title.Engineer = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.Engineers);
            PropertyText.Title.AcceptedTime = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.AcceptedTime);
            PropertyText.Title.IssueCategory = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.IssueCategory);
            PropertyText.Title.IssueDescription = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.IssueDescription);
            PropertyText.Title.Details = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.Details);
            PropertyText.Title.RepairStarted = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.RepairStarted);
            PropertyText.Title.RepairCompleted = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.RepairCompleted);
            PropertyText.Title.RepairDuration = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.RepairDuration);
            PropertyText.Title.FillingTime = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.FillingTime);

            PropertyText.Title.RequestingUnit = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.RequestingUnit);
            PropertyText.Title.FeedbackEmployee = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.FeedbackEmployee);
            PropertyText.Title.Feedback = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.Feedback);
            PropertyText.Title.OutageStarted = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.OutageStarted);
            PropertyText.Title.OutageEnded = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.OutageEnded);
            PropertyText.Title.OutageDuration = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.OutageDuration);

            PropertyText.Title.Responsible = EnumHelper.GetDescription<TaskOrder>(PropertyText.Name.Responsible);

            SplashMessenger.Post("維護工單模組: 註冊事件");
            // 註冊核心共用資料更新訊息。
            WeakReferenceMessenger.Default.Register<RequestEmployeeDataUpdate>(this, (recipient, message) =>
            {
                _ = Task.Run(async () =>
                {
                    try
                    {
                        await UpdateCache();
                    }
                    catch (Exception ex)
                    {
                        // 記錄 log 或處理錯誤
                    }
                });
            });
            WeakReferenceMessenger.Default.Register<RequestTaskOrderDataUpdate>(this, async (recipient, message) =>
            {
                await UpdateCache();
            });

            SplashMessenger.Post("維護工單模組: 更新快取");
            await UpdateCache();
            _isInitialized = true;
        }

        /// <inheritdoc/>
        public async Task UpdateCache()
        {
            try
            {
                _flowData.TaskOrders = await _context.TaskOrders
                    .Include(t => t.Creator)
                    .Include(t => t.TaskOrderEngineers.Select(te => te.Engineer))
                    .Include(t => t.Machine)
                    .Include(t => t.Workstation)
                    .Include(t => t.MaintenanceUnit)
                    .Include(t => t.IssueCategory)
                    .Include(t => t.RequestingUnit)
                    .Include(t => t.FeedbackEmployee)
                    .OrderByDescending(to => to.WorkOrderNo)
                    .AsNoTracking()
                    .ToListAsync();

                // 將非映射的 Engineers 屬性填回（因為它是 [NotMapped]）
                foreach (var to in _flowData.TaskOrders)
                {
                    to.Engineers = to.TaskOrderEngineers?
                        .Select(te => te.Engineer)
                        .Where(e => e != null)
                        .ToList() ?? new List<Employee>();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            _cacheManager.NotifyTaskOrderUpdated();
            //_ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);
        }
    }
}
