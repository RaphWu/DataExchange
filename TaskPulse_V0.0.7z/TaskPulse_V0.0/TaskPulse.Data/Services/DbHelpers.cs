using System;
using System.Data.Entity.Infrastructure;
using System.Linq;

namespace Calin.TaskPulse.Data.Services
{
    public static class DbHelpers
    {
        public static void LogSaveException(DbUpdateException ex)
        {
            Exception inner = ex;
            while (inner.InnerException != null) inner = inner.InnerException;
            var msg = inner.Message;
            
            var entriesInfo = ex.Entries != null && ex.Entries.Any()
                ? string.Join(", ", ex.Entries.Select(e => $"{e.Entity.GetType().Name}[{e.State}]"))
                : "<Entries is null>";
            
            var errorMessage = $"Save failed: {msg}\nEntries: {entriesInfo}\nInner Exception: {inner.GetType().Name}";
            System.Diagnostics.Trace.TraceError(errorMessage);
        }
    }
}