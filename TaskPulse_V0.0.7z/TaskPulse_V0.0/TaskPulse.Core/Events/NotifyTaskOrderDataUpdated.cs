﻿namespace Calin.TaskPulse.Core.Events
{
    public class NotifyTaskOrderDataUpdated
    {
        public static readonly NotifyTaskOrderDataUpdated Instance = new NotifyTaskOrderDataUpdated();
        private NotifyTaskOrderDataUpdated() { }
    }
}
