﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 使用者切換訊息。
    /// </summary>
public class NotifyCurrentUserChanged
{
    public static readonly NotifyCurrentUserChanged Instance = new NotifyCurrentUserChanged();
    private NotifyCurrentUserChanged() { }
}
}
