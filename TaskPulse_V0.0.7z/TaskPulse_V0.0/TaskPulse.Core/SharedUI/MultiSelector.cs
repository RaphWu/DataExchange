﻿/*
 * 機台/機種選擇對話框。
 * 
 * 多選：
 *     使用 CoreData.ClassifyMachines 及 CoreData.MachinesMultiTabPageCache。
 *     建立分類TAB，以CheckBox選擇。
 * 單選：
 *     使用 CoreData.Models 及 CoreData.ModelTabPageCache。
 *     以RadioButton選擇。
 * 下方顯示已選取項目：分類 » 類型 » 項目1,項目2...
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.WinForms;
using Sunny.UI;

namespace Calin.TaskPulse.Core.SharedUI
{
    public partial class MultiSelector : UIForm
    {
        #region fields

        private readonly ICore _core;

        private const int OPTIONAL_WIDTH = 140; // Items寬度
        private bool _preventControlsEvents = false; // 屏蔽Control事件
        private Dictionary<int, CategoryInfo> _allSelectedItem = new Dictionary<int, CategoryInfo>(); // 記錄目前選擇的Items

        #endregion fields

        /********************
         * properties
         ********************/
        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 對話框寬度。
        /// </summary>
        public int DialogWidth { get; set; } = 860;

        /// <summary>
        /// 對話框高度。
        /// </summary>
        public int DialogHeight { get; set; } = 600;

        /// <summary>
        /// 是否隱藏標籤列。
        /// </summary>
        public bool HideTabHeaders
        {
            get { return _hideTabHeaders; }
            set
            {
                _hideTabHeaders = value;
                tabControlTypes.HideTabHeaders = value;
            }
        }
        private bool _hideTabHeaders;

        /// <summary>
        /// 是否隱藏 TreeView。
        /// </summary>
        public bool ShowTreeView
        {
            get { return _showTreeView; }
            set
            {
                treeViewCategories.Visible = value;
                label_TreeCaption.Visible = value;
                TLP_Content.ColumnStyles[0].Width = value ? 140 : 1;
                _showTreeView = value;
            }
        }
        private bool _showTreeView;

        /// <summary>
        /// TreeView標題。
        /// </summary>
        public string TreeViewCaption { set => label_TreeCaption.Text = value; }

        /// <summary>
        /// TabPage Cache。
        /// </summary>
        public Dictionary<string, List<TabPage>> TabPageCache { get; set; }

        /// <summary>
        /// 多選的類型。
        /// </summary>
        /// <remarks>true = 多選 (使用 CheckBox)。<br/>false = 單選 (使用 RadioButton)。</remarks>
        public bool MultiSelection { get; set; } = true;

        /// <summary>
        /// 預設值列表。
        /// </summary>
        public List<string> DefaultChecked { get; set; } = new List<string>();

        /// <summary>
        /// 返回的 Items。
        /// </summary>
        public List<CategoryInfo> ResultList { get; set; } = new List<CategoryInfo>();

        /********************
         * ctor
         ********************/
        public MultiSelector(ICore core)
        {
            InitializeComponent();
            _core = core;

            label_ResultList.Text = "";
        }

        /********************
         * Form
         ********************/
        private void FlowLayoutSelector_Shown(object sender, EventArgs e)
        {
            if (treeViewCategories.Nodes.Count > 0)
            {
                treeViewCategories.SelectedNode = treeViewCategories.Nodes[0];
                treeViewCategories_AfterSelect(treeViewCategories, new TreeViewEventArgs(treeViewCategories.SelectedNode));
            }
            this.BringToFront();
        }

        private void FlowLayoutSelector_FormClosing(object sender, FormClosingEventArgs e)
        {
            RemoveCheckBoxEvent();
            RemoveRadioButtonEvent();
            tabControlTypes.TabPages.Clear(); // 沒清掉的話，裡面的Control會全被釋放掉
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        /********************
         * Initialize
         ********************/
        public void Initialize()
        {
            this.Width = DialogWidth;
            this.Height = DialogHeight;
            DialogWidth = 860;
            DialogHeight = 600;

            tabControlTypes.TabPages.Clear();
            treeViewCategories.Nodes.Clear();
            foreach (var categoryName in TabPageCache.Keys)
                treeViewCategories.Nodes.Add(new TreeNode(categoryName));

            if (MultiSelection)
            {
                SetMultiSelectionToDefault();
                SetCheckBoxEvent();
            }
            else
            {
                // 單選預設值只取第一個
                if (DefaultChecked.Count > 1)
                    DefaultChecked = new List<string>() { DefaultChecked[0] };

                SetSingleSelectionToDefault();
                SetRadioButtonEvent();
            }

            tabControlTypes.Refresh();
            SetAndShowSelected();
        }

        /********************
         * Utility
         ********************/
        /// <summary>
        /// 
        /// </summary>
        private void SetAndShowSelected()
        {
            List<string> showResultList = new List<string>();
            ResultList = _allSelectedItem.Values.ToList();

            if (MultiSelection)
            {
                var grouped = ResultList
                    .GroupBy(r => r.Category1)
                    .OrderBy(g => g.Key);

                foreach (var categoryGroup in grouped)
                {
                    var typeGroups = categoryGroup
                        .GroupBy(g => g.Category2)
                        .OrderBy(g => g.Key);

                    foreach (var typeGroup in typeGroups)
                    {
                        string typeString = string.IsNullOrWhiteSpace(typeGroup.Key) ? "" : $"{typeGroup.Key} » ";
                        string names = string.Join("; ", typeGroup.Select(t => t.Name));
                        showResultList.Add($"{categoryGroup.Key} » {typeString}{names}");
                    }
                }

                label_ResultList.Text = string.Join("\n", showResultList);
            }
            else
            {
                if (ResultList.FirstOrDefault() is CategoryInfo selected)
                {
                    if (ShowTreeView)
                    {
                        if (string.IsNullOrEmpty(selected.IdString))
                            label_ResultList.Text = string.Join(" » ", new string[]
                            {
                                selected.Category1,
                                selected.Category2,
                                selected.Name,
                            });
                        else
                            label_ResultList.Text = string.Join(" » ", new string[]
                            {
                                selected.IdString,
                                selected.Name,
                            });
                    }
                    else
                    {
                        label_ResultList.Text = $"選擇的項目：{selected.Name}";
                    }
                }
                else
                {
                    label_ResultList.Text = "";
                }
            }
        }

        /********************
         * Treeview
         ********************/
        private void treeViewCategories_AfterSelect(object sender, TreeViewEventArgs e)
        {
            _preventControlsEvents = true;
            WinFormExtension.RunOnUIThread(() =>
            {
                tabControlTypes.SuspendLayout();

                var categoryName = e.Node.Text;
                tabControlTypes.TabPages.Clear();

                var typeDict = TabPageCache[categoryName];
                foreach (var typePage in typeDict)
                    tabControlTypes.TabPages.Add(typePage);

                tabControlTypes.ResumeLayout();
            });
            _preventControlsEvents = false;
        }

        /********************
         * CheckBox
         ********************/
        /// <summary>
        /// 清除全部 CheckBox。
        /// </summary>
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearAllChecked();
            SetAndShowSelected();
        }

        ///// <summary>
        ///// 將 Machine Cache 中為 True 的 MachineCode 轉存到 ResultList 和 _allSelectedItem，並更新顯示。
        ///// </summary>
        //private void GetMachineListCache()
        //{
        //    _preventControlsEvents = true;
        //    _allSelectedItem.Clear();
        //    var typeList = TabPageCache.Values;
        //    foreach (var typePage in typeList)
        //        foreach (var page in typePage)
        //            GetMachineListCache(page.Controls);
        //    SetAndShowSelected();
        //    _preventControlsEvents = false;
        //}

        ///// <summary>
        ///// 將 Machine Cache 中為 True 的 MachineCode 轉存到 _allSelectedItem (遞迴用)。
        ///// </summary>
        ///// <param name="controls">根控制項。</param>
        //private void GetMachineListCache(Control.ControlCollection controls)
        //{
        //    foreach (Control uiTextBox in controls)
        //    {
        //        if (uiTextBox is UICheckBox rb)
        //        {
        //            if (rb.Checked)
        //            {
        //                var tag = (SelectorInfo)rb.Tag;
        //                string name = tag.Name;
        //                string type = tag.TypeName;
        //                string category = tag.Category;
        //                _allSelectedItem.Add(name, (category, type));
        //            }
        //        }
        //        else if (uiTextBox.HasChildren)
        //        {
        //            GetMachineListCache(uiTextBox.Controls);
        //        }
        //    }
        //}

        /// <summary>
        /// 清除所有 CheckBox 已勾選項目。
        /// </summary>
        private void ClearAllChecked()
        {
            _preventControlsEvents = true;

            _allSelectedItem.Clear();
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    ClearAllChecked(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 清除所有 CheckBox 已勾選項目 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void ClearAllChecked(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (cb.Checked)
                        cb.Checked = false;
                }
                else if (control.HasChildren)
                {
                    ClearAllChecked(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked。
        /// </summary>
        private void SetMultiSelectionToDefault()
        {
            _preventControlsEvents = true;
            _allSelectedItem.Clear();

            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetMachineListToDefault(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void SetMachineListToDefault(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (cb.Tag is CategoryInfo ci)
                        if (DefaultChecked.Contains(ci.Name))
                        {
                            if (!cb.Checked)
                                cb.Checked = true;
                            _allSelectedItem.Add(ci.Id, ci);
                        }
                        else
                        {
                            if (cb.Checked)
                                cb.Checked = false;
                        }
                }
                else if (control.HasChildren)
                {
                    SetMachineListToDefault(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 加入事件。
        /// </summary>
        private void SetCheckBoxEvent()
        {
            _preventControlsEvents = true;
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxEvent(page.Controls, true);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 移除所有 CheckBox 事件。
        /// </summary>
        private void RemoveCheckBoxEvent()
        {
            _preventControlsEvents = true;
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxEvent(page.Controls, false);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 遍歷所有 CheckBox 並加入或移除事件 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        /// <param name="addOrRemove">加入或移除。</param>
        private void SetCheckBoxEvent(Control.ControlCollection controls, bool addOrRemove)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (addOrRemove)
                        cb.CheckedChanged += CheckBox_CheckedChanged;
                    else
                        cb.CheckedChanged -= CheckBox_CheckedChanged;
                }
                else if (control.HasChildren)
                {
                    SetCheckBoxEvent(control.Controls, addOrRemove);
                }
            }
        }

        /// <summary>
        /// CheckBox 勾選事件。
        /// </summary>
        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (_preventControlsEvents)
                return;
            if (!(sender is UICheckBox cb) || !(cb.Tag is CategoryInfo ci))
                return;

            if (cb.Checked)
                _allSelectedItem[ci.Id] = ci;
            else
                _allSelectedItem.Remove(ci.Id);
            SetAndShowSelected();
        }

        /********************
         * RadioButton
         ********************/
        /// <summary>
        /// 清除所有 RadioButton 項目。
        /// </summary>
        private void ClearAllSelected()
        {
            _preventControlsEvents = true;

            _allSelectedItem.Clear();
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    ClearAllSelected(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 清除所有 RadioButton 項目 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void ClearAllSelected(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (rb.Checked)
                        rb.Checked = false;
                }
                else if (control.HasChildren)
                {
                    ClearAllChecked(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked。
        /// </summary>
        private void SetSingleSelectionToDefault()
        {
            _preventControlsEvents = true;
            _allSelectedItem.Clear();

            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetSingleSelectionToDefault(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void SetSingleSelectionToDefault(Control.ControlCollection controls)
        {
            bool notyetChecked = true;
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (rb.Tag is CategoryInfo ci)
                        if (notyetChecked && DefaultChecked.Contains(ci.Name))
                        {
                            if (!rb.Checked)
                                rb.Checked = true;

                            _allSelectedItem.Add(ci.Id, ci);
                            notyetChecked = false;
                        }
                        else
                        {
                            if (rb.Checked)
                                rb.Checked = false;
                        }
                }
                else if (control.HasChildren)
                {
                    SetSingleSelectionToDefault(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 RadioButton 加入事件。
        /// </summary>
        private void SetRadioButtonEvent()
        {
            _preventControlsEvents = true;
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetRadioButtonEvent(page.Controls, true);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 移除所有 RadioButton 事件。
        /// </summary>
        private void RemoveRadioButtonEvent()
        {
            _preventControlsEvents = true;
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetRadioButtonEvent(page.Controls, false);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 遍歷所有 RadioButton 並加入或移除事件 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        /// <param name="addOrRemove">加入或移除。</param>
        private void SetRadioButtonEvent(Control.ControlCollection controls, bool addOrRemove)
        {
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (addOrRemove)
                        rb.CheckedChanged += RadioButton_CheckedChanged;
                    else
                        rb.CheckedChanged -= RadioButton_CheckedChanged;
                }
                else if (control.HasChildren)
                {
                    SetRadioButtonEvent(control.Controls, addOrRemove);
                }
            }
        }

        /// <summary>
        /// RadioButton 點選事件。
        /// </summary>
        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (_preventControlsEvents)
                return;
            if (!(sender is UIRadioButton rb) || !(rb.Tag is CategoryInfo info))
                return;

            var tag = rb.Tag as CategoryInfo;
            _allSelectedItem.Clear();
            _allSelectedItem.Add(tag.Id, tag);

            SetAndShowSelected();
        }
    }
}
