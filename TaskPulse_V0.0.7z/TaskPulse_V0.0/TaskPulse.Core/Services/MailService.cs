﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Serilog;

namespace Calin.TaskPulse.Core.Services
{
    public class MailService : IMail
    {
        #region fields

        private ILogger _logger;
        private readonly CoreData _coreData;

        private HashSet<Mail> _mailList;
        private HashSet<Mail> _ccList;
        private HashSet<Mail> _errorMailList;

        #endregion fields

        public MailService(ILogger logger, CoreData coreData)
        {
            _logger = logger;
            _coreData = coreData;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                _ = new System.Net.Mail.MailAddress(email);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <inheritdoc/>
        public void SendMail(string senderTitle, ICollection<int> recipient, string subject, string contents)
        {
            HashSet<string> nameList = new HashSet<string>();
            _mailList = new HashSet<Mail>();
            _ccList = new HashSet<Mail>();
            _errorMailList = new HashSet<Mail>();

            foreach (var empId in recipient)
            {
                var emp = _coreData.Employees.FirstOrDefault(e => e.Id == empId);
                if (emp != null)
                {
                    if (IsValidEmail(emp.Email))
                        _mailList.Add(new Mail()
                        {
                            Name = emp.EmployeeName,
                            Email = emp.Email,
                        });
                    else
                        _errorMailList.Add(new Mail()
                        {
                            Name = emp.EmployeeName,
                            Email = string.IsNullOrWhiteSpace(emp.Email) ? "未設定" : emp.Email,
                        });

                    foreach (var cc in emp.CarbonCopies)
                    {
                        if (!recipient.Contains(cc.Id) && !_ccList.Any(existingCc => existingCc.Email == cc.Email))
                        {
                            if (IsValidEmail(cc.Email))
                                _ccList.Add(new Mail()
                                {
                                    Name = cc.EmployeeName,
                                    Email = cc.Email,
                                });
                            else
                                _errorMailList.Add(new Mail()
                                {
                                    Name = cc.EmployeeName,
                                    Email = string.IsNullOrWhiteSpace(cc.Email) ? "未設定" : cc.Email,
                                });
                        }
                    }
                }
            }
            //_ccList.Add(new Mail() { Name = "系統管理員", Email = "raphael.wu@calin.com.tw" }); // 追蹤用，可移除

            if (_errorMailList.Count > 0)
            {
                string errMsg = "請注意：以下同仁未設定郵件地址或設定不正確，他們將不會收到信件！";

                StringBuilder errlist = new StringBuilder();
                errlist.Append($"<div style='background-color: PapayaWhip; padding: 15px;'>{errMsg}");
                foreach (var em in _errorMailList)
                    errlist.Append($"<br/>{em.Name} ({em.Email})");
                errlist.Append("</div>");

                contents = string.Concat(contents, errlist.ToString());

                string errorNames = string.Join("\n", _errorMailList.Select(em => $"{em.Name} ({em.Email})"));
                MessageBox.Show($"{errMsg}\n\n{errorNames}",
                                "郵件地址不正確",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }

            if (_mailList.Count == 0)
                return;

            contents = contents.Replace("\n", "<br/>");
            contents = Regex.Replace(contents,
                @"<table[^>]*>",
                "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse:collapse; border:1px solid #8c8c8c;'>",
                RegexOptions.IgnoreCase);
            contents = Regex.Replace(contents,
                @"<caption[^>]*>",
                "<caption style='font-weight:bold;margin-bottom:10px;'>",
                RegexOptions.IgnoreCase);
            contents = Regex.Replace(contents,
                @"<td[^>]*>",
                "<td style='border:1px solid #8c8c8c;'>",
                RegexOptions.IgnoreCase);

            string header = $@"<p style=""font-family: 'Microsoft JhengHei', '微軟正黑體', sans-serif;"">";
            //string title = $"<h2 style='color:#000099;'>{subject}</h2><hr/>";
            string footer = $"<span style='color:#990000;'><em><strong>此信件由{senderTitle}自動發送，請勿回覆此信件！</strong></em></span>";
            string body = $"{header}<p>{contents}</p><p>{footer}</p></p>";

            /********************
             * 使用 MimeKit/MailKit 寄信
             * 這是微軟建議的做法，但公司郵件伺服器似乎支援有問題，本來可以，後來又寄不出去，很不穩定，所以暫時棄用
             * https://learn.microsoft.com/zh-tw/dotnet/api/system.net.mail.smtpclient?view=netframework-4.6.2#remarks
             * https://github.com/dotnet/platform-compat/blob/master/docs/DE0005.md
             ********************/
            //            var message = new MimeMessage();
            //            message.From.Add(new MailboxAddress(senderTitle, "sys.automate@calin.com.tw"));

            //            foreach (var mail in _mailList)
            //                message.To.Add(new MailboxAddress(mail.Name, mail.Email));

            //            foreach (var cc in _ccList)
            //            {
            //                bool alreadyInTo = message.To
            //                   .Cast<MailboxAddress>()
            //                   .Any(m => string.Equals(m.Address, cc.Email, StringComparison.OrdinalIgnoreCase));

            //                if (!alreadyInTo)
            //                    message.Cc.Add(new MailboxAddress(cc.Name, cc.Email));
            //            }

            //#if DEBUG
            //            message.Subject = "[TaskPulse] 系統測試，請忽略此信件";
            //#else
            //            //message.Subject = subject;
            //#endif

            //            var builder = new BodyBuilder();
            //            builder.HtmlBody = body;
            //            message.Body = builder.ToMessageBody();

            //            _ = Task.Run(async () =>
            //            {
            //                try
            //                {
            //#if DEBUG
            //                    string from = string.Join("\n", message.From.Mailboxes.Select(mb => $"{mb.Name} <{mb.Address}>"));
            //                    string to = string.Join("\n", message.To.Mailboxes.Select(mb => $"{mb.Name} <{mb.Address}>"));
            //                    string cc = string.Join("\n", message.Cc.Mailboxes.Select(mb => $"{mb.Name} <{mb.Address}>"));
            //                    MessageBox.Show($"郵件寄送測試！\n\n寄件者：\n{from}\n\n收件者：\n{to}\n\n副本：\n{cc}\n\n主旨：\n{subject}\n{message.Subject}\n\n內容：\n{body}",
            //                                    "郵件寄送測試",
            //                                    MessageBoxButtons.OK,
            //                                    MessageBoxIcon.Information);
            //#endif

            //                    using (var client = new SmtpClient())
            //                    {
            //                        await client.ConnectAsync("calin-mails0.calin.com.tw", 25, false);
            //                        //await client.ConnectAsync("calin-mails0.calin.com.tw", 587, SecureSocketOptions.StartTls);
            //                        //await client.AuthenticateAsync("sys.automate@calin.com.tw", "#Calin@70848492");
            //                        await client.SendAsync(message);
            //                        await client.DisconnectAsync(true);
            //                    }

            //                }
            //                catch (Exception ex)
            //                {
            //                    Console.WriteLine(ex.ToString());
            //                    MessageBox.Show($"郵件寄送失敗！\n錯誤訊息：{ex.Message}",
            //                                    "郵件寄送失敗",
            //                                    MessageBoxButtons.OK,
            //                                    MessageBoxIcon.Error);
            //                }
            //                finally
            //                {
            //                }
            //            });


            /********************
             * 修改自公司提供的示範程式碼
             ********************/
            var message = new System.Net.Mail.MailMessage();
            message.From = new System.Net.Mail.MailAddress("sys.automate@calin.com.tw");

            //讀取收件者
#if DEBUG
            message.To.Clear();
            Entity.Core.Employee testEmp;
            //testEmp = _coreData.Employees.FirstOrDefault(e => e.EmployeeName == "蔡孟堅");
            //message.To.Add(new System.Net.Mail.MailAddress(testEmp.Email, testEmp.EmployeeName));
            testEmp = _coreData.Employees.FirstOrDefault(e => e.EmployeeName == "吳仁中");
            message.To.Add(new System.Net.Mail.MailAddress(testEmp.Email, testEmp.EmployeeName));
#else
            foreach (var emp in _mailList)
                message.To.Add(new System.Net.Mail.MailAddress(emp.Email, emp.Name));

            foreach (var cc in _ccList)
            {
                bool alreadyInTo = message.To
                   .Cast<System.Net.Mail.MailAddress>()
                   .Any(m => string.Equals(m.Address, cc.Email, StringComparison.OrdinalIgnoreCase));

                if (!alreadyInTo)
                    message.CC.Add(cc.Email);
            }
#endif

            message.Subject = subject;
            message.IsBodyHtml = true;
            message.Body = body;

            _ = Task.Run(() =>
            {
                try
                {
#if DEBUG
                    //string from = string.Join("\n", $"{message.From.DisplayName} <{message.From.Address}>");
                    //string to = string.Join("\n", message.To.Select(mb => $"{mb.DisplayName} <{mb.Address}>"));
                    //string cc = string.Join("\n", message.CC.Select(mb => $"{mb.DisplayName} <{mb.Address}>"));
                    //MessageBox.Show($"郵件寄送測試！\n\n寄件者：\n{from}\n\n收件者：\n{to}\n\n副本：\n{cc}\n\n主旨：\n{subject}\n{message.Subject}\n\n內容：\n{body}",
                    //                "郵件寄送測試",
                    //                MessageBoxButtons.OK,
                    //                MessageBoxIcon.Information);
#endif

                    //////////////設定郵箱smtp伺服器 埠//////////////
                    System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                    smtp.Port = 25;
                    smtp.Host = "calin-mails0.calin.com.tw";
                    //   smtp.EnableSsl = true; //SSL安全連線
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new System.Net.NetworkCredential("sys.automate@calin.com.tw", "#Calin@70848492"); //自動寄信公用帳號

                    //設定郵件傳送格式
                    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                    smtp.Send(message);
                    smtp.Dispose();
                    message.Dispose();
                }
                catch (Exception ex)
                {
                    _logger.Error(ex, "郵件寄送失敗");
                    MessageBox.Show($"郵件寄送失敗！\n錯誤訊息：{ex.Message}",
                                    "郵件寄送失敗",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                }
            });
        }
    }
}
