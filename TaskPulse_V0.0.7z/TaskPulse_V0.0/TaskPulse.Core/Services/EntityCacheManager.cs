﻿using System;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Events;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Services
{
    public class EntityCacheManager : IEntityCacheManager
    {
        #region fields

        private bool _employeeAvailable = false;
        private DateTime _employeeUpdatedTime = DateTime.MinValue;
        private bool _machineAvailable = false;
        private DateTime _machineUpdatedTime = DateTime.MinValue;
        private bool _modelNoAvailable = false;
        private DateTime _modelNoUpdatedTime = DateTime.MinValue;
        private bool _workstationAvailable = false;
        private DateTime _workstationUpdatedTime = DateTime.MinValue;
        private bool _taskOrderAvailable = false;
        private DateTime _taskOrderUpdatedTime = DateTime.MinValue;

        #endregion fields

        /********************
         * Public Properties
         ********************/
        /// <inheritdoc/>
        public bool EmployeeAvailable => _employeeAvailable;
        /// <inheritdoc/>
        public DateTime EmployeeUpdatedTime => _employeeUpdatedTime;

        /// <inheritdoc/>
        public bool MachineAvailable => _machineAvailable;
        /// <inheritdoc/>
        public DateTime MachineUpdatedTime => _machineUpdatedTime;

        /// <inheritdoc/>
        public bool ModelNoAvailable => _modelNoAvailable;
        /// <inheritdoc/>
        public DateTime ModelNoUpdatedTime => _modelNoUpdatedTime;

        /// <inheritdoc/>
        public bool WorkstationAvailable => _workstationAvailable;
        /// <inheritdoc/>
        public DateTime WorkstationUpdatedTime => _workstationUpdatedTime;

        /// <inheritdoc/>
        public bool TaskOrderAvailable => _taskOrderAvailable;
        /// <inheritdoc/>
        public DateTime TaskOrderUpdatedTime => _taskOrderUpdatedTime;

        /********************
         * Public Methods
         ********************/
        /// <inheritdoc/>
        public bool HaveCacheNotAvailable
            => !(_employeeAvailable
                && _machineAvailable
                && _modelNoAvailable
                && _workstationAvailable
                && _taskOrderAvailable);

        /// <inheritdoc/>
        public void UpdateAllCaches()
        {
            if (!_employeeAvailable)
                RequestEmployeeUpdate();
            if (!_machineAvailable)
                RequestMachineUpdate();
            if (!_modelNoAvailable)
                RequestModelNoUpdate();
            if (!_workstationAvailable)
                RequestWorkstationUpdate();
            if (!_taskOrderAvailable)
                RequestTaskOrderUpdate();
        }

        /// <inheritdoc/>
        public void RequestEmployeeUpdateDelay()
        {
            _employeeAvailable = false;
        }

        /// <inheritdoc/>
        public void RequestEmployeeUpdate()
        {
            _employeeAvailable = false;
            _ = WeakReferenceMessenger.Default.Send(RequestEmployeeDataUpdate.Instance);
        }

        /// <inheritdoc/>
        public void NotifyEmployeeUpdated()
        {
            _employeeAvailable = true;
            _employeeUpdatedTime = DateTime.Now;
            _ = WeakReferenceMessenger.Default.Send(NotifyEmployeeDataUpdated.Instance);
        }

        /// <inheritdoc/>
        public async Task WaitForEmployeeAvailableAsync()
        {
            while (!_employeeAvailable)
            {
                //token.ThrowIfCancellationRequested();
                await Task.Delay(50);
            }
        }

        /// <inheritdoc/>
        public void RequestMachineUpdateDelay()
        {
            _machineAvailable = false;
        }

        /// <inheritdoc/>
        public void RequestMachineUpdate()
        {
            _machineAvailable = false;
            _ = WeakReferenceMessenger.Default.Send(RequestMachineDataUpdate.Instance);
        }

        /// <inheritdoc/>
        public void NotifyMachineUpdated()
        {
            _machineAvailable = true;
            _machineUpdatedTime = DateTime.Now;
            _ = WeakReferenceMessenger.Default.Send(NotifyMachineDataUpdated.Instance);
        }

        /// <inheritdoc/>
        public async Task WaitForMachineAvailableAsync()
        {
            while (!_machineAvailable)
            {
                //token.ThrowIfCancellationRequested();
                await Task.Delay(50);
            }
        }

        /// <inheritdoc/>
        public void RequestModelNoUpdateDelay()
        {
            _modelNoAvailable = false;
        }

        /// <inheritdoc/>
        public void RequestModelNoUpdate()
        {
            _modelNoAvailable = false;
            _ = WeakReferenceMessenger.Default.Send(RequestModelNoDataUpdate.Instance);
        }

        /// <inheritdoc/>
        public void NotifyModelNoUpdated()
        {
            _modelNoAvailable = true;
            _modelNoUpdatedTime = DateTime.Now;
            _ = WeakReferenceMessenger.Default.Send(NotifyModelNoDataUpdated.Instance);
        }

        /// <inheritdoc/>
        public async Task WaitForModelNoAvailableAsync()
        {
            while (!_modelNoAvailable)
            {
                //token.ThrowIfCancellationRequested();
                await Task.Delay(50);
            }
        }

        /// <inheritdoc/>
        public void RequestWorkstationUpdateDelay()
        {
            _workstationAvailable = false;
        }

        /// <inheritdoc/>
        public void RequestWorkstationUpdate()
        {
            _workstationAvailable = false;
            _ = WeakReferenceMessenger.Default.Send(RequestWorkstationDataUpdate.Instance);
        }

        /// <inheritdoc/>
        public void NotifyWorkstationUpdated()
        {
            _workstationAvailable = true;
            _workstationUpdatedTime = DateTime.Now;
            _ = WeakReferenceMessenger.Default.Send(NotifyWorkstationDataUpdated.Instance);
        }

        /// <inheritdoc/>
        public async Task WaitForWorkstationAvailableAsync()
        {
            while (!_workstationAvailable)
            {
                //token.ThrowIfCancellationRequested();
                await Task.Delay(50);
            }
        }

        /// <inheritdoc/>
        public void RequestTaskOrderUpdateDelay()
        {
            _taskOrderAvailable = false;
        }

        /// <inheritdoc/>
        public void RequestTaskOrderUpdate()
        {
            _taskOrderAvailable = false;
            _ = WeakReferenceMessenger.Default.Send(RequestTaskOrderDataUpdate.Instance);
        }

        /// <inheritdoc/>
        public void NotifyTaskOrderUpdated()
        {
            _taskOrderAvailable = true;
            _taskOrderUpdatedTime = DateTime.Now;
            _ = WeakReferenceMessenger.Default.Send(NotifyTaskOrderDataUpdated.Instance);
        }

        /// <inheritdoc/>
        public async Task WaitForTaskOrderAvailableAsync()
        {
            while (!_taskOrderAvailable)
            {
                //token.ThrowIfCancellationRequested();
                await Task.Delay(50);
            }
        }
    }
}
