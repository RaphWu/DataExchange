﻿using System.Collections.Generic;
using System.Windows.Forms;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 核心共用資料。
    /// </summary>
    public class CoreData : BindableBase
    {
        /// <summary>
        /// 員工仍在職狀態值。
        /// </summary>
        public int IsActiveEmployee
        {
            get { return _isActiveEmployee; }
            set { SetProperty(ref _isActiveEmployee, value); }
        }
        private int _isActiveEmployee;

        /********************
         * Models
         ********************/
        /// <summary>
        /// 員工名冊，已排除離職。
        /// </summary>
        public List<Employee> Employees { get; set; }

        /// <summary>
        /// 依部門-姓名分類與排序的員工列表。<br/>格式: Dictionary<部門, List<(職稱, 工號, 姓名)>>
        /// </summary>
        public Dictionary<string, List<CategoryInfo>> ClassifyEmployee { get; set; }

        /// <summary>
        /// 維護工程師名冊。
        /// </summary>
        public List<Employee> Engineers { get; set; }

        /// <summary>
        /// 機台列表，已排除被處置。
        /// </summary>
        /// <remarks>排序規則：<br/>1. 去掉 '-' 符號分成前後部分。<br/>2. 先按前方英文字母排序。<br/>3. 再依後方數字小到大排序。</remarks>
        public List<Machine> Machines { get; set; }

        /// <summary>
        /// 依種類-類型-名稱分類與排序的機台列表，已排除被處置。
        /// </summary>
        public Dictionary<string, Dictionary<string, List<CategoryInfo>>> ClassifyMachines { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<MachineCategory> MachineCategories { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<MachineType> MachineTypes { get; set; }

        /// <summary>
        /// 機種清單。
        /// </summary>
        /// <remarks>排序規則：<br/>1. 先看 '-' 符號前面，只有三位數字的優先排序。<br/>2. 其它位數的排在後面。<br/>3. 有 '-' 符號的，再依 '-' 符號後的數字排序。<br/>4. 所有數字均為由小到大排序。</remarks>
        public List<Model> Models { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Dictionary<string, Dictionary<string, List<CategoryInfo>>> ClassifyModels { get; set; }

        /// <summary>
        /// 工站清單。
        /// </summary>
        /// <remarks>排序規則：<br/>1. 先按<see cref="Models"/>的規則排序機種。<br/>2. 再按工站的字母排序。</remarks>
        public List<Workstation> Workstations { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Dictionary<string, Dictionary<string, List<CategoryInfo>>> ClassifyWorkstations { get; set; }

        /********************
         * Controls
         ********************/
        /// <summary>
        /// 員工分類多選頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> EmployeeMultiTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();

        /// <summary>
        /// 員工分類單選頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> EmployeeSingleTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();

        /// <summary>
        /// 工程師多選頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> EngineerMultiTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();

        /// <summary>
        /// 工程師單選頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> EngineerSingleTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();

        /// <summary>
        /// 機台分類多選頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> MachinesMultiTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();

        /// <summary>
        /// 機台分類單選頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> MachinesSingleTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();

        /// <summary>
        /// 機種分類選擇頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> ModelTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();

        /// <summary>
        /// 機種/工站分類選擇頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> ModelWsMultiTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();

        /// <summary>
        /// 機種/工站分類選擇頁面 Cache。
        /// </summary>
        /// <remarks>僅給 UI 使用。</remarks>
        public Dictionary<string, List<TabPage>> ModelWsSingleTabPageCache { get; set; }
            = new Dictionary<string, List<TabPage>>();
    }
}
