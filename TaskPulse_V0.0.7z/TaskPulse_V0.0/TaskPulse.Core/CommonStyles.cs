﻿using System.Drawing;
using System.Windows.Forms;
using Calin.TaskPulse.Core.ADGV;
using Sunny.UI;

namespace Calin.TaskPulse.Core
{
    /*
     * SunnyUI 的 Styles 套用似乎有些問題，
     * 非自訂的有時子物件不會繼承，
     * 如果看到不是想要的效果須要自行修改。
     */
    /// <summary>
    /// 統一的共用 Styles。
    /// </summary>
    public static class CommonStyles
    {
        #region fields

        private const int DefaultFontSize = 11;
        private static ToolTip _toolTip = new ToolTip();

        #endregion fields

        //public static Color BackColor => Color.FromArgb(80, 126, 164); // 藍灰
        public static Color BackColor => Color.FromArgb(24, 74, 97);
        public static Color AccentColor => Color.DarkCyan;
        public static Color SelectedColor => Color.FromArgb(19, 77, 77);
        public static Color HoverColor => Color.FromArgb(96, 164, 164);
        public static Color HoverAccentColor => Color.FromArgb(50, 119, 119);
        public static Color CancelColor => Color.Maroon;
        public static string FontFamily => "微軟正黑體";
        public static Font Font => new Font(FontFamily, 11f);

        public static void SetButton(Control control,
                                     string toolTip = null,
                                     int fontSize = DefaultFontSize,
                                     bool isAccent = false,
                                     bool isCancel = false)
        {
            control.Font = new Font(FontFamily, fontSize);
            if (toolTip != null)
                _toolTip.SetToolTip(control, toolTip);

            if (control is Button btn)
            {
                if (isCancel)
                    btn.BackColor = CancelColor;
                else if (isAccent)
                    btn.BackColor = AccentColor;
                else
                    btn.BackColor = BackColor;
            }

            if (control is UIButton uiButton)
            {
                uiButton.Radius = 10;
                uiButton.BackColor = Color.Transparent;

                if (isCancel)
                {
                    uiButton.FillColor = CancelColor;
                    uiButton.RectColor = CancelColor;
                }
                else if (isAccent)
                {
                    uiButton.FillColor = AccentColor;
                    uiButton.RectColor = AccentColor;
                }
                else
                {
                    uiButton.FillColor = BackColor;
                    uiButton.RectColor = BackColor;
                }
            }

            if (control is UISymbolButton uiSButton)
            {
                uiSButton.Radius = 10;
                uiSButton.BackColor = Color.Transparent;

                if (isCancel)
                {
                    uiSButton.FillColor = CancelColor;
                    uiSButton.RectColor = CancelColor;
                }
                else if (isAccent)
                {
                    uiSButton.FillColor = AccentColor;
                    uiSButton.RectColor = AccentColor;
                }
                else
                {
                    uiSButton.FillColor = BackColor;
                    uiSButton.RectColor = BackColor;
                }
            }

            if (control is UITextBox uiTextBox)
            {
                uiTextBox.ButtonFillColor = BackColor;
            }

            if (control is UISwitch uiSwitch)
            {
                uiSwitch.ActiveColor = BackColor;
                uiSwitch.InActiveColor = Color.DarkRed;
            }
        }

        // CRUD按鍵
        /// <summary>
        /// 統一設定 CRUD 按鍵。
        /// </summary>
        /// <param name="control">按鍵。</param>
        /// <param name="type">C: 新增。<br/>D: 刪除。<br/>E: 編輯。<br/>M: 變更。<br/>R: 重新命名。<br/>UP: 往前/上。<br/>DOWN: 往後/下。</param>
        /// <param name="itemName">項目名稱。</param>
        public static void SetCrudButton(UISymbolButton button, string type, string itemName)
        {
            if (button == null) return;

            button.Font = new Font(FontFamily, DefaultFontSize);
            button.Radius = 10;
            button.BackColor = Color.Transparent;

            switch (type)
            {
                case "C":
                    _toolTip.SetToolTip(button, $"新增{itemName}");
                    button.FillColor = BackColor;
                    button.Symbol = 557669;
                    break;

                case "D":
                    _toolTip.SetToolTip(button, $"刪除{itemName}");
                    button.FillColor = BackColor;
                    button.Symbol = 559506;
                    button.SymbolOffset = new Point(-1, 1);
                    break;

                case "E":
                    _toolTip.SetToolTip(button, $"編輯{itemName}");
                    button.FillColor = BackColor;
                    button.Symbol = 559205;
                    break;

                case "M":
                    _toolTip.SetToolTip(button, $"變更{itemName}");
                    button.FillColor = BackColor;
                    button.Symbol = 61473;
                    break;

                case "R":
                    _toolTip.SetToolTip(button, $"重新命名{itemName}");
                    button.FillColor = BackColor;
                    button.Symbol = 559810;
                    break;

                case "UP":
                    _toolTip.SetToolTip(button, $"往前/上移動指定的{itemName}");
                    button.FillColor = BackColor;
                    button.Symbol = 361702;
                    button.SymbolOffset = new Point(-1, 1);
                    break;

                case "DOWN":
                    _toolTip.SetToolTip(button, $"往後/下移動指定的{itemName}");
                    button.FillColor = BackColor;
                    button.Symbol = 361703;
                    button.SymbolOffset = new Point(-1, 1);
                    break;

                default:
                    return;
            }
        }

        public static void SetCheckBox(Control control, string toolTip = null)
        {
            control.Font = new Font(FontFamily, DefaultFontSize);
            control.TabStop = false;

            if (control is UICheckBox cb)
            {
                if (toolTip != null)
                    _toolTip.SetToolTip(control, toolTip);

                cb.CheckBoxColor = BackColor;
            }
        }

        public static void SetListBox(Control control, string toolTip = null)
        {
            control.Font = new Font(FontFamily, DefaultFontSize);
            control.TabStop = false;

            if (control is UIListBox uiListBox)
            {
                uiListBox.ItemSelectBackColor = SelectedColor;
                uiListBox.HoverColor = HoverColor;
                uiListBox.ScrollBarColor = BackColor;

                if (toolTip != null)
                    _toolTip.SetToolTip(control, toolTip);
            }
        }

        public static void SetTreeView(Control control, string toolTip = null)
        {
            control.Font = new Font(FontFamily, DefaultFontSize);
            control.TabStop = false;

            if (control is UITreeView tv)
            {
                tv.SelectedColor = BackColor;
                tv.HoverColor = HoverColor;
                tv.ScrollBarColor = BackColor;
                if (toolTip != null)
                    _toolTip.SetToolTip(control, toolTip);
            }
        }

        public static void SetAdvancedDataGridView(AdvancedDataGridView adgv, bool filterAndSort = false)
        {
            adgv.SetDoubleBuffered();
            adgv.AutoGenerateColumns = false;
            adgv.RowHeadersVisible = false;
            adgv.MultiSelect = false;
            adgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            adgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            adgv.DefaultCellStyle.SelectionBackColor = SelectedColor;
            adgv.DefaultCellStyle.SelectionForeColor = Color.White;
            adgv.AlternatingRowsDefaultCellStyle.BackColor = Color.WhiteSmoke;
            adgv.ColumnHeadersDefaultCellStyle.BackColor = BackColor;
            adgv.GridColor = Color.LightGray;

            adgv.DefaultCellStyle.Font = Font;
            adgv.ColumnHeadersDefaultCellStyle.Font = Font;

            adgv.AllowUserToResizeColumns = true;
            adgv.AllowUserToResizeRows = false;
            adgv.AllowUserToAddRows = false;
            adgv.AllowUserToDeleteRows = false;
            adgv.AllowUserToOrderColumns = false;

            adgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            adgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            adgv.FilterAndSortEnabled = false;
            foreach (DataGridViewColumn col in adgv.Columns)
            {
                adgv.SetFilterEnabled(col, filterAndSort);
                adgv.SetSortEnabled(col, filterAndSort);
                adgv.SetFilterChecklistEnabled(col, filterAndSort);
                adgv.SetFilterCustomEnabled(col, filterAndSort);
            }

            adgv.Tag = -1;
            adgv.CellMouseEnter += (sender, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    adgv.Tag = e.RowIndex;
                    adgv.InvalidateRow(e.RowIndex);
                }
            };

            adgv.CellMouseLeave += (sender, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    adgv.Tag = -1;
                    adgv.InvalidateRow(e.RowIndex);
                }
            };

            adgv.RowPrePaint += (sender, e) =>
            {
                var dgv = sender as DataGridView;
                var row = dgv.Rows[e.RowIndex];

                // 避免 Header row
                if (e.RowIndex < 0) return;

                for (int col = 0; col < dgv.ColumnCount; col++)
                {
                    var cell = row.Cells[col];
                    var cellBounds = dgv.GetCellDisplayRectangle(col, e.RowIndex, true);

                    // 取得文字
                    string text = cell.FormattedValue?.ToString() ?? "";

                    // 用 TextRenderer 測量字串寬度（較準確）
                    Size textSize = TextRenderer.MeasureText(text, dgv.Font);

                    // 只畫文字寬度的背景
                    Rectangle dataRect = new Rectangle(
                        cellBounds.X,
                        cellBounds.Y,
                        textSize.Width + 4,   // 加 4px margin
                        cellBounds.Height
                    );

                    // 畫你要的背景（例如淡藍色）
                    using (SolidBrush brush = new SolidBrush(Color.FromArgb(90, HoverColor)))
                    {
                        e.Graphics.FillRectangle(brush, dataRect);
                    }
                    e.Handled = false; // 確保不會阻止其他繪製操作

                    // 若要畫文字(自己畫)（避免被預設繪製覆蓋，可用 CellPainting）
                    // TextRenderer.DrawText(e.Graphics, text, dgv.Font, cellBounds, Color.Black);
                }

                //if (e.RowIndex == (int)adgv.Tag)
                //{
                //    using (var brush = new SolidBrush(Color.FromArgb(70, HoverColor))) // 使用透明顏色
                //    {
                //        e.Graphics.FillRectangle(brush, e.RowBounds);
                //    }
                //    e.Handled = false; // 確保不會阻止其他繪製操作
                //}
            };

            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
        }

        /// <summary>
        /// 全域 Styles 設定。<br/>但若遇到子物件沒繼承的，仍須自行修改。
        /// </summary>
        public static void SetStyles()
        {
            UIStyles.MultiLanguageSupport = true;
            UIStyles.BuiltInResources.TryAdd(CultureInfos.zh_TW.LCID, new zh_TW_Resources());
            UIStyles.CultureInfo = CultureInfos.zh_TW;
            UIStyles.SetStyle(UIStyle.DarkBlue);
            UIStyles.InitColorful(BackColor, Color.White);
            UIStyles.DPIScale = true;
            UIStyles.GlobalFont = true;
            UIStyles.GlobalFontName = "微軟正黑體";
            UIStyles.SetDPIScale();
        }
    }
}
