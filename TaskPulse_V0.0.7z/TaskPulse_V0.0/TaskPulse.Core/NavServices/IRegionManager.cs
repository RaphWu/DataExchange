﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavServices
{
    public interface IRegionManager
    {
        void RegisterRegion(string name, Control control);
        IRegion GetRegion(string name);
    }
}
