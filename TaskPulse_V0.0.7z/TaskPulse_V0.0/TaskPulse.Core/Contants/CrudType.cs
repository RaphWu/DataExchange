﻿namespace Calin.TaskPulse.Core.Contants
{
    public enum CrudType
    {
        None,

        Create,
        Add,

        Edit,

        Read,

        Update,

        Delete,
    }
}
