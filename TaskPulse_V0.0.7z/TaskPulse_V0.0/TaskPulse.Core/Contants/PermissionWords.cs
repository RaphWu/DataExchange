﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.Contants
{
    public static class PermissionWords
    {
        /********************
         * User
         ********************/
        public const string USER_GUEST = "Guest";

        /********************
         * Home
         ********************/
        [Description("主頁")]
        public const string MODULE_HOME = "HomeModule";


        /********************
         * 系統設定
         ********************/
        [Description("系統設定")]
        public const string MODULE_SETUP = "SetupModule";

        [Description("機台管理")]
        public const string PAGE_MACHINE_MANAGER = "Machine";
        [Description("員工管理")]
        public const string PAGE_EMPLOYEE_MANAGER = "Employee";
        [Description("工具委託管理")]
        public const string PAGE_TOOL_QUEST_MANAGER = "ToolQuest";
        [Description("專案管理")]
        public const string PAGE_MECHA_TRACK_MANAGER = "MechaTrack";
        [Description("維護工單管理")]
        public const string PAGE_MAINTI_FLOW_MANAGER = "MaintiFlow";

        /********************
         * 工具委託
         ********************/
        public const string MODULE_TOOL_QUEST = "ToolQuestModule";



        /********************
         * 專案管理
         ********************/
        [Description("專案管理")]
        public const string MODULE_MECHA_TRACK = "MechaTrackModule";



        /********************
         * 維護工單
         ********************/
        [Description("維護工單")]
        public const string MODULE_MAINTI_FLOW = "MaintiFlowModule";

        [Description("維護總表")]
        public const string PAGE_FLOW_SUMMARY = "Summary";
        [Description("新建工單")]
        public const string PAGE_CREATE_FLOW = "Create";
        [Description("取消工單")]
        public const string PAGE_CANCEL_FLOW = "Cancel";
        [Description("接單")]
        public const string PAGE_ACCEPT_FLOW = "Accept";
        [Description("維護作業")]
        public const string PAGE_MAINTI_FLOW = "MaintiFlow";
        [Description("確認作業")]
        public const string PAGE_FLOW_CONFIRM = "Confirm";


        /********************
         * 動作
         ********************/
        [Description("可檢視")]
        public const string ACTION_VIEW = "View";
        [Description("可編輯")]
        public const string ACTION_EDIT = "Edit";

        [Description("不可檢視")]
        public const string ACTION_NO_VIEW = "NoView";
        [Description("不可編輯")]
        public const string ACTION_NO_EDIT = "NoEdit";
    }
}
