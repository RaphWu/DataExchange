﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_MachineCategory
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Name_Create = new Sunny.UI.UISymbolButton();
            this.Name_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.Name_Edit = new Sunny.UI.UISymbolButton();
            this.Type_Create = new Sunny.UI.UISymbolButton();
            this.Type_Edit = new Sunny.UI.UISymbolButton();
            this.Type_Delete = new Sunny.UI.UISymbolButton();
            this.HeadLabel_Type = new System.Windows.Forms.Label();
            this.HeadLabel_Category = new System.Windows.Forms.Label();
            this.List_Categories = new Sunny.UI.UIListBox();
            this.List_Types = new Sunny.UI.UIListBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Category_Create = new Sunny.UI.UISymbolButton();
            this.Category_Edit = new Sunny.UI.UISymbolButton();
            this.HeadLabel_Name = new System.Windows.Forms.Label();
            this.Category_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.Category_Up = new Sunny.UI.UISymbolButton();
            this.Category_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.Type_Up = new Sunny.UI.UISymbolButton();
            this.Type_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.Name_Up = new Sunny.UI.UISymbolButton();
            this.Name_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.List_Names = new Sunny.UI.UIListBox();
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // Name_Create
            // 
            this.Name_Create.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Name_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name_Create.Location = new System.Drawing.Point(9, 0);
            this.Name_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Name_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Name_Create.Name = "Name_Create";
            this.Name_Create.Size = new System.Drawing.Size(30, 30);
            this.Name_Create.Symbol = 557669;
            this.Name_Create.SymbolSize = 32;
            this.Name_Create.TabIndex = 2;
            this.Name_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name_Create.Click += new System.EventHandler(this.Name_Create_Click);
            // 
            // Name_Delete
            // 
            this.Name_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Name_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name_Delete.Location = new System.Drawing.Point(105, 0);
            this.Name_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Name_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Name_Delete.Name = "Name_Delete";
            this.Name_Delete.Size = new System.Drawing.Size(30, 30);
            this.Name_Delete.Symbol = 559506;
            this.Name_Delete.SymbolSize = 26;
            this.Name_Delete.TabIndex = 4;
            this.Name_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name_Delete.Click += new System.EventHandler(this.Name_Delete_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel2.AutoSize = true;
            this.flowLayoutPanel2.Controls.Add(this.Name_Create);
            this.flowLayoutPanel2.Controls.Add(this.Name_Edit);
            this.flowLayoutPanel2.Controls.Add(this.Name_Delete);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(772, 655);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel2.TabIndex = 25;
            // 
            // Name_Edit
            // 
            this.Name_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Name_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name_Edit.Location = new System.Drawing.Point(57, 0);
            this.Name_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Name_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Name_Edit.Name = "Name_Edit";
            this.Name_Edit.Size = new System.Drawing.Size(30, 30);
            this.Name_Edit.Symbol = 559205;
            this.Name_Edit.SymbolSize = 32;
            this.Name_Edit.TabIndex = 3;
            this.Name_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name_Edit.Click += new System.EventHandler(this.Name_Edit_Click);
            // 
            // Type_Create
            // 
            this.Type_Create.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Type_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Type_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Type_Create.Location = new System.Drawing.Point(9, 0);
            this.Type_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Type_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Type_Create.Name = "Type_Create";
            this.Type_Create.Size = new System.Drawing.Size(30, 30);
            this.Type_Create.Symbol = 557669;
            this.Type_Create.SymbolSize = 32;
            this.Type_Create.TabIndex = 2;
            this.Type_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Type_Create.Click += new System.EventHandler(this.Type_Create_Click);
            // 
            // Type_Edit
            // 
            this.Type_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Type_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Type_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Type_Edit.Location = new System.Drawing.Point(57, 0);
            this.Type_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Type_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Type_Edit.Name = "Type_Edit";
            this.Type_Edit.Size = new System.Drawing.Size(30, 30);
            this.Type_Edit.Symbol = 559205;
            this.Type_Edit.SymbolSize = 32;
            this.Type_Edit.TabIndex = 3;
            this.Type_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Type_Edit.Click += new System.EventHandler(this.Type_Edit_Click);
            // 
            // Type_Delete
            // 
            this.Type_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Type_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Type_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Type_Delete.Location = new System.Drawing.Point(105, 0);
            this.Type_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Type_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Type_Delete.Name = "Type_Delete";
            this.Type_Delete.Size = new System.Drawing.Size(30, 30);
            this.Type_Delete.Symbol = 559506;
            this.Type_Delete.SymbolSize = 26;
            this.Type_Delete.TabIndex = 4;
            this.Type_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Type_Delete.Click += new System.EventHandler(this.Type_Delete_Click);
            // 
            // HeadLabel_Type
            // 
            this.HeadLabel_Type.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_Type.AutoSize = true;
            this.HeadLabel_Type.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_Type.Location = new System.Drawing.Point(489, 6);
            this.HeadLabel_Type.Name = "HeadLabel_Type";
            this.HeadLabel_Type.Size = new System.Drawing.Size(69, 19);
            this.HeadLabel_Type.TabIndex = 18;
            this.HeadLabel_Type.Text = "設備別";
            this.HeadLabel_Type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HeadLabel_Category
            // 
            this.HeadLabel_Category.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_Category.AutoSize = true;
            this.HeadLabel_Category.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_Category.Location = new System.Drawing.Point(179, 6);
            this.HeadLabel_Category.Name = "HeadLabel_Category";
            this.HeadLabel_Category.Size = new System.Drawing.Size(49, 19);
            this.HeadLabel_Category.TabIndex = 17;
            this.HeadLabel_Category.Text = "分類";
            this.HeadLabel_Category.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // List_Categories
            // 
            this.List_Categories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Categories.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Categories.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Categories.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Categories.Location = new System.Drawing.Point(83, 30);
            this.List_Categories.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Categories.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Categories.Name = "List_Categories";
            this.List_Categories.Padding = new System.Windows.Forms.Padding(2);
            this.List_Categories.ShowText = false;
            this.List_Categories.Size = new System.Drawing.Size(242, 620);
            this.List_Categories.TabIndex = 20;
            this.List_Categories.Text = "uiListBox1";
            this.List_Categories.SelectedIndexChanged += new System.EventHandler(this.List_Categories_SelectedIndexChanged);
            // 
            // List_Types
            // 
            this.List_Types.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Types.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Types.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Types.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Types.Location = new System.Drawing.Point(403, 30);
            this.List_Types.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Types.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Types.Name = "List_Types";
            this.List_Types.Padding = new System.Windows.Forms.Padding(2);
            this.List_Types.Radius = 1;
            this.List_Types.ShowText = false;
            this.List_Types.Size = new System.Drawing.Size(242, 620);
            this.List_Types.TabIndex = 21;
            this.List_Types.Text = "uiListBox1";
            this.List_Types.SelectedIndexChanged += new System.EventHandler(this.List_Types_SelectedIndexChanged);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.Type_Create);
            this.flowLayoutPanel1.Controls.Add(this.Type_Edit);
            this.flowLayoutPanel1.Controls.Add(this.Type_Delete);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(452, 655);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel1.TabIndex = 24;
            // 
            // Category_Create
            // 
            this.Category_Create.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Category_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Category_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Category_Create.Location = new System.Drawing.Point(9, 0);
            this.Category_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Category_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Category_Create.Name = "Category_Create";
            this.Category_Create.Size = new System.Drawing.Size(30, 30);
            this.Category_Create.Symbol = 557669;
            this.Category_Create.SymbolSize = 32;
            this.Category_Create.TabIndex = 2;
            this.Category_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Category_Create.Click += new System.EventHandler(this.Category_Create_Click);
            // 
            // Category_Edit
            // 
            this.Category_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Category_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Category_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Category_Edit.Location = new System.Drawing.Point(57, 0);
            this.Category_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Category_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Category_Edit.Name = "Category_Edit";
            this.Category_Edit.Size = new System.Drawing.Size(30, 30);
            this.Category_Edit.Symbol = 559205;
            this.Category_Edit.SymbolSize = 32;
            this.Category_Edit.TabIndex = 3;
            this.Category_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Category_Edit.Click += new System.EventHandler(this.Category_Edit_Click);
            // 
            // HeadLabel_Name
            // 
            this.HeadLabel_Name.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_Name.AutoSize = true;
            this.HeadLabel_Name.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_Name.Location = new System.Drawing.Point(819, 6);
            this.HeadLabel_Name.Name = "HeadLabel_Name";
            this.HeadLabel_Name.Size = new System.Drawing.Size(49, 19);
            this.HeadLabel_Name.TabIndex = 19;
            this.HeadLabel_Name.Text = "名稱";
            this.HeadLabel_Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Category_Delete
            // 
            this.Category_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Category_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Category_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Category_Delete.Location = new System.Drawing.Point(105, 0);
            this.Category_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Category_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Category_Delete.Name = "Category_Delete";
            this.Category_Delete.Size = new System.Drawing.Size(30, 30);
            this.Category_Delete.Symbol = 559506;
            this.Category_Delete.SymbolSize = 26;
            this.Category_Delete.TabIndex = 4;
            this.Category_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Category_Delete.Click += new System.EventHandler(this.Category_Delete_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.Controls.Add(this.Category_Create);
            this.flowLayoutPanel4.Controls.Add(this.Category_Edit);
            this.flowLayoutPanel4.Controls.Add(this.Category_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(132, 655);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 23;
            // 
            // Category_Up
            // 
            this.Category_Up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Category_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Category_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Category_Up.Location = new System.Drawing.Point(0, 9);
            this.Category_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Category_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Category_Up.Name = "Category_Up";
            this.Category_Up.Size = new System.Drawing.Size(30, 30);
            this.Category_Up.Symbol = 361702;
            this.Category_Up.SymbolSize = 32;
            this.Category_Up.TabIndex = 2;
            this.Category_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Category_Up.Click += new System.EventHandler(this.Category_Up_Click);
            // 
            // Category_Down
            // 
            this.Category_Down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Category_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Category_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Category_Down.Location = new System.Drawing.Point(0, 57);
            this.Category_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Category_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Category_Down.Name = "Category_Down";
            this.Category_Down.Size = new System.Drawing.Size(30, 30);
            this.Category_Down.Symbol = 361703;
            this.Category_Down.SymbolSize = 32;
            this.Category_Down.TabIndex = 4;
            this.Category_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Category_Down.Click += new System.EventHandler(this.Category_Down_Click);
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel3.AutoSize = true;
            this.flowLayoutPanel3.Controls.Add(this.Category_Up);
            this.flowLayoutPanel3.Controls.Add(this.Category_Down);
            this.flowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(46, 168);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel3.TabIndex = 26;
            // 
            // Type_Up
            // 
            this.Type_Up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Type_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Type_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Type_Up.Location = new System.Drawing.Point(0, 9);
            this.Type_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Type_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Type_Up.Name = "Type_Up";
            this.Type_Up.Size = new System.Drawing.Size(30, 30);
            this.Type_Up.Symbol = 361702;
            this.Type_Up.SymbolSize = 32;
            this.Type_Up.TabIndex = 2;
            this.Type_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Type_Up.Click += new System.EventHandler(this.Type_Up_Click);
            // 
            // Type_Down
            // 
            this.Type_Down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Type_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Type_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Type_Down.Location = new System.Drawing.Point(0, 57);
            this.Type_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Type_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Type_Down.Name = "Type_Down";
            this.Type_Down.Size = new System.Drawing.Size(30, 30);
            this.Type_Down.Symbol = 361703;
            this.Type_Down.SymbolSize = 32;
            this.Type_Down.TabIndex = 4;
            this.Type_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Type_Down.Click += new System.EventHandler(this.Type_Down_Click);
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel5.AutoSize = true;
            this.flowLayoutPanel5.Controls.Add(this.Type_Up);
            this.flowLayoutPanel5.Controls.Add(this.Type_Down);
            this.flowLayoutPanel5.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(366, 168);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel5.TabIndex = 27;
            // 
            // Name_Up
            // 
            this.Name_Up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Name_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name_Up.Location = new System.Drawing.Point(0, 9);
            this.Name_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Name_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Name_Up.Name = "Name_Up";
            this.Name_Up.Size = new System.Drawing.Size(30, 30);
            this.Name_Up.Symbol = 361702;
            this.Name_Up.SymbolSize = 32;
            this.Name_Up.TabIndex = 2;
            this.Name_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name_Up.Click += new System.EventHandler(this.Name_Up_Click);
            // 
            // Name_Down
            // 
            this.Name_Down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Name_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name_Down.Location = new System.Drawing.Point(0, 57);
            this.Name_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Name_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Name_Down.Name = "Name_Down";
            this.Name_Down.Size = new System.Drawing.Size(30, 30);
            this.Name_Down.Symbol = 361703;
            this.Name_Down.SymbolSize = 32;
            this.Name_Down.TabIndex = 4;
            this.Name_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name_Down.Click += new System.EventHandler(this.Name_Down_Click);
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel6.AutoSize = true;
            this.flowLayoutPanel6.Controls.Add(this.Name_Up);
            this.flowLayoutPanel6.Controls.Add(this.Name_Down);
            this.flowLayoutPanel6.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel6.Location = new System.Drawing.Point(686, 168);
            this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel6.TabIndex = 28;
            // 
            // List_Names
            // 
            this.List_Names.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Names.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Names.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Names.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Names.Location = new System.Drawing.Point(723, 30);
            this.List_Names.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Names.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Names.Name = "List_Names";
            this.List_Names.Padding = new System.Windows.Forms.Padding(2);
            this.List_Names.Radius = 1;
            this.List_Names.ShowText = false;
            this.List_Names.Size = new System.Drawing.Size(242, 620);
            this.List_Names.TabIndex = 22;
            this.List_Names.Text = "uiListBox1";
            this.List_Names.SelectedIndexChanged += new System.EventHandler(this.List_Names_SelectedIndexChanged);
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 8;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel6, 5, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel5, 3, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel3, 1, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel4, 2, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Names, 6, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_Name, 6, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_Type, 4, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_Category, 2, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Categories, 2, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Types, 4, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel1, 4, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel2, 6, 2);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 3;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1236, 705);
            this.tableLayoutPanel_Page.TabIndex = 1;
            // 
            // Setup_MachineInfo2
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Name = "Setup_MachineInfo2";
            this.Size = new System.Drawing.Size(1236, 705);
            this.Load += new System.EventHandler(this.Setup_MachineInfo2_Load);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.tableLayoutPanel_Page.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UISymbolButton Name_Create;
        private Sunny.UI.UISymbolButton Name_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private Sunny.UI.UISymbolButton Name_Edit;
        private Sunny.UI.UISymbolButton Type_Create;
        private Sunny.UI.UISymbolButton Type_Edit;
        private Sunny.UI.UISymbolButton Type_Delete;
        private System.Windows.Forms.Label HeadLabel_Type;
        private System.Windows.Forms.Label HeadLabel_Category;
        private Sunny.UI.UIListBox List_Categories;
        private Sunny.UI.UIListBox List_Types;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Sunny.UI.UISymbolButton Category_Create;
        private Sunny.UI.UISymbolButton Category_Edit;
        private System.Windows.Forms.Label HeadLabel_Name;
        private Sunny.UI.UISymbolButton Category_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton Category_Up;
        private Sunny.UI.UISymbolButton Category_Down;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private Sunny.UI.UISymbolButton Type_Up;
        private Sunny.UI.UISymbolButton Type_Down;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private Sunny.UI.UISymbolButton Name_Up;
        private Sunny.UI.UISymbolButton Name_Down;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private Sunny.UI.UIListBox List_Names;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
    }
}
