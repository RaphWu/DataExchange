using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    /// <summary>
    /// �v���޲z����
    /// �䴩�����B�s�աB�ӤH�T���v���]�w
    /// �䴩���\/�T�����V�v��
    /// </summary>
    public partial class Setup_Permission : UserControl
    {
        #region Fields

        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly ICurrentUserService _currentUser;
        private readonly IPermissionService _permission;

        private PermissionSource _currentSource;
        private int _selectedDepartmentId;
        private int _selectedUserGroupId;
        private string _selectedEmployeeId;

        private List<PermissionItemViewModel> _currentPermissions;
        private List<PermissionMergeResult> _mergedPermissions;
        private List<PermissionConflictViewModel> _conflicts;

        #endregion

        #region Constructor

        public Setup_Permission(
            CoreContext coreContext,
            CurrentUserContext currentUserContext,
            ICurrentUserService currentUserService,
            IPermissionService permissionService)
        {
            InitializeComponent();

            _context = coreContext;
            _user = currentUserContext;
            _currentUser = currentUserService;
            _permission = permissionService;

            InitializeUI();
        }

        #endregion

        #region Initialization

        private void InitializeUI()
        {
            // �]�w TreeView �˦�
            CommonStyles.SetTreeView(treeSource);

            // �]�w DataGridView �˦�
            SetupDataGridViewStyle(dgvPermissions);
            SetupDataGridViewStyle(dgvMergedPermissions);
            SetupDataGridViewStyle(dgvConflicts);

            // ��l�� TreeView
            InitializeSourceTree();

            // �]�w DataGridView ���
            SetupPermissionGridColumns();
            SetupMergedGridColumns();
            SetupConflictGridColumns();
        }

        private void SetupDataGridViewStyle(DataGridView dgv)
        {
            dgv.AutoGenerateColumns = false;
            dgv.RowHeadersVisible = false;
            dgv.MultiSelect = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv.DefaultCellStyle.SelectionBackColor = CommonStyles.SelectedColor;
            dgv.DefaultCellStyle.SelectionForeColor = Color.White;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.WhiteSmoke;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.GridColor = Color.LightGray;
            dgv.DefaultCellStyle.Font = CommonStyles.Font;
            dgv.ColumnHeadersDefaultCellStyle.Font = CommonStyles.Font;
            dgv.AllowUserToResizeColumns = true;
            dgv.AllowUserToResizeRows = false;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToOrderColumns = false;
        }

        private void InitializeSourceTree()
        {
            treeSource.Nodes.Clear();

            // �����`�I
            var deptNode = new TreeNode("����")
            {
                Tag = "Department",
                ImageIndex = 0,
                SelectedImageIndex = 0
            };

            var departments = _context.Departments
                .OrderBy(d => d.OrderNo)
                .ToList();

            foreach (var dept in departments)
            {
                var node = new TreeNode(dept.DepartmentName)
                {
                    Tag = new SourceNodeData
                    {
                        Source = PermissionSource.Department,
                        Id = dept.Id,
                        Name = dept.DepartmentName
                    }
                };
                deptNode.Nodes.Add(node);
            }

            treeSource.Nodes.Add(deptNode);

            // �s�ո`�I
            var groupNode = new TreeNode("�ϥΪ̸s��")
            {
                Tag = "UserGroup",
                ImageIndex = 1,
                SelectedImageIndex = 1
            };

            var userGroups = _context.UserGroups
                .OrderBy(g => g.OrderNo)
                .ToList();

            foreach (var group in userGroups)
            {
                var node = new TreeNode(group.Name)
                {
                    Tag = new SourceNodeData
                    {
                        Source = PermissionSource.UserGroup,
                        Id = group.Id,
                        Name = group.Name
                    }
                };
                groupNode.Nodes.Add(node);
            }

            treeSource.Nodes.Add(groupNode);

            // ���u�`�I
            var empNode = new TreeNode("���u")
            {
                Tag = "Employee",
                ImageIndex = 2,
                SelectedImageIndex = 2
            };

            var employees = _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Status)
                .Where(e => e.StatusId == 1) // �u��ܦb¾���u
                .OrderBy(e => e.Department.OrderNo)
                .ThenBy(e => e.EmployeeId)
                .ToList();

            // ����������
            var empByDept = employees.GroupBy(e => e.Department?.DepartmentName ?? "�����t����");

            foreach (var deptGroup in empByDept)
            {
                var deptSubNode = new TreeNode(deptGroup.Key);

                foreach (var emp in deptGroup)
                {
                    var node = new TreeNode($"{emp.EmployeeId} - {emp.EmployeeName}")
                    {
                        Tag = new SourceNodeData
                        {
                            Source = PermissionSource.Employee,
                            EmployeeId = emp.EmployeeId,
                            Name = emp.EmployeeName
                        }
                    };
                    deptSubNode.Nodes.Add(node);
                }

                empNode.Nodes.Add(deptSubNode);
            }

            treeSource.Nodes.Add(empNode);

            // �i�}�Ĥ@�h
            treeSource.ExpandAll();
        }

        private void SetupPermissionGridColumns()
        {
            dgvPermissions.Columns.Clear();
            dgvPermissions.AutoGenerateColumns = false;

            dgvPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Module",
                HeaderText = "�Ҳ�",
                Width = 120
            });

            dgvPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Page",
                HeaderText = "����",
                Width = 120
            });

            dgvPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Control",
                HeaderText = "���",
                Width = 120
            });

            dgvPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Action",
                HeaderText = "�ʧ@",
                Width = 100
            });

            dgvPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "TypeText",
                HeaderText = "����",
                Width = 80
            });

            dgvPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "SourceText",
                HeaderText = "�ӷ�",
                Width = 150,
                ReadOnly = true
            });

            dgvPermissions.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "IsInherited",
                HeaderText = "�~��",
                Width = 60,
                ReadOnly = true
            });
        }

        private void SetupMergedGridColumns()
        {
            dgvMergedPermissions.Columns.Clear();
            dgvMergedPermissions.AutoGenerateColumns = false;

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Module",
                HeaderText = "�Ҳ�",
                Width = 120
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Page",
                HeaderText = "����",
                Width = 120
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Control",
                HeaderText = "���",
                Width = 120
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Action",
                HeaderText = "�ʧ@",
                Width = 100
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "FinalType",
                HeaderText = "�̲��v��",
                Width = 100
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DecidingSourceName",
                HeaderText = "�M�w�ӷ�",
                Width = 150
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "HasConflict",
                HeaderText = "���Ĭ�",
                Width = 80
            });
        }

        private void SetupConflictGridColumns()
        {
            dgvConflicts.Columns.Clear();
            dgvConflicts.AutoGenerateColumns = false;

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "PermissionString",
                HeaderText = "�v��",
                Width = 200
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DepartmentSetting",
                HeaderText = "�����]�w",
                Width = 100
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "EmployeeSetting",
                HeaderText = "�ӤH�]�w",
                Width = 100
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "FinalType",
                HeaderText = "�̲ץͮ�",
                Width = 100
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "ConflictLevel",
                HeaderText = "�Ĭ𵥯�",
                Width = 80
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "ConflictDescription",
                HeaderText = "����",
                Width = 250
            });
        }

        #endregion

        #region Event Handlers

        private void TreeSource_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node?.Tag is SourceNodeData data)
            {
                _currentSource = data.Source;

                switch (data.Source)
                {
                    case PermissionSource.Department:
                        _selectedDepartmentId = data.Id;
                        LoadDepartmentPermissions(data.Id);
                        break;

                    case PermissionSource.UserGroup:
                        _selectedUserGroupId = data.Id;
                        LoadUserGroupPermissions(data.Id);
                        break;

                    case PermissionSource.Employee:
                        _selectedEmployeeId = data.EmployeeId;
                        LoadEmployeePermissions(data.EmployeeId);
                        break;
                }
            }
        }

        private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedTab?.Name == "tabMerged" && !string.IsNullOrEmpty(_selectedEmployeeId))
            {
                LoadMergedPermissions();
            }
            else if (tabControl.SelectedTab?.Name == "tabConflicts" && !string.IsNullOrEmpty(_selectedEmployeeId))
            {
                LoadConflicts();
            }
        }

        #endregion

        #region Data Loading Methods

        private void LoadDepartmentPermissions(int departmentId)
        {
            var dept = _context.Departments
                .Include(d => d.Permissions)
                .FirstOrDefault(d => d.Id == departmentId);

            if (dept != null)
            {
                _currentPermissions = dept.Permissions.Select(p => new PermissionItemViewModel
                {
                    Module = p.Module,
                    Page = p.Page,
                    Control = p.Control,
                    Action = p.Action,
                    PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                    Type = (PermissionType)p.PermissionType,
                    Source = PermissionSource.Department,
                    SourceName = dept.DepartmentName,
                    IsInherited = false
                }).ToList();

                dgvPermissions.DataSource = _currentPermissions;
            }
        }

        private void LoadUserGroupPermissions(int userGroupId)
        {
            var group = _context.UserGroups
                .Include(g => g.Permissions)
                .FirstOrDefault(g => g.Id == userGroupId);

            if (group != null)
            {
                _currentPermissions = group.Permissions.Select(p => new PermissionItemViewModel
                {
                    Module = p.Module,
                    Page = p.Page,
                    Control = p.Control,
                    Action = p.Action,
                    PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                    Type = (PermissionType)p.PermissionType,
                    Source = PermissionSource.UserGroup,
                    SourceName = group.Name,
                    IsInherited = false
                }).ToList();

                dgvPermissions.DataSource = _currentPermissions;
            }
        }

        private void LoadEmployeePermissions(string employeeId)
        {
            _currentPermissions = _permission.GetPermissionDetails(employeeId);
            dgvPermissions.DataSource = _currentPermissions;
        }

        private void LoadMergedPermissions()
        {
            if (!string.IsNullOrEmpty(_selectedEmployeeId))
            {
                _mergedPermissions = _permission.GetMergedPermissions(_selectedEmployeeId);
                dgvMergedPermissions.DataSource = _mergedPermissions;

                // ���G��ܦ��Ĭ𪺦�
                foreach (DataGridViewRow row in dgvMergedPermissions.Rows)
                {
                    var item = row.DataBoundItem as PermissionMergeResult;
                    if (item?.HasConflict == true)
                    {
                        row.DefaultCellStyle.BackColor = Color.LightYellow;
                    }
                }
            }
        }

        private void LoadConflicts()
        {
            if (!string.IsNullOrEmpty(_selectedEmployeeId))
            {
                _conflicts = _permission.GetPermissionConflicts(_selectedEmployeeId);
                dgvConflicts.DataSource = _conflicts;

                // �̽Ĭ𵥯ų]�w�C��
                foreach (DataGridViewRow row in dgvConflicts.Rows)
                {
                    var conflict = row.DataBoundItem as PermissionConflictViewModel;
                    if (conflict != null)
                    {
                        switch (conflict.ConflictLevel)
                        {
                            case 2:
                                row.DefaultCellStyle.BackColor = Color.LightCoral; // ���Ĭ�
                                break;
                            case 1:
                                row.DefaultCellStyle.BackColor = Color.LightYellow; // �C�Ĭ�
                                break;
                        }
                    }
                }
            }
        }

        #endregion

        #region Nested Classes

        private class SourceNodeData
        {
            public PermissionSource Source { get; set; }
            public int Id { get; set; }
            public string EmployeeId { get; set; }
            public string Name { get; set; }
        }

        #endregion
    }
}
