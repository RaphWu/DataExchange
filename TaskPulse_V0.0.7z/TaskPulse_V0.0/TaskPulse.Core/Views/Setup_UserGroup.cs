using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    /// <summary>
    /// �ϥΪ̸s�ճ]�w����
    /// �䴩�s�� CRUD �\��M�H���޲z
    /// </summary>
    public partial class Setup_UserGroup : UserControl
    {
        #region Fields

        private readonly ILifetimeScope _scope;
        private readonly IRegionManager _region;
        private readonly INavigationService _navigation;
        private readonly CoreContext _context;

        private readonly DbSet<UserGroup> _userGroups;
        private readonly DbSet<Employee> _employees;

        private List<ListViewModel> _vmUserGroups = null;
        private ListViewModel _vmUserGroup = null;
        private UserGroup _selectedUserGroup = null;

        private List<EmployeeViewModel> _vmAvailableEmployees = null;
        private List<EmployeeViewModel> _vmGroupMembers = null;

        #endregion

        #region Constructor

        public Setup_UserGroup(
            ILifetimeScope lifetimeScope,
            IRegionManager regionManager,
            INavigationService navigationService,
            CoreContext coreContext)
        {
            InitializeComponent();

            _scope = lifetimeScope;
            _region = regionManager;
            _navigation = navigationService;
            _context = coreContext;

            _region.RegisterRegion(nameof(Panel_Permission), Panel_Permission);
            _navigation.Navigate<Setup_Permission_Small>(nameof(Panel_Permission), alive: false);

            _userGroups = _context.UserGroups;
            _employees = _context.Employees;

            InitializeUI();

            WeakReferenceMessenger.Default.Register<NotifyEmployeeDataUpdated>(this, async (recipient, message) =>
            {
                await UpdateData();
            });
        }

        #endregion

        #region Initialization

        private void InitializeUI()
        {
            // �]�w�s�� ListBox
            string itemName = "�ϥΪ̸s��";
            Label_UserGroup.Text = itemName;
            CommonStyles.SetListBox(lboxUserGroups);
            CommonStyles.SetCrudButton(UserGroup_Create, "C", itemName);
            CommonStyles.SetCrudButton(UserGroup_Edit, "E", itemName);
            CommonStyles.SetCrudButton(UserGroup_Delete, "D", itemName);
            CommonStyles.SetCrudButton(UserGroup_Up, "UP", itemName);
            CommonStyles.SetCrudButton(UserGroup_Down, "DOWN", itemName);

            // �]�w�i�ΤH�� DataGridView
            SetupDataGridViewStyle(dgvAvailableEmployees);
            dgvAvailableEmployees.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAvailableEmployees.MultiSelect = true;

            dgvAvailableEmployees.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "EmployeeId",
                HeaderText = "�u��",
                Width = 80,
                ReadOnly = true
            });

            dgvAvailableEmployees.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "EmployeeName",
                HeaderText = "�m�W",
                Width = 120,
                ReadOnly = true
            });

            dgvAvailableEmployees.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DepartmentName",
                HeaderText = "����",
                Width = 120,
                ReadOnly = true
            });

            // �]�w�s�զ��� DataGridView
            SetupDataGridViewStyle(dgvGroupMembers);
            dgvGroupMembers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvGroupMembers.MultiSelect = true;

            dgvGroupMembers.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "EmployeeId",
                HeaderText = "�u��",
                Width = 80,
                ReadOnly = true
            });

            dgvGroupMembers.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "EmployeeName",
                HeaderText = "�m�W",
                Width = 120,
                ReadOnly = true
            });

            dgvGroupMembers.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DepartmentName",
                HeaderText = "����",
                Width = 120,
                ReadOnly = true
            });

            // �]�w���s�˦�
            CommonStyles.SetButton(btnAddMembers, "�N�襤���H���[�J�s��", isAccent: true);
            CommonStyles.SetButton(btnRemoveMembers, "�N�襤���H���q�s�ղ���", isCancel: true);
        }

        private void SetupDataGridViewStyle(DataGridView dgv)
        {
            dgv.AutoGenerateColumns = false;
            dgv.RowHeadersVisible = false;
            dgv.AllowUserToResizeColumns = true;
            dgv.AllowUserToResizeRows = false;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToOrderColumns = false;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv.DefaultCellStyle.SelectionBackColor = CommonStyles.SelectedColor;
            dgv.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.WhiteSmoke;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            dgv.GridColor = System.Drawing.Color.LightGray;
            dgv.DefaultCellStyle.Font = CommonStyles.Font;
            dgv.ColumnHeadersDefaultCellStyle.Font = CommonStyles.Font;
        }

        #endregion

        #region Lifecycle

        protected override void Dispose(bool disposing)
        {
            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            if (disposing)
            {
                components?.Dispose();
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        private async void Setup_UserGroup_Load(object sender, EventArgs e)
        {
            await UpdateData();
        }

        #endregion

        #region Data Loading

        private async Task UpdateData()
        {
            await UpdateUserGroupView();
            await UpdateEmployeeLists();
        }

        private async Task UpdateUserGroupView()
        {
            _vmUserGroups = await _userGroups
                .Select(g => new ListViewModel()
                {
                    Id = g.Id,
                    Name = g.Name,
                    OrderNo = g.OrderNo,
                })
                .ToListAsync();

            lboxUserGroups.DisplayMember = nameof(ListViewModel.Name);
            lboxUserGroups.ValueMember = nameof(ListViewModel.Id);
            lboxUserGroups.DataSource = _vmUserGroups;
        }

        private async Task UpdateEmployeeLists()
        {
            if (_selectedUserGroup == null)
            {
                _vmAvailableEmployees = new List<EmployeeViewModel>();
                _vmGroupMembers = new List<EmployeeViewModel>();
            }
            else
            {
                // ���s���J�襤���s�ա]�]�t�����^
                _selectedUserGroup = await _userGroups
                    .Include(g => g.Members.Select(m => m.Department))
                    .FirstOrDefaultAsync(g => g.Id == _selectedUserGroup.Id);

                if (_selectedUserGroup != null)
                {
                    var memberIds = _selectedUserGroup.Members.Select(m => m.Id).ToList();

                    // �s�զ���
                    _vmGroupMembers = _selectedUserGroup.Members
                        .Where(emp => emp.StatusId == 1) // �u��ܦb¾���u
                        .Select(emp => new EmployeeViewModel
                        {
                            Id = emp.Id,
                            EmployeeId = emp.EmployeeId,
                            EmployeeName = emp.EmployeeName,
                            DepartmentName = emp.Department?.DepartmentName ?? ""
                        })
                        .OrderBy(emp => emp.EmployeeId)
                        .ToList();

                    // �i�ΤH���]���b�s�դ����b¾���u�^
                    _vmAvailableEmployees = await _employees
                        .Include(emp => emp.Department)
                        .Where(emp => emp.StatusId == 1 && !memberIds.Contains(emp.Id))
                        .Select(emp => new EmployeeViewModel
                        {
                            Id = emp.Id,
                            EmployeeId = emp.EmployeeId,
                            EmployeeName = emp.EmployeeName,
                            DepartmentName = emp.Department.DepartmentName ?? ""
                        })
                        .OrderBy(emp => emp.EmployeeId)
                        .ToListAsync();
                }
            }

            dgvAvailableEmployees.DataSource = _vmAvailableEmployees;
            dgvGroupMembers.DataSource = _vmGroupMembers;

            UpdateMemberButtonsState();
        }

        private void UpdateMemberButtonsState()
        {
            bool hasGroup = _selectedUserGroup != null;
            bool hasAvailableSelection = dgvAvailableEmployees.SelectedRows.Count > 0;
            bool hasMemberSelection = dgvGroupMembers.SelectedRows.Count > 0;

            btnAddMembers.Enabled = hasGroup && hasAvailableSelection;
            btnRemoveMembers.Enabled = hasGroup && hasMemberSelection;
        }

        #endregion

        #region UserGroup CRUD

        private void lboxUserGroups_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmUserGroup = lboxUserGroups.SelectedItem as ListViewModel;

            if (_vmUserGroup != null)
            {
                _selectedUserGroup = _userGroups
                    .Include(g => g.Members)
                    .FirstOrDefault(g => g.Id == _vmUserGroup.Id);

                UserGroup_Edit.Enabled = true;
                UserGroup_Delete.Enabled = true;

                if (lboxUserGroups.DataSource is List<ListViewModel> vmGroups)
                {
                    var vmOrderNo = vmGroups.FirstOrDefault(w => w.Id == _vmUserGroup.Id)?.OrderNo ?? 0;
                    UserGroup_Up.Enabled = vmOrderNo != vmGroups.Min(w => w.OrderNo);
                    UserGroup_Down.Enabled = vmOrderNo != vmGroups.Max(w => w.OrderNo);
                }
                else
                {
                    UserGroup_Up.Enabled = false;
                    UserGroup_Down.Enabled = false;
                }

                _ = UpdateEmployeeLists();

                // �o�e�v���]�w�T��
                _ = WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                    new PermissionSettingInfo()
                    {
                        PermissionSource = PermissionSource.UserGroup,
                        UserGroupId = _vmUserGroup.Id,
                    }));
            }
            else
            {
                _selectedUserGroup = null;
                UserGroup_Edit.Enabled = false;
                UserGroup_Delete.Enabled = false;
                UserGroup_Up.Enabled = false;
                UserGroup_Down.Enabled = false;

                _ = UpdateEmployeeLists();
            }
        }

        private async void UserGroup_Create_Click(object sender, EventArgs e)
        {
            string title = "�п�J�s�ϥΪ̸s�զW��";
            string caption = "�s�s�զW��";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "�s�զW�٤��i���ťաI"),
                input => input.Length <= 50 ? (true, "") : (false, "�s�զW�٥����p�󵥩� 50 �Ӧr���I"),
                input => _userGroups.Any(m => m.Name == input) ? (false, "�s�զW�٤w�s�b�I") : (true, "")
            );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);

                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newGroupName = crud.Result.StringValue;
                    int maxOrderNo = _userGroups.Any() ? _userGroups.Max(w => w.OrderNo) : 0;

                    _context.UserGroups.Add(new UserGroup()
                    {
                        Name = newGroupName,
                        OrderNo = maxOrderNo + 1
                    });

                    await _context.SaveChangesAsync();
                    await UpdateUserGroupView();
                    lboxUserGroups.SelectedIndex = _vmUserGroups.FindIndex(m => m.Name == newGroupName);

                    MessageBox.Show($"�w�W�[�s�ϥΪ̸s��: {newGroupName}",
                                    "�s�W���\",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void UserGroup_Edit_Click(object sender, EventArgs e)
        {
            if (_vmUserGroup != null)
            {
                var thisGroup = _vmUserGroup;
                string title = "�п�J�s�s�զW��";
                string oldCaption = "��s�զW��";
                string newCaption = "�s�s�զW��";
                var validator = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "�s�զW�٤��i���ťաI"),
                    input => input.Length <= 50 ? (true, "") : (false, "�s�զW�٥����p�󵥩� 50 �Ӧr���I"),
                    input => _userGroups.Any(m => m.Name == input && m.Id != thisGroup.Id) ? (false, "�s�զW�٤w�s�b�I") : (true, "")
                );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = thisGroup.Name,
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisGroup.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validator);

                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        string newGroupName = crud.Result.StringValue;

                        var newGroup = _userGroups.FirstOrDefault(m => m.Id == thisGroup.Id);
                        if (newGroup != null)
                        {
                            newGroup.Name = newGroupName;
                            await _context.SaveChangesAsync();
                            await UpdateUserGroupView();
                            lboxUserGroups.SelectedIndex = _vmUserGroups.FindIndex(m => m.Id == newGroup.Id);

                            MessageBox.Show($"�ϥΪ̸s�� {thisGroup.Name} �W�٤w��s�� {newGroupName}",
                                            "��s���\",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private async void UserGroup_Delete_Click(object sender, EventArgs e)
        {
            if (_vmUserGroup != null)
            {
                var thisGroup = _vmUserGroup;

                if (UIMessageBox.ShowAsk2($"�T�w�n�R���ϥΪ̸s�� {thisGroup.Name} �ܡH\n\n���ާ@�N�Ѱ��s�ջP�Ҧ����������p�C",
                    true, UIMessageDialogButtons.Cancel))
                {
                    var targetGroup = _userGroups
                        .Include(g => g.Members)
                        .Include(g => g.Permissions)
                        .FirstOrDefault(m => m.Id == thisGroup.Id);

                    if (targetGroup != null)
                    {
                        // �M�����p
                        targetGroup.Members.Clear();
                        targetGroup.Permissions.Clear();

                        _userGroups.Remove(targetGroup);
                        await _context.SaveChangesAsync();
                        await UpdateUserGroupView();

                        MessageBox.Show($"�ϥΪ̸s�� {thisGroup.Name} �w�R��",
                                        "�R�����\",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void UserGroup_Up_Click(object sender, EventArgs e)
        {
            if (_vmUserGroup != null)
            {
                var thisGroup = _vmUserGroup;
                var smallerVmGroup = _vmUserGroups.LastOrDefault(w => w.OrderNo < thisGroup.OrderNo);
                if (smallerVmGroup != null)
                {
                    await SwapUserGroupOrderNo(thisGroup.Id, smallerVmGroup.Id);
                    lboxUserGroups.SelectedIndex = _vmUserGroups.FindIndex(m => m.Id == thisGroup.Id);
                }
            }
        }

        private async void UserGroup_Down_Click(object sender, EventArgs e)
        {
            if (_vmUserGroup != null)
            {
                var thisVm = _vmUserGroup;
                var biggerVm = _vmUserGroups.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapUserGroupOrderNo(thisVm.Id, biggerVm.Id);
                    lboxUserGroups.SelectedIndex = _vmUserGroups.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapUserGroupOrderNo(int id1, int id2)
        {
            var entity1 = _userGroups.FirstOrDefault(w => w.Id == id1);
            var entity2 = _userGroups.FirstOrDefault(w => w.Id == id2);

            if (entity1 != null && entity2 != null)
            {
                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateUserGroupView();
            }
        }

        #endregion

        #region Member Management

        private void dgvAvailableEmployees_SelectionChanged(object sender, EventArgs e)
        {
            UpdateMemberButtonsState();
        }

        private void dgvGroupMembers_SelectionChanged(object sender, EventArgs e)
        {
            UpdateMemberButtonsState();
        }

        private async void btnAddMembers_Click(object sender, EventArgs e)
        {
            if (_selectedUserGroup == null || dgvAvailableEmployees.SelectedRows.Count == 0)
                return;

            var selectedEmployeeIds = dgvAvailableEmployees.SelectedRows
                .Cast<DataGridViewRow>()
                .Select(row => ((EmployeeViewModel)row.DataBoundItem).Id)
                .ToList();

            var employeesToAdd = await _employees
                .Where(emp => selectedEmployeeIds.Contains(emp.Id))
                .ToListAsync();

            foreach (var employee in employeesToAdd)
            {
                if (!_selectedUserGroup.Members.Any(m => m.Id == employee.Id))
                {
                    _selectedUserGroup.Members.Add(employee);
                }
            }

            await _context.SaveChangesAsync();
            await UpdateEmployeeLists();

            MessageBox.Show($"�w�N {employeesToAdd.Count} ��H���[�J�s��",
                            "�[�J���\",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }

        private async void btnRemoveMembers_Click(object sender, EventArgs e)
        {
            if (_selectedUserGroup == null || dgvGroupMembers.SelectedRows.Count == 0)
                return;

            var selectedEmployeeIds = dgvGroupMembers.SelectedRows
                .Cast<DataGridViewRow>()
                .Select(row => ((EmployeeViewModel)row.DataBoundItem).Id)
                .ToList();

            if (UIMessageBox.ShowAsk2($"�T�w�n�N�襤�� {selectedEmployeeIds.Count} ��H���q�s�ղ����ܡH",
                true, UIMessageDialogButtons.Cancel))
            {
                var employeesToRemove = _selectedUserGroup.Members
                    .Where(m => selectedEmployeeIds.Contains(m.Id))
                    .ToList();

                foreach (var employee in employeesToRemove)
                {
                    _selectedUserGroup.Members.Remove(employee);
                }

                await _context.SaveChangesAsync();
                await UpdateEmployeeLists();

                MessageBox.Show($"�w�N {employeesToRemove.Count} ��H���q�s�ղ���",
                                "�������\",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        #endregion

        #region Helper Classes

        private class EmployeeViewModel
        {
            public int Id { get; set; }
            public string EmployeeId { get; set; }
            public string EmployeeName { get; set; }
            public string DepartmentName { get; set; }
        }

        #endregion
    }
}
