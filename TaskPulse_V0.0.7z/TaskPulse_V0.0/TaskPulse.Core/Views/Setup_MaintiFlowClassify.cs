﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;
using IssueCategory = Calin.TaskPulse.Entity.MaintiFlow.MaintiFlowIssueCategory;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MaintiFlowClassify : UserControl
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ILifetimeScope _scope;
        private readonly IEntityCacheManager _cacheManager;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        private List<ListViewModel> _vmIssueCategories = null;
        private ListViewModel _vmIssueCategory = null;

        #endregion fields

        public Setup_MaintiFlowClassify(
            Serilog.ILogger logger,
            ILifetimeScope lifetimeScope,
            IEntityCacheManager cacheManager,
            CoreContext coreContext,
            CoreData coreData)
        {
            InitializeComponent();
            _logger = logger;
            _scope = lifetimeScope;
            _cacheManager = cacheManager;
            _context = coreContext;
            _coreData = coreData;

            _context.IssueCategories = _context.IssueCategories;

            string itemName = PropertyText.Title.MaintiFlowIssueCategory;
            HeadLabel_IssueCategory.Text = itemName;
            CommonStyles.SetListBox(List_IssueCategories);
            CommonStyles.SetCrudButton(IssueCategory_Create, "C", itemName);
            CommonStyles.SetCrudButton(IssueCategory_Edit, "E", itemName);
            CommonStyles.SetCrudButton(IssueCategory_Delete, "D", itemName);
            CommonStyles.SetCrudButton(IssueCategory_Up, "UP", itemName);
            CommonStyles.SetCrudButton(IssueCategory_Down, "DOWN", itemName);

            WeakReferenceMessenger.Default.Register<NotifyMachineDataUpdated>(this, async (recipient, message) =>
            {
                await LoadData();
            });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        private async void Setup_MaintiFlowClassify_Load(object sender, EventArgs e)
        {
            await LoadData();
        }

        private async Task LoadData()
        {
            await UpdateIssueCategoriesView();
        }

        #region IssueIssueCategories

        /********************
         * IssueCategory
         ********************/
        private async Task UpdateIssueCategoriesView()
        {
            var query = await _context.IssueCategories
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmIssueCategories = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.CategoryName, OrderNo = b.OrderNo })
                .ToList();
            List_IssueCategories.DataSource = null;
            List_IssueCategories.ValueMember = nameof(ListViewModel.Id);
            List_IssueCategories.DisplayMember = nameof(ListViewModel.Name);
            List_IssueCategories.DataSource = _vmIssueCategories;
        }

        private async void List_IssueCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmIssueCategory = List_IssueCategories.SelectedItem as ListViewModel;
            if (_vmIssueCategory != null)
            {
                IssueCategory_Edit.Enabled = true;
                IssueCategory_Delete.Enabled = true;

                if (List_IssueCategories.DataSource is List<ListViewModel> vmIssueCategory)
                {
                    var vmOrderNo = vmIssueCategory.FirstOrDefault(w => w.Id == _vmIssueCategory.Id).OrderNo;
                    IssueCategory_Up.Enabled = vmOrderNo != vmIssueCategory.Min(w => w.OrderNo);
                    IssueCategory_Down.Enabled = vmOrderNo != vmIssueCategory.Max(w => w.OrderNo);
                }
                else
                {
                    IssueCategory_Up.Enabled = false;
                    IssueCategory_Down.Enabled = false;
                }
            }
            else
            {
                IssueCategory_Edit.Enabled = false;
                IssueCategory_Delete.Enabled = false;
                IssueCategory_Up.Enabled = false;
                IssueCategory_Down.Enabled = false;
            }
        }

        private async void IssueCategory_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.MaintiFlowIssueCategory}名稱";
            string caption = $"新{PropertyText.Title.MaintiFlowIssueCategory}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.MaintiFlowIssueCategory}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.MaintiFlowIssueCategory}名稱必須小於等於 30 個字元！"),
                input => _context.IssueCategories.Any(m => m.CategoryName == input) ? (false, $"{PropertyText.Title.MaintiFlowIssueCategory}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newMachineIssueCategoryName = crud.Result.StringValue;
                    int maxOrderNo = _context.IssueCategories.Max(w => w.OrderNo);

                    _context.IssueCategories.Add(new IssueCategory()
                    {
                        CategoryName = newMachineIssueCategoryName,
                        OrderNo = maxOrderNo + 1,
                    });
                    await _context.SaveChangesAsync();
                    await UpdateIssueCategoriesView();
                    _cacheManager.RequestMachineUpdateDelay();
                    List_IssueCategories.SelectedIndex = _vmIssueCategories.FindIndex(m => m.Name == newMachineIssueCategoryName);

                    MessageBox.Show($"已增加新{PropertyText.Title.MaintiFlowIssueCategory}: {newMachineIssueCategoryName}",
                                    $"新增成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void IssueCategory_Edit_Click(object sender, EventArgs e)
        {
            if (_vmIssueCategory != null)
            {
                var thisIssueCategory = _vmIssueCategory;
                string title = $"請輸入新{PropertyText.Title.MaintiFlowIssueCategory}名稱";
                string oldCaption = $"原{PropertyText.Title.MaintiFlowIssueCategory}名稱";
                string newCaption = $"新{PropertyText.Title.MaintiFlowIssueCategory}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.MaintiFlowIssueCategory}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.MaintiFlowIssueCategory}名稱必須小於等於 30 個字元！"),
                    input => _context.IssueCategories.Any(m => m.CategoryName == input) ? (false, $"{PropertyText.Title.MaintiFlowIssueCategory}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = thisIssueCategory.Name,
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = "",
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        string newIssueCategoryName = crud.Result.StringValue;

                        var newIssueCategory = _context.IssueCategories.FirstOrDefault(m => m.Id == thisIssueCategory.Id);
                        if (newIssueCategory != null)
                        {
                            newIssueCategory.CategoryName = newIssueCategoryName;
                            await _context.SaveChangesAsync();
                            await UpdateIssueCategoriesView();
                            _cacheManager.RequestMachineUpdateDelay();
                            List_IssueCategories.SelectedIndex = _vmIssueCategories.FindIndex(m => m.Id == newIssueCategory.Id);

                            MessageBox.Show($"{PropertyText.Title.MaintiFlowIssueCategory} {thisIssueCategory.Name} 名稱已更新為 {newIssueCategoryName}",
                                            $"更新成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private async void IssueCategory_Delete_Click(object sender, EventArgs e)
        {
            if (_vmIssueCategory != null)
            {
                var thisIssueCategory = _vmIssueCategory;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.MaintiFlowIssueCategory} {thisIssueCategory.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetIssueCategory = _context.IssueCategories.FirstOrDefault(m => m.Id == thisIssueCategory.Id);
                    if (targetIssueCategory != null)
                    {
                        _context.IssueCategories.Remove(targetIssueCategory);
                        await _context.SaveChangesAsync();
                        await UpdateIssueCategoriesView();
                        _cacheManager.RequestMachineUpdateDelay();

                        MessageBox.Show($"{PropertyText.Title.MaintiFlowIssueCategory} {thisIssueCategory.Name} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void IssueCategory_Up_Click(object sender, EventArgs e)
        {
            if (_vmIssueCategory != null)
            {
                var thisVmWs = _vmIssueCategory;
                var smallerVmWs = _vmIssueCategories.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapIssueCategoryOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_IssueCategories.SelectedIndex = _vmIssueCategories.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void IssueCategory_Down_Click(object sender, EventArgs e)
        {
            if (_vmIssueCategory != null)
            {
                var thisVm = _vmIssueCategory;
                var biggerVm = _vmIssueCategories.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapIssueCategoryOrderNo(thisVm.Id, biggerVm.Id);
                    List_IssueCategories.SelectedIndex = _vmIssueCategories.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapIssueCategoryOrderNo(int id1, int id2)
        {
            var entity1 = _context.IssueCategories.FirstOrDefault(w => w.Id == id1);
            var entity2 = _context.IssueCategories.FirstOrDefault(w => w.Id == id2);

            (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
            await _context.SaveChangesAsync();
            await UpdateIssueCategoriesView();
            _cacheManager.RequestMachineUpdateDelay();
        }

        #endregion IssueIssueCategories

    }
}
