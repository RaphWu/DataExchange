﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Department
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.Status_Create = new Sunny.UI.UISymbolButton();
            this.Status_Edit = new Sunny.UI.UISymbolButton();
            this.Status_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.Status_Up = new Sunny.UI.UISymbolButton();
            this.Status_Down = new Sunny.UI.UISymbolButton();
            this.lboxStatus = new Sunny.UI.UIListBox();
            this.labelStatus = new System.Windows.Forms.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.JobTitle_Create = new Sunny.UI.UISymbolButton();
            this.JobTitle_Edit = new Sunny.UI.UISymbolButton();
            this.JobTitle_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.JobTitle_Up = new Sunny.UI.UISymbolButton();
            this.JobTitle_Down = new Sunny.UI.UISymbolButton();
            this.lboxJobTitles = new Sunny.UI.UIListBox();
            this.Label_Title = new System.Windows.Forms.Label();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.Department_Create = new Sunny.UI.UISymbolButton();
            this.Department_Edit = new Sunny.UI.UISymbolButton();
            this.Department_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.Department_Up = new Sunny.UI.UISymbolButton();
            this.Department_Down = new Sunny.UI.UISymbolButton();
            this.lboxDepartments = new Sunny.UI.UIListBox();
            this.Label_Department = new System.Windows.Forms.Label();
            this.Panel_Permission = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 8;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel6, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel5, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.lboxStatus, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelStatus, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.lboxJobTitles, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.Label_Title, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel4, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel3, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lboxDepartments, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.Label_Department, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.Panel_Permission, 2, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 210F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1058, 714);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel6.AutoSize = true;
            this.flowLayoutPanel6.Controls.Add(this.Status_Create);
            this.flowLayoutPanel6.Controls.Add(this.Status_Edit);
            this.flowLayoutPanel6.Controls.Add(this.Status_Delete);
            this.flowLayoutPanel6.Location = new System.Drawing.Point(772, 454);
            this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel6.TabIndex = 37;
            // 
            // Status_Create
            // 
            this.Status_Create.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Status_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Status_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status_Create.Location = new System.Drawing.Point(9, 0);
            this.Status_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Status_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Status_Create.Name = "Status_Create";
            this.Status_Create.Size = new System.Drawing.Size(30, 30);
            this.Status_Create.Symbol = 557669;
            this.Status_Create.SymbolSize = 32;
            this.Status_Create.TabIndex = 2;
            this.Status_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Status_Create.Click += new System.EventHandler(this.Status_Create_Click);
            // 
            // Status_Edit
            // 
            this.Status_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Status_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Status_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status_Edit.Location = new System.Drawing.Point(57, 0);
            this.Status_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Status_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Status_Edit.Name = "Status_Edit";
            this.Status_Edit.Size = new System.Drawing.Size(30, 30);
            this.Status_Edit.Symbol = 559205;
            this.Status_Edit.SymbolSize = 32;
            this.Status_Edit.TabIndex = 3;
            this.Status_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Status_Edit.Click += new System.EventHandler(this.Status_Edit_Click);
            // 
            // Status_Delete
            // 
            this.Status_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Status_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Status_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status_Delete.Location = new System.Drawing.Point(105, 0);
            this.Status_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Status_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Status_Delete.Name = "Status_Delete";
            this.Status_Delete.Size = new System.Drawing.Size(30, 30);
            this.Status_Delete.Symbol = 559506;
            this.Status_Delete.SymbolSize = 26;
            this.Status_Delete.TabIndex = 4;
            this.Status_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Status_Delete.Click += new System.EventHandler(this.Status_Delete_Click);
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel5.AutoSize = true;
            this.flowLayoutPanel5.Controls.Add(this.Status_Up);
            this.flowLayoutPanel5.Controls.Add(this.Status_Down);
            this.flowLayoutPanel5.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(686, 68);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel5.TabIndex = 36;
            // 
            // Status_Up
            // 
            this.Status_Up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Status_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Status_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status_Up.Location = new System.Drawing.Point(0, 9);
            this.Status_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Status_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Status_Up.Name = "Status_Up";
            this.Status_Up.Size = new System.Drawing.Size(30, 30);
            this.Status_Up.Symbol = 361702;
            this.Status_Up.SymbolSize = 32;
            this.Status_Up.TabIndex = 2;
            this.Status_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Status_Up.Click += new System.EventHandler(this.Status_Up_Click);
            // 
            // Status_Down
            // 
            this.Status_Down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Status_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Status_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status_Down.Location = new System.Drawing.Point(0, 57);
            this.Status_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Status_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Status_Down.Name = "Status_Down";
            this.Status_Down.Size = new System.Drawing.Size(30, 30);
            this.Status_Down.Symbol = 361703;
            this.Status_Down.SymbolSize = 32;
            this.Status_Down.TabIndex = 4;
            this.Status_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Status_Down.Click += new System.EventHandler(this.Status_Down_Click);
            // 
            // lboxStatus
            // 
            this.lboxStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lboxStatus.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.lboxStatus.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.lboxStatus.ItemSelectForeColor = System.Drawing.Color.White;
            this.lboxStatus.Location = new System.Drawing.Point(723, 30);
            this.lboxStatus.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lboxStatus.MinimumSize = new System.Drawing.Size(1, 1);
            this.lboxStatus.Name = "lboxStatus";
            this.lboxStatus.Padding = new System.Windows.Forms.Padding(2);
            this.lboxStatus.Radius = 1;
            this.lboxStatus.ShowText = false;
            this.lboxStatus.Size = new System.Drawing.Size(242, 419);
            this.lboxStatus.TabIndex = 35;
            this.lboxStatus.Text = "uiListBox1";
            this.lboxStatus.SelectedIndexChanged += new System.EventHandler(this.lboxStatuss_SelectedIndexChanged);
            // 
            // labelStatus
            // 
            this.labelStatus.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.labelStatus.AutoSize = true;
            this.labelStatus.Font = new System.Drawing.Font("標楷體", 14F);
            this.labelStatus.Location = new System.Drawing.Point(819, 6);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(49, 19);
            this.labelStatus.TabIndex = 34;
            this.labelStatus.Text = "狀態";
            this.labelStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel2.AutoSize = true;
            this.flowLayoutPanel2.Controls.Add(this.JobTitle_Create);
            this.flowLayoutPanel2.Controls.Add(this.JobTitle_Edit);
            this.flowLayoutPanel2.Controls.Add(this.JobTitle_Delete);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(452, 454);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel2.TabIndex = 32;
            // 
            // JobTitle_Create
            // 
            this.JobTitle_Create.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.JobTitle_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.JobTitle_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.JobTitle_Create.Location = new System.Drawing.Point(9, 0);
            this.JobTitle_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.JobTitle_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.JobTitle_Create.Name = "JobTitle_Create";
            this.JobTitle_Create.Size = new System.Drawing.Size(30, 30);
            this.JobTitle_Create.Symbol = 557669;
            this.JobTitle_Create.SymbolSize = 32;
            this.JobTitle_Create.TabIndex = 2;
            this.JobTitle_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.JobTitle_Create.Click += new System.EventHandler(this.JobTitle_Create_Click);
            // 
            // JobTitle_Edit
            // 
            this.JobTitle_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.JobTitle_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.JobTitle_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.JobTitle_Edit.Location = new System.Drawing.Point(57, 0);
            this.JobTitle_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.JobTitle_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.JobTitle_Edit.Name = "JobTitle_Edit";
            this.JobTitle_Edit.Size = new System.Drawing.Size(30, 30);
            this.JobTitle_Edit.Symbol = 559205;
            this.JobTitle_Edit.SymbolSize = 32;
            this.JobTitle_Edit.TabIndex = 3;
            this.JobTitle_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.JobTitle_Edit.Click += new System.EventHandler(this.JobTitle_Edit_Click);
            // 
            // JobTitle_Delete
            // 
            this.JobTitle_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.JobTitle_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.JobTitle_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.JobTitle_Delete.Location = new System.Drawing.Point(105, 0);
            this.JobTitle_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.JobTitle_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.JobTitle_Delete.Name = "JobTitle_Delete";
            this.JobTitle_Delete.Size = new System.Drawing.Size(30, 30);
            this.JobTitle_Delete.Symbol = 559506;
            this.JobTitle_Delete.SymbolSize = 26;
            this.JobTitle_Delete.TabIndex = 4;
            this.JobTitle_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.JobTitle_Delete.Click += new System.EventHandler(this.JobTitle_Delete_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.JobTitle_Up);
            this.flowLayoutPanel1.Controls.Add(this.JobTitle_Down);
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(366, 68);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel1.TabIndex = 31;
            // 
            // JobTitle_Up
            // 
            this.JobTitle_Up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.JobTitle_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.JobTitle_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.JobTitle_Up.Location = new System.Drawing.Point(0, 9);
            this.JobTitle_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.JobTitle_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.JobTitle_Up.Name = "JobTitle_Up";
            this.JobTitle_Up.Size = new System.Drawing.Size(30, 30);
            this.JobTitle_Up.Symbol = 361702;
            this.JobTitle_Up.SymbolSize = 32;
            this.JobTitle_Up.TabIndex = 2;
            this.JobTitle_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.JobTitle_Up.Click += new System.EventHandler(this.JobTitle_Up_Click);
            // 
            // JobTitle_Down
            // 
            this.JobTitle_Down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.JobTitle_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.JobTitle_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.JobTitle_Down.Location = new System.Drawing.Point(0, 57);
            this.JobTitle_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.JobTitle_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.JobTitle_Down.Name = "JobTitle_Down";
            this.JobTitle_Down.Size = new System.Drawing.Size(30, 30);
            this.JobTitle_Down.Symbol = 361703;
            this.JobTitle_Down.SymbolSize = 32;
            this.JobTitle_Down.TabIndex = 4;
            this.JobTitle_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.JobTitle_Down.Click += new System.EventHandler(this.JobTitle_Down_Click);
            // 
            // lboxJobTitles
            // 
            this.lboxJobTitles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lboxJobTitles.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.lboxJobTitles.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.lboxJobTitles.ItemSelectForeColor = System.Drawing.Color.White;
            this.lboxJobTitles.Location = new System.Drawing.Point(403, 30);
            this.lboxJobTitles.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lboxJobTitles.MinimumSize = new System.Drawing.Size(1, 1);
            this.lboxJobTitles.Name = "lboxJobTitles";
            this.lboxJobTitles.Padding = new System.Windows.Forms.Padding(2);
            this.lboxJobTitles.Radius = 1;
            this.lboxJobTitles.ShowText = false;
            this.lboxJobTitles.Size = new System.Drawing.Size(242, 419);
            this.lboxJobTitles.TabIndex = 30;
            this.lboxJobTitles.Text = "uiListBox1";
            this.lboxJobTitles.SelectedIndexChanged += new System.EventHandler(this.lboxJobTitles_SelectedIndexChanged);
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Label_Title.AutoSize = true;
            this.Label_Title.Font = new System.Drawing.Font("標楷體", 14F);
            this.Label_Title.Location = new System.Drawing.Point(499, 6);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(49, 19);
            this.Label_Title.TabIndex = 29;
            this.Label_Title.Text = "職稱";
            this.Label_Title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.Controls.Add(this.Department_Create);
            this.flowLayoutPanel4.Controls.Add(this.Department_Edit);
            this.flowLayoutPanel4.Controls.Add(this.Department_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(132, 454);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 28;
            // 
            // Department_Create
            // 
            this.Department_Create.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Department_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Department_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Department_Create.Location = new System.Drawing.Point(9, 0);
            this.Department_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Department_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Department_Create.Name = "Department_Create";
            this.Department_Create.Size = new System.Drawing.Size(30, 30);
            this.Department_Create.Symbol = 557669;
            this.Department_Create.SymbolSize = 32;
            this.Department_Create.TabIndex = 2;
            this.Department_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Department_Create.Click += new System.EventHandler(this.Department_Create_Click);
            // 
            // Department_Edit
            // 
            this.Department_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Department_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Department_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Department_Edit.Location = new System.Drawing.Point(57, 0);
            this.Department_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Department_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Department_Edit.Name = "Department_Edit";
            this.Department_Edit.Size = new System.Drawing.Size(30, 30);
            this.Department_Edit.Symbol = 559205;
            this.Department_Edit.SymbolSize = 32;
            this.Department_Edit.TabIndex = 3;
            this.Department_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Department_Edit.Click += new System.EventHandler(this.Department_Edit_Click);
            // 
            // Department_Delete
            // 
            this.Department_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Department_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Department_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Department_Delete.Location = new System.Drawing.Point(105, 0);
            this.Department_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Department_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Department_Delete.Name = "Department_Delete";
            this.Department_Delete.Size = new System.Drawing.Size(30, 30);
            this.Department_Delete.Symbol = 559506;
            this.Department_Delete.SymbolSize = 26;
            this.Department_Delete.TabIndex = 4;
            this.Department_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Department_Delete.Click += new System.EventHandler(this.Department_Delete_Click);
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel3.AutoSize = true;
            this.flowLayoutPanel3.Controls.Add(this.Department_Up);
            this.flowLayoutPanel3.Controls.Add(this.Department_Down);
            this.flowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(46, 68);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel3.TabIndex = 27;
            // 
            // Department_Up
            // 
            this.Department_Up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Department_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Department_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Department_Up.Location = new System.Drawing.Point(0, 9);
            this.Department_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Department_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Department_Up.Name = "Department_Up";
            this.Department_Up.Size = new System.Drawing.Size(30, 30);
            this.Department_Up.Symbol = 361702;
            this.Department_Up.SymbolSize = 32;
            this.Department_Up.TabIndex = 2;
            this.Department_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Department_Up.Click += new System.EventHandler(this.Department_Up_Click);
            // 
            // Department_Down
            // 
            this.Department_Down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.Department_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Department_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Department_Down.Location = new System.Drawing.Point(0, 57);
            this.Department_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Department_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Department_Down.Name = "Department_Down";
            this.Department_Down.Size = new System.Drawing.Size(30, 30);
            this.Department_Down.Symbol = 361703;
            this.Department_Down.SymbolSize = 32;
            this.Department_Down.TabIndex = 4;
            this.Department_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Department_Down.Click += new System.EventHandler(this.Department_Down_Click);
            // 
            // lboxDepartments
            // 
            this.lboxDepartments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lboxDepartments.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.lboxDepartments.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.lboxDepartments.ItemSelectForeColor = System.Drawing.Color.White;
            this.lboxDepartments.Location = new System.Drawing.Point(83, 30);
            this.lboxDepartments.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lboxDepartments.MinimumSize = new System.Drawing.Size(1, 1);
            this.lboxDepartments.Name = "lboxDepartments";
            this.lboxDepartments.Padding = new System.Windows.Forms.Padding(2);
            this.lboxDepartments.Radius = 1;
            this.lboxDepartments.ShowText = false;
            this.lboxDepartments.Size = new System.Drawing.Size(242, 419);
            this.lboxDepartments.TabIndex = 21;
            this.lboxDepartments.Text = "uiListBox1";
            this.lboxDepartments.SelectedIndexChanged += new System.EventHandler(this.lboxDepartments_SelectedIndexChanged);
            // 
            // Label_Department
            // 
            this.Label_Department.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Label_Department.AutoSize = true;
            this.Label_Department.Font = new System.Drawing.Font("標楷體", 14F);
            this.Label_Department.Location = new System.Drawing.Point(179, 6);
            this.Label_Department.Name = "Label_Department";
            this.Label_Department.Size = new System.Drawing.Size(49, 19);
            this.Label_Department.TabIndex = 18;
            this.Label_Department.Text = "部門";
            this.Label_Department.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel_Permission
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.Panel_Permission, 5);
            this.Panel_Permission.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_Permission.Location = new System.Drawing.Point(82, 507);
            this.Panel_Permission.Name = "Panel_Permission";
            this.Panel_Permission.Size = new System.Drawing.Size(884, 204);
            this.Panel_Permission.TabIndex = 33;
            // 
            // Setup_Department
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Setup_Department";
            this.Size = new System.Drawing.Size(1058, 714);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.flowLayoutPanel6.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label Label_Department;
        private Sunny.UI.UIListBox lboxDepartments;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private Sunny.UI.UISymbolButton Department_Up;
        private Sunny.UI.UISymbolButton Department_Down;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton Department_Create;
        private Sunny.UI.UISymbolButton Department_Edit;
        private Sunny.UI.UISymbolButton Department_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private Sunny.UI.UISymbolButton JobTitle_Create;
        private Sunny.UI.UISymbolButton JobTitle_Edit;
        private Sunny.UI.UISymbolButton JobTitle_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Sunny.UI.UISymbolButton JobTitle_Up;
        private Sunny.UI.UISymbolButton JobTitle_Down;
        private Sunny.UI.UIListBox lboxJobTitles;
        private System.Windows.Forms.Label Label_Title;
        private System.Windows.Forms.Panel Panel_Permission;
        private System.Windows.Forms.Label labelStatus;
        private Sunny.UI.UIListBox lboxStatus;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private Sunny.UI.UISymbolButton Status_Create;
        private Sunny.UI.UISymbolButton Status_Edit;
        private Sunny.UI.UISymbolButton Status_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private Sunny.UI.UISymbolButton Status_Up;
        private Sunny.UI.UISymbolButton Status_Down;
    }
}
