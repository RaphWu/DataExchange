﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachinesSummary : UserControl
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ILifetimeScope _scope;
        private readonly IPermissionService _permission;
        private readonly IEntityCacheManager _cacheManager;
        private readonly ICore _core;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        private List<MachineViewModel> _mdgv;
        private readonly BindingSource _bs = new BindingSource();

        private bool _editPermission = false;
        private Machine _thisMachine;
        private string _thisMachineCode = "";
        private int _thisCategoryId = 0;
        private int _thisTypeId = 0;
        private int _thisTypeIndex = 0;
        private int _thisMachineNameId = 0;

        private TreeNode _newNode = null;
        private string _newMachineCode = "";

        #endregion fields

        public Setup_MachinesSummary(
            Serilog.ILogger logger,
            ILifetimeScope lifetimeScope,
            IPermissionService permissionService,
            IEntityCacheManager cacheManager,
            ICore core,
            CoreContext coreContext,
            CoreData coreData)
        {
            InitializeComponent();

            _logger = logger;
            _scope = lifetimeScope;
            _permission = permissionService;
            _cacheManager = cacheManager;
            _core = core;
            _context = coreContext;
            _coreData = coreData;

            var ctSource = _context.MachineCategories
                .OrderBy(mc => mc.OrderNo)
                .Select(mc => new ListViewModel()
                {
                    Id = mc.Id,
                    Name = mc.CategoryName,
                })
                .ToList();
            Catelogry.DataSource = ctSource;
            Catelogry.DisplayMember = "Name";
            Catelogry.ValueMember = "Id";

            //var ctType = new List<ListViewModel>();
            //ctType.AddRange(_context.MachineTypes
            //    .OrderBy(mt => mt.OrderNo)
            //    .Select(mt => new ListViewModel()
            //    {
            //        Id = mt.Id,
            //        Name = mt.TypeName,
            //    })
            //    .ToList());
            //Type.DataSource = ctType;
            //Type.DisplayMember = "Name";
            //Type.ValueMember = "Id";

            //var ctModelNo = new List<ListViewModel>();
            //ctModelNo.AddRange(_context.MachineNames
            //    .OrderBy(mn => mn.OrderNo)
            //    .Select(mn => new ListViewModel()
            //    {
            //        Id = mn.Id,
            //        Name = mn.ModelName,
            //    })
            //    .ToList());
            //ModelNo.DataSource = ctModelNo;
            //ModelNo.DisplayMember = "Name";
            //ModelNo.ValueMember = "Id";

            var ctCondition = _context.MachineConditions
                .Select(m => new ListViewModel()
                {
                    Id = m.Id,
                    Name = m.ConditionName,
                })
                .ToList();
            Condition.DataSource = ctCondition;
            Condition.DisplayMember = "Name";
            Condition.ValueMember = "Id";

            var ctBrand = _context.MachineBrands
                .Select(m => new ListViewModel()
                {
                    Id = m.Id,
                    Name = m.BrandName,
                })
                .ToList();
            Brand.DataSource = ctBrand;
            Brand.DisplayMember = "Name";
            Brand.ValueMember = "Id";

            var ctLoc = _context.MachineLocations
                .Select(m => new ListViewModel()
                {
                    Id = m.Id,
                    Name = m.LocationName,
                })
                .ToList();
            Location.DataSource = ctLoc;
            Location.DisplayMember = "Name";
            Location.ValueMember = "Id";


            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.MachineCode),
                HeaderText = PropertyText.Title.Machine,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            //adgv.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = nameof(MachineViewModel.CategoryName),
            //    HeaderText = PropertyString.Title.MachineCategory,
            //    ValueType = typeof(string),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            //});

            //adgv.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = nameof(MachineViewModel.TypeName),
            //    HeaderText = PropertyString.Title.MachineType,
            //    ValueType = typeof(string),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            //});

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.ModelName),
                HeaderText = PropertyText.Title.MachineModel,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.ConditionName),
                HeaderText = PropertyText.Title.Condition,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.BrandName),
                HeaderText = PropertyText.Title.Brand,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.LocationName),
                HeaderText = PropertyText.Title.Location,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.AssetString),
                HeaderText = PropertyText.Title.Assets,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    WrapMode = DataGridViewTriState.True,
                    //Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.SerialNumber),
                HeaderText = PropertyText.Title.SerialNumber,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.ConnectedString),
                HeaderText = PropertyText.Title.Connected,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.DisposalString),
                HeaderText = PropertyText.Title.Disposal,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            //adgv.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = nameof(MachineViewModel.Workstations),
            //    HeaderText = PropertyString.Title.Workstations,
            //    ValueType = typeof(string),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            //});

            SwitchEditMode(false);
            string itemName = PropertyText.Title.Machine;
            //headLabel_Machine.Text = $"{PropertyString.Title.MachineCategory} » {PropertyString.Title.MachineType}";
            CommonStyles.SetCrudButton(Machine_Create, "C", itemName);
            CommonStyles.SetCrudButton(Machine_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Machine_Delete, "D", itemName);
            CommonStyles.SetAdvancedDataGridView(adgv, true);
            CommonStyles.SetButton(btnSave);
            CommonStyles.SetTreeView(list_Catelogries);
            EditModeSwitch.ActiveColor = CommonStyles.BackColor;
            EditModeSwitch.InActiveColor = Color.DarkRed;

            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (recipient, message) =>
            {
                UserChanged();
            });

            WeakReferenceMessenger.Default.Register<NotifyMachineDataUpdated>(this, (recipient, message) =>
            {
                LoadData();

                if (_newNode != null)
                {
                    list_Catelogries.SuspendLayout();
                    list_Catelogries.SelectedNode = _newNode;
                    _newNode.EnsureVisible();
                    list_Catelogries.ResumeLayout();
                    _newNode = null;
                }

                if (!string.IsNullOrWhiteSpace(_newMachineCode))
                {
                    int rowIndex = _mdgv.FindIndex(m => m.MachineCode == _newMachineCode);
                    if (rowIndex >= 0)
                    {
                        adgv.SuspendLayout();
                        adgv.FirstDisplayedScrollingRowIndex = rowIndex;
                        adgv.CurrentCell = adgv.Rows[rowIndex].Cells[0];
                        adgv.ResumeLayout();
                    }
                    _newMachineCode = "";
                }
            });
        }

        protected override void Dispose(bool disposing)
        {
            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            if (disposing)
            {
                components?.Dispose();
                _mdgv = null;
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        private void Setup_MachinesSummary_Load(object sender, System.EventArgs e)
        {
            UserChanged();
            LoadData();

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "正在載入資料...";
                loadingDialog.Show();

                _bs.DataSource = new MachineViewModel();

                label_MachineId.Text = PropertyText.Title.Machine;
                MaincheId.DataBindings.Clear();
                //MaincheId.DataBindings.Add("Text", _bs, PropertyText.Name.MachineCode);

                label_Catelogry.Text = PropertyText.Title.MachineCategory;
                Catelogry.DataBindings.Clear();
                //Catelogry.DataBindings.Add("Text", _bs, PropertyText.Name.MachineCategory);

                label_Type.Text = PropertyText.Title.MachineType;
                Type.DataBindings.Clear();
                //Type.DataBindings.Add("Text", _bs, PropertyText.Name.MachineType);

                label_ModeName.Text = PropertyText.Title.MachineModel;
                ModelNo.DataBindings.Clear();
                //ModelNo.DataBindings.Add("Text", _bs, PropertyText.Name.MachineModel);

                label_Condition.Text = PropertyText.Title.Condition;
                Condition.DataBindings.Clear();
                //Condition.DataBindings.Add("Text", _bs, PropertyText.Name.ConditionName);

                label_Brand.Text = PropertyText.Title.Brand;
                Brand.DataBindings.Clear();
                //Brand.DataBindings.Add("Text", _bs, PropertyText.Name.BrandName);

                label_Location.Text = PropertyText.Title.Location;
                Location.DataBindings.Clear();
                //Location.DataBindings.Add("Text", _bs, PropertyText.Name.LocationName);

                label_Assets.Text = PropertyText.Title.Assets;
                Assets.DataBindings.Clear();
                //Assets.DataBindings.Add("Text", _bs, PropertyText.Name.AssetString);

                label_SerialNumber.Text = PropertyText.Title.SerialNumber;
                SerialNumber.DataBindings.Clear();
                //SerialNumber.DataBindings.Add("Text", _bs, PropertyText.Name.SerialNumber);

                label_Barcode.Text = PropertyText.Title.Barcode;
                Barcode.DataBindings.Clear();
                //Barcode.DataBindings.Add("Text", _bs, PropertyText.Name.Barcode);

                //label_Workstations.Text = PropertyString.Title.Workstations;
                //Workstations.DataBindings.Clear();
                //Workstations.DataBindings.Add("Text", _bs, PropertyString.Name.Workstations);

                label_Remark.Text = PropertyText.Title.Remark;
                Remark.DataBindings.Clear();
                //Remark.DataBindings.Add("Text", _bs, PropertyText.Name.Remark);

                //label_Connected.Text = PropertyText.Title.Connected;
                Connected.DataBindings.Clear();
                //Connected.DataBindings.Add("Checked", _bs, PropertyText.Name.Connected);

                //label_Disposal.Text = PropertyText.Title.Disposal;
                Disposal.DataBindings.Clear();
                //Disposal.DataBindings.Add("Checked", _bs, PropertyText.Name.Disposal);

                loadingDialog.Close();
            }
        }

        private void LoadData()
        {
            UpdateMachinesList();
            UpdateMachinesView();
        }

        /********************
         * Permission
         ********************/
        private void UserChanged()
        {
            bool _editPermission = _permission.HasControlAccess(
                PermissionWords.MODULE_SETUP,
                PermissionWords.PAGE_MACHINE_MANAGER,
                "*",
                PermissionWords.ACTION_EDIT);

            btnSave.Visible = _editPermission;
            EditModeSwitch.Visible = _editPermission;

            //ADGV.ContextMenuStrip = allowEdit
            //    ? adgvContextMenu
            //    : null;
        }

        /********************
         * 編輯模式
         ********************/
        private void SwitchEditMode(bool editMode)
        {
            //MaincheId.Enabled = editMode;
            //Catelogry.Enabled = editMode;
            //Type.Enabled = editMode;
            ModelNo.Enabled = editMode;
            Condition.Enabled = editMode;
            Brand.Enabled = editMode;
            Location.Enabled = editMode;

            Workstations.Enabled = editMode;
            Assets.Enabled = editMode;
            SerialNumber.Enabled = editMode;
            Barcode.Enabled = editMode;

            Remark.Enabled = editMode;
            Connected.Enabled = editMode;
            Disposal.Enabled = editMode;

            Machine_Create.Enabled = editMode;
            Machine_Edit.Enabled = editMode;
            Machine_Delete.Enabled = editMode;

            btnSave.Enabled = editMode;
        }

        private void EditModeSwitch_ValueChanged(object sender, bool value)
        {
            SwitchEditMode(value);
        }

        /********************
         * TreeView
         ********************/
        private void UpdateMachinesList()
        {
            if (_newNode != null) return;

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "正在更新資料...";
                loadingDialog.Show();

                //var mQuery = await _context.Machines
                //    .Include(m => m.MachineName)
                //    .Include(m => m.MachineName.MachineType)
                //    .Include(m => m.MachineName.MachineType.Category)
                //    .Include(m => m.Brand)
                //    .Include(m => m.Assets)
                //    .Include(m => m.Location)
                //    .Include(m => m.Condition)
                //    .AsNoTracking()
                //    .ToListAsync();

                TreeNode topNode = null;
                TreeNode parent;
                TreeNode child;

                list_Catelogries.Nodes.Clear();
                foreach (var mCat in _coreData.MachineCategories)
                {
                    parent = new TreeNode(mCat.CategoryName);
                    parent.Tag = -1;
                    list_Catelogries.Nodes.Add(parent);

                    var mTypes = _coreData.MachineTypes
                        .Where(c => c.CategoryId == mCat.Id)
                        .Select(b => new ListViewModel { Id = b.Id, Name = b.TypeName })
                        .ToList();

                    foreach (var mType in mTypes)
                    {
                        child = new TreeNode(mType.Name);
                        child.Tag = mType.Id;
                        parent.Nodes.Add(child);

                        if (topNode == null)
                            topNode = child;
                    }
                }

                //list_Catelogries.ExpandAll();
                //list_Catelogries.SelectedNode = topNode;
                //topNode.EnsureVisible();

                loadingDialog.Close();
            }
        }

        private void List_Catelogries_AfterSelect(object sender, TreeViewEventArgs e)
        {
            _thisTypeId = (int)e.Node.Tag;
            if (_thisTypeId > 0)
            {
                Machine_Create.Enabled = true;
            }
            else
            {
                Machine_Create.Enabled = false;
                Machine_Edit.Enabled = false;
                Machine_Delete.Enabled = false;
            }
            UpdateMachinesView();
        }

        private void List_Catelogries_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            _thisTypeId = (int)e.Node.Tag;
            if (e.Node.IsExpanded)
                e.Node.Collapse();
            else
                e.Node.Expand();

            UpdateMachinesView();
        }

        /********************
         * ADGV
         ********************/
        bool _prohibitUpdateAdgv = false;
        private void UpdateMachinesView()
        {
            if (_prohibitUpdateAdgv)
                return;

            _prohibitUpdateAdgv = true;
            if (_thisTypeId > 0)
            {
                _mdgv = _coreData.Machines
                    .Where(m => m.MachineName.TypeId == _thisTypeId)
                    .Select(m => new MachineViewModel
                    {
                        MachineCode = m.MachineCode,
                        CategoryName = m.CategoryName,
                        TypeName = m.TypeName,
                        ModelName = m.MachineName.ModelName,
                        ConditionId = m.ConditionId,
                        ConditionName = m.ConditionName,
                        BrandName = m.Brand.BrandName,
                        LocationName = m.Location.LocationName,
                        //Status = m.MachineName.ModelStatus != null ? m.MachineName.ModelStatus.Status : "",
                        AssetString = m.AssetString,
                        SerialNumber = m.SerialNumber,
                        Barcode = m.Barcode,
                        Connected = m.Connected,
                        ConnectedString = m.ConnectedString,
                        Disposal = m.Disposal,
                        DisposalString = m.DisposalString,
                        Remark = m.Remark,
                        Workstations = string.Join("\n", m.Workstations.Select(w => w.FullWorkstationName)),
                    })
                    .ToList();

                adgv.DataSource = _mdgv.ToDataTable();
                _bs.DataSource = _mdgv;
                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_mdgv.Count()} 筆資料"));
            }
            else
            {
                _mdgv = null;
                adgv.DataSource = null;
                _bs.DataSource = new List<MachineViewModel>();

                Machine_Create.Enabled = false;

                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"沒有資料顯示"));
            }
            _prohibitUpdateAdgv = false;
        }

        private void ADGV_SelectionChanged(object sender, System.EventArgs e)
        {
            if (adgv.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                _thisMachineCode = drv[PropertyText.Name.MachineCode].ToString();
                _thisMachine = _coreData.Machines.FirstOrDefault(m => m.MachineCode == _thisMachineCode);
                _thisMachineNameId = _thisMachine?.MachineNameId ?? -1;
                _thisTypeId = _thisMachine?.MachineName.TypeId ?? -1;
                _thisTypeIndex = adgv.CurrentCell.RowIndex;
                _thisCategoryId = _thisMachine?.CategoryId ?? -1;

                MaincheId.Text = _thisMachine.MachineCode;
                Catelogry.SelectedValue = _thisMachine.CategoryId;
                Type.SelectedValue = _thisMachine.TypeId;
                ModelNo.SelectedValue = _thisMachine.MachineNameId;
                Condition.Text = _thisMachine.ConditionName;
                Brand.Text = _thisMachine.BrandName;
                Location.Text = _thisMachine.LocationName;
                Assets.Text = _thisMachine.AssetString;
                SerialNumber.Text = _thisMachine.SerialNumber;
                Barcode.Text = _thisMachine.Barcode;
                Remark.Text = _thisMachine.Remark;
                Connected.Checked = _thisMachine.Connected;
                Disposal.Checked = _thisMachine.Disposal;

                SetMachineTypeList();
                SetMachineModelNo();

                int index = _mdgv?.FindIndex(x => x.MachineCode == _thisMachineCode) ?? -1;
                _bs.Position = index;
                if (index >= 0)
                {
                    Machine_Edit.Enabled = true;
                    Machine_Delete.Enabled = true;
                    return;
                }
            }
            Machine_Edit.Enabled = false;
            Machine_Delete.Enabled = false;
        }

        private void SetMachineTypeList()
        {
            var ctType = _context.MachineTypes
                .Where(mt => mt.CategoryId == _thisCategoryId)
                .OrderBy(mt => mt.OrderNo)
                .Select(mt => new ListViewModel()
                {
                    Id = mt.Id,
                    Name = mt.TypeName,
                })
                .ToList();
            Type.DataSource = ctType;
            Type.DisplayMember = "Name";
            Type.ValueMember = "Id";

            if (!ctType.Any(ct => ct.Id == _thisTypeId))
                Type.SelectedIndex = -1;
        }

        private void SetMachineModelNo()
        {
            var ctModelNo = _context.MachineNames
                .Where(mn => mn.TypeId == _thisTypeId)
                .OrderBy(mn => mn.OrderNo)
                .Select(mn => new ListViewModel()
                {
                    Id = mn.Id,
                    Name = mn.ModelName,
                })
                .ToList();
            ModelNo.DataSource = ctModelNo;
            ModelNo.DisplayMember = "Name";
            ModelNo.ValueMember = "Id";

            if (!ctModelNo.Any(mn => mn.Id == _thisMachineNameId))
                ModelNo.SelectedIndex = -1;
        }

        /********************
         * BCRUD Buttons
         ********************/
        private async void Machine_Create_Click(object sender, System.EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.Machine}編號";
            string caption = $"新{PropertyText.Title.Machine}編號";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Machine}編號不可為空白！"),
                input => input.Length <= 10 ? (true, "") : (false, $"{PropertyText.Title.Machine}編號必須小於等於 10 個字元！"),
                input => _coreData.Machines.Any(m => m.CategoryName == input) ? (false, $"{PropertyText.Title.Machine}編號已存在！") : (true, "")
                );
            bool hasDash = _thisMachineCode.Contains("-");
            string header = Regex.Replace(_thisMachineCode.Split('-')[0], @"\d+$", "");
            int maxNo = _mdgv
                .Select(s =>
                {
                    if (string.IsNullOrEmpty(s.MachineCode)) return 0;
                    var match = Regex.Match(s.MachineCode, @"\d+"); // 找出第一串數字
                    return match.Success ? int.Parse(match.Value) : 0;
                })
                .DefaultIfEmpty(0)
                .Max();
            string appendId = string.Concat(header, hasDash ? "-" : "", (maxNo + 1).ToString());

            using (var editor = _scope.Resolve<MachineEdit>())
            {
                editor.Title = $"請輸入新{PropertyText.Title.Machine}資料";
                editor.CrudType = CrudType.Add;
                editor.Machine = new MachineViewModel()
                {
                    MachineCode = appendId,
                    CategoryId = _thisCategoryId,
                    TypeId = _thisTypeId,
                    MachineNameId = _thisMachineNameId,
                    ConditionId = 1,
                    BrandId = 1,
                    LocationId = 1,
                    AssetString = "",
                    SerialNumber = "",
                    Barcode = "",
                    Connected = false,
                    Disposal = false,
                    Remark = "",
                };
                if (MyFormEx.ShowDialogWithMask(editor) == DialogResult.OK)
                {
                    try
                    {
                        var category = await _context.MachineCategories
                            .FirstOrDefaultAsync(c => c.CategoryName == Catelogry.Text);
                        if (category == null)
                        {
                            category = new MachineCategory
                            {
                                CategoryName = Catelogry.Text,
                                OrderNo = _context.MachineCategories.Any() ? _context.MachineCategories.Max(c => c.OrderNo) + 1 : 1
                            };
                            _context.MachineCategories.Add(category);
                            await _context.SaveChangesAsync();
                        }

                        // Check if the type exists, if not, create it
                        var machineType = await _context.MachineTypes
                            .FirstOrDefaultAsync(t => t.TypeName == Type.Text && t.CategoryId == category.Id);
                        if (machineType == null)
                        {
                            machineType = new MachineType
                            {
                                TypeName = Type.Text,
                                CategoryId = category.Id,
                                OrderNo = _context.MachineTypes.Any() ? _context.MachineTypes.Max(t => t.OrderNo) + 1 : 1
                            };
                            _context.MachineTypes.Add(machineType);
                            await _context.SaveChangesAsync();
                        }

                        // Check if the machine name exists, if not, create it
                        var machineName = await _context.MachineNames
                            .FirstOrDefaultAsync(mn => mn.ModelName == ModelNo.Text && mn.TypeId == machineType.Id);
                        if (machineName == null)
                        {
                            machineName = new MachineName
                            {
                                ModelName = ModelNo.Text,
                                TypeId = machineType.Id,
                                OrderNo = _context.MachineNames.Any() ? _context.MachineNames.Max(mn => mn.OrderNo) + 1 : 1
                            };
                            _context.MachineNames.Add(machineName);
                            await _context.SaveChangesAsync();
                        }

                        var machine = new Machine();
                        machine.MachineCode = editor.Machine.MachineCode;
                        machine.MachineNameId = editor.Machine.MachineNameId;
                        machine.ConditionId = editor.Machine.ConditionId;
                        machine.BrandId = editor.Machine.BrandId;
                        machine.LocationId = editor.Machine.LocationId;
                        machine.Connected = editor.Machine.Connected;
                        machine.Disposal = editor.Machine.Disposal;
                        machine.AssetString = editor.Machine.AssetString;
                        machine.SerialNumber = editor.Machine.SerialNumber;
                        machine.Barcode = editor.Machine.Barcode;
                        machine.Remark = editor.Machine.Remark;

                        _context.Machines.Add(machine);
                        await _context.SaveChangesAsync();
                        _newMachineCode = machine.MachineCode;
                        _cacheManager.RequestMachineUpdate();

                        MessageBox.Show($"已增加新{PropertyText.Title.Machine}: {editor.Machine.MachineCode}",
                                        $"新增成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增設備失敗: {nameof(Setup_MachinesSummary)} -> {nameof(Machine_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, $"新增失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Machine_Edit_Click(object sender, System.EventArgs e)
        {
            using (var editor = _scope.Resolve<MachineEdit>())
            {
                var machine = await _context.Machines
                    .Include(m => m.MachineName.MachineType)
                    .FirstOrDefaultAsync(m => m.MachineCode == _thisMachineCode);

                editor.Title = $"修改此{PropertyText.Title.Machine}資料";
                editor.CrudType = CrudType.Edit;
                editor.Machine = new MachineViewModel()
                {
                    MachineCode = machine.MachineCode,
                    CategoryId = machine.CategoryId,
                    TypeId = machine.TypeId,
                    MachineNameId = machine.MachineNameId,
                    ConditionId = machine.ConditionId,
                    BrandId = machine.BrandId ?? -1,
                    LocationId = machine.LocationId ?? -1,
                    AssetString = machine.AssetString,
                    SerialNumber = machine.SerialNumber,
                    Barcode = machine.Barcode,
                    Connected = machine.Connected,
                    Disposal = machine.Disposal,
                    Remark = machine.Remark,
                };
                if (editor.ShowDialog() == DialogResult.OK)
                {
                    machine = await _context.Machines
                        .Include(m => m.MachineName)
                        .FirstOrDefaultAsync(m => m.MachineCode == editor.Machine.MachineCode);

                    machine.MachineCode = editor.Machine.MachineCode;
                    machine.ConditionId = editor.Machine.ConditionId;
                    machine.BrandId = editor.Machine.BrandId;
                    machine.LocationId = editor.Machine.LocationId;
                    machine.Connected = editor.Machine.Connected;
                    machine.Disposal = editor.Machine.Disposal;
                    machine.AssetString = editor.Machine.AssetString;
                    machine.SerialNumber = editor.Machine.SerialNumber;
                    machine.Barcode = editor.Machine.Barcode;
                    machine.Remark = editor.Machine.Remark;

                    machine.MachineNameId = editor.Machine.MachineNameId;
                    var machineName = await _context.MachineNames
                        .FirstOrDefaultAsync(mn => mn.Id == editor.Machine.MachineNameId);
                    if (machineName != null)
                    {
                        machine.MachineName.TypeId = editor.Machine.TypeId;
                        var machineType = await _context.MachineTypes
                            .FirstOrDefaultAsync(t => t.Id == editor.Machine.TypeId);
                        if (machineType != null)
                            machineType.CategoryId = editor.Machine.CategoryId;
                    }

                    await _context.SaveChangesAsync();
                    _newMachineCode = machine.MachineCode;
                    _cacheManager.RequestMachineUpdate();

                    MessageBox.Show($"已更新{PropertyText.Title.Machine}: {editor.Machine.MachineCode}",
                                    $"更新成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void Machine_Delete_Click(object sender, System.EventArgs e)
        {
            if (_thisMachine != null)
            {
                if (UIMessageBox.ShowAsk2($"確定要刪除 {_thisMachine.MachineCode} » {_thisMachine.ModelName} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetmachine = _context.Machines.FirstOrDefault(m => m.Id == _thisMachine.Id);
                    if (targetmachine != null)
                    {
                        _context.Machines.Remove(targetmachine);
                        await _context.SaveChangesAsync();
                        _cacheManager.RequestMachineUpdate();

                        MessageBox.Show($"{_thisMachine.MachineCode} » {_thisMachine.ModelName} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            var machine = _context.Machines
                .FirstOrDefault(m => m.MachineCode == _thisMachineCode);

            machine.MachineCode = MaincheId.Text;
            machine.MachineNameId = (int)ModelNo.SelectedValue;
            //machine.MachineName.TypeId = (int?)Type.SelectedValue;
            //machine.MachineName.MachineType.CategoryId = (int)Catelogry.SelectedValue;
            machine.ConditionId = _context.MachineConditions.FirstOrDefault(mc => mc.ConditionName == Condition.Text)?.Id ?? 0;
            machine.BrandId = _context.MachineBrands.FirstOrDefault(mb => mb.BrandName == Brand.Text)?.Id ?? null;
            machine.LocationId = _context.MachineLocations.FirstOrDefault(ml => ml.LocationName == Location.Text)?.Id ?? null;
            machine.AssetString = Assets.Text;
            machine.SerialNumber = SerialNumber.Text;
            machine.Barcode = Barcode.Text;
            machine.Remark = Remark.Text;
            machine.Connected = Connected.Checked;
            machine.Disposal = Disposal.Checked;

            try
            {
                await _context.SaveChangesAsync();
                if (_thisTypeId > 0)
                    _newNode = list_Catelogries.Nodes
                        .Cast<TreeNode>()
                        .FirstOrDefault(n => (int)n.Tag == _thisCategoryId)?
                        .Nodes
                        .Cast<TreeNode>()
                        .FirstOrDefault(n => (int)n.Tag == _thisTypeId);
                _newMachineCode = _thisMachineCode;
                _cacheManager.RequestMachineUpdate();
            }
            catch (Exception ex)
            {
                string errMsg = $"資料儲存失敗: {nameof(Setup_MachinesSummary)} -> {nameof(btnSave_Click)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, $"儲存失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
