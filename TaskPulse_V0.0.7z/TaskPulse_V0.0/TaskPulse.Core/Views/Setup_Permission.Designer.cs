﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Permission
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("工具委託");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("專案管理");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("維護工單");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("設定");
            this.NM_Permission = new Sunny.UI.UINavMenu();
            this.TC_Permission = new Sunny.UI.UITabControl();
            this.TP_ToolQuest = new System.Windows.Forms.TabPage();
            this.TP_MechaTrack = new System.Windows.Forms.TabPage();
            this.TP_MaintiFlow = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.CBe_Cancel = new Sunny.UI.UICheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CBr_MaintiFlowSummy = new Sunny.UI.UICheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CBe_MaintiFlowSummy = new Sunny.UI.UICheckBox();
            this.CBe_Create = new Sunny.UI.UICheckBox();
            this.CBe_Accept = new Sunny.UI.UICheckBox();
            this.CBe_Maintant = new Sunny.UI.UICheckBox();
            this.CBe_Confirm = new Sunny.UI.UICheckBox();
            this.TP_Setup = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.CBr_MachineManager = new Sunny.UI.UICheckBox();
            this.CBr_EmployeeManager = new Sunny.UI.UICheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.CBe_MachineManager = new Sunny.UI.UICheckBox();
            this.CBe_EmployeeManager = new Sunny.UI.UICheckBox();
            this.uiLine1 = new Sunny.UI.UILine();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Save = new Sunny.UI.UISymbolButton();
            this.TC_Permission.SuspendLayout();
            this.TP_MaintiFlow.SuspendLayout();
            this.TP_Setup.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // NM_Permission
            // 
            this.NM_Permission.BackColor = System.Drawing.SystemColors.Control;
            this.NM_Permission.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NM_Permission.Dock = System.Windows.Forms.DockStyle.Left;
            this.NM_Permission.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.NM_Permission.FillColor = System.Drawing.Color.Transparent;
            this.NM_Permission.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.NM_Permission.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.NM_Permission.FullRowSelect = true;
            this.NM_Permission.HotTracking = true;
            this.NM_Permission.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.NM_Permission.ItemHeight = 40;
            this.NM_Permission.Location = new System.Drawing.Point(4, 0);
            this.NM_Permission.MenuStyle = Sunny.UI.UIMenuStyle.Custom;
            this.NM_Permission.Name = "NM_Permission";
            treeNode1.Name = "NI_ToolQuest";
            treeNode1.Text = "工具委託";
            treeNode2.Name = "NI_MechaTrack";
            treeNode2.Text = "專案管理";
            treeNode3.Name = "NI_MaintiFlow";
            treeNode3.Text = "維護工單";
            treeNode4.Checked = true;
            treeNode4.Name = "NI_Setup";
            treeNode4.Text = "設定";
            this.NM_Permission.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4});
            this.NM_Permission.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.NM_Permission.ScrollBarHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.NM_Permission.ScrollBarPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.NM_Permission.ScrollFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.NM_Permission.SecondBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            this.NM_Permission.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.NM_Permission.SelectedColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.NM_Permission.SelectedForeColor = System.Drawing.SystemColors.MenuText;
            this.NM_Permission.ShowLines = false;
            this.NM_Permission.ShowPlusMinus = false;
            this.NM_Permission.ShowRootLines = false;
            this.NM_Permission.Size = new System.Drawing.Size(128, 200);
            this.NM_Permission.TabControl = this.TC_Permission;
            this.NM_Permission.TabIndex = 7;
            this.NM_Permission.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NM_Permission.MenuItemClick += new Sunny.UI.UINavMenu.OnMenuItemClick(this.NM_Permission_MenuItemClick);
            this.NM_Permission.NodeRightSymbolClick += new Sunny.UI.UINavMenu.OnNodeRightSymbolClick(this.NM_Permission_NodeRightSymbolClick);
            this.NM_Permission.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.NM_Permission_AfterSelect);
            // 
            // TC_Permission
            // 
            this.TC_Permission.Controls.Add(this.TP_ToolQuest);
            this.TC_Permission.Controls.Add(this.TP_MechaTrack);
            this.TC_Permission.Controls.Add(this.TP_MaintiFlow);
            this.TC_Permission.Controls.Add(this.TP_Setup);
            this.TC_Permission.Dock = System.Windows.Forms.DockStyle.Left;
            this.TC_Permission.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.TC_Permission.FillColor = System.Drawing.SystemColors.Control;
            this.TC_Permission.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.TC_Permission.ItemSize = new System.Drawing.Size(0, 1);
            this.TC_Permission.Location = new System.Drawing.Point(132, 0);
            this.TC_Permission.MainPage = "";
            this.TC_Permission.MenuStyle = Sunny.UI.UIMenuStyle.Custom;
            this.TC_Permission.Name = "TC_Permission";
            this.TC_Permission.SelectedIndex = 0;
            this.TC_Permission.Size = new System.Drawing.Size(232, 200);
            this.TC_Permission.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.TC_Permission.TabBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.TC_Permission.TabIndex = 8;
            this.TC_Permission.TabVisible = false;
            this.TC_Permission.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // TP_ToolQuest
            // 
            this.TP_ToolQuest.BackColor = System.Drawing.SystemColors.Control;
            this.TP_ToolQuest.Location = new System.Drawing.Point(0, 0);
            this.TP_ToolQuest.Name = "TP_ToolQuest";
            this.TP_ToolQuest.Size = new System.Drawing.Size(232, 200);
            this.TP_ToolQuest.TabIndex = 0;
            this.TP_ToolQuest.Text = "工具委託";
            // 
            // TP_MechaTrack
            // 
            this.TP_MechaTrack.BackColor = System.Drawing.SystemColors.Control;
            this.TP_MechaTrack.Location = new System.Drawing.Point(0, 40);
            this.TP_MechaTrack.Name = "TP_MechaTrack";
            this.TP_MechaTrack.Size = new System.Drawing.Size(200, 60);
            this.TP_MechaTrack.TabIndex = 1;
            this.TP_MechaTrack.Text = "專案管理";
            // 
            // TP_MaintiFlow
            // 
            this.TP_MaintiFlow.BackColor = System.Drawing.SystemColors.Control;
            this.TP_MaintiFlow.Controls.Add(this.label3);
            this.TP_MaintiFlow.Controls.Add(this.CBe_Cancel);
            this.TP_MaintiFlow.Controls.Add(this.label6);
            this.TP_MaintiFlow.Controls.Add(this.label5);
            this.TP_MaintiFlow.Controls.Add(this.label7);
            this.TP_MaintiFlow.Controls.Add(this.label9);
            this.TP_MaintiFlow.Controls.Add(this.label10);
            this.TP_MaintiFlow.Controls.Add(this.label8);
            this.TP_MaintiFlow.Controls.Add(this.label1);
            this.TP_MaintiFlow.Controls.Add(this.CBr_MaintiFlowSummy);
            this.TP_MaintiFlow.Controls.Add(this.label2);
            this.TP_MaintiFlow.Controls.Add(this.CBe_MaintiFlowSummy);
            this.TP_MaintiFlow.Controls.Add(this.CBe_Create);
            this.TP_MaintiFlow.Controls.Add(this.CBe_Accept);
            this.TP_MaintiFlow.Controls.Add(this.CBe_Maintant);
            this.TP_MaintiFlow.Controls.Add(this.CBe_Confirm);
            this.TP_MaintiFlow.Location = new System.Drawing.Point(0, 40);
            this.TP_MaintiFlow.Name = "TP_MaintiFlow";
            this.TP_MaintiFlow.Size = new System.Drawing.Size(200, 60);
            this.TP_MaintiFlow.TabIndex = 2;
            this.TP_MaintiFlow.Text = "維護工單";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(10, 90);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 25);
            this.label3.TabIndex = 56;
            this.label3.Text = "取消工單";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CBe_Cancel
            // 
            this.CBe_Cancel.CheckBoxSize = 18;
            this.CBe_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Cancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Cancel.Location = new System.Drawing.Point(183, 90);
            this.CBe_Cancel.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Cancel.Name = "CBe_Cancel";
            this.CBe_Cancel.Size = new System.Drawing.Size(29, 25);
            this.CBe_Cancel.TabIndex = 54;
            this.CBe_Cancel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(10, 10);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 25);
            this.label6.TabIndex = 48;
            this.label6.Text = "　";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(10, 40);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 25);
            this.label5.TabIndex = 47;
            this.label5.Text = "維護總表";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(10, 65);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 25);
            this.label7.TabIndex = 50;
            this.label7.Text = "建立工單";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(10, 115);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 25);
            this.label9.TabIndex = 52;
            this.label9.Text = "接單";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(10, 140);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 25);
            this.label10.TabIndex = 53;
            this.label10.Text = "維護作業";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(10, 165);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 25);
            this.label8.TabIndex = 51;
            this.label8.Text = "確認作業";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(130, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 25);
            this.label1.TabIndex = 43;
            this.label1.Text = "檢視";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // CBr_MaintiFlowSummy
            // 
            this.CBr_MaintiFlowSummy.CheckBoxSize = 18;
            this.CBr_MaintiFlowSummy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_MaintiFlowSummy.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_MaintiFlowSummy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_MaintiFlowSummy.Location = new System.Drawing.Point(138, 40);
            this.CBr_MaintiFlowSummy.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_MaintiFlowSummy.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_MaintiFlowSummy.Name = "CBr_MaintiFlowSummy";
            this.CBr_MaintiFlowSummy.Size = new System.Drawing.Size(29, 25);
            this.CBr_MaintiFlowSummy.TabIndex = 42;
            this.CBr_MaintiFlowSummy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(175, 10);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 25);
            this.label2.TabIndex = 44;
            this.label2.Text = "編輯";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // CBe_MaintiFlowSummy
            // 
            this.CBe_MaintiFlowSummy.CheckBoxSize = 18;
            this.CBe_MaintiFlowSummy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_MaintiFlowSummy.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_MaintiFlowSummy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_MaintiFlowSummy.Location = new System.Drawing.Point(183, 40);
            this.CBe_MaintiFlowSummy.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_MaintiFlowSummy.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_MaintiFlowSummy.Name = "CBe_MaintiFlowSummy";
            this.CBe_MaintiFlowSummy.Size = new System.Drawing.Size(29, 25);
            this.CBe_MaintiFlowSummy.TabIndex = 37;
            this.CBe_MaintiFlowSummy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_Create
            // 
            this.CBe_Create.CheckBoxSize = 18;
            this.CBe_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Create.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Create.Location = new System.Drawing.Point(183, 65);
            this.CBe_Create.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Create.Name = "CBe_Create";
            this.CBe_Create.Size = new System.Drawing.Size(29, 25);
            this.CBe_Create.TabIndex = 33;
            this.CBe_Create.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_Accept
            // 
            this.CBe_Accept.CheckBoxSize = 18;
            this.CBe_Accept.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Accept.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Accept.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Accept.Location = new System.Drawing.Point(183, 115);
            this.CBe_Accept.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Accept.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Accept.Name = "CBe_Accept";
            this.CBe_Accept.Size = new System.Drawing.Size(29, 25);
            this.CBe_Accept.TabIndex = 34;
            this.CBe_Accept.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_Maintant
            // 
            this.CBe_Maintant.CheckBoxSize = 18;
            this.CBe_Maintant.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Maintant.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Maintant.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Maintant.Location = new System.Drawing.Point(183, 140);
            this.CBe_Maintant.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Maintant.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Maintant.Name = "CBe_Maintant";
            this.CBe_Maintant.Size = new System.Drawing.Size(29, 25);
            this.CBe_Maintant.TabIndex = 35;
            this.CBe_Maintant.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_Confirm
            // 
            this.CBe_Confirm.CheckBoxSize = 18;
            this.CBe_Confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Confirm.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Confirm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Confirm.Location = new System.Drawing.Point(183, 165);
            this.CBe_Confirm.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Confirm.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Confirm.Name = "CBe_Confirm";
            this.CBe_Confirm.Size = new System.Drawing.Size(29, 25);
            this.CBe_Confirm.TabIndex = 36;
            this.CBe_Confirm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TP_Setup
            // 
            this.TP_Setup.BackColor = System.Drawing.SystemColors.Control;
            this.TP_Setup.Controls.Add(this.label11);
            this.TP_Setup.Controls.Add(this.label12);
            this.TP_Setup.Controls.Add(this.label13);
            this.TP_Setup.Controls.Add(this.label14);
            this.TP_Setup.Controls.Add(this.CBr_MachineManager);
            this.TP_Setup.Controls.Add(this.CBr_EmployeeManager);
            this.TP_Setup.Controls.Add(this.label15);
            this.TP_Setup.Controls.Add(this.CBe_MachineManager);
            this.TP_Setup.Controls.Add(this.CBe_EmployeeManager);
            this.TP_Setup.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.TP_Setup.Location = new System.Drawing.Point(0, 40);
            this.TP_Setup.Name = "TP_Setup";
            this.TP_Setup.Size = new System.Drawing.Size(200, 60);
            this.TP_Setup.TabIndex = 3;
            this.TP_Setup.Text = "設定";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(10, 10);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 25);
            this.label11.TabIndex = 51;
            this.label11.Text = "　";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(10, 40);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 25);
            this.label12.TabIndex = 50;
            this.label12.Text = "機台管理";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(10, 65);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 25);
            this.label13.TabIndex = 53;
            this.label13.Text = "人員管理";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(130, 10);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 25);
            this.label14.TabIndex = 46;
            this.label14.Text = "檢視";
            this.label14.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // CBr_MachineManager
            // 
            this.CBr_MachineManager.CheckBoxSize = 18;
            this.CBr_MachineManager.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_MachineManager.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_MachineManager.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_MachineManager.Location = new System.Drawing.Point(138, 40);
            this.CBr_MachineManager.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_MachineManager.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_MachineManager.Name = "CBr_MachineManager";
            this.CBr_MachineManager.Size = new System.Drawing.Size(29, 25);
            this.CBr_MachineManager.TabIndex = 45;
            this.CBr_MachineManager.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBr_EmployeeManager
            // 
            this.CBr_EmployeeManager.CheckBoxSize = 18;
            this.CBr_EmployeeManager.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_EmployeeManager.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_EmployeeManager.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_EmployeeManager.Location = new System.Drawing.Point(138, 65);
            this.CBr_EmployeeManager.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_EmployeeManager.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_EmployeeManager.Name = "CBr_EmployeeManager";
            this.CBr_EmployeeManager.Size = new System.Drawing.Size(29, 25);
            this.CBr_EmployeeManager.TabIndex = 44;
            this.CBr_EmployeeManager.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(175, 10);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 25);
            this.label15.TabIndex = 47;
            this.label15.Text = "編輯";
            this.label15.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // CBe_MachineManager
            // 
            this.CBe_MachineManager.CheckBoxSize = 18;
            this.CBe_MachineManager.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_MachineManager.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_MachineManager.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_MachineManager.Location = new System.Drawing.Point(183, 40);
            this.CBe_MachineManager.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_MachineManager.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_MachineManager.Name = "CBe_MachineManager";
            this.CBe_MachineManager.Size = new System.Drawing.Size(29, 25);
            this.CBe_MachineManager.TabIndex = 43;
            this.CBe_MachineManager.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_EmployeeManager
            // 
            this.CBe_EmployeeManager.CheckBoxSize = 18;
            this.CBe_EmployeeManager.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_EmployeeManager.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_EmployeeManager.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_EmployeeManager.Location = new System.Drawing.Point(183, 65);
            this.CBe_EmployeeManager.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_EmployeeManager.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_EmployeeManager.Name = "CBe_EmployeeManager";
            this.CBe_EmployeeManager.Size = new System.Drawing.Size(29, 25);
            this.CBe_EmployeeManager.TabIndex = 42;
            this.CBe_EmployeeManager.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiLine1.Dock = System.Windows.Forms.DockStyle.Left;
            this.uiLine1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.LineSize = 2;
            this.uiLine1.Location = new System.Drawing.Point(0, 0);
            this.uiLine1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.RectSize = 2;
            this.uiLine1.Size = new System.Drawing.Size(4, 200);
            this.uiLine1.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btn_Save);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(364, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(150, 200);
            this.panel1.TabIndex = 10;
            // 
            // btn_Save
            // 
            this.btn_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Save.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btn_Save.Location = new System.Drawing.Point(10, 120);
            this.btn_Save.MinimumSize = new System.Drawing.Size(1, 1);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Radius = 10;
            this.btn_Save.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btn_Save.Size = new System.Drawing.Size(140, 40);
            this.btn_Save.Symbol = 61639;
            this.btn_Save.TabIndex = 93;
            this.btn_Save.Text = "儲存權限資料";
            this.btn_Save.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // Setup_Permission
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TC_Permission);
            this.Controls.Add(this.NM_Permission);
            this.Controls.Add(this.uiLine1);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Setup_Permission";
            this.Size = new System.Drawing.Size(530, 200);
            this.TC_Permission.ResumeLayout(false);
            this.TP_MaintiFlow.ResumeLayout(false);
            this.TP_Setup.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UINavMenu NM_Permission;
        private Sunny.UI.UITabControl TC_Permission;
        private System.Windows.Forms.TabPage TP_ToolQuest;
        private System.Windows.Forms.TabPage TP_MechaTrack;
        private System.Windows.Forms.TabPage TP_MaintiFlow;
        private System.Windows.Forms.TabPage TP_Setup;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private Sunny.UI.UICheckBox CBr_MaintiFlowSummy;
        private System.Windows.Forms.Label label2;
        private Sunny.UI.UICheckBox CBe_MaintiFlowSummy;
        private Sunny.UI.UICheckBox CBe_Create;
        private Sunny.UI.UICheckBox CBe_Accept;
        private Sunny.UI.UICheckBox CBe_Maintant;
        private Sunny.UI.UICheckBox CBe_Confirm;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private Sunny.UI.UICheckBox CBr_MachineManager;
        private Sunny.UI.UICheckBox CBr_EmployeeManager;
        private System.Windows.Forms.Label label15;
        private Sunny.UI.UICheckBox CBe_MachineManager;
        private Sunny.UI.UICheckBox CBe_EmployeeManager;
        private Sunny.UI.UILine uiLine1;
        private System.Windows.Forms.Label label3;
        private Sunny.UI.UICheckBox CBe_Cancel;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton btn_Save;
    }
}
