﻿using Calin.TaskPulse.Core.ADGV;

namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_MachinesSummary
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.list_Catelogries = new Sunny.UI.UITreeView();
            this.detailPanel = new System.Windows.Forms.Panel();
            this.ModelNo = new Sunny.UI.UIComboBox();
            this.Type = new Sunny.UI.UIComboBox();
            this.Catelogry = new Sunny.UI.UIComboBox();
            this.btnSave = new Sunny.UI.UISymbolButton();
            this.EditModeSwitch = new Sunny.UI.UISwitch();
            this.label_Workstations = new Sunny.UI.UILabel();
            this.Workstations = new Sunny.UI.UITextBox();
            this.label_ModeName = new Sunny.UI.UILabel();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.Machine_Create = new Sunny.UI.UISymbolButton();
            this.Machine_Edit = new Sunny.UI.UISymbolButton();
            this.Machine_Delete = new Sunny.UI.UISymbolButton();
            this.label_Remark = new Sunny.UI.UILabel();
            this.Remark = new Sunny.UI.UIRichTextBox();
            this.Assets = new Sunny.UI.UIRichTextBox();
            this.label_SerialNumber = new Sunny.UI.UILabel();
            this.label_Barcode = new Sunny.UI.UILabel();
            this.SerialNumber = new Sunny.UI.UITextBox();
            this.label_Assets = new Sunny.UI.UILabel();
            this.Barcode = new Sunny.UI.UITextBox();
            this.label_Location = new Sunny.UI.UILabel();
            this.label_Brand = new Sunny.UI.UILabel();
            this.label_Condition = new Sunny.UI.UILabel();
            this.label_Type = new Sunny.UI.UILabel();
            this.label_Catelogry = new Sunny.UI.UILabel();
            this.label_MachineId = new Sunny.UI.UILabel();
            this.MaincheId = new Sunny.UI.UITextBox();
            this.Condition = new Sunny.UI.UIComboBox();
            this.Brand = new Sunny.UI.UIComboBox();
            this.Location = new Sunny.UI.UIComboBox();
            this.Connected = new Sunny.UI.UICheckBox();
            this.Disposal = new Sunny.UI.UICheckBox();
            this.adgv = new Calin.TaskPulse.Core.ADGV.AdvancedDataGridView();
            this.TLP.SuspendLayout();
            this.detailPanel.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).BeginInit();
            this.SuspendLayout();
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 2;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.list_Catelogries, 0, 0);
            this.TLP.Controls.Add(this.detailPanel, 1, 1);
            this.TLP.Controls.Add(this.adgv, 1, 0);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 2;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 320F));
            this.TLP.Size = new System.Drawing.Size(1154, 675);
            this.TLP.TabIndex = 0;
            // 
            // list_Catelogries
            // 
            this.list_Catelogries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_Catelogries.FillColor = System.Drawing.Color.White;
            this.list_Catelogries.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.list_Catelogries.Location = new System.Drawing.Point(4, 2);
            this.list_Catelogries.Margin = new System.Windows.Forms.Padding(4, 2, 4, 3);
            this.list_Catelogries.MinimumSize = new System.Drawing.Size(1, 1);
            this.list_Catelogries.Name = "list_Catelogries";
            this.TLP.SetRowSpan(this.list_Catelogries, 2);
            this.list_Catelogries.ScrollBarStyleInherited = false;
            this.list_Catelogries.ShowText = false;
            this.list_Catelogries.Size = new System.Drawing.Size(217, 670);
            this.list_Catelogries.TabIndex = 9;
            this.list_Catelogries.Text = "uiTreeView1";
            this.list_Catelogries.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.list_Catelogries.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.List_Catelogries_AfterSelect);
            this.list_Catelogries.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.List_Catelogries_NodeMouseClick);
            // 
            // detailPanel
            // 
            this.detailPanel.Controls.Add(this.Disposal);
            this.detailPanel.Controls.Add(this.Connected);
            this.detailPanel.Controls.Add(this.Location);
            this.detailPanel.Controls.Add(this.Brand);
            this.detailPanel.Controls.Add(this.Condition);
            this.detailPanel.Controls.Add(this.ModelNo);
            this.detailPanel.Controls.Add(this.Type);
            this.detailPanel.Controls.Add(this.Catelogry);
            this.detailPanel.Controls.Add(this.btnSave);
            this.detailPanel.Controls.Add(this.EditModeSwitch);
            this.detailPanel.Controls.Add(this.label_Workstations);
            this.detailPanel.Controls.Add(this.Workstations);
            this.detailPanel.Controls.Add(this.label_ModeName);
            this.detailPanel.Controls.Add(this.flowLayoutPanel4);
            this.detailPanel.Controls.Add(this.label_Remark);
            this.detailPanel.Controls.Add(this.Remark);
            this.detailPanel.Controls.Add(this.Assets);
            this.detailPanel.Controls.Add(this.label_SerialNumber);
            this.detailPanel.Controls.Add(this.label_Barcode);
            this.detailPanel.Controls.Add(this.SerialNumber);
            this.detailPanel.Controls.Add(this.label_Assets);
            this.detailPanel.Controls.Add(this.Barcode);
            this.detailPanel.Controls.Add(this.label_Location);
            this.detailPanel.Controls.Add(this.label_Brand);
            this.detailPanel.Controls.Add(this.label_Condition);
            this.detailPanel.Controls.Add(this.label_Type);
            this.detailPanel.Controls.Add(this.label_Catelogry);
            this.detailPanel.Controls.Add(this.label_MachineId);
            this.detailPanel.Controls.Add(this.MaincheId);
            this.detailPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.detailPanel.Location = new System.Drawing.Point(228, 358);
            this.detailPanel.Name = "detailPanel";
            this.detailPanel.Size = new System.Drawing.Size(923, 314);
            this.detailPanel.TabIndex = 11;
            // 
            // ModelNo
            // 
            this.ModelNo.DataSource = null;
            this.ModelNo.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.ModelNo.Enabled = false;
            this.ModelNo.FillColor = System.Drawing.Color.White;
            this.ModelNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.ModelNo.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.ModelNo.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.ModelNo.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.ModelNo.Location = new System.Drawing.Point(103, 127);
            this.ModelNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ModelNo.MinimumSize = new System.Drawing.Size(63, 0);
            this.ModelNo.Name = "ModelNo";
            this.ModelNo.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.ModelNo.Size = new System.Drawing.Size(201, 29);
            this.ModelNo.SymbolSize = 24;
            this.ModelNo.TabIndex = 104;
            this.ModelNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ModelNo.Watermark = "";
            // 
            // Type
            // 
            this.Type.DataSource = null;
            this.Type.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Type.Enabled = false;
            this.Type.FillColor = System.Drawing.Color.White;
            this.Type.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Type.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Type.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Type.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Type.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Type.Location = new System.Drawing.Point(103, 88);
            this.Type.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Type.MinimumSize = new System.Drawing.Size(63, 0);
            this.Type.Name = "Type";
            this.Type.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Type.Size = new System.Drawing.Size(201, 29);
            this.Type.SymbolSize = 24;
            this.Type.TabIndex = 104;
            this.Type.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Type.Watermark = "";
            // 
            // Catelogry
            // 
            this.Catelogry.DataSource = null;
            this.Catelogry.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Catelogry.Enabled = false;
            this.Catelogry.FillColor = System.Drawing.Color.White;
            this.Catelogry.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Catelogry.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Catelogry.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Catelogry.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Catelogry.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Catelogry.Location = new System.Drawing.Point(102, 49);
            this.Catelogry.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Catelogry.MinimumSize = new System.Drawing.Size(63, 0);
            this.Catelogry.Name = "Catelogry";
            this.Catelogry.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Catelogry.Size = new System.Drawing.Size(201, 29);
            this.Catelogry.SymbolSize = 24;
            this.Catelogry.TabIndex = 103;
            this.Catelogry.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Catelogry.Watermark = "";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnSave.Location = new System.Drawing.Point(654, 268);
            this.btnSave.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Radius = 10;
            this.btnSave.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnSave.Size = new System.Drawing.Size(110, 35);
            this.btnSave.Symbol = 61639;
            this.btnSave.TabIndex = 102;
            this.btnSave.Text = "儲存";
            this.btnSave.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // EditModeSwitch
            // 
            this.EditModeSwitch.ActiveText = "編輯";
            this.EditModeSwitch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.EditModeSwitch.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.EditModeSwitch.InActiveText = "鎖定";
            this.EditModeSwitch.Location = new System.Drawing.Point(794, 269);
            this.EditModeSwitch.MinimumSize = new System.Drawing.Size(1, 1);
            this.EditModeSwitch.Name = "EditModeSwitch";
            this.EditModeSwitch.Size = new System.Drawing.Size(110, 33);
            this.EditModeSwitch.SwitchShape = Sunny.UI.UISwitch.UISwitchShape.Square;
            this.EditModeSwitch.TabIndex = 101;
            this.EditModeSwitch.Text = "uiSwitch1";
            this.EditModeSwitch.ValueChanged += new Sunny.UI.UISwitch.OnValueChanged(this.EditModeSwitch_ValueChanged);
            // 
            // label_Workstations
            // 
            this.label_Workstations.BackColor = System.Drawing.Color.Transparent;
            this.label_Workstations.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Workstations.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Workstations.Location = new System.Drawing.Point(619, 166);
            this.label_Workstations.Margin = new System.Windows.Forms.Padding(0);
            this.label_Workstations.Name = "label_Workstations";
            this.label_Workstations.Size = new System.Drawing.Size(44, 29);
            this.label_Workstations.TabIndex = 47;
            this.label_Workstations.Text = "工站";
            this.label_Workstations.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_Workstations.Visible = false;
            // 
            // Workstations
            // 
            this.Workstations.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Workstations.FillDisableColor = System.Drawing.Color.White;
            this.Workstations.FillReadOnlyColor = System.Drawing.Color.White;
            this.Workstations.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstations.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Workstations.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Workstations.Location = new System.Drawing.Point(667, 166);
            this.Workstations.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Workstations.MinimumSize = new System.Drawing.Size(1, 16);
            this.Workstations.Name = "Workstations";
            this.Workstations.Padding = new System.Windows.Forms.Padding(5);
            this.Workstations.ReadOnly = true;
            this.Workstations.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Workstations.ShowText = false;
            this.Workstations.Size = new System.Drawing.Size(200, 53);
            this.Workstations.TabIndex = 46;
            this.Workstations.TabStop = false;
            this.Workstations.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Workstations.Visible = false;
            this.Workstations.Watermark = "";
            // 
            // label_ModeName
            // 
            this.label_ModeName.BackColor = System.Drawing.Color.Transparent;
            this.label_ModeName.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_ModeName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_ModeName.Location = new System.Drawing.Point(22, 127);
            this.label_ModeName.Margin = new System.Windows.Forms.Padding(0);
            this.label_ModeName.Name = "label_ModeName";
            this.label_ModeName.Size = new System.Drawing.Size(76, 29);
            this.label_ModeName.TabIndex = 44;
            this.label_ModeName.Text = "型號";
            this.label_ModeName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel4.Controls.Add(this.Machine_Create);
            this.flowLayoutPanel4.Controls.Add(this.Machine_Edit);
            this.flowLayoutPanel4.Controls.Add(this.Machine_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(357, 273);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 6;
            // 
            // Machine_Create
            // 
            this.Machine_Create.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Machine_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Create.Enabled = false;
            this.Machine_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Create.Location = new System.Drawing.Point(9, 0);
            this.Machine_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Create.Name = "Machine_Create";
            this.Machine_Create.Size = new System.Drawing.Size(30, 30);
            this.Machine_Create.Symbol = 557669;
            this.Machine_Create.SymbolSize = 32;
            this.Machine_Create.TabIndex = 2;
            this.Machine_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Machine_Create.Click += new System.EventHandler(this.Machine_Create_Click);
            // 
            // Machine_Edit
            // 
            this.Machine_Edit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Machine_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Edit.Enabled = false;
            this.Machine_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Edit.Location = new System.Drawing.Point(57, 0);
            this.Machine_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Edit.Name = "Machine_Edit";
            this.Machine_Edit.Size = new System.Drawing.Size(30, 30);
            this.Machine_Edit.Symbol = 559205;
            this.Machine_Edit.SymbolSize = 32;
            this.Machine_Edit.TabIndex = 3;
            this.Machine_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Machine_Edit.Click += new System.EventHandler(this.Machine_Edit_Click);
            // 
            // Machine_Delete
            // 
            this.Machine_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Machine_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Delete.Enabled = false;
            this.Machine_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Delete.Location = new System.Drawing.Point(105, 0);
            this.Machine_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Delete.Name = "Machine_Delete";
            this.Machine_Delete.Size = new System.Drawing.Size(30, 30);
            this.Machine_Delete.Symbol = 559506;
            this.Machine_Delete.SymbolSize = 26;
            this.Machine_Delete.TabIndex = 4;
            this.Machine_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Machine_Delete.Click += new System.EventHandler(this.Machine_Delete_Click);
            // 
            // label_Remark
            // 
            this.label_Remark.BackColor = System.Drawing.Color.Transparent;
            this.label_Remark.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Remark.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Remark.Location = new System.Drawing.Point(615, 10);
            this.label_Remark.Margin = new System.Windows.Forms.Padding(0);
            this.label_Remark.Name = "label_Remark";
            this.label_Remark.Size = new System.Drawing.Size(48, 29);
            this.label_Remark.TabIndex = 42;
            this.label_Remark.Text = "備註";
            this.label_Remark.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Remark
            // 
            this.Remark.FillColor = System.Drawing.Color.White;
            this.Remark.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Remark.Location = new System.Drawing.Point(667, 10);
            this.Remark.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Remark.MinimumSize = new System.Drawing.Size(1, 1);
            this.Remark.Name = "Remark";
            this.Remark.Padding = new System.Windows.Forms.Padding(2);
            this.Remark.ReadOnly = true;
            this.Remark.ShowText = false;
            this.Remark.Size = new System.Drawing.Size(237, 146);
            this.Remark.TabIndex = 38;
            this.Remark.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Assets
            // 
            this.Assets.FillColor = System.Drawing.Color.White;
            this.Assets.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Assets.Location = new System.Drawing.Point(400, 10);
            this.Assets.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Assets.MinimumSize = new System.Drawing.Size(1, 1);
            this.Assets.Name = "Assets";
            this.Assets.Padding = new System.Windows.Forms.Padding(2);
            this.Assets.ReadOnly = true;
            this.Assets.ShowText = false;
            this.Assets.Size = new System.Drawing.Size(200, 53);
            this.Assets.TabIndex = 37;
            this.Assets.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_SerialNumber
            // 
            this.label_SerialNumber.BackColor = System.Drawing.Color.Transparent;
            this.label_SerialNumber.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_SerialNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_SerialNumber.Location = new System.Drawing.Point(321, 73);
            this.label_SerialNumber.Margin = new System.Windows.Forms.Padding(0);
            this.label_SerialNumber.Name = "label_SerialNumber";
            this.label_SerialNumber.Size = new System.Drawing.Size(75, 29);
            this.label_SerialNumber.TabIndex = 28;
            this.label_SerialNumber.Text = "序號";
            this.label_SerialNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Barcode
            // 
            this.label_Barcode.BackColor = System.Drawing.Color.Transparent;
            this.label_Barcode.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Barcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Barcode.Location = new System.Drawing.Point(321, 112);
            this.label_Barcode.Margin = new System.Windows.Forms.Padding(0);
            this.label_Barcode.Name = "label_Barcode";
            this.label_Barcode.Size = new System.Drawing.Size(75, 29);
            this.label_Barcode.TabIndex = 26;
            this.label_Barcode.Text = "條碼";
            this.label_Barcode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SerialNumber
            // 
            this.SerialNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SerialNumber.FillDisableColor = System.Drawing.Color.White;
            this.SerialNumber.FillReadOnlyColor = System.Drawing.Color.White;
            this.SerialNumber.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.SerialNumber.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.SerialNumber.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.SerialNumber.Location = new System.Drawing.Point(400, 73);
            this.SerialNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SerialNumber.MinimumSize = new System.Drawing.Size(1, 16);
            this.SerialNumber.Name = "SerialNumber";
            this.SerialNumber.Padding = new System.Windows.Forms.Padding(5);
            this.SerialNumber.ReadOnly = true;
            this.SerialNumber.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.SerialNumber.ShowText = false;
            this.SerialNumber.Size = new System.Drawing.Size(200, 29);
            this.SerialNumber.TabIndex = 27;
            this.SerialNumber.TabStop = false;
            this.SerialNumber.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.SerialNumber.Watermark = "";
            // 
            // label_Assets
            // 
            this.label_Assets.BackColor = System.Drawing.Color.Transparent;
            this.label_Assets.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Assets.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Assets.Location = new System.Drawing.Point(321, 10);
            this.label_Assets.Margin = new System.Windows.Forms.Padding(0);
            this.label_Assets.Name = "label_Assets";
            this.label_Assets.Size = new System.Drawing.Size(75, 29);
            this.label_Assets.TabIndex = 24;
            this.label_Assets.Text = "資產編號";
            this.label_Assets.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Barcode
            // 
            this.Barcode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Barcode.FillDisableColor = System.Drawing.Color.White;
            this.Barcode.FillReadOnlyColor = System.Drawing.Color.White;
            this.Barcode.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Barcode.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Barcode.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Barcode.Location = new System.Drawing.Point(400, 112);
            this.Barcode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Barcode.MinimumSize = new System.Drawing.Size(1, 16);
            this.Barcode.Name = "Barcode";
            this.Barcode.Padding = new System.Windows.Forms.Padding(5);
            this.Barcode.ReadOnly = true;
            this.Barcode.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Barcode.ShowText = false;
            this.Barcode.Size = new System.Drawing.Size(200, 29);
            this.Barcode.TabIndex = 25;
            this.Barcode.TabStop = false;
            this.Barcode.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Barcode.Watermark = "";
            // 
            // label_Location
            // 
            this.label_Location.BackColor = System.Drawing.Color.Transparent;
            this.label_Location.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Location.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Location.Location = new System.Drawing.Point(23, 244);
            this.label_Location.Margin = new System.Windows.Forms.Padding(0);
            this.label_Location.Name = "label_Location";
            this.label_Location.Size = new System.Drawing.Size(76, 29);
            this.label_Location.TabIndex = 22;
            this.label_Location.Text = "位置";
            this.label_Location.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Brand
            // 
            this.label_Brand.BackColor = System.Drawing.Color.Transparent;
            this.label_Brand.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Brand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Brand.Location = new System.Drawing.Point(23, 205);
            this.label_Brand.Margin = new System.Windows.Forms.Padding(0);
            this.label_Brand.Name = "label_Brand";
            this.label_Brand.Size = new System.Drawing.Size(76, 29);
            this.label_Brand.TabIndex = 20;
            this.label_Brand.Text = "廠牌";
            this.label_Brand.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Condition
            // 
            this.label_Condition.BackColor = System.Drawing.Color.Transparent;
            this.label_Condition.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Condition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Condition.Location = new System.Drawing.Point(22, 166);
            this.label_Condition.Margin = new System.Windows.Forms.Padding(0);
            this.label_Condition.Name = "label_Condition";
            this.label_Condition.Size = new System.Drawing.Size(76, 29);
            this.label_Condition.TabIndex = 18;
            this.label_Condition.Text = "狀態";
            this.label_Condition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Type
            // 
            this.label_Type.BackColor = System.Drawing.Color.Transparent;
            this.label_Type.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Type.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Type.Location = new System.Drawing.Point(22, 88);
            this.label_Type.Margin = new System.Windows.Forms.Padding(0);
            this.label_Type.Name = "label_Type";
            this.label_Type.Size = new System.Drawing.Size(76, 29);
            this.label_Type.TabIndex = 14;
            this.label_Type.Text = "設備別";
            this.label_Type.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Catelogry
            // 
            this.label_Catelogry.BackColor = System.Drawing.Color.Transparent;
            this.label_Catelogry.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Catelogry.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Catelogry.Location = new System.Drawing.Point(22, 49);
            this.label_Catelogry.Margin = new System.Windows.Forms.Padding(0);
            this.label_Catelogry.Name = "label_Catelogry";
            this.label_Catelogry.Size = new System.Drawing.Size(76, 29);
            this.label_Catelogry.TabIndex = 12;
            this.label_Catelogry.Text = "分類";
            this.label_Catelogry.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_MachineId
            // 
            this.label_MachineId.BackColor = System.Drawing.Color.Transparent;
            this.label_MachineId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_MachineId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_MachineId.Location = new System.Drawing.Point(22, 10);
            this.label_MachineId.Margin = new System.Windows.Forms.Padding(0);
            this.label_MachineId.Name = "label_MachineId";
            this.label_MachineId.Size = new System.Drawing.Size(76, 29);
            this.label_MachineId.TabIndex = 10;
            this.label_MachineId.Text = "編號";
            this.label_MachineId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MaincheId
            // 
            this.MaincheId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaincheId.FillDisableColor = System.Drawing.Color.White;
            this.MaincheId.FillReadOnlyColor = System.Drawing.Color.White;
            this.MaincheId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaincheId.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaincheId.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.MaincheId.Location = new System.Drawing.Point(103, 10);
            this.MaincheId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaincheId.MinimumSize = new System.Drawing.Size(1, 16);
            this.MaincheId.Name = "MaincheId";
            this.MaincheId.Padding = new System.Windows.Forms.Padding(5);
            this.MaincheId.ReadOnly = true;
            this.MaincheId.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.MaincheId.ShowText = false;
            this.MaincheId.Size = new System.Drawing.Size(200, 29);
            this.MaincheId.TabIndex = 9;
            this.MaincheId.TabStop = false;
            this.MaincheId.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaincheId.Watermark = "";
            // 
            // Condition
            // 
            this.Condition.DataSource = null;
            this.Condition.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Condition.Enabled = false;
            this.Condition.FillColor = System.Drawing.Color.White;
            this.Condition.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Condition.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Condition.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Condition.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Condition.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Condition.Location = new System.Drawing.Point(103, 166);
            this.Condition.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Condition.MinimumSize = new System.Drawing.Size(63, 0);
            this.Condition.Name = "Condition";
            this.Condition.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Condition.Size = new System.Drawing.Size(201, 29);
            this.Condition.SymbolSize = 24;
            this.Condition.TabIndex = 105;
            this.Condition.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Condition.Watermark = "";
            // 
            // Brand
            // 
            this.Brand.DataSource = null;
            this.Brand.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Brand.Enabled = false;
            this.Brand.FillColor = System.Drawing.Color.White;
            this.Brand.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Brand.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Brand.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Brand.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Brand.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Brand.Location = new System.Drawing.Point(102, 205);
            this.Brand.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Brand.MinimumSize = new System.Drawing.Size(63, 0);
            this.Brand.Name = "Brand";
            this.Brand.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Brand.Size = new System.Drawing.Size(201, 29);
            this.Brand.SymbolSize = 24;
            this.Brand.TabIndex = 105;
            this.Brand.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Brand.Watermark = "";
            // 
            // Location
            // 
            this.Location.DataSource = null;
            this.Location.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Location.Enabled = false;
            this.Location.FillColor = System.Drawing.Color.White;
            this.Location.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Location.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Location.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Location.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Location.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Location.Location = new System.Drawing.Point(103, 244);
            this.Location.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Location.MinimumSize = new System.Drawing.Size(63, 0);
            this.Location.Name = "Location";
            this.Location.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Location.Size = new System.Drawing.Size(201, 29);
            this.Location.SymbolSize = 24;
            this.Location.TabIndex = 105;
            this.Location.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Location.Watermark = "";
            // 
            // Connected
            // 
            this.Connected.CheckBoxSize = 18;
            this.Connected.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Connected.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Connected.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Connected.Location = new System.Drawing.Point(400, 149);
            this.Connected.MinimumSize = new System.Drawing.Size(1, 1);
            this.Connected.Name = "Connected";
            this.Connected.Size = new System.Drawing.Size(119, 30);
            this.Connected.TabIndex = 106;
            this.Connected.Text = "可否連網";
            // 
            // Disposal
            // 
            this.Disposal.CheckBoxSize = 18;
            this.Disposal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Disposal.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Disposal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Disposal.Location = new System.Drawing.Point(400, 185);
            this.Disposal.MinimumSize = new System.Drawing.Size(1, 1);
            this.Disposal.Name = "Disposal";
            this.Disposal.Size = new System.Drawing.Size(119, 30);
            this.Disposal.TabIndex = 107;
            this.Disposal.Text = "是否處置";
            // 
            // adgv
            // 
            this.adgv.AllowUserToAddRows = false;
            this.adgv.AllowUserToDeleteRows = false;
            this.adgv.AllowUserToResizeRows = false;
            this.adgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.adgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adgv.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.adgv.FilterAndSortEnabled = true;
            this.adgv.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.Location = new System.Drawing.Point(228, 3);
            this.adgv.MaxFilterButtonImageHeight = 23;
            this.adgv.MultiSelect = false;
            this.adgv.Name = "adgv";
            this.adgv.ReadOnly = true;
            this.adgv.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adgv.RowTemplate.Height = 24;
            this.adgv.Size = new System.Drawing.Size(923, 349);
            this.adgv.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.TabIndex = 10;
            this.adgv.SelectionChanged += new System.EventHandler(this.ADGV_SelectionChanged);
            // 
            // Setup_MachinesSummary
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.TLP);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_MachinesSummary";
            this.Size = new System.Drawing.Size(1154, 675);
            this.Load += new System.EventHandler(this.Setup_MachinesSummary_Load);
            this.TLP.ResumeLayout(false);
            this.detailPanel.ResumeLayout(false);
            this.detailPanel.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel TLP;
        private Sunny.UI.UITreeView list_Catelogries;
        private AdvancedDataGridView adgv;
        private System.Windows.Forms.Panel detailPanel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton Machine_Create;
        private Sunny.UI.UISymbolButton Machine_Edit;
        private Sunny.UI.UISymbolButton Machine_Delete;
        private Sunny.UI.UILabel label_Remark;
        private Sunny.UI.UIRichTextBox Remark;
        private Sunny.UI.UIRichTextBox Assets;
        private Sunny.UI.UILabel label_SerialNumber;
        private Sunny.UI.UILabel label_Barcode;
        private Sunny.UI.UITextBox SerialNumber;
        private Sunny.UI.UILabel label_Assets;
        private Sunny.UI.UITextBox Barcode;
        private Sunny.UI.UILabel label_Location;
        private Sunny.UI.UILabel label_Brand;
        private Sunny.UI.UILabel label_Condition;
        private Sunny.UI.UILabel label_Type;
        private Sunny.UI.UILabel label_Catelogry;
        private Sunny.UI.UILabel label_MachineId;
        private Sunny.UI.UITextBox MaincheId;
        private Sunny.UI.UILabel label_ModeName;
        private Sunny.UI.UILabel label_Workstations;
        private Sunny.UI.UITextBox Workstations;
        private Sunny.UI.UISymbolButton btnSave;
        private Sunny.UI.UISwitch EditModeSwitch;
        private Sunny.UI.UIComboBox ModelNo;
        private Sunny.UI.UIComboBox Type;
        private Sunny.UI.UIComboBox Catelogry;
        private Sunny.UI.UIComboBox Location;
        private Sunny.UI.UIComboBox Brand;
        private Sunny.UI.UIComboBox Condition;
        private Sunny.UI.UICheckBox Connected;
        private Sunny.UI.UICheckBox Disposal;
    }
}
