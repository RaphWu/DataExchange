﻿using System.Data.Entity.Migrations;

namespace Calin.TaskPulse.Core.Migrations
{
    public partial class AddEmployeeCarbonCopy : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.EmployeeCarbonCopies",
                c => new
                {
                    EmployeeId = c.Int(nullable: false),
                    CarbonCopyEmployeeId = c.Int(nullable: false),
                })
                .PrimaryKey(t => new { t.EmployeeId, t.CarbonCopyEmployeeId })
                .ForeignKey("dbo.Employees", t => t.EmployeeId, cascadeDelete: false)
                .ForeignKey("dbo.Employees", t => t.CarbonCopyEmployeeId, cascadeDelete: false)
                .Index(t => t.EmployeeId)
                .Index(t => t.CarbonCopyEmployeeId);
        }

        public override void Down()
        {
            DropForeignKey("dbo.EmployeeCarbonCopies", "CarbonCopyEmployeeId", "dbo.Employees");
            DropForeignKey("dbo.EmployeeCarbonCopies", "EmployeeId", "dbo.Employees");
            DropIndex("dbo.EmployeeCarbonCopies", new[] { "CarbonCopyEmployeeId" });
            DropIndex("dbo.EmployeeCarbonCopies", new[] { "EmployeeId" });
            DropTable("dbo.EmployeeCarbonCopies");
        }
    }
}
