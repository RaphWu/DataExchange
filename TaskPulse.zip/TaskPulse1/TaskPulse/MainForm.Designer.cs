﻿namespace Calin.TaskPulse
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kryptonManager = new Krypton.Toolkit.KryptonManager(this.components);
            this.mainMenuStatusStrip = new Krypton.Toolkit.KryptonStatusStrip();
            this.toolStripStatus_SystemMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatus_UserName = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Version = new System.Windows.Forms.Label();
            this.mainMenuButton_MaintiFlow = new Krypton.Toolkit.KryptonButton();
            this.panel_MainMenu = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.mainMenuButton_ToolQuest = new Krypton.Toolkit.KryptonButton();
            this.mainMenuButton_MechaTrack = new Krypton.Toolkit.KryptonButton();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.mainMenuButton_SwitchUser = new Krypton.Toolkit.KryptonButton();
            this.mainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem_File = new System.Windows.Forms.ToolStripMenuItem();
            this.結束ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Tool = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_System = new System.Windows.Forms.ToolStripMenuItem();
            this.切換使用者ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.使用者管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainMenuStatusStrip.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel_MainMenu.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.mainMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // kryptonManager
            // 
            this.kryptonManager.BaseFont = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kryptonManager.GlobalPaletteMode = Krypton.Toolkit.PaletteMode.Office2010Silver;
            // 
            // mainMenuStatusStrip
            // 
            this.mainMenuStatusStrip.Font = new System.Drawing.Font("Segoe UI", 8.999999F);
            this.mainMenuStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatus_SystemMessage,
            this.toolStripStatus_UserName});
            this.mainMenuStatusStrip.Location = new System.Drawing.Point(0, 545);
            this.mainMenuStatusStrip.Name = "mainMenuStatusStrip";
            this.mainMenuStatusStrip.ProgressBars = null;
            this.mainMenuStatusStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode;
            this.mainMenuStatusStrip.Size = new System.Drawing.Size(1132, 22);
            this.mainMenuStatusStrip.TabIndex = 2;
            this.mainMenuStatusStrip.Text = "使用者名稱";
            // 
            // toolStripStatus_SystemMessage
            // 
            this.toolStripStatus_SystemMessage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatus_SystemMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatus_SystemMessage.Name = "toolStripStatus_SystemMessage";
            this.toolStripStatus_SystemMessage.Size = new System.Drawing.Size(979, 17);
            this.toolStripStatus_SystemMessage.Spring = true;
            this.toolStripStatus_SystemMessage.Text = "Messages";
            this.toolStripStatus_SystemMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatus_UserName
            // 
            this.toolStripStatus_UserName.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatus_UserName.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatus_UserName.Name = "toolStripStatus_UserName";
            this.toolStripStatus_UserName.Size = new System.Drawing.Size(138, 17);
            this.toolStripStatus_UserName.Text = "toolStripStatusLabel1";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label_Version);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 521);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1132, 24);
            this.panel1.TabIndex = 4;
            // 
            // label_Version
            // 
            this.label_Version.AutoSize = true;
            this.label_Version.Dock = System.Windows.Forms.DockStyle.Right;
            this.label_Version.Location = new System.Drawing.Point(1078, 0);
            this.label_Version.Name = "label_Version";
            this.label_Version.Size = new System.Drawing.Size(54, 17);
            this.label_Version.TabIndex = 4;
            this.label_Version.Text = "Version";
            this.label_Version.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // mainMenuButton_MaintiFlow
            // 
            this.mainMenuButton_MaintiFlow.Location = new System.Drawing.Point(0, 323);
            this.mainMenuButton_MaintiFlow.Margin = new System.Windows.Forms.Padding(0);
            this.mainMenuButton_MaintiFlow.Name = "mainMenuButton_MaintiFlow";
            this.mainMenuButton_MaintiFlow.Size = new System.Drawing.Size(250, 120);
            this.mainMenuButton_MaintiFlow.StateCommon.Border.Rounding = 12F;
            this.mainMenuButton_MaintiFlow.StateCommon.Border.Width = 2;
            this.mainMenuButton_MaintiFlow.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mainMenuButton_MaintiFlow.TabIndex = 14;
            this.mainMenuButton_MaintiFlow.TabStop = false;
            this.mainMenuButton_MaintiFlow.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.mainMenuButton_MaintiFlow.Values.Text = "維護工單";
            this.mainMenuButton_MaintiFlow.Visible = false;
            // 
            // panel_MainMenu
            // 
            this.panel_MainMenu.ColumnCount = 5;
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panel_MainMenu.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.panel_MainMenu.Controls.Add(this.tableLayoutPanel3, 3, 1);
            this.panel_MainMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_MainMenu.Location = new System.Drawing.Point(0, 25);
            this.panel_MainMenu.Name = "panel_MainMenu";
            this.panel_MainMenu.RowCount = 3;
            this.panel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 520F));
            this.panel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panel_MainMenu.Size = new System.Drawing.Size(1132, 496);
            this.panel_MainMenu.TabIndex = 5;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.mainMenuButton_ToolQuest, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.mainMenuButton_MechaTrack, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.mainMenuButton_MaintiFlow, 0, 5);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(227, -9);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 7;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(250, 514);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // mainMenuButton_ToolQuest
            // 
            this.mainMenuButton_ToolQuest.Location = new System.Drawing.Point(0, 46);
            this.mainMenuButton_ToolQuest.Margin = new System.Windows.Forms.Padding(0);
            this.mainMenuButton_ToolQuest.Name = "mainMenuButton_ToolQuest";
            this.mainMenuButton_ToolQuest.Size = new System.Drawing.Size(250, 120);
            this.mainMenuButton_ToolQuest.StateCommon.Border.Rounding = 12F;
            this.mainMenuButton_ToolQuest.StateCommon.Border.Width = 2;
            this.mainMenuButton_ToolQuest.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mainMenuButton_ToolQuest.TabIndex = 14;
            this.mainMenuButton_ToolQuest.TabStop = false;
            this.mainMenuButton_ToolQuest.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.mainMenuButton_ToolQuest.Values.Text = "工具委託";
            this.mainMenuButton_ToolQuest.Visible = false;
            // 
            // mainMenuButton_MechaTrack
            // 
            this.mainMenuButton_MechaTrack.Location = new System.Drawing.Point(0, 186);
            this.mainMenuButton_MechaTrack.Margin = new System.Windows.Forms.Padding(0);
            this.mainMenuButton_MechaTrack.Name = "mainMenuButton_MechaTrack";
            this.mainMenuButton_MechaTrack.Size = new System.Drawing.Size(250, 117);
            this.mainMenuButton_MechaTrack.StateCommon.Border.Rounding = 12F;
            this.mainMenuButton_MechaTrack.StateCommon.Border.Width = 2;
            this.mainMenuButton_MechaTrack.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mainMenuButton_MechaTrack.TabIndex = 16;
            this.mainMenuButton_MechaTrack.TabStop = false;
            this.mainMenuButton_MechaTrack.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.mainMenuButton_MechaTrack.Values.Text = "專案管理";
            this.mainMenuButton_MechaTrack.Visible = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.mainMenuButton_SwitchUser, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(633, -9);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(272, 514);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // mainMenuButton_SwitchUser
            // 
            this.mainMenuButton_SwitchUser.Location = new System.Drawing.Point(3, 140);
            this.mainMenuButton_SwitchUser.Name = "mainMenuButton_SwitchUser";
            this.mainMenuButton_SwitchUser.Size = new System.Drawing.Size(218, 111);
            this.mainMenuButton_SwitchUser.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mainMenuButton_SwitchUser.TabIndex = 0;
            this.mainMenuButton_SwitchUser.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.mainMenuButton_SwitchUser.Values.Image = global::Calin.TaskPulse.Properties.Resources.user_group_296;
            this.mainMenuButton_SwitchUser.Values.Text = "切換使用者";
            this.mainMenuButton_SwitchUser.Click += new System.EventHandler(this.button_SwitchUser_Click);
            // 
            // mainMenuStrip
            // 
            this.mainMenuStrip.Font = new System.Drawing.Font("Segoe UI", 8.999999F);
            this.mainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_File,
            this.toolStripMenuItem_Tool,
            this.toolStripMenuItem_System});
            this.mainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.mainMenuStrip.Name = "mainMenuStrip";
            this.mainMenuStrip.Size = new System.Drawing.Size(1132, 25);
            this.mainMenuStrip.TabIndex = 6;
            this.mainMenuStrip.Text = "主選單";
            // 
            // toolStripMenuItem_File
            // 
            this.toolStripMenuItem_File.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.結束ToolStripMenuItem});
            this.toolStripMenuItem_File.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem_File.Name = "toolStripMenuItem_File";
            this.toolStripMenuItem_File.Size = new System.Drawing.Size(46, 21);
            this.toolStripMenuItem_File.Text = "檔案";
            // 
            // 結束ToolStripMenuItem
            // 
            this.結束ToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.結束ToolStripMenuItem.Name = "結束ToolStripMenuItem";
            this.結束ToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.結束ToolStripMenuItem.Text = "結束";
            // 
            // toolStripMenuItem_Tool
            // 
            this.toolStripMenuItem_Tool.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem_Tool.Name = "toolStripMenuItem_Tool";
            this.toolStripMenuItem_Tool.Size = new System.Drawing.Size(46, 21);
            this.toolStripMenuItem_Tool.Text = "工具";
            // 
            // toolStripMenuItem_System
            // 
            this.toolStripMenuItem_System.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.切換使用者ToolStripMenuItem,
            this.toolStripSeparator1,
            this.使用者管理ToolStripMenuItem});
            this.toolStripMenuItem_System.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem_System.Name = "toolStripMenuItem_System";
            this.toolStripMenuItem_System.Size = new System.Drawing.Size(46, 21);
            this.toolStripMenuItem_System.Text = "系統";
            // 
            // 切換使用者ToolStripMenuItem
            // 
            this.切換使用者ToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.切換使用者ToolStripMenuItem.Name = "切換使用者ToolStripMenuItem";
            this.切換使用者ToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.切換使用者ToolStripMenuItem.Text = "切換使用者";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(138, 6);
            // 
            // 使用者管理ToolStripMenuItem
            // 
            this.使用者管理ToolStripMenuItem.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.使用者管理ToolStripMenuItem.Name = "使用者管理ToolStripMenuItem";
            this.使用者管理ToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.使用者管理ToolStripMenuItem.Text = "使用者管理";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 567);
            this.Controls.Add(this.panel_MainMenu);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.mainMenuStatusStrip);
            this.Controls.Add(this.mainMenuStrip);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.MainMenuStrip = this.mainMenuStrip;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Shown += new System.EventHandler(this.MainForm_Shown);
            this.mainMenuStatusStrip.ResumeLayout(false);
            this.mainMenuStatusStrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel_MainMenu.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.mainMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Krypton.Toolkit.KryptonManager kryptonManager;
        private Krypton.Toolkit.KryptonStatusStrip mainMenuStatusStrip;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_Version;
        private Krypton.Toolkit.KryptonButton mainMenuButton_MaintiFlow;
        private System.Windows.Forms.TableLayoutPanel panel_MainMenu;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private Krypton.Toolkit.KryptonButton mainMenuButton_ToolQuest;
        private Krypton.Toolkit.KryptonButton mainMenuButton_MechaTrack;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Krypton.Toolkit.KryptonButton mainMenuButton_SwitchUser;
        private System.Windows.Forms.MenuStrip mainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_File;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Tool;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_System;
        private System.Windows.Forms.ToolStripMenuItem 結束ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 切換使用者ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 使用者管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatus_SystemMessage;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatus_UserName;
    }
}

