﻿namespace Calin.TaskPulse.Models
{
    /// <summary>
    /// 問題分類清單。
    /// </summary>
    public class IssueCategory
    {
        /// <summary>
        /// 問題分類代號。
        /// </summary>
        public int CategoryId { get; set; }

        /// <summary>
        /// 問題分類名稱。
        /// </summary>
        public string CategoryName { get; set; }
    }
}
