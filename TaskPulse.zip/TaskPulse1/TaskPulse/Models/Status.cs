﻿namespace Calin.TaskPulse.Models
{
    /// <summary>
    /// 目前狀態。
    /// </summary>
    public class Status
    {
        public int StatusId { get; set; }
        public int OrderNo { get; set; }
        public string StatusName { get; set; }
    }
}
