﻿extern alias SQLiteCodeFirst;

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using SQLiteCodeFirst;
using SQLiteCodeFirst::SQLite.CodeFirst;

namespace Calin.TaskPulse.Models
{
    /// <summary>
    /// 資料庫區。
    /// </summary>
    public class MaintiFlowContext : DbContext
    {
        public MaintiFlowContext() : base("name=MaintiFlowContext")
        {
            //if (System.IO.File.Exists("MaintiFlowDB.db"))
            //    System.IO.File.Delete("MaintiFlowDB.db");

            //Database.SetInitializer(new CreateDatabaseIfNotExists<MaintiFlowContext>());
            //Database.SetInitializer(new DropCreateDatabaseAlways<MaintiFlowContext>());
            //Database.SetInitializer<MaintiFlowContext>(null);
            //Database.CreateIfNotExists();
        }

        //public DbSet<History> Histories { get; set; }
        //public DbSet<MaintenanceUnit> MaintenanceUnits { get; set; }
        //public DbSet<RequestingUnit> RequestingUnits { get; set; }
        //public DbSet<IssueCategory> IssueCategories { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Status> Statuses { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            var sqliteConnectionInitializer = new SqliteDropCreateDatabaseAlways<MaintiFlowContext>(modelBuilder);
            Database.SetInitializer(sqliteConnectionInitializer);
        }

        protected override void Seed(MaintiFlowContext context)
        {
            var faker = new Bogus.Faker("zh_TW");
            var em = context.Set<Employee>();
            for (int i = 0; i < 100; i++)
            {
                em.Add(new Employee()
                {
                    EmployeeId = (8500 + i).ToString(),
                    Department = faker.Commerce.Department(),
                    Title = faker.Name.JobTitle(),
                    Name = faker.Name.FullName(),
                });
            }

            var st = context.Set<Status>();
            st.Add(new Status() { StatusId = 1, OrderNo = 1, StatusName = "待處理" });
            st.Add(new Status() { StatusId = 2, OrderNo = 2, StatusName = "處理中" });
            st.Add(new Status() { StatusId = 3, OrderNo = 3, StatusName = "已完成" });

            context.SaveChanges();
        }
    }
}
