﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.Models
{
    /// <summary>
    /// 員工清單。
    /// </summary>
    public class Employee
    {
        /// <summary>
        /// 工號。
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string EmployeeId { get; set; }

        /// <summary>
        /// 部門。
        /// </summary>
        public string Department { get; set; }

        /// <summary>
        /// 職稱。
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        [Required]
        public string Name { get; set; }


    }


}
