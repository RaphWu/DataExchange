﻿namespace Calin.TaskPulse.Core.Constants
{
    /// <summary>
    /// 操作模式。
    /// </summary>
    public enum OperationModeId
    {
        /// <summary>
        /// 位於主選單。
        /// </summary>
        MainMenu,

        /// <summary>
        /// 工具委託。
        /// </summary>
        ToolQuest,

        /// <summary>
        /// 專案管理。
        /// </summary>
        MechaTrack,

        /// <summary>
        /// 維護工單。
        /// </summary>
        MaintiFlow,
    }
}
