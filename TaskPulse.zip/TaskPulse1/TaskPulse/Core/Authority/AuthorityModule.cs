﻿using Autofac;

namespace Calin.TaskPulse.Core.Authority
{
    public class AuthorityModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<AuthorityService>().As<IAuthority>();
        }
    }
}
