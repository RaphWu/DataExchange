﻿namespace Calin.TaskPulse.Core.Authority
{
    /// <summary>
    /// 使用者資料。
    /// </summary>
    public class UserData
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
