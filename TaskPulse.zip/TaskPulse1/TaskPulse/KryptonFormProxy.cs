﻿using System.ComponentModel;
using System.Drawing;
using Krypton.Toolkit;

namespace Calin.TaskPulse
{
    public class KryptonFormProxy
    {
        private readonly KryptonForm _form;

        public KryptonFormProxy(KryptonForm form) => _form = form;

        [Category("Appearance")]
        [Description("The text associated with the control.")]
        [DefaultValue("")]
        public string Text
        {
            get => _form.Text;
            set => _form.Text = value;
        }

        [Category("Appearance")]
        [Description("The extra text associated with the control.")]
        [DefaultValue("")]
        public string TextExtra
        {
            get => _form.TextExtra;
            set => _form.TextExtra = value;
        }

        [Category("Appearance")]
        [Description("The icon associated with the control.")]
        [DefaultValue("")]
        public Icon Icon
        {
            get => _form.Icon;
            set => _form.Icon = value;
        }

        [Category("Visuals")]
        [Description("是否應允許此 KryptonForm 實例使用自訂 chrome。")]
        [DefaultValue(true)]
        public bool UseThemeFormChromeBorderWidth
        {
            get => _form.UseThemeFormChromeBorderWidth;
            set => _form.UseThemeFormChromeBorderWidth = value;
        }

        [Category("Visuals")]
        [Description("是否應考慮將表單狀態列合併到 chrome 中。")]
        [DefaultValue(true)]
        public bool AllowStatusStripMerge
        {
            get => _form.AllowStatusStripMerge;
            set => _form.AllowStatusStripMerge = value;
        }

        [Category("Visuals")]
        [Description("Header style for a main form.")]
        [DefaultValue(HeaderStyle.Form)]
        public HeaderStyle HeaderStyle
        {
            get => _form.HeaderStyle;
            set => _form.HeaderStyle = value;
        }
        [Category(@"Visuals")]
        [Description(@"The Form Title position, relative to available space")]
        [RefreshProperties(RefreshProperties.All)]
        [DefaultValue(PaletteRelativeAlign.Near)]
        public PaletteRelativeAlign FormTitleAlign
        {
            get => _form.FormTitleAlign;
            set => _form.FormTitleAlign = value;
        }


        [Category("Visuals")]
        [Description("Chrome group border style.")]
        [DefaultValue(PaletteBorderStyle.FormMain)]
        public PaletteBorderStyle GroupBorderStyle
        {
            get => _form.GroupBorderStyle;
            set => _form.GroupBorderStyle = value;
        }

        [Category("Visuals")]
        [Description("Chrome group background style.")]
        [DefaultValue(PaletteBackStyle.FormMain)]
        public PaletteBackStyle GroupBackStyle
        {
            get => _form.GroupBackStyle;
            set => _form.GroupBackStyle = value;
        }

        [Category("Visuals")]
        [Description("用於定義其他狀態可以覆蓋的通用表單外觀的覆蓋。")]
        public PaletteFormRedirect StateCommon => _form.StateCommon;

        [Category("Visuals")]
        [Description("用於定義非活動表單外觀的覆蓋。")]
        public PaletteForm StateInactive => _form.StateInactive;

        [Category("Visuals")]
        [Description("用於定義活動表單外觀的覆蓋範圍。")]
        public PaletteForm StateActive => _form.StateActive;

        [Category("Visuals")]
        [Description("按鈕規格的集合。")]
        public KryptonForm.FormButtonSpecCollection ButtonSpecs => _form.ButtonSpecs;

        [Category("Window Style")]
        [DefaultValue(true)]
        public bool ControlBox
        {
            get => _form.ControlBox;
            set => _form.ControlBox = value;
        }

        [Category("Window Style")]
        [DefaultValue(true)]
        public bool MaximizeBox
        {
            get => _form.MaximizeBox;
            set => _form.MaximizeBox = value;
        }

        [Category("Window Style")]
        [DefaultValue(true)]
        public bool MinimizeBox
        {
            get => _form.MinimizeBox;
            set => _form.MinimizeBox = value;
        }

        [Category("Window Style")]
        [DefaultValue(true)]
        public bool ShowIcon
        {
            get => _form.ShowIcon;
            set => _form.ShowIcon = value;
        }
    }
}
