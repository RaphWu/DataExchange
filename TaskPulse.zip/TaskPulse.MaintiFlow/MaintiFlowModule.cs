﻿using Autofac;
using Calin.TaskPulse.MaintiFlow.Views;

namespace Calin.TaskPulse.MaintiFlow
{
    public class MaintiFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<MaintiFlowPage>().AsSelf();
        }
    }
}
