﻿using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowPage : UIPage
    {
        public MaintiFlowPage()
        {
            InitializeComponent();
        }
    }
}
