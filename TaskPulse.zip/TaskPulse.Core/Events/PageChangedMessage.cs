﻿using Calin.TaskPulse.Core.Contants;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 頁面切換事件。
    /// </summary>
    public class PageChangedMessage : ValueChangedMessage<PageCode>
    {
        public PageChangedMessage(PageCode pageCode) : base(pageCode) { }
    }
}
