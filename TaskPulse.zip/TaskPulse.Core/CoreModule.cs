﻿using Autofac;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType(typeof(AuthorityData)).SingleInstance();

            builder.RegisterType<DialogService>();
            builder.RegisterType<AuthorityService>().As<IAuthority>();

            builder.RegisterType<SetupPage>().AsSelf();
            //builder.RegisterType<UserLogin>().AsSelf();
            //builder.RegisterType<AuthorityEditor>().AsSelf().PropertiesAutowired();
        }
    }
}
