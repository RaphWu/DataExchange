﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.Contants
{
    /// <summary>
    /// 頁面代號。
    /// </summary>
    public enum PageCode
    {
        None = 0,

        [Description("主選單")]
        MainPage = 1000,

        [Description("工具委託")]
        ToolQuest = 2000,

        [Description("專案管理")]
        MechaTrack = 3000,

        [Description("維護工單")]
        MaintiFlow = 4000,

        [Description("設定")]
        Setup = 5000,

        [Description("切換使用者")]
        UserLogin = 5001,
    }
}
