﻿using Autofac;

namespace TaskPulse.MechaTrack
{
    public class MechaTrackModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<MechaTrackControl>().AsSelf();
        }
    }
}
