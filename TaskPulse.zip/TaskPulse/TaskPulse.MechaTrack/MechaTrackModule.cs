﻿using Autofac;
using Calin.TaskPulse.MechaTrack.Views;

namespace Calin.TaskPulse.MechaTrack
{
    public class MechaTrackModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<MechaTrackPage>().AsSelf();
        }
    }
}
