﻿using Sunny.UI;

namespace Calin.TaskPulse.MechaTrack.Views
{
    public partial class MechaTrackPage : UIPage
    {
        public MechaTrackPage()
        {
            InitializeComponent();
        }
    }
}
