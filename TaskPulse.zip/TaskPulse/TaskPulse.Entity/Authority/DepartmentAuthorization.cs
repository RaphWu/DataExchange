﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Entity.Authority
{
    /// <summary>
    /// 部門權限。
    /// </summary>
    public class DepartmentAuthorization
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 部門。
        /// </summary>
        [Description("部門")]
        public virtual Department Department { get; set; }
        [Required]
        public int DepartmentId { get; set; }

        /// <summary>
        /// 部門權限表。
        /// </summary>
        [Description("權限表")]
        [Required]
        public string AuthorizedList { get; set; }

        public virtual ICollection<UserAuthorization> UserAuthorizations { get; set; }
    }
}
