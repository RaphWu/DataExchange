﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Entity.Authority
{
    public class UserAuthorization
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 使用者名稱。
        /// </summary>
        public virtual Employee User { get; set; }
        [Required]
        public int UserId { get; set; }

        /// <summary>
        /// 所屬部門。
        /// </summary>
        [Description("所屬部門")]
        public virtual DepartmentAuthorization Department { get; set; }
        [Required]
        public int DepartmentId { get; set; }

        /// <summary>
        /// 使用者密碼。
        /// </summary>
        [Description("密碼")]
        public string Password { get; set; }

        /// <summary>
        /// 使用者權限表。
        /// </summary>
        [Description("權限表")]
        public string AuthorizedList { get; set; }
    }
}
