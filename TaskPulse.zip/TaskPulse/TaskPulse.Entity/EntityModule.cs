﻿using Autofac;

namespace TaskPulse.Entity
{
    public class EntityModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            //builder.RegisterType<FieldName>().SingleInstance();
            //builder.RegisterType<FieldName>().AsSelf().SingleInstance();
        }
    }
}
