﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    /// <summary>
    /// 維護工單。
    /// </summary>
    public class TaskOrder : ObservableObject
    {
        /// <summary>
        /// 維護工單序號。
        /// </summary>
        [Description("序號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /********************
         * 工單資料
         ********************/
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        [Description("工單編號")]
        [Required]
        [Index(IsUnique = true)]
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 維護狀態。
        /// </summary>
        [Description("狀態")]
        [Required]
        public OrderStatus Status { get; set; }

        /// <summary>
        /// 機台編號。
        /// </summary>
        [Description("機台")]
        public virtual Machine Machine { get; set; } // CoreContext
        [Index]
        public int? MachineId { get; set; } // FK
        [NotMapped]
        public string MachineCode { get => Machine?.MachineId ?? string.Empty; }
        [NotMapped]
        public string MachineName { get => Machine?.MachineName?.ModelName ?? string.Empty; }
        [NotMapped]
        public string FullMachineName =>
            string.Join(" » ", new[] { MachineName, MachineCode }.Where(s => !string.IsNullOrEmpty(s)));

        //public string FullMachineName
        //{
        //    get
        //    {
        //        string[] mName = new string[2];
        //        mName[0] = MachineCode;
        //        mName[1] = MachineName;
        //        string ret = "";

        //        if (!string.IsNullOrEmpty(mName[0]))
        //        {
        //            ret = mName[0];
        //            if (!string.IsNullOrEmpty(mName[1]))
        //                ret += " » ";
        //        }
        //        if (!string.IsNullOrEmpty(mName[1]))
        //            ret += mName[1];
        //        return ret;
        //    }
        //}

        /// <summary>
        /// 工站。
        /// </summary>
        [Description("工站")]
        public virtual Workstation Workstation { get; set; } // CoreContext
        [Index]
        public int? WorkstationId { get; set; } // FK
        [NotMapped]
        public string ModelName { get => Workstation?.Model?.ModelName ?? string.Empty; }
        [NotMapped]
        public string WorkstationName => Workstation?.WorkstationName ?? string.Empty;
        [NotMapped]
        [Description("機種 » 工站")]
        public string ModelWorkstationName => string.Join(" » ", new string[] { ModelName, WorkstationName });

        /// <summary>
        /// 建檔人員。
        /// </summary>
        [Description("建檔人員")]
        public virtual Employee Creator { get; set; } // CoreContext
        public int CreatorId { get; set; } // FK
        [NotMapped]
        public string CreatorName => Creator != null ? Creator.Name : string.Empty;
        [NotMapped]
        public string CreatorHalfName => Creator != null
            ? $"{Creator.Department.DepartmentName}, {Creator.Name}"
            : string.Empty;
        [NotMapped]
        public string CreatorFullName => Creator != null
            ? $"{Creator.EmployeeId}, {Creator.Department.DepartmentName}, {Creator.Name}"
            : string.Empty;

        /// <summary>
        /// 建檔日期。
        /// </summary> 
        [Description("建檔日期")]
        [Required]
        public DateTime CreationDate { get; set; }
        [NotMapped]
        public string CreationDateString => CreationDate.ToString("yyyy/MM/dd") ?? string.Empty;

        /********************
         * 維護部門
         ********************/
        /// <summary>
        /// 維護單位。
        /// </summary>
        [Description("維護單位")]
        public virtual MaintenanceUnit MaintenanceUnit { get; set; }
        public int? MaintenanceUnitId { get; set; } // FK
        [NotMapped]
        public string MaintenanceUnitString => MaintenanceUnit?.UnitName ?? string.Empty;

        /// <summary>
        /// 維護工程師。EngineerList
        /// </summary>
        [Description("工程師")]
        public virtual ICollection<Employee> Engineers { get; set; } // 多對多
        [NotMapped]
        public Dictionary<int, string> EngineerList
        {
            get => Engineers.ToDictionary(emp => emp.Id, emp => emp.Name);
        }
        [NotMapped]
        public string EngineerString
        {
            get => Engineers != null
                ? string.Join("; ", Engineers.Select(emp => emp.Name))
                : string.Empty;
        }
        [NotMapped]
        public string EngineerMultiString
        {
            get => Engineers != null
                ? string.Join(Environment.NewLine, Engineers.Select(emp => emp.Name))
                : string.Empty;
        }

        /// <summary>
        /// 接單時間。
        /// </summary>
        [Description("接單時間")]
        [Required]
        public DateTime AcceptedTime { get; set; }
        [NotMapped]
        public string AcceptedTimeString { get => AcceptedTime.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /********************
         * 維護內容
         ********************/
        /// <summary>
        /// 維護類型。
        /// </summary>
        [Description("維護類型")]
        public virtual IssueCategory IssueCategory { get; set; }
        public int? IssueCategoryId { get; set; } // FK
        [NotMapped]
        public string IssueCategoryString { get => IssueCategory?.CategoryName ?? string.Empty; }

        /// <summary>
        /// 問題描述。
        /// </summary>
        [Description("問題描述")]
        public string IssueDescription { get; set; }

        /// <summary>
        /// 維護內容。
        /// </summary>
        [Description("維護內容")]
        public string Details { get; set; }

        /// <summary>
        /// 維護開始時間。
        /// </summary>
        [Description("開始時間")]
        public DateTime? RepairStarted { get; set; }
        [NotMapped]
        public string RepairStartedString
        {
            get => RepairStarted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set
            {
                if (DateTime.TryParse(value, out var dt))
                    RepairStarted = dt;
                else
                    RepairStarted = null;
            }
        }

        /// <summary>
        /// 維修完成時間。
        /// </summary>
        [Description("完成時間")]
        public DateTime? RepairCompleted { get; set; }
        [NotMapped]
        public string RepairCompletedString
        {
            get => RepairCompleted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set
            {
                if (DateTime.TryParse(value, out var dt))
                    RepairCompleted = dt;
                else
                    RepairCompleted = null;
            }
        }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [Description("維修工時")]
        public long RepairDurationTick { get; set; }
        [Description("維修工時")]
        [NotMapped]
        public TimeSpan RepairDuration
        {
            get
            {
                TimeSpan ts;
                if (RepairCompleted.HasValue && RepairStarted.HasValue)
                {
                    ts = (TimeSpan)(RepairCompleted - RepairStarted);
                    RepairDurationTick = ts.Ticks;
                }
                else
                {
                    ts = TimeSpan.FromTicks(RepairDurationTick);
                }
                return ts;
            }
            set
            {
                RepairDurationTick = value.Ticks;
                //OnPropertyChanged(nameof(RepairDurationString));
            }
        }
        [Description("維修工時")]
        [NotMapped]
        public string RepairDurationString
        {
            get
            {
                var ts = RepairDuration;
                string days = ts.Days > 0 ? $"{ts.Days}天 " : "";
                return $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
            }
        }

        /// <summary>
        /// 維護工單內容填寫完成時間。
        /// </summary>
        [Description("填寫時間")]
        public DateTime? FillingTime { get; set; }

        [Description("填寫時間")]
        [NotMapped]
        public string FillingTimeString { get => FillingTime?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /********************
         * 維護申請資訊
         ********************/
        /// <summary>
        /// 需求單位名稱。
        /// </summary>
        [Description("需求單位")]
        public virtual RequestingUnit RequestingUnit { get; set; }
        public int? RequestingUnitId { get; set; } // FK
        [NotMapped]
        public string RequestingUnitString { get => RequestingUnit?.UnitName ?? string.Empty; }

        /// <summary>
        /// 回覆人員工號。
        /// </summary>
        [Description("回覆人員")]
        public virtual Employee RequestingEmployee { get; set; } // CoreContext
        public int? RequestingEmployeeId { get; set; } // FK
        [NotMapped]
        public string RequestingEmployeeString
        {
            get => RequestingEmployee != null
                    ? (RequestingEmployee.Title != null ? $"{RequestingEmployee.Title}, " : string.Empty) + RequestingEmployee.Name
                    : string.Empty;
        }

        /// <summary>
        /// 需求單位回覆內容。
        /// </summary>
        [Description("回覆內容")]
        public string Response { get; set; }
        //public virtual ResponseList Response { get; set; }

        /// <summary>
        /// 停動開始。
        /// </summary>
        [Description("停動開始")]
        public DateTime? OutageStarted { get; set; }
        [NotMapped]
        public string OutageStartedString
        {
            get => OutageStarted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set
            {
                if (DateTime.TryParse(value, out var dt))
                    OutageStarted = dt;
                else
                    OutageStarted = null;
            }
        }

        /// <summary>
        /// 停動結束。
        /// </summary>
        [Description("停動結束")]
        public DateTime? OutageEnded { get; set; }
        [NotMapped]
        public string OutageEndedString
        {
            get => OutageEnded?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set
            {
                if (DateTime.TryParse(value, out var dt))
                    OutageEnded = dt;
                else
                    OutageEnded = null;
            }
        }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [Description("停動工時")]
        public long OutageDurationTick { get; set; }
        [Description("停動工時")]
        [NotMapped]
        public TimeSpan OutageDuration
        {
            get
            {
                TimeSpan ts;
                if (OutageEnded.HasValue && OutageStarted.HasValue)
                {
                    ts = (TimeSpan)(OutageEnded - OutageStarted);
                    OutageDurationTick = ts.Ticks;
                }
                else
                {
                    ts = TimeSpan.FromTicks(OutageDurationTick);
                }
                return ts;
            }
            set
            {
                OutageDurationTick = value.Ticks;
                //OnPropertyChanged(nameof(OutageDurationString));
            }
        }
        [Description("停動工時")]
        [NotMapped]
        public string OutageDurationString
        {
            get
            {
                var ts = OutageDuration;
                string days = ts.Days > 0 ? $"{ts.Days}天 " : "";
                return $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
            }
        }

        /********************
         * 其他
         ********************/
        /// <summary>
        /// 責任歸屬。
        /// </summary>
        [Description("責任歸屬")]
        public string Responsible { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        [Description("編號")]
        public int OrderNo { get; set; }
    }
}
