﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台類別。
    /// </summary>
    public class MachineCategory
    {
        /// <summary>
        /// 機台類別代號。
        /// </summary>
        [Description("類別代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台類別名稱。
        /// </summary>
        [Description("類別")]
        [Required]
        [MaxLength(30)]
        public string CategoryName { get; set; }

        /// <summary>
        /// 排序用。
        /// </summary>
        public int OrderNo { get; set; }

        public virtual ICollection<MachineType> MachineTypes { get; set; }
    }
}
