﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.Authority;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 部門。
    /// </summary>
    public class Department
    {
        /// <summary>
        /// 部門代號。
        /// </summary>
        [Description("部門代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 部門名稱。
        /// </summary>
        [Description("部門")]
        [MaxLength(12)]
        public string DepartmentName { get; set; }

        /// <summary>
        /// 排序用。
        /// </summary>
        public int OrderNo { get; set; }

        public virtual ICollection<Employee> Employees { get; set; }
        public virtual ICollection<DepartmentAuthorization> DepartmentAuthorizations { get; set; }
    }
}
