﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 廠牌。
    /// </summary>
    public class MachineBrand
    {
        /// <summary>
        /// 廠牌代號。
        /// </summary>
        [Description("廠牌代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 廠牌。
        /// </summary>
        [Description("廠牌")]
        [MaxLength(30)]
        public string BrandName { get; set; }

        /// <summary>
        /// 排序用。
        /// </summary>
        public int OrderNo { get; set; }

        public virtual ICollection<Machine> Machines { get; set; } // 廠牌
    }
}
