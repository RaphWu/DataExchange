﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 資產編號。
    /// </summary>
    public class MachineAssetCode
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 資產編號。
        /// </summary>
        [Description("資產編號")]
        [MaxLength(20)]
        public string AssetCode { get; set; }

        /// <summary>
        /// 機台。
        /// </summary>
        public virtual Machine Machine { get; set; }
        public int? MachineId { get; set; } // FK
    }
}
