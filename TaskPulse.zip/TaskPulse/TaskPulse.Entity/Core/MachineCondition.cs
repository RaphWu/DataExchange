﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台狀態列表。
    /// </summary>
    public class MachineCondition
    {
        /// <summary>
        /// 機台狀態代號。
        /// </summary>
        [Description("狀態代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台狀態。
        /// </summary>
        [Description("狀態")]
        [Required]
        public string Condition { get; set; }

        /// <summary>
        /// 排序用。
        /// </summary>
        public int OrderNo { get; set; }

        public virtual ICollection<Machine> Machines { get; set; }
    }
}
