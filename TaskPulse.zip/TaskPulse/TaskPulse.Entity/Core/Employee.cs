﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 員工清單。
    /// </summary>
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 工號。
        /// </summary>
        [Description("工號")]
        [Required, MaxLength(6)]
        [Index(IsUnique = true)]
        public string EmployeeId { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        [Description("姓名")]
        [Required]
        [MaxLength(20)]
        public string EmployeeName { get; set; }

        /// <summary>
        /// 密碼。
        /// </summary>
        [Description("密碼")]
        [Required, MaxLength(256)]
        public string PasswordHash { get; set; }

        /// <summary>
        /// 部門。
        /// </summary>
        [Description("部門")]
        public virtual Department Department { get; set; }
        public int? DepartmentId { get; set; } // FK
        [NotMapped]
        public string DepartmentName => Department?.DepartmentName ?? string.Empty;

        /// <summary>
        /// 職稱。
        /// </summary>
        [Description("職稱")]
        public virtual Title Title { get; set; }
        public int? TitleId { get; set; } // FK
        [NotMapped]
        public string TitleName => Title?.TitleName ?? string.Empty;

        /// <summary>
        /// 電子郵件。
        /// </summary>
        [Description("EMail")]
        public string EMail { get; set; }

        /// <summary>
        /// 是否為維護工程師。
        /// </summary>
        [Description("維護工程師")]
        public bool IsEngineer { get; set; } = false;
        [NotMapped]
        public string IsEngineerYes => IsEngineer ? "是" : "";

        /// <summary>
        /// 是否仍在職。
        /// </summary>
        [Description("在職")]
        public bool OnStaff { get; set; } = true;
        [NotMapped]
        public string OnStaffString => OnStaff ? "在職" : "離職";

        //[MaxLength(512)]
        //public string SensitiveData { get; set; } // AES

        public virtual ICollection<TaskOrder> CreaterTaskOrders { get; set; }
        public virtual ICollection<TaskOrder> EngineerTaskOrders { get; set; }
        public virtual ICollection<TaskOrder> FeedbackEmployeeTaskOrders { get; set; }
        public virtual ICollection<Permission> Permissions { get; set; }
        public virtual ICollection<UserGroup> UserGroups { get; set; }
    }
}
