﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 工站。
    /// </summary>
    public class Workstation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 工站名稱。
        /// </summary>
        [Description("工站")]
        [MaxLength(20)]
        public string WorkstationName { get; set; }

        /// <summary>
        /// 機種。
        /// </summary>
        [Description("機種")]
        public virtual Model Model { get; set; }
        [Required]
        public int ModelId { get; set; } // FK

        [NotMapped]
        public string FullWorkstationName
        {
            get
            {
                string ret = "";
                bool hasWorkstation = !string.IsNullOrWhiteSpace(WorkstationName);

                if (Model != null)
                {
                    ret = Model?.ModelName;
                    if (hasWorkstation)
                        ret += string.Concat(", ");
                }
                if (hasWorkstation)
                    ret += WorkstationName;
                return ret;
            }
        }

        /// <summary>
        /// 排序用。
        /// </summary>
        public int OrderNo { get; set; }

        public virtual ICollection<Machine> Machines { get; set; }
        public virtual ICollection<TaskOrder> TaskOrders { get; set; }
    }
}
