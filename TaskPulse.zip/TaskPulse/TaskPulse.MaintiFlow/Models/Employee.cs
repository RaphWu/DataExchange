﻿namespace TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 員工清單。
    /// </summary>
    public class Employee
    {
        /// <summary>
        /// 工號。
        /// </summary>
        public string EmployeeNo { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        public string Name { get; set; }
    }
}
