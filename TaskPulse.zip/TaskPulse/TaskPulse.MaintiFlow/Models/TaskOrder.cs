﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護工單。
    /// </summary>
    public class TaskOrder
    {
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        [Key]
        [Required]
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 序號。
        /// </summary>
        [Required]
        public int SerNo { get; set; }

        /// <summary>
        /// 建檔人員。
        /// </summary>
        [Required]
        public string CreatorId { get; set; }

        /// <summary>
        /// 建檔日期。
        /// </summary>
        [Required]
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// 目前狀態。
        /// </summary>
        [Required]
        public Status Status { get; set; }

        /// <summary>
        /// 維護單位。
        /// </summary>
        public int MaintenanceUnitId { get; set; }

        /// <summary>
        /// 機台編號。
        /// </summary>
        public ICollection<string> MachineId { get; set; }

        /// <summary>
        /// 接收時間。
        /// </summary>
        [Required]
        public DateTime AcceptedTime { get; set; }

        /// <summary>
        /// 維修開始時間。
        /// </summary>
        public DateTime? RepairStarted { get; set; }

        /// <summary>
        /// 完成時間。
        /// </summary>
        public DateTime? RepairCompleted { get; set; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        public string RepairDurationString { get; set; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [NotMapped]
        public TimeSpan? RepairDuration
        {
            get => TimeSpan.Parse(RepairDurationString);
            set => RepairDurationString = value.ToString();
        }

        /// <summary>
        /// 停動開始。
        /// </summary>
        public DateTime? OutageStarted { get; set; }

        /// <summary>
        /// 停動結束。
        /// </summary>
        public DateTime? OutageEnded { get; set; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        public string OutageDurationString { get; set; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [NotMapped]
        public TimeSpan? OutageDuration
        {
            get => TimeSpan.Parse(OutageDurationString);
            set => OutageDurationString = value.ToString();
        }

        /// <summary>
        /// 責任歸屬。
        /// </summary>
        public string Responsible { get; set; }

        /// <summary>
        /// 機種。
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        /// 工站。
        /// </summary>
        public string Workstation { get; set; }

        /// <summary>
        /// 問題描述。
        /// </summary>
        public string IssueDescription { get; set; }

        /// <summary>
        /// 維護內容。
        /// </summary>
        public string Details { get; set; }

        /// <summary>
        /// 需求單位回覆。
        /// </summary>
        public string RequestingUnitResponse { get; set; }

        /********************
         * navigation property
         ********************/
        /// <summary>
        /// 建檔人員。
        /// </summary>
        [ForeignKey(nameof(CreatorId))]
        public virtual Employee Creator { get; set; }

        /// <summary>
        /// 維護單位。
        /// </summary>
        [ForeignKey(nameof(MaintenanceUnitId))]
        public virtual MaintenanceUnit MaintenanceUnit { get; set; }

        /// <summary>
        /// 維護人員。
        /// </summary>
        public virtual ICollection<Employee> MaintenanceEngineer { get; set; }

        /// <summary>
        /// 維護類型。
        /// </summary>
        public virtual IssueCategory IssueCategory { get; set; }

        /// <summary>
        /// 需求單位名稱。
        /// </summary>
        public virtual RequestingUnit RequestingUnit { get; set; }

        /// <summary>
        /// 需求單位人員工號。
        /// </summary>
        public virtual Employee RequestingEmployee { get; set; }
    }
}
