﻿using System.Data.Entity;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 資料庫區。
    /// </summary>
    public class MaintiFlowContext : DbContext
    {
        public MaintiFlowContext() : base("name=MaintiFlowContext")
        {
            //if (System.IO.File.Exists("MaintiFlowDB.db"))
            //    System.IO.File.Delete("MaintiFlowDB.db");

            //Database.SetInitializer(new CreateDatabaseIfNotExists<MaintiFlowContext>());
            //Database.SetInitializer(new DropCreateDatabaseAlways<MaintiFlowContext>());
            //Database.SetInitializer<MaintiFlowContext>(null);
            //Database.CreateIfNotExists();
        }

        public DbSet<TaskOrder> TaskOrders { get; set; }
        public DbSet<MaintenanceUnit> MaintenanceUnits { get; set; }
        public DbSet<RequestingUnit> RequestingUnits { get; set; }
        public DbSet<IssueCategory> IssueCategories { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Status> Statuses { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //var sqliteConnectionInitializer = new SqliteDropCreateDatabaseAlways<MaintiFlowContext>(modelBuilder);
            //Database.SetInitializer(sqliteConnectionInitializer);

            //Database.SetInitializer(new MaintiFlowInitializer(modelBuilder));

            modelBuilder.Entity<TaskOrder>()
                .HasMany(t => t.MaintenanceEngineer)
                .WithMany(e => e.TaskOrders)
                .Map(m =>
                {
                    //m.ToTable("TaskOrderEmployees"); // 自訂關聯表名稱
                    m.MapLeftKey("TaskOrderId");
                    m.MapRightKey("EmployeeId");
                });
        }
    }
}
