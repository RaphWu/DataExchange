﻿using System.ComponentModel.DataAnnotations;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 問題分類清單。
    /// </summary>
    public class IssueCategory
    {
        /// <summary>
        /// 問題分類代號。
        /// </summary>
        [Key]
        public int CategoryId { get; set; }

        /// <summary>
        /// 問題分類名稱。
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        public int OrderNo { get; set; }
    }
}
