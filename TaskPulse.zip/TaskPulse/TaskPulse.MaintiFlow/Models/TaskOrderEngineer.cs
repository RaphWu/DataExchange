﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    public class TaskOrderEngineer
    {
        [Key]
        public int Id { get; set; }

        // 外鍵：TaskOrder
        [Required]
        public string TaskOrderNo { get; set; }

        [ForeignKey(nameof(TaskOrderNo))]
        public virtual TaskOrder TaskOrder { get; set; }

        // 外鍵：Employee
        [Required]
        public string EmployeeId { get; set; }

        [ForeignKey(nameof(EmployeeId))]
        public virtual Employee Employee { get; set; }
    }

}
