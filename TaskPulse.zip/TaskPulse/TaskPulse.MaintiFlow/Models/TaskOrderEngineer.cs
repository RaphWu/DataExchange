﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    public class TaskOrderEngineer
    {
        [Key, Column(Order = 0)]
        public string WorkOrderNo { get; set; }
        [ForeignKey(nameof(WorkOrderNo))]
        public virtual TaskOrder TaskOrder { get; set; }

        [Key, Column(Order = 1)]
        public string EmployeeId { get; set; }
        [ForeignKey(nameof(EmployeeId))]
        public virtual Employee Engineer { get; set; }
    }
}
