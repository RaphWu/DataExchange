﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using System.Timers;
using System.Xml.Linq;
using Calin.CSharp.Extensions;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    public class MaintiFlowInitializer : SqliteDropCreateDatabaseAlways<MaintiFlowContext>
    {
        public MaintiFlowInitializer(DbModelBuilder modelBuilder) : base(modelBuilder)
        {
        }

        protected override void Seed(MaintiFlowContext context)
        {
            var st = context.Set<Status>();
            st.Add(new Status() { StatusId = 1, OrderNo = 1, StatusName = "待處理" });
            st.Add(new Status() { StatusId = 2, OrderNo = 2, StatusName = "處理中" });
            st.Add(new Status() { StatusId = 3, OrderNo = 3, StatusName = "完成" });

            var mu = context.Set<MaintenanceUnit>();
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 1, OrderNo = 1, Name = "工具設計" });
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 2, OrderNo = 2, Name = "維護-維小" });
            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 3, OrderNo = 3, Name = "維護-製一" });

            var ic = context.Set<IssueCategory>();
            ic.Add(new IssueCategory() { CategoryId = 1, OrderNo = 1, CategoryName = "日常維護" });
            ic.Add(new IssueCategory() { CategoryId = 2, OrderNo = 2, CategoryName = "機台保養" });
            ic.Add(new IssueCategory() { CategoryId = 3, OrderNo = 3, CategoryName = "更換零件" });
            ic.Add(new IssueCategory() { CategoryId = 4, OrderNo = 4, CategoryName = "機台改線" });
            ic.Add(new IssueCategory() { CategoryId = 5, OrderNo = 5, CategoryName = "故障中待協助" });
            ic.Add(new IssueCategory() { CategoryId = 6, OrderNo = 6, CategoryName = "異常排除" });
            ic.Add(new IssueCategory() { CategoryId = 7, OrderNo = 7, CategoryName = "設備功能追加" });
            ic.Add(new IssueCategory() { CategoryId = 8, OrderNo = 8, CategoryName = "機台移動" });

            var ru = context.Set<RequestingUnit>();
            ru.Add(new RequestingUnit() { RequestingUnitId = 1, OrderNo = 1, Name = "組立" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 2, OrderNo = 2, Name = "製技" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 3, OrderNo = 3, Name = "RD" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 4, OrderNo = 4, Name = "試作" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 5, OrderNo = 5, Name = "試作開發" });
            ru.Add(new RequestingUnit() { RequestingUnitId = 6, OrderNo = 6, Name = "品管" });

            var ep = context.Set<Employee>();
            ep.Add(new Employee() { EmployeeId = "08001", Name = "蔡孟堅", IsEngineer = true });
            ep.Add(new Employee() { EmployeeId = "08002", Name = "鄭大德", IsEngineer = true });
            ep.Add(new Employee() { EmployeeId = "08003", Name = "李起修", IsEngineer = true });
            ep.Add(new Employee() { EmployeeId = "08004", Name = "葉柏均", IsEngineer = true });
            ep.Add(new Employee() { EmployeeId = "08005", Name = "曾惠鈴", IsEngineer = true });
            ep.Add(new Employee() { EmployeeId = "08006", Name = "蔡素貞" });
            ep.Add(new Employee() { EmployeeId = "08007", Name = "張志榮" });
            ep.Add(new Employee() { EmployeeId = "08008", Name = "賴惠珠" });
            ep.Add(new Employee() { EmployeeId = "08009", Name = "侯倩玉" });
            ep.Add(new Employee() { EmployeeId = "08010", Name = "李雅婷" });
            ep.Add(new Employee() { EmployeeId = "08011", Name = "彭紹軒" });
            ep.Add(new Employee() { EmployeeId = "08012", Name = "黎氏鳳" });
            ep.Add(new Employee() { EmployeeId = "08013", Name = "阮碧幸" });
            ep.Add(new Employee() { EmployeeId = "08014", Name = "盧海燕" });
            ep.Add(new Employee() { EmployeeId = "08015", Name = "余沂霈" });
            ep.Add(new Employee() { EmployeeId = "08016", Name = "楊瓊瑛" });
            ep.Add(new Employee() { EmployeeId = "08017", Name = "陳寶琴" });
            ep.Add(new Employee() { EmployeeId = "08018", Name = "劉名峻" });
            ep.Add(new Employee() { EmployeeId = "08019", Name = "黃琪雯" });
            ep.Add(new Employee() { EmployeeId = "08020", Name = "黃姿蓉" });
            ep.Add(new Employee() { EmployeeId = "08021", Name = "林承翰" });
            ep.Add(new Employee() { EmployeeId = "08022", Name = "雷舒涵" });
            ep.Add(new Employee() { EmployeeId = "08023", Name = "黃嘉惠" });
            ep.Add(new Employee() { EmployeeId = "08024", Name = "蔡素真" });
            ep.Add(new Employee() { EmployeeId = "08025", Name = "黃玉紅" });
            ep.Add(new Employee() { EmployeeId = "08026", Name = "許凱婷" });
            ep.Add(new Employee() { EmployeeId = "08027", Name = "林昆達" });
            ep.Add(new Employee() { EmployeeId = "08028", Name = "晉玉樹" });
            ep.Add(new Employee() { EmployeeId = "08029", Name = "謝定傑", IsEngineer = true });

            context.SaveChanges();

#if DEBUG

            try
            {
                int recCount = 1;
                using (var sr = new StreamReader("設備維修履歷(Sample).txt", Encoding.Default))
                {
                    string[] sList;

                    var tos = context.Set<TaskOrder>();

                    try
                    {
                        while (sr.Peek() != -1)
                        {
                            string[] data = sr.ReadLine().Split('\t');

                            if (recCount > 1) // 去掉標題
                            {
                                var to = new TaskOrder();
                                to.OrderNo = int.Parse(data[0]);
                                to.WorkOrderNo = data[1].Trim();

                                if (!string.IsNullOrWhiteSpace(data[2]))
                                {
                                    string name = data[2].Trim();
                                    to.Creator = ep.FirstOrDefault(x => x.Name == name);
                                }
                                else
                                {
                                    to.Creator = null;
                                }

                                to.CreationDate = DateTime.Parse(data[3]);

                                if (!string.IsNullOrWhiteSpace(data[4]))
                                {
                                    string name = data[4].Trim();
                                    to.MaintenanceUnit = mu.FirstOrDefault(x => x.Name == name);
                                }
                                else
                                {
                                    to.MaintenanceUnit = null;
                                }

                                sList = data[5].Split('/');
                                List<Employee> me = new List<Employee>();
                                foreach (var d5 in sList)
                                    me.Add(ep.FirstOrDefault(x => x.Name == d5));
                                to.MaintenanceEngineer = me;

                                var mi = data[6].Split('_');
                                to.MachineId = mi;
                                to.AcceptedTime = DateTime.Parse(string.Concat(data[3], " ", data[7]));

                                if (DateTime.TryParse(string.Concat(data[3], " ", data[8]), out DateTime rs))
                                    to.RepairStarted = rs;
                                else
                                    to.RepairStarted = null;

                                if (DateTime.TryParse(string.Concat(data[3], " ", data[9]), out DateTime rc))
                                    to.RepairCompleted = rc;
                                else
                                    to.RepairCompleted = null;

                                if (int.TryParse(data[10], out int rd))
                                    to.RepairDuration = TimeSpan.FromMinutes(rd);
                                else
                                {
                                    if (rs == null || rc == null)
                                        to.RepairDuration = null;
                                    else
                                        to.RepairDuration = rc - rs;
                                }

                                if (DateTime.TryParse(string.Concat(data[3], " ", data[11]), out DateTime os))
                                    to.OutageStarted = os;
                                else
                                    to.OutageStarted = null;

                                if (DateTime.TryParse(string.Concat(data[3], " ", data[12]), out DateTime oe))
                                    to.OutageEnded = oe;
                                else
                                    to.OutageEnded = null;

                                if (int.TryParse(data[13], out int od))
                                    to.OutageDuration = TimeSpan.FromMinutes(od);
                                else
                                {
                                    if (rs == null || rc == null)
                                        to.OutageDuration = null;
                                    else
                                        to.OutageDuration = oe - os;
                                }

                                to.Model = data[15].Trim();
                                to.Workstation = data[16].Trim().Split(',');

                                if (!string.IsNullOrWhiteSpace(data[17]))
                                {
                                    string name = data[17].Trim();
                                    to.IssueCategory = ic.FirstOrDefault(x => x.CategoryName == name);
                                }
                                else
                                {
                                    to.IssueCategory = null;
                                }

                                to.IssueDescription = data[18].Trim();
                                to.Details = data[19].Trim();

                                if (!string.IsNullOrWhiteSpace(data[20]))
                                {
                                    string name = data[20].Trim();
                                    to.RequestingUnit = ru.FirstOrDefault(x => x.Name == name);
                                }
                                else
                                {
                                    to.RequestingUnit = null;
                                }

                                if (!string.IsNullOrWhiteSpace(data[21]))
                                {
                                    string name = data[21].Trim();
                                    to.RequestingEmployee = ep.FirstOrDefault(x => x.Name == name);
                                }
                                else
                                {
                                    to.RequestingEmployee = null;
                                }

                                if (!string.IsNullOrWhiteSpace(data[22]))
                                {
                                    string name = data[22].Trim();
                                    to.Status = st.FirstOrDefault(x => x.StatusName == name);
                                }
                                if (to.Status == null)
                                    to.Status = st.FirstOrDefault(x => x.StatusName == "待處理");

                                to.RequestingUnitResponse = data[23].Trim();

                                tos.Add(to);
                                context.SaveChanges();
                            }

                            recCount++;
                        }

                    }
                    catch (DbEntityValidationException ex)
                    {
                        foreach (var eve in ex.EntityValidationErrors)
                        {
                            Console.WriteLine($"Entity of type '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

                            foreach (var ve in eve.ValidationErrors)
                            {
                                Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                            }
                        }

                        throw; // 若你要繼續丟出錯誤
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

#endif

            base.Seed(context);
        }
    }
}
