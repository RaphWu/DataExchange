﻿using System;
using System.Collections.Generic;
using System.Data;

namespace TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 資料庫區。
    /// </summary>
    public static class MainDB
    {
        // 主表
        public static DataTable history = new DataTable();

        // 參照表
        public static DataTable allCompanyEmployees = new DataTable();
        public static DataTable maintenanceEngineers = new DataTable();
        public static DataTable maintenanceUnits = new DataTable();
        public static DataTable maintenanceTypes = new DataTable();
        public static DataTable issueCategories = new DataTable();
        public static DataTable requestingUnits = new DataTable();
        public static DataTable confirmations = new DataTable();

        // 中介表
        public static List<Historty_MaintenanceEmployee> historty_MaintenanceEmployees = new List<Historty_MaintenanceEmployee>();
        public static List<History_IssueCategory> history_IssueCategories = new List<History_IssueCategory>();

        public static void Init(DataTable dt)
        {
            _ = dt.Columns.Add(nameof(History.SerNo), typeof(int));
            _ = dt.Columns.Add(nameof(History.WorkOrderNo), typeof(string));
            _ = dt.Columns.Add(nameof(History.Creator), typeof(string));
            _ = dt.Columns.Add(nameof(History.Date), typeof(DateTime));
            _ = dt.Columns.Add(nameof(History.MaintenanceUnit), typeof(int));
            //_ = dt.Columns.Add(nameof(HistoryDisplay.MaintenanceEmployee), typeof(string));
            _ = dt.Columns.Add(nameof(History.MachineNo), typeof(string));
            _ = dt.Columns.Add(nameof(History.AcceptedTime), typeof(DateTime));
            _ = dt.Columns.Add(nameof(History.RepairStarted), typeof(DateTime));
            _ = dt.Columns.Add(nameof(History.CompletedTime), typeof(DateTime));
            _ = dt.Columns.Add(nameof(History.RepairDuration), typeof(TimeSpan));
            _ = dt.Columns.Add(nameof(History.OutageStarted), typeof(DateTime));
            _ = dt.Columns.Add(nameof(History.OutageEnded), typeof(DateTime));
            _ = dt.Columns.Add(nameof(History.OutageDuration), typeof(TimeSpan));
            _ = dt.Columns.Add(nameof(History.Responsible), typeof(string));
            _ = dt.Columns.Add(nameof(History.Model), typeof(string));
            _ = dt.Columns.Add(nameof(History.Workstation), typeof(string));
            //_ = dt.Columns.Add(nameof(HistoryDisplay.IssueCategory), typeof(string));
            _ = dt.Columns.Add(nameof(History.IssueDescription), typeof(string));
            _ = dt.Columns.Add(nameof(History.Details), typeof(string));
            _ = dt.Columns.Add(nameof(History.RequestingUnit), typeof(int));
            _ = dt.Columns.Add(nameof(History.RequestingEmployee), typeof(string));
            _ = dt.Columns.Add(nameof(History.RequestingUnitConfirmation), typeof(int));
            _ = dt.Columns.Add(nameof(History.RequestingUnitResponse), typeof(string));
        }
    }
}
