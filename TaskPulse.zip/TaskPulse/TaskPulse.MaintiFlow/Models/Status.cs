﻿using System.ComponentModel.DataAnnotations;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 目前狀態。
    /// </summary>
    public class Status
    {
        /// <summary>
        /// 狀態ID。
        /// </summary>
        [Key]
        public int StatusId { get; set; }

        /// <summary>
        /// 狀態名稱。
        /// </summary>
        public string StatusName { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        public int OrderNo { get; set; }
    }
}
