﻿using System;

namespace TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 設備維護履歷主資料表。
    /// </summary>
    public class History
    {
        /// <summary>
        /// 序號。
        /// </summary>
        public int SerNo { get; set; }

        /// <summary>
        /// 維護工單編號。
        /// </summary>
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 建檔人員工號。
        /// </summary>
        public string Creator { get; set; }

        /// <summary>
        /// 建檔日期。
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// 維護單位。
        /// </summary>
        public int MaintenanceUnit { get; set; }

        // MaintenanceEmployee	維護人員

        /// <summary>
        /// 機台編號。
        /// </summary>
        public string MachineNo { get; set; }

        /// <summary>
        /// 接收時間。
        /// </summary>
        public DateTime AcceptedTime { get; set; }

        /// <summary>
        /// 維修開始時間。
        /// </summary>
        public DateTime? RepairStarted { get; set; }

        /// <summary>
        /// 完成時間。
        /// </summary>
        public DateTime? CompletedTime { get; set; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        public TimeSpan? RepairDuration { get; set; }

        /// <summary>
        /// 停動開始。
        /// </summary>
        public DateTime? OutageStarted { get; set; }

        /// <summary>
        /// 停動結束。
        /// </summary>
        public DateTime? OutageEnded { get; set; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        public TimeSpan? OutageDuration { get; set; }

        /// <summary>
        /// 責任歸屬。
        /// </summary>
        public string Responsible { get; set; }

        /// <summary>
        /// 機種。
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        /// 工站。
        /// </summary>
        public string Workstation { get; set; }

        // IssueCategory 維護類型

        /// <summary>
        /// 問題描述。
        /// </summary>
        public string IssueDescription { get; set; }

        /// <summary>
        /// 維護內容。
        /// </summary>
        public string Details { get; set; }

        /// <summary>
        /// 需求單位名稱。
        /// </summary>
        public int RequestingUnit { get; set; }

        /// <summary>
        /// 需求單位人員工號。
        /// </summary>
        public string RequestingEmployee { get; set; }

        /// <summary>
        /// 需求單位確認。
        /// </summary>
        public int RequestingUnitConfirmation { get; set; }

        /// <summary>
        /// 需求單位回覆。
        /// </summary>
        public string RequestingUnitResponse { get; set; }
    }
}
