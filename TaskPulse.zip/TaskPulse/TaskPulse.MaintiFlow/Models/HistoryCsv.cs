﻿namespace TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 設備維護履歷主資料表 (顯示用)。
    /// </summary>
    public class HistoryDisplay : History
    {
        /// <summary>
        /// 維護人員。
        /// </summary>
        public string MaintenanceEmployee { get; set; }

        /// <summary>
        /// 問題分類。
        /// </summary>
        public int IssueCategory { get; set; }
    }
}
