﻿using System.ComponentModel.DataAnnotations;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護單位清單。
    /// </summary>
    public class MaintenanceUnit
    {
        /// <summary>
        /// 單位代號。
        /// </summary>
        [Key]
        public int MaintenanceUnitId { get; set; }

        /// <summary>
        /// 單位名稱。
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        public int OrderNo { get; set; }
    }
}
