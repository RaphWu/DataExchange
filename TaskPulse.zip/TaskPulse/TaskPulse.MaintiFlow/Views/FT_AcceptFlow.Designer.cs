﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FT_AcceptFlow
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_Actions = new System.Windows.Forms.Panel();
            this.Button_OK = new Sunny.UI.UISymbolButton();
            this.Button_Cancel = new Sunny.UI.UISymbolButton();
            this.ADGV = new Zuby.ADGV.AdvancedDataGridView();
            this.panel_Actions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ADGV)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Actions
            // 
            this.panel_Actions.Controls.Add(this.Button_OK);
            this.panel_Actions.Controls.Add(this.Button_Cancel);
            this.panel_Actions.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_Actions.Location = new System.Drawing.Point(3, 511);
            this.panel_Actions.Name = "panel_Actions";
            this.panel_Actions.Size = new System.Drawing.Size(935, 70);
            this.panel_Actions.TabIndex = 0;
            // 
            // Button_OK
            // 
            this.Button_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_OK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_OK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_OK.Location = new System.Drawing.Point(660, 16);
            this.Button_OK.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_OK.Name = "Button_OK";
            this.Button_OK.Radius = 10;
            this.Button_OK.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_OK.Size = new System.Drawing.Size(110, 35);
            this.Button_OK.TabIndex = 5;
            this.Button_OK.Text = "確定";
            this.Button_OK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_OK.Click += new System.EventHandler(this.Button_OK_Click);
            // 
            // Button_Cancel
            // 
            this.Button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Button_Cancel.Location = new System.Drawing.Point(790, 16);
            this.Button_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Cancel.Name = "Button_Cancel";
            this.Button_Cancel.Radius = 10;
            this.Button_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_Cancel.Size = new System.Drawing.Size(110, 35);
            this.Button_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.Button_Cancel.Symbol = 361453;
            this.Button_Cancel.TabIndex = 4;
            this.Button_Cancel.Text = "取消";
            this.Button_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Cancel.Click += new System.EventHandler(this.Button_Cancel_Click);
            // 
            // ADGV
            // 
            this.ADGV.AllowUserToAddRows = false;
            this.ADGV.AllowUserToDeleteRows = false;
            this.ADGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ADGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ADGV.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ADGV.FilterAndSortEnabled = true;
            this.ADGV.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.ADGV.Location = new System.Drawing.Point(3, 40);
            this.ADGV.MaxFilterButtonImageHeight = 23;
            this.ADGV.Name = "ADGV";
            this.ADGV.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ADGV.RowTemplate.Height = 24;
            this.ADGV.Size = new System.Drawing.Size(935, 471);
            this.ADGV.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.ADGV.TabIndex = 1;
            this.ADGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ADGV_CellContentClick);
            this.ADGV.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.ADGV_CellValueChanged);
            this.ADGV.CurrentCellDirtyStateChanged += new System.EventHandler(this.ADGV_CurrentCellDirtyStateChanged);
            this.ADGV.SelectionChanged += new System.EventHandler(this.ADGV_SelectionChanged);
            // 
            // FT_AcceptFlow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(941, 584);
            this.Controls.Add(this.ADGV);
            this.Controls.Add(this.panel_Actions);
            this.EscClose = true;
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FT_AcceptFlow";
            this.Padding = new System.Windows.Forms.Padding(3, 40, 3, 3);
            this.Resizable = true;
            this.ShowDragStretch = true;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "FT_OrderAccepted";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.ZoomScaleRect = new System.Drawing.Rectangle(19, 19, 814, 584);
            this.Shown += new System.EventHandler(this.FT_AcceptFlow_Shown);
            this.panel_Actions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ADGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Actions;
        private Sunny.UI.UISymbolButton Button_OK;
        private Sunny.UI.UISymbolButton Button_Cancel;
        private Zuby.ADGV.AdvancedDataGridView ADGV;
    }
}
