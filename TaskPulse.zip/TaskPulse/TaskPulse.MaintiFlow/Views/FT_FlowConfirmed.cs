﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Models;
using MailKit.Search;
using Sunny.UI;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_FlowConfirmed : UIForm
    {
        #region fields

        private readonly ILifetimeScope _rootScope;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly IMail _mail;
        private readonly CurrentUserContext _user;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;

        #endregion fields

        public TaskOrder TaskOrder { get; set; }

        public FT_FlowConfirmed(ILifetimeScope lifetimeScope,
                                CoreContext coreContext,
                                ICore core,
                                IMail mail,
                                CurrentUserContext currentUserContext,
                                MaintiFlowData maintiFlowData,
                                CoreData coreData)
        {
            InitializeComponent();
            _rootScope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _mail = mail;
            _user = currentUserContext;
            _flowData = maintiFlowData;
            _coreData = coreData;

            CommonStyles.SetButton(btnCompleted);
            CommonStyles.SetButton(btnReturn);
            CommonStyles.SetButton(btnCancel, isCancel: true);
        }

        private void FT_FlowConfirmed_Load(object sender, System.EventArgs e)
        {
            Label_WorkOrderNo.Text = PropertyText.Title.WorkOrderNo;
            Label_Creator.Text = PropertyText.Title.Creator;
            Label_CreationDate.Text = PropertyText.Title.CreationDate;
            Label_MachineList.Text = PropertyText.Title.Machine;
            Label_ModelWorkstation.Text = PropertyText.Title.ModelWorkstationName;
            Label_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
            Label_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
            Label_Engineers.Text = PropertyText.Title.Engineer;
            Label_IssueCategory.Text = PropertyText.Title.IssueCategory;
            Label_IssueDescription.Text = PropertyText.Title.IssueDescription;
            Label_Details.Text = PropertyText.Title.Details;
            Label_RepairStarted.Text = PropertyText.Title.RepairStarted;
            Label_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
            Label_RepairDuration.Text = PropertyText.Title.RepairDuration;
            Label_OutageStarted.Text = PropertyText.Title.OutageStarted;
            Label_OutageEnded.Text = PropertyText.Title.OutageEnded;
            Label_OutageDuration.Text = PropertyText.Title.OutageDuration;
            Label_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
            Label_FeedbackEmployee.Text = PropertyText.Title.FeedbackEmployee;
            Label_Feedback.Text = PropertyText.Title.Feedback;

            var orders = _flowData.TaskOrders
                .Where(ts => (_user.IsAdmin || ts.EngineerList.ContainsKey(_user.UserId)) && ts.Status == FlowStatus.Pending)
                .Select(ts => new ListViewModel()
                {
                    Id = ts.Id,
                    IdString = ts.WorkOrderNo,
                    Name = $"{ts.WorkOrderNo}: {ts.FullMachineName}",
                })
                .ToList();
            OrderList.DataSource = orders;
            OrderList.DisplayMember = "Name";
            OrderList.ValueMember = "Id";
        }

        public void LoadData(TaskOrder taskOrder)
        {
            TaskOrder = taskOrder;

            if (taskOrder == null)
                return;

            WorkOrderNo.Text = TaskOrder.WorkOrderNo;
            Creator.Text = TaskOrder.CreatorName;
            CreationDate.Text = TaskOrder.CreationDateString;
            MachineList.Text = TaskOrder.MachineName;
            ModelWorkstation.Text = TaskOrder.ModelWorkstationName;
            AcceptedTime.Text = TaskOrder.AcceptedTimeString;
            MaintenanceUnit.Text = TaskOrder.MaintenanceUnitString;
            Engineers.Text = TaskOrder.EngineerString;
            IssueCategory.Text = TaskOrder.IssueCategoryString;
            IssueDescription.Text = TaskOrder.IssueDescription;
            Details.Text = TaskOrder.Details;
            RepairStarted.Text = TaskOrder.RepairStartedString;
            RepairCompleted.Text = TaskOrder.RepairCompletedString;
            RepairDuration.Text = TaskOrder.RepairDurationString;
            OutageStarted.Text = TaskOrder.OutageStartedString;
            OutageEnded.Text = TaskOrder.OutageEndedString;
            OutageDuration.Text = TaskOrder.OutageDurationString;
            RequestingUnit.Text = TaskOrder.RequestingUnitString;
            FeedbackEmployee.Text = TaskOrder.FeedbackEmployeeString;
            Feedback.Text = TaskOrder.Feedback;
        }

        private void OrderList_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (OrderList.SelectedValue is int selId)
                LoadData(_flowData.TaskOrders
                    .FirstOrDefault(to => to.Id == selId));
        }

        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
