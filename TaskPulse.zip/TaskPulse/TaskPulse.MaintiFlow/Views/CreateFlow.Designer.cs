﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class CreateFlow
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_IssueDescription = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UIDatetimePicker();
            this.Label_OutageStarted = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.Label_MachineList = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UIComboBox();
            this.Label_Creator = new Sunny.UI.UILabel();
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Button_Clear = new Sunny.UI.UISymbolButton();
            this.Button_OK = new Sunny.UI.UISymbolButton();
            this.Button_Cancel = new Sunny.UI.UISymbolButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.IssueDescription = new Sunny.UI.UIRichTextBox();
            this.RequestingUnit = new Sunny.UI.UIComboBox();
            this.Label_RequestingUnit = new Sunny.UI.UILabel();
            this.TLP.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label_IssueDescription
            // 
            this.Label_IssueDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueDescription.Location = new System.Drawing.Point(16, 170);
            this.Label_IssueDescription.Name = "Label_IssueDescription";
            this.Label_IssueDescription.Size = new System.Drawing.Size(80, 29);
            this.Label_IssueDescription.TabIndex = 37;
            this.Label_IssueDescription.Text = "Issue";
            this.Label_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.DateFormat = "yyyy-MM-dd HH:mm";
            this.OutageStarted.FillColor = System.Drawing.Color.White;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.Location = new System.Drawing.Point(105, 131);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MaxLength = 16;
            this.OutageStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.OutageStarted.Size = new System.Drawing.Size(255, 29);
            this.OutageStarted.SymbolDropDown = 61555;
            this.OutageStarted.SymbolNormal = 61555;
            this.OutageStarted.SymbolSize = 24;
            this.OutageStarted.TabIndex = 35;
            this.OutageStarted.Text = "2025-10-13 10:39";
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.OutageStarted.Value = new System.DateTime(2025, 10, 13, 10, 39, 6, 671);
            this.OutageStarted.Watermark = "";
            // 
            // Label_OutageStarted
            // 
            this.Label_OutageStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageStarted.Location = new System.Drawing.Point(16, 131);
            this.Label_OutageStarted.Name = "Label_OutageStarted";
            this.Label_OutageStarted.Size = new System.Drawing.Size(80, 29);
            this.Label_OutageStarted.TabIndex = 34;
            this.Label_OutageStarted.Text = "Outage";
            this.Label_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.Location = new System.Drawing.Point(105, 92);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ShowButton = true;
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(255, 29);
            this.MachineList.TabIndex = 29;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            this.MachineList.ButtonClick += new System.EventHandler(this.MachineId_ButtonClick);
            // 
            // Label_MachineList
            // 
            this.Label_MachineList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.Label_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MachineList.Location = new System.Drawing.Point(16, 92);
            this.Label_MachineList.Name = "Label_MachineList";
            this.Label_MachineList.Size = new System.Drawing.Size(80, 29);
            this.Label_MachineList.TabIndex = 28;
            this.Label_MachineList.Text = "Machine";
            this.Label_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Creator
            // 
            this.Creator.DataSource = null;
            this.Creator.FillColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Creator.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Creator.Location = new System.Drawing.Point(105, 53);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MaxDropDownItems = 12;
            this.Creator.MinimumSize = new System.Drawing.Size(63, 0);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Creator.ShowFilter = true;
            this.Creator.Size = new System.Drawing.Size(255, 29);
            this.Creator.SymbolSize = 24;
            this.Creator.TabIndex = 27;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // Label_Creator
            // 
            this.Label_Creator.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Creator.BackColor = System.Drawing.Color.Transparent;
            this.Label_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Creator.Location = new System.Drawing.Point(16, 53);
            this.Label_Creator.Name = "Label_Creator";
            this.Label_Creator.Size = new System.Drawing.Size(80, 29);
            this.Label_Creator.TabIndex = 26;
            this.Label_Creator.Text = "Creator";
            this.Label_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 1;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.panel1, 0, 1);
            this.TLP.Controls.Add(this.panel2, 0, 0);
            this.TLP.Location = new System.Drawing.Point(3, 40);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 2;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.TLP.Size = new System.Drawing.Size(385, 412);
            this.TLP.TabIndex = 38;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Button_Clear);
            this.panel1.Controls.Add(this.Button_OK);
            this.panel1.Controls.Add(this.Button_Cancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(67, 305);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(315, 104);
            this.panel1.TabIndex = 0;
            // 
            // Button_Clear
            // 
            this.Button_Clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Clear.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Clear.Location = new System.Drawing.Point(181, 53);
            this.Button_Clear.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Radius = 10;
            this.Button_Clear.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_Clear.Size = new System.Drawing.Size(110, 35);
            this.Button_Clear.Symbol = 362746;
            this.Button_Clear.TabIndex = 4;
            this.Button_Clear.Text = "全部清除";
            this.Button_Clear.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Button_OK
            // 
            this.Button_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_OK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_OK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_OK.Location = new System.Drawing.Point(51, 12);
            this.Button_OK.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_OK.Name = "Button_OK";
            this.Button_OK.Radius = 10;
            this.Button_OK.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_OK.Size = new System.Drawing.Size(110, 76);
            this.Button_OK.TabIndex = 3;
            this.Button_OK.Text = "確定";
            this.Button_OK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_OK.Click += new System.EventHandler(this.uiButton_OK_Click);
            // 
            // Button_Cancel
            // 
            this.Button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Button_Cancel.Location = new System.Drawing.Point(181, 12);
            this.Button_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Cancel.Name = "Button_Cancel";
            this.Button_Cancel.Radius = 10;
            this.Button_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_Cancel.Size = new System.Drawing.Size(110, 35);
            this.Button_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.Button_Cancel.Symbol = 361453;
            this.Button_Cancel.TabIndex = 2;
            this.Button_Cancel.Text = "取消";
            this.Button_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Cancel.Click += new System.EventHandler(this.uiButton_Cancel_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.AutoSize = true;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.Controls.Add(this.IssueDescription);
            this.panel2.Controls.Add(this.RequestingUnit);
            this.panel2.Controls.Add(this.Label_RequestingUnit);
            this.panel2.Controls.Add(this.Creator);
            this.panel2.Controls.Add(this.Label_Creator);
            this.panel2.Controls.Add(this.Label_IssueDescription);
            this.panel2.Controls.Add(this.Label_MachineList);
            this.panel2.Controls.Add(this.OutageStarted);
            this.panel2.Controls.Add(this.MachineList);
            this.panel2.Controls.Add(this.Label_OutageStarted);
            this.panel2.Location = new System.Drawing.Point(4, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(376, 296);
            this.panel2.TabIndex = 1;
            // 
            // IssueDescription
            // 
            this.IssueDescription.FillColor = System.Drawing.Color.White;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(105, 170);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(2);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(255, 125);
            this.IssueDescription.TabIndex = 38;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // RequestingUnit
            // 
            this.RequestingUnit.DataSource = null;
            this.RequestingUnit.FillColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.RequestingUnit.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.RequestingUnit.Location = new System.Drawing.Point(105, 14);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MaxDropDownItems = 12;
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.RequestingUnit.Name = "RequestingUnit";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.RequestingUnit.ShowFilter = true;
            this.RequestingUnit.Size = new System.Drawing.Size(255, 29);
            this.RequestingUnit.SymbolSize = 24;
            this.RequestingUnit.TabIndex = 29;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // Label_RequestingUnit
            // 
            this.Label_RequestingUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RequestingUnit.BackColor = System.Drawing.Color.Transparent;
            this.Label_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RequestingUnit.Location = new System.Drawing.Point(16, 14);
            this.Label_RequestingUnit.Name = "Label_RequestingUnit";
            this.Label_RequestingUnit.Size = new System.Drawing.Size(80, 29);
            this.Label_RequestingUnit.TabIndex = 28;
            this.Label_RequestingUnit.Text = "Unit";
            this.Label_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreateFlow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(398, 455);
            this.Controls.Add(this.TLP);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateFlow";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 12F);
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 1141, 732);
            this.Load += new System.EventHandler(this.CreateFlow_Load);
            this.Shown += new System.EventHandler(this.CreateFlow_Shown);
            this.TLP.ResumeLayout(false);
            this.TLP.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UILabel Label_IssueDescription;
        private Sunny.UI.UIDatetimePicker OutageStarted;
        private Sunny.UI.UILabel Label_OutageStarted;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UILabel Label_MachineList;
        private Sunny.UI.UIComboBox Creator;
        private Sunny.UI.UILabel Label_Creator;
        private System.Windows.Forms.TableLayoutPanel TLP;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton Button_OK;
        private Sunny.UI.UISymbolButton Button_Cancel;
        private Sunny.UI.UISymbolButton Button_Clear;
        private Sunny.UI.UIComboBox RequestingUnit;
        private Sunny.UI.UILabel Label_RequestingUnit;
        private Sunny.UI.UIRichTextBox IssueDescription;
    }
}
