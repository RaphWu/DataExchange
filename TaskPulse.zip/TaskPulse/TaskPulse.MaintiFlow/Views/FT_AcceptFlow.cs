﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Security.AccessControl;
using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.MaintiFlow;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_AcceptFlow : UIForm
    {
        #region fields

        private DataTable _dt;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        #endregion fields

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// OK 按鈕標題。
        /// </summary>
        public string OkCaption { set => Button_OK.Text = value; }

        /// <summary>
        /// OK 按鈕符號。
        /// </summary>
        public int OkSymbol { set => Button_OK.Symbol = value; }

        /// <summary>
        /// 工單列表。
        /// </summary>
        public List<TaskOrder> Orders { get; set; }

        /// <summary>
        /// 驗證器。
        /// </summary>
        public Func<string, (bool isValid, string errorMessage)> Validator { get; set; } = null;

        /// <summary>
        /// 選取的工單ID。
        /// </summary>
        public TaskOrder SelectedOrder { get; set; }

        public FT_AcceptFlow(FieldName fieldName, FieldTitle fieldTitle)
        {
            InitializeComponent();
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            CommonStyles.SetButton(Button_OK);
            CommonStyles.SetButton(Button_Cancel, accent: true);

            ADGV.SetDoubleBuffered();
            ADGV.MultiSelect = false;
            ADGV.AllowUserToAddRows = false;
            ADGV.AllowUserToDeleteRows = false;
            ADGV.AllowDrop = false;
            ADGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ADGV.RowHeadersWidth = 20;

            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
        }

        private void FT_AcceptFlow_Shown(object sender, EventArgs e)
        {
            _dt=new DataTable();
            _dt.Columns.Add(_fieldName.OrderNo, typeof(int));
            _dt.Columns.Add(_fieldName.WorkOrderNo, typeof(string));
            _dt.Columns.Add(nameof(TaskOrder.CreatorFullName), typeof(string));
            _dt.Columns.Add(_fieldName.CreationDate, typeof(DateTime));
            _dt.Columns.Add(_fieldName.MachineId, typeof(string));
            _dt.Columns.Add(_fieldName.IssueDescription, typeof(string));


            ADGV.Columns.Clear();
            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.OrderNo,
                HeaderText = _fieldTitle.OrderNo,
                ValueType = typeof(int),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.OrderNo], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.WorkOrderNo,
                HeaderText = _fieldTitle.WorkOrderNo,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });
            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.WorkOrderNo], true);
            //ADGV.SetFilterCustomEnabled(ADGV.Columns[_fieldName.WorkOrderNo], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(TaskOrder.CreatorFullName),
                HeaderText = _fieldTitle.Creator,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });
            //ADGV.SetFilterCustomEnabled(ADGV.Columns[nameof(TaskOrder.CreatorFullName)], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.CreationDate,
                HeaderText = _fieldTitle.CreationDate,
                ValueType = typeof(DateTime),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.CreationDate], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.MachineId,
                HeaderText = _fieldTitle.Machine,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });
            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.MachineId], true);
            //ADGV.SetFilterCustomEnabled(ADGV.Columns[_fieldName.MachineId], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.IssueDescription,
                HeaderText = _fieldTitle.IssueDescription,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.IssueDescription], true);
            //ADGV.SetFilterCustomEnabled(ADGV.Columns[_fieldName.IssueDescription], true);

            //pName = $"{_fieldName.Workstation}.{nameof(TaskOrder.Workstation.WorkstationName)}";
            //ADGV.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = _fieldName.Workstation,
            //    HeaderText = _fieldTitle.Workstation,
            //    ValueType = typeof(string),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            //    DefaultCellStyle = new DataGridViewCellStyle()
            //    {
            //        Alignment = DataGridViewContentAlignment.MiddleLeft,
            //    },
            //});
            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[pName], true);


            ADGV.AutoGenerateColumns = false;
            ADGV.AllowUserToResizeColumns = true;
            ADGV.AllowUserToResizeRows = true;
            _dt = Orders.ToDataTable();
            ADGV.DataSource = _dt;

            foreach (DataGridViewColumn col in ADGV.Columns)
            {
                ADGV.SetFilterChecklistEnabled(col, true);
                ADGV.SetFilterCustomEnabled(col, true);
            }
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            SelectedOrder = null;
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void Button_OK_Click(object sender, EventArgs e)
        {

            //if (Validator != null)
            //{
            //    var (isValid, errorMessage) = Validator(input);
            //    if (!isValid)
            //    {
            //        MessageBox.Show(errorMessage, "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        _inputTextBox.Focus();
            //        return;
            //    }
            //}

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is TaskOrder to)
            {
                if (to != null)
                {
                    SelectedOrder = to;
                    return;
                }
            }
            SelectedOrder = null;
        }
    }
}
