﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.MaintiFlow;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_AcceptFlow : UIForm
    {
        #region fields

        private readonly FieldName _fieldName;

        #endregion fields

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// OK 按鈕標題。
        /// </summary>
        public string OkCaption { get; set; }

        /// <summary>
        /// OK 按鈕符號。
        /// </summary>
        public int OkSymbol { get; set; }

        /// <summary>
        /// 工單列表。
        /// </summary>
        public List<TaskOrder> Orders { get; set; }

        /// <summary>
        /// 驗證器。
        /// </summary>
        public Func<string, (bool isValid, string errorMessage)> Validator { get; set; } = null;

        /// <summary>
        /// 選取的工單ID。
        /// </summary>
        public int SelectedOrder { get; set; }

        public FT_AcceptFlow(FieldName fieldName)
        {
            InitializeComponent();
            _fieldName = fieldName;
        }

        private void FT_AcceptFlow_Load(object sender, System.EventArgs e)
        {
            DGV_OrderList.AutoGenerateColumns = false;
            DGV_OrderList.DataSource = Orders;

            DGV_OrderList.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(TaskOrder.WorkOrderNo),
                HeaderText = _fieldName.WorkOrderNo,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            DGV_OrderList.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(TaskOrder.Creator.Name),
                HeaderText = _fieldName.Creator,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            DGV_OrderList.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(TaskOrder.CreationDate),
                HeaderText = _fieldName.CreationDate,
                ValueType = typeof(DateTime),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            DGV_OrderList.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(TaskOrder.Machine.MachineName),
                HeaderText = _fieldName.Machine,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            DGV_OrderList.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(TaskOrder.Workstation.WorkstationName),
                HeaderText = _fieldName.Workstation,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            DGV_OrderList.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(TaskOrder.Workstation.WorkstationName),
                HeaderText = _fieldName.Workstation,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            SelectedOrder = -1;
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void Button_OK_Click(object sender, EventArgs e)
        {

            //if (Validator != null)
            //{
            //    var (isValid, errorMessage) = Validator(input);
            //    if (!isValid)
            //    {
            //        MessageBox.Show(errorMessage, "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        _inputTextBox.Focus();
            //        return;
            //    }
            //}
        }
    }
}
