﻿using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_OrderAccepted : UIPage
    {
        public FT_OrderAccepted()
        {
            InitializeComponent();
        }
    }
}
