﻿using System;
using System.Data.Design;
using System.Windows.Forms;
using System.Xml.Linq;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowPage : UIPage
    {
        private readonly MaintiFlowSummary _flowSummary;

        public MaintiFlowPage(MaintiFlowSummary flowSummary)
        {
            InitializeComponent();

            _flowSummary = flowSummary;

            TreeNode node1, node2;
            int pageIndex;

            pageIndex = (int)PageCode.MaintiFlowSummary;
            node1 = uiNavMenu.CreateNode(PageCode.MaintiFlowSummary.GetDescription(), 559631, 24, pageIndex);
            node1.Tag = pageIndex;

            node1 = uiNavMenu.CreateNode("TEST", 1);
            node1.Tag = pageIndex;
        }

        private void uiNavMenu_MenuItemClick(TreeNode node, NavMenuItem item, int pageIndex)
        {
            switch (Enum.Parse(typeof(PageCode), pageIndex.ToString()))
            {
                case PageCode.MaintiFlowSummary:
                    uiPanel_Nav.Controls.Clear();
                    _flowSummary.Dock = DockStyle.Fill;
                    uiPanel_Nav.Controls.Add(_flowSummary);
                    break;
            }
        }
    }
}
