﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FT_FlowConfirmed
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.RequestingUnitResponse = new Sunny.UI.UITextBox();
            this.uiLabel_RequestingUnitResponse = new Sunny.UI.UILabel();
            this.RequestingEmployee = new Sunny.UI.UITextBox();
            this.uiLabel_RequestingEmployee = new Sunny.UI.UILabel();
            this.uiLabel_RequestingUnit = new Sunny.UI.UILabel();
            this.RequestingUnit = new Sunny.UI.UITextBox();
            this.SuspendLayout();
            // 
            // Response
            // 
            this.RequestingUnitResponse.CanEmpty = true;
            this.RequestingUnitResponse.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnitResponse.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnitResponse.Location = new System.Drawing.Point(160, 108);
            this.RequestingUnitResponse.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnitResponse.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnitResponse.Multiline = true;
            this.RequestingUnitResponse.Name = "Response";
            this.RequestingUnitResponse.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnitResponse.ShowText = false;
            this.RequestingUnitResponse.Size = new System.Drawing.Size(250, 85);
            this.RequestingUnitResponse.TabIndex = 86;
            this.RequestingUnitResponse.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.RequestingUnitResponse.Watermark = "";
            // 
            // uiLabel_RequestingUnitResponse
            // 
            this.uiLabel_RequestingUnitResponse.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RequestingUnitResponse.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingUnitResponse.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingUnitResponse.Location = new System.Drawing.Point(35, 108);
            this.uiLabel_RequestingUnitResponse.Name = "uiLabel_RequestingUnitResponse";
            this.uiLabel_RequestingUnitResponse.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_RequestingUnitResponse.TabIndex = 87;
            this.uiLabel_RequestingUnitResponse.Text = "需求單位回覆";
            this.uiLabel_RequestingUnitResponse.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RequestingEmployee
            // 
            this.RequestingEmployee.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingEmployee.FillDisableColor = System.Drawing.Color.White;
            this.RequestingEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingEmployee.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingEmployee.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RequestingEmployee.Location = new System.Drawing.Point(160, 69);
            this.RequestingEmployee.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingEmployee.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingEmployee.Name = "RequestingEmployee";
            this.RequestingEmployee.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingEmployee.ShowText = false;
            this.RequestingEmployee.Size = new System.Drawing.Size(200, 29);
            this.RequestingEmployee.TabIndex = 84;
            this.RequestingEmployee.TabStop = false;
            this.RequestingEmployee.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingEmployee.Watermark = "";
            // 
            // uiLabel_RequestingEmployee
            // 
            this.uiLabel_RequestingEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingEmployee.Location = new System.Drawing.Point(33, 69);
            this.uiLabel_RequestingEmployee.Name = "uiLabel_RequestingEmployee";
            this.uiLabel_RequestingEmployee.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RequestingEmployee.TabIndex = 85;
            this.uiLabel_RequestingEmployee.Text = "需求單位人員";
            this.uiLabel_RequestingEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RequestingUnit
            // 
            this.uiLabel_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingUnit.Location = new System.Drawing.Point(33, 30);
            this.uiLabel_RequestingUnit.Name = "uiLabel_RequestingUnit";
            this.uiLabel_RequestingUnit.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RequestingUnit.TabIndex = 83;
            this.uiLabel_RequestingUnit.Text = "需求單位名稱";
            this.uiLabel_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RequestingUnit
            // 
            this.RequestingUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnit.FillDisableColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingUnit.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RequestingUnit.Location = new System.Drawing.Point(160, 30);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnit.Name = "RequestingUnit";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnit.ShowText = false;
            this.RequestingUnit.Size = new System.Drawing.Size(200, 29);
            this.RequestingUnit.TabIndex = 82;
            this.RequestingUnit.TabStop = false;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // FT_FlowConfirmed
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(802, 460);
            this.Controls.Add(this.RequestingUnitResponse);
            this.Controls.Add(this.uiLabel_RequestingUnitResponse);
            this.Controls.Add(this.RequestingEmployee);
            this.Controls.Add(this.uiLabel_RequestingEmployee);
            this.Controls.Add(this.uiLabel_RequestingUnit);
            this.Controls.Add(this.RequestingUnit);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "FT_FlowConfirmed";
            this.Text = "FT_FlowConfirmed";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UITextBox RequestingUnitResponse;
        private Sunny.UI.UILabel uiLabel_RequestingUnitResponse;
        private Sunny.UI.UITextBox RequestingEmployee;
        private Sunny.UI.UILabel uiLabel_RequestingEmployee;
        private Sunny.UI.UILabel uiLabel_RequestingUnit;
        private Sunny.UI.UITextBox RequestingUnit;
    }
}
