﻿namespace TaskPulse.MaintiFlow
{
    partial class MaintiFlowControl
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.funcPanel = new System.Windows.Forms.TableLayoutPanel();
            this.adgv = new Zuby.ADGV.AdvancedDataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).BeginInit();
            this.SuspendLayout();
            // 
            // funcPanel
            // 
            this.funcPanel.ColumnCount = 2;
            this.funcPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.funcPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.funcPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.funcPanel.Location = new System.Drawing.Point(0, 0);
            this.funcPanel.Name = "funcPanel";
            this.funcPanel.RowCount = 2;
            this.funcPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.funcPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.funcPanel.Size = new System.Drawing.Size(1060, 104);
            this.funcPanel.TabIndex = 0;
            // 
            // adgv
            // 
            this.adgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adgv.FilterAndSortEnabled = true;
            this.adgv.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.Location = new System.Drawing.Point(0, 104);
            this.adgv.MaxFilterButtonImageHeight = 23;
            this.adgv.Name = "adgv";
            this.adgv.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adgv.RowTemplate.Height = 24;
            this.adgv.Size = new System.Drawing.Size(1060, 509);
            this.adgv.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.TabIndex = 1;
            // 
            // MaintiFlowControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.adgv);
            this.Controls.Add(this.funcPanel);
            this.Name = "MaintiFlowControl";
            this.Size = new System.Drawing.Size(1060, 613);
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel funcPanel;
        private Zuby.ADGV.AdvancedDataGridView adgv;
    }
}
