﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.MaintiFlow.Models;
using SQLite.CodeFirst.Extensions;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class CreateFlow : UIForm
    {
        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;
        private readonly FlowLayoutSelector _flowLayoutSelector;

        public CreateFlow(CoreData coreData, MaintiFlowData flowData, FlowLayoutSelector flowLayoutSelector)
        {
            InitializeComponent();
            _coreData = coreData;
            _flowData = flowData;
            _flowLayoutSelector = flowLayoutSelector;

            uiPanel_BasicData.TitleColor = CommonStyles.BackColor;
            uiButton_OK.FillColor = CommonStyles.BackColor;
            uiButton_OK.FillHoverColor = CommonStyles.Hover;

            /********************
             * Controls
             ********************/
            string caption;

            //caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.WorkOrderNo));
            //uiLabel_WorkOrderNo.Text = caption;
            //WorkOrderNo.Watermark = caption;

            //caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.CreationDate));
            //uiLabel_CreationDate.Text = caption;
            //CreationDate.Watermark = caption;

            caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Creator));
            uiLabel_Creator.Text = caption;
            var employeeList = _coreData.Employees
                .Select(e => new
                {
                    e.EmployeeId,
                    Display = $"{e.EmployeeId}, {e.Department}, {e.Name}"
                })
                .ToList();
            Creator.DataSource = employeeList;
            Creator.DisplayMember = "Display";
            Creator.ValueMember = "EmployeeId";
            Creator.Watermark = caption;

            caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderDevices));
            uiLabel_DeviceList.Text = caption;
            DeviceList.Watermark = caption;
            DeviceList.ButtonFillColor = CommonStyles.BackColor;
            DeviceList.ButtonFillHoverColor = CommonStyles.Hover;

            caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Model));
            uiLabel_Model.Text = caption;
            Model.Watermark = caption;
            Model.ButtonFillColor = CommonStyles.BackColor;
            Model.ButtonFillHoverColor = CommonStyles.Hover;
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {

        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void DeviceId_NodesSelected(object sender, TreeNodeCollection nodes)
        {
            DeviceList.Text = string.Empty;

            foreach (TreeNode item in nodes)
            {
                if (item.Checked)
                    DeviceList.Text += item.Text + ";";
            }
        }

        private void DeviceId_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.Title = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderDevices));
            _flowLayoutSelector.MultiSelection = true;

            Dictionary<string, ItemState> groupedDevices = new Dictionary<string, ItemState>();
            string[] typeList = _coreData.Devices.Select(x => x.DeviceName.Type.Name).Distinct().ToArray();
            foreach (var type in typeList)
            {
                ItemState itemList = new ItemState()
                {
                    IsChecked = false,
                     Name = type
                    _coreData.Devices
                    .Where(x => x.DeviceName.Type.Name == type)
                    .Select(x => x.DeviceId)
                    .ToList();
                };
                if (itemList.Count > 0)
                    groupedDevices.Add(type, itemList);
            }
            _flowLayoutSelector.Items = groupedDevices;

            string deviceString = "";
            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                foreach (var item in _flowLayoutSelector.ResultList)
                {
                    if (deviceString != "")
                        deviceString += "; ";
                    deviceString += item;
                }
            }
            DeviceList.Text = deviceString;
        }

        private void Model_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.Title = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Model));
            _flowLayoutSelector.MultiSelection = false;

            Dictionary<string, List<string>> groupedDevices = new Dictionary<string, List<string>>();
            string[] typeList = _coreData.Devices.Select(x => x.DeviceName.Type.Name).Distinct().ToArray();
            foreach (var type in typeList)
            {
                List<string> itemList = new List<string>();
                groupedDevices.Add(type, _coreData.Devices
                    .Where(x => x.DeviceName.Type.Name == type)
                    .Select(x => x.DeviceName.FullName)
                    .ToList()
                    );
                groupedDevices.Add(type, itemList);
            }
            _flowLayoutSelector.Items = groupedDevices;

            string modelString = "";
            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                foreach (var item in _flowLayoutSelector.ResultList)
                {
                    if (modelString != "")
                        modelString += "; ";
                    modelString += _flowData.ModelList.First(x => x == item);
                }
            }
            Model.Text = modelString;
        }
    }
}
