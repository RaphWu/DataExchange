﻿/*
 * 工程師開單 vs 線上人員開單分開。
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Core.WinForms;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Events;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class CreateFlow : UIForm
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly IMail _mail;
        private readonly FieldTitle _fieldTitle;
        private readonly FlowLayoutSelector _fls;

        private string _todayPrefix;
        private int _lastWorkOrderNo;

        #endregion fields

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 新建工單的工單號。
        /// </summary>
        public List<TaskOrder> NewWorkOrderNos { get; set; } = new List<TaskOrder>();

        public CreateFlow(CoreContext CoreContext,
                          CoreData coreData,
                          IMail mail,
                          FieldTitle fieldTitle,
                          FlowLayoutSelector flowLayoutSelector)
        {
            InitializeComponent();
            _context = CoreContext;
            _coreData = coreData;
            _mail = mail;
            _fieldTitle = fieldTitle;
            _fls = flowLayoutSelector;

            CommonStyles.SetButton(Button_OK);
            CommonStyles.SetButton(Button_Cancel, isCancel: true);

            this.AcceptButton = Button_OK;
            this.CancelButton = Button_Cancel;
        }

        private void CreateFlow_Load(object sender, EventArgs e)
        {
            string caption;

            caption = _fieldTitle.RequestingUnit;
            Label_RequestingUnit.Text = caption;
            RequestingUnit.Watermark = caption;
            var rUnitList = _context.RequestingUnits
                .Select(r => new { Id = r.Id, Display = r.UnitName, })
                .ToList();
            RequestingUnit.DataSource = rUnitList;
            RequestingUnit.DisplayMember = "Display";
            RequestingUnit.ValueMember = "Id";

            caption = _fieldTitle.Creator;
            Label_Creator.Text = caption;
            var employeeList = _coreData.Employees
                .Select(emp => new
                {
                    Id = emp.EmployeeId,
                    Display = $"{emp.EmployeeId}, {emp.Department.DepartmentName}, {emp.EmployeeName}",
                })
                .ToList();
            Creator.DataSource = employeeList;
            Creator.DisplayMember = "Display";
            Creator.ValueMember = "Id";
            Creator.Watermark = caption;

            caption = _fieldTitle.Machine;
            Label_MachineList.Text = caption;
            MachineList.Watermark = caption;
            MachineList.ButtonFillColor = CommonStyles.BackColor;
            MachineList.ButtonFillHoverColor = CommonStyles.HoverColor;

            caption = _fieldTitle.OutageStarted;
            Label_OutageStarted.Text = caption;
            OutageStarted.Watermark = caption;
            OutageStarted.Value = DateTime.Now;

            caption = _fieldTitle.IssueDescription;
            Label_IssueDescription.Text = caption;
        }

        private void CreateFlow_Shown(object sender, EventArgs e)
        {
            SunnyUiHelper.AdjustFormLayout(this, TLP);
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            // 需求單位
            if (string.IsNullOrWhiteSpace(RequestingUnit.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{Label_RequestingUnit.Text}！");
                return;
            }

            // 拆解機台編號
            var machineList = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();

            // 錯誤檢查
            if (string.IsNullOrWhiteSpace(Creator.Text))
            {
                UIMessageBox.ShowError2($"{Label_Creator.Text}必須要選擇一人！");
                return;
            }
            if (string.IsNullOrWhiteSpace(MachineList.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{Label_MachineList.Text}！");
                return;
            }
            else
            {
                foreach (var mId in machineList)
                    if (_coreData.Machines.FindIndex(x => x.MachineCode == mId) == -1)
                    {
                        UIMessageBox.ShowError2($"{Label_MachineList.Text}不存在: {mId}");
                        return;
                    }
            }
            //if (string.IsNullOrWhiteSpace(ModelWs.Text))
            //{
            //    UIMessageBox.ShowError2($"必須選擇{uiLabel_ModelWs.Text}！");
            //    return;
            //}
            //else
            //{
            //    if (_coreData.Models.FindIndex(x => x.ModelName == ModelWs.Text) == -1)
            //    {
            //        UIMessageBox.ShowError2($"{uiLabel_ModelWs.Text}不存在: {ModelWs.Text}");
            //        return;
            //    }
            //}

            try
            {
                var deviceList = new List<Machine>();

                // 計算新工單號
                _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                var tos = _context.TaskOrders;
                _lastWorkOrderNo = tos
                    .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                    .Select(w => w.WorkOrderNo)
                    .AsEnumerable()
                    .Select(o => int.TryParse(o.Substring(8, 3), out int val) ? val : 0)
                    .DefaultIfEmpty(0)
                    .Max();

                // 加入資料庫
                var creator = _coreData.Employees.
                    FirstOrDefault(c => c.EmployeeId == (string)Creator.SelectedValue);
                int rUnitId = (int)RequestingUnit.SelectedValue;

                NewWorkOrderNos.Clear();
                for (int no = 1; no <= machineList.Count; no++)
                {
                    string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                    string machineId = machineList[no - 1];
                    var to = new TaskOrder()
                    {
                        WorkOrderNo = newWorkOrderNo,
                        CreationDateTime = DateTime.Today,
                        Machine = _context.Machines.FirstOrDefault(x => x.MachineCode == machineId),
                        IssueDescription = IssueDescription.Text,

                        CreatorId = creator.Id,
                        Engineers = null,
                        Status = FlowStatus.NewTaskOrder,
                        AcceptedTime = DateTime.Now,
                        OutageStarted = OutageStarted.Value,
                        RequestingUnitId = rUnitId,

                        WorkstationId = 0,
                        MaintenanceUnitId = 0,
                        IssueCategoryId = 0,
                        Details = "",
                        FeedbackEmployeeId = 0,
                        Feedback = "",
                        Responsible = "",
                    };
                    _context.TaskOrders.Add(to);
                    NewWorkOrderNos.Add(to);
                }
                _context.SaveChanges();
                WeakReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

                // send email
                StringBuilder mail = new StringBuilder();
                mail.Append("<table><caption>新建工單</caption>");

                var ruId = NewWorkOrderNos[0].RequestingUnitId;
                mail.Append("<tr>");
                mail.Append("<td>需求單位</td>");
                mail.Append($"<td>{_context.RequestingUnits.FirstOrDefault(r => r.Id == ruId).UnitName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>工單建立者</td>");
                mail.Append($"<td>{creator.EmployeeName}</td>");
                mail.Append("</tr>");

                List<string> oms = new List<string>();
                foreach (var wo in NewWorkOrderNos)
                    oms.Add($"{wo.WorkOrderNo}, {wo.FullMachineName}");

                mail.Append("<tr>");
                mail.Append("<td>新增工單</td>");
                mail.Append($"<td>{string.Join("<br/>", oms)}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>建立時間</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].CreationDateString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動時間</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].OutageStartedString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>問題描述</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].IssueDescription}</td>");
                mail.Append("</tr>");

                mail.Append("</table>");
                _mail.SendMail("新建工單",
                               $"[TaskPulse][維護工單][新建工單] {creator.EmployeeName} 新建 {NewWorkOrderNos.Count} 張維護工單。",
                               mail.ToString());

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void MachineId_ButtonClick(object sender, EventArgs e)
        {
            _fls.HideTabHeaders = false;
            _fls.ShowTreeView = true;
            _fls.Title = $"請選擇{_fieldTitle.Machine}";
            _fls.TreeViewCaption = "機台";
            _fls.MultiSelection = true;
            _fls.TabPageCache = _coreData.MachinesMultiTabPageCache;
            _fls.DefaultChecked = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _fls.Initialize();

            //if (Core.Views.FormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_fls.ShowDialog() == DialogResult.OK)
            {
                if (_fls.ResultList.Count > 0)
                {
                    //string deviceString = "";
                    //foreach (var info in _flowLayoutSelector.ResultList)
                    //{
                    //    if (deviceString != "")
                    //        deviceString += "; ";
                    //    deviceString += info.Name;
                    //}
                    //MachineList.Text = deviceString;
                    MachineList.Text = string.Join("; ", _fls.ResultList.Select(r => r.Name).ToArray());
                }
                else
                {
                    MachineList.Text = "";
                }
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            Creator.Text = "";
            MachineList.Text = "";
            OutageStarted.Value = DateTime.Now;
            IssueDescription.Text = "";
        }
    }
}
