﻿/*
 * 工程師開單 vs 線上人員開單分開。
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Events;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class CreateFlow : UIForm
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly FieldName _fieldName;
        private readonly FlowLayoutSelector _flowLayoutSelector;

        private string _todayPrefix;
        private int _lastWorkOrderNo;

        #endregion fields

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 新建工單的工單號。
        /// </summary>
        public List<TaskOrder> NewWorkOrderNos { get; set; } = new List<TaskOrder>();

        public CreateFlow(CoreContext CoreContext,
                          CoreData coreData,
                          FieldName fieldName,
                          FlowLayoutSelector flowLayoutSelector)
        {
            InitializeComponent();
            _context = CoreContext;
            _coreData = coreData;
            _fieldName = fieldName;
            _flowLayoutSelector = flowLayoutSelector;

            CommonStyles.SetButton(Button_OK);
            CommonStyles.SetButton(Button_Cancel, accent: true);

            this.AcceptButton = Button_OK;
            this.CancelButton = Button_Cancel;
        }

        private void CreateFlow_Load(object sender, EventArgs e)
        {
            string caption;
            caption = _fieldName.Creator;
            uiLabel_Creator.Text = caption;
            var employeeList = _coreData.Employees
                .Select(emp => new
                {
                    emp.EmployeeId,
                    Display = $"{emp.EmployeeId}, {emp.Department.DepartmentName}, {emp.Name}",
                })
                .ToList();
            Creator.DataSource = employeeList;
            Creator.DisplayMember = "Display";
            Creator.ValueMember = "EmployeeId";
            Creator.Watermark = caption;

            caption = _fieldName.Machine;
            uiLabel_MachineList.Text = caption;
            MachineList.Watermark = caption;
            MachineList.ButtonFillColor = CommonStyles.BackColor;
            MachineList.ButtonFillHoverColor = CommonStyles.HoverColor;

            caption = _fieldName.OutageStarted;
            uiLabel_OutageStarted.Text = caption;
            OutageStarted.Watermark = caption;

            caption = _fieldName.IssueDescription;
            uiLabel_IssueDescription.Text = caption;
            IssueDescription.Watermark = caption;
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            // 拆解機台編號
            var machineList = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();

            // 錯誤檢查
            if (string.IsNullOrWhiteSpace(Creator.Text))
            {
                UIMessageBox.ShowError2($"{uiLabel_Creator.Text}必須要選擇一人！");
                return;
            }
            if (string.IsNullOrWhiteSpace(MachineList.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{uiLabel_MachineList.Text}！");
                return;
            }
            else
            {
                foreach (var mId in machineList)
                    if (_coreData.Machines.FindIndex(x => x.MachineId == mId) == -1)
                    {
                        UIMessageBox.ShowError2($"{uiLabel_MachineList.Text}不存在: {mId}");
                        return;
                    }
            }
            //if (string.IsNullOrWhiteSpace(ModelWs.Text))
            //{
            //    UIMessageBox.ShowError2($"必須選擇{uiLabel_ModelWs.Text}！");
            //    return;
            //}
            //else
            //{
            //    if (_coreData.Models.FindIndex(x => x.ModelName == ModelWs.Text) == -1)
            //    {
            //        UIMessageBox.ShowError2($"{uiLabel_ModelWs.Text}不存在: {ModelWs.Text}");
            //        return;
            //    }
            //}

            try
            {
                var deviceList = new List<Machine>();

                // 計算新工單號
                _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                var tos = _context.TaskOrders;
                int lastOrderNo = tos.Select(x => x.OrderNo).Max();
                _lastWorkOrderNo = tos
                    .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                    .Select(w => w.WorkOrderNo)
                    .AsEnumerable()
                    .Select(o => int.TryParse(o.Substring(8, 3), out int val) ? val : 0)
                    .DefaultIfEmpty(0)
                    .Max();

                // 加入資料庫
                NewWorkOrderNos.Clear();

                for (int no = 1; no <= machineList.Count; no++)
                {
                    string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                    string creatorId = (string)Creator.SelectedValue;
                    string machineId = machineList[no - 1];
                    var to = new TaskOrder()
                    {
                        OrderNo = lastOrderNo + no,
                        WorkOrderNo = newWorkOrderNo,
                        Creator = _context.Employees.FirstOrDefault(x => x.EmployeeId == creatorId),
                        CreationDate = DateTime.Today,
                        Machine = _context.Machines.FirstOrDefault(x => x.MachineId == machineId),
                        Workstation = null,
                        //Workstation = _coreData.Workstations.FirstOrDefault(w => w.WorkstationName == ModelWs.Text),
                        Status = OrderStatus.NewTaskOrder,
                        AcceptedTime = DateTime.Now,
                        OutageStarted = OutageStarted.Value,

                        MaintenanceUnitId = 0,
                        IssueCategoryId = 0,
                        IssueDescription = "",
                        Details = "",
                        RequestingEmployeeId = 0,
                        Response = "",
                        Responsible="",
                    };
                    _context.TaskOrders.Add(to);
                    NewWorkOrderNos.Add(to);
                }
                _context.SaveChanges();

                StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void MachineId_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.HideTabHeaders = false;
            _flowLayoutSelector.Title = $"請選擇{_fieldName.Machine}";
            _flowLayoutSelector.MultiSelection = true;
            _flowLayoutSelector.TabPageCache = _coreData.MachinesTabPageCache;
            _flowLayoutSelector.DefaultChecked = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _flowLayoutSelector.Initialize();

            //if (Core.Views.FormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                if (_flowLayoutSelector.ResultList.Count > 0)
                {
                    string deviceString = "";
                    foreach (var item in _flowLayoutSelector.ResultList)
                    {
                        if (deviceString != "")
                            deviceString += "; ";
                        deviceString += item;
                    }
                    MachineList.Text = deviceString;
                }
            }
        }
    }
}
