﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class TaskOrderView : UIForm
    {
        private readonly MaintiFlowData _flowData;
        private readonly FieldTitle _fieldTitle;

        public string Title { set => this.Text = value; }

        /// <summary>
        /// 
        /// </summary>
        public List<TaskOrder> NewWorkOrderNos { get; set; }

        public TaskOrderView(MaintiFlowData maintiFlow, FieldTitle fieldTitle)
        {
            InitializeComponent();
            _flowData = maintiFlow;
            _fieldTitle = fieldTitle;
        }

        public void Initialize()
        {
            if (NewWorkOrderNos == null || NewWorkOrderNos.Count == 0)
                return;

            var newWorkOrderNos = NewWorkOrderNos[0];
            var to0 = _flowData.TaskOrders.FirstOrDefault(x => x.Id == newWorkOrderNos.Id);

            // 單行
            Creator.Text = to0.CreatorFullName;
            uiLabel_Creator.Text = _fieldTitle.Creator;

            CreationDate.Text = to0.CreationDateString;
            uiLabel_CreationDate.Text = _fieldTitle.CreationDate;

            OutageStarted.Text = to0.OutageStartedString;
            uiLabel_OutageStarted.Text = _fieldTitle.OutageStarted;

            IssueDescription.Text = to0.IssueDescription;
            uiLabel_IssueDescription.Text = _fieldTitle.IssueDescription;

            // 複合
            List<int> nos = new List<int>();
            List<string> orders = new List<string>();
            List<string> machines = new List<string>();

            foreach (var item in NewWorkOrderNos)
            {
                nos.Add(item.Id);
                orders.Add(item.WorkOrderNo);
                machines.Add(item.Machine.MachineId);
            }

            OrderNo.Text = string.Join(", ", nos);
            uiLabel_OrderNo.Text = _fieldTitle.OrderNo;

            WorkOrderNo.Multiline = true;
            WorkOrderNo.Lines = orders.ToArray();
            uiLabel_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;

            MachineList.Text = string.Join(", ", machines);
            uiLabel_MachineList.Text = _fieldTitle.Machine;
        }

        private void uiButton_Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
