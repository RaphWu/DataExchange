﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class TaskOrderView : UIForm
    {
        private readonly MaintiFlowData _maintiFlow;
        private readonly FieldName _fieldName;

        public string Title { set => this.Text = value; }

        /// <summary>
        /// 
        /// </summary>
        public List<TaskOrder> NewWorkOrderNos { get; set; }

        public TaskOrderView(MaintiFlowData maintiFlow, FieldName fieldName)
        {
            InitializeComponent();
            _maintiFlow = maintiFlow;
            _fieldName = fieldName;
        }

        public void Initialize()
        {
            if (NewWorkOrderNos == null || NewWorkOrderNos.Count == 0)
                return;

            var newWorkOrderNos = NewWorkOrderNos[0];
            var to0 = _maintiFlow.TaskOrders.FirstOrDefault(x => x.Id == newWorkOrderNos.Id);

            // 單行
            Creator.Text = to0.CreatorFullName;
            uiLabel_Creator.Text = _fieldName.Creator;

            CreationDate.Text = to0.CreationDateString;
            uiLabel_CreationDate.Text = _fieldName.CreationDate;

            OutageStarted.Text = to0.OutageStartedString;
            uiLabel_OutageStarted.Text = _fieldName.OutageStarted;

            IssueDescription.Text = to0.IssueDescription;
            uiLabel_IssueDescription.Text = _fieldName.IssueDescription;

            // 複合
            List<int> nos = new List<int>();
            List<string> orders = new List<string>();
            List<string> machines = new List<string>();

            foreach (var item in NewWorkOrderNos)
            {
                nos.Add(item.Id);
                orders.Add(item.WorkOrderNo);
                machines.Add(item.Machine.MachineId);
            }

            OrderNo.Text = string.Join(", ", nos);
            uiLabel_OrderNo.Text = _fieldName.OrderNo;

            WorkOrderNo.Multiline = true;
            WorkOrderNo.Lines = orders.ToArray();
            uiLabel_WorkOrderNo.Text = _fieldName.WorkOrderNo;

            MachineList.Text = string.Join(", ", machines);
            uiLabel_MachineList.Text = _fieldName.Machine;
        }

        private void uiButton_Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
