﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_MaintiWork : UIForm
    {
        private readonly CoreContext _context;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly FlowLayoutSelector _flowLayoutSelector;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private List<TaskOrder> _orders;
        private BindingSource _bs = new BindingSource();
        private bool isChanged = false;

        public List<int> EngineerList { get; set; } = new List<int>();

        public FT_MaintiWork(CoreContext coreContext,
                             MaintiFlowData maintiFlowData,
                             CoreData coreData,
                             FlowLayoutSelector flowLayoutSelector,
                             FieldName fieldName,
                             FieldTitle fieldTitle)
        {
            InitializeComponent();
            _context = coreContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _flowLayoutSelector = flowLayoutSelector;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            CommonStyles.SetButton(Button_Save);
            CommonStyles.SetButton(Button_Cancel, accent: true);

            ListBox_Orders.HoverColor = CommonStyles.HoverColor;

            //Model.ButtonFillColor = CommonStyles.BackColor;
            //Model.ButtonFillHoverColor = CommonStyles.HoverColor;
            //Workstation.ButtonFillColor = CommonStyles.BackColor;
            //Workstation.ButtonFillHoverColor = CommonStyles.HoverColor;
        }

        private void FT_MaintiWork_Load(object sender, System.EventArgs e)
        {
            LoadData();
            isChanged = false;
        }

        private void LoadData()
        {
            //_orders = _flowData.TaskOrders
            //    .Where(to => to.Engineers != null
            //        && to.Engineers.Any(e => EngineerList.Contains(e.Id))
            //        && to.Status == OrderStatus.InProgress)
            //    .ToList();

            _orders = _context.TaskOrders
               .Where(to =>
                   to.Engineers.Any(e => EngineerList.Contains(e.Id)) &&
                   to.Status == OrderStatus.InProgress)
               .ToList();

            ListBox_Orders.DataSource = _orders.Select(t => t.WorkOrderNo).ToList();
            _bs.DataSource = _orders;

            OrderNo.DataBindings.Clear();
            OrderNo.DataBindings.Add("Text", _bs, _fieldName.OrderNo);
            OrderNo.ReadOnly = true;
            Label_OrderNo.Text = _fieldTitle.OrderNo;

            WorkOrderNo.DataBindings.Clear();
            WorkOrderNo.DataBindings.Add("Text", _bs, _fieldName.WorkOrderNo);
            WorkOrderNo.ReadOnly = true;
            Label_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;

            Creator.DataBindings.Clear();
            Creator.DataBindings.Add("Text", _bs, _fieldName.CreatorFullName);
            Creator.ReadOnly = true;
            Label_Creator.Text = _fieldTitle.Creator;

            CreationDate.DataBindings.Clear();
            CreationDate.DataBindings.Add("Text", _bs, _fieldName.CreationDateString);
            CreationDate.ReadOnly = true;
            Label_CreationDate.Text = _fieldTitle.CreationDate;

            MachineList.DataBindings.Clear();
            MachineList.DataBindings.Add("Text", _bs, _fieldName.FullMachineName);
            MachineList.ReadOnly = true;
            Label_MachineList.Text = _fieldTitle.Machine;

            Model.DataBindings.Clear();
            Model.DataBindings.Add("Text", _bs, _fieldName.Model);
            Label_Model.Text = _fieldTitle.Model;

            Workstation.DataBindings.Clear();
            Workstation.DataBindings.Add("Text", _bs, _fieldName.Workstation);
            Label_Workstation.Text = _fieldTitle.Workstation;

            AcceptedTime.DataBindings.Clear();
            AcceptedTime.DataBindings.Add("Text", _bs, _fieldName.AcceptedTimeString);
            AcceptedTime.ReadOnly = true;
            Label_AcceptedTime.Text = _fieldTitle.AcceptedTime;

            /*****/

            Binding b;

            MaintenanceUnit.DataBindings.Clear();
            MaintenanceUnit.DataBindings.Add("Text", _bs, _fieldName.MaintenanceUnit);
            Label_MaintenanceUnit.Text = _fieldTitle.MaintenanceUnit;

            Engineers.DataBindings.Clear();
            Engineers.DataBindings.Add("Text", _bs, _fieldName.EngineerList);
            Label_Engineers.Text = _fieldTitle.Engineer;

            IssueCategory.DataBindings.Clear();
            IssueCategory.DataBindings.Add("Text", _bs, _fieldName.IssueCategory);
            Label_IssueCategory.Text = _fieldTitle.IssueCategory;

            IssueDescription.DataBindings.Clear();
            IssueDescription.DataBindings.Add("Text", _bs, _fieldName.IssueDescription);
            Label_IssueDescription.Text = _fieldTitle.IssueDescription;

            Details.DataBindings.Clear();
            Details.DataBindings.Add("Text", _bs, _fieldName.Details);
            Label_Details.Text = _fieldTitle.Details;

            RepairStarted.DataBindings.Clear();
            RepairStarted.DataBindings.Add("Text", _bs, _fieldName.RepairStartedString);
            Label_RepairStarted.Text = _fieldTitle.RepairStarted;

            b = new Binding("Value", _bs, _fieldName.RepairCompleted, true);
            b.Format += (s, e) =>
            {
                if (e.Value == null || !(e.Value is DateTime))
                    e.Value = DateTime.Now;
            };
            b.Parse += (s, e) =>
            {
                if ((DateTime)e.Value == DateTimePicker.MinimumDateTime)
                    e.Value = null;
            };
            RepairCompleted.DataBindings.Clear();
            RepairCompleted.DataBindings.Add(b);
            Label_RepairCompleted.Text = _fieldTitle.RepairCompleted;

            RepairDuration.DataBindings.Clear();
            RepairDuration.DataBindings.Add("Text", _bs, _fieldName.RepairDurationString);
            Label_RepairDuration.Text = _fieldTitle.RepairDuration;

            OutageStarted.DataBindings.Clear();
            OutageStarted.DataBindings.Add("Text", _bs, _fieldName.OutageStartedString);
            OutageStarted.ReadOnly = true;
            Label_OutageStarted.Text = _fieldTitle.OutageStarted;

            b = new Binding("Value", _bs, _fieldName.OutageEnded, true);
            b.Format += (s, e) =>
            {
                if (e.Value == null || !(e.Value is DateTime))
                    e.Value = DateTime.Now;
            };
            b.Parse += (s, e) =>
            {
                if ((DateTime)e.Value == DateTimePicker.MinimumDateTime)
                    e.Value = null;
            };
            OutageEnded.DataBindings.Clear();
            OutageEnded.DataBindings.Add(b);
            Label_OutageEnded.Text = _fieldTitle.OutageEnded;

            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add("Text", _bs, _fieldName.OutageDurationString);
            Label_OutageDuration.Text = _fieldTitle.OutageDuration;
        }

        private void ListBox_Orders_SelectedIndexChanged(object sender, EventArgs e)
        {
            _bs.Position = ListBox_Orders.SelectedIndex;
        }

        private void Model_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.HideTabHeaders = true;
            _flowLayoutSelector.ShowTreeView = false;
            _flowLayoutSelector.Title = $"請選擇{_fieldTitle.Model}";
            _flowLayoutSelector.MultiSelection = false;
            _flowLayoutSelector.TabPageCache = _coreData.ModelTabPageCache;
            _flowLayoutSelector.DefaultChecked = new List<string>() { Model.Text };
            _flowLayoutSelector.Initialize();

            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                if (_flowLayoutSelector.ResultList.Count > 0)
                {
                    string mName = _flowLayoutSelector.ResultList[0];
                    var model = _context.Models.FirstOrDefault(m => m.ModelName == mName);
                    //_orders[ListBox_Orders.SelectedIndex].Workstation.Model = model;
                    Model.Text = mName;

                    isChanged = true;
                }
            }
        }
    }
}
