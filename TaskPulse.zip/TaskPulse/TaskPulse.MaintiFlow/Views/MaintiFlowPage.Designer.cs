﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class MaintiFlowPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiNavMenu = new Sunny.UI.UINavMenu();
            this.uiPanel_Nav = new Sunny.UI.UIPanel();
            this.SuspendLayout();
            // 
            // uiNavMenu
            // 
            this.uiNavMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiNavMenu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.uiNavMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.uiNavMenu.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.uiNavMenu.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiNavMenu.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiNavMenu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavMenu.FullRowSelect = true;
            this.uiNavMenu.HotTracking = true;
            this.uiNavMenu.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.uiNavMenu.ItemHeight = 50;
            this.uiNavMenu.Location = new System.Drawing.Point(0, 0);
            this.uiNavMenu.MenuStyle = Sunny.UI.UIMenuStyle.Custom;
            this.uiNavMenu.Name = "uiNavMenu";
            this.uiNavMenu.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavMenu.ScrollBarHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavMenu.ScrollBarPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavMenu.ScrollFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiNavMenu.SecondBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            this.uiNavMenu.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.uiNavMenu.SelectedColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.uiNavMenu.ShowLines = false;
            this.uiNavMenu.ShowPlusMinus = false;
            this.uiNavMenu.ShowRootLines = false;
            this.uiNavMenu.Size = new System.Drawing.Size(160, 702);
            this.uiNavMenu.TabIndex = 1;
            this.uiNavMenu.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiNavMenu.MenuItemClick += new Sunny.UI.UINavMenu.OnMenuItemClick(this.uiNavMenu_MenuItemClick);
            // 
            // uiPanel_Nav
            // 
            this.uiPanel_Nav.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel_Nav.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiPanel_Nav.Location = new System.Drawing.Point(160, 0);
            this.uiPanel_Nav.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel_Nav.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel_Nav.Name = "uiPanel_Nav";
            this.uiPanel_Nav.Padding = new System.Windows.Forms.Padding(5);
            this.uiPanel_Nav.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiPanel_Nav.Size = new System.Drawing.Size(963, 702);
            this.uiPanel_Nav.TabIndex = 2;
            this.uiPanel_Nav.Text = "MaintiFlow";
            this.uiPanel_Nav.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MaintiFlowPage
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1123, 702);
            this.Controls.Add(this.uiPanel_Nav);
            this.Controls.Add(this.uiNavMenu);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "MaintiFlowPage";
            this.Text = "MaintiFlowPage";
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UINavMenu uiNavMenu;
        private Sunny.UI.UIPanel uiPanel_Nav;
    }
}