﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UIPage
    {
        private readonly MaintiFlowContext _db;
        private DataTable _dt;

        public MaintiFlowSummary(MaintiFlowContext db)
        {
            InitializeComponent();
            _db = db;

            adgv.SetDoubleBuffered();
            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

            _dt = new DataTable(); // 初始化 DataTable
        }

        private void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            if (_db != null)
            {
                // 維護工程師名單
                var engineerList = _db.TaskOrderEngineers
                    .Where(te => te.Engineer.IsEngineer)
                    .Select(te => new
                    {
                        te.Engineer.EmployeeId,
                        te.Engineer.Name,
                        te.Engineer.Department,
                        te.Engineer.Title
                    })
                    .ToList();

                // .Include(u => u.MaintenanceEngineers.Select(te => te.Engineer)) // EF6 的 Include 不支援多層 Lambda
                var orderList = _db.TaskOrders
                    .Include(nameof(TaskOrder.MaintenanceEngineers) + "." + nameof(TaskOrderEngineer.Engineer))
                    .Include(nameof(TaskOrder.TaskOrderDevices) + "." + nameof(TaskOrderDevice.Device))
                    .Include(nameof(TaskOrder.Status))
                    .Include(nameof(TaskOrder.IssueCategory))
                    .OrderByDescending(u => u.OrderNo)
                    .ToList()  
                    .Select(u => new
                    {
                        u.OrderNo,
                        u.WorkOrderNo,
                        creatorName = u.Creator?.Name ?? string.Empty,
                        u.CreationDate,
                        statusText = u.Status.StatusName,
                        maintenanceUnitName = u.MaintenanceUnit?.Name ?? string.Empty,
                        maintenanceEngineerNames = string.Join("\n", u.MaintenanceEngineers.Select(te => te.Engineer.Name)),
                        //machineList = string.Join("\n", u.TaskOrderDevices.Select(m => m.Device.DeviceName)),
                        modelName = u.ModelName,
                        u.Workstation,
                        u.RepairDuration,
                        u.OutageDuration,
                    })
                    .ToList();

                _dt = orderList.ToDataTable();
                adgv.DataSource = _dt;

                DataGridViewColumn c = adgv.Columns[nameof(TaskOrder.OrderNo)];
                c.HeaderText = "編號";
                c.ValueType = typeof(int);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns[nameof(TaskOrder.WorkOrderNo)];
                c.HeaderText = "工單";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["creatorName"];
                c.HeaderText = "建檔人員";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns[nameof(TaskOrder.CreationDate)];
                c.HeaderText = "建檔日期";
                c.ValueType = typeof(DateTime);
                c.DefaultCellStyle.Format = "yyyy/MM/dd";
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["statusText"];
                c.HeaderText = "狀態";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["maintenanceUnitName"];
                c.HeaderText = "維護單位";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["maintenanceEngineerNames"];
                c.HeaderText = "工程師";
                c.ValueType = typeof(string);
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                //c = adgv.Columns["deviceList"];
                //c.HeaderText = "機台編號";
                //c.ValueType = typeof(string);
                //c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                //c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

                c = adgv.Columns[nameof(TaskOrder.Workstation)];
                c.HeaderText = "工站";
                c.ValueType = typeof(string);
                c.DefaultCellStyle.Format = "HH:mm";
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["modelName"];
                c.HeaderText = "機種";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

                c = adgv.Columns[nameof(TaskOrder.RepairDuration)];
                c.HeaderText = "維修工時";
                c.ValueType = typeof(TimeSpan);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //c.DefaultCellStyle.Format = "hh:mm";

                c = adgv.Columns[nameof(TaskOrder.OutageDuration)];
                c.HeaderText = "停動工時";
                c.ValueType = typeof(TimeSpan);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //c.DefaultCellStyle.Format = "hh:mm";

                adgv.CellFormatting += (s, e) =>
                {
                    if (adgv.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                        && e.Value is TimeSpan ts)
                    {
                        e.Value = ts.ToString(@"hh\:mm");
                        e.FormattingApplied = true;
                    }
                };

                adgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                adgv.SetFilterCustomEnabled(adgv.Columns[nameof(TaskOrder.RepairDuration)], false);
                adgv.SetFilterCustomEnabled(adgv.Columns[nameof(TaskOrder.OutageDuration)], false);
            }
        }
    }
}
