﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;
using Zuby.ADGV;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UIUserControl
    {
        private readonly MaintiFlowContext _db;
        private DataTable _dt;

        public MaintiFlowSummary(MaintiFlowContext db)
        {
            InitializeComponent();
            _db = db;
            adgv.SetDoubleBuffered();
            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

            _dt = new DataTable();
            _dt.Columns.Add("編號", typeof(int));
            _dt.Columns.Add(nameof(TaskOrder.WorkOrderNo), typeof(int));
            _dt.Columns.Add(nameof(TaskOrder.CreatorId), typeof(string));
            _dt.Columns.Add(nameof(TaskOrder.CreationDate), typeof(DataTable));
            _dt.Columns.Add(nameof(TaskOrder.Status), typeof(Models.Status));

            //_dt.Columns.Add("decimal", typeof(decimal));
            //_dt.Columns.Add("double", typeof(double));
            //_dt.Columns.Add("date", typeof(DateTime));
            //_dt.Columns.Add("datetime", typeof(DateTime));
            //_dt.Columns.Add("string", typeof(string));
            //_dt.Columns.Add("boolean", typeof(bool));
            //_dt.Columns.Add("guid", typeof(Guid));
            //_dt.Columns.Add("image", typeof(Bitmap));
            //_dt.Columns.Add("timespan", typeof(TimeSpan));
        }

        private void MaintiFlowSummary_Load(object sender, EventArgs e)
        {
            if (_db != null)
            {
                // 維護工程師名單
                var engineerList = _db.TaskOrderEngineers
                    .Where(te => te.Engineer.IsEngineer)
                    .Select(te => new
                    {
                        te.Engineer.EmployeeId,
                        te.Engineer.Name,
                        te.Engineer.Department,
                        te.Engineer.Title
                    })
                    .ToList();

                // .Include(u => u.MaintenanceEngineers.Select(te => te.Engineer)) // EF6 的 Include 不支援多層 Lambda
                var orderList = _db.TaskOrders
                    .Include(nameof(TaskOrder.MaintenanceEngineers) + "." + nameof(TaskOrderEngineer.Engineer))
                    .Include(nameof(TaskOrder.TaskOrderMachines) + "." + nameof(TaskOrderMachine.Machine))
                    .Include(nameof(TaskOrder.Status))
                    .Include(nameof(TaskOrder.IssueCategory))
                    .OrderByDescending(u => u.OrderNo)
                    .ToList()  // 先把資料從DB拉出來，這時候LINQ to Objects開始，否則string.Join會報錯
                    .Select(u => new
                    {
                        u.OrderNo,
                        u.WorkOrderNo,
                        MaintenanceEngineerNames = string.Join(", ", u.MaintenanceEngineers.Select(te => te.Engineer.Name)),
                        u.CreationDate,
                        StatusText = u.Status.StatusName,
                        MaintenanceUnitName = u.MaintenanceUnit.Name,
                        MachineList = string.Join(",", u.TaskOrderMachines.Select(m => m.MachineId)),
                        u.AcceptedTime,
                        u.Model,
                        u.Workstation,
                        u.RepairDuration,
                        u.OutageDuration,
                    })
                    .ToList();

                //var orderList = _db.TaskOrders
                //                       .Include(u => u.MaintenanceEngineers.Select(te => te.Engineer))
                //                       .OrderByDescending(u => u.OrderNo)
                //                       .ToList()
                //                       .Select(u => new
                //                       {
                //                           u.OrderNo,
                //                           u.WorkOrderNo,
                //                           MaintenanceEngineerNames = string.Join(", ", u.MaintenanceEngineers.Select(te => te.Engineer.Name))
                //                           //u.CreationDate,
                //                           //u.Status,
                //                           //u.MaintenanceUnit,
                //                           //u.MaintenanceEngineer,
                //                           //MachineIds = u.MachineId.Select(m => m.MachineId)
                //                           //u.AcceptedTime,
                //                           //u.Model,
                //                           //u.Workstation,
                //                           //u.IssueCategory,
                //                           //u.RequestingUnitResponse,
                //                       })
                //                       .ToList();
                _dt = orderList.ToDataTable();
                adgv.DataSource = _dt;

                DataGridViewColumn c = adgv.Columns[nameof(TaskOrder.OrderNo)];
                c.HeaderText = "編號";
                c.ValueType = typeof(int);

                c = adgv.Columns[nameof(TaskOrder.WorkOrderNo)];
                c.HeaderText = "工單編號";
                c.ValueType = typeof(string);

                c = adgv.Columns["MaintenanceEngineerNames"];
                c.HeaderText = "維護工程師";
                c.ValueType = typeof(string);

                c = adgv.Columns[nameof(TaskOrder.CreationDate)];
                c.HeaderText = "建檔日期";
                c.ValueType = typeof(DateTime);
                c.DefaultCellStyle.Format = "yyyy/MM/dd";

                _dt.Columns[04].ColumnName = "狀態";
                _dt.Columns[04].DataType = typeof(string);
                _dt.Columns[05].ColumnName = "維護單位";
                _dt.Columns[05].DataType = typeof(string);
                _dt.Columns[06].ColumnName = "機台編號";
                _dt.Columns[06].DataType = typeof(string);

                c = adgv.Columns[nameof(TaskOrder.AcceptedTime)];
                c.HeaderText = "接收時間";
                c.ValueType = typeof(DateTime);
                c.DefaultCellStyle.Format = "HH:mm";

                _dt.Columns[08].ColumnName = "機種";
                _dt.Columns[08].DataType = typeof(string);
                adgv.AutoResizeColumns();

                c = adgv.Columns[nameof(TaskOrder.RepairDuration)];
                c.HeaderText = "維修工時";
                c.ValueType = typeof(TimeSpan);
                //c.DefaultCellStyle.Format = "hh:mm";

                c = adgv.Columns[nameof(TaskOrder.OutageDuration)];
                c.HeaderText = "停動工時";
                c.ValueType = typeof(TimeSpan);
                //c.DefaultCellStyle.Format = "hh:mm";
            }
        }
    }
}
