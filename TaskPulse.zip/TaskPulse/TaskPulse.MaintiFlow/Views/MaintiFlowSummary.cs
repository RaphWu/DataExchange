﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UIUserControl
    {
        private readonly MaintiFlowContext _db;
        private DataTable _dt;

        public MaintiFlowSummary(MaintiFlowContext db)
        {
            InitializeComponent();
            _db = db;

            adgv.SetDoubleBuffered();
            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

            _dt = new DataTable(); // 初始化 DataTable
        }

        private void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            if (_db != null)
            {
                // 維護工程師名單
                var engineerList = _db.TaskOrderEngineers
                    .Where(te => te.Engineer.IsEngineer)
                    .Select(te => new
                    {
                        te.Engineer.EmployeeId,
                        te.Engineer.Name,
                        te.Engineer.Department,
                        te.Engineer.Title
                    })
                    .ToList();

                // .Include(u => u.MaintenanceEngineers.Select(te => te.Engineer)) // EF6 的 Include 不支援多層 Lambda
                var orderList = _db.TaskOrders
                    .Include(nameof(TaskOrder.MaintenanceEngineers) + "." + nameof(TaskOrderEngineer.Engineer))
                    .Include(nameof(TaskOrder.TaskOrderMachines) + "." + nameof(TaskOrderMachine.Machine))
                    .Include(nameof(TaskOrder.Status))
                    .Include(nameof(TaskOrder.IssueCategory))
                    .OrderByDescending(u => u.OrderNo)
                    .ToList()  // 先把資料從DB拉出來，這時候LINQ to Objects開始，否則string.Join會報錯
                    .Select(u => new
                    {
                        u.OrderNo,
                        u.WorkOrderNo,
                        CreatorName = u.Creator?.Name ?? string.Empty,
                        u.CreationDate,
                        StatusText = u.Status.StatusName,
                        MaintenanceUnitName = u.MaintenanceUnit?.Name ?? string.Empty,
                        MaintenanceEngineerNames = string.Join("\n", u.MaintenanceEngineers.Select(te => te.Engineer.Name)),
                        MachineList = string.Join("\n", u.TaskOrderMachines.Select(m => m.Machine.MachineName)),
                        u.Model,
                        u.Workstation,
                        u.RepairDuration,
                        u.OutageDuration,
                    })
                    .ToList();

                _dt = orderList.ToDataTable();
                adgv.DataSource = _dt;

                DataGridViewColumn c = adgv.Columns[nameof(TaskOrder.OrderNo)];
                c.HeaderText = "編號";
                c.ValueType = typeof(int);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns[nameof(TaskOrder.WorkOrderNo)];
                c.HeaderText = "工單";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["CreatorName"];
                c.HeaderText = "建檔人員";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns[nameof(TaskOrder.CreationDate)];
                c.HeaderText = "建檔日期";
                c.ValueType = typeof(DateTime);
                c.DefaultCellStyle.Format = "yyyy/MM/dd";
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["StatusText"];
                c.HeaderText = "狀態";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["MaintenanceUnitName"];
                c.HeaderText = "維護單位";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["MaintenanceEngineerNames"];
                c.HeaderText = "工程師";
                c.ValueType = typeof(string);
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["MachineList"];
                c.HeaderText = "機台編號";
                c.ValueType = typeof(string);
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

                //c = adgv.Columns[nameof(TaskOrder.AcceptedTime)];
                //c.HeaderText = "接收時間";
                //c.ValueType = typeof(DateTime);
                //c.DefaultCellStyle.Format = "HH:mm";
                //c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                //c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns[nameof(TaskOrder.Model)];
                c.HeaderText = "機種";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

                c = adgv.Columns[nameof(TaskOrder.RepairDuration)];
                c.HeaderText = "維修工時";
                c.ValueType = typeof(TimeSpan);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //c.DefaultCellStyle.Format = "hh:mm";

                c = adgv.Columns[nameof(TaskOrder.OutageDuration)];
                c.HeaderText = "停動工時";
                c.ValueType = typeof(TimeSpan);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //c.DefaultCellStyle.Format = "hh:mm";

                adgv.CellFormatting += (s, e) =>
                {
                    if (adgv.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                        && e.Value is TimeSpan ts)
                    {
                        e.Value = ts.ToString(@"hh\:mm");
                        e.FormattingApplied = true;
                    }
                };
            }
        }
    }
}
