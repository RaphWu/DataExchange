﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UIUserControl
    {
        private readonly MaintiFlowContext _db;
        private DataTable _dt;

        public MaintiFlowSummary(MaintiFlowContext db)
        {
            InitializeComponent();
            _db = db;
            adgv.SetDoubleBuffered();

            _dt = new DataTable();
            _dt.Columns.Add("序號", typeof(int));
            _dt.Columns.Add(nameof(TaskOrder.WorkOrderNo), typeof(int));
            _dt.Columns.Add(nameof(TaskOrder.CreatorId), typeof(string));
            _dt.Columns.Add(nameof(TaskOrder.CreationDate), typeof(DataTable));
            _dt.Columns.Add(nameof(TaskOrder.Status), typeof(Status));

            //_dt.Columns.Add("decimal", typeof(decimal));
            //_dt.Columns.Add("double", typeof(double));
            //_dt.Columns.Add("date", typeof(DateTime));
            //_dt.Columns.Add("datetime", typeof(DateTime));
            //_dt.Columns.Add("string", typeof(string));
            //_dt.Columns.Add("boolean", typeof(bool));
            //_dt.Columns.Add("guid", typeof(Guid));
            //_dt.Columns.Add("image", typeof(Bitmap));
            //_dt.Columns.Add("timespan", typeof(TimeSpan));
        }

        private void MaintiFlowSummary_Load(object sender, EventArgs e)
        {
            if (_db != null)
            {
                var orderList = _db.TaskOrders
                                   //.Include(u=>u.tas)
                                   .OrderByDescending(u => u.OrderNo)
                                   .Select(u => new
                                   {
                                       u.OrderNo,
                                       u.WorkOrderNo,
                                       //Creator = _db.Employees.Select(m => m.Name). == u.CreatorId),
                                       u.CreationDate,
                                       u.Status,
                                       u.MaintenanceUnit,
                                       u.MaintenanceEngineer,
                                       //MachineIds = u.MachineId.Select(m => m.MachineId)
                                       u.AcceptedTime,
                                       u.Model,
                                       //u.Workstation,
                                       //u.IssueCategory,
                                       //u.RequestingUnitResponse,
                                   })
                                   .ToList();
                _dt = orderList.ToDataTable();
                adgv.DataSource = _dt;
            }
        }
    }
}
