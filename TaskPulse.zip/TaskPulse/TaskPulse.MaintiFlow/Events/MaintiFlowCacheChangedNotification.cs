﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.MaintiFlow.Events
{
    public class MaintiFlowCacheChangedNotification
    {
        public static readonly MaintiFlowCacheChangedNotification Instance = new MaintiFlowCacheChangedNotification();
        private MaintiFlowCacheChangedNotification() { }
    }
}
