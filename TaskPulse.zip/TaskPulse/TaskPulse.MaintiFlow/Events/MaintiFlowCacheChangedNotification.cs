﻿namespace Calin.TaskPulse.MaintiFlow.Events
{
    public class MaintiFlowCacheChangedNotification
    {
        public static readonly MaintiFlowCacheChangedNotification Instance = new MaintiFlowCacheChangedNotification();
        private MaintiFlowCacheChangedNotification() { }
    }
}
