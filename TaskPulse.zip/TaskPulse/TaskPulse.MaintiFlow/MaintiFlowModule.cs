﻿using System;
using System.IO;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.MaintiFlow.Models;
using Calin.TaskPulse.MaintiFlow.Views;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow
{
    public class MaintiFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<MaintiFlowContext>().AsSelf().InstancePerLifetimeScope();

            builder.RegisterType<MaintiFlowPage>().AsSelf();
            builder.RegisterType<MaintiFlowSummary>().AsSelf();

            try
            {
                using (var context = new MaintiFlowContext())
                {
                    // 觸發資料庫初始化
                    context.Database.Initialize(force: true);
                }
            }
            catch (IOException ioe)
            {
                UIMessageBox.ShowError(ioe.Message);
                Application.Exit();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
    }
}
