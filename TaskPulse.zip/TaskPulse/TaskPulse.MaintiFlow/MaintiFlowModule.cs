﻿using Autofac;

namespace TaskPulse.MaintiFlow
{
    public class MaintiFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<MaintiFlowControl>().AsSelf();
        }
    }
}
