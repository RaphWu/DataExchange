﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.MaintiFlow.Contract
{
    /// <summary>
    /// 維護工單服務介面。
    /// </summary>
    public interface IMaintiFlow
    {
        /// <summary>
        /// 從核心資料更新。
        /// </summary>
        void UpdateFromCoreData();

        /// <summary>
        /// 初始化服務。
        /// </summary>
        void Initialize();
    }
}
