﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Views;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public partial class MaintiFlowService : ITaskOrderAction
    {
        /// <inheritdoc/>
        public bool CreateNewFlow()
        {
            using (var createFlow = _rootScope.Resolve<FT_CreateFlow>())
            {
                createFlow.Title = "新建工單";
                if (createFlow.ShowDialog() == DialogResult.OK)
                {
                    _ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);

                    using (var taskOrderView = _rootScope.Resolve<TaskOrderView>())
                    {
                        taskOrderView.Title = "工單已建立";
                        taskOrderView.NewWorkOrderNos = createFlow.NewWorkOrderNos;
                        taskOrderView.Initialize();
                        Core.Views.FormEx.ShowDialogWithMask(taskOrderView);
                        return true;
                    }
                }
            }
            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> CancelFlow()
        {
            var notAccepted = _flowData.TaskOrders.Where(t => t.Status == FlowStatus.NewTaskOrder).ToList();
            if (notAccepted.Any())
            {
                using (var acceptFlow = _rootScope.Resolve<FT_AcceptFlow>())
                {
                    acceptFlow.Title = "取消工單";
                    acceptFlow.OkCaption = "取消工單";
                    acceptFlow.Orders = notAccepted;
                    if (Core.Views.FormEx.ShowDialogWithMask(acceptFlow) == DialogResult.OK)
                    {
                        if (MessageBox.Show($"確定要取消工單？\n維護工單：\n{string.Join(Environment.NewLine, acceptFlow.SelectedOrder)}",
                             "取消工單確認",
                             MessageBoxButtons.OKCancel,
                             MessageBoxIcon.Question,
                             MessageBoxDefaultButton.Button2) == DialogResult.OK)
                        {
                            List<TaskOrder> tos = new List<TaskOrder>();
                            foreach (string orderId in acceptFlow.SelectedOrder)
                            {
                                TaskOrder to = _context.TaskOrders.FirstOrDefault(t => t.WorkOrderNo == orderId);
                                to.Status = FlowStatus.Completed;
                                to.FillingTime = DateTime.Now;
                                tos.Add(to);
                            }
                            await _context.SaveChangesAsync();
                            _ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);

                            List<string> pickOrderNames = new List<string>();
                            foreach (var to in tos)
                            {
                                var machine = _coreData.Machines.FirstOrDefault(m => m.Id == to.MachineId);
                                pickOrderNames.Add($"{to.WorkOrderNo}: {machine.MachineCode} » {machine.ModelName}");
                            }

                            // send email
                            StringBuilder mail = new StringBuilder();
                            mail.Append("<table><caption>取消工單</caption>");

                            mail.Append("<tr>");
                            mail.Append($"<td>{PropertyText.Title.Performer}</td>");
                            mail.Append($"<td>{_user.UserName}</td>");
                            mail.Append("</tr>");

                            mail.Append("<tr>");
                            mail.Append("<td>取消時間</td>");
                            mail.Append($"<td>{tos[0].FillingTimeString}</td>");
                            mail.Append("</tr>");

                            mail.Append("<tr>");
                            mail.Append("<td>取消工單</td>");
                            mail.Append($"<td>{string.Join("<br/>", pickOrderNames.ToArray())}</td>");
                            mail.Append("</tr>");

                            mail.Append("</table>");
                            _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", "取消工單",
                                           $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][取消工單] {_user.UserName} 取消 {pickOrderNames.Count} 張維護工單。",
                                           mail.ToString());

                            MessageBox.Show($"{_user.UserName} 已取消工單:\n{string.Join("\n", pickOrderNames.ToArray())}",
                                            "提示",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);

                        }
                    }
                    return true;
                }
            }
            else
            {
                MessageBox.Show("無可取消的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> AcceptFlow()
        {
            var notAccepted = _flowData.TaskOrders
                .OrderBy(t => t.WorkOrderNo)
                .Where(t => t.Status == FlowStatus.NewTaskOrder)
                .ToList();
            if (notAccepted.Any())
            {
                using (var acceptFlow = _rootScope.Resolve<FT_AcceptFlow>())
                {
                    acceptFlow.Title = "接單";
                    acceptFlow.OkCaption = "接單";
                    acceptFlow.Orders = notAccepted;
                    if (Core.Views.FormEx.ShowDialogWithMask(acceptFlow) == DialogResult.OK)
                    {
                        var tos = _context.TaskOrders;
                        List<TaskOrder> toList = new List<TaskOrder>();
                        foreach (string orderId in acceptFlow.SelectedOrder)
                        {
                            TaskOrder to = tos.FirstOrDefault(t => t.WorkOrderNo == orderId);
                            to.Status = FlowStatus.InProgress;
                            to.AcceptedTime = DateTime.Now;
                            to.Engineers = _user.CurrentUser != null
                                ? new HashSet<Employee>() { _context.Employees.FirstOrDefault(e => e.EmployeeId == _user.EmployeeId) }
                                : new HashSet<Employee>();
                            to.MaintenanceUnitId = _user.CurrentUser?.DepartmentId;
                            toList.Add(to);
                        }
                        await _context.SaveChangesAsync();
                        _ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);

                        List<string> pickOrderNames = new List<string>();
                        foreach (var to in toList)
                        {
                            var machine = _coreData.Machines.FirstOrDefault(m => m.Id == to.MachineId);
                            pickOrderNames.Add($"{to.WorkOrderNo}: {machine.MachineCode} » {machine.ModelName}");
                        }

                        // send email
                        StringBuilder mail = new StringBuilder();
                        mail.Append("<table><caption>接單</caption>");

                        mail.Append("<tr>");
                        mail.Append("<td>工程師</td>");
                        mail.Append($"<td>{_user.UserName}</td>");
                        mail.Append("</tr>");

                        mail.Append("<tr>");
                        mail.Append("<td>接單時間</td>");
                        mail.Append($"<td>{toList[0].AcceptedTimeString}</td>");
                        mail.Append("</tr>");

                        mail.Append("<tr>");
                        mail.Append("<td>承接工單</td>");
                        mail.Append($"<td>{string.Join("<br/>", pickOrderNames.ToArray())}</td>");
                        mail.Append("</tr>");

                        mail.Append("</table>");
                        _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", "接單",
                                       $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][接單] {_user.UserName} 承接 {pickOrderNames.Count} 張維護工單。",
                                       mail.ToString());

                        MessageBox.Show($"{_user.UserName} 已接單:\n{string.Join("\n", pickOrderNames.ToArray())}",
                                        "提示",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有新的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> MaintiWork()
        {
            using (var maintiWork = _rootScope.Resolve<FT_MaintiWork>())
            {
                maintiWork.Initialize();
                var tos = maintiWork.Orders;
                if (tos.Any())
                {
                    var engs = tos
                        .SelectMany(t => new[] { t.CreatorId }
                            .Concat(t.Engineers?.Select(e => e.Id) ?? Enumerable.Empty<int>()))
                        .Distinct()
                        .ToList();

                    //if (Core.Views.FormEx.ShowDialogWithMask(maintiWork) == DialogResult.OK)
                    if (maintiWork.ShowDialog() == DialogResult.OK)
                    {
                        //var to = _context.TaskOrders.FirstOrDefault(t => t.Id == acceptFlow.SelectedOrder.Id);
                        //if (to != null)
                        //{
                        //    to.StatusString = FlowStatus.InProgress;
                        //    var empId = _coreData.Employees.FirstOrDefault(e => e.Id == to.CreatorId)?.Id;
                        //    if (empId != null)
                        //    {
                        //        var t = _context.Employees.Find(empId);
                        //        if (t != null)
                        //            to.Engineer = new List<User> { t };
                        //    }
                        //    await _context.SaveChangesAsync();
                        //_ = WeakReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
                        //    MessageBox.Show($"{to.CreatorName.Name} 已接單: {to.WorkOrderNo}", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //}
                    }
                    return true;
                }
                else
                {
                    MessageBox.Show("沒有維護中的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
        }

        /// <inheritdoc/>
        public async Task<bool> FlowConfirmed()
        {
            var to = _flowData.TaskOrders.FirstOrDefault(t => t.Status == FlowStatus.Pending);
            if (to != null)
            {
                using (var flowConfirmed = _rootScope.Resolve<FT_FlowConfirmed>())
                {
                    //flowConfirmed.LoadData(to);
                    if (flowConfirmed.ShowDialog() == DialogResult.OK)
                    {
                        to = flowConfirmed.TaskOrder;

                        await _context.SaveChangesAsync();
                    }
                    _ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);
                }
            }
            else
            {
                MessageBox.Show("沒有待確認的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return false;
        }
    }
}
