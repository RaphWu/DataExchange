﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Views;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public partial class MaintiFlowService : ITaskOrderAction
    {
        /// <inheritdoc/>
        public bool CreateNewFlow()
        {
            _createFlow.Title = "新建工單";
            if (_createFlow.ShowDialog() == DialogResult.OK)
            {
                _taskOrderView.Title = "工單已建立";
                _taskOrderView.NewWorkOrderNos = _createFlow.NewWorkOrderNos;
                _taskOrderView.Initialize();
                Core.Views.FormEx.ShowDialogWithMask(_taskOrderView);
                return true;
            }

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> CancelFlow()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.NewTaskOrder).ToList();
            if (to.Any())
            {
                _acceptFlow.Title = "取消工單";
                _acceptFlow.OkCaption = "取消工單";
                _acceptFlow.Orders = to;
                if (Core.Views.FormEx.ShowDialogWithMask(_acceptFlow) == DialogResult.OK)
                {
                    //var order = _context.TaskOrders.FirstOrDefault(t => t.Id == _acceptFlow.SelectedOrder);
                    var order = _acceptFlow.SelectedOrder;
                    if (order != null)
                    {
                        order.Status = OrderStatus.Completed;
                        await _context.SaveChangesAsync();
                        await UpdateCache();
                    }
                }
                return true;
            }
            else
            {
                MessageBox.Show("無可取消的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> AcceptFlow()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.NewTaskOrder).ToList();
            if (to.Any())
            {
                _acceptFlow.Title = "接單";
                _acceptFlow.OkCaption = "接單";
                _acceptFlow.Orders = to;
                if (Core.Views.FormEx.ShowDialogWithMask(_acceptFlow) == DialogResult.OK)
                {
                    var order = _context.TaskOrders.FirstOrDefault(t => t.Id == _acceptFlow.SelectedOrder.Id);
                    if (order != null)
                    {
                        order.Status = OrderStatus.InProgress;
                        var empId = _coreData.Employees.FirstOrDefault(e => e.Id == order.CreatorId)?.Id;
                        if (empId != null)
                        {
                            var emp = _context.Employees.Find(empId);
                            if (emp != null)
                                order.Engineers = new List<Employee> { emp };
                        }
                        await _context.SaveChangesAsync();
                        await UpdateCache();
                        MessageBox.Show($"{order.Creator.Name} 已接單: {order.WorkOrderNo}", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有新的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> MaintiWork()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.InProgress).ToList();
            if (to.Any())
            {
                _maintiWork.EngineerList = to
                    .SelectMany(t => t.Engineers)
                    .Select(emp => emp.Id)
                    .Distinct()
                    .ToList();
                //if (Core.Views.FormEx.ShowDialogWithMask(_maintiWork) == DialogResult.OK)
                if (_maintiWork.ShowDialog() == DialogResult.OK)
                {
                    //var order = _context.TaskOrders.FirstOrDefault(t => t.Id == _acceptFlow.SelectedOrder.Id);
                    //if (order != null)
                    //{
                    //    order.Status = OrderStatus.InProgress;
                    //    var empId = _coreData.Employees.FirstOrDefault(e => e.Id == order.CreatorId)?.Id;
                    //    if (empId != null)
                    //    {
                    //        var emp = _context.Employees.Find(empId);
                    //        if (emp != null)
                    //            order.Engineer = new List<Employee> { emp };
                    //    }
                    //    await _context.SaveChangesAsync();
                    //    await UpdateCache();
                    //    MessageBox.Show($"{order.Creator.Name} 已接單: {order.WorkOrderNo}", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //}
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有維護中的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> FlowConfirmed()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.Pending).ToList();
            if (to.Any())
            {

            }
            else
            {
                MessageBox.Show("沒有待確認的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return false;
        }
    }
}
