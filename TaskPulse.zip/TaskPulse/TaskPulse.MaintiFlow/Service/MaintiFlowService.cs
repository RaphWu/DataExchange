﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    /// <summary>
    /// 維護工單服務。
    /// </summary>
    public partial class MaintiFlowService : IDisposable, IMaintiFlow
    {
        #region fields

        private ILifetimeScope _rootScope;
        private ILifetimeScope _currentScope;
        private UIForm _currentForm;

        private readonly CoreContext _context;
        private readonly CurrentAuthority _authority;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private bool _isInitialized = false;

        #endregion fields

        public MaintiFlowService(ILifetimeScope lifetimeScope,
                                 CoreContext coreContext,
                                 CurrentAuthority currentAuthority,
                                 CoreData coreData,
                                 MaintiFlowData maintiFlowData,
                                 FieldName fieldName,
                                 FieldTitle fieldTitle)
        {
            _rootScope = lifetimeScope;
            _context = coreContext;
            _authority = currentAuthority;
            _coreData = coreData;
            _flowData = maintiFlowData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;
        }

        /// <summary>
        /// 釋放註冊的事件。
        /// </summary>
        public void Dispose()
        {
            _currentScope?.Dispose();
            StrongReferenceMessenger.Default.Unregister<CoreDataChangedNotification>(this);
            StrongReferenceMessenger.Default.Unregister<MaintiFlowDataChangedNotification>(this);
        }

        /// <inheritdoc/>
        public async Task Initialize()
        {
            if (_isInitialized)
                return;

            //UpdateModelsCache();

            //_flowData.Engineer = _coreData.Employees
            //    .Where(e => e.IsEngineer)
            //    .Select(e => new Engineer
            //    {
            //        EmployeeId = e.EmployeeId,
            //        UnitName = e.UnitName,
            //        Department = e.Department,
            //        Title = e.Title
            //    })
            //    .ToList();

            _fieldName.TaskOrderId = nameof(TaskOrder.Id);
            _fieldName.WorkOrderNo = nameof(TaskOrder.WorkOrderNo);
            _fieldName.Status = nameof(TaskOrder.Status);
            _fieldName.StatusString = nameof(TaskOrder.StatusString);
            _fieldName.Machine = nameof(TaskOrder.Machine);
            _fieldName.MachineCode = nameof(TaskOrder.MachineCode);
            _fieldName.FullMachineName = nameof(TaskOrder.FullMachineName);
            _fieldName.Model = nameof(Model.ModelName);
            _fieldName.Workstation = nameof(TaskOrder.Workstation);
            _fieldName.WorkstationName = nameof(TaskOrder.WorkstationName);
            _fieldName.ModelWorkstationName = nameof(TaskOrder.ModelWorkstationName);
            _fieldName.Creator = nameof(TaskOrder.Creator);
            _fieldName.CreatorName = nameof(TaskOrder.CreatorName);
            _fieldName.CreatorHalfName = nameof(TaskOrder.CreatorHalfName);
            _fieldName.CreatorFullName = nameof(TaskOrder.CreatorFullName);
            _fieldName.CreationDateTime = nameof(TaskOrder.CreationDateTime);
            _fieldName.CreationDateTimeString = nameof(TaskOrder.CreationDateTimeString);
            _fieldName.CreationDateString = nameof(TaskOrder.CreationDateString);

            _fieldName.MaintenanceUnit = nameof(TaskOrder.MaintenanceUnit);
            _fieldName.MaintenanceUnitId = nameof(TaskOrder.MaintenanceUnitId);
            _fieldName.MaintenanceUnitString = nameof(TaskOrder.MaintenanceUnitString);
            _fieldName.UnitString = nameof(TaskOrder.MaintenanceUnitString);
            _fieldName.Engineers = nameof(TaskOrder.Engineers);
            _fieldName.EngineerString = nameof(TaskOrder.EngineerString);
            _fieldName.EngineerMultiString = nameof(TaskOrder.EngineerMultiString);
            _fieldName.AcceptedTime = nameof(TaskOrder.AcceptedTime);
            _fieldName.AcceptedTimeString = nameof(TaskOrder.AcceptedTimeString);
            _fieldName.IssueCategory = nameof(TaskOrder.IssueCategory);
            _fieldName.IssueCategoryId = nameof(TaskOrder.IssueCategoryId);
            _fieldName.IssueCategoryString = nameof(TaskOrder.IssueCategoryString);
            _fieldName.IssueDescription = nameof(TaskOrder.IssueDescription);
            _fieldName.Details = nameof(TaskOrder.Details);
            _fieldName.RepairStarted = nameof(TaskOrder.RepairStarted);
            _fieldName.RepairStartedString = nameof(TaskOrder.RepairStartedString);
            _fieldName.RepairCompleted = nameof(TaskOrder.RepairCompleted);
            _fieldName.RepairCompletedString = nameof(TaskOrder.RepairCompletedString);
            _fieldName.RepairDurationTick = nameof(TaskOrder.RepairDurationTick);
            _fieldName.RepairDuration = nameof(TaskOrder.RepairDuration);
            _fieldName.RepairDurationString = nameof(TaskOrder.RepairDurationString);
            _fieldName.FillingTime = nameof(TaskOrder.FillingTime);
            _fieldName.FillingTimeString = nameof(TaskOrder.FillingTimeString);

            _fieldName.RequestingUnit = nameof(TaskOrder.RequestingUnit);
            _fieldName.RequestingUnitString = nameof(TaskOrder.RequestingUnitString);
            _fieldName.FeedbackEmployee = nameof(TaskOrder.FeedbackEmployee);
            _fieldName.FeedbackEmployeeString = nameof(TaskOrder.FeedbackEmployeeString);
            _fieldName.Feedback = nameof(TaskOrder.Feedback);
            _fieldName.OutageStarted = nameof(TaskOrder.OutageStarted);
            _fieldName.OutageStartedString = nameof(TaskOrder.OutageStartedString);
            _fieldName.OutageEnded = nameof(TaskOrder.OutageEnded);
            _fieldName.OutageEndedString = nameof(TaskOrder.OutageEndedString);
            _fieldName.OutageDurationTick = nameof(TaskOrder.OutageDurationTick);
            _fieldName.OutageDuration = nameof(TaskOrder.OutageDuration);
            _fieldName.OutageDurationString = nameof(TaskOrder.OutageDurationString);

            _fieldName.Responsible = nameof(TaskOrder.Responsible);

            _fieldTitle.TaskOrderId = EnumHelper.GetDescription<TaskOrder>(_fieldName.TaskOrderId);
            _fieldTitle.WorkOrderNo = EnumHelper.GetDescription<TaskOrder>(_fieldName.WorkOrderNo);
            _fieldTitle.Status = EnumHelper.GetDescription<TaskOrder>(_fieldName.Status);
            _fieldTitle.Machine = EnumHelper.GetDescription<TaskOrder>(_fieldName.Machine);
            _fieldTitle.Model = EnumHelper.GetDescription<Model>(_fieldName.Model);
            _fieldTitle.Workstation = EnumHelper.GetDescription<TaskOrder>(_fieldName.Workstation);
            _fieldTitle.ModelWorkstationName = EnumHelper.GetDescription<TaskOrder>(_fieldName.ModelWorkstationName);
            _fieldTitle.Creator = EnumHelper.GetDescription<TaskOrder>(_fieldName.Creator);
            _fieldTitle.CreationDate = EnumHelper.GetDescription<TaskOrder>(_fieldName.CreationDateTime);

            _fieldTitle.MaintenanceUnit = EnumHelper.GetDescription<TaskOrder>(_fieldName.MaintenanceUnit);
            _fieldTitle.Engineer = EnumHelper.GetDescription<TaskOrder>(_fieldName.Engineers);
            _fieldTitle.AcceptedTime = EnumHelper.GetDescription<TaskOrder>(_fieldName.AcceptedTime);
            _fieldTitle.IssueCategory = EnumHelper.GetDescription<TaskOrder>(_fieldName.IssueCategory);
            _fieldTitle.IssueDescription = EnumHelper.GetDescription<TaskOrder>(_fieldName.IssueDescription);
            _fieldTitle.Details = EnumHelper.GetDescription<TaskOrder>(_fieldName.Details);
            _fieldTitle.RepairStarted = EnumHelper.GetDescription<TaskOrder>(_fieldName.RepairStarted);
            _fieldTitle.RepairCompleted = EnumHelper.GetDescription<TaskOrder>(_fieldName.RepairCompleted);
            _fieldTitle.RepairDuration = EnumHelper.GetDescription<TaskOrder>(_fieldName.RepairDuration);
            _fieldTitle.FillingTime = EnumHelper.GetDescription<TaskOrder>(_fieldName.FillingTime);

            _fieldTitle.RequestingUnit = EnumHelper.GetDescription<TaskOrder>(_fieldName.RequestingUnit);
            _fieldTitle.FeedbackEmployee = EnumHelper.GetDescription<TaskOrder>(_fieldName.FeedbackEmployee);
            _fieldTitle.Feedback = EnumHelper.GetDescription<TaskOrder>(_fieldName.Feedback);
            _fieldTitle.OutageStarted = EnumHelper.GetDescription<TaskOrder>(_fieldName.OutageStarted);
            _fieldTitle.OutageEnded = EnumHelper.GetDescription<TaskOrder>(_fieldName.OutageEnded);
            _fieldTitle.OutageDuration = EnumHelper.GetDescription<TaskOrder>(_fieldName.OutageDuration);

            _fieldTitle.Responsible = EnumHelper.GetDescription<TaskOrder>(_fieldName.Responsible);

            // 註冊核心共用資料更新訊息。
            StrongReferenceMessenger.Default.Register<CoreDataChangedNotification>(this, async (r, m) =>
            {
                await UpdateCache();
            });
            StrongReferenceMessenger.Default.Register<MaintiFlowDataChangedNotification>(this, async (r, m) =>
            {
                await UpdateCache();
            });

            await UpdateCache();
            _isInitialized = true;
        }

        /// <inheritdoc/>
        public async Task UpdateCache()
        {
            _flowData.TaskOrders = await _context.TaskOrders
                //.Include(t => t.Creator.Department)
                //.Include(t => t.Creator.Title)
                .Include(t => t.Creator)
                .Include(t => t.Engineers)
                .Include(t => t.Machine)
                .Include(t => t.Workstation)
                .Include(t => t.MaintenanceUnit)
                .Include(t => t.IssueCategory)
                .Include(t => t.RequestingUnit)
                .Include(t => t.FeedbackEmployee)
                .OrderByDescending(to => to.WorkOrderNo)
                .AsNoTracking()
                .ToListAsync();

            //_flowData.TaskOrders = await _context.TaskOrders
            //    .Include(t => t.Machine)
            //    .Include(t => t.Workstation.Model)
            //    .Include(t => t.Creator.Department)
            //    .Include(t => t.Engineers)
            //    .Include(t => t.MaintenanceUnit)
            //    .Include(t => t.IssueCategory)
            //    .Include(t => t.RequestingUnit)
            //    .Include(t => t.FeedbackEmployee)
            //    .OrderByDescending(to => to.Id)
            //    .AsNoTracking()
            //    .ToListAsync();

            StrongReferenceMessenger.Default.Send(MaintiFlowCacheChangedNotification.Instance);
        }
    }
}
