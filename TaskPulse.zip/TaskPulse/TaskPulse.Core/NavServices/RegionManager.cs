﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavServices
{
    public class RegionManager : IRegionManager
    {
        private readonly Dictionary<string, IRegion> _regions = new Dictionary<string, IRegion>();

        public void RegisterRegion(string name, Control control)
        {
            _regions[name] = new Region(name, control);
        }

        public IRegion GetRegion(string name)
        {
            if (_regions.TryGetValue(name, out var region))
                return region;

            throw new KeyNotFoundException($"Region '{name}' not found.");
        }
    }
}
