﻿//using System;
//using System.Collections.Generic;
//using System.Windows.Forms;
//using Autofac;

////我要設計一個VIEW管理器，管理AUTOFAC註冊的VIEW，要能指定是否要ALIVE模式(緩存)，能使用在多層的VIEW結構。WINFORM+.NET462，沒有使用MVVM

//public class ViewManager : IDisposable
//{
//    private readonly ILifetimeScope _rootScope;
//    private readonly Control _contentHost;

//    // 追蹤當前活躍 View 樹的專屬 Scope
//    private ILifetimeScope _activeViewScope;

//    // 🏆 緩存字典：儲存已創建的 View 實例及其 Scope
//    // Key: View 類型 (例如 typeof(MaintiFlowPage))
//    // Value: 該 View 實例的專屬 Scope
//    private readonly Dictionary<Type, ILifetimeScope> _viewCache =
//        new Dictionary<Type, ILifetimeScope>();

//    public ViewManager(ILifetimeScope rootScope, Control contentHost)
//    {
//        _rootScope = rootScope;
//        _contentHost = contentHost;
//    }

//    public TView ShowView<TView>() where TView : UserControl
//    {
//        var viewType = typeof(TView);

//        // 1. 將當前顯示的 View 隱藏並存入緩存 (如果還沒有被緩存)
//        HideCurrentView();

//        TView newView;

//        // 2. 檢查緩存：如果 View 已經存在
//        if (_viewCache.TryGetValue(viewType, out var cachedScope))
//        {
//            // 🚨 緩存命中：
//            // 只需要取得緩存中的 View 實例，因為它還活著
//            // 在 WinForms 樹中，UserControl 的 Controls[0] 就是它自己
//            newView = (TView)cachedScope.Resolve<TView>();
//            _activeViewScope = cachedScope; // 設定當前活躍 Scope
//        }
//        else
//        {
//            // 🚨 緩存未命中：
//            // 像以前一樣創建新 Scope，但這次不處置它
//            var newScope = _rootScope.BeginLifetimeScope("CachedViewScope");
//            newView = newScope.Resolve<TView>();

//            // 將新創建的 Scope 存入緩存
//            _viewCache[viewType] = newScope;
//            _activeViewScope = newScope; // 設定當前活躍 Scope
//        }

//        // 3. 顯示 View
//        _contentHost.SuspendLayout();
//        _contentHost.Controls.Clear(); // 移除舊的 UserControl (已被隱藏)

//        newView.Dock = DockStyle.Fill;
//        _contentHost.Controls.Add(newView);

//        _contentHost.ResumeLayout();

//        return newView;
//    }

//    private void HideCurrentView()
//    {
//        // 舊的邏輯是 DisposeCurrentViewScope()

//        if (_activeViewScope != null)
//        {
//            // 1. 從 UI 容器中移除 View (不 Dispose)
//            if (_contentHost.Controls.Count > 0)
//            {
//                _contentHost.Controls.Clear(); // 清空容器
//            }

//            // 2. 保持 _activeViewScope 活躍，因為它已在 _viewCache 中
//            // 重置 _activeViewScope 變數，表示目前沒有 View 是活躍的
//            _activeViewScope = null;
//        }
//    }

//    public void Dispose()
//    {
//        // 處置所有緩存的 View Scope，釋放所有 UI 資源
//        foreach (var scope in _viewCache.Values)
//        {
//            scope.Dispose();
//        }
//        _viewCache.Clear();

//        // 確保當前 UI 也是空的
//        if (_contentHost.Controls.Count > 0)
//        {
//            _contentHost.Controls.Clear();
//        }
//    }
//}