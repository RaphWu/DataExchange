﻿using System;
using System.Collections.Generic;
using Autofac;
using Calin.TaskPulse.Core.NavContracts;

namespace Calin.TaskPulse.Core.NavServices
{
    public class ViewManager : IViewManager
    {
        private readonly ILifetimeScope _rootScope;
        private readonly Dictionary<Type, ILifetimeScope> _aliveScopes = new Dictionary<Type, ILifetimeScope>();

        public ViewManager(ILifetimeScope rootScope)
        {
            _rootScope = rootScope;
        }

        public object Resolve(Type viewType, bool alive = false)
        {
            if (!alive)
                return _rootScope.Resolve(viewType);

            if (_aliveScopes.TryGetValue(viewType, out var scope))
                return scope.Resolve(viewType);

            var childScope = _rootScope.BeginLifetimeScope();
            var view = childScope.Resolve(viewType);
            _aliveScopes[viewType] = childScope;
            return view;
        }

        public TView Resolve<TView>(bool alive = false) where TView : class
        {
            return (TView)Resolve(typeof(TView), alive);
        }

        public void Release(Type viewType)
        {
            if (_aliveScopes.TryGetValue(viewType, out var scope))
            {
                scope.Dispose();
                _aliveScopes.Remove(viewType);
            }
        }

        public void Release<TView>() where TView : class
        {
            Release(typeof(TView));
        }
    }

}
