﻿using Calin.TaskPulse.Core.Contants;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Event
{
    /// <summary>
    /// 頁面切換事件。
    /// </summary>
    public class PageChangedMessage : ValueChangedMessage<PageCode>
    {
        public PageChangedMessage(PageCode pageCode) : base(pageCode) { }
    }
}
