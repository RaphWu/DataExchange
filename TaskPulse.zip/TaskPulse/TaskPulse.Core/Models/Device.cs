﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 設備基本資料。
    /// </summary>
    public class Device
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 設備編號。
        /// </summary>
        [Description("設備編號")]
        [Index(IsUnique = true)]
        [MaxLength(10)]
        public string DeviceId { get; set; }

        /// <summary>
        /// 設備是否已被處置 (除帳/報廢...)。
        /// </summary>
        [Description("處置")]
        public bool Disposal { get; set; }

        /// <summary>
        /// 設備名稱。
        /// </summary>
        [Description("設備名稱")]
        public DeviceName DeviceName { get; set; }
        public int DeviceNameId { get; set; } // FK

        /// <summary>
        /// 廠牌。
        /// </summary>
        [Description("廠牌")]
        public Brand Brand { get; set; }
        public int BrandId { get; set; } // FK

        /// <summary>
        /// 設備序號。
        /// </summary>
        [Description("設備序號")]
        [MaxLength(20)]
        public string SerialNumber { get; set; }

        /// <summary>
        /// 資產編號。
        /// </summary>
        [Description("資產編號")]
        public virtual ICollection<AssetCode> Assets { get; set; } = new List<AssetCode>();

        /// <summary>
        /// 位置。
        /// </summary>
        [Description("位置")]
        public DeviceLocation Location { get; set; }
        public int LocationId { get; set; } // FK

        /// <summary>
        /// 設備狀態。
        /// </summary>
        [Description("設備狀態")]
        public DeviceCondition Condition { get; set; }
        public int ConditionId { get; set; } // FK

        /// <summary>
        /// 條碼。
        /// </summary>
        [Description("條碼")]
        [MaxLength(50)]
        public string Barcode { get; set; }

        /// <summary>
        /// 能否連網。
        /// </summary>
        [Description("能否連網")]
        public bool Connected { get; set; }

        /// <summary>
        /// 備註。
        /// </summary>
        [Description("備註")]
        public string Remark { get; set; }
    }
}
