﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.Core.Models
{
    /********************
     * SqliteDropCreateDatabaseAlways // 每次執行都刪除並重建資料庫
     * SqliteCreateDatabaseIfNotExists // 如果資料庫不存在，則建立資料庫並初始化預設資料。
     * SqliteDropCreateDatabaseWhenModelChanges // 如果模型有變更，則刪除並重建資料庫。
     ********************/
    /// <summary>
    /// AssetCode First 初始化類別。
    /// </summary>
    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
    public class CoreInitializer : SqliteCreateDatabaseIfNotExists<CoreContext>
    {
        public CoreInitializer(DbModelBuilder modelBuilder) : base(modelBuilder)
        {
        }

        protected override void Seed(CoreContext context)
        {
            int recCount;
            int orderNo;

            orderNo = 0;
            var dbDep = context.Set<Department>();
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "設備部" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "組裝製造部" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "第一製造部" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "成形部" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "模具部" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "光學開發部" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "機構開發部" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "元件開發部" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "光學開發部2" });
            dbDep.Add(new Department() { OrderNo = orderNo++, DepartmentName = "機構開發部2" });

            orderNo = 0;
            var dbTitle = context.Set<Title>();
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "經理" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "副理" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "課長" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "副課長" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "主任" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "副主任" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "工程師" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "副工程師" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "管理師" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "副管理師" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "領班" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "高級技術員" });
            dbTitle.Add(new Title() { OrderNo = ++orderNo, TitleName = "技術員" });

            orderNo = 0;
            var dCategory = context.Set<MachineCategory>();
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo, CategoryName = "半自動生產設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo, CategoryName = "全自動生產設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo, CategoryName = "檢測設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo, CategoryName = "其他" });

            orderNo = 0;
            var dType = context.Set<MachineType>();
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "打壓機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "插入機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "斜點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "中壓斜點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "桌上型點膠機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "熔著機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "21039自動線" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "UV照射機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "氣密檢漏儀" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "鎖附機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "PF機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "儀科MTF機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "鬼影機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "鉚合機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo, TypeName = "切割機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "高度量測" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "自動組裝機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "自動整列機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "高速點膠機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "自動鎖附機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "三合一點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo, TypeName = "貼膜設備" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo, TypeName = "調芯機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo, TypeName = "拆解機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo, TypeName = "成形扭斷" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo, TypeName = "氣密自動檢測機台" });

            orderNo = 0;
            var brand = context.Set<MachineBrand>();
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "自製" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "晟普" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "點膠科技" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "稼動科技" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "立璽(LIHSI)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "高興易" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "衫綺" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "勛凱" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "USHIO" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "KGN" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "MUSASHI" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "IEI(iwashitainstrumemt)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "九驊" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "儀科" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "客戶製" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "元利盛(EVEST)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "翔元(SYAUTO)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "瀚升" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo, BrandName = "儀銳" });

            orderNo = 0;
            var cond = context.Set<MachineCondition>();
            cond.Add(new MachineCondition() { OrderNo = ++orderNo, Condition = "稼動中" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo, Condition = "停動中" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo, Condition = "檢討室" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo, Condition = "RD檢討室" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo, Condition = "微小倉庫" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo, Condition = "試作線上" });

            var model = context.Set<Model>();
            model.Add(new Model() { ModelName = "其他" });
            model.Add(new Model() { ModelName = "155" });
            model.Add(new Model() { ModelName = "260" });
            model.Add(new Model() { ModelName = "271" });
            model.Add(new Model() { ModelName = "273" });
            model.Add(new Model() { ModelName = "281" });
            model.Add(new Model() { ModelName = "283" });
            model.Add(new Model() { ModelName = "366" });
            model.Add(new Model() { ModelName = "453" });
            model.Add(new Model() { ModelName = "459" });
            model.Add(new Model() { ModelName = "467" });
            model.Add(new Model() { ModelName = "561" });
            model.Add(new Model() { ModelName = "563" });
            model.Add(new Model() { ModelName = "568" });
            model.Add(new Model() { ModelName = "570" });
            model.Add(new Model() { ModelName = "575" });
            model.Add(new Model() { ModelName = "585" });
            model.Add(new Model() { ModelName = "19008" });
            model.Add(new Model() { ModelName = "20006" });
            model.Add(new Model() { ModelName = "20007" });
            model.Add(new Model() { ModelName = "20019" });
            model.Add(new Model() { ModelName = "20056" });
            model.Add(new Model() { ModelName = "21018" });
            model.Add(new Model() { ModelName = "21028" });
            model.Add(new Model() { ModelName = "21039" });
            model.Add(new Model() { ModelName = "22001" });
            model.Add(new Model() { ModelName = "23010" });
            model.Add(new Model() { ModelName = "23021" });
            model.Add(new Model() { ModelName = "23069" });
            model.Add(new Model() { ModelName = "23070" });
            model.Add(new Model() { ModelName = "23071" });
            model.Add(new Model() { ModelName = "23073" });
            model.Add(new Model() { ModelName = "24301" });
            model.Add(new Model() { ModelName = "132-07" });
            model.Add(new Model() { ModelName = "19003-04" });
            model.Add(new Model() { ModelName = "19003-06" });
            model.Add(new Model() { ModelName = "20007-AS2" });
            model.Add(new Model() { ModelName = "20007-AS3" });
            model.Add(new Model() { ModelName = "417-01" });
            model.Add(new Model() { ModelName = "417-02" });
            model.Add(new Model() { ModelName = "568-02" });

            //var fLoc = context.Set<Factory>();
            //fLoc.Add(new Factory() { FactoryName = "本廠" });
            //fLoc.Add(new Factory() { FactoryName = "區北廠" });
            //fLoc.Add(new Factory() { FactoryName = "嘉義廠" });

            orderNo = 0;
            var mu = context.Set<MaintenanceUnit>();
            mu.Add(new MaintenanceUnit() { OrderNo = ++orderNo, UnitName = "工具/設計課" });
            mu.Add(new MaintenanceUnit() { OrderNo = ++orderNo, UnitName = "自働化課" });

            orderNo = 0;
            var ic = context.Set<IssueCategory>();
            ic.Add(new IssueCategory() { OrderNo = ++orderNo, CategoryName = "日常維護" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo, CategoryName = "機台保養" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo, CategoryName = "更換零件" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo, CategoryName = "機台改線" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo, CategoryName = "故障中待協助" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo, CategoryName = "異常排除" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo, CategoryName = "機台功能追加" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo, CategoryName = "機台移動" });

            orderNo = 0;
            var ru = context.Set<RequestingUnit>();
            ru.Add(new RequestingUnit() { OrderNo = ++orderNo, UnitName = "組立" });
            ru.Add(new RequestingUnit() { OrderNo = ++orderNo, UnitName = "製技" });
            ru.Add(new RequestingUnit() { OrderNo = ++orderNo, UnitName = "RD" });
            ru.Add(new RequestingUnit() { OrderNo = ++orderNo, UnitName = "試作" });
            ru.Add(new RequestingUnit() { OrderNo = ++orderNo, UnitName = "試作開發" });
            ru.Add(new RequestingUnit() { OrderNo = ++orderNo, UnitName = "品管" });

            context.SaveChanges();

            var dep = dbDep.ToList();
            var title = dbTitle.ToList();
            var employees = context.Set<Employee>();

            orderNo = 0;
            List<string> tmpId = new List<string>() { "06268", "07126", "07271", "07484", "06662", "08525", "08532", "07383", "07346", "06793", "07670", "07867", "07932", "08304", "07910", "00001", "00002", "00003", "00004" };
            List<string> tmpTitle = new List<string>() { "副理", "課長", "工程師", "工程師", "副工程師", "副工程師", "副工程師", "工程師", "工程師", "工程師", "主任", "副工程師", "副工程師", "副工程師", "副工程師", "副工程師", "副工程師", "副工程師", "副工程師" };
            List<string> tmpNames = new List<string>() { "黃建勝", "蔡孟堅", "苗天恒", "李起修", "呂明哲", "吳仁中", "謝定傑", "李書銘", "林昱仁", "徐維隆", "周明謙", "張銘晉", "林柏俊", "張瑞寶", "劉庭源", "葉柏均", "鄭大德", "曾惠鈴", "張志榮" };
            foreach (var name in tmpNames)
            {
                employees.Add(new Employee()
                {
                    EmployeeId = tmpId[orderNo],
                    Name = tmpNames[orderNo],
                    Title = title.FirstOrDefault(t => t.TitleName == tmpTitle[orderNo]),
                    Department = dep.FirstOrDefault(d => d.DepartmentName == "設備部"),
                    IsEngineer = tmpNames[orderNo] != "黃建勝",
                });
                orderNo++;
            }

            orderNo = 0;
            tmpId = new List<string>() { "00600", "00350", "04289", "06690", "07084", "00443", "00725", "02194", "01268", "01281", "05723", "02017", "02176", "02098", "02492", "02296", "01289", "01269", "01259", "03061" };
            tmpTitle = new List<string>() { "課長", "副工程師", "副管理師", "技術員", "課長", "主任", "領班", "副主任", "領班", "領班", "領班", "技術員", "主任", "副主任", "領班", "主任", "副主任", "領班", "領班", "領班" };
            tmpNames = new List<string>() { "康淑貞", "温秋香", "詹雅惠", "林俊廷", "林昆達", "侯倩玉", "賴惠珠", "李雅婷", "阮碧幸", "黎氏鳳", "陳寶琴", "陳盈蓁", "蔡素貞", "黃姿蓉", "黃玉紅", "黃琪雯", "楊瓊瑛", "余沂霈", "許凱婷", "黃嘉惠" };
            foreach (var name in tmpNames)
            {
                employees.Add(new Employee()
                {
                    EmployeeId = tmpId[orderNo],
                    Name = tmpNames[orderNo],
                    Title = title.FirstOrDefault(t => t.TitleName == tmpTitle[orderNo]),
                    Department = dep.FirstOrDefault(d => d.DepartmentName == "組裝製造部"),
                });
                orderNo++;
            }

            orderNo = 0;
            tmpId = new List<string>() { "00683", "07065", "07197", "07785", "07786", "04997", "06679", "07564", "08443", "07477", "07361", "04397", "06348", "06922", "07510", "00251", "01725", "07157", "00096", "01743", "08413", "06139", "03054", "06200", "00675", "01711", "00728", "07688" };
            tmpTitle = new List<string>() { "課長", "工程師", "工程師", "工程師", "工程師", "主任", "副工程師", "副工程師", "副工程師", "領班", "副工程師", "高級技術員", "副管理師", "副理師", "副理", "主任", "主任", "副主任", "副工程師", "領班", "主任", "副主任", "領班", "領班", "副工程師", "副主任", "副工程師", "領班" };
            tmpNames = new List<string>() { "林宜君", "林銘璋", "林宏諺", "羅文廷", "李銓淙", "温孟巡", "陳俊豪", "黃昭旭", "吳品辰", "廖翊智", "廖于盛", "呂佩盈", "林欣儀", "張詠琇", "林瑞斌", "陳淑英", "蔡俊弘", "廖宥嘉", "吳燕燕", "蔡育哲", "黃延誠", "陳建竹", "朱艷華", "林千惠", "丁武艷珠", "黃子珊", "黃羿婷", "傅建璋" };
            foreach (var name in tmpNames)
            {
                employees.Add(new Employee()
                {
                    EmployeeId = tmpId[orderNo],
                    Name = tmpNames[orderNo],
                    Title = title.FirstOrDefault(t => t.TitleName == tmpTitle[orderNo]),
                    Department = dep.FirstOrDefault(d => d.DepartmentName == "第一製造部"),
                });
                orderNo++;
            }

            context.SaveChanges();

            var machines = context.Set<Machine>();
            var wss = context.Set<Workstation>();
            var assCode = context.Set<MachineAssetCode>();
            var ctLoc = context.Set<MachineLocation>();

            try
            {
                //var machineName = context.Set<MachineNames>();
                var machineName = new HashSet<(string Model, string TypeName)>(context.MachineNames
                    .Include(d => d.MachineType)
                    .Include(d => d.MachineType.Category)
                    .Select(d => new { d.ModelName, d.MachineType.TypeName })
                    .AsEnumerable()
                    .Select(x => (x.ModelName, x.TypeName))
                    );

                ////var factory = context.Set<MachineLocation>();
                //var factory = new HashSet<(string Factory, string Location)>(context.MachineLocations
                //    .Include(d => d.Factory)
                //    .Select(d => new { d.Factory.FactoryName, d.Location })
                //    .AsEnumerable()
                //    .Select(x => (x.FactoryName, x.Location))
                //    );

                recCount = 0;
                orderNo = 0;
                // 一對多
                using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                {
                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var type = data[1].Trim();
                            var mName = data[3].Trim();
                            var dKey = (mName, type);
                            if (!machineName.Contains(dKey))
                            {
                                var mn = new MachineName
                                {
                                    MachineType = dType.FirstOrDefault(x => x.TypeName == type),
                                    ModelName = mName,
                                };

                                context.MachineNames.Add(mn);
                                machineName.Add(dKey);
                            }

                            //if (machineName.Local.FirstOrDefault(x => x.Value == mName && x.MachineType.TypeName == type) == null)
                            //{
                            //    machineName.Add(new MachineNames()
                            //    {
                            //        MachineType = dType.FirstOrDefault(x => x.TypeName == type),
                            //        Value = mName,
                            //    });
                            //}

                            var loc = $"{data[6].Trim()}, {data[7].Trim()}";
                            var oLoc = ctLoc.FirstOrDefault(x => x.Location == loc);
                            if (oLoc == null)
                            {
                                ctLoc.Add(new MachineLocation { Location = loc, OrderNo = ++orderNo });
                                context.SaveChanges();
                            }

                            //if (!factory.Contains(fKey))
                            //{
                            //    var newLoc = new MachineLocation
                            //    {
                            //        Factory = fLoc.FirstOrDefault(x => x.FactoryName == fac),
                            //        Location = loc,
                            //    };

                            //    context.MachineLocations.Add(newLoc);
                            //    factory.Add(fKey);
                            //}

                            //if (factory.FirstOrDefault(x => x.Location == loc && x.Factory.FactoryName == fac) == null)
                            //{
                            //    factory.Add(new MachineLocation()
                            //    {
                            //        Factory = fLoc.FirstOrDefault(x => x.FactoryName == fac),
                            //        Location = loc,
                            //    });
                            //}
                        }
                    }
                    context.SaveChanges();
                }

                /********************
                 * WorkstationName
                 ********************/
                recCount = 0;
                orderNo = 0;
                using (var sr = new StreamReader("設備維修履歷_Import.txt", Encoding.Default))
                {
                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            Model thisModel = null;
                            string moData = default;
                            if (!string.IsNullOrWhiteSpace(data[15]))
                            {
                                moData = data[15].Trim();
                                thisModel = model.FirstOrDefault(x => x.ModelName == moData);
                            }

                            if (!string.IsNullOrWhiteSpace(data[16]))
                            {
                                var wsData = data[16].Trim();
                                var ws = wss.FirstOrDefault(x => x.WorkstationName == wsData && x.Model.ModelName == moData);
                                if (ws == null)
                                {
                                    ws = new Workstation()
                                    {
                                        WorkstationName = wsData,
                                        Model = thisModel,
                                        OrderNo = ++orderNo,
                                    };
                                    wss.Add(ws);
                                    context.SaveChanges();
                                }
                            }
                        }
                    }
                    context.SaveChanges();
                }

                /********************
                 * MachineLocations
                 ********************/
                recCount = 0;
                orderNo = 0;
                using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                {
                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var machine = new Machine();

                            string deviceId = data[0].Trim();
                            machine.MachineId = deviceId;

                            var type = data[1].Trim();
                            var mName = data[3].Trim();
                            var mn = context.MachineNames.FirstOrDefault(x => x.ModelName == mName && x.MachineType.TypeName == type);
                            if (mn != null)
                            {
                                machine.MachineName = mn;
                            }

                            var bName = data[2].Trim();
                            machine.Brand = brand.FirstOrDefault(x => x.BrandName == bName);
                            machine.SerialNumber = data[4].Trim();

                            if (data[5].StartsWith("\""))
                                data[5] = data[5].Substring(1, data[5].Length - 2);
                            var assets = data[5].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                            .Select(x => x.Trim())
                                            .Where(x => x != "無" && !string.IsNullOrWhiteSpace(x))
                                            .Distinct()
                                            .ToList();
                            machine.Assets = new List<MachineAssetCode>();
                            foreach (var a in assets)
                                machine.Assets.Add(new MachineAssetCode() { AssetCode = a });

                            var loc = $"{data[6].Trim()}, {data[7].Trim()}";
                            var mmLoc = context.MachineLocations.FirstOrDefault(x => x.Location == loc);
                            if (mmLoc != null)
                                machine.Location = mmLoc;

                            var cnd = data[8].Trim();
                            machine.Condition = cond.FirstOrDefault(x => x.Condition == cnd);
                            machine.Barcode = data[9].Trim();
                            machine.Connected = !string.IsNullOrWhiteSpace(data[10].Trim());
                            machine.Remark = data[11].Trim();

                            machines.Add(machine);
                        }
                    }

                    var t = machines.FirstOrDefault(x => x.MachineId == "SAL-1");
                    if (t != null)
                        t.Disposal = true;
                    context.SaveChanges();
                }

                /********************
                 * 
                 ********************/

                //var depList = context.Set<Department>();
                //foreach (var dl in depList)
                //{
                //    dbDep.Add(new Department() { DepartmentName = dl.DepartmentName, });
                //}

                //var titleList = context.Set<Title>();
                //var dbTitle = context.Set<Title>();
                //foreach (var tl in titleList)
                //{
                //    dbTitle.Add(new Title() { TitleName = tl.TitleName, });
                //}
                //context.SaveChanges();

                //var empList = context.Set<Employee>()
                //    .OrderBy(e => e.EmployeeId)
                //    .ToList();
                //var employees = context.Set<Employee>();
                //var buffs = empList.Select(e =>
                //{
                //    var dd = dbDep.FirstOrDefault(d => d.Key == e.Key);
                //    var tt = (e.Key > 0) ? dbTitle.FirstOrDefault(d => d.Key == e.Key) : null;

                //    return new Employee
                //    {
                //        EmployeeId = e.EmployeeId,
                //        UnitName = e.UnitName,
                //        Department = dd,
                //        Title = tt,
                //        IsEngineer = e.IsEngineer,
                //    };
                //}).ToList();
                //employees.AddRange(buffs);

                //var deviceList = context.Set<Core.Models.MachineLocations>()
                //    .Include(d => d.MachineName.MachineType)
                //    .ToList();
                //var mn = context.Set<MachineLocations>();
                //foreach (var w in deviceList)
                //{
                //    mn.Add(new MachineLocations()
                //    {
                //        MachineId = w.MachineId,
                //        MachineName = w.MachineName,
                //    });
                //}

                //var modelList = context.Set<Model>().ToList();
                //foreach (var ml in modelList)
                //{
                //    model.Add(new Model()
                //    {
                //        Value = ml.Value,
                //    });
                //}
                //context.SaveChanges();

                //var workstationList = context.Set<WorkstationName>().ToList();
                //foreach (var w in workstationList)
                //{
                //    var mb = model.FirstOrDefault(m => m.Key == w.Key);
                //    wss.Add(new WorkstationName()
                //    {
                //        WorkstationName = w.WorkstationName,
                //        Model = mb,
                //    });
                //}
                //context.SaveChanges();

                /********************
                 * TaskOrder
                 ********************/
                recCount = 0;
                orderNo = 0;
                using (var sr = new StreamReader("設備維修履歷_Import.txt", Encoding.Default))
                {
                    string[] sList;

                    var mod = context.Set<Model>().ToList();
                    var machine = context.Set<Machine>().Include(m => m.MachineName).ToList();
                    var engineers = context.Set<Employee>().Where(e => e.IsEngineer).ToList();

                    var tos = context.Set<TaskOrder>();
                    string data;

                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] datas = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var to = new TaskOrder();
                            string workOrderNo = datas[1].Trim();

                            to.OrderNo = int.Parse(datas[0]);
                            to.WorkOrderNo = workOrderNo;

                            string empName = datas[2].Trim();
                            to.Creator = employees.FirstOrDefault(x => x.Name == empName);
                            //to.CreatorId = (to.CreatorName != null) ? to.CreatorName.EmployeeId : string.Empty;

                            to.CreationDateTime = DateTime.Parse(datas[3]);

                            string muName = datas[4].Trim();
                            if (muName == "工具設計")
                                to.MaintenanceUnit = mu.FirstOrDefault(x => x.Id == 1);
                            else
                                to.MaintenanceUnit = mu.FirstOrDefault(x => x.Id == 2);

                            sList = datas[5].Split('/');
                            to.Engineers = new List<Employee>();
                            foreach (var d5 in sList)
                            {
                                var e = engineers.FirstOrDefault(x => x.Name == d5);
                                if (e != null)
                                    to.Engineers.Add(e);
                            }

                            data = datas[6].Trim();
                            var mac = machine.FirstOrDefault(x => x.MachineId == data);
                            to.MachineId = (mac != null) ? mac.Id : 0;
                            to.Machine = null;

                            //var d6 = datas[6].Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries)
                            //                .Select(x => x.Trim())
                            //                .Where(x => !string.IsNullOrWhiteSpace(x))
                            //                .Distinct()
                            //                .ToList();
                            //to.MachineId = new List<MachineId>();
                            //foreach (var d_6 in d6)
                            //{
                            //    var mch = deviceList.FirstOrDefault(x => x.MachineId == d_6);
                            //    if (mch != null)
                            //        to.MachineId.Add(new MachineId
                            //        {
                            //            WorkOrderNo = workOrderNo,
                            //            MachineId = mch.MachineId,
                            //        });
                            //}

                            to.AcceptedTime = DateTime.Parse(string.Concat(datas[3], " ", datas[7]));

                            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[8]), out DateTime rs))
                                to.RepairStarted = rs;
                            else
                                to.RepairStarted = null;

                            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[9]), out DateTime rc))
                                to.RepairCompleted = rc;
                            else
                                to.RepairCompleted = null;

                            if (int.TryParse(datas[10], out int rd))
                                to.RepairDuration = TimeSpan.FromMinutes(rd);
                            else
                            {
                                if (rs == null || rc == null)
                                    to.RepairDuration = TimeSpan.Zero;
                                else
                                    to.RepairDuration = rc - rs;
                            }

                            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[11]), out DateTime os))
                                to.OutageStarted = os;
                            else
                                to.OutageStarted = null;

                            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[12]), out DateTime oe))
                                to.OutageEnded = oe;
                            else
                                to.OutageEnded = null;

                            if (int.TryParse(datas[13], out int od))
                            //    to.OutageDuration = TimeSpan.FromMinutes(od);
                            //else
                            {
                                if (os == null || oe == null)
                                    to.OutageDuration = TimeSpan.Zero;
                                else
                                    to.OutageDuration = oe - os;
                            }

                            //if (!string.IsNullOrWhiteSpace(datas[15]))
                            //{
                            //    string name = datas[15].Trim();
                            //    to.Model = mod.FirstOrDefault(x => x.Value == name);
                            //    if (to.Model == null)
                            //    {
                            //        var newModel = new Model() { Value = name };
                            //        mod.Add(newModel);
                            //        context.SaveChanges();
                            //        //to.Value = newModel;
                            //        //to.Value = newModel.Value;
                            //    }
                            //}

                            data = datas[16].Trim();
                            var ws = wss.FirstOrDefault(x => x.WorkstationName == data);
                            if (ws != null)
                            {
                                to.Workstation = ws;
                            }

                            if (!string.IsNullOrWhiteSpace(datas[17]))
                            {
                                string name = datas[17].Trim();
                                to.IssueCategory = ic.FirstOrDefault(x => x.CategoryName == name);
                            }
                            else
                            {
                                to.IssueCategory = null;
                            }

                            to.IssueDescription = datas[18].Trim();
                            to.Details = datas[19].Trim();

                            if (!string.IsNullOrWhiteSpace(datas[20]))
                            {
                                string name = datas[20].Trim();
                                to.RequestingUnit = ru.FirstOrDefault(x => x.UnitName == name);
                            }
                            else
                            {
                                to.RequestingUnit = null;
                            }

                            if (!string.IsNullOrWhiteSpace(datas[21]))
                            {
                                string name = datas[21].Trim();
                                to.FeedbackEmployee = employees.FirstOrDefault(x => x.Name == name);
                            }
                            else
                            {
                                to.FeedbackEmployee = null;
                            }

                            to.Status = FlowStatus.Completed;
                            //if (!string.IsNullOrWhiteSpace(datas[22]))
                            //{
                            //    string name = datas[22].Trim();
                            //    to.Condition = st.FirstOrDefault(x => x.Condition == name);
                            //}
                            //if (to.Condition == null)
                            //    to.Condition = st.FirstOrDefault(x => x.Condition == "待處理");

                            to.Feedback = datas[23].Trim();
                            to.Responsible = string.Empty;

                            tos.Add(to);
                        }
                    }
                    context.SaveChanges();
                }
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    Console.WriteLine($"Entity of type '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                    }
                }

                throw;
            }
            catch (Exception ex)
            {
                // 檢查 inner exception 是否為 DbEntityValidationException
                var validationException = ex as DbEntityValidationException
                    ?? ex.InnerException as DbEntityValidationException;

                if (validationException != null)
                {
                    foreach (var validationErrors in validationException.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            Console.WriteLine("❌ Entity: " + validationErrors.Entry.Entity.GetType().Name);
                            Console.WriteLine("   Property: " + validationError.PropertyName);
                            Console.WriteLine("   Error: " + validationError.ErrorMessage);
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"其他例外：{ex.ToString()}");
                }

                throw;
            }

            base.Seed(context);
        }
    }
}
