﻿using System.Data.Entity;
using Calin.TaskPulse.Entity.Authority;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.Models
{
    public class CoreContext : DbContext
    {
        public CoreContext() : base("name=CoreContext") { }

        /********************
         * Core
         ********************/

        /***** 權限表 *****/
        public DbSet<UserAuthorization> UserAuthorizations { get; set; }
        public DbSet<DepartmentAuthorization> DepartmentAuthorizations { get; set; }

        /***** Employee *****/
        public DbSet<Department> Departments { get; set; }
        public DbSet<Title> Titles { get; set; }
        public DbSet<Employee> Employees { get; set; }

        /***** Workstation *****/
        public DbSet<Workstation> Workstations { get; set; }
        public DbSet<Model> Models { get; set; }

        /***** Machines *****/
        public DbSet<MachineCondition> MachineConditions { get; set; }
        public DbSet<MachineLocation> MachineLocations { get; set; }
        public DbSet<MachineAssetCode> MachineAssetCodes { get; set; }
        public DbSet<MachineBrand> MachineBrands { get; set; }
        public DbSet<MachineCategory> MachineCategories { get; set; }
        public DbSet<MachineType> MachineTypes { get; set; }
        public DbSet<MachineName> MachineNames { get; set; }
        public DbSet<Machine> Machines { get; set; }

        /********************
         * MaintiFlow
         ********************/

        /***** 需求單位 *****/
        public DbSet<RequestingUnit> RequestingUnits { get; set; }

        /***** 維護單位 *****/
        public DbSet<IssueCategory> IssueCategories { get; set; }
        public DbSet<MaintenanceUnit> MaintenanceUnits { get; set; }

        /***** TaskOrder *****/
        public DbSet<TaskOrder> TaskOrders { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new CoreInitializer(modelBuilder));

            /********************
             * Core
            ********************/

            /***** 權限表 *****/
            // 部門權限 一對多: DepartmentAuthorization.Department → Department.DepartmentAuthorizations
            modelBuilder.Entity<DepartmentAuthorization>()
                .HasRequired(d => d.Department)
                .WithMany(u => u.DepartmentAuthorizations)
                .HasForeignKey(d => d.DepartmentId)
                .WillCascadeOnDelete(false);

            // 使用者權限 一對多: UserAuthorization.User → Employee.UserAuthorizations
            modelBuilder.Entity<UserAuthorization>()
                .HasRequired(u => u.User)
                .WithMany(e => e.UserAuthorizations)
                .HasForeignKey(u => u.UserId)
                .WillCascadeOnDelete(false);

            // 使用者所屬部門 一對多: UserAuthorization.Department → DepartmentAuthorization.UserAuthorizations
            modelBuilder.Entity<UserAuthorization>()
                .HasRequired(d => d.Department)
                .WithMany(u => u.UserAuthorizations)
                .HasForeignKey(d => d.DepartmentId)
                .WillCascadeOnDelete(false);

            /***** Employee *****/
            var employee = modelBuilder.Entity<Employee>();

            // 部門 一對多: Employee.Department → Department.Employees
            employee.HasRequired(e => e.Department)
                    .WithMany(d => d.Employees)
                    .HasForeignKey(e => e.DepartmentId)
                    .WillCascadeOnDelete(false);

            // 職稱 一對多: Employee.Title → Title.Employees
            employee.HasOptional(e => e.Title)
                    .WithMany(t => t.Employees)
                    .HasForeignKey(e => e.TitleId)
                    .WillCascadeOnDelete(false);

            /***** Machines *****/
            var machine = modelBuilder.Entity<Machine>();

            // 機台狀態 一對多: Machines.Condition → MachineCondition.Machines
            machine.HasRequired(m => m.Condition)
                  .WithMany(ms => ms.Machines)
                  .HasForeignKey(m => m.ConditionId)
                  .WillCascadeOnDelete(false);

            // 位置 一對多: Machines.Location → MachineLocation.Location
            machine.HasRequired(m => m.Location)
                   .WithMany(ml => ml.Machines)
                   .HasForeignKey(m => m.LocationId)
                   .WillCascadeOnDelete(false);

            // 資產編號 多對一: Machines.Assets <- MachineAssetCode.Machine
            modelBuilder.Entity<MachineAssetCode>()
                .HasRequired(m => m.Machine)
                .WithMany(ma => ma.Assets)
                .HasForeignKey(m => m.MachineId)
                .WillCascadeOnDelete(false);

            // 廠牌 一對多: Machines.Brand → MachineBrand.Machines
            machine.HasRequired(m => m.Brand)
                   .WithMany(mb => mb.Machines)
                   .HasForeignKey(m => m.BrandId)
                   .WillCascadeOnDelete(false);

            // 機台類別 一對多: MachineType.Category → MachineCategory.MachineTypes
            modelBuilder.Entity<MachineType>()
                .HasRequired(m => m.Category)
                .WithMany(mc => mc.MachineTypes)
                .HasForeignKey(m => m.CategoryId)
                .WillCascadeOnDelete(false);

            // 機台型式 一對多: MachineNames.MachineTypes → MachineTypes.MachineNames
            modelBuilder.Entity<MachineName>()
                .HasRequired(m => m.MachineType)
                .WithMany(mt => mt.MachineNames)
                .HasForeignKey(m => m.TypeId)
                .WillCascadeOnDelete(false);

            // 機台名稱 一對多: Machines.MachineNames → MachineNames.Machines
            machine.HasRequired(m => m.MachineName)
                   .WithMany(mn => mn.Machines)
                   .HasForeignKey(m => m.MachineNameId)
                   .WillCascadeOnDelete(false);

            // 工站 多對多: Machines.Workstations ↔ Workstation.Machines
            machine.HasMany(m => m.Worktations)
                   .WithMany(w => w.Machines)
                   .Map(m =>
                   {
                       m.ToTable("MachineWorkstation");
                       m.MapLeftKey("MachineId");
                       m.MapRightKey("Key");
                   });

            /********************
             * MaintiFlow
             ********************/

            var taskorder = modelBuilder.Entity<TaskOrder>();

            /***** 需求單位 *****/
            // 需求單位 一對多: TaskOrder.RequestingUnit → RequestingUnit.TaskOrderEngineers
            taskorder.HasRequired(t => t.RequestingUnit)
                     .WithMany(ru => ru.TaskOrders)
                     .HasForeignKey(t => t.RequestingUnitId)
                     .WillCascadeOnDelete(false);

            // 回覆人員 一對多: TaskOrder.RequestingEmployee → Core.Employee.RequestingTaskOrders
            taskorder.HasOptional(t => t.RequestingEmployee)
                   .WithMany(ru => ru.RequestingEmployeeTaskOrders)
                   .HasForeignKey(t => t.RequestingEmployeeId)
                   .WillCascadeOnDelete(false);

            /***** 維護單位 *****/
            // 維護類型 一對多: TaskOrderEngineers.IssueCategory → IssueCategory.TaskOrderEngineers
            taskorder.HasOptional(t => t.IssueCategory)
                     .WithMany(ic => ic.TaskOrders)
                     .HasForeignKey(t => t.IssueCategoryId)
                     .WillCascadeOnDelete(false);

            // 維護單位 一對多: TaskOrder.MaintenanceUnit → MaintenanceUnit.TaskOrders
            taskorder.HasOptional(t => t.MaintenanceUnit)
                     .WithMany(mu => mu.TaskOrders)
                     .HasForeignKey(t => t.MaintenanceUnitId)
                     .WillCascadeOnDelete(false);

            /***** TaskOrder.Core *****/
            // 部門 一對多: Employee.Department → Department.Employees
            modelBuilder.Entity<Employee>()
                .HasRequired(t => t.Department)
                .WithMany(e => e.Employees)
                .HasForeignKey(t => t.DepartmentId)
                .WillCascadeOnDelete(false);

            // 職稱 一對多: Employee.Title → Title.Employees
            modelBuilder.Entity<Employee>()
                .HasOptional(t => t.Title)
                .WithMany(e => e.Employees)
                .HasForeignKey(t => t.TitleId)
                .WillCascadeOnDelete(false);

            // 建檔人員 一對多: TaskOrder.Creator → Employee.CreatedTaskOrders
            taskorder.HasRequired(t => t.Creator)
                     .WithMany(e => e.CreaterTaskOrders)
                     .HasForeignKey(t => t.CreatorId)
                     .WillCascadeOnDelete(false);

            // 維護工程師 多對多 TaskOrder.Creator ↔ Employee.CreatedTaskOrders
            taskorder.HasMany(m => m.Engineers)
                     .WithMany(e => e.EngineerTaskOrders)
                     .Map(m =>
                     {
                         m.ToTable("TaskOrderEngineers");
                         m.MapLeftKey("EmployeeIds");
                         m.MapRightKey("EmployeeId");
                     });

            /***** Workstation *****/
            // 工站 一對多: TaskOrder.Workstation → Workstation.TaskOrders
            taskorder
                .HasRequired(t => t.Workstation)
                .WithMany(w => w.TaskOrders)
                .HasForeignKey(t => t.WorkstationId)
                .WillCascadeOnDelete(false);

            // 機種 一對多: Workstation.Model → Model.Worktations
            modelBuilder.Entity<Workstation>()
                .HasRequired(w => w.Model)
                .WithMany(m => m.Worktations)
                .HasForeignKey(w => w.ModelId)
                .WillCascadeOnDelete(false);
        }
    }
}
