﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace Calin.TaskPulse.Core.Models
{
    public class CoreContext : DbContext
    {
        public CoreContext() : base("name=CoreContext") { }

        public DbSet<Authorization> AuthorizationTable { get; set; }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Factory> Factorys { get; set; }
        public DbSet<DeviceLocation> Locations { get; set; }
        public DbSet<DeviceType> DeviceTypes { get; set; }
        public DbSet<DeviceName> DeviceNames { get; set; }
        public DbSet<Model> Models { get; set; }
        public DbSet<Brand> DeviceBrands { get; set; }
        public DbSet<AssetCode> AssetCodes { get; set; }

        public DbSet<DeviceCondition> DeviceConditions { get; set; }

        public DbSet<Device> Devices { get; set; } // 所有設備清單

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new CoreInitializer(modelBuilder));

            //var device = modelBuilder.Entity<Device>();

            //// DeviceName 一對多
            //device.HasRequired(d => d.DeviceName)
            //      .WithMany(e => e.Devices)
            //      .HasForeignKey(d => d.DeviceNameId)
            //      .WillCascadeOnDelete(false);

            //// Brand 一對多
            //device.HasRequired(d => d.Brand)
            //      .WithMany(e => e.Brands)
            //      .HasForeignKey(d => d.BrandId)
            //      .WillCascadeOnDelete(false);

            //// Factory 一對多
            //modelBuilder.Entity<DeviceLocation>()
            //    .HasRequired(p => p.Factory)
            //    .WithMany(l => l.Factorys)
            //    .HasForeignKey(p => p.FactoryId)
            //    .WillCascadeOnDelete(false);

            //// Condition 一對多
            //device.HasRequired(d => d.Condition)
            //      .WithMany(c => c.Conditions)
            //      .HasForeignKey(d => d.ConditionId)
            //      .WillCascadeOnDelete(false);

            //// Assets 多對一
            //modelBuilder.Entity<AssetCode>()
            //    .HasRequired(a => a.Device)
            //    .WithMany(d => d.Assets)
            //    .HasForeignKey(a => a.DeviceId)
            //    .WillCascadeOnDelete(false);

            //// ===== DeviceName -> DeviceType 一對多 =====
            //modelBuilder.Entity<DeviceName>()
            //    .HasRequired(d => d.Type)
            //    .WithMany(t => t.DeviceTypes)
            //    .HasForeignKey(d => d.TypeId)
            //    .WillCascadeOnDelete(false);

            // 設備類別 一對多: DeviceName.DeviceType → DeviceType.Id
            modelBuilder.Entity<DeviceName>()
                .HasRequired(d => d.Type)
                .WithMany(e => e.DeviceTypes)
                .HasForeignKey(t => t.TypeId)
                .WillCascadeOnDelete(false);

            // 設備名稱 一對多: Device.DeviceName → DeviceName.Devices
            modelBuilder.Entity<Device>()
                .HasRequired(d => d.DeviceName)
                .WithMany(e => e.Devices)
                .HasForeignKey(t => t.DeviceNameId)
                .WillCascadeOnDelete(false);

            // 廠牌 一對多: Device.Brand → Brand.Brands
            modelBuilder.Entity<Device>()
                .HasRequired(d => d.Brand)
                .WithMany(e => e.Brands)
                .HasForeignKey(t => t.BrandId)
                .WillCascadeOnDelete(false);

            // 位置 一對多: DeviceLocation.Factory → Factory.Factorys
            modelBuilder.Entity<DeviceLocation>()
                .HasRequired(d => d.Factory)
                .WithMany(e => e.Factorys)
                .HasForeignKey(t => t.FactoryId)
                .WillCascadeOnDelete(false);

            // 設備狀態 一對多: Device.Condition → DeviceCondition.Conditions
            modelBuilder.Entity<Device>()
                .HasRequired(d => d.Condition)
                .WithMany(e => e.Conditions)
                .HasForeignKey(t => t.ConditionId)
                .WillCascadeOnDelete(false);

            // 資產編號 多對一: Device.Assets → AssetCode.Device
            modelBuilder.Entity<AssetCode>()
                .HasRequired(a => a.Device)
                .WithMany(d => d.Assets)
                .HasForeignKey(a => a.DeviceId)
                .WillCascadeOnDelete(false);
        }
    }
}
