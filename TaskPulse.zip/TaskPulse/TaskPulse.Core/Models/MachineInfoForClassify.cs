﻿namespace Calin.TaskPulse.Core.Models
{
    //public class MachineInfoForClassify
    public class MachineInfo
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
    }
}
