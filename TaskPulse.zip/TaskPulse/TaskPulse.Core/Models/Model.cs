﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 機種清單。
    /// </summary>
    public class Model
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ModelId { get; set; }

        /// <summary>
        /// 機種名稱。
        /// </summary>
        [Description("機種")]
        public string ModelName { get; set; }
    }
}
