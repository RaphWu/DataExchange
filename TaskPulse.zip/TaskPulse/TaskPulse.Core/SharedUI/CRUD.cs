﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.WinForms;
using Sunny.UI;

namespace Calin.TaskPulse.Core.SharedUI
{
    public partial class CRUD : UIForm
    {
        #region fields

        private readonly ICore _core;
        private Func<string, (bool isValid, string errorMessage)> _validator;

        private UITextBox _inputTextBox;
        private UITextBox _captionTextBox;
        private UIComboBox _inputComboBox;

        private enum CtlType
        {
            None,
            TextBox,
            ComboBox,
            TextBoxComboBox,
        }
        private CtlType _ctlType = CtlType.None;

        #endregion fields

        /// <summary>
        /// 返回值。
        /// </summary>
        public DialogResults Result { get; set; } = new DialogResults();

        public CRUD(ICore core)
        {
            InitializeComponent();
            _core = core;

            CommonStyles.SetButton(uiButton_OK);
            CommonStyles.SetButton(uiButton_Cancel, isCancel: true);
        }

        /********************
         * Form
         ********************/
        private void CRUD_Load(object sender, EventArgs e)
        {
        }

        /********************
         * Buttons
         ********************/
        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Result = new DialogResults() { DialogResult = DialogResult.Cancel };
            this.Close();
        }

        private void Button_OK_Click(object sender, EventArgs e)
        {
            Result = new DialogResults() { DialogResult = DialogResult.OK };
            string input;

            switch (_ctlType)
            {
                case CtlType.TextBox:
                    input = _inputTextBox.Text.Trim();
                    if (_validator != null)
                    {
                        var (isValid, errorMessage) = _validator(input);
                        if (!isValid)
                        {
                            UIMessageBox.ShowMessageDialog(errorMessage, "輸入錯誤", false, UIStyle.Red);
                            _inputTextBox.Focus();
                            return;
                        }
                    }
                    Result.StringValue = input;
                    break;

                case CtlType.ComboBox:
                    Result.IntValue = _inputComboBox.SelectedIndex;
                    break;

                case CtlType.TextBoxComboBox:
                    input = _inputTextBox.Text.Trim();
                    if (_validator != null)
                    {
                        var (isValid, errorMessage) = _validator(input);
                        if (!isValid)
                        {
                            UIMessageBox.ShowMessageDialog(errorMessage, "輸入錯誤", false, UIStyle.Red);
                            _inputTextBox.Focus();
                            return;
                        }
                    }
                    Result.StringValue = input;
                    Result.IntValue = _inputComboBox.SelectedIndex;
                    break;
            }

            DialogResult = DialogResult.OK;
            this.Close();
        }

        /********************
         * Functions
         ********************/
        /// <summary>
        /// 建立內容。<br/>顯示一個 TextBox，用來輸入新值。
        /// </summary>
        /// <param name="content">新內容。</param>
        /// <param name="title">標題。輸入空白字串則隱藏標題列。</param>
        /// <param name="validator">驗證器。</param>
        public void New_1TextBox(TextBoxInfo content,
                                 string title = "",
                                 Func<string, (bool isValid, string errorMessage)> validator = null)
        {
            _ctlType = CtlType.TextBox;
            _validator = validator;
            this.ShowTitle = !string.IsNullOrWhiteSpace(title);
            this.Text = title;
            _core.CleanUpControls(leftFLP.Controls);
            _core.CleanUpControls(rightFLP.Controls);

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(content.Caption));
            _inputTextBox = CreateNewTextBoxFromTemplate(content.Value, content.WaterMark);
            rightFLP.Controls.Add(_inputTextBox);
            _inputTextBox.TabIndex = 0;
            _inputTextBox.Focus();

            SunnyUiHelper.AdjustFormLayout(this, TLP_Page);
        }

        /// <summary>
        /// 建立內容。<br/>顯示一個 TextBox 和二個 ComboBox，用來輸入新值。
        /// </summary>
        /// <param name="content">新內容。</param>
        /// <param name="NewSelection1">新選擇內容1。</param>
        /// <param name="NewSelection2">新選擇內容2。</param>
        /// <param name="title">標題。輸入空白字串則隱藏標題列。</param>
        /// <param name="validator">驗證器。</param>
        public void New_1TextBox2ComboBox(TextBoxInfo content,
                                          ComboBoxInfo NewSelection1,
                                          ComboBoxInfo NewSelection2,
                                          string title = "",
                                          Func<string, (bool isValid, string errorMessage)> validator = null)
        {
            _ctlType = CtlType.TextBox;
            _validator = validator;
            this.ShowTitle = !string.IsNullOrWhiteSpace(title);
            this.Text = title;
            _core.CleanUpControls(leftFLP.Controls);
            _core.CleanUpControls(rightFLP.Controls);

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(content.Caption));
            _inputTextBox = CreateNewTextBoxFromTemplate(content.Value, content.WaterMark);
            rightFLP.Controls.Add(_inputTextBox);
            _inputTextBox.TabIndex = 0;
            _inputTextBox.Focus();

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(NewSelection1.Caption));
            _inputComboBox = CreateNewComboBoxFromTemplate(NewSelection1.Id,
                                                           NewSelection1.ListSource,
                                                           NewSelection1.WaterMark);
            rightFLP.Controls.Add(_inputComboBox);
            _inputComboBox.TabIndex = 1;

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(NewSelection2.Caption));
            _inputComboBox = CreateNewComboBoxFromTemplate(NewSelection2.Id,
                                                           NewSelection2.ListSource,
                                                           NewSelection2.WaterMark);
            rightFLP.Controls.Add(_inputComboBox);
            _inputComboBox.TabIndex = 2;

            SunnyUiHelper.AdjustFormLayout(this, TLP_Page);
        }

        /// <summary>
        /// 編輯內容。<br/>顯示二個 TextBox，第一個顯示舊值 (唯讀)，第二個輸入新值。
        /// </summary>
        /// <param name="OldContent">舊值內容。</param>
        /// <param name="NewContent">新值內容。</param>
        /// <param name="title">標題。輸入空白字串則隱藏標題列。</param>
        /// <param name="validator">驗證器。</param>
        public void Edit_1TextBox(TextBoxInfo OldContent,
                                  TextBoxInfo NewContent,
                                  string title = "",
                                  Func<string, (bool isValid, string errorMessage)> validator = null)
        {
            _ctlType = CtlType.TextBox;
            _validator = validator;
            this.ShowTitle = !string.IsNullOrWhiteSpace(title);
            this.Text = title;
            _core.CleanUpControls(leftFLP.Controls);
            _core.CleanUpControls(rightFLP.Controls);

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(OldContent.Caption));
            _captionTextBox = CreateNewTextBoxFromTemplate(OldContent.Value, "");
            _captionTextBox.ReadOnly = true;
            _captionTextBox.TabIndex = 999;
            _captionTextBox.TabStop = false;
            rightFLP.Controls.Add(_captionTextBox);

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(NewContent.Caption));
            _inputTextBox = CreateNewTextBoxFromTemplate(NewContent.Value, NewContent.WaterMark);
            rightFLP.Controls.Add(_inputTextBox);
            _inputTextBox.TabIndex = 0;
            _inputTextBox.Focus();

            SunnyUiHelper.AdjustFormLayout(this, TLP_Page);
        }

        /// <summary>
        /// 編輯內容。<br/>第一組為一個 TextBox 顯示舊值 (唯讀)，一個 TextBox 輸入新值；<br/>第二組為一個 TextBox 顯示舊值 (唯讀)，一個 ComboBox，用來選擇新值。
        /// </summary>
        /// <param name="OldText">舊值內容。</param>
        /// <param name="NewText">舊值內容。</param>
        /// <param name="OldSelection">新值內容。</param>
        /// <param name="OldSelection">新值內容。</param>
        /// <param name="title">標題。輸入空白字串則隱藏標題列。</param>
        /// <param name="validator">驗證器。</param>
        public void Edit_1TextBox_1ComboBox(TextBoxInfo OldText,
                                            TextBoxInfo NewText,
                                            TextBoxInfo OldSelection,
                                            ComboBoxInfo NewSelection,
                                            string title = "",
                                            Func<string, (bool isValid, string errorMessage)> validator = null)
        {
            _ctlType = CtlType.TextBoxComboBox;
            _validator = validator;
            this.ShowTitle = !string.IsNullOrWhiteSpace(title);
            this.Text = title;
            _core.CleanUpControls(leftFLP.Controls);
            _core.CleanUpControls(rightFLP.Controls);

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(OldText.Caption));
            _captionTextBox = CreateNewTextBoxFromTemplate(OldText.Value, "");
            _captionTextBox.ReadOnly = true;
            _captionTextBox.TabIndex = 999;
            _captionTextBox.TabStop = false;
            rightFLP.Controls.Add(_captionTextBox);

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(NewText.Caption));
            _inputTextBox = CreateNewTextBoxFromTemplate(NewText.Value, NewText.WaterMark);
            rightFLP.Controls.Add(_inputTextBox);
            _inputTextBox.TabIndex = 0;
            _inputTextBox.Focus();

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(OldSelection.Caption));
            _captionTextBox = CreateNewTextBoxFromTemplate(OldSelection.Value, OldSelection.WaterMark);
            _captionTextBox.ReadOnly = true;
            _captionTextBox.TabIndex = 999;
            _captionTextBox.TabStop = false;
            rightFLP.Controls.Add(_captionTextBox);

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(NewSelection.Caption));
            _inputComboBox = CreateNewComboBoxFromTemplate(NewSelection.Id,
                                                           NewSelection.ListSource,
                                                           NewSelection.WaterMark);
            rightFLP.Controls.Add(_inputComboBox);
            _inputComboBox.TabIndex = 1;

            SunnyUiHelper.AdjustFormLayout(this, TLP_Page);
        }

        /// <summary>
        /// 選擇一個值。<br/>使用一個 ComboBox 用來顯示值。
        /// </summary>
        /// <param name="content">內容。</param>
        /// <param name="title">標題。輸入空白字串則隱藏標題列。</param>
        /// <param name="validator">驗證器。</param>
        public void Edit_1ComboBox(ComboBoxInfo content,
                                   string title = "",
                                   Func<string, (bool isValid, string errorMessage)> validator = null)
        {
            _ctlType = CtlType.ComboBox;
            _validator = validator;
            this.ShowTitle = !string.IsNullOrWhiteSpace(title);
            this.Text = title;
            _core.CleanUpControls(leftFLP.Controls);
            _core.CleanUpControls(rightFLP.Controls);

            leftFLP.Controls.Add(CreateNewLabelFromTemplate(content.Caption));

            _inputComboBox = CreateNewComboBoxFromTemplate(content.Id, content.ListSource, content.WaterMark);
            rightFLP.Controls.Add(_inputComboBox);
            _inputComboBox.TabIndex = 0;
            _inputComboBox.Focus();

            SunnyUiHelper.AdjustFormLayout(this, TLP_Page);
        }

        /********************
         * Control Template
         ********************/
        /// <summary>
        /// Label。
        /// </summary>
        private UILabel CreateNewLabelFromTemplate(string caption)
        {
            var control = new UILabel
            {
                AutoSize = LabelTemplate.AutoSize,
                Font = LabelTemplate.Font,
                ForeColor = LabelTemplate.ForeColor,
                Location = LabelTemplate.Location,
                Size = LabelTemplate.Size,
                TextAlign = LabelTemplate.TextAlign,
                Padding = LabelTemplate.Padding,
                Margin = LabelTemplate.Margin,
                Dock = LabelTemplate.Dock,
                Cursor = LabelTemplate.Cursor,
                BackColor = LabelTemplate.BackColor,
                Text = caption,
                Visible = true
            };
            control.Font = CommonStyles.Font;
            control.AutoSize = false;
            control.Height = 30;
            return control;
        }

        /// <summary>
        /// TextBox
        /// </summary>
        private UITextBox CreateNewTextBoxFromTemplate(string value, string watermark = "")
        {
            var control = new UITextBox
            {
                AutoSize = TextBoxTemplate.AutoSize,
                Font = TextBoxTemplate.Font,
                ForeColor = TextBoxTemplate.ForeColor,
                Location = TextBoxTemplate.Location,
                Size = TextBoxTemplate.Size,
                TextAlignment = TextBoxTemplate.TextAlignment,
                Padding = TextBoxTemplate.Padding,
                Margin = TextBoxTemplate.Margin,
                Dock = TextBoxTemplate.Dock,
                Cursor = TextBoxTemplate.Cursor,
                BackColor = TextBoxTemplate.BackColor,
                Watermark = watermark,
                Text = value,
                Visible = true
            };
            control.Font = CommonStyles.Font;
            return control;
        }

        /// <summary>
        /// ComboBox
        /// </summary>
        private UIComboBox CreateNewComboBoxFromTemplate(int id,
                                                         List<ListViewModel> listSource,
                                                         string watermark = "")
        {
            var control = new UIComboBox
            {
                AutoSize = ComboBoxTemplate.AutoSize,
                Font = ComboBoxTemplate.Font,
                ForeColor = ComboBoxTemplate.ForeColor,
                Location = ComboBoxTemplate.Location,
                Size = ComboBoxTemplate.Size,
                TextAlignment = ComboBoxTemplate.TextAlignment,
                Padding = ComboBoxTemplate.Padding,
                Margin = ComboBoxTemplate.Margin,
                Dock = ComboBoxTemplate.Dock,
                Cursor = ComboBoxTemplate.Cursor,
                BackColor = ComboBoxTemplate.BackColor,
                Watermark = watermark,
                Visible = true
            };
            control.DisplayMember = nameof(ListViewModel.Name);
            control.ValueMember = nameof(ListViewModel.Id);
            control.DataSource = listSource;
            control.SelectedValue = id;
            control.Font = CommonStyles.Font;
            return control;
        }
    }
}
