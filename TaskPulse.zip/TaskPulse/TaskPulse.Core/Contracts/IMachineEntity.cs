﻿namespace Calin.TaskPulse.Core.Contracts
{
    public interface IMachineEntity
    {
    }
}
