﻿namespace Calin.TaskPulse.Core.Contracts
{
    public interface IMachineDto
    {
    }
}
