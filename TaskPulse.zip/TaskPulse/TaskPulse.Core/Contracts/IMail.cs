﻿using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Contracts
{
    public interface IMail
    {
        // 內部初始化用
        void Initialize();

        /// <summary>
        /// 發送信件。
        /// </summary>
        /// <param name="workName">作業名稱。</param>
        /// <param name="subject">主旨。</param>
        /// <param name="contents">信件內容。</param>
        Task SendMail(string workName, string subject, string contents);
    }
}
