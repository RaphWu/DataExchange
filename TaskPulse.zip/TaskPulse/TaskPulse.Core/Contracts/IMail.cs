﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Contracts
{
    public interface IMail
    {
        // 內部初始化用
        void Initialize();

        /// <summary>
        /// 發送信件。
        /// </summary>
        /// <param name="senderTitle">寄信者名稱。</param>
        /// <param name="workName">作業名稱。</param>
        /// <param name="subject">主旨。</param>
        /// <param name="contents">信件內容。</param>
        void SendMail(string senderTitle, string workName, string subject, string contents);

        /// <summary>
        /// 發送信件。
        /// </summary>
        /// <param name="senderTitle">寄信者名稱。</param>
        /// <param name="mailList">Email 清單。</param>
        /// <param name="subject">主旨。</param>
        /// <param name="contents">信件內容。</param>
        void SendMail(string senderTitle, List<Mail> mailList, string subject, string contents);
    }
}
