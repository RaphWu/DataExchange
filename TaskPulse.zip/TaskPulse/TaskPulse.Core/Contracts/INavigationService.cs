﻿using System;

namespace Calin.TaskPulse.Contracts
{
    public interface INavigationService
    {
        void Navigate(string regionName, Type viewType, bool alive = true);
        void Navigate<TView>(string regionName, bool alive = true) where TView : class;
    }
}
