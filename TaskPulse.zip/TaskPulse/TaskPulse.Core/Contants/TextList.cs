﻿namespace Calin.TaskPulse.Core.Contants
{
    public static class TextList
    {
        public static string Menu = "選單";
    }
}
