﻿namespace Calin.TaskPulse.Core.Contants
{
    public static class PermissionPrefix
    {
        /********************
         * User
         ********************/
        public const string Guest = "GUEST";

        /********************
         * Home
         ********************/
        /// <summary>
        /// 主頁。
        /// </summary>
        public const string HOME = "HOME";


        /********************
         * 系統設定
         ********************/
        /// <summary>
        /// 系統設定。
        /// </summary>
        public const string SETUP = "SETUP";



        /********************
         * 工具委託
         ********************/
        /// <summary>
        /// 工具委託。
        /// </summary>
        public const string TOOL_QUEST = "TQ";



        /********************
         * 專案管理
         ********************/
        /// <summary>
        /// 專案管理。
        /// </summary>
        public const string MECHA_TRACK = "MT";



        /********************
         * 維護工單
         ********************/
        /// <summary>
        /// 維護工單。
        /// </summary>
        public const string MAINTI_FLOW = "MF";

        /// <summary>
        /// 新建工單。
        /// </summary>
        public const string CREATE_FLOW = "CREATE";
        /// <summary>
        /// 取消工單。
        /// </summary>
        public const string CANCEL_FLOW = "CANCEL";
        /// <summary>
        /// 接單。
        /// </summary>
        public const string ACCEPT_FLOW = "ACCEPT";
        /// <summary>
        /// 工單轉移。
        /// </summary>
        public const string FLOW_TRANSFER = "TRANSFER";


    }
}
