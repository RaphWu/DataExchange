﻿using Newtonsoft.Json.Linq;

namespace Calin.TaskPulse.Core.Contants
{
    public static class PermissionWords
    {
        /********************
         * User
         ********************/
        public const string USER_Guest = "Guest";

        /********************
         * Home
         ********************/
        /// <summary>
        /// 主頁。
        /// </summary>
        public const string MODULE_HOME = "Home";


        /********************
         * 系統設定
         ********************/
        /// <summary>
        /// 系統設定。
        /// </summary>
        public const string MODULE_SETUP = "Setup";

        /// <summary>
        /// 機台管理。
        /// </summary>
        public const string PAGE_MACHINE_MANAGER = "Machine";
        /// <summary>
        /// 員工管理。
        /// </summary>
        public const string PAGE_EMPLOYEE_MANAGER = "Employee";

        /********************
         * 工具委託
         ********************/
        /// <summary>
        /// 工具委託。
        /// </summary>
        public const string MODULE_TOOL_QUEST = "TQ";



        /********************
         * 專案管理
         ********************/
        /// <summary>
        /// 專案管理。
        /// </summary>
        public const string MODULE_MECHA_TRACK = "MT";



        /********************
         * 維護工單
         ********************/
        /// <summary>
        /// 維護工單。
        /// </summary>
        public const string MODULE_MAINTI_FLOW = "MF";

        /// <summary>
        /// 維護總表。
        /// </summary>
        public const string PAGE_SUMMARY = "Summary";
        /// <summary>
        /// 新建工單。
        /// </summary>
        public const string PAGE_CREATE_FLOW = "Create";
        /// <summary>
        /// 取消工單。
        /// </summary>
        public const string PAGE_CANCEL_FLOW = "Cancel";
        /// <summary>
        /// 接單。
        /// </summary>
        public const string PAGE_ACCEPT_FLOW = "Accept";
        /// <summary>
        /// 維護作業。
        /// </summary>
        public const string PAGE_MAINTANT_FLOW = "Maintant";
        /// <summary>
        /// 確認作業。
        /// </summary>
        public const string PAGE_FLOW_CONFIRM = "Confirm";


        /********************
         * 動作
         ********************/
        /// <summary>
        /// 可檢視。
        /// </summary>
        public const string ACTION_VIEW = "View";

        /// <summary>
        /// 可編輯。
        /// </summary>
        public const string ACTION_EDIT = "Edit";
    }
}
