﻿using System;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contract;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class UserLogin : UIForm
    {
        private readonly ILifetimeScope _scope;

        public string[] NameList = new string[0];

        public UserLogin(ILifetimeScope lifetimeScope)
        {
            InitializeComponent();
            _scope = lifetimeScope;

            uiComboBox_UserName.Items.AddRange(NameList);

            CommonStyles.SetButton(Button_Login);
            CommonStyles.SetButton(Button_Cancel, accent: true);
        }

        private async void Button_Login_Click(object sender, EventArgs e)
        {
            var auth = _scope.Resolve<IAuthService>();
            bool pass = await auth.ActiveDirectoryAsync(
                uiComboBox_UserName.Text.Trim(),
                uiTextBox_Password.Text.Trim()
            );
            DialogResult = pass ? DialogResult.OK : DialogResult.Cancel;
            this.Close();
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
