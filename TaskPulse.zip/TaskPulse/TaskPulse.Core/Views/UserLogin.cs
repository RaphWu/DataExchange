﻿using System;
using System.Windows.Forms;
using Calin.CSharp.Security;
using Calin.TaskPulse.Core.Authority;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class UserLogin : UIForm
    {
        public string[] NameList = new string[0];
        internal DialogInfo DialogInfo { get; private set; } // Dialog 溝通用

        public UserLogin()
        {
            InitializeComponent();
        }

        private void UserLogin_Activated(object sender, EventArgs e)
        {
            uiComboBox_UserName.Items.Clear();
            uiComboBox_UserName.Items.AddRange(NameList);
        }

        private void uiButton_Login_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            DialogInfo = new DialogInfo
            {
                NewName = uiComboBox_UserName.Text.Trim(),
                NewPassword = uiTextBox_Password.Text.Trim().GetMD5Hash(),
            };

            this.Close();
        }
    }
}
