﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class MachineEdit : UIForm
    {

        #region fields

        private readonly CoreContext _context;

        #endregion fields

        public string MachineId { get; set; }

        public MachineEdit(CoreContext coreContext)
        {
            InitializeComponent();
            _context = coreContext;
        }

        private void MachineEdit_Load(object sender, EventArgs e)
        {
            cbCategory.DisplayMember = "Name";
            cbCategory.ValueMember = "Id";
            cbCategory.DataSource = _context.MachineCategories
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.CategoryName })
                .ToList();

            cbType.DisplayMember = "Name";
            cbType.ValueMember = "Id";
            cbType.DataSource = _context.MachineTypes
                .Where(t => t.CategoryId == (int)cbCategory.SelectedValue)
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.TypeName })
                .ToList();

            cbCondition.DisplayMember = "Name";
            cbCondition.ValueMember = "Id";
            cbCondition.DataSource = _context.MachineConditions
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.Condition })
                .ToList();

            cbBrand.DisplayMember = "Name";
            cbBrand.ValueMember = "Id";
            cbBrand.DataSource = _context.MachineBrands
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.BrandName })
                .ToList();

            cbLocation.DisplayMember = "Name";
            cbLocation.ValueMember = "Id";
            cbLocation.DataSource = _context.MachineLocations
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.Location })
                .ToList();

            cbConnected.DisplayMember = "Name";
            cbConnected.ValueMember = "Id";
            cbConnected.DataSource = new List<ListViewModel>()
            {
                new ListViewModel() { Id = 0, Name = "未連網" },
                new ListViewModel() { Id = 1, Name = "可連網" },
            };

            cbDisposal.DisplayMember = "Name";
            cbDisposal.ValueMember = "Id";
            cbDisposal.DataSource = new List<ListViewModel>()
            {
                new ListViewModel() { Id = 0, Name = "正常作業" },
                new ListViewModel() { Id = 1, Name = "已處置" },
            };

            var rec = _context.Machines.FirstOrDefault(m => m.MachineId == MachineId);
            tbMaincheId.Text = rec.MachineId;

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
