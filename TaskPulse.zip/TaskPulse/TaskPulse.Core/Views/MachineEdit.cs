﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class MachineEdit : UIForm
    {

        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly FieldTitle _fieldTitle;
        private readonly FlowLayoutSelector _fls;

        #endregion fields

        public string Title { get; set; }
        public CrudType CrudType { get; set; }
        public MachineViewModel Machine { get; set; } = new MachineViewModel();

        public MachineEdit(CoreContext coreContext, CoreData coreData, FieldTitle fieldTitle, FlowLayoutSelector flowLayoutSelector)
        {
            InitializeComponent();
            _context = coreContext;
            _coreData = coreData;
            _fieldTitle = fieldTitle;
            _fls = flowLayoutSelector;
        }

        private bool _isLoading = true;

        private async void MachineEdit_Load(object sender, EventArgs e)
        {
            this.Text = Title;
            tbMaincheId.Text = Machine.MachineCode;

            cbCategory.DisplayMember = "Name";
            cbCategory.ValueMember = "Id";
            cbCategory.DataSource = await _context.MachineCategories
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.CategoryName })
                .ToListAsync();
            cbCategory.Enabled = false;
            //cbCategory.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            cbType.DisplayMember = "Name";
            cbType.ValueMember = "Id";
            cbType.DataSource = await _context.MachineTypes
                .Where(t => t.CategoryId == Machine.CategoryId)
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.TypeName })
                .ToListAsync();
            cbType.Enabled = false;
            //cbType.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            cbModelName.DisplayMember = "Name";
            cbModelName.ValueMember = "Id";
            cbModelName.DataSource = await _context.MachineNames
                .Where(t => t.TypeId == Machine.TypeId)
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.ModelName })
                .ToListAsync();
            //cbModelName.Enabled = false;
            //cbModelName.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            cbCondition.DisplayMember = "Name";
            cbCondition.ValueMember = "Id";
            cbCondition.DataSource = await _context.MachineConditions
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.ConditionName })
                .ToListAsync();

            cbBrand.DisplayMember = "Name";
            cbBrand.ValueMember = "Id";
            cbBrand.DataSource = await _context.MachineBrands
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.BrandName })
                .ToListAsync();

            cbLocation.DisplayMember = "Name";
            cbLocation.ValueMember = "Id";
            cbLocation.DataSource = await _context.MachineLocations
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.LocationName })
                .ToListAsync();

            cbConnected.DisplayMember = "Name";
            cbConnected.ValueMember = "BooleanId";
            cbConnected.DataSource = new List<ListViewModel>()
            {
                new ListViewModel() { BooleanId = false, Name = "未連網" },
                new ListViewModel() { BooleanId= true, Name = "可連網" },
            };

            cbDisposal.DisplayMember = "Name";
            cbDisposal.ValueMember = "BooleanId";
            cbDisposal.DataSource = new List<ListViewModel>()
            {
                new ListViewModel() {BooleanId = false, Name = "正常作業" },
                new ListViewModel() {BooleanId = true, Name = "已處置" },
            };

            cbCategory.SelectedValue = Machine.CategoryId;
            cbType.SelectedValue = Machine.TypeId;
            cbModelName.SelectedValue = Machine.MachineNameId;
            cbCondition.SelectedValue = Machine.ConditionId;
            cbBrand.SelectedValue = Machine.BrandId;
            cbLocation.SelectedValue = Machine.LocationId;
            cbConnected.SelectedValue = Machine.Connected;
            cbDisposal.SelectedValue = Machine.Disposal;
            tbAssets.Text = Machine.AssetString;
            tbSerialNumber.Text = Machine.SerialNumber;
            tbBarcode.Text = Machine.Barcode;
            tbRemark.Text = Machine.Remark;

            _isLoading = false;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {

            //Machine.MachineCode = Machine.MachineCode;
            Machine.MachineNameId = (int)cbModelName.SelectedValue;
            Machine.TypeId = (int)cbType.SelectedValue;
            Machine.CategoryId = (int)cbCategory.SelectedValue;
            Machine.ConditionId = (int)cbCondition.SelectedValue;
            Machine.BrandId = (int)cbBrand.SelectedValue;
            Machine.LocationId = (int)cbLocation.SelectedValue;
            Machine.Connected = (bool)cbConnected.SelectedValue;
            Machine.Disposal = (bool)cbDisposal.SelectedValue;
            Machine.AssetString = tbAssets.Text;
            Machine.SerialNumber = tbSerialNumber.Text;
            Machine.Barcode = tbBarcode.Text;
            Machine.Remark = tbRemark.Text;

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnWorkstation_Click(object sender, EventArgs e)
        {
            _fls.HideTabHeaders = false;
            _fls.ShowTreeView = true;
            _fls.Title = $"請選擇{_fieldTitle.Workstation}";
            _fls.TreeViewCaption = "機種";
            _fls.MultiSelection = true;
            _fls.TabPageCache = _coreData.ModelWsMultiTabPageCache;
            _fls.DefaultChecked = tbWorkstations.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _fls.Initialize();

            //if (Core.Views.FormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (FormEx.ShowDialogWithMask(_fls) == DialogResult.OK)
            {
                if (_fls.ResultList.Count > 0)
                {
                    //string deviceString = "";
                    //foreach (var info in _flowLayoutSelector.ResultList)
                    //{
                    //    if (deviceString != "")
                    //        deviceString += "; ";
                    //    deviceString += info.Name;
                    //}
                    //MachineList.Text = deviceString;
                    tbWorkstations.Text = string.Join("; ", _fls.ResultList.Select(r => r.Name).ToArray());
                }
                else
                {
                    tbWorkstations.Text = "";
                }
            }
        }

        private async void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (_isLoading)
            //    return;

            //int categoryId = -1;
            //if (cbCategory.SelectedValue != null && int.TryParse(cbCategory.SelectedValue.ToString(), out int val))
            //    categoryId = val;

            //cbType.DisplayMember = "Name";
            //cbType.ValueMember = "Id";
            //cbType.DataSource = await _context.MachineTypes
            //    .Where(t => t.CategoryId == categoryId)
            //    .Select(c => new ListViewModel() { Id = c.Id, Name = c.TypeName })
            //    .ToListAsync();
        }

        private async void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (_isLoading)
            //    return;

            //int typeId = -1;
            //if (cbType.SelectedValue != null && int.TryParse(cbType.SelectedValue.ToString(), out int val))
            //    typeId = val;

            //cbModelName.DisplayMember = "Name";
            //cbModelName.ValueMember = "Id";
            //cbModelName.DataSource = await _context.MachineNames
            //    .Where(t => t.TypeId == typeId)
            //    .Select(c => new ListViewModel() { Id = c.Id, Name = c.ModelName })
            //    .ToListAsync();
        }
    }
}
