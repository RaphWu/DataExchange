﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class MachineEdit : UIForm
    {

        #region fields

        private readonly CoreContext _context;

        #endregion fields

        public Machine Machine { get; set; } = new Machine();
        public CrudType CrudType { get; set; }
        public string MachineId { get; set; }
        public int CategoryId { get; set; }
        public int TypeId { get; set; }

        public MachineEdit(CoreContext coreContext)
        {
            InitializeComponent();
            _context = coreContext;
        }

        private async void MachineEdit_Load(object sender, EventArgs e)
        {
            tbMaincheId.Text = MachineId;

            cbCategory.DisplayMember = "Name";
            cbCategory.ValueMember = "Id";
            cbCategory.DataSource = await _context.MachineCategories
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.CategoryName })
                .ToListAsync();
            cbCategory.Enabled = false;
            //cbCategory.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            cbType.DisplayMember = "Name";
            cbType.ValueMember = "Id";
            cbType.DataSource = await _context.MachineTypes
                .Where(t => t.CategoryId == (int)cbCategory.SelectedValue)
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.TypeName })
                .ToListAsync();
            cbType.Enabled = false;
            //cbType.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            cbCondition.DisplayMember = "Name";
            cbCondition.ValueMember = "Id";
            cbCondition.DataSource = await _context.MachineConditions
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.Condition })
                .ToListAsync();

            cbBrand.DisplayMember = "Name";
            cbBrand.ValueMember = "Id";
            cbBrand.DataSource = await _context.MachineBrands
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.BrandName })
                .ToListAsync();

            cbLocation.DisplayMember = "Name";
            cbLocation.ValueMember = "Id";
            cbLocation.DataSource = await _context.MachineLocations
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.Location })
                .ToListAsync();

            cbConnected.DisplayMember = "Name";
            cbConnected.ValueMember = "BooleanId";
            cbConnected.DataSource = new List<ListViewModel>()
            {
                new ListViewModel() { BooleanId = false, Name = "未連網" },
                new ListViewModel() { BooleanId= true, Name = "可連網" },
            };

            cbDisposal.DisplayMember = "Name";
            cbDisposal.ValueMember = "BooleanId";
            cbDisposal.DataSource = new List<ListViewModel>()
            {
                new ListViewModel() {BooleanId = false, Name = "正常作業" },
                new ListViewModel() {BooleanId = true, Name = "已處置" },
            };

            Machine = await _context.Machines.FirstOrDefaultAsync(m => m.MachineId == MachineId);
            if (Machine != null)
            {
                cbCategory.SelectedValue = Machine.MachineNameId;
                cbType.SelectedValue = Machine.MachineName.TypeId;
                cbCondition.SelectedValue = Machine.ConditionId;
                cbBrand.SelectedValue = Machine.BrandId;
                cbLocation.SelectedValue = Machine.LocationId;
                cbConnected.SelectedValue = Machine.Connected;
                cbDisposal.SelectedValue = Machine.Disposal;
                tbAssets.Text = Machine.AssetString;
                tbSerialNumber.Text = Machine.SerialNumber;
                tbBarcode.Text = Machine.Barcode;
                tbRemark.Text = Machine.Remark;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Machine = new Machine()
            {
                MachineId = MachineId,
                MachineNameId = (int)cbCategory.SelectedValue,
                MachineName = new MachineName()
                {
                    TypeId = (int?)cbType.SelectedValue,
                    MachineType = new MachineType() { CategoryId = CategoryId }
                },
                ConditionId = (int)cbCondition.SelectedValue,
                BrandId = (int?)cbBrand.SelectedValue,
                LocationId = (int?)cbLocation.SelectedValue,
                Connected = (bool)cbConnected.SelectedValue,
                Disposal = (bool)cbDisposal.SelectedValue,
                AssetString = tbAssets.Text,
                SerialNumber = tbSerialNumber.Text,
                Barcode = tbBarcode.Text,
                Remark = tbRemark.Text,
            };

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
