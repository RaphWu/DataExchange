﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Views
{
    public class ItemState
    {
        public bool IsChecked { get; set; }
        public string Name { get; set; }
    }
}
