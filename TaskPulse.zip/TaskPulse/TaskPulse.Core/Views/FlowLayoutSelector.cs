﻿/*
 * 機台/機種選擇對話框。
 * 
 * 多選：
 *     使用 CoreData.ClassifyMachines 及 CoreData.MachinesMultiTabPageCache。
 *     建立分類TAB，以CheckBox選擇。
 * 單選：
 *     使用 CoreData.Models 及 CoreData.ModelTabPageCache。
 *     以RadioButton選擇。
 * 下方顯示已選取項目：分類 » 類型 » 項目1,項目2...
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.WinForms;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class FlowLayoutSelector : UIForm
    {
        #region fields

        private readonly ICore _core;

        private const int OPTIONAL_WIDTH = 140; // Items寬度
        private bool _preventControlsEvents = false; // 屏蔽Control事件
        private Dictionary<int, SelectorInfo> _allSelectedItem = new Dictionary<int, SelectorInfo>(); // 記錄目前選擇的Items

        #endregion fields

        /********************
         * properties
         ********************/
        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 是否隱藏標籤列。
        /// </summary>
        public bool HideTabHeaders
        {
            get { return _hideTabHeaders; }
            set
            {
                _hideTabHeaders = value;
                tabControlTypes.HideTabHeaders = value;
            }
        }
        private bool _hideTabHeaders;

        /// <summary>
        /// 是否隱藏 TreeView。
        /// </summary>
        public bool ShowTreeView
        {
            get { return _showTreeView; }
            set
            {
                treeViewCategories.Visible = value;
                label_TreeCaption.Visible = value;
                TLP_Content.ColumnStyles[0].Width = value ? 140 : 1;
                _showTreeView = value;
            }
        }
        private bool _showTreeView;

        /// <summary>
        /// TreeView標題。
        /// </summary>
        public string TreeViewCaption { set => label_TreeCaption.Text = value; }

        /// <summary>
        /// TabPage Cache。
        /// </summary>
        public Dictionary<string, List<TabPage>> TabPageCache { get; set; }

        /// <summary>
        /// 多選的類型。
        /// </summary>
        /// <remarks>true = 多選 (使用 CheckBox)。<br/>false = 單選 (使用 RadioButton)。</remarks>
        public bool MultiSelection { get; set; } = true;

        /// <summary>
        /// 預設值列表。
        /// </summary>
        public List<string> DefaultChecked { get; set; } = new List<string>();

        /// <summary>
        /// 返回的 Items。
        /// </summary>
        public List<SelectorInfo> ResultList { get; set; } = new List<SelectorInfo>();

        /********************
         * ctor
         ********************/
        public FlowLayoutSelector(ICore core)
        {
            InitializeComponent();
            _core = core;

            label_ResultList.Text = "";
        }

        /********************
         * Form
         ********************/
        private void FlowLayoutSelector_Shown(object sender, EventArgs e)
        {
            if (treeViewCategories.Nodes.Count > 0)
            {
                treeViewCategories.SelectedNode = treeViewCategories.Nodes[0];
                treeViewCategories_AfterSelect(treeViewCategories, new TreeViewEventArgs(treeViewCategories.SelectedNode));
            }
            this.BringToFront();
        }

        private void FlowLayoutSelector_FormClosing(object sender, FormClosingEventArgs e)
        {
            RemoveCheckBoxEvent();
            RemoveRadioButtonEvent();
            tabControlTypes.TabPages.Clear(); // 沒清掉的話，裡面的Control會全被釋放掉
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        /********************
         * Initialize
         ********************/
        public void Initialize()
        {
            tabControlTypes.TabPages.Clear();
            treeViewCategories.Nodes.Clear();
            foreach (var categoryName in TabPageCache.Keys)
                treeViewCategories.Nodes.Add(new TreeNode(categoryName));

            if (MultiSelection)
            {
                SetMultiSelectionToDefault();
                SetCheckBoxEvent();
            }
            else
            {
                if (DefaultChecked.Count > 1) // 預設值最多只能一個
                    DefaultChecked = new List<string>() { DefaultChecked[0] };

                SetSingleSelectionToDefault();
                SetRadioButtonEvent();
            }

            tabControlTypes.Refresh();
            SetAndShowSelected();
        }

        /********************
         * Utility
         ********************/
        /// <summary>
        /// 
        /// </summary>
        private void SetAndShowSelected()
        {
            ResultList = _allSelectedItem.Values.ToList();
            List<string> showResultList = new List<string>();

            if (MultiSelection)
            {
                var grouped = ResultList
                    .GroupBy(r => r.Category)
                    .OrderBy(g => g.Key);

                foreach (var categoryGroup in grouped)
                {
                    var typeGroups = categoryGroup
                        .GroupBy(g => g.Type)
                        .OrderBy(g => g.Key);

                    foreach (var typeGroup in typeGroups)
                    {
                        string names = string.Join("; ", typeGroup.Select(t => t.Name));
                        showResultList.Add($"{categoryGroup.Key} » {typeGroup.Key} » {names}");
                    }
                }

                label_ResultList.Text = string.Join("\n", showResultList);
            }
            else
            {
                if (ResultList.FirstOrDefault() is SelectorInfo selected)
                {
                    label_ResultList.Text = ShowTreeView
                        ? string.Join(" » ", new string[] { selected.Category, selected.Name })
                        : $"選擇的項目：{selected.Name}";
                }
                else
                {
                    label_ResultList.Text = "";
                }
            }

            //ResultList.Clear();
            //List<string> showResultList = new List<string>();

            //if (_allSelectedItem.Count > 0)
            //{
            //    if (MultiSelection)
            //    {
            //        var categories = _allSelectedItem
            //            .GroupBy(kvp => kvp.Value.Category)
            //            .OrderBy(g => g.Key);

            //        foreach (var categoryGroup in categories)
            //        {
            //            var types = categoryGroup
            //                .GroupBy(kvp => kvp.Value.TypeName)
            //                .OrderBy(tg => tg.Key);

            //            foreach (var typeGroup in types)
            //            {
            //                var selectedNames = typeGroup.Select(kvp => kvp.Key).ToList();
            //                var sortedSelectedNames = _core.SortMachineId(selectedNames);
            //                ResultList.AddRange(sortedSelectedNames);

            //                string names = string.Join("; ", sortedSelectedNames);
            //                string line = $"{categoryGroup.Key} » {typeGroup.Key} » {names}";
            //                showResultList.Add(line);
            //            }
            //        }
            //        label_ResultList.Text = string.Join("\n", showResultList);
            //    }
            //    else
            //    {
            //        if (_allSelectedItem != null && _allSelectedItem.Count > 0)
            //        {
            //            var selectedItem = _allSelectedItem.First();
            //            //string[] selected = new string[2];
            //            //selected[0] = selectedItem.Value.Category;
            //            //selected[1] = selectedItem.Key;

            //            //selected = selected.Where(s => !string.IsNullOrEmpty(s)).ToArray();
            //            //ResultList.Add(string.Join("; ", selected));
            //            ResultList.Clear();
            //            ResultList.Add(selectedItem.Key);
            //            label_ResultList.Text = $"選擇的項目： {selectedItem.Key}";
            //        }
            //        else
            //            label_ResultList.Text = "";
            //    }
            //}
        }

        /********************
         * Treeview
         ********************/
        private void treeViewCategories_AfterSelect(object sender, TreeViewEventArgs e)
        {
            _preventControlsEvents = true;
            WinFormExtension.RunOnUIThread(() =>
            {
                tabControlTypes.SuspendLayout();

                var categoryName = e.Node.Text;
                tabControlTypes.TabPages.Clear();

                var typeDict = TabPageCache[categoryName];
                foreach (var typePage in typeDict)
                    tabControlTypes.TabPages.Add(typePage);

                tabControlTypes.ResumeLayout();
            });
            _preventControlsEvents = false;
        }

        /********************
         * CheckBox
         ********************/
        /// <summary>
        /// 清除全部 CheckBox。
        /// </summary>
        private void uiButton_Clear_Click(object sender, EventArgs e)
        {
            ClearAllChecked();
            SetAndShowSelected();
        }

        ///// <summary>
        ///// 將 Machine Cache 中為 True 的 MachineId 轉存到 ResultList 和 _allSelectedItem，並更新顯示。
        ///// </summary>
        //private void GetMachineListCache()
        //{
        //    _preventControlsEvents = true;
        //    _allSelectedItem.Clear();
        //    var typeList = TabPageCache.Values;
        //    foreach (var typePage in typeList)
        //        foreach (var page in typePage)
        //            GetMachineListCache(page.Controls);
        //    SetAndShowSelected();
        //    _preventControlsEvents = false;
        //}

        ///// <summary>
        ///// 將 Machine Cache 中為 True 的 MachineId 轉存到 _allSelectedItem (遞迴用)。
        ///// </summary>
        ///// <param name="controls">根控制項。</param>
        //private void GetMachineListCache(Control.ControlCollection controls)
        //{
        //    foreach (Control uiTextBox in controls)
        //    {
        //        if (uiTextBox is UICheckBox rb)
        //        {
        //            if (rb.Checked)
        //            {
        //                var tag = (SelectorInfo)rb.Tag;
        //                string name = tag.Name;
        //                string type = tag.TypeName;
        //                string category = tag.Category;
        //                _allSelectedItem.Add(name, (category, type));
        //            }
        //        }
        //        else if (uiTextBox.HasChildren)
        //        {
        //            GetMachineListCache(uiTextBox.Controls);
        //        }
        //    }
        //}

        /// <summary>
        /// 清除所有 CheckBox 已勾選項目。
        /// </summary>
        private void ClearAllChecked()
        {
            _preventControlsEvents = true;

            _allSelectedItem.Clear();
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    ClearAllChecked(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 清除所有 CheckBox 已勾選項目 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void ClearAllChecked(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (cb.Checked)
                        cb.Checked = false;
                }
                else if (control.HasChildren)
                {
                    ClearAllChecked(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked。
        /// </summary>
        private void SetMultiSelectionToDefault()
        {
            _preventControlsEvents = true;
            _allSelectedItem.Clear();

            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetMachineListToDefault(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void SetMachineListToDefault(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (DefaultChecked.Contains(cb.Text))
                    {
                        if (!cb.Checked)
                            cb.Checked = true;

                        var tag = (SelectorInfo)cb.Tag;
                        int id = tag.Id;
                        string name = tag.Name;
                        string type = tag.Type;
                        string category = tag.Category;
                        _allSelectedItem.Add(id, new SelectorInfo()
                        {
                            Id = id,
                            Category = category,
                            Type = type,
                            Name = name,
                        });
                    }
                    else
                    {
                        if (cb.Checked)
                            cb.Checked = false;
                    }
                }
                else if (control.HasChildren)
                {
                    SetMachineListToDefault(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 加入事件。
        /// </summary>
        private void SetCheckBoxEvent()
        {
            _preventControlsEvents = true;
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxEvent(page.Controls, true);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 移除所有 CheckBox 事件。
        /// </summary>
        private void RemoveCheckBoxEvent()
        {
            _preventControlsEvents = true;
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxEvent(page.Controls, false);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 遍歷所有 CheckBox 並加入或移除事件 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        /// <param name="addOrRemove">加入或移除。</param>
        private void SetCheckBoxEvent(Control.ControlCollection controls, bool addOrRemove)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (addOrRemove)
                        cb.CheckedChanged += CheckBox_CheckedChanged;
                    else
                        cb.CheckedChanged -= CheckBox_CheckedChanged;
                }
                else if (control.HasChildren)
                {
                    SetCheckBoxEvent(control.Controls, addOrRemove);
                }
            }
        }

        /// <summary>
        /// CheckBox 勾選事件。
        /// </summary>
        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (_preventControlsEvents)
                return;
            if (!(sender is UICheckBox cb) || !(cb.Tag is SelectorInfo info))
                return;

            if (cb.Checked)
                _allSelectedItem[info.Id] = info;
            else
                _allSelectedItem.Remove(info.Id);
            SetAndShowSelected();
        }

        /********************
         * RadioButton
         ********************/
        /// <summary>
        /// 清除所有 RadioButton 項目。
        /// </summary>
        private void ClearAllSelected()
        {
            _preventControlsEvents = true;

            _allSelectedItem.Clear();
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    ClearAllSelected(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 清除所有 RadioButton 項目 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void ClearAllSelected(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (rb.Checked)
                        rb.Checked = false;
                }
                else if (control.HasChildren)
                {
                    ClearAllChecked(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked。
        /// </summary>
        private void SetSingleSelectionToDefault()
        {
            _preventControlsEvents = true;
            _allSelectedItem.Clear();

            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetSingleSelectionToDefault(page.Controls);

            _preventControlsEvents = false;
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void SetSingleSelectionToDefault(Control.ControlCollection controls)
        {
            bool notyetChecked = true;
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (notyetChecked && DefaultChecked.Contains(rb.Text))
                    {
                        if (!rb.Checked)
                            rb.Checked = true;

                        var tag = (SelectorInfo)rb.Tag;
                        int id = tag.Id;
                        string name = tag.Name;
                        string type = tag.Type;
                        string category = tag.Category;
                        _allSelectedItem.Clear();
                        _allSelectedItem.Add(id, new SelectorInfo()
                        {
                            Id = id,
                            Category = category,
                            Type = type,
                            Name = name,
                        });

                        notyetChecked = false;
                    }
                    else
                    {
                        if (rb.Checked)
                            rb.Checked = false;
                    }
                }
                else if (control.HasChildren)
                {
                    SetSingleSelectionToDefault(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 RadioButton 加入事件。
        /// </summary>
        private void SetRadioButtonEvent()
        {
            _preventControlsEvents = true;
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetRadioButtonEvent(page.Controls, true);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 移除所有 RadioButton 事件。
        /// </summary>
        private void RemoveRadioButtonEvent()
        {
            _preventControlsEvents = true;
            var typeList = TabPageCache.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetRadioButtonEvent(page.Controls, false);
            _preventControlsEvents = false;
        }

        /// <summary>
        /// 遍歷所有 RadioButton 並加入或移除事件 (遞迴用)。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        /// <param name="addOrRemove">加入或移除。</param>
        private void SetRadioButtonEvent(Control.ControlCollection controls, bool addOrRemove)
        {
            foreach (Control control in controls)
            {
                if (control is UIRadioButton rb)
                {
                    if (addOrRemove)
                        rb.CheckedChanged += RadioButton_CheckedChanged;
                    else
                        rb.CheckedChanged -= RadioButton_CheckedChanged;
                }
                else if (control.HasChildren)
                {
                    SetRadioButtonEvent(control.Controls, addOrRemove);
                }
            }
        }

        /// <summary>
        /// RadioButton 點選事件。
        /// </summary>
        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (_preventControlsEvents)
                return;
            if (!(sender is UIRadioButton rb) || !(rb.Tag is SelectorInfo info))
                return;

            _allSelectedItem.Clear();

            var tag = (SelectorInfo)rb.Tag;
            int id = tag.Id;
            string name = tag.Name;
            string type = tag.Type;
            string category = tag.Category;
            _allSelectedItem.Add(id, new SelectorInfo()
            {
                Id = id,
                Category = category,
                Type = type,
                Name = name,
            });

            SetAndShowSelected();
        }
    }
}
