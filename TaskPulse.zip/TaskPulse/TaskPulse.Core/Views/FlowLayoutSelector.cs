﻿/*
 * 多選：
 *     建立分類TAB。
 * 單選：
 *     排序 -> 3位數字 -> 5位數字
 * 下方顯示已選取項目。分類: 項目1,項目2...
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class FlowLayoutSelector : UIForm
    {
        #region fields

        private const int MACHINEID_WIDTH = 140;
        private CoreData _coreData;
        private ICore _core;

        private Dictionary<string, (string Category, string Type)> _checkedMachines
            = new Dictionary<string, (string Category, string Type)>();
        private Dictionary<string, TabPage> _tabPagesCache = new Dictionary<string, TabPage>();

        private List<string> _resultListWhenCancel;
        //private string _selectMachine = string.Empty;

        private string _categoryName = string.Empty;
        private string _typeName = string.Empty;
        private string _currentCategory;

        #endregion fields

        /********************
         * properties
         ********************/
        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 是否隱藏標籤列。
        /// </summary>
        public bool HideTabHeaders
        {
            get => tabControlTypes.HideTabHeaders;
            set
            {
                if (tabControlTypes.HideTabHeaders != value)
                    tabControlTypes.HideTabHeaders = value;
            }
        }

        /// <summary>
        /// 是否允許多選。
        /// </summary>
        /// <remarks>true=多選 (使用 CheckBox)，false=單選 (使用 RadioButton)。</remarks>
        public bool MultiSelection { get; set; } = true;

        /// <summary>
        /// 預設值列表。
        /// </summary>
        public List<string> DefaultChecked { get; set; }

        /// <summary>
        /// 返回的項目。
        /// </summary>
        public List<string> ResultList { get; set; } = new List<string>();

        /// <summary>
        /// 單選的顯示項目。
        /// </summary>
        public List<string> SingleItems { get; set; }

        /********************
         * ctor
         ********************/
        public FlowLayoutSelector(CoreData coreData, ICore core)
        {
            InitializeComponent();
            _coreData = coreData;
            _core = core;

            label_ResultList.Text = "";

            this.AcceptButton = uiButton_OK;
            this.CancelButton = uiButton_Cancel;
        }

        /********************
         * Form
         ********************/
        private void FlowLayoutSelector_Shown(object sender, EventArgs e)
        {
            if (treeViewCategories.Nodes.Count > 0)
            {
                treeViewCategories.SelectedNode = treeViewCategories.Nodes[0];
                treeViewCategories_AfterSelect(treeViewCategories, new TreeViewEventArgs(treeViewCategories.SelectedNode));
            }
        }

        private void FlowLayoutSelector_FormClosing(object sender, FormClosingEventArgs e)
        {
            RemoveCheckBoxEvent();
            tabControlTypes.TabPages.Clear(); // 沒清掉的話，裡面的Control會全被釋放掉
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        /********************
         * Initialize
         ********************/
        public void Initialize()
        {
            tabControlTypes.TabPages.Clear();
            SetCheckBoxToDefault();

            if (MultiSelection)
            {
                treeViewCategories.Nodes.Clear();
                foreach (var categoryName in _coreData.TabPageSelector.Keys)
                    treeViewCategories.Nodes.Add(new TreeNode(categoryName));
                treeViewCategories.Visible = true;
            }
            else
            {
                treeViewCategories.Visible = false;
                var tabPage = new TabPage("SinglePage");
                var flow = new UIFlowLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    AutoScroll = true,
                    WrapContents = true,
                };

                foreach (var text in SingleItems)
                {
                    var rb = new UIRadioButton();
                    rb.SetDPIScale();
                    rb.Width = MACHINEID_WIDTH;
                    rb.GroupIndex = 1;
                    rb.Name = text;
                    rb.Text = text;
                    rb.Checked = DefaultChecked.Count > 0 && DefaultChecked[0] == text;
                    rb.CheckedChanged += RadioButton_CheckedChanged;
                    flow.Add(rb);
                }

                tabPage.Controls.Add(flow);
                tabControlTypes.TabPages.Add(tabPage);
            }

            SetAndShowSelected();
            SetCheckBoxEvent();
        }

        /********************
         * Utility
         ********************/
        /// <summary>
        /// 
        /// </summary>
        private void SetAndShowSelected()
        {
            var grouped = _checkedMachines
                .GroupBy(kvp => kvp.Value.Category)
                .OrderBy(g => g.Key)  // 分類排序
                .Select(categoryGroup => new
                {
                    Category = categoryGroup.Key,
                    Types = categoryGroup
                        .GroupBy(kvp => kvp.Value.Type)
                        .OrderBy(tg => tg.Key)  // 型式排序
                        .Select(typeGroup => new
                        {
                            Type = typeGroup.Key,
                            Machines = typeGroup.Select(m => m.Key).OrderBy(m => m) // 機台排序
                        })
                });

            ResultList.Clear();
            List<string> showResultList = new List<string>();
            foreach (var g in grouped)
            {
                foreach (var t in g.Types)
                {
                    var result = _core.SortMachineId(t.Machines.ToList());
                    ResultList.AddRange(result);

                    string machines = string.Join(", ", result);
                    string line = $"{g.Category} » {t.Type} » {machines}";
                    showResultList.Add(line);
                }
            }
            label_ResultList.Text = string.Join("\n", showResultList);
        }

        /// <summary>
        /// 將 Cache 中為 True 的 MachineId 轉存到 ResultList 和 _checkedMachines。
        /// </summary>
        private void GetCheckBoxCacheResult()
        {
            _checkedMachines.Clear();
            var typeList = _coreData.TabPageSelector.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    GetCheckBoxCacheResult(page.Controls);
        }

        /// <summary>
        /// 將 Cache 中為 True 的 MachineId 轉存到 _checkedMachines。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void GetCheckBoxCacheResult(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (cb.Checked)
                    {
                        dynamic tag = cb.Tag;
                        string machineId = tag.MachineId;
                        string type = tag.Type;
                        string category = tag.Category;
                        _checkedMachines.Add(machineId, (category, type));
                    }
                }
                else if (control.HasChildren)
                {
                    GetCheckBoxCacheResult(control.Controls);
                }
            }
        }

        /********************
         * Treeview
         ********************/
        private void treeViewCategories_AfterSelect(object sender, TreeViewEventArgs e)
        {
            this.ShowProcessForm();

            _loadingCheckboxes = true;
            tabControlTypes.SuspendLayout();

            var categoryName = e.Node.Text;
            tabControlTypes.TabPages.Clear();

            var typeDict = _coreData.TabPageSelector[categoryName];
            foreach (var typePage in typeDict)
                tabControlTypes.TabPages.Add(typePage);

            tabControlTypes.ResumeLayout();
            _loadingCheckboxes = false;

            this.HideProcessForm();
        }

        /********************
         * CheckBox
         ********************/

        private void uiButton_Clear_Click(object sender, EventArgs e)
        {
            ClearAllChecked();
            SetAndShowSelected();
        }

        /// <summary>
        /// 將所有 CheckBox 加入事件。
        /// </summary>
        private void SetCheckBoxEvent()
        {
            _loadingCheckboxes = false;
            var typeList = _coreData.TabPageSelector.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxEvent(page.Controls, true);
            _loadingCheckboxes = true;
        }

        /// <summary>
        /// 將所有 CheckBox 移除事件。
        /// </summary>
        private void RemoveCheckBoxEvent()
        {
            _loadingCheckboxes = false;
            var typeList = _coreData.TabPageSelector.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxEvent(page.Controls, false);
            _loadingCheckboxes = true;
        }

        /// <summary>
        /// 遍歷所有 CheckBox 並加入或移除事件。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        /// <param name="addOrRemove">加入或移除。</param>
        private void SetCheckBoxEvent(Control.ControlCollection controls, bool addOrRemove)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (addOrRemove)
                        cb.CheckedChanged += CheckBox_CheckedChanged;
                    else
                        cb.CheckedChanged -= CheckBox_CheckedChanged;
                }
                else if (control.HasChildren)
                {
                    SetCheckBoxEvent(control.Controls, addOrRemove);
                }
            }
        }

        /// <summary>
        /// 清除所有 CheckBox 已勾選項目。
        /// </summary>
        private void ClearAllChecked()
        {
            _loadingCheckboxes = false;

            _checkedMachines.Clear();
            var typeList = _coreData.TabPageSelector.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    ClearAllChecked(page.Controls);

            _loadingCheckboxes = true;
        }

        /// <summary>
        /// 清除所有 CheckBox 已勾選項目。。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void ClearAllChecked(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (cb.Checked)
                        cb.Checked = false;
                }
                else if (control.HasChildren)
                {
                    ClearAllChecked(control.Controls);
                }
            }
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked。
        /// </summary>
        private void SetCheckBoxToDefault()
        {
            _loadingCheckboxes = false;
            _checkedMachines.Clear();

            var typeList = _coreData.TabPageSelector.Values;
            foreach (var typePage in typeList)
                foreach (var page in typePage)
                    SetCheckBoxToDefault(page.Controls);

            _loadingCheckboxes = true;
        }

        /// <summary>
        /// 將所有 CheckBox 設定為預設值 DefaultChecked。
        /// </summary>
        /// <param name="controls">根控制項。</param>
        private void SetCheckBoxToDefault(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (DefaultChecked.Contains(cb.Text))
                    {
                        if (!cb.Checked)
                            cb.Checked = true;

                        dynamic tag = cb.Tag;
                        string machineId = tag.MachineId;
                        string type = tag.Type;
                        string category = tag.Category;
                        _checkedMachines.Add(machineId, (category, type));
                    }
                    else
                    {
                        if (cb.Checked)
                            cb.Checked = false;
                    }
                }
                else if (control.HasChildren)
                {
                    SetCheckBoxToDefault(control.Controls);
                }
            }
        }

        private bool _loadingCheckboxes = false;
        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (_loadingCheckboxes)
                return;
            if (!(sender is UICheckBox cb) || cb.Tag == null)
                return;

            dynamic tag = cb.Tag;
            string machineId = tag.MachineId;
            string type = tag.Type;
            string category = tag.Category;

            if (cb.Checked)
            {
                if (!_checkedMachines.ContainsKey(machineId))
                    _checkedMachines.Add(machineId, (category, type));
            }
            else
            {
                if (_checkedMachines.ContainsKey(machineId))
                    _checkedMachines.Remove(machineId);
            }
            SetAndShowSelected();
        }

        /********************
         * RadioButton
         ********************/
        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (sender is UIRadioButton rb)
            {
                //_selectMachine = rb.Text;
                label_ResultList.Text = rb.Text;
                ResultList[0] = rb.Text;
            }
        }
    }
}
