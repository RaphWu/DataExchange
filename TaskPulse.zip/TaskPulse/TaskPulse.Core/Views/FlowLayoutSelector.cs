﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Sunny.UI;
using static System.Net.Mime.MediaTypeNames;

namespace Calin.TaskPulse.Core.Views
{
    public partial class FlowLayoutSelector : UIForm
    {
        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 是否允許多選。
        /// </summary>
        /// <remarks>true=多選 (使用 CheckBox)，false=單選 (使用 RadioButton)。</remarks>
        public bool MultiSelection { get; set; }

        /// <summary>
        /// 返回的項目。
        /// </summary>
        public List<string> ResultList { get; set; }

        private const string Flow_Layout_Panel_NAME = "flowLayout";
        private int _tabIndex;
        private int _itemIndex;

        private Dictionary<int, ItemState> _selected;

        /// <summary>
        /// 顯示的項目。
        /// </summary>
        public Dictionary<string, ItemState> Items
        {
            set
            {
                if (value != null)
                {
                    tabMenu.TabPages.Clear();
                    _selected = new Dictionary<int, ItemState>();

                    _tabIndex = 0;
                    _itemIndex = 0;
                    foreach (var item in value)
                    {
                        string flpName = $"{Flow_Layout_Panel_NAME}{_tabIndex}";

                        var page = new TabPage(item.Key);
                        page.Name = $"page{_tabIndex}";

                        var flp = new UIFlowLayoutPanel()
                        {
                            Name = flpName,
                            Dock = DockStyle.Fill,
                            AutoScroll = true,
                            WrapContents = true,
                        };

                        if (MultiSelection)
                        {
                            string text = item.Value.Name;
                            var ctl = new UICheckBox();
                            ctl.SetDPIScale();
                            ctl.Width = 160;
                            ctl.Name = text;
                            ctl.Text = text;
                            ctl.Checked = item.Value.IsChecked;
                            ctl.Tag = _itemIndex;
                            ctl.CheckedChanged += Ctl_CheckedChanged;
                            flp.Controls.Add(ctl);
                            _selected[_itemIndex++] = new ItemState
                            {
                                Name = text,
                                IsChecked = false
                            };
                        }
                        else
                        {
                            string text = item.Value.Name;
                            var ctl = new UIRadioButton();
                            ctl.SetDPIScale();
                            ctl.Width = 160;
                            ctl.GroupIndex = 0;
                            ctl.Name = text;
                            ctl.Text = text;
                            ctl.Checked = item.Value.IsChecked;
                            ctl.Tag = _itemIndex;
                            ctl.CheckedChanged += Ctl_CheckedChanged;
                            flp.Controls.Add(ctl);
                            _selected[_itemIndex++] = new ItemState
                            {
                                Name = text,
                                IsChecked = false
                            };
                        }

                        page.Controls.Add(flp);
                        tabMenu.TabPages.Add(page);
                        _tabIndex++;
                    }
                }
            }
        }

        private void Ctl_CheckedChanged(object sender, EventArgs e)
        {
            if (!(sender is UICheckBox ctl))
                return;

            int index = (int)ctl.Tag;
            _selected[index].IsChecked = ctl.Checked;
        }

        public FlowLayoutSelector()
        {
            InitializeComponent();
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            ResultList = _selected
                .Where(x => x.Value.IsChecked)
                .Select(x => x.Value.Name)
                .ToList();

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
