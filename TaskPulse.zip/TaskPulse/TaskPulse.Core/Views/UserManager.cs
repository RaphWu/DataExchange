﻿using System;
using Calin.CSharp.Security;
using Calin.TaskPulse.Core.Authority;
using Krypton.Toolkit;

namespace Calin.TaskPulse.Core.Views
{
    public partial class UserManager : KryptonForm
    {
        public DialogInfo DialogInfo { get; set; } = new DialogInfo();

        public UserManager()
        {
            InitializeComponent();
        }

        private void UserManager_Load(object sender, EventArgs e)
        {
            bool showIt;

            showIt = !string.IsNullOrEmpty(DialogInfo.OldNameCaption);
            textBox_OldUserName.Visible = showIt;
            label_OldUserName.Visible = showIt;
            if (showIt)
            {
                textBox_OldUserName.Text = DialogInfo.NewName;
                label_OldUserName.Text = DialogInfo.OldNameCaption;
            }

            showIt = !string.IsNullOrEmpty(DialogInfo.NewNameCaption);
            textBox_NewUserName.Visible = showIt;
            label_NewUserName.Visible = showIt;
            if (showIt)
            {
                textBox_NewUserName.Text = DialogInfo.NewName;
                label_NewUserName.Text = DialogInfo.NewNameCaption;
            }

            showIt = !string.IsNullOrEmpty(DialogInfo.OldPasswordCaption);
            maskedTextBox_OldPassword.Visible = showIt;
            label_OldPassword.Visible = showIt;
            if (showIt)
            {
                maskedTextBox_OldPassword.Text = string.Empty;
                label_OldPassword.Text = DialogInfo.OldPasswordCaption;
            }

            showIt = !string.IsNullOrEmpty(DialogInfo.NewPasswordCaption);
            maskedTextBox_NewPassword.Visible = showIt;
            label_NewPassword.Visible = showIt;
            if (showIt)
            {
                maskedTextBox_NewPassword.Text = string.Empty;
                label_NewPassword.Text = DialogInfo.NewPasswordCaption;
            }

            this.Text = DialogInfo.Title;
        }

        private void button_OK_Click(object sender, EventArgs e)
        {
            DialogInfo = new DialogInfo()
            {
                NewName = textBox_NewUserName.Text.Trim(),
                NewPassword = maskedTextBox_NewPassword.Text.Trim().GetMD5Hash(),
            };

            this.Close();
        }
    }
}
