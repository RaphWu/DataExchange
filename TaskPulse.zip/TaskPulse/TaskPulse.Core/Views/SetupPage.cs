﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class SetupPage : UIPage
    {
        private readonly Setup_Company _setupCompany;
        private readonly Setup_Machines _setupMachines;
        private readonly Setup_Models _setupModels;

        public enum ItemCode
        {
            /***** 共用資料 *****/

            [Description("公司資料")]
            Company = 1,

            [Description("人員名冊")]
            Employees = 2,

            [Description("權限系統")]
            Authority = 3,

            /***** 工具委託 *****/

            /***** 專案管理 *****/

            /***** 工單維護 *****/

            [Description("機台管理")]
            Machines = 30,

            [Description("機種&&工站")]
            Models = 31,

            [Description("維護資料")]
            Maintenance = 32,
        }

        public SetupPage(Setup_Company setup_Company, Setup_Machines setup_Machines, Setup_Models setup_Models)
        {
            InitializeComponent();
            _setupCompany = setup_Company;
            _setupMachines = setup_Machines;
            _setupModels = setup_Models;

            uiTreeView_SetupMenu.SelectedColor = CommonStyles.BackColor;

            TreeNode parent;
            TreeNode child;

            /***** 共用資料 *****/
            parent = new TreeNode("共用資料");
            parent.Tag = -1;
            uiTreeView_SetupMenu.Nodes.Add(parent);

            child = new TreeNode(ItemCode.Company.GetDescription());
            child.Tag = (int)ItemCode.Company;
            parent.Nodes.Add(child);

            child = new TreeNode(ItemCode.Employees.GetDescription());
            child.Tag = (int)ItemCode.Employees;
            parent.Nodes.Add(child);

            child = new TreeNode(ItemCode.Authority.GetDescription());
            child.Tag = (int)ItemCode.Authority;
            parent.Nodes.Add(child);

            /***** 工具委託 *****/

            /***** 專案管理 *****/

            /***** 工單維護 *****/
            parent = new TreeNode(PageCode.MaintiFlow.GetDescription());
            parent.Tag = -1;
            uiTreeView_SetupMenu.Nodes.Add(parent);

            child = new TreeNode(ItemCode.Machines.GetDescription());
            child.Tag = (int)ItemCode.Machines;
            parent.Nodes.Add(child);

            child = new TreeNode(ItemCode.Models.GetDescription());
            child.Tag = (int)ItemCode.Models;
            parent.Nodes.Add(child);

            uiTreeView_SetupMenu.ExpandAll();
        }

        private void uiTreeView_SetupMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (Enum.TryParse(e.Node.Tag.ToString(), out ItemCode itemCode))
            {
                panel_Setup.Controls.Clear();
                UIUserControl control = default;

                switch (itemCode)
                {
                    case ItemCode.Company:
                        control = _setupCompany;
                        break;

                    //case ItemCode.Employees:
                    //    break;

                    //case ItemCode.Authority:
                    //    break;

                    case ItemCode.Models:
                        control = _setupModels;
                        break;

                    case ItemCode.Machines:
                        control = _setupMachines;
                        break;

                    default:
                        return;
                }

                if (control != null)
                {
                    control.Dock = DockStyle.Fill;
                    panel_Setup.Controls.Add(control);
                }
            }
        }

        private void uiTreeView_SetupMenu_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.IsExpanded)
                e.Node.Collapse();
            else
                e.Node.Expand();

            uiTreeView_SetupMenu.SelectedNode = e.Node;
        }
    }
}
