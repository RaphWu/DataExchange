﻿using System;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class SetupPage : UIPage
    {
        private ILifetimeScope _rootScope;
        private ILifetimeScope _currentScope;
        private UIUserControl _currentPage;
        private PageCode _currentPageCode = PageCode.None;

        //private readonly Setup_MachinesSummary _setupMachinesSummary;
        //private readonly Setup_MachineInfo1 _setupMachineInfo1;
        //private readonly Setup_MachineInfo2 _setupMachineInfo2;
        //private readonly Setup_Models _setupModels;

        //public SetupPage(Setup_MachinesSummary setup_MachinesSummary,
        //                 Setup_MachineInfo1 setup_MachineInfo1,
        //                 Setup_MachineInfo2 setup_MachineInfo2,
        //                 Setup_Models setup_Models)
        public SetupPage(ILifetimeScope rootScope)
        {
            InitializeComponent();
            _rootScope = rootScope;

            //_setupMachinesSummary = setup_MachinesSummary;
            //_setupMachineInfo1 = setup_MachineInfo1;
            //_setupMachineInfo2 = setup_MachineInfo2;
            //_setupModels = setup_Models;

            TreeView_SetupMenu.SelectedColor = CommonStyles.BackColor;

            TreeNode parent;
            TreeNode child1;
            TreeNode child2;

            /***** 維護工單 *****/

            //parent = new TreeNode(PageCode.MachinesSummary.GetDescription());
            //parent.Tag = (int)PageCode.MachinesSummary;
            //TreeView_SetupMenu.Nodes.Add(parent);

            /***** 工具委託 *****/

            /***** 專案管理 *****/

            /***** 基本資料管理 *****/
            parent = new TreeNode("基本資料管理");
            parent.Tag = -1;
            TreeView_SetupMenu.Nodes.Add(parent);

            child1 = new TreeNode(PageCode.Machines.GetDescription());
            child1.Tag = (int)PageCode.Machines;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.MachinesInfo1.GetDescription());
            child1.Tag = (int)PageCode.MachinesInfo1;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.MachinesInfo2.GetDescription());
            child1.Tag = (int)PageCode.MachinesInfo2;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.Models.GetDescription());
            child1.Tag = (int)PageCode.Models;
            parent.Nodes.Add(child1);

            //parent = new TreeNode(PageCode.MaintiFlowMain.GetDescription());
            //parent.Tag = -1;
            //TreeView_SetupMenu.Nodes.Add(parent);

            child1 = new TreeNode(PageCode.Employees.GetDescription());
            child1.Tag = (int)PageCode.Employees;
            parent.Nodes.Add(child1);

            //child1 = new TreeNode(PageCode.Authority.GetDescription());
            //child1.Tag = (int)PageCode.Authority;
            //parent.Nodes.Add(child1);

            TreeView_SetupMenu.ExpandAll();
        }

        private void TreeView_SetupMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (Enum.TryParse(e.Node.Tag.ToString(), out PageCode pageCode))
            {
                if (_currentPageCode == pageCode)
                    return;

                _currentScope?.Dispose();
                _currentScope = _rootScope.BeginLifetimeScope();

                switch (pageCode)
                {
                    case PageCode.MachinesSummary:
                        _currentPage = _currentScope.Resolve<Setup_MachinesSummary>();
                        break;

                    case PageCode.MachinesInfo1:
                        _currentPage = _currentScope.Resolve<Setup_MachineInfo1>();
                        break;

                    case PageCode.MachinesInfo2:
                        _currentPage = _currentScope.Resolve<Setup_MachineInfo2>();
                        break;

                    case PageCode.Models:
                        _currentPage = _currentScope.Resolve<Setup_Models>();
                        break;

                    //case PageCode.Employees:
                    //    break;

                    //case PageCode.Authority:
                    //    break;

                    default:
                        return;
                }

                _currentPage.Dock = DockStyle.Fill;
                panel_Setup.Controls.Clear();
                panel_Setup.Controls.Add(_currentPage);
                _currentPageCode = pageCode;
            }
        }

        private void uiTreeView_SetupMenu_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.IsExpanded)
                e.Node.Collapse();
            else
                e.Node.Expand();

            TreeView_SetupMenu.SelectedNode = e.Node;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                if (!DesignMode)
                    _currentScope?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
