﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Models
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.Workstation_Up = new Sunny.UI.UISymbolButton();
            this.Workstation_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.Workstation_Create = new Sunny.UI.UISymbolButton();
            this.Workstation_Edit = new Sunny.UI.UISymbolButton();
            this.Workstation_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Model_Create = new Sunny.UI.UISymbolButton();
            this.Model_Edit = new Sunny.UI.UISymbolButton();
            this.Model_Delete = new Sunny.UI.UISymbolButton();
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.List_Workstations = new Sunny.UI.UIListBox();
            this.HeadLabel_Workstation = new System.Windows.Forms.Label();
            this.Button_Refresh = new Sunny.UI.UISymbolButton();
            this.List_Models = new Sunny.UI.UIListBox();
            this.HeadLabel_Model = new System.Windows.Forms.Label();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel3.AutoSize = true;
            this.flowLayoutPanel3.Controls.Add(this.Workstation_Up);
            this.flowLayoutPanel3.Controls.Add(this.Workstation_Down);
            this.flowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(236, 157);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel3.TabIndex = 6;
            // 
            // Workstation_Up
            // 
            this.Workstation_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Up.Location = new System.Drawing.Point(0, 9);
            this.Workstation_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Workstation_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Up.Name = "Workstation_Up";
            this.Workstation_Up.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Up.Symbol = 361702;
            this.Workstation_Up.SymbolSize = 32;
            this.Workstation_Up.TabIndex = 2;
            this.Workstation_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Up.Click += new System.EventHandler(this.WorkStation_Up_Click);
            // 
            // Workstation_Down
            // 
            this.Workstation_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Down.Location = new System.Drawing.Point(0, 57);
            this.Workstation_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Workstation_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Down.Name = "Workstation_Down";
            this.Workstation_Down.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Down.Symbol = 361703;
            this.Workstation_Down.SymbolSize = 32;
            this.Workstation_Down.TabIndex = 4;
            this.Workstation_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Down.Click += new System.EventHandler(this.WorkStation_Down_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.Controls.Add(this.Workstation_Create);
            this.flowLayoutPanel4.Controls.Add(this.Workstation_Edit);
            this.flowLayoutPanel4.Controls.Add(this.Workstation_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(287, 632);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 5;
            // 
            // Workstation_Create
            // 
            this.Workstation_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Create.Location = new System.Drawing.Point(9, 0);
            this.Workstation_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Workstation_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Create.Name = "Workstation_Create";
            this.Workstation_Create.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Create.Symbol = 557669;
            this.Workstation_Create.SymbolSize = 32;
            this.Workstation_Create.TabIndex = 2;
            this.Workstation_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Create.Click += new System.EventHandler(this.WorkStation_Create_Click);
            // 
            // Workstation_Edit
            // 
            this.Workstation_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Edit.Location = new System.Drawing.Point(57, 0);
            this.Workstation_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Workstation_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Edit.Name = "Workstation_Edit";
            this.Workstation_Edit.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Edit.Symbol = 559205;
            this.Workstation_Edit.SymbolSize = 32;
            this.Workstation_Edit.TabIndex = 3;
            this.Workstation_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Edit.Click += new System.EventHandler(this.WorkStation_Edit_Click);
            // 
            // Workstation_Delete
            // 
            this.Workstation_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Delete.Location = new System.Drawing.Point(105, 0);
            this.Workstation_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Workstation_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Delete.Name = "Workstation_Delete";
            this.Workstation_Delete.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Delete.Symbol = 559506;
            this.Workstation_Delete.SymbolSize = 26;
            this.Workstation_Delete.TabIndex = 4;
            this.Workstation_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Delete.Click += new System.EventHandler(this.WorkStation_Delete_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.Model_Create);
            this.flowLayoutPanel1.Controls.Add(this.Model_Edit);
            this.flowLayoutPanel1.Controls.Add(this.Model_Delete);
            this.flowLayoutPanel1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(39, 632);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(120, 30);
            this.flowLayoutPanel1.TabIndex = 3;
            // 
            // Model_Create
            // 
            this.Model_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Create.Location = new System.Drawing.Point(5, 0);
            this.Model_Create.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Create.Name = "Model_Create";
            this.Model_Create.Size = new System.Drawing.Size(30, 30);
            this.Model_Create.Symbol = 557669;
            this.Model_Create.SymbolSize = 32;
            this.Model_Create.TabIndex = 2;
            this.Model_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Create.Click += new System.EventHandler(this.Model_Create_Click);
            // 
            // Model_Edit
            // 
            this.Model_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Edit.Location = new System.Drawing.Point(45, 0);
            this.Model_Edit.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Edit.Name = "Model_Edit";
            this.Model_Edit.Size = new System.Drawing.Size(30, 30);
            this.Model_Edit.Symbol = 559205;
            this.Model_Edit.SymbolSize = 32;
            this.Model_Edit.TabIndex = 3;
            this.Model_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Edit.Click += new System.EventHandler(this.Model_Edit_Click);
            // 
            // Model_Delete
            // 
            this.Model_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Delete.Location = new System.Drawing.Point(85, 0);
            this.Model_Delete.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Delete.Name = "Model_Delete";
            this.Model_Delete.Size = new System.Drawing.Size(30, 30);
            this.Model_Delete.Symbol = 559506;
            this.Model_Delete.SymbolSize = 26;
            this.Model_Delete.TabIndex = 4;
            this.Model_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Delete.Click += new System.EventHandler(this.Model_Delete_Click);
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 6;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.List_Workstations, 3, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_Workstation, 3, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel3, 2, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel4, 3, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel1, 1, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.Button_Refresh, 5, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Models, 1, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.HeadLabel_Model, 1, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 3;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(872, 682);
            this.tableLayoutPanel_Page.TabIndex = 1;
            // 
            // List_Workstations
            // 
            this.List_Workstations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Workstations.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Workstations.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Workstations.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Workstations.Location = new System.Drawing.Point(273, 30);
            this.List_Workstations.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Workstations.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Workstations.Name = "List_Workstations";
            this.List_Workstations.Padding = new System.Windows.Forms.Padding(2);
            this.List_Workstations.Radius = 1;
            this.List_Workstations.ShowText = false;
            this.List_Workstations.Size = new System.Drawing.Size(172, 597);
            this.List_Workstations.TabIndex = 18;
            this.List_Workstations.Text = "uiListBox1";
            this.List_Workstations.SelectedIndexChanged += new System.EventHandler(this.List_Workstations_SelectedIndexChanged);
            // 
            // HeadLabel_Workstation
            // 
            this.HeadLabel_Workstation.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_Workstation.AutoSize = true;
            this.HeadLabel_Workstation.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_Workstation.Location = new System.Drawing.Point(334, 6);
            this.HeadLabel_Workstation.Name = "HeadLabel_Workstation";
            this.HeadLabel_Workstation.Size = new System.Drawing.Size(49, 19);
            this.HeadLabel_Workstation.TabIndex = 17;
            this.HeadLabel_Workstation.Text = "工站";
            this.HeadLabel_Workstation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Button_Refresh
            // 
            this.Button_Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Refresh.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Refresh.Location = new System.Drawing.Point(582, 225);
            this.Button_Refresh.Margin = new System.Windows.Forms.Padding(3, 200, 3, 3);
            this.Button_Refresh.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Refresh.Name = "Button_Refresh";
            this.Button_Refresh.Size = new System.Drawing.Size(120, 35);
            this.Button_Refresh.Symbol = 57386;
            this.Button_Refresh.TabIndex = 13;
            this.Button_Refresh.Text = "更新頁面";
            this.Button_Refresh.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Refresh.Visible = false;
            this.Button_Refresh.Click += new System.EventHandler(this.Button_Refresh_Click);
            // 
            // List_Models
            // 
            this.List_Models.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Models.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Models.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Models.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Models.Location = new System.Drawing.Point(13, 30);
            this.List_Models.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Models.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Models.Name = "List_Models";
            this.List_Models.Padding = new System.Windows.Forms.Padding(2);
            this.List_Models.ShowText = false;
            this.List_Models.Size = new System.Drawing.Size(172, 597);
            this.List_Models.TabIndex = 14;
            this.List_Models.Text = "uiListBox1";
            this.List_Models.SelectedIndexChanged += new System.EventHandler(this.List_Models_SelectedIndexChanged);
            // 
            // HeadLabel_Model
            // 
            this.HeadLabel_Model.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.HeadLabel_Model.AutoSize = true;
            this.HeadLabel_Model.Font = new System.Drawing.Font("標楷體", 14F);
            this.HeadLabel_Model.Location = new System.Drawing.Point(74, 6);
            this.HeadLabel_Model.Name = "HeadLabel_Model";
            this.HeadLabel_Model.Size = new System.Drawing.Size(49, 19);
            this.HeadLabel_Model.TabIndex = 16;
            this.HeadLabel_Model.Text = "機種";
            this.HeadLabel_Model.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Setup_Models
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_Models";
            this.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Size = new System.Drawing.Size(872, 682);
            this.Load += new System.EventHandler(this.Setup_Models_Load);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.tableLayoutPanel_Page.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Sunny.UI.UISymbolButton Model_Create;
        private Sunny.UI.UISymbolButton Model_Edit;
        private Sunny.UI.UISymbolButton Model_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton Workstation_Create;
        private Sunny.UI.UISymbolButton Workstation_Edit;
        private Sunny.UI.UISymbolButton Workstation_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private Sunny.UI.UISymbolButton Workstation_Up;
        private Sunny.UI.UISymbolButton Workstation_Down;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private Sunny.UI.UISymbolButton Button_Refresh;
        private Sunny.UI.UIListBox List_Models;
        private System.Windows.Forms.Label HeadLabel_Workstation;
        private System.Windows.Forms.Label HeadLabel_Model;
        private Sunny.UI.UIListBox List_Workstations;
    }
}
