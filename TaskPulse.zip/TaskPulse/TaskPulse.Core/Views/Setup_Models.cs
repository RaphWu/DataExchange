﻿/*
 * 編輯後ListBox不會更新的問題
 * 
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Models : UIUserControl
    {
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly CoreData _coreData;
        private readonly CRUD _crud;

        private List<ListViewModel> _modelViews;

        public Setup_Models(CoreContext coreContext, ICore core, CoreData coreData, CRUD crud)
        {
            InitializeComponent();
            _context = coreContext;
            _core = core;
            _coreData = coreData;
            _crud = crud;

            Button_Refresh.FillColor = CommonStyles.BackColor;

            // 機種
            List_Models.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Models.ScrollBarColor = CommonStyles.BackColor;
            List_Models.ValueMember = nameof(ListViewModel.Key);
            List_Models.DisplayMember = nameof(ListViewModel.Value);

            Model_Create.FillColor = CommonStyles.BackColor;
            Model_Edit.FillColor = CommonStyles.BackColor;
            Model_Delete.FillColor = CommonStyles.BackColor;

            // 工站
            List_Workstations.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Workstations.ScrollBarColor = CommonStyles.BackColor;
            List_Workstations.ValueMember = nameof(ListViewModel.Key);
            List_Workstations.DisplayMember = nameof(ListViewModel.Value);

            WorkStation_Create.FillColor = CommonStyles.BackColor;
            WorkStation_Edit.FillColor = CommonStyles.BackColor;
            WorkStation_Delete.FillColor = CommonStyles.BackColor;
            WorkStation_Up.FillColor = CommonStyles.BackColor;
            WorkStation_Down.FillColor = CommonStyles.BackColor;
        }

        private void Setup_Models_Load(object sender, EventArgs e)
        {
            UpdateModelsView();
            //Models_SelectionChanged();
            //Workstations_SelectionChanged();
        }

        /********************
         * Models
         ********************/
        private void UpdateModelsView()
        {
            _modelViews = _coreData.Models
                .Select(m => new ListViewModel { Key = m.Id, Value = m.ModelName })
                .ToList();
            List_Models.DataSource = null;
            List_Models.Items.Clear();
            List_Models.ValueMember = nameof(ListViewModel.Key);
            List_Models.DisplayMember = nameof(ListViewModel.Value);
            List_Models.DataSource = _modelViews;
            List_Models.Refresh();
        }

        private void Models_SelectionChanged()
        {
            if (List_Models.SelectedItem is ListViewModel model)
            {
                Model_Create.Enabled = true;
                Model_Edit.Enabled = true;
                Model_Delete.Enabled = true;

                var wss = _coreData.Workstations
                    .Where(ws => ws.ModelId == model.Key)
                    .Select(ws => new ListViewModel { Key = ws.Id, Value = ws.WorkstationName })
                    .ToList();
                List_Workstations.DataSource = null;
                List_Workstations.ValueMember = nameof(ListViewModel.Key);
                List_Workstations.DisplayMember = nameof(ListViewModel.Value);
                List_Workstations.DataSource = wss;
                List_Workstations.Refresh();
            }
            else
            {
                Model_Create.Enabled = false;
                Model_Edit.Enabled = false;
                Model_Delete.Enabled = false;
            }
        }

        private void List_Models_SelectedIndexChanged(object sender, EventArgs e)
        {
            Models_SelectionChanged();
        }

        private async void Model_Create_Click(object sender, EventArgs e)
        {
            string title = "請輸入新機種名稱";
            string caption = "新機種名稱";
            var validor = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "機種名稱不可為空白！"),
                input => input.Length <= 10 ? (true, "") : (false, "機種名稱必須小於等於 10 個字元！"),
                input => _coreData.Models.Any(m => m.ModelName == input) ? (false, "機種名稱已存在！") : (true, "")
                );

            _crud.OneTextBox("", caption, title, caption, validor);
            if (_crud.ShowDialog() == DialogResult.OK)
            {
                string newModelName = _crud.ResultString;

                _context.Models.Add(new Model() { ModelName = newModelName });
                await _context.SaveChangesAsync();
                await _core.UpdateCoreDataFromDb();
                UpdateModelsView();
                List_Models.SelectedIndex = _modelViews.FindIndex(m => m.Value == newModelName);

                MessageBox.Show($"已增加新機種: {newModelName}",
                                "新增成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private async void Model_Edit_Click(object sender, EventArgs e)
        {
            if (List_Models.SelectedItem is ListViewModel model)
            {
                string title = "請輸入新機種名稱";
                string oldCaption = "原機種名稱";
                string newCaption = "新機種名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "機種名稱不可為空白！"),
                    input => input.Length <= 10 ? (true, "") : (false, "機種名稱必須小於等於 10 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, "機種名稱已存在！") : (true, "")
                    );

                _crud.TwoTextBox("", model.Value, newCaption, oldCaption, title, newCaption, validor);
                if (_crud.ShowDialog() == DialogResult.OK)
                {
                    string newModelName = _crud.ResultString;

                    var newModel = _context.Models.FirstOrDefault(m => m.ModelName == model.Value);
                    if (newModel != null)
                    {
                        newModel.ModelName = newModelName;
                        await _context.SaveChangesAsync();
                        await _core.UpdateCoreDataFromDb();
                        UpdateModelsView();
                        List_Models.SelectedIndex = _modelViews.FindIndex(m => m.Key == newModel.Id);

                        MessageBox.Show($"機種 {model.Value} 名稱已更新為 {newModelName}",
                                        "更新成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Model_Delete_Click(object sender, EventArgs e)
        {
            if (List_Models.SelectedItem is ListViewModel model)
            {
                if (UIMessageBox.ShowAsk2($"確定要刪除 {model.Value} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetModel = _context.Models.FirstOrDefault(m => m.ModelName == model.Value);
                    if (targetModel != null)
                    {
                        _context.Models.Remove(targetModel);
                        await _context.SaveChangesAsync();
                        await _core.UpdateCoreDataFromDb();
                        UpdateModelsView();

                        MessageBox.Show($"機種 {model.Value} 已刪除",
                                        "刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        /********************
         * Workstations
         ********************/
        private void Workstations_SelectionChanged()
        {
            if (List_Workstations.SelectedIndex >= 0)
            {
                WorkStation_Create.Enabled = true;
                WorkStation_Edit.Enabled = true;
                WorkStation_Delete.Enabled = true;
                WorkStation_Up.Enabled = true;
                WorkStation_Down.Enabled = true;
            }
            else
            {
                WorkStation_Create.Enabled = false;
                WorkStation_Edit.Enabled = false;
                WorkStation_Delete.Enabled = false;
                WorkStation_Up.Enabled = false;
                WorkStation_Down.Enabled = false;
            }
        }

        private void List_Workstations_SelectedIndexChanged(object sender, EventArgs e)
        {
            Workstations_SelectionChanged();
        }

        private async void Button_Refresh_Click(object sender, EventArgs e)
        {
            var selectedModel = List_Models.SelectedItem as ListViewModel;
            var selectedWorkstation = List_Workstations.SelectedItem as ListViewModel;

            await _core.UpdateCoreDataFromDb();
            UpdateModelsView();

            if (selectedModel != null)
                List_Models.SelectedIndex = _modelViews.FindIndex(m => m.Key == selectedModel.Key);

            var wss = _coreData.Workstations
                .Where(ws => ws.ModelId == selectedModel.Key)
                .Select(ws => new ListViewModel { Key = ws.Id, Value = ws.WorkstationName })
                .ToList();
            List_Workstations.DataSource = null;
            List_Workstations.ValueMember = nameof(ListViewModel.Key);
            List_Workstations.DisplayMember = nameof(ListViewModel.Value);
            List_Workstations.DataSource = wss;
            List_Workstations.Refresh();

            if (selectedWorkstation != null)
                List_Workstations.SelectedIndex = wss.FindIndex(ws => ws.Key == selectedWorkstation.Key);
        }
    }
}
