﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.Views
{
    public class FixIndexTabControl : TabControl
    {
        private const int TCM_SETCURSEL = 0x130C;

        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == TCM_SETCURSEL)
            {
                int oldIndex = this.SelectedIndex;
                base.WndProc(ref m);

                if (this.SelectedIndex != oldIndex)
                {
                    // 防止 TabControl 自動滾動
                    SendMessage(this.Handle, TCM_SETCURSEL, oldIndex, 0);
                    this.SelectedIndex = oldIndex;
                }
                return;
            }
            base.WndProc(ref m);
        }
    }
}