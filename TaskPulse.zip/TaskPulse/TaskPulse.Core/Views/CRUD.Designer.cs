﻿namespace Calin.TaskPulse.Core.Views
{
    partial class CRUD
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel_Controls = new System.Windows.Forms.TableLayoutPanel();
            this.LabelTemplate = new Sunny.UI.UILabel();
            this.TextBoxTemplate = new Sunny.UI.UITextBox();
            this.leftFLP = new System.Windows.Forms.FlowLayoutPanel();
            this.rightFLP = new System.Windows.Forms.FlowLayoutPanel();
            this.panel_Buttons = new System.Windows.Forms.Panel();
            this.uiButton_OK = new Sunny.UI.UISymbolButton();
            this.uiButton_Cancel = new Sunny.UI.UISymbolButton();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.tableLayoutPanel_Controls.SuspendLayout();
            this.panel_Buttons.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.AutoSize = true;
            this.tableLayoutPanel_Page.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel_Page.ColumnCount = 1;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.tableLayoutPanel_Controls, 0, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.panel_Buttons, 0, 2);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(15, 91);
            this.tableLayoutPanel_Page.Margin = new System.Windows.Forms.Padding(15, 15, 15, 5);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 3;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(360, 133);
            this.tableLayoutPanel_Page.TabIndex = 0;
            // 
            // tableLayoutPanel_Controls
            // 
            this.tableLayoutPanel_Controls.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel_Controls.AutoSize = true;
            this.tableLayoutPanel_Controls.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel_Controls.ColumnCount = 2;
            this.tableLayoutPanel_Controls.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel_Controls.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel_Controls.Controls.Add(this.LabelTemplate, 0, 1);
            this.tableLayoutPanel_Controls.Controls.Add(this.TextBoxTemplate, 1, 1);
            this.tableLayoutPanel_Controls.Controls.Add(this.leftFLP, 0, 0);
            this.tableLayoutPanel_Controls.Controls.Add(this.rightFLP, 1, 0);
            this.tableLayoutPanel_Controls.Location = new System.Drawing.Point(20, 25);
            this.tableLayoutPanel_Controls.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.tableLayoutPanel_Controls.Name = "tableLayoutPanel_Controls";
            this.tableLayoutPanel_Controls.RowCount = 2;
            this.tableLayoutPanel_Controls.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel_Controls.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel_Controls.Size = new System.Drawing.Size(320, 45);
            this.tableLayoutPanel_Controls.TabIndex = 0;
            // 
            // LabelTemplate
            // 
            this.LabelTemplate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelTemplate.AutoSize = true;
            this.LabelTemplate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.LabelTemplate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.LabelTemplate.Location = new System.Drawing.Point(3, 6);
            this.LabelTemplate.Margin = new System.Windows.Forms.Padding(3, 0, 3, 9);
            this.LabelTemplate.Name = "LabelTemplate";
            this.LabelTemplate.Size = new System.Drawing.Size(68, 19);
            this.LabelTemplate.TabIndex = 3;
            this.LabelTemplate.Text = "uiLabel1";
            this.LabelTemplate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LabelTemplate.Visible = false;
            // 
            // TextBoxTemplate
            // 
            this.TextBoxTemplate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxTemplate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.TextBoxTemplate.Location = new System.Drawing.Point(77, 6);
            this.TextBoxTemplate.Margin = new System.Windows.Forms.Padding(3, 0, 3, 9);
            this.TextBoxTemplate.MinimumSize = new System.Drawing.Size(1, 16);
            this.TextBoxTemplate.Name = "TextBoxTemplate";
            this.TextBoxTemplate.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.TextBoxTemplate.ShowText = false;
            this.TextBoxTemplate.Size = new System.Drawing.Size(240, 30);
            this.TextBoxTemplate.TabIndex = 999;
            this.TextBoxTemplate.TabStop = false;
            this.TextBoxTemplate.Text = "uiTextBox1";
            this.TextBoxTemplate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.TextBoxTemplate.Visible = false;
            this.TextBoxTemplate.Watermark = "";
            // 
            // leftFLP
            // 
            this.leftFLP.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.leftFLP.AutoSize = true;
            this.leftFLP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.leftFLP.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.leftFLP.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.leftFLP.Location = new System.Drawing.Point(71, 3);
            this.leftFLP.Margin = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.leftFLP.Name = "leftFLP";
            this.leftFLP.Size = new System.Drawing.Size(0, 0);
            this.leftFLP.TabIndex = 0;
            // 
            // rightFLP
            // 
            this.rightFLP.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.rightFLP.AutoSize = true;
            this.rightFLP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.rightFLP.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.rightFLP.Location = new System.Drawing.Point(77, 3);
            this.rightFLP.Name = "rightFLP";
            this.rightFLP.Size = new System.Drawing.Size(0, 0);
            this.rightFLP.TabIndex = 1;
            // 
            // panel_Buttons
            // 
            this.panel_Buttons.Controls.Add(this.uiButton_OK);
            this.panel_Buttons.Controls.Add(this.uiButton_Cancel);
            this.panel_Buttons.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_Buttons.Location = new System.Drawing.Point(82, 76);
            this.panel_Buttons.Name = "panel_Buttons";
            this.panel_Buttons.Size = new System.Drawing.Size(275, 54);
            this.panel_Buttons.TabIndex = 1;
            // 
            // uiButton_OK
            // 
            this.uiButton_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.uiButton_OK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_OK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_OK.Location = new System.Drawing.Point(18, 10);
            this.uiButton_OK.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_OK.Name = "uiButton_OK";
            this.uiButton_OK.Radius = 10;
            this.uiButton_OK.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiButton_OK.Size = new System.Drawing.Size(110, 35);
            this.uiButton_OK.TabIndex = 5;
            this.uiButton_OK.Text = "確定";
            this.uiButton_OK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_OK.Click += new System.EventHandler(this.uiButton_OK_Click);
            // 
            // uiButton_Cancel
            // 
            this.uiButton_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.uiButton_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.uiButton_Cancel.Location = new System.Drawing.Point(148, 10);
            this.uiButton_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Cancel.Name = "uiButton_Cancel";
            this.uiButton_Cancel.Radius = 10;
            this.uiButton_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiButton_Cancel.Size = new System.Drawing.Size(110, 35);
            this.uiButton_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton_Cancel.Symbol = 361453;
            this.uiButton_Cancel.TabIndex = 4;
            this.uiButton_Cancel.Text = "取消";
            this.uiButton_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Cancel.Click += new System.EventHandler(this.uiButton_Cancel_Click);
            // 
            // CRUD
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(390, 229);
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(380, 180);
            this.Name = "CRUD";
            this.Padding = new System.Windows.Forms.Padding(15, 30, 15, 5);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TitleHeight = 30;
            this.TopMost = true;
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 467, 317);
            this.Load += new System.EventHandler(this.CRUD_Load);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.tableLayoutPanel_Page.PerformLayout();
            this.tableLayoutPanel_Controls.ResumeLayout(false);
            this.tableLayoutPanel_Controls.PerformLayout();
            this.panel_Buttons.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Controls;
        private System.Windows.Forms.FlowLayoutPanel leftFLP;
        private System.Windows.Forms.FlowLayoutPanel rightFLP;
        private System.Windows.Forms.Panel panel_Buttons;
        private Sunny.UI.UISymbolButton uiButton_OK;
        private Sunny.UI.UISymbolButton uiButton_Cancel;
        private Sunny.UI.UILabel LabelTemplate;
        private Sunny.UI.UITextBox TextBoxTemplate;
    }
}
