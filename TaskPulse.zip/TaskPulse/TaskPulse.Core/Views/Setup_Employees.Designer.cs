﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Employees
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.TLP_Page = new System.Windows.Forms.TableLayoutPanel();
            this.adgv = new Zuby.ADGV.AdvancedDataGridView();
            this.Panel_Detail = new System.Windows.Forms.Panel();
            this.tclDetail = new Sunny.UI.UITabControl();
            this.TP_Employees = new System.Windows.Forms.TabPage();
            this.TP_Permission = new System.Windows.Forms.TabPage();
            this.TLP_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).BeginInit();
            this.Panel_Detail.SuspendLayout();
            this.tclDetail.SuspendLayout();
            this.SuspendLayout();
            // 
            // TLP_Page
            // 
            this.TLP_Page.ColumnCount = 1;
            this.TLP_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Page.Controls.Add(this.adgv, 0, 0);
            this.TLP_Page.Controls.Add(this.Panel_Detail, 0, 1);
            this.TLP_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP_Page.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.TLP_Page.Location = new System.Drawing.Point(0, 0);
            this.TLP_Page.Name = "TLP_Page";
            this.TLP_Page.RowCount = 2;
            this.TLP_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 230F));
            this.TLP_Page.Size = new System.Drawing.Size(904, 643);
            this.TLP_Page.TabIndex = 1;
            // 
            // adgv
            // 
            this.adgv.AllowUserToAddRows = false;
            this.adgv.AllowUserToDeleteRows = false;
            this.adgv.AllowUserToResizeRows = false;
            this.adgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.adgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adgv.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.adgv.FilterAndSortEnabled = true;
            this.adgv.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.Location = new System.Drawing.Point(3, 3);
            this.adgv.MaxFilterButtonImageHeight = 23;
            this.adgv.MultiSelect = false;
            this.adgv.Name = "adgv";
            this.adgv.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adgv.RowTemplate.Height = 24;
            this.adgv.Size = new System.Drawing.Size(898, 407);
            this.adgv.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.TabIndex = 11;
            this.adgv.SelectionChanged += new System.EventHandler(this.ADGV_SelectionChanged);
            // 
            // Panel_Detail
            // 
            this.Panel_Detail.BackColor = System.Drawing.Color.Transparent;
            this.Panel_Detail.Controls.Add(this.tclDetail);
            this.Panel_Detail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_Detail.Location = new System.Drawing.Point(3, 416);
            this.Panel_Detail.Name = "Panel_Detail";
            this.Panel_Detail.Size = new System.Drawing.Size(898, 224);
            this.Panel_Detail.TabIndex = 12;
            // 
            // tclDetail
            // 
            this.tclDetail.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tclDetail.Controls.Add(this.TP_Employees);
            this.tclDetail.Controls.Add(this.TP_Permission);
            this.tclDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tclDetail.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tclDetail.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tclDetail.ItemSize = new System.Drawing.Size(150, 27);
            this.tclDetail.Location = new System.Drawing.Point(0, 0);
            this.tclDetail.MainPage = "";
            this.tclDetail.Margin = new System.Windows.Forms.Padding(0);
            this.tclDetail.MenuStyle = Sunny.UI.UIMenuStyle.Custom;
            this.tclDetail.Name = "tclDetail";
            this.tclDetail.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tclDetail.SelectedIndex = 0;
            this.tclDetail.ShowTabDivider = false;
            this.tclDetail.Size = new System.Drawing.Size(898, 224);
            this.tclDetail.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tclDetail.TabBackColor = System.Drawing.Color.WhiteSmoke;
            this.tclDetail.TabIndex = 1;
            this.tclDetail.TabSelectedColor = System.Drawing.SystemColors.ActiveCaption;
            this.tclDetail.TabSelectedForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tclDetail.TabSelectedHighColor = System.Drawing.SystemColors.MenuHighlight;
            this.tclDetail.TabUnSelectedColor = System.Drawing.SystemColors.Menu;
            this.tclDetail.TabUnSelectedForeColor = System.Drawing.SystemColors.MenuText;
            this.tclDetail.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.tclDetail.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // TP_Employees
            // 
            this.TP_Employees.Location = new System.Drawing.Point(0, 0);
            this.TP_Employees.Name = "TP_Employees";
            this.TP_Employees.Size = new System.Drawing.Size(898, 197);
            this.TP_Employees.TabIndex = 0;
            this.TP_Employees.Text = "人員設定";
            this.TP_Employees.UseVisualStyleBackColor = true;
            // 
            // TP_Permission
            // 
            this.TP_Permission.Location = new System.Drawing.Point(0, 0);
            this.TP_Permission.Name = "TP_Permission";
            this.TP_Permission.Size = new System.Drawing.Size(200, 60);
            this.TP_Permission.TabIndex = 1;
            this.TP_Permission.Text = "權限設定";
            this.TP_Permission.UseVisualStyleBackColor = true;
            // 
            // Setup_Employees
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.TLP_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_Employees";
            this.Size = new System.Drawing.Size(904, 643);
            this.Load += new System.EventHandler(this.Setup_Employees_Load);
            this.TLP_Page.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).EndInit();
            this.Panel_Detail.ResumeLayout(false);
            this.tclDetail.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel TLP_Page;
        private Zuby.ADGV.AdvancedDataGridView adgv;
        private System.Windows.Forms.Panel Panel_Detail;
        private Sunny.UI.UITabControl tclDetail;
        private System.Windows.Forms.TabPage TP_Permission;
        private System.Windows.Forms.TabPage TP_Employees;
    }
}
