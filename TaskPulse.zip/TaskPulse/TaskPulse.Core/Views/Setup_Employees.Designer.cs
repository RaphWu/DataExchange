﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Employees
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.TLP_Page = new System.Windows.Forms.TableLayoutPanel();
            this.ADGV = new Zuby.ADGV.AdvancedDataGridView();
            this.Panel_Premission = new System.Windows.Forms.Panel();
            this.TLP_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ADGV)).BeginInit();
            this.SuspendLayout();
            // 
            // TLP_Page
            // 
            this.TLP_Page.ColumnCount = 1;
            this.TLP_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Page.Controls.Add(this.ADGV, 0, 0);
            this.TLP_Page.Controls.Add(this.Panel_Premission, 0, 1);
            this.TLP_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP_Page.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.TLP_Page.Location = new System.Drawing.Point(0, 0);
            this.TLP_Page.Name = "TLP_Page";
            this.TLP_Page.RowCount = 2;
            this.TLP_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 245F));
            this.TLP_Page.Size = new System.Drawing.Size(870, 711);
            this.TLP_Page.TabIndex = 1;
            // 
            // ADGV
            // 
            this.ADGV.AllowUserToAddRows = false;
            this.ADGV.AllowUserToDeleteRows = false;
            this.ADGV.AllowUserToResizeRows = false;
            this.ADGV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.ADGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ADGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ADGV.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ADGV.FilterAndSortEnabled = true;
            this.ADGV.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.ADGV.Location = new System.Drawing.Point(3, 3);
            this.ADGV.MaxFilterButtonImageHeight = 23;
            this.ADGV.MultiSelect = false;
            this.ADGV.Name = "ADGV";
            this.ADGV.ReadOnly = true;
            this.ADGV.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ADGV.RowTemplate.Height = 24;
            this.ADGV.Size = new System.Drawing.Size(864, 460);
            this.ADGV.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.ADGV.TabIndex = 11;
            // 
            // Panel_Premission
            // 
            this.Panel_Premission.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_Premission.Location = new System.Drawing.Point(3, 469);
            this.Panel_Premission.Name = "Panel_Premission";
            this.Panel_Premission.Size = new System.Drawing.Size(864, 239);
            this.Panel_Premission.TabIndex = 12;
            // 
            // Setup_Employees
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.TLP_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_Employees";
            this.Size = new System.Drawing.Size(870, 711);
            this.Load += new System.EventHandler(this.Setup_Employees_Load);
            this.TLP_Page.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ADGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel TLP_Page;
        private Zuby.ADGV.AdvancedDataGridView ADGV;
        private System.Windows.Forms.Panel Panel_Premission;
    }
}
