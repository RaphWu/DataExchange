﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Permission
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.FLP_System = new System.Windows.Forms.FlowLayoutPanel();
            this.uiCheckBox1 = new Sunny.UI.UICheckBox();
            this.Group_System = new Sunny.UI.UITitlePanel();
            this.uiTitlePanel1 = new Sunny.UI.UITitlePanel();
            this.FLP_MaintiFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.CB_Summy = new Sunny.UI.UICheckBox();
            this.uiLine3 = new Sunny.UI.UILine();
            this.CB_Create = new Sunny.UI.UICheckBox();
            this.CB_Cancel = new Sunny.UI.UICheckBox();
            this.uiLine1 = new Sunny.UI.UILine();
            this.CB_Accept = new Sunny.UI.UICheckBox();
            this.CB_Transfer = new Sunny.UI.UICheckBox();
            this.uiLine2 = new Sunny.UI.UILine();
            this.CB_Maniti = new Sunny.UI.UICheckBox();
            this.CB_Confirm = new Sunny.UI.UICheckBox();
            this.FLP_Page = new System.Windows.Forms.FlowLayoutPanel();
            this.uiCheckBox2 = new Sunny.UI.UICheckBox();
            this.uiCheckBox3 = new Sunny.UI.UICheckBox();
            this.uiCheckBox4 = new Sunny.UI.UICheckBox();
            this.uiCheckBox5 = new Sunny.UI.UICheckBox();
            this.uiCheckBox6 = new Sunny.UI.UICheckBox();
            this.uiLine4 = new Sunny.UI.UILine();
            this.uiLine5 = new Sunny.UI.UILine();
            this.FLP_System.SuspendLayout();
            this.Group_System.SuspendLayout();
            this.uiTitlePanel1.SuspendLayout();
            this.FLP_MaintiFlow.SuspendLayout();
            this.FLP_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // FLP_System
            // 
            this.FLP_System.Controls.Add(this.uiCheckBox1);
            this.FLP_System.Controls.Add(this.uiLine4);
            this.FLP_System.Controls.Add(this.uiCheckBox2);
            this.FLP_System.Controls.Add(this.uiCheckBox3);
            this.FLP_System.Controls.Add(this.uiCheckBox4);
            this.FLP_System.Controls.Add(this.uiCheckBox5);
            this.FLP_System.Controls.Add(this.uiLine5);
            this.FLP_System.Controls.Add(this.uiCheckBox6);
            this.FLP_System.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FLP_System.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.FLP_System.Location = new System.Drawing.Point(1, 35);
            this.FLP_System.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.FLP_System.Name = "FLP_System";
            this.FLP_System.Padding = new System.Windows.Forms.Padding(9);
            this.FLP_System.Size = new System.Drawing.Size(425, 314);
            this.FLP_System.TabIndex = 0;
            // 
            // uiCheckBox1
            // 
            this.uiCheckBox1.CheckBoxSize = 18;
            this.uiCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiCheckBox1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiCheckBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiCheckBox1.Location = new System.Drawing.Point(12, 12);
            this.uiCheckBox1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiCheckBox1.Name = "uiCheckBox1";
            this.uiCheckBox1.Size = new System.Drawing.Size(200, 29);
            this.uiCheckBox1.TabIndex = 0;
            this.uiCheckBox1.Text = "uiCheckBox1";
            this.uiCheckBox1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Group_System
            // 
            this.Group_System.Controls.Add(this.FLP_System);
            this.Group_System.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Group_System.Location = new System.Drawing.Point(261, 14);
            this.Group_System.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Group_System.MinimumSize = new System.Drawing.Size(1, 1);
            this.Group_System.Name = "Group_System";
            this.Group_System.Padding = new System.Windows.Forms.Padding(1, 35, 1, 1);
            this.Group_System.ShowText = false;
            this.Group_System.Size = new System.Drawing.Size(427, 350);
            this.Group_System.TabIndex = 3;
            this.Group_System.Text = "系統";
            this.Group_System.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiTitlePanel1
            // 
            this.uiTitlePanel1.Controls.Add(this.FLP_MaintiFlow);
            this.uiTitlePanel1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiTitlePanel1.Location = new System.Drawing.Point(13, 14);
            this.uiTitlePanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTitlePanel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiTitlePanel1.Name = "uiTitlePanel1";
            this.uiTitlePanel1.Padding = new System.Windows.Forms.Padding(1, 35, 1, 1);
            this.uiTitlePanel1.ShowText = false;
            this.uiTitlePanel1.Size = new System.Drawing.Size(240, 350);
            this.uiTitlePanel1.TabIndex = 4;
            this.uiTitlePanel1.Text = "維護工單";
            this.uiTitlePanel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FLP_MaintiFlow
            // 
            this.FLP_MaintiFlow.Controls.Add(this.CB_Summy);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine3);
            this.FLP_MaintiFlow.Controls.Add(this.CB_Create);
            this.FLP_MaintiFlow.Controls.Add(this.CB_Cancel);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine1);
            this.FLP_MaintiFlow.Controls.Add(this.CB_Accept);
            this.FLP_MaintiFlow.Controls.Add(this.CB_Transfer);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine2);
            this.FLP_MaintiFlow.Controls.Add(this.CB_Maniti);
            this.FLP_MaintiFlow.Controls.Add(this.CB_Confirm);
            this.FLP_MaintiFlow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FLP_MaintiFlow.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.FLP_MaintiFlow.Location = new System.Drawing.Point(1, 35);
            this.FLP_MaintiFlow.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.FLP_MaintiFlow.Name = "FLP_MaintiFlow";
            this.FLP_MaintiFlow.Padding = new System.Windows.Forms.Padding(9);
            this.FLP_MaintiFlow.Size = new System.Drawing.Size(238, 314);
            this.FLP_MaintiFlow.TabIndex = 0;
            // 
            // CB_Summy
            // 
            this.CB_Summy.CheckBoxSize = 18;
            this.CB_Summy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Summy.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CB_Summy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CB_Summy.Location = new System.Drawing.Point(12, 12);
            this.CB_Summy.MinimumSize = new System.Drawing.Size(1, 1);
            this.CB_Summy.Name = "CB_Summy";
            this.CB_Summy.Size = new System.Drawing.Size(200, 29);
            this.CB_Summy.TabIndex = 8;
            this.CB_Summy.Text = "CB_Summy";
            this.CB_Summy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine3
            // 
            this.uiLine3.BackColor = System.Drawing.Color.Transparent;
            this.uiLine3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine3.Location = new System.Drawing.Point(12, 47);
            this.uiLine3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine3.Name = "uiLine3";
            this.uiLine3.Size = new System.Drawing.Size(210, 8);
            this.uiLine3.TabIndex = 9;
            // 
            // CB_Create
            // 
            this.CB_Create.CheckBoxSize = 18;
            this.CB_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CB_Create.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CB_Create.Location = new System.Drawing.Point(12, 61);
            this.CB_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.CB_Create.Name = "CB_Create";
            this.CB_Create.Size = new System.Drawing.Size(200, 29);
            this.CB_Create.TabIndex = 0;
            this.CB_Create.Text = "CB_Create";
            this.CB_Create.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CB_Cancel
            // 
            this.CB_Cancel.CheckBoxSize = 18;
            this.CB_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CB_Cancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CB_Cancel.Location = new System.Drawing.Point(12, 96);
            this.CB_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.CB_Cancel.Name = "CB_Cancel";
            this.CB_Cancel.Size = new System.Drawing.Size(200, 29);
            this.CB_Cancel.TabIndex = 2;
            this.CB_Cancel.Text = "CB_Cancel";
            this.CB_Cancel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.Location = new System.Drawing.Point(12, 131);
            this.uiLine1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(210, 8);
            this.uiLine1.TabIndex = 4;
            // 
            // CB_Accept
            // 
            this.CB_Accept.CheckBoxSize = 18;
            this.CB_Accept.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Accept.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CB_Accept.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CB_Accept.Location = new System.Drawing.Point(12, 145);
            this.CB_Accept.MinimumSize = new System.Drawing.Size(1, 1);
            this.CB_Accept.Name = "CB_Accept";
            this.CB_Accept.Size = new System.Drawing.Size(200, 29);
            this.CB_Accept.TabIndex = 1;
            this.CB_Accept.Text = "CB_Accept";
            this.CB_Accept.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CB_Transfer
            // 
            this.CB_Transfer.CheckBoxSize = 18;
            this.CB_Transfer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Transfer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CB_Transfer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CB_Transfer.Location = new System.Drawing.Point(12, 180);
            this.CB_Transfer.MinimumSize = new System.Drawing.Size(1, 1);
            this.CB_Transfer.Name = "CB_Transfer";
            this.CB_Transfer.Size = new System.Drawing.Size(200, 29);
            this.CB_Transfer.TabIndex = 3;
            this.CB_Transfer.Text = "CB_Transfer";
            this.CB_Transfer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine2
            // 
            this.uiLine2.BackColor = System.Drawing.Color.Transparent;
            this.uiLine2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine2.Location = new System.Drawing.Point(12, 215);
            this.uiLine2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(210, 8);
            this.uiLine2.TabIndex = 5;
            // 
            // CB_Maniti
            // 
            this.CB_Maniti.CheckBoxSize = 18;
            this.CB_Maniti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Maniti.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CB_Maniti.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CB_Maniti.Location = new System.Drawing.Point(12, 229);
            this.CB_Maniti.MinimumSize = new System.Drawing.Size(1, 1);
            this.CB_Maniti.Name = "CB_Maniti";
            this.CB_Maniti.Size = new System.Drawing.Size(200, 29);
            this.CB_Maniti.TabIndex = 6;
            this.CB_Maniti.Text = "CB_Maniti";
            this.CB_Maniti.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CB_Confirm
            // 
            this.CB_Confirm.CheckBoxSize = 18;
            this.CB_Confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CB_Confirm.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CB_Confirm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CB_Confirm.Location = new System.Drawing.Point(12, 264);
            this.CB_Confirm.MinimumSize = new System.Drawing.Size(1, 1);
            this.CB_Confirm.Name = "CB_Confirm";
            this.CB_Confirm.Size = new System.Drawing.Size(200, 29);
            this.CB_Confirm.TabIndex = 7;
            this.CB_Confirm.Text = "CB_Confirm";
            this.CB_Confirm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FLP_Page
            // 
            this.FLP_Page.Controls.Add(this.uiTitlePanel1);
            this.FLP_Page.Controls.Add(this.Group_System);
            this.FLP_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FLP_Page.Location = new System.Drawing.Point(0, 0);
            this.FLP_Page.Name = "FLP_Page";
            this.FLP_Page.Padding = new System.Windows.Forms.Padding(9);
            this.FLP_Page.Size = new System.Drawing.Size(951, 677);
            this.FLP_Page.TabIndex = 5;
            // 
            // uiCheckBox2
            // 
            this.uiCheckBox2.CheckBoxSize = 18;
            this.uiCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiCheckBox2.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiCheckBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiCheckBox2.Location = new System.Drawing.Point(12, 61);
            this.uiCheckBox2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiCheckBox2.Name = "uiCheckBox2";
            this.uiCheckBox2.Size = new System.Drawing.Size(200, 29);
            this.uiCheckBox2.TabIndex = 11;
            this.uiCheckBox2.Text = "uiCheckBox2";
            this.uiCheckBox2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiCheckBox3
            // 
            this.uiCheckBox3.CheckBoxSize = 18;
            this.uiCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiCheckBox3.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiCheckBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiCheckBox3.Location = new System.Drawing.Point(12, 96);
            this.uiCheckBox3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiCheckBox3.Name = "uiCheckBox3";
            this.uiCheckBox3.Size = new System.Drawing.Size(200, 29);
            this.uiCheckBox3.TabIndex = 12;
            this.uiCheckBox3.Text = "uiCheckBox3";
            this.uiCheckBox3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiCheckBox4
            // 
            this.uiCheckBox4.CheckBoxSize = 18;
            this.uiCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FLP_System.SetFlowBreak(this.uiCheckBox4, true);
            this.uiCheckBox4.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiCheckBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiCheckBox4.Location = new System.Drawing.Point(12, 131);
            this.uiCheckBox4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiCheckBox4.Name = "uiCheckBox4";
            this.uiCheckBox4.Size = new System.Drawing.Size(200, 29);
            this.uiCheckBox4.TabIndex = 13;
            this.uiCheckBox4.Text = "uiCheckBox4";
            this.uiCheckBox4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiCheckBox5
            // 
            this.uiCheckBox5.CheckBoxSize = 18;
            this.uiCheckBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiCheckBox5.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiCheckBox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiCheckBox5.Location = new System.Drawing.Point(218, 12);
            this.uiCheckBox5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiCheckBox5.Name = "uiCheckBox5";
            this.uiCheckBox5.Size = new System.Drawing.Size(200, 29);
            this.uiCheckBox5.TabIndex = 14;
            this.uiCheckBox5.Text = "uiCheckBox5";
            this.uiCheckBox5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiCheckBox6
            // 
            this.uiCheckBox6.CheckBoxSize = 18;
            this.uiCheckBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiCheckBox6.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiCheckBox6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiCheckBox6.Location = new System.Drawing.Point(218, 61);
            this.uiCheckBox6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiCheckBox6.Name = "uiCheckBox6";
            this.uiCheckBox6.Size = new System.Drawing.Size(200, 29);
            this.uiCheckBox6.TabIndex = 16;
            this.uiCheckBox6.Text = "uiCheckBox6";
            this.uiCheckBox6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine4
            // 
            this.uiLine4.BackColor = System.Drawing.Color.Transparent;
            this.uiLine4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine4.Location = new System.Drawing.Point(12, 47);
            this.uiLine4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine4.Name = "uiLine4";
            this.uiLine4.Size = new System.Drawing.Size(195, 8);
            this.uiLine4.TabIndex = 17;
            // 
            // uiLine5
            // 
            this.uiLine5.BackColor = System.Drawing.Color.Transparent;
            this.uiLine5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine5.Location = new System.Drawing.Point(218, 47);
            this.uiLine5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine5.Name = "uiLine5";
            this.uiLine5.Size = new System.Drawing.Size(195, 8);
            this.uiLine5.TabIndex = 18;
            // 
            // Setup_Permission
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.FLP_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Setup_Permission";
            this.Size = new System.Drawing.Size(951, 677);
            this.FLP_System.ResumeLayout(false);
            this.Group_System.ResumeLayout(false);
            this.uiTitlePanel1.ResumeLayout(false);
            this.FLP_MaintiFlow.ResumeLayout(false);
            this.FLP_Page.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel FLP_System;
        private Sunny.UI.UICheckBox uiCheckBox1;
        private Sunny.UI.UITitlePanel Group_System;
        private Sunny.UI.UITitlePanel uiTitlePanel1;
        private System.Windows.Forms.FlowLayoutPanel FLP_MaintiFlow;
        private Sunny.UI.UICheckBox CB_Create;
        private Sunny.UI.UICheckBox CB_Accept;
        private Sunny.UI.UICheckBox CB_Cancel;
        private Sunny.UI.UICheckBox CB_Transfer;
        private Sunny.UI.UILine uiLine1;
        private Sunny.UI.UICheckBox CB_Summy;
        private Sunny.UI.UILine uiLine3;
        private Sunny.UI.UILine uiLine2;
        private Sunny.UI.UICheckBox CB_Maniti;
        private Sunny.UI.UICheckBox CB_Confirm;
        private System.Windows.Forms.FlowLayoutPanel FLP_Page;
        private Sunny.UI.UICheckBox uiCheckBox2;
        private Sunny.UI.UICheckBox uiCheckBox3;
        private Sunny.UI.UICheckBox uiCheckBox4;
        private Sunny.UI.UICheckBox uiCheckBox5;
        private Sunny.UI.UILine uiLine4;
        private Sunny.UI.UILine uiLine5;
        private Sunny.UI.UICheckBox uiCheckBox6;
    }
}
