﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_MachinesSummary
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.Machine_Create = new Sunny.UI.UISymbolButton();
            this.Machine_Edit = new Sunny.UI.UISymbolButton();
            this.Machine_Delete = new Sunny.UI.UISymbolButton();
            this.adgv = new Zuby.ADGV.AdvancedDataGridView();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 1;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel4, 0, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.adgv, 0, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 4;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 280F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1154, 675);
            this.tableLayoutPanel_Page.TabIndex = 0;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.Controls.Add(this.Machine_Create);
            this.flowLayoutPanel4.Controls.Add(this.Machine_Edit);
            this.flowLayoutPanel4.Controls.Add(this.Machine_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(505, 622);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 6;
            // 
            // Machine_Create
            // 
            this.Machine_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Create.Location = new System.Drawing.Point(9, 0);
            this.Machine_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Create.Name = "Machine_Create";
            this.Machine_Create.Size = new System.Drawing.Size(30, 30);
            this.Machine_Create.Symbol = 557669;
            this.Machine_Create.SymbolSize = 32;
            this.Machine_Create.TabIndex = 2;
            this.Machine_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Machine_Create.Click += new System.EventHandler(this.Machine_Create_Click);
            // 
            // Machine_Edit
            // 
            this.Machine_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Edit.Location = new System.Drawing.Point(57, 0);
            this.Machine_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Edit.Name = "Machine_Edit";
            this.Machine_Edit.Size = new System.Drawing.Size(30, 30);
            this.Machine_Edit.Symbol = 559205;
            this.Machine_Edit.SymbolSize = 32;
            this.Machine_Edit.TabIndex = 3;
            this.Machine_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Machine_Edit.Click += new System.EventHandler(this.Machine_Edit_Click);
            // 
            // Machine_Delete
            // 
            this.Machine_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Delete.Location = new System.Drawing.Point(105, 0);
            this.Machine_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Delete.Name = "Machine_Delete";
            this.Machine_Delete.Size = new System.Drawing.Size(30, 30);
            this.Machine_Delete.Symbol = 559506;
            this.Machine_Delete.SymbolSize = 26;
            this.Machine_Delete.TabIndex = 4;
            this.Machine_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Machine_Delete.Click += new System.EventHandler(this.Machine_Delete_Click);
            // 
            // adgv
            // 
            this.adgv.AllowUserToAddRows = false;
            this.adgv.AllowUserToDeleteRows = false;
            this.adgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adgv.FilterAndSortEnabled = true;
            this.adgv.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.Location = new System.Drawing.Point(3, 3);
            this.adgv.MaxFilterButtonImageHeight = 23;
            this.adgv.Name = "adgv";
            this.adgv.ReadOnly = true;
            this.adgv.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adgv.RowTemplate.Height = 24;
            this.adgv.Size = new System.Drawing.Size(1148, 329);
            this.adgv.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.TabIndex = 7;
            // 
            // Setup_MachinesSummary
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_MachinesSummary";
            this.Size = new System.Drawing.Size(1154, 675);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.tableLayoutPanel_Page.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton Machine_Create;
        private Sunny.UI.UISymbolButton Machine_Edit;
        private Sunny.UI.UISymbolButton Machine_Delete;
        private Zuby.ADGV.AdvancedDataGridView adgv;
    }
}
