﻿namespace Calin.TaskPulse.Core.Authority
{
    partial class UserLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kryptonLabel2 = new Krypton.Toolkit.KryptonLabel();
            this.kryptonLabel1 = new Krypton.Toolkit.KryptonLabel();
            this.maskedTextBox_Password = new Krypton.Toolkit.KryptonMaskedTextBox();
            this.button_ClearPassword = new Krypton.Toolkit.ButtonSpecAny();
            this.comboBox_UserNameList = new Krypton.Toolkit.KryptonComboBox();
            this.button_ClearUserName = new Krypton.Toolkit.ButtonSpecAny();
            this.button_OK = new Krypton.Toolkit.KryptonButton();
            this.button_Cancel = new Krypton.Toolkit.KryptonButton();
            ((System.ComponentModel.ISupportInitialize)(this.comboBox_UserNameList)).BeginInit();
            this.SuspendLayout();
            // 
            // kryptonLabel2
            // 
            this.kryptonLabel2.Location = new System.Drawing.Point(64, 66);
            this.kryptonLabel2.Name = "kryptonLabel2";
            this.kryptonLabel2.Size = new System.Drawing.Size(42, 24);
            this.kryptonLabel2.StateCommon.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kryptonLabel2.TabIndex = 18;
            this.kryptonLabel2.Values.Text = "密碼";
            // 
            // kryptonLabel1
            // 
            this.kryptonLabel1.Location = new System.Drawing.Point(48, 26);
            this.kryptonLabel1.Name = "kryptonLabel1";
            this.kryptonLabel1.Size = new System.Drawing.Size(58, 24);
            this.kryptonLabel1.StateCommon.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.kryptonLabel1.TabIndex = 17;
            this.kryptonLabel1.Values.Text = "使用者";
            // 
            // maskedTextBox_Password
            // 
            this.maskedTextBox_Password.AlwaysActive = false;
            this.maskedTextBox_Password.ButtonSpecs.Add(this.button_ClearPassword);
            this.maskedTextBox_Password.Location = new System.Drawing.Point(107, 65);
            this.maskedTextBox_Password.Margin = new System.Windows.Forms.Padding(15, 3, 3, 3);
            this.maskedTextBox_Password.Name = "maskedTextBox_Password";
            this.maskedTextBox_Password.PasswordChar = '●';
            this.maskedTextBox_Password.Size = new System.Drawing.Size(196, 27);
            this.maskedTextBox_Password.StateActive.Border.Color1 = System.Drawing.Color.Orange;
            this.maskedTextBox_Password.StateActive.Border.DrawBorders = ((Krypton.Toolkit.PaletteDrawBorders)((((Krypton.Toolkit.PaletteDrawBorders.Top | Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | Krypton.Toolkit.PaletteDrawBorders.Left) 
            | Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.maskedTextBox_Password.StateCommon.Content.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.maskedTextBox_Password.TabIndex = 2;
            // 
            // button_ClearPassword
            // 
            this.button_ClearPassword.Edge = Krypton.Toolkit.PaletteRelativeEdgeAlign.Near;
            this.button_ClearPassword.ToolTipTitle = "清除密碼";
            this.button_ClearPassword.Type = Krypton.Toolkit.PaletteButtonSpecStyle.Close;
            this.button_ClearPassword.UniqueName = "5db584c1616e4b1d83ca740ffb5d8228";
            this.button_ClearPassword.Click += new System.EventHandler(this.button_ClearPassword_Click);
            // 
            // comboBox_UserNameList
            // 
            this.comboBox_UserNameList.ButtonSpecs.Add(this.button_ClearUserName);
            this.comboBox_UserNameList.DropDownWidth = 212;
            this.comboBox_UserNameList.Location = new System.Drawing.Point(107, 26);
            this.comboBox_UserNameList.Margin = new System.Windows.Forms.Padding(15, 3, 3, 3);
            this.comboBox_UserNameList.Name = "comboBox_UserNameList";
            this.comboBox_UserNameList.Size = new System.Drawing.Size(212, 26);
            this.comboBox_UserNameList.StateCommon.ComboBox.Content.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_UserNameList.StateCommon.ComboBox.Content.Padding = new System.Windows.Forms.Padding(20, -1, -1, -1);
            this.comboBox_UserNameList.StateCommon.ComboBox.Content.TextH = Krypton.Toolkit.PaletteRelativeAlign.Near;
            this.comboBox_UserNameList.StateCommon.Item.Content.Padding = new System.Windows.Forms.Padding(30, -1, -1, -1);
            this.comboBox_UserNameList.TabIndex = 1;
            // 
            // button_ClearUserName
            // 
            this.button_ClearUserName.Edge = Krypton.Toolkit.PaletteRelativeEdgeAlign.Near;
            this.button_ClearUserName.Type = Krypton.Toolkit.PaletteButtonSpecStyle.Close;
            this.button_ClearUserName.UniqueName = "4097880c1b3d42688e5b804608b4f52e";
            this.button_ClearUserName.Click += new System.EventHandler(this.button_ClearUserName_Click);
            // 
            // button_OK
            // 
            this.button_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button_OK.Location = new System.Drawing.Point(64, 121);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(89, 40);
            this.button_OK.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_OK.TabIndex = 20;
            this.button_OK.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.button_OK.Values.Text = "登入";
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Location = new System.Drawing.Point(214, 121);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(89, 40);
            this.button_Cancel.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Cancel.TabIndex = 21;
            this.button_Cancel.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.button_Cancel.Values.Text = "取消";
            // 
            // UserLogin
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(393, 188);
            this.ControlBox = false;
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.button_OK);
            this.Controls.Add(this.comboBox_UserNameList);
            this.Controls.Add(this.kryptonLabel2);
            this.Controls.Add(this.kryptonLabel1);
            this.Controls.Add(this.maskedTextBox_Password);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UserLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "切換使用者";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.UserLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.comboBox_UserNameList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Krypton.Toolkit.KryptonLabel kryptonLabel2;
        private Krypton.Toolkit.KryptonLabel kryptonLabel1;
        private Krypton.Toolkit.KryptonMaskedTextBox maskedTextBox_Password;
        private Krypton.Toolkit.ButtonSpecAny button_ClearPassword;
        private Krypton.Toolkit.KryptonComboBox comboBox_UserNameList;
        private Krypton.Toolkit.KryptonButton button_OK;
        private Krypton.Toolkit.KryptonButton button_Cancel;
        private Krypton.Toolkit.ButtonSpecAny button_ClearUserName;
    }
}