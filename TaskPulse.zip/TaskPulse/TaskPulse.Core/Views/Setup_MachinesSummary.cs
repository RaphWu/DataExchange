﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachinesSummary : UIUserControl
    {
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly CoreData _coreData;
        private readonly FieldName _fieldName;

        private List<MachineViewModel> _machineViews;

        public Setup_MachinesSummary(CoreContext coreContext, ICore core, CoreData coreData, FieldName fieldName)
        {
            InitializeComponent();
            _context = coreContext;
            _core = core;
            _coreData = coreData;
            _fieldName = fieldName;

            Machine_Create.BackColor = CommonStyles.BackColor;
            Machine_Edit.BackColor = CommonStyles.BackColor;
            Machine_Delete.BackColor = CommonStyles.BackColor;

            adgv.AutoGenerateColumns = false;
            adgv.RowHeadersVisible = false;
            adgv.MultiSelect = false;
            adgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            adgv.AllowUserToResizeRows = false;
            adgv.AllowUserToAddRows = false;
            adgv.AllowUserToDeleteRows = false;
            adgv.AllowUserToOrderColumns = false;
            adgv.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            adgv.DefaultCellStyle.SelectionBackColor = CommonStyles.HoverColor;
            adgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            adgv.SetDoubleBuffered();

            //Machine_Create.FillColor = CommonStyles.BackColor;
            //Machine_Edit.FillColor = CommonStyles.BackColor;
            //Machine_Delete.FillColor = CommonStyles.BackColor;

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.MachineId),
                HeaderText = _fieldName.MachineId,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.MachineName),
                HeaderText = $"{_fieldName.MachineName} (分類 » 名稱)",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Status),
                HeaderText = _fieldName.Condition,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Brand),
                HeaderText = _fieldName.Brand,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Location),
                HeaderText = _fieldName.Location,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Assets),
                HeaderText = _fieldName.Assets,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.SerialNumber),
                HeaderText = _fieldName.SerialNumber,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Barcode),
                HeaderText = _fieldName.Barcode,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Connected),
                HeaderText = _fieldName.Connected,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Disposal),
                HeaderText = _fieldName.Disposal,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Remark),
                HeaderText = _fieldName.Remark,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Worktations),
                HeaderText = _fieldName.Worktations,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            UpdateMachinesView();
        }

        /********************
         * View
         ********************/
        private void UpdateMachinesView()
        {
            _machineViews = _coreData.Machines
                .Select(m => new MachineViewModel
                {
                    MachineId = m.MachineId,
                    MachineName = m.MachineName.FullName,
                    Status = m.Condition.Condition,
                    Brand = m.Brand.BrandName,
                    Location = m.Location.Location,
                    Assets = string.Join("\n", m.Assets.Select(s => s.AssetCode)),
                    SerialNumber = m.SerialNumber,
                    Barcode = m.Barcode,
                    Connected = m.Connected ? "可連線" : "",
                    Disposal = m.Disposal ? "已處置" : "",
                    Remark = m.Remark,
                    Worktations = string.Join("\n", m.Worktations.Select(w => w.FullWorkstationName)),
                })
                .ToList();

            adgv.DataSource = null;
            adgv.DataSource = _machineViews.ToDataTable();
        }

        private void dgv_Machines_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            e.CellStyle.Font = CommonStyles.Font;
        }

        private void Machine_Create_Click(object sender, System.EventArgs e)
        {

        }

        private void Machine_Edit_Click(object sender, System.EventArgs e)
        {

        }

        private void Machine_Delete_Click(object sender, System.EventArgs e)
        {

        }
    }
}
