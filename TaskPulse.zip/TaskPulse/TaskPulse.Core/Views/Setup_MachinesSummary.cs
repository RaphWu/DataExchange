﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;
using static Sunny.UI.UIMeter;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachinesSummary : UIUserControl
    {
        #region fields

        private readonly ILifetimeScope _scope;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly CoreData _coreData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private List<Machine> _machines;
        private int _typeId = 0;
        private List<MachineViewModel> _mdgv;
        private readonly BindingSource _bs = new BindingSource();
        private string thisMachineId = "";

        #endregion fields

        public Setup_MachinesSummary(ILifetimeScope lifetimeScope,
                                     CoreContext coreContext,
                                     ICore core,
                                     CoreData coreData,
                                     FieldName fieldName,
                                     FieldTitle fieldTitle)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _coreData = coreData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            adgv.SetDoubleBuffered();
            adgv.AutoGenerateColumns = false;
            adgv.RowHeadersVisible = false;
            adgv.MultiSelect = false;
            adgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            adgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            adgv.AllowUserToResizeRows = false;
            adgv.AllowUserToAddRows = false;
            adgv.AllowUserToDeleteRows = false;
            adgv.AllowUserToOrderColumns = false;
            adgv.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            adgv.DefaultCellStyle.SelectionBackColor = CommonStyles.HoverColor;
            adgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            adgv.FilterAndSortEnabled = false;

            string itemName = _fieldTitle.Machine;
            headLabel_Machine.Text = $"{_fieldTitle.MachineCategory} » {_fieldTitle.MachineType}";
            CommonStyles.SetCrudButton(Machine_Create, "C", itemName);
            CommonStyles.SetCrudButton(Machine_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Machine_Delete, "D", itemName);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.MachineId),
                HeaderText = _fieldTitle.MachineId,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Status),
                HeaderText = _fieldTitle.Condition,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Brand),
                HeaderText = _fieldTitle.Brand,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Location),
                HeaderText = _fieldTitle.Location,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.AssetList),
                HeaderText = _fieldTitle.Assets,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    WrapMode = DataGridViewTriState.True,
                    //Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.SerialNumber),
                HeaderText = _fieldTitle.SerialNumber,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.ConnectedString),
                HeaderText = _fieldTitle.Connected,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.DisposalString),
                HeaderText = _fieldTitle.Disposal,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Worktations),
                HeaderText = _fieldTitle.Worktations,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                _mdgv = null;
                StrongReferenceMessenger.Default.Send(new DbInfoMessage(""));
            }
            base.Dispose(disposing);
        }

        private async void Setup_MachinesSummary_Load(object sender, System.EventArgs e)
        {
            await UpdateMachinesList();
            _bs.DataSource = new MachineViewModel();

            label_MachineId.Text = _fieldTitle.MachineId;
            MaincheId.DataBindings.Clear();
            MaincheId.DataBindings.Add("Text", _bs, _fieldName.MachineId);

            label_Catelogry.Text = _fieldTitle.MachineCategory;
            Catelogry.DataBindings.Clear();
            Catelogry.DataBindings.Add("Text", _bs, _fieldName.MachineCategory);

            label_Type.Text = _fieldTitle.MachineType;
            Type.DataBindings.Clear();
            Type.DataBindings.Add("Text", _bs, _fieldName.MachineType);

            label_Condition.Text = _fieldTitle.Condition;
            Condition.DataBindings.Clear();
            Condition.DataBindings.Add("Text", _bs, _fieldName.Condition);

            label_Brand.Text = _fieldTitle.Brand;
            Brand.DataBindings.Clear();
            Brand.DataBindings.Add("Text", _bs, _fieldName.Brand);

            label_Location.Text = _fieldTitle.Location;
            Location.DataBindings.Clear();
            Location.DataBindings.Add("Text", _bs, _fieldName.Location);

            label_Assets.Text = _fieldTitle.Assets;
            Assets.DataBindings.Clear();
            Assets.DataBindings.Add("Text", _bs, _fieldName.AssetList);

            label_SerialNumber.Text = _fieldTitle.SerialNumber;
            SerialNumber.DataBindings.Clear();
            SerialNumber.DataBindings.Add("Text", _bs, _fieldName.SerialNumber);

            label_Barcode.Text = _fieldTitle.Barcode;
            Barcode.DataBindings.Clear();
            Barcode.DataBindings.Add("Text", _bs, _fieldName.Barcode);

            label_Connected.Text = _fieldTitle.Connected;
            Connected.DataBindings.Clear();
            Connected.DataBindings.Add("Text", _bs, _fieldName.ConnectedString);

            label_Disposal.Text = _fieldTitle.Disposal;
            Disposal.DataBindings.Clear();
            Disposal.DataBindings.Add("Text", _bs, _fieldName.DisposalString);

            label_Remark.Text = _fieldTitle.Remark;
            Remark.DataBindings.Clear();
            Remark.DataBindings.Add("Text", _bs, _fieldName.Remark);
        }

        /********************
         * View
         ********************/
        private async Task UpdateMachinesList()
        {
            var mQuery = await _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.MachineName.MachineType)
                .Include(m => m.MachineName.MachineType.Category)
                .Include(m => m.Brand)
                .Include(m => m.Assets)
                .Include(m => m.Location)
                .Include(m => m.Condition)
                .AsNoTracking()
                .ToListAsync();
            _machines = _core.SortMachines(mQuery).ToList();

            list_Catelogries.SelectedColor = CommonStyles.BackColor;
            TreeNode topNode = null;
            TreeNode parent;
            TreeNode child;

            foreach (var mCat in _context.MachineCategories)
            {
                parent = new TreeNode(mCat.CategoryName);
                parent.Tag = -1;
                list_Catelogries.Nodes.Add(parent);

                var tQuery = await _context.MachineTypes
                    .Where(m => m.CategoryId == mCat.Id)
                    .OrderBy(b => b.OrderNo)
                    .AsNoTracking()
                    .ToListAsync();
                var mTypes = tQuery
                    .Select(b => new ListViewModel { Id = b.Id, Name = b.TypeName })
                    .ToList();

                foreach (var mType in mTypes)
                {
                    child = new TreeNode(mType.Name);
                    child.Tag = mType.Id;
                    parent.Nodes.Add(child);

                    if (topNode == null)
                        topNode = child;
                }
            }

            list_Catelogries.ExpandAll();
            list_Catelogries.SelectedNode = topNode;
            topNode.EnsureVisible();
        }

        private void list_Catelogries_AfterSelect(object sender, TreeViewEventArgs e)
        {
            _typeId = (int)e.Node.Tag;
            if (_typeId > 0)
            {
                Machine_Create.Enabled = true;
            }
            else
            {
                Machine_Create.Enabled = false;
                Machine_Edit.Enabled = false;
                Machine_Delete.Enabled = false;
            }
            UpdateMachinesView();
        }

        private void UpdateMachinesView()
        {
            adgv.DataSource = null;
            if (_typeId > 0)
            {
                _mdgv = _machines
                    .Where(m => m.MachineName.TypeId == _typeId)
                    .Select(m => new MachineViewModel
                    {
                        MachineId = m.MachineId,
                        CategoryName = m.CategoryName,
                        TypeName = m.TypeName,
                        MachineName = m.MachineName.FullName,
                        Status = m.Condition.Condition,
                        Condition = m.ConditionString,
                        Brand = m.Brand.BrandName,
                        Location = m.Location.Location,
                        Assets = m.Assets,
                        AssetString = m.AssetString,
                        AssetList = m.AssetList,
                        SerialNumber = m.SerialNumber,
                        Barcode = m.Barcode,
                        Connected = m.Connected,
                        ConnectedString = m.ConnectedString,
                        Disposal = m.Disposal,
                        DisposalString = m.DisposalString,
                        Remark = m.Remark,
                        Worktations = string.Join("\n", m.Worktations.Select(w => w.FullWorkstationName)),
                    })
                    .ToList();

                adgv.DataSource = _mdgv.ToDataTable();
                _bs.DataSource = _mdgv;
                StrongReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_mdgv.Count()} 筆資料"));
            }
            else
            {
                _mdgv = null;
                _bs.DataSource = new List<MachineViewModel>();
                StrongReferenceMessenger.Default.Send(new DbInfoMessage($"沒有資料顯示"));
            }
        }

        private void adgv_SelectionChanged(object sender, System.EventArgs e)
        {
            if (adgv.CurrentRow?.DataBoundItem is DataRowView drv && _mdgv != null)
            {
                thisMachineId = drv[_fieldName.MachineId].ToString();
                int index = _mdgv.FindIndex(x => x.MachineId == thisMachineId);
                if (_typeId > 0 && index >= 0)
                {
                    _bs.Position = index;
                    Machine_Edit.Enabled = true;
                    Machine_Delete.Enabled = true;
                    return;
                }
            }
            Machine_Edit.Enabled = false;
            Machine_Delete.Enabled = false;
            _bs.Position = -1;
        }

        private async void Machine_Create_Click(object sender, System.EventArgs e)
        {
            string title = $"請輸入新{_fieldTitle.Machine}編號";
            string caption = $"新{_fieldTitle.Machine}編號";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.Machine}編號不可為空白！"),
                input => input.Length <= 10 ? (true, "") : (false, $"{_fieldTitle.Machine}編號必須小於等於 10 個字元！"),
                input => _machines.Any(m => m.CategoryName == input) ? (false, $"{_fieldTitle.Machine}編號已存在！") : (true, "")
                );
            string[] aNo = thisMachineId.Split('-');
            int maxNo = _mdgv
                .Select(s =>
                {
                    if (string.IsNullOrEmpty(s.MachineId)) return 0;
                    var match = Regex.Match(s.MachineId, @"\d+"); // 找出第一串數字
                    return match.Success ? int.Parse(match.Value) : 0;
                })
                .DefaultIfEmpty(0)
                .Max();
            string defaultId = string.Concat(aNo[0], '-', (maxNo + 1).ToString());

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.OneTextBox(defaultId, caption, title, caption, validator);
                if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newMachineId = crud.ResultString;
                    _context.Machines.Add(new Machine()
                    {
                        MachineId = newMachineId,
                        ConditionId = 1,
                    });
                    await _context.SaveChangesAsync();
                    StrongReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Machine));
                    MessageBox.Show($"已增加新{_fieldTitle.Machine}: {newMachineId}",
                                    $"新增成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                    await UpdateMachinesList();
                }
            }
        }

        private void Machine_Edit_Click(object sender, System.EventArgs e)
        {
            using (var dlg = _scope.Resolve<MachineEdit>())
            {
                dlg.MachineId = thisMachineId;
                dlg.ShowDialog();
            }
        }

        private void Machine_Delete_Click(object sender, System.EventArgs e)
        {

        }
    }
}
