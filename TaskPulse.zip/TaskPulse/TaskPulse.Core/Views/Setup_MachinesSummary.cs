﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachinesSummary : UIUserControl
    {
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly CoreData _coreData;
        private readonly FieldTitle _fieldTitle;

        private List<Machine> _machines;
        private int _typeId = 0;
        private List<MachineViewModel> _mdgv;

        public Setup_MachinesSummary(CoreContext coreContext, ICore core, CoreData coreData, FieldTitle fieldTitle)
        {
            InitializeComponent();
            _context = coreContext;
            _core = core;
            _coreData = coreData;
            _fieldTitle = fieldTitle;

            adgv.SetDoubleBuffered();
            adgv.AutoGenerateColumns = false;
            adgv.RowHeadersVisible = false;
            adgv.MultiSelect = false;
            adgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            adgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            adgv.AllowUserToResizeRows = false;
            adgv.AllowUserToAddRows = false;
            adgv.AllowUserToDeleteRows = false;
            adgv.AllowUserToOrderColumns = false;
            adgv.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            adgv.DefaultCellStyle.SelectionBackColor = CommonStyles.HoverColor;
            adgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            adgv.FilterAndSortEnabled = false;

            string itemName = _fieldTitle.Machine;
            headLabel_Machine.Text = $"{_fieldTitle.MachineCategory} » {_fieldTitle.MachineType}";
            CommonStyles.SetCrudButton(Machine_Create, "C", itemName);
            CommonStyles.SetCrudButton(Machine_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Machine_Delete, "D", itemName);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.MachineId),
                HeaderText = _fieldTitle.MachineId,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Status),
                HeaderText = _fieldTitle.Condition,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Brand),
                HeaderText = _fieldTitle.Brand,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Location),
                HeaderText = _fieldTitle.Location,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.AssetList),
                HeaderText = _fieldTitle.Assets,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    WrapMode = DataGridViewTriState.True,
                    //Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.SerialNumber),
                HeaderText = _fieldTitle.SerialNumber,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Barcode),
                HeaderText = _fieldTitle.Barcode,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.ConnectedString),
                HeaderText = _fieldTitle.Connected,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.DisposalString),
                HeaderText = _fieldTitle.Disposal,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Remark),
                HeaderText = _fieldTitle.Remark,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.Worktations),
                HeaderText = _fieldTitle.Worktations,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });
        }

        private async void Setup_MachinesSummary_Load(object sender, System.EventArgs e)
        {
            await UpdateMachinesList();
        }

        /********************
         * View
         ********************/
        private async Task UpdateMachinesList()
        {
            var mQuery = await _context.Machines
                .Include(m => m.MachineName.MachineType.Category)
                .Include(m => m.Brand)
                .Include(m => m.Assets)
                .Include(m => m.Location)
                .Include(m => m.Condition)
                .AsNoTracking()
                .ToListAsync();
            _machines = _core.SortMachines(mQuery).ToList();

            list_Catelogries.SelectedColor = CommonStyles.BackColor;
            TreeNode parent;
            TreeNode child;

            foreach (var mCat in _context.MachineCategories)
            {
                parent = new TreeNode(mCat.CategoryName);
                parent.Tag = mCat.Id;
                list_Catelogries.Nodes.Add(parent);

                var tQuery = await _context.MachineTypes
                    .Where(m => m.CategoryId == mCat.Id)
                    .OrderBy(b => b.OrderNo)
                    .AsNoTracking()
                    .ToListAsync();
                var mTypes = tQuery
                    .Select(b => new ListViewModel { Id = b.Id, Name = b.TypeName })
                    .ToList();

                foreach (var mType in mTypes)
                {
                    child = new TreeNode(mType.Name);
                    child.Tag = mType.Id;
                    parent.Nodes.Add(child);
                }
            }
            list_Catelogries.ExpandAll();
        }

        private void list_Catelogries_AfterSelect(object sender, TreeViewEventArgs e)
        {
            _typeId = (int)e.Node.Tag;
            if (_typeId > 0)
            {
                Machine_Edit.Enabled = true;
                Machine_Delete.Enabled = true;
                UpdateMachinesView();
            }
            else
            {
                Machine_Edit.Enabled = false;
                Machine_Delete.Enabled = false;
            }
        }

        private void UpdateMachinesView()
        {
            adgv.DataSource = null;
            if (_typeId > 0)
            {
                _mdgv = _machines
                    .Where(m => m.MachineName.TypeId == _typeId)
                    .Select(m => new MachineViewModel
                    {
                        MachineId = m.MachineId,
                        MachineName = m.MachineName.FullName,
                        Status = m.Condition.Condition,
                        Brand = m.Brand.BrandName,
                        Location = m.Location.Location,
                        Assets = m.Assets,
                        AssetString = m.AssetString,
                        AssetList = m.AssetList,
                        SerialNumber = m.SerialNumber,
                        Barcode = m.Barcode,
                        Connected = m.Connected,
                        ConnectedString = m.ConnectedString,
                        Disposal = m.Disposal,
                        DisposalString = m.DisposalString,
                        Remark = m.Remark,
                        Worktations = string.Join("\n", m.Worktations.Select(w => w.FullWorkstationName)),
                    })
                    .ToList();

                adgv.DataSource = _mdgv.ToDataTable();
            }
            else
            {
                _mdgv = null;
            }
        }

        private void Machine_Create_Click(object sender, System.EventArgs e)
        {

        }

        private void Machine_Edit_Click(object sender, System.EventArgs e)
        {

        }

        private void Machine_Delete_Click(object sender, System.EventArgs e)
        {

        }
    }
}
