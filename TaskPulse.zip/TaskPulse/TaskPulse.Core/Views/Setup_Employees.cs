﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavContracts;
using Calin.TaskPulse.Core.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Employees : UserControl
    {
        #region fields

        private readonly IRegionManager _region;
        private readonly INavigationService _navigation;
        private readonly CoreContext _context;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private List<EmployeeViewModel> _vmEmps = null;
        private DataTable _dt;
        private DataGridViewComboBoxColumn dgvComboBox;

        #endregion fields

        public Setup_Employees(IRegionManager regionManager,
                               INavigationService navigationService,
                               CoreContext coreContext,
                               FieldName fieldName,
                               FieldTitle fieldTitle)
        {
            InitializeComponent();
            _region = regionManager;
            _navigation = navigationService;
            _context = coreContext;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            _region.RegisterRegion(nameof(TP_Employees), TP_Employees);
            _region.RegisterRegion(nameof(TP_Permission), TP_Permission);

            _dt = new DataTable();
            _dt.Columns.Add(_fieldName.EmployeeId, typeof(string));
            _dt.Columns.Add(_fieldName.Department, typeof(string));
            _dt.Columns.Add(_fieldName.Title, typeof(string));
            _dt.Columns.Add(_fieldName.EmployeeName, typeof(string));
            _dt.Columns.Add(_fieldName.Email, typeof(string));
            _dt.Columns.Add(_fieldName.IsEngineer, typeof(bool));
            _dt.Columns.Add(_fieldName.OnStaff, typeof(bool));

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.EmployeeId,
                DataPropertyName = nameof(EmployeeViewModel.Id),
                HeaderText = _fieldTitle.EmployeeId,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            dgvComboBox = new DataGridViewComboBoxColumn()
            {
                DataPropertyName = nameof(EmployeeViewModel.DepartmentId),
                HeaderText = _fieldTitle.Department,
                ValueType = typeof(string),
            };
            //dgvComboBox.Items.Add("");
            //dgvComboBox.Items.AddRange(_context.Departments.Select(d => d.DepartmentName).ToList());
            dgvComboBox.DataSource = _context.Departments
                .Select(d => new ListViewModel() { Id = d.Id, Name = d.DepartmentName })
                .ToList();
            dgvComboBox.DisplayMember = "Name";
            dgvComboBox.ValueMember = "Id";
            dgvComboBox.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
            dgvComboBox.DisplayStyleForCurrentCellOnly = true;
            adgv.Columns.Add(dgvComboBox);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.Name),
                HeaderText = _fieldTitle.EmployeeName,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.Email),
                HeaderText = _fieldTitle.Email,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.IsEngineer),
                HeaderText = _fieldTitle.IsEngineer,
                ValueType = typeof(bool),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.OnStaff),
                HeaderText = _fieldTitle.OnStaff,
                ValueType = typeof(bool),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            CommonStyles.SetAdvancedDataGridView(adgv, true);
        }

        private async void Setup_Employees_Load(object sender, EventArgs e)
        {
            await UpdateEmployeesView();

            _navigation.Navigate<Setup_Permission>(nameof(TP_Permission));

            //_core.CleanUpControls(TP_Permission.Controls);
            //TP_Permission.Controls.Add(_permission);
            //WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
            //new PermissionSettingInfo()
            //    {
            //        PermissionSource = PermissionSource.Employee,
            //        EmployeeId = "",
            //    }));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            }
            base.Dispose(disposing);
        }

        private async Task UpdateEmployeesView()
        {
            var query = await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Title)
                .AsNoTracking()
                .ToListAsync();
            _vmEmps = query.Select(e => new EmployeeViewModel
            {
                Id = e.EmployeeId,
                Name = e.EmployeeName,
                DepartmentId = (int)e.DepartmentId,
                Department = e.Department?.DepartmentName ?? string.Empty,
                Title = e.Title?.TitleName ?? string.Empty,
                Email = e.Email,
                IsEngineer = e.IsEngineerYes,
                OnStaff = e.OnStaffString,
            }).ToList();

            adgv.AutoGenerateColumns = false;
            _dt = _vmEmps.ToDataTable();
            adgv.DataSource = _dt;
            WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_vmEmps.Count()} 筆資料"));
        }

        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewRow row = adgv.CurrentRow;
            if (row != null)
            {
                string employeeId = row.Cells[_fieldName.EmployeeId].Value.ToString();
                WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                    new PermissionSettingInfo()
                    {
                        PermissionSource = PermissionSource.Employee,
                        EmployeeId = employeeId,
                    }));
            }
        }
    }
}
