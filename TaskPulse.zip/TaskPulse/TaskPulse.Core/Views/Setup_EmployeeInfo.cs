﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavContracts;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_EmployeeInfo : UserControl
    {
        #region fields

        private readonly IRegionManager _region;
        private readonly INavigationService _navigation;
        private readonly CoreContext _context;
        private readonly FieldTitle _fieldTitle;

        private readonly DbSet<Department> _departments;
        private readonly DbSet<Title> _titles;

        private List<ListViewModel> _vmDepartments = null;
        private ListViewModel _vmDep = null;
        private List<ListViewModel> _vmTitles = null;
        private ListViewModel _vmTitle = null;

        #endregion fields

        public Setup_EmployeeInfo(IRegionManager regionManager,
                                  INavigationService navigationService,
                                  CoreContext coreContext,
                                  FieldTitle fieldTitle)
        {
            InitializeComponent();
            _region = regionManager;
            _navigation = navigationService;
            _context = coreContext;
            _fieldTitle = fieldTitle;

            _region.RegisterRegion(nameof(Panel_Permission), Panel_Permission);
            _navigation.Navigate<Setup_Permission>(nameof(Panel_Permission));

            _departments = _context.Departments;
            _titles = _context.Titles;

            string itemName = _fieldTitle.Department;
            Label_Department.Text = itemName;
            CommonStyles.SetListBox(LB_Departments);
            CommonStyles.SetCrudButton(Department_Create, "C", itemName);
            CommonStyles.SetCrudButton(Department_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Department_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Department_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Department_Down, "DOWN", itemName);

            itemName = _fieldTitle.Title;
            Label_Title.Text = itemName;
            CommonStyles.SetListBox(LB_Titles);
            CommonStyles.SetCrudButton(Title_Create, "C", itemName);
            CommonStyles.SetCrudButton(Title_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Title_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Title_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Title_Down, "DOWN", itemName);
        }

        private async void EmployeeInfo_Load(object sender, EventArgs e)
        {
            await UpdateDepartmentView();
            await UpdateTitleView();

            //_core.CleanUpControls(Panel_Permission.Controls);
            //Panel_Permission.Controls.Add(_permission);
            //WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
            //    new PermissionSettingInfo()
            //    {
            //        PermissionSource = PermissionSource.Employee,
            //    }));
        }

        /********************
         * Department
         ********************/
        private async Task UpdateDepartmentView()
        {
            _vmDepartments = await _departments
                .Select(d => new ListViewModel()
                {
                    Id = d.Id,
                    Name = d.DepartmentName,
                })
                .ToListAsync();

            LB_Departments.DisplayMember = nameof(ListViewModel.Name);
            LB_Departments.ValueMember = nameof(ListViewModel.Id);
            LB_Departments.DataSource = _vmDepartments;
        }





        /********************
         * Title
         ********************/
        private async Task UpdateTitleView()
        {
            _vmTitles = await _titles
                .Select(d => new ListViewModel()
                {
                    Id = d.Id,
                    Name = d.TitleName,
                })
                .ToListAsync();

            LB_Titles.DisplayMember = nameof(ListViewModel.Name);
            LB_Titles.ValueMember = nameof(ListViewModel.Id);
            LB_Titles.DataSource = _vmTitles;
        }

        private void LB_Departments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LB_Departments.SelectedItem is ListViewModel select)
            {
                WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                    new PermissionSettingInfo()
                    {
                        PermissionSource = PermissionSource.Department,
                        DepartmentId = select.Id,
                    }));
            }
        }
    }
}
