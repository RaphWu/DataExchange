﻿using System.Collections.Generic;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Authority;
using Krypton.Toolkit;

namespace Calin.TaskPulse.Core.Views
{
    public partial class AuthorityManager : KryptonForm
    {
        public IAuthority Authority { get; set; } // 自動屬性注入
        private readonly AuthorityData _ad = AuthorityData.Instance;
        private BindingSource _bs = new BindingSource();

        public AuthorityManager()
        {
            InitializeComponent();

            _bs.DataSource = _ad;
        }

        private void AuthorityManager_Load(object sender, System.EventArgs e)
        {

        }

        /********************
         * Database
         ********************/
        /// <summary>
        /// 讀入系統設定值。
        /// </summary>
        private void LoadSysData()
        {
            InputDetectInterval = _ad.Params.InputDetectInterval;
        }

        /// <summary>
        /// 將指定使用者的權限設定存入Model。
        /// </summary>
        private bool SaveUserAuthorizationTable(int userId)
        {
            if (!_authority.IsUserIdExist(userId))
                return false;

            return _authority.SetUserAuthorizationTable(userId, new AuthorizationTable
            {
                Menu_MainConsole = Menu_MainConsole,
                Menu_PalletParameters = Menu_PalletParameters,
                Menu_StageParameters = Menu_StageParameters,
                Menu_Manual = Menu_Manual,
                Menu_Pallet = Menu_Pallet,
                Menu_WFS_Specification = Menu_WFS_Specification,
                Menu_Tray = Menu_Tray,

                Menu_MachineDatum = Menu_MachineDatum,
                Menu_ClayTable = Menu_ClayTable,
                Menu_Displacement = Menu_Displacement,
                Menu_Stage = Menu_Stage,
                Menu_PalletInstallPoints = Menu_PalletInstallPoints,
                Menu_RepeatabilityTest = Menu_RepeatabilityTest,
                Func_ReportOutput = Func_ReportOutput,

                Menu_BigData = Menu_BigData,
                Report_AbnormalHistory = Report_AbnormalHistory,
                Report_SystemLogger = Report_SystemLogger,
                Report_ExceptionLogger = Report_ExceptionLogger,
                Menu_Product_Switch = Menu_Product_Switch,
                Menu_Product_Manager = Menu_Product_Manager,
                Menu_System = Menu_System,
                Menu_Connection = Menu_Connection,
                Menu_Authority = Menu_Authority,
            });
        }

        /// <summary>
        /// 從Model的載入指定使用者的權限設定。
        /// </summary>
        /// <returns>載入是否完成。</returns>
        private bool LoadUserAuthorizationTable(int userId)
        {
            if (!Authority.IsUserIdExist(userId))
                return false;

            var at = Authority.GetUserAuthorizationTable(userId);
            if (at == null)
                at = new AuthorizationTable();

            ToolQuest = at.ToolQuest;
            Menu_PalletParameters = at.Menu_PalletParameters;
            Menu_StageParameters = at.Menu_StageParameters;
            Menu_Manual = at.Menu_Manual;
            Menu_Pallet = at.Menu_Pallet;
            Menu_WFS_Specification = at.Menu_WFS_Specification;
            Menu_Tray = at.Menu_Tray;

            Menu_MachineDatum = at.Menu_MachineDatum;
            Menu_ClayTable = at.Menu_ClayTable;
            Menu_Displacement = at.Menu_Displacement;
            Menu_Stage = at.Menu_Stage;
            Menu_PalletInstallPoints = at.Menu_PalletInstallPoints;
            Menu_RepeatabilityTest = at.Menu_RepeatabilityTest;
            Func_ReportOutput = at.Func_ReportOutput;

            Menu_BigData = at.Menu_BigData;
            Report_AbnormalHistory = at.Report_AbnormalHistory;
            Report_SystemLogger = at.Report_SystemLogger;
            Report_ExceptionLogger = at.Report_ExceptionLogger;
            Menu_Product_Switch = at.Menu_Product_Switch;
            Menu_Product_Manager = at.Menu_Product_Manager;
            Menu_System = at.Menu_System;
            Menu_Connection = at.Menu_Connection;
            Menu_Authority = at.Menu_Authority;

            return true;
        }

        /********************
         * Binding
         ********************/
        /// <summary>
        /// 使用者名稱列表。
        /// </summary>
        public List<UserNameListDefine> UserNameList
        {
            get { return _userNameList; }
            set { SetProperty(ref _userNameList, value); }
        }
        private List<UserNameListDefine> _userNameList;

        /// <summary>
        /// 選擇的使用者。
        /// </summary>
        public UserNameListDefine SelectedUser
        {
            get { return _selectedUser; }
            set
            {
                SetProperty(ref _selectedUser, value);
                if (value != null)
                    LoadUserAuthorizationTable(value.Id);
            }
        }
        private UserNameListDefine _selectedUser;



    }
}
