﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Permission : UserControl
    {
        #region fields

        //private List<Authority> _dSource = new List<Authority>();

        #endregion fields

        public Setup_Permission()
        {
            InitializeComponent();
        }


        public void Update()
        {

        }
    }
}
