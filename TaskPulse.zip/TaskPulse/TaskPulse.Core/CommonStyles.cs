﻿using System.Drawing;
using Sunny.UI;

namespace Calin.TaskPulse.Core
{
    /*
     * SunnyUI 的 Styles 套用似乎有些問題，
     * 非自訂的有時子物件不會繼承，
     * 如果看到不是想要的效果須要自行修改。
     */
    /// <summary>
    /// 統一的共用 Styles。
    /// </summary>
    public static class CommonStyles
    {
        //public static Color BackColor => Color.FromArgb(80, 126, 164); // 藍灰
        public static Color BackColor => Color.FromArgb(44, 94, 127);
        public static Color SelectionBar => Color.FromArgb(0, 116, 126);
        public static Color Hover => Color.FromArgb(102, 161, 209);
        public static Font Font => new Font("微軟正黑體", 11f);

        /// <summary>
        /// 全域 Styles 設定。<br/>但若遇到子物件沒繼承的，仍須自行修改。
        /// </summary>
        public static void SetStyles()
        {
            UIStyles.MultiLanguageSupport = true;
            UIStyles.BuiltInResources.TryAdd(CultureInfos.zh_TW.LCID, new zh_TW_Resources());
            UIStyles.CultureInfo = CultureInfos.zh_TW;
            UIStyles.SetStyle(UIStyle.DarkBlue);
            UIStyles.InitColorful(BackColor, Color.White);
            UIStyles.DPIScale = true;
            UIStyles.GlobalFont = true;
            UIStyles.GlobalFontName = "微軟正黑體";
            UIStyles.SetDPIScale();
        }
    }
}
