﻿using Autofac;
using Autofac.Core;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Service;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // dialog
            builder.RegisterType<UserLogin>().ExternallyOwned();
            builder.RegisterType<CRUD>().ExternallyOwned();
            builder.RegisterType<FlowLayoutSelector>().ExternallyOwned();
            builder.RegisterType<MachineEdit>().ExternallyOwned();

            // views
            builder.RegisterType<SetupPage>().InstancePerDependency();
            builder.RegisterType<Setup_Permission>().InstancePerDependency();
            builder.RegisterType<Setup_Models>().InstancePerDependency();
            builder.RegisterType<Setup_MachinesSummary>().InstancePerDependency();
            builder.RegisterType<Setup_MachineInfo1>().InstancePerDependency();
            builder.RegisterType<Setup_MachineInfo2>().InstancePerDependency();
            builder.RegisterType<Setup_Employees>().InstancePerDependency();
            builder.RegisterType<Setup_EmployeeInfo>().InstancePerDependency();

            // service
            builder.RegisterType<DialogService>().InstancePerLifetimeScope().SingleInstance();
            builder.RegisterType<CoreService>().As<ICore>().SingleInstance();

            builder.RegisterType<MemoryCacheService>().SingleInstance();
            builder.RegisterType<AuthService>().As<IAuthService>().SingleInstance();
            builder.RegisterType<ActivityLogService>().As<IActivityLogService>().SingleInstance();
            builder.RegisterType<PermissionService>().As<IPermissionService>().InstancePerLifetimeScope();
            builder.RegisterType<EmployeeService>().As<IEmployeeService>().InstancePerLifetimeScope();
            builder.RegisterType<CurrentUserService>().As<ICurrentUserService>().InstancePerDependency();

            // public data
            builder.RegisterType<CoreData>().SingleInstance();
            builder.RegisterType<FieldTitle>().SingleInstance();
            builder.RegisterType<FieldName>().SingleInstance();

            // DbContext
            builder.RegisterType<CoreContext>().InstancePerDependency();
            builder.RegisterType<CoreInitializer>().As<IStartable>().SingleInstance();

            builder.RegisterBuildCallback(async c =>
            {
                var core = c.Resolve<ICore>();
                await core.Initialize();
            });
        }
    }
}
