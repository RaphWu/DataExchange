﻿using Autofac;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Service;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // dialog
            builder.RegisterType<UserLogin>().PropertiesAutowired();
            builder.RegisterType<CRUD>().PropertiesAutowired();
            builder.RegisterType<FlowLayoutSelector>().PropertiesAutowired();

            // views
            builder.RegisterType<SetupPage>();
            builder.RegisterType<Setup_Models>().InstancePerDependency();
            builder.RegisterType<Setup_MachinesSummary>().InstancePerDependency();
            builder.RegisterType<Setup_MachineInfo1>().InstancePerDependency();
            builder.RegisterType<Setup_MachineInfo2>().InstancePerDependency();

            // service
            builder.RegisterType<DialogService>().InstancePerLifetimeScope().SingleInstance();
            builder.RegisterType<CoreService>().As<ICore>().SingleInstance();
            builder.RegisterType<CrudService>().As<ICrudService>().SingleInstance();
            builder.RegisterType<AuthorityService>().As<IAuthority>().SingleInstance();

            // public data
            builder.RegisterType<CoreData>().SingleInstance();
            builder.RegisterType<FieldName>().SingleInstance();
            builder.RegisterType<CurrentAuthority>().SingleInstance();
            builder.RegisterType<AuthorityParameters>().SingleInstance();

            // DbContext
            builder.RegisterType<CoreContext>().InstancePerDependency();
            builder.RegisterType<CoreInitializer>().As<IStartable>().SingleInstance();

            builder.RegisterBuildCallback(async c =>
            {
                var core = c.Resolve<ICore>();
                await core.Initialize();
            });
        }
    }
}
