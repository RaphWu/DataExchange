﻿using Autofac;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<AuthorityService>().As<IAuthority>();

            builder.RegisterType<UserLogin>().AsSelf();
            builder.RegisterType<AuthorityManager>().AsSelf().PropertiesAutowired();
        }
    }
}
