﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Service
{
    public class CoreService : ICore
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private bool _isInitialized = false;

        public CoreService(CoreContext coreContext, CoreData coreData, FieldName fieldName, FieldTitle fieldTitle)
        {
            _context = coreContext;
            _coreData = coreData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;
        }

        /// <inheritdoc/>
        public async Task Initialize()
        {
            if (_isInitialized)
                return;

            await UpdateCoreDataCache();

            _fieldName.MachineId = nameof(Machine.MachineId);
            _fieldName.MachineCategory = nameof(MachineCategory.CategoryName);
            _fieldName.MachineType = nameof(MachineType.TypeName);
            _fieldName.MachineName = nameof(Machine.MachineName);
            _fieldName.Condition = nameof(Machine.Condition);
            _fieldName.Brand = nameof(Machine.Brand);
            _fieldName.Location = nameof(Machine.Location);
            _fieldName.Assets = nameof(Machine.Assets);
            _fieldName.SerialNumber = nameof(Machine.SerialNumber);
            _fieldName.Barcode = nameof(Machine.Barcode);
            _fieldName.Connected = nameof(Machine.Connected);
            _fieldName.Disposal = nameof(Machine.Disposal);
            _fieldName.Remark = nameof(Machine.Remark);
            _fieldName.Worktations = nameof(Machine.Worktations);

            _fieldTitle.MachineId = EnumHelper.GetDescription<Machine>(_fieldName.MachineId);
            _fieldTitle.MachineCategory = EnumHelper.GetDescription<MachineCategory>(_fieldName.MachineCategory);
            _fieldTitle.MachineType = EnumHelper.GetDescription<MachineType>(_fieldName.MachineType);
            _fieldTitle.MachineName = EnumHelper.GetDescription<Machine>(_fieldName.MachineName);
            _fieldTitle.Condition = EnumHelper.GetDescription<Machine>(_fieldName.Condition);
            _fieldTitle.Brand = EnumHelper.GetDescription<Machine>(_fieldName.Brand);
            _fieldTitle.Location = EnumHelper.GetDescription<Machine>(_fieldName.Location);
            _fieldTitle.Assets = EnumHelper.GetDescription<Machine>(_fieldName.Assets);
            _fieldTitle.SerialNumber = EnumHelper.GetDescription<Machine>(_fieldName.SerialNumber);
            _fieldTitle.Barcode = EnumHelper.GetDescription<Machine>(_fieldName.Barcode);
            _fieldTitle.Connected = EnumHelper.GetDescription<Machine>(_fieldName.Connected);
            _fieldTitle.Disposal = EnumHelper.GetDescription<Machine>(_fieldName.Disposal);
            _fieldTitle.Remark = EnumHelper.GetDescription<Machine>(_fieldName.Remark);
            _fieldTitle.Worktations = EnumHelper.GetDescription<Machine>(_fieldName.Worktations);

            _isInitialized = true;
        }

        /********************
         * Core Data
         ********************/
        /// <inheritdoc/>
        public async Task UpdateCoreDataCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            await UpdateEmployeesCache(false);
            await UpdateMachinesCache(false, false);
            await UpdateModelsCache(false, false);
            await UpdateWorkstationsCache(false, false);

            if (RecreateTabPage)
            {
                CreateMachineTabPage();
                CreateModelTabPage();
                CreateModelWsTabPage();
            }

            // 發佈資料更新通知
            if (SendUpdateNotification)
                StrongReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.AllCoreData));
        }

        /// <inheritdoc/>
        public async Task UpdateEmployeesCache(bool SendUpdateNotification = true)
        {
            _coreData.Employees = await _context.Employees
                .OrderBy(x => x.DepartmentId)
                .ThenBy(x => x.TitleId)
                .ThenBy(x => x.EmployeeId)
                .AsNoTracking()
                .ToListAsync();

            _coreData.Engineers = _coreData.Employees
                .Where(e => e.IsEngineer)
                .ToList();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                StrongReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Employee));
        }

        /// <inheritdoc/>
        public async Task UpdateMachinesCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var tMachines = await _context.Machines
                .Include(m => m.MachineName.MachineType.Category)
                .Include(m => m.Brand)
                .Include(m => m.Assets)
                .Include(m => m.Location)
                .Include(m => m.Condition)
                .Where(m => m.Disposal == false)
                .AsNoTracking()
                .ToListAsync();
            _coreData.Machines = tMachines
                .Select(m => new { Original = m, Key = GetMachineSortKey(m.MachineId) })
                .OrderBy(x => x.Key.Text)
                .ThenBy(x => x.Key.Number)
                .Select(x => x.Original)
                .ToList();

            // 機台分類
            _coreData.ClassifyMachines = _coreData.Machines
                .Where(m => m.MachineName != null &&
                            m.MachineName.MachineType != null &&
                            m.MachineName.MachineType.Category != null)
                .GroupBy(m => m.MachineName.MachineType.Category.CategoryName) // 外層 Category
                .OrderBy(g => g.First().MachineName.MachineType.Category.OrderNo)
                .ToDictionary(
                    categoryGroup => categoryGroup.Key, // CategoryName
                    categoryGroup => categoryGroup
                        .GroupBy(m => m.MachineName.MachineType.TypeName) // 內層 Type
                        .OrderBy(typeGroup => typeGroup.First().MachineName.MachineType.OrderNo)
                        .ToDictionary(
                            typeGroup => typeGroup.Key, // TypeName
                            typeGroup => typeGroup
                                .Select(m => new MachineInfo
                                {
                                    Id = m.Id,
                                    Name = m.MachineId // 或 MachineName.MachineName
                                })
                                .ToList()
                        )
                );


            //_coreData.ClassifyMachines = _coreData.MachineLocations
            //    .Where(m => m.MachineName != null &&
            //                m.MachineName.MachineType != null &&
            //                m.MachineName.MachineType.Category != null)
            //    .GroupBy(m => m.MachineName.MachineType.Category.CategoryName) // ✅ 外層 key 是 CategoryName (string)
            //    .OrderBy(g => g.First().MachineName.MachineType.Category.OrderNo)
            //    .ToDictionary(
            //        categoryNameGroup => categoryNameGroup.Key, // string: CategoryName
            //        categoryNameGroup => categoryNameGroup
            //            .GroupBy(m => m.MachineName.MachineType.TypeName) // ✅ 內層 key 是 TypeName (string)
            //            .OrderBy(typeGroup => typeGroup.First().MachineName.MachineType.OrderNo)
            //            .ToDictionary(
            //                typeGroup => typeGroup.Key, // string: TypeName
            //                typeGroup => typeGroup
            //                    .Select(m => m.MachineId.ToString()) // ✅ List<string>
            //                    .Distinct()
            //                    .ToList()
            //            )
            //    );


            //_coreData.ClassifyMachines = _coreData.MachineLocations
            //    .Where(m => m.MachineName != null && m.MachineName.MachineType != null && m.MachineName.MachineType.Category != null)
            //    .GroupBy(m => m.MachineName.MachineType.Category)
            //    .OrderBy(categoryGroup => categoryGroup.Key.OrderNo)
            //    .ToDictionary(
            //        categoryGroup => categoryGroup.Key.CategoryName,
            //        categoryGroup => categoryGroup
            //            .GroupBy(m => m.MachineName.MachineType)
            //            .OrderBy(typeGroup => typeGroup.Key.OrderNo)
            //            .ToDictionary(
            //                typeGroup => typeGroup.Key.TypeName,
            //                typeGroup => typeGroup
            //                    .Select(m => m.MachineId)
            //                    .Distinct()
            //                    .ToList()
            //            )
            //    );

            if (RecreateTabPage)
                CreateMachineTabPage();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                StrongReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Machine));
        }

        /// <inheritdoc/>
        public async Task UpdateModelsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var tModels = await _context.Models
                .AsNoTracking()
                .ToListAsync();
            _coreData.Models = tModels
                .ToList()
                .Select(m => new { Original = m, Key = GetModelSortKey(m.ModelName) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();

            if (RecreateTabPage)
            {
                CreateModelTabPage();
                CreateModelWsTabPage();
            }

            // 發佈資料更新通知
            if (SendUpdateNotification)
                StrongReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Model));
        }

        /// <inheritdoc/>
        public async Task UpdateWorkstationsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var tWorkstations = await _context.Workstations
                .Include(w => w.Model)
                .AsNoTracking()
                .ToListAsync();
            _coreData.Workstations = tWorkstations
                .Select(w => new { Original = w, Key = GetWorkstationSortKey(w) })
                .OrderBy(w => w.Key.ModelPriority)
                .ThenBy(w => w.Key.ModelNumber)
                .ThenBy(w => w.Key.OrderNo)
                .Select(w => w.Original)
                .ToList();

            if (RecreateTabPage)
                CreateModelWsTabPage();
            //    CreateModelTabPage();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                StrongReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Workstation));
        }

        /********************
         * TabPage注入
         * 這裡要創建 Controls，如果用非同步創建，會造成有些 Control 在顯示時引發 "跨執行緒作業無效"
         ********************/
        /// <inheritdoc/>
        public void CreateMachineTabPage()
        {
            _coreData.MachinesMultiTabPageCache = new Dictionary<string, List<TabPage>>();
            _coreData.MachinesSingleTabPageCache = new Dictionary<string, List<TabPage>>();
            foreach (var mCategoryName in _coreData.ClassifyMachines.Keys)
            {
                List<TabPage> mmTabPages = new List<TabPage>();
                List<TabPage> msTabPages = new List<TabPage>();
                var mTypesDicts = _coreData.ClassifyMachines[mCategoryName];
                foreach (var mTypeName in mTypesDicts.Keys)
                {
                    var mmTabPage = new TabPage(mTypeName)
                    {
                        Name = mTypeName,
                        Font = CommonStyles.Font,
                    };
                    var mmFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    mmTabPage.Controls.Add(mmFlow);

                    var msTabPage = new TabPage(mTypeName)
                    {
                        Name = mTypeName,
                        Font = CommonStyles.Font,
                    };
                    var msFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    msTabPage.Controls.Add(msFlow);

                    var machineList = mTypesDicts[mTypeName];
                    List<UICheckBox> cbs = new List<UICheckBox>();
                    List<UIRadioButton> rbs = new List<UIRadioButton>();
                    foreach (var machine in machineList)
                    {
                        var cb = new UICheckBox
                        {
                            Text = machine.Name,
                            Name = machine.Name,
                            Checked = false,
                            AutoSize = false,
                            Width = 130,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            CheckBoxColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = machine.Id,
                                Category = mCategoryName,
                                Type = mTypeName,
                                Name = machine.Name,
                            }
                        };
                        cbs.Add(cb);

                        var rb = new UIRadioButton
                        {
                            GroupIndex = 1,
                            Text = machine.Name,
                            Name = machine.Name,
                            Checked = false,
                            AutoSize = false,
                            Width = 130,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            RadioButtonColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = machine.Id,
                                Category = mCategoryName,
                                Type = mTypeName,
                                Name = machine.Name,
                            }
                        };
                        rbs.Add(rb);
                    }
                    mmFlow.Controls.AddRange(cbs.ToArray());
                    mmTabPages.Add(mmTabPage);
                    msFlow.Controls.AddRange(rbs.ToArray());
                    msTabPages.Add(msTabPage);
                }
                _coreData.MachinesMultiTabPageCache.Add(mCategoryName, mmTabPages);
                _coreData.MachinesSingleTabPageCache.Add(mCategoryName, msTabPages);
            }
        }

        /// <inheritdoc/>
        public void CreateModelTabPage()
        {
            _coreData.ModelTabPageCache = new Dictionary<string, List<TabPage>>();
            foreach (var model in _coreData.Models)
            {
                //var wss = _coreData.Models
                //    .Where(w => w.Id == model.Id)
                //    .ToList();
                if (_coreData.Models.Count > 0)
                {
                    string moCategoryName = model.ModelName;
                    string moSingleName = "Single";
                    List<TabPage> moTabPages = new List<TabPage>();
                    var moTabPage = new TabPage(moSingleName)
                    {
                        Name = moSingleName,
                        Font = CommonStyles.Font,
                    };
                    var moFlow = new UIFlowLayoutPanel()
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    moTabPage.Controls.Add(moFlow);

                    List<UIRadioButton> rbs = new List<UIRadioButton>();
                    foreach (var ml in _coreData.Models)
                    {
                        var rb = new UIRadioButton
                        {
                            GroupIndex = 1,
                            Text = ml.ModelName,
                            Name = ml.ModelName,
                            Checked = false,
                            AutoSize = false,
                            Width = 150,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            RadioButtonColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = ml.Id,
                                Category = moCategoryName,
                                Type = moSingleName,
                                Name = ml.ModelName,
                            }
                        };
                        rbs.Add(rb);
                    }
                    moFlow.Controls.AddRange(rbs.ToArray());
                    moTabPages.Add(moTabPage);
                    _coreData.ModelTabPageCache.Add(moCategoryName, moTabPages);
                }
            }
        }

        ///// <inheritdoc/>
        //public void CreateModelTabPage()
        //{
        //    _coreData.ModelTabPageCache = new Dictionary<string, List<TabPage>>();
        //    foreach (var model in _coreData.Models)
        //    {
        //        var wss = _coreData.Workstations
        //            .Where(w => w.ModelId == model.Id)
        //            .ToList();
        //        if (wss.Count > 0)
        //        {
        //            string moCategoryName = model.ModelName;
        //            string moSingleName = "Single";
        //            List<TabPage> moTabPages = new List<TabPage>();
        //            var moTabPage = new TabPage(moSingleName)
        //            {
        //                Name = moSingleName,
        //                Font = CommonStyles.Font,
        //            };
        //            var moFlow = new UIFlowLayoutPanel
        //            {
        //                Dock = DockStyle.Fill,
        //                AutoScroll = true,
        //            };
        //            moTabPage.Controls.Add(moFlow);

        //            List<UIRadioButton> rbs = new List<UIRadioButton>();
        //            foreach (var ml in wss)
        //            {
        //                var rb = new UIRadioButton
        //                {
        //                    Text = ml.WorkstationName,
        //                    Name = ml.WorkstationName,
        //                    Checked = false,
        //                    AutoSize = false,
        //                    Width = 150,
        //                    Font = CommonStyles.Font,
        //                    Style = UIStyle.Inherited,
        //                    RadioButtonColor = CommonStyles.BackColor,
        //                    Tag = new SelectorInfo() { Category = moCategoryName, Type = moSingleName, Workstation = ml.WorkstationName }
        //                };
        //                rbs.Add(rb);
        //            }
        //            moFlow.Controls.AddRange(rbs.ToArray());
        //            moTabPages.Add(moTabPage);
        //            _coreData.ModelTabPageCache.Add(moCategoryName, moTabPages);
        //        }
        //    }
        //}

        /// <inheritdoc/>
        public void CreateModelWsTabPage()
        {
            _coreData.ModelWsTabPageCache = new Dictionary<string, List<TabPage>>();
            foreach (var model in _coreData.Models)
            {
                var wss = _coreData.Workstations
                    .Where(w => w.ModelId == model.Id)
                    .ToList();
                if (wss.Count > 0)
                {
                    string moCategoryName = model.ModelName;
                    string moSingleName = "Single";
                    List<TabPage> moTabPages = new List<TabPage>();
                    var moTabPage = new TabPage(moSingleName)
                    {
                        Name = moSingleName,
                        Font = CommonStyles.Font,
                    };
                    var moFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    moTabPage.Controls.Add(moFlow);

                    List<UIRadioButton> rbs = new List<UIRadioButton>();
                    foreach (var ws in wss)
                    {
                        var rb = new UIRadioButton
                        {
                            Text = ws.WorkstationName,
                            Name = ws.WorkstationName,
                            Checked = false,
                            AutoSize = false,
                            Width = 150,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            RadioButtonColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = ws.Id,
                                Category = moCategoryName,
                                Type = moSingleName,
                                Name = ws.WorkstationName,
                            }
                        };
                        rbs.Add(rb);
                    }
                    moFlow.Controls.AddRange(rbs.ToArray());
                    moTabPages.Add(moTabPage);
                    _coreData.ModelWsTabPageCache.Add(moCategoryName, moTabPages);
                }
            }
        }

        /********************
         * Utility
         ********************/
        /// <inheritdoc/>
        public List<string> SortMachineId(IEnumerable<string> machineIds)
        {
            return machineIds
               .Select(s => new { Original = s, Key = GetMachineSortKey(s) })
               .OrderBy(x => x.Key.Text)
               .ThenBy(x => x.Key.Number)
               .Select(x => x.Original)
               .ToList();
        }

        /// <inheritdoc/>
        public List<string> SortModelNames(IEnumerable<string> modelNames)
        {
            return modelNames
                .Select(name => new { Original = name, Key = GetModelSortKey(name) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();
        }

        /// <inheritdoc/>
        public List<Workstation> SortWorkstations(IEnumerable<Workstation> workstations)
        {
            return workstations
                .OrderBy(w => GetWorkstationSortKey(w))
                .ToList();
        }

        /********************
         * Control
         ********************/
        /// <inheritdoc/>
        public void CleanUpControls(Control.ControlCollection controls)
        {
            if (controls.Count == 0)
                return;

            foreach (Control c in controls)
                c.Dispose();
            controls.Clear();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        /********************
         * private Common Functions
         ********************/
        /// <summary>
        /// MachineId 的共用排序規則。
        /// </summary>
        private (string Text, int Number) GetMachineSortKey(string machineId)
        {
            var match = Regex.Match(machineId, @"^([^\d\-]+)-?(\d+)$", RegexOptions.IgnoreCase);
            string textPart = match.Success ? match.Groups[1].Value : machineId;
            int numberPart = (match.Success && int.TryParse(match.Groups[2].Value, out int n)) ? n : int.MaxValue;
            return (textPart.ToLowerInvariant(), numberPart);

        }

        /// <summary>
        /// Model 的共用排序規則。
        /// </summary>
        private (bool IsThreeDigits, int SortKey) GetModelSortKey(string modelName)
        {
            var prefix = modelName.Split('-')[0];
            bool isThreeDigits = Regex.IsMatch(prefix, @"^\d{3}$");
            int sortKey = int.TryParse(prefix, out var n) ? n : int.MaxValue;
            return (isThreeDigits, sortKey);
        }

        /// <summary>
        /// Workstation 的共用排序規則。
        /// </summary>
        private (int ModelPriority, int ModelNumber, int OrderNo) GetWorkstationSortKey(Workstation w)
        {
            var modelName = w.Model?.ModelName ?? "";
            var key = GetModelSortKey(modelName);

            int modelPriority = key.IsThreeDigits ? 0 : 1;
            int modelNumber = key.SortKey;
            int orderNo = w.OrderNo;

            return (modelPriority, modelNumber, orderNo);
        }
    }
}
