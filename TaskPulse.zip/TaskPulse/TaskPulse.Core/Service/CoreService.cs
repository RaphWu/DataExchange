﻿using System.Linq;
using Autofac;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI.Win32;

namespace Calin.TaskPulse.Core.Service
{
    public class CoreService : ICore
    {
        private readonly ILifetimeScope _scope;
        private bool _isInitialized = false;

        public CoreService(ILifetimeScope scope)
        {
            _scope = scope;
        }

        public void Initialize()
        {
            if (_isInitialized)
                return;

            UpdateCoreDataFromDb();
            _isInitialized = true;
        }

        /// <inheritdoc/>
        public void UpdateCoreDataFromDb()
        {
            using (var scope = _scope.BeginLifetimeScope())
            {
                var coreContext = scope.Resolve<CoreContext>();
                var coreData = scope.Resolve<CoreData>();

                coreData.Employees = coreContext.Employees
                    .OrderBy(x => x.EmployeeId)
                    .ToList();

                coreData.Devices = coreContext.Devices
                     .Include("DeviceName")
                     .Include("DeviceName.Type")
                     .Include("Brand")
                     .Include("Assets")
                     .Include("Location")
                     .Include("Location.Factory")
                     .Include("Condition")
                     .OrderBy(x => x.DeviceId)
                     .ToList();

                coreData.Models = coreContext
                    .Models.OrderBy(x => x.ModelId)
                    .ToList();

                StrongReferenceMessenger.Default.Send(CoreDataChangedNotification.Instance);
            }
        }
    }
}
