﻿using System;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Serilog;
using Serilog.Formatting.Compact;

namespace Calin.TaskPulse.Core.Service
{
    public class LogService : ILogService
    {
        private readonly ILogger _infoLogger; // 一般資訊事件 (APP 流程、操作訊息、狀態更新)，Text，每天一個檔案，保留 7~30 天
        private readonly ILogger _activityLogger; // 使用者操作事件 (登入、登出、重要操作)，Json，每日一檔，保留 90 天
        private readonly ILogger _errorLogger; // 錯誤事件 (程式錯誤追蹤、堆疊追蹤)，Text，每天一個檔案，保留 90 天
        private readonly ILogger _securityLogger; // 安全事件 (權限變更、異常登入)，Json，每天一個檔案，保留 180 天

        public LogService()
        {
            _infoLogger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.File("logs/information.txt", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 30)
                .CreateLogger();

            _activityLogger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.File(new CompactJsonFormatter(),
                    "logs/user_activity.json", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 90)
                .CreateLogger();

            _errorLogger = new LoggerConfiguration()
              .MinimumLevel.Error()
              .WriteTo.File("logs/error_log_.txt", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 90)
              .CreateLogger();

            _securityLogger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.File(new CompactJsonFormatter(),
                    "logs/security_event.json", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 180)
                .CreateLogger();
        }

        /********************
         * System
         ********************/
        /// <inheritdoc/>
        public async Task ErrorAsync(string message, Exception ex = null)
        {
            var logEntry = new
            {
                Message = message,
                Exception = ex?.ToString(),
                Timestamp = DateTime.UtcNow
            };
            _errorLogger.Error("{@LogEntry}", logEntry);
            await Task.CompletedTask;
        }

        /********************
         * User
         ********************/
        /// <inheritdoc/>
        public async Task LoginAsync(string userId, string action, string dataJson)
        {
            var logEntry = new
            {
                UserId = userId,
                Action = action,
                Data = dataJson,
                Timestamp = DateTime.UtcNow
            };
            _activityLogger.Information("{@LogEntry}", logEntry);
            await Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task UIActionAsync(int userId, string formName, string controlName, string action, object data = null)
        {
            var logEntry = new
            {
                Timestamp = DateTime.Now,
                UserId = userId,
                Form = formName,
                Control = controlName,
                Action = action,
                Data = data
            };

            _infoLogger.Information("{@LogEntry}", logEntry);
            await Task.CompletedTask;
        }
    }
}
