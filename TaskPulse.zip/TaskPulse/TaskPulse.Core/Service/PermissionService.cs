﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Caching;
using System.Runtime.Remoting.Contexts;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI.Win32;

namespace Calin.TaskPulse.Core.Service
{
    public class PermissionService : IPermissionService
    {
        private readonly CoreContext _context;
        private readonly MemoryCacheService _cache;
        private readonly ICurrentUserService _currentUser;
        private static readonly string[] GuestPermissions = new[] { "Home.View", "Login.Access" };

        public PermissionService(CoreContext coreContext, MemoryCacheService cache, ICurrentUserService currentUserService)
        {
            _context = coreContext;
            _cache = cache;
            _currentUser = currentUserService;
        }

        /********************
         * Permission
         ********************/
        /// <inheritdoc/>
        public HashSet<string> GetUserPermissions(String employeeId, string prefix)
        {
            string cacheKey = $"{prefix}{employeeId}";

            return _cache.GetOrCreate(cacheKey, policy =>
            {
                var user = _context.Employees
                    .Include(u => u.Department.Permissions)
                    .Include(u => u.UserGroups.Select(g => g.Permissions))
                    .Include(u => u.Permissions)
                    .FirstOrDefault(u => u.EmployeeId == employeeId);

                if (user == null)
                    return new HashSet<string>();

                if (_currentUser.IsAdmin)
                    return new HashSet<string> { "*" };

                if (_currentUser.IsGuest || !user.OnStaff)
                    return new HashSet<string>(GuestPermissions);

                var permissions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                if (user.Department?.Permissions != null)
                    permissions.UnionWith(user.Department.Permissions.Select(p => p.Code));

                if (user.UserGroups != null)
                    permissions.UnionWith(user.UserGroups
                        .Where(g => g.Permissions != null)
                        .SelectMany(g => g.Permissions.Select(p => p.Code)));

                if (user.Permissions != null)
                    permissions.UnionWith(user.Permissions.Select(p => p.Code));

                return permissions;
            }, TimeSpan.FromMinutes(30));
        }

        /// <inheritdoc/>
        public bool HasPermission(string employeeId, string prefix, string permission)
        {
            if (_currentUser.IsAdmin)
                return true;

            var user = _context.Employees.FirstOrDefault(u => u.EmployeeId == employeeId);
            if (user == null)
                return GuestPermissions.Any(p => IsMatch(p, permission));

            var all = GetUserPermissions(prefix, employeeId);
            return all.Any(p => IsMatch(p, permission));
        }

        /// <summary>
        /// 權限比對，支援萬用字元。
        /// </summary>
        /// <param name="granted">已授權的權限字串。</param>
        /// <param name="target">目標權限字串。</param>
        /// <returns>傳回是否匹配。</returns>
        private bool IsMatch(string granted, string target)
        {
            if (granted == "*")
                return true;

            if (granted.EndsWith(".*"))
                return target.StartsWith(granted.Substring(0, granted.Length - 2), StringComparison.OrdinalIgnoreCase);

            return string.Equals(granted, target, StringComparison.OrdinalIgnoreCase);
        }

        /********************
         * Control Access
         ********************/
        /// <inheritdoc/>
        public bool HasControlAccess(string employeeId, string prefix, string controlName)
        {
            if (_currentUser.IsAdmin)
                return true;

            var permissions = GetUserPermissions(prefix, employeeId);
            return permissions.Contains(controlName);
        }

        /// <inheritdoc/>
        public string GetPermissionSource(string employeeId, string prefix, string controlName)
        {
            string cacheKey = $"{prefix}_{controlName}_*";
            string result = _cache.GetOrCreate(cacheKey, policy =>
            {
                // 可自訂快取策略
                // policy.SlidingExpiration = TimeSpan.FromMinutes(10);

                var user = _context.Employees
                                   .Include(e => e.Department.Permissions)
                                   .FirstOrDefault(e => e.EmployeeId == employeeId);

                if (user?.Department?.Permissions?.Any(p => p.Code == controlName) == true)
                    return "Department";

                var groups = _context.UserGroups
                                     .Include(g => g.Permissions)
                                     .Include(g => g.Members)
                                     .Where(g => g.Members.Any(m => m.EmployeeId == employeeId))
                                     .ToList();

                if (groups.Any(g => g.Permissions.Any(p => p.Code == controlName)))
                    return "UserGroup";

                return "None";
            });
            return result;
        }

        /********************
         * Refresh
         ********************/
        /// <inheritdoc/>
        public void RefreshUserPermissions(string employeeId)
        {
            _cache.Remove(employeeId);
        }

        /// <inheritdoc/>
        public void RefreshAllUserCaches()
        {
            // 避免全站暴力清除太頻繁，但這是個提供的工具
            // 取得在快取中的所有 key，MemoryCache 不直接提供列舉所有 key 的好方法，這裡示範常見模式：
            // 若你需要經常全清，考慮維護一個已快取 employeeId 列表
            // 這裡示範：清除所有 Users（從 DB 查詢）
            var allUserIds = _context.Employees
                .Select(u => u.EmployeeId)
                .ToList();
            foreach (var userId in allUserIds)
                _cache.Remove(userId);
        }

        /// <inheritdoc/>
        public void RefreshDepartmentPermissions(int departmentId)
        {
            var userIds = _context.Employees
                .Where(u => u.DepartmentId == departmentId)
                .Select(u => u.EmployeeId)
                .ToList();

            foreach (var userId in userIds)
                _cache.Remove(userId);
        }

        /// <inheritdoc/>
        public void RefreshUserGroupPermissions(int userGroupId)
        {
            var userIds = _context.Employees
                .Where(u => u.UserGroups.Any(g => g.Id == userGroupId))
                .Select(u => u.EmployeeId)
                .ToList();

            foreach (var userId in userIds)
                _cache.Remove(userId);
        }
    }
}





//// 手動清除使用者權限快取（例如權限更新時）
///// <inheritdoc/>
//public void ClearUserCache(int userId)
//{
//    _cache.Remove($"Permissions_{userId}");
//}

///********************
// * 
// ********************/
///// <inheritdoc/>
//private HashSet<string> LoadPermissionsFromDb(int userId)
//{
//    var user = _context.Employees.Include(e => e.Department)
//                            .ThenInclude(d => d.Permissions)
//                            .FirstOrDefault(e => e.Id == userId);

//    var deptPerms = user?.Department?.Permissions.Select(p => p.ControlName).ToList() ?? new List<string>();

//    var groupPerms = _context.UserGroups
//                        .Include(g => g.Permissions)
//                        .Where(g => g.Members.Any(m => m.Id == userId))
//                        .SelectMany(g => g.Permissions)
//                        .Select(p => p.ControlName)
//                        .ToList();

//    return deptPerms.Union(groupPerms).ToHashSet();
//}

///// <summary>
///// 取得使用者所有權限清單
///// </summary>
///// <param name="userId"></param>
///// <returns></returns>
//public async Task<HashSet<string>> GetUserPermissionsAsync(int userId)
//{
//    return _cache.GetOrCreate($"permissions_{userId}", () =>
//    {
//        var employee = _db.Employees
//            .Include("Department.Permissions")
//            .Include("UserGroups.Permissions")
//            .FirstOrDefault(e => e.Id == userId);

//        if (employee == null) return new List<string>();

//        var deptPerms = employee.Department?.Permissions.Select(p => p.Name).ToList() ?? new List<string>();
//        var groupPerms = employee.UserGroups
//            .SelectMany(ug => ug.Permissions)
//            .Select(p => p.Name)
//            .ToList();

//        return deptPerms.Union(groupPerms).Distinct().ToList();
//    }, TimeSpan.FromMinutes(30));
//}