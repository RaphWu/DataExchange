﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Newtonsoft.Json;

namespace Calin.TaskPulse.Core.Service
{
    /// <summary>
    /// 員工資料庫與權限操作。
    /// </summary>
    public class EmployeeService : IEmployeeService
    {
        private readonly CoreContext _context;
        private readonly IPermissionService _permissionService;
        private readonly ILogService _log;

        public EmployeeService(CoreContext coreContext,
                               IPermissionService permissionService,
                               ILogService activityLogService)
        {
            _context = coreContext;
            _permissionService = permissionService;
            _log = activityLogService;
        }

        /********************
         * database operations
         ********************/
        /// <inheritdoc/>
        public async Task AddEmployeeAsync(EmployeeDto dto, string performedByUserId)
        {
            var emp = new Employee
            {
                EmployeeId = dto.Id,
                EmployeeName = dto.Name,
                DepartmentId = dto.DepartmentId,
                TitleId = dto.TitleId,
                EMail = dto.EMail,
                IsEngineer = dto.IsEngineer,
                OnStaff = dto.OnStaff,
            };
            _context.Employees.Add(emp);
            await _context.SaveChangesAsync();

            _permissionService.RefreshUserPermissions(emp.EmployeeId);
            //await _log.LoginAsync(performedByUserId, "AddEmployee", JsonConvert.SerializeObject(new { emp.Id, emp.Name }));
            await _log.LoginAsync(performedByUserId, "新增員工", JsonConvert.SerializeObject(new { dto.Id, dto.Name }));
        }

        /// <inheritdoc/>
        public async Task EditEmployeeAsync(Employee emp, string performedByUserId)
        {
            _context.Entry(emp).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            _permissionService.RefreshUserPermissions(emp.EmployeeId);
            await _log.LoginAsync(performedByUserId,
                                "編輯員工",
                                JsonConvert.SerializeObject(new { emp.EmployeeId, emp.EmployeeName }));
        }

        /// <inheritdoc/>
        public async Task EmployeeResignationAsync(int employeeId, string performedByUserId)
        {
            var emp = await _context.Employees.FindAsync(employeeId);
            if (emp != null)
            {
                emp.OnStaff = false;
                await _context.SaveChangesAsync();

                _permissionService.RefreshUserPermissions(emp.EmployeeId);
                await _log.LoginAsync(performedByUserId,
                                    "員工離職",
                                    JsonConvert.SerializeObject(new { emp.EmployeeId, emp.EmployeeName }));
            }
        }

        /// <inheritdoc/>
        public async Task EmployeeRehireAsync(int employeeId, string performedByUserId, string newEmployeeId = "")
        {
            var emp = await _context.Employees
                                    .Include(e => e.Permissions)
                                    .Include(e => e.UserGroups)
                                    .FirstOrDefaultAsync(e => e.Id == employeeId);

            if (emp == null)
                return;

            // 建立新員工實體
            var newEmployee = new Employee
            {
                EmployeeId = string.IsNullOrEmpty(newEmployeeId) ? emp.EmployeeId : newEmployeeId,
                EmployeeName = emp.EmployeeName,
                PasswordHash = emp.PasswordHash,
                EMail = emp.EMail,
                DepartmentId = emp.DepartmentId,
                TitleId = emp.TitleId,
                IsEngineer = emp.IsEngineer,
                OnStaff = true
            };

            // 批次取得所有 Permissions
            if (emp.Permissions != null && emp.Permissions.Any())
            {
                var permissionIds = emp.Permissions.Select(p => p.Id).ToList();
                var permissions = await _context.Permissions
                                                .Where(p => permissionIds.Contains(p.Id))
                                                .ToListAsync();
                newEmployee.Permissions = permissions;
            }

            // 批次取得所有 UserGroups
            if (emp.UserGroups != null && emp.UserGroups.Any())
            {
                var groupIds = emp.UserGroups.Select(g => g.Id).ToList();
                var groups = await _context.UserGroups
                                           .Where(g => groupIds.Contains(g.Id))
                                           .ToListAsync();
                newEmployee.UserGroups = groups;
            }

            // 新增員工並保存
            _context.Employees.Add(newEmployee);
            await _context.SaveChangesAsync();

            // 刷新權限快取
            _permissionService.RefreshUserPermissions(emp.EmployeeId);

            // 記錄日誌
            await _log.LoginAsync(
                performedByUserId,
                "員工復職",
                JsonConvert.SerializeObject(new { emp.EmployeeId, emp.EmployeeName })
            );
        }

        /// <inheritdoc/>
        public async Task UpdateEmployeeAsync(Employee emp, string performedByUserId)
        {
            _context.Entry(emp).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            _permissionService.RefreshUserPermissions(emp.EmployeeId);
            await _log.LoginAsync(performedByUserId, "更新員工資料", JsonConvert.SerializeObject(emp));
        }

        /// <inheritdoc/>
        public async Task UpdateDepartmentPermissionsAsync(int departmentId, List<int> permissionIds, string performedByUserId)
        {
            var dept = _context.Departments.Include("Permissions").First(d => d.Id == departmentId);
            dept.Permissions.Clear();
            var perms = _context.Permissions.Where(p => permissionIds.Contains(p.Id)).ToList();
            foreach (var p in perms) dept.Permissions.Add(p);
            await _context.SaveChangesAsync();

            _permissionService.RefreshDepartmentPermissions(departmentId);
            await _log.LoginAsync(performedByUserId,
                                "更新部門權限",
                                JsonConvert.SerializeObject(new
                                {
                                    DepartmentId = departmentId,
                                    Permissions = permissionIds
                                }));
        }

        /// <inheritdoc/>
        public async Task UpdateUserGroupPermissionsAsync(int groupId, List<int> permissionIds, string performedByUserId)
        {
            var group = await _context.UserGroups
                .Include(g => g.Permissions)
                .FirstOrDefaultAsync(g => g.Id == groupId);
            group.Permissions.Clear();
            var perms = await _context.Permissions
                .Where(p => permissionIds.Contains(p.Id))
                .ToListAsync();
            foreach (var p in perms)
                group.Permissions.Add(p);
            await _context.SaveChangesAsync();

            _permissionService.RefreshUserGroupPermissions(groupId);
            await _log.LoginAsync(performedByUserId,
                                "更新群組權限",
                                JsonConvert.SerializeObject(new
                                {
                                    UserGroupId = groupId,
                                    Permissions = permissionIds
                                }));
        }
    }
}
