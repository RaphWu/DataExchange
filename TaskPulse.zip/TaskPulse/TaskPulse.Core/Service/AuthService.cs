﻿using System;
using System.Data.Entity;
using System.DirectoryServices.Protocols;
using System.Linq;
using System.Net;
using System.Security;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;
using Serilog;

namespace Calin.TaskPulse.Core.Service
{
    /// <summary>
    /// 登入驗證。
    /// </summary>
    public class AuthService : IAuthService
    {
        private readonly CoreContext _context;
        private readonly ICurrentUserService _currentUser;
        private readonly IActivityLogService _log;

        public AuthService(CoreContext coreContext, ICurrentUserService currentUserService, IActivityLogService activityLogService)
        {
            _context = coreContext;
            _currentUser = currentUserService;
            _log = activityLogService;
        }

        /********************
         * AD認證服務
         ********************/
        /// <inheritdoc/>
        public async Task<bool> ActiveDirectoryAsync(string employeeId, string password)
        {
            try
            {
                SecureString securePwd = new SecureString();
                foreach (var c in password)
                    securePwd.AppendChar(c);

                var identifier = new LdapDirectoryIdentifier("172.16.254.200");
                using (var connection = new LdapConnection(identifier))
                {
                    connection.SessionOptions.ProtocolVersion = 3;
                    connection.AuthType = AuthType.Negotiate;
                    var credential = new NetworkCredential(employeeId, securePwd);
                    connection.Bind(credential);
                    Console.WriteLine("LDAP驗證成功");

                    var user = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employeeId);
                    if (user != null)
                    {
                        _currentUser.SwitchCurrentUser(user);
                        await _log.LoginAsync(employeeId, "登入成功", "");
                        StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
                        return true;
                    }
                    else
                    {
                        Console.WriteLine("使用者不存在於系統中");
                        await _log.LoginAsync(employeeId, "登入失敗", "使用者不存在於系統中");
                    }
                }
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LDAP驗證失敗: {ex.Message}");
                await _log.LoginAsync(employeeId, "LDAP驗證失敗", $"User: {employeeId}, LDAP Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"系統錯誤: {ex.Message}");
                await _log.ErrorAsync($"LDAP驗證系統錯誤: {ex.Message}", ex);
            }
            finally
            {
                _currentUser.SwitchCurrentUserToGuest();
            }
            StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
            return false;
        }
    }
}


//public User Login(string username, string password)
//{
//    var emp = _context.Employees.FirstOrDefault(e => e.UserName == username);
//    if (emp != null && PasswordHelper.VerifyPassword(password, emp.PasswordHash))
//        return emp;
//    return null;
//}

//public async Task LoginAsync(User user)
//{
//    await _log.LoginAsync(user.Id, "Login", new { user.UserName });
//}

//public async Task LogoutAsync(User user)
//{
//    await _log.LoginAsync(user.Id, "Logout", new { user.UserName });
//}
