﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using Newtonsoft.Json;

namespace Calin.TaskPulse.Core.Service
{
    public class UserGroupService : IUserGroupService
    {
        private readonly CoreContext _context;
        private readonly ILogService _log;
        private readonly MemoryCacheService _cache;

        public UserGroupService(CoreContext coreContext, ILogService activityLogService, MemoryCacheService cache)
        {
            _context = coreContext;
            _log = activityLogService;
            _cache = cache;
        }

        public async Task<UserGroup> CreateAsync(UserGroup group, string currentUserId)
        {
            _context.UserGroups.Add(group);
            await _context.SaveChangesAsync();

            await _log.LoginAsync(currentUserId,
                                  "Create UserGroup",
                                  JsonConvert.SerializeObject(new { group.Id, group.Name }));
            return group;
        }

        public async Task<UserGroup> UpdateAsync(UserGroup group, string currentUserId)
        {
            var existing = await _context.UserGroups.FindAsync(group.Id);
            if (existing == null) throw new Exception("UserGroup not found");

            existing.Name = group.Name;
            await _context.SaveChangesAsync();

            _cache.RemoveByPrefix("permissions_"); // 更新群組權限後清空所有使用者快取

            await _log.LoginAsync(currentUserId,
                                  "Update UserGroup",
                                  JsonConvert.SerializeObject(new { group.Id, group.Name }));
            return existing;
        }

        public async Task DeleteAsync(int groupId, string currentUserId)
        {
            var existing = await _context.UserGroups.FindAsync(groupId);
            if (existing == null) throw new Exception("UserGroup not found");

            _context.UserGroups.Remove(existing);
            await _context.SaveChangesAsync();

            _cache.RemoveByPrefix("permissions_");

            await _log.LoginAsync(currentUserId,
                                  "Delete UserGroup",
                                  JsonConvert.SerializeObject(new { groupId }));
        }

        public Task<UserGroup> GetByIdAsync(int groupId)
        {
            return _context.UserGroups
                .Include(ug => ug.Permissions)
                .Include(ug => ug.Members)
                .FirstOrDefaultAsync(ug => ug.Id == groupId);
        }

        public Task<List<UserGroup>> GetAllAsync()
        {
            return _context.UserGroups
                .Include(ug => ug.Permissions)
                .Include(ug => ug.Members)
                .ToListAsync();
        }

        public async Task AssignUsersAsync(int groupId, List<int> userIds, string currentUserId)
        {
            var group = await _context.UserGroups.Include(ug => ug.Members).FirstOrDefaultAsync(ug => ug.Id == groupId);
            if (group == null) throw new Exception("UserGroup not found");

            group.Members.Clear();
            var users = await _context.Employees.Where(e => userIds.Contains(e.Id)).ToListAsync();
            foreach (var u in users) group.Members.Add(u);

            await _context.SaveChangesAsync();
            _cache.RemoveByPrefix("permissions_");

            await _log.LoginAsync(currentUserId,
                                  "Assign Users to Group",
                                  JsonConvert.SerializeObject(new { groupId, userIds }));
        }

        public async Task AssignPermissionsAsync(int groupId, List<int> permissionIds, string currentUserId)
        {
            var group = await _context.UserGroups.Include(ug => ug.Permissions).FirstOrDefaultAsync(ug => ug.Id == groupId);
            if (group == null) throw new Exception("UserGroup not found");

            group.Permissions.Clear();
            var perms = await _context.Permissions.Where(p => permissionIds.Contains(p.Id)).ToListAsync();
            foreach (var p in perms) group.Permissions.Add(p);

            await _context.SaveChangesAsync();
            _cache.RemoveByPrefix("permissions_");

            await _log.LoginAsync(currentUserId,
                                  "Assign Permissions to Group",
                                  JsonConvert.SerializeObject(new { groupId, permissionIds }));
        }
    }
}
