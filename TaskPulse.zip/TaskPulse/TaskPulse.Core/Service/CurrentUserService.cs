﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Service
{
    public class CurrentUserService : ICurrentUserService
    {
        private readonly CoreContext _context;
        private readonly MemoryCacheService _cache;
        private readonly IPermissionService _permissionService;
        private Employee _currentUser = null;

        private bool _isAdmin = false;
        private bool _isGuest = false;

        public CurrentUserService(CoreContext coreContext, MemoryCacheService cache, IPermissionService permissionService)
        {
            _context = coreContext;
            _permissionService = permissionService;
            _cache = cache;
        }

        /// <inheritdoc/>
        public int UserId => _currentUser?.Id ?? 0;

        /// <inheritdoc/>
        public string EmployeeId => _currentUser?.EmployeeId ?? "";

        /// <inheritdoc/>
        public string UserName => _currentUser?.EmployeeName ?? "";

        /// <inheritdoc/>
        public Employee User => _currentUser;

        /********************
         * Permission
         ********************/
        /// <inheritdoc/>
        public bool IsAdmin => UserId == int.MaxValue;

        /// <inheritdoc/>
        public bool IsGuest => UserId == 0;

        /********************
         * Switch User
         ********************/
        /// <inheritdoc/>
        public void SwitchCurrentUser(Employee user)
        {
            _currentUser = user;
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(int userId)
        {
            if (UserId == int.MaxValue)
            {
                _isAdmin = true;
                _currentUser = null;
            }
            else
            {
                _isAdmin = false;
                _currentUser = _context.Employees.FirstOrDefault(e => e.Id == userId);
            }
        }

        /// <inheritdoc/>
        public void SwitchCurrentUserToGuest()
        {
            _currentUser = null;
        }

        /********************
         * Utility
         ********************/
        /// <inheritdoc/>
        public HashSet<string> GetPermissionsAsync(string prefix)
        {
            return _cache.GetOrCreate($"{prefix}_{EmployeeId}", policy =>
            {
                // 由同步方式取得權限，因為 MemoryCache 不支援 async lambda
                return _permissionService.GetUserPermissions(EmployeeId, prefix);
            }, TimeSpan.FromMinutes(30));
        }
    }
}
