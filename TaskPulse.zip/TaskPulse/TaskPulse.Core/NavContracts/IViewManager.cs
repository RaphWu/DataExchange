﻿using System;

namespace Calin.TaskPulse.Core.NavContracts
{
    public interface IViewManager
    {
        object Resolve(Type viewType, bool alive = false);
        TView Resolve<TView>(bool alive = false) where TView : class;
        void Release(Type viewType);
        void Release<TView>() where TView : class;
    }
}
