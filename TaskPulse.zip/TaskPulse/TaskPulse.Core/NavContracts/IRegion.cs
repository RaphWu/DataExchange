﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavContracts
{
    public interface IRegion
    {
        string Name { get; }
        Control HostControl { get; }

        void ShowView(object view);
        void Clear();
    }
}
