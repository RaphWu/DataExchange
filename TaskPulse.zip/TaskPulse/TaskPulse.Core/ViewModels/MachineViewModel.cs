﻿using System.Collections.Generic;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.ViewModels
{
    public class MachineViewModel
    {
        public string MachineId { get; set; }
        public string MachineName { get; set; }
        public string CategoryName { get; set; }
        public string TypeName { get; set; }
        public string Status { get; set; }
        public string Condition { get; set; }
        public string Brand { get; set; }
        public string Location { get; set; }
        public ICollection<MachineAssetCode> Assets { get; set; }
        public string AssetString { get; set; }
        public string AssetList { get; set; }
        public string SerialNumber { get; set; }
        public string Barcode { get; set; }
        public bool Connected { get; set; }
        public string ConnectedString { get; set; }
        public bool Disposal { get; set; }
        public string DisposalString { get; set; }
        public string Remark { get; set; }
        public string Worktations { get; set; }
    }
}
