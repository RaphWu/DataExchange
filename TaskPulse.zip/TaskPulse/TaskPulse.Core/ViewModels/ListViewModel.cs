﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public class ListViewModel : ViewModelBase
    {
    }
}
