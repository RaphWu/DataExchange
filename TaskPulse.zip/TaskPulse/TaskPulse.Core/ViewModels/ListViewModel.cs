﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public class ListViewModel
    {
        public int Id { get; set; }
        public int? NullableId { get; set; }
        public string Name { get; set; }
        public int OrderNo { get; set; }
    }
}
