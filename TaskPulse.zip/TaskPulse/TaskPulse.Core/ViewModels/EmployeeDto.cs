﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public class EmployeeDto
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public int DepartmentId { get; set; }
        public int TitleId { get; set; }
        public string EMail { get; set; } = "";
        public bool IsEngineer { get; set; } = false;
        public bool OnStaff { get; set; } = true;
        public string Permission { get; set; } = "";
    }
}
