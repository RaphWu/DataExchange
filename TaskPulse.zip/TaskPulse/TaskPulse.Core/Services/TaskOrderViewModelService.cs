﻿using Calin.TaskPulse.Core.Contracts;

namespace Calin.TaskPulse.Core.Services
{
    public class TaskOrderViewModelService : ITaskOrderViewModel
    {
    }
}
