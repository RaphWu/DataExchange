﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Services
{
    public class EmployeeEntityService : IEmployeeEntity
    {
        private readonly DbContext _db;

        public EmployeeEntityService(DbContext db)
        {
            _db = db;
        }

        /********************
         * Employees
         ********************/
        /// <summary>
        /// Gets the queryable collection of Employees.
        /// </summary>
        public IQueryable<Employee> Employees => _db.Set<Employee>();

        public async Task<List<Employee>> GetAllEmployeesAsync() => await Employees.ToListAsync();

        public async Task<List<Employee>> SearchEmployeesByNameAsync(string name)
        {
            return await Employees
                .Where(e => e.EmployeeName.Contains(name))
                .ToListAsync();
        }

        public async Task<int> GetEmployeeCountAsync() => await Employees.CountAsync();

        /********************
         * Employee
         ********************/

        public async Task<Employee> GetEmployeeByIdAsync(int id)
            => await Employees.FirstOrDefaultAsync(e => e.Id == id);


        public async Task<Employee> GetEmployeeByEmployeeIdAsync(string employeeId)
            => await Employees.FirstOrDefaultAsync(e => e.EmployeeId == employeeId);


        public async Task AddEmployeeAsync(Employee employee)
        {
            _db.Set<Employee>().Add(employee);
            await _db.SaveChangesAsync();
        }

        public async Task UpdateEmployeeAsync(Employee employee)
        {
            _db.Entry(employee).State = EntityState.Modified;
            await _db.SaveChangesAsync();
        }

        public async Task DeleteEmployeeAsync(int id)
        {
            var employee = await GetEmployeeByIdAsync(id);
            if (employee != null)
            {
                _db.Set<Employee>().Remove(employee);
                await _db.SaveChangesAsync();
            }
        }

        public async Task<bool> EmployeeExistsAsync(int id)
        {
            return await Employees.AnyAsync(e => e.Id == id);
        }
    }
}
