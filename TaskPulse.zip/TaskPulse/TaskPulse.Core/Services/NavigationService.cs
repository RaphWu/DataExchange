﻿using System;
using Calin.TaskPulse.Contracts;

namespace Calin.TaskPulse.Services
{
    public class NavigationService : INavigationService
    {
        private readonly IRegionManager _regionManager;
        private readonly IViewManager _viewManager;

        public NavigationService(IRegionManager regionManager, IViewManager viewManager)
        {
            _regionManager = regionManager;
            _viewManager = viewManager;
        }

        public void Navigate(string regionName, Type viewType, bool alive = true)
        {
            var region = _regionManager.GetRegion(regionName);
            var view = _viewManager.Resolve(viewType, alive);
            region.ShowView(view);
        }

        public void Navigate<TView>(string regionName, bool alive = true) where TView : class
        {
            Navigate(regionName, typeof(TView), alive);
        }
    }
}
