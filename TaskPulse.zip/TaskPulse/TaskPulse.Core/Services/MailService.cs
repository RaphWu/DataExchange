﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using MailKit.Net.Smtp;
using MimeKit;
using Newtonsoft.Json;

namespace Calin.TaskPulse.Core.Services
{
    public class MailService : IMail
    {
        private Dictionary<string, List<Mail>> _mailList;

        public void Initialize()
        {
            try
            {
                string json = File.ReadAllText("郵件列表.json");
                if (string.IsNullOrWhiteSpace(json))
                    throw new FileNotFoundException("郵件列表.json 找不到或異常！");

                _mailList = JsonConvert.DeserializeObject<Dictionary<string, List<Mail>>>(json);
                if (_mailList == null)
                    throw new InvalidDataException("郵件列表.json 內容解析錯誤！");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <inheritdoc/>
        public void SendMail(string senderTitle, string workName, string subject, string contents)
        {
            if (_mailList != null && _mailList.ContainsKey(workName))
                SendMail(senderTitle, _mailList[workName], subject, contents);
        }

        /// <inheritdoc/>
        public void SendMail(string senderTitle, List<Mail> mailList, string subject, string contents)
        {
            if (mailList.Count == 0)
                return;

            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(senderTitle, "sys.automate@calin.com.tw"));

            foreach (var mail in mailList)
                message.To.Add(new MailboxAddress(mail.Name, mail.Email));

            message.Subject = subject;

            contents = Regex.Replace(contents,
                @"<table[^>]*>",
                "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse:collapse; border:1px solid #8c8c8c;'>",
                RegexOptions.IgnoreCase);
            contents = Regex.Replace(contents,
                @"<caption[^>]*>",
                "<caption style='font-weight:bold;margin-bottom:10px;'>",
                RegexOptions.IgnoreCase);
            contents = Regex.Replace(contents,
                @"<td[^>]*>",
                "<td style='border:1px solid #8c8c8c;'>",
                RegexOptions.IgnoreCase);

            string footer = $"<span style='color:#ba372a;'><em><strong>此信件由{senderTitle}自動發送，請勿回覆此信件！</strong></em></span>";

            var builder = new BodyBuilder();
            builder.HtmlBody = $"<p>{contents}</p><p>{footer}</p>";
            message.Body = builder.ToMessageBody();

            _ = Task.Run(async () =>
            {
                try
                {
                    using (var client = new SmtpClient())
                    {
                        await client.ConnectAsync("calin-mails0.calin.com.tw", 25, false);
                        //await client.AuthenticateAsync("sys.automate@calin.com.tw", "#Calin@70848492");
                        await client.SendAsync(message);
                        await client.DisconnectAsync(true);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            });


            //try
            //{
            //    //tsslMsg.Text = "";
            //    System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
            //    message.From = new System.Net.Mail.MailAddress("sys.automate@calin.com.tw");

            //    //讀取收件者
            //    foreach (var emp in _mailList[workName])
            //        message.To.Add(new System.Net.Mail.MailAddress(emp.Email, emp.Name));

            //    message.Subject = subject;
            //    message.IsBodyHtml = true;
            //    contents = Regex.Replace(contents,
            //        @"<table[^>]*>",
            //        "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse:collapse; border:1px solid #8c8c8c;'>",
            //        RegexOptions.IgnoreCase);
            //    contents = Regex.Replace(contents,
            //        @"<caption[^>]*>",
            //        "<caption style='font-weight:bold;margin-bottom:10px;'>",
            //        RegexOptions.IgnoreCase);
            //    contents = Regex.Replace(contents,
            //        @"<td[^>]*>",
            //        "<td style='border:1px solid #8c8c8c;'>",
            //        RegexOptions.IgnoreCase);

            //    message.Body = contents;

            //    //////////////設定郵箱smtp伺服器 埠//////////////
            //    System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
            //    smtp.Port = 25;
            //    smtp.Host = "calin-mails0.calin.com.tw";
            //    //   smtp.EnableSsl = true; //SSL安全連線
            //    smtp.UseDefaultCredentials = false;
            //    smtp.Credentials = new System.Net.NetworkCredential("sys.automate@calin.com.tw", "#Calin@70848492"); //自動寄信公用帳號

            //    //設定郵件傳送格式
            //    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            //    smtp.Send(message);
            //    smtp.Dispose();
            //    message.Dispose();
            //}
            //catch
            //{
            //    //tsslMsg.Text = "EMAIL位址錯誤: " + ex.Message;
            //}
            //finally
            //{

            //}
        }
    }
}
