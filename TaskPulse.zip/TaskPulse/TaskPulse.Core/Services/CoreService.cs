﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Services
{
    public class CoreService : ICore
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private bool _isInitialized = false;
        private CancellationTokenSource _syncCts;

        #endregion fields

        public CoreService(CoreContext coreContext,
                           CoreData coreData,
                           FieldName fieldName,
                           FieldTitle fieldTitle)
        {
            _context = coreContext;
            _coreData = coreData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;
        }

        /// <inheritdoc/>
        public async Task Initialize()
        {
            if (_isInitialized)
                return;

            await UpdateCoreDataCache();

            _fieldName.EmployeeId = nameof(Employee.EmployeeId);
            _fieldName.EmployeeName = nameof(Employee.EmployeeName);
            _fieldName.Department = nameof(Employee.Department);
            _fieldName.Title = nameof(Employee.Title);
            _fieldName.IsEngineer = nameof(Employee.IsEngineer);
            _fieldName.IsEngineerYes = nameof(Employee.IsEngineerYes);
            _fieldName.OnStaff = nameof(Employee.OnStaff);
            _fieldName.OnStaffString = nameof(Employee.OnStaffString);
            _fieldName.Email = nameof(Employee.Email);

            _fieldName.MachineCode = nameof(Machine.MachineCode);
            _fieldName.MachineCategory = nameof(MachineCategory.CategoryName);
            _fieldName.MachineType = nameof(MachineType.TypeName);
            _fieldName.MachineName = nameof(Machine.MachineName);
            _fieldName.MachineModel = nameof(Machine.MachineName.ModelName);
            _fieldName.Condition = nameof(Machine.Condition);
            _fieldName.ConditionName = nameof(Machine.ConditionName);
            _fieldName.Brand = nameof(Machine.Brand);
            _fieldName.BrandName = nameof(Machine.BrandName);
            _fieldName.Location = nameof(Machine.Location);
            _fieldName.LocationName = nameof(Machine.LocationName);
            _fieldName.Assets = nameof(Machine.Assets);
            _fieldName.AssetString = nameof(Machine.AssetString);
            _fieldName.AssetList = nameof(Machine.AssetList);
            _fieldName.SerialNumber = nameof(Machine.SerialNumber);
            _fieldName.Barcode = nameof(Machine.Barcode);
            _fieldName.Connected = nameof(Machine.Connected);
            _fieldName.ConnectedString = nameof(Machine.ConnectedString);
            _fieldName.Disposal = nameof(Machine.Disposal);
            _fieldName.DisposalString = nameof(Machine.DisposalString);
            _fieldName.Remark = nameof(Machine.Remark);
            _fieldName.Workstations = nameof(Machine.Workstations);

            _fieldTitle.Performer = "執行人員";

            _fieldTitle.Setup = EnumHelper.GetDescription<PageCode>(nameof(PageCode.Setup));
            _fieldTitle.ToolQuest = EnumHelper.GetDescription<PageCode>(nameof(PageCode.ToolQuest));
            _fieldTitle.MechaTrack = EnumHelper.GetDescription<PageCode>(nameof(PageCode.MechaTrack));
            _fieldTitle.MaintiFlow = EnumHelper.GetDescription<PageCode>(nameof(PageCode.MaintiFlow));

            _fieldTitle.EmployeeId = EnumHelper.GetDescription<Employee>(_fieldName.EmployeeId);
            _fieldTitle.EmployeeName = EnumHelper.GetDescription<Employee>(_fieldName.EmployeeName);
            _fieldTitle.Department = EnumHelper.GetDescription<Employee>(_fieldName.Department);
            _fieldTitle.Title = EnumHelper.GetDescription<Employee>(_fieldName.Title);
            _fieldTitle.IsEngineer = EnumHelper.GetDescription<Employee>(_fieldName.IsEngineer);
            _fieldTitle.OnStaff = EnumHelper.GetDescription<Employee>(_fieldName.OnStaff);
            _fieldTitle.Email = EnumHelper.GetDescription<Employee>(_fieldName.Email);

            _fieldTitle.MachineCategory = EnumHelper.GetDescription<MachineCategory>(_fieldName.MachineCategory);
            _fieldTitle.MachineType = EnumHelper.GetDescription<MachineType>(_fieldName.MachineType);
            _fieldTitle.MachineName = EnumHelper.GetDescription<Machine>(_fieldName.MachineName);
            _fieldTitle.MachineModel = EnumHelper.GetDescription<MachineName>(_fieldName.MachineModel);
            _fieldTitle.Condition = EnumHelper.GetDescription<Machine>(_fieldName.Condition);
            _fieldTitle.Brand = EnumHelper.GetDescription<Machine>(_fieldName.Brand);
            _fieldTitle.Location = EnumHelper.GetDescription<Machine>(_fieldName.Location);
            _fieldTitle.Assets = EnumHelper.GetDescription<Machine>(_fieldName.Assets);
            _fieldTitle.SerialNumber = EnumHelper.GetDescription<Machine>(_fieldName.SerialNumber);
            _fieldTitle.Barcode = EnumHelper.GetDescription<Machine>(_fieldName.Barcode);
            _fieldTitle.Connected = EnumHelper.GetDescription<Machine>(_fieldName.Connected);
            _fieldTitle.Disposal = EnumHelper.GetDescription<Machine>(_fieldName.Disposal);
            _fieldTitle.Remark = EnumHelper.GetDescription<Machine>(_fieldName.Remark);
            _fieldTitle.Workstations = EnumHelper.GetDescription<Machine>(_fieldName.Workstations);

            _isInitialized = true;
        }

        /********************
         * Control
         ********************/
        /// <inheritdoc/>
        public void CleanUpControls(Control.ControlCollection controls)
        {
            if (controls.Count == 0)
                return;

            foreach (Control c in controls)
                c.Dispose();
            controls.Clear();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        /********************
         * 取得 Core Data
         ********************/
        /***** Machine *****/

        /// <inheritdoc/>
        public int? GetMachineId(string machineString)
        {
            Machine ma = GetMachine(machineString);
            return ma?.Id ?? null;
        }

        /// <inheritdoc/>
        public Machine GetMachine(int id)
            => _coreData.Machines.FirstOrDefault(e => e.Id == id);

        /// <inheritdoc/>
        public Machine GetMachine(string MachineCode)
            => _coreData.Machines.FirstOrDefault(e => e.MachineCode == MachineCode);

        /***** User *****/

        /// <inheritdoc/>
        public Employee GetEmployee(int id)
            => _coreData.Employees.FirstOrDefault(e => e.Id == id);

        /// <inheritdoc/>
        public Employee GetEmployee(string employee)
            => _coreData.Employees.FirstOrDefault(e => employee.Contains(e.EmployeeId) || employee.Contains(e.EmployeeName));

        /***** Engineer *****/

        /// <inheritdoc/>
        public Employee GetEngineer(int id)
            => _coreData.Engineers.FirstOrDefault(e => e.Id == id);

        /// <inheritdoc/>
        public Employee GetEngineer(string employee)
            => _coreData.Engineers.FirstOrDefault(e => employee.Contains(e.EmployeeId) || employee.Contains(e.EmployeeName));

        /// <inheritdoc/>
        public List<Employee> GetEngineers(List<int> engineerIdList)
        {
            if (engineerIdList.Count == 0)
                return new List<Employee>();

            return _coreData.Employees
                .Where(e => e.IsEngineer && engineerIdList.Contains(e.Id))
                .ToList();
        }

        /// <inheritdoc/>
        public List<Employee> GetEngineers(string engineerNameList)
        {
            if (string.IsNullOrWhiteSpace(engineerNameList))
                return new List<Employee>();

            var emps = engineerNameList
                .Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())
                .Where(n => !string.IsNullOrEmpty(n))
                .ToList();
            return _coreData.Employees
                .Where(e => e.IsEngineer && emps.Contains(e.EmployeeName))
                .ToList();
        }

        /***** Model *****/

        /// <inheritdoc/>
        public Model GetModel(int modelId)
        {
            return _coreData.Models.FirstOrDefault(w => w.Id == modelId);
        }

        /// <inheritdoc/>
        public Model GetModel(string modelName)
        {
            return _coreData.Models.FirstOrDefault(w => w.ModelName == modelName);
        }

        /***** Workstation *****/

        /// <inheritdoc/>
        public Workstation GetWorkstation(int id)
        {
            return _coreData.Workstations.FirstOrDefault(w => w.Id == id);
        }

        /// <inheritdoc/>
        public Workstation GetWorkstation(string workstationName)
        {
            if (string.IsNullOrWhiteSpace(workstationName))
                return null;

            var wsName = workstationName
                .Split(new[] { '»', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())
                .Last(n => !string.IsNullOrEmpty(n));
            return _coreData.Workstations.FirstOrDefault(w => w.WorkstationName == wsName);

            //return _coreData.Workstations.FirstOrDefault(w => w.workstationName == workstationName);
        }

        /***** Model » Workstation *****/

        /// <inheritdoc/>
        public (Model, Workstation) GetModelWorkstation(string modelWorkstation)
        {
            if (string.IsNullOrWhiteSpace(modelWorkstation))
                return (null, null);

            var objs = modelWorkstation
                .Split(new[] { '»', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())
                .ToList();

            Model model;
            Workstation ws;
            switch (objs.Count)
            {
                case 1:
                    model = null;
                    ws = GetWorkstation(objs[0]);
                    break;
                case 2:
                    model = GetModel(objs[0]);
                    ws = GetWorkstation(objs[1]);
                    break;
                default:
                    model = null;
                    ws = null;
                    break;
            }
            return (model, ws);
        }

        /********************
         * Core Data
         ********************/
        /// <inheritdoc/>
        public async Task UpdateCoreDataCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            await UpdateEmployeesCache(false);
            await UpdateMachinesCache(false, false);
            await UpdateModelsCache(false, false);
            await UpdateWorkstationsCache(false, false);

            if (RecreateTabPage)
            {
                CreateMachineTabPage();
                CreateModelTabPage();
                CreateModelWsTabPage();
            }

            // 發佈資料更新通知
            if (SendUpdateNotification)
                WeakReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.AllCoreData));
        }

        /// <inheritdoc/>
        public async Task UpdateEmployeesCache(bool SendUpdateNotification = true)
        {
            _coreData.Employees = await _context.Employees
                .Where(x => x.OnStaff)
                .OrderBy(x => x.DepartmentId)
                .ThenBy(x => x.TitleId)
                .ThenBy(x => x.EmployeeId)
                .AsNoTracking()
                .ToListAsync();

            _coreData.Engineers = _coreData.Employees
                .Where(e => e.IsEngineer)
                .ToList();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                WeakReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Employee));
        }

        /********************
         * Cache Update
         ********************/
        /// <inheritdoc/>
        public async Task UpdateMachinesCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var tMachines = await _context.Machines
                .Include(m => m.MachineName.MachineType.Category)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Condition)
                .Where(m => m.Disposal == false)
                .AsNoTracking()
                .ToListAsync();
            _coreData.Machines = tMachines
                .Select(m => new { Original = m, Key = GetMachineSortKey(m.MachineCode) })
                .OrderBy(x => x.Key.Text)
                .ThenBy(x => x.Key.Number)
                .Select(x => x.Original)
                .ToList();

            _coreData.ClassifyMachines = _coreData.Machines
                .Where(m => m.MachineName != null &&
                            m.MachineName.MachineType != null &&
                            m.MachineName.MachineType.Category != null)
                .GroupBy(m => m.MachineName.MachineType.Category.CategoryName) // 外層 Category
                .OrderBy(g => g.First().MachineName.MachineType.Category.OrderNo)
                .ToDictionary(
                    categoryGroup => categoryGroup.Key, // CategoryName
                    categoryGroup => categoryGroup
                        .GroupBy(m => m.MachineName.MachineType.TypeName) // 內層 TypeName
                        .OrderBy(typeGroup => typeGroup.First().MachineName.MachineType.OrderNo)
                        .ToDictionary(
                            typeGroup => typeGroup.Key, // TypeName
                            typeGroup => typeGroup
                                .Select(m => new TabPageInfo
                                {
                                    Id = m.Id,
                                    Name = m.MachineCode // 或 MachineName.MachineName
                                })
                                .ToList()
                        )
                );

            // MachineCategories
            _coreData.MachineCategories = await _context.MachineCategories
                    .OrderBy(b => b.OrderNo)
                    .AsNoTracking()
                    .ToListAsync();

            // MachineTypes
            _coreData.MachineTypes = await _context.MachineTypes
                    .OrderBy(b => b.OrderNo)
                    .AsNoTracking()
                    .ToListAsync();

            if (RecreateTabPage)
                CreateMachineTabPage();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                WeakReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Machine));
        }

        /// <inheritdoc/>
        public async Task UpdateModelsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var tModels = await _context.Models
                .AsNoTracking()
                .ToListAsync();
            _coreData.Models = tModels
                .ToList()
                .Select(m => new { Original = m, Key = GetModelSortKey(m.ModelName) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();

            var sortedModels = SortModelNames(_coreData.Models.Select(m => m.ModelName).Distinct())
                .SelectMany(name => _coreData.Models.Where(m => m.ModelName == name))
                .ToList();
            _coreData.ClassifyModels = ClassifyItems(
                sortedModels,
                m => m.ModelName,
                "Model",
                m => m.Id,
                m => m.ModelName
            );

            if (RecreateTabPage)
            {
                CreateModelTabPage();
                CreateModelWsTabPage();
            }

            // 發佈資料更新通知
            if (SendUpdateNotification)
                WeakReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Model));
        }

        /// <inheritdoc/>
        public async Task UpdateWorkstationsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var tWorkstations = await _context.Workstations
                .Include(w => w.Model)
                .AsNoTracking()
                .ToListAsync();
            _coreData.Workstations = tWorkstations
                .Select(w => new { Original = w, Key = GetWorkstationSortKey(w) })
                .OrderBy(w => w.Key.ModelPriority)
                .ThenBy(w => w.Key.ModelNumber)
                .ThenBy(w => w.Key.OrderNo)
                .Select(w => w.Original)
                .ToList();

            var sortedWorkstations = SortWorkstations(_coreData.Workstations);
            _coreData.ClassifyWorkstations = ClassifyItems(
                sortedWorkstations,
                w => w.Model.ModelName,
                "Workstation",
                w => w.Id,
                w => w.WorkstationName
            );

            if (RecreateTabPage)
                CreateModelWsTabPage();
            //    CreateModelTabPage();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                WeakReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Workstation));
        }

        /********************
         * Utility
         ********************/
        /// <inheritdoc/>
        public IEnumerable<Machine> SortMachines(IEnumerable<Machine> machines)
        {
            return machines
                .Select(m => new { Machine = m, Key = GetMachineSortKey(m.MachineCode) })
                .OrderBy(x => x.Key.Text)
                .ThenBy(x => x.Key.Number)
                .Select(x => x.Machine);
        }

        /// <inheritdoc/>
        public List<string> SortModelNames(IEnumerable<string> modelNames)
        {
            return modelNames
                .Select(name => new { Original = name, Key = GetModelSortKey(name) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();
        }

        /// <inheritdoc/>
        public List<Workstation> SortWorkstations(IEnumerable<Workstation> workstations)
        {
            return workstations
                .OrderBy(w => GetWorkstationSortKey(w))
                .ToList();
        }

        /// <summary>
        /// 將資料列表轉換成 Classify 結構
        /// </summary>
        /// <typeparam name="T">資料類型，例如 Model 或 Workstation</typeparam>
        /// <param name="items">資料列表</param>
        /// <param name="categorySelector">第一層分類 key，例如 ModelName</param>
        /// <param name="typeName">第二層 Type 名稱，例如 "Model" 或 "Workstation"</param>
        /// <param name="idSelector">取得 Id 的函式</param>
        /// <param name="nameSelector">取得 Name 的函式</param>
        /// <returns>分類後的 Dictionary 結構</returns>
        private static Dictionary<string, Dictionary<string, List<TabPageInfo>>> ClassifyItems<T>(
            IEnumerable<T> items,
            Func<T, string> categorySelector,
            string typeName,
            Func<T, int> idSelector,
            Func<T, string> nameSelector)
        {
            return items
                .GroupBy(categorySelector)
                .ToDictionary(
                    g => g.Key,
                    g => new Dictionary<string, List<TabPageInfo>>
                    {
                        {
                            typeName,
                            g.Select(x => new TabPageInfo
                            {
                                Id = idSelector(x),
                                Type = typeName,
                                Name = nameSelector(x)
                            }).ToList()
                        }
                    }
                );
        }

        /********************
         * TabPage Cache
         ********************/
        //public async Task CreateMachineTabPage()
        //{
        //    await DebouncedSmartSyncAsync(
        //        _coreData.MachinesMultiTabPageCache,
        //        _coreData.ClassifyMachines,
        //        isMultiMode: true);

        //    await DebouncedSmartSyncAsync(
        //        _coreData.MachinesSingleTabPageCache,
        //        _coreData.ClassifyMachines,
        //        isMultiMode: false);
        //}

        ///// <inheritdoc/>
        //public async Task CreateModelTabPage()
        //{
        //    await DebouncedSmartSyncAsync(
        //        _coreData.ModelTabPageCache,
        //        _coreData.ClassifyModels,
        //        isMultiMode: false);
        //}

        ///// <inheritdoc/>
        //public async Task CreateModelWsTabPage()
        //{
        //    await DebouncedSmartSyncAsync(
        //        _coreData.ModelWsTabPageCache,
        //        _coreData.ClassifyWorkstations,
        //        isMultiMode: false);
        //}

        /********************
         * Common TabPage Cache Update Functions
         ********************/
        /// <summary>
        /// 比對兩個TabPage是否相同。
        /// </summary>
        private bool AreTabPageListsEqual(List<TabPage> oldList, List<TabPage> newList)
        {
            if (oldList.Count != newList.Count)
                return false;

            for (int i = 0; i < oldList.Count; i++)
            {
                if (oldList[i].Name != newList[i].Name)
                    return false;
            }
            return true;
        }

        /// <inheritdoc/>
        public void CreateMachineTabPage()
        {
            _coreData.MachinesMultiTabPageCache = new Dictionary<string, List<TabPage>>();
            _coreData.MachinesSingleTabPageCache = new Dictionary<string, List<TabPage>>();
            foreach (var mCategoryName in _coreData.ClassifyMachines.Keys)
            {
                List<TabPage> mmTabPages = new List<TabPage>();
                List<TabPage> msTabPages = new List<TabPage>();
                var mTypesDicts = _coreData.ClassifyMachines[mCategoryName];
                foreach (var mTypeName in mTypesDicts.Keys)
                {
                    var mmTabPage = new TabPage(mTypeName)
                    {
                        Name = mTypeName,
                        Font = CommonStyles.Font,
                    };
                    var mmFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    mmTabPage.Controls.Add(mmFlow);

                    var msTabPage = new TabPage(mTypeName)
                    {
                        Name = mTypeName,
                        Font = CommonStyles.Font,
                    };
                    var msFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    msTabPage.Controls.Add(msFlow);

                    var machineList = mTypesDicts[mTypeName];
                    List<UICheckBox> cbs = new List<UICheckBox>();
                    List<UIRadioButton> rbs = new List<UIRadioButton>();
                    foreach (var machine in machineList)
                    {
                        var cb = new UICheckBox
                        {
                            Text = machine.Name,
                            Name = machine.Name,
                            Checked = false,
                            AutoSize = false,
                            Width = 130,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            CheckBoxColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = machine.Id,
                                Category = mCategoryName,
                                Type = mTypeName,
                                Name = machine.Name,
                            }
                        };
                        cbs.Add(cb);

                        var rb = new UIRadioButton
                        {
                            GroupIndex = 1,
                            Text = machine.Name,
                            Name = machine.Name,
                            Checked = false,
                            AutoSize = false,
                            Width = 130,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            RadioButtonColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = machine.Id,
                                Category = mCategoryName,
                                Type = mTypeName,
                                Name = machine.Name,
                            }
                        };
                        rbs.Add(rb);
                    }
                    mmFlow.Controls.AddRange(cbs.ToArray());
                    mmTabPages.Add(mmTabPage);
                    msFlow.Controls.AddRange(rbs.ToArray());
                    msTabPages.Add(msTabPage);
                }
                _coreData.MachinesMultiTabPageCache.Add(mCategoryName, mmTabPages);
                _coreData.MachinesSingleTabPageCache.Add(mCategoryName, msTabPages);
            }
        }

        /// <inheritdoc/>
        public void CreateModelTabPage()
        {
            _coreData.ModelTabPageCache = new Dictionary<string, List<TabPage>>();
            foreach (var model in _coreData.Models)
            {
                //var wss = _coreData.Models
                //    .Where(w => w.Id == model.Id)
                //    .ToList();
                if (_coreData.Models.Count > 0)
                {
                    string moCategoryName = model.ModelName;
                    string moTypeName = _fieldTitle.ModelName;
                    List<TabPage> moTabPages = new List<TabPage>();
                    var moTabPage = new TabPage(moTypeName)
                    {
                        Name = moTypeName,
                        Font = CommonStyles.Font,
                    };
                    var moFlow = new UIFlowLayoutPanel()
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    moTabPage.Controls.Add(moFlow);

                    List<UIRadioButton> rbs = new List<UIRadioButton>();
                    foreach (var ml in _coreData.Models)
                    {
                        var rb = new UIRadioButton
                        {
                            GroupIndex = 1,
                            Text = ml.ModelName,
                            Name = ml.ModelName,
                            Checked = false,
                            AutoSize = false,
                            Width = 150,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            RadioButtonColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = ml.Id,
                                Category = moCategoryName,
                                Type = moTypeName,
                                Name = ml.ModelName,
                            }
                        };
                        rbs.Add(rb);
                    }
                    moFlow.Controls.AddRange(rbs.ToArray());
                    moTabPages.Add(moTabPage);
                    _coreData.ModelTabPageCache.Add(moCategoryName, moTabPages);
                }
            }
        }

        /// <inheritdoc/>
        public void CreateModelWsTabPage()
        {
            _coreData.ModelWsMultiTabPageCache = new Dictionary<string, List<TabPage>>();
            _coreData.ModelWsSingleTabPageCache = new Dictionary<string, List<TabPage>>();
            foreach (var model in _coreData.Models)
            {
                var wss = _coreData.Workstations
                    .Where(w => w.ModelId == model.Id)
                    .ToList();
                if (wss.Count > 0)
                {
                    string moCategoryName = model.ModelName;
                    string moTypeName = _fieldTitle.Workstation;
                    List<TabPage> mmTabPages = new List<TabPage>();
                    List<TabPage> msTabPages = new List<TabPage>();
                    var mmTabPage = new TabPage(moTypeName)
                    {
                        Name = moTypeName,
                        Font = CommonStyles.Font,
                    };
                    var mmFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    mmTabPage.Controls.Add(mmFlow);

                    var msTabPage = new TabPage(moTypeName)
                    {
                        Name = moTypeName,
                        Font = CommonStyles.Font,
                    };
                    var msFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    msTabPage.Controls.Add(msFlow);

                    List<UICheckBox> cbs = new List<UICheckBox>();
                    List<UIRadioButton> rbs = new List<UIRadioButton>();
                    foreach (var ws in wss)
                    {
                        var cb = new UICheckBox
                        {
                            Text = ws.WorkstationName,
                            Name = ws.WorkstationName,
                            Checked = false,
                            AutoSize = false,
                            Width = 150,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            CheckBoxColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = ws.Id,
                                Category = moCategoryName,
                                Type = moTypeName,
                                Name = ws.WorkstationName,
                            }
                        };
                        cbs.Add(cb);

                        var rb = new UIRadioButton
                        {
                            Text = ws.WorkstationName,
                            Name = ws.WorkstationName,
                            Checked = false,
                            AutoSize = false,
                            Width = 150,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            RadioButtonColor = CommonStyles.BackColor,
                            Tag = new SelectorInfo()
                            {
                                Id = ws.Id,
                                Category = moCategoryName,
                                Type = moTypeName,
                                Name = ws.WorkstationName,
                            }
                        };
                        rbs.Add(rb);
                    }
                    mmFlow.Controls.AddRange(cbs.ToArray());
                    mmTabPages.Add(mmTabPage);
                    msFlow.Controls.AddRange(rbs.ToArray());
                    msTabPages.Add(msTabPage);
                    _coreData.ModelWsMultiTabPageCache.Add(moCategoryName, mmTabPages);
                    _coreData.ModelWsSingleTabPageCache.Add(moCategoryName, msTabPages);
                }
            }
        }

        ///// <summary>
        ///// 智慧快取防抖，300ms內多次呼叫只跑最後一次
        ///// </summary>
        ///// <param name="cache">原 Cache。</param>
        ///// <param name="source">待更新資料來源。</param>
        ///// <param name="isMultiMode">true: 多選模式，使用 CheckBox。<br/>false: 單選模式，使用 RadioButtom。</param>
        ///// <param name="rebuildThreshold">變動比例。原 Cache 與資料來源差異比例超過此值，則執行完整重建，否則使用差異更新。</param>
        //public async Task DebouncedSmartSyncAsync(
        //    ConcurrentDictionary<string, List<TabPage>> cache,
        //    Dictionary<string, Dictionary<string, List<TabPageInfo>>> source,
        //    bool isMultiMode,
        //    double rebuildThreshold = 0.7)
        //{
        //    _syncCts?.Cancel();
        //    _syncCts = new CancellationTokenSource();

        //    try
        //    {
        //        await Task.Delay(300, _syncCts.Token);
        //        await SmartSyncCacheAsync(cache, source, isMultiMode, rebuildThreshold);
        //    }
        //    catch (TaskCanceledException) { }
        //}

        ///// <summary>
        ///// 智慧快取。根據變動比例選擇差異更新或完整重建，並在背景執行。
        ///// </summary>
        //public async Task SmartSyncCacheAsync(
        //    ConcurrentDictionary<string, List<TabPage>> cache,
        //    Dictionary<string, Dictionary<string, List<TabPageInfo>>> source,
        //    bool isMultiMode,
        //    double rebuildThreshold = 0.7)
        //{
        //    // 分析差異比例
        //    var currentKeys = cache.Keys.ToList();
        //    var newKeys = source.Keys.ToList();

        //    double changeRatio;
        //    int totalKeys = newKeys.Count;
        //    if (totalKeys == 0)
        //    {
        //        changeRatio = 1.0;
        //    }
        //    else
        //    {
        //        int changedOrMissingCount = newKeys.Count(k => !cache.ContainsKey(k));
        //        int removedCount = currentKeys.Count(k => !newKeys.Contains(k));
        //        int totalChanges = changedOrMissingCount + removedCount;
        //        changeRatio = (double)totalChanges / totalKeys;
        //    }

        //    // 背景處理資料差異
        //    var diffResult = await Task.Run(() =>
        //    {
        //        var toRemove = cache.Keys.Except(source.Keys).ToList();
        //        var updatedItems = new List<(string key, List<TabPageInfo> pageInfos)>();

        //        if (changeRatio >= rebuildThreshold)
        //        {
        //            // 大幅變動：重建整個 cache
        //            foreach (var category in source.Keys)
        //            {
        //                var newPageInfos = source[category].SelectMany(kv => kv.Value).ToList();
        //                updatedItems.Add((category, newPageInfos));
        //            }
        //        }
        //        else
        //        {
        //            // 小幅變動：只更新差異
        //            foreach (var category in source.Keys)
        //            {
        //                var newPageInfos = source[category].SelectMany(kv => kv.Value).ToList();
        //                if (!cache.TryGetValue(category, out var oldPages) ||
        //                    !AreTabPageInfosEqual(oldPages, newPageInfos))
        //                {
        //                    updatedItems.Add((category, newPageInfos));
        //                }
        //            }
        //        }

        //        return (toRemove, updatedItems);
        //    });

        //    // UI 執行緒生成 TabPage 控件
        //    WinFormExtension.RunOnUIThread(() =>
        //    {
        //        // 移除多餘
        //        foreach (var key in diffResult.toRemove)
        //            cache.TryRemove(key, out _);

        //        // 更新或新增
        //        foreach (var (key, pageInfos) in diffResult.updatedItems)
        //        {
        //            var tabPages = pageInfos.Select(pi =>
        //            {
        //                var tab = new TabPage(pi.Name);
        //                foreach (var ctrlData in pi.ControlsData)
        //                {
        //                    // 這裡根據 DTO 生成 Control
        //                    var c = CreateControlFromData(ctrlData);
        //                    tab.Controls.Add(c);
        //                }
        //                return tab;
        //            }).ToList();

        //            cache.AddOrUpdate(key, tabPages, (k, oldVal) => tabPages);
        //        }
        //    });

        //    // 背景執行實際同步
        //    await Task.Run(() =>
        //    {
        //        if (changeRatio >= rebuildThreshold)
        //        {
        //            // 大幅變動，執行完整重建
        //            var newCache = new ConcurrentDictionary<string, List<TabPage>>();
        //            foreach (var category in source.Keys)
        //            {
        //                var newTabs = CreateTabPages(category, isMultiMode);
        //                newCache.TryAdd(category, newTabs);
        //            }
        //            WinFormExtension.RunOnUIThread(() =>
        //            {
        //                cache.Clear();
        //                foreach (var kvp in newCache)
        //                    cache.TryAdd(kvp.Key, kvp.Value);
        //            });
        //        }
        //        else
        //        {
        //            // 小幅變動，執行差異更新
        //            var toRemove = cache.Keys.Except(source.Keys).ToList();
        //            var updatedItems = new List<(string key, List<TabPage> value)>();
        //            foreach (var category in source.Keys)
        //            {
        //                var newTabs = CreateTabPages(category, isMultiMode);
        //                if (!cache.TryGetValue(category, out var oldTabs) ||
        //                    !AreTabPageListsEqual(oldTabs, newTabs))
        //                {
        //                    updatedItems.Add((category, newTabs));
        //                }
        //            }
        //            WinFormExtension.RunOnUIThread(() =>
        //            {
        //                foreach (var (key, value) in updatedItems)
        //                    cache.AddOrUpdate(key, value, (k, oldVal) => value);

        //                foreach (var key in toRemove)
        //                    cache.TryRemove(key, out _);
        //            });
        //        }
        //    });
        //}

        //// 判斷 TabPage 是否一致（可依實際需求調整）
        //private bool AreTabPageInfosEqual(List<TabPage> tabs, List<TabPageInfo> infos)
        //{
        //    if (tabs.Count != infos.Count) return false;
        //    for (int i = 0; i < tabs.Count; i++)
        //    {
        //        if (tabs[i].Text != infos[i].Name) return false;
        //    }
        //    return true;
        //}

        ///// <summary>
        ///// 建立 TabPage 列表。
        ///// </summary>
        ///// <param name="categoryName">第一層分類。</param>
        ///// <param name="isMultiMode">true: 多選模式，使用 CheckBox。<br/>false: 單選模式，使用 RadioButtom。</param>
        ///// <returns>TabPage 列表。</returns>
        //private List<TabPage> CreateTabPages(string categoryName, bool isMultiMode)
        //{
        //    var tabPages = new List<TabPage>();
        //    if (!_coreData.ClassifyMachines.TryGetValue(categoryName, out var typeDicts))
        //        return tabPages;

        //    foreach (var mTypeName in typeDicts.Keys)
        //    {
        //        var tabPage = new TabPage(mTypeName)
        //        {
        //            Name = mTypeName,
        //            Font = CommonStyles.Font,
        //        };

        //        var flow = new UIFlowLayoutPanel
        //        {
        //            Dock = DockStyle.Fill,
        //            AutoScroll = true,
        //        };
        //        tabPage.Controls.Add(flow);

        //        var items = typeDicts[mTypeName];
        //        foreach (var item in items)
        //        {
        //            Control ctrl;
        //            if (isMultiMode)
        //                ctrl = CreateCheckBox(item, categoryName, mTypeName);
        //            else
        //                ctrl = CreateRadioButton(item, categoryName, mTypeName);

        //            flow.Controls.Add(ctrl);
        //        }

        //        tabPages.Add(tabPage);
        //    }
        //    return tabPages;
        //}

        ///// <summary>
        ///// 建立 CheckBox Control。
        ///// </summary>
        ///// <param name="item">要建立的 Control 資訊。</param>
        ///// <param name="categoryName">所屬第一層分類名稱。</param>
        ///// <param name="mTypeName">所屬第二層分類名稱。</param>
        ///// <returns>CheckBox。</returns>
        //private UICheckBox CreateCheckBox(TabPageInfo item, string categoryName, string mTypeName)
        //{
        //    return new UICheckBox
        //    {
        //        Text = item.Name,
        //        Name = item.Name,
        //        Checked = false,
        //        AutoSize = false,
        //        Width = 130,
        //        Font = CommonStyles.Font,
        //        Style = UIStyle.Inherited,
        //        CheckBoxColor = CommonStyles.BackColor,
        //        Tag = new SelectorInfo()
        //        {
        //            Id = item.Id,
        //            Category = categoryName,
        //            Type = mTypeName,
        //            Name = item.Name,
        //        }
        //    };
        //}

        ///// <summary>
        ///// 建立 RadioButton Control。
        ///// </summary>
        ///// <param name="item">要建立的 Control 資訊。</param>
        ///// <param name="categoryName">所屬第一層分類名稱。</param>
        ///// <param name="mTypeName">所屬第二層分類名稱。</param>
        ///// <returns>RadioButton。</returns>
        //private UIRadioButton CreateRadioButton(TabPageInfo item, string categoryName, string mTypeName)
        //{
        //    return new UIRadioButton
        //    {
        //        GroupIndex = 1,
        //        Text = item.Name,
        //        Name = item.Name,
        //        Checked = false,
        //        AutoSize = false,
        //        Width = 130,
        //        Font = CommonStyles.Font,
        //        Style = UIStyle.Inherited,
        //        RadioButtonColor = CommonStyles.BackColor,
        //        Tag = new SelectorInfo()
        //        {
        //            Id = item.Id,
        //            Category = categoryName,
        //            Type = mTypeName,
        //            Name = item.Name,
        //        }
        //    };
        //}

        /********************
         * private Common Functions
         ********************/
        /*****
         * 英文開頭	                  ^([A-Za-z]+)-?(\d+)?$
         * 英文 + 中文 + 任意文字開頭   ^([^\d\-]+)-?(\d+)?$
         * 前綴可包含任意非數字字元     ^([^\d]+?)-?(\d+)?$
        *****/
        /// <summary>
        /// MachineCode 的共用排序規則。支援 A-1, A1, SS12, B-05, 等格式。
        /// </summary>
        private (string Text, int Number) GetMachineSortKey(string MachineCode)
        {
            if (string.IsNullOrWhiteSpace(MachineCode))
                return ("", 0);

            var match = Regex.Match(MachineCode, @"^([^\d]+?)-?(\d+)?$", RegexOptions.IgnoreCase);
            if (match.Success)
            {
                string text = match.Groups[1].Value.Trim();
                int number = 0;
                if (match.Groups[2].Success && !string.IsNullOrEmpty(match.Groups[2].Value))
                    int.TryParse(match.Groups[2].Value, out number);
                return (text, number);
            }

            return (MachineCode.Trim(), 0);
        }

        /// <summary>
        /// Model 的共用排序規則。
        /// </summary>
        private (bool IsThreeDigits, int SortKey) GetModelSortKey(string modelName)
        {
            var prefix = modelName.Split('-')[0];
            bool isThreeDigits = Regex.IsMatch(prefix, @"^\d{3}$");
            int sortKey = int.TryParse(prefix, out var n) ? n : int.MaxValue;
            return (isThreeDigits, sortKey);
        }

        /// <summary>
        /// workstationName 的共用排序規則。
        /// </summary>
        private (int ModelPriority, int ModelNumber, int OrderNo) GetWorkstationSortKey(Workstation w)
        {
            var modelName = w.Model?.ModelName ?? "";
            var key = GetModelSortKey(modelName);

            int modelPriority = key.IsThreeDigits ? 0 : 1;
            int modelNumber = key.SortKey;
            int orderNo = w.OrderNo;

            return (modelPriority, modelNumber, orderNo);
        }
    }
}


///// <inheritdoc/>
//public void CreateMachineTabPage()
//{
//    _coreData.MachinesMultiTabPageCache = new ConcurrentDictionary<string, List<TabPage>>();
//    _coreData.MachinesSingleTabPageCache = new ConcurrentDictionary<string, List<TabPage>>();
//    foreach (var mCategoryName in _coreData.ClassifyMachines.Keys)
//    {
//        List<TabPage> mmTabPages = new List<TabPage>();
//        List<TabPage> msTabPages = new List<TabPage>();
//        var mTypesDicts = _coreData.ClassifyMachines[mCategoryName];
//        foreach (var mTypeName in mTypesDicts.Keys)
//        {
//            var mmTabPage = new TabPage(mTypeName)
//            {
//                Name = mTypeName,
//                Font = CommonStyles.Font,
//            };
//            var mmFlow = new UIFlowLayoutPanel
//            {
//                Dock = DockStyle.Fill,
//                AutoScroll = true,
//            };
//            mmTabPage.Controls.Add(mmFlow);

//            var msTabPage = new TabPage(mTypeName)
//            {
//                Name = mTypeName,
//                Font = CommonStyles.Font,
//            };
//            var msFlow = new UIFlowLayoutPanel
//            {
//                Dock = DockStyle.Fill,
//                AutoScroll = true,
//            };
//            msTabPage.Controls.Add(msFlow);

//            var machineList = mTypesDicts[mTypeName];
//            List<UICheckBox> cbs = new List<UICheckBox>();
//            List<UIRadioButton> rbs = new List<UIRadioButton>();
//            foreach (var machine in machineList)
//            {
//                var cb = new UICheckBox
//                {
//                    Text = machine.Name,
//                    Name = machine.Name,
//                    Checked = false,
//                    AutoSize = false,
//                    Width = 130,
//                    Font = CommonStyles.Font,
//                    Style = UIStyle.Inherited,
//                    CheckBoxColor = CommonStyles.BackColor,
//                    Tag = new SelectorInfo()
//                    {
//                        Id = machine.Id,
//                        Category = mCategoryName,
//                        Type = mTypeName,
//                        Name = machine.Name,
//                    }
//                };
//                cbs.Add(cb);

//                var rb = new UIRadioButton
//                {
//                    GroupIndex = 1,
//                    Text = machine.Name,
//                    Name = machine.Name,
//                    Checked = false,
//                    AutoSize = false,
//                    Width = 130,
//                    Font = CommonStyles.Font,
//                    Style = UIStyle.Inherited,
//                    RadioButtonColor = CommonStyles.BackColor,
//                    Tag = new SelectorInfo()
//                    {
//                        Id = machine.Id,
//                        Category = mCategoryName,
//                        Type = mTypeName,
//                        Name = machine.Name,
//                    }
//                };
//                rbs.Add(rb);
//            }
//            mmFlow.Controls.AddRange(cbs.ToArray());
//            mmTabPages.Add(mmTabPage);
//            msFlow.Controls.AddRange(rbs.ToArray());
//            msTabPages.Add(msTabPage);
//        }
//        _coreData.MachinesMultiTabPageCache[mCategoryName] = mmTabPages;
//        _coreData.MachinesSingleTabPageCache.AddOrUpdate(mCategoryName, msTabPages);
//    }
//}



///// <inheritdoc/>
//public async Task CreateModelTabPage()
//{
//    _coreData.ModelTabPageCache = new ConcurrentDictionary<string, List<TabPage>>();
//    foreach (var model in _coreData.Models)
//    {
//        //var wss = _coreData.Models
//        //    .Where(w => w.Id == model.Id)
//        //    .ToList();
//        if (_coreData.Models.Count > 0)
//        {
//            string moCategoryName = model.ModelName;
//            string moTypeName = _fieldTitle.Model;
//            List<TabPage> moTabPages = new List<TabPage>();
//            var moTabPage = new TabPage(moTypeName)
//            {
//                Name = moTypeName,
//                Font = CommonStyles.Font,
//            };
//            var moFlow = new UIFlowLayoutPanel()
//            {
//                Dock = DockStyle.Fill,
//                AutoScroll = true,
//            };
//            moTabPage.Controls.Add(moFlow);

//            List<UIRadioButton> rbs = new List<UIRadioButton>();
//            foreach (var ml in _coreData.Models)
//            {
//                var rb = new UIRadioButton
//                {
//                    GroupIndex = 1,
//                    Text = ml.ModelName,
//                    Name = ml.ModelName,
//                    Checked = false,
//                    AutoSize = false,
//                    Width = 150,
//                    Font = CommonStyles.Font,
//                    Style = UIStyle.Inherited,
//                    RadioButtonColor = CommonStyles.BackColor,
//                    Tag = new SelectorInfo()
//                    {
//                        Id = ml.Id,
//                        Category = moCategoryName,
//                        Type = moTypeName,
//                        Name = ml.ModelName,
//                    }
//                };
//                rbs.Add(rb);
//            }
//            moFlow.Controls.AddRange(rbs.ToArray());
//            moTabPages.Add(moTabPage);
//            _coreData.ModelTabPageCache.Add(moCategoryName, moTabPages);
//        }
//    }
//}



///// <inheritdoc/>
//public void CreateModelWsTabPage()
//{
//    _coreData.ModelWsTabPageCache = new Dictionary<string, List<TabPage>>();
//    foreach (var model in _coreData.Models)
//    {
//        var wss = _coreData.Workstations
//            .Where(w => w.ModelId == model.Id)
//            .ToList();
//        if (wss.Count > 0)
//        {
//            string moCategoryName = model.ModelName;
//            string moTypeName = _fieldTitle.Workstation;
//            List<TabPage> moTabPages = new List<TabPage>();
//            var moTabPage = new TabPage(moTypeName)
//            {
//                Name = moTypeName,
//                Font = CommonStyles.Font,
//            };
//            var moFlow = new UIFlowLayoutPanel
//            {
//                Dock = DockStyle.Fill,
//                AutoScroll = true,
//            };
//            moTabPage.Controls.Add(moFlow);

//            List<UIRadioButton> rbs = new List<UIRadioButton>();
//            foreach (var ws in wss)
//            {
//                var rb = new UIRadioButton
//                {
//                    Text = ws.WorkstationName,
//                    Name = ws.WorkstationName,
//                    Checked = false,
//                    AutoSize = false,
//                    Width = 150,
//                    Font = CommonStyles.Font,
//                    Style = UIStyle.Inherited,
//                    RadioButtonColor = CommonStyles.BackColor,
//                    Tag = new SelectorInfo()
//                    {
//                        Id = ws.Id,
//                        Category = moCategoryName,
//                        Type = moTypeName,
//                        Name = ws.WorkstationName,
//                    }
//                };
//                rbs.Add(rb);
//            }
//            moFlow.Controls.AddRange(rbs.ToArray());
//            moTabPages.Add(moTabPage);
//            _coreData.ModelWsTabPageCache.Add(moCategoryName, moTabPages);
//        }
//    }
//}