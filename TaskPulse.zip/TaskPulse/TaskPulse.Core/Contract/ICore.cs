﻿using System.Collections.Generic;

namespace Calin.TaskPulse.Core.Contract
{
    public interface ICore
    {
        /// <summary>
        /// 排序機台編號。
        /// </summary>
        /// <param name="machineIds">機台編號列表。</param>
        /// <returns>排序完成的機台編號。</returns>
        /// <remarks>排序規則：<br/>1. 不考慮 '-' 符號。<br/>2. 先按前方英文字母排序。<br/>3. 再依後方數字小到大排序。</remarks>
        List<string> SortMachineId(List<string> machineIds);

        /// <summary>
        /// 更新員工名冊。
        /// </summary>
        void UpdateCoreDataFromDb();

        /// <summary>
        /// CoreService 初始化。
        /// </summary>
        void Initialize();
    }
}
