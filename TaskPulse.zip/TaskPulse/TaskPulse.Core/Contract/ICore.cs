﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contract
{
    public interface ICore
    {
        /// <summary>
        /// CoreService 初始化。
        /// </summary>
        Task Initialize();

        /********************
         * 從 Cache 取得 Core Data
         ********************/

        /***** Machine *****/

        /// <summary>
        /// 從資料庫傳回機台編號對應機台的 Id。
        /// </summary>
        /// <param name="machineString">機台名稱字串，分隔符號可用 '»' 或 ',' 或 ';'，機台編號須放在最後。</param>
        /// <returns>機台 Id。</returns>
        int? GetMachineId(string machineString);

        /// <summary>
        /// 以機台資料庫 Id 取得 Machine 物件。
        /// </summary>
        /// <param name="id">機台 Id。</param>
        /// <returns><see cref="Machine"/> 物件。</returns>
        Machine GetMachine(int id);

        /// <summary>
        /// 以機台名稱取得 Machine 物件。
        /// </summary>
        /// <param name="MachineId">機台名稱。</param>
        /// <returns><see cref="Machine"/> 物件。</returns>
        Machine GetMachine(string MachineId);

        /***** Employee *****/

        /// <summary>
        /// 以員工資料庫 Id 取得 Employee 物件。
        /// </summary>
        /// <param name="id">員工 Id。</param>
        /// <returns><see cref="Employee"/> 物件。</returns>
        Employee GetEmployee(int id);

        /// <summary>
        /// 以員工工號或姓名取得 Employee 物件。
        /// </summary>
        /// <param name="employee">員工工號或姓名。</param>
        /// <returns><see cref="Calin.TaskPulse.Entity.Core.Employee"/> 物件。</returns>
        Employee GetEmployee(string employee);

        /***** Engineer *****/

        /// <summary>
        /// 以維護工程師資料庫 Id 取得 Employee 物件。
        /// </summary>
        /// <param name="id">維護工程師 Id。</param>
        /// <returns><see cref="Employee"/> 物件。</returns>
        Employee GetEngineer(int id);

        /// <summary>
        /// 以維護工程師工號或姓名取得 Employee 物件。
        /// </summary>
        /// <param name="employee">維護工程師工號或姓名。</param>
        /// <returns><see cref="Calin.TaskPulse.Entity.Core.Employee"/> 物件。</returns>
        Employee GetEngineer(string employee);

        /// <summary>
        /// 將維護工程師資料庫 Id 拆解後，返回 EngineerString List。
        /// </summary>
        /// <param name="engineerIdList">維護工程師資料庫 Id。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>EngineerString List。</returns>
        List<Employee> GetEngineers(List<int> engineerIdList);

        /// <summary>
        /// 將維護工程師姓名字串拆解後，返回 EngineerString。
        /// </summary>
        /// <param name="engineerNameList">維護工程師字串，分隔符號可用 ',' 或 ';' 或 '\n'。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>EngineerString 的資料庫格式資料。</returns>
        List<Employee> GetEngineers(string engineerNameList);

        /***** WorkstationName *****/

        /// <summary>
        /// 以工站資料庫 Id 取得 Workstation 物件。
        /// </summary>
        /// <param name="id">工站資料庫 Id。</param>
        /// <returns><see cref="Workstation"/> 物件。</returns>
        Workstation GetWorkstation(int id);

        /***** Model *****/

        /// <summary>
        /// 以機種資料庫 Id 取得 Model 物件。
        /// </summary>
        /// <param name="id">機種資料庫 Id。</param>
        /// <returns><see cref="Model"/> 物件。</returns>
        Model GetModel(int id);

        /********************
         * Core Data Cache
         ********************/
        /// <summary>
        /// 從資料庫更新全部核心資料。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送全部更新通知？</param>
        /// <param name="RecreateTabPage">更新後是否要重建全部 TabPage Cache？</param>
        Task UpdateCoreDataCache(bool SendUpdateNotification = true, bool RecreateTabPage = true);

        /// <summary>
        /// 從資料庫更新員工名冊快取。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送更新通知？</param>
        Task UpdateEmployeesCache(bool SendUpdateNotification = true);

        /// <summary>
        /// 從資料庫更新機台清單快取。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送更新通知？</param>
        /// <param name="RecreateTabPage">更新後是否要重建 TabPage Cache？</param>
        Task UpdateMachinesCache(bool SendUpdateNotification = true, bool RecreateTabPage = true);

        /// <summary>
        /// 從資料庫更新機種清單快取。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送更新通知？</param>
        /// <param name="RecreateTabPage">更新後是否要重建 TabPage Cache？</param>
        Task UpdateModelsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true);

        /// <summary>
        /// 從資料庫更新工站清單快取。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送更新通知？</param>
        /// <param name="RecreateTabPage">更新後是否要重建 TabPage Cache？</param>
        Task UpdateWorkstationsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true);

        /********************
         * TabPage注入
         ********************/
        /// <summary>
        /// 依機台分類建立 TabPage 並注入 Autofac。
        /// </summary>
        void CreateMachineTabPage();

        /// <summary>
        /// 依機種及工站的分類建立 TabPage 並注入 Autofac，每個機種各自一頁。
        /// </summary>
        void CreateModelTabPage();

        /// <summary>
        /// 
        /// </summary>
        void CreateModelWsTabPage();

        /********************
         * Utility
         ********************/
        /// <summary>
        /// 排序機台。
        /// </summary>
        /// <param name="machineIds">機台列表。</param>
        /// <returns>排序完成的機台列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Machines"/></remarks>
        List<string> SortMachineId(IEnumerable<string> machineIds);

        /// <summary>
        /// 排序機種。
        /// </summary>
        /// <param name="machineIds">機種列表。</param>
        /// <returns>排序完成的機種列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Models"/></remarks>
        List<string> SortModelNames(IEnumerable<string> modelNames);

        /// <summary>
        /// 排序工站。
        /// </summary>
        /// <param name="workstations">工站列表。</param>
        /// <returns>排序完成的工站列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Workstations"/></remarks>
        List<Workstation> SortWorkstations(IEnumerable<Workstation> workstations);

        /// <summary>
        /// 移除並釋放集合中所有的控制項。
        /// </summary>
        /// <param name="controls">控制項集合。</param>
        void CleanUpControls(Control.ControlCollection controls);
    }
}
