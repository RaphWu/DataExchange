﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contract
{
    public interface ICore
    {
        /// <summary>
        /// CoreService 初始化。
        /// </summary>
        Task Initialize();

        /********************
         * Core Data
         ********************/
        /// <summary>
        /// 從資料庫更新全部核心資料。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送全部更新通知？</param>
        /// <param name="RecreateTabPage">更新後是否要重建全部 TabPage Cache？</param>
        Task UpdateCoreDataCache(bool SendUpdateNotification = true, bool RecreateTabPage = true);

        /// <summary>
        /// 從資料庫更新員工名冊快取。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送更新通知？</param>
        Task UpdateEmployeesCache(bool SendUpdateNotification = true);

        /// <summary>
        /// 從資料庫更新機台清單快取。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送更新通知？</param>
        /// <param name="RecreateTabPage">更新後是否要重建 TabPage Cache？</param>
        Task UpdateMachinesCache(bool SendUpdateNotification = true, bool RecreateTabPage = true);

        /// <summary>
        /// 從資料庫更新機種清單快取。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送更新通知？</param>
        /// <param name="RecreateTabPage">更新後是否要重建 TabPage Cache？</param>
        Task UpdateModelsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true);

        /// <summary>
        /// 從資料庫更新工站清單快取。
        /// </summary>
        /// <param name="SendUpdateNotification">更新後是否要發送更新通知？</param>
        /// <param name="RecreateTabPage">更新後是否要重建 TabPage Cache？</param>
        Task UpdateWorkstationsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true);

        /********************
         * TabPage注入
         ********************/
        /// <summary>
        /// 依機台分類建立 TabPage 並注入 Autofac。
        /// </summary>
        void CreateMachineTabPage();

        /// <summary>
        /// 依機種及工站的分類建立 TabPage 並注入 Autofac，每個機種各自一頁。
        /// </summary>
        void CreateModelTabPage();

        /********************
         * Utility
         ********************/
        /// <summary>
        /// 排序機台。
        /// </summary>
        /// <param name="machineIds">機台列表。</param>
        /// <returns>排序完成的機台列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Machines"/></remarks>
        List<string> SortMachineId(IEnumerable<string> machineIds);

        /// <summary>
        /// 排序機種。
        /// </summary>
        /// <param name="machineIds">機種列表。</param>
        /// <returns>排序完成的機種列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Models"/></remarks>
        List<string> SortModelNames(IEnumerable<string> modelNames);

        /// <summary>
        /// 排序工站。
        /// </summary>
        /// <param name="workstations">工站列表。</param>
        /// <returns>排序完成的工站列表。</returns>
        /// <remarks>排序規則：詳見 <see cref="CoreData.Workstations"/></remarks>
        List<Workstation> SortWorkstations(IEnumerable<Workstation> workstations);

        /// <summary>
        /// 移除並釋放集合中所有的控制項。
        /// </summary>
        /// <param name="controls">控制項集合。</param>
        void CleanUpControls(Control.ControlCollection controls);
    }
}
