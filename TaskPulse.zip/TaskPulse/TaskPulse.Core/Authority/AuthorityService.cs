﻿/*
 * Active Directory認證
 */

using System;
using System.Collections.Generic;
using System.DirectoryServices.Protocols;
using System.Linq;
using System.Net;
using System.Security;
using System.Windows.Forms;
using Calin.CSharp.Extensions;
using Calin.CSharp.Helpers;
using Calin.CSharp.Security;
using Calin.TaskPulse.Core.Authority.Constants;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Service;
using Calin.TaskPulse.Core.Views;
using CommunityToolkit.Mvvm.Messaging;
using Newtonsoft.Json;

namespace Calin.TaskPulse.Core.Authority
{
    /// <summary>
    /// 權限管理。
    /// </summary>
    public class AuthorityService : IAuthority
    {
        private readonly object _dbLocker = new object();
        private readonly CoreContext _context;
        private CurrentAuthority _ca;
        private AuthorityParameters _ap;
        private readonly DialogService _dialogService;

        /// <summary>
        /// 所有User的授權表。
        /// </summary>
        private static List<AuthorizationDefine> _authorizations = new List<AuthorizationDefine>();

        private System.Timers.Timer InputDetector { get; set; }

        // User = ADMIN => 管理員
        // User = 空白 => Guest
        private readonly string _userName_Admin = UserGroup.Admin.ToString();
#if DEBUG
        private readonly string _adminPassword = "D41D8CD98F00B204E9800998ECF8427E"; // 空密碼
#else
        private readonly string _adminPassword = "3E37BDBE31120EEAF5F5227C65E054B4"; // Calin880819
#endif
        private readonly string _guestPassword = "D41D8CD98F00B204E9800998ECF8427E"; // 空密碼
        private readonly string _publickey = "Calin";
        private readonly string _secretkey = "CalinDevelopment";

        /********************
         * ctor
         ********************/
        public AuthorityService(CoreContext context, CurrentAuthority ad, AuthorityParameters ap, DialogService dialogService)
        {
            _context = context;
            _ca = ad;
            _ap = ap;
            _dialogService = dialogService;

            //ReadFromDb();
            //var ah = context.Set<DepartmentAuthorization>();
            //if (ah.ToList().FindIndex(x => x.User == "客") == -1)
            //{
            //    ah.Add(new DepartmentAuthorization()
            //    {
            //        User = GuestTitle,
            //        Password = _guestPassword,
            //        AuthorizedList = EncryptTableToString(GetDefaultAuthorization(UserGroup.Guest))
            //    });
            //}

            //UpdateUserNameList();

            // 鍵盤與滑鼠idle偵測
            InputDetector = new System.Timers.Timer();
        }

        /********************   
         * Property
         ********************/
        public CurrentAuthority AuthorityData => _ca;
        public string AdminTitle => EnumHelper.GetDescription(UserGroup.Admin);
        public string GuestTitle => EnumHelper.GetDescription(UserGroup.Guest);

        //        /********************
        //         * Database
        //         ********************/
        //        /// <inheritdoc/>
        //        public bool WriteToDb(bool writeTable, bool writeParam)
        //        {
        //            lock (_dbLocker)
        //            {
        //                using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
        //                {
        //                    if (conn != null)
        //                    {
        //                        using (var tran = conn.BeginTransaction())
        //                        {
        //                            try
        //                            {
        //                                if (writeTable)
        //                                    conn.Update<List<AuthorizationDefine>>(_authorizations, transaction: tran);
        //                                if (writeParam)
        //                                    conn.Update<AuthorityParametersDefine>(_ap.Params, transaction: tran);
        //                                tran.Commit();
        //                                return true;
        //                            }
        //                            catch (Exception ex)
        //                            {
        //                                tran.Rollback();
        //                                string errMsg = $"權限資料庫寫入失敗 {DBbase.DbName_System}\n{ex.Message}";
        //                                //Log.Fatal(ex, errMsg);
        //                                _ = MessageBox.Show(errMsg,
        //                                                    MessageList.DatabaseErrorTitle,
        //                                                    MessageBoxButtons.OK,
        //                                                    MessageBoxIcon.Error);
        //                            }
        //                        }
        //                    }
        //                    return false;
        //                }
        //            }
        //        }

        //        /// <inheritdoc/>
        //        public bool ReadFromDb()
        //        {
        //            lock (_dbLocker)
        //            {
        //                using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
        //                {
        //                    if (conn != null)
        //                    {
        //                        using (var tran = conn.BeginTransaction())
        //                        {
        //                            try
        //                            {
        //                                if (!SQLiteHelper.IsTableExist(conn, DB_Authority.TableName_Authority))
        //                                {
        //                                    SQLiteHelper.CreateTable(conn, DB_Authority.CreateTableSQL_Authority);
        //                                    //conn.Insert(new AuthorityParameters { Key = 1, InputDetectInterval = 5 });
        //                                    string sql = $@"INSERT INTO {DB_Authority.TableName_Authority} (Key, InputDetectInterval) VALUES (@Key, @InputDetectInterval);";
        //                                    conn.Execute(sql, new AuthorityParametersDefine()
        //                                    {
        //                                        Key = 1,
        //                                        InputDetectInterval = 5,
        //                                    }, transaction: tran);
        //                                }
        //                                _ap.Params = conn.Get<AuthorityParametersDefine>(1, transaction: tran);

        //                                if (!SQLiteHelper.IsTableExist(conn, DB_Authority.TableName_Authorization))
        //                                {
        //                                    SQLiteHelper.CreateTable(conn, DB_Authority.CreateTableSQL_Authorization);
        //                                    string sql = $@"INSERT INTO {DB_Authority.TableName_Authorization}
        //(Key, OrderNo, User, Password, DepartmentAuthorization)
        //VALUES (@Key, @OrderNo, @User, @Password, @DepartmentAuthorization);";
        //                                    conn.Execute(sql, new AuthorizationDefine()
        //                                    {
        //                                        Key = (int)UserGroup.Guest,
        //                                        OrderNo = (int)UserGroup.Guest,
        //                                        User = GuestTitle,
        //                                        Password = _guestPassword,
        //                                        Authorization = EncryptTableToString(GetDefaultAuthorization(UserGroup.Guest)),
        //                                    }, transaction: tran);
        //                                    //conn.Execute(sql, new AuthorizationDbDefine()
        //                                    //{
        //                                    //    Key = (int)BasicUser.,
        //                                    //    User = GetResource.GetValue<string>("Glorytek.WFSCore", "UserTitle_TeamLeader"),
        //                                    //    NewPassword = _guestPassword,
        //                                    //    DepartmentAuthorization = EncryptAuthorization(GetDefaultAuthorization(_userName_TeamLeader)),
        //                                    //}, transaction: tran);
        //                                    //conn.Execute(sql, new AuthorizationDbDefine()
        //                                    //{
        //                                    //    Key = (int)BasicUser.,
        //                                    //    User = GetResource.GetValue<string>("Glorytek.WFSCore", "UserTitle_Engineer"),
        //                                    //    NewPassword = _guestPassword,
        //                                    //    DepartmentAuthorization = EncryptAuthorization(GetDefaultAuthorization(_userName_Engineer)),
        //                                    //}, transaction: tran);
        //                                    //conn.Execute(sql, new AuthorizationDbDefine()
        //                                    //{
        //                                    //    Key = (int)BasicUser.,
        //                                    //    User = GetResource.GetValue<string>("Glorytek.WFSCore", "UserTitle_Manager"),
        //                                    //    NewPassword = _guestPassword,
        //                                    //    DepartmentAuthorization = EncryptAuthorization(GetDefaultAuthorization(_userName_Manager)),
        //                                    //}, transaction: tran);
        //                                }

        //                                _authorizations = conn.GetAll<AuthorizationDefine>(transaction: tran).OrderBy(x => x.OrderNo).ToList();
        //                                tran.Commit();
        //                                UpdateUserNameList();
        //                                return true;
        //                            }
        //                            catch (Exception ex)
        //                            {
        //                                tran.Rollback();
        //                                string errMsg = $"權限資料庫讀取失敗!\n{ex.Message}";
        //                                _authorizations = new List<AuthorizationDefine>();
        //                                //Log.Fatal(ex, errMsg);
        //                                _ = MessageBox.Show(errMsg,
        //                                                    MessageList.DatabaseErrorTitle,
        //                                                    MessageBoxButtons.OK,
        //                                                    MessageBoxIcon.Error);
        //                            }
        //                        }
        //                    }
        //                    return false;
        //                }
        //            }
        //        }

        /// <summary>
        /// 更新使用者名稱列表。
        /// </summary>
        private void UpdateUserNameList()
        {
            List<UserNameListDefine> unl = new List<UserNameListDefine>();
            foreach (var item in _authorizations.OrderBy(x => x.OrderNo))
                unl.Add(new UserNameListDefine() { Id = item.Id, Name = item.UserName, OrderNo = item.OrderNo });
            _ca.UserNameList = unl;
        }

        /********************
         * 基本資料
         ********************/
        /// <inheritdoc/>
        public bool IsUserIdExist(int userId)
        {
            return _authorizations.Any(x => x.Id == userId);
        }

        /********************
         * AD認證服務
         ********************/
        /// <inheritdoc/>
        public bool Authenticate(string userName, string password)
        {
            try
            {
                SecureString securePwd = new SecureString();
                foreach (var c in password)
                    securePwd.AppendChar(c);

                var identifier = new LdapDirectoryIdentifier("172.16.254.200");
                using (var connection = new LdapConnection(identifier))
                {
                    connection.SessionOptions.ProtocolVersion = 3;
                    connection.AuthType = AuthType.Negotiate;
                    var credential = new NetworkCredential(userName, securePwd);
                    connection.Bind(credential);

                    Console.WriteLine("驗證成功");
                    return true;
                }
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LDAP 驗證失敗: {ex.Message}");
                SwitchAuthorityToGuest();
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"系統錯誤: {ex.Message}");
                SwitchAuthorityToGuest();
                return false;
            }
        }

        /********************
         * 權限操作
         ********************/
        /// <inheritdoc/>
        public void SwitchAuthority(int userId, string password)
        {
            try
            {
                // admin
                if ((int)UserGroup.Admin == userId)
                {
                    if (_adminPassword != password)
                        throw new AuthorityException(MessageList.PasswordError);

                    _ca.CurrentUserId = userId;
                    _ca.CurrentUserGroup = UserGroup.Admin;
                    _ca.CurrentUserTitle = AdminTitle;
                    _ca.IsAdmin = true;
                    _ca.IsGuest = false;

                    _ca.CurrentAuthotization = GetDefaultAuthorization(UserGroup.Admin);
                    StrongReferenceMessenger.Default.Send(new LoggedInUserChangedMessage(_ca));
                    //Log.Information($"{_userName_Admin_Title}登入。");
                }
                else if ((int)UserGroup.Guest == userId)
                {
                    // 訪客不需密碼
                    //if (_adminPassword != password)
                    //    throw new AuthorityException(MessageList.PasswordError);

                    _ca.CurrentUserId = userId;
                    _ca.CurrentUserGroup = UserGroup.Guest;
                    _ca.CurrentUserTitle = GuestTitle;
                    _ca.IsAdmin = false;
                    _ca.IsGuest = true;

                    _ca.CurrentAuthotization = GetDefaultAuthorization(UserGroup.Guest);
                    StrongReferenceMessenger.Default.Send(new LoggedInUserChangedMessage(_ca));
                    //Log.Information($"{_userName_Admin_Title}登入。");
                }
                else
                {
                    var user = GetUser(userId);

                    if (user.Password == password)
                        throw new AuthorityException(MessageList.PasswordError);

                    string jsonAuthorization = user.Authorization.Decrypt(_publickey, _secretkey);
                    if (jsonAuthorization == string.Empty)
                        throw new Exception("程式內部錯誤：權限資料異常");

                    var authorization = JsonConvert.DeserializeObject<AuthorizationTable>(jsonAuthorization);

                    _ca.CurrentUserId = userId;
                    _ca.CurrentUserGroup = UserGroup.Employee;
                    _ca.CurrentUserTitle = user.UserName;
                    _ca.IsAdmin = false;
                    _ca.IsGuest = (int)UserGroup.Guest == userId;

                    _ca.CurrentAuthotization = new AuthorizationTable
                    {
                        AuthorityManager = authorization.AuthorityManager,
                        ToolQuest = authorization.ToolQuest,
                        MechaTrack = authorization.MechaTrack,
                        MaintiFlow = authorization.MaintiFlow,
                    };
                    StrongReferenceMessenger.Default.Send(new LoggedInUserChangedMessage(_ca));
                    //Log.Information($"權限管理: {user.User} 登入。");
                }
            }
            catch (AuthorityException ae)
            {
                //Log.Warning(ae, errTitle);
                _ = MessageBox.Show(ae.Message,
                                    MessageList.AuthorityLoginErrorTitle,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                //Log.Fatal(ex, errTitle);
                _ = MessageBox.Show(ex.Message,
                                    MessageList.AuthorityProcErrorTitle,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
            }
        }

        /// <inheritdoc/>
        public void SwitchAuthority(string userName, string password)
        {
            try
            {
                if (_userName_Admin == userName.ToTitleCase())
                {
                    SwitchAuthority((int)UserGroup.Admin, password);
                }
                else if (string.IsNullOrEmpty(userName))
                {
                    SwitchAuthority((int)UserGroup.Guest, string.Empty);
                }
                else
                {
                    var user = _authorizations.Find(x => x.UserName == userName);
                    if (user != null)
                    {
                        SwitchAuthority(user.Id, password);
                    }
                    else
                    {
                        throw new AuthorityException($"{MessageList.User}不存在: {userName}");
                    }
                }
            }
            catch (AuthorityException ae)
            {
                //Log.Warning(ae, errTitle);
                _ = MessageBox.Show(ae.Message,
                                    MessageList.AuthorityLoginErrorTitle,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
            }
        }

        /// <inheritdoc/>
        public void SwitchAuthority(UserGroup basicUser, string password)
        {
            SwitchAuthority((int)basicUser, password);
        }

        /// <inheritdoc/>
        public bool SwitchAuthorityByDialog()
        {
            try
            {
                DialogInfo user = new DialogInfo();
                using (var dlg = new UserLogin())
                {
                    //dlg.NameList = _ca.UserNameList.Select(x => x.Name).ToArray();
                    if (dlg.ShowDialog() != DialogResult.OK)
                        return false;

                    user = dlg.DialogInfo;
                }

                if (_userName_Admin == user.NewName.ToTitleCase())
                {
                    SwitchAuthority((int)UserGroup.Admin, user.NewPassword);
                }
                else if (string.IsNullOrEmpty(user.NewName))
                {
                    // 使用者名稱空白則視為訪客
                    SwitchAuthorityToGuest();
                }
                else
                {
                    var ad = _authorizations.Find(x => x.UserName == user.NewName);
                    if (ad != null)
                    {
                        SwitchAuthority(ad.Id, user.NewPassword);
                    }
                    else
                    {
                        throw new AuthorityException($"{MessageList.User}不存在: {user.NewName}");
                    }
                }
                return true;
            }
            catch (AuthorityException ae)
            {
                //Log.Warning(ae, errTitle);
                _ = MessageBox.Show(ae.Message,
                                    MessageList.AuthorityLoginErrorTitle,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
            }
            return false;
        }

        /// <inheritdoc/>
        public void SwitchAuthorityToGuest()
        {
            if ((int)UserGroup.Guest != _ca.CurrentUserId)
                SwitchAuthority((int)UserGroup.Guest, _guestPassword);
        }

        ///// <summary>
        ///// 切換權限至訪客(IEventAggregator版本)。
        ///// </summary>
        //private void SwitchAuthorityToGuest(string _)
        //{
        //    if ((int)UserGroup.Guest != _ad.CurrentUserId)
        //        SwitchAuthority((int)UserGroup.Guest, _guestPassword);
        //}

        /// <inheritdoc/>
        public void OpenAuthorityEditor()
        {
            //try
            //{
            //    DialogInfo user = new DialogInfo();
            //    var result = _dialogService.ShowDialog<AuthorityEditor>();
            //    if (result != DialogResult.OK)
            //        return;

            //}
            //catch (AuthorityException ae)
            //{
            //    //Log.Warning(ae, errTitle);
            //    _ = MessageBox.Show(ae.Message,
            //                        MessageList.AuthorityLoginErrorTitle,
            //                        MessageBoxButtons.OK,
            //                        MessageBoxIcon.Error);
            //}
        }

        /// <inheritdoc/>
        public AuthorizationDefine GetUser(int userId)
        {
            try
            {
                var user = _authorizations.Find(x => x.Id == userId);
                if (user == null)
                    throw new Exception("使用者名稱錯誤");

                return user;
            }
            catch (Exception ex)
            {
                //Log.Fatal(ex, errTitle);
                _ = MessageBox.Show($"{MessageList.InternalErrorTitle}: {ex.Message}\n{MessageList.ContactAdministrator}。",
                                    MessageList.InternalErrorTitle,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                return null;
            }
        }

        ///// <inheritdoc/>
        //public string EncryptFromJson(string json) => Encryption.AESEncrypt(json, _publickey, _secretkey);

        ///// <inheritdoc/>
        //public string DecryptToJson(string EncryptedString) => AES.Encrypt(EncryptedString, _publickey, _secretkey);

        /// <inheritdoc/>
        public string EncryptTableToString(AuthorizationTable table)
        {
            try
            {
                string json = JsonConvert.SerializeObject(table);
                if (string.IsNullOrWhiteSpace(json))
                    throw new Exception("權限設定資料錯誤");

                var ad = json.Encrypt(_publickey, _secretkey);
                if (ad == null)
                    throw new Exception("權限設定資料錯誤");

                return ad;
            }
            catch (Exception ex)
            {
                string errMsg = $"程式異常，請連繫相關人員！\n{ex.Message}";
                //Log.Fatal(ex, errTitle);
                _ = MessageBox.Show(errMsg,
                                    MessageList.InternalErrorTitle,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                return string.Empty;
            }
        }

        /// <inheritdoc/>
        public AuthorizationTable DecryptStringToTable(string encryptedString)
        {
            try
            {
                string json = encryptedString.Decrypt(_publickey, _secretkey);
                if (string.IsNullOrWhiteSpace(json))
                    throw new Exception("權限設定資料錯誤");

                var ad = JsonConvert.DeserializeObject<AuthorizationTable>(json);
                if (ad == null)
                    throw new Exception("權限設定資料錯誤");

                return ad;
            }
            catch (Exception ex)
            {
                //Log.Fatal(ex, errTitle);
                _ = MessageBox.Show($"{MessageList.InternalErrorTitle}: {ex.Message}\n{MessageList.ContactAdministrator}。",
                                    MessageList.InternalErrorTitle,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                return null;
            }
        }

        /// <inheritdoc/>
        public bool SetUserAuthorizationTable(int userId, AuthorizationTable table)
        {
            string encryptedString = EncryptTableToString(table);

            if (!string.IsNullOrEmpty(encryptedString))
            {
                //GetUser(userName).DepartmentAuthorization = encryptedString;
                _authorizations.Find(x => x.Id == userId).Authorization = encryptedString;
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <inheritdoc/>
        public AuthorizationTable GetUserAuthorizationTable(int userId)
        {
            return DecryptStringToTable(GetUser(userId).Authorization);
        }

        /// <summary>
        /// 取得預設權限表。
        /// </summary>
        /// <param name="userGroup">參照的使用者。</param>
        /// <returns>權限表。</returns>
        private AuthorizationTable GetDefaultAuthorization(UserGroup userGroup)
        {
            AuthorizationTable at;
            switch (userGroup)
            {
                case UserGroup.Admin:
                    {
                        at = new AuthorizationTable
                        {
                            AuthorityManager = true,
                            ToolQuest = true,
                            MechaTrack = true,
                            MaintiFlow = true,
                        };
                    }
                    break;

                default:
                    {
                        at = new AuthorizationTable
                        {
                            AuthorityManager = false,
                            ToolQuest = false,
                            MechaTrack = false,
                            MaintiFlow = false,
                        };
                        break;
                    }
            }

            return at;
        }

        /********************
         * CRUD
         ********************/
        /// <inheritdoc/>
        public void NewUser()
        {
            return;

            //DialogInfo user = new DialogInfo();
            ////using (var dlg = new UserManager())
            ////{
            ////    dlg.DialogInfo.Title = "新增使用者";
            ////    dlg.DialogInfo.OldNameCaption = string.Empty;
            ////    dlg.DialogInfo.NewNameCaption = "新使用者名稱";
            ////    dlg.DialogInfo.OldPasswordCaption = string.Empty;
            ////    dlg.DialogInfo.NewPasswordCaption = "新密碼";

            ////    if (dlg.ShowDialog() != DialogResult.OK)
            ////        return;

            ////    user = dlg.DialogInfo;
            ////}

            //if (_userName_Admin.ToUpper() == user.NewName.ToUpper())
            //{
            //    _ = MessageBox.Show("管理員資料不可更改！",
            //                        MessageList.UserErrorTitle,
            //                        MessageBoxButtons.OK,
            //                        MessageBoxIcon.Error);
            //    return;
            //}

            //if (_authorizations.Any(x => x.User == user.NewName))
            //{
            //    _ = MessageBox.Show($"{MessageList.UserNameExist}: {user.NewName}",
            //                        MessageList.UserErrorTitle,
            //                        MessageBoxButtons.OK,
            //                        MessageBoxIcon.Error);
            //    return;
            //}

            //try
            //{
            //    lock (_dbLocker)
            //    {
            //        using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
            //        {
            //            if (conn != null)
            //            {
            //                int nextId = SQLiteHelper.GetMaxValue(conn, DB_Authority.TableName_Authorization, "Key") + 1;
            //                int nextOrderNo = SQLiteHelper.GetMaxValue(conn, DB_Authority.TableName_Authorization, "OrderNo") + 1;
            //                //if (nextId < 10)
            //                //    nextId = 10;

            //                using (var tran = conn.BeginTransaction())
            //                {
            //                    try
            //                    {
            //                        string sql = $"INSERT INTO {DB_Authority.TableName_Authorization} (Key, OrderNo, User, NewPassword, DepartmentAuthorization) VALUES (@Key, @OrderNo, @User, @NewPassword, @DepartmentAuthorization);";
            //                        conn.Execute(sql, new AuthorizationDefine()
            //                        {
            //                            Key = nextId,
            //                            OrderNo = nextOrderNo,
            //                            User = user.NewName,
            //                            Password = user.NewPassword,
            //                            Authorization = EncryptTableToString(GetDefaultAuthorization(UserGroup.Guest)),
            //                        }, transaction: tran);
            //                        tran.Commit();
            //                    }
            //                    catch
            //                    {
            //                        tran.Rollback();
            //                    }
            //                }

            //                ReadFromDb();
            //                return;
            //            }
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    string errMsg = $"新增使用者異常！\n{ex.Message}\n{MessageList.ContactAdministrator}";
            //    //Log.Fatal(ex, errMsg);
            //    _ = MessageBox.Show(errMsg,
            //                        MessageList.DatabaseErrorTitle,
            //                        MessageBoxButtons.OK,
            //                        MessageBoxIcon.Error);
            //    return;
            //}
        }

        /// <inheritdoc/>
        public void DeleteUser(int userId)
        {
            //try
            //{
            //    var user = GetUser(userId);
            //    if (_prismMessageBox.ShowOKCancel($"確定要刪除使用者嗎？\n使用者名稱： {user.User}",
            //                                      "動作確認",
            //                                      MessageBoxImage.Question,
            //                                      "確定刪除",
            //                                      "取消") == ButtonResult.OK)
            //    {
            //        using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
            //        {
            //            if (conn != null)
            //            {
            //                using (var tran = conn.BeginTransaction())
            //                {
            //                    try
            //                    {
            //                        _authorizations.RemoveAll(x => x.Key == user.Key);
            //                        string sql = $"DELETE FROM {DB_Authority.TableName_Authorization} WHERE Key = @Key";
            //                        conn.Execute(sql, new { user.Key }, transaction: tran);
            //                        tran.Commit();
            //                        UpdateUserNameList();
            //                    }
            //                    catch
            //                    {
            //                        tran.Rollback();
            //                    }
            //                }
            //            }
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    string errMsg = $"刪除使用者異常！{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}";
            //    Log.Fatal(ex, errMsg);
            //    _prismMessageBox.Show(errMsg,
            //                          GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
            //                          MessageBoxImage.Error);
            //}
        }

        /// <inheritdoc/>
        public void ModifyUserName(int userId)
        {
            //var user = GetUser(userId);

            //CrudInfo crudInfo = new CrudInfo()
            //{
            //    Action = CrudAction.Modify,
            //    Title = "修改使用者資料",
            //    OriginalTitle = "原使用者名稱",
            //    OriginalName = user.User,
            //    NewTitle = "新使用者名稱",
            //    NewName = "",
            //    PasswordTitle = "",
            //    MemoTitle = "",
            //};
            //CrudInfo user = _crudDialog.ShowDialog(crudInfo);

            //if (user.DialogInfo == ButtonResult.OK)
            //{
            //    if (_authorizations.Any(x => x.User == user.NewName))
            //    {
            //        _prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_UserNameExist")}: {user.NewName}",
            //                              MessageBoxImage.Error);
            //        return;
            //    }

            //    if (_userName_Admin.ToTitleCase() == crudInfo.NewName.ToTitleCase())
            //    {
            //        _prismMessageBox.Show($"{GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_UserNameInvalid")}: {crudInfo.NewName}",
            //                              MessageBoxImage.Error);
            //        return;
            //    }

            //    try
            //    {
            //        using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
            //        {
            //            if (conn != null)
            //            {
            //                using (var tran = conn.BeginTransaction())
            //                {
            //                    try
            //                    {
            //                        user.User = user.NewName;
            //                        conn.Update<AuthorizationDefine>(user, transaction: tran);
            //                        tran.Commit();
            //                        UpdateUserNameList();
            //                    }
            //                    catch
            //                    {
            //                        tran.Rollback();
            //                    }
            //                }
            //            }
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        string errMsg = $"修改使用者資料異常！{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}";
            //        Log.Fatal(ex, errMsg);
            //        _prismMessageBox.Show(errMsg,
            //                              GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
            //                              MessageBoxImage.Error);
            //    }
            //}
        }

        /// <inheritdoc/>
        public void ChangePassword(int userId)
        {
            //var user = GetUser(userId);

            //CrudInfo crudInfo = new CrudInfo()
            //{
            //    Action = CrudAction.Modify,
            //    Title = "變更使用者密碼",
            //    OriginalTitle = "使用者名稱",
            //    OriginalName = user.User,
            //    PasswordTitle = "新密碼",
            //    PasswordMaxLength = 16,
            //    PasswordWatermark = GetResource.GetValue<string>("Glorytek.WFSComponents", "Login_PasswordDescription"),
            //    NewTitle = "",
            //    MemoTitle = "",
            //};
            //CrudInfo user = _crudDialog.ShowDialog(crudInfo);

            //if (user.DialogInfo == ButtonResult.OK)
            //{
            //    try
            //    {
            //        using (var conn = SQLiteHelper.OpenConnection(DBbase.Directory_Base, DBbase.DbName_System))
            //        {
            //            if (conn != null)
            //            {
            //                using (var tran = conn.BeginTransaction())
            //                {
            //                    try
            //                    {
            //                        user.NewPassword = user.NewPassword;
            //                        conn.Update<AuthorizationDefine>(user, transaction: tran);
            //                        tran.Commit();
            //                    }
            //                    catch
            //                    {
            //                        tran.Rollback();
            //                    }
            //                }
            //            }
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        string errMsg = $"變更使用者密碼異常！{GetResource.GetValue<string>("Glorytek.WFSCore", "Message_ContactMaintenance")}";
            //        Log.Fatal(ex, errMsg);
            //        _prismMessageBox.Show(errMsg,
            //                              GetResource.GetValue<string>("Glorytek.WFSCore", "ErrorMessage_DatabaseError"),
            //                              MessageBoxImage.Error);
            //    }
            //}
        }

        /********************
         * OrderNo操作
         ********************/
        /// <inheritdoc/>
        public bool MoveOrderUp(int userId)
        {
            var thisAuthorzation = _authorizations.Find(x => x.Id == userId);
            if (thisAuthorzation != null)
            {
                int thisOrderNo = thisAuthorzation.OrderNo;
                int targetOrderNo = thisOrderNo - 1;
                var targetAuthorzation = _authorizations.Find(x => x.OrderNo == targetOrderNo);

                if (targetAuthorzation != null)
                {
                    var a = thisAuthorzation.OrderNo;
                    thisAuthorzation.OrderNo = targetAuthorzation.OrderNo;
                    targetAuthorzation.OrderNo = a;
                    ResortOrderNo();
                    return true;
                }
            }
            return false;
        }

        /// <inheritdoc/>
        public bool MoveOrderDown(int userId)
        {
            var thisAuthorzation = _authorizations.Find(x => x.Id == userId);
            if (thisAuthorzation != null)
            {
                int thisOrderNo = thisAuthorzation.OrderNo;
                int targetOrderNo = thisOrderNo + 1;
                var targetAuthorzation = _authorizations.Find(x => x.OrderNo == targetOrderNo);

                if (targetAuthorzation != null)
                {
                    var a = thisAuthorzation.OrderNo;
                    thisAuthorzation.OrderNo = targetAuthorzation.OrderNo;
                    targetAuthorzation.OrderNo = a;
                    ResortOrderNo();
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 對OrderNo重新排序。
        /// </summary>
        private void ResortOrderNo()
        {
            _authorizations.Sort((x, y) => x.OrderNo.CompareTo(y.OrderNo));
            int orderNo = 0;
            foreach (var au in _authorizations)
                au.OrderNo = ++orderNo;
            //WriteToDb(true, false);
            UpdateUserNameList();
        }

        /********************
         * 輸入裝置idle偵測
         * 設定時間內鍵盤或滑鼠沒有觸發時，切換使用者權限至訪客
         * 註：輸入裝置偵測事件位於 MainWindow.xaml.cs
         ********************/
        /// <summary>
        /// 重設Idel Timer事件。
        /// </summary>
        /// <param name="timerInterval">設定Timer Interval。<br/>設為0: 不執行事件。<br/>小於0: 依資料庫值重設Timer。</param>
        public void ResetInputDetectorTimer(int timerInterval)
        {
            int interval = timerInterval >= 0 ? timerInterval : _ap.Params.InputDetectInterval;
            if (interval > 0)
            {
                InputDetector.Interval = interval * 60000.0; // 1 min = 60000 ms
                InputDetector.AutoReset = false;
                InputDetector.Elapsed += IdleForTooLong;
                InputDetector.Start();
            }
            else
            {
                InputDetector.Stop();
                InputDetector.Elapsed -= IdleForTooLong;
            }
        }

        /// <summary>
        /// Timer Event。
        /// </summary>
        private void IdleForTooLong(object sender, System.Timers.ElapsedEventArgs e)
        {
            //if (_ad.CurrentUserId != (int)UserGroup.Operator)
            //    _ea.GetEvent<SwitchAuthorityToOperatorEvent>().Publish("");
            InputDetector.Elapsed -= IdleForTooLong;
        }
    }
}
