﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Authority
{
    /// <summary>
    /// 使用者授權資料。
    /// </summary>
    [Table(DB_Authority.TableName_Authorization)]
    public class AuthorizationDefine
    {
        /// <summary>
        /// Key。
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// 排列順序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 使用者名稱。
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 登入密碼 (MD5加密)。
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 權限 (AES加密)。
        /// </summary>
        public string Authorization { get; set; }
    }
}
