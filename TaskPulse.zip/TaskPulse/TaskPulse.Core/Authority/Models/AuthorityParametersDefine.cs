﻿using Dapper.Contrib.Extensions;

namespace Calin.TaskPulse.Core.Authority
{
    /// <summary>
    /// 權限系統參數。
    /// </summary>
    [Table(DB_Authority.TableName_Authority)]
    public class AuthorityParametersDefine
    {
        [ExplicitKey]
        public int Id { get; set; }

        /// <summary>
        /// 權限idle時間設定(分鐘)：鍵盤沒按鍵或滑鼠沒移動多久，自動切換回作業員權限。
        /// </summary>
        public int InputDetectInterval { get; set; }
    }
}
