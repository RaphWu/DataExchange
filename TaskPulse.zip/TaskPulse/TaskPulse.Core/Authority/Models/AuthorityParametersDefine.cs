﻿using Calin.TaskPulse.Core.Authority.Constants;
using Dapper.Contrib.Extensions;

namespace Calin.TaskPulse.Core.Authority.Models
{
    /// <summary>
    /// 權限系統參數。
    /// </summary>
    [Table(DB_Authority.TableName_Authority)]
    public class AuthorityParametersDefine
    {
        [ExplicitKey]
        public int Id { get; set; }

        /// <summary>
        /// 權限 idle 時間設定(分鐘)：鍵盤沒按鍵或滑鼠沒移動多久，自動切換回訪客權限。
        /// </summary>
        public int InputDetectInterval { get; set; }
    }
}
