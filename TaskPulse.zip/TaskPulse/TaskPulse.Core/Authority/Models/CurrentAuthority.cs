﻿using System.Collections.Generic;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Core.Authority.Models
{
    /// <summary>
    /// 權限系統資料
    /// </summary>
    public class CurrentAuthority : ObservableObject
    {
        /********************
         * DialogInfo
         ********************/
        /// <summary>
        /// UserName列表。
        /// </summary>
        public List<UserNameListDefine> UserNameList
        {
            get { return _userNameList; }
            set { SetProperty(ref _userNameList, value); }
        }
        private List<UserNameListDefine> _userNameList;

        /********************
         * 權限
         ********************/
        /// <summary>
        /// 目前權限群組的使用者ID。
        /// </summary>
        public int CurrentUserId
        {
            get { return _currentUserId; }
            set { SetProperty(ref _currentUserId, value); }
        }
        private int _currentUserId;

        /// <summary>
        /// 目前權限群組的使用者名稱。
        /// </summary>
        public UserGroup CurrentUserGroup
        {
            get { return _currentUserGroup; }
            set { SetProperty(ref _currentUserGroup, value); }
        }
        private UserGroup _currentUserGroup;

        /// <summary>
        /// 目前使用者的顯示名稱。
        /// </summary>
        public string CurrentUserTitle
        {
            get { return _currentUserTitle; }
            set { SetProperty(ref _currentUserTitle, value); }
        }
        private string _currentUserTitle;

        /// <summary>
        /// 目前權限群組的權限表。
        /// </summary>
        public AuthorizationTable CurrentAuthotization
        {
            get { return _currentAuthotization; }
            set { SetProperty(ref _currentAuthotization, value); }
        }
        private AuthorizationTable _currentAuthotization = new AuthorizationTable();

        /// <summary>
        /// 目前登入者是否為超級管理員。
        /// </summary>
        public bool IsAdmin
        {
            get { return _isAdmin; }
            set { SetProperty(ref _isAdmin, value); }
        }
        private bool _isAdmin;

        /// <summary>
        /// 目前登入者是否為訪客。
        /// </summary>
        public bool IsGuest
        {
            get { return _isOperator; }
            set { SetProperty(ref _isOperator, value); }
        }
        private bool _isOperator;
    }
}
