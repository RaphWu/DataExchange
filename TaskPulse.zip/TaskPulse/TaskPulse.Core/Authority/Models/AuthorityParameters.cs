﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Authority.Models
{
    public class AuthorityParameters
    {
        /// <summary>
        /// 權限系統參數。
        /// </summary>
        public AuthorityParametersDefine Params { get; set; }
    }
}
