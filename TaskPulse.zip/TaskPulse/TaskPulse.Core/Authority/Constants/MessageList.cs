﻿namespace Calin.TaskPulse.Core.Authority.Constants
{
    public static class MessageList
    {
        #region Message

        // Message
        public static readonly string User = "使用者";

        // Error
        public static readonly string ContactAdministrator = "請聯繫相關人員";
        public static readonly string PasswordError = "密碼錯誤！";
        public static readonly string UserNameExist = "使用者名稱已存在";

        #endregion Message

        #region Title

        // Error
        public static readonly string InternalErrorTitle = "系統內部錯誤!";
        public static readonly string DatabaseErrorTitle = "資料庫錯誤！";
        public static readonly string AuthorityLoginErrorTitle = "權限登入錯誤";
        public static readonly string AuthorityProcErrorTitle = "權限處理異常";
        public static readonly string UserErrorTitle = "使用者資料異常";

        #endregion Title
    }
}
