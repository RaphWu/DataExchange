﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 機台快取已更新通知。
    /// </summary>
    public class NotifyMachineCacheUpdated
    {
        public static readonly NotifyMachineCacheUpdated Instance = new NotifyMachineCacheUpdated();
        private NotifyMachineCacheUpdated() { }
    }
}
