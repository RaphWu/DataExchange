﻿using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    public class ProcessBarMessage : ValueChangedMessage<int>
    {
        public ProcessBarMessage(int percent) : base(percent) { }
    }
}
