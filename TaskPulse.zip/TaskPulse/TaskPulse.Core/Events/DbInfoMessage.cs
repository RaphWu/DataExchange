﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Authority.Models;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 狀態列DB資料顯示訊息。
    /// </summary>
    public class DbInfoMessage : ValueChangedMessage<string>
    {
        public DbInfoMessage(string info) : base(info) { }
    }
}
