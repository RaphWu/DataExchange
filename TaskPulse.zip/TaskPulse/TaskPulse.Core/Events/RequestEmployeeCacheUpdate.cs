﻿using Calin.TaskPulse.Entity.Contants;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 要求更新員工快取。
    /// </summary>
    public class RequestEmployeeCacheUpdate
    {
        public static readonly RequestEmployeeCacheUpdate Instance = new RequestEmployeeCacheUpdate();
        private RequestEmployeeCacheUpdate() { }
    }
}
