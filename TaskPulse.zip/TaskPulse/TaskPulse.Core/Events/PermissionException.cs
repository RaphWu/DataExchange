﻿using System;
using System.Runtime.Serialization;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 權限自訂例外。
    /// </summary>
    internal class PermissionException : Exception, ISerializable
    {
        public PermissionException() : base("Setup_Permission Error!") { }
        public PermissionException(string message) : base(message) { }
        public PermissionException(string message, Exception inner) : base(message, inner) { }
        protected PermissionException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
