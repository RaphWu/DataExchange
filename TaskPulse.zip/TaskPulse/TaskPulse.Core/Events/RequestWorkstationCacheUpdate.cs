﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 要求更新工站快取。
    /// </summary>
    public class RequestWorkstationCacheUpdate
    {
        public static readonly RequestWorkstationCacheUpdate Instance = new RequestWorkstationCacheUpdate();
        private RequestWorkstationCacheUpdate() { }
    }
}
