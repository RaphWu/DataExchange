﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 工站快取已更新通知。
    /// </summary>
    public class NotifyWorkstationCacheUpdated
    {
        public static readonly NotifyWorkstationCacheUpdated Instance = new NotifyWorkstationCacheUpdated();
        private NotifyWorkstationCacheUpdated() { }
    }
}
