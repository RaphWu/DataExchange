﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 核心共用資料更新。
    /// </summary>
    public class CoreDataChangedNotification
    {
        public static readonly CoreDataChangedNotification Instance = new CoreDataChangedNotification();
        private CoreDataChangedNotification() { }
    }
}
