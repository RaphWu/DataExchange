﻿using Calin.TaskPulse.Entity.Contants;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 核心共用資料更新訊息。
    /// </summary>
    public class CoreDataChangedNotification : ValueChangedMessage<CoreDataType>
    {
        public CoreDataChangedNotification(CoreDataType cdt) : base(cdt) { }

        //public static readonly CoreDataChangedNotification Instance = new CoreDataChangedNotification();
        //private CoreDataChangedNotification() { }
    }
}
