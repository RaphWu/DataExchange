﻿using Calin.TaskPulse.Entity.Contants;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 員工快取已更新通知。
    /// </summary>
    public class NotifyEmployeeCacheUpdated
    {
        public static readonly NotifyEmployeeCacheUpdated Instance = new NotifyEmployeeCacheUpdated();
        private NotifyEmployeeCacheUpdated() { }
    }
}
