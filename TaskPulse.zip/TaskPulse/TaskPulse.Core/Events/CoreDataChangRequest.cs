﻿using Calin.TaskPulse.Entity.Contants;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 核心共用資料 Cache 更新需求。
    /// </summary>
    /// <remarks>當 Core 資料庫有更新時，要求更新 Cache。</remarks>
    public class CoreDataChangRequest : ValueChangedMessage<CoreDataType>
    {
        public CoreDataChangRequest(CoreDataType cdt) : base(cdt) { }
    }
}
