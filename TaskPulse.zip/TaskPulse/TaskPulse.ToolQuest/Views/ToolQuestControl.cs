﻿using System.Windows.Forms;

namespace TaskPulse.ToolQuest
{
    public partial class ToolQuestControl : UserControl
    {
        public ToolQuestControl()
        {
            InitializeComponent();
        }
    }
}
