﻿using Sunny.UI;

namespace Calin.TaskPulse.ToolQuest.Views
{
    public partial class ToolQuestPage : UIPage
    {
        public ToolQuestPage()
        {
            InitializeComponent();
        }
    }
}
