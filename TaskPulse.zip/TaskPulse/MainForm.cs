﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Views;
using Calin.TaskPulse.MechaTrack;
using Calin.TaskPulse.MechaTrack.Views;
using Calin.TaskPulse.ToolQuest;
using Calin.TaskPulse.ToolQuest.Views;
using Calin.TaskPulse.Views;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calin.TaskPulse
{
    public partial class MainForm : UIForm
    {
        internal static new IContainer Container { get; set; }

        const int PAGE_IDX_MAIN_PAGE = 0;
        const int PAGE_IDX_TOOL_QUEST = 1;
        const int PAGE_IDX_MECHA_TRACK = 2;
        const int PAGE_IDX_MAINTI_FLOW = 3;
        const int PAGE_IDX_SETUP = 4;
        private TreeNode _node;

        public MainForm()
        {
            InitializeComponent();

            // IoC & Module
            var builder = new ContainerBuilder();
            builder.RegisterModule(new CoreModule());
            builder.RegisterModule(new MainModule());
            builder.RegisterModule(new ToolQuestMoudle());
            builder.RegisterModule(new MechaTrackModule());
            builder.RegisterModule(new MaintiFlowModule());
            Container = builder.Build();

            // 註冊使用者切換事件
            WeakReferenceMessenger.Default.Register<LoggedInUserChangedMessage>(this, (r, m) =>
            {
                SetAuthority(m.Value);
            });

            // 註冊頁面切換事件
            WeakReferenceMessenger.Default.Register<PageChangedMessage>(this, (r, m) =>
            {
                //SwitchPage(m.Value);
            });

            UIStyles.InitColorful(Color.FromArgb(80, 126, 164), Color.White); // 藍灰
            UIStyles.DPIScale = true;
            UIStyles.GlobalFont = true;
            UIStyles.GlobalFontName = "微軟正黑體";
            UIStyles.SetDPIScale();

            //MainTabControl = uiTabControl;
            //uiNavBar.TabControl = uiTabControl;

            uiNavBar.Nodes.Add(PageCode.MainPage.GetDescription());
            uiNavBar.SetNodePageIndex(uiNavBar.Nodes[PAGE_IDX_MAIN_PAGE], (int)PageCode.MainPage);
            uiNavBar.SetNodeSymbol(uiNavBar.Nodes[PAGE_IDX_MAIN_PAGE], 559530);

            uiNavBar.Nodes.Add(PageCode.ToolQuest.GetDescription());
            uiNavBar.SetNodePageIndex(uiNavBar.Nodes[PAGE_IDX_TOOL_QUEST], (int)PageCode.ToolQuest);
            uiNavBar.SetNodeSymbol(uiNavBar.Nodes[PAGE_IDX_TOOL_QUEST], 57397);

            uiNavBar.Nodes.Add(PageCode.MechaTrack.GetDescription());
            uiNavBar.SetNodePageIndex(uiNavBar.Nodes[PAGE_IDX_MECHA_TRACK], (int)PageCode.MechaTrack);
            uiNavBar.SetNodeSymbol(uiNavBar.Nodes[PAGE_IDX_MECHA_TRACK], 261474);

            uiNavBar.Nodes.Add(PageCode.MaintiFlow.GetDescription());
            uiNavBar.SetNodePageIndex(uiNavBar.Nodes[PAGE_IDX_MAINTI_FLOW], (int)PageCode.MaintiFlow);
            uiNavBar.SetNodeSymbol(uiNavBar.Nodes[PAGE_IDX_MAINTI_FLOW], 361613);

            uiNavBar.Nodes.Add(PageCode.Setup.GetDescription());
            uiNavBar.SetNodePageIndex(uiNavBar.Nodes[PAGE_IDX_SETUP], (int)PageCode.MechaTrack);
            uiNavBar.SetNodeSymbol(uiNavBar.Nodes[PAGE_IDX_SETUP], 361459);

            _node = uiNavBar.CreateChildNode(uiNavBar.Nodes[PAGE_IDX_SETUP],
                                             PageCode.UserLogin.GetDescription(),
                                             (int)PageCode.UserLogin);
            uiNavBar.SetNodeSymbol(_node, 357448);

            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthorityToGuest();
            }
            ResizeScreen();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            WeakReferenceMessenger.Default.Unregister<LoggedInUserChangedMessage>(this);
            WeakReferenceMessenger.Default.Unregister<PageChangedMessage>(this);
        }

        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1440;
            const int TARGET_HEIGHT = 900;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        /********************
         * 操作模式 & 頁面載入
         ********************/
        private int _currentPage = (int)PageCode.None;

        private void uiNavBar_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            SwitchPage(itemText, menuIndex, pageIndex);
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="page">頁面代號。</param>
        private void SwitchPage(string itemText, int menuIndex, int pageIndex)
        {
            UIPage control;

            if (_currentPage == pageIndex)
                return;

            switch (Enum.Parse(typeof(PageCode), pageIndex.ToString()))
            {
                case PageCode.MainPage:
                    control = Container.Resolve<MainPage>();
                    LoadPage(control);
                    break;

                case PageCode.ToolQuest:
                    control = Container.Resolve<ToolQuestPage>();
                    LoadPage(control);
                    break;

                case PageCode.MechaTrack:
                    control = Container.Resolve<MechaTrackPage>();
                    LoadPage(control);
                    break;

                case PageCode.MaintiFlow:
                    control = Container.Resolve<MaintiFlowPage>();
                    LoadPage(control);
                    break;

                case PageCode.UserLogin:
                    LoginIfNeed();
                    break;
            }

            _currentPage = pageIndex;

            using (var scope = Container.BeginLifetimeScope())
            {
                var ad = scope.Resolve<AuthorityData>();
                if (ad.IsGuest)
                    LoginIfNeed();
            }
        }

        /// <summary>
        /// 載入頁面。
        /// </summary>
        /// <param name="page">頁面物件。</param>
        private void LoadPage(UIPage page)
        {
            uiPanel.Controls.Clear();
            if (page != null)
            {
                page.Dock = DockStyle.Fill;
                uiPanel.Controls.Add(page);
            }
        }

        /********************
         * 權限
         ********************/
        private void SetAuthority(AuthorityData ad)
        {
            CurrentUser.Text = ad.CurrentUserTitle; // User

            //if (ad.IsAdmin)
            //{
            //    toolStripStatus_UserName.BackColor = Color.Red;
            //    toolStripStatus_UserName.ForeColor = Color.Yellow;
            //}
            //else if (!ad.IsGuest)
            //{
            //    toolStripStatus_UserName.BackColor = Color.Transparent;
            //    toolStripStatus_UserName.ForeColor = Color.Blue;
            //}
            //else
            //{
            //    toolStripStatus_UserName.BackColor = Color.Transparent;
            //    toolStripStatus_UserName.ForeColor = Color.Black;
            //}

            //UIProperty.Instance.ToolQuestFunction = ad.CurrentAuthotization.ToolQuest;
            //UIProperty.Instance.MechaTrackFunction = ad.CurrentAuthotization.MechaTrack;
            //UIProperty.Instance.MaintiFlowFunction = ad.CurrentAuthotization.MaintiFlow;

            /********************
             * 頁面、按鍵 ON/OFF
             ********************/
            bool bVal;

            bVal = ad.CurrentAuthotization.AuthorityManager;
            //toolStripMenuItem_UserManager.Enabled = bVal;

            //bVal = ad.CurrentAuthotization.ToolQuest;
            //uiButton_ToolQuestPage.Enabled = bVal;

            //bVal = ad.CurrentAuthotization.MechaTrack;
            //uiButton_MechaTrackPage.Enabled = bVal;

            //bVal = ad.CurrentAuthotization.MaintiFlow;
            //uiButton_MaintiFlowPage.Enabled = bVal;

            if (ad.IsGuest)
                LoginIfNeed();
        }

        /// <summary>
        /// 目前使用者是訪客時，顥示登入對話框。
        /// </summary>
        /// <param name="isGuest">是否是訪客。</param>
        private void LoginIfNeed()
        {
            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthorityByDialog();
            }
        }

        /********************
         * 系統事件
         ********************/
        private void clockTimer_Tick(object sender, EventArgs e)
        {
            Clock.Text = DateTime.Now.DateTimeString();
        }

        //private void uiButton_MainPage_Click(object sender, EventArgs e)
        //{
        //    SwitchPage(PageCode.MainPage);
        //}

        //private void uiButton_ToolQuestPage_Click(object sender, EventArgs e)
        //{
        //    SwitchPage(PageCode.ToolQuest);
        //}

        //private void uiButton_MechaTrackPage_Click(object sender, EventArgs e)
        //{
        //    SwitchPage(PageCode.MechaTrack);
        //}

        //private void uiButton_MaintiFlowPage_Click(object sender, EventArgs e)
        //{
        //    SwitchPage(PageCode.MaintiFlow);
        //}

        private void toolStripMenuItem_SwitchUser_Click(object sender, EventArgs e)
        {
            LoginIfNeed();
        }
    }
}
