﻿using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Event;
using CommunityToolkit.Mvvm.Messaging;
using Krypton.Toolkit;

namespace Calin.TaskPulse
{
    public partial class MainForm : KryptonForm
    {
        private static new IContainer Container { get; set; }
        private readonly BindingSource _bs = new BindingSource();

        public MainForm()
        {
            InitializeComponent();

            // KryptonForm
            var form = this;
            form.AllowStatusStripMerge = true;

            // Assembly Info
            var assembly = Assembly.GetExecutingAssembly();
            form.Text = assembly.GetName().Name;
            label_Version.Text = assembly.GetName().Version.ToString();

            // IoC & Module
            var builder = new ContainerBuilder();
            builder.RegisterModule(new AuthorityModule());
            Container = builder.Build();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            _bs.DataSource = UIProperty.Instance;

            // 使用者切換事件
            WeakReferenceMessenger.Default.Register<LoggedInUserChangedMessage>(this, (r, m) =>
            {
                SetAuthority(m.Value);
            });

            // 權限預設為訪客
            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthorityToGuest();
            }
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            mainMenuButton_ToolQuest.DataBindings.Add("Visible", _bs, "ToolQuestVisibility", true, DataSourceUpdateMode.OnPropertyChanged);
            mainMenuButton_MechaTrack.DataBindings.Add("Visible", _bs, "MechaTrackVisibility", true, DataSourceUpdateMode.OnPropertyChanged);
            mainMenuButton_MaintiFlow.DataBindings.Add("Visible", _bs, "MaintiFlowVisibility", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            WeakReferenceMessenger.Default.Unregister<LoggedInUserChangedMessage>(this);

            mainMenuButton_ToolQuest.DataBindings.Clear();
            mainMenuButton_MechaTrack.DataBindings.Clear();
            mainMenuButton_MaintiFlow.DataBindings.Clear();
        }

        /********************
         * 權限
         ********************/
        private void SetAuthority(AuthorityData ad)
        {
            toolStripStatus_UserName.Text = ad.CurrentUserTitle;
            if (ad.IsAdmin)
            {
                toolStripStatus_UserName.BackColor = Color.Red;
                toolStripStatus_UserName.ForeColor = Color.Yellow;
            }
            else if (!ad.IsGuest)
            {
                toolStripStatus_UserName.BackColor = Color.Transparent;
                toolStripStatus_UserName.ForeColor = Color.Blue;
            }
            else
            {
                toolStripStatus_UserName.BackColor = Color.Transparent;
                toolStripStatus_UserName.ForeColor = Color.Black;
            }

            UIProperty.Instance.ToolQuestFunction = ad.CurrentAuthotization.ToolQuest;
            UIProperty.Instance.ToolQuestVisibility = ad.CurrentAuthotization.ToolQuest;

            UIProperty.Instance.MechaTrackFunction = ad.CurrentAuthotization.MechaTrack;
            UIProperty.Instance.MechaTrackVisibility = ad.CurrentAuthotization.MechaTrack;

            UIProperty.Instance.MaintiFlowFunction = ad.CurrentAuthotization.MaintiFlow;
            UIProperty.Instance.MaintiFlowVisibility = ad.CurrentAuthotization.MaintiFlow;
        }

        /********************
         * Control Event
         ********************/
        private void button_SwitchUser_Click(object sender, EventArgs e)
        {
            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthority();
            }
        }
    }
}
