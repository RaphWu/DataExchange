﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Autofac;
//using Calin.TaskPulse.Core.Authority;

//namespace Calin.TaskPulse
//{
//    internal class MainModule : Module
//    {
//        private static IContainer Container { get; set; }

//        protected override void Load(ContainerBuilder builder)
//        {
//            builder.RegisterType<AuthorityService>().As<IAuthority>();
//            Container = builder.Build();
//        }
//    }
//}
