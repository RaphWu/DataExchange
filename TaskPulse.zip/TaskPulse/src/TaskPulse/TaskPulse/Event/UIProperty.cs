﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Authority;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Event
{
    /// <summary>
    /// UI用的屬性。
    /// </summary>
    public class UIProperty : ObservableObject
    {
        private static readonly Lazy<UIProperty> _instance = new Lazy<UIProperty>(() => new UIProperty());
        public static UIProperty Instance => _instance.Value;

        /// <summary>
        /// 工具委託功能。
        /// </summary>
        public bool ToolQuestFunction
        {
            get { return _toolQuestFunction; }
            set { SetProperty(ref _toolQuestFunction, value); }
        }
        private bool _toolQuestFunction;

        /// <summary>
        /// 工具委託顯示。
        /// </summary>
        public bool ToolQuestVisibility
        {
            get { return _toolQuestVisibility; }
            set { SetProperty(ref _toolQuestVisibility, value); }
        }
        private bool _toolQuestVisibility;

        /// <summary>
        /// 專案管理功能。
        /// </summary>
        public bool MechaTrackFunction
        {
            get { return _mechaTrackFunction; }
            set { SetProperty(ref _mechaTrackFunction, value); }
        }
        private bool _mechaTrackFunction;

        /// <summary>
        /// 專案管理顯示。
        /// </summary>
        public bool MechaTrackVisibility
        {
            get { return _MechaTrackVisibility; }
            set { SetProperty(ref _MechaTrackVisibility, value); }
        }
        private bool _MechaTrackVisibility;

        /// <summary>
        /// 維護工單功能。
        /// </summary>
        public bool MaintiFlowFunction
        {
            get { return _maintiFlowFunction; }
            set { SetProperty(ref _maintiFlowFunction, value); }
        }
        private bool _maintiFlowFunction;

        /// <summary>
        /// 維護工單顯示。
        /// </summary>
        public bool MaintiFlowVisibility
        {
            get { return _maintiFlowVisibility; }
            set { SetProperty(ref _maintiFlowVisibility, value); }
        }
        private bool _maintiFlowVisibility;
    }
}
