﻿using Calin.TaskPulse.Core.Authority;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Event
{
    /// <summary>
    /// 使用者切換訊息。
    /// </summary>
    public class LoggedInUserChangedMessage : ValueChangedMessage<AuthorityData>
    {
        public LoggedInUserChangedMessage(AuthorityData ad) : base(ad) { }
    }
}
