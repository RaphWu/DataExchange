﻿using System.Windows.Forms;
using Autofac;
using Autofac.Core.Lifetime;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Views
{
    public partial class MainPage : UserControl
    {
        public MainPage(IRegionManager region, INavigationService nav)
        {
            InitializeComponent();

            region.RegisterRegion(nameof(TLP), TLP);
            nav.Navigate<LoginControl>(nameof(TLP), alive: false);

            var ctl = region.GetRegion(nameof(TLP)).HostControl.Controls[0];
            ctl.Dock = DockStyle.None;
            ctl.Anchor = AnchorStyles.None;
        }
    }
}
