﻿using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Views;
using Sunny.UI;

namespace Calin.TaskPulse.Views
{
    public partial class LoginForm : UIForm
    {
        private readonly ILifetimeScope _lifetimeScope;

        public LoginForm(LoginControl loginControl)
        {
            InitializeComponent();
            //_lifetimeScope = lifetimeScope;

            //using (var loginControl = _lifetimeScope.Resolve<LoginControl>())
            //{
            loginControl.Dock = DockStyle.None;
            TLP.Controls.Add(loginControl);
            //}
        }
    }
}
