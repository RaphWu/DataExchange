﻿using System.Windows.Forms;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Event;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse
{
    public partial class MainMenuControl : UserControl
    {
        public IAuthority Authority { get; set; } // 自動屬性注入

        public MainMenuControl()
        {
            InitializeComponent();

            // 註冊使用者切換事件
            WeakReferenceMessenger.Default.Register<LoggedInUserChangedMessage>(this, (r, m) =>
            {
                SetAuthority(m.Value);
            });
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="page">頁面代號。</param>
        private void SetAuthority(AuthorityData ad)
        {
            mainMenuButton_ToolQuest.Enabled = ad.CurrentAuthotization.ToolQuest;
            mainMenuButton_MechaTrack.Enabled = ad.CurrentAuthotization.MechaTrack;
            mainMenuButton_MaintiFlow.Enabled = ad.CurrentAuthotization.MaintiFlow;
        }

        /********************
         * Control Event
         ********************/
        private void mainMenuButton_SwitchUser_Click(object sender, System.EventArgs e)
        {
            Authority.SwitchAuthority();
        }
    }
}
