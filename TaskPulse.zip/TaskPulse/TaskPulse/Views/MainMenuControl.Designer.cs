﻿namespace Calin.TaskPulse.Views
{
    partial class MainMenuControl
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_MainMenu = new System.Windows.Forms.TableLayoutPanel();
            this.panel_MainMenu_Button = new System.Windows.Forms.TableLayoutPanel();
            this.mainMenuButton_ToolQuest = new Krypton.Toolkit.KryptonButton();
            this.mainMenuButton_MechaTrack = new Krypton.Toolkit.KryptonButton();
            this.mainMenuButton_MaintiFlow = new Krypton.Toolkit.KryptonButton();
            this.panel_MainMenu_FuncArray = new System.Windows.Forms.TableLayoutPanel();
            this.mainMenuButton_SwitchUser = new Krypton.Toolkit.KryptonButton();
            this.panel_MainMenu.SuspendLayout();
            this.panel_MainMenu_Button.SuspendLayout();
            this.panel_MainMenu_FuncArray.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_MainMenu
            // 
            this.panel_MainMenu.ColumnCount = 5;
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_MainMenu.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panel_MainMenu.Controls.Add(this.panel_MainMenu_Button, 1, 1);
            this.panel_MainMenu.Controls.Add(this.panel_MainMenu_FuncArray, 3, 1);
            this.panel_MainMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_MainMenu.Location = new System.Drawing.Point(0, 0);
            this.panel_MainMenu.Name = "panel_MainMenu";
            this.panel_MainMenu.RowCount = 3;
            this.panel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 520F));
            this.panel_MainMenu.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.panel_MainMenu.Size = new System.Drawing.Size(1224, 765);
            this.panel_MainMenu.TabIndex = 6;
            // 
            // panel_MainMenu_Button
            // 
            this.panel_MainMenu_Button.ColumnCount = 1;
            this.panel_MainMenu_Button.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_MainMenu_Button.Controls.Add(this.mainMenuButton_ToolQuest, 0, 1);
            this.panel_MainMenu_Button.Controls.Add(this.mainMenuButton_MechaTrack, 0, 3);
            this.panel_MainMenu_Button.Controls.Add(this.mainMenuButton_MaintiFlow, 0, 5);
            this.panel_MainMenu_Button.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_MainMenu_Button.Location = new System.Drawing.Point(273, 125);
            this.panel_MainMenu_Button.Name = "panel_MainMenu_Button";
            this.panel_MainMenu_Button.RowCount = 7;
            this.panel_MainMenu_Button.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.panel_MainMenu_Button.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.panel_MainMenu_Button.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panel_MainMenu_Button.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.panel_MainMenu_Button.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panel_MainMenu_Button.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.panel_MainMenu_Button.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.panel_MainMenu_Button.Size = new System.Drawing.Size(250, 514);
            this.panel_MainMenu_Button.TabIndex = 0;
            // 
            // mainMenuButton_ToolQuest
            // 
            this.mainMenuButton_ToolQuest.Location = new System.Drawing.Point(0, 46);
            this.mainMenuButton_ToolQuest.Margin = new System.Windows.Forms.Padding(0);
            this.mainMenuButton_ToolQuest.Name = "mainMenuButton_ToolQuest";
            this.mainMenuButton_ToolQuest.Size = new System.Drawing.Size(250, 120);
            this.mainMenuButton_ToolQuest.StateCommon.Border.Rounding = 12F;
            this.mainMenuButton_ToolQuest.StateCommon.Border.Width = 2;
            this.mainMenuButton_ToolQuest.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mainMenuButton_ToolQuest.TabIndex = 14;
            this.mainMenuButton_ToolQuest.TabStop = false;
            this.mainMenuButton_ToolQuest.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.mainMenuButton_ToolQuest.Values.Text = "工具委託";
            this.mainMenuButton_ToolQuest.Click += new System.EventHandler(this.mainMenuButton_ToolQuest_Click);
            // 
            // mainMenuButton_MechaTrack
            // 
            this.mainMenuButton_MechaTrack.Location = new System.Drawing.Point(0, 186);
            this.mainMenuButton_MechaTrack.Margin = new System.Windows.Forms.Padding(0);
            this.mainMenuButton_MechaTrack.Name = "mainMenuButton_MechaTrack";
            this.mainMenuButton_MechaTrack.Size = new System.Drawing.Size(250, 117);
            this.mainMenuButton_MechaTrack.StateCommon.Border.Rounding = 12F;
            this.mainMenuButton_MechaTrack.StateCommon.Border.Width = 2;
            this.mainMenuButton_MechaTrack.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mainMenuButton_MechaTrack.TabIndex = 16;
            this.mainMenuButton_MechaTrack.TabStop = false;
            this.mainMenuButton_MechaTrack.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.mainMenuButton_MechaTrack.Values.Text = "專案管理";
            this.mainMenuButton_MechaTrack.Click += new System.EventHandler(this.mainMenuButton_MechaTrack_Click);
            // 
            // mainMenuButton_MaintiFlow
            // 
            this.mainMenuButton_MaintiFlow.Location = new System.Drawing.Point(0, 323);
            this.mainMenuButton_MaintiFlow.Margin = new System.Windows.Forms.Padding(0);
            this.mainMenuButton_MaintiFlow.Name = "mainMenuButton_MaintiFlow";
            this.mainMenuButton_MaintiFlow.Size = new System.Drawing.Size(250, 120);
            this.mainMenuButton_MaintiFlow.StateCommon.Border.Rounding = 12F;
            this.mainMenuButton_MaintiFlow.StateCommon.Border.Width = 2;
            this.mainMenuButton_MaintiFlow.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mainMenuButton_MaintiFlow.TabIndex = 14;
            this.mainMenuButton_MaintiFlow.TabStop = false;
            this.mainMenuButton_MaintiFlow.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.mainMenuButton_MaintiFlow.Values.Text = "維護工單";
            this.mainMenuButton_MaintiFlow.Click += new System.EventHandler(this.mainMenuButton_MaintiFlow_Click);
            // 
            // panel_MainMenu_FuncArray
            // 
            this.panel_MainMenu_FuncArray.ColumnCount = 1;
            this.panel_MainMenu_FuncArray.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.panel_MainMenu_FuncArray.Controls.Add(this.mainMenuButton_SwitchUser, 0, 1);
            this.panel_MainMenu_FuncArray.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_MainMenu_FuncArray.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.AddColumns;
            this.panel_MainMenu_FuncArray.Location = new System.Drawing.Point(679, 125);
            this.panel_MainMenu_FuncArray.Name = "panel_MainMenu_FuncArray";
            this.panel_MainMenu_FuncArray.RowCount = 3;
            this.panel_MainMenu_FuncArray.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35F));
            this.panel_MainMenu_FuncArray.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.panel_MainMenu_FuncArray.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65F));
            this.panel_MainMenu_FuncArray.Size = new System.Drawing.Size(272, 514);
            this.panel_MainMenu_FuncArray.TabIndex = 1;
            // 
            // mainMenuButton_SwitchUser
            // 
            this.mainMenuButton_SwitchUser.Location = new System.Drawing.Point(3, 140);
            this.mainMenuButton_SwitchUser.Name = "mainMenuButton_SwitchUser";
            this.mainMenuButton_SwitchUser.Size = new System.Drawing.Size(218, 111);
            this.mainMenuButton_SwitchUser.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.mainMenuButton_SwitchUser.TabIndex = 0;
            this.mainMenuButton_SwitchUser.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.mainMenuButton_SwitchUser.Values.Image = global::Calin.TaskPulse.Properties.Resources.user_group_296;
            this.mainMenuButton_SwitchUser.Values.Text = "切換使用者";
            this.mainMenuButton_SwitchUser.Click += new System.EventHandler(this.mainMenuButton_SwitchUser_Click);
            // 
            // MainMenuControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel_MainMenu);
            this.Name = "MainMenuControl";
            this.Size = new System.Drawing.Size(1224, 765);
            this.Load += new System.EventHandler(this.MainMenuControl_Load);
            this.panel_MainMenu.ResumeLayout(false);
            this.panel_MainMenu_Button.ResumeLayout(false);
            this.panel_MainMenu_FuncArray.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel panel_MainMenu;
        private System.Windows.Forms.TableLayoutPanel panel_MainMenu_Button;
        private Krypton.Toolkit.KryptonButton mainMenuButton_ToolQuest;
        private Krypton.Toolkit.KryptonButton mainMenuButton_MechaTrack;
        private Krypton.Toolkit.KryptonButton mainMenuButton_MaintiFlow;
        private System.Windows.Forms.TableLayoutPanel panel_MainMenu_FuncArray;
        private Krypton.Toolkit.KryptonButton mainMenuButton_SwitchUser;
    }
}
