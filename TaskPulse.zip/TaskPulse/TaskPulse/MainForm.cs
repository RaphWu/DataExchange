﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.MaintiFlow.Views;
using Calin.TaskPulse.MechaTrack.Views;
using Calin.TaskPulse.ToolQuest.Views;
using Calin.TaskPulse.Views;
using Calin.WinForm;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse
{
    public partial class MainForm : UIForm
    {
        private readonly IContainer _container = Program.Container;
        private readonly PageManager _pageManager;

        private bool _isAdmin = false;
        private bool _isGuest = false;

        private PageCode _currentNavItem = PageCode.None; // 目前選單項目

        private readonly System.Windows.Forms.Timer _idleTimer; // 無動作計時器
        private bool _idleTriggered = false; // 是否已經觸發過

        public MainForm(ILifetimeScope lifetimeScope)
        {
            InitializeComponent();
            _pageManager = new PageManager(lifetimeScope, this);

            // 註冊使用者切換事件
            WeakReferenceMessenger.Default.Register<LoggedInUserChangedMessage>(this, (r, m) =>
            {
                SetAuthority(m.Value);
            });

            // 註冊頁面切換事件
            WeakReferenceMessenger.Default.Register<PageChangedMessage>(this, (r, m) =>
            {
                //SwitchPage(m.Value);
            });

            // UI Global Setting
            UIStyles.InitColorful(Color.FromArgb(80, 126, 164), Color.White); // 藍灰
            UIStyles.DPIScale = true;
            UIStyles.GlobalFont = true;
            UIStyles.GlobalFontName = "微軟正黑體";
            UIStyles.SetDPIScale();

            // 設定訪客模式
            using (var scope = _container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
#if DEBUG
                authority.SwitchAuthority("admin", CSharp.Security.MD5.GetMD5Hash(""));
#else
                authority.SwitchAuthorityToGuest();
#endif
            }

            ResizeScreen();

            _idleTimer = new Timer { Interval = 2000 };
            _idleTimer.Tick += idleTimer_Tick;
            // 先關閉功能 _idleTimer.Start();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            UISettings.ApplyGlobalFont(this);

            //this.MouseMove += OnUserInput;
            //this.KeyDown += OnUserInput;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.KeyDown -= OnUserInput;
            this.MouseMove -= OnUserInput;

            WeakReferenceMessenger.Default.Unregister<LoggedInUserChangedMessage>(this);
            WeakReferenceMessenger.Default.Unregister<PageChangedMessage>(this);

            _pageManager.DisposeAll();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
        }

        /// <summary>
        /// 調整視窗大小。
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1440;
            const int TARGET_HEIGHT = 900;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        /********************
         * 操作模式 & 頁面載入
         ********************/
        /// <summary>
        /// 依權限設定/重設導航主選單。
        /// </summary>
        private void SetupMenu()
        {
            TreeNode node1, node2;
            int pageIndex;

            using (var scope = _container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<AuthorityData>();
                uiNavBar.Nodes.Clear();
                uiTabControl.RemoveAllPages();

                // 主頁面
                pageIndex = (int)PageCode.MainPage;
                _pageManager.AddOrReplacePage<MainPage>(pageIndex);
                node1 = uiNavBar.CreateNode(PageCode.MainPage.GetDescription(), pageIndex);
                uiNavBar.SetNodePageIndex(node1, pageIndex);
                uiNavBar.SetNodeSymbol(node1, 559530);
                node1.Tag = pageIndex;

                // 工具委託
                if (authority.IsAdmin || authority.CurrentAuthotization.ToolQuest)
                {
                    pageIndex = (int)PageCode.ToolQuest;
                    _pageManager.AddOrReplacePage<ToolQuestPage>(pageIndex);
                    node1 = uiNavBar.CreateNode(PageCode.ToolQuest.GetDescription(), pageIndex);
                    uiNavBar.SetNodePageIndex(node1, pageIndex);
                    uiNavBar.SetNodeSymbol(node1, 57397);
                    node1.Tag = pageIndex;
                }

                // 專案管理
                if (authority.IsAdmin || authority.CurrentAuthotization.MechaTrack)
                {
                    pageIndex = (int)PageCode.MechaTrack;
                    _pageManager.AddOrReplacePage<MechaTrackPage>(pageIndex);
                    node1 = uiNavBar.CreateNode(PageCode.MechaTrack.GetDescription(), pageIndex);
                    uiNavBar.SetNodePageIndex(node1, pageIndex);
                    uiNavBar.SetNodeSymbol(node1, 261474);
                    node1.Tag = pageIndex;
                }

                // 維護工單
                if (authority.IsAdmin || authority.CurrentAuthotization.MechaTrack)
                {
                    pageIndex = (int)PageCode.MaintiFlow;
                    _pageManager.AddOrReplacePage<MaintiFlowPage>(pageIndex);
                    node1 = uiNavBar.CreateNode(PageCode.MaintiFlow.GetDescription(), pageIndex);
                    uiNavBar.SetNodePageIndex(node1, pageIndex);
                    uiNavBar.SetNodeSymbol(node1, 361613);
                    node1.Tag = pageIndex;
                }

                // 設定
                pageIndex = (int)PageCode.Setup;
                node1 = uiNavBar.CreateNode(PageCode.Setup.GetDescription(), pageIndex);
                uiNavBar.SetNodePageIndex(node1, pageIndex);
                uiNavBar.SetNodeSymbol(node1, 361459);
                node1.Tag = pageIndex;

                // 切換使用者
                pageIndex = (int)PageCode.UserLogin;
                node2 = uiNavBar.CreateChildNode(node1, PageCode.UserLogin.GetDescription(), pageIndex);
                uiNavBar.SetNodeSymbol(node2, 357448);
                node2.Tag = pageIndex;
            }

            if (uiNavBar.SelectedIndex == -1)
                uiNavBar.SelectedIndex = 0;

            uiNavBar.SelectedIndex = 0;
            uiNavBar.Refresh();
            uiTabControl.Refresh();
        }

        /// <summary>
        /// 點擊導覽列選單。
        /// </summary>
        /// <param name="itemText">選單文字。</param>
        /// <param name="menuIndex">選項索引。</param>
        /// <param name="pageIndex">頁面索引。</param>
        private void uiNavBar_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            SwitchPage(pageIndex);
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageCode">頁面代碼。</param>
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentNavItem == pageCode && PageCode.UserLogin != pageCode)
                return;

            SwitchPage((int)pageCode);
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageIndex">頁面索引。</param>
        private void SwitchPage(int pageIndex)
        {
            if (Enum.TryParse(pageIndex.ToString(), out PageCode pageCode))
            {
                switch (pageCode)
                {
                    case PageCode.MainPage:
                    case PageCode.ToolQuest:
                    case PageCode.MechaTrack:
                    case PageCode.MaintiFlow:
                        SelectPage(pageIndex);
                        break;

                    case PageCode.UserLogin:
                        Login();
                        break;
                }
            }
        }

        ///// <summary>
        ///// 載入頁面。
        ///// </summary>
        ///// <param name="page">頁面物件。</param>
        //private void LoadPage(UIForm page)
        //{
        //    uiPanel_Content.Controls.Clear();
        //    if (page != null)
        //    {

        //        page.Dock = DockStyle.Fill;
        //        uiPanel_Content.Controls.Add(page);
        //    }
        //}

        /********************
         * 權限
         ********************/
        private void SetAuthority(AuthorityData ad)
        {
            _isAdmin = ad.IsAdmin;
            _isGuest = ad.IsGuest;
            CurrentUser.Text = ad.CurrentUserTitle; // StatusBar 顯示目前使用者
            SetupMenu(); // 依權限重設選單

            if (_isGuest) // 設定無動作偵測
                _idleTriggered = false;
        }

        /// <summary>
        /// 登入對話框。
        /// </summary>
        private void Login()
        {
            using (var scope = _container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                if (!authority.SwitchAuthorityByDialog())
                    SetAuthority(scope.Resolve<AuthorityData>());
            }
        }

        /********************
         * 無動作偵測
         ********************/
        private void OnUserInput(object sender, EventArgs e)
        {
            // ResetIdleTimer
            if (!_isGuest) return;

            _idleTimer.Stop();
            _idleTimer.Start();
            _idleTriggered = false;
        }

        private void idleTimer_Tick(object sender, EventArgs e)
        {
            if (!_idleTriggered)
            {
                _idleTriggered = true;
                Login();
            }
        }

        /********************
         * 系統事件
         ********************/
        private void clockTimer_Tick(object sender, EventArgs e)
        {
            Clock.Text = DateTime.Now.DateTimeString();
        }
    }
}
