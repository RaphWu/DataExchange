﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Extensions;
using Calin.TaskPulse.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Views;
using Calin.TaskPulse.MechaTrack;
using Calin.TaskPulse.MechaTrack.Views;
using Calin.TaskPulse.ToolQuest;
using Calin.TaskPulse.ToolQuest.Views;
using Calin.TaskPulse.Views;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse
{
    public partial class MainForm : UIForm
    {
        internal static new IContainer Container { get; set; }
        private NavBarManager _navBarManager;
        private PageCode _currentNavMenu = (int)PageCode.None; // 目前主導航選單
        private PageCode _currentNavItem = (int)PageCode.None;    // 目前選單項目

        public MainForm()
        {
            InitializeComponent();

            // IoC & Module
            var builder = new ContainerBuilder();
            builder.RegisterModule(new CoreModule());
            builder.RegisterModule(new MainModule());
            builder.RegisterModule(new ToolQuestMoudle());
            builder.RegisterModule(new MechaTrackModule());
            builder.RegisterModule(new MaintiFlowModule());
            Container = builder.Build();

            // 註冊使用者切換事件
            WeakReferenceMessenger.Default.Register<LoggedInUserChangedMessage>(this, (r, m) =>
            {
                SetAuthority(m.Value);
            });

            // 註冊頁面切換事件
            WeakReferenceMessenger.Default.Register<PageChangedMessage>(this, (r, m) =>
            {
                //SwitchPage(m.Value);
            });

            // UI Global Setting
            UIStyles.InitColorful(Color.FromArgb(80, 126, 164), Color.White); // 藍灰
            UIStyles.DPIScale = true;
            UIStyles.GlobalFont = true;
            UIStyles.GlobalFontName = "微軟正黑體";
            UIStyles.SetDPIScale();


            //_navBarManager = new NavBarManager(uiNavBar);

            //_navBarManager.AddNode(PageCode.MainPage.GetDescription(), PageCode.MainPage, 0);
            //_navBarManager.AddNode(PageCode.ToolQuest.GetDescription(), PageCode.ToolQuest, 1);
            //_navBarManager.AddNode(PageCode.MechaTrack.GetDescription(), PageCode.MechaTrack, 2);
            //_navBarManager.AddNode(PageCode.MaintiFlow.GetDescription(), PageCode.MaintiFlow, 3);
            //_navBarManager.AddNode(PageCode.Setup.GetDescription(), PageCode.Setup, 4);

            // 設定訪客模式
            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthorityToGuest();
            }

            ResizeScreen();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            WeakReferenceMessenger.Default.Unregister<LoggedInUserChangedMessage>(this);
            WeakReferenceMessenger.Default.Unregister<PageChangedMessage>(this);
        }

        /// <summary>
        /// 調整視窗大小。
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1440;
            const int TARGET_HEIGHT = 900;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        /// <summary>
        /// 依權限設定/重設導航主選單。
        /// </summary>
        private void SetupMenu()
        {
            TreeNode nodeSelected = null;
            TreeNode node1, node2;
            int pageIndex;

            int rootItem = (int)_currentNavMenu;
            bool currentPageExist = false;

            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<AuthorityData>();
                uiNavBar.Nodes.Clear();
                uiTabControl.RemoveAllPages();

                // 主頁面
                pageIndex = (int)PageCode.MainPage;
                AddPage(new MainPage(), pageIndex);
                node1 = uiNavBar.CreateNode(PageCode.MainPage.GetDescription(), (int)PageCode.MainPage);
                uiNavBar.SetNodePageIndex(node1, pageIndex);
                uiNavBar.SetNodeSymbol(node1, 559530);
                node1.Tag = pageIndex;
                //currentPageExist = pageIndex == rootItem;
                //if (currentPageExist)
                //    nodeSelected = node1;

                // 工具委託
                if (authority.IsAdmin || authority.CurrentAuthotization.ToolQuest)
                {
                    pageIndex = (int)PageCode.ToolQuest;
                    AddPage(new ToolQuestPage(), pageIndex);
                    node1 = uiNavBar.CreateNode(PageCode.ToolQuest.GetDescription(), (int)PageCode.ToolQuest);
                    uiNavBar.SetNodePageIndex(node1, pageIndex);
                    uiNavBar.SetNodeSymbol(node1, 57397);
                    node1.Tag = pageIndex;
                    //if (!currentPageExist)
                    //    currentPageExist = pageIndex == rootItem;
                    //if (currentPageExist)
                    //    nodeSelected = node1;
                }

                // 專案管理
                if (authority.IsAdmin || authority.CurrentAuthotization.MechaTrack)
                {
                    pageIndex = (int)PageCode.MechaTrack;
                    AddPage(new MechaTrackPage(), pageIndex);
                    node1 = uiNavBar.CreateNode(PageCode.MechaTrack.GetDescription(), (int)PageCode.MechaTrack);
                    uiNavBar.SetNodePageIndex(node1, pageIndex);
                    uiNavBar.SetNodeSymbol(node1, 261474);
                    node1.Tag = pageIndex;
                    if (!currentPageExist)
                        currentPageExist = pageIndex == rootItem;
                    if (currentPageExist)
                        nodeSelected = node1;
                }

                // 維護工單
                if (authority.IsAdmin || authority.CurrentAuthotization.MechaTrack)
                {
                    pageIndex = (int)PageCode.MaintiFlow;
                    AddPage(new MaintiFlowPage(), (int)PageCode.MaintiFlow);
                    node1 = uiNavBar.CreateNode(PageCode.MaintiFlow.GetDescription(), (int)PageCode.MaintiFlow);
                    uiNavBar.SetNodePageIndex(node1, pageIndex);
                    uiNavBar.SetNodeSymbol(node1, 361613);
                    node1.Tag = pageIndex;
                    //if (!currentPageExist)
                    //    currentPageExist = pageIndex == rootItem;
                    //if (currentPageExist)
                    //    nodeSelected = node1;
                }

                // 設定
                pageIndex = (int)PageCode.Setup;
                node1 = uiNavBar.CreateNode(PageCode.Setup.GetDescription(), (int)PageCode.Setup);
                uiNavBar.SetNodePageIndex(node1, pageIndex);
                uiNavBar.SetNodeSymbol(node1, 361459);
                node1.Tag = pageIndex;
                //if (!currentPageExist)
                //    currentPageExist = pageIndex == rootItem;
                //if (currentPageExist)
                //    nodeSelected = node1;

                // 切換使用者
                node2 = uiNavBar.CreateChildNode(node1,
                                                 PageCode.UserLogin.GetDescription(),
                                                 (int)PageCode.UserLogin);
                uiNavBar.SetNodeSymbol(node2, 357448);
                node2.Tag = pageIndex;

                if (uiNavBar.SelectedIndex == -1)
                    uiNavBar.SelectedIndex = 0;
                uiNavBar.Refresh();

                if (nodeSelected != null && (int)nodeSelected.Tag != (int)PageCode.Setup)
                {
                    nodeSelected.Checked = true;
                    SwitchPage((int)nodeSelected.Tag);
                }
                else
                {
                    SwitchPage(PageCode.MainPage);
                }
            }

            uiNavBar.SelectedIndex = 0;
            uiNavBar.Refresh();
            uiTabControl.Refresh();
        }

        /********************
         * 操作模式 & 頁面載入
         ********************/
        /// <summary>
        /// 點擊導覽列選單。
        /// </summary>
        /// <param name="itemText">選單文字。</param>
        /// <param name="menuIndex">選項索引。</param>
        /// <param name="pageIndex">頁面索引。</param>
        private void uiNavBar_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            //_currentNavMenu = (PageCode)Enum.Parse(typeof(PageCode), uiNavBar.Nodes[menuIndex].Tag.ToString());
            SwitchPage(pageIndex);
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageCode">頁面代碼。</param>
        private void SwitchPage(PageCode pageCode)
        {
            UIPage page;

            if (_currentNavItem == pageCode && PageCode.UserLogin != pageCode)
                return;

            switch (pageCode)
            {
                //case PageCode.MainPage:
                //    page = Container.Resolve<MainPage>();
                //    LoadPage(page);
                //    break;

                //case PageCode.ToolQuest:
                //    page = Container.Resolve<ToolQuestPage>();
                //    LoadPage(page);
                //    break;

                //case PageCode.MechaTrack:
                //    page = Container.Resolve<MechaTrackPage>();
                //    LoadPage(page);
                //    break;

                //case PageCode.MaintiFlow:
                //    page = Container.Resolve<MaintiFlowPage>();
                //    LoadPage(page);
                //    break;

                case PageCode.UserLogin:
                    Login();
                    break;

                    //default:
                    //    return;
            }

            _currentNavItem = pageCode;
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageIndex">頁面索引。</param>
        private void SwitchPage(int pageIndex)
        {
            SwitchPage((PageCode)Enum.Parse(typeof(PageCode), pageIndex.ToString()));
        }

        /// <summary>
        /// 載入頁面。
        /// </summary>
        /// <param name="page">頁面物件。</param>
        private void LoadPage(UIUserControl page)
        {
            //uiPanel.Controls.Clear();
            //if (page != null)
            //{
            //    page.Dock = DockStyle.Fill;
            //    uiPanel.Controls.Add(page);
            //}
        }

        /********************
         * 權限
         ********************/
        private void SetAuthority(AuthorityData ad)
        {
            CurrentUser.Text = ad.CurrentUserTitle; // StatusBar 顯示目前使用者
            SetupMenu(); // 依權限重設選單
        }

        /// <summary>
        /// 登入對話框。
        /// </summary>
        private void Login()
        {
            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthorityByDialog();
            }
        }

        /********************
         * 系統事件
         ********************/
        private void clockTimer_Tick(object sender, EventArgs e)
        {
            Clock.Text = DateTime.Now.DateTimeString();
        }

        /********************
         * Control 事件
         ********************/
    }
}
