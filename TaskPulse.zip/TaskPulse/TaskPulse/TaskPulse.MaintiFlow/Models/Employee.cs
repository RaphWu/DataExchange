﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 員工清單。
    /// </summary>
    public class Employee
    {
        /// <summary>
        /// 工號。
        /// </summary>
        [Description("工號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string EmployeeId { get; set; }

        /// <summary>
        /// 部門。
        /// </summary>
        [Description("部門")]
        public string Department { get; set; }

        /// <summary>
        /// 職稱。
        /// </summary>
        [Description("職稱")]
        public string Title { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        [Description("姓名")]
        [Required]
        public string Name { get; set; }

        /// <summary>
        /// 是否為維護工程師。
        /// </summary>
        [Description("維護工程師")]
        public bool IsEngineer { get; set; }

        public virtual string CreatorId { get; set; }
        public virtual ICollection<TaskOrder> TaskOrders { get; set; }
        public virtual ICollection<TaskOrderEngineer> TaskOrdersAsEngineer { get; set; }
    }
}
