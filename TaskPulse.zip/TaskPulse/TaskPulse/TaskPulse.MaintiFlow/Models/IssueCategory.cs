﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 問題分類清單。
    /// </summary>
    public class IssueCategory
    {
        /// <summary>
        /// 問題分類代號。
        /// </summary>
        [Description("分類代號")]
        [Key]
        public int CategoryId { get; set; }

        /// <summary>
        /// 問題分類名稱。
        /// </summary>
        [Description("分類名稱")]
        public string CategoryName { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        [Description("編號")]
        public int OrderNo { get; set; }
    }
}
