﻿using Autofac;

namespace Calin.TaskPulse
{
    internal class MainModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<MainMenuControl>().AsSelf().PropertiesAutowired();
        }
    }
}
