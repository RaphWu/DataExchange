﻿using System;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.MaintiFlow;
using Calin.TaskPulse.MechaTrack;
using Calin.TaskPulse.ToolQuest;

namespace Calin.TaskPulse
{
    internal static class Program
    {
        public static IContainer Container { get; private set; }

        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 註冊頁面與服務
            var builder = new ContainerBuilder();
            builder.RegisterType<MainForm>();
            builder.RegisterModule(new MaintiFlowModule());
            builder.RegisterModule(new MechaTrackModule());
            builder.RegisterModule(new ToolQuestMoudle());
            builder.RegisterModule(new MainModule());
            builder.RegisterModule(new CoreModule());

            //builder.RegisterModule(new CoreModule());
            //builder.RegisterModule(new MainModule());
            //builder.RegisterModule(new ToolQuestMoudle());
            //builder.RegisterModule(new MechaTrackModule());
            //builder.RegisterModule(new MaintiFlowModule());
            Container = builder.Build();

            using (var scope = Container.BeginLifetimeScope())
            {
                var mainForm = scope.Resolve<MainForm>();
                Application.Run(mainForm);
            }
        }
    }
}
