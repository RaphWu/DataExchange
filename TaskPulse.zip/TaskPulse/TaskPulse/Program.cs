﻿using System;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.MaintiFlow;
using Calin.TaskPulse.MechaTrack;
using Calin.TaskPulse.ToolQuest;
using Serilog;
using Serilog.Formatting.Json;
using TaskPulse.Entity;

namespace Calin.TaskPulse
{
    internal static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 註冊模組
            var builder = new ContainerBuilder();
            builder.RegisterType<MainForm>();

            builder.RegisterModule(new MaintiFlowModule());
            builder.RegisterModule(new MechaTrackModule());
            builder.RegisterModule(new ToolQuestMoudle());
            builder.RegisterModule(new MainModule());
            builder.RegisterModule(new CoreModule());
            builder.RegisterModule(new EntityModule());

            builder.RegisterInstance(Log.Logger)
               .As<Serilog.ILogger>()
               .SingleInstance();

            var container = builder.Build();

            using (var scope = container.BeginLifetimeScope())
            {
                var mainForm = scope.Resolve<MainForm>();
                Application.Run(mainForm);
            }
        }
    }
}
