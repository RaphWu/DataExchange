﻿namespace Calin.TaskPulse
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.uiContextMenuStrip_Setup = new Sunny.UI.UIContextMenuStrip();
            this.toolStripMenuItem_SwitchUser = new System.Windows.Forms.ToolStripMenuItem();
            this.Footer = new Sunny.UI.UIPanel();
            this.CurrentUser = new Sunny.UI.UIPanel();
            this.SystemMessage = new Sunny.UI.UIPanel();
            this.Clock = new Sunny.UI.UIPanel();
            this.clockTimer = new System.Windows.Forms.Timer(this.components);
            this.uiStyleManager = new Sunny.UI.UIStyleManager(this.components);
            this.Header = new Sunny.UI.UIPanel();
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiNavBar = new Sunny.UI.UINavBar();
            this.uiTabControl = new Sunny.UI.UITabControl();
            this.uiContextMenuStrip_Setup.SuspendLayout();
            this.Footer.SuspendLayout();
            this.Header.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiContextMenuStrip_Setup
            // 
            this.uiContextMenuStrip_Setup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiContextMenuStrip_Setup.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiContextMenuStrip_Setup.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_SwitchUser});
            this.uiContextMenuStrip_Setup.Name = "uiContextMenuStrip_Setup";
            this.uiContextMenuStrip_Setup.Size = new System.Drawing.Size(159, 28);
            // 
            // toolStripMenuItem_SwitchUser
            // 
            this.toolStripMenuItem_SwitchUser.Name = "toolStripMenuItem_SwitchUser";
            this.toolStripMenuItem_SwitchUser.Size = new System.Drawing.Size(158, 24);
            this.toolStripMenuItem_SwitchUser.Text = "切換使用者";
            // 
            // Footer
            // 
            this.Footer.Controls.Add(this.CurrentUser);
            this.Footer.Controls.Add(this.SystemMessage);
            this.Footer.Controls.Add(this.Clock);
            this.Footer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Footer.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Footer.Location = new System.Drawing.Point(2, 598);
            this.Footer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Footer.MinimumSize = new System.Drawing.Size(1, 1);
            this.Footer.Name = "Footer";
            this.Footer.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Footer.Size = new System.Drawing.Size(996, 25);
            this.Footer.TabIndex = 3;
            this.Footer.Text = null;
            this.Footer.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CurrentUser
            // 
            this.CurrentUser.Dock = System.Windows.Forms.DockStyle.Right;
            this.CurrentUser.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CurrentUser.Location = new System.Drawing.Point(686, 0);
            this.CurrentUser.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CurrentUser.MinimumSize = new System.Drawing.Size(1, 1);
            this.CurrentUser.Name = "CurrentUser";
            this.CurrentUser.Radius = 0;
            this.CurrentUser.RectSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)(((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)));
            this.CurrentUser.Size = new System.Drawing.Size(140, 25);
            this.CurrentUser.TabIndex = 2;
            this.CurrentUser.Text = "CurrentUser";
            this.CurrentUser.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SystemMessage
            // 
            this.SystemMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SystemMessage.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.SystemMessage.Location = new System.Drawing.Point(0, 0);
            this.SystemMessage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SystemMessage.MinimumSize = new System.Drawing.Size(1, 1);
            this.SystemMessage.Name = "SystemMessage";
            this.SystemMessage.Radius = 0;
            this.SystemMessage.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Top;
            this.SystemMessage.Size = new System.Drawing.Size(826, 25);
            this.SystemMessage.TabIndex = 1;
            this.SystemMessage.Text = null;
            this.SystemMessage.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Clock
            // 
            this.Clock.Dock = System.Windows.Forms.DockStyle.Right;
            this.Clock.Font = new System.Drawing.Font("Cambria", 11F);
            this.Clock.Location = new System.Drawing.Point(826, 0);
            this.Clock.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Clock.MinimumSize = new System.Drawing.Size(1, 1);
            this.Clock.Name = "Clock";
            this.Clock.Radius = 0;
            this.Clock.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Top;
            this.Clock.Size = new System.Drawing.Size(170, 25);
            this.Clock.TabIndex = 0;
            this.Clock.Text = "Clock";
            this.Clock.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clockTimer
            // 
            this.clockTimer.Enabled = true;
            this.clockTimer.Tick += new System.EventHandler(this.clockTimer_Tick);
            // 
            // uiStyleManager
            // 
            this.uiStyleManager.DPIScale = true;
            this.uiStyleManager.GlobalFont = true;
            this.uiStyleManager.GlobalFontName = "微軟正黑體";
            // 
            // Header
            // 
            this.Header.Controls.Add(this.uiLine1);
            this.Header.Controls.Add(this.uiNavBar);
            this.Header.Dock = System.Windows.Forms.DockStyle.Top;
            this.Header.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Header.Location = new System.Drawing.Point(2, 36);
            this.Header.Margin = new System.Windows.Forms.Padding(0);
            this.Header.MinimumSize = new System.Drawing.Size(1, 1);
            this.Header.Name = "Header";
            this.Header.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.Header.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Header.Size = new System.Drawing.Size(996, 50);
            this.Header.TabIndex = 6;
            this.Header.Text = null;
            this.Header.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiLine1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.uiLine1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.LineSize = 2;
            this.uiLine1.Location = new System.Drawing.Point(0, 48);
            this.uiLine1.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiLine1.Size = new System.Drawing.Size(996, 2);
            this.uiLine1.TabIndex = 6;
            this.uiLine1.TextInterval = 0;
            // 
            // uiNavBar
            // 
            this.uiNavBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiNavBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.uiNavBar.DropMenuFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiNavBar.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiNavBar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiNavBar.Location = new System.Drawing.Point(0, 0);
            this.uiNavBar.MenuHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.uiNavBar.MenuSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.uiNavBar.MenuStyle = Sunny.UI.UIMenuStyle.White;
            this.uiNavBar.Name = "uiNavBar";
            this.uiNavBar.NodeInterval = 60;
            this.uiNavBar.NodeSize = new System.Drawing.Size(110, 40);
            this.uiNavBar.Size = new System.Drawing.Size(996, 50);
            this.uiNavBar.TabIndex = 5;
            this.uiNavBar.MenuItemClick += new Sunny.UI.UINavBar.OnMenuItemClick(this.uiNavBar_MenuItemClick);
            // 
            // uiTabControl
            // 
            this.uiTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTabControl.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.uiTabControl.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiTabControl.ItemSize = new System.Drawing.Size(0, 1);
            this.uiTabControl.Location = new System.Drawing.Point(2, 86);
            this.uiTabControl.MainPage = "";
            this.uiTabControl.MenuStyle = Sunny.UI.UIMenuStyle.White;
            this.uiTabControl.Name = "uiTabControl";
            this.uiTabControl.SelectedIndex = 0;
            this.uiTabControl.Size = new System.Drawing.Size(996, 512);
            this.uiTabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.uiTabControl.TabBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiTabControl.TabIndex = 7;
            this.uiTabControl.TabSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.uiTabControl.TabUnSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiTabControl.TabUnSelectedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiTabControl.TabVisible = false;
            this.uiTabControl.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1000, 625);
            this.CloseAskString = "";
            this.Controls.Add(this.uiTabControl);
            this.Controls.Add(this.Header);
            this.Controls.Add(this.Footer);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(2, 36, 2, 2);
            this.Resizable = true;
            this.ShowDragStretch = true;
            this.Text = "TaskPulse";
            this.TitleColor = System.Drawing.Color.SteelBlue;
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 800, 450);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.uiContextMenuStrip_Setup.ResumeLayout(false);
            this.Footer.ResumeLayout(false);
            this.Header.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UIPanel Footer;
        private Sunny.UI.UIPanel Clock;
        private System.Windows.Forms.Timer clockTimer;
        private Sunny.UI.UIPanel SystemMessage;
        private Sunny.UI.UIPanel CurrentUser;
        private Sunny.UI.UIContextMenuStrip uiContextMenuStrip_Setup;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_SwitchUser;
        private Sunny.UI.UIStyleManager uiStyleManager;
        private Sunny.UI.UIPanel Header;
        private Sunny.UI.UINavBar uiNavBar;
        private Sunny.UI.UILine uiLine1;
        private Sunny.UI.UITabControl uiTabControl;
    }
}

