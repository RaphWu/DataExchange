﻿namespace Counter_ContinueCompare
{
    partial class ContinueCompareForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ContinueCompareForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtTab2Data2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTab2Data1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTab2Data0 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtTab1Data2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTab1Data1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTab1Data0 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtInt2Count = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtInt2Increment = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtInt2FirstValue = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtInt1Count = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtInt1Increment = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtInt1FirstValue = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.radInterval = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.txtCounterValue = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPMCount = new System.Windows.Forms.TextBox();
            this.txtEndCount = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.radTable = new System.Windows.Forms.RadioButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.udCounterCtrl1 = new Automation.BDaq.UdCounterCtrl(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Location = new System.Drawing.Point(12, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(183, 222);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtTab2Data2);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.txtTab2Data1);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.txtTab2Data0);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Location = new System.Drawing.Point(8, 114);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(167, 101);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Table 2";
            // 
            // txtTab2Data2
            // 
            this.txtTab2Data2.Location = new System.Drawing.Point(101, 72);
            this.txtTab2Data2.Name = "txtTab2Data2";
            this.txtTab2Data2.Size = new System.Drawing.Size(60, 21);
            this.txtTab2Data2.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "CompareData2:";
            // 
            // txtTab2Data1
            // 
            this.txtTab2Data1.Location = new System.Drawing.Point(101, 44);
            this.txtTab2Data1.Name = "txtTab2Data1";
            this.txtTab2Data1.Size = new System.Drawing.Size(60, 21);
            this.txtTab2Data1.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "CompareData1:";
            // 
            // txtTab2Data0
            // 
            this.txtTab2Data0.Location = new System.Drawing.Point(101, 17);
            this.txtTab2Data0.Name = "txtTab2Data0";
            this.txtTab2Data0.Size = new System.Drawing.Size(60, 21);
            this.txtTab2Data0.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "CompareData0:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtTab1Data2);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.txtTab1Data1);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.txtTab1Data0);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(10, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(167, 101);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Table 1";
            // 
            // txtTab1Data2
            // 
            this.txtTab1Data2.Location = new System.Drawing.Point(101, 72);
            this.txtTab1Data2.Name = "txtTab1Data2";
            this.txtTab1Data2.Size = new System.Drawing.Size(60, 21);
            this.txtTab1Data2.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "CompareData2:";
            // 
            // txtTab1Data1
            // 
            this.txtTab1Data1.Location = new System.Drawing.Point(101, 44);
            this.txtTab1Data1.Name = "txtTab1Data1";
            this.txtTab1Data1.Size = new System.Drawing.Size(60, 21);
            this.txtTab1Data1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "CompareData1:";
            // 
            // txtTab1Data0
            // 
            this.txtTab1Data0.Location = new System.Drawing.Point(101, 17);
            this.txtTab1Data0.Name = "txtTab1Data0";
            this.txtTab1Data0.Size = new System.Drawing.Size(60, 21);
            this.txtTab1Data0.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "CompareData0:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox7);
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Location = new System.Drawing.Point(205, 43);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(169, 222);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtInt2Count);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.Controls.Add(this.txtInt2Increment);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.txtInt2FirstValue);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Location = new System.Drawing.Point(10, 115);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(149, 101);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Interval 2";
            // 
            // txtInt2Count
            // 
            this.txtInt2Count.Location = new System.Drawing.Point(81, 72);
            this.txtInt2Count.Name = "txtInt2Count";
            this.txtInt2Count.Size = new System.Drawing.Size(60, 21);
            this.txtInt2Count.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 15);
            this.label10.TabIndex = 10;
            this.label10.Text = "Count:";
            // 
            // txtInt2Increment
            // 
            this.txtInt2Increment.Location = new System.Drawing.Point(80, 44);
            this.txtInt2Increment.Name = "txtInt2Increment";
            this.txtInt2Increment.Size = new System.Drawing.Size(60, 21);
            this.txtInt2Increment.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 44);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 15);
            this.label11.TabIndex = 8;
            this.label11.Text = "Increment:";
            // 
            // txtInt2FirstValue
            // 
            this.txtInt2FirstValue.Location = new System.Drawing.Point(80, 15);
            this.txtInt2FirstValue.Name = "txtInt2FirstValue";
            this.txtInt2FirstValue.Size = new System.Drawing.Size(60, 21);
            this.txtInt2FirstValue.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 15);
            this.label12.TabIndex = 6;
            this.label12.Text = "FirstValue:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtInt1Count);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.txtInt1Increment);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.txtInt1FirstValue);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Location = new System.Drawing.Point(10, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(149, 101);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Interval 1";
            // 
            // txtInt1Count
            // 
            this.txtInt1Count.Location = new System.Drawing.Point(81, 72);
            this.txtInt1Count.Name = "txtInt1Count";
            this.txtInt1Count.Size = new System.Drawing.Size(60, 21);
            this.txtInt1Count.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Count:";
            // 
            // txtInt1Increment
            // 
            this.txtInt1Increment.Location = new System.Drawing.Point(80, 44);
            this.txtInt1Increment.Name = "txtInt1Increment";
            this.txtInt1Increment.Size = new System.Drawing.Size(60, 21);
            this.txtInt1Increment.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "Increment:";
            // 
            // txtInt1FirstValue
            // 
            this.txtInt1FirstValue.Location = new System.Drawing.Point(80, 15);
            this.txtInt1FirstValue.Name = "txtInt1FirstValue";
            this.txtInt1FirstValue.Size = new System.Drawing.Size(60, 21);
            this.txtInt1FirstValue.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 15);
            this.label9.TabIndex = 6;
            this.label9.Text = "FirstValue:";
            // 
            // radInterval
            // 
            this.radInterval.AutoSize = true;
            this.radInterval.Location = new System.Drawing.Point(215, 31);
            this.radInterval.Name = "radInterval";
            this.radInterval.Size = new System.Drawing.Size(118, 19);
            this.radInterval.TabIndex = 8;
            this.radInterval.TabStop = true;
            this.radInterval.Text = "Compare interval";
            this.radInterval.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnStop);
            this.groupBox3.Controls.Add(this.btnStart);
            this.groupBox3.Controls.Add(this.txtCounterValue);
            this.groupBox3.Location = new System.Drawing.Point(385, 43);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(129, 222);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(21, 170);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(87, 24);
            this.btnStop.TabIndex = 2;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(20, 106);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(87, 24);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // txtCounterValue
            // 
            this.txtCounterValue.Location = new System.Drawing.Point(9, 27);
            this.txtCounterValue.Name = "txtCounterValue";
            this.txtCounterValue.Size = new System.Drawing.Size(110, 21);
            this.txtCounterValue.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(0, 282);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(195, 15);
            this.label13.TabIndex = 3;
            this.label13.Text = "Pattern match event capture count:";
            // 
            // txtPMCount
            // 
            this.txtPMCount.Location = new System.Drawing.Point(201, 282);
            this.txtPMCount.Name = "txtPMCount";
            this.txtPMCount.ReadOnly = true;
            this.txtPMCount.Size = new System.Drawing.Size(67, 21);
            this.txtPMCount.TabIndex = 4;
            // 
            // txtEndCount
            // 
            this.txtEndCount.Location = new System.Drawing.Point(428, 279);
            this.txtEndCount.Name = "txtEndCount";
            this.txtEndCount.ReadOnly = true;
            this.txtEndCount.Size = new System.Drawing.Size(76, 21);
            this.txtEndCount.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(274, 282);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(148, 15);
            this.label14.TabIndex = 6;
            this.label14.Text = "Compare table end count:";
            // 
            // radTable
            // 
            this.radTable.AutoSize = true;
            this.radTable.Checked = true;
            this.radTable.Location = new System.Drawing.Point(22, 31);
            this.radTable.Name = "radTable";
            this.radTable.Size = new System.Drawing.Size(106, 19);
            this.radTable.TabIndex = 7;
            this.radTable.TabStop = true;
            this.radTable.Text = "Compare table";
            this.radTable.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // udCounterCtrl1
            // 
            this.udCounterCtrl1._StateStream = ((Automation.BDaq.DeviceStateStreamer)(resources.GetObject("udCounterCtrl1._StateStream")));
            this.udCounterCtrl1.UdCntrEvent += new System.EventHandler<Automation.BDaq.UdCntrEventArgs>(this.udCounterCtrl1_UdCntrEvent);
            // 
            // ContinueCompareForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(526, 312);
            this.Controls.Add(this.radInterval);
            this.Controls.Add(this.radTable);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtEndCount);
            this.Controls.Add(this.txtPMCount);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ContinueCompareForm";
            this.Text = "ContinueCompare";
            this.Load += new System.EventHandler(this.ContinueCompareForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTab1Data0;
        private System.Windows.Forms.TextBox txtTab1Data2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTab1Data1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtTab2Data2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTab2Data1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTab2Data0;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtInt1Count;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtInt1Increment;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtInt1FirstValue;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtInt2Count;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtInt2Increment;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtInt2FirstValue;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCounterValue;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtPMCount;
        private System.Windows.Forms.TextBox txtEndCount;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton radTable;
        private System.Windows.Forms.RadioButton radInterval;
        private System.Windows.Forms.Timer timer1;
        private Automation.BDaq.UdCounterCtrl udCounterCtrl1;
    }
}

