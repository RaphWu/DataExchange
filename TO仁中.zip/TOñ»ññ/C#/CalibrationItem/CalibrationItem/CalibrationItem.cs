﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Automation.BDaq;

namespace CalibrationItem
{
   public partial class CalibrationItem : Form
   {
      CalibrationCtrl m_cali_ctrl;
      
      CaliSolution[]  m_sln_list;
      CaliSection[]   m_sect_list;
      CaliSubject[]   m_subj_list;

      int m_sln_idx;
      int m_sect_idx;
      int m_subj_idx;

      bool m_ai_auto_matching;
      bool m_ai_manual_matching;
      bool m_ao_auto_matching;
      bool m_ao_manual_matching;

      int  RelatedCountMax = 8;
      int  RelatedCount    = 1;

      public CalibrationItem()
      {
         InitializeComponent();

         m_cali_ctrl = new CalibrationCtrl();

         Initialize();
      }

      private void Initialize()
      {
         btn_Config.Enabled = true;
         btn_Start.Enabled = true;
         btn_Stop.Enabled = false;
         btn_Save.Enabled = false;
         spb_adj_code.Enabled = false;
         table_list_result.Enabled = false;
         textBox_read_value.Enabled = false;

         m_sln_idx = 0;
         m_sect_idx = 0;
         m_subj_idx = 0;

         ConfigureDevice();
      }

      private void ConfigureDevice()
      {
         m_cali_ctrl.SelectedDevice = new DeviceInformation(ConfigureParameter.deviceName);
         this.Text = "Calibration Item(" + ConfigureParameter.deviceName + ")";

         m_sln_idx = ConfigureParameter.slnIdx;
         m_sln_list = m_cali_ctrl.Solutions;
         string sln_desc = m_sln_list[m_sln_idx].Description;

         //check info again.
         bool is_matching = string.Equals(sln_desc, ConfigureParameter.slnName);
         if (!is_matching){
            MessageBox.Show("The description based on Solution index DO NOT match to driver!", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
         }
         //Console.WriteLine("{0}\n", is_matching);

         //Solution Info
         lbl_sln_desc.Text = sln_desc;
         textBox_sln_instrc.Text = m_sln_list[m_sln_idx].Instruction;

         //Section Info
         m_sect_list = m_sln_list[m_sln_idx].Sections;
         
         cmb_sect_desc.Items.Clear();
         for (int i = 0; i < m_sect_list.Length; i++)
         {
            string sect_desc = m_sect_list[i].Description;
            cmb_sect_desc.Items.Add(sect_desc);          
         }
         cmb_sect_desc.SelectedIndex = 0;
         m_sect_idx = cmb_sect_desc.SelectedIndex;
         textBox_sect_instrc.Text = m_sect_list[m_sect_idx].Instruction;

         SectionTypeCheck();

         //Subject Info
         m_subj_list = m_sect_list[m_sect_idx].Subjects;

         cmb_subj_desc.Items.Clear();
         if(m_ai_manual_matching || m_ao_manual_matching)
         {
            for (int i = 0; i < m_subj_list.Length; i++)
            {
               string subj_desc = m_subj_list[i].Description;
               cmb_subj_desc.Items.Add(subj_desc);
            }
            cmb_subj_desc.SelectedIndex = 0;
            m_subj_idx = cmb_subj_desc.SelectedIndex;

            textBox_subj_instrc.Text = m_subj_list[m_subj_idx].Instruction;
            textBox_subj_target.Text = m_subj_list[m_subj_idx].TargetRange;

            double value = 0;
            int refCount = 0;
            int[] adjustCode = new int[RelatedCountMax];
            
            CaliState caliState = m_subj_list[m_subj_idx].AdjCodeGetCurrentState(out value, ref refCount, adjustCode);
            textBox_read_value.Text = value.ToString();

            int[] lowerVal = new int[RelatedCountMax];
            int[] upperVal = new int[RelatedCountMax];
            m_subj_list[m_subj_idx].AdjCodeGetRange(lowerVal, upperVal);

            int idx = refCount - 1;
            spb_adj_code.Minimum = lowerVal[idx];
            spb_adj_code.Maximum = upperVal[idx];
            spb_adj_code.Value = adjustCode[idx];
         }

         if (m_ai_auto_matching || m_ao_auto_matching)
         {
            InitTableList();
         }

         SettingWidgetsState();
      }

      private void onCmbSect_Changed(object sender, EventArgs e)
      {
         m_sect_idx = cmb_sect_desc.SelectedIndex;

         //table_list_result.Rows.Clear();
         table_list_result.Columns.Clear();
         textBox_sect_instrc.Text = m_sect_list[m_sect_idx].Instruction;
         
         SectionTypeCheck();         
         onCmbSubj_Changed(this, e);
      }

      private void onCmbSubj_Changed(object sender, EventArgs e)
      {
         m_subj_list = m_sect_list[m_sect_idx].Subjects;

         if (sender != cmb_subj_desc)
         {
            SubjectChangeForComponentsClear();

            for (int i = 0; i < m_subj_list.Length; i++)
            {
               cmb_subj_desc.Items.Add(m_subj_list[i].Description);
            }
            cmb_subj_desc.SelectedIndex = 0;
         }

         m_subj_idx = cmb_subj_desc.SelectedIndex;
         if (m_ai_manual_matching || m_ao_manual_matching)
         {
            textBox_subj_instrc.Text = m_subj_list[m_subj_idx].Instruction;
            textBox_subj_target.Text = m_subj_list[m_subj_idx].TargetRange;

            double value = 0;
            int refCount = 0;
            int[] adjustCode = new int[RelatedCountMax];

            CaliState caliState = m_subj_list[m_subj_idx].AdjCodeGetCurrentState(out value, ref refCount, adjustCode);
            textBox_read_value.Text = value.ToString();

            int[] lowerVal = new int[RelatedCountMax];
            int[] upperVal = new int[RelatedCountMax];
            m_subj_list[m_subj_idx].AdjCodeGetRange(lowerVal, upperVal);

            int idx = refCount - 1;
            spb_adj_code.Minimum = lowerVal[idx];
            spb_adj_code.Maximum = upperVal[idx];
            spb_adj_code.Value = adjustCode[idx];
         }

         if (m_ai_auto_matching || m_ao_auto_matching)
         {
            InitTableList();
         }
         
         SettingWidgetsState();
      } 

      private void InitTableList()
      {
         table_list_result.Rows.Clear();         

         table_list_result.Enabled = true;
         table_list_result.RowHeadersVisible = false;
         table_list_result.ReadOnly = true;         

         table_list_result.ColumnHeadersVisible = true;
         table_list_result.ColumnCount = 3;
         string[] strHeaders  = new string[] {"Step", "Description", "Result"};
         string[] strNames = new string[] { "Column1", "Column2", "Column3" };
         int[] widths = new int[] { 50, 250, 80 };
         for (int i = 0; i < 3; i++ )
         {
            table_list_result.Columns[i].HeaderText = strHeaders[i];
            table_list_result.Columns[i].Name = strNames[i];
            table_list_result.Columns[i].Width = widths[i];
         }
                  

         int tableRowCount = m_subj_list.Length;
         table_list_result.RowCount = tableRowCount;

         for (int i = 0; i < tableRowCount; i++)
         {  
            string str = "Step" + (i + 1).ToString();
            table_list_result.Rows[i].Cells["Column1"].Value = str;

            string subj_desc = m_subj_list[i].Description;
            table_list_result.Rows[i].Cells["Column2"].Value = subj_desc;

            table_list_result.Rows[i].Cells["Column3"].Value = "Idle";
         }
      }

      private void btnStart_Click(object sender, EventArgs e)
      {
         ErrorCode errCode = ErrorCode.Success;

         //update UI
         btn_Config.Enabled = false;
         btn_Start.Enabled = false;
         btn_Stop.Enabled = true;

         cmb_sect_desc.Enabled = false;
         cmb_subj_desc.Enabled = false;

         if(m_ai_auto_matching || m_ao_auto_matching)
         {            
            int tableRowCount = m_subj_list.Length;
            for (int i = 0; i < tableRowCount; i++ )
            {
               table_list_result.Rows[i].Cells["Column3"].Value = "---NA---";               
            }

            timer1.Start();

            errCode = m_sect_list[m_sect_idx].BatchStart();
            Console.WriteLine("==>btnStart_Click_Auto_{0}\n", errCode);
         }

         if(m_ai_manual_matching || m_ao_manual_matching)
         {            
            spb_adj_code.Enabled = true;

            if(m_ai_manual_matching){
               timer2.Start();
            }

            errCode = m_subj_list[m_subj_idx].ManualAdjStart();
            Console.WriteLine("==>btnStart_Click_Manual_{0}\n", errCode);
         }         
      }

      private void btnStop_Click(object sender, EventArgs e)
      {
         //Updata UI
         btn_Config.Enabled = true;
         btn_Start.Enabled = true;
         btn_Stop.Enabled = false;

         cmb_sect_desc.Enabled = true;
         cmb_subj_desc.Enabled = true;

         if (m_ai_auto_matching || m_ao_auto_matching)
         {                        
            m_sect_list[m_sect_idx].BatchTerminate();
         }

         if (m_ai_manual_matching || m_ao_manual_matching)
         {
            ErrorCode errCode = ErrorCode.Success;
            spb_adj_code.Enabled = false;
            btn_Save.Enabled = true;

            errCode = m_subj_list[m_subj_idx].ManualAdjStop();
            Console.WriteLine("==>btnStop_Click_Manual_{0}\n", errCode);

            timer2.Stop();
         }
      }

      private void btnConfig_Click(object sender, EventArgs e)
      {
         ConfigureDialog configureDialog = new ConfigureDialog();
         configureDialog.ShowDialog();
         if (configureDialog.DialogResult == DialogResult.OK)
         {
            Initialize();            
         }
      }

      private void btnSave_Click(object sender, EventArgs e)
      {         
         m_sln_list[m_sln_idx].AdjCodesSave();
      }

      private void spinBox_Click(object sender, EventArgs e)
      {
         ErrorCode errCode = ErrorCode.Success;
         btn_Save.Enabled = true;
         
         //string strVal = spb_adj_code.Value.ToString();
         int[] cali_code = new int[RelatedCountMax];
         cali_code[0] = Int32.Parse(spb_adj_code.Value.ToString());         
         errCode = m_subj_list[m_subj_idx].ManualAdjSetCode(RelatedCount, cali_code);
         Console.WriteLine("==>spinBox_Click{0}\n", errCode);
      }

      private void timer1_Tick(object sender, EventArgs e)
      {
         double value = 0;
         int refCount = 0;
         int[] adjustCode = new int[64];
         string strState;

         int tableRowCount = m_subj_list.Length;
         Int32 lastOneIdx = tableRowCount - 1;
         
         for (int i = 0; i < tableRowCount; i++ )
         {
            CaliState caliState = m_subj_list[i].AdjCodeGetCurrentState(out value, ref refCount, adjustCode);

            if(caliState != CaliState.CaliIdle)
            {
               switch ((int)caliState)
               {
                  case 0:
                     strState = "Success"; break;
                  case 1:
                     strState = "Failed"; break;
                  case 2:
                     strState = "Running"; break;
                  default:
                     strState = "---NA---"; break;
               }
               table_list_result.Rows[i].Cells["Column3"].Value = strState;
            }

            if ( caliState == CaliState.CaliFailed || (i == lastOneIdx && (caliState == CaliState.CaliSuccess || caliState == CaliState.CaliFailed)) )
            {
               btn_Save.Enabled = true;
               btnStop_Click(this, e);
               timer1.Stop();
               Console.WriteLine("Auto Cali Finish~~\n");
            }
         }
      }

      private void timer2_Tick(object sender, EventArgs e)
      {
         double value = 0;
         int refCount = 0;
         int[] adjustCode = new int[64];

         CaliState caliState = m_subj_list[m_subj_idx].AdjCodeGetCurrentState(out value, ref refCount, adjustCode);

         textBox_read_value.Text = value.ToString();
      }  

      private void SubjectChangeForComponentsClear()
      {
         cmb_subj_desc.Items.Clear();

         textBox_subj_instrc.Clear();
         textBox_subj_target.Clear();
         textBox_read_value.Clear();         
      }

      private void SectionTypeCheck()
      {
         m_ai_auto_matching = false;
         m_ai_manual_matching = false;         
         m_ao_auto_matching = false;
         m_ao_manual_matching = false;
         
         string sect_type_name = m_sect_list[m_sect_idx].TypeName;

         m_ai_auto_matching = string.Equals(sect_type_name, "Cali.Section.InSignals.Batch");
         m_ai_manual_matching |= string.Equals(sect_type_name, "Cali.Section.InSignals.DigitalVR");
         //m_ai_manual_matching |= string.Equals(sect_type_name, "Cali.Section.InSignals.KnobVR");

         m_ao_auto_matching = string.Equals(sect_type_name, "Cali.Section.OutSignals.Batch");         
         m_ao_manual_matching |= string.Equals(sect_type_name, "Cali.Section.OutSignals.DigitalVR");
         //m_ao_manual_matching |= string.Equals(sect_type_name, "Cali.Section.OutSignals.KnobVR");
      }

      private void SettingWidgetsState()
      {         
         if(m_ai_manual_matching || m_ao_manual_matching)
         {
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;

            cmb_subj_desc.Visible = true;
            textBox_subj_instrc.Visible = true;
            textBox_subj_target.Visible = true;
            textBox_read_value.Visible = true;
            spb_adj_code.Visible = true;

            table_list_result.Visible = false;

            btn_Config.Visible = true;
            btn_Start.Visible  = true;
            btn_Stop.Visible   = true;
            btn_Save.Visible   = true;            
         }

         if (m_ai_auto_matching || m_ao_auto_matching)
         {
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;

            cmb_subj_desc.Visible = false;
            textBox_subj_instrc.Visible = false;
            textBox_subj_target.Visible = false;
            textBox_read_value.Visible = false;
            spb_adj_code.Visible = false;

            table_list_result.Visible = true;
            table_list_result.Location = new System.Drawing.Point(16, 265);
            table_list_result.Size = new System.Drawing.Size(410, 160);

            btn_Config.Visible = true;
            btn_Start.Visible  = true;
            btn_Stop.Visible   = true;
            btn_Save.Visible   = true;
         }
      }         
   }
}
