﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CalibrationItem
{
   static class Program
   {
      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      [STAThread]
      static void Main()
      {
         Application.EnableVisualStyles();
         Application.SetCompatibleTextRenderingDefault(false);
         //Application.Run(new Form1());
         ConfigureDialog configureDialog = new ConfigureDialog();
         configureDialog.ShowDialog();

         if(configureDialog.DialogResult == DialogResult.OK){
            configureDialog.Dispose();                       

            CalibrationItem calibrationItem = new CalibrationItem();
            Application.Run(calibrationItem);
         }else if (configureDialog.DialogResult == DialogResult.Cancel){
            configureDialog.Dispose();
            Application.Exit();
         }         
      }
   }

   public static class ConfigureParameter
   {
      public static string deviceName;
      public static string slnName;      
      public static int slnIdx;
      public static int devIdx;
   }
}
