﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Automation.BDaq;

namespace CalibrationItem
{
   public partial class ConfigureDialog : Form
   {
      CalibrationCtrl  m_caliCtrl;

      public ConfigureDialog()
      {
         InitializeComponent();

         m_caliCtrl = new CalibrationCtrl();

         List<DeviceTreeNode> sptedDevices = m_caliCtrl.SupportedDevices;

         if (sptedDevices.Count == 0)
         {
            MessageBox.Show("No device to support the currently demonstrated function!", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            this.DialogResult = DialogResult.Cancel;
         }
         else
         {            
            for (int i = 0; i < sptedDevices.Count; i++ )
            {
               cmb_Device.Items.Add(sptedDevices[i].Description);
               Console.WriteLine("{0}, {1}\n", sptedDevices[i].Description, sptedDevices[i].DeviceNumber);
            }

            if (string.IsNullOrEmpty(ConfigureParameter.deviceName)){
               cmb_Device.SelectedIndex = 0;
            }else{
               cmb_Device.Text = ConfigureParameter.deviceName;
               cmb_Solution.Text = ConfigureParameter.slnName;
            }            
         }         
      }      

      private void btnOK_Click(object sender, EventArgs e)
      {  
         if(cmb_Device.Items.Count == 0){
            this.DialogResult = DialogResult.Cancel;
         }
         
         ConfigureParameter.deviceName = cmb_Device.Text;
         ConfigureParameter.devIdx = cmb_Device.SelectedIndex;
         ConfigureParameter.slnIdx = cmb_Solution.SelectedIndex;
         ConfigureParameter.slnName = cmb_Solution.Text;

         this.DialogResult = DialogResult.OK;
      }

      private void btnCancel_Click(object sender, EventArgs e)
      {
         this.DialogResult = DialogResult.Cancel;
      }

      private void cmbDevice_Changed(object sender, EventArgs e)
      {
         cmb_Solution.Items.Clear();

         string deviceName = cmb_Device.Text;
         m_caliCtrl.SelectedDevice = new DeviceInformation(deviceName);
         btn_OK.Enabled = true;         

         CaliSolution[] slnList = m_caliCtrl.Solutions;
         for (int i = 0; i < slnList.Length; i++ )
         {
            string sln_desc = slnList[i].Description;
            cmb_Solution.Items.Add(sln_desc);
         }
         cmb_Solution.SelectedIndex = 0;
      }

      static bool BioFailed(ErrorCode err)
      {
         return err < ErrorCode.Success && err >= ErrorCode.ErrorHandleNotValid;
      }

      ///class end
   }    
}
