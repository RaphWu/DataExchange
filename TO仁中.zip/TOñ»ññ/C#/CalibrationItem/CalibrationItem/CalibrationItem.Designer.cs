﻿namespace CalibrationItem
{
   partial class CalibrationItem
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         this.btn_Config = new System.Windows.Forms.Button();
         this.btn_Save = new System.Windows.Forms.Button();
         this.btn_Stop = new System.Windows.Forms.Button();
         this.btn_Start = new System.Windows.Forms.Button();
         this.lbl_sln_desc = new System.Windows.Forms.Label();
         this.label2 = new System.Windows.Forms.Label();
         this.textBox_sln_instrc = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.cmb_sect_desc = new System.Windows.Forms.ComboBox();
         this.textBox_sect_instrc = new System.Windows.Forms.TextBox();
         this.label3 = new System.Windows.Forms.Label();
         this.cmb_subj_desc = new System.Windows.Forms.ComboBox();
         this.label4 = new System.Windows.Forms.Label();
         this.textBox_subj_instrc = new System.Windows.Forms.TextBox();
         this.label5 = new System.Windows.Forms.Label();
         this.textBox_subj_target = new System.Windows.Forms.TextBox();
         this.label6 = new System.Windows.Forms.Label();
         this.spb_adj_code = new System.Windows.Forms.NumericUpDown();
         this.table_list_result = new System.Windows.Forms.DataGridView();
         this.label7 = new System.Windows.Forms.Label();
         this.textBox_read_value = new System.Windows.Forms.TextBox();
         this.timer1 = new System.Windows.Forms.Timer(this.components);
         this.timer2 = new System.Windows.Forms.Timer(this.components);
         ((System.ComponentModel.ISupportInitialize)(this.spb_adj_code)).BeginInit();
         ((System.ComponentModel.ISupportInitialize)(this.table_list_result)).BeginInit();
         this.SuspendLayout();
         // 
         // btn_Config
         // 
         this.btn_Config.DialogResult = System.Windows.Forms.DialogResult.Cancel;
         this.btn_Config.Location = new System.Drawing.Point(12, 588);
         this.btn_Config.Name = "btn_Config";
         this.btn_Config.Size = new System.Drawing.Size(75, 23);
         this.btn_Config.TabIndex = 0;
         this.btn_Config.Text = "Config";
         this.btn_Config.UseVisualStyleBackColor = true;
         this.btn_Config.Click += new System.EventHandler(this.btnConfig_Click);
         // 
         // btn_Save
         // 
         this.btn_Save.Location = new System.Drawing.Point(159, 590);
         this.btn_Save.Name = "btn_Save";
         this.btn_Save.Size = new System.Drawing.Size(75, 23);
         this.btn_Save.TabIndex = 1;
         this.btn_Save.Text = "Save";
         this.btn_Save.UseVisualStyleBackColor = true;
         this.btn_Save.Click += new System.EventHandler(this.btnSave_Click);
         // 
         // btn_Stop
         // 
         this.btn_Stop.Location = new System.Drawing.Point(250, 589);
         this.btn_Stop.Name = "btn_Stop";
         this.btn_Stop.Size = new System.Drawing.Size(75, 23);
         this.btn_Stop.TabIndex = 2;
         this.btn_Stop.Text = "Stop";
         this.btn_Stop.UseVisualStyleBackColor = true;
         this.btn_Stop.Click += new System.EventHandler(this.btnStop_Click);
         // 
         // btn_Start
         // 
         this.btn_Start.Location = new System.Drawing.Point(347, 588);
         this.btn_Start.Name = "btn_Start";
         this.btn_Start.Size = new System.Drawing.Size(75, 23);
         this.btn_Start.TabIndex = 3;
         this.btn_Start.Text = "Start";
         this.btn_Start.UseVisualStyleBackColor = true;
         this.btn_Start.Click += new System.EventHandler(this.btnStart_Click);
         // 
         // lbl_sln_desc
         // 
         this.lbl_sln_desc.AutoSize = true;
         this.lbl_sln_desc.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
         this.lbl_sln_desc.Location = new System.Drawing.Point(12, 9);
         this.lbl_sln_desc.Name = "lbl_sln_desc";
         this.lbl_sln_desc.Size = new System.Drawing.Size(189, 19);
         this.lbl_sln_desc.TabIndex = 4;
         this.lbl_sln_desc.Text = "Solution Description";
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Location = new System.Drawing.Point(14, 28);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(125, 12);
         this.label2.TabIndex = 5;
         this.label2.Text = "Solution Instruction";
         // 
         // textBox_sln_instrc
         // 
         this.textBox_sln_instrc.Location = new System.Drawing.Point(16, 48);
         this.textBox_sln_instrc.Multiline = true;
         this.textBox_sln_instrc.Name = "textBox_sln_instrc";
         this.textBox_sln_instrc.ReadOnly = true;
         this.textBox_sln_instrc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.textBox_sln_instrc.Size = new System.Drawing.Size(406, 86);
         this.textBox_sln_instrc.TabIndex = 6;
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Location = new System.Drawing.Point(16, 144);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(59, 12);
         this.label1.TabIndex = 7;
         this.label1.Text = "Section: ";
         // 
         // cmb_sect_desc
         // 
         this.cmb_sect_desc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cmb_sect_desc.FormattingEnabled = true;
         this.cmb_sect_desc.Location = new System.Drawing.Point(77, 141);
         this.cmb_sect_desc.Name = "cmb_sect_desc";
         this.cmb_sect_desc.Size = new System.Drawing.Size(345, 20);
         this.cmb_sect_desc.TabIndex = 8;
         this.cmb_sect_desc.SelectedIndexChanged += new System.EventHandler(this.onCmbSect_Changed);
         // 
         // textBox_sect_instrc
         // 
         this.textBox_sect_instrc.Location = new System.Drawing.Point(18, 167);
         this.textBox_sect_instrc.Multiline = true;
         this.textBox_sect_instrc.Name = "textBox_sect_instrc";
         this.textBox_sect_instrc.ReadOnly = true;
         this.textBox_sect_instrc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.textBox_sect_instrc.Size = new System.Drawing.Size(404, 89);
         this.textBox_sect_instrc.TabIndex = 9;
         // 
         // label3
         // 
         this.label3.AutoSize = true;
         this.label3.Location = new System.Drawing.Point(16, 265);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(53, 12);
         this.label3.TabIndex = 10;
         this.label3.Text = "Subject:";
         // 
         // cmb_subj_desc
         // 
         this.cmb_subj_desc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.cmb_subj_desc.FormattingEnabled = true;
         this.cmb_subj_desc.Location = new System.Drawing.Point(106, 262);
         this.cmb_subj_desc.Name = "cmb_subj_desc";
         this.cmb_subj_desc.Size = new System.Drawing.Size(316, 20);
         this.cmb_subj_desc.TabIndex = 11;
         this.cmb_subj_desc.SelectedIndexChanged += new System.EventHandler(this.onCmbSubj_Changed);
         // 
         // label4
         // 
         this.label4.AutoSize = true;
         this.label4.Location = new System.Drawing.Point(16, 313);
         this.label4.Name = "label4";
         this.label4.Size = new System.Drawing.Size(77, 12);
         this.label4.TabIndex = 12;
         this.label4.Text = "Instruction:";
         // 
         // textBox_subj_instrc
         // 
         this.textBox_subj_instrc.Location = new System.Drawing.Point(106, 288);
         this.textBox_subj_instrc.Multiline = true;
         this.textBox_subj_instrc.Name = "textBox_subj_instrc";
         this.textBox_subj_instrc.ReadOnly = true;
         this.textBox_subj_instrc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
         this.textBox_subj_instrc.Size = new System.Drawing.Size(316, 58);
         this.textBox_subj_instrc.TabIndex = 13;
         // 
         // label5
         // 
         this.label5.AutoSize = true;
         this.label5.Location = new System.Drawing.Point(16, 355);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(47, 12);
         this.label5.TabIndex = 14;
         this.label5.Text = "Target:";
         // 
         // textBox_subj_target
         // 
         this.textBox_subj_target.Location = new System.Drawing.Point(106, 352);
         this.textBox_subj_target.Name = "textBox_subj_target";
         this.textBox_subj_target.ReadOnly = true;
         this.textBox_subj_target.Size = new System.Drawing.Size(316, 21);
         this.textBox_subj_target.TabIndex = 15;
         // 
         // label6
         // 
         this.label6.AutoSize = true;
         this.label6.Location = new System.Drawing.Point(16, 410);
         this.label6.Name = "label6";
         this.label6.Size = new System.Drawing.Size(77, 12);
         this.label6.TabIndex = 16;
         this.label6.Text = "Adjust Code:";
         // 
         // spb_adj_code
         // 
         this.spb_adj_code.Location = new System.Drawing.Point(106, 408);
         this.spb_adj_code.Name = "spb_adj_code";
         this.spb_adj_code.Size = new System.Drawing.Size(316, 21);
         this.spb_adj_code.TabIndex = 17;
         this.spb_adj_code.Click += new System.EventHandler(this.spinBox_Click);
         // 
         // table_list_result
         // 
         this.table_list_result.AllowUserToDeleteRows = false;
         this.table_list_result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
         this.table_list_result.Location = new System.Drawing.Point(12, 453);
         this.table_list_result.Name = "table_list_result";
         this.table_list_result.ReadOnly = true;
         this.table_list_result.RowTemplate.Height = 23;
         this.table_list_result.Size = new System.Drawing.Size(410, 114);
         this.table_list_result.TabIndex = 18;
         // 
         // label7
         // 
         this.label7.AutoSize = true;
         this.label7.Location = new System.Drawing.Point(16, 382);
         this.label7.Name = "label7";
         this.label7.Size = new System.Drawing.Size(65, 12);
         this.label7.TabIndex = 19;
         this.label7.Text = "Read Value";
         // 
         // textBox_read_value
         // 
         this.textBox_read_value.Location = new System.Drawing.Point(106, 379);
         this.textBox_read_value.Name = "textBox_read_value";
         this.textBox_read_value.ReadOnly = true;
         this.textBox_read_value.Size = new System.Drawing.Size(316, 21);
         this.textBox_read_value.TabIndex = 20;
         // 
         // timer1
         // 
         this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
         // 
         // timer2
         // 
         this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
         // 
         // CalibrationItem
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.CancelButton = this.btn_Config;
         this.ClientSize = new System.Drawing.Size(441, 623);
         this.Controls.Add(this.textBox_read_value);
         this.Controls.Add(this.label7);
         this.Controls.Add(this.table_list_result);
         this.Controls.Add(this.spb_adj_code);
         this.Controls.Add(this.label6);
         this.Controls.Add(this.textBox_subj_target);
         this.Controls.Add(this.label5);
         this.Controls.Add(this.textBox_subj_instrc);
         this.Controls.Add(this.label4);
         this.Controls.Add(this.cmb_subj_desc);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.textBox_sect_instrc);
         this.Controls.Add(this.cmb_sect_desc);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.textBox_sln_instrc);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.lbl_sln_desc);
         this.Controls.Add(this.btn_Start);
         this.Controls.Add(this.btn_Stop);
         this.Controls.Add(this.btn_Save);
         this.Controls.Add(this.btn_Config);
         this.Name = "CalibrationItem";
         this.Text = "Calibration Item";
         ((System.ComponentModel.ISupportInitialize)(this.spb_adj_code)).EndInit();
         ((System.ComponentModel.ISupportInitialize)(this.table_list_result)).EndInit();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Button btn_Config;
      private System.Windows.Forms.Button btn_Save;
      private System.Windows.Forms.Button btn_Stop;
      private System.Windows.Forms.Button btn_Start;
      private System.Windows.Forms.Label lbl_sln_desc;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.TextBox textBox_sln_instrc;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.ComboBox cmb_sect_desc;
      private System.Windows.Forms.TextBox textBox_sect_instrc;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.ComboBox cmb_subj_desc;
      private System.Windows.Forms.Label label4;
      private System.Windows.Forms.TextBox textBox_subj_instrc;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.TextBox textBox_subj_target;
      private System.Windows.Forms.Label label6;
      private System.Windows.Forms.NumericUpDown spb_adj_code;
      private System.Windows.Forms.DataGridView table_list_result;
      private System.Windows.Forms.Label label7;
      private System.Windows.Forms.TextBox textBox_read_value;
      private System.Windows.Forms.Timer timer1;
      private System.Windows.Forms.Timer timer2;
   }
}