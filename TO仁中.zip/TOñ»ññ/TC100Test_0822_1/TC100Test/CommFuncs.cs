﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TC100Test
{
    public partial class TC100Test
    {
        const int ONE_WORD = 4;
        const int TWO_WORD = 8;
        const int MAX_QUEUE_CAPACITY = 100;

        private CancellationTokenSource _cts;
        private CancellationToken _token;
        private readonly object _lock = new object();
        private Thread _portAccessThread = null;
        private Thread _screenUpdateThread = null;

        private bool _screenUpdating = false;
        private byte _statusReadingLoop = 0;
        private ReadStatus _readStatus = new ReadStatus();
        private string _readStatusMessage = string.Empty;
        private OutputSettings _outputSetting = new OutputSettings();
        private string _outputSettingMessage = string.Empty;

        //private CommStatus _commStatus = CommStatus.Idle;
        //private CommStatus _lastCommStatus = CommStatus.Idle;
        private bool _requestHolding = false;

        //private byte[] _requestMessage;
        //int _byteToWrite = 0;
        //private byte[] _responseMessage;
        private string _responseString = string.Empty;
        int _bytesToRead = 0;

        private Queue<FrameStruct> _highPriorityQueue = new Queue<FrameStruct>();
        private Queue<FrameStruct> _retryQueue = new Queue<FrameStruct>();
        private Queue<FrameStruct> _requestQueue = new Queue<FrameStruct>();

        private int _watchDogCounter = 0;
        private System.Timers.Timer _watchDog;
        private System.Timers.Timer _statusReadingTimer;

        public struct FrameStruct
        {
            public CallerId CallerId { get; set; }
            public byte[] ByteArray { get; set; }
            public int Length { get; set; }
        }

        public enum CallerId
        {
            Initializer,
            WatchDog,
            Command,
            ReadStatus,
            OutputSettings,
        }

        //public enum CommStatus
        //{
        //    ERROR,
        //    Idle,
        //    //ActiveFinished,

        //    Command,
        //    WatchDog,
        //    Initialization, // 開通權限中

        //    ReadStatus,
        //}

        #region Serial Port Open/Close

        private void ClosePort()
        {
            if (_cts != null)
            {
                _cts.Cancel();
                _cts.Dispose();
                //_cts = null;
            }

            _requestQueue.Clear();
            _retryQueue.Clear();
            _highPriorityQueue.Clear();

            _statusReadingTimer.Stop();
            _statusReadingTimer.Elapsed -= StatusReadingProc;
            //_statusReadingTimer = null;
            _watchDog.Stop();
            _watchDog.Elapsed -= WatchDogProc;
            //_watchDog = null;

            if (_portAccessThread != null)
            {
                _portAccessThread.Join(1000);
                _portAccessThread = null;
            }

            if (_screenUpdateThread != null)
            {
                _screenUpdateThread.Join(1000);
                _screenUpdateThread = null;
            }

            if (_sps.IsOpen)
                _sps.Close();

            textBox_MotorStatus.InvokeIfRequired(() =>
            {
                textBox_MotorStatus.Text = "";
                textBox_MotorAlarm.Text = "";
                textBox_MotorRPM.Text = "";
                textBox_MotorSpeed.Text = "";
                textBox_MotorCurrent.Text = "";
                textBox_MotorCommandPos.Text = "";
                textBox_MotorCurrentPos.Text = "";
                textBox_InpStatus.Text = "";
                textBox_ServoStatus.Text = "";
            });

            button_Connect.Enabled = true;
            button_Disconnct.Enabled = false;
            panel_Action.Enabled = false;
            panel_Test.Enabled = false;
        }

        private void OpenPort()
        {
            if (!_sps.IsOpen)
            {
                try
                {
                    if (_cts != null)
                        _cts.Dispose();
                    _cts = new CancellationTokenSource();

                    _sps.Open();
                    if (_sps.IsOpen)
                    {
                        if (_screenUpdateThread == null || _screenUpdateThread.ThreadState == ThreadState.Stopped)
                        {
                            _screenUpdateThread = new Thread(ScreenUpdatePolling)
                            {
                                Name = "",
                                IsBackground = true
                            };
                            _screenUpdateThread.Start(_cts);
                        }

                        if (_portAccessThread == null || _portAccessThread.ThreadState == ThreadState.Stopped)
                        {
                            _portAccessThread = new Thread(PortAccessPolling)
                            {
                                Name = "",
                                IsBackground = true
                            };
                            _portAccessThread.Start(_cts);
                        }

                        HighPriorityRequest(CallerId.Initializer, ":0110999B0004084C7630315479566702\r\n"); // 權限開通請求

                        _watchDog = new System.Timers.Timer()
                        {
                            Interval = 1000,
                            AutoReset = true,
                        };
                        _watchDog.Elapsed += WatchDogProc;
                        _watchDog.Start();

                        _statusReadingTimer = new System.Timers.Timer()
                        {
                            Interval = 233,
                            AutoReset = true,
                        };
                        _statusReadingTimer.Elapsed += StatusReadingProc;
                        _statusReadingTimer.Start();

                        button_Connect.Enabled = false;
                        button_Disconnct.Enabled = true;
                        panel_Action.Enabled = true;
                        panel_Test.Enabled = true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(String.Concat("Failed to open serial port: ", ex.Message));
                }
            }
        }

        #endregion

        #region Timer

        private void WatchDogProc(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (_sps.IsOpen)
            {
                foreach (var rq in _highPriorityQueue)
                    if (rq.CallerId == CallerId.WatchDog)
                        return;
                HighPriorityRequest(CallerId.WatchDog, 01, 0x03, 0x10E0, 1);
                _watchDogCounter++;
            }

            //if (_watchDogCounter % 10 == 0)
            //    GC.Collect();
        }

        private void StatusReadingProc(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (_sps.IsOpen && !_screenUpdating && !_requestHolding)
            {
                foreach (var rq in _requestQueue)
                    if (rq.CallerId == CallerId.ReadStatus)
                        return;

                _statusReadingLoop ^= 0x01;
                switch (_statusReadingLoop)
                {
                    case 0:
                        SendRequestFrame(CallerId.ReadStatus, 01, 0x03, 0x1000, 0x0F * ONE_WORD);
                        break;
                    case 1:
                        //SendRequestFrame(CallerId.OutputSettings, 01, 0x03, 0x0700, 0x14 * ONE_WORD);
                        break;
                }
            }
        }

        #endregion

        #region 畫面更新

        private async void ScreenUpdatePolling(object param)
        {
            CancellationTokenSource cts = (param as CancellationTokenSource);
            _token = cts.Token;

            try
            {
                while (true)
                {
                    if (_token.IsCancellationRequested)
                        _token.ThrowIfCancellationRequested();

                    textBox_WatchDog.InvokeIfRequired(() =>
                    {
                        textBox_WatchDog.Text = _watchDogCounter.ToString();
                    });

                    if (!string.IsNullOrEmpty(_readStatusMessage) && !_screenUpdating)
                    {
                        int readByte;
                        string data;

                        _screenUpdating = true;
                        string responseString = _readStatusMessage;
                        readByte = responseString.Length;
                        data = responseString.Substring(7, readByte - 8);

                        //NumberStyles styles = NumberStyles.HexNumber;

                        _readStatus.ServoStatus = Convert.ToBoolean(Convert.ToInt16(data.Substring(0xC * ONE_WORD, ONE_WORD)));
                        _readStatus.ActionStatus = Convert.ToInt16(data.Substring(0x0 * ONE_WORD, ONE_WORD), 16);
                        _readStatus.InpStatus = Convert.ToInt16(data.Substring(0x01 * ONE_WORD, ONE_WORD), 16);
                        _readStatus.TrqLmtStatus = Convert.ToInt16(data.Substring(0x4 * ONE_WORD, ONE_WORD), 16);
                        _readStatus.AlarmStatus = Convert.ToInt16(data.Substring(0x5 * ONE_WORD, ONE_WORD), 16);
                        _readStatus.ErrorStatus = Convert.ToInt16(data.Substring(0xD * ONE_WORD, ONE_WORD), 16);
                        _readStatus.MonRpm = Convert.ToInt16(data.Substring(0x3 * ONE_WORD, ONE_WORD), 16);
                        _readStatus.MonSpeed = Convert.ToInt16(data.Substring(0x6 * ONE_WORD, ONE_WORD), 16);
                        _readStatus.MonCurrent = Convert.ToInt16(data.Substring(0x7 * ONE_WORD, ONE_WORD), 16) / 10.0;
                        _readStatus.CmdNowPos = Convert.ToInt32(data.Substring(0x8 * ONE_WORD, TWO_WORD), 16) / 100.0;
                        _readStatus.EcdPos = Convert.ToInt32(data.Substring(0xA * ONE_WORD, TWO_WORD), 16) / 100.0;
                        _readStatus.Updated = true;

                        string caption_ServoStatus = _readStatus.ServoStatus ? "伺服ON" : "伺服OFF";
                        string caption_MotorStatus = _readStatus.ActionStatus == 0 ? "停止" : _readStatus.ActionStatus == 1 ? "動作中" : "異常停止";
                        string caption_InpStatus = (_readStatus.InpStatus == 1 ? "位置已在設定範圍內" : "尚未到達設定範圍內");
                        string caption_AlarmStatus;
                        switch (_readStatus.AlarmStatus)
                        {
                            case 0:
                                caption_AlarmStatus = "無警報";
                                break;
                            case 1:
                                caption_AlarmStatus = "Loop error";
                                break;
                            case 2:
                                caption_AlarmStatus = "Full Count";
                                break;
                            case 3:
                                caption_AlarmStatus = "過速度";
                                break;
                            case 4:
                                caption_AlarmStatus = "增益值調整不良";
                                break;
                            case 5:
                                caption_AlarmStatus = "過電壓";
                                break;
                            case 6:
                                caption_AlarmStatus = "初期化異常";
                                break;
                            case 7:
                                caption_AlarmStatus = "EEPROM 異常";
                                break;
                            case 8:
                                caption_AlarmStatus = "主迴路電源電壓不足";
                                break;
                            case 9:
                                caption_AlarmStatus = "過電流";
                                break;
                            case 10:
                                caption_AlarmStatus = "回生異常";
                                break;
                            case 11:
                                caption_AlarmStatus = "緊急停止";
                                break;
                            case 12:
                                caption_AlarmStatus = "馬達斷線";
                                break;
                            case 13:
                                caption_AlarmStatus = "編碼器斷線";
                                break;
                            case 14:
                                caption_AlarmStatus = "保護電流值";
                                break;
                            case 15:
                                caption_AlarmStatus = "電源再投入";
                                break;
                            case 16:
                                caption_AlarmStatus = "動作超時";
                                break;
                            default:
                                caption_AlarmStatus = "不明錯誤";
                                break;
                        }
                        string caption_ErrorStatus;
                        switch (_readStatus.ErrorStatus)
                        {
                            case 0:
                                caption_ErrorStatus = "沒有錯誤";
                                break;
                            case 1:
                                caption_ErrorStatus = "在動作中接收動作指令";
                                break;
                            case 2:
                                caption_ErrorStatus = "上下限錯誤";
                                break;
                            case 3:
                                caption_ErrorStatus = "位置錯誤";
                                break;
                            case 4:
                                caption_ErrorStatus = "格式錯誤";
                                break;
                            case 5:
                                caption_ErrorStatus = "控制模式錯誤";
                                break;
                            case 6:
                                caption_ErrorStatus = "斷電重開";
                                break;
                            case 7:
                                caption_ErrorStatus = "初始化未完成";
                                break;
                            case 8:
                                caption_ErrorStatus = "Servo ON/OFF 錯誤";
                                break;
                            case 9:
                                caption_ErrorStatus = "LOCK";
                                break;
                            case 10:
                                caption_ErrorStatus = "軟體極限";
                                break;
                            case 11:
                                caption_ErrorStatus = "參數寫入權限不足";
                                break;
                            case 12:
                                caption_ErrorStatus = "原點復歸未完成";
                                break;
                            case 13:
                                caption_ErrorStatus = "剎車已解除";
                                break;
                            default:
                                caption_ErrorStatus = "不明錯誤";
                                break;
                        }
                        string caption_TrqLmtStatus = _readStatus.TrqLmtStatus == 1 ? "已在設定範圍內" : "未到設定範圍內";
                        string caption_MotorRPM = _readStatus.MonRpm.ToString();
                        string caption_MotorSpeed = _readStatus.MonSpeed.ToString("0.0");
                        string caption_MotorCurrent = _readStatus.MonCurrent.ToString("0.0");
                        string caption_MotorCommandPos = _readStatus.CmdNowPos.ToString("0.00");
                        string caption_MotorCurrentPos = _readStatus.EcdPos.ToString("0.00");
                        string caption_SoftwareLimitJudge = _readStatus.TrqLmtStatus.ToString();

                        textBox_MotorStatus.InvokeIfRequired(() =>
                        {
                            textBox_ServoStatus.Text = caption_ServoStatus;
                            textBox_MotorStatus.Text = caption_MotorStatus;
                            textBox_InpStatus.Text = caption_InpStatus;
                            textBox_TrqLmtStatus.Text = caption_TrqLmtStatus;
                            textBox_MotorAlarm.Text = caption_AlarmStatus;
                            textBox_ErrorStatus.Text = caption_ErrorStatus;
                            textBox_MotorRPM.Text = caption_MotorRPM;
                            textBox_MotorSpeed.Text = caption_MotorSpeed;
                            textBox_MotorCurrent.Text = caption_MotorCurrent;
                            textBox_MotorCommandPos.Text = caption_MotorCommandPos;
                            textBox_MotorCurrentPos.Text = caption_MotorCurrentPos;
                        });

                        _screenUpdating = false;
                        _readStatusMessage = string.Empty;
                    }

                    if (!string.IsNullOrEmpty(_outputSettingMessage) && !_screenUpdating)
                    {
                        int readByte;
                        string data;

                        _screenUpdating = true;
                        string responseString = _readStatusMessage;
                        readByte = responseString.Length;
                        data = responseString.Substring(7, readByte - 8);

                        //NumberStyles styles = NumberStyles.HexNumber;

                        _outputSetting.InPosition = Convert.ToInt16(data.Substring(0x0 * ONE_WORD, ONE_WORD));
                        _outputSetting.Alarm = Convert.ToInt16(data.Substring(0x1 * ONE_WORD, ONE_WORD));
                        _outputSetting.Ready = Convert.ToInt16(data.Substring(0x2 * ONE_WORD, ONE_WORD));
                        _outputSetting.Move = Convert.ToInt16(data.Substring(0x3 * ONE_WORD, ONE_WORD));
                        _outputSetting.ServoS = Convert.ToInt16(data.Substring(0x5 * ONE_WORD, ONE_WORD));
                        _outputSetting.TrqLmt = Convert.ToInt16(data.Substring(0xD * ONE_WORD, ONE_WORD));
                        _outputSetting.InRange = Convert.ToInt16(data.Substring(0x12 * ONE_WORD, ONE_WORD));
                        _outputSetting.Near = Convert.ToInt16(data.Substring(0x13 * ONE_WORD, ONE_WORD));
                        _outputSetting.SoftLmt = Convert.ToInt16(data.Substring(0x14 * ONE_WORD, ONE_WORD));
                        _outputSetting.Updated = true;

                        textBox_InPosition.InvokeIfRequired(() =>
                        {
                            textBox_InPosition.Text = _outputSetting.InPosition.ToString();
                            textBox_Alarm.Text = _outputSetting.Alarm.ToString();
                            textBox_Ready.Text = _outputSetting.Ready.ToString();
                            textBox_Move.Text = _outputSetting.Move.ToString();
                            textBox_ServoS.Text = _outputSetting.ServoS.ToString();
                            textBox_TrqLmtStatus.Text = _outputSetting.TrqLmt.ToString();
                            textBox_InRange.Text = _outputSetting.InRange.ToString();
                            textBox_Near.Text = _outputSetting.Near.ToString();
                            textBox_SoftLmt.Text = _outputSetting.SoftLmt.ToString();
                        });

                        _screenUpdating = false;
                        _outputSettingMessage = string.Empty;
                    }

                    //await Task.Delay(10);
                    await Task.CompletedTask;
                }
            }
            catch (OperationCanceledException)
            {
                // do nothing for Cancellation
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Concat("畫面更新輪詢的執行緒異常: ", ex.Message, "\n", _readStatusMessage));
            }
        }

        #endregion

        #region 通訊處理

        private async void PortAccessPolling(object param)
        {
            CancellationTokenSource cts = (param as CancellationTokenSource);
            _token = cts.Token;

            const int RETRY_LIMIT = 3;
            int retryCounter = 0;

            bool requestFinished = true;
            FrameStruct nextRequest = new FrameStruct();

            try
            {
                while (true)
                {
                    if (_token.IsCancellationRequested)
                        _token.ThrowIfCancellationRequested();

                    if (requestFinished)
                    {
                        if (_highPriorityQueue.Count > 0 || _retryQueue.Count > 0 || _requestQueue.Count > 0)
                        {
                            nextRequest = (_highPriorityQueue.Count > 0)
                                ? _highPriorityQueue.Dequeue()
                                : (_retryQueue.Count > 0)
                                    ? _retryQueue.Dequeue()
                                    : _requestQueue.Dequeue();

                            await Task.Delay(10, _token);
                            //Thread.Sleep(10);
                            //_sps.DiscardInBuffer();
                            _sps.DiscardOutBuffer();
                            _sps.Write(nextRequest.ByteArray, 0, nextRequest.Length);

                            ShowRequestMessage(Encoding.ASCII.GetString(nextRequest.ByteArray));
                            //}
                            //else
                            //{
                            //    TESTCounter++;
                            //}
                            requestFinished = false;
                        }
                    }

                    if (!requestFinished && _sps.BytesToRead > 0)
                    {
                        byte st = 0;
                        byte fCode = 0xFF;

                        //Task.Delay(300).Wait();
                        //byte[] readBuffer = new byte[_bytesToRead];
                        _responseString = _sps.ReadLine();
                        _bytesToRead = _sps.BytesToRead;
                        ShowResponseMessage(_responseString);

                        bool validation = ValidFrame(_responseString);
                        if (validation)
                        {
                            //ShowConsoleMessage("Response訊息OK.");
                            st = Convert.ToByte(_responseString.Substring(1, 2), 16);
                            fCode = Convert.ToByte(_responseString.Substring(3, 2), 16);
                        }

                        if (validation && fCode < 0x80)
                        {
                            if (!_requestHolding)
                                retryCounter = 0;

                            switch (nextRequest.CallerId)
                            {
                                case CallerId.ReadStatus:
                                    _readStatusMessage = _responseString;
                                    requestFinished = true;
                                    break;
                                case CallerId.OutputSettings:
                                    _outputSettingMessage = _responseString;
                                    requestFinished = true;
                                    break;
                                case CallerId.Command:
                                    requestFinished = true;
                                    break;
                                case CallerId.WatchDog:
                                    if (_responseString == ":010302544363\r")
                                    {
                                        requestFinished = true;
                                    }
                                    else
                                    {
                                        ClosePort();
                                        throw new Exception("電動缸斷線！");
                                    }
                                    break;
                                case CallerId.Initializer:
                                    if (_responseString == ":0110999B0004B7\r")
                                    {
                                        requestFinished = true;
                                    }
                                    else
                                    {
                                        ClosePort();
                                        throw new Exception("權限開通異常！");
                                    }
                                    break;
                                default:
                                    throw new Exception(string.Concat("CallerId錯誤:\n", nextRequest.CallerId, "\nResponse Message: ", _responseString));
                            }

                            _requestHolding = false;
                        }
                        else
                        {
                            string msg = string.Concat("CallerID: ", nextRequest.CallerId, ", Frame: ", Encoding.ASCII.GetString(nextRequest.ByteArray));
                            if (++retryCounter <= RETRY_LIMIT)
                            {
                                _requestHolding = true;
                                ShowErrorMessage(string.Concat("重試第 ", retryCounter, " 次, ", msg));
                                Thread.Sleep(500);
                                SendRetryFrame(nextRequest);
                            }
                            else
                            {
                                if (checkBox_HowToHandleException.Checked)
                                {
                                    ShowErrorMessage(string.Concat("重試3次失敗！", msg));
                                    if (MessageBox.Show(string.Concat("已重試3次失敗！\n訊息：", _responseString),
                                                        "接收訊息異常",
                                                        MessageBoxButtons.RetryCancel,
                                                        MessageBoxIcon.Error) == DialogResult.Retry)
                                        SendRetryFrame(nextRequest);
                                }
                                else
                                {
                                    ShowConsoleMessage(string.Concat("此指令已放棄！", msg));
                                }

                                _requestHolding = !checkBox_HowToHandleException.Checked;
                                retryCounter = 0;
                            }
                            requestFinished = true;
                        }
                    }

                    //if (_commStatus == CommStatus.ERROR)
                    //    throw new Exception(string.Concat("未知錯誤:\n", _lastCommStatus, " / ", _commStatus, "\nFunctionCode: ", fCode, "\nResponse Message: ", _responseString));

                }
            }
            catch (TimeoutException te)
            {
                ShowConsoleMessage(te.Message);
                requestFinished = false;
            }
            catch (OperationCanceledException)
            {
                // do nothing for Cancellation
            }
            catch (UnauthorizedAccessException)
            {
                ClosePort();
                requestFinished = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Concat("接收輪詢的執行緒異常: ", ex.Message));
            }
            //finally
            //{
            //    _requestHolding = false;
            //}
        }

        #endregion

        #region 通訊發送

        private byte[] GetRequestFrame(byte station, byte functionCode, int data, int length)
        {
            int dataHigh = data >> 8;
            int dataLow = data - (dataHigh << 8);
            int lenHigh = length >> 8;
            int lenLow = length - (lenHigh << 8);
            int lrc = ((station + functionCode + dataHigh + dataLow + lenHigh + lenLow) ^ 0xFF) + 1;

            byte[] st = Encoding.ASCII.GetBytes(station.ToString("X2"));
            byte[] fCode = Encoding.ASCII.GetBytes(functionCode.ToString("X2"));
            byte[] d = Encoding.ASCII.GetBytes(data.ToString("X4"));
            byte[] len = Encoding.ASCII.GetBytes(length.ToString("X4"));
            byte[] l = Encoding.ASCII.GetBytes(lrc.ToString("X2"));

            byte[] frame = new byte[17];
            frame[00] = 0x3A;
            frame[01] = st[0];
            frame[02] = st[1];
            frame[03] = fCode[0];
            frame[04] = fCode[1];
            frame[05] = d[0];
            frame[06] = d[1];
            frame[07] = d[2];
            frame[08] = d[3];
            frame[09] = len[0];
            frame[10] = len[1];
            frame[11] = len[2];
            frame[12] = len[3];
            frame[13] = l[0];
            frame[14] = l[1];
            frame[15] = 0x0D;
            frame[16] = 0x0A;

            return frame;
        }

        private byte[] GetRequestFrame(string requestFrame)
        {
            byte[] frame = new byte[requestFrame.Length / 2];
            for (int i = 0; i < requestFrame.Length; i += 2)
            {
                frame[i / 2] = Convert.ToByte(requestFrame.Substring(i, 2), 16);
            }
            return frame;
        }

        private void HighPriorityRequest(CallerId callerId, byte station, byte functionCode, int data, int length)
        {
            if (_highPriorityQueue.Count < MAX_QUEUE_CAPACITY)
            {
                byte[] requestFrame = GetRequestFrame(station, functionCode, data, length);
                FrameStruct frame = new FrameStruct();
                //FrameStruct frame = _framePool.Get();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                frame.Length = requestFrame.Length;
                _highPriorityQueue.Enqueue(frame);
                //_framePool.Return(frame);
            }
        }

        private void HighPriorityRequest(CallerId callerId, string requestFrame)
        {
            if (_highPriorityQueue.Count < MAX_QUEUE_CAPACITY)
            {
                FrameStruct frame = new FrameStruct();
                //FrameStruct frame = _framePool.Get();
                frame.CallerId = callerId;
                frame.ByteArray = Encoding.ASCII.GetBytes(requestFrame);
                frame.Length = requestFrame.Length;
                _highPriorityQueue.Enqueue(frame);
                //_framePool.Return(frame);
            }
        }

        private void SendRetryFrame(FrameStruct frame)
        {
            if (_retryQueue.Count < MAX_QUEUE_CAPACITY)
                _retryQueue.Enqueue(frame);
        }

        private void SendRequestFrame(CallerId callerId, byte station, byte functionCode, int data, int length)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                byte[] requestFrame = GetRequestFrame(station, functionCode, data, length);
                FrameStruct frame = new FrameStruct();
                //FrameStruct frame = _framePool.Get();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                frame.Length = requestFrame.Length;
                _requestQueue.Enqueue(frame);
                //_framePool.Return(frame);
            }

            //if (_sps.IsOpen)
            //{
            //    _commStatus = requestType;
            //    byte[] requestFrame = GetRequestFrame(station, functionCode, data, length);
            //    //_sps.DiscardInBuffer();
            //    //_sps.DiscardOutBuffer();
            //    await _sps.WriteAsync(requestFrame, 0, requestFrame.Length);
            //}
            //else
            //{
            //    MessageBox.Show("Serial port is not open.");
            //}
        }

        private void SendRequestFrame(CallerId callerId, byte[] requestFrame)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                FrameStruct frame = new FrameStruct();
                //FrameStruct frame = _framePool.Get();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                frame.Length = requestFrame.Length;
                _requestQueue.Enqueue(frame);
                //_framePool.Return(frame);
            }

            //if (_sps.IsOpen)
            //{
            //    _commStatus = requestType;
            //    //_sps.DiscardInBuffer();
            //    //_sps.DiscardOutBuffer();
            //    await _sps.WriteAsync(requestFrame, 0, requestFrame.Length);
            //}
            //else
            //{
            //    MessageBox.Show("Serial port is not open.");
            //}
        }

        private void SendRequestFrame(CallerId callerId, string requestString, bool includeLRC = false)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                byte[] requestFrame;
                if (includeLRC)
                {
                    requestFrame = Encoding.ASCII.GetBytes(string.Concat(requestString, "\r\n"));
                }
                else
                {
                    int lrc = AsciiLrc(requestString);
                    requestFrame = Encoding.ASCII.GetBytes(string.Concat(requestString, lrc.ToString("X2"), "\r\n"));
                }
                FrameStruct frame = new FrameStruct();
                //FrameStruct frame = _framePool.Get();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                frame.Length = requestFrame.Length;
                _requestQueue.Enqueue(frame);
                //_framePool.Return(frame);
            }

            //if (_sps.IsOpen)
            //{
            //    _commStatus = requestType;
            //    //_sps.DiscardInBuffer();
            //    //_sps.DiscardOutBuffer();
            //    byte[] request = Encoding.ASCII.GetBytes(string.Concat(":", requestFrame, "\r\n"));
            //    await _sps.WriteAsync(request, 0, request.Length);
            //}
            //else
            //{
            //    MessageBox.Show("Serial port is not open.");
            //}
        }

        #endregion

        private void ShowRequestMessage(string msg)
        {
            label_RequestMessage.InvokeIfRequired(() =>
            {
                label_RequestMessage.Text = msg;
            });
        }

        private void ShowResponseMessage(string msg)
        {
            label_ResponseMessage.InvokeIfRequired(() =>
            {
                label_ResponseMessage.Text = msg;
            });
        }

        private void ShowConsoleMessage(string msg)
        {
            label_ConsoleMessage.InvokeIfRequired(() =>
            {
                label_ConsoleMessage.Text = msg;
            });
        }

        private void ShowErrorMessage(string msg)
        {
            label_ErrorMessage.InvokeIfRequired(() =>
            {
                label_ErrorMessage.Text = msg;
            });
        }

        private bool ValidFrame(string frame)
        {
            int len = frame.Length;

            if (frame.Substring(0, 1) != ":")
                return false;

            if (frame.Substring(len - 1, 1) != "\r")
                return false;

            string lrc = frame.Substring(len - 1 - 2, 2);
            frame = frame.Substring(1, len - 1 - 1 - 2);
            if (AsciiLrc(frame) != Convert.ToByte(lrc, 16))
                return false;

            return true;
        }
    }
}
