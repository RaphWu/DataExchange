﻿using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TC100Test
{
    public partial class TC100Test
    {
        private static byte Lrc(byte[] data)
        {
            byte lrc = 0;
            for (int i = 0; i < data.Length; i++)
                lrc += data[i];
            return (byte)((lrc ^ 0xFF) + 1);
        }

        private static byte AsciiLrc(string data)
        {
            byte lrc = 0;
            if (data.Substring(0, 1) == ":")
                data = data.Substring(1);
            int totalLen = data.Length / 2;

            for (int i = 0; i < totalLen; i++)
            {
                int t = Convert.ToInt16(data.Substring(i * 2, 2), 16);
                //int t = (data[i] > '9') ? data[i] - 'A' + 10 : data[i] - '0';
                //if (i < 4 && i % 2 == 0)
                //    t <<= 4;

                lrc += (byte)t;
            }

            return (byte)((lrc ^ 0xFF) + 1);
        }

        private byte[] AsciiToRtu(string asciiFrame)
        {
            byte[] rtuFrame = new byte[(asciiFrame.Length - 1 - 4) / 2];
            for (int i = 1; i < asciiFrame.Length - 1 - 4; i += 2)
            {
                rtuFrame[(i - 1) / 2] = Convert.ToByte(asciiFrame.Substring(i, 2), 16);
            }
            return rtuFrame;
        }
    }


    public static class Extension
    {
        public static void InvokeIfRequired(this Control control, MethodInvoker action)
        {
            if (control.InvokeRequired)
                control.Invoke(action);
            else
                action();
        }
    }
}
