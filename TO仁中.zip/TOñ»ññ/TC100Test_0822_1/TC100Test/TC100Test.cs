﻿using System;
using System.IO.Ports;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TC100Test
{
    public partial class TC100Test : Form
    {
        public TC100Test()
        {
            InitializeComponent();
        }

        private SerialPort _sps = new SerialPort()
        {
            PortName = "COM28",
            BaudRate = 19200,
            DataBits = 8,
            StopBits = StopBits.One,
            Parity = Parity.None,
            ReadTimeout = 500,
            WriteTimeout = 500,
        };

        private void button_Connect_Click(object sender, EventArgs e)
        {
            OpenPort();
        }

        private void button_Disconnct_Click(object sender, EventArgs e)
        {
            ClosePort();
        }

        /// <summary>
        /// 復歸。
        /// </summary>
        private void button_OriginReturn_Click(object sender, EventArgs e)
        {
            OriginReturn();
        }

        private void button_ManualSend_Click(object sender, EventArgs e)
        {
            SendRequestFrame(CallerId.Command, textBox_TestRequest.Text);
        }

        private async void checkBox_RepeatTest_CheckedChanged(object sender, EventArgs e)
        {
            Random rnd = new Random(DateTime.Now.Millisecond);

            await Task.Run(async () =>
            {
                while (checkBox_RepeatTest.Checked)
                {
                    double pos = Math.Round((rnd.NextDouble() * (100.0 - 5.0)) + 5.0, 2);
                    int speed = rnd.Next(15, 60);

                    label_TestPos.InvokeIfRequired(() =>
                    {
                        label_TestPos.Text = string.Concat("位置: ", pos.ToString("N2"));
                        label_TestSpeed.Text = string.Concat("速度: ", speed.ToString(), "%");
                    });

                    await AbsMove(1, pos, speed, 1);
                    Task.Delay(150).Wait();
                }
            });
        }

        private async void button_AbsMove_Click(object sender, EventArgs e)
        {
            await AbsMove(1, 100.0, 50, 1);
        }

        private void checkBox_WatchDog_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_WatchDog.Checked)
                _watchDog.Start();
            else
                _watchDog.Stop();
        }

        private void checkBox_ReadStatus_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_ReadStatus.Checked)
                _statusReadingTimer.Start();
            else
                _statusReadingTimer.Stop();
        }

        private void checkBox_HowToHandleException_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_HowToHandleException.Checked)
                checkBox_HowToHandleException.Text = "三次錯誤要詢問";
            else
                checkBox_HowToHandleException.Text = "三次錯誤直接放棄";
        }
    }
}
