﻿namespace TC100Test
{
    partial class TC100Test
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label_MotorStatus = new System.Windows.Forms.Label();
            this.textBox_MotorStatus = new System.Windows.Forms.TextBox();
            this.textBox_MotorAlarm = new System.Windows.Forms.TextBox();
            this.label_MotorAlarm = new System.Windows.Forms.Label();
            this.textBox_MotorRPM = new System.Windows.Forms.TextBox();
            this.label_MotorRPM = new System.Windows.Forms.Label();
            this.textBox_MotorSpeed = new System.Windows.Forms.TextBox();
            this.label_MotorSpeed = new System.Windows.Forms.Label();
            this.textBox_MotorCurrent = new System.Windows.Forms.TextBox();
            this.label_MotorCurrent = new System.Windows.Forms.Label();
            this.textBox_MotorCommandPos = new System.Windows.Forms.TextBox();
            this.label_MotorCommandPos = new System.Windows.Forms.Label();
            this.textBox_MotorCurrentPos = new System.Windows.Forms.TextBox();
            this.label_MotorCurrentPos = new System.Windows.Forms.Label();
            this.textBox_InpStatus = new System.Windows.Forms.TextBox();
            this.label_InpStatus = new System.Windows.Forms.Label();
            this.textBox_ServoStatus = new System.Windows.Forms.TextBox();
            this.label_ServoStatus = new System.Windows.Forms.Label();
            this.label_ReadStatusTitle = new System.Windows.Forms.Label();
            this.button_Connect = new System.Windows.Forms.Button();
            this.button_Disconnct = new System.Windows.Forms.Button();
            this.panel_Action = new System.Windows.Forms.Panel();
            this.label_TestSpeed = new System.Windows.Forms.Label();
            this.label_TestPos = new System.Windows.Forms.Label();
            this.checkBox_RepeatTest = new System.Windows.Forms.CheckBox();
            this.button_AbsMove = new System.Windows.Forms.Button();
            this.button_OriginReturn = new System.Windows.Forms.Button();
            this.panel_Test = new System.Windows.Forms.Panel();
            this.textBox_WatchDog = new System.Windows.Forms.TextBox();
            this.checkBox_HowToHandleException = new System.Windows.Forms.CheckBox();
            this.checkBox_ReadStatus = new System.Windows.Forms.CheckBox();
            this.checkBox_WatchDog = new System.Windows.Forms.CheckBox();
            this.textBox_TestRequest = new System.Windows.Forms.TextBox();
            this.button_ManualSend = new System.Windows.Forms.Button();
            this.label_ConsoleMessage = new System.Windows.Forms.Label();
            this.label_RequestMessage = new System.Windows.Forms.Label();
            this.label_ResponseMessage = new System.Windows.Forms.Label();
            this.textBox_ErrorStatus = new System.Windows.Forms.TextBox();
            this.label_ErrorStatus = new System.Windows.Forms.Label();
            this.label_ErrorMessage = new System.Windows.Forms.Label();
            this.label_InPosition = new System.Windows.Forms.Label();
            this.label_OutputSettingTitle = new System.Windows.Forms.Label();
            this.textBox_InPosition = new System.Windows.Forms.TextBox();
            this.label_Alarm = new System.Windows.Forms.Label();
            this.textBox_Alarm = new System.Windows.Forms.TextBox();
            this.label_Move = new System.Windows.Forms.Label();
            this.textBox_Move = new System.Windows.Forms.TextBox();
            this.label_Ready = new System.Windows.Forms.Label();
            this.textBox_Ready = new System.Windows.Forms.TextBox();
            this.label_Near = new System.Windows.Forms.Label();
            this.textBox_Near = new System.Windows.Forms.TextBox();
            this.label_InRange = new System.Windows.Forms.Label();
            this.textBox_InRange = new System.Windows.Forms.TextBox();
            this.label_TrqLmtStatus = new System.Windows.Forms.Label();
            this.textBox_TrqLmtStatus = new System.Windows.Forms.TextBox();
            this.label_ServoS = new System.Windows.Forms.Label();
            this.textBox_ServoS = new System.Windows.Forms.TextBox();
            this.label_SoftLmt = new System.Windows.Forms.Label();
            this.textBox_SoftLmt = new System.Windows.Forms.TextBox();
            this.panel_Action.SuspendLayout();
            this.panel_Test.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_MotorStatus
            // 
            this.label_MotorStatus.AutoSize = true;
            this.label_MotorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorStatus.Location = new System.Drawing.Point(433, 87);
            this.label_MotorStatus.Name = "label_MotorStatus";
            this.label_MotorStatus.Size = new System.Drawing.Size(60, 17);
            this.label_MotorStatus.TabIndex = 0;
            this.label_MotorStatus.Text = "馬達狀態";
            this.label_MotorStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorStatus
            // 
            this.textBox_MotorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorStatus.Location = new System.Drawing.Point(562, 84);
            this.textBox_MotorStatus.Name = "textBox_MotorStatus";
            this.textBox_MotorStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorStatus.TabIndex = 1;
            this.textBox_MotorStatus.TabStop = false;
            // 
            // textBox_MotorAlarm
            // 
            this.textBox_MotorAlarm.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorAlarm.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorAlarm.Location = new System.Drawing.Point(562, 177);
            this.textBox_MotorAlarm.Name = "textBox_MotorAlarm";
            this.textBox_MotorAlarm.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorAlarm.TabIndex = 3;
            this.textBox_MotorAlarm.TabStop = false;
            // 
            // label_MotorAlarm
            // 
            this.label_MotorAlarm.AutoSize = true;
            this.label_MotorAlarm.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorAlarm.Location = new System.Drawing.Point(433, 180);
            this.label_MotorAlarm.Name = "label_MotorAlarm";
            this.label_MotorAlarm.Size = new System.Drawing.Size(60, 17);
            this.label_MotorAlarm.TabIndex = 2;
            this.label_MotorAlarm.Text = "報警狀態";
            this.label_MotorAlarm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorRPM
            // 
            this.textBox_MotorRPM.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorRPM.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorRPM.Location = new System.Drawing.Point(562, 239);
            this.textBox_MotorRPM.Name = "textBox_MotorRPM";
            this.textBox_MotorRPM.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorRPM.TabIndex = 5;
            this.textBox_MotorRPM.TabStop = false;
            // 
            // label_MotorRPM
            // 
            this.label_MotorRPM.AutoSize = true;
            this.label_MotorRPM.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorRPM.Location = new System.Drawing.Point(433, 242);
            this.label_MotorRPM.Name = "label_MotorRPM";
            this.label_MotorRPM.Size = new System.Drawing.Size(123, 17);
            this.label_MotorRPM.TabIndex = 4;
            this.label_MotorRPM.Text = "馬達的迴轉速(RPM)";
            this.label_MotorRPM.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorSpeed
            // 
            this.textBox_MotorSpeed.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorSpeed.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorSpeed.Location = new System.Drawing.Point(562, 270);
            this.textBox_MotorSpeed.Name = "textBox_MotorSpeed";
            this.textBox_MotorSpeed.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorSpeed.TabIndex = 7;
            this.textBox_MotorSpeed.TabStop = false;
            // 
            // label_MotorSpeed
            // 
            this.label_MotorSpeed.AutoSize = true;
            this.label_MotorSpeed.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorSpeed.Location = new System.Drawing.Point(433, 273);
            this.label_MotorSpeed.Name = "label_MotorSpeed";
            this.label_MotorSpeed.Size = new System.Drawing.Size(116, 17);
            this.label_MotorSpeed.TabIndex = 6;
            this.label_MotorSpeed.Text = "行進速度(mm/sec)";
            this.label_MotorSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorCurrent
            // 
            this.textBox_MotorCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCurrent.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorCurrent.Location = new System.Drawing.Point(562, 301);
            this.textBox_MotorCurrent.Name = "textBox_MotorCurrent";
            this.textBox_MotorCurrent.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorCurrent.TabIndex = 9;
            this.textBox_MotorCurrent.TabStop = false;
            // 
            // label_MotorCurrent
            // 
            this.label_MotorCurrent.AutoSize = true;
            this.label_MotorCurrent.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCurrent.Location = new System.Drawing.Point(433, 304);
            this.label_MotorCurrent.Name = "label_MotorCurrent";
            this.label_MotorCurrent.Size = new System.Drawing.Size(105, 17);
            this.label_MotorCurrent.TabIndex = 8;
            this.label_MotorCurrent.Text = "馬達的電流值(%)";
            this.label_MotorCurrent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorCommandPos
            // 
            this.textBox_MotorCommandPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCommandPos.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorCommandPos.Location = new System.Drawing.Point(562, 332);
            this.textBox_MotorCommandPos.Name = "textBox_MotorCommandPos";
            this.textBox_MotorCommandPos.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorCommandPos.TabIndex = 11;
            this.textBox_MotorCommandPos.TabStop = false;
            // 
            // label_MotorCommandPos
            // 
            this.label_MotorCommandPos.AutoSize = true;
            this.label_MotorCommandPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCommandPos.Location = new System.Drawing.Point(433, 335);
            this.label_MotorCommandPos.Name = "label_MotorCommandPos";
            this.label_MotorCommandPos.Size = new System.Drawing.Size(118, 17);
            this.label_MotorCommandPos.TabIndex = 10;
            this.label_MotorCommandPos.Text = "指令現在位置(mm)";
            this.label_MotorCommandPos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_MotorCurrentPos
            // 
            this.textBox_MotorCurrentPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_MotorCurrentPos.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_MotorCurrentPos.Location = new System.Drawing.Point(562, 363);
            this.textBox_MotorCurrentPos.Name = "textBox_MotorCurrentPos";
            this.textBox_MotorCurrentPos.Size = new System.Drawing.Size(132, 25);
            this.textBox_MotorCurrentPos.TabIndex = 13;
            this.textBox_MotorCurrentPos.TabStop = false;
            // 
            // label_MotorCurrentPos
            // 
            this.label_MotorCurrentPos.AutoSize = true;
            this.label_MotorCurrentPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_MotorCurrentPos.Location = new System.Drawing.Point(433, 366);
            this.label_MotorCurrentPos.Name = "label_MotorCurrentPos";
            this.label_MotorCurrentPos.Size = new System.Drawing.Size(92, 17);
            this.label_MotorCurrentPos.TabIndex = 12;
            this.label_MotorCurrentPos.Text = "目前位置(mm)";
            this.label_MotorCurrentPos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_InpStatus
            // 
            this.textBox_InpStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_InpStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_InpStatus.Location = new System.Drawing.Point(562, 115);
            this.textBox_InpStatus.Name = "textBox_InpStatus";
            this.textBox_InpStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_InpStatus.TabIndex = 15;
            this.textBox_InpStatus.TabStop = false;
            // 
            // label_InpStatus
            // 
            this.label_InpStatus.AutoSize = true;
            this.label_InpStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_InpStatus.Location = new System.Drawing.Point(433, 118);
            this.label_InpStatus.Name = "label_InpStatus";
            this.label_InpStatus.Size = new System.Drawing.Size(60, 17);
            this.label_InpStatus.TabIndex = 14;
            this.label_InpStatus.Text = "到位訊號";
            this.label_InpStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_ServoStatus
            // 
            this.textBox_ServoStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_ServoStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_ServoStatus.Location = new System.Drawing.Point(562, 53);
            this.textBox_ServoStatus.Name = "textBox_ServoStatus";
            this.textBox_ServoStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_ServoStatus.TabIndex = 17;
            this.textBox_ServoStatus.TabStop = false;
            // 
            // label_ServoStatus
            // 
            this.label_ServoStatus.AutoSize = true;
            this.label_ServoStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ServoStatus.Location = new System.Drawing.Point(433, 56);
            this.label_ServoStatus.Name = "label_ServoStatus";
            this.label_ServoStatus.Size = new System.Drawing.Size(60, 17);
            this.label_ServoStatus.TabIndex = 16;
            this.label_ServoStatus.Text = "伺服狀態";
            this.label_ServoStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_ReadStatusTitle
            // 
            this.label_ReadStatusTitle.AutoSize = true;
            this.label_ReadStatusTitle.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ReadStatusTitle.Location = new System.Drawing.Point(432, 14);
            this.label_ReadStatusTitle.Name = "label_ReadStatusTitle";
            this.label_ReadStatusTitle.Size = new System.Drawing.Size(74, 21);
            this.label_ReadStatusTitle.TabIndex = 18;
            this.label_ReadStatusTitle.Text = "讀取狀態";
            this.label_ReadStatusTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button_Connect
            // 
            this.button_Connect.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Connect.Location = new System.Drawing.Point(52, 25);
            this.button_Connect.Name = "button_Connect";
            this.button_Connect.Size = new System.Drawing.Size(77, 31);
            this.button_Connect.TabIndex = 19;
            this.button_Connect.Text = "連線";
            this.button_Connect.UseVisualStyleBackColor = true;
            this.button_Connect.Click += new System.EventHandler(this.button_Connect_Click);
            // 
            // button_Disconnct
            // 
            this.button_Disconnct.Enabled = false;
            this.button_Disconnct.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Disconnct.Location = new System.Drawing.Point(52, 62);
            this.button_Disconnct.Name = "button_Disconnct";
            this.button_Disconnct.Size = new System.Drawing.Size(77, 31);
            this.button_Disconnct.TabIndex = 20;
            this.button_Disconnct.Text = "離線";
            this.button_Disconnct.UseVisualStyleBackColor = true;
            this.button_Disconnct.Click += new System.EventHandler(this.button_Disconnct_Click);
            // 
            // panel_Action
            // 
            this.panel_Action.Controls.Add(this.label_TestSpeed);
            this.panel_Action.Controls.Add(this.label_TestPos);
            this.panel_Action.Controls.Add(this.checkBox_RepeatTest);
            this.panel_Action.Controls.Add(this.button_AbsMove);
            this.panel_Action.Controls.Add(this.button_OriginReturn);
            this.panel_Action.Enabled = false;
            this.panel_Action.Location = new System.Drawing.Point(201, 12);
            this.panel_Action.Name = "panel_Action";
            this.panel_Action.Size = new System.Drawing.Size(209, 380);
            this.panel_Action.TabIndex = 29;
            // 
            // label_TestSpeed
            // 
            this.label_TestSpeed.AutoSize = true;
            this.label_TestSpeed.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TestSpeed.Location = new System.Drawing.Point(117, 322);
            this.label_TestSpeed.Name = "label_TestSpeed";
            this.label_TestSpeed.Size = new System.Drawing.Size(47, 17);
            this.label_TestSpeed.TabIndex = 31;
            this.label_TestSpeed.Text = "SPEED";
            // 
            // label_TestPos
            // 
            this.label_TestPos.AutoSize = true;
            this.label_TestPos.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TestPos.Location = new System.Drawing.Point(117, 302);
            this.label_TestPos.Name = "label_TestPos";
            this.label_TestPos.Size = new System.Drawing.Size(70, 17);
            this.label_TestPos.TabIndex = 30;
            this.label_TestPos.Text = "POSITION";
            // 
            // checkBox_RepeatTest
            // 
            this.checkBox_RepeatTest.AutoSize = true;
            this.checkBox_RepeatTest.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_RepeatTest.Location = new System.Drawing.Point(15, 313);
            this.checkBox_RepeatTest.Name = "checkBox_RepeatTest";
            this.checkBox_RepeatTest.Size = new System.Drawing.Size(105, 21);
            this.checkBox_RepeatTest.TabIndex = 29;
            this.checkBox_RepeatTest.Text = "重覆運動測試";
            this.checkBox_RepeatTest.UseVisualStyleBackColor = true;
            this.checkBox_RepeatTest.CheckedChanged += new System.EventHandler(this.checkBox_RepeatTest_CheckedChanged);
            // 
            // button_AbsMove
            // 
            this.button_AbsMove.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_AbsMove.Location = new System.Drawing.Point(15, 53);
            this.button_AbsMove.Name = "button_AbsMove";
            this.button_AbsMove.Size = new System.Drawing.Size(101, 31);
            this.button_AbsMove.TabIndex = 27;
            this.button_AbsMove.Text = "ABS MOVE";
            this.button_AbsMove.UseVisualStyleBackColor = false;
            this.button_AbsMove.Click += new System.EventHandler(this.button_AbsMove_Click);
            // 
            // button_OriginReturn
            // 
            this.button_OriginReturn.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_OriginReturn.Location = new System.Drawing.Point(15, 11);
            this.button_OriginReturn.Name = "button_OriginReturn";
            this.button_OriginReturn.Size = new System.Drawing.Size(77, 31);
            this.button_OriginReturn.TabIndex = 26;
            this.button_OriginReturn.Text = "復歸";
            this.button_OriginReturn.UseVisualStyleBackColor = true;
            this.button_OriginReturn.Click += new System.EventHandler(this.button_OriginReturn_Click);
            // 
            // panel_Test
            // 
            this.panel_Test.Controls.Add(this.textBox_WatchDog);
            this.panel_Test.Controls.Add(this.checkBox_HowToHandleException);
            this.panel_Test.Controls.Add(this.checkBox_ReadStatus);
            this.panel_Test.Controls.Add(this.checkBox_WatchDog);
            this.panel_Test.Controls.Add(this.textBox_TestRequest);
            this.panel_Test.Controls.Add(this.button_ManualSend);
            this.panel_Test.Enabled = false;
            this.panel_Test.Location = new System.Drawing.Point(12, 111);
            this.panel_Test.Name = "panel_Test";
            this.panel_Test.Size = new System.Drawing.Size(166, 281);
            this.panel_Test.TabIndex = 30;
            // 
            // textBox_WatchDog
            // 
            this.textBox_WatchDog.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_WatchDog.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_WatchDog.Location = new System.Drawing.Point(80, 196);
            this.textBox_WatchDog.Name = "textBox_WatchDog";
            this.textBox_WatchDog.Size = new System.Drawing.Size(83, 25);
            this.textBox_WatchDog.TabIndex = 30;
            this.textBox_WatchDog.TabStop = false;
            this.textBox_WatchDog.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // checkBox_HowToHandleException
            // 
            this.checkBox_HowToHandleException.AutoSize = true;
            this.checkBox_HowToHandleException.Checked = true;
            this.checkBox_HowToHandleException.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_HowToHandleException.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_HowToHandleException.Location = new System.Drawing.Point(16, 246);
            this.checkBox_HowToHandleException.Name = "checkBox_HowToHandleException";
            this.checkBox_HowToHandleException.Size = new System.Drawing.Size(118, 21);
            this.checkBox_HowToHandleException.TabIndex = 29;
            this.checkBox_HowToHandleException.Text = "三次錯誤要詢問";
            this.checkBox_HowToHandleException.UseVisualStyleBackColor = true;
            this.checkBox_HowToHandleException.CheckedChanged += new System.EventHandler(this.checkBox_HowToHandleException_CheckedChanged);
            // 
            // checkBox_ReadStatus
            // 
            this.checkBox_ReadStatus.AutoSize = true;
            this.checkBox_ReadStatus.Checked = true;
            this.checkBox_ReadStatus.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_ReadStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_ReadStatus.Location = new System.Drawing.Point(16, 219);
            this.checkBox_ReadStatus.Name = "checkBox_ReadStatus";
            this.checkBox_ReadStatus.Size = new System.Drawing.Size(66, 21);
            this.checkBox_ReadStatus.TabIndex = 28;
            this.checkBox_ReadStatus.Text = "讀狀態";
            this.checkBox_ReadStatus.UseVisualStyleBackColor = true;
            this.checkBox_ReadStatus.CheckedChanged += new System.EventHandler(this.checkBox_ReadStatus_CheckedChanged);
            // 
            // checkBox_WatchDog
            // 
            this.checkBox_WatchDog.AutoSize = true;
            this.checkBox_WatchDog.Checked = true;
            this.checkBox_WatchDog.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_WatchDog.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox_WatchDog.Location = new System.Drawing.Point(16, 198);
            this.checkBox_WatchDog.Name = "checkBox_WatchDog";
            this.checkBox_WatchDog.Size = new System.Drawing.Size(66, 21);
            this.checkBox_WatchDog.TabIndex = 27;
            this.checkBox_WatchDog.Text = "看門狗";
            this.checkBox_WatchDog.UseVisualStyleBackColor = true;
            this.checkBox_WatchDog.CheckedChanged += new System.EventHandler(this.checkBox_WatchDog_CheckedChanged);
            // 
            // textBox_TestRequest
            // 
            this.textBox_TestRequest.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_TestRequest.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_TestRequest.Location = new System.Drawing.Point(16, 50);
            this.textBox_TestRequest.Name = "textBox_TestRequest";
            this.textBox_TestRequest.Size = new System.Drawing.Size(134, 25);
            this.textBox_TestRequest.TabIndex = 24;
            this.textBox_TestRequest.TabStop = false;
            this.textBox_TestRequest.Text = ":0103011561";
            // 
            // button_ManualSend
            // 
            this.button_ManualSend.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_ManualSend.Location = new System.Drawing.Point(16, 13);
            this.button_ManualSend.Name = "button_ManualSend";
            this.button_ManualSend.Size = new System.Drawing.Size(134, 31);
            this.button_ManualSend.TabIndex = 21;
            this.button_ManualSend.Text = "手動發送訊息";
            this.button_ManualSend.UseVisualStyleBackColor = true;
            this.button_ManualSend.Click += new System.EventHandler(this.button_ManualSend_Click);
            // 
            // label_ConsoleMessage
            // 
            this.label_ConsoleMessage.AutoSize = true;
            this.label_ConsoleMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ConsoleMessage.Location = new System.Drawing.Point(12, 436);
            this.label_ConsoleMessage.Name = "label_ConsoleMessage";
            this.label_ConsoleMessage.Size = new System.Drawing.Size(62, 17);
            this.label_ConsoleMessage.TabIndex = 31;
            this.label_ConsoleMessage.Text = "Message";
            // 
            // label_RequestMessage
            // 
            this.label_RequestMessage.AutoSize = true;
            this.label_RequestMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_RequestMessage.Location = new System.Drawing.Point(12, 402);
            this.label_RequestMessage.Name = "label_RequestMessage";
            this.label_RequestMessage.Size = new System.Drawing.Size(62, 17);
            this.label_RequestMessage.TabIndex = 32;
            this.label_RequestMessage.Text = "Message";
            // 
            // label_ResponseMessage
            // 
            this.label_ResponseMessage.AutoSize = true;
            this.label_ResponseMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ResponseMessage.Location = new System.Drawing.Point(12, 419);
            this.label_ResponseMessage.Name = "label_ResponseMessage";
            this.label_ResponseMessage.Size = new System.Drawing.Size(62, 17);
            this.label_ResponseMessage.TabIndex = 33;
            this.label_ResponseMessage.Text = "Message";
            // 
            // textBox_ErrorStatus
            // 
            this.textBox_ErrorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_ErrorStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_ErrorStatus.Location = new System.Drawing.Point(562, 208);
            this.textBox_ErrorStatus.Name = "textBox_ErrorStatus";
            this.textBox_ErrorStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_ErrorStatus.TabIndex = 35;
            this.textBox_ErrorStatus.TabStop = false;
            // 
            // label_ErrorStatus
            // 
            this.label_ErrorStatus.AutoSize = true;
            this.label_ErrorStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ErrorStatus.Location = new System.Drawing.Point(433, 211);
            this.label_ErrorStatus.Name = "label_ErrorStatus";
            this.label_ErrorStatus.Size = new System.Drawing.Size(60, 17);
            this.label_ErrorStatus.TabIndex = 34;
            this.label_ErrorStatus.Text = "故障狀態";
            this.label_ErrorStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_ErrorMessage
            // 
            this.label_ErrorMessage.AutoSize = true;
            this.label_ErrorMessage.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ErrorMessage.ForeColor = System.Drawing.Color.Red;
            this.label_ErrorMessage.Location = new System.Drawing.Point(12, 453);
            this.label_ErrorMessage.Name = "label_ErrorMessage";
            this.label_ErrorMessage.Size = new System.Drawing.Size(92, 17);
            this.label_ErrorMessage.TabIndex = 36;
            this.label_ErrorMessage.Text = "ErrorMessage";
            // 
            // label_InPosition
            // 
            this.label_InPosition.AutoSize = true;
            this.label_InPosition.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_InPosition.Location = new System.Drawing.Point(724, 54);
            this.label_InPosition.Name = "label_InPosition";
            this.label_InPosition.Size = new System.Drawing.Size(124, 17);
            this.label_InPosition.TabIndex = 37;
            this.label_InPosition.Text = "Inposition 到位訊號";
            this.label_InPosition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_InPosition.Visible = false;
            // 
            // label_OutputSettingTitle
            // 
            this.label_OutputSettingTitle.AutoSize = true;
            this.label_OutputSettingTitle.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_OutputSettingTitle.Location = new System.Drawing.Point(723, 12);
            this.label_OutputSettingTitle.Name = "label_OutputSettingTitle";
            this.label_OutputSettingTitle.Size = new System.Drawing.Size(74, 21);
            this.label_OutputSettingTitle.TabIndex = 39;
            this.label_OutputSettingTitle.Text = "輸出設定";
            this.label_OutputSettingTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_OutputSettingTitle.Visible = false;
            // 
            // textBox_InPosition
            // 
            this.textBox_InPosition.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_InPosition.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_InPosition.Location = new System.Drawing.Point(865, 51);
            this.textBox_InPosition.Name = "textBox_InPosition";
            this.textBox_InPosition.Size = new System.Drawing.Size(132, 25);
            this.textBox_InPosition.TabIndex = 38;
            this.textBox_InPosition.TabStop = false;
            this.textBox_InPosition.Visible = false;
            // 
            // label_Alarm
            // 
            this.label_Alarm.AutoSize = true;
            this.label_Alarm.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Alarm.Location = new System.Drawing.Point(724, 87);
            this.label_Alarm.Name = "label_Alarm";
            this.label_Alarm.Size = new System.Drawing.Size(60, 17);
            this.label_Alarm.TabIndex = 40;
            this.label_Alarm.Text = "錯誤訊號";
            this.label_Alarm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_Alarm.Visible = false;
            // 
            // textBox_Alarm
            // 
            this.textBox_Alarm.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_Alarm.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_Alarm.Location = new System.Drawing.Point(865, 84);
            this.textBox_Alarm.Name = "textBox_Alarm";
            this.textBox_Alarm.Size = new System.Drawing.Size(132, 25);
            this.textBox_Alarm.TabIndex = 41;
            this.textBox_Alarm.TabStop = false;
            this.textBox_Alarm.Visible = false;
            // 
            // label_Move
            // 
            this.label_Move.AutoSize = true;
            this.label_Move.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Move.Location = new System.Drawing.Point(724, 149);
            this.label_Move.Name = "label_Move";
            this.label_Move.Size = new System.Drawing.Size(47, 17);
            this.label_Move.TabIndex = 44;
            this.label_Move.Text = "移動中";
            this.label_Move.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_Move.Visible = false;
            // 
            // textBox_Move
            // 
            this.textBox_Move.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_Move.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_Move.Location = new System.Drawing.Point(865, 146);
            this.textBox_Move.Name = "textBox_Move";
            this.textBox_Move.Size = new System.Drawing.Size(132, 25);
            this.textBox_Move.TabIndex = 45;
            this.textBox_Move.TabStop = false;
            this.textBox_Move.Visible = false;
            // 
            // label_Ready
            // 
            this.label_Ready.AutoSize = true;
            this.label_Ready.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Ready.Location = new System.Drawing.Point(724, 118);
            this.label_Ready.Name = "label_Ready";
            this.label_Ready.Size = new System.Drawing.Size(99, 17);
            this.label_Ready.TabIndex = 42;
            this.label_Ready.Text = "可執行下一點位";
            this.label_Ready.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_Ready.Visible = false;
            // 
            // textBox_Ready
            // 
            this.textBox_Ready.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_Ready.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_Ready.Location = new System.Drawing.Point(865, 115);
            this.textBox_Ready.Name = "textBox_Ready";
            this.textBox_Ready.Size = new System.Drawing.Size(132, 25);
            this.textBox_Ready.TabIndex = 43;
            this.textBox_Ready.TabStop = false;
            this.textBox_Ready.Visible = false;
            // 
            // label_Near
            // 
            this.label_Near.AutoSize = true;
            this.label_Near.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Near.Location = new System.Drawing.Point(724, 273);
            this.label_Near.Name = "label_Near";
            this.label_Near.Size = new System.Drawing.Size(138, 17);
            this.label_Near.TabIndex = 52;
            this.label_Near.Text = "至目標的範圍內時輸出";
            this.label_Near.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_Near.Visible = false;
            // 
            // textBox_Near
            // 
            this.textBox_Near.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_Near.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_Near.Location = new System.Drawing.Point(865, 270);
            this.textBox_Near.Name = "textBox_Near";
            this.textBox_Near.Size = new System.Drawing.Size(132, 25);
            this.textBox_Near.TabIndex = 53;
            this.textBox_Near.TabStop = false;
            this.textBox_Near.Visible = false;
            // 
            // label_InRange
            // 
            this.label_InRange.AutoSize = true;
            this.label_InRange.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_InRange.Location = new System.Drawing.Point(724, 242);
            this.label_InRange.Name = "label_InRange";
            this.label_InRange.Size = new System.Drawing.Size(125, 17);
            this.label_InRange.TabIndex = 50;
            this.label_InRange.Text = "區間設定範圍內輸出";
            this.label_InRange.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_InRange.Visible = false;
            // 
            // textBox_InRange
            // 
            this.textBox_InRange.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_InRange.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_InRange.Location = new System.Drawing.Point(865, 239);
            this.textBox_InRange.Name = "textBox_InRange";
            this.textBox_InRange.Size = new System.Drawing.Size(132, 25);
            this.textBox_InRange.TabIndex = 51;
            this.textBox_InRange.TabStop = false;
            this.textBox_InRange.Visible = false;
            // 
            // label_TrqLmtStatus
            // 
            this.label_TrqLmtStatus.AutoSize = true;
            this.label_TrqLmtStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TrqLmtStatus.Location = new System.Drawing.Point(433, 149);
            this.label_TrqLmtStatus.Name = "label_TrqLmtStatus";
            this.label_TrqLmtStatus.Size = new System.Drawing.Size(86, 17);
            this.label_TrqLmtStatus.TabIndex = 48;
            this.label_TrqLmtStatus.Text = "扭力極限狀態";
            this.label_TrqLmtStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBox_TrqLmtStatus
            // 
            this.textBox_TrqLmtStatus.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_TrqLmtStatus.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_TrqLmtStatus.Location = new System.Drawing.Point(562, 146);
            this.textBox_TrqLmtStatus.Name = "textBox_TrqLmtStatus";
            this.textBox_TrqLmtStatus.Size = new System.Drawing.Size(132, 25);
            this.textBox_TrqLmtStatus.TabIndex = 49;
            this.textBox_TrqLmtStatus.TabStop = false;
            // 
            // label_ServoS
            // 
            this.label_ServoS.AutoSize = true;
            this.label_ServoS.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ServoS.Location = new System.Drawing.Point(724, 180);
            this.label_ServoS.Name = "label_ServoS";
            this.label_ServoS.Size = new System.Drawing.Size(103, 17);
            this.label_ServoS.TabIndex = 46;
            this.label_ServoS.Text = "SERVO ON 狀態";
            this.label_ServoS.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_ServoS.Visible = false;
            // 
            // textBox_ServoS
            // 
            this.textBox_ServoS.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_ServoS.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_ServoS.Location = new System.Drawing.Point(865, 177);
            this.textBox_ServoS.Name = "textBox_ServoS";
            this.textBox_ServoS.Size = new System.Drawing.Size(132, 25);
            this.textBox_ServoS.TabIndex = 47;
            this.textBox_ServoS.TabStop = false;
            this.textBox_ServoS.Visible = false;
            // 
            // label_SoftLmt
            // 
            this.label_SoftLmt.AutoSize = true;
            this.label_SoftLmt.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_SoftLmt.Location = new System.Drawing.Point(724, 304);
            this.label_SoftLmt.Name = "label_SoftLmt";
            this.label_SoftLmt.Size = new System.Drawing.Size(112, 17);
            this.label_SoftLmt.TabIndex = 54;
            this.label_SoftLmt.Text = "軟體極限輸出燈號";
            this.label_SoftLmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_SoftLmt.Visible = false;
            // 
            // textBox_SoftLmt
            // 
            this.textBox_SoftLmt.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_SoftLmt.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBox_SoftLmt.Location = new System.Drawing.Point(865, 301);
            this.textBox_SoftLmt.Name = "textBox_SoftLmt";
            this.textBox_SoftLmt.Size = new System.Drawing.Size(132, 25);
            this.textBox_SoftLmt.TabIndex = 55;
            this.textBox_SoftLmt.TabStop = false;
            this.textBox_SoftLmt.Visible = false;
            // 
            // TC100Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(712, 475);
            this.Controls.Add(this.label_SoftLmt);
            this.Controls.Add(this.textBox_SoftLmt);
            this.Controls.Add(this.label_Near);
            this.Controls.Add(this.textBox_Near);
            this.Controls.Add(this.label_InRange);
            this.Controls.Add(this.textBox_InRange);
            this.Controls.Add(this.label_TrqLmtStatus);
            this.Controls.Add(this.textBox_TrqLmtStatus);
            this.Controls.Add(this.label_ServoS);
            this.Controls.Add(this.textBox_ServoS);
            this.Controls.Add(this.label_Move);
            this.Controls.Add(this.textBox_Move);
            this.Controls.Add(this.label_Ready);
            this.Controls.Add(this.textBox_Ready);
            this.Controls.Add(this.label_Alarm);
            this.Controls.Add(this.textBox_Alarm);
            this.Controls.Add(this.label_InPosition);
            this.Controls.Add(this.label_OutputSettingTitle);
            this.Controls.Add(this.textBox_InPosition);
            this.Controls.Add(this.label_ErrorMessage);
            this.Controls.Add(this.textBox_ErrorStatus);
            this.Controls.Add(this.label_ErrorStatus);
            this.Controls.Add(this.label_ResponseMessage);
            this.Controls.Add(this.label_RequestMessage);
            this.Controls.Add(this.label_ConsoleMessage);
            this.Controls.Add(this.panel_Test);
            this.Controls.Add(this.label_ServoStatus);
            this.Controls.Add(this.button_Disconnct);
            this.Controls.Add(this.button_Connect);
            this.Controls.Add(this.label_ReadStatusTitle);
            this.Controls.Add(this.textBox_ServoStatus);
            this.Controls.Add(this.textBox_InpStatus);
            this.Controls.Add(this.label_InpStatus);
            this.Controls.Add(this.textBox_MotorCurrentPos);
            this.Controls.Add(this.label_MotorCurrentPos);
            this.Controls.Add(this.textBox_MotorCommandPos);
            this.Controls.Add(this.label_MotorCommandPos);
            this.Controls.Add(this.textBox_MotorCurrent);
            this.Controls.Add(this.label_MotorCurrent);
            this.Controls.Add(this.textBox_MotorSpeed);
            this.Controls.Add(this.label_MotorSpeed);
            this.Controls.Add(this.textBox_MotorRPM);
            this.Controls.Add(this.label_MotorRPM);
            this.Controls.Add(this.textBox_MotorAlarm);
            this.Controls.Add(this.label_MotorAlarm);
            this.Controls.Add(this.textBox_MotorStatus);
            this.Controls.Add(this.label_MotorStatus);
            this.Controls.Add(this.panel_Action);
            this.Name = "TC100Test";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TC-100 測試";
            this.panel_Action.ResumeLayout(false);
            this.panel_Action.PerformLayout();
            this.panel_Test.ResumeLayout(false);
            this.panel_Test.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_MotorStatus;
        private System.Windows.Forms.TextBox textBox_MotorStatus;
        private System.Windows.Forms.TextBox textBox_MotorAlarm;
        private System.Windows.Forms.Label label_MotorAlarm;
        private System.Windows.Forms.TextBox textBox_MotorRPM;
        private System.Windows.Forms.Label label_MotorRPM;
        private System.Windows.Forms.TextBox textBox_MotorSpeed;
        private System.Windows.Forms.Label label_MotorSpeed;
        private System.Windows.Forms.TextBox textBox_MotorCurrent;
        private System.Windows.Forms.Label label_MotorCurrent;
        private System.Windows.Forms.TextBox textBox_MotorCommandPos;
        private System.Windows.Forms.Label label_MotorCommandPos;
        private System.Windows.Forms.TextBox textBox_MotorCurrentPos;
        private System.Windows.Forms.Label label_MotorCurrentPos;
        private System.Windows.Forms.TextBox textBox_InpStatus;
        private System.Windows.Forms.Label label_InpStatus;
        private System.Windows.Forms.TextBox textBox_ServoStatus;
        private System.Windows.Forms.Label label_ServoStatus;
        private System.Windows.Forms.Label label_ReadStatusTitle;
        private System.Windows.Forms.Button button_Connect;
        private System.Windows.Forms.Button button_Disconnct;
        private System.Windows.Forms.Panel panel_Action;
        private System.Windows.Forms.Label label_TestSpeed;
        private System.Windows.Forms.Label label_TestPos;
        private System.Windows.Forms.CheckBox checkBox_RepeatTest;
        private System.Windows.Forms.Button button_AbsMove;
        private System.Windows.Forms.Button button_OriginReturn;
        private System.Windows.Forms.Panel panel_Test;
        private System.Windows.Forms.TextBox textBox_TestRequest;
        private System.Windows.Forms.Button button_ManualSend;
        private System.Windows.Forms.CheckBox checkBox_ReadStatus;
        private System.Windows.Forms.CheckBox checkBox_WatchDog;
        private System.Windows.Forms.Label label_ConsoleMessage;
        private System.Windows.Forms.Label label_RequestMessage;
        private System.Windows.Forms.Label label_ResponseMessage;
        private System.Windows.Forms.TextBox textBox_ErrorStatus;
        private System.Windows.Forms.Label label_ErrorStatus;
        private System.Windows.Forms.CheckBox checkBox_HowToHandleException;
        private System.Windows.Forms.Label label_ErrorMessage;
        private System.Windows.Forms.TextBox textBox_WatchDog;
        private System.Windows.Forms.Label label_InPosition;
        private System.Windows.Forms.Label label_OutputSettingTitle;
        private System.Windows.Forms.TextBox textBox_InPosition;
        private System.Windows.Forms.Label label_Alarm;
        private System.Windows.Forms.TextBox textBox_Alarm;
        private System.Windows.Forms.Label label_Move;
        private System.Windows.Forms.TextBox textBox_Move;
        private System.Windows.Forms.Label label_Ready;
        private System.Windows.Forms.TextBox textBox_Ready;
        private System.Windows.Forms.Label label_Near;
        private System.Windows.Forms.TextBox textBox_Near;
        private System.Windows.Forms.Label label_InRange;
        private System.Windows.Forms.TextBox textBox_InRange;
        private System.Windows.Forms.Label label_TrqLmtStatus;
        private System.Windows.Forms.TextBox textBox_TrqLmtStatus;
        private System.Windows.Forms.Label label_ServoS;
        private System.Windows.Forms.TextBox textBox_ServoS;
        private System.Windows.Forms.Label label_SoftLmt;
        private System.Windows.Forms.TextBox textBox_SoftLmt;
    }
}

