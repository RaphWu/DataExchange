﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TC100Test
{
    public partial class TC100Test
    {
        private bool InPosition(double position)
        {
            return _readStatus.ActionStatus == 0
                    && _readStatus.InpStatus == 1
                    && Math.Abs(_readStatus.CmdNowPos - position) <= 0.01
                    && Math.Abs(_readStatus.EcdPos - position) <= 0.01;
        }

        private void OriginReturn()
        {
            SendRequestFrame(CallerId.Command, GetRequestFrame(0x01, 0x06, 0x201E, 3));
        }

        public async Task AbsMove(byte station, double position, int speed, double push)
        {
            string cmd = string.Concat(":01062014", speed.ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);
            //await Task.Delay(10);

            cmd = string.Concat(":01060400", ((int)(push * 10)).ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);
            //await Task.Delay(10);

            cmd = string.Concat(":01060401", ((int)(push * 10)).ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);
            //await Task.Delay(10);

            cmd = string.Concat(":01102002000204", ((int)(position * 100)).ToString("X8"));
            SendRequestFrame(CallerId.Command, cmd);
            //await Task.Delay(10);

            SendRequestFrame(CallerId.Command, ":0106201E0001");

            while (!InPosition(position))
                await Task.Delay(50, this._token);
            //await Task.CompletedTask;
        }
    }
}
