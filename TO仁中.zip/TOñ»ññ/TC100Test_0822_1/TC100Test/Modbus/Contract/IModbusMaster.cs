﻿
namespace TC100Test.External.Contract
{
    public interface IModbusMaster
    {
    }
}
