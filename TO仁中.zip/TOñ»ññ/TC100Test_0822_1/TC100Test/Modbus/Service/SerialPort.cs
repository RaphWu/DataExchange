﻿//using System;

//namespace TC100Test.Modbus.Service
//{
//    public class SerialPort
//    {
//        private SerialPortStream _port;

//        /// <summary>
//        /// ctor
//        /// </summary>
//        public SerialPort()
//        {
//            _port = new SerialPortStream
//            {
//                PortName = "COM28",
//                BaudRate = 19200,
//                DataBits = 8,
//                StopBits = StopBits.One,
//                Parity = Parity.None,
//            };

//            Open();
//        }

//        public bool IsOpen
//        {
//            get { return _port.IsOpen; }
//        }

//        public int InfiniteTimeout
//        {
//            get { return SerialPortStream.InfiniteTimeout; }
//        }

//        public int ReadTimeout
//        {
//            get { return _port.ReadTimeout; }
//            set { _port.ReadTimeout = value; }
//        }

//        public int WriteTimeout
//        {
//            get { return _port.WriteTimeout; }
//            set { _port.WriteTimeout = value; }
//        }

//        public void DiscardInBuffer()
//        {
//            _port.DiscardInBuffer();
//        }

//        public int Read(byte[] buffer, int offset, int count)
//        {
//            return _port.Read(buffer, offset, count);
//        }

//        public int Read(byte[] buffer, int offset)
//        {
//            return Read(buffer, offset, buffer.Length - offset);
//        }

//        public int Read(byte[] buffer)
//        {
//            return Read(buffer, 0, buffer.Length);
//        }

//        public void Write(byte[] buffer, int offset, int count)
//        {
//            _port.Write(buffer, offset, count);
//        }

//        public void Write(byte[] buffer, int offset)
//        {
//            _port.Write(buffer, offset, buffer.Length - offset);
//        }

//        public void Write(byte[] buffer)
//        {
//            _port.Write(buffer, 0, buffer.Length);
//        }

//        private void Open()
//        {
//            try
//            {
//                if (_port.IsOpen)
//                {
//                    _port.DataReceived -= DataReceived;
//                    _port.Close();
//                }
//                _port.Open();

//                if (_port.IsOpen)
//                {
//                    _port.DataReceived += DataReceived;
//                }
//            }
//            catch
//            {
//                _port.DataReceived -= DataReceived;
//                _port.Close();
//            }
//        }

//        private void Close()
//        {
//            _port.Close();
//        }

//        private void Send(string message)
//        {
//            _port.Write(message);
//        }

//        /***** private functions *****/
//        private void DataReceived(object sender, SerialDataReceivedEventArgs e)
//        {
//            string data = _port.ReadExisting();
//            Console.WriteLine(data);
//        }
//    }
//}
