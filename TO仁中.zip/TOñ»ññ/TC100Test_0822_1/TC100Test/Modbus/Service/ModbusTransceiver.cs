﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using TC100Test.Modbus.Contant;

//namespace TC100Test.Modbus.Service
//{
//    public class ModbusTransceiver
//    {
//        /// <summary>
//        /// 在功能碼0x01/0x02/0x03/0x04查詢後，依照指定的位元組順序對從站(伺服器端)傳回的資料進行解析。 
//        /// 1、功能碼0x01和0x02回傳的資料是bool數組，順序是低位址到高位址的開關狀態。 
//        /// 2、功能碼0x03和0x04回傳的資料是byte、ushort、int、float數組，由byOrder參數決定。 
//        /// 3、功能碼0x05、0x06、0x0F、0x10回傳資料解析為數值沒有意義，如果有其他用途可以再做補充。 
//        /// </summary>
//        /// <param name="data">從站(伺服器端)傳回的全部數據，ModbusRTU包括CRC,ModbusASCII包括幀頭冒號和幀尾\r\n</param>
//        /// <param name="byteOrder">指定的位元組順序，只對0x03、0x04查詢回傳的資料有效</param>
//        /// <param name="transferMode">Modbus協定類型，預設為ModbusRTU</param>
//        /// <returns>解析後的bool/byte/ushort/int/float陣列</returns>
//        public object ParseModbusData(byte[] data,
//        ModbusByteOrder byteOrder = ModbusByteOrder.NONE,
//        ModbusTransferMode transferMode = ModbusTransferMode.ASCII)
//        {
//            ModbusErrorCodes error = ModbusErrorCodes.NO_ERROR;

//            try
//            {
//                // 0.根據連線類型，把原始資料轉換成標準的byte[]
//                List<byte> temp = new List<byte>();
//                if (transferMode == ModbusTransferMode.RTU)
//                {
//                    temp.AddRange(data);
//                }
//                else if (transferMode == ModbusTransferMode.ASCII)
//                {
//                    // ModbusASCII幀頭和幀尾檢測合格後對原始資料進行轉換
//                    if (data[0] == 0x3A && data[data.Length - 2] == 0x0D && data[data.Length - 1] == 0x0A)
//                    {
//                        byte[] btemp = data.Skip(1).Take(data.Length - 3).ToArray();
//                        string tempString = Encoding.ASCII.GetString(btemp);
//                        temp.AddRange(ModbusUtility.HexToBytes(tempString));
//                    }
//                    else
//                    {
//                        error = ModbusErrorCodes.WRONG_RESPONSE_VALUE;
//                        return null;
//                    }
//                }
//                // else if (modbusType == ModbusTransferMode.TCP_IP)
//                // {
//                // temp = data.Skip(6).Take(data.Length - 6).ToList();
//                // }

//                byte[] source = temp.ToArray();

//                // 1、偵測是否為返回命令數據
//                bool isCode = false;
//                foreach (ModbusFunctionCodes Mc in Enum.GetValues(typeof(ModbusFunctionCodes)))
//                {
//                    // 不是回傳指令，也不是回傳異常碼
//                    if (source[1] == Mc.GetHashCode() || source[1] == (Mc.GetHashCode() + 0x80))
//                    {
//                        isCode = true;
//                        break;
//                    }
//                }
//                if (!isCode)
//                {
//                    error = ModbusErrorCodes.EXCEEDING_MODBUSCODE_RANGE;
//                    return null;
//                }

//                // 2、偵測CRC16或LRC是否正確(ModbusTCP無此校驗)
//                if (transferMode == ModbusTransferMode.RTU)// CRC16是否正確
//                {
//                    byte[] crc16Temp = ModbusUtility.CalculateCRC(source);
//                    if (crc16Temp[0] != source[source.Length - 2] && crc16Temp[1] != source[source.Length - 1])
//                    {
//                        error = ModbusErrorCodes.WRONG_CRC;
//                        return null;
//                    }
//                }

//                if (transferMode == ModbusTransferMode.ASCII)// LRC是否正確
//                {
//                    byte lrc = ModbusUtility.CalculateLRC(source);
//                    if (lrc != source[source.Length - 1])
//                    {
//                        error = ModbusErrorCodes.WRONG_LRC;
//                        return null;
//                    }
//                }

//                // 3.解析功能碼0x01,0x02查詢線圈或離散量開關量數據，所以用bool類型
//                if (source[1] == 0x01 || source[1] == 0x02)
//                {
//                    // 3.1、把有效資料從回傳資料的陣列中取出來
//                    byte[] values = new byte[source[2]];
//                    Array.Copy(source, 3, values, 0, values.Length);

//                    // 3.2、把資料放入BitArray數組，它會依byte值產生由低位到高位的bool數組，正好與Modbus返回開關量由低到高的順序一致。 
//                    BitArray barray = new BitArray(values);

//                    // 3.3、產生bool數組，把BitArray產生的開關量取回，順序是由低到高
//                    bool[] results = new bool[barray.Length];
//                    barray.CopyTo(results, 0);

//                    // 所以，功能碼0x01和0x02回傳的資料是bool數組，順序是低位址到高位址的開關狀態，bool數組是長度是以位元組順序
//                    // 轉換的，所以是8(bit)的倍數，大於等於要查詢的線圈或離散量的數量，從低到高取要查看的開關量數量即可，最後多餘
//                    // 出來的是從站回傳資料時自動補的0(false)。 
//                    return results;

//                }
//                // 4.解析功能碼0x03、0x04查詢暫存器值的數據，在一些PLC、使用485傳輸或其他裝置上，多數會取一個暫存器(兩個位元組)或
//                // 兩個暫存器的值，用以表示電流、電壓、溫度或加工時所用到的參數等數據，那麼就會牽涉到取回值是int,還是float等型別。 
//                if (source[1] == 0x03 || source[1] == 0x04)
//                {
//                    // 4.1、把有效資料從回傳資料的陣列中取出來
//                    byte[] values = new byte[source[2]];
//                    Array.Copy(source, 3, values, 0, values.Length);

//                    // 4.2、根據給定參數來決定回傳值，如果沒有指定類型，則原樣傳回取出來的數據
//                    if (byteOrder == ModbusByteOrder.NONE)
//                    {
//                        return values;
//                    }

//                    // 4.3、目前只考慮WORD、int和float常用類型
//                    // 拆解位元組型別與順序枚舉：byOrder[0]表示兩個或四個位元組，byOrder[1]表示型別是WORD、int、float，byOder[2]表示取值時的位元組順序
//                    string[] byOrder = Enum.GetName(typeof(ModbusByteOrder), byteOrder).Split('_');

//                    // 4.3.1、WORD類型(無符號)
//                    if (byOrder[0] == "TWO" && byOrder[1] == "WORD")
//                    {
//                        // WORD類型必須是兩個位元組為一組，先把資料value兩個兩個分好組，如果有餘數，則棄掉
//                        ushort[] result = new ushort[values.Length / 2];

//                        // 假如回傳零個或一個位元組數據，那肯定有誤，不可能發生，但是還是防止吧。 
//                        if (result.Length == 0)
//                        {
//                            error = ModbusErrorCodes.WRONG_RESPONSE_REGISTERS;
//                            return null;
//                        }

//                        if (byOrder[2] == "12")
//                        {
//                            for (int i = 0; i < result.Length; i++)
//                            {
//                                // BitConvert.ToUInt16轉換byte數組，byte[0]是低字節，byte[1]是高字節
//                                result[i] = BitConverter.ToUInt16(new byte[] { values[i * 2 + 1], values[i * 2] }, 0);
//                                // 上面語句相當於以下語句
//                                // result[i] = (ushort)((values[i * 2] << 8) | (values[i * 2 + 1] & 0x00FF));
//                            }

//                            return result;
//                        }

//                        if (byOrder[2] == "21")
//                        {
//                            for (int i = 0; i < result.Length; i++)
//                            {
//                                // BitConvert.ToUInt16轉換byte數組，byte[0]是低字節，byte[1]是高字節
//                                result[i] = BitConverter.ToUInt16(new byte[] { values[i * 2], values[i * 2 + 1] }, 0);
//                                // 上面語句相當於以下語句
//                                // result[i] = (ushort)((values[i * 2] & 0x00FF) | (values[i * 2 + 1] << 8));
//                            }

//                            return result;
//                        }
//                    }

//                    // 4.3.2、int型
//                    if (byOrder[0] == "FOUR" && byOrder[1] == "INT")
//                    {
//                        // 解析傳回的int數組
//                        int[] result = new int[values.Length / 4];

//                        // 假如回傳0個至3個位元組數據，那肯定有誤，不可能發生，但還是防止吧。 
//                        if (result.Length == 0)
//                        {
//                            error = ModbusErrorCodes.WRONG_RESPONSE_REGISTERS;
//                            return null;
//                        }

//                        for (int i = 0; i < result.Length; i++)
//                        {
//                            byte No1 = values[i * 4];
//                            byte No2 = values[i * 4 + 1];
//                            byte No3 = values[i * 4 + 2];
//                            byte No4 = values[i * 4 + 3];
//                            switch (byOrder[2])
//                            {
//                                case "1234":
//                                    // 大端1234，在BitConvert.ToInt32時，輸入的byte[]陣列是依小端順序，
//                                    // 即從右向左賦值順序是1234(4 <- 3 <- 2 <- 1)
//                                    result[i] = BitConverter.ToInt32(new byte[] { No4, No3, No2, No1 }, 0);
//                                    break;
//                                case "1243":
//                                    // 大端1243，轉小端應從右向左賦值(3 <- 4 <- 2 <- 1)
//                                    result[i] = BitConverter.ToInt32(new byte[] { No3, No4, No2, No1 }, 0);
//                                    break;
//                                case "2134":
//                                    // 大端2143，轉小端也可以認為是把2143前後倒過來，即4312
//                                    result[i] = BitConverter.ToInt32((new byte[] { No2, No1, No3, No4 }).Reverse().ToArray(), 0);
//                                    break;
//                                case "2143":
//                                    result[i] = BitConverter.ToInt32(new byte[] { No3, No4, No1, No2 }, 0);
//                                    break;
//                                case "3412":
//                                    result[i] = BitConverter.ToInt32(new byte[] { No2, No1, No4, No3 }, 0);
//                                    break;
//                                case "3421":
//                                    result[i] = BitConverter.ToInt32(new byte[] { No1, No2, No4, No3 }, 0);
//                                    break;
//                                case "4312":
//                                    result[i] = BitConverter.ToInt32(new byte[] { No2, No1, No3, No4 }, 0);
//                                    break;
//                                case "4321":
//                                    result[i] = BitConverter.ToInt32(new byte[] { No1, No2, No3, No4 }, 0);
//                                    break;
//                            }
//                        }

//                        return result;
//                    }

//                    // 4.3.3、float類型
//                    if (byOrder[0] == "FOUR" && byOrder[1] == "FLOAT")
//                    {
//                        // 解析傳回的float數組
//                        float[] result = new float[values.Length / 4];

//                        // 假如回傳0個至3個位元組數據，那肯定有誤，不可能發生，但還是防止吧。 
//                        if (result.Length == 0)
//                        {
//                            error = ModbusErrorCodes.WRONG_RESPONSE_REGISTERS;
//                            return null;
//                        }

//                        for (int i = 0; i < result.Length; i++)
//                        {
//                            byte No1 = values[i * 4];
//                            byte No2 = values[i * 4 + 1];
//                            byte No3 = values[i * 4 + 2];
//                            byte No4 = values[i * 4 + 3];

//                            switch (byOrder[2])
//                            {
//                                case "1234":
//                                    // 大端1234，在BitConvert.ToSingle)時，輸入的byte[]陣列是依小端順序，
//                                    // 即從右向左賦值順序是1234(4 <- 3 <- 2 <- 1)
//                                    result[i] = BitConverter.ToSingle(new byte[] { No4, No3, No2, No1 }, 0);
//                                    break;
//                                case "1243":
//                                    // 大端1243，轉小端應從右向左賦值(3 <- 4 <- 2 <- 1)
//                                    result[i] = BitConverter.ToSingle(new byte[] { No3, No4, No2, No1 }, 0);
//                                    break;
//                                case "2134":
//                                    // 大端2143，轉小端也可以認為是把2143前後倒過來，即4312
//                                    result[i] = BitConverter.ToSingle((new byte[] { No2, No1, No3, No4 }).Reverse().ToArray(), 0);
//                                    break;
//                                case "2143":
//                                    result[i] = BitConverter.ToSingle(new byte[] { No3, No4, No1, No2 }, 0);
//                                    break;
//                                case "3412":
//                                    result[i] = BitConverter.ToSingle(new byte[] { No2, No1, No4, No3 }, 0);
//                                    break;
//                                case "3421":
//                                    result[i] = BitConverter.ToSingle(new byte[] { No1, No2, No4, No3 }, 0);
//                                    break;
//                                case "4312":
//                                    result[i] = BitConverter.ToSingle(new byte[] { No2, No1, No3, No4 }, 0);
//                                    break;
//                                case "4321":
//                                    result[i] = BitConverter.ToSingle(new byte[] { No1, No2, No3, No4 }, 0);
//                                    break;
//                            }
//                        }

//                        return result;
//                    }
//                }
//                // 5.功能碼0x05、0x06、0x0F、0x10指令的回傳資料與傳送時基本上相同，0x05、0x06完全相同，0x0F、0x10前6個字節相同，CRC16不同。 
//                // 所以取回傳資料意義不大。 
//                if (source[1] == 0x05 || source[1] == 0x06 || source[1] == 0x0F || source[1] == 0x10)
//                {
//                    /*
//                    * 有用時再寫相關內容
//                    */
//                    error = ModbusErrorCodes.UNPROCESSED_MODBUSCODE;
//                    return null;
//                }

//                // 6、異常處理
//                if (source[1] > 0x80)
//                {
//                    switch (source[2])
//                    {
//                        case 1:
//                            error = ModbusErrorCodes.EXCEPTION_ILLEGAL_FUNCTION;// 非法的功能碼
//                            break;

//                        case 2:
//                            error = ModbusErrorCodes.EXCEPTION_ILLEGAL_DATA_ADDRESS;// 非法的資料位址
//                            break;

//                        case 3:
//                            error = ModbusErrorCodes.EXCEPTION_ILLEGAL_DATA_VALUE;// 非法的資料值
//                            break;

//                        case 4:
//                            error = ModbusErrorCodes.EXCEPTION_SLAVE_DEVICE_FAILURE;// 從站(伺服器)故障
//                            break;
//                    }

//                    return null;
//                }

//                // 7、其他ModbusRTU指令，這裡不做解析
//                error = ModbusErrorCodes.UNPROCESSED_MODBUSCODE;
//                return null;
//            }
//            catch
//            {
//                error = ModbusErrorCodes.EXCEPTION_UNKNOWN;
//                return null;
//            }
//        }
//    }
//}
