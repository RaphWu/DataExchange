﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace TC100Test.Modbus.Service
//{
//    public class ModbusAsciiTransceiver : ModbusTransceiver
//    {
//        /// <summary>
//        /// ctor
//        /// </summary>
//        public ModbusAsciiTransceiver()
//        {
//        }

//        /********************
//         * Coil
//         ********************/


//        /********************
//         * 離散輸入
//         ********************/


//        /********************
//         * 保存暫存器
//         ********************/
//        //public byte[] ReadHoldingRegister(this 

//        /********************
//         * 輸入暫存器
//         ********************/
//    }
//}
