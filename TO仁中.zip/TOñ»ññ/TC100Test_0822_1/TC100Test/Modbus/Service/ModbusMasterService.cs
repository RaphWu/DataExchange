﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TC100Test.External.Contract;

namespace TC100Test
{
    public class ModbusMasterService : IModbusMaster
    {
    }
}
