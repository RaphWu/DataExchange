﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TC100Test.Modbus.Contant
{
    public enum ModbusFunctionCodes
    {
        READ_COILS = 0x01,
        READ_DISCRETE_INPUTS = 0x02,
        READ_HOLDING_REGISTERS = 0x03,
        READ_INPUT_REGISTERS = 0x04,
        WRITE_SINGLE_COIL = 0x05,
        WRITE_SINGLE_REGISTER = 0x06,
        READ_EXCEPTION_STATUS = 0x07,
        DIAGNOSTIC = 0x08,
        GET_COM_EVENT_COUNTER = 0x0B,
        GET_COM_EVENT_LOG = 0x0C,
        WRITE_MULTIPLE_COILS = 0x0F,
        WRITE_MULTIPLE_REGISTERS = 0x10,
        REPORT_SLAVE_ID = 0x11,
        READ_FILE_RECORD = 0x14,
        WRITE_FILE_RECORD = 0x15,
        MASK_WRITE_REGISTER = 0x16,
        READ_WRITE_MULTIPLE_REGISTERS = 0x17,
        READ_FIFO_QUEUE = 0x18,
        READ_DEVICE_IDENTIFICATION = 0x2B
    }
}
