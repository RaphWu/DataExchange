﻿
namespace TC100Test.Modbus.Contant
{
    public enum ModbusTransferMode
    {
        RTU,
        ASCII,
    }
}
