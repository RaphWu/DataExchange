﻿
namespace TC100Test.Modbus.Contant
{
    /// <summary>
    /// Modbus協定的Data Type。
    /// </summary>
    public enum ModbusDataType
    {
        /// <summary>
        /// Coil(讀/寫)。
        /// </summary>
        Coil,

        /// <summary>
        /// 離散輸入(唯讀)。
        /// </summary>
        Input,

        /// <summary>
        /// 保存暫存器(讀/寫)。
        /// </summary>
        HoldingRegister,

        /// <summary>
        /// 輸入暫存器(唯讀)。
        /// </summary>
        InputRegister,
    }
}
