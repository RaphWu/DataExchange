﻿namespace TC100Test.Modbus.Contant
{
    public enum ModbusByteOrder
    {
        NONE = 0,
        TWO_WORD_12 = 1,
        TWO_WORD_21 = 2,
        FOUR_INT_1234 = 3,
        FOUR_INT_1243 = 4,
        FOUR_INT_2134 = 5,
        FOUR_INT_2143 = 6,
        FOUR_INT_3412 = 7,
        FOUR_INT_3421 = 8,
        FOUR_INT_4312 = 9,
        FOUR_INT_4321 = 10,
        FOUR_FLOAT_1234 = 11,
        FOUR_FLOAT_1243 = 12,
        FOUR_FLOAT_2134 = 13,
        FOUR_FLOAT_2143 = 14,
        FOUR_FLOAT_3412 = 15,
        FOUR_FLOAT_3421 = 16,
        FOUR_FLOAT_4312 = 17,
        FOUR_FLOAT_4321 = 18
    }
}
