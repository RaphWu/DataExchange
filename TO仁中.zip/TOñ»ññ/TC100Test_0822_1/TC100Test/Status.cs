﻿namespace TC100Test
{
    /// <summary>
    /// 讀取狀態。
    /// </summary>
    public class ReadStatus
    {
        /// <summary>
        /// 是否已更新？
        /// </summary>
        public bool Updated { get; set; }

        /// <summary>
        /// 動作狀態。
        /// </summary>
        public int ActionStatus { get; set; }

        /// <summary>
        /// 到位訊號目前的狀態。
        /// </summary>
        public int InpStatus { get; set; }

        /// <summary>
        /// 扭力極限狀態。
        /// </summary>
        public int TrqLmtStatus { get; set; }

        /// <summary>
        /// 警報狀態。
        /// </summary>
        public int AlarmStatus { get; set; }

        /// <summary>
        /// 馬達轉速。
        /// </summary>
        public int MonRpm { get; set; }

        /// <summary>
        /// 馬達轉速。
        /// </summary>
        public int MonSpeed { get; set; }

        /// <summary>
        /// 馬達電流值。
        /// </summary>
        public double MonCurrent { get; set; }

        /// <summary>
        /// 指令現在位置。
        /// </summary>
        public double CmdNowPos { get; set; }

        /// <summary>
        /// 編碼器位置。
        /// </summary>
        public double EcdPos { get; set; }

        /// <summary>
        /// 伺服狀態。
        /// </summary>
        public bool ServoStatus { get; set; }

        /// <summary>
        /// 故障狀態。
        /// </summary>
        public int ErrorStatus { get; set; }
    }

    /// <summary>
    /// 輸出設定。
    /// </summary>
    public class OutputSettings
    {
        /// <summary>
        /// 是否已更新？
        /// </summary>
        public bool Updated { get; set; }

        /// <summary>
        /// Inposition 到位訊號。
        /// </summary>
        public int InPosition { get; set; }

        /// <summary>
        /// 錯誤訊號。
        /// </summary>
        public int Alarm { get; set; }

        /// <summary>
        /// 準備完成，可執行下一點位。
        /// </summary>
        public int Ready { get; set; }

        /// <summary>
        /// 移動中。
        /// </summary>
        public int Move { get; set; }

        /// <summary>
        /// SERVO ON 狀態。
        /// </summary>
        public int ServoS { get; set; }

        /// <summary>
        /// 扭力極限。
        /// </summary>
        public int TrqLmt { get; set; }

        /// <summary>
        /// 區間設定範圍內輸出。
        /// </summary>
        public int InRange { get; set; }

        /// <summary>
        /// 當移動至目標位置的範圍內時輸出。
        /// </summary>
        public int Near { get; set; }

        /// <summary>
        /// 軟體極限輸出燈號。
        /// </summary>
        public int SoftLmt { get; set; }
    }
}
