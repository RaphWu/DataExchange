﻿namespace USB4704Test
{
    partial class MainForm
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_DO0 = new System.Windows.Forms.CheckBox();
            this.cb_DO1 = new System.Windows.Forms.CheckBox();
            this.cb_DO3 = new System.Windows.Forms.CheckBox();
            this.cb_DO2 = new System.Windows.Forms.CheckBox();
            this.cb_DO7 = new System.Windows.Forms.CheckBox();
            this.cb_DO6 = new System.Windows.Forms.CheckBox();
            this.cb_DO5 = new System.Windows.Forms.CheckBox();
            this.cb_DO4 = new System.Windows.Forms.CheckBox();
            this.cb_DI7 = new System.Windows.Forms.CheckBox();
            this.cb_DI6 = new System.Windows.Forms.CheckBox();
            this.cb_DI5 = new System.Windows.Forms.CheckBox();
            this.cb_DI4 = new System.Windows.Forms.CheckBox();
            this.cb_DI3 = new System.Windows.Forms.CheckBox();
            this.cb_DI2 = new System.Windows.Forms.CheckBox();
            this.cb_DI1 = new System.Windows.Forms.CheckBox();
            this.cb_DI0 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cb_DO0
            // 
            this.cb_DO0.AutoSize = true;
            this.cb_DO0.Location = new System.Drawing.Point(19, 34);
            this.cb_DO0.Name = "cb_DO0";
            this.cb_DO0.Size = new System.Drawing.Size(48, 17);
            this.cb_DO0.TabIndex = 0;
            this.cb_DO0.Text = "DO0";
            this.cb_DO0.UseVisualStyleBackColor = true;
            // 
            // cb_DO1
            // 
            this.cb_DO1.AutoSize = true;
            this.cb_DO1.Location = new System.Drawing.Point(19, 57);
            this.cb_DO1.Name = "cb_DO1";
            this.cb_DO1.Size = new System.Drawing.Size(48, 17);
            this.cb_DO1.TabIndex = 1;
            this.cb_DO1.Text = "DO1";
            this.cb_DO1.UseVisualStyleBackColor = true;
            // 
            // cb_DO3
            // 
            this.cb_DO3.AutoSize = true;
            this.cb_DO3.Location = new System.Drawing.Point(19, 103);
            this.cb_DO3.Name = "cb_DO3";
            this.cb_DO3.Size = new System.Drawing.Size(48, 17);
            this.cb_DO3.TabIndex = 3;
            this.cb_DO3.Text = "DO3";
            this.cb_DO3.UseVisualStyleBackColor = true;
            // 
            // cb_DO2
            // 
            this.cb_DO2.AutoSize = true;
            this.cb_DO2.Location = new System.Drawing.Point(19, 80);
            this.cb_DO2.Name = "cb_DO2";
            this.cb_DO2.Size = new System.Drawing.Size(48, 17);
            this.cb_DO2.TabIndex = 2;
            this.cb_DO2.Text = "DO2";
            this.cb_DO2.UseVisualStyleBackColor = true;
            // 
            // cb_DO7
            // 
            this.cb_DO7.AutoSize = true;
            this.cb_DO7.Location = new System.Drawing.Point(19, 195);
            this.cb_DO7.Name = "cb_DO7";
            this.cb_DO7.Size = new System.Drawing.Size(48, 17);
            this.cb_DO7.TabIndex = 7;
            this.cb_DO7.Text = "DO7";
            this.cb_DO7.UseVisualStyleBackColor = true;
            // 
            // cb_DO6
            // 
            this.cb_DO6.AutoSize = true;
            this.cb_DO6.Location = new System.Drawing.Point(19, 172);
            this.cb_DO6.Name = "cb_DO6";
            this.cb_DO6.Size = new System.Drawing.Size(48, 17);
            this.cb_DO6.TabIndex = 6;
            this.cb_DO6.Text = "DO6";
            this.cb_DO6.UseVisualStyleBackColor = true;
            // 
            // cb_DO5
            // 
            this.cb_DO5.AutoSize = true;
            this.cb_DO5.Location = new System.Drawing.Point(19, 149);
            this.cb_DO5.Name = "cb_DO5";
            this.cb_DO5.Size = new System.Drawing.Size(48, 17);
            this.cb_DO5.TabIndex = 5;
            this.cb_DO5.Text = "DO5";
            this.cb_DO5.UseVisualStyleBackColor = true;
            // 
            // cb_DO4
            // 
            this.cb_DO4.AutoSize = true;
            this.cb_DO4.Location = new System.Drawing.Point(19, 126);
            this.cb_DO4.Name = "cb_DO4";
            this.cb_DO4.Size = new System.Drawing.Size(48, 17);
            this.cb_DO4.TabIndex = 4;
            this.cb_DO4.Text = "DO4";
            this.cb_DO4.UseVisualStyleBackColor = true;
            // 
            // cb_DI7
            // 
            this.cb_DI7.AutoSize = true;
            this.cb_DI7.Enabled = false;
            this.cb_DI7.Location = new System.Drawing.Point(19, 195);
            this.cb_DI7.Name = "cb_DI7";
            this.cb_DI7.Size = new System.Drawing.Size(43, 17);
            this.cb_DI7.TabIndex = 15;
            this.cb_DI7.Text = "DI7";
            this.cb_DI7.UseVisualStyleBackColor = true;
            // 
            // cb_DI6
            // 
            this.cb_DI6.AutoSize = true;
            this.cb_DI6.Enabled = false;
            this.cb_DI6.Location = new System.Drawing.Point(19, 172);
            this.cb_DI6.Name = "cb_DI6";
            this.cb_DI6.Size = new System.Drawing.Size(43, 17);
            this.cb_DI6.TabIndex = 14;
            this.cb_DI6.Text = "DI6";
            this.cb_DI6.UseVisualStyleBackColor = true;
            // 
            // cb_DI5
            // 
            this.cb_DI5.AutoSize = true;
            this.cb_DI5.Enabled = false;
            this.cb_DI5.Location = new System.Drawing.Point(19, 149);
            this.cb_DI5.Name = "cb_DI5";
            this.cb_DI5.Size = new System.Drawing.Size(43, 17);
            this.cb_DI5.TabIndex = 13;
            this.cb_DI5.Text = "DI5";
            this.cb_DI5.UseVisualStyleBackColor = true;
            // 
            // cb_DI4
            // 
            this.cb_DI4.AutoSize = true;
            this.cb_DI4.Enabled = false;
            this.cb_DI4.Location = new System.Drawing.Point(19, 126);
            this.cb_DI4.Name = "cb_DI4";
            this.cb_DI4.Size = new System.Drawing.Size(43, 17);
            this.cb_DI4.TabIndex = 12;
            this.cb_DI4.Text = "DI4";
            this.cb_DI4.UseVisualStyleBackColor = true;
            // 
            // cb_DI3
            // 
            this.cb_DI3.AutoSize = true;
            this.cb_DI3.Enabled = false;
            this.cb_DI3.Location = new System.Drawing.Point(19, 103);
            this.cb_DI3.Name = "cb_DI3";
            this.cb_DI3.Size = new System.Drawing.Size(43, 17);
            this.cb_DI3.TabIndex = 11;
            this.cb_DI3.Text = "DI3";
            this.cb_DI3.UseVisualStyleBackColor = true;
            // 
            // cb_DI2
            // 
            this.cb_DI2.AutoSize = true;
            this.cb_DI2.Enabled = false;
            this.cb_DI2.Location = new System.Drawing.Point(19, 80);
            this.cb_DI2.Name = "cb_DI2";
            this.cb_DI2.Size = new System.Drawing.Size(43, 17);
            this.cb_DI2.TabIndex = 10;
            this.cb_DI2.Text = "DI2";
            this.cb_DI2.UseVisualStyleBackColor = true;
            // 
            // cb_DI1
            // 
            this.cb_DI1.AutoSize = true;
            this.cb_DI1.Enabled = false;
            this.cb_DI1.Location = new System.Drawing.Point(19, 57);
            this.cb_DI1.Name = "cb_DI1";
            this.cb_DI1.Size = new System.Drawing.Size(43, 17);
            this.cb_DI1.TabIndex = 9;
            this.cb_DI1.Text = "DI1";
            this.cb_DI1.UseVisualStyleBackColor = true;
            // 
            // cb_DI0
            // 
            this.cb_DI0.AutoSize = true;
            this.cb_DI0.Enabled = false;
            this.cb_DI0.Location = new System.Drawing.Point(19, 34);
            this.cb_DI0.Name = "cb_DI0";
            this.cb_DI0.Size = new System.Drawing.Size(43, 17);
            this.cb_DI0.TabIndex = 8;
            this.cb_DI0.Text = "DI0";
            this.cb_DI0.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cb_DO0);
            this.groupBox1.Controls.Add(this.cb_DO1);
            this.groupBox1.Controls.Add(this.cb_DO2);
            this.groupBox1.Controls.Add(this.cb_DO3);
            this.groupBox1.Controls.Add(this.cb_DO4);
            this.groupBox1.Controls.Add(this.cb_DO5);
            this.groupBox1.Controls.Add(this.cb_DO6);
            this.groupBox1.Controls.Add(this.cb_DO7);
            this.groupBox1.Location = new System.Drawing.Point(38, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(91, 235);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Digital Outputs";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cb_DI0);
            this.groupBox2.Controls.Add(this.cb_DI1);
            this.groupBox2.Controls.Add(this.cb_DI7);
            this.groupBox2.Controls.Add(this.cb_DI2);
            this.groupBox2.Controls.Add(this.cb_DI6);
            this.groupBox2.Controls.Add(this.cb_DI3);
            this.groupBox2.Controls.Add(this.cb_DI5);
            this.groupBox2.Controls.Add(this.cb_DI4);
            this.groupBox2.Location = new System.Drawing.Point(163, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(84, 235);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Digital Inputs";
            // 
            // btn_Stop
            // 
            this.btn_Stop.Enabled = false;
            this.btn_Stop.Location = new System.Drawing.Point(126, 287);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(121, 41);
            this.btn_Stop.TabIndex = 18;
            this.btn_Stop.Text = "Stop";
            this.btn_Stop.UseVisualStyleBackColor = true;
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 346);
            this.Controls.Add(this.btn_Stop);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox cb_DO0;
        private System.Windows.Forms.CheckBox cb_DO1;
        private System.Windows.Forms.CheckBox cb_DO3;
        private System.Windows.Forms.CheckBox cb_DO2;
        private System.Windows.Forms.CheckBox cb_DO7;
        private System.Windows.Forms.CheckBox cb_DO6;
        private System.Windows.Forms.CheckBox cb_DO5;
        private System.Windows.Forms.CheckBox cb_DO4;
        private System.Windows.Forms.CheckBox cb_DI7;
        private System.Windows.Forms.CheckBox cb_DI6;
        private System.Windows.Forms.CheckBox cb_DI5;
        private System.Windows.Forms.CheckBox cb_DI4;
        private System.Windows.Forms.CheckBox cb_DI3;
        private System.Windows.Forms.CheckBox cb_DI2;
        private System.Windows.Forms.CheckBox cb_DI1;
        private System.Windows.Forms.CheckBox cb_DI0;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_Stop;
    }
}

