﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TC100Test
{
    public partial class TC100Test : Form
    {
        private CancellationTokenSource _cts;
        private ToyoSingleCylinder.ToyoSingleCylinder _tsc;
        private Thread _screenUpdateThread = null;

        public TC100Test()
        {
            InitializeComponent();
        }

        private void TC100Test_Load(object sender, EventArgs e)
        {
            UpdateSerialPortParamsSelector();
        }

        private void button_UpdateSerialPortParams_Click(object sender, EventArgs e)
        {
            UpdateSerialPortParamsSelector();
        }

        private void button_Disconnct_Click(object sender, EventArgs e)
        {
            if (_cts != null)
            {
                _cts.Cancel();
                _cts.Dispose();
            }

            if (_screenUpdateThread != null)
            {
                _screenUpdateThread.Join();
                _screenUpdateThread = null;
            }

            if (_tsc != null)
                _tsc.ClosePort();

            textBox_ServoStatus.Text = "";
            textBox_MotorStatus.Text = "";
            textBox_InpStatus.Text = "";
            textBox_TrqLmtStatus.Text = "";
            textBox_MotorAlarm.Text = "";
            textBox_ErrorStatus.Text = "";
            textBox_MotorRPM.Text = "";
            textBox_MotorSpeed.Text = "";
            textBox_MotorCurrent.Text = "";
            textBox_MotorCommandPos.Text = "";
            textBox_MotorCurrentPos.Text = "";

            button_Connect.Enabled = true;
            groupBox_SerialPort.Enabled = true;
            button_Disconnct.Enabled = false;
            panel_Action.Enabled = false;
            panel_Test.Enabled = false;
        }

        private void button_Connect_Click(object sender, EventArgs e)
        {
            if (_cts != null)
            {
                //_cts.Cancel();
                _cts.Dispose();
            }
            _cts = new CancellationTokenSource();

            if (_tsc != null)
                _tsc = null;

            _tsc = new ToyoSingleCylinder.ToyoSingleCylinder(
                       byte.Parse(textBox_Station.Text),
                       (string)comboBox_COM.SelectedItem,
                       int.Parse(comboBox_BaudRate.Text),
                       (System.IO.Ports.Parity)comboBox_Parity.SelectedItem,
                       int.Parse(textBox_DataBits.Text),
                       (System.IO.Ports.StopBits)comboBox_StopBits.SelectedItem);

            _tsc.OpenPort();

            if (_screenUpdateThread == null || _screenUpdateThread.ThreadState == ThreadState.Stopped)
            {
                _screenUpdateThread = new Thread(ScreenUpdatePolling)
                {
                    Name = "ScreenUpdatePolling",
                    IsBackground = true
                };
                _screenUpdateThread.Start(_cts);
            }

            button_Connect.Enabled = false;
            groupBox_SerialPort.Enabled = false;
            button_Disconnct.Enabled = true;
            panel_Action.Enabled = true;
            panel_Test.Enabled = true;
        }

        /// <summary>
        /// 復歸。
        /// </summary>
        private async void button_OriginReturn_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                await _tsc.OriginReturn();
            }
        }

        private async void checkBox_RepeatTest_CheckedChanged(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                Random rnd = new Random(DateTime.Now.Millisecond);

                try
                {
                    await Task.Run(async () =>
                    {
                        while (checkBox_RepeatTest.Checked)
                        {
                            double pos = Math.Round((rnd.NextDouble() * (100.0 - 5.0)) + 5.0, 2);
                            int speed = rnd.Next(15, 60);

                            label_TestPos.InvokeIfRequired(() =>
                            {
                                label_TestPos.Text = string.Concat("位置: ", pos.ToString("N2"));
                                label_TestSpeed.Text = string.Concat("速度: ", speed.ToString(), "%");
                            });

                            await _tsc.AbsMove(pos, speed, 1);
                            await Task.Delay(150);
                        }
                    }, this._cts.Token);
                }
                catch (OperationCanceledException)
                {
                    checkBox_RepeatTest.InvokeIfRequired(() =>
                    {
                        checkBox_RepeatTest.Checked = false;
                    });
                }
                catch (Exception ex)
                {
                    _tsc.ClosePort();
                    Console.WriteLine(string.Concat("checkBox_RepeatTest_CheckedChanged Exception: ", ex.Message));
                }
            }
        }

        private async void checkBox_PortIn01_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                await _tsc.OriginReturn();
            }
        }

        private void checkBox_PortIn02_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                if (_tsc.PortOutStatus.PortOut04)
                    _tsc.ServoOn();
                else
                    _tsc.ServoOff();
            }
        }

        private void checkBox_PortIn03_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                _tsc.AlarmReset();
            }
        }

        private async void button_AbsMove_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                if (_tsc.CylinderStatus.EcdPos > 50.0)
                    await _tsc.AbsMove(10.0, 50, 1);
                else
                    await _tsc.AbsMove(100.0, 50, 1);
            }
        }

        private async void button_IncMoveP_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                await _tsc.IncMove(10.0, 30, 1);
            }
        }

        private async void button_IncMoveM_Click(object sender, EventArgs e)
        {
            if (_tsc != null && _tsc.Ready())
            {
                await _tsc.IncMove(-10.0, 30, 1);
            }
        }

        private void button_AlarmReset_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.AlarmReset();
            }
        }

        private void button_EmergencyStop_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.EmergencyStop();
                checkBox_RepeatTest.Checked = false;
            }
        }

        private void button_DeceleratesToStop_Click(object sender, EventArgs e)
        {
            if (_tsc != null)
            {
                _tsc.DeceleratesToStop();
                checkBox_RepeatTest.Checked = false;
            }
        }
    }
}
