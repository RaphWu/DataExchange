﻿using System.Text;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        private void HighPriorityRequest(CallerId callerId, byte station, byte functionCode, int data, int length)
        {
            if (_highPriorityQueue.Count < MAX_QUEUE_CAPACITY)
            {
                byte[] requestFrame = GetRequestFrame(station, functionCode, data, length);
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                _highPriorityQueue.Enqueue(frame);
            }
        }

        private void HighPriorityRequest(CallerId callerId, string requestFrame)
        {
            if (_highPriorityQueue.Count < MAX_QUEUE_CAPACITY)
            {
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = Encoding.ASCII.GetBytes(requestFrame);
                _highPriorityQueue.Enqueue(frame);
            }
        }

        private void SendRetryFrame(FrameStruct frame)
        {
            if (_retryQueue.Count < MAX_QUEUE_CAPACITY)
                _retryQueue.Enqueue(frame);
        }

        private void SendRequestFrame(CallerId callerId, byte station, byte functionCode, int data, int length)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                byte[] requestFrame = GetRequestFrame(station, functionCode, data, length);
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                _requestQueue.Enqueue(frame);
            }
        }

        private void SendRequestFrame(CallerId callerId, byte[] requestFrame)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                _requestQueue.Enqueue(frame);
            }
        }

        private void SendRequestFrame(CallerId callerId, string requestString, bool includeLRC = false)
        {
            if (_requestQueue.Count < MAX_QUEUE_CAPACITY && !_requestHolding)
            {
                byte[] requestFrame;
                if (includeLRC)
                {
                    requestFrame = Encoding.ASCII.GetBytes(string.Concat(requestString, "\r\n"));
                }
                else
                {
                    int lrc = AsciiLrc(requestString);
                    requestFrame = Encoding.ASCII.GetBytes(string.Concat(requestString, lrc.ToString("X2"), "\r\n"));
                }
                FrameStruct frame = new FrameStruct();
                frame.CallerId = callerId;
                frame.ByteArray = requestFrame;
                _requestQueue.Enqueue(frame);
            }
        }
    }
}
