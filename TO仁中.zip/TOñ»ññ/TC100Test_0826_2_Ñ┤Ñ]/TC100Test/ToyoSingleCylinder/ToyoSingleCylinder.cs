﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO.Ports;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        const int ONE_WORD = 4;
        const int TWO_WORD = 8;

        /// <summary>
        /// 限制 Queue 最大容量。
        /// </summary>
        const int MAX_QUEUE_CAPACITY = 100;

        private CancellationTokenSource _cts;
        private SerialPort _sp;

        private CylinderParams _cp;

        private CylinderStatus _statusCylinder = new CylinderStatus();
        private PortOutStatus _statusPortOut = new PortOutStatus();
        private PortInStatus _statusPortIn = new PortInStatus();
        private DebugMessage _debugMessage = new DebugMessage();

        private Queue<FrameStruct> _highPriorityQueue = new Queue<FrameStruct>(); // 最高優先權指令 Queue
        private Queue<FrameStruct> _retryQueue = new Queue<FrameStruct>(); // 指令重送 Queue
        private Queue<FrameStruct> _requestQueue = new Queue<FrameStruct>(); // 一般指令 Queue

        private Thread _portAccessThread = null; // 負責 SerialPort 存取的執行緒
        private bool _pollingFinished = true;
        private uint _watchdogCounter = 0; // 看門狗計數器
        private System.Timers.Timer _watchdog; // 看門狗計時器
        private System.Timers.Timer _statusReadingTimer; // 狀態讀取計時器

        /// <summary>
        /// 請求發送暫停。
        /// </summary>
        /// <remarks>當有指令發送失敗須重送時，此 Flag 會 ON。此時 HighPriorityQueue 仍不會停，但 RequestQueue 會停止發送。</remarks>
        private bool _requestHolding = false;

        #region ctor

        /// <summary>
        /// TOYO 電動缸 (單缸)。
        /// </summary>
        /// <param name="station">站號。</param>
        /// <param name="portName">Serial Port 名稱。</param>
        /// <param name="baudRate">BaudRate 鮑率。</param>
        /// <param name="parity">Parity 同位位元。</param>
        /// <param name="dataBits">DataBits 資料位元。</param>
        /// <param name="stopBits">StopBits 停止位元。</param>
        /// <param name="cts">CancellationTokenSource 物件。請參考 <see href="https://learn.microsoft.com/zh-tw/dotnet/api/system.threading.cancellationtokensource">CancellationTokenSource Class</see>。</param>
        public ToyoSingleCylinder(byte station,
                                  string portName,
                                  int baudRate,
                                  Parity parity,
                                  int dataBits,
                                  StopBits stopBits)
        {
            _cp = new CylinderParams()
            {
                Station = station,
                RetryTimes = 5,
            };

            _sp = new SerialPort()
            {
                PortName = portName,
                BaudRate = baudRate,
                DataBits = dataBits,
                StopBits = stopBits,
                Parity = parity,
                ReadTimeout = 500,
                WriteTimeout = 500,
            };
        }

        #endregion

        #region Serial Port Open/Close

        /// <summary>
        /// 關閉電動缸。
        /// </summary>
        public void ClosePort()
        {
            while (!_pollingFinished)
                Task.Delay(20).Wait();

            if (_cts != null)
            {
                _cts.Cancel();
                _cts.Dispose();
            }

            _requestQueue.Clear();
            _retryQueue.Clear();
            _highPriorityQueue.Clear();

            _statusReadingTimer.Stop();
            _statusReadingTimer.Elapsed -= StatusReadingProc;

            _watchdog.Stop();
            _watchdog.Elapsed -= WatchdogProc;

            if (_portAccessThread != null)
            {
                _portAccessThread.Join();
                _portAccessThread = null;
            }

            if (_sp.IsOpen)
                _sp.Close();

            Thread.Sleep(200);
        }

        /// <summary>
        /// 開啟電動缸。
        /// </summary>
        public void OpenPort()
        {
            if (!_sp.IsOpen)
            {
                try
                {
                    if (_cts != null)
                        _cts.Dispose();
                    _cts = new CancellationTokenSource();

                    _sp.Open();
                    if (_sp.IsOpen)
                    {
                        if (_portAccessThread == null || _portAccessThread.ThreadState == ThreadState.Stopped)
                        {
                            _portAccessThread = new Thread(PortAccessPolling)
                            {
                                Name = "PortAccessPolling",
                                IsBackground = true
                            };
                            _portAccessThread.Start(_cts);
                        }

                        HighPriorityRequest(CallerId.Initializer, ":0110999B0004084C7630315479566702\r\n"); // 權限開通請求

                        _watchdog = new System.Timers.Timer()
                        {
                            Interval = 1000,
                            AutoReset = true,
                        };
                        _watchdog.Elapsed += WatchdogProc;
                        _watchdog.Start();

                        _statusReadingTimer = new System.Timers.Timer()
                        {
                            Interval = 233,
                            AutoReset = true,
                        };
                        _statusReadingTimer.Elapsed += StatusReadingProc;
                        _statusReadingTimer.Start();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(String.Concat("Failed to open serial port: ", ex.Message));
                }
            }
        }

        #endregion

    }
}
