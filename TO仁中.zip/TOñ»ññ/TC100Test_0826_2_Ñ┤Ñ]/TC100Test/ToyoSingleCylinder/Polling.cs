﻿using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        private async void PortAccessPolling(object param)
        {
            CancellationTokenSource cts = (param as CancellationTokenSource);
            CancellationToken token = cts.Token;

            bool requestFinished = true;
            FrameStruct nextRequest = new FrameStruct();
            int retryCounter = 0;

            try
            {
                while (true)
                {
                    if (token.IsCancellationRequested)
                        token.ThrowIfCancellationRequested();

                    _pollingFinished = false;

                    if (requestFinished)
                    {
                        if (_highPriorityQueue.Count > 0 || _retryQueue.Count > 0 || _requestQueue.Count > 0)
                        {
                            nextRequest = (_highPriorityQueue.Count > 0)
                                ? _highPriorityQueue.Dequeue()
                                : (_retryQueue.Count > 0)
                                    ? _retryQueue.Dequeue()
                                    : _requestQueue.Dequeue();

                            await Task.Delay(10, token);
                            //Thread.Sleep(10);
                            //_sps.DiscardInBuffer();
                            _sp.DiscardOutBuffer();
                            _sp.Write(nextRequest.ByteArray, 0, nextRequest.ByteArray.Length);

                            _debugMessage.RequestFrame = Encoding.ASCII.GetString(nextRequest.ByteArray);
                            _debugMessage.Updated = true;

                            requestFinished = false;
                        }
                    }

                    if (!requestFinished && _sp.BytesToRead > 0)
                    {
                        byte st = 0;
                        byte fCode = 0xFF;

                        //Task.Delay(300).Wait();
                        //byte[] readBuffer = new byte[_bytesToRead];
                        string responseString = _sp.ReadLine();
                        int bytesToRead = _sp.BytesToRead;

                        _debugMessage.ResponseFrame = responseString;
                        _debugMessage.Updated = true;

                        bool validation = ValidFrame(responseString);
                        if (validation)
                        {
                            //ShowConsoleMessage("Response訊息OK.");
                            st = Convert.ToByte(responseString.Substring(1, 2), 16);
                            fCode = Convert.ToByte(responseString.Substring(3, 2), 16);
                        }

                        if (validation && fCode < 0x80)
                        {
                            if (!_requestHolding)
                                retryCounter = 0;

                            switch (nextRequest.CallerId)
                            {
                                case CallerId.ReadStatus:
                                    const int head = 7;
                                    _statusCylinder.ServoStatus = Convert.ToBoolean(Convert.ToInt16(responseString.Substring(head + 0xC * ONE_WORD, ONE_WORD)));
                                    _statusCylinder.ActionStatus = Convert.ToInt16(responseString.Substring(head + 0x0 * ONE_WORD, ONE_WORD), 16);
                                    _statusCylinder.InpStatus = Convert.ToInt16(responseString.Substring(head + 0x01 * ONE_WORD, ONE_WORD), 16);
                                    _statusCylinder.TrqLmtStatus = Convert.ToInt16(responseString.Substring(head + 0x4 * ONE_WORD, ONE_WORD), 16);
                                    _statusCylinder.AlarmStatus = Convert.ToInt16(responseString.Substring(head + 0x5 * ONE_WORD, ONE_WORD), 16);
                                    _statusCylinder.ErrorStatus = Convert.ToInt16(responseString.Substring(head + 0xD * ONE_WORD, ONE_WORD), 16);
                                    _statusCylinder.MonRpm = Convert.ToInt16(responseString.Substring(head + 0x3 * ONE_WORD, ONE_WORD), 16);
                                    _statusCylinder.MonSpeed = Convert.ToInt16(responseString.Substring(head + 0x6 * ONE_WORD, ONE_WORD), 16);
                                    _statusCylinder.MonCurrent = Convert.ToInt16(responseString.Substring(head + 0x7 * ONE_WORD, ONE_WORD), 16) / 10.0;
                                    _statusCylinder.CmdNowPos = Convert.ToInt32(responseString.Substring(head + 0x8 * ONE_WORD, TWO_WORD), 16) / 100.0;
                                    _statusCylinder.EcdPos = Convert.ToInt32(responseString.Substring(head + 0xA * ONE_WORD, TWO_WORD), 16) / 100.0;
                                    _statusCylinder.Updated = true;

                                    requestFinished = true;
                                    break;
                                case CallerId.PortOut:
                                    ushort portOut = Convert.ToUInt16(responseString.Substring(1 + 2 + 2 + 2, 4), 16);
                                    _statusPortOut.PortOut01 = (portOut & 0x0001) != 0;
                                    _statusPortOut.PortOut02 = (portOut & 0x0002) != 0;
                                    _statusPortOut.PortOut03 = (portOut & 0x0004) != 0;
                                    _statusPortOut.PortOut04 = (portOut & 0x0008) != 0;
                                    _statusPortOut.PortOut05 = (portOut & 0x0010) != 0;
                                    _statusPortOut.PortOut06 = (portOut & 0x0020) != 0;
                                    _statusPortOut.PortOut07 = (portOut & 0x0040) != 0;
                                    _statusPortOut.PortOut08 = (portOut & 0x0080) != 0;
                                    _statusPortOut.PortOut09 = (portOut & 0x0100) != 0;
                                    _statusPortOut.PortOut10 = (portOut & 0x0200) != 0;
                                    _statusPortOut.Updated = true;

                                    requestFinished = true;
                                    break;
                                case CallerId.PortIn:
                                    ushort data = Convert.ToUInt16(responseString.Substring(1 + 2 + 2 + 2, 4), 16);
                                    _statusPortIn.PortIn01 = (data & 0x0001) != 0;
                                    _statusPortIn.PortIn02 = (data & 0x0002) != 0;
                                    _statusPortIn.PortIn03 = (data & 0x0004) != 0;
                                    _statusPortIn.PortIn04 = (data & 0x0008) != 0;
                                    _statusPortIn.PortIn05 = (data & 0x0010) != 0;
                                    _statusPortIn.PortIn06 = (data & 0x0020) != 0;
                                    _statusPortIn.PortIn07 = (data & 0x0040) != 0;
                                    _statusPortIn.PortIn08 = (data & 0x0080) != 0;
                                    _statusPortIn.PortIn09 = (data & 0x0100) != 0;
                                    _statusPortIn.PortIn10 = (data & 0x0200) != 0;
                                    _statusPortIn.PortIn11 = (data & 0x0400) != 0;
                                    _statusPortIn.PortIn12 = (data & 0x0800) != 0;
                                    _statusPortIn.PortIn13 = (data & 0x1000) != 0;
                                    _statusPortIn.PortIn14 = (data & 0x2000) != 0;

                                    requestFinished = true;
                                    break;
                                case CallerId.Command:
                                    requestFinished = true;
                                    break;
                                case CallerId.WatchDog:
                                    if (responseString == ":010302544363\r")
                                    {
                                        requestFinished = true;
                                    }
                                    else
                                    {
                                        ClosePort();
                                        throw new Exception("電動缸斷線！");
                                    }
                                    break;
                                case CallerId.Initializer:
                                    if (responseString == ":0110999B0004B7\r")
                                    {
                                        requestFinished = true;
                                    }
                                    else
                                    {
                                        ClosePort();
                                        throw new Exception("權限開通異常！");
                                    }
                                    break;
                                default:
                                    throw new Exception(string.Concat("CallerId錯誤:\n", nextRequest.CallerId, "\nResponse Message: ", responseString));
                            }

                            _requestHolding = false;
                        }
                        else
                        {
                            string msg = string.Concat("CallerID: ", nextRequest.CallerId,
                                                       ", Frame: ", Encoding.ASCII.GetString(nextRequest.ByteArray));
                            if (++retryCounter <= _cp.RetryTimes)
                            {
                                _requestHolding = true;
                                _debugMessage.ConsoleMessage = string.Concat("重試第 ", retryCounter, " 次, ", msg);
                                _debugMessage.Updated = true;
                                Console.WriteLine(_debugMessage.ConsoleMessage);

                                Thread.Sleep(500);
                                SendRetryFrame(nextRequest);
                            }
                            else
                            {
                                _debugMessage.ErrorMessage = string.Concat("此指令已被放棄: ", msg);
                                _debugMessage.Updated = true;
                                Console.WriteLine(_debugMessage.ErrorMessage);

                                retryCounter = 0;
                            }
                            requestFinished = true;
                        }
                    }

                    //if (_commStatus == CommStatus.ERROR)
                    //    throw new Exception(string.Concat("未知錯誤:\n", _lastCommStatus, " / ", _commStatus, "\nFunctionCode: ", fCode, "\nResponse Message: ", _responseString));
                    _pollingFinished = true;
                }
            }
            catch (TimeoutException te)
            {
                Console.WriteLine(te.Message);
                requestFinished = false;
            }
            catch (OperationCanceledException)
            {
                // do nothing for Cancellation
            }
            catch (UnauthorizedAccessException)
            {
                ClosePort();
                requestFinished = true;
            }
            catch (Exception ex)
            {
                _debugMessage.ErrorMessage = string.Concat("接收輪詢的執行緒異常: ", ex.Message);
                _debugMessage.Updated = true;
                Console.WriteLine(_debugMessage.ErrorMessage);
            }
            //finally
            //{
            //    _requestHolding = false;
            //}
        }

        private void WatchdogProc(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (_sp.IsOpen)
            {
                foreach (var rq in _highPriorityQueue)
                    if (rq.CallerId == CallerId.WatchDog)
                        return;
                HighPriorityRequest(CallerId.WatchDog, 01, 0x03, 0x10E0, 1);
                _watchdogCounter++;
            }
        }

        private static byte _statusReadingLoop = 0;

        private void StatusReadingProc(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (_sp.IsOpen && !_requestHolding)
            {
                switch (_statusReadingLoop)
                {
                    case 0:
                        foreach (var rq in _requestQueue)
                            if (rq.CallerId == CallerId.ReadStatus)
                                break;
                        SendRequestFrame(CallerId.ReadStatus, 01, 0x03, 0x1000, 0x0F * 1);
                        break;
                    case 1:
                        foreach (var rq in _requestQueue)
                            if (rq.CallerId == CallerId.PortOut)
                                break;
                        SendRequestFrame(CallerId.PortOut, 01, 0x03, 0x1020, 1);
                        break;
                    case 2:
                        foreach (var rq in _requestQueue)
                            if (rq.CallerId == CallerId.PortIn)
                                break;
                        SendRequestFrame(CallerId.PortIn, 01, 0x03, 0x1040, 1);
                        break;
                }

                if (++_statusReadingLoop > 2)
                    _statusReadingLoop = 0;
            }
        }
    }
}
