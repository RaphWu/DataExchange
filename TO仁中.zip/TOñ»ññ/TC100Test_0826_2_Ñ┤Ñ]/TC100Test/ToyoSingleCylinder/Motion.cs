﻿using System;
using System.Threading.Tasks;

namespace ToyoSingleCylinder
{
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 判斷運動是否已達指定位置。
        /// </summary>
        /// <param name="position">卻比對的座標。</param>
        /// <returns>是否已達指定位置。</returns>
        private bool InPosition(double position)
        {
            return _statusCylinder.ActionStatus == 0
                    && _statusCylinder.InpStatus == 1
                    && Math.Abs(_statusCylinder.CmdNowPos - position) <= 0.01
                    && Math.Abs(_statusCylinder.EcdPos - position) <= 0.01;
        }

        /// <summary>
        /// 原點復歸。
        /// </summary>
        public async Task OriginReturn()
        {
            SendRequestFrame(CallerId.Command, GetRequestFrame(_cp.Station, 0x06, 0x201E, 3));

            while (!InPosition(0.0))
                await Task.Delay(50, _cts.Token);
        }

        /// <summary>
        /// 緊急停止。
        /// </summary>
        public void EmergencyStop()
        {
            SendRequestFrame(CallerId.Command, GetRequestFrame(_cp.Station, 0x06, 0x201E, 9));
        }

        /// <summary>
        /// 減速停止。
        /// </summary>
        public void DeceleratesToStop()
        {
            SendRequestFrame(CallerId.Command, GetRequestFrame(_cp.Station, 0x06, 0x201E, 8));
        }

        /// <summary>
        /// ABS 絕對位置運動。
        /// </summary>
        /// <param name="coordinate">絕對座標值，單位 mm。</param>
        /// <param name="speed">運動速度，0~100，為最高速度的比例設定值。</param>
        /// <param name="push">推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        public async Task AbsMove(double coordinate, int speed, double push)
        {
            string cmd = string.Concat(":01062014", speed.ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);

            cmd = string.Concat(":01060400", ((int)(push * 10)).ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);

            cmd = string.Concat(":01060401", ((int)(push * 10)).ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);

            cmd = string.Concat(":01102002000204", ((int)(coordinate * 100)).ToString("X8"));
            SendRequestFrame(CallerId.Command, cmd);

            SendRequestFrame(CallerId.Command, ":0106201E0001");

            while (!InPosition(coordinate))
                await Task.Delay(50, _cts.Token);
            //await Task.CompletedTask;
        }

        /// <summary>
        /// INC 相對位置運動。
        /// </summary>
        /// <param name="offset">相對位移量，單位 mm。</param>
        /// <param name="speed">運動速度，0~100，為最高速度的比例設定值。</param>
        /// <param name="push">推壓，0~1000，為扭力值的比例設定值 x 0.1%。</param>
        public async Task IncMove(double offset, int speed, double push)
        {
            string cmd = string.Concat(":01062014", speed.ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);

            cmd = string.Concat(":01060400", ((int)(push * 10)).ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);

            cmd = string.Concat(":01060401", ((int)(push * 10)).ToString("X4"));
            SendRequestFrame(CallerId.Command, cmd);

            double targetPos = _statusCylinder.CmdNowPos + offset;
            cmd = string.Concat(":01102000000204", ((int)(offset * 100)).ToString("X8"));
            SendRequestFrame(CallerId.Command, cmd);

            SendRequestFrame(CallerId.Command, ":0106201E0000");

            while (!InPosition(targetPos))
                await Task.Delay(50, _cts.Token);
            //await Task.CompletedTask;
        }
    }
}
