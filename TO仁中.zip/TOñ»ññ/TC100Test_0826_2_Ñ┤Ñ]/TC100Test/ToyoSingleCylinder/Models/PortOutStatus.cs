﻿namespace ToyoSingleCylinder
{
    /// <summary>
    /// 輸出訊號。
    /// </summary>
    public class PortOutStatus
    {
        /// <summary>
        /// 是否已更新？
        /// </summary>
        public bool Updated { get; set; }

        /// <summary>
        /// 輸出訊號 01。
        /// </summary>
        /// <remarks>ORG-S。</remarks>
        public bool PortOut01 { get; set; }

        /// <summary>
        /// 輸出訊號 02。
        /// </summary>
        /// <remarks>INPOSITION。</remarks>
        public bool PortOut02 { get; set; }

        /// <summary>
        /// 輸出訊號 03。
        /// </summary>
        /// <remarks>READY。</remarks>
        public bool PortOut03 { get; set; }

        /// <summary>
        /// 輸出訊號 04。
        /// </summary>
        /// <remarks>SERVO-S。</remarks>
        public bool PortOut04 { get; set; }

        /// <summary>
        /// 輸出訊號 05。
        /// </summary>
        /// <remarks>PRGSEL0-S。</remarks>
        public bool PortOut05 { get; set; }

        /// <summary>
        /// 輸出訊號 06。
        /// </summary>
        /// <remarks>PRGSEL1-S。</remarks>
        public bool PortOut06 { get; set; }

        /// <summary>
        /// 輸出訊號 07。
        /// </summary>
        /// <remarks>ALARM。</remarks>
        public bool PortOut07 { get; set; }

        /// <summary>
        /// 輸出訊號 08。
        /// </summary>
        /// <remarks>MOVE。</remarks>
        public bool PortOut08 { get; set; }

        /// <summary>
        /// 輸出訊號 09。
        /// </summary>
        /// <remarks>OUT9。</remarks>
        public bool PortOut09 { get; set; }

        /// <summary>
        /// 輸出訊號 10。
        /// </summary>
        /// <remarks>OUT10。</remarks>
        public bool PortOut10 { get; set; }
    }
}