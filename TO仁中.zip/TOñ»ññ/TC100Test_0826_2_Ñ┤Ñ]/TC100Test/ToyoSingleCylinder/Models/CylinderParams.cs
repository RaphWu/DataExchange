﻿namespace ToyoSingleCylinder
{
    /// <summary>
    /// 電動缸參數。
    /// </summary>
    internal class CylinderParams
    {
        /// <summary>
        /// 站號。
        /// </summary>
        internal byte Station { get; set; }

        /// <summary>
        /// 訊息幀傳送錯誤時的重傳次數。
        /// </summary>
        internal int RetryTimes { get; set; }
    }
}
