﻿namespace ToyoSingleCylinder
{
    /// <summary>
    /// 輸入訊號。
    /// </summary>
    public class PortInStatus
    {
        /// <summary>
        /// 是否已更新？
        /// </summary>
        public bool Updated { get; set; }

        /// <summary>
        /// 輸入訊號 01。
        /// </summary>
        /// <remarks>ORG。</remarks>
        public bool PortIn01 { get; set; }

        /// <summary>
        /// 輸入訊號 02。
        /// </summary>
        /// <remarks>SERVO ON/OFF。</remarks>
        public bool PortIn02 { get; set; }

        /// <summary>
        /// 輸入訊號 03。
        /// </summary>
        /// <remarks>ALR_RESET。</remarks>
        public bool PortIn03 { get; set; }

        /// <summary>
        /// 輸入訊號 04。
        /// </summary>
        /// <remarks>START。</remarks>
        public bool PortIn04 { get; set; }

        /// <summary>
        /// 輸入訊號 05。
        /// </summary>
        /// <remarks>PRGSEL0。</remarks>
        public bool PortIn05 { get; set; }

        /// <summary>
        /// 輸入訊號 06。
        /// </summary>
        /// <remarks>PRGSEL1。</remarks>
        public bool PortIn06 { get; set; }

        /// <summary>
        /// 輸入訊號 07。
        /// </summary>
        /// <remarks>PRGSEL2。</remarks>
        public bool PortIn07 { get; set; }

        /// <summary>
        /// 輸入訊號 08。
        /// </summary>
        /// <remarks>PRGSEL3。</remarks>
        public bool PortIn08 { get; set; }

        /// <summary>
        /// 輸入訊號 09。
        /// </summary>
        /// <remarks>LOCK。</remarks>
        public bool PortIn09 { get; set; }

        /// <summary>
        /// 輸入訊號 10。
        /// </summary>
        /// <remarks>MANUAL。</remarks>
        public bool PortIn10 { get; set; }

        /// <summary>
        /// 輸入訊號 11。
        /// </summary>
        /// <remarks>IN11。</remarks>
        public bool PortIn11 { get; set; }

        /// <summary>
        /// 輸入訊號 12。
        /// </summary>
        /// <remarks>IN12。</remarks>
        public bool PortIn12 { get; set; }

        /// <summary>
        /// 輸入訊號 13。
        /// </summary>
        /// <remarks>IN13。</remarks>
        public bool PortIn13 { get; set; }

        /// <summary>
        /// 輸入訊號 14。
        /// </summary>
        /// <remarks>IN14。</remarks>
        public bool PortIn14 { get; set; }
    }
}
