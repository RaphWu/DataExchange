﻿namespace ToyoSingleCylinder
{
    /********************
     * DEBUG用訊息存放區。
     ********************/
    public class DebugMessage
    {
        public bool Updated { get; set; }
        public string RequestFrame { get; set; }
        public string ResponseFrame { get; set; }
        public string ConsoleMessage { get; set; }
        public string ErrorMessage { get; set; }
    }
}
