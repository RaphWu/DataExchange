﻿using System.ComponentModel;

namespace ToyoSingleCylinder
{
    /// <summary>
    /// 讀取狀態。
    /// </summary>
    public class CylinderStatus
    {
        /// <summary>
        /// 是否已更新？
        /// </summary>
        public bool Updated { get; set; }

        /// <summary>
        /// 伺服狀態 ON/FF。
        /// </summary>
        [Description("伺服狀態")]
        public bool ServoStatus { get; set; }

        /// <summary>
        /// 動作狀態。
        /// </summary>
        [Description("動作狀態")]
        public int ActionStatus { get; set; }

        /// <summary>
        /// 到位訊號目前的狀態。
        /// </summary>
        [Description("到位訊號目前的狀態")]
        public int InpStatus { get; set; }

        /// <summary>
        /// 扭力極限狀態。
        /// </summary>
        [Description("扭力極限狀態")]
        public int TrqLmtStatus { get; set; }

        /// <summary>
        /// 故障狀態。
        /// </summary>
        [Description("故障狀態")]
        public int ErrorStatus { get; set; }

        /// <summary>
        /// 警報狀態。
        /// </summary>
        [Description("警報狀態")]
        public int AlarmStatus { get; set; }

        /// <summary>
        /// 馬達轉速。
        /// </summary>
        [Description("馬達轉速")]
        public int MonRpm { get; set; }

        /// <summary>
        /// 馬達轉速。
        /// </summary>
        [Description("馬達轉速")]
        public int MonSpeed { get; set; }

        /// <summary>
        /// 馬達電流值。
        /// </summary>
        [Description("馬達電流值")]
        public double MonCurrent { get; set; }

        /// <summary>
        /// 指令現在位置。
        /// </summary>
        [Description("指令現在位置")]
        public double CmdNowPos { get; set; }

        /// <summary>
        /// 編碼器位置。
        /// </summary>
        [Description("編碼器位置")]
        public double EcdPos { get; set; }
    }
}
