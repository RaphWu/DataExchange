﻿namespace ToyoSingleCylinder
{
    public enum CallerId
    {
        Initializer,
        WatchDog,
        Command,
        ReadStatus,
        PortOut,
        PortIn,
    }
}
