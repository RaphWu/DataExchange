﻿using System;

namespace CALIN.Data.Verify
{
    public static class LRC
    {
        /// <summary>
        /// 計算LRC值。
        /// </summary>
        /// <param name="data">要計算的byte陣列。</param>
        /// <returns>LRC值</returns>
        public static byte Lrc(byte[] data)
        {
            byte lrc = 0;
            for (int i = 0; i < data.Length; i++)
                lrc += data[i];
            return (byte)((lrc ^ 0xFF) + 1);
        }

        /// <summary>
        /// 計算字串的LRC值。
        /// </summary>
        /// <param name="data">要計算的字串。</param>
        /// <returns>LRC值</returns>
        /// <remarks>用於 Modbus ASCII 模式的字串報文LRC計算。</remarks>
        public static byte LrcByAscii(string data)
        {
            byte lrc = 0;
            if (data.Substring(0, 1) == ":")
                data = data.Substring(1);
            int totalLen = data.Length / 2;

            for (int i = 0; i < totalLen; i++)
            {
                int t = Convert.ToInt16(data.Substring(i * 2, 2), 16);
                //int t = (data[i] > '9') ? data[i] - 'A' + 10 : data[i] - '0';
                //if (i < 4 && i % 2 == 0)
                //    t <<= 4;

                lrc += (byte)t;
            }

            return (byte)((lrc ^ 0xFF) + 1);
        }
    }
}
