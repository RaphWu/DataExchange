﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CALIN.Core
{
    public static class Extension
    {

    }
}
