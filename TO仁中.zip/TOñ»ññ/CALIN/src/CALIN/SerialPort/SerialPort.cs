﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;

namespace CALIN.SerialPort
{
    /// <summary>
    /// SerialPort實例化。
    /// </summary>
    public class SerialPort : ISerialPort
    {
        private static readonly object _lockObject = new object();
        private static System.IO.Ports.SerialPort c_sp { get; set; }
        private readonly SerialPortParameters _spp = SerialPortParameters.Instance;

        /*************************
         * Serial Port Pin State
         *************************/
        //private static bool _cdHolding;
        //private static bool _ctsHolding;
        //private static bool _dsrHolding;

        /********************
         * ctor
         ********************/
        public SerialPort()
        {
        }

        public SerialPort(string portName, int baudRate, Parity parity, int dataBits, StopBits stopBits)
        {
            _spp.PortName = portName;
            _spp.BaudRate = baudRate;
            _spp.Parity = parity;
            _spp.DataBits = dataBits;
            _spp.StopBits = stopBits;
        }

        /********************
         * 內部參數
         ********************/
        /// <inheritdoc/>
        public bool IsOpen => c_sp != null && c_sp.IsOpen;

        /// <inheritdoc/>
        public List<string> PortNameList
        {
            get
            {
                _spp.PortNameList = System.IO.Ports.SerialPort.GetPortNames().ToList();
                _spp.PortNameList.Sort();
                return _spp.PortNameList;
            }
        }

        /********************
         * Port開啟與關閉。
         ********************/
        /// <inheritdoc/>
        public void Close()
        {
            if (IsOpen)
            {
                c_sp.DataReceived -= SerialPort_DataReceived;
                c_sp.ErrorReceived -= SerialPort_ErrorReceived;
                c_sp.PinChanged -= SerialPort_PinChanged;
                c_sp.Close();
            }
        }

        /// <inheritdoc/>
        public void Open()
        {
            // Port Close
            if (IsOpen)
            {
                c_sp.DataReceived -= SerialPort_DataReceived;
                c_sp.ErrorReceived -= SerialPort_ErrorReceived;
                c_sp.PinChanged -= SerialPort_PinChanged;
                c_sp.Close();
            }

            try
            {
                c_sp = new System.IO.Ports.SerialPort(_spp.PortName,
                                                      _spp.BaudRate,
                                                      _spp.Parity,
                                                      _spp.DataBits,
                                                      _spp.StopBits)
                {
                    Handshake = _spp.Handshake,
                    ReadTimeout = _spp.ReadTimeout,
                    WriteTimeout = _spp.WriteTimeout
                };
                c_sp.Open();

                if (IsOpen)
                {
                    Console.WriteLine($"已開啟 {_spp.PortName}");

                    c_sp.DataReceived += SerialPort_DataReceived;
                    c_sp.ErrorReceived += SerialPort_ErrorReceived;
                    c_sp.PinChanged += SerialPort_PinChanged;
                }
                else
                {
                    Console.WriteLine($"{_spp.PortName} 開啟失敗！");
                }
            }
            catch (TimeoutException te)
            {
                Console.WriteLine($"{_spp.PortName} 開啟逾時: {te.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{_spp.PortName} 開啟異常: {ex.Message}");
            }
        }

        /// <summary>
        /// 接收資料事件。
        /// </summary>
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (!IsOpen)
            {
                _spp.BytesToReceived = 0;
                return;
            }

            var sps = sender as System.IO.Ports.SerialPort;
            _spp.BytesToReceived = sps.Read(_spp.ReceivedMessages, 0, sps.BytesToRead);
            return;
        }

        /// <summary>
        /// 錯誤發生處理事件。
        /// </summary>
        private void SerialPort_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {
            //Task.Delay(10);
        }

        /// <summary>
        /// 序列通訊埠上控制引腳狀態變更的事件。
        /// </summary>
        private void SerialPort_PinChanged(object sender, SerialPinChangedEventArgs e)
        {
            // UpdatePinState();
        }

        //private void UpdatePinState()
        //{
        //    _ = Task.Run(() =>
        //    {
        //        _ctsHolding = _serialPort.CtsHolding;
        //        _dsrHolding = _serialPort.DsrHolding;
        //        _cdHolding = _serialPort.CDHolding;
        //    });
        //}

        /********************
         * Functions
         ********************/
        /// <inheritdoc/>
        public bool SendData(string data)
        {
            if (c_sp != null && c_sp.IsOpen)
            {
                lock (_lockObject)
                {
                    try
                    {
                        if (data == null || data.Length == 0)
                            throw new ArgumentException("傳送的資料不能為空或null。");

                        c_sp.Write(data);
                    }
                    catch (TimeoutException te)
                    {
                        throw new Exception($"傳送逾時: {te.Message}");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception($"傳送異常: {ex.Message}");
                    }
                }
                return true;
            }
            return false;
        }

        /// <inheritdoc/>
        public bool SendData(byte[] data)
        {
            if (c_sp != null && c_sp.IsOpen)
            {
                lock (_lockObject)
                {
                    try
                    {
                        if (data == null || data.Length == 0)
                            throw new ArgumentException("傳送的資料不能為空或null。");

                        c_sp.Write(data, 0, data.Length);
                    }
                    catch (TimeoutException te)
                    {
                        throw new Exception($"傳送逾時: {te.Message}");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception($"傳送異常: {ex.Message}");
                    }
                }
                return true;
            }
            return false;
        }
    }
}
