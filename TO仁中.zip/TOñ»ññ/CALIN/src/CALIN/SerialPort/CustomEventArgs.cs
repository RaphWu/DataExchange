﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CALIN.SerialPort
{
    public  class CustomEventArgs: EventArgs
    {

    }
}
