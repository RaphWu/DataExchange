﻿using System;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 軸狀態旗標列舉。
    /// </summary>
    public enum AxisStateFlags : ushort
    {
        STA_AX_DISABLE = 0,
        STA_AX_READY = 1,
        STA_AX_STOPPING = 2,
        STA_AX_ERROR_STOP = 3,
        STA_AX_HOMING = 4,
        STA_AX_PTP_MOTION = 5,
        STA_AX_CONTI_MOTION = 6,
        STA_AX_SYNC_MOTION = 7,
        STA_AX_EXT_JOG = 8,
        STA_AX_EXT_MPG = 9,
        STA_AX_PAUSE = 10,
        STA_AX_BUSY = 11,
        STA_AX_WAIT_DI = 12,
        STA_AX_WAIT_PTP = 13,
        STA_AX_WAIT_VEL = 14,
        STA_AX_EXT_JOG_READY = 15,
    }
}
