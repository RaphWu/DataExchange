﻿using System;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 軸的運動 I/O 旗標列舉。
    /// </summary>
    [Flags]
    public enum AxisIoFlags : uint
    {
        RDY = 1 << 0,
        ALM = 1 << 1,
        LMT_Positive = 1 << 2,
        LMT_Negative = 1 << 3,
        ORG = 1 << 4,
        DIR = 1 << 5,
        EMG = 1 << 6,
        EZ = 1 << 9,
        LTC = 1 << 11,
        INP = 1 << 13,
        SVON = 1 << 14,
        ALRM = 1 << 15,
        SLMT_Positive = 1 << 16,
        SLMT_Negative = 1 << 17,
    }
}
