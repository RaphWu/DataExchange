﻿using System;
using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Services
{
    // 軸操作
    public partial class AcmService : IAcmService_Axis
    {
        #region Fields

        private RawAxisState[] _rawAxisStates = new RawAxisState[2]; // 軸原始狀態 Snapshot buffer

        private ParsedAxisState[] _parsedAxisStates = new ParsedAxisState[2]; // 軸解析後狀態

        #endregion Fields

        #region Properties

        public uint AxisCount => _axisCount;
        public ParsedAxisState[] AxisStates => _parsedAxisStates;

        #endregion Properties

        #region Methods

        /// <inheritdoc/>
        public bool AxisStop(int axisNo)
        {
            ErrCode = Motion.mAcm_AxStopDec(_axisHandles[axisNo]);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisStop)}", $"軸 {axisNo + 1} 減速停止錯誤！");
        }

        /// <inheritdoc/>
        public bool AxisStopEmg(int axisNo)
        {
            ErrCode = Motion.mAcm_AxStopEmg(_axisHandles[axisNo]);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisStop)}", $"軸 {axisNo + 1} 緊急停止錯誤！");
        }

        /// <inheritdoc/>
        public bool AxisHome(int axisNo, uint homeMode, uint direction, uint switchMode, double crossDistance)
        {
            // stopping condition
            ErrCode = Motion.mAcm_SetU32Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxHomeExSwitchMode, switchMode);
            if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisHome)}", $"軸 {axisNo + 1} 屬性 PAR_AxHomeExSwitchMode 設定失敗：{switchMode}！"))
                return false;

            // home cross distance (Unit: PPU). 須大於 0. 預設值 10000
            ErrCode = Motion.mAcm_SetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxHomeCrossDistance, crossDistance);
            if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisHome)}", $"軸 {axisNo + 1} 屬性 PAR_AxHomeCrossDistance 設定失敗：{crossDistance}！"))
                return false;

            // Home動作
            ErrCode = Motion.mAcm_AxHome(_axisHandles[axisNo], homeMode, direction);
            if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(AxisHome)}", $"軸 {axisNo + 1} 原點復歸失敗！\n復歸模式：{(HomeMode)homeMode}\n復歸方向：{direction}"))
                return false;

            return true;
        }

        /// <inheritdoc/>
        public bool SetCmdPosition(int axisNo, double position)
        {
            ErrCode = Motion.mAcm_AxSetCmdPosition(_axisHandles[axisNo], position);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(SetCmdPosition)}", $"軸 {axisNo + 1} 設定命令位置失敗：{position}！");
        }

        /// <inheritdoc/>
        public bool SetActPosition(int axisNo, double position)
        {
            ErrCode = Motion.mAcm_AxSetActualPosition(_axisHandles[axisNo], position);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(SetActPosition)}", $"軸 {axisNo + 1} 設定實際位置失敗：{position}！");
        }

        #endregion Methods

        #region Axis Parameters

        // VelLow
        /// <inheritdoc/>
        public (bool IsSuccess, double Value) GetAxisVelLow(int axisNo)
        {
            double value = default;
            ErrCode = Motion.mAcm_GetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxVelLow, ref value);
            if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(GetAxisVelLow)}", $"軸 {axisNo + 1} 屬性 PAR_AxVelLow 讀取失敗：{value}！"))
                return (false, default);
            else
                return (true, value);
        }

        /// <inheritdoc/>
        public bool SetAxisVelLow(int axisNo, double value)
        {
            ErrCode = Motion.mAcm_SetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxVelLow, value);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(SetAxisVelLow)}", $"軸 {axisNo + 1} 屬性 PAR_AxVelLow 設定失敗：{value}！");
        }

        // VelHigh
        /// <inheritdoc/>
        public (bool IsSuccess, double Value) GetAxisVelHigh(int axisNo)
        {
            double value = default;
            ErrCode = Motion.mAcm_GetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxVelHigh, ref value);
            if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(GetAxisVelHigh)}", $"軸 {axisNo + 1} 屬性 PAR_AxVelHigh 讀取失敗：{value}！"))
                return (false, default);
            else
                return (true, value);
        }

        /// <inheritdoc/>
        public bool SetAxisVelHigh(int axisNo, double value)
        {
            ErrCode = Motion.mAcm_SetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxVelHigh, value);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(SetAxisVelHigh)}", $"軸 {axisNo + 1} 屬性 PAR_AxVelHigh 設定失敗：{value}！");
        }

        // Acceleration
        /// <inheritdoc/>
        public (bool IsSuccess, double Value) GetAxisAcc(int axisNo)
        {
            double value = default;
            ErrCode = Motion.mAcm_GetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxAcc, ref value);
            if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(GetAxisAcc)}", $"軸 {axisNo + 1} 屬性 PAR_AxAcc 讀取失敗：{value}！"))
                return (false, default);
            else
                return (true, value);
        }

        /// <inheritdoc/>
        public bool SetAxisAcc(int axisNo, double value)
        {
            ErrCode = Motion.mAcm_SetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxAcc, value);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(SetAxisAcc)}", $"軸 {axisNo + 1} 屬性 PAR_AxAcc 設定失敗：{value}！");
        }

        // Deceleration
        /// <inheritdoc/>
        public (bool IsSuccess, double Value) GetAxisDec(int axisNo)
        {
            double value = default;
            ErrCode = Motion.mAcm_GetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxDec, ref value);
            if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(GetAxisDec)}", $"軸 {axisNo + 1} 屬性 PAR_AxDec 讀取失敗：{value}！"))
                return (false, default);
            else
                return (true, value);
        }

        /// <inheritdoc/>
        public bool SetAxisDec(int axisNo, double value)
        {
            ErrCode = Motion.mAcm_SetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxDec, value);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(SetAxisDec)}", $"軸 {axisNo + 1} 屬性 PAR_AxDec 設定失敗：{value}！");
        }

        // Jerk
        /// <inheritdoc/>
        public (bool IsSuccess, double Value) GetAxisJerk(int axisNo)
        {
            double value = default;
            ErrCode = Motion.mAcm_GetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxJerk, ref value);
            if (CheckErr($"{nameof(IAcmService_Axis)}.{nameof(GetAxisJerk)}", $"軸 {axisNo + 1} 屬性 PAR_AxJerk 讀取失敗：{value}！"))
                return (false, default);
            else
                return (true, value);
        }

        /// <inheritdoc/>
        public bool SetAxisJerk(int axisNo, double value)
        {
            ErrCode = Motion.mAcm_SetF64Property(_axisHandles[axisNo], (uint)PropertyID.PAR_AxJerk, value);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(SetAxisJerk)}", $"軸 {axisNo + 1} 屬性 PAR_AxJerk 設定失敗：{value}！");
        }

        #endregion Axis Parameters

        #region Motion

        /// <inheritdoc/>
        public bool MoveAbsolute(int axisNo, double position)
        {
            ErrCode = Motion.mAcm_AxMoveAbs(_axisHandles[axisNo], position);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(MoveAbsolute)}", $"軸 {axisNo + 1} 絕對位置移動失敗：{position}！");
        }

        /// <inheritdoc/>
        public bool MoveRelative(int axisNo, double distance)
        {
            ErrCode = Motion.mAcm_AxMoveRel(_axisHandles[axisNo], distance);
            return !CheckErr($"{nameof(IAcmService_Axis)}.{nameof(MoveRelative)}", $"軸 {axisNo + 1} 相對位置移動失敗：{distance}！");
        }

        #endregion Motion

        #region Helpers

        /// <inheritdoc/>
        public string GetHomeModeName(uint homeMode)
        {
            if (Enum.TryParse(homeMode.ToString(), out HomeMode hm))
                return hm.ToString();
            else
                return "";
        }

        /// <inheritdoc/>
        public string GetHomeModeDescription(uint homeMode)
        {
            if (Enum.TryParse(homeMode.ToString(), out HomeMode hm))
            {
                switch (hm)
                {
                    case HomeMode.MODE1_Abs: return "Move (Dir) -> Touch ORG -> Stop";
                    case HomeMode.MODE2_Lmt: return "Move (Dir) -> Touch EL -> Stop";
                    case HomeMode.MODE3_Ref: return "Move (Dir) -> Touch EZ -> Stop";
                    case HomeMode.MODE4_Abs_Ref: return "ORG + EZ; Move (Dir) -> Touch ORG -> Stop -> Move (Dir) -> Touch EZ -> Stop";
                    case HomeMode.MODE5_Abs_NegRef: return "ORG+EZ; Move (Dir) -> Touch ORG -> Stop -> Move (-Dir) -> Touch EZ -> Stop";
                    case HomeMode.MODE6_Lmt_Ref: return "EL + NegEZ; Move (Dir) -> Touch EL -> Stop -> Move (-Dir) -> Touch EZ -> Stop";
                    case HomeMode.MODE7_AbsSearch: return "Move (Dir) -> Search ORG -> Stop";
                    case HomeMode.MODE8_LmtSearch: return "Move (Dir) -> Search EL -> Stop";
                    case HomeMode.MODE9_AbsSearch_Ref: return "Search ORG + EZ; Move (Dir) -> Search ORG -> Stop -> Move (Dir) -> Touch EeZ ->  sacStop";
                    case HomeMode.MODE10_AbsSearch_NegRef: return "Search ORG + NegEZ; Move (Dir) -> Search ORG -> Stop -> Move (-Dir) -> se acTouch EZ -> Stop";
                    case HomeMode.MODE11_LmtSearch_Ref: return "Search EL + Neg EZ; Move (Dir) -> Search EL -> Stop -> Move (-Dir) -> Touch se EZ ac-> Stop";
                    case HomeMode.MODE12_AbsSearchReFind: return "Search ORG +Re-find ORG; Move (Dir) -> Search ORG -> Stop -> Move (-Deir) ->  sacLeave ORG (FL) -> Stop -> Move (-Dir) -> Re-find ORG(FL) -> Stop";
                    case HomeMode.MODE13_LmtSearchReFind: return "Search EL +Refind EL; Move (Dir) -> Search EL -> Stop -> Move (-Dir) -> se acLeave EL(FL) -> Stop -> Move (-Dir) -> Re-find EL(FL) -> Stop";
                    case HomeMode.MODE14_AbsSearchReFind_Ref: return "Search ORG +Refind ORG + EZ; Move (Dir) -> Search ORG -> Stop -> Move (e -sacDir) -> Leave ORG(FL) -> Stop -> Move (-Dir) -> Re-find ORG (FL) -> Stop -> Move (Dir) -> touch EZ -> Stop";
                    case HomeMode.MODE15_AbsSearchReFind_NegRef: return "Search ORG + Re-find ORG + Neg EZ; Move (Dir) -> Search ORG -> ce Stop s-a> Move (-Dir) -> Leave ORG (FL) -> Stop -> Move (-Dir) -> Re-find ORG (FL) -> Stop -> Move (-Dir) -> ce Touch EZ -sa>Stop";
                    case HomeMode.MODE16_LmtSearchReFind_Ref:
                        return "Search EL + Re-find EL + EZ; Move (Dir) - > Search EL -> Stop -> Move (-Dir) -> Leave EL (FL) -> Stop -> Move (-Dir) -> Re-find EL (FL) -> Stop -> Move (-Dir) -> Touch EZ -> Stop";
                    default: return "";
                }
            }
            else
            {
                return "";
            }
        }

        #endregion Helpers
    }
}
