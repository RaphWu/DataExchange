﻿using Calin.LockingMachine.Constants;
using Calin.LockingMachine.Ext;
using Calin.LockingMachine.Models;
using Calin.Navigation;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class Monitor : UserControl
    {
        private readonly BindingData _bindingData;

        public Monitor(BindingData bindingData)
        {
            _bindingData = bindingData;

            InitializeComponent();

            pbDI0.BindBackColorToBool(_bindingData, nameof(BindingData.DI0), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI1.BindBackColorToBool(_bindingData, nameof(BindingData.DI1), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI2.BindBackColorToBool(_bindingData, nameof(BindingData.DI2), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI3.BindBackColorToBool(_bindingData, nameof(BindingData.DI3), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI4.BindBackColorToBool(_bindingData, nameof(BindingData.DI4), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI5.BindBackColorToBool(_bindingData, nameof(BindingData.DI5), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI6.BindBackColorToBool(_bindingData, nameof(BindingData.DI6), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI7.BindBackColorToBool(_bindingData, nameof(BindingData.DI7), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
        }
    }
}
