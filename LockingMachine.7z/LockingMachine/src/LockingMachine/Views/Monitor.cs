﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Calin.Extensions;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.SharedUI.StatusIndicator;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Services;
using Calin.Navigation;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class Monitor : UserControl
    {
        #region Fields

        private readonly IAcm _acm;

        // 軸狀態旗標Buffers
        private string[][] _pbAxisStatusName;
        private CircularIndicator[][] _pbAxisStatus;
        private bool[] STA_AX_DISABLE;
        private bool[] STA_AX_READY;
        private bool[] STA_AX_STOPPING;
        private bool[] STA_AX_ERROR_STOP;
        private bool[] STA_AX_HOMING;
        private bool[] STA_AX_PTP_MOTION;
        private bool[] STA_AX_CONTI_MOTION;
        private bool[] STA_AX_SYNC_MOTION;
        private bool[] STA_AX_EXT_JOG;
        private bool[] STA_AX_EXT_MPG;
        private bool[] STA_AX_PAUSE;
        private bool[] STA_AX_BUSY;
        private bool[] STA_AX_WAIT_DI;
        private bool[] STA_AX_WAIT_PTP;
        private bool[] STA_AX_WAIT_VEL;
        private bool[] STA_AX_EXT_JOG_READY;

        // 軸運動旗標Buffers
        private CircularIndicator[][] _pbAxisMotionStatus;
        private bool[] Stop;
        private bool[] CorrectBksh;
        private bool[] InFA;
        private bool[] InFL;
        private bool[] InACC;
        private bool[] InFH;
        private bool[] InDEC;
        private bool[] WaitINP;

        // 軸的運動 I/O 旗標Buffers
        private CircularIndicator[][] _pbAxisIoStatus;
        private bool[] RDY;
        private bool[] ALM;
        private bool[] LMT_Positive;
        private bool[] LMT_Negative;
        private bool[] ORG;
        private bool[] DIR;
        private bool[] EMG;
        private bool[] EZ;
        private bool[] LTC;
        private bool[] INP;
        private bool[] SVON;
        private bool[] ALRM;
        private bool[] SLMT_Positive;
        private bool[] SLMT_Negative;

        #endregion Fields

        public Monitor(IAcm acm, BindingData bindingData)
        {
            _acm = acm;

            InitializeComponent();

            // 軸狀態旗標Buffers
            _pbAxisStatus = new CircularIndicator[2][];
            //_pbAxisStatus[0] = new CircularIndicator[]
            //{
            //    light1_STA_AX_DISABLE, light1_STA_AX_READY, light1_STA_AX_STOPPING, light1_STA_AX_ERROR_STOP,
            //    light1_STA_AX_HOMING, light1_STA_AX_PTP_MOTION, light1_STA_AX_CONTI_MOTION, light1_STA_AX_SYNC_MOTION,
            //    light1_STA_AX_EXT_JOG, light1_STA_AX_EXT_MPG, light1_STA_AX_PAUSE, light1_STA_AX_BUSY, light1_STA_AX_WAIT_DI,
            //    light1_STA_AX_WAIT_PTP, light1_STA_AX_WAIT_VEL, light1_STA_AX_EXT_JOG_READY
            //};
            //_pbAxisStatus[1] = new CircularIndicator[]
            //{
            //    light2_STA_AX_DISABLE, light2_STA_AX_READY, light2_STA_AX_STOPPING, light2_STA_AX_ERROR_STOP,
            //    light2_STA_AX_HOMING, light2_STA_AX_PTP_MOTION, light2_STA_AX_CONTI_MOTION, light2_STA_AX_SYNC_MOTION,
            //    light2_STA_AX_EXT_JOG, light2_STA_AX_EXT_MPG, light2_STA_AX_PAUSE, light2_STA_AX_BUSY, light2_STA_AX_WAIT_DI,
            //    light2_STA_AX_WAIT_PTP, light2_STA_AX_WAIT_VEL, light2_STA_AX_EXT_JOG_READY
            //};

            STA_AX_DISABLE = new bool[2];
            STA_AX_READY = new bool[2];
            STA_AX_STOPPING = new bool[2];
            STA_AX_ERROR_STOP = new bool[2];
            STA_AX_HOMING = new bool[2];
            STA_AX_PTP_MOTION = new bool[2];
            STA_AX_CONTI_MOTION = new bool[2];
            STA_AX_SYNC_MOTION = new bool[2];
            STA_AX_EXT_JOG = new bool[2];
            STA_AX_EXT_MPG = new bool[2];
            STA_AX_PAUSE = new bool[2];
            STA_AX_BUSY = new bool[2];
            STA_AX_WAIT_DI = new bool[2];
            STA_AX_WAIT_PTP = new bool[2];
            STA_AX_WAIT_VEL = new bool[2];
            STA_AX_EXT_JOG_READY = new bool[2];

            // 軸運動旗標Buffers
            _pbAxisMotionStatus = new CircularIndicator[2][];
            _pbAxisMotionStatus[0] = new CircularIndicator[]
            {

            };
            _pbAxisMotionStatus[1] = new CircularIndicator[]
            {

            };
            Stop = new bool[2];
            CorrectBksh = new bool[2];
            InFA = new bool[2];
            InFL = new bool[2];
            InACC = new bool[2];
            InFH = new bool[2];
            InDEC = new bool[2];
            WaitINP = new bool[2];

            // 軸的運動 I/O 旗標Buffers
            _pbAxisMotionStatus = new CircularIndicator[2][];
            _pbAxisMotionStatus[0] = new CircularIndicator[]
            {

            };
            _pbAxisMotionStatus[1] = new CircularIndicator[]
            {

            };
            RDY = new bool[2];
            ALM = new bool[2];
            LMT_Positive = new bool[2];
            LMT_Negative = new bool[2];
            ORG = new bool[2];
            DIR = new bool[2];
            EMG = new bool[2];
            EZ = new bool[2];
            LTC = new bool[2];
            INP = new bool[2];
            SVON = new bool[2];
            ALRM = new bool[2];
            SLMT_Positive = new bool[2];
            SLMT_Negative = new bool[2];

            //pbDI0.BindBackColorToBool(_bindingData, nameof(BindingData.DI0), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI1.BindBackColorToBool(_bindingData, nameof(BindingData.DI1), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI2.BindBackColorToBool(_bindingData, nameof(BindingData.DI2), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI3.BindBackColorToBool(_bindingData, nameof(BindingData.DI3), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI4.BindBackColorToBool(_bindingData, nameof(BindingData.DI4), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI5.BindBackColorToBool(_bindingData, nameof(BindingData.DI5), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI6.BindBackColorToBool(_bindingData, nameof(BindingData.DI6), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI7.BindBackColorToBool(_bindingData, nameof(BindingData.DI7), CommonStyle.SignalOn, CommonStyle.SignalOff, true);

            //var multiCircularIndicator = new MultiCircularIndicator
            //{
            //    Columns = 1,
            //    IndicatorSize = 20,
            //    Padding = 3,
            //    OnColor = Color.Lime,
            //    OffColor = Color.DimGray,
            //    BorderColor = Color.Black,
            //    TextColor = Color.Black,
            //    //Font = new Font("Arial", 9)
            //};

            string[] axisStatusCaptin = {
                "禁用","Ready","Stopping","ErrorStop","Homing","PTP運動中",
                "連續運動中","群組運動中(插補)","外部控制，JOG模式","外部控制，MPG模式","暫停中",
                "Busy","等候DI信號","等候R軸PTP運動完成","等候R軸連續運動完成","外部JOG準備完成",
            };
            string[] axisMotionStatusCaption = {
                "停止","背隙補償","處於特定速度中","處於低速中","加速中","處於最大速度中","減速中","到位INP等待",
            };
            string[] axisIoStatusCaption = {
                "RDY","ALM","極限開關+","極限開關-","原點","DIR","緊急停止","編碼器Z相",
                "鎖存訊號","INP到位訊號","伺服ON","警報復位","軟體極限+","軟體極限-",
            };

            axis1Indicator.Columns = new List<int>
            {
                axisStatusCaptin.Count(),
                axisMotionStatusCaption.Count(),
                axisIoStatusCaption.Count()
            };
            axis1Indicator.ColumnHeaders = new List<string>
            {
                "軸狀態",
                "運動狀態",
                "軸I/O"
            };
            var axis1ItemList = new List<MultiCircularIndicator.IndicatorItem>();
            foreach (var item in axisStatusCaptin)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item });
            foreach (var item in axisMotionStatusCaption)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item });
            foreach (var item in axisIoStatusCaption)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item });
            axis1Indicator.SetIndicators(axis1ItemList);
            axis1Indicator.Size = axis1Indicator.GetPreferredSize();

            axis2Indicator.Columns = new List<int>
            {
                axisStatusCaptin.Count(),
                axisMotionStatusCaption.Count(),
                axisIoStatusCaption.Count()
            };
            axis2Indicator.ColumnHeaders = new List<string>
            {
                "軸狀態",
                "運動狀態",
                "軸I/O"
            };
            var axis2ItemList = new List<MultiCircularIndicator.IndicatorItem>();
            foreach (var item in axisStatusCaptin)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item });
            foreach (var item in axisMotionStatusCaption)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item });
            foreach (var item in axisIoStatusCaption)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item });
            axis2Indicator.SetIndicators(axis2ItemList);
            axis2Indicator.Size = axis2Indicator.GetPreferredSize();

            axis1Indicator.BeginUpdate();
            axis1Indicator.UpdateIndicator(4, true);
            axis1Indicator.EndUpdate();

            _acm.AcmStatusUpdated += OnAcmStatusUpdated;
        }

        private void OnAcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs asue)
        {
            ThreadExt.RunOnUiThread(() =>
            {
                int axisNo = asue.AxisNo;
                var parsedAxisState = asue.ParsedAxisState;

                //// 軸狀態
                //var axisState = parsedAxisState.AxisStateFlags;
                //if (STA_AX_DISABLE[axisNo] != parsedAxisState.STA_AX_DISABLE)
                //{
                //    STA_AX_DISABLE[axisNo] = parsedAxisState.STA_AX_DISABLE;
                //    if (axisNo == 0)
                //        light1_STA_AX_DISABLE.IsOn = parsedAxisState.STA_AX_DISABLE;
                //    else
                //        light2_STA_AX_DISABLE.IsOn = parsedAxisState.STA_AX_DISABLE;
                //}
                //if (STA_AX_READY[axisNo] != parsedAxisState.STA_AX_READY)
                //{
                //    STA_AX_READY[axisNo] = parsedAxisState.STA_AX_READY;
                //    if (axisNo == 0)
                //        light1_STA_AX_READY.IsOn = parsedAxisState.STA_AX_READY;
                //    else
                //        light2_STA_AX_READY.IsOn = parsedAxisState.STA_AX_READY;
                //}
                //if (STA_AX_STOPPING[axisNo] != parsedAxisState.STA_AX_STOPPING)
                //{
                //    STA_AX_STOPPING[axisNo] = parsedAxisState.STA_AX_STOPPING;
                //    if (axisNo == 0)
                //        light1_STA_AX_STOPPING.IsOn = parsedAxisState.STA_AX_STOPPING;
                //    else
                //        light2_STA_AX_STOPPING.IsOn = parsedAxisState.STA_AX_STOPPING;
                //}
                //if (STA_AX_ERROR_STOP[axisNo] != parsedAxisState.STA_AX_ERROR_STOP)
                //{
                //    STA_AX_ERROR_STOP[axisNo] = parsedAxisState.STA_AX_ERROR_STOP;
                //    if (axisNo == 0)
                //        light1_STA_AX_ERROR_STOP.IsOn = parsedAxisState.STA_AX_ERROR_STOP;
                //    else
                //        light2_STA_AX_ERROR_STOP.IsOn = parsedAxisState.STA_AX_ERROR_STOP;
                //}
                //if (STA_AX_HOMING[axisNo] != parsedAxisState.STA_AX_HOMING)
                //{
                //    STA_AX_HOMING[axisNo] = parsedAxisState.STA_AX_HOMING;
                //    if (axisNo == 0)
                //        light1_STA_AX_HOMING.IsOn = parsedAxisState.STA_AX_HOMING;
                //    else
                //        light2_STA_AX_HOMING.IsOn = parsedAxisState.STA_AX_HOMING;
                //}
                //if (STA_AX_CONTI_MOTION[axisNo] != parsedAxisState.STA_AX_CONTI_MOTION)
                //{
                //    STA_AX_CONTI_MOTION[axisNo] = parsedAxisState.STA_AX_CONTI_MOTION;
                //    if (axisNo == 0)
                //        light1_STA_AX_CONTI_MOTION.IsOn = parsedAxisState.STA_AX_CONTI_MOTION;
                //    else
                //        light2_STA_AX_CONTI_MOTION.IsOn = parsedAxisState.STA_AX_CONTI_MOTION;
                //}
                //if (STA_AX_SYNC_MOTION[axisNo] != parsedAxisState.STA_AX_SYNC_MOTION)
                //{
                //    STA_AX_SYNC_MOTION[axisNo] = parsedAxisState.STA_AX_SYNC_MOTION;
                //    if (axisNo == 0)
                //        light1_STA_AX_SYNC_MOTION.IsOn = parsedAxisState.STA_AX_SYNC_MOTION;
                //    else
                //        light2_STA_AX_SYNC_MOTION.IsOn = parsedAxisState.STA_AX_SYNC_MOTION;
                //}
                //if (STA_AX_EXT_JOG[axisNo] != parsedAxisState.STA_AX_EXT_JOG)
                //{
                //    STA_AX_EXT_JOG[axisNo] = parsedAxisState.STA_AX_EXT_JOG;
                //    if (axisNo == 0)
                //        light1_STA_AX_EXT_JOG.IsOn = parsedAxisState.STA_AX_EXT_JOG;
                //    else
                //        light2_STA_AX_EXT_JOG.IsOn = parsedAxisState.STA_AX_EXT_JOG;
                //}
                //if (STA_AX_EXT_MPG[axisNo] != parsedAxisState.STA_AX_EXT_MPG)
                //{
                //    STA_AX_EXT_MPG[axisNo] = parsedAxisState.STA_AX_EXT_MPG;
                //    if (axisNo == 0)
                //        light1_STA_AX_EXT_MPG.IsOn = parsedAxisState.STA_AX_EXT_MPG;
                //    else
                //        light2_STA_AX_EXT_MPG.IsOn = parsedAxisState.STA_AX_EXT_MPG;
                //}
                //if (STA_AX_PAUSE[axisNo] != parsedAxisState.STA_AX_PAUSE)
                //{
                //    STA_AX_PAUSE[axisNo] = parsedAxisState.STA_AX_PAUSE;
                //    if (axisNo == 0)
                //        light1_STA_AX_PAUSE.IsOn = parsedAxisState.STA_AX_PAUSE;
                //    else
                //        light2_STA_AX_PAUSE.IsOn = parsedAxisState.STA_AX_PAUSE;
                //}
                //if (STA_AX_BUSY[axisNo] != parsedAxisState.STA_AX_BUSY)
                //{
                //    STA_AX_BUSY[axisNo] = parsedAxisState.STA_AX_BUSY;
                //    if (axisNo == 0)
                //        light1_STA_AX_BUSY.IsOn = parsedAxisState.STA_AX_BUSY;
                //    else
                //        light2_STA_AX_BUSY.IsOn = parsedAxisState.STA_AX_BUSY;
                //}
                //if (STA_AX_WAIT_DI[axisNo] != parsedAxisState.STA_AX_WAIT_DI)
                //{
                //    STA_AX_WAIT_DI[axisNo] = parsedAxisState.STA_AX_WAIT_DI;
                //    if (axisNo == 0)
                //        light1_STA_AX_WAIT_DI.IsOn = parsedAxisState.STA_AX_WAIT_DI;
                //    else
                //        light2_STA_AX_WAIT_DI.IsOn = parsedAxisState.STA_AX_WAIT_DI;
                //}
                //if (STA_AX_WAIT_PTP[axisNo] != parsedAxisState.STA_AX_WAIT_PTP)
                //{
                //    STA_AX_WAIT_PTP[axisNo] = parsedAxisState.STA_AX_WAIT_PTP;
                //    if (axisNo == 0)
                //        light1_STA_AX_WAIT_PTP.IsOn = parsedAxisState.STA_AX_WAIT_PTP;
                //    else
                //        light2_STA_AX_WAIT_PTP.IsOn = parsedAxisState.STA_AX_WAIT_PTP;
                //}
                //if (STA_AX_WAIT_VEL[axisNo] != parsedAxisState.STA_AX_WAIT_VEL)
                //{
                //    STA_AX_WAIT_VEL[axisNo] = parsedAxisState.STA_AX_WAIT_VEL;
                //    if (axisNo == 0)
                //        light1_STA_AX_WAIT_VEL.IsOn = parsedAxisState.STA_AX_WAIT_VEL;
                //    else
                //        light2_STA_AX_WAIT_VEL.IsOn = parsedAxisState.STA_AX_WAIT_VEL;
                //}
                //if (STA_AX_EXT_JOG_READY[axisNo] != parsedAxisState.STA_AX_EXT_JOG_READY)
                //{
                //    STA_AX_EXT_JOG_READY[axisNo] = parsedAxisState.STA_AX_EXT_JOG_READY;
                //    if (axisNo == 0)
                //        light1_STA_AX_EXT_JOG_READY.IsOn = parsedAxisState.STA_AX_EXT_JOG_READY;
                //    else
                //        light2_STA_AX_EXT_JOG_READY.IsOn = parsedAxisState.STA_AX_EXT_JOG_READY;
                //}










            });
        }
    }
}
