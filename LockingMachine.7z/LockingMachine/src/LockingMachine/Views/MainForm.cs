using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.Extensions;
using Calin.LockingMachine.Constants;
using Calin.LockingMachine.Events;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.ProcessFlow.UI;
using Calin.LockingMachine.Views;
using Calin.MotionControl.Advantech.Contracts;
using Calin.Navigation;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.LockingMachine
{
    public partial class MainForm : Form
    {
        #region Fields

        private readonly INavigation _nav;
        private readonly IAcm _acm;
        private readonly LmData _lmData;
        private readonly BindingData _bindingData;

        private PageCode _currentPageCode = PageCode.None;
        private bool _zAxisActive = true;
        private double _zAxisCoor = double.MinValue;
        private bool _rAxisActive = true;
        private double _angle = double.MinValue;
        private bool _torqueMeterActive = true;
        private double _torqueValue = double.MinValue;
        private bool _heightDisplacementActive = true;
        private double _heightDisplacementValue = double.MinValue;

        private readonly System.Timers.Timer _statusbarTimer = new System.Timers.Timer();
        private readonly System.Timers.Timer _messageTimer = new System.Timers.Timer();

        #endregion Fields

        #region ctor

        public MainForm(
            INavigation navigationService,
            IAcm acm,
            LmData lmData,
            BindingData bindingData)
        {
            _nav = navigationService;
            _acm = acm;
            _lmData = lmData;
            _bindingData = bindingData;

            InitializeComponent();

            // Region ���U
            _nav.RegisterRegion(nameof(ContentPanel), view =>
            {
                ContentPanel.SuspendLayout();
                ContentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    ContentPanel.Controls.Add(control);
                }
                ContentPanel.ResumeLayout();
            });

            // Status Bar
            //_bindingData.PropertyChanged += MainFormData_PropertyChanged;

            // ���U���A�C�T�������
            _messageTimer.AutoReset = false;
            _messageTimer.Elapsed += (s, e) => { sbMessage.Text = ""; };
            WeakReferenceMessenger.Default.Register<ShowStatusBarMessage>(this, (recipient, message) =>
            {
                _messageTimer.Stop();
                if (message?.Value != null)
                {
                    sbMessage.Text = message.Value.Message;
                    if (message.Value.Duration > 0)
                    {
                        _messageTimer.Interval = message.Value.Duration;
                        _messageTimer.Start();
                    }
                }
            });

            //���U���A�C�i�ױ����
            //WeakReferenceMessenger.Default.Register<ShowProcessBar>(this, (recipient, message) =>
            //{
            //    ProcessBarInfo info = message.Value;
            //    SetProcessBar(info.Percent);
            //    if (!string.IsNullOrWhiteSpace(info.Message))
            //    {
            //        SBMessage.Text = info.Message;
            //        _messageTimer.ReStart();
            //    }
            //    else
            //    {
            //        SBMessage.Text = "";
            //    }
            //});
        }

        #endregion ctor

        #region Form Events

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // ����Ҧ� Timer
            _messageTimer?.Stop();
            _messageTimer?.Dispose();

            ClockTimer?.Stop();
            ClockTimer?.Dispose();

            if (_acm.IsBoardInit)
                _acm.BoardClose();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ResizeScreen();
            _bindingData.ZAxisActive = false;
            _bindingData.RAxisActive = false;

            if (_acm.GetAvailableDevs() > 0)
            {
                _acm.BoardOpen(_acm.AvailableDevices[0].DeviceNumber);
                if (_acm.IsBoardInit)
                {
                    if (_acm.AxisCount != 2)
                    {
                        MessageBox.Show("Advantech �b�d�b�Ƥ��� 2�A���ˬd�I", "�t�ο��~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    _bindingData.ZAxisActive = true;
                    _bindingData.RAxisActive = true;

                    _acm.PollingStart();
                }
            }

            _statusbarTimer.Interval = _lmData.uiScanTimeInterval;
            _statusbarTimer.Elapsed += StatusbarTimer_Elapsed;
            _statusbarTimer.Start();
        }

        private async void StatusbarTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            await UpdateStatusBar();
        }

        /// <summary>
        /// ��s���A�C��ܤ��e�C
        /// </summary>
        /// <param name="propertyName"></param>
        private async Task UpdateStatusBar()
        {
            ThreadExt.RunOnUiThread(() =>
            {
                // Z�b
                if (_zAxisActive != _bindingData.ZAxisActive)
                {
                    _zAxisActive = _bindingData.ZAxisActive;
                    if (_zAxisActive)
                    {
                        sbZTitle.BackColor = SystemColors.Control;
                        sbZTitle.ForeColor = SystemColors.ControlText;
                        sbZ.BackColor = SystemColors.Control;
                        sbZ.ForeColor = SystemColors.ControlText;
                    }
                    else
                    {
                        sbZTitle.BackColor = CommonStyle.BgDeviceInOperation;
                        sbZTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                        sbZ.BackColor = CommonStyle.BgDeviceInOperation;
                        sbZ.ForeColor = CommonStyle.FgDeviceInOperation;
                    }
                }

                if (_zAxisCoor != _bindingData.ZAxisCoor)
                {
                    _zAxisCoor = _bindingData.ZAxisCoor;
                    sbZ.Text = _bindingData.ZAxisCoor.ToString("F3");
                }

                // R�b
                if (_rAxisActive != _bindingData.RAxisActive)
                {
                    _rAxisActive = _bindingData.RAxisActive;
                    if (_rAxisActive)
                    {
                        sbRTitle.BackColor = SystemColors.Control;
                        sbRTitle.ForeColor = SystemColors.ControlText;
                        sbR.BackColor = SystemColors.Control;
                        sbR.ForeColor = SystemColors.ControlText;
                    }
                    else
                    {
                        sbRTitle.BackColor = CommonStyle.BgDeviceInOperation;
                        sbRTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                        sbR.BackColor = CommonStyle.BgDeviceInOperation;
                        sbR.ForeColor = CommonStyle.FgDeviceInOperation;
                    }
                }

                if (_angle != _bindingData.Angle)
                {
                    _angle = _bindingData.Angle;
                    sbR.Text = _bindingData.Angle.ToString("F1");
                }

                // ��O�p
                if (_torqueMeterActive != _bindingData.TorqueMeterActive)
                {
                    _torqueMeterActive = _bindingData.TorqueMeterActive;
                    if (_torqueMeterActive)
                    {
                        sbTorqueTitle.BackColor = SystemColors.Control;
                        sbTorqueTitle.ForeColor = SystemColors.ControlText;
                        sbTorque.BackColor = SystemColors.Control;
                        sbTorque.ForeColor = SystemColors.ControlText;
                    }
                    else
                    {
                        sbTorqueTitle.BackColor = CommonStyle.BgDeviceInOperation;
                        sbTorqueTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                        sbTorque.BackColor = CommonStyle.BgDeviceInOperation;
                        sbTorque.ForeColor = CommonStyle.FgDeviceInOperation;
                    }
                }

                if (_torqueValue != _bindingData.TorqueValue)
                {
                    _torqueValue = _bindingData.TorqueValue;
                    sbTorque.Text = _bindingData.TorqueValue.ToString("F3");
                }

                // LD_RS1A
                if (_heightDisplacementActive != _bindingData.HeightDisplacementActive)
                {
                    _heightDisplacementActive = _bindingData.HeightDisplacementActive;
                    if (_heightDisplacementActive)
                    {
                        sbHeightTitle.BackColor = SystemColors.Control;
                        sbHeightTitle.ForeColor = SystemColors.ControlText;
                        sbHeight.BackColor = SystemColors.Control;
                        sbHeight.ForeColor = SystemColors.ControlText;
                    }
                    else
                    {
                        sbHeightTitle.BackColor = CommonStyle.BgDeviceInOperation;
                        sbHeightTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                        sbHeight.BackColor = CommonStyle.BgDeviceInOperation;
                        sbHeight.ForeColor = CommonStyle.FgDeviceInOperation;
                    }
                }

                if (_heightDisplacementValue != _bindingData.HeightDisplacementValue)
                {
                    _heightDisplacementValue = _bindingData.HeightDisplacementValue;
                    sbHeight.Text = _bindingData.HeightDisplacementValue.ToString("F3");
                }

            });
            await Task.CompletedTask;
        }

        #endregion Form Events

        #region Form Methods

        /// <summary>
        /// �վ�����j�p�C
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1024;
            const int TARGET_HEIGHT = 768;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        #endregion Form Methods

        #region Timer

        private void ClockTimer_Tick(object sender, EventArgs e)
        {
            sbClock.Text = DateTime.Now.ToString();
        }

        #endregion Timer

        #region Navigation

        /// <summary>
        /// �����ާ@�����C
        /// </summary>
        /// <param name="pageCode">�������ޡC</param>
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentPageCode == pageCode) return;

            switch (pageCode)
            {
                case PageCode.MainPage:
                    _nav.NavigateTo<MainPage>(nameof(ContentPanel));
                    break;
                case PageCode.Monitor:
                    _nav.NavigateTo<Monitor>(nameof(ContentPanel));
                    break;
                case PageCode.ProcessFlow:
                    _nav.NavigateTo<ProcessFlowMainForm>(nameof(ContentPanel));
                    break;
                case PageCode.Manual:
                    _nav.NavigateTo<ManualPage>(nameof(ContentPanel));
                    break;
                case PageCode.Setup:
                    _nav.NavigateTo<SetupPage>(nameof(ContentPanel));
                    break;
                default:
                    return;
            }
            _currentPageCode = pageCode;
        }

        private void rbMenuMain_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.MainPage);
        }

        private void rbMenuMonitor_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Monitor);
        }

        private void rbMenuWorkSetup_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.ProcessFlow);
        }

        private void rbMenuManul_CheckedChanged(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Manual);
        }

        private void rbMenuSetup_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Setup);
        }

        #endregion Navigation
    }
}
