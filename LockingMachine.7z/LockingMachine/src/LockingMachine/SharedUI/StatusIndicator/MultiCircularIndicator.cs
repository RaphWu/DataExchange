﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.LockingMachine.SharedUI.StatusIndicator
{
    /// <summary>
    /// 多重圓形指示燈控件（TableLayout 思維 + Hover 高亮 + 老機效能優化）
    /// </summary>
    public class MultiCircularIndicator : Control
    {
        public class IndicatorItem
        {
            public bool IsOn;
            public string Text;
        }

        private List<IndicatorItem> _indicators = new List<IndicatorItem>();
        private int _updateLockCount = 0;
        private bool _layoutDirty = false;
        private bool _invalidateDirty = false;

        public IReadOnlyList<IndicatorItem> Indicators => _indicators.AsReadOnly();

        public List<int> Columns { get; set; } = new List<int>() { 2 };
        public List<string> ColumnHeaders { get; set; } = new List<string>();

        public int IndicatorSize { get; set; } = 20;
        public int RowSpacing { get; set; } = 4;
        public int TextSpacing { get; set; } = 5;
        public int ColumnSpacing { get; set; } = 8;
        public int HeaderHeight { get; set; } = 22;
        public int HeaderBottomSpacing { get; set; } = 6; // 底線與第一顆燈的距離

        public Color OnColor { get; set; } = Color.Lime;
        public Color OffColor { get; set; } = Color.DimGray;
        public Color TextColor { get; set; } = Color.Black;
        public Color BorderColor { get; set; } = Color.Black;
        public Color HeaderTextColor { get; set; } = Color.Black;
        public Color HeaderLineColor { get; set; } = Color.DarkGray;
        public int HeaderLineThickness { get; set; } = 2;

        public Color HoverColor { get; set; } = Color.Yellow; // 滑鼠 Hover 高亮

        public Font HeaderFont { get; set; }

        public event EventHandler<int> IndicatorClick;

        private readonly List<int> _maxTextWidthPerColumn = new List<int>();
        private readonly List<int> _headerTextWidthPerColumn = new List<int>();

        private SolidBrush _onBrush;
        private SolidBrush _offBrush;
        private Pen _borderPen;

        private int _hoverIndex = -1;

        public MultiCircularIndicator()
        {
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.UserPaint |
                ControlStyles.SupportsTransparentBackColor, true);

            BackColor = Color.Transparent;
            HeaderFont = new Font(Font, FontStyle.Bold);

            _onBrush = new SolidBrush(OnColor);
            _offBrush = new SolidBrush(OffColor);
            _borderPen = new Pen(BorderColor);

            MouseMove += MultiCircularIndicator_MouseMove;
            MouseLeave += MultiCircularIndicator_MouseLeave;
        }

        #region Public API

        public void SetIndicators(List<IndicatorItem> items)
        {
            _indicators = items ?? new List<IndicatorItem>();
            _layoutDirty = true;
            if (_updateLockCount == 0)
                RecalculateLayout();
        }

        public void SetColumns(List<int> columns)
        {
            Columns = columns ?? new List<int>() { 1 };
            _layoutDirty = true;
            if (_updateLockCount == 0)
                RecalculateLayout();
        }

        public void UpdateIndicator(int index, bool isOn, string text = null)
        {
            if (index < 0 || index >= _indicators.Count)
                return;

            var item = _indicators[index];
            bool needLayout = false;

            if (item.IsOn != isOn)
                item.IsOn = isOn;

            if (text != null && item.Text != text)
            {
                item.Text = text;
                needLayout = true;
            }

            if (_updateLockCount > 0)
            {
                if (needLayout)
                    _layoutDirty = true;
                else
                    _invalidateDirty = true;
                return;
            }

            if (needLayout)
                RecalculateLayout();
            else
                Invalidate(GetIndicatorBounds(index));
        }

        public void BeginUpdate() => _updateLockCount++;

        public void EndUpdate()
        {
            if (_updateLockCount == 0)
                return;

            _updateLockCount--;

            if (_updateLockCount == 0)
            {
                if (_layoutDirty)
                    RecalculateLayout();
                else if (_invalidateDirty)
                    Invalidate();

                _layoutDirty = false;
                _invalidateDirty = false;
            }
        }

        #endregion

        #region Layout

        private Rectangle GetIndicatorBounds(int index)
        {
            int col = 0;
            int row = index;

            foreach (var rows in Columns)
            {
                if (row < rows)
                    break;

                row -= rows;
                col++;
            }

            int x = GetColumnX(col);
            int y = HeaderHeight + HeaderBottomSpacing + row * (IndicatorSize + RowSpacing);

            return new Rectangle(x, y, IndicatorSize, IndicatorSize);
        }

        private void RecalculateLayout()
        {
            if (_updateLockCount > 0)
            {
                _layoutDirty = true;
                return;
            }

            UpdateTextMetrics();
            Size = GetPreferredSize();
            Invalidate();
        }

        private void UpdateTextMetrics()
        {
            _maxTextWidthPerColumn.Clear();
            _headerTextWidthPerColumn.Clear();

            int index = 0;
            using (Graphics g = CreateGraphics())
            {
                for (int col = 0; col < Columns.Count; col++)
                {
                    int rows = Columns[col];
                    int maxIndicatorText = 0;

                    for (int r = 0; r < rows && index < _indicators.Count; r++, index++)
                    {
                        var t = _indicators[index].Text;
                        if (!string.IsNullOrEmpty(t))
                            maxIndicatorText = Math.Max(
                                maxIndicatorText,
                                TextRenderer.MeasureText(g, t, Font).Width);
                    }

                    _maxTextWidthPerColumn.Add(maxIndicatorText);

                    if (col < ColumnHeaders.Count && !string.IsNullOrEmpty(ColumnHeaders[col]))
                    {
                        _headerTextWidthPerColumn.Add(
                            TextRenderer.MeasureText(g, ColumnHeaders[col], HeaderFont).Width);
                    }
                    else
                    {
                        _headerTextWidthPerColumn.Add(0);
                    }
                }
            }
        }

        private int GetColumnWidth(int col)
        {
            int indicatorWidth =
                IndicatorSize +
                (_maxTextWidthPerColumn[col] > 0
                    ? TextSpacing + _maxTextWidthPerColumn[col]
                    : 0);

            return Math.Max(indicatorWidth, _headerTextWidthPerColumn[col]);
        }

        private int GetColumnX(int col)
        {
            int x = 0;
            for (int i = 0; i < col; i++)
                x += GetColumnWidth(i) + ColumnSpacing;
            return x;
        }

        public Size GetPreferredSize()
        {
            int width = 0;
            int height = HeaderHeight;

            for (int col = 0; col < Columns.Count; col++)
            {
                width += GetColumnWidth(col);
                if (col < Columns.Count - 1)
                    width += ColumnSpacing;

                height = Math.Max(
                    height,
                    HeaderHeight + HeaderBottomSpacing + Columns[col] * (IndicatorSize + RowSpacing));
            }

            return new Size(width, height);
        }

        #endregion

        #region Paint

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            int index = 0;

            for (int col = 0; col < Columns.Count; col++)
            {
                int x = GetColumnX(col);

                // Header
                if (col < ColumnHeaders.Count && !string.IsNullOrEmpty(ColumnHeaders[col]))
                {
                    var headerRect = new Rectangle(x, 0, GetColumnWidth(col), HeaderHeight);

                    TextRenderer.DrawText(
                        e.Graphics,
                        ColumnHeaders[col],
                        HeaderFont,
                        headerRect,
                        HeaderTextColor,
                        TextFormatFlags.HorizontalCenter |
                        TextFormatFlags.VerticalCenter |
                        TextFormatFlags.SingleLine
                    );

                    // Header bottom line
                    using (Pen pen = new Pen(HeaderLineColor, HeaderLineThickness))
                    {
                        int lineY = HeaderHeight - HeaderLineThickness / 2;
                        e.Graphics.DrawLine(
                            pen,
                            x,
                            lineY,
                            x + GetColumnWidth(col),
                            lineY
                        );
                    }
                }

                // Indicators
                for (int row = 0; row < Columns[col] && index < _indicators.Count; row++, index++)
                {
                    int y = HeaderHeight + HeaderBottomSpacing + row * (IndicatorSize + RowSpacing);
                    var item = _indicators[index];

                    var circle = new Rectangle(x, y, IndicatorSize, IndicatorSize);

                    var brush = item.IsOn ? _onBrush : _offBrush;

                    // Hover 高亮
                    if (index == _hoverIndex)
                    {
                        using (SolidBrush hoverBrush = new SolidBrush(HoverColor))
                        {
                            e.Graphics.FillEllipse(hoverBrush, circle);
                        }
                    }
                    else
                    {
                        e.Graphics.FillEllipse(brush, circle);
                    }

                    e.Graphics.DrawEllipse(_borderPen, circle);

                    if (!string.IsNullOrEmpty(item.Text))
                    {
                        var textRect = new Rectangle(
                            x + IndicatorSize + TextSpacing,
                            y,
                            _maxTextWidthPerColumn[col],
                            IndicatorSize);

                        TextRenderer.DrawText(
                            e.Graphics,
                            item.Text,
                            Font,
                            textRect,
                            TextColor,
                            TextFormatFlags.Left |
                            TextFormatFlags.VerticalCenter |
                            TextFormatFlags.SingleLine);
                    }
                }
            }
        }

        #endregion

        #region Mouse Hover

        private void MultiCircularIndicator_MouseMove(object sender, MouseEventArgs e)
        {
            int hover = -1;
            for (int i = 0; i < _indicators.Count; i++)
            {
                if (GetIndicatorBounds(i).Contains(e.Location))
                {
                    hover = i;
                    break;
                }
            }

            if (_hoverIndex != hover)
            {
                _hoverIndex = hover;
                Invalidate(); // 只 repaint hover
            }
        }

        private void MultiCircularIndicator_MouseLeave(object sender, EventArgs e)
        {
            if (_hoverIndex != -1)
            {
                _hoverIndex = -1;
                Invalidate();
            }
        }

        #endregion

        #region Mouse Click

        protected override void OnMouseClick(MouseEventArgs e)
        {
            base.OnMouseClick(e);

            for (int i = 0; i < _indicators.Count; i++)
            {
                if (GetIndicatorBounds(i).Contains(e.Location))
                {
                    IndicatorClick?.Invoke(this, i);
                    return;
                }
            }
        }

        #endregion
    }
}
