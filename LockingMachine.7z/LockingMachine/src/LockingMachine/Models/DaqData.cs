﻿namespace Calin.LockingMachine.Models
{
    /// <summary>
    /// 資料擷取裝置 (DAQ) 資料模型。
    /// </summary>
    /// <remarks>DAQ設定，會儲存成 .JSON 檔。</remarks>
    public class DaqData
    {
        public string DeviceCode { get; set; } = "USB-4704,BID#0";

        // 扭力計上下限設定
        public double TorqueLimitH { get; set; } = 20.0;
        public double TorqueLimitL { get; set; } = 10.0;

        // 尋邊
        public string GateMarkPort { get; set; } = "DO0";
    }
}
