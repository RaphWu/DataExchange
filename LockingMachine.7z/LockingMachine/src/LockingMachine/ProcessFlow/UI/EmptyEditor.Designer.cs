namespace Calin.LockingMachine.ProcessFlow.UI
{
    partial class EmptyEditor
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblMessage;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblMessage
            // 
            this.lblMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMessage.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblMessage.Location = new System.Drawing.Point(0, 0);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(400, 200);
            this.lblMessage.TabIndex = 0;
            this.lblMessage.Text = "�L�i�Ϊ��Ѽƽs�边";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EmptyEditor
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblMessage);
            this.Name = "EmptyEditor";
            this.Size = new System.Drawing.Size(400, 200);
            this.ResumeLayout(false);
        }
    }
}
