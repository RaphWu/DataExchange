namespace Calin.LockingMachine.ProcessFlow.UI
{
    partial class ProcessFlowEditorView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label _lblSourceTitle;
        private System.Windows.Forms.TreeView tvProcessSource;
        private System.Windows.Forms.Label _lblListTitle;
        private System.Windows.Forms.FlowLayoutPanel _pnlButtons;
        private System.Windows.Forms.Button _btnAdd;
        private System.Windows.Forms.Button _btnRemove;
        private System.Windows.Forms.Button _btnMoveUp;
        private System.Windows.Forms.Button _btnMoveDown;
        private System.Windows.Forms.DataGridView dgvProcessList;
        private System.Windows.Forms.Label _lblEditorTitle;
        private System.Windows.Forms.Panel pnlEditorHost;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                ClearEditor();
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tvProcessSource = new System.Windows.Forms.TreeView();
            this._lblSourceTitle = new System.Windows.Forms.Label();
            this.dgvProcessList = new System.Windows.Forms.DataGridView();
            this._pnlButtons = new System.Windows.Forms.FlowLayoutPanel();
            this._btnAdd = new System.Windows.Forms.Button();
            this._btnRemove = new System.Windows.Forms.Button();
            this._btnMoveUp = new System.Windows.Forms.Button();
            this._btnMoveDown = new System.Windows.Forms.Button();
            this._lblListTitle = new System.Windows.Forms.Label();
            this.pnlEditorHost = new System.Windows.Forms.Panel();
            this._lblEditorTitle = new System.Windows.Forms.Label();
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProcessList)).BeginInit();
            this._pnlButtons.SuspendLayout();
            this.TLP.SuspendLayout();
            this.SuspendLayout();
            // 
            // tvProcessSource
            // 
            this.tvProcessSource.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvProcessSource.HideSelection = false;
            this.tvProcessSource.Location = new System.Drawing.Point(2, 28);
            this.tvProcessSource.Margin = new System.Windows.Forms.Padding(2);
            this.tvProcessSource.Name = "tvProcessSource";
            this.tvProcessSource.Size = new System.Drawing.Size(126, 300);
            this.tvProcessSource.TabIndex = 1;
            this.tvProcessSource.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TvProcessSource_AfterSelect);
            this.tvProcessSource.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.TvProcessSource_NodeMouseDoubleClick);
            // 
            // _lblSourceTitle
            // 
            this._lblSourceTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this._lblSourceTitle.Location = new System.Drawing.Point(2, 0);
            this._lblSourceTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this._lblSourceTitle.Name = "_lblSourceTitle";
            this._lblSourceTitle.Size = new System.Drawing.Size(126, 26);
            this._lblSourceTitle.TabIndex = 0;
            this._lblSourceTitle.Text = "�s�{�ӷ�";
            this._lblSourceTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvProcessList
            // 
            this.dgvProcessList.AllowUserToAddRows = false;
            this.dgvProcessList.AllowUserToDeleteRows = false;
            this.dgvProcessList.AllowUserToResizeRows = false;
            this.dgvProcessList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProcessList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvProcessList.Location = new System.Drawing.Point(132, 28);
            this.dgvProcessList.Margin = new System.Windows.Forms.Padding(2);
            this.dgvProcessList.MultiSelect = false;
            this.dgvProcessList.Name = "dgvProcessList";
            this.dgvProcessList.RowHeadersVisible = false;
            this.TLP.SetRowSpan(this.dgvProcessList, 2);
            this.dgvProcessList.RowTemplate.Height = 24;
            this.dgvProcessList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProcessList.Size = new System.Drawing.Size(446, 470);
            this.dgvProcessList.TabIndex = 1;
            this.dgvProcessList.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvProcessList_CellValueChanged);
            this.dgvProcessList.CurrentCellDirtyStateChanged += new System.EventHandler(this.DgvProcessList_CurrentCellDirtyStateChanged);
            this.dgvProcessList.SelectionChanged += new System.EventHandler(this.DgvProcessList_SelectionChanged);
            // 
            // _pnlButtons
            // 
            this._pnlButtons.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this._pnlButtons.AutoSize = true;
            this._pnlButtons.Controls.Add(this._btnMoveUp);
            this._pnlButtons.Controls.Add(this._btnMoveDown);
            this._pnlButtons.Controls.Add(this._btnAdd);
            this._pnlButtons.Controls.Add(this._btnRemove);
            this._pnlButtons.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this._pnlButtons.Location = new System.Drawing.Point(56, 337);
            this._pnlButtons.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this._pnlButtons.Name = "_pnlButtons";
            this._pnlButtons.Size = new System.Drawing.Size(70, 159);
            this._pnlButtons.TabIndex = 2;
            // 
            // _btnAdd
            // 
            this._btnAdd.Location = new System.Drawing.Point(0, 92);
            this._btnAdd.Margin = new System.Windows.Forms.Padding(0, 20, 0, 0);
            this._btnAdd.Name = "_btnAdd";
            this._btnAdd.Size = new System.Drawing.Size(70, 31);
            this._btnAdd.TabIndex = 0;
            this._btnAdd.Text = "�s�W";
            this._btnAdd.UseVisualStyleBackColor = true;
            this._btnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // _btnRemove
            // 
            this._btnRemove.Location = new System.Drawing.Point(0, 128);
            this._btnRemove.Margin = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this._btnRemove.Name = "_btnRemove";
            this._btnRemove.Size = new System.Drawing.Size(70, 31);
            this._btnRemove.TabIndex = 1;
            this._btnRemove.Text = "����";
            this._btnRemove.UseVisualStyleBackColor = true;
            this._btnRemove.Click += new System.EventHandler(this.BtnRemove_Click);
            // 
            // _btnMoveUp
            // 
            this._btnMoveUp.Location = new System.Drawing.Point(0, 5);
            this._btnMoveUp.Margin = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this._btnMoveUp.Name = "_btnMoveUp";
            this._btnMoveUp.Size = new System.Drawing.Size(70, 31);
            this._btnMoveUp.TabIndex = 2;
            this._btnMoveUp.Text = "�W��";
            this._btnMoveUp.UseVisualStyleBackColor = true;
            this._btnMoveUp.Click += new System.EventHandler(this.BtnMoveUp_Click);
            // 
            // _btnMoveDown
            // 
            this._btnMoveDown.Location = new System.Drawing.Point(0, 41);
            this._btnMoveDown.Margin = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this._btnMoveDown.Name = "_btnMoveDown";
            this._btnMoveDown.Size = new System.Drawing.Size(70, 31);
            this._btnMoveDown.TabIndex = 3;
            this._btnMoveDown.Text = "�U��";
            this._btnMoveDown.UseVisualStyleBackColor = true;
            this._btnMoveDown.Click += new System.EventHandler(this.BtnMoveDown_Click);
            // 
            // _lblListTitle
            // 
            this._lblListTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this._lblListTitle.Location = new System.Drawing.Point(132, 0);
            this._lblListTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this._lblListTitle.Name = "_lblListTitle";
            this._lblListTitle.Size = new System.Drawing.Size(446, 26);
            this._lblListTitle.TabIndex = 0;
            this._lblListTitle.Text = "�y�{�M��";
            this._lblListTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlEditorHost
            // 
            this.pnlEditorHost.AutoScroll = true;
            this.pnlEditorHost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlEditorHost.Location = new System.Drawing.Point(582, 28);
            this.pnlEditorHost.Margin = new System.Windows.Forms.Padding(2);
            this.pnlEditorHost.Name = "pnlEditorHost";
            this.TLP.SetRowSpan(this.pnlEditorHost, 2);
            this.pnlEditorHost.Size = new System.Drawing.Size(316, 470);
            this.pnlEditorHost.TabIndex = 1;
            // 
            // _lblEditorTitle
            // 
            this._lblEditorTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this._lblEditorTitle.Location = new System.Drawing.Point(582, 0);
            this._lblEditorTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this._lblEditorTitle.Name = "_lblEditorTitle";
            this._lblEditorTitle.Size = new System.Drawing.Size(316, 26);
            this._lblEditorTitle.TabIndex = 0;
            this._lblEditorTitle.Text = "�Ѽƽs��";
            this._lblEditorTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 3;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 320F));
            this.TLP.Controls.Add(this.tvProcessSource, 0, 1);
            this.TLP.Controls.Add(this.dgvProcessList, 1, 1);
            this.TLP.Controls.Add(this._lblEditorTitle, 2, 0);
            this.TLP.Controls.Add(this._lblSourceTitle, 0, 0);
            this.TLP.Controls.Add(this.pnlEditorHost, 2, 1);
            this.TLP.Controls.Add(this._lblListTitle, 1, 0);
            this.TLP.Controls.Add(this._pnlButtons, 0, 2);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 3;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 26F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 170F));
            this.TLP.Size = new System.Drawing.Size(900, 500);
            this.TLP.TabIndex = 1;
            // 
            // ProcessFlowEditorView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.TLP);
            this.Font = new System.Drawing.Font("�L�n������", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ProcessFlowEditorView";
            this.Size = new System.Drawing.Size(900, 500);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProcessList)).EndInit();
            this._pnlButtons.ResumeLayout(false);
            this.TLP.ResumeLayout(false);
            this.TLP.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TableLayoutPanel TLP;
    }
}
