using Calin.LockingMachine.ProcessFlow.Editor;

namespace Calin.LockingMachine.ProcessFlow.UI
{
    /// <summary>
    /// �Ū��s�边�A�Ω���ܨS�������s�边�ɪ����ܡC
    /// </summary>
    public partial class EmptyEditor : ProcessEditorBase
    {
        private string _processId;

        public override string ProcessId => _processId ?? "EMPTY";

        public EmptyEditor()
        {
            InitializeComponent();
        }

        public void SetProcessId(string processId)
        {
            _processId = processId;
            lblMessage.Text = $"�u�� [{processId}] �L�i�Ϊ��Ѽƽs�边";
        }

        public override void Load(string paramJson)
        {
            // �Žs�边���ݭn���J
        }

        public override string Save()
        {
            return "{}";
        }
    }
}
