using Autofac;
using Calin.LockingMachine.ProcessFlow.Core;

namespace Calin.LockingMachine.ProcessFlow.Engine
{
    /// <summary>
    /// �y�{����ƥ�ѼơC
    /// </summary>
    public class ProcessStepExecutingEventArgs : EventArgs
    {
        public ProcessStepEntity Step { get; }
        public int TotalSteps { get; }
        public int CurrentIndex { get; }

        public ProcessStepExecutingEventArgs(ProcessStepEntity step, int totalSteps, int currentIndex)
        {
            Step = step;
            TotalSteps = totalSteps;
            CurrentIndex = currentIndex;
        }
    }

    /// <summary>
    /// �y�{�B�J�����ƥ�ѼơC
    /// </summary>
    public class ProcessStepCompletedEventArgs : EventArgs
    {
        public ProcessStepEntity Step { get; }
        public ProcessExecutionResult Result { get; }
        public int TotalSteps { get; }
        public int CurrentIndex { get; }

        public ProcessStepCompletedEventArgs(ProcessStepEntity step, ProcessExecutionResult result, int totalSteps, int currentIndex)
        {
            Step = step;
            Result = result;
            TotalSteps = totalSteps;
            CurrentIndex = currentIndex;
        }
    }

    /// <summary>
    /// �y�{���浲�G�C
    /// </summary>
    public class ProcessFlowResult
    {
        public bool Success { get; }
        public int TotalSteps { get; }
        public int ExecutedSteps { get; }
        public int FailedStepIndex { get; }
        public string ErrorMessage { get; }
        public Exception Exception { get; }

        private ProcessFlowResult(bool success, int totalSteps, int executedSteps, int failedStepIndex = -1, string errorMessage = null, Exception exception = null)
        {
            Success = success;
            TotalSteps = totalSteps;
            ExecutedSteps = executedSteps;
            FailedStepIndex = failedStepIndex;
            ErrorMessage = errorMessage;
            Exception = exception;
        }

        public static ProcessFlowResult Succeeded(int totalSteps, int executedSteps)
            => new ProcessFlowResult(true, totalSteps, executedSteps);

        public static ProcessFlowResult Failed(int totalSteps, int executedSteps, int failedStepIndex, string errorMessage, Exception exception = null)
            => new ProcessFlowResult(false, totalSteps, executedSteps, failedStepIndex, errorMessage, exception);

        public static ProcessFlowResult Cancelled(int totalSteps, int executedSteps)
            => new ProcessFlowResult(false, totalSteps, executedSteps, -1, "�y�{�w�Q����");
    }

    /// <summary>
    /// �y�{���澹�A�̧ǰ���u�ǡC
    /// </summary>
    /// <remarks>
    /// <para>�� OrderNo �̧ǰ���AEnabled = false ���u�Ƿ|���L�C</para>
    /// <para>�z�L IProcessHandler ����A�䴩 CancellationToken�C</para>
    /// <para>���̿���� UI ���O�C</para>
    /// </remarks>
    public class ProcessRunner
    {
        private readonly ILifetimeScope _scope;

        /// <summary>
        /// �u�Ƕ}�l�����Ĳ�o�C
        /// </summary>
        public event EventHandler<ProcessStepExecutingEventArgs> StepExecuting;

        /// <summary>
        /// �u�ǰ��槹����Ĳ�o�C
        /// </summary>
        public event EventHandler<ProcessStepCompletedEventArgs> StepCompleted;

        public ProcessRunner(ILifetimeScope scope)
        {
            _scope = scope ?? throw new ArgumentNullException(nameof(scope));
        }

        /// <summary>
        /// ����y�{�C
        /// </summary>
        /// <param name="steps">�u�ǨB�J���X�C</param>
        /// <param name="cancellationToken">�����v���C</param>
        /// <returns>�y�{���浲�G�C</returns>
        public async Task<ProcessFlowResult> RunAsync(IEnumerable<ProcessStepEntity> steps, CancellationToken cancellationToken = default)
        {
            if (steps == null)
                throw new ArgumentNullException(nameof(steps));

            var orderedSteps = steps.OrderBy(s => s.OrderNo).ToList();
            var enabledSteps = orderedSteps.Where(s => s.Enabled).ToList();
            var totalSteps = enabledSteps.Count;
            var executedSteps = 0;

            for (int i = 0; i < enabledSteps.Count; i++)
            {
                var step = enabledSteps[i];

                if (cancellationToken.IsCancellationRequested)
                {
                    return ProcessFlowResult.Cancelled(totalSteps, executedSteps);
                }

                try
                {
                    OnStepExecuting(new ProcessStepExecutingEventArgs(step, totalSteps, i));

                    var handler = _scope.ResolveKeyed<IProcessHandler>(step.ProcessId);
                    var result = await handler.ExecuteAsync(step.ParamJson, cancellationToken);

                    OnStepCompleted(new ProcessStepCompletedEventArgs(step, result, totalSteps, i));

                    if (!result.Success)
                    {
                        return ProcessFlowResult.Failed(totalSteps, executedSteps, i, result.ErrorMessage, result.Exception);
                    }

                    executedSteps++;
                }
                catch (OperationCanceledException)
                {
                    return ProcessFlowResult.Cancelled(totalSteps, executedSteps);
                }
                catch (Exception ex)
                {
                    var failedResult = ProcessExecutionResult.Failed(ex);
                    OnStepCompleted(new ProcessStepCompletedEventArgs(step, failedResult, totalSteps, i));
                    return ProcessFlowResult.Failed(totalSteps, executedSteps, i, ex.Message, ex);
                }
            }

            return ProcessFlowResult.Succeeded(totalSteps, executedSteps);
        }

        protected virtual void OnStepExecuting(ProcessStepExecutingEventArgs e)
        {
            StepExecuting?.Invoke(this, e);
        }

        protected virtual void OnStepCompleted(ProcessStepCompletedEventArgs e)
        {
            StepCompleted?.Invoke(this, e);
        }
    }
}
