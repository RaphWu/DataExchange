using Calin.LockingMachine.ProcessFlow.Engine;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Handlers
{
    /// <summary>
    /// ���𵥫ݤu�ǳB�z���C
    /// </summary>
    public class DelayHandler : IProcessHandler
    {
        public async Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken cancellationToken)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<DelayParam>(paramJson);
                if (param == null)
                    return ProcessExecutionResult.Failed("�ѼƸѪR����");

                await Task.Delay(param.DelayMilliseconds, cancellationToken);

                return ProcessExecutionResult.Succeeded();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                return ProcessExecutionResult.Failed(ex);
            }
        }

        public string ValidateParam(string paramJson)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<DelayParam>(paramJson);
                if (param == null)
                    return "�ѼƤ��i����";

                if (param.DelayMilliseconds < 0)
                    return "����ɶ����i���t��";

                return null;
            }
            catch (Exception ex)
            {
                return $"�ѼƮ榡���~: {ex.Message}";
            }
        }
    }
}
