namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    partial class SensorCheckEditor
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblSensorId;
        private System.Windows.Forms.TextBox txtSensorId;
        private System.Windows.Forms.Label lblMinValue;
        private System.Windows.Forms.NumericUpDown numMinValue;
        private System.Windows.Forms.Label lblMaxValue;
        private System.Windows.Forms.NumericUpDown numMaxValue;
        private System.Windows.Forms.Label lblInRange;
        private System.Windows.Forms.ComboBox cmbInRangeAction;
        private System.Windows.Forms.Label lblOutOfRange;
        private System.Windows.Forms.ComboBox cmbOutOfRangeAction;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblSensorId = new System.Windows.Forms.Label();
            this.txtSensorId = new System.Windows.Forms.TextBox();
            this.lblMinValue = new System.Windows.Forms.Label();
            this.numMinValue = new System.Windows.Forms.NumericUpDown();
            this.lblMaxValue = new System.Windows.Forms.Label();
            this.numMaxValue = new System.Windows.Forms.NumericUpDown();
            this.lblInRange = new System.Windows.Forms.Label();
            this.cmbInRangeAction = new System.Windows.Forms.ComboBox();
            this.lblOutOfRange = new System.Windows.Forms.Label();
            this.cmbOutOfRangeAction = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMinValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMaxValue)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.lblSensorId, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtSensorId, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblMinValue, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.numMinValue, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblMaxValue, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.numMaxValue, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblInRange, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.cmbInRangeAction, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblOutOfRange, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.cmbOutOfRangeAction, 1, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(10, 10);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(430, 190);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lblSensorId
            // 
            this.lblSensorId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSensorId.Location = new System.Drawing.Point(3, 0);
            this.lblSensorId.Name = "lblSensorId";
            this.lblSensorId.Size = new System.Drawing.Size(114, 30);
            this.lblSensorId.TabIndex = 0;
            this.lblSensorId.Text = "�P���� ID�G";
            this.lblSensorId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtSensorId
            // 
            this.txtSensorId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSensorId.Location = new System.Drawing.Point(123, 3);
            this.txtSensorId.Name = "txtSensorId";
            this.txtSensorId.Size = new System.Drawing.Size(304, 22);
            this.txtSensorId.TabIndex = 1;
            // 
            // lblMinValue
            // 
            this.lblMinValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMinValue.Location = new System.Drawing.Point(3, 30);
            this.lblMinValue.Name = "lblMinValue";
            this.lblMinValue.Size = new System.Drawing.Size(114, 30);
            this.lblMinValue.TabIndex = 2;
            this.lblMinValue.Text = "�̤p�ȡG";
            this.lblMinValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numMinValue
            // 
            this.numMinValue.DecimalPlaces = 3;
            this.numMinValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numMinValue.Location = new System.Drawing.Point(123, 33);
            this.numMinValue.Maximum = new decimal(new int[] {999999, 0, 0, 0});
            this.numMinValue.Minimum = new decimal(new int[] {999999, 0, 0, -2147483648});
            this.numMinValue.Name = "numMinValue";
            this.numMinValue.Size = new System.Drawing.Size(304, 22);
            this.numMinValue.TabIndex = 3;
            // 
            // lblMaxValue
            // 
            this.lblMaxValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMaxValue.Location = new System.Drawing.Point(3, 60);
            this.lblMaxValue.Name = "lblMaxValue";
            this.lblMaxValue.Size = new System.Drawing.Size(114, 30);
            this.lblMaxValue.TabIndex = 4;
            this.lblMaxValue.Text = "�̤j�ȡG";
            this.lblMaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numMaxValue
            // 
            this.numMaxValue.DecimalPlaces = 3;
            this.numMaxValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numMaxValue.Location = new System.Drawing.Point(123, 63);
            this.numMaxValue.Maximum = new decimal(new int[] {999999, 0, 0, 0});
            this.numMaxValue.Minimum = new decimal(new int[] {999999, 0, 0, -2147483648});
            this.numMaxValue.Name = "numMaxValue";
            this.numMaxValue.Size = new System.Drawing.Size(304, 22);
            this.numMaxValue.TabIndex = 5;
            this.numMaxValue.Value = new decimal(new int[] {100, 0, 0, 0});
            // 
            // lblInRange
            // 
            this.lblInRange.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInRange.Location = new System.Drawing.Point(3, 90);
            this.lblInRange.Name = "lblInRange";
            this.lblInRange.Size = new System.Drawing.Size(114, 30);
            this.lblInRange.TabIndex = 6;
            this.lblInRange.Text = "�d�򤺰ʧ@�G";
            this.lblInRange.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbInRangeAction
            // 
            this.cmbInRangeAction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbInRangeAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInRangeAction.FormattingEnabled = true;
            this.cmbInRangeAction.Location = new System.Drawing.Point(123, 93);
            this.cmbInRangeAction.Name = "cmbInRangeAction";
            this.cmbInRangeAction.Size = new System.Drawing.Size(304, 20);
            this.cmbInRangeAction.TabIndex = 7;
            // 
            // lblOutOfRange
            // 
            this.lblOutOfRange.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblOutOfRange.Location = new System.Drawing.Point(3, 120);
            this.lblOutOfRange.Name = "lblOutOfRange";
            this.lblOutOfRange.Size = new System.Drawing.Size(114, 30);
            this.lblOutOfRange.TabIndex = 8;
            this.lblOutOfRange.Text = "�d��~�ʧ@�G";
            this.lblOutOfRange.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbOutOfRangeAction
            // 
            this.cmbOutOfRangeAction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbOutOfRangeAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOutOfRangeAction.FormattingEnabled = true;
            this.cmbOutOfRangeAction.Location = new System.Drawing.Point(123, 123);
            this.cmbOutOfRangeAction.Name = "cmbOutOfRangeAction";
            this.cmbOutOfRangeAction.Size = new System.Drawing.Size(304, 20);
            this.cmbOutOfRangeAction.TabIndex = 9;
            // 
            // SensorCheckEditor
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "SensorCheckEditor";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.Size = new System.Drawing.Size(450, 210);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numMinValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMaxValue)).EndInit();
            this.ResumeLayout(false);
        }
    }
}
