﻿using Calin.LockingMachine.Models;
using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// 尋邊工序參數編輯器。
    /// </summary>
    public partial class GateMarkSearchEditor : ProcessEditorBase
    {
        private readonly DaqData _daqData;

        public override string ProcessId => ProcessIds.GATE_MARK_SEARCH;

        public GateMarkSearchEditor(DaqData daqData)
        {
            _daqData = daqData;

            InitializeComponent();

            numAngleCompensation.ValueChanged += (s, e) => OnParamChanged();
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new GateMarkSearchParam()
                : JsonConvert.DeserializeObject<GateMarkSearchParam>(paramJson) ?? new GateMarkSearchParam();

            numAngleCompensation.Value = (decimal)param.AngleCompensation;
        }

        public override string Save()
        {
            var param = new GateMarkSearchParam
            {
                AngleCompensation = (double)numAngleCompensation.Value
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            return null;
        }
    }
}
