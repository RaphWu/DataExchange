﻿using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// Z軸移動參數編輯器。
    /// </summary>
    public partial class ZAxisMoveEditor : ProcessEditorBase
    {
        public override string ProcessId => ProcessIds.Z_AXIS_MOVE;

        public ZAxisMoveEditor()
        {
            InitializeComponent();

            // 將 UI 事件接到基底的 ParamChanged
            cbHome.CheckedChanged += (s, e) => OnParamChanged();
            cbSafetyHeight.CheckedChanged += (s, e) => OnParamChanged();
            rbAbs.CheckedChanged += (s, e) => OnParamChanged();
            rbRes.CheckedChanged += (s, e) => OnParamChanged();
            numTargetPosition.ValueChanged += (s, e) => OnParamChanged();
            numSpeed.ValueChanged += (s, e) => OnParamChanged();
            numAcceleration.ValueChanged += (s, e) => OnParamChanged();
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new ZAxisMoveParam()
                : JsonConvert.DeserializeObject<ZAxisMoveParam>(paramJson) ?? new ZAxisMoveParam();

            cbHome.Checked = param.IsHome;
            cbSafetyHeight.Checked = param.IsSafetyHeight;
            if (param.IsAbsolute)
                rbAbs.Checked = true;
            else
                rbRes.Checked = true;
            numTargetPosition.Value = (decimal)param.TargetPosition;
            numSpeed.Value = (decimal)param.Speed;
            numAcceleration.Value = (decimal)param.Acceleration;
        }

        public override string Save()
        {
            var param = new ZAxisMoveParam
            {
                AxisId = "Z",
                IsHome = cbHome.Checked,
                IsSafetyHeight = cbSafetyHeight.Checked,
                IsAbsolute = rbAbs.Checked,
                TargetPosition = (double)numTargetPosition.Value,
                Speed = (double)numSpeed.Value,
                Acceleration = (double)numAcceleration.Value
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (numSpeed.Value <= 0)
                return "速度必須大於 0";

            if (numAcceleration.Value <= 0)
                return "加速度必須大於 0";

            return null;
        }

        private void cbHome_Click(object sender, EventArgs e)
        {

        }

        private void cbSafetyHeight_Click(object sender, EventArgs e)
        {

        }

        private void cbHome_CheckedChanged(object sender, EventArgs e)
        {
            if (cbHome.Checked)
                cbSafetyHeight.Checked = false;

            cbSafetyHeight.Enabled = !cbHome.Checked;
            gbMoveParams.Enabled = !cbHome.Checked;
        }

        private void cbSafetyHeight_CheckedChanged(object sender, EventArgs e)
        {
            if (cbSafetyHeight.Checked)
                cbHome.Checked = false;

            cbHome.Enabled = !cbSafetyHeight.Checked;
            gbMoveParams.Enabled = !cbSafetyHeight.Checked;
        }
    }
}
