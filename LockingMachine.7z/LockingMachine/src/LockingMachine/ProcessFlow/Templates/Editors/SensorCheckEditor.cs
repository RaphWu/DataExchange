using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// �P�����d��P�_�Ѽƽs�边�C
    /// </summary>
    public partial class SensorCheckEditor : ProcessEditorBase
    {
        public override string ProcessId => ProcessIds.HEIGHT_DISPLACEMENT;

        public SensorCheckEditor()
        {
            InitializeComponent();

            // �U�Կ�涵��
            cmbInRangeAction.Items.Clear();
            cmbInRangeAction.Items.AddRange(new object[]
            {
                new ActionItem(SensorCheckAction.None, "�L�ʧ@"),
                new ActionItem(SensorCheckAction.Continue, "�~��y�{"),
                new ActionItem(SensorCheckAction.StopFlow, "����y�{"),
                new ActionItem(SensorCheckAction.TriggerAlarm, "Ĳ�oĵ��")
            });
            cmbInRangeAction.DisplayMember = "DisplayName";

            cmbOutOfRangeAction.Items.Clear();
            cmbOutOfRangeAction.Items.AddRange(new object[]
            {
                new ActionItem(SensorCheckAction.None, "�L�ʧ@"),
                new ActionItem(SensorCheckAction.Continue, "�~��y�{"),
                new ActionItem(SensorCheckAction.StopFlow, "����y�{"),
                new ActionItem(SensorCheckAction.TriggerAlarm, "Ĳ�oĵ��")
            });
            cmbOutOfRangeAction.DisplayMember = "DisplayName";

            // �ƥ�ô��
            txtSensorId.TextChanged += (s, e) => OnParamChanged();
            numMinValue.ValueChanged += (s, e) => OnParamChanged();
            numMaxValue.ValueChanged += (s, e) => OnParamChanged();
            cmbInRangeAction.SelectedIndexChanged += (s, e) => OnParamChanged();
            cmbOutOfRangeAction.SelectedIndexChanged += (s, e) => OnParamChanged();

            if (cmbInRangeAction.Items.Count > 0 && cmbInRangeAction.SelectedIndex < 0)
                cmbInRangeAction.SelectedIndex = 0;
            if (cmbOutOfRangeAction.Items.Count > 0 && cmbOutOfRangeAction.SelectedIndex < 0)
                cmbOutOfRangeAction.SelectedIndex = 0;
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new SensorCheckParam()
                : JsonConvert.DeserializeObject<SensorCheckParam>(paramJson) ?? new SensorCheckParam();

            txtSensorId.Text = param.SensorId ?? "SENSOR_01";
            numMinValue.Value = (decimal)param.MinValue;
            numMaxValue.Value = (decimal)param.MaxValue;

            SelectActionItem(cmbInRangeAction, param.InRangeAction);
            SelectActionItem(cmbOutOfRangeAction, param.OutOfRangeAction);
        }

        public override string Save()
        {
            var param = new SensorCheckParam
            {
                SensorId = txtSensorId.Text,
                MinValue = (double)numMinValue.Value,
                MaxValue = (double)numMaxValue.Value,
                InRangeAction = GetSelectedAction(cmbInRangeAction),
                OutOfRangeAction = GetSelectedAction(cmbOutOfRangeAction)
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (string.IsNullOrWhiteSpace(txtSensorId.Text))
                return "�P���� ID ���i����";

            if (numMinValue.Value > numMaxValue.Value)
                return "�̤p�Ȥ��i�j��̤j��";

            return null;
        }

        private void SelectActionItem(ComboBox comboBox, SensorCheckAction action)
        {
            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                if (comboBox.Items[i] is ActionItem item && item.Action == action)
                {
                    comboBox.SelectedIndex = i;
                    return;
                }
            }
            if (comboBox.Items.Count > 0)
                comboBox.SelectedIndex = 0;
        }

        private SensorCheckAction GetSelectedAction(ComboBox comboBox)
        {
            return (comboBox.SelectedItem as ActionItem)?.Action ?? SensorCheckAction.None;
        }

        private class ActionItem
        {
            public SensorCheckAction Action { get; }
            public string DisplayName { get; }

            public ActionItem(SensorCheckAction action, string displayName)
            {
                Action = action;
                DisplayName = displayName;
            }

            public override string ToString() => DisplayName;
        }
    }
}
