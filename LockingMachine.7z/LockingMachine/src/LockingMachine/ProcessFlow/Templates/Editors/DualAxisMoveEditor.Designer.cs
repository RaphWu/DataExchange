﻿namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    partial class DualAxisMoveEditor
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.gbAxis1MoveParams = new System.Windows.Forms.GroupBox();
            this.rbAxis1Res = new System.Windows.Forms.RadioButton();
            this.rbAxis1Abs = new System.Windows.Forms.RadioButton();
            this.numAxis1TargetPosition = new System.Windows.Forms.NumericUpDown();
            this.lblAxis1TargetPosition = new System.Windows.Forms.Label();
            this.numAxis1Acceleration = new System.Windows.Forms.NumericUpDown();
            this.lblAxis1Acceleration = new System.Windows.Forms.Label();
            this.lblAxis1Speed = new System.Windows.Forms.Label();
            this.numAxis1Speed = new System.Windows.Forms.NumericUpDown();
            this.gbAxis2MoveParams = new System.Windows.Forms.GroupBox();
            this.rbAxis2Res = new System.Windows.Forms.RadioButton();
            this.rbAxis2Abs = new System.Windows.Forms.RadioButton();
            this.numAxis2TargetAngle = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.numAxis2Acceleration = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numAxis2Speed = new System.Windows.Forms.NumericUpDown();
            this.cbDualAxisHome = new System.Windows.Forms.CheckBox();
            this.gbAxis1MoveParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis1TargetPosition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis1Acceleration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis1Speed)).BeginInit();
            this.gbAxis2MoveParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis2TargetAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis2Acceleration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis2Speed)).BeginInit();
            this.SuspendLayout();
            // 
            // gbAxis1MoveParams
            // 
            this.gbAxis1MoveParams.Controls.Add(this.rbAxis1Res);
            this.gbAxis1MoveParams.Controls.Add(this.rbAxis1Abs);
            this.gbAxis1MoveParams.Controls.Add(this.numAxis1TargetPosition);
            this.gbAxis1MoveParams.Controls.Add(this.lblAxis1TargetPosition);
            this.gbAxis1MoveParams.Controls.Add(this.numAxis1Acceleration);
            this.gbAxis1MoveParams.Controls.Add(this.lblAxis1Acceleration);
            this.gbAxis1MoveParams.Controls.Add(this.lblAxis1Speed);
            this.gbAxis1MoveParams.Controls.Add(this.numAxis1Speed);
            this.gbAxis1MoveParams.Location = new System.Drawing.Point(15, 45);
            this.gbAxis1MoveParams.Name = "gbAxis1MoveParams";
            this.gbAxis1MoveParams.Size = new System.Drawing.Size(290, 160);
            this.gbAxis1MoveParams.TabIndex = 12;
            this.gbAxis1MoveParams.TabStop = false;
            this.gbAxis1MoveParams.Text = "Z軸移動參數";
            // 
            // rbAxis1Res
            // 
            this.rbAxis1Res.AutoSize = true;
            this.rbAxis1Res.Location = new System.Drawing.Point(148, 32);
            this.rbAxis1Res.Name = "rbAxis1Res";
            this.rbAxis1Res.Size = new System.Drawing.Size(73, 20);
            this.rbAxis1Res.TabIndex = 9;
            this.rbAxis1Res.TabStop = true;
            this.rbAxis1Res.Text = "相對位置";
            this.rbAxis1Res.UseVisualStyleBackColor = true;
            // 
            // rbAxis1Abs
            // 
            this.rbAxis1Abs.AutoSize = true;
            this.rbAxis1Abs.Checked = true;
            this.rbAxis1Abs.Location = new System.Drawing.Point(49, 32);
            this.rbAxis1Abs.Name = "rbAxis1Abs";
            this.rbAxis1Abs.Size = new System.Drawing.Size(73, 20);
            this.rbAxis1Abs.TabIndex = 8;
            this.rbAxis1Abs.TabStop = true;
            this.rbAxis1Abs.Text = "絕對位置";
            this.rbAxis1Abs.UseVisualStyleBackColor = true;
            // 
            // numAxis1TargetPosition
            // 
            this.numAxis1TargetPosition.DecimalPlaces = 3;
            this.numAxis1TargetPosition.Location = new System.Drawing.Point(124, 65);
            this.numAxis1TargetPosition.Margin = new System.Windows.Forms.Padding(4);
            this.numAxis1TargetPosition.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numAxis1TargetPosition.Name = "numAxis1TargetPosition";
            this.numAxis1TargetPosition.Size = new System.Drawing.Size(135, 23);
            this.numAxis1TargetPosition.TabIndex = 3;
            // 
            // lblAxis1TargetPosition
            // 
            this.lblAxis1TargetPosition.Location = new System.Drawing.Point(24, 63);
            this.lblAxis1TargetPosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAxis1TargetPosition.Name = "lblAxis1TargetPosition";
            this.lblAxis1TargetPosition.Size = new System.Drawing.Size(92, 25);
            this.lblAxis1TargetPosition.TabIndex = 2;
            this.lblAxis1TargetPosition.Text = "目標座標";
            this.lblAxis1TargetPosition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numAxis1Acceleration
            // 
            this.numAxis1Acceleration.DecimalPlaces = 1;
            this.numAxis1Acceleration.Location = new System.Drawing.Point(124, 115);
            this.numAxis1Acceleration.Margin = new System.Windows.Forms.Padding(4);
            this.numAxis1Acceleration.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.numAxis1Acceleration.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numAxis1Acceleration.Name = "numAxis1Acceleration";
            this.numAxis1Acceleration.Size = new System.Drawing.Size(135, 23);
            this.numAxis1Acceleration.TabIndex = 7;
            this.numAxis1Acceleration.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // lblAxis1Acceleration
            // 
            this.lblAxis1Acceleration.Location = new System.Drawing.Point(24, 113);
            this.lblAxis1Acceleration.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAxis1Acceleration.Name = "lblAxis1Acceleration";
            this.lblAxis1Acceleration.Size = new System.Drawing.Size(92, 25);
            this.lblAxis1Acceleration.TabIndex = 6;
            this.lblAxis1Acceleration.Text = "加速度 (mm/s²)";
            this.lblAxis1Acceleration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAxis1Speed
            // 
            this.lblAxis1Speed.Location = new System.Drawing.Point(24, 88);
            this.lblAxis1Speed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAxis1Speed.Name = "lblAxis1Speed";
            this.lblAxis1Speed.Size = new System.Drawing.Size(92, 25);
            this.lblAxis1Speed.TabIndex = 4;
            this.lblAxis1Speed.Text = "速度 (mm/s)";
            this.lblAxis1Speed.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numAxis1Speed
            // 
            this.numAxis1Speed.DecimalPlaces = 1;
            this.numAxis1Speed.Location = new System.Drawing.Point(124, 90);
            this.numAxis1Speed.Margin = new System.Windows.Forms.Padding(4);
            this.numAxis1Speed.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numAxis1Speed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numAxis1Speed.Name = "numAxis1Speed";
            this.numAxis1Speed.Size = new System.Drawing.Size(135, 23);
            this.numAxis1Speed.TabIndex = 5;
            this.numAxis1Speed.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // gbAxis2MoveParams
            // 
            this.gbAxis2MoveParams.Controls.Add(this.rbAxis2Res);
            this.gbAxis2MoveParams.Controls.Add(this.rbAxis2Abs);
            this.gbAxis2MoveParams.Controls.Add(this.numAxis2TargetAngle);
            this.gbAxis2MoveParams.Controls.Add(this.label1);
            this.gbAxis2MoveParams.Controls.Add(this.numAxis2Acceleration);
            this.gbAxis2MoveParams.Controls.Add(this.label2);
            this.gbAxis2MoveParams.Controls.Add(this.label3);
            this.gbAxis2MoveParams.Controls.Add(this.numAxis2Speed);
            this.gbAxis2MoveParams.Location = new System.Drawing.Point(15, 225);
            this.gbAxis2MoveParams.Name = "gbAxis2MoveParams";
            this.gbAxis2MoveParams.Size = new System.Drawing.Size(290, 160);
            this.gbAxis2MoveParams.TabIndex = 13;
            this.gbAxis2MoveParams.TabStop = false;
            this.gbAxis2MoveParams.Text = "R軸移動參數";
            // 
            // rbAxis2Res
            // 
            this.rbAxis2Res.AutoSize = true;
            this.rbAxis2Res.Location = new System.Drawing.Point(148, 32);
            this.rbAxis2Res.Name = "rbAxis2Res";
            this.rbAxis2Res.Size = new System.Drawing.Size(73, 20);
            this.rbAxis2Res.TabIndex = 9;
            this.rbAxis2Res.TabStop = true;
            this.rbAxis2Res.Text = "相對位置";
            this.rbAxis2Res.UseVisualStyleBackColor = true;
            // 
            // rbAxis2Abs
            // 
            this.rbAxis2Abs.AutoSize = true;
            this.rbAxis2Abs.Checked = true;
            this.rbAxis2Abs.Location = new System.Drawing.Point(49, 32);
            this.rbAxis2Abs.Name = "rbAxis2Abs";
            this.rbAxis2Abs.Size = new System.Drawing.Size(73, 20);
            this.rbAxis2Abs.TabIndex = 8;
            this.rbAxis2Abs.TabStop = true;
            this.rbAxis2Abs.Text = "絕對位置";
            this.rbAxis2Abs.UseVisualStyleBackColor = true;
            // 
            // numAxis2TargetAngle
            // 
            this.numAxis2TargetAngle.DecimalPlaces = 3;
            this.numAxis2TargetAngle.Location = new System.Drawing.Point(124, 65);
            this.numAxis2TargetAngle.Margin = new System.Windows.Forms.Padding(4);
            this.numAxis2TargetAngle.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numAxis2TargetAngle.Name = "numAxis2TargetAngle";
            this.numAxis2TargetAngle.Size = new System.Drawing.Size(135, 23);
            this.numAxis2TargetAngle.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(24, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "目標角度";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numAxis2Acceleration
            // 
            this.numAxis2Acceleration.DecimalPlaces = 1;
            this.numAxis2Acceleration.Location = new System.Drawing.Point(124, 115);
            this.numAxis2Acceleration.Margin = new System.Windows.Forms.Padding(4);
            this.numAxis2Acceleration.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
            this.numAxis2Acceleration.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numAxis2Acceleration.Name = "numAxis2Acceleration";
            this.numAxis2Acceleration.Size = new System.Drawing.Size(135, 23);
            this.numAxis2Acceleration.TabIndex = 7;
            this.numAxis2Acceleration.Value = new decimal(new int[] {
            500,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(24, 113);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "加速度 (mm/s²)";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(24, 88);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "速度 (mm/s)";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numAxis2Speed
            // 
            this.numAxis2Speed.DecimalPlaces = 1;
            this.numAxis2Speed.Location = new System.Drawing.Point(124, 90);
            this.numAxis2Speed.Margin = new System.Windows.Forms.Padding(4);
            this.numAxis2Speed.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numAxis2Speed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numAxis2Speed.Name = "numAxis2Speed";
            this.numAxis2Speed.Size = new System.Drawing.Size(135, 23);
            this.numAxis2Speed.TabIndex = 5;
            this.numAxis2Speed.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // cbDualAxisHome
            // 
            this.cbDualAxisHome.AutoSize = true;
            this.cbDualAxisHome.Location = new System.Drawing.Point(20, 15);
            this.cbDualAxisHome.Name = "cbDualAxisHome";
            this.cbDualAxisHome.Size = new System.Drawing.Size(86, 20);
            this.cbDualAxisHome.TabIndex = 14;
            this.cbDualAxisHome.Text = "兩軸回原點";
            this.cbDualAxisHome.UseVisualStyleBackColor = true;
            this.cbDualAxisHome.CheckedChanged += new System.EventHandler(this.cbDualAxisHome_CheckedChanged);
            // 
            // DualAxisMoveEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cbDualAxisHome);
            this.Controls.Add(this.gbAxis2MoveParams);
            this.Controls.Add(this.gbAxis1MoveParams);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "DualAxisMoveEditor";
            this.Size = new System.Drawing.Size(320, 430);
            this.gbAxis1MoveParams.ResumeLayout(false);
            this.gbAxis1MoveParams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis1TargetPosition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis1Acceleration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis1Speed)).EndInit();
            this.gbAxis2MoveParams.ResumeLayout(false);
            this.gbAxis2MoveParams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis2TargetAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis2Acceleration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAxis2Speed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox gbAxis1MoveParams;
        private RadioButton rbAxis1Res;
        private RadioButton rbAxis1Abs;
        private NumericUpDown numAxis1TargetPosition;
        private Label lblAxis1TargetPosition;
        private NumericUpDown numAxis1Acceleration;
        private Label lblAxis1Acceleration;
        private Label lblAxis1Speed;
        private NumericUpDown numAxis1Speed;
        private GroupBox gbAxis2MoveParams;
        private RadioButton rbAxis2Res;
        private RadioButton rbAxis2Abs;
        private NumericUpDown numAxis2TargetAngle;
        private Label label1;
        private NumericUpDown numAxis2Acceleration;
        private Label label2;
        private Label label3;
        private NumericUpDown numAxis2Speed;
        private CheckBox cbDualAxisHome;
    }
}
