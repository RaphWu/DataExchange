using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// ���𵥫ݰѼƽs�边�C
    /// </summary>
    public partial class DelayEditor : ProcessEditorBase
    {
        public override string ProcessId => ProcessIds.DELAY;

        public DelayEditor()
        {
            InitializeComponent();

            numDelayMs.ValueChanged += (s, e) => OnParamChanged();
            txtDescription.TextChanged += (s, e) => OnParamChanged();
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new DelayParam()
                : JsonConvert.DeserializeObject<DelayParam>(paramJson) ?? new DelayParam();

            numDelayMs.Value = param.DelayMilliseconds;
            txtDescription.Text = param.Description ?? "";
        }

        public override string Save()
        {
            var param = new DelayParam
            {
                DelayMilliseconds = (int)numDelayMs.Value,
                Description = txtDescription.Text
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (numDelayMs.Value < 0)
                return "����ɶ����i���t��";

            return null;
        }
    }
}
