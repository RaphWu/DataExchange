﻿using System;
using System.Diagnostics;
using System.Threading;
using Calin.Extensions;

namespace Calin.LockingMachine.Services
{
    public partial class LockingMachineService
    {
        #region Fields

        private CancellationTokenSource _pollingCts;
        private Thread _acquisitionThread;
        private Thread _monitoringThread;
        //private readonly System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();

        private byte diValue = 0;

        #endregion Fields

        #region Methods

        /// <inheritdoc/>
        public void PollingStop()
        {
            // 先發出取消請求
            _pollingCts?.Cancel();

            // 等待執行緒結束（最多等待 2 秒），如果沒結束再嘗試 Interrupt
            if (_acquisitionThread != null)
            {
                try
                {
                    if (!_acquisitionThread.Join(2000))
                    {
                        // 若執行緒在 Sleep/Wait/Join 中，Interrupt 會拋出 ThreadInterruptedException
                        _acquisitionThread.Interrupt();
                        _acquisitionThread.Join(500);
                    }
                }
                catch (ThreadInterruptedException)
                {
                    // 預期可能發生，忽略
                }
                catch (Exception)
                {
                    // Log／忽略其他例外（視需求處理）
                }
                finally
                {
                    _acquisitionThread = null;
                }
            }

            // 等待執行緒結束（最多等待 2 秒），如果沒結束再嘗試 Interrupt
            if (_monitoringThread != null)
            {
                try
                {
                    if (!_monitoringThread.Join(2000))
                    {
                        // 若執行緒在 Sleep/Wait/Join 中，Interrupt 會拋出 ThreadInterruptedException
                        _monitoringThread.Interrupt();
                        _monitoringThread.Join(500);
                    }
                }
                catch (ThreadInterruptedException)
                {
                    // 預期可能發生，忽略
                }
                catch (Exception)
                {
                    // Log／忽略其他例外（視需求處理）
                }
                finally
                {
                    _monitoringThread = null;
                }
            }

            // 釋放 CancellationTokenSource
            _pollingCts?.Dispose();
            _pollingCts = null;

            // 停用並釋放 Timer
            //_timer.Stop();
            //_timer.Tick -= Monitoring_Tick;
            //_timer.Dispose();
        }

        /// <inheritdoc/>
        public void PollingStart()
        {
            _pollingCts = new CancellationTokenSource();

            //_acquisitionThread = new Thread(() => AcquisitionProc(_pollingCts.Token));
            //_acquisitionThread.Name = "Data Acquisition Thread";
            //_acquisitionThread.IsBackground = true;
            //_acquisitionThread.Priority = ThreadPriority.Highest;
            //_acquisitionThread.Start();

            _monitoringThread = new Thread(() => MonitoringProc(_pollingCts.Token));
            _monitoringThread.Name = "Data Acquisition Thread";
            _monitoringThread.IsBackground = true;
            _monitoringThread.Priority = ThreadPriority.Highest;
            _monitoringThread.Start();

            //_timer.Interval = 50;
            //_timer.Tick += Monitoring_Tick;
            //_timer.Start();
        }

        #endregion Methods

        #region Polling Procedures

        //private void AcquisitionProc(CancellationToken token)
        //{
        //    var sw = Stopwatch.StartNew();
        //    long ticksPerMs = Stopwatch.Frequency / 1000;
        //    long nextTick = sw.ElapsedTicks;
        //    var spin = new SpinWait();

        //    while (!token.IsCancellationRequested)
        //    {
        //        long now = sw.ElapsedTicks;
        //        if (now >= nextTick)
        //        {
        //            nextTick += ticksPerMs;
        //            spin.Reset();

        //            // 用於須快速反應的停止條件
        //            //if (torque >= TorqueLimit)
        //            //{
        //            //    EmergencyStop();
        //            //}
        //        }
        //        else
        //        {
        //            spin.SpinOnce();
        //        }
        //    }
        //}

        private void MonitoringProc(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                // 高度計
                if (_bindingData.HeightDisplacementActive)
                {
                    // PS:程式啟動時第一次讀取常常沒回應，原因待查
                    if (_rawData.WaitForReceiveHeightDisplacement++ > 0)
                    {
                        // 若50次循環都沒收到回應，重新發出讀取指令
                        if (_rawData.WaitForReceiveHeightDisplacement > 50)
                            _rawData.WaitForReceiveHeightDisplacement = 0;
                    }
                    else
                    {
#if DEBUG
                        _dispStopwatch.Restart();
#endif
                        _lmData.dlrs1a.ReadValue();
                        //ThreadExt.RunOnUiThread(() => { _lmData.dlrs1a.ReadAll(); });
                    }
                }

                // USB4704 DI
                if (_bindingData.DaqIoActive)
                {
                    if (_lmData.dio.ReadDigital(0, out diValue))
                    {
                        ThreadExt.RunOnUiThread(() =>
                        {
                            _rawData.DI0 = (diValue & 0x01) != 0;
                            _rawData.DI1 = (diValue & 0x02) != 0;
                            _rawData.DI2 = (diValue & 0x04) != 0;
                            _rawData.DI3 = (diValue & 0x08) != 0;
                            _rawData.DI4 = (diValue & 0x10) != 0;
                            _rawData.DI5 = (diValue & 0x20) != 0;
                            _rawData.DI6 = (diValue & 0x40) != 0;
                            _rawData.DI7 = (diValue & 0x80) != 0;
                        });
                    }
                }

                Thread.Sleep(20);
            }
        }

        #endregion Polling Procedures
    }
}
