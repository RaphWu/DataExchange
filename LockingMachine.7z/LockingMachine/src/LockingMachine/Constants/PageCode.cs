﻿namespace Calin.LockingMachine.Constants
{
    public enum PageCode
    {
        None,

        MainPage,
        ProcessFlow,
        Monitor,
        Setup,
    }
}
