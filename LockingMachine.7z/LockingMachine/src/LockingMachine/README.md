﻿# Calin.LockingMachine

Calin.LockingMachine 是一個鎖付機的控制程式。

# 使用框架

- WinForm
- .NET Framework 4.8

# NuGet 依賴

- AutoFac
- Calin v0.0.1

# 主要功能

# 選單規劃

```mermaid
mindmap
主選單
    主控頁
        扭力/高度/速度
        作業數量 (總/OK/NG)
        作業時間
        Cycle Time
    作業設定
        扭力/高度/速度規格
        檔案存取
    即時監控
        伺服軸
        扭力計
        測高計
        IO 狀態
    設定
        運動軸卡設定
        扭力計設定
        測高計設定
        使用者管理
```

## 參數

### 扭力(kgf/cm)

- 作業參數
  - 上限
  - 下限
  - 目前扭力
  - 峰值
  - 判定
- 扭力計參數
  - DAQ參數
    - 取樣頻率
    - 量測點數
    - 濾波設定
  - 轉速
  - 時間
      - Suck
      - Cylinder
      - Screw fail
      - Screw holding

### 高度(mm)

### Barrel角度(°)

- 量測角度

### 速度(RPM)

- 設定值
- 目前轉速

## 工序

### 軸移動

#### Z軸移動

```mermaid
graph TD
  Start(開始) --> Home{回原點}
  Home -- 是 --> GoHome[原點復歸]
    GoHome --> End
  Home -- 否 --> Saft{回安全高度}
    Saft -- 是 --> IsSafty{已在安全高度之上}
      IsSafty -- 是 --> End
      IsSafty -- 否 --> MoveToSafty[回安全高度]
      MoveToSafty --> End
    Saft -- 否 --> ReadParam[讀取參數]
      ReadParam --> IsCylinderExtend{目標在安全高度之下<br/>且氣缸已伸出}
        IsCylinderExtend -- 是 --> Alert[警報]
          Alert --> End
        IsCylinderExtend -- 否 --> MoveToTarget[移動至目標高度]
      MoveToTarget --> End(結束)
```

#### R軸旋轉

```mermaid
graph TD
  Start(開始) --> SaftZ{Z軸在安全高度之上}
  SaftZ -- 是 --> Home{回原點}
    Home -- 是 --> GoHome[原點復歸]
      GoHome --> End
    Home -- 否 --> ReadParam[讀取參數]
      ReadParam --> MoveToAngle[移動至目標角度]
      MoveToAngle --> End
  SaftZ -- 否 --> Alert[警報]
  Alert --> End(結束)
```

#### 兩軸移動

```mermaid
graph TD
  Start(開始) --> SaftZ{Z軸在安全高度之上}
  SaftZ -- 是 --> Home{回原點}
    Home -- 是 --> GoHome[原點復歸]
      GoHome --> End
    Home -- 否 --> ReadParam[讀取參數]
      ReadParam --> MoveToAngle[移動至目標角度]
      MoveToAngle --> End
  SaftZ -- 否 --> Alert[警報]
  Alert --> End(結束)
```
