﻿using Autofac;

namespace TaskPulse.ToolQuest
{
    public class ToolQuestModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<ToolQuestControl>().AsSelf();
        }
    }
}
