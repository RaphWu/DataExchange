﻿using System;
using System.IO;
using System.Windows.Forms;
using TaskPulse.MaintiFlow.Models;
using TaskPulse.MaintiFlow.Utility;
using Zuby.ADGV;

namespace TaskPulse.MaintiFlow
{
    public partial class MaintiFlowControl : UserControl
    {
        BindingSource bs = new BindingSource();

        public MaintiFlowControl()
        {
            InitializeComponent();

            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            adgv.SetDoubleBuffered();
            adgv.CleanFilter();

#if DEBUG
            //LoadCsvFromFileName(@"..\..\..\..\..\docs\\範本\A - 工具設計 - 設備維修履歷.csv");
#else
            LoadCsvFromFileName(@"A - 工具設計 - 設備維修履歷.csv");
#endif
        }

        private void LoadCsvFromFileName(string fileName)
        {
            //var (isSuccess, newHistory, newHistorty_MaintenanceEmployee, newHistory_IssueCategory) = Csv.LoadCsv(fileName);
            var newHistory = Csv.LoadCsv(fileName);
            //if (isSuccess)
            //{
            MainDB.history = newHistory;
            //MainDB.historty_MaintenanceEmployees = newHistorty_MaintenanceEmployee;
            //MainDB.history_IssueCategories = newHistory_IssueCategory;

            bs = new BindingSource();
            //DataTable dt = CollectionExtension.ToDataTable(MainDB.history);
            //bs.DataSource = dt;
            adgv.DataSource = MainDB.history;
            SetDataGridView();
            //}
        }

        private void LoadCsvFromDialog()
        {
            using (OpenFileDialog openDialog = new OpenFileDialog())
            {
                try
                {
                    openDialog.Title = "選取維護履歷csv格式檔";
                    openDialog.Filter = "CSV 檔案 (*.csv)|*.csv|所有檔案 (*.*)|*.*";
                    openDialog.DefaultExt = "csv";
                    openDialog.CheckPathExists = true;
                    openDialog.CheckFileExists = true;
                    openDialog.InitialDirectory = Directory.GetCurrentDirectory();

                    if (openDialog.ShowDialog() == DialogResult.OK)
                        LoadCsvFromFileName(openDialog.FileName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        internal void SetDataGridView()
        {
            DataGridViewColumn col;

            //adgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            adgv.FilterAndSortEnabled = true;
            foreach (DataGridViewColumn column in adgv.Columns)
            {
                column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                column.SortMode = DataGridViewColumnSortMode.Automatic;
                adgv.SetSortEnabled(column, true);
                adgv.SetFilterEnabled(column, true);
            }

            col = adgv.Columns[nameof(History.SerNo)];
            col.HeaderText = "序號";
            adgv.SortDESC(col);

            col = adgv.Columns[nameof(History.WorkOrderNo)];
            col.HeaderText = "維護工單";

            col = adgv.Columns[nameof(History.Creator)];
            col.HeaderText = "建檔人員";

            col = adgv.Columns[nameof(History.Date)];
            col.HeaderText = "建檔日期";

            col = adgv.Columns[nameof(History.MaintenanceUnit)];
            col.HeaderText = "維護單位";

            col = adgv.Columns[nameof(History.MachineNo)];
            col.HeaderText = "機台編號";

            col = adgv.Columns[nameof(History.AcceptedTime)];
            col.HeaderText = "接收時間";
            col.DefaultCellStyle.Format = "yyyy-MM-dd HH:mm";

            col = adgv.Columns[nameof(History.RepairStarted)];
            col.HeaderText = "維護開始時間";
            col.DefaultCellStyle.Format = "yyyy-MM-dd HH:mm";

            col = adgv.Columns[nameof(History.CompletedTime)];
            col.HeaderText = "維護完成時間";
            col.DefaultCellStyle.Format = "yyyy-MM-dd HH:mm";

            col = adgv.Columns[nameof(History.OutageStarted)];
            col.HeaderText = "停動開始";
            col.DefaultCellStyle.Format = "yyyy-MM-dd HH:mm";

            col = adgv.Columns[nameof(History.OutageEnded)];
            col.HeaderText = "停動結束";
            col.DefaultCellStyle.Format = "yyyy-MM-dd HH:mm";

            col = adgv.Columns[nameof(History.Responsible)];
            col.HeaderText = "責任歸屬";

            col = adgv.Columns[nameof(History.Model)];
            col.HeaderText = "機種";

            col = adgv.Columns[nameof(History.Workstation)];
            col.HeaderText = "工站";

            col = adgv.Columns[nameof(History.IssueDescription)];
            col.HeaderText = "問題描述";

            col = adgv.Columns[nameof(History.Details)];
            col.HeaderText = "內容說明";

            col = adgv.Columns[nameof(History.RequestingUnit)];
            col.HeaderText = "需求單位名稱";

            col = adgv.Columns[nameof(History.RequestingEmployee)];
            col.HeaderText = "需求單位人員";

            col = adgv.Columns[nameof(History.RequestingUnitConfirmation)];
            col.HeaderText = "需求單位確認";

            col = adgv.Columns[nameof(History.RequestingUnitResponse)];
            col.HeaderText = "需求單位回覆";
        }
    }
}
