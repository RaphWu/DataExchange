﻿using System;
using System.Data;
using System.IO;
using System.Text;
using TaskPulse.MaintiFlow.Models;

namespace TaskPulse.MaintiFlow.Utility
{
    /// <summary>
    /// CSV檔案操作。
    /// </summary>
    internal static class Csv
    {
        /// <summary>
        /// 讀取維護履的CSV格式檔。
        /// </summary>
        /// <returns>isSuccess: 是否讀取成功。<br />newHistory: 讀取的新履歷。</returns>
        //internal static (bool isSuccess, DataTable newHistory, DataTable newHM, DataTable newHI) LoadCsv(string fileName)
        internal static DataTable LoadCsv(string fileName)
        {
            bool isSuccess = false;
            var history = new DataTable();
            var hm = new DataTable();
            var hi = new DataTable();

            try
            {
                int recCount = 1;
                MainDB.Init(history);

                using (var sr = new StreamReader(fileName, Encoding.UTF8))
                {
                    isSuccess = false;

                    while (sr.Peek() != -1)
                    {
                        string[] data = sr.ReadLine().Split(',');

                        if (recCount > 1) // 去掉標題
                        {
                            var workOrderNo = data[1].Trim();

                            DateTime date;
                            bool parseOk_Date = DateTime.TryParse(data[3], out date);
                            DateTime acceptedTime;
                            bool parseOk_AcceptedTime = DateTime.TryParse(data[7], out acceptedTime);
                            DateTime repairStarted;
                            bool parseOk_RepairStarted = DateTime.TryParse(data[8], out repairStarted);
                            DateTime completedTime;
                            bool parseOk_CompletedTime = DateTime.TryParse(data[9], out completedTime);
                            DateTime outageStarted;
                            bool parseOk_OutageStarted = DateTime.TryParse(data[11], out outageStarted);
                            DateTime outageEnded;
                            bool parseOk_OutageEnded = DateTime.TryParse(data[12], out outageEnded);

                            // 加入並轉換資料
                            history.Rows.Add(
                                int.Parse(data[0]),
                                 workOrderNo,
                            data[2].Trim(),
                                 date,
                             //MainDB.maintenanceUnits.FirstOrDefault(u => u.NewName.Contains(data[4].Trim()))?.MaintenanceUnitId ?? -1,
                             -1,
                                data[6].Trim(),
                               acceptedTime,
                                repairStarted,
                                completedTime,
                                completedTime - repairStarted,
                                outageStarted,
                                 outageEnded,
                                 outageEnded - outageStarted,
                                 data[14].Trim(),
                           data[15].Trim(),
                             data[16].Trim(),
                                data[18].Trim(),
                                 data[19].Trim(),
                                 -1,
                                 string.Empty,
                                 -1,
                             // MainDB.requestingUnits.FirstOrDefault(u => u.NewName == data[20].Trim())?.RequestingUnitId ?? -1,
                             //MainDB.allCompanyEmployees.FirstOrDefault(e => e.NewName == data[21].Trim())?.EmployeeNo ?? String.Empty,
                             //  MainDB.confirmations.FirstOrDefault(c => c.NewName == data[22].Trim())?.ConfirmationId ?? -1,
                             data[23].Trim()
                           );

                            // 計算類
                            //rec.RepairDuration = completedTime - repairStarted; // 維護工時
                            //rec.OutageDuration = outageEnded - outageStarted    ;   // 停動工時

                            //history.Add(rec);

                            //// 多對多欄位
                            //// 維護人員
                            //string[] maintenanceEmployee = data[5].Trim().Split(',');
                            //foreach (var me in maintenanceEmployee)
                            //{
                            //    string employeeID = MainDB.maintenanceEngineers.FirstOrDefault(e => me.Trim() == e.NewName)?.EmployeeNo ?? String.Empty;

                            //    if (!string.IsNullOrEmpty(employeeID))
                            //    {
                            //        hm.Add(new Historty_MaintenanceEmployee()
                            //        {
                            //            WorkOrderNo = workOrderNo,
                            //            EmployeeID = employeeID,
                            //        });
                            //    }
                            //}

                            //// 維護類型
                            //string[] issueCategory = data[17].Trim().Split(',');
                            //foreach (var ic in issueCategory)
                            //{
                            //    int categoryId = MainDB.issueCategories.FirstOrDefault(c => ic == c.CategoryName)?.CategoryId ?? -1;

                            //    if (categoryId != -1)
                            //    {
                            //        hi.Add(new History_IssueCategory()
                            //        {
                            //            WorkOrderNo = workOrderNo,
                            //            CategoryId = categoryId,
                            //        });
                            //    }
                            //}

                            //// 問題描述
                            //string[] issueDescription = data[18].Trim().Split(',');
                            //foreach (var de in issueDescription)
                            //    MainDB.history_IssueDescriptions.Add(new History_IssueDescription()
                            //    {
                            //        WorkOrderNo = workOrderNo,
                            //        DescriptionId = MainDB.issueDescriptions.FirstOrDefault(d => d.DescriptionId == de.Trim())?.
                            //    });
                        }

                        recCount++;
                    }

                    //var csv = new Csv();
                    //var historyCsv = csv.LoadCsvFromDialog(openDialog.FileName, hasHeader: true);

                    //_history.Clear();
                    //foreach (var rec in historyCsv)
                    //{
                    //    //_history.Add(rec);
                    //}

                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return history;
            //return (isSuccess, history, hm, hi);
        }

        //        internal List<HistoryDisplay> LoadCsvFromDialog(string fullFileName, bool hasHeader)
        //        {
        //            try
        //            {
        //                using (var sr = new StreamReader(fullFileName, Encoding.UTF8))
        //                {
        //                    var config = new CsvConfiguration(CultureInfo.InvariantCulture)
        //                    {
        //                        HasHeaderRecord = hasHeader
        //                    };

        //                    using (var csv = new CsvReader(sr, config))
        //                    {
        //                        csv.Context.RegisterClassMap<HistoryCsvMap>();
        //                        var data = csv.GetRecords<HistoryDisplay>().ToList();
        //                        return data;
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                Console.WriteLine(ex.Message);
        //            }

        //            return new List<HistoryDisplay>();
        //        }
    }
}
