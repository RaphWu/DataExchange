﻿namespace TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 需求單位清單。
    /// </summary>
    public class RequestingUnit
    {
        /// <summary>
        /// 單位代號
        /// </summary>
        public int RequestingUnitId { get; set; }

        /// <summary>
        /// 單位名稱
        /// </summary>
        public string Name { get; set; }
    }
}
