﻿namespace TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護類型清單。
    /// </summary>
    public class MaintenanceType
    {
        /// <summary>
        /// 類型代號。
        /// </summary>
        public int TypeId { get; set; }

        /// <summary>
        /// 類型名稱。
        /// </summary>
        public string Name { get; set; }
    }
}
