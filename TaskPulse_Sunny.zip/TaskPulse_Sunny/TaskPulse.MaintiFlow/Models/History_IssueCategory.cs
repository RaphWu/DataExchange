﻿namespace TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 問題分類中介表。
    /// </summary>
    public class History_IssueCategory
    {
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 維護人員工號。
        /// </summary>
        public int CategoryId { get; set; }
    }
}
