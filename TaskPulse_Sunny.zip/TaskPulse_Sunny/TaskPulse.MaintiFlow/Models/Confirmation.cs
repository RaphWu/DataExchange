﻿namespace TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 處理確認清單。
    /// </summary>
    public class Confirmation
    {
        /// <summary>
        /// 處理代號。
        /// </summary>
        public int ConfirmationId { get; set; }

        /// <summary>
        /// 處理名稱。
        /// </summary>
        public string Name { get; set; }
    }
}
