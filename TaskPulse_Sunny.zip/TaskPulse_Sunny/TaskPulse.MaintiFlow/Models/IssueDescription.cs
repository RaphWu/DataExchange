﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace TaskPulse.MaintiFlow.Models
//{
//    /// <summary>
//    /// 描述內容列表。
//    /// </summary>
//    public class IssueDescription
//    {
//        /// <summary>
//        /// 描述代號。
//        /// </summary>
//        public int DescriptionId { get; set; }

//        /// <summary>
//        /// 描述內容。
//        /// </summary>
//        public string Description { get; set; }
//    }
//}
