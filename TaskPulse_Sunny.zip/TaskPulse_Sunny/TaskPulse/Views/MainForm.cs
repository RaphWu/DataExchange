﻿using System;
using System.Reflection;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Event;
using Calin.TaskPulse.Views;
using CommunityToolkit.Mvvm.Messaging;
using Krypton.Toolkit;
using TaskPulse.MaintiFlow;
using TaskPulse.MechaTrack;
using TaskPulse.ToolQuest;

namespace Calin.TaskPulse
{
    public partial class MainForm : KryptonForm
    {
        internal static new IContainer Container { get; set; }
        //private readonly BindingSource _bs = new BindingSource();
        //private readonly UIProperty _uiProperty = UIProperty.Instance;

        public MainForm()
        {
            InitializeComponent();

            // KryptonForm
            var form = this;
            form.AllowStatusStripMerge = true;

            // Assembly Info
            var assembly = Assembly.GetExecutingAssembly();
            form.Text = assembly.GetName().Name;
            label_Version.Text = assembly.GetName().Version.ToString();

            // IoC & Module
            var builder = new ContainerBuilder();
            builder.RegisterModule(new CoreModule());
            builder.RegisterModule(new MainModule());
            builder.RegisterModule(new ToolQuestModule());
            builder.RegisterModule(new MechaTrackModule());
            builder.RegisterModule(new MaintiFlowModule());
            Container = builder.Build();

            // 註冊使用者切換事件
            WeakReferenceMessenger.Default.Register<LoggedInUserChangedMessage>(this, (r, m) =>
            {
                SetAuthority(m.Value);
            });

            // 註冊頁面切換事件
            WeakReferenceMessenger.Default.Register<PageChangedMessage>(this, (r, m) =>
            {
                SwitchPage(m.Value);
            });
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //_bs.DataSource = _uiProperty;
            SwitchPage(PageCode.MainMenu);

            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthorityToGuest();
            }
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            //panel_MainMenu.DataBindings.Add("Visible", _bs, nameof(_uiProperty.MainMenuVisibility),
            //    true, DataSourceUpdateMode.OnPropertyChanged);
            //panel_ToolQuest.DataBindings.Add("Visible", _bs, nameof(_uiProperty.ToolQuestVisibility),
            //    true, DataSourceUpdateMode.OnPropertyChanged);
            //panel_MechaTrack.DataBindings.Add("Visible", _bs, nameof(_uiProperty.MechaTrackVisibility),
            //    true, DataSourceUpdateMode.OnPropertyChanged);
            //panel_MaintiFlow.DataBindings.Add("Visible", _bs, nameof(_uiProperty.MaintiFlowVisibility),
            //    true, DataSourceUpdateMode.OnPropertyChanged);

            //mainMenuButton_ToolQuest.DataBindings.Add("Enabled", _bs, nameof(_uiProperty.ToolQuestFunction),
            //    true, DataSourceUpdateMode.OnPropertyChanged);
            //mainMenuButton_MechaTrack.DataBindings.Add("Enabled", _bs, nameof(_uiProperty.MechaTrackFunction),
            //    true, DataSourceUpdateMode.OnPropertyChanged);
            //mainMenuButton_MaintiFlow.DataBindings.Add("Enabled", _bs, nameof(_uiProperty.MaintiFlowFunction),
            //    true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            WeakReferenceMessenger.Default.Unregister<LoggedInUserChangedMessage>(this);

            //mainMenuButton_ToolQuest.DataBindings.Clear();
            //mainMenuButton_MechaTrack.DataBindings.Clear();
            //mainMenuButton_MaintiFlow.DataBindings.Clear();
        }

        /********************
         * 操作模式 & 頁面載入
         ********************/
        private PageCode _currentPage = PageCode.Nothing;

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="page">頁面代號。</param>
        private void SwitchPage(PageCode page)
        {
            UserControl control;

            if (_currentPage == page)
                return;

            switch (page)
            {
                case PageCode.ToolQuest:
                    control = Container.Resolve<ToolQuestControl>();
                    LoadPage(control);
                    break;
                case PageCode.MechaTrack:
                    control = Container.Resolve<MechaTrackControl>();
                    LoadPage(control);
                    break;
                case PageCode.MaintiFlow:
                    control = Container.Resolve<MaintiFlowControl>();
                    LoadPage(control);
                    break;
                default:
                    control = Container.Resolve<MainMenuControl>();
                    LoadPage(control);
                    break;
            }

            _currentPage = page;
        }

        /// <summary>
        /// 載入頁面。
        /// </summary>
        /// <param name="page">頁面物件。</param>
        private void LoadPage(UserControl page)
        {
            panelContainer.Controls.Clear();
            page.Dock = DockStyle.Fill;
            panelContainer.Controls.Add(page);
        }

        /********************
         * 權限
         ********************/
        private void SetAuthority(AuthorityData ad)
        {
            toolStripStatus_UserName.Text = ad.CurrentUserTitle;
            //if (ad.IsAdmin)
            //{
            //    toolStripStatus_UserName.BackColor = Color.Red;
            //    toolStripStatus_UserName.ForeColor = Color.Yellow;
            //}
            //else if (!ad.IsGuest)
            //{
            //    toolStripStatus_UserName.BackColor = Color.Transparent;
            //    toolStripStatus_UserName.ForeColor = Color.Blue;
            //}
            //else
            //{
            //    toolStripStatus_UserName.BackColor = Color.Transparent;
            //    toolStripStatus_UserName.ForeColor = Color.Black;
            //}

            //UIProperty.Instance.ToolQuestFunction = ad.CurrentAuthotization.ToolQuest;
            //UIProperty.Instance.MechaTrackFunction = ad.CurrentAuthotization.MechaTrack;
            //UIProperty.Instance.MaintiFlowFunction = ad.CurrentAuthotization.MaintiFlow;

            bool bVal;

            bVal = ad.CurrentAuthotization.AuthorityManager;
            toolStripMenuItem_UserManager.Enabled = bVal;

            bVal = ad.CurrentAuthotization.ToolQuest;
            buttonSpecAny_ToolQuest.Enabled = bVal ? ButtonEnabled.True : ButtonEnabled.False;

            bVal = ad.CurrentAuthotization.MechaTrack;
            buttonSpecAny_MechaTrack.Enabled = bVal ? ButtonEnabled.True : ButtonEnabled.False;

            bVal = ad.CurrentAuthotization.MaintiFlow;
            buttonSpecAny_MaintiFlow.Enabled = bVal ? ButtonEnabled.True : ButtonEnabled.False;
        }

        /********************
         * Control Event
         ********************/
        private void toolStripMenuItem_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_SwitchUser_Click(object sender, EventArgs e)
        {
            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthority();
            }
        }

        private void toolStripMenuItem_SwitchUser_Click(object sender, EventArgs e)
        {
            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthority();
            }
        }

        private void toolStripMenuItem_UserManager_Click(object sender, EventArgs e)
        {
            using (var scope = Container.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.OpenAuthorityEditor();
            }
        }

        private void buttonSpecAny_MainMenu_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.MainMenu);
        }

        private void buttonSpecAny_ToolQuest_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.ToolQuest);
        }

        private void buttonSpecAny_MechaTrack_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.MechaTrack);
        }

        private void buttonSpecAny_MaintiFlow_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.MaintiFlow);
        }
    }
}
