﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.Contants
{
    /// <summary>
    /// 頁面代號。
    /// </summary>
    public enum PageCode
    {
        Nothing,

        [Description("主選單")]
        MainMenu,

        [Description("工具委託")]
        ToolQuest,

        [Description("專案管理")]
        MechaTrack,

        [Description("維護工單")]
        MaintiFlow,
    }
}
