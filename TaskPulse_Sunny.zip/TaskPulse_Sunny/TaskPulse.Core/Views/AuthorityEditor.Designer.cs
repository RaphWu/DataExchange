﻿namespace Calin.TaskPulse.Core.Views
{
    partial class AuthorityEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox_UserNameList = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox_ToolQuest = new System.Windows.Forms.CheckBox();
            this.checkBox_MechaTrack = new System.Windows.Forms.CheckBox();
            this.checkBox_MaintiFlow = new System.Windows.Forms.CheckBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_MoveDown = new System.Windows.Forms.Button();
            this.button_MoveUp = new System.Windows.Forms.Button();
            this.checkBox_AuthorityManager = new System.Windows.Forms.CheckBox();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_ChangePassword = new System.Windows.Forms.Button();
            this.button_Rename = new System.Windows.Forms.Button();
            this.button_Create = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox_UserNameList
            // 
            this.listBox_UserNameList.FormattingEnabled = true;
            this.listBox_UserNameList.ItemHeight = 17;
            this.listBox_UserNameList.Location = new System.Drawing.Point(49, 43);
            this.listBox_UserNameList.Name = "listBox_UserNameList";
            this.listBox_UserNameList.Size = new System.Drawing.Size(215, 361);
            this.listBox_UserNameList.TabIndex = 0;
            this.listBox_UserNameList.SelectedIndexChanged += new System.EventHandler(this.listBox_UserNameList_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(96, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "使用者名稱列表";
            // 
            // checkBox_ToolQuest
            // 
            this.checkBox_ToolQuest.AutoSize = true;
            this.checkBox_ToolQuest.Location = new System.Drawing.Point(355, 43);
            this.checkBox_ToolQuest.Name = "checkBox_ToolQuest";
            this.checkBox_ToolQuest.Size = new System.Drawing.Size(79, 21);
            this.checkBox_ToolQuest.TabIndex = 2;
            this.checkBox_ToolQuest.Text = "工具委託";
            this.checkBox_ToolQuest.UseVisualStyleBackColor = true;
            // 
            // checkBox_MechaTrack
            // 
            this.checkBox_MechaTrack.AutoSize = true;
            this.checkBox_MechaTrack.Location = new System.Drawing.Point(355, 70);
            this.checkBox_MechaTrack.Name = "checkBox_MechaTrack";
            this.checkBox_MechaTrack.Size = new System.Drawing.Size(79, 21);
            this.checkBox_MechaTrack.TabIndex = 3;
            this.checkBox_MechaTrack.Text = "專案管理";
            this.checkBox_MechaTrack.UseVisualStyleBackColor = true;
            // 
            // checkBox_MaintiFlow
            // 
            this.checkBox_MaintiFlow.AutoSize = true;
            this.checkBox_MaintiFlow.Location = new System.Drawing.Point(355, 97);
            this.checkBox_MaintiFlow.Name = "checkBox_MaintiFlow";
            this.checkBox_MaintiFlow.Size = new System.Drawing.Size(79, 21);
            this.checkBox_MaintiFlow.TabIndex = 4;
            this.checkBox_MaintiFlow.Text = "維護工單";
            this.checkBox_MaintiFlow.UseVisualStyleBackColor = true;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(412, 456);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(79, 25);
            this.numericUpDown1.TabIndex = 5;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(285, 460);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "管理員閒置自動跳脫　　　　　　　分鐘";
            this.label2.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button_MoveDown);
            this.panel1.Controls.Add(this.button_MoveUp);
            this.panel1.Controls.Add(this.checkBox_AuthorityManager);
            this.panel1.Controls.Add(this.button_Delete);
            this.panel1.Controls.Add(this.button_ChangePassword);
            this.panel1.Controls.Add(this.button_Rename);
            this.panel1.Controls.Add(this.button_Create);
            this.panel1.Controls.Add(this.numericUpDown1);
            this.panel1.Controls.Add(this.checkBox_MaintiFlow);
            this.panel1.Controls.Add(this.checkBox_MechaTrack);
            this.panel1.Controls.Add(this.checkBox_ToolQuest);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.listBox_UserNameList);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(106, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 514);
            this.panel1.TabIndex = 7;
            // 
            // button_MoveDown
            // 
            this.button_MoveDown.Location = new System.Drawing.Point(0, 171);
            this.button_MoveDown.Name = "button_MoveDown";
            this.button_MoveDown.Size = new System.Drawing.Size(32, 32);
            this.button_MoveDown.TabIndex = 13;
            this.button_MoveDown.Text = "↓";
            this.button_MoveDown.UseVisualStyleBackColor = true;
            // 
            // button_MoveUp
            // 
            this.button_MoveUp.Location = new System.Drawing.Point(0, 120);
            this.button_MoveUp.Name = "button_MoveUp";
            this.button_MoveUp.Size = new System.Drawing.Size(32, 32);
            this.button_MoveUp.TabIndex = 12;
            this.button_MoveUp.Text = "↑";
            this.button_MoveUp.UseVisualStyleBackColor = true;
            // 
            // checkBox_AuthorityManager
            // 
            this.checkBox_AuthorityManager.AutoSize = true;
            this.checkBox_AuthorityManager.Location = new System.Drawing.Point(355, 156);
            this.checkBox_AuthorityManager.Name = "checkBox_AuthorityManager";
            this.checkBox_AuthorityManager.Size = new System.Drawing.Size(79, 21);
            this.checkBox_AuthorityManager.TabIndex = 11;
            this.checkBox_AuthorityManager.Text = "權限管理";
            this.checkBox_AuthorityManager.UseVisualStyleBackColor = true;
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(164, 422);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(81, 32);
            this.button_Delete.TabIndex = 10;
            this.button_Delete.Text = "刪除";
            this.button_Delete.UseVisualStyleBackColor = true;
            // 
            // button_ChangePassword
            // 
            this.button_ChangePassword.Location = new System.Drawing.Point(164, 460);
            this.button_ChangePassword.Name = "button_ChangePassword";
            this.button_ChangePassword.Size = new System.Drawing.Size(81, 32);
            this.button_ChangePassword.TabIndex = 9;
            this.button_ChangePassword.Text = "變更密碼";
            this.button_ChangePassword.UseVisualStyleBackColor = true;
            // 
            // button_Rename
            // 
            this.button_Rename.Location = new System.Drawing.Point(64, 460);
            this.button_Rename.Name = "button_Rename";
            this.button_Rename.Size = new System.Drawing.Size(81, 32);
            this.button_Rename.TabIndex = 8;
            this.button_Rename.Text = "變更名稱";
            this.button_Rename.UseVisualStyleBackColor = true;
            // 
            // button_Create
            // 
            this.button_Create.Location = new System.Drawing.Point(64, 422);
            this.button_Create.Name = "button_Create";
            this.button_Create.Size = new System.Drawing.Size(81, 32);
            this.button_Create.TabIndex = 7;
            this.button_Create.Text = "新增";
            this.button_Create.UseVisualStyleBackColor = true;
            this.button_Create.Click += new System.EventHandler(this.button_Create_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 550F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 520F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(756, 512);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(380, 422);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 32);
            this.button1.TabIndex = 14;
            this.button1.Text = "儲存";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // AuthorityEditor
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(756, 512);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AuthorityEditor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "權限管理";
            this.Load += new System.EventHandler(this.AuthorityManager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBox_UserNameList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox_ToolQuest;
        private System.Windows.Forms.CheckBox checkBox_MechaTrack;
        private System.Windows.Forms.CheckBox checkBox_MaintiFlow;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_ChangePassword;
        private System.Windows.Forms.Button button_Rename;
        private System.Windows.Forms.Button button_Create;
        private System.Windows.Forms.CheckBox checkBox_AuthorityManager;
        private System.Windows.Forms.Button button_MoveDown;
        private System.Windows.Forms.Button button_MoveUp;
        private System.Windows.Forms.Button button1;
    }
}