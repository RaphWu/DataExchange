﻿using System;
using Calin.CSharp.Security;
using Krypton.Toolkit;

namespace Calin.TaskPulse.Core.Authority
{
    public partial class UserLogin : KryptonForm
    {
        internal DialogInfo DialogInfo { get; private set; } // Dialog 溝通用

        public UserLogin()
        {
            InitializeComponent();
        }

        /********************
         * Control Event
         ********************/
        private void UserLogin_Load(object sender, EventArgs e)
        {
            comboBox_UserNameList.Items.AddRange(AuthorityData.Instance.UserNameList.ToArray());
            comboBox_UserNameList.Focus();
        }

        private void button_ClearUserName_Click(object sender, EventArgs e)
        {
            comboBox_UserNameList.Text = string.Empty;
            maskedTextBox_Password.Text = string.Empty;
            comboBox_UserNameList.ComboBox.Focus();
        }

        private void button_ClearPassword_Click(object sender, EventArgs e)
        {
            maskedTextBox_Password.Text = string.Empty;
        }

        private void button_OK_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.OK;
            DialogInfo = new DialogInfo
            {
                NewName = comboBox_UserNameList.Text.Trim(),
                NewPassword = maskedTextBox_Password.Text.Trim().GetMD5Hash(),
            };

            this.Close();
        }
    }
}
