﻿using System.Windows.Forms;
using Calin.TaskPulse.Core.Authority;
using Krypton.Toolkit;

namespace Calin.TaskPulse.Core.Views
{
    public partial class AuthorityEditor : KryptonForm
    {
        //public IAuthority Authority { get; set; } // 自動屬性注入
        private IAuthority _authority;
        private readonly AuthorityData _ad = AuthorityData.Instance;
        private BindingSource _bs = new BindingSource();

        public AuthorityEditor(IAuthority authority)
        {
            InitializeComponent();

            _authority = authority;
            _bs.DataSource = _ad;
        }

        private void AuthorityManager_Load(object sender, System.EventArgs e)
        {
            if (_ad.UserNameList.Count > 0)
            {
                RefreshNameList();

                var item = _ad.UserNameList[0];
                listBox_UserNameList.DisplayMember = nameof(item.Name);
                listBox_UserNameList.SelectedIndex = 0;
            }
        }

        /********************
         * Database
         ********************/
        ///// <summary>
        ///// 讀入系統設定值。
        ///// </summary>
        //private void LoadSysData()
        //{
        //    InputDetectInterval = _ad.Params.InputDetectInterval;
        //}

        /// <summary>
        /// 將指定使用者的權限設定存入Model。
        /// </summary>
        private bool SaveUserAuthorizationTable(int userId)
        {
            if (!_authority.IsUserIdExist(userId))
                return false;

            return _authority.SetUserAuthorizationTable(userId, new AuthorizationTable
            {
                AuthorityManager = checkBox_ToolQuest.Checked,
                ToolQuest = checkBox_ToolQuest.Checked,
                MechaTrack = checkBox_MechaTrack.Checked,
                MaintiFlow = checkBox_MaintiFlow.Checked,
            });
        }

        /// <summary>
        /// 從Model的載入指定使用者的權限設定。
        /// </summary>
        /// <returns>載入是否完成。</returns>
        private bool LoadUserAuthorizationTable(int userId)
        {
            if (!_authority.IsUserIdExist(userId))
                return false;

            var at = _authority.GetUserAuthorizationTable(userId);
            if (at == null)
                at = new AuthorizationTable();

            checkBox_AuthorityManager.Checked = at.AuthorityManager;
            checkBox_ToolQuest.Checked = at.ToolQuest;
            checkBox_MechaTrack.Checked = at.MechaTrack;
            checkBox_MaintiFlow.Checked = at.MaintiFlow;

            return true;
        }
        /********************
         * NameList
         ********************/
        private void RefreshNameList()
        {
            listBox_UserNameList.DataSource = _ad.UserNameList;
        }

        /********************
         * Control Event
         ********************/
        private void listBox_UserNameList_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            var list = sender as ListBox;
            var item = list.SelectedItem as UserNameListDefine;
            LoadUserAuthorizationTable(_ad.UserNameList.Find(x => x.Name == item.Name).Id);
        }

        private void button_Create_Click(object sender, System.EventArgs e)
        {
            _authority.NewUser();
        }
    }
}
