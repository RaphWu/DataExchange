﻿namespace Calin.TaskPulse.Core.Views
{
    partial class UserManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_Cancel = new Krypton.Toolkit.KryptonButton();
            this.button_OK = new Krypton.Toolkit.KryptonButton();
            this.label_OldPassword = new Krypton.Toolkit.KryptonLabel();
            this.label_OldUserName = new Krypton.Toolkit.KryptonLabel();
            this.maskedTextBox_OldPassword = new Krypton.Toolkit.KryptonMaskedTextBox();
            this.textBox_OldUserName = new Krypton.Toolkit.KryptonTextBox();
            this.textBox_NewUserName = new Krypton.Toolkit.KryptonTextBox();
            this.label_NewUserName = new Krypton.Toolkit.KryptonLabel();
            this.label_NewPassword = new Krypton.Toolkit.KryptonLabel();
            this.maskedTextBox_NewPassword = new Krypton.Toolkit.KryptonMaskedTextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_Cancel.Location = new System.Drawing.Point(253, 23);
            this.button_Cancel.Margin = new System.Windows.Forms.Padding(4);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(102, 42);
            this.button_Cancel.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Cancel.TabIndex = 27;
            this.button_Cancel.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.button_Cancel.Values.Text = "取消";
            // 
            // button_OK
            // 
            this.button_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button_OK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button_OK.Location = new System.Drawing.Point(63, 23);
            this.button_OK.Margin = new System.Windows.Forms.Padding(4);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(102, 42);
            this.button_OK.StateCommon.Content.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_OK.TabIndex = 26;
            this.button_OK.Values.DropDownArrowColor = System.Drawing.Color.Empty;
            this.button_OK.Values.Text = "確定";
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // label_OldPassword
            // 
            this.label_OldPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_OldPassword.Location = new System.Drawing.Point(35, 85);
            this.label_OldPassword.Margin = new System.Windows.Forms.Padding(0);
            this.label_OldPassword.Name = "label_OldPassword";
            this.label_OldPassword.Size = new System.Drawing.Size(120, 30);
            this.label_OldPassword.StateCommon.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_OldPassword.StateCommon.ShortText.TextH = Krypton.Toolkit.PaletteRelativeAlign.Far;
            this.label_OldPassword.TabIndex = 25;
            this.label_OldPassword.Values.Text = "舊密碼";
            // 
            // label_OldUserName
            // 
            this.label_OldUserName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_OldUserName.Location = new System.Drawing.Point(35, 15);
            this.label_OldUserName.Margin = new System.Windows.Forms.Padding(0);
            this.label_OldUserName.Name = "label_OldUserName";
            this.label_OldUserName.Size = new System.Drawing.Size(120, 30);
            this.label_OldUserName.StateCommon.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_OldUserName.StateCommon.ShortText.TextH = Krypton.Toolkit.PaletteRelativeAlign.Far;
            this.label_OldUserName.TabIndex = 24;
            this.label_OldUserName.Values.Text = "舊使用者名稱";
            // 
            // maskedTextBox_OldPassword
            // 
            this.maskedTextBox_OldPassword.AlwaysActive = false;
            this.maskedTextBox_OldPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.maskedTextBox_OldPassword.Location = new System.Drawing.Point(165, 85);
            this.maskedTextBox_OldPassword.Margin = new System.Windows.Forms.Padding(0);
            this.maskedTextBox_OldPassword.Name = "maskedTextBox_OldPassword";
            this.maskedTextBox_OldPassword.PasswordChar = '●';
            this.maskedTextBox_OldPassword.Size = new System.Drawing.Size(200, 27);
            this.maskedTextBox_OldPassword.StateActive.Border.Color1 = System.Drawing.Color.Orange;
            this.maskedTextBox_OldPassword.StateActive.Border.DrawBorders = ((Krypton.Toolkit.PaletteDrawBorders)((((Krypton.Toolkit.PaletteDrawBorders.Top | Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | Krypton.Toolkit.PaletteDrawBorders.Left) 
            | Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.maskedTextBox_OldPassword.StateCommon.Content.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.maskedTextBox_OldPassword.TabIndex = 23;
            // 
            // textBox_OldUserName
            // 
            this.textBox_OldUserName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_OldUserName.Location = new System.Drawing.Point(165, 15);
            this.textBox_OldUserName.Margin = new System.Windows.Forms.Padding(0);
            this.textBox_OldUserName.Name = "textBox_OldUserName";
            this.textBox_OldUserName.Size = new System.Drawing.Size(200, 22);
            this.textBox_OldUserName.StateCommon.Content.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_OldUserName.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            this.textBox_OldUserName.TabIndex = 28;
            this.textBox_OldUserName.Text = "kryptonTextBox1";
            this.textBox_OldUserName.WordWrap = false;
            // 
            // textBox_NewUserName
            // 
            this.textBox_NewUserName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_NewUserName.Location = new System.Drawing.Point(165, 50);
            this.textBox_NewUserName.Margin = new System.Windows.Forms.Padding(0);
            this.textBox_NewUserName.Name = "textBox_NewUserName";
            this.textBox_NewUserName.Size = new System.Drawing.Size(200, 22);
            this.textBox_NewUserName.StateCommon.Content.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox_NewUserName.StateCommon.Content.Padding = new System.Windows.Forms.Padding(10, -1, -1, -1);
            this.textBox_NewUserName.TabIndex = 30;
            this.textBox_NewUserName.Text = "kryptonTextBox2";
            this.textBox_NewUserName.WordWrap = false;
            // 
            // label_NewUserName
            // 
            this.label_NewUserName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_NewUserName.Location = new System.Drawing.Point(35, 50);
            this.label_NewUserName.Margin = new System.Windows.Forms.Padding(0);
            this.label_NewUserName.Name = "label_NewUserName";
            this.label_NewUserName.Size = new System.Drawing.Size(120, 30);
            this.label_NewUserName.StateCommon.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_NewUserName.StateCommon.ShortText.TextH = Krypton.Toolkit.PaletteRelativeAlign.Far;
            this.label_NewUserName.TabIndex = 29;
            this.label_NewUserName.Values.Text = "新使用者名稱";
            // 
            // label_NewPassword
            // 
            this.label_NewPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_NewPassword.Location = new System.Drawing.Point(35, 120);
            this.label_NewPassword.Margin = new System.Windows.Forms.Padding(0);
            this.label_NewPassword.Name = "label_NewPassword";
            this.label_NewPassword.Size = new System.Drawing.Size(120, 30);
            this.label_NewPassword.StateCommon.ShortText.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_NewPassword.StateCommon.ShortText.TextH = Krypton.Toolkit.PaletteRelativeAlign.Far;
            this.label_NewPassword.TabIndex = 32;
            this.label_NewPassword.Values.Text = "新密碼";
            // 
            // maskedTextBox_NewPassword
            // 
            this.maskedTextBox_NewPassword.AlwaysActive = false;
            this.maskedTextBox_NewPassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.maskedTextBox_NewPassword.Location = new System.Drawing.Point(165, 120);
            this.maskedTextBox_NewPassword.Margin = new System.Windows.Forms.Padding(0);
            this.maskedTextBox_NewPassword.Name = "maskedTextBox_NewPassword";
            this.maskedTextBox_NewPassword.PasswordChar = '●';
            this.maskedTextBox_NewPassword.Size = new System.Drawing.Size(200, 27);
            this.maskedTextBox_NewPassword.StateActive.Border.Color1 = System.Drawing.Color.Orange;
            this.maskedTextBox_NewPassword.StateActive.Border.DrawBorders = ((Krypton.Toolkit.PaletteDrawBorders)((((Krypton.Toolkit.PaletteDrawBorders.Top | Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | Krypton.Toolkit.PaletteDrawBorders.Left) 
            | Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.maskedTextBox_NewPassword.StateCommon.Content.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.maskedTextBox_NewPassword.TabIndex = 31;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.button_OK, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button_Cancel, 3, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 170);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(419, 98);
            this.tableLayoutPanel1.TabIndex = 33;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 5;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.Controls.Add(this.maskedTextBox_NewPassword, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.maskedTextBox_OldPassword, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.label_OldUserName, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label_NewUserName, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label_NewPassword, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label_OldPassword, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.textBox_NewUserName, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.textBox_OldUserName, 3, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(419, 170);
            this.tableLayoutPanel2.TabIndex = 34;
            // 
            // UserManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(419, 268);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UserManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserManager";
            this.Load += new System.EventHandler(this.UserManager_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Krypton.Toolkit.KryptonButton button_Cancel;
        private Krypton.Toolkit.KryptonButton button_OK;
        private Krypton.Toolkit.KryptonLabel label_OldPassword;
        private Krypton.Toolkit.KryptonLabel label_OldUserName;
        private Krypton.Toolkit.KryptonMaskedTextBox maskedTextBox_OldPassword;
        private Krypton.Toolkit.KryptonTextBox textBox_OldUserName;
        private Krypton.Toolkit.KryptonTextBox textBox_NewUserName;
        private Krypton.Toolkit.KryptonLabel label_NewUserName;
        private Krypton.Toolkit.KryptonLabel label_NewPassword;
        private Krypton.Toolkit.KryptonMaskedTextBox maskedTextBox_NewPassword;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
    }
}