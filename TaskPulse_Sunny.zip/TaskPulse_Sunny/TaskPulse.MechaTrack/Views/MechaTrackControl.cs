﻿using System.Windows.Forms;

namespace TaskPulse.MechaTrack
{
    public partial class MechaTrackControl : UserControl
    {
        public MechaTrackControl()
        {
            InitializeComponent();
        }
    }
}
