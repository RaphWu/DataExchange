﻿using Autofac;
using Calin.TaskPulse.ToolQuest.Views;

namespace Calin.TaskPulse.ToolQuest
{
    public class ToolQuestMoudle : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // views
            builder.RegisterType<ToolQuestPage>().AsSelf().PropertiesAutowired();
        }
    }
}
