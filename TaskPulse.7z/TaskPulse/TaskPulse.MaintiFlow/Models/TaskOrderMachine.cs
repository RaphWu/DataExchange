﻿//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace Calin.TaskPulse.MaintiFlow.Models
//{
//    public class MachineId
//    {
//        [Key, Column(Order = 0)]
//        public string WorkOrderNo { get; set; }   // FK，指向 TaskOrder.WorkOrderNo
//        public virtual TaskOrder TaskOrder { get; set; }

//        [Key, Column(Order = 1)]
//        public string MachineId { get; set; }        // FK，指向 MachineId.MachineId
//        public virtual MachineId MachineId { get; set; }
//    }
//}
