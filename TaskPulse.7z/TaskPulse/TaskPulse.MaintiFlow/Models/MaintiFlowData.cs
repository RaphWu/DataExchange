﻿using System.Collections.Generic;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護工單共用資料。
    /// </summary>
    public class MaintiFlowData : ObservableObject
    {
        /// <summary>
        /// 員工名冊 (EF版)。
        /// </summary>
        public List<Employee> Employees
        {
            get { return _employees; }
            set { SetProperty(ref _employees, value); }
        }
        private List<Employee> _employees;

        /// <summary>
        /// 維護工程師名冊。
        /// </summary>
        public List<Engineer> Engineers
        {
            get { return _engineers; }
            set { SetProperty(ref _engineers, value); }
        }
        private List<Engineer> _engineers;

        /// <summary>
        /// 顯示用機台編號列表。
        /// </summary>
        public List<KeyValuePair<string, string>> MachineList
        {
            get { return _machineList; }
            set { SetProperty(ref _machineList, value); }
        }
        private List<KeyValuePair<string, string>> _machineList;

        /// <summary>
        /// 顯示用機種列表。
        /// </summary>
        public List<string> ModelList
        {
            get { return _modelList; }
            set { SetProperty(ref _modelList, value); }
        }
        private List<string> _modelList;
    }
}
