﻿using System.Collections.Generic;
using Calin.TaskPulse.Entity.MaintiFlow;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護工單共用資料。
    /// </summary>
    public class MaintiFlowData : ObservableObject
    {
        /// <summary>
        /// 全部維護工單。
        /// </summary>
        public List<TaskOrder> TaskOrders
        {
            get { return _taskOrders; }
            set { SetProperty(ref _taskOrders, value); }
        }
        private List<TaskOrder> _taskOrders;
    }
}
