﻿using System.Collections.Generic;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護工單共用資料。
    /// </summary>
    public class MaintiFlowData : ObservableObject
    {
        /// <summary>
        /// 
        /// </summary>
        public List<Employee> Employees
        {
            get { return _employees; }
            set { SetProperty(ref _employees, value); }
        }
        private List<Employee> _employees;

        /// <summary>
        /// 顯示用機台編號列表。
        /// </summary>
        public List<KeyValuePair<string, string>> DeviceList
        {
            get { return _machineList; }
            set { SetProperty(ref _machineList, value); }
        }
        private List<KeyValuePair<string, string>> _machineList;

        /// <summary>
        /// 顯示用機種列表。
        /// </summary>
        public List<string> ModelList
        {
            get { return _modelList; }
            set { SetProperty(ref _modelList, value); }
        }
        private List<string> _modelList;
    }
}
