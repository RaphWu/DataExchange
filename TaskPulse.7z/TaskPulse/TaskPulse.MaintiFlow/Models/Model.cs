﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    public class Model
    {
        /// <summary>
        /// 機種名稱。
        /// </summary>
        [Description("機種")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string ModelName { get; set; }

        public virtual ICollection<TaskOrder> ModelTaskOrders { get; set; } // 機種
    }
}
