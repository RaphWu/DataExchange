﻿//using System;
//using System.Data.Entity;
//using System.Data.Entity.Validation;
//using System.IO;
//using System.Linq;
//using System.Text;
//using Calin.TaskPulse.Core.Models;
//using Calin.TaskPulse.Entity.Core;
//using Calin.TaskPulse.Entity.MaintiFlow;
//using SQLite.CodeFirst;

//namespace Calin.TaskPulse.MaintiFlow.Models
//{
//    /// <summary>
//    /// Code First 初始化類別。
//    /// </summary>
//    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
//    public class MaintiFlowInitializer : SqliteCreateDatabaseIfNotExists<MaintiFlowContext>
//    {
//        private readonly CoreContext _coreContext;

//        public MaintiFlowInitializer(DbModelBuilder modelBuilder, CoreContext coreContext) : base(modelBuilder)
//        {
//            _coreContext = coreContext;
//        }

//        protected override void Seed(MaintiFlowContext context)
//        {
//            var mu = context.Set<MaintenanceUnit>();
//            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 1, OrderNo = 1, Name = "工具設計" });
//            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 2, OrderNo = 2, Name = "維護-維小" });
//            mu.Add(new MaintenanceUnit() { MaintenanceUnitId = 3, OrderNo = 3, Name = "維護-製一" });

//            var ic = context.Set<IssueCategory>();
//            ic.Add(new IssueCategory() { CategoryId = 1, OrderNo = 1, CategoryName = "日常維護" });
//            ic.Add(new IssueCategory() { CategoryId = 2, OrderNo = 2, CategoryName = "機台保養" });
//            ic.Add(new IssueCategory() { CategoryId = 3, OrderNo = 3, CategoryName = "更換零件" });
//            ic.Add(new IssueCategory() { CategoryId = 4, OrderNo = 4, CategoryName = "機台改線" });
//            ic.Add(new IssueCategory() { CategoryId = 5, OrderNo = 5, CategoryName = "故障中待協助" });
//            ic.Add(new IssueCategory() { CategoryId = 6, OrderNo = 6, CategoryName = "異常排除" });
//            ic.Add(new IssueCategory() { CategoryId = 7, OrderNo = 7, CategoryName = "機台功能追加" });
//            ic.Add(new IssueCategory() { CategoryId = 8, OrderNo = 8, CategoryName = "機台移動" });

//            var ru = context.Set<RequestingUnit>();
//            ru.Add(new RequestingUnit() { OrderNo = 1, UnitName = "組立" });
//            ru.Add(new RequestingUnit() { OrderNo = 2, UnitName = "製技" });
//            ru.Add(new RequestingUnit() { OrderNo = 3, UnitName = "RD" });
//            ru.Add(new RequestingUnit() { OrderNo = 4, UnitName = "試作" });
//            ru.Add(new RequestingUnit() { OrderNo = 5, UnitName = "試作開發" });
//            ru.Add(new RequestingUnit() { OrderNo = 6, UnitName = "品管" });

//            var depList = _coreContext.Set<Department>();
//            var dep = context.Set<Department>();
//            foreach (var dl in depList)
//            {
//                dep.Add(new Department() { DepartmentName = dl.DepartmentName, });
//            }

//            var titleList = _coreContext.Set<Title>();
//            var title = context.Set<Title>();
//            foreach (var tl in titleList)
//            {
//                title.Add(new Title() { TitleName = tl.TitleName, });
//            }
//            context.SaveChanges();

//            var empList = _coreContext.Set<Employee>()
//                .OrderBy(e => e.EmployeeId)
//                .ToList();
//            var employees = context.Set<Employee>();
//            var buffs = empList.Select(emp =>
//            {
//                var dd = dep.FirstOrDefault(d => d.Id == emp.DepartmentId);
//                var tt = (emp.TitleId > 0) ? title.FirstOrDefault(d => d.Id == emp.TitleId) : null;

//                return new Employee
//                {
//                    EmployeeId = emp.EmployeeId,
//                    Name = emp.Name,
//                    Department = dd,
//                    Title = tt,
//                    IsEngineer = emp.IsEngineer,
//                };
//            }).ToList();
//            employees.AddRange(buffs);

//            //var deviceList = _coreContext.Set<Core.Models.Machines>()
//            //    .Include(d => d.MachineName.MachineType)
//            //    .ToList();
//            //var device = context.Set<Machines>();
//            //foreach (var w in deviceList)
//            //{
//            //    device.Add(new Machines()
//            //    {
//            //        MachineId = w.MachineId,
//            //        MachineName = w.MachineName,
//            //    });
//            //}

//            var modelList = _coreContext.Set<Model>().ToList();
//            var model = context.Set<Model>();
//            foreach (var ml in modelList)
//            {
//                model.Add(new Model()
//                {
//                    ModelId = ml.ModelId,
//                    ModelName = ml.ModelName,
//                });
//            }
//            context.SaveChanges();

//            var workstationList = _coreContext.Set<Workstation>().ToList();
//            var wss = context.Set<Workstation>();
//            foreach (var w in workstationList)
//            {
//                var mb = model.FirstOrDefault(m => m.ModelId == w.ModelId);
//                wss.Add(new Workstation()
//                {
//                    WorkstationId = w.WorkstationId,
//                    WorkstationName = w.WorkstationName,
//                    Model = mb,
//                });
//            }
//            context.SaveChanges();

//            try
//            {
//                int recCount = 0;
//                using (var sr = new StreamReader("設備維修履歷_Import.txt", Encoding.Default))
//                {
//                    string[] sList;

//                    var mod = context.Set<Model>().ToList();
//                    var machine = _coreContext.Set<Machine>().Include(m => m.MachineName).ToList();
//                    //var employees = context.Set<Employee>().ToList();
//                    var engineers = context.Set<Employee>().Where(e => e.IsEngineer).ToList();

//                    var tos = context.Set<TaskOrder>();
//                    //var ru = context.Set<RequestingUnit>();
//                    string data;

//                    while (sr.Peek() != -1)
//                    {
//                        recCount++;
//                        string[] datas = sr.ReadLine().Split('\t');

//                        if (recCount > 1) // 去掉標題
//                        {
//                            var to = new TaskOrder();
//                            string workOrderNo = datas[1].Trim();

//                            to.OrderNo = int.Parse(datas[0]);
//                            to.WorkOrderNo = workOrderNo;

//                            string empName = datas[2].Trim();
//                            to.Creator = employees.FirstOrDefault(x => x.Name == empName);
//                            //to.CreatorId = (to.Creator != null) ? to.Creator.EmployeeId : string.Empty;

//                            to.CreationDate = DateTime.Parse(datas[3]);

//                            string muName = datas[4].Trim();
//                            to.MaintenanceUnit = mu.FirstOrDefault(x => x.Name == muName);

//                            //sList = datas[5].Split('/');
//                            //to.Engineers = new List<Employee>();
//                            //foreach (var d5 in sList)
//                            //{
//                            //    var e = engineers.FirstOrDefault(x => x.Name == d5 && x.IsEngineer);
//                            //    if (e != null)
//                            //        to.Engineers.Add(new Employee()
//                            //        {
//                            //            EmployeeId = e.EmployeeId,
//                            //            Name = e.Name,
//                            //            Department = e.Department,
//                            //            Title = e.Title,
//                            //        });
//                            //}

//                            data = datas[6].Trim();
//                            var mac = machine.FirstOrDefault(x => x.MachineId == data);
//                            to.MachineId = (mac != null) ? mac.Id : -1;
//                            to.Machine = null;

//                            //var d6 = datas[6].Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries)
//                            //                .Select(x => x.Trim())
//                            //                .Where(x => !string.IsNullOrWhiteSpace(x))
//                            //                .Distinct()
//                            //                .ToList();
//                            //to.MachineId = new List<MachineId>();
//                            //foreach (var d_6 in d6)
//                            //{
//                            //    var mch = deviceList.FirstOrDefault(x => x.MachineId == d_6);
//                            //    if (mch != null)
//                            //        to.MachineId.Add(new MachineId
//                            //        {
//                            //            WorkOrderNo = workOrderNo,
//                            //            MachineId = mch.MachineId,
//                            //        });
//                            //}

//                            to.AcceptedTime = DateTime.Parse(string.Concat(datas[3], " ", datas[7]));

//                            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[8]), out DateTime rs))
//                                to.RepairStarted = rs;
//                            else
//                                to.RepairStarted = null;

//                            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[9]), out DateTime rc))
//                                to.RepairCompleted = rc;
//                            else
//                                to.RepairCompleted = null;

//                            if (int.TryParse(datas[10], out int rd))
//                                to.RepairDuration = TimeSpan.FromMinutes(rd);
//                            else
//                            {
//                                if (rs == null || rc == null)
//                                    to.RepairDuration = TimeSpan.Zero;
//                                else
//                                    to.RepairDuration = rc - rs;
//                            }

//                            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[11]), out DateTime os))
//                                to.OutageStarted = os;
//                            else
//                                to.OutageStarted = null;

//                            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[12]), out DateTime oe))
//                                to.OutageEnded = oe;
//                            else
//                                to.OutageEnded = null;

//                            if (int.TryParse(datas[13], out int od))
//                                to.OutageDuration = TimeSpan.FromMinutes(od);
//                            else
//                            {
//                                if (rs == null || rc == null)
//                                    to.OutageDuration = TimeSpan.Zero;
//                                else
//                                    to.OutageDuration = oe - os;
//                            }

//                            //if (!string.IsNullOrWhiteSpace(datas[15]))
//                            //{
//                            //    string name = datas[15].Trim();
//                            //    to.Model = mod.FirstOrDefault(x => x.ModelName == name);
//                            //    if (to.Model == null)
//                            //    {
//                            //        var newModel = new Model() { ModelName = name };
//                            //        mod.Add(newModel);
//                            //        context.SaveChanges();
//                            //        //to.ModelName = newModel;
//                            //        //to.ModelName = newModel.ModelName;
//                            //    }
//                            //}

//                            //data = datas[16].Trim();
//                            //var ws = wss.FirstOrDefault(x => x.WorkstationName == data);
//                            //if (ws != null)
//                            //{
//                            //    to.Workstation = ws;
//                            //    to.WorkstationId = ws.WorkstationId;
//                            //}

//                            if (!string.IsNullOrWhiteSpace(datas[17]))
//                            {
//                                string name = datas[17].Trim();
//                                to.IssueCategory = ic.FirstOrDefault(x => x.CategoryName == name);
//                            }
//                            else
//                            {
//                                to.IssueCategory = null;
//                            }

//                            to.IssueDescription = datas[18].Trim();
//                            to.Details = datas[19].Trim();

//                            if (!string.IsNullOrWhiteSpace(datas[20]))
//                            {
//                                string name = datas[20].Trim();
//                                to.RequestingUnit = ru.FirstOrDefault(x => x.UnitName == name);
//                            }
//                            else
//                            {
//                                to.RequestingUnit = null;
//                            }

//                            if (!string.IsNullOrWhiteSpace(datas[21]))
//                            {
//                                string name = datas[21].Trim();
//                                to.RequestingEmployee = employees.FirstOrDefault(x => x.Name == name);
//                            }
//                            else
//                            {
//                                to.RequestingEmployee = null;
//                            }

//                            to.Status = Status.Finished;
//                            //if (!string.IsNullOrWhiteSpace(datas[22]))
//                            //{
//                            //    string name = datas[22].Trim();
//                            //    to.Status = st.FirstOrDefault(x => x.StatusName == name);
//                            //}
//                            //if (to.Status == null)
//                            //    to.Status = st.FirstOrDefault(x => x.StatusName == "待處理");

//                            to.Response = datas[23].Trim();

//                            tos.Add(to);
//                        }
//                    }
//                    context.SaveChanges();
//                }
//            }
//            catch (DbEntityValidationException ex)
//            {
//                foreach (var eve in ex.EntityValidationErrors)
//                {
//                    Console.WriteLine($"Entity of type '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

//                    foreach (var ve in eve.ValidationErrors)
//                    {
//                        Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
//                    }
//                }

//                throw;
//            }
//            catch (Exception ex)
//            {
//                // 檢查 inner exception 是否為 DbEntityValidationException
//                var validationException = ex as DbEntityValidationException
//                    ?? ex.InnerException as DbEntityValidationException;

//                if (validationException != null)
//                {
//                    foreach (var validationErrors in validationException.EntityValidationErrors)
//                    {
//                        foreach (var validationError in validationErrors.ValidationErrors)
//                        {
//                            Console.WriteLine("❌ Entity: " + validationErrors.Entry.Entity.GetType().Name);
//                            Console.WriteLine("   Property: " + validationError.PropertyName);
//                            Console.WriteLine("   Error: " + validationError.ErrorMessage);
//                        }
//                    }
//                }
//                else
//                {
//                    // 其他例外狀況
//                    Console.WriteLine("🔴 一般例外：");
//                    Console.WriteLine(ex.ToString());
//                }

//                throw;
//            }

//            base.Seed(context);
//        }
//    }
//}
