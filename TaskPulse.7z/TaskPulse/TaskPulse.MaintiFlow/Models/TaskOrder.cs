﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護工單。
    /// </summary>
    public class TaskOrder
    {
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        [Description("維護工單編號")]
        [Key]
        [Required]
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        [Description("編號")]
        public int OrderNo { get; set; }

        /// <summary>
        /// 建檔人員。
        /// </summary>
        [Description("建檔人員")]
        public Employee Creator { get; set; }
        public string CreatorId { get; set; } // FK
        [NotMapped]
        public string CreatorFullName
        {
            get
            {
                if (Creator == null)
                    return string.Empty;
                else
                    return $"{Creator.EmployeeId}, {Creator.Department}, {Creator.Name}";
            }
        }

        /// <summary>
        /// 建檔日期。
        /// </summary>
        [Description("建檔日期")]
        [Required]
        public DateTime? CreationDate { get; set; }
        [NotMapped]
        public string CreationDateString { get => CreationDate?.ToString("yyyy/MM/dd") ?? string.Empty; }

        /// <summary>
        /// 目前狀態。
        /// </summary>
        [Description("目前狀態")]
        [Required]
        public Status Status { get; set; }

        /// <summary>
        /// 維護單位。
        /// </summary>
        [Description("維護單位")]
        public virtual MaintenanceUnit MaintenanceUnit { get; set; }
        public int? MaintenanceUnitId { get; set; } // FK
        [NotMapped]
        public string UnitString { get { return MaintenanceUnit?.Name ?? string.Empty; } }

        /// <summary>
        /// 維護工程師。
        /// </summary>
        [Description("維護工程師")]
        public virtual ICollection<TaskOrderEngineer> MaintenanceEngineers { get; set; }
        [NotMapped]
        public string EngineerString
        {
            get
            {
                if (MaintenanceEngineers == null)
                    return string.Empty;
                else
                {
                    string ret = "";
                    int cnt = 0;
                    foreach (var emp in MaintenanceEngineers)
                    {
                        if (cnt++ > 0)
                            ret += "; ";
                        ret = emp.Engineer.Name;
                    }
                    return ret;
                }
            }
        }

        /// <summary>
        /// 機台編號。
        /// </summary>
        [Description("機台編號")]
        public virtual ICollection<TaskOrderDevice> TaskOrderDevices { get; set; }

        [NotMapped]
        public string DeviceString
        {
            get
            {
                int cnt = 0;
                string ret = "";
                foreach (var tod in TaskOrderDevices)
                {
                    if (cnt++ > 0)
                        ret += "; ";
                    ret += tod.DeviceId;
                }
                return ret;
            }
        }


        /// <summary>
        /// 接收時間。
        /// </summary>
        [Description("接收時間")]
        [Required]
        public DateTime? AcceptedTime { get; set; }
        [NotMapped]
        public string AcceptedTimeString { get => AcceptedTime?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 維修開始時間。
        /// </summary>
        [Description("開始時間")]
        public DateTime? RepairStarted { get; set; }
        [NotMapped]
        public string RepairStartedString { get => RepairStarted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 維修完成時間。
        /// </summary>
        [Description("完成時間")]
        public DateTime? RepairCompleted { get; set; }
        [NotMapped]
        public string RepairCompletedString { get => RepairCompleted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [Description("維修工時")]
        public string RepairDurationString { get; set; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [Description("維修工時")]
        [NotMapped]
        public TimeSpan RepairDuration
        {
            get
            {
                if (RepairDurationString != null)
                    return TimeSpan.Parse(RepairDurationString);
                else
                    return TimeSpan.Zero;
            }
            set => RepairDurationString = value.ToString();
        }

        /// <summary>
        /// 停動開始。
        /// </summary>
        [Description("停動開始")]
        public DateTime? OutageStarted { get; set; }
        [NotMapped]
        public string OutageStartedString { get => OutageStarted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 停動結束。
        /// </summary>
        [Description("停動結束")]
        public DateTime? OutageEnded { get; set; }
        [NotMapped]
        public string OutageEndedString { get => OutageEnded?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [Description("停動工時")]
        public string OutageDurationString { get; set; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [Description("停動工時")]
        [NotMapped]
        public TimeSpan OutageDuration
        {
            get
            {
                if (OutageDurationString != null)
                    return TimeSpan.Parse(OutageDurationString);
                else
                    return TimeSpan.Zero;
            }
            set => OutageDurationString = value.ToString();
        }

        /// <summary>
        /// 責任歸屬。
        /// </summary>
        [Description("責任歸屬")]
        public string Responsible { get; set; }

        /// <summary>
        /// 機種。
        /// </summary>
        [Description("機種")]
        public Model Model { get; set; }
        public string ModelName { get; set; } // FK

        /// <summary>
        /// 工站。
        /// </summary>
        [Description("工站")]
        public string Workstation { get; set; }

        /// <summary>
        /// 維護類型。
        /// </summary>
        [Description("維護類型")]
        public virtual IssueCategory IssueCategory { get; set; }
        public int? IssueCategoryId { get; set; } // FK
        [NotMapped]
        public string IssueCategoryString { get => IssueCategory?.CategoryName ?? string.Empty; }

        /// <summary>
        /// 問題描述。
        /// </summary>
        [Description("問題描述")]
        public string IssueDescription { get; set; }

        /// <summary>
        /// 維護內容。
        /// </summary>
        [Description("維護內容")]
        public string Details { get; set; }

        /// <summary>
        /// 需求單位名稱。
        /// </summary>
        [Description("需求單位名稱")]
        public virtual RequestingUnit RequestingUnit { get; set; }
        public int? RequestingUnitId { get; set; } // FK
        [NotMapped]
        public string RequestingUnitString { get => RequestingUnit?.Name ?? string.Empty; }

        /// <summary>
        /// 需求單位人員工號。
        /// </summary>
        [Description("需求單位人員工號")]
        public virtual Employee RequestingEmployee { get; set; }
        public string RequestingEmployeeId { get; set; } // FK
        [NotMapped]
        public string RequestingEmployeeString
        {
            get
            {
                if (RequestingEmployee == null)
                    return string.Empty;
                else
                {
                    string ret = "";
                    if (!string.IsNullOrWhiteSpace(RequestingEmployee.Title))
                        ret = $"{RequestingEmployee.Title}, ";
                    return ret + RequestingEmployee.Name;
                }
            }
        }

        /// <summary>
        /// 需求單位回覆。
        /// </summary>
        [Description("需求單位回覆")]
        public string RequestingUnitResponse { get; set; }
    }
}
