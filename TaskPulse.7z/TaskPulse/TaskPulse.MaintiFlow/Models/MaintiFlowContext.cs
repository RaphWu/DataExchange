﻿using System.Data.Entity;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 資料庫區。
    /// </summary>
    public class MaintiFlowContext : DbContext
    {
        private readonly CoreContext _coreContext;

        public MaintiFlowContext(CoreContext coreContext) : base("name=MaintiFlowContext")
        {
            _coreContext = coreContext;

            //if (System.IO.File.Exists("MaintiFlowDB.db"))
            //    System.IO.File.Delete("MaintiFlowDB.db");

            //Database.SetInitializer(new CreateDatabaseIfNotExists<MaintiFlowContext>());
            //Database.SetInitializer(new DropCreateDatabaseAlways<MaintiFlowContext>());
            //Database.SetInitializer<MaintiFlowContext>(null);
            //Database.CreateIfNotExists();
        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Status> Statuses { get; set; }
        public DbSet<Model> Models { get; set; }
        public DbSet<IssueCategory> IssueCategories { get; set; }
        public DbSet<MaintenanceUnit> MaintenanceUnits { get; set; }
        public DbSet<RequestingUnit> RequestingUnits { get; set; }

        public DbSet<TaskOrderEngineer> TaskOrderEngineers { get; set; }
        public DbSet<Device> TaskOrderMachines { get; set; }

        public DbSet<TaskOrder> TaskOrders { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new MaintiFlowInitializer(modelBuilder, _coreContext));

            // 建檔人員 一對多: TaskOrder.Creator → Employee.CreatedTaskOrders
            modelBuilder.Entity<TaskOrder>()
                .HasRequired(t => t.Creator)
                .WithMany(e => e.CreatedTaskOrders)
                .HasForeignKey(t => t.CreatorId)
                .WillCascadeOnDelete(false);

            // 維護單位 一對多: TaskOrder.MaintenanceUnit → MaintenanceUnit.TaskOrders
            modelBuilder.Entity<TaskOrder>()
                .HasOptional(t => t.MaintenanceUnit)
                .WithMany(mu => mu.TaskOrders)
                .HasForeignKey(t => t.MaintenanceUnitId)
                .WillCascadeOnDelete(false);

            // 維護工程師 多對多（透過中介表 TaskOrderEngineer）
            modelBuilder.Entity<TaskOrderEngineer>()
                .HasKey(te => new { te.WorkOrderNo, te.EmployeeId });

            modelBuilder.Entity<TaskOrderEngineer>()
                .HasRequired(te => te.TaskOrder)
                .WithMany(t => t.MaintenanceEngineers)
                .HasForeignKey(te => te.WorkOrderNo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TaskOrderEngineer>()
                .HasRequired(te => te.Engineer)
                .WithMany(e => e.AssignedTasks)
                .HasForeignKey(te => te.EmployeeId)
                .WillCascadeOnDelete(false);

            // 機台編號 多對多（透過中介表 TaskOrderDevice）
            modelBuilder.Entity<TaskOrderDevice>()
                .HasKey(t => new { t.WorkOrderNo, t.DeviceId });

            modelBuilder.Entity<TaskOrderDevice>()
                .HasRequired(tm => tm.TaskOrder)
                .WithMany(to => to.TaskOrderDevices)
                .HasForeignKey(tm => tm.WorkOrderNo)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TaskOrderDevice>()
                .HasRequired(tm => tm.Device)
                .WithMany(m => m.TaskOrderDevices)
                .HasForeignKey(tm => tm.DeviceId)
                .WillCascadeOnDelete(false);

            // 機種 一對多: TaskOrder.Model → Model.ModelTaskOrders
            modelBuilder.Entity<TaskOrder>()
                .HasRequired(t => t.Model)
                .WithMany(e => e.ModelTaskOrders)
                .HasForeignKey(t => t.ModelName)
                .WillCascadeOnDelete(false);

            // 需求單位 一對多: TaskOrder.RequestingUnit → RequestingUnit.TaskOrders
            modelBuilder.Entity<TaskOrder>()
                .HasOptional(t => t.RequestingUnit)
                .WithMany(ru => ru.TaskOrders)
                .HasForeignKey(t => t.RequestingUnitId)
                .WillCascadeOnDelete(false);

            // 需求單位人員 一對多: TaskOrder.RequestingEmployee → Employee.RequestingTaskOrders
            modelBuilder.Entity<TaskOrder>()
                .HasOptional(t => t.RequestingEmployee)
                .WithMany(e => e.RequestingTaskOrders)
                .HasForeignKey(t => t.RequestingEmployeeId)
                .WillCascadeOnDelete(false);

            // 維護類型 一對多: TaskOrder → IssueCategory
            modelBuilder.Entity<TaskOrder>()
                .HasOptional(t => t.IssueCategory)
                .WithMany(c => c.TaskOrders)
                .HasForeignKey(t => t.IssueCategoryId)
                .WillCascadeOnDelete(false);
        }
    }
}
