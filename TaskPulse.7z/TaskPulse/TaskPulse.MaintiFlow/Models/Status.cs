﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 目前狀態。
    /// </summary>
    public class Status
    {
        /// <summary>
        /// 狀態ID。
        /// </summary>
        [Description("狀態")]
        [Key]
        public int StatusId { get; set; }

        /// <summary>
        /// 狀態名稱。
        /// </summary>
        [Description("名稱")]
        public string StatusName { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        [Description("編號")]
        public int OrderNo { get; set; }
    }
}
