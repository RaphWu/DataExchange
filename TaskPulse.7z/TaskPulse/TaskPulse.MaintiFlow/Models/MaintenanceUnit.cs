﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護單位清單。
    /// </summary>
    public class MaintenanceUnit
    {
        /// <summary>
        /// 單位代號。
        /// </summary>
        [Description("單位代號")]
        [Key]
        public int MaintenanceUnitId { get; set; }

        /// <summary>
        /// 單位名稱。
        /// </summary>
        [Description("單位名稱")]
        public string Name { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        [Description("編號")]
        public int OrderNo { get; set; }

        public ICollection<TaskOrder> TaskOrders { get; set; } // 維護單位
    }
}
