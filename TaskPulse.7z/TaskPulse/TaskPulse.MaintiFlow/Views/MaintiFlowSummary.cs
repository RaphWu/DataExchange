﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UIPage
    {
        private readonly MaintiFlowContext _db;
        private DataTable _dt;

        public MaintiFlowSummary(MaintiFlowContext db)
        {
            InitializeComponent();
            _db = db;

            adgv.SetDoubleBuffered();
            adgv.MultiSelect = false;
            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

            _dt = new DataTable(); // 初始化 DataTable
        }

        private void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            if (_db != null)
            {
                // 維護工程師名單
                var engineerList = _db.TaskOrderEngineers
                    .Where(te => te.Engineer.IsEngineer)
                    .Select(te => new
                    {
                        te.Engineer.EmployeeId,
                        te.Engineer.Name,
                        te.Engineer.Department,
                        te.Engineer.Title
                    })
                    .ToList();

                // .Include(u => u.MaintenanceEngineers.Select(te => te.Engineer)) // EF6 的 Include 不支援多層 Lambda
                var orderList = _db.TaskOrders
                    .Include(nameof(TaskOrder.MaintenanceEngineers) + "." + nameof(TaskOrderEngineer.Engineer))
                    .Include(nameof(TaskOrder.TaskOrderDevices) + "." + nameof(TaskOrderDevice.Device))
                    .Include(nameof(TaskOrder.Status))
                    .Include(nameof(TaskOrder.IssueCategory))
                    .OrderByDescending(u => u.OrderNo)
                    .ToList()
                    .Select(u => new
                    {
                        u.OrderNo,
                        u.WorkOrderNo,
                        creatorName = u.Creator?.Name ?? string.Empty,
                        u.CreationDate,
                        statusText = u.Status.StatusName,
                        maintenanceUnitName = u.MaintenanceUnit?.Name ?? string.Empty,
                        maintenanceEngineerNames = string.Join("\n", u.MaintenanceEngineers.Select(te => te.Engineer.Name)),
                        //machineList = string.Join("\n", u.TaskOrderDevices.Select(m => m.Device.DeviceName)),
                        modelName = u.ModelName,
                        u.Workstation,
                        u.RepairDuration,
                        u.OutageDuration,
                    })
                    .ToList();

                _dt = orderList.ToDataTable();
                adgv.DataSource = _dt;

                DataGridViewColumn c = adgv.Columns[nameof(TaskOrder.OrderNo)];
                c.HeaderText = "編號";
                c.ValueType = typeof(int);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns[nameof(TaskOrder.WorkOrderNo)];
                c.HeaderText = "工單";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["creatorName"];
                c.HeaderText = "建檔人員";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns[nameof(TaskOrder.CreationDate)];
                c.HeaderText = "建檔日期";
                c.ValueType = typeof(DateTime);
                c.DefaultCellStyle.Format = "yyyy/MM/dd";
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["statusText"];
                c.HeaderText = "狀態";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["maintenanceUnitName"];
                c.HeaderText = "維護單位";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                c = adgv.Columns["maintenanceEngineerNames"];
                c.HeaderText = "工程師";
                c.ValueType = typeof(string);
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                //c = adgv.Columns["deviceList"];
                //c.HeaderText = "機台編號";
                //c.ValueType = typeof(string);
                //c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                //c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

                c = adgv.Columns[nameof(TaskOrder.Workstation)];
                c.HeaderText = "工站";
                c.ValueType = typeof(string);
                c.DefaultCellStyle.Format = "HH:mm";
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                c = adgv.Columns["modelName"];
                c.HeaderText = "機種";
                c.ValueType = typeof(string);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

                c = adgv.Columns[nameof(TaskOrder.RepairDuration)];
                c.HeaderText = "維修工時";
                c.ValueType = typeof(TimeSpan);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //c.DefaultCellStyle.Format = "hh:mm";

                c = adgv.Columns[nameof(TaskOrder.OutageDuration)];
                c.HeaderText = "停動工時";
                c.ValueType = typeof(TimeSpan);
                c.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //c.DefaultCellStyle.Format = "hh:mm";

                adgv.CellFormatting += (s, e) =>
                {
                    if (adgv.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                        && e.Value is TimeSpan ts)
                    {
                        e.Value = ts.ToString(@"hh\:mm");
                        e.FormattingApplied = true;
                    }
                };

                adgv.AllowUserToAddRows = false;
                adgv.AllowUserToDeleteRows = false;
                adgv.AllowDrop = false;
                adgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                adgv.SetFilterCustomEnabled(adgv.Columns[nameof(TaskOrder.RepairDuration)], false);
                adgv.SetFilterCustomEnabled(adgv.Columns[nameof(TaskOrder.OutageDuration)], false);
            }
        }

        private void adgv_SelectionChanged(object sender, EventArgs e)
        {
            var items = adgv.SelectedRows;
            if (items != null && items.Count > 0)
            {
                DataGridViewRow selectedRow = adgv.SelectedRows[0];
                var workOrderNo = selectedRow.Cells[1].Value.ToString();

                var to = _db.TaskOrders
                    .Include(nameof(TaskOrder.MaintenanceEngineers) + "." + nameof(TaskOrderEngineer.Engineer))
                    .Include(nameof(TaskOrder.TaskOrderDevices) + "." + nameof(TaskOrderDevice.Device))
                    .Include(nameof(TaskOrder.Status))
                    .Include(nameof(TaskOrder.IssueCategory))
                    .Where(x => x.WorkOrderNo == workOrderNo)
                    .ToList()[0];

                OrderNo.Text = to.OrderNo.ToString();
                uiLabel_OrderNo.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OrderNo));

                WorkOrderNo.Text = workOrderNo;
                uiLabel_WorkOrderNo.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.WorkOrderNo));

                Creator.Text = to.CreatorFullName;
                uiLabel_Creator.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Creator));

                CreationDate.Text = to.CreationDateString;
                uiLabel_CreationDate.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.CreationDate));

                AcceptedTime.Text = to.AcceptedTimeString;
                uiLabel_AcceptedTime.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.AcceptedTime));

                Status.Text = to.Status.StatusName;
                uiLabel_Status.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Status));

                MaintenanceUnit.Text = to.UnitString;
                uiLabel_MaintenanceUnit.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.MaintenanceUnit));

                MaintenanceEngineer.Text = to.EngineerString;
                uiLabel_MaintenanceEngineer.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.MaintenanceEngineers));

                DeviceList.Text = to.DeviceString;
                uiLabel_DeviceList.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderDevices));

                Model.Text = to.ModelName;
                uiLabel_Model.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Model));

                Workstation.Text = to.Workstation;
                uiLabel_WorkStation.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Workstation));

                IssueCategory.Text = to.IssueCategoryString;
                uiLabel_IssueCategory.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.IssueCategory));

                IssueDescription.Text = to.IssueDescription;
                uiLabel_IssueDescription.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.IssueDescription));

                Details.Text = to.Details;
                uiLabel_Details.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Details));

                RequestingUnit.Text = to.RequestingUnitString;
                uiLabel_RequestingUnit.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RequestingUnit));

                RequestingEmployee.Text = to.RequestingEmployeeString;
                uiLabel_RequestingEmployee.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RequestingEmployee));

                RequestingUnitResponse.Text = to.RequestingUnitResponse;
                uiLabel_RequestingUnitResponse.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RequestingUnitResponse));

                RepairStarted.Text = to.RepairStartedString;
                uiLabel_RepairStarted.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RepairStarted));

                RepairCompleted.Text = to.RepairCompletedString;
                uiLabel_RepairCompleted.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RepairCompleted));

                RepairDuration.Text = to.RepairDuration.ToString(@"hh\:mm");
                uiLabel_RepairDuration.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RepairDuration));

                OutageStarted.Text = to.OutageStartedString;
                uiLabel_OutageStarted.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OutageStarted));

                OutageEnded.Text = to.OutageEndedString;
                uiLabel_OutageEnded.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OutageEnded));

                OutageDuration.Text = to.OutageDuration.ToString(@"hh\:mm");
                uiLabel_OutageDuration.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OutageDuration));
            }
        }

        private void ShowTaskOrder(TaskOrder taskOrder)
        {

        }

        private void uiLabel_RequestingUnit_Click(object sender, EventArgs e)
        {

        }
    }
}
