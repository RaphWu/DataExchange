﻿/*
 * 資料查詢改為非同步。
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UIPage
    {
        private readonly CoreContext _context;
        private readonly MaintiFlowFieldName _fieldName;

        private List<SummaryViewModel> _svm;
        private DataTable _dt;
        private BindingSource _bs = new BindingSource();

        public MaintiFlowSummary(CoreContext coreContext, MaintiFlowFieldName maintiFlowFieldName)
        {
            InitializeComponent();
            _context = coreContext;
            _fieldName = maintiFlowFieldName;

            adgv.SetDoubleBuffered();
            adgv.MultiSelect = false;
            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

            _dt = new DataTable();
            SwitchEditMode(false);

            StrongReferenceMessenger.Default.Register<MaintiFlowDataChangedNotification>(this, async (r, m) =>
            {
                await UpdateData();
            });
        }

        private void MaintiFlowSummary_FormClosing(object sender, FormClosingEventArgs e)
        {
            StrongReferenceMessenger.Default.Unregister<MaintiFlowDataChangedNotification>(this);
        }

        private async void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            adgv.AutoGenerateColumns = false; // 這行要在UpdateData()之前，不然表格會亂掉
            await UpdateData();

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.OrderNo),
                HeaderText = "編號",
                ValueType = typeof(int),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.WorkOrderNo),
                HeaderText = "工單",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.CreatorName),
                HeaderText = "建檔人員",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.CreationDate),
                HeaderText = "建檔日期",
                ValueType = typeof(DateTime),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.Status),
                HeaderText = "狀態",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.MaintenanceUnit),
                HeaderText = "維護單位",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.Engineers),
                HeaderText = "工程師",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.MachineId),
                HeaderText = "機台編號",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.Workstation),
                HeaderText = "工站",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.ModelName),
                HeaderText = "機種",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.RepairDuration),
                HeaderText = "維修工時",
                ValueType = typeof(TimeSpan),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(SummaryViewModel.OutageDuration),
                HeaderText = "停動工時",
                ValueType = typeof(TimeSpan),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            // TimeSpan的Format須另外設定
            adgv.CellFormatting += (s, e) =>
            {
                if (adgv.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                    && e.Value is TimeSpan ts)
                {
                    string days = ts.Days > 0 ? $"{ts.Days}d " : "";
                    e.Value = $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
                    e.FormattingApplied = true;
                }
            };

            adgv.AllowUserToAddRows = false;
            adgv.AllowUserToDeleteRows = false;
            adgv.AllowDrop = false;
            adgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            adgv.RowHeadersWidth = 20;
            adgv.SetFilterCustomEnabled(adgv.Columns[nameof(TaskOrder.RepairDuration)], false);
            adgv.SetFilterCustomEnabled(adgv.Columns[nameof(TaskOrder.OutageDuration)], false);

            // 下方
            Binding bs;

            OrderNo.DataBindings.Clear();
            OrderNo.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.OrderNo));
            uiLabel_OrderNo.Text = _fieldName.OrderNo;

            WorkOrderNo.DataBindings.Clear();
            WorkOrderNo.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.WorkOrderNo));
            uiLabel_WorkOrderNo.Text = _fieldName.WorkOrderNo;

            Creator.DataBindings.Clear();
            Creator.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.CreatorName));
            uiLabel_Creator.Text = _fieldName.Creator;

            bs = new Binding("Text", _bs, nameof(SummaryViewModel.CreationDate));
            bs.Format += (s, e) =>
            {
                if (e.Value is DateTime dt)
                    e.Value = dt.ToString("yyyy/MM/dd");
                else
                    e.Value = string.Empty;
            };
            CreationDate.DataBindings.Clear();
            CreationDate.DataBindings.Add(bs);
            uiLabel_CreationDate.Text = _fieldName.CreationDate;

            bs = new Binding("Text", _bs, nameof(SummaryViewModel.AcceptedTime));
            bs.Format += (s, e) =>
            {
                if (e.Value is DateTime dt)
                    e.Value = dt.ToString("yyyy/MM/dd");
                else
                    e.Value = string.Empty;
            };
            AcceptedTime.DataBindings.Clear();
            AcceptedTime.DataBindings.Add(bs);
            uiLabel_AcceptedTime.Text = _fieldName.AcceptedTime;

            Status.DataBindings.Clear();
            Status.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Status));
            uiLabel_Status.Text = _fieldName.Status;

            MaintenanceUnit.DataBindings.Clear();
            MaintenanceUnit.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.MaintenanceUnit));
            uiLabel_MaintenanceUnit.Text = _fieldName.MaintenanceUnit;

            MaintenanceEngineer.DataBindings.Clear();
            MaintenanceEngineer.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Engineers));
            uiLabel_MaintenanceEngineer.Text = _fieldName.Engineers;

            MachineList.DataBindings.Clear();
            MachineList.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.MachineId));
            uiLabel_MachineList.Text = _fieldName.Machine;

            Model.DataBindings.Clear();
            Model.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.ModelName));
            uiLabel_Model.Text = _fieldName.Model;

            Workstation.DataBindings.Clear();
            Workstation.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Workstation));
            uiLabel_WorkStation.Text = _fieldName.Workstation;

            IssueCategory.DataBindings.Clear();
            IssueCategory.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.IssueCategory));
            uiLabel_IssueCategory.Text = _fieldName.IssueCategory;

            IssueDescription.DataBindings.Clear();
            IssueDescription.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.IssueDescription));
            uiLabel_IssueDescription.Text = _fieldName.IssueDescription;

            Details.DataBindings.Clear();
            Details.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Details));
            uiLabel_Details.Text = _fieldName.Details;

            RequestingUnit.DataBindings.Clear();
            RequestingUnit.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RequestingUnit));
            uiLabel_RequestingUnit.Text = _fieldName.RequestingUnit;

            RequestingEmployee.DataBindings.Clear();
            RequestingEmployee.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RequestingEmployee));
            uiLabel_RequestingEmployee.Text = _fieldName.RequestingEmployee;

            RequestingUnitResponse.DataBindings.Clear();
            RequestingUnitResponse.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Response));
            uiLabel_RequestingUnitResponse.Text = _fieldName.Response;

            RepairStarted.DataBindings.Clear();
            RepairStarted.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RepairStarted));
            uiLabel_RepairStarted.Text = _fieldName.RepairStarted;

            RepairCompleted.DataBindings.Clear();
            RepairCompleted.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RepairCompleted));
            uiLabel_RepairCompleted.Text = _fieldName.RepairCompleted;

            bs = new Binding("Text", _bs, nameof(SummaryViewModel.RepairDuration));
            bs.Format += (s, e) =>
            {
                if (e.Value is TimeSpan ts)
                {
                    string days = ts.Days > 0 ? $"{ts.Days}d " : "";
                    e.Value = $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
                }
                else
                    e.Value = string.Empty;
            };
            RepairDuration.DataBindings.Clear();
            RepairDuration.DataBindings.Add(bs);
            uiLabel_RepairDuration.Text = _fieldName.RepairDuration;

            OutageStarted.DataBindings.Clear();
            OutageStarted.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.OutageStarted));
            uiLabel_OutageStarted.Text = _fieldName.OutageStarted;

            OutageEnded.DataBindings.Clear();
            OutageEnded.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.OutageEnded));
            uiLabel_OutageEnded.Text = _fieldName.OutageEnded;

            bs = new Binding("Text", _bs, nameof(SummaryViewModel.OutageDuration));
            bs.Format += (s, e) =>
            {
                if (e.Value is TimeSpan ts)
                {
                    string days = ts.Days > 0 ? $"{ts.Days}d " : "";
                    e.Value = $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
                }
                else
                    e.Value = string.Empty;
            };
            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add(bs);
            uiLabel_OutageDuration.Text = _fieldName.OutageDuration;

            Responsible.DataBindings.Clear();
            Responsible.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Responsible));
            uiLabel_Responsible.Text = _fieldName.Responsible;
        }

        private async Task UpdateData()
        {
            var taskOrders = await _context.TaskOrders
                .Include(t => t.Machine)
                .Include(t => t.Creator)
                .Include(t => t.Workstation)
                .Include(t => t.Workstation.Model)
                .Include(t => t.MaintenanceUnit)
                .Include(t => t.RequestingUnit)
                .Include(t => t.IssueCategory)
                .OrderByDescending(u => u.OrderNo)
                .ToListAsync();

            _svm = taskOrders
                .Select(u => new SummaryViewModel
                {
                    WorkOrderNo = u.WorkOrderNo,
                    Status = u.Status.GetDescription(),
                    MachineId = u.Machine.MachineId,
                    ModelName = u.Workstation.Model.ModelName,
                    Workstation = u.Workstation.WorkstationName,
                    CreatorName = (u.Creator != null) ? u.Creator.Name : string.Empty,
                    CreationDate = u.CreationDate,

                    MaintenanceUnit = u.MaintenanceUnit?.UnitName ?? string.Empty,
                    Engineers = string.Join(", ", u.Engineers.Select(emp => emp.Name)),
                    AcceptedTime = u.AcceptedTime,
                    IssueCategory = u.IssueCategoryString,
                    IssueDescription = u.IssueDescription,
                    Details = u.Details,
                    RepairStarted = u.RepairStarted,
                    RepairCompleted = u.RepairCompleted,
                    RepairDuration = u.RepairDuration,

                    RequestingUnit = u.RequestingUnitString,
                    RequestingEmployee = u.RequestingEmployeeString,
                    Response = u.Response,
                    OutageStarted = u.OutageStarted,
                    OutageEnded = u.OutageEnded,
                    OutageDuration = u.OutageDuration,

                    Responsible = u.Responsible,
                    OrderNo = u.OrderNo,
                })
                .ToList();

            _bs.DataSource = _svm;
            _dt = _svm.ToDataTable();
            adgv.DataSource = _dt;
        }

        /********************
         * 編輯模式
         ********************/
        private void SwitchEditMode(bool editMode)
        {
            EditModeSwitch.Active = editMode;
            adgv.SelectionMode = editMode ? DataGridViewSelectionMode.CellSelect : DataGridViewSelectionMode.FullRowSelect;
            adgv.ReadOnly = !editMode;
            adgv.Refresh();
        }

        private void EditModeSwitch_ValueChanged(object sender, bool value)
        {
            SwitchEditMode(value);
        }

        /********************
         * adgv
         ********************/
        private void adgv_SelectionChanged(object sender, EventArgs e)
        {
            if (adgv.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                int selectedOrderNo = Convert.ToInt32(drv["OrderNo"]);
                int index = _svm.FindIndex(x => x.OrderNo == selectedOrderNo);
                if (index >= 0)
                    _bs.Position = index;
            }
        }

        private void uiButton_Edit_Click(object sender, EventArgs e)
        {
        }

        private void uiButton_Delete_Click(object sender, EventArgs e)
        {
            if (adgv.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                string selectedKey = drv["WorkOrderNo"].ToString();
                var item = _svm.FirstOrDefault(x => x.WorkOrderNo == selectedKey);
                if (item != null)
                {
                    string msg = $"確定刪除這筆資料嗎？\n\n{_fieldName.OrderNo}: {item.OrderNo}\n{_fieldName.WorkOrderNo}: {item.WorkOrderNo}\n{_fieldName.Creator}: {item.CreatorName}\n{_fieldName.Model}: {item.ModelName}";
                    if (MessageBox.Show(msg, "刪除確認",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Warning,
                                        MessageBoxDefaultButton.Button2)
                        == DialogResult.Yes)
                    {
                        var entity = _context.TaskOrders.FirstOrDefault(x => x.WorkOrderNo == item.WorkOrderNo);
                        if (entity != null)
                        {
                            try
                            {
                                _context.TaskOrders.Remove(entity);
                                _context.SaveChanges();

                                _svm.Remove(item);

                                foreach (DataRow row in _dt.Rows)
                                {
                                    if (row["WorkOrderNo"].ToString() == selectedKey)
                                    {
                                        _dt.Rows.Remove(row);
                                        break;
                                    }
                                }

                                _bs.ResetBindings(false);

                                MessageBox.Show($"{_fieldName.WorkOrderNo}: {item.WorkOrderNo} 已刪除！");
                            }
                            //catch (DbUpdateConcurrencyException duce)
                            //{
                            //    emsg = "資料庫命令不會影響預期的資料列數目。";
                            //}
                            //catch (DbUpdateException due)
                            //{
                            //    emsg = "傳送更新至資料庫時發生錯誤。";
                            //}
                            //catch (DbEntityValidationException deve)
                            //{
                            //    emsg = "儲存已中止，因為實體屬性值的驗證失敗。";
                            //}
                            //catch (NotSupportedException nse)
                            //{
                            //    emsg = "嘗試使用不支援的行為，例如在相同的內容實例上同時執行多個非同步命令。";
                            //}
                            //catch (ObjectDisposedException ode)
                            //{
                            //    emsg = "內容或連線已處置。";
                            //}
                            //catch (InvalidOperationException ioe)
                            //{
                            //    emsg = "嘗試在將命令傳送至資料庫之前或之後，嘗試處理內容中的實體時發生一些錯誤。";
                            //}
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "資料庫變更失敗");
                            }
                        }
                    }
                }
            }
        }
    }
}
