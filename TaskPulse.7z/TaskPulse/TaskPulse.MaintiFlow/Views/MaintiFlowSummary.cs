﻿/*
 * 資料查詢改為非同步。
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Helper;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UserControl
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;
        private readonly ICore _core;
        private readonly IPermissionService _permission;
        private readonly MultiSelector _mSel;

        private int _thisTaskOrderId;
        private TaskOrderViewModel _tovm;
        private List<TaskOrderViewModel> _tovms = new List<TaskOrderViewModel>();
        private DataTable _dt;
        private BindingSource _bs = new BindingSource();

        public bool IsEnabled
        {
            get { return _isEnabled; }
            set { _isEnabled = value; }
        }
        private bool _isEnabled;

        public MaintiFlowSummary(CoreContext coreContext,
                                 CoreData coreData,
                                 MaintiFlowData maintiFlowData,
                                 ICore core,
                                 IPermissionService permissionService,
                                 MultiSelector multiSelector)
        {
            InitializeComponent();
            _context = coreContext;
            _coreData = coreData;
            _flowData = maintiFlowData;
            _core = core;
            _permission = permissionService;
            _mSel = multiSelector;

            _dt = new DataTable();
            _dt.Columns.Add(PropertyText.Title.WorkOrderNo, typeof(string));
            _dt.Columns.Add(PropertyText.Title.Creator, typeof(string));
            _dt.Columns.Add(PropertyText.Title.CreationDate, typeof(DateTime));
            _dt.Columns.Add(PropertyText.Title.Status, typeof(string));
            _dt.Columns.Add(PropertyText.Title.MaintenanceUnit, typeof(string));
            _dt.Columns.Add(PropertyText.Title.Engineer, typeof(string));
            _dt.Columns.Add(PropertyText.Title.Machine, typeof(string));
            _dt.Columns.Add(PropertyText.Title.ModelName, typeof(string));
            _dt.Columns.Add(PropertyText.Title.Workstation, typeof(string));
            _dt.Columns.Add(PropertyText.Title.RepairDuration, typeof(TimeSpan));
            _dt.Columns.Add(PropertyText.Title.OutageDuration, typeof(TimeSpan));

            SwitchEditMode(false);
            CommonStyles.SetButton(btnSave);
            EditModeSwitch.ActiveColor = CommonStyles.BackColor;
            EditModeSwitch.InActiveColor = Color.DarkRed;
            Creator.ButtonFillColor = CommonStyles.BackColor;
            Engineers.ButtonFillColor = CommonStyles.BackColor;
            MachineCode.ButtonFillColor = CommonStyles.BackColor;
            ModelWs.ButtonFillColor = CommonStyles.BackColor;
            FeedbackEmployee.ButtonFillColor = CommonStyles.BackColor;

            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (r, m) =>
            {
                UserChanged();
            });

            WeakReferenceMessenger.Default.Register<NotifyMaintiFlowCacheUpdated>(this, async (r, m) =>
            {
                var result = await UpdateDataAsync();
                UpdateDataToUI(result.List, result.Table);
            });
        }

        private void UserChanged()
        {
            bool allowEdit = _permission.HasControlAccess(PermissionWords.MODULE_MAINTI_FLOW,
                                                          PermissionWords.PAGE_SUMMARY,
                                                          "*",
                                                          PermissionWords.ACTION_EDIT);
            IsEnabled = !allowEdit;
            btnSave.Visible = allowEdit;
            EditModeSwitch.Visible = allowEdit;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                _tovms = null;
                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        private async void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            UserChanged();

            var result = await UpdateDataAsync();
            UpdateDataToUI(result.List, result.Table);

            ADGV.AutoGenerateColumns = false;
            ADGV.DataSource = _bs;

            //ADGV.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = PropertyString.Name.TaskOrderId,
            //    HeaderText = PropertyString.Title.TaskOrderId,
            //    ValueType = typeof(int),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            //    DefaultCellStyle = new DataGridViewCellStyle()
            //    {
            //        Alignment = DataGridViewContentAlignment.MiddleCenter,
            //    },
            //});
            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyString.Name.TaskOrderId], false);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.WorkOrderNo,
                HeaderText = PropertyText.Title.WorkOrderNo,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.WorkOrderNo], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.CreatorName,
                HeaderText = PropertyText.Title.Creator,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.Creator], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.CreationDateString,
                HeaderText = PropertyText.Title.CreationDate,
                ValueType = typeof(DateTime),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.CreationDateTime], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.OrderStatusString,
                HeaderText = PropertyText.Title.Status,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.OrderStatusString], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.MaintenanceUnit,
                HeaderText = PropertyText.Title.MaintenanceUnit,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.MaintenanceUnit], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.EngineerString,
                HeaderText = PropertyText.Title.Engineer,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.Engineers], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.MachineCode,
                HeaderText = PropertyText.Title.Machine,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.MachineCode], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.ModelName,
                HeaderText = PropertyText.Title.ModelName,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.ModelName], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.WorkstationName,
                HeaderText = PropertyText.Title.Workstation,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyText.Name.WorkstationName], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.RepairDurationString,
                HeaderText = PropertyText.Title.RepairDuration,
                ValueType = typeof(TimeSpan),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterCustomEnabled(ADGV.Columns[PropertyText.Name.RepairDuration], false);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.OutageDurationString,
                HeaderText = PropertyText.Title.OutageDuration,
                ValueType = typeof(TimeSpan),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterCustomEnabled(ADGV.Columns[PropertyText.Name.OutageDuration], false);

            // TimeSpan的Format須另外設定
            ADGV.CellFormatting += (s, e) =>
            {
                if (ADGV.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                    && e.Value is TimeSpan ts)
                {
                    string days = ts.Days > 0 ? $"{ts.Days}d " : "";
                    e.Value = $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
                    e.FormattingApplied = true;
                }
            };

            //adgvSearchToolBar.SetColumns(ADGV.Columns);
            //CommonStyles.SetAdvancedDataGridView(ADGV, filterAndSort: true);
            CommonStyles.SetAdvancedDataGridView(ADGV);

            // 下方
            uiLabel_OrderNo.Text = PropertyText.Title.TaskOrderId;
            OrderNo.DataBindings.Clear();
            OrderNo.DataBindings.Add("Text", _bs, PropertyText.Name.TaskOrderId, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_WorkOrderNo.Text = PropertyText.Title.WorkOrderNo;
            WorkOrderNo.DataBindings.Clear();
            WorkOrderNo.DataBindings.Add("Text", _bs, PropertyText.Name.WorkOrderNo, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_Creator.Text = PropertyText.Title.Creator;
            Creator.DataBindings.Clear();
            Creator.DataBindings.Add("Text", _bs, PropertyText.Name.CreatorName, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_CreationDate.Text = PropertyText.Title.CreationDate;
            CreationDate.DataBindings.Clear();
            CreationDate.DataBindings.Add("Value", _bs, PropertyText.Name.CreationDateTime, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
            AcceptedTime.DataBindings.Clear();
            AcceptedTime.DataBindings.Add("Value", _bs, PropertyText.Name.AcceptedTime, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_Status.Text = PropertyText.Title.Status;
            var statusList = Enum.GetValues(typeof(FlowStatus))
                .Cast<FlowStatus>()
                .OrderByDescending(s => (int)s)
                .Select(s => new { Value = (int)s, Text = s.GetDescription() })
                .ToList();
            Status.DisplayMember = "Text";
            Status.ValueMember = "Value";
            Status.DataSource = statusList;
            Status.DataBindings.Clear();
            Status.DataBindings.Add("SelectedValue", _bs, PropertyText.Name.OrderStatusId, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
            var lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
            lvm.AddRange(_context.MaintenanceUnits
                .Select(m => new ListViewModel()
                {
                    NullableId = m.Id,
                    Name = m.UnitName,
                })
                .ToList());
            MaintenanceUnit.DataSource = lvm;
            MaintenanceUnit.DisplayMember = "Name";
            MaintenanceUnit.ValueMember = "NullableId";
            MaintenanceUnit.DataBindings.Clear();
            MaintenanceUnit.DataBindings.Add("Text", _bs, PropertyText.Name.MaintenanceUnit, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_MaintenanceEngineer.Text = PropertyText.Title.Engineer;
            Engineers.DataBindings.Clear();
            Engineers.DataBindings.Add("Text", _bs, PropertyText.Name.EngineerString, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_MachineList.Text = PropertyText.Title.Machine;
            MachineCode.DataBindings.Clear();
            MachineCode.DataBindings.Add("Text", _bs, PropertyText.Name.MachineCode, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_ModelWs.Text = PropertyText.Title.ModelWorkstationName;
            ModelWs.DataBindings.Clear();
            ModelWs.DataBindings.Add("Text", _bs, PropertyText.Name.ModelWorkstationName, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_IssueCategory.Text = PropertyText.Title.IssueCategory;
            lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
            lvm.AddRange(_context.IssueCategories
                .Select(m => new ListViewModel()
                {
                    NullableId = m.Id,
                    Name = m.CategoryName,
                })
                .ToList());
            IssueCategory.DataSource = lvm;
            IssueCategory.DisplayMember = "Name";
            IssueCategory.ValueMember = "NullableId"; IssueCategory.DataBindings.Clear();
            IssueCategory.DataBindings.Add("Text", _bs, PropertyText.Name.IssueCategoryString, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_IssueDescription.Text = PropertyText.Title.IssueDescription;
            IssueDescription.DataBindings.Clear();
            IssueDescription.DataBindings.Add("Text", _bs, PropertyText.Name.IssueDescription, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_Details.Text = PropertyText.Title.Details;
            Details.DataBindings.Clear();
            Details.DataBindings.Add("Text", _bs, PropertyText.Name.Details, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
            var rUnitList = _context.Departments
                .OrderBy(r => r.OrderNo)
                .Select(r => new ListViewModel { Id = r.Id, Name = r.DepartmentName, })
                .ToList();
            RequestingUnit.DataSource = rUnitList;
            RequestingUnit.DisplayMember = "Name";
            RequestingUnit.ValueMember = "Id";
            RequestingUnit.DataBindings.Clear();
            RequestingUnit.DataBindings.Add("Text", _bs, PropertyText.Name.RequestingUnitString, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_FeedbackEmployee.Text = PropertyText.Title.FeedbackEmployee;
            FeedbackEmployee.DataBindings.Clear();
            FeedbackEmployee.DataBindings.Add("Text", _bs, PropertyText.Name.FeedbackEmployeeString, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_RequestingUnitResponse.Text = PropertyText.Title.Feedback;
            RequestingUnitFeedback.DataBindings.Clear();
            RequestingUnitFeedback.DataBindings.Add("Text", _bs, PropertyText.Name.Feedback, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_RepairStarted.Text = PropertyText.Title.RepairStarted;
            RepairStarted.DataBindings.Clear();
            RepairStarted.DataBindings.Add("Value", _bs, PropertyText.Name.RepairStarted, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
            RepairCompleted.DataBindings.Clear();
            RepairCompleted.DataBindings.Add("Value", _bs, PropertyText.Name.RepairCompleted, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_RepairDuration.Text = PropertyText.Title.RepairDuration;
            RepairDuration.DataBindings.Clear();
            RepairDuration.DataBindings.Add("Text", _bs, PropertyText.Name.RepairDurationString, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_FillingTime.Text = PropertyText.Title.FillingTime;
            FillingTime.DataBindings.Clear();
            FillingTime.DataBindings.Add("Value", _bs, PropertyText.Name.FillingTime, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_OutageStarted.Text = PropertyText.Title.OutageStarted;
            OutageStarted.DataBindings.Clear();
            OutageStarted.DataBindings.Add("Value", _bs, PropertyText.Name.OutageStarted, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_OutageEnded.Text = PropertyText.Title.OutageEnded;
            OutageEnded.DataBindings.Clear();
            OutageEnded.DataBindings.Add("Value", _bs, PropertyText.Name.OutageEnded, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_OutageDuration.Text = PropertyText.Title.OutageDuration;
            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add("Text", _bs, PropertyText.Name.OutageDurationString, true, DataSourceUpdateMode.OnPropertyChanged);

            uiLabel_Responsible.Text = PropertyText.Title.Responsible;
            Responsible.DataBindings.Clear();
            Responsible.DataBindings.Add("Text", _bs, PropertyText.Name.Responsible, true, DataSourceUpdateMode.OnPropertyChanged);
        }

        //private void UpdateDataAsync()
        //{
        //    //var taskOrders = await _context.TaskOrders
        //    //    .Include(t => t.CreatorName.Department)
        //    //    .Include(t => t.CreatorName.Title)
        //    //    .Include(t => t.EngineerString)
        //    //    .Include(t => t.Machine)
        //    //    .Include(t => t.WorkstationName.ModelWorkstation)
        //    //    .Include(t => t.MaintenanceUnit)
        //    //    .Include(t => t.IssueCategoryString)
        //    //    .Include(t => t.RequestingUnitString)
        //    //    .Include(t => t.FeedbackEmployeeString)
        //    //    .OrderByDescending(u => u.Id)
        //    //    .AsNoTracking()
        //    //    .ToListAsync();

        //    _tovms = _flowData.TaskOrders.Select(u => new TaskOrderViewModel
        //    {
        //        Id = u.Id,
        //        WorkOrderNo = u.WorkOrderNo,
        //        StatusString = u.StatusString,
        //        CreatorName = u.CreatorName,
        //        CreatorNameWithDepartment = u.CreatorNameWithDepartment,
        //        CreationDateTime = u.CreationDateTime,
        //        CreationDateTimeString = u.CreationDateTimeString,
        //        CreationDateString = u.CreationDateString,
        //        MachineCode = u.MachineCode,
        //        ModelName = u.ModelName,
        //        WorkstationId = u.WorkstationId,
        //        WorkstationName = u.WorkstationName,
        //        ModelWorkstationName = u.ModelWorkstationName,

        //        MaintenanceUnit = u.MaintenanceUnitString,
        //        EngineerString = u.EngineerString,
        //        AcceptedTime = u.AcceptedTime,
        //        AcceptedTimeString = u.AcceptedTimeString,
        //        StatusId = u.StatusId,
        //        IssueCategoryString = u.IssueCategoryString,
        //        IssueDescription = u.IssueDescription,
        //        Details = u.Details,
        //        RepairStarted = u.RepairStarted,
        //        RepairStartedString = u.RepairStartedString,
        //        RepairCompleted = u.RepairCompleted,
        //        RepairCompletedString = u.RepairCompletedString,
        //        RepairDuration = u.RepairDuration,
        //        RepairDurationString = u.RepairDurationString,
        //        FillingTimeString = u.FillingTimeString,

        //        RequestingUnitString = u.RequestingUnitString,
        //        FeedbackEmployeeString = u.FeedbackEmployeeString,
        //        Feedback = u.Feedback,
        //        OutageStarted = u.OutageStarted,
        //        OutageStartedString = u.OutageStartedString,
        //        OutageEnded = u.OutageEnded,
        //        OutageEndedString = u.OutageEndedString,
        //        OutageDuration = u.OutageDuration,
        //        OutageDurationString = u.OutageDurationString,

        //        Responsible = u.Responsible,
        //    }).ToList();
        //    //_tovms = new BindingList<TaskOrderViewModel>(svm);

        //    _dt = _tovms.ToDataTable();
        //    _bs.DataSource = _dt;

        //    //ADGV.AutoGenerateColumns = false;
        //    //ADGV.DataSource = null;
        //    //ADGV.DataSource = _bs;
        //    //ADGV.VirtualMode = true;
        //    //_bs.DataSource = _tovms;
        //    //_bs.DataSource = _context.TaskOrders.Local.ToBindingList();
        //    //_bs.ResetBindings(true);
        //    //ADGV.RowCount = _svm.Count;
        //    //ADGV.CellValueNeeded += new DataGridViewCellValueEventHandler(ADGV_CellValueNeeded);

        //    _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_tovms.Count()} 筆資料"));
        //}

        private Task<(List<TaskOrderViewModel> List, DataTable Table)> UpdateDataAsync()
        {
            return Task.Run(() =>
            {
                var list = _flowData.TaskOrders.Select(u => new TaskOrderViewModel
                {
                    Id = u.Id,
                    WorkOrderNo = u.WorkOrderNo,
                    StatusString = u.StatusString,
                    CreatorName = u.CreatorName,
                    CreatorNameWithDepartment = u.CreatorNameWithDepartment,
                    CreationDateTime = u.CreationDateTime,
                    CreationDateTimeString = u.CreationDateTimeString,
                    CreationDateString = u.CreationDateString,
                    MachineCode = u.MachineCode,
                    ModelName = u.ModelName,
                    WorkstationId = u.WorkstationId,
                    WorkstationName = u.WorkstationName,
                    ModelWorkstationName = u.ModelWorkstationName,
                    MaintenanceUnit = u.MaintenanceUnitString,
                    EngineerString = u.EngineerString,
                    AcceptedTime = u.AcceptedTime,
                    AcceptedTimeString = u.AcceptedTimeString,
                    StatusId = u.StatusId,
                    IssueCategoryString = u.IssueCategoryString,
                    IssueDescription = u.IssueDescription,
                    Details = u.Details,
                    RepairStarted = u.RepairStarted,
                    RepairStartedString = u.RepairStartedString,
                    RepairCompleted = u.RepairCompleted,
                    RepairCompletedString = u.RepairCompletedString,
                    RepairDuration = u.RepairDuration,
                    RepairDurationString = u.RepairDurationString,
                    FillingTimeString = u.FillingTimeString,
                    RequestingUnitString = u.RequestingUnitString,
                    FeedbackEmployeeString = u.FeedbackEmployeeString,
                    Feedback = u.Feedback,
                    OutageStarted = u.OutageStarted,
                    OutageStartedString = u.OutageStartedString,
                    OutageEnded = u.OutageEnded,
                    OutageEndedString = u.OutageEndedString,
                    OutageDuration = u.OutageDuration,
                    OutageDurationString = u.OutageDurationString,
                    Responsible = u.Responsible
                }).ToList();

                DataTable table = list.ToDataTable();
                return (list, table);
            });
        }

        private void UpdateDataToUI(List<TaskOrderViewModel> list, DataTable table)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => UpdateDataToUI(list, table)));
                return;
            }

            _tovms = list;
            _dt = table;

            _bs.DataSource = _dt;   // UI thread 更新 BindingSource → ADGV
        }

        private void ADGV_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e)
        {
        }

        /********************
         * 編輯模式
         ********************/
        private void SwitchEditMode(bool editMode)
        {
            IsEnabled = editMode;

            WorkOrderNo.Enabled = IsEnabled;
            Creator.Enabled = IsEnabled;
            CreationDate.Enabled = IsEnabled;
            AcceptedTime.Enabled = IsEnabled;
            Status.Enabled = IsEnabled;
            MaintenanceUnit.Enabled = IsEnabled;
            Engineers.Enabled = IsEnabled;
            MachineCode.Enabled = IsEnabled;
            ModelWs.Enabled = IsEnabled;
            IssueCategory.Enabled = IsEnabled;
            IssueDescription.Enabled = IsEnabled;
            Details.Enabled = IsEnabled;
            RequestingUnit.Enabled = IsEnabled;
            FeedbackEmployee.Enabled = IsEnabled;
            RequestingUnitFeedback.Enabled = IsEnabled;
            RepairStarted.Enabled = IsEnabled;
            RepairCompleted.Enabled = IsEnabled;
            OutageStarted.Enabled = IsEnabled;
            OutageEnded.Enabled = IsEnabled;
            Responsible.Enabled = IsEnabled;
            FillingTime.Enabled = IsEnabled;

            cbRepairStarted.Enabled = IsEnabled;
            cbRepairCompleted.Enabled = IsEnabled;
            cbOutageEnded.Enabled = IsEnabled;
            cbOutageStarted.Enabled = IsEnabled;

            btnSave.Enabled = IsEnabled;
        }

        private void EditModeSwitch_ValueChanged(object sender, bool value)
        {
            SwitchEditMode(value);
        }

        /********************
         * ADGV
         ********************/
        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                _thisTaskOrderId = Convert.ToInt32(drv[PropertyText.Name.TaskOrderId]);
                _tovm = _tovms.FirstOrDefault(x => x.Id == _thisTaskOrderId);
                int index = _tovms.IndexOf(_tovm);
                if (index >= 0)
                    _bs.Position = index;
            }
        }

        private void Button_Edit_Click(object sender, EventArgs e)
        {
        }

        private async void Button_Delete_Click(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                string selectedKey = drv[PropertyText.Name.WorkOrderNo].ToString();
                var item = _tovms.FirstOrDefault(x => x.WorkOrderNo == selectedKey);
                if (item != null)
                {
                    string msg = $"確定刪除這筆資料嗎？\n\n{PropertyText.Title.WorkOrderNo}: {item.WorkOrderNo}\n{PropertyText.Title.Creator}: {item.CreatorName}\n{PropertyText.Title.ModelName}: {item.ModelName}";
                    if (MessageBox.Show(msg, "刪除確認",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        var entity = _context.TaskOrders.FirstOrDefault(x => x.WorkOrderNo == item.WorkOrderNo);
                        if (entity != null)
                        {
                            try
                            {
                                _context.TaskOrders.Remove(entity);
                                await _context.SaveChangesAsync();

                                _tovms.Remove(item);

                                foreach (DataRow row in _dt.Rows)
                                {
                                    if (row[PropertyText.Name.WorkOrderNo].ToString() == selectedKey)
                                    {
                                        _dt.Rows.Remove(row);
                                        break;
                                    }
                                }

                                _bs.ResetBindings(false);

                                MessageBox.Show($"{PropertyText.Title.WorkOrderNo}: {item.WorkOrderNo} 已刪除！");
                            }
                            //catch (DbUpdateConcurrencyException duce)
                            //{
                            //    emsg = "資料庫命令不會影響預期的資料列數目。";
                            //}
                            //catch (DbUpdateException due)
                            //{
                            //    emsg = "傳送更新至資料庫時發生錯誤。";
                            //}
                            //catch (DbEntityValidationException deve)
                            //{
                            //    emsg = "儲存已中止，因為實體屬性值的驗證失敗。";
                            //}
                            //catch (NotSupportedException nse)
                            //{
                            //    emsg = "嘗試使用不支援的行為，例如在相同的內容實例上同時執行多個非同步命令。";
                            //}
                            //catch (ObjectDisposedException ode)
                            //{
                            //    emsg = "內容或連線已處置。";
                            //}
                            //catch (InvalidOperationException ioe)
                            //{
                            //    emsg = "嘗試在將命令傳送至資料庫之前或之後，嘗試處理內容中的實體時發生一些錯誤。";
                            //}
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "資料庫變更失敗");
                            }
                        }
                    }
                }
            }
        }

        private void RepairStarted_ValueChanged(object sender, DateTime value)
        {
            if (cbRepairStarted.Checked && _tovm != null)
            {
                if (DateTime.TryParse(RepairStarted.Text, out DateTime dt))
                    _tovm.RepairStarted = dt;
            }
            UpdateRepairDuration();
        }

        private void RepairCompleted_ValueChanged(object sender, DateTime value)
        {
            if (cbRepairCompleted.Checked && _tovm != null)
            {
                if (DateTime.TryParse(RepairCompleted.Text, out DateTime dt))
                    _tovm.RepairCompleted = dt;
            }
            UpdateRepairDuration();
        }

        private void UpdateRepairDuration()
        {
            bool hasStarted = cbRepairStarted.Checked && _tovm.RepairStarted.HasValue;
            bool hasCompleted = cbRepairCompleted.Checked && _tovm.RepairCompleted.HasValue;

            if (!hasCompleted)
                RepairCompleted.Text = "";

            if (!hasStarted)
                RepairStarted.Text = "";

            if (hasStarted)
            {
                _tovm.RepairDuration = hasCompleted
                    ? (TimeSpan)(_tovm.RepairCompleted - _tovm.RepairStarted)
                    : (TimeSpan)(DateTime.Now - _tovm.RepairStarted);
            }
            else
            {
                _tovm.RepairDuration = TimeSpan.Zero;
            }
            RepairDuration.Text = _tovm.RepairDurationString;
        }

        private void OutageStarted_ValueChanged(object sender, DateTime value)
        {
            if (cbOutageStarted.Checked && _tovm != null)
            {
                if (DateTime.TryParse(OutageStarted.Text, out DateTime dt))
                    _tovm.OutageStarted = dt;
            }
            UpdateOutageDuration();
        }

        private void OutageEnded_ValueChanged(object sender, DateTime value)
        {
            if (cbOutageEnded.Checked && _tovm != null)
            {
                if (DateTime.TryParse(OutageEnded.Text, out DateTime dt))
                    _tovm.OutageEnded = dt;
            }
            UpdateOutageDuration();
        }

        private void UpdateOutageDuration()
        {
            bool hasStarted = cbOutageStarted.Checked && _tovm.OutageStarted.HasValue;
            bool hasEnded = cbOutageEnded.Checked && _tovm.OutageEnded.HasValue;

            if (!hasEnded)
                OutageEnded.Text = "";

            if (!hasStarted)
                OutageStarted.Text = "";

            if (hasStarted)
            {
                _tovm.OutageDuration = hasEnded
                    ? (TimeSpan)(_tovm.OutageEnded - _tovm.OutageStarted)
                    : (TimeSpan)(DateTime.Now - _tovm.OutageStarted);
            }
            else
            {
                _tovm.OutageDuration = TimeSpan.Zero;
            }
            OutageDuration.Text = _tovm.OutageDurationString;
        }

        private void Creator_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>() { (string)Creator.Tag };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    var emp = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(emp.Category2) ? "" : $"{emp.Category2} » ";
                    displayText += $"{emp.IdString} {emp.Name}";

                    Creator.Tag = emp.Name;
                    Creator.Text = string.Join(" » ", displayText);
                }
                else
                {
                    Creator.Tag = "";
                    Creator.Text = "";
                }
            }
        }

        private void MachineList_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.Machine}";
            _mSel.TreeViewCaption = "機台";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.MachinesSingleTabPageCache;
            _mSel.DefaultChecked = MachineCode.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                MachineCode.Text = _mSel.ResultList.Count > 0
                    ? string.Join("; ", _mSel.ResultList.Select(r => r.Name).ToArray())
                    : "";
            }
        }

        private void ModelWs_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.ModelName}";
            _mSel.TreeViewCaption = "機種";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>() { ModelWs.Text };
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    CategoryInfo info = _mSel.ResultList[0];
                    var ws = _core.GetWorkstation(info.Id);
                    var tovm = _tovms.FirstOrDefault(x => x.Id == _thisTaskOrderId);
                    tovm.WorkstationId = ws.Id;
                    tovm.Workstation = ws;
                    //tovm.Workstation.ModelId = ws != null && ws.ModelId != null
                    //? (int?)_core.GetModel((int)ws.ModelId).Id
                    //: null;
                    tovm.Workstation.Model = _coreData.Models.FirstOrDefault(m => m.Id == ws.ModelId);
                    ModelWs.Text = tovm.Workstation.FullWorkstationName;
                }
                else
                {
                    ModelWs.Text = "";
                }
            }
        }

        private void Engineers_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = false;
            _mSel.Title = $"請選擇{PropertyText.Title.Engineer}";
            _mSel.DialogWidth = 600;
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EmployeeMultiTabPageCache;
            _mSel.DefaultChecked = Engineers.Text
                .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                List<string> emps = new List<string>();
                foreach (var emp in _mSel.ResultList)
                    emps.Add(emp.Name);
                Engineers.Text = string.Join("; ", emps);
            }
        }

        private void FeedbackEmployee_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>() { (string)Creator.Tag };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    var emp = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(emp.Category2) ? "" : $"{emp.Category2} » ";
                    displayText += $"{emp.IdString} {emp.Name}";

                    Creator.Tag = emp.Name;
                    Creator.Text = string.Join(" » ", displayText);
                }
                else
                {
                    Creator.Tag = "";
                    Creator.Text = "";
                }
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            var to = _context.TaskOrders.FirstOrDefault(x => x.Id == _thisTaskOrderId);
            if (to != null)
            {
                to.WorkOrderNo = WorkOrderNo.Text;
                to.StatusId = (int)Status.SelectedValue;
                to.CreationDateTime = CreationDate.Value;
                to.AcceptedTime = AcceptedTime.Value;
                to.IssueCategoryId = (int?)IssueCategory.SelectedValue;
                to.IssueDescription = IssueDescription.Text;
                to.Details = Details.Text;
                to.RepairStarted = RepairStarted.Value;
                to.RepairCompleted = RepairCompleted.Value;
                to.RepairDurationString = RepairDuration.Text;
                to.FillingTime = FillingTime.Value;
                to.OutageStarted = OutageStarted.Value;
                to.OutageEnded = OutageEnded.Value;
                to.OutageDurationString = OutageDuration.Text;
                to.WorkstationId = to.GetWorkstationId(ModelWs.Text, _context);

                _context.Entry(to).Collection(x => x.Engineers).Load();
                to.Engineers.Clear();
                var newEngineers = to.GetEngineers(Engineers.Text, _context);
                foreach (var eng in newEngineers)
                    to.Engineers.Add(eng);
                //to.Engineers = to.GetEngineers(Engineers.Text, _context);

                var machine = _coreData.Machines.FirstOrDefault(m => m.MachineCode == MachineCode.Text);
                to.MachineId = machine?.Id;

                var creator = await _context.Employees.FirstOrDefaultAsync(emp => emp.EmployeeName == Creator.Text);
                to.CreatorId = creator?.Id ?? 0;

                int selectedMunitId = MaintenanceUnit.SelectedValue is int i ? i : 0;
                var munit = await _context.MaintenanceUnits.FirstOrDefaultAsync(r => r.Id == selectedMunitId);
                to.MaintenanceUnitId = munit?.Id ?? 0;

                await _context.SaveChangesAsync();
                UpdateDataAsync();
                _ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("維護工單已儲存！"));
            }
        }

        private void adgvSearchToolBar_Search(object sender, Zuby.ADGV.AdvancedDataGridViewSearchToolBarSearchEventArgs e)
        {
            bool restartsearch = true;
            int startColumn = 0;
            int startRow = 0;
            if (!e.FromBegin)
            {
                bool endcol = ADGV.CurrentCell.ColumnIndex + 1 >= ADGV.ColumnCount;
                bool endrow = ADGV.CurrentCell.RowIndex + 1 >= ADGV.RowCount;

                if (endcol && endrow)
                {
                    startColumn = ADGV.CurrentCell.ColumnIndex;
                    startRow = ADGV.CurrentCell.RowIndex;
                }
                else
                {
                    startColumn = endcol ? 0 : ADGV.CurrentCell.ColumnIndex + 1;
                    startRow = ADGV.CurrentCell.RowIndex + (endcol ? 1 : 0);
                }
            }
            DataGridViewCell c = ADGV.FindCell(
                e.ValueToSearch,
                e.ColumnToSearch != null ? e.ColumnToSearch.Name : null,
                startRow,
                startColumn,
                e.WholeWord,
                e.CaseSensitive);
            if (c == null && restartsearch)
                c = ADGV.FindCell(
                    e.ValueToSearch,
                    e.ColumnToSearch != null ? e.ColumnToSearch.Name : null,
                    0,
                    0,
                    e.WholeWord,
                    e.CaseSensitive);
            if (c != null)
                ADGV.CurrentCell = c;
        }
    }
}
