﻿/*
 * 資料查詢改為非同步。
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UserControl
    {
        private readonly CoreContext _context;
        private readonly MaintiFlowData _flowData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private List<TaskOrderViewModel> _svm;
        private DataTable _dt;
        private BindingSource _bs = new BindingSource();

        public MaintiFlowSummary(CoreContext coreContext,
                                 MaintiFlowData maintiFlowData,
                                 FieldName fieldName,
                                 FieldTitle fieldTitle)
        {
            InitializeComponent();
            _context = coreContext;
            _flowData = maintiFlowData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            //ADGV.SetDoubleBuffered();
            //ADGV.MultiSelect = false;
            //ADGV.AllowUserToAddRows = false;
            //ADGV.AllowUserToDeleteRows = false;
            //ADGV.AllowDrop = false;
            //ADGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //ADGV.RowHeadersVisible = false;
            //ADGV.AllowUserToResizeRows = false;
            //AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            //AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

            _dt = new DataTable();
            SwitchEditMode(false);

            WeakReferenceMessenger.Default.Register<MaintiFlowCacheChangedNotification>(this, async (r, m) =>
            {
                await UpdateData();
            });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                _svm = null;
                WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        private async void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            await UpdateData();

            //ADGV.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = _fieldName.TaskOrderId,
            //    HeaderText = _fieldTitle.TaskOrderId,
            //    ValueType = typeof(int),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            //    DefaultCellStyle = new DataGridViewCellStyle()
            //    {
            //        Alignment = DataGridViewContentAlignment.MiddleCenter,
            //    },
            //});
            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.TaskOrderId], false);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.WorkOrderNo,
                HeaderText = _fieldTitle.WorkOrderNo,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.WorkOrderNo], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.CreatorName,
                HeaderText = _fieldTitle.Creator,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.Creator], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.CreationDateString,
                HeaderText = _fieldTitle.CreationDate,
                ValueType = typeof(DateTime),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.CreationDateTime], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.StatusString,
                HeaderText = _fieldTitle.Status,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.StatusString], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.MaintenanceUnit,
                HeaderText = _fieldTitle.MaintenanceUnit,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.MaintenanceUnit], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.EngineerString,
                HeaderText = _fieldTitle.Engineer,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.Engineers], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.MachineId,
                HeaderText = _fieldTitle.Machine,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.MachineId], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.ModelName,
                HeaderText = _fieldTitle.ModelName,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.ModelName], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.WorkstationName,
                HeaderText = _fieldTitle.Workstation,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.WorkstationName], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.RepairDurationString,
                HeaderText = _fieldTitle.RepairDuration,
                ValueType = typeof(TimeSpan),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterCustomEnabled(ADGV.Columns[_fieldName.RepairDuration], false);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.OutageDurationString,
                HeaderText = _fieldTitle.OutageDuration,
                ValueType = typeof(TimeSpan),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterCustomEnabled(ADGV.Columns[_fieldName.OutageDuration], false);

            // TimeSpan的Format須另外設定
            ADGV.CellFormatting += (s, e) =>
            {
                if (ADGV.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                    && e.Value is TimeSpan ts)
                {
                    string days = ts.Days > 0 ? $"{ts.Days}d " : "";
                    e.Value = $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
                    e.FormattingApplied = true;
                }
            };

            CommonStyles.SetAdvancedDataGridView(ADGV);

            // 下方
            uiLabel_OrderNo.Text = _fieldTitle.TaskOrderId;
            OrderNo.DataBindings.Clear();
            OrderNo.DataBindings.Add("Text", _bs, _fieldName.TaskOrderId);

            uiLabel_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;
            WorkOrderNo.DataBindings.Clear();
            WorkOrderNo.DataBindings.Add("Text", _bs, _fieldName.WorkOrderNo);

            uiLabel_Creator.Text = _fieldTitle.Creator;
            Creator.DataBindings.Clear();
            Creator.DataBindings.Add("Text", _bs, _fieldName.CreatorHalfName);

            uiLabel_CreationDate.Text = _fieldTitle.CreationDate;
            CreationDate.DataBindings.Clear();
            CreationDate.DataBindings.Add("Text", _bs, _fieldName.CreationDateTimeString);

            uiLabel_AcceptedTime.Text = _fieldTitle.AcceptedTime;
            AcceptedTime.DataBindings.Clear();
            AcceptedTime.DataBindings.Add("Text", _bs, _fieldName.AcceptedTimeString);

            uiLabel_Status.Text = _fieldTitle.Status;
            Status.DataBindings.Clear();
            Status.DataBindings.Add("Text", _bs, _fieldName.StatusString);

            uiLabel_MaintenanceUnit.Text = _fieldTitle.MaintenanceUnit;
            MaintenanceUnit.DataBindings.Clear();
            MaintenanceUnit.DataBindings.Add("Text", _bs, _fieldName.MaintenanceUnit);

            uiLabel_MaintenanceEngineer.Text = _fieldTitle.Engineer;
            MaintenanceEngineer.DataBindings.Clear();
            MaintenanceEngineer.DataBindings.Add("Text", _bs, _fieldName.EngineerString);

            uiLabel_MachineList.Text = _fieldTitle.Machine;
            MachineList.DataBindings.Clear();
            MachineList.DataBindings.Add("Text", _bs, _fieldName.MachineId);

            uiLabel_Model.Text = _fieldTitle.ModelName;
            Model.DataBindings.Clear();
            Model.DataBindings.Add("Text", _bs, _fieldName.ModelName);

            uiLabel_WorkStation.Text = _fieldTitle.Workstation;
            Workstation.DataBindings.Clear();
            Workstation.DataBindings.Add("Text", _bs, _fieldName.WorkstationName);

            uiLabel_IssueCategory.Text = _fieldTitle.IssueCategory;
            IssueCategory.DataBindings.Clear();
            IssueCategory.DataBindings.Add("Text", _bs, _fieldName.IssueCategoryString);

            uiLabel_IssueDescription.Text = _fieldTitle.IssueDescription;
            IssueDescription.DataBindings.Clear();
            IssueDescription.DataBindings.Add("Text", _bs, _fieldName.IssueDescription);

            uiLabel_Details.Text = _fieldTitle.Details;
            Details.DataBindings.Clear();
            Details.DataBindings.Add("Text", _bs, _fieldName.Details);

            uiLabel_RequestingUnit.Text = _fieldTitle.RequestingUnit;
            RequestingUnit.DataBindings.Clear();
            RequestingUnit.DataBindings.Add("Text", _bs, _fieldName.RequestingUnitString);

            uiLabel_FeedbackEmployee.Text = _fieldTitle.FeedbackEmployee;
            FeedbackEmployee.DataBindings.Clear();
            FeedbackEmployee.DataBindings.Add("Text", _bs, _fieldName.FeedbackEmployeeString);

            uiLabel_RequestingUnitResponse.Text = _fieldTitle.Feedback;
            RequestingUnitFeedback.DataBindings.Clear();
            RequestingUnitFeedback.DataBindings.Add("Text", _bs, _fieldName.Feedback);

            uiLabel_RepairStarted.Text = _fieldTitle.RepairStarted;
            RepairStarted.DataBindings.Clear();
            RepairStarted.DataBindings.Add("Text", _bs, _fieldName.RepairStartedString);

            uiLabel_RepairCompleted.Text = _fieldTitle.RepairCompleted;
            RepairCompleted.DataBindings.Clear();
            RepairCompleted.DataBindings.Add("Text", _bs, _fieldName.RepairCompletedString);

            uiLabel_RepairDuration.Text = _fieldTitle.RepairDuration;
            RepairDuration.DataBindings.Clear();
            RepairDuration.DataBindings.Add("Text", _bs, _fieldName.RepairDurationString);

            uiLabel_OutageDuration.Text = _fieldTitle.FillingTime;
            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add("Text", _bs, _fieldName.FillingTimeString);

            uiLabel_OutageStarted.Text = _fieldTitle.OutageStarted;
            OutageStarted.DataBindings.Clear();
            OutageStarted.DataBindings.Add("Text", _bs, _fieldName.OutageStartedString);

            uiLabel_OutageEnded.Text = _fieldTitle.OutageEnded;
            OutageEnded.DataBindings.Clear();
            OutageEnded.DataBindings.Add("Text", _bs, _fieldName.OutageEndedString);

            uiLabel_OutageDuration.Text = _fieldTitle.OutageDuration;
            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add("Text", _bs, _fieldName.OutageDurationString);

            uiLabel_Responsible.Text = _fieldTitle.Responsible;
            Responsible.DataBindings.Clear();
            Responsible.DataBindings.Add("Text", _bs, _fieldName.Responsible);
        }

        private async Task UpdateData()
        {
            //var taskOrders = await _context.TaskOrders
            //    .Include(t => t.CreatorName.Department)
            //    .Include(t => t.CreatorName.Title)
            //    .Include(t => t.EngineerString)
            //    .Include(t => t.Machine)
            //    .Include(t => t.WorkstationName.ModelWorkstation)
            //    .Include(t => t.MaintenanceUnit)
            //    .Include(t => t.IssueCategoryString)
            //    .Include(t => t.RequestingUnitString)
            //    .Include(t => t.FeedbackEmployeeString)
            //    .OrderByDescending(u => u.Id)
            //    .AsNoTracking()
            //    .ToListAsync();

            _svm = _flowData.TaskOrders.Select(u => new TaskOrderViewModel
            {
                Id = u.Id,
                WorkOrderNo = u.WorkOrderNo,
                StatusString = u.StatusString,
                CreatorName = u.CreatorName,
                CreatorHalfName = u.CreatorHalfName,
                CreationDate = u.CreationDateTime,
                CreationDateTimeString = u.CreationDateTimeString,
                CreationDateString = u.CreationDateString,
                MachineId = u.MachineName,
                ModelName = u.ModelName,
                WorkstationName = u.WorkstationName,

                MaintenanceUnit = u.MaintenanceUnitString,
                EngineerString = u.EngineerString,
                AcceptedTime = u.AcceptedTime,
                AcceptedTimeString = u.AcceptedTimeString,
                IssueCategoryString = u.IssueCategoryString,
                IssueDescription = u.IssueDescription,
                Details = u.Details,
                RepairStarted = u.RepairStarted,
                RepairStartedString = u.RepairStartedString,
                RepairCompleted = u.RepairCompleted,
                RepairCompletedString = u.RepairCompletedString,
                RepairDuration = u.RepairDuration,
                RepairDurationString = u.RepairDurationString,
                FillingTimeString = u.FillingTimeString,

                RequestingUnitString = u.RequestingUnitString,
                FeedbackEmployeeString = u.FeedbackEmployeeString,
                Feedback = u.Feedback,
                OutageStarted = u.OutageStarted,
                OutageStartedString = u.OutageStartedString,
                OutageEnded = u.OutageEnded,
                OutageEndedString = u.OutageEndedString,
                OutageDuration = u.OutageDuration,
                OutageDurationString = u.OutageDurationString,

                Responsible = u.Responsible,
            }).ToList();

            _bs.DataSource = _svm;
            _dt = _svm.ToDataTable();

            ADGV.AutoGenerateColumns = false;
            ADGV.DataSource = _dt;
            //ADGV.VirtualMode = true;
            //ADGV.RowCount = _svm.Count;
            //ADGV.CellValueNeeded += new DataGridViewCellValueEventHandler(ADGV_CellValueNeeded);


            WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_svm.Count()} 筆資料"));
            await Task.CompletedTask;
        }

        private void ADGV_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e)
        {
        }

        /********************
         * 編輯模式
         ********************/
        private void SwitchEditMode(bool editMode)
        {
            //EditModeSwitch.Active = editMode;
            ADGV.SelectionMode = editMode ? DataGridViewSelectionMode.CellSelect : DataGridViewSelectionMode.FullRowSelect;
            ADGV.ReadOnly = !editMode;
            ADGV.Refresh();
        }

        private void EditModeSwitch_ValueChanged(object sender, bool value)
        {
            SwitchEditMode(value);
        }

        /********************
         * ADGV
         ********************/
        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                int selectedOrderNo = Convert.ToInt32(drv[_fieldName.TaskOrderId]);
                int index = _svm.FindIndex(x => x.Id == selectedOrderNo);
                if (index >= 0)
                    _bs.Position = index;
            }
        }

        private void Button_Edit_Click(object sender, EventArgs e)
        {
        }

        private async void Button_Delete_Click(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                string selectedKey = drv[_fieldName.WorkOrderNo].ToString();
                var item = _svm.FirstOrDefault(x => x.WorkOrderNo == selectedKey);
                if (item != null)
                {
                    string msg = $"確定刪除這筆資料嗎？\n\n{_fieldTitle.WorkOrderNo}: {item.WorkOrderNo}\n{_fieldTitle.Creator}: {item.CreatorName}\n{_fieldTitle.ModelName}: {item.ModelName}";
                    if (MessageBox.Show(msg, "刪除確認",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Warning,
                                        MessageBoxDefaultButton.Button2)
                        == DialogResult.Yes)
                    {
                        var entity = _context.TaskOrders.FirstOrDefault(x => x.WorkOrderNo == item.WorkOrderNo);
                        if (entity != null)
                        {
                            try
                            {
                                _context.TaskOrders.Remove(entity);
                                await _context.SaveChangesAsync();

                                _svm.Remove(item);

                                foreach (DataRow row in _dt.Rows)
                                {
                                    if (row[_fieldName.WorkOrderNo].ToString() == selectedKey)
                                    {
                                        _dt.Rows.Remove(row);
                                        break;
                                    }
                                }

                                _bs.ResetBindings(false);

                                MessageBox.Show($"{_fieldTitle.WorkOrderNo}: {item.WorkOrderNo} 已刪除！");
                            }
                            //catch (DbUpdateConcurrencyException duce)
                            //{
                            //    emsg = "資料庫命令不會影響預期的資料列數目。";
                            //}
                            //catch (DbUpdateException due)
                            //{
                            //    emsg = "傳送更新至資料庫時發生錯誤。";
                            //}
                            //catch (DbEntityValidationException deve)
                            //{
                            //    emsg = "儲存已中止，因為實體屬性值的驗證失敗。";
                            //}
                            //catch (NotSupportedException nse)
                            //{
                            //    emsg = "嘗試使用不支援的行為，例如在相同的內容實例上同時執行多個非同步命令。";
                            //}
                            //catch (ObjectDisposedException ode)
                            //{
                            //    emsg = "內容或連線已處置。";
                            //}
                            //catch (InvalidOperationException ioe)
                            //{
                            //    emsg = "嘗試在將命令傳送至資料庫之前或之後，嘗試處理內容中的實體時發生一些錯誤。";
                            //}
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "資料庫變更失敗");
                            }
                        }
                    }
                }
            }
        }
    }
}
