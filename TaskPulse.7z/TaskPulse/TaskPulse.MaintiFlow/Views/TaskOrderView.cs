﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class TaskOrderView : UIForm
    {
        private readonly ILifetimeScope _scope;

        public string Title { set => this.Text = value; }

        /// <summary>
        /// 
        /// </summary>
        public string NewWorkOrderNo
        {
            get { return _newWorkOrderNo; }
            set
            {
                if (_newWorkOrderNo != value)
                    _newWorkOrderNo = value;
            }
        }
        private string _newWorkOrderNo;

        public TaskOrderView(ILifetimeScope lifetimeScope)
        {
            InitializeComponent();
            _scope = lifetimeScope;
        }

        public void Initialize()
        {
            if (NewWorkOrderNo == null)
                return;

            //SetReadOnly(false);
            using (var scope = _scope.BeginLifetimeScope())
            {
                var context = scope.Resolve<MaintiFlowContext>();
                var to = context.TaskOrders
                    .Include(nameof(TaskOrder.Creator))
                    .FirstOrDefault(x => x.WorkOrderNo == NewWorkOrderNo);

                OrderNo.Text = to.OrderNo.ToString();
                uiLabel_OrderNo.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OrderNo));

                WorkOrderNo.Text = to.WorkOrderNo.ToString();
                uiLabel_WorkOrderNo.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.WorkOrderNo));

                Creator.Text = to.CreatorFullName;
                uiLabel_Creator.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Creator));

                CreationDate.Text = to.CreationDateString;
                uiLabel_CreationDate.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.CreationDate));

                DeviceList.Text = to.DeviceString;
                uiLabel_DeviceList.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderDevices));

                Model.Text = to.ModelName;
                uiLabel_Model.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Model));

                Workstation.Text = to.Workstation;
                uiLabel_WorkStation.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Workstation));

                OutageStarted.Text = to.OutageStartedString;
                uiLabel_OutageStarted.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OutageStarted));

                IssueDescription.Text = to.IssueDescription;
                uiLabel_IssueDescription.Text = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.IssueDescription));
            }
            //SetReadOnly(true);
        }

        private void uiButton_Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
