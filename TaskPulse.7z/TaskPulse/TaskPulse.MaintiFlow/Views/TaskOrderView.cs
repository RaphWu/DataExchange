﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class TaskOrderView : UIForm
    {
        private readonly MaintiFlowContext _context;
        private readonly MaintiFlowFieldName _fieldName;

        public string Title { set => this.Text = value; }

        /// <summary>
        /// 
        /// </summary>
        public List<string> NewWorkOrderNos { get; set; }

        public TaskOrderView(MaintiFlowContext maintiFlowContext, MaintiFlowFieldName fieldName)
        {
            InitializeComponent();
            _context = maintiFlowContext;
            _fieldName = fieldName;
        }

        public void Initialize()
        {
            if (NewWorkOrderNos == null || NewWorkOrderNos.Count == 0)
                return;

            string newWorkOrderNos = NewWorkOrderNos[0];
            var to = _context.TaskOrders
                .Include(nameof(TaskOrder.Creator))
                .FirstOrDefault(x => x.WorkOrderNo == newWorkOrderNos);

            OrderNo.Text = to.OrderNo.ToString();
            uiLabel_OrderNo.Text = _fieldName.OrderNo;

            WorkOrderNo.Multiline = true;
            WorkOrderNo.Lines = NewWorkOrderNos.ToArray();
            uiLabel_WorkOrderNo.Text = _fieldName.WorkOrderNo;

            Creator.Text = to.CreatorFullName;
            uiLabel_Creator.Text = _fieldName.Creator;

            CreationDate.Text = to.CreationDateString;
            uiLabel_CreationDate.Text = _fieldName.CreationDate;

            MachineList.Text = to.MachineId;
            uiLabel_MachineList.Text = _fieldName.Machine;

            Model.Text = to.ModelName;
            uiLabel_Model.Text = _fieldName.Model;

            Workstation.Text = to.Workstation;
            uiLabel_WorkStation.Text = _fieldName.Workstation;

            OutageStarted.Text = to.OutageStartedString;
            uiLabel_OutageStarted.Text = _fieldName.OutageStarted;

            IssueDescription.Text = to.IssueDescription;
            uiLabel_IssueDescription.Text = _fieldName.IssueDescription;
        }

        private void uiButton_Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
