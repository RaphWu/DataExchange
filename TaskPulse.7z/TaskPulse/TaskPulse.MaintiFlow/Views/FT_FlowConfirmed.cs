﻿using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_FlowConfirmed : UIPage
    {
        public FT_FlowConfirmed()
        {
            InitializeComponent();
        }
    }
}
