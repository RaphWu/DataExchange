﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class CreateFlow : UIForm
    {
        private readonly ILifetimeScope _scope;

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 新建工單的工單號。
        /// </summary>
        public string NewWorkOrderNo { get; set; }

        public CreateFlow(ILifetimeScope lifetimeScope)
        {
            InitializeComponent();
            _scope = lifetimeScope;

            uiPanel_BasicData.TitleColor = CommonStyles.BackColor;
            uiButton_OK.FillColor = CommonStyles.BackColor;
            uiButton_OK.FillHoverColor = CommonStyles.Hover;

            this.AcceptButton = uiButton_OK;
            this.CancelButton = uiButton_Cancel;

            /********************
             * Controls
             ********************/
            string caption;
            using (var scope = _scope.BeginLifetimeScope())
            {
                var coreData = scope.Resolve<CoreData>();
                var flowData = scope.Resolve<MaintiFlowData>();

                caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Creator));
                uiLabel_Creator.Text = caption;
                var employeeList = flowData.Employees
                    .Select(e => new
                    {
                        e.EmployeeId,
                        Display = $"{e.EmployeeId}, {e.Department}, {e.Name}",
                    })
                    .ToList();
                Creator.DataSource = employeeList;
                Creator.DisplayMember = "Display";
                Creator.ValueMember = "EmployeeId";
                Creator.Watermark = caption;

                caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderDevices));
                uiLabel_DeviceList.Text = caption;
                DeviceList.Watermark = caption;
                DeviceList.ButtonFillColor = CommonStyles.BackColor;
                DeviceList.ButtonFillHoverColor = CommonStyles.Hover;

                caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Model));
                uiLabel_Model.Text = caption;
                Model.Watermark = caption;
                Model.ButtonFillColor = CommonStyles.BackColor;
                Model.ButtonFillHoverColor = CommonStyles.Hover;

                caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Workstation));
                uiLabel_Workstation.Text = caption;
                Workstation.Watermark = caption;
                Workstation.ButtonFillColor = CommonStyles.BackColor;
                Workstation.ButtonFillHoverColor = CommonStyles.Hover;

                caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OutageStarted));
                uiLabel_OutageStarted.Text = caption;
                OutageStarted.Watermark = caption;

                caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.IssueDescription));
                uiLabel_IssueDescription.Text = caption;
                IssueDescription.Watermark = caption;
            }
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            var deviceList = new List<TaskOrderDevice>();

            using (var scope = _scope.BeginLifetimeScope())
            {
                var flow = scope.Resolve<IMaintiFlow>();
                var coreData = scope.Resolve<CoreData>();
                var flowData = scope.Resolve<MaintiFlowData>();
                var context = scope.Resolve<MaintiFlowContext>();
                var to = context.TaskOrders;
                var statuses = context.Statuses;

                string todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                int maxSerial = to
                    .Where(o => o.WorkOrderNo.StartsWith(todayPrefix))
                    .AsEnumerable()
                    .Select(o => o.WorkOrderNo.Substring(8, 3))
                    .Select(s =>
                    {
                        bool success = int.TryParse(s, out int val);
                        return success ? val : 0;
                    })
                    .DefaultIfEmpty(0)
                    .Max();
                NewWorkOrderNo = todayPrefix + (maxSerial + 1).ToString("D3");

                // 錯誤檢查
                if (string.IsNullOrWhiteSpace(Creator.Text))
                {
                    UIMessageBox.ShowError2($"{uiLabel_Creator.Text}必須要選擇一人！");
                    return;
                }
                if (string.IsNullOrWhiteSpace(DeviceList.Text))
                {
                    UIMessageBox.ShowError2($"必須選擇{uiLabel_DeviceList.Text}！");
                    return;
                }
                else
                {
                    var dList = DeviceList.Text
                        .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(s => s.Trim())
                        .ToList();
                    foreach (var d in dList)
                    {
                        if (coreData.Devices.FindIndex(x => x.DeviceId == d) == -1)
                        {
                            UIMessageBox.ShowError2($"{uiLabel_DeviceList.Text}不存在: {d}");
                            return;
                        }
                        else
                        {
                            deviceList.Add(new TaskOrderDevice()
                            {
                                WorkOrderNo = NewWorkOrderNo,
                                DeviceId = d,
                            });
                        }
                    }
                }
                if (string.IsNullOrWhiteSpace(Model.Text))
                {
                    UIMessageBox.ShowError2($"必須選擇{uiLabel_Model.Text}！");
                    return;
                }
                else
                {
                    if (flowData.ModelList.FindIndex(x => x == Model.Text) == -1)
                    {
                        UIMessageBox.ShowError2($"{uiLabel_Model.Text}不存在: {Model.Text}");
                        return;
                    }
                }

                to.Add(new TaskOrder()
                {
                    OrderNo = to.Select(x => x.OrderNo).Max() + 1,
                    WorkOrderNo = NewWorkOrderNo,
                    CreatorId = flowData.Employees.FirstOrDefault(x => x.EmployeeId == (string)Creator.SelectedValue).EmployeeId,
                    CreationDate = DateTime.Today,
                    TaskOrderDevices = deviceList,
                    ModelName = Model.Text,
                    Status = flow.DefaultStatus,
                    AcceptedTime = DateTime.Now,
                    OutageStarted = OutageStarted.Value,
                });
                context.SaveChanges();
            }

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void DeviceId_ButtonClick(object sender, EventArgs e)
        {
            using (var scope = _scope.BeginLifetimeScope())
            {
                var coreData = scope.Resolve<CoreData>();
                var flowLayoutSelector = scope.Resolve<FlowLayoutSelector>();

                flowLayoutSelector.HideTabHeaders = false;
                flowLayoutSelector.Title = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderDevices));
                flowLayoutSelector.MultiSelection = true;
                flowLayoutSelector.ResultList = DeviceList.Text
                    .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim())
                    .ToList();

                Dictionary<string, List<string>> deviceGroip = new Dictionary<string, List<string>>();
                var typeList = coreData.Devices
                    .OrderBy(x => x.DeviceName.Type.OrderNo)
                    .Select(x => x.DeviceName.Type.Name)
                    .Distinct().ToList();
                foreach (var type in typeList)
                {
                    List<string> itemList = new List<string>();
                    var Names = coreData.Devices
                           .Where(x => x.DeviceName.Type.Name == type)
                           .Select(x => x.DeviceId)
                           .ToList();
                    if (Names.Count > 0)
                        foreach (var name in Names)
                            itemList.Add(name);
                    deviceGroip.Add(type, itemList);
                }
                flowLayoutSelector.Items = deviceGroip;
                flowLayoutSelector.Initialize();

                string deviceString = "";
                if (flowLayoutSelector.ShowDialog() == DialogResult.OK)
                {
                    if (flowLayoutSelector.ResultList.Count > 0)
                        foreach (var item in flowLayoutSelector.ResultList)
                        {
                            if (deviceString != "")
                                deviceString += "; ";
                            deviceString += item;
                        }
                }
                DeviceList.Text = deviceString;
            }
        }

        private void Model_ButtonClick(object sender, EventArgs e)
        {
            using (var scope = _scope.BeginLifetimeScope())
            {
                var flowData = scope.Resolve<MaintiFlowData>();
                var flowLayoutSelector = scope.Resolve<FlowLayoutSelector>();

                flowLayoutSelector.HideTabHeaders = true;
                flowLayoutSelector.Title = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Model));
                flowLayoutSelector.MultiSelection = false;
                flowLayoutSelector.ResultList = new List<string>();
                if (!string.IsNullOrWhiteSpace(Model.Text))
                    flowLayoutSelector.ResultList.Add(Model.Text.Trim());

                Dictionary<string, List<string>> deviceGroip = new Dictionary<string, List<string>>();

                List<string> itemList = new List<string>();
                if (flowData.ModelList.Count > 0)
                    foreach (var name in flowData.ModelList)
                        itemList.Add(name);
                deviceGroip.Add("", itemList);

                flowLayoutSelector.Items = deviceGroip;
                flowLayoutSelector.Initialize();

                if (flowLayoutSelector.ShowDialog() == DialogResult.OK)
                {
                    if (flowLayoutSelector.ResultList.Count > 0)
                        Model.Text = flowLayoutSelector.ResultList[0];
                }
            }
        }
    }
}
