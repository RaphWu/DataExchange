﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FlowTracking
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.uiBreadcrumb = new Sunny.UI.UIBreadcrumb();
            this.uiTabControl_Steps = new Sunny.UI.UITabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel_WholePage = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel_OrderList = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.uiListBox_OrderList = new Sunny.UI.UIListBox();
            this.uiTabControl_Steps.SuspendLayout();
            this.tableLayoutPanel_WholePage.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel_OrderList.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiBreadcrumb
            // 
            this.uiBreadcrumb.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiBreadcrumb.ItemIndex = 0;
            this.uiBreadcrumb.ItemWidth = 135;
            this.uiBreadcrumb.Location = new System.Drawing.Point(240, 15);
            this.uiBreadcrumb.Margin = new System.Windows.Forms.Padding(20, 15, 3, 3);
            this.uiBreadcrumb.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiBreadcrumb.Name = "uiBreadcrumb";
            this.uiBreadcrumb.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiBreadcrumb.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiBreadcrumb.Size = new System.Drawing.Size(400, 29);
            this.uiBreadcrumb.TabIndex = 1;
            this.uiBreadcrumb.UnSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.uiBreadcrumb.ItemIndexChanged += new Sunny.UI.UIBreadcrumb.OnValueChanged(this.uiBreadcrumb_ItemIndexChanged);
            // 
            // uiTabControl_Steps
            // 
            this.uiTabControl_Steps.Controls.Add(this.tabPage1);
            this.uiTabControl_Steps.Controls.Add(this.tabPage2);
            this.uiTabControl_Steps.Controls.Add(this.tabPage3);
            this.uiTabControl_Steps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiTabControl_Steps.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.uiTabControl_Steps.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiTabControl_Steps.ItemSize = new System.Drawing.Size(0, 1);
            this.uiTabControl_Steps.Location = new System.Drawing.Point(223, 73);
            this.uiTabControl_Steps.MainPage = "";
            this.uiTabControl_Steps.MenuStyle = Sunny.UI.UIMenuStyle.White;
            this.uiTabControl_Steps.Name = "uiTabControl_Steps";
            this.uiTabControl_Steps.SelectedIndex = 0;
            this.uiTabControl_Steps.Size = new System.Drawing.Size(831, 625);
            this.uiTabControl_Steps.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.uiTabControl_Steps.TabBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiTabControl_Steps.TabIndex = 3;
            this.uiTabControl_Steps.TabSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.uiTabControl_Steps.TabUnSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.uiTabControl_Steps.TabUnSelectedForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiTabControl_Steps.TabVisible = false;
            this.uiTabControl_Steps.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(0, 0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(831, 625);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(0, 40);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(200, 60);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(0, 40);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(200, 60);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel_WholePage
            // 
            this.tableLayoutPanel_WholePage.ColumnCount = 2;
            this.tableLayoutPanel_WholePage.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 220F));
            this.tableLayoutPanel_WholePage.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WholePage.Controls.Add(this.uiTabControl_Steps, 1, 1);
            this.tableLayoutPanel_WholePage.Controls.Add(this.uiBreadcrumb, 1, 0);
            this.tableLayoutPanel_WholePage.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel_WholePage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_WholePage.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_WholePage.Name = "tableLayoutPanel_WholePage";
            this.tableLayoutPanel_WholePage.RowCount = 2;
            this.tableLayoutPanel_WholePage.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel_WholePage.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_WholePage.Size = new System.Drawing.Size(1057, 701);
            this.tableLayoutPanel_WholePage.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel_OrderList);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.tableLayoutPanel_WholePage.SetRowSpan(this.panel1, 2);
            this.panel1.Size = new System.Drawing.Size(214, 695);
            this.panel1.TabIndex = 5;
            // 
            // tableLayoutPanel_OrderList
            // 
            this.tableLayoutPanel_OrderList.ColumnCount = 1;
            this.tableLayoutPanel_OrderList.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_OrderList.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel_OrderList.Controls.Add(this.uiListBox_OrderList, 0, 1);
            this.tableLayoutPanel_OrderList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_OrderList.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_OrderList.Name = "tableLayoutPanel_OrderList";
            this.tableLayoutPanel_OrderList.RowCount = 2;
            this.tableLayoutPanel_OrderList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel_OrderList.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_OrderList.Size = new System.Drawing.Size(214, 695);
            this.tableLayoutPanel_OrderList.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("標楷體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 45);
            this.label1.TabIndex = 6;
            this.label1.Text = "未完成工單列表";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiListBox_OrderList
            // 
            this.uiListBox_OrderList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiListBox_OrderList.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiListBox_OrderList.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.uiListBox_OrderList.ItemSelectForeColor = System.Drawing.Color.White;
            this.uiListBox_OrderList.Location = new System.Drawing.Point(4, 45);
            this.uiListBox_OrderList.Margin = new System.Windows.Forms.Padding(4, 0, 4, 5);
            this.uiListBox_OrderList.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiListBox_OrderList.Name = "uiListBox_OrderList";
            this.uiListBox_OrderList.Padding = new System.Windows.Forms.Padding(2);
            this.uiListBox_OrderList.RectSize = 2;
            this.uiListBox_OrderList.ShowText = false;
            this.uiListBox_OrderList.Size = new System.Drawing.Size(206, 645);
            this.uiListBox_OrderList.TabIndex = 5;
            this.uiListBox_OrderList.Text = "uiListBox1";
            // 
            // FlowTracking
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1057, 701);
            this.Controls.Add(this.tableLayoutPanel_WholePage);
            this.Name = "FlowTracking";
            this.uiTabControl_Steps.ResumeLayout(false);
            this.tableLayoutPanel_WholePage.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel_OrderList.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UIBreadcrumb uiBreadcrumb;
        private Sunny.UI.UITabControl uiTabControl_Steps;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_WholePage;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_OrderList;
        private System.Windows.Forms.Label label1;
        private Sunny.UI.UIListBox uiListBox_OrderList;
    }
}
