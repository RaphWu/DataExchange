﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FlowTracking
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.uiPanel_FlowData = new Sunny.UI.UIPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.uiBreadcrumb = new Sunny.UI.UIBreadcrumb();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiPanel_FlowData
            // 
            this.uiPanel_FlowData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel_FlowData.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiPanel_FlowData.Location = new System.Drawing.Point(0, 0);
            this.uiPanel_FlowData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel_FlowData.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel_FlowData.Name = "uiPanel_FlowData";
            this.uiPanel_FlowData.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPanel_FlowData.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiPanel_FlowData.Size = new System.Drawing.Size(1057, 701);
            this.uiPanel_FlowData.TabIndex = 1;
            this.uiPanel_FlowData.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.uiBreadcrumb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1057, 80);
            this.panel1.TabIndex = 2;
            // 
            // uiBreadcrumb
            // 
            this.uiBreadcrumb.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiBreadcrumb.ItemIndex = 0;
            this.uiBreadcrumb.ItemWidth = 135;
            this.uiBreadcrumb.Location = new System.Drawing.Point(35, 25);
            this.uiBreadcrumb.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiBreadcrumb.Name = "uiBreadcrumb";
            this.uiBreadcrumb.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiBreadcrumb.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiBreadcrumb.Size = new System.Drawing.Size(400, 29);
            this.uiBreadcrumb.TabIndex = 1;
            this.uiBreadcrumb.UnSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            // 
            // FlowTracking
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1057, 701);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.uiPanel_FlowData);
            this.Name = "FlowTracking";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UIPanel uiPanel_FlowData;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UIBreadcrumb uiBreadcrumb;
    }
}
