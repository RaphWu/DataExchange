﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FT_FlowConfirmed
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Feedback = new Sunny.UI.UIRichTextBox();
            this.Label_Feedback = new Sunny.UI.UILabel();
            this.FeedbackEmployee = new Sunny.UI.UITextBox();
            this.Label_FeedbackEmployee = new Sunny.UI.UILabel();
            this.Label_RequestingUnit = new Sunny.UI.UILabel();
            this.btnCompleted = new Sunny.UI.UISymbolButton();
            this.RequestingUnit = new Sunny.UI.UITextBox();
            this.Label_Details = new Sunny.UI.UILabel();
            this.Details = new Sunny.UI.UITextBox();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.IssueDescription = new Sunny.UI.UITextBox();
            this.Label_WorkOrderNo = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UITextBox();
            this.Creator = new Sunny.UI.UITextBox();
            this.IssueCategory = new Sunny.UI.UITextBox();
            this.Label_Creator = new Sunny.UI.UILabel();
            this.Engineers = new Sunny.UI.UITextBox();
            this.Label_CreationDate = new Sunny.UI.UILabel();
            this.MaintenanceUnit = new Sunny.UI.UITextBox();
            this.CreationDate = new Sunny.UI.UITextBox();
            this.Label_MachineList = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.RepairStarted = new Sunny.UI.UITextBox();
            this.Label_ModelWorkstation = new Sunny.UI.UILabel();
            this.OutageEnded = new Sunny.UI.UITextBox();
            this.ModelWorkstation = new Sunny.UI.UITextBox();
            this.RepairCompleted = new Sunny.UI.UITextBox();
            this.Label_OutageStarted = new Sunny.UI.UILabel();
            this.OutageDuration = new Sunny.UI.UITextBox();
            this.Label_MaintenanceUnit = new Sunny.UI.UILabel();
            this.RepairDuration = new Sunny.UI.UITextBox();
            this.Label_Engineers = new Sunny.UI.UILabel();
            this.Label_OutageDuration = new Sunny.UI.UILabel();
            this.Label_IssueCategory = new Sunny.UI.UILabel();
            this.Label_RepairDuration = new Sunny.UI.UILabel();
            this.Label_AcceptedTime = new Sunny.UI.UILabel();
            this.Label_OutageEnded = new Sunny.UI.UILabel();
            this.AcceptedTime = new Sunny.UI.UITextBox();
            this.Label_RepairCompleted = new Sunny.UI.UILabel();
            this.Label_IssueDescription = new Sunny.UI.UILabel();
            this.Label_RepairStarted = new Sunny.UI.UILabel();
            this.btnReturn = new Sunny.UI.UISymbolButton();
            this.btnCancel = new Sunny.UI.UISymbolButton();
            this.OrderList = new Sunny.UI.UIListBox();
            this.SuspendLayout();
            // 
            // Feedback
            // 
            this.Feedback.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Feedback.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Feedback.FillColor = System.Drawing.Color.White;
            this.Feedback.FillDisableColor = System.Drawing.SystemColors.Control;
            this.Feedback.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Feedback.Location = new System.Drawing.Point(1018, 127);
            this.Feedback.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Feedback.MinimumSize = new System.Drawing.Size(1, 16);
            this.Feedback.Name = "Feedback";
            this.Feedback.Padding = new System.Windows.Forms.Padding(5);
            this.Feedback.ShowText = false;
            this.Feedback.Size = new System.Drawing.Size(250, 303);
            this.Feedback.TabIndex = 86;
            this.Feedback.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // Label_Feedback
            // 
            this.Label_Feedback.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Feedback.BackColor = System.Drawing.Color.Transparent;
            this.Label_Feedback.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Feedback.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Feedback.Location = new System.Drawing.Point(909, 127);
            this.Label_Feedback.Name = "Label_Feedback";
            this.Label_Feedback.Size = new System.Drawing.Size(102, 29);
            this.Label_Feedback.TabIndex = 87;
            this.Label_Feedback.Text = "需求單位回覆";
            this.Label_Feedback.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FeedbackEmployee
            // 
            this.FeedbackEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.FeedbackEmployee.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.FeedbackEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.FeedbackEmployee.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.FeedbackEmployee.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.FeedbackEmployee.Location = new System.Drawing.Point(1018, 88);
            this.FeedbackEmployee.Margin = new System.Windows.Forms.Padding(0);
            this.FeedbackEmployee.MinimumSize = new System.Drawing.Size(1, 16);
            this.FeedbackEmployee.Name = "FeedbackEmployee";
            this.FeedbackEmployee.Padding = new System.Windows.Forms.Padding(2);
            this.FeedbackEmployee.ReadOnly = true;
            this.FeedbackEmployee.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.FeedbackEmployee.ShowText = false;
            this.FeedbackEmployee.Size = new System.Drawing.Size(250, 29);
            this.FeedbackEmployee.TabIndex = 84;
            this.FeedbackEmployee.TabStop = false;
            this.FeedbackEmployee.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.FeedbackEmployee.Watermark = "";
            // 
            // Label_FeedbackEmployee
            // 
            this.Label_FeedbackEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_FeedbackEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_FeedbackEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_FeedbackEmployee.Location = new System.Drawing.Point(907, 88);
            this.Label_FeedbackEmployee.Name = "Label_FeedbackEmployee";
            this.Label_FeedbackEmployee.Size = new System.Drawing.Size(104, 29);
            this.Label_FeedbackEmployee.TabIndex = 85;
            this.Label_FeedbackEmployee.Text = "需求單位人員";
            this.Label_FeedbackEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RequestingUnit
            // 
            this.Label_RequestingUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RequestingUnit.Location = new System.Drawing.Point(907, 49);
            this.Label_RequestingUnit.Name = "Label_RequestingUnit";
            this.Label_RequestingUnit.Size = new System.Drawing.Size(104, 29);
            this.Label_RequestingUnit.TabIndex = 83;
            this.Label_RequestingUnit.Text = "需求單位名稱";
            this.Label_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCompleted
            // 
            this.btnCompleted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCompleted.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCompleted.Location = new System.Drawing.Point(1018, 486);
            this.btnCompleted.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCompleted.Name = "btnCompleted";
            this.btnCompleted.Radius = 10;
            this.btnCompleted.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnCompleted.Size = new System.Drawing.Size(110, 76);
            this.btnCompleted.Style = Sunny.UI.UIStyle.Custom;
            this.btnCompleted.Symbol = 61452;
            this.btnCompleted.TabIndex = 95;
            this.btnCompleted.Text = "維護完成";
            this.btnCompleted.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCompleted.Click += new System.EventHandler(this.btnCompleted_Click);
            // 
            // RequestingUnit
            // 
            this.RequestingUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RequestingUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.Black;
            this.RequestingUnit.Location = new System.Drawing.Point(1018, 49);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(0);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnit.Name = "RequestingUnit";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(2);
            this.RequestingUnit.ReadOnly = true;
            this.RequestingUnit.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.RequestingUnit.ShowText = false;
            this.RequestingUnit.Size = new System.Drawing.Size(250, 29);
            this.RequestingUnit.TabIndex = 125;
            this.RequestingUnit.TabStop = false;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // Label_Details
            // 
            this.Label_Details.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Details.BackColor = System.Drawing.Color.Transparent;
            this.Label_Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Details.Location = new System.Drawing.Point(562, 301);
            this.Label_Details.Name = "Label_Details";
            this.Label_Details.Size = new System.Drawing.Size(78, 29);
            this.Label_Details.TabIndex = 118;
            this.Label_Details.Text = "維護內容";
            this.Label_Details.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Details
            // 
            this.Details.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Details.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Details.Location = new System.Drawing.Point(647, 301);
            this.Details.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Details.MinimumSize = new System.Drawing.Size(1, 1);
            this.Details.Multiline = true;
            this.Details.Name = "Details";
            this.Details.Padding = new System.Windows.Forms.Padding(2);
            this.Details.ReadOnly = true;
            this.Details.ShowText = false;
            this.Details.Size = new System.Drawing.Size(255, 222);
            this.Details.TabIndex = 131;
            this.Details.TabStop = false;
            this.Details.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.Details.Watermark = "";
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.WorkOrderNo.Location = new System.Drawing.Point(357, 49);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(0);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(2);
            this.WorkOrderNo.ReadOnly = true;
            this.WorkOrderNo.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(200, 29);
            this.WorkOrderNo.TabIndex = 96;
            this.WorkOrderNo.TabStop = false;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // IssueDescription
            // 
            this.IssueDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IssueDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(647, 166);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueDescription.Multiline = true;
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(2);
            this.IssueDescription.ReadOnly = true;
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(255, 125);
            this.IssueDescription.TabIndex = 130;
            this.IssueDescription.TabStop = false;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.IssueDescription.Watermark = "";
            // 
            // Label_WorkOrderNo
            // 
            this.Label_WorkOrderNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_WorkOrderNo.BackColor = System.Drawing.Color.Transparent;
            this.Label_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_WorkOrderNo.Location = new System.Drawing.Point(241, 49);
            this.Label_WorkOrderNo.Name = "Label_WorkOrderNo";
            this.Label_WorkOrderNo.Size = new System.Drawing.Size(109, 29);
            this.Label_WorkOrderNo.TabIndex = 97;
            this.Label_WorkOrderNo.Text = "維護工單編號";
            this.Label_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OutageStarted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageStarted.Location = new System.Drawing.Point(357, 455);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(0);
            this.OutageStarted.MaxLength = 16;
            this.OutageStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(2);
            this.OutageStarted.ReadOnly = true;
            this.OutageStarted.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.OutageStarted.ShowText = false;
            this.OutageStarted.Size = new System.Drawing.Size(200, 29);
            this.OutageStarted.TabIndex = 124;
            this.OutageStarted.TabStop = false;
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageStarted.Watermark = "";
            // 
            // Creator
            // 
            this.Creator.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.Black;
            this.Creator.Location = new System.Drawing.Point(647, 49);
            this.Creator.Margin = new System.Windows.Forms.Padding(0);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(2);
            this.Creator.ReadOnly = true;
            this.Creator.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(255, 29);
            this.Creator.TabIndex = 98;
            this.Creator.TabStop = false;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // IssueCategory
            // 
            this.IssueCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IssueCategory.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.IssueCategory.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.IssueCategory.Location = new System.Drawing.Point(357, 224);
            this.IssueCategory.Margin = new System.Windows.Forms.Padding(0);
            this.IssueCategory.MinimumSize = new System.Drawing.Size(63, 0);
            this.IssueCategory.Name = "IssueCategory";
            this.IssueCategory.Padding = new System.Windows.Forms.Padding(2);
            this.IssueCategory.ReadOnly = true;
            this.IssueCategory.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.IssueCategory.ShowText = false;
            this.IssueCategory.Size = new System.Drawing.Size(200, 29);
            this.IssueCategory.TabIndex = 129;
            this.IssueCategory.TabStop = false;
            this.IssueCategory.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.IssueCategory.Watermark = "";
            // 
            // Label_Creator
            // 
            this.Label_Creator.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Creator.BackColor = System.Drawing.Color.Transparent;
            this.Label_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Creator.Location = new System.Drawing.Point(560, 49);
            this.Label_Creator.Name = "Label_Creator";
            this.Label_Creator.Size = new System.Drawing.Size(80, 29);
            this.Label_Creator.TabIndex = 100;
            this.Label_Creator.Text = "建檔人員";
            this.Label_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Engineers
            // 
            this.Engineers.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Engineers.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Engineers.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Engineers.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Engineers.Location = new System.Drawing.Point(357, 263);
            this.Engineers.Margin = new System.Windows.Forms.Padding(0);
            this.Engineers.MinimumSize = new System.Drawing.Size(63, 0);
            this.Engineers.Name = "Engineers";
            this.Engineers.Padding = new System.Windows.Forms.Padding(2);
            this.Engineers.ReadOnly = true;
            this.Engineers.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Engineers.ShowText = false;
            this.Engineers.Size = new System.Drawing.Size(200, 29);
            this.Engineers.TabIndex = 128;
            this.Engineers.TabStop = false;
            this.Engineers.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Engineers.Watermark = "";
            // 
            // Label_CreationDate
            // 
            this.Label_CreationDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_CreationDate.BackColor = System.Drawing.Color.Transparent;
            this.Label_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_CreationDate.Location = new System.Drawing.Point(560, 88);
            this.Label_CreationDate.Name = "Label_CreationDate";
            this.Label_CreationDate.Size = new System.Drawing.Size(80, 29);
            this.Label_CreationDate.TabIndex = 101;
            this.Label_CreationDate.Text = "建檔日期";
            this.Label_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MaintenanceUnit
            // 
            this.MaintenanceUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MaintenanceUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaintenanceUnit.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.MaintenanceUnit.Location = new System.Drawing.Point(357, 185);
            this.MaintenanceUnit.Margin = new System.Windows.Forms.Padding(0);
            this.MaintenanceUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.MaintenanceUnit.Name = "MaintenanceUnit";
            this.MaintenanceUnit.Padding = new System.Windows.Forms.Padding(2);
            this.MaintenanceUnit.ReadOnly = true;
            this.MaintenanceUnit.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.ShowText = false;
            this.MaintenanceUnit.Size = new System.Drawing.Size(200, 29);
            this.MaintenanceUnit.TabIndex = 127;
            this.MaintenanceUnit.TabStop = false;
            this.MaintenanceUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceUnit.Watermark = "";
            // 
            // CreationDate
            // 
            this.CreationDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CreationDate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CreationDate.ForeDisableColor = System.Drawing.Color.Black;
            this.CreationDate.Location = new System.Drawing.Point(647, 88);
            this.CreationDate.Margin = new System.Windows.Forms.Padding(0);
            this.CreationDate.MinimumSize = new System.Drawing.Size(1, 16);
            this.CreationDate.Name = "CreationDate";
            this.CreationDate.Padding = new System.Windows.Forms.Padding(2);
            this.CreationDate.ReadOnly = true;
            this.CreationDate.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.CreationDate.ShowText = false;
            this.CreationDate.Size = new System.Drawing.Size(255, 29);
            this.CreationDate.TabIndex = 99;
            this.CreationDate.TabStop = false;
            this.CreationDate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreationDate.Watermark = "";
            // 
            // Label_MachineList
            // 
            this.Label_MachineList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.Label_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MachineList.Location = new System.Drawing.Point(241, 88);
            this.Label_MachineList.Name = "Label_MachineList";
            this.Label_MachineList.Size = new System.Drawing.Size(109, 29);
            this.Label_MachineList.TabIndex = 104;
            this.Label_MachineList.Text = "機台編號";
            this.Label_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MachineList.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.MachineList.Location = new System.Drawing.Point(357, 88);
            this.MachineList.Margin = new System.Windows.Forms.Padding(0);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(2);
            this.MachineList.ReadOnly = true;
            this.MachineList.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(200, 29);
            this.MachineList.TabIndex = 102;
            this.MachineList.TabStop = false;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            // 
            // RepairStarted
            // 
            this.RepairStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RepairStarted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairStarted.Location = new System.Drawing.Point(357, 323);
            this.RepairStarted.Margin = new System.Windows.Forms.Padding(0);
            this.RepairStarted.MaxLength = 16;
            this.RepairStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.RepairStarted.Name = "RepairStarted";
            this.RepairStarted.Padding = new System.Windows.Forms.Padding(2);
            this.RepairStarted.ReadOnly = true;
            this.RepairStarted.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.RepairStarted.ShowText = false;
            this.RepairStarted.Size = new System.Drawing.Size(200, 29);
            this.RepairStarted.TabIndex = 122;
            this.RepairStarted.TabStop = false;
            this.RepairStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairStarted.Watermark = "";
            // 
            // Label_ModelWorkstation
            // 
            this.Label_ModelWorkstation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ModelWorkstation.BackColor = System.Drawing.Color.Transparent;
            this.Label_ModelWorkstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_ModelWorkstation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_ModelWorkstation.Location = new System.Drawing.Point(241, 127);
            this.Label_ModelWorkstation.Name = "Label_ModelWorkstation";
            this.Label_ModelWorkstation.Size = new System.Drawing.Size(109, 29);
            this.Label_ModelWorkstation.TabIndex = 108;
            this.Label_ModelWorkstation.Text = "機種";
            this.Label_ModelWorkstation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageEnded
            // 
            this.OutageEnded.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OutageEnded.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageEnded.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageEnded.Location = new System.Drawing.Point(357, 494);
            this.OutageEnded.Margin = new System.Windows.Forms.Padding(0);
            this.OutageEnded.MaxLength = 16;
            this.OutageEnded.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageEnded.Name = "OutageEnded";
            this.OutageEnded.Padding = new System.Windows.Forms.Padding(2);
            this.OutageEnded.ReadOnly = true;
            this.OutageEnded.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.OutageEnded.ShowText = false;
            this.OutageEnded.Size = new System.Drawing.Size(200, 29);
            this.OutageEnded.TabIndex = 123;
            this.OutageEnded.TabStop = false;
            this.OutageEnded.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageEnded.Watermark = "";
            // 
            // ModelWorkstation
            // 
            this.ModelWorkstation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ModelWorkstation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ModelWorkstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelWorkstation.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.ModelWorkstation.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.ModelWorkstation.Location = new System.Drawing.Point(357, 127);
            this.ModelWorkstation.Margin = new System.Windows.Forms.Padding(0);
            this.ModelWorkstation.MinimumSize = new System.Drawing.Size(1, 16);
            this.ModelWorkstation.Name = "ModelWorkstation";
            this.ModelWorkstation.Padding = new System.Windows.Forms.Padding(2);
            this.ModelWorkstation.ReadOnly = true;
            this.ModelWorkstation.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.ModelWorkstation.ShowText = false;
            this.ModelWorkstation.Size = new System.Drawing.Size(200, 29);
            this.ModelWorkstation.TabIndex = 106;
            this.ModelWorkstation.TabStop = false;
            this.ModelWorkstation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ModelWorkstation.Watermark = "";
            // 
            // RepairCompleted
            // 
            this.RepairCompleted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RepairCompleted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairCompleted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairCompleted.Location = new System.Drawing.Point(357, 362);
            this.RepairCompleted.Margin = new System.Windows.Forms.Padding(0);
            this.RepairCompleted.MaxLength = 16;
            this.RepairCompleted.MinimumSize = new System.Drawing.Size(63, 0);
            this.RepairCompleted.Name = "RepairCompleted";
            this.RepairCompleted.Padding = new System.Windows.Forms.Padding(2);
            this.RepairCompleted.ReadOnly = true;
            this.RepairCompleted.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.RepairCompleted.ShowText = false;
            this.RepairCompleted.Size = new System.Drawing.Size(200, 29);
            this.RepairCompleted.TabIndex = 121;
            this.RepairCompleted.TabStop = false;
            this.RepairCompleted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairCompleted.Watermark = "";
            // 
            // Label_OutageStarted
            // 
            this.Label_OutageStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageStarted.Location = new System.Drawing.Point(241, 455);
            this.Label_OutageStarted.Name = "Label_OutageStarted";
            this.Label_OutageStarted.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageStarted.TabIndex = 110;
            this.Label_OutageStarted.Text = "停動開始時間";
            this.Label_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageDuration
            // 
            this.OutageDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OutageDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageDuration.Location = new System.Drawing.Point(357, 533);
            this.OutageDuration.Margin = new System.Windows.Forms.Padding(0);
            this.OutageDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageDuration.Name = "OutageDuration";
            this.OutageDuration.Padding = new System.Windows.Forms.Padding(2);
            this.OutageDuration.ReadOnly = true;
            this.OutageDuration.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.OutageDuration.ShowText = false;
            this.OutageDuration.Size = new System.Drawing.Size(200, 29);
            this.OutageDuration.TabIndex = 119;
            this.OutageDuration.TabStop = false;
            this.OutageDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageDuration.Watermark = "";
            // 
            // Label_MaintenanceUnit
            // 
            this.Label_MaintenanceUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_MaintenanceUnit.BackColor = System.Drawing.Color.Transparent;
            this.Label_MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MaintenanceUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MaintenanceUnit.Location = new System.Drawing.Point(241, 185);
            this.Label_MaintenanceUnit.Name = "Label_MaintenanceUnit";
            this.Label_MaintenanceUnit.Size = new System.Drawing.Size(109, 29);
            this.Label_MaintenanceUnit.TabIndex = 107;
            this.Label_MaintenanceUnit.Text = "維護單位";
            this.Label_MaintenanceUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RepairDuration
            // 
            this.RepairDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RepairDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairDuration.Location = new System.Drawing.Point(357, 401);
            this.RepairDuration.Margin = new System.Windows.Forms.Padding(0);
            this.RepairDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairDuration.Name = "RepairDuration";
            this.RepairDuration.Padding = new System.Windows.Forms.Padding(2);
            this.RepairDuration.ReadOnly = true;
            this.RepairDuration.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.RepairDuration.ShowText = false;
            this.RepairDuration.Size = new System.Drawing.Size(200, 29);
            this.RepairDuration.TabIndex = 114;
            this.RepairDuration.TabStop = false;
            this.RepairDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairDuration.Watermark = "";
            // 
            // Label_Engineers
            // 
            this.Label_Engineers.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Engineers.BackColor = System.Drawing.Color.Transparent;
            this.Label_Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Engineers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Engineers.Location = new System.Drawing.Point(241, 263);
            this.Label_Engineers.Name = "Label_Engineers";
            this.Label_Engineers.Size = new System.Drawing.Size(109, 29);
            this.Label_Engineers.TabIndex = 109;
            this.Label_Engineers.Text = "維護工程師";
            this.Label_Engineers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageDuration
            // 
            this.Label_OutageDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_OutageDuration.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageDuration.Location = new System.Drawing.Point(241, 533);
            this.Label_OutageDuration.Name = "Label_OutageDuration";
            this.Label_OutageDuration.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageDuration.TabIndex = 120;
            this.Label_OutageDuration.Text = "停動工時";
            this.Label_OutageDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_IssueCategory
            // 
            this.Label_IssueCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_IssueCategory.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueCategory.Location = new System.Drawing.Point(241, 224);
            this.Label_IssueCategory.Name = "Label_IssueCategory";
            this.Label_IssueCategory.Size = new System.Drawing.Size(109, 29);
            this.Label_IssueCategory.TabIndex = 111;
            this.Label_IssueCategory.Text = "維護類型";
            this.Label_IssueCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairDuration
            // 
            this.Label_RepairDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RepairDuration.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairDuration.Location = new System.Drawing.Point(241, 401);
            this.Label_RepairDuration.Name = "Label_RepairDuration";
            this.Label_RepairDuration.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairDuration.TabIndex = 115;
            this.Label_RepairDuration.Text = "維護工時";
            this.Label_RepairDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_AcceptedTime
            // 
            this.Label_AcceptedTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_AcceptedTime.BackColor = System.Drawing.Color.Transparent;
            this.Label_AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_AcceptedTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_AcceptedTime.Location = new System.Drawing.Point(560, 127);
            this.Label_AcceptedTime.Name = "Label_AcceptedTime";
            this.Label_AcceptedTime.Size = new System.Drawing.Size(80, 29);
            this.Label_AcceptedTime.TabIndex = 105;
            this.Label_AcceptedTime.Text = "接單時間";
            this.Label_AcceptedTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageEnded
            // 
            this.Label_OutageEnded.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_OutageEnded.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageEnded.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageEnded.Location = new System.Drawing.Point(241, 494);
            this.Label_OutageEnded.Name = "Label_OutageEnded";
            this.Label_OutageEnded.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageEnded.TabIndex = 117;
            this.Label_OutageEnded.Text = "停動結束時間";
            this.Label_OutageEnded.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AcceptedTime
            // 
            this.AcceptedTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AcceptedTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.AcceptedTime.ForeDisableColor = System.Drawing.Color.Black;
            this.AcceptedTime.Location = new System.Drawing.Point(647, 127);
            this.AcceptedTime.Margin = new System.Windows.Forms.Padding(0);
            this.AcceptedTime.MinimumSize = new System.Drawing.Size(1, 16);
            this.AcceptedTime.Name = "AcceptedTime";
            this.AcceptedTime.Padding = new System.Windows.Forms.Padding(2);
            this.AcceptedTime.ReadOnly = true;
            this.AcceptedTime.RectDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.AcceptedTime.ShowText = false;
            this.AcceptedTime.Size = new System.Drawing.Size(255, 29);
            this.AcceptedTime.TabIndex = 103;
            this.AcceptedTime.TabStop = false;
            this.AcceptedTime.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.AcceptedTime.Watermark = "";
            // 
            // Label_RepairCompleted
            // 
            this.Label_RepairCompleted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RepairCompleted.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairCompleted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairCompleted.Location = new System.Drawing.Point(241, 362);
            this.Label_RepairCompleted.Name = "Label_RepairCompleted";
            this.Label_RepairCompleted.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairCompleted.TabIndex = 113;
            this.Label_RepairCompleted.Text = "維護完成時間";
            this.Label_RepairCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_IssueDescription
            // 
            this.Label_IssueDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueDescription.Location = new System.Drawing.Point(562, 166);
            this.Label_IssueDescription.Name = "Label_IssueDescription";
            this.Label_IssueDescription.Size = new System.Drawing.Size(78, 29);
            this.Label_IssueDescription.TabIndex = 116;
            this.Label_IssueDescription.Text = "問題描述";
            this.Label_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairStarted
            // 
            this.Label_RepairStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RepairStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairStarted.Location = new System.Drawing.Point(241, 323);
            this.Label_RepairStarted.Name = "Label_RepairStarted";
            this.Label_RepairStarted.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairStarted.TabIndex = 112;
            this.Label_RepairStarted.Text = "維護開始時間";
            this.Label_RepairStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnReturn
            // 
            this.btnReturn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturn.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnReturn.Location = new System.Drawing.Point(1158, 486);
            this.btnReturn.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Radius = 10;
            this.btnReturn.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnReturn.Size = new System.Drawing.Size(110, 35);
            this.btnReturn.Symbol = 61470;
            this.btnReturn.TabIndex = 137;
            this.btnReturn.Text = "工單返回";
            this.btnReturn.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCancel.Location = new System.Drawing.Point(1158, 527);
            this.btnCancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Radius = 10;
            this.btnCancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnCancel.Size = new System.Drawing.Size(110, 35);
            this.btnCancel.Style = Sunny.UI.UIStyle.Custom;
            this.btnCancel.Symbol = 361453;
            this.btnCancel.TabIndex = 136;
            this.btnCancel.Text = "取消";
            this.btnCancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // OrderList
            // 
            this.OrderList.Dock = System.Windows.Forms.DockStyle.Left;
            this.OrderList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OrderList.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.OrderList.ItemSelectForeColor = System.Drawing.Color.White;
            this.OrderList.Location = new System.Drawing.Point(0, 35);
            this.OrderList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OrderList.MinimumSize = new System.Drawing.Size(1, 1);
            this.OrderList.Name = "OrderList";
            this.OrderList.Padding = new System.Windows.Forms.Padding(2);
            this.OrderList.ShowText = false;
            this.OrderList.Size = new System.Drawing.Size(240, 540);
            this.OrderList.TabIndex = 138;
            this.OrderList.Text = "uiListBox1";
            this.OrderList.SelectedIndexChanged += new System.EventHandler(this.OrderList_SelectedIndexChanged);
            // 
            // FT_FlowConfirmed
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1282, 575);
            this.Controls.Add(this.OrderList);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnCompleted);
            this.Controls.Add(this.RequestingUnit);
            this.Controls.Add(this.Label_Details);
            this.Controls.Add(this.Details);
            this.Controls.Add(this.WorkOrderNo);
            this.Controls.Add(this.IssueDescription);
            this.Controls.Add(this.Label_WorkOrderNo);
            this.Controls.Add(this.OutageStarted);
            this.Controls.Add(this.Creator);
            this.Controls.Add(this.IssueCategory);
            this.Controls.Add(this.Label_Creator);
            this.Controls.Add(this.Engineers);
            this.Controls.Add(this.Label_CreationDate);
            this.Controls.Add(this.MaintenanceUnit);
            this.Controls.Add(this.CreationDate);
            this.Controls.Add(this.Label_MachineList);
            this.Controls.Add(this.MachineList);
            this.Controls.Add(this.RepairStarted);
            this.Controls.Add(this.Label_ModelWorkstation);
            this.Controls.Add(this.OutageEnded);
            this.Controls.Add(this.ModelWorkstation);
            this.Controls.Add(this.RepairCompleted);
            this.Controls.Add(this.Label_OutageStarted);
            this.Controls.Add(this.OutageDuration);
            this.Controls.Add(this.Label_MaintenanceUnit);
            this.Controls.Add(this.RepairDuration);
            this.Controls.Add(this.Label_Engineers);
            this.Controls.Add(this.Label_OutageDuration);
            this.Controls.Add(this.Label_IssueCategory);
            this.Controls.Add(this.Label_RepairDuration);
            this.Controls.Add(this.Label_AcceptedTime);
            this.Controls.Add(this.Label_OutageEnded);
            this.Controls.Add(this.AcceptedTime);
            this.Controls.Add(this.Label_RepairCompleted);
            this.Controls.Add(this.Label_IssueDescription);
            this.Controls.Add(this.Label_RepairStarted);
            this.Controls.Add(this.Feedback);
            this.Controls.Add(this.Label_Feedback);
            this.Controls.Add(this.FeedbackEmployee);
            this.Controls.Add(this.Label_FeedbackEmployee);
            this.Controls.Add(this.Label_RequestingUnit);
            this.EscClose = true;
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "FT_FlowConfirmed";
            this.Text = "FT_FlowConfirmed";
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 802, 460);
            this.Load += new System.EventHandler(this.FT_FlowConfirmed_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UIRichTextBox Feedback;
        private Sunny.UI.UILabel Label_Feedback;
        private Sunny.UI.UITextBox FeedbackEmployee;
        private Sunny.UI.UILabel Label_FeedbackEmployee;
        private Sunny.UI.UILabel Label_RequestingUnit;
        private Sunny.UI.UISymbolButton btnCompleted;
        private Sunny.UI.UITextBox RequestingUnit;
        private Sunny.UI.UILabel Label_Details;
        private Sunny.UI.UITextBox Details;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UITextBox IssueDescription;
        private Sunny.UI.UILabel Label_WorkOrderNo;
        private Sunny.UI.UITextBox OutageStarted;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UITextBox IssueCategory;
        private Sunny.UI.UILabel Label_Creator;
        private Sunny.UI.UITextBox Engineers;
        private Sunny.UI.UILabel Label_CreationDate;
        private Sunny.UI.UITextBox MaintenanceUnit;
        private Sunny.UI.UITextBox CreationDate;
        private Sunny.UI.UILabel Label_MachineList;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UITextBox RepairStarted;
        private Sunny.UI.UILabel Label_ModelWorkstation;
        private Sunny.UI.UITextBox OutageEnded;
        private Sunny.UI.UITextBox ModelWorkstation;
        private Sunny.UI.UITextBox RepairCompleted;
        private Sunny.UI.UILabel Label_OutageStarted;
        private Sunny.UI.UITextBox OutageDuration;
        private Sunny.UI.UILabel Label_MaintenanceUnit;
        private Sunny.UI.UITextBox RepairDuration;
        private Sunny.UI.UILabel Label_Engineers;
        private Sunny.UI.UILabel Label_OutageDuration;
        private Sunny.UI.UILabel Label_IssueCategory;
        private Sunny.UI.UILabel Label_RepairDuration;
        private Sunny.UI.UILabel Label_AcceptedTime;
        private Sunny.UI.UILabel Label_OutageEnded;
        private Sunny.UI.UITextBox AcceptedTime;
        private Sunny.UI.UILabel Label_RepairCompleted;
        private Sunny.UI.UILabel Label_IssueDescription;
        private Sunny.UI.UILabel Label_RepairStarted;
        private Sunny.UI.UISymbolButton btnReturn;
        private Sunny.UI.UISymbolButton btnCancel;
        private Sunny.UI.UIListBox OrderList;
    }
}
