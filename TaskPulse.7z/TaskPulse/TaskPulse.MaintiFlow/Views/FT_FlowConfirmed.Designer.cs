﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FT_FlowConfirmed
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.RequestingUnitResponse = new Sunny.UI.UITextBox();
            this.uiLabel_RequestingUnitResponse = new Sunny.UI.UILabel();
            this.FeedbackEmployee = new Sunny.UI.UITextBox();
            this.uiLabel_FeedbackEmployee = new Sunny.UI.UILabel();
            this.uiLabel_RequestingUnit = new Sunny.UI.UILabel();
            this.RequestingUnit = new Sunny.UI.UITextBox();
            this.SuspendLayout();
            // 
            // Feedback
            // 
            this.RequestingUnitResponse.CanEmpty = true;
            this.RequestingUnitResponse.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnitResponse.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnitResponse.Location = new System.Drawing.Point(160, 108);
            this.RequestingUnitResponse.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnitResponse.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnitResponse.Multiline = true;
            this.RequestingUnitResponse.Name = "Feedback";
            this.RequestingUnitResponse.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnitResponse.ShowText = false;
            this.RequestingUnitResponse.Size = new System.Drawing.Size(250, 85);
            this.RequestingUnitResponse.TabIndex = 86;
            this.RequestingUnitResponse.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.RequestingUnitResponse.Watermark = "";
            // 
            // uiLabel_RequestingUnitResponse
            // 
            this.uiLabel_RequestingUnitResponse.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RequestingUnitResponse.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingUnitResponse.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingUnitResponse.Location = new System.Drawing.Point(35, 108);
            this.uiLabel_RequestingUnitResponse.Name = "uiLabel_RequestingUnitResponse";
            this.uiLabel_RequestingUnitResponse.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_RequestingUnitResponse.TabIndex = 87;
            this.uiLabel_RequestingUnitResponse.Text = "需求單位回覆";
            this.uiLabel_RequestingUnitResponse.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // FeedbackEmployeeString
            // 
            this.FeedbackEmployee.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.FeedbackEmployee.FillDisableColor = System.Drawing.Color.White;
            this.FeedbackEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.FeedbackEmployee.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.FeedbackEmployee.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.FeedbackEmployee.Location = new System.Drawing.Point(160, 69);
            this.FeedbackEmployee.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.FeedbackEmployee.MinimumSize = new System.Drawing.Size(1, 16);
            this.FeedbackEmployee.Name = "FeedbackEmployeeString";
            this.FeedbackEmployee.Padding = new System.Windows.Forms.Padding(5);
            this.FeedbackEmployee.ShowText = false;
            this.FeedbackEmployee.Size = new System.Drawing.Size(200, 29);
            this.FeedbackEmployee.TabIndex = 84;
            this.FeedbackEmployee.TabStop = false;
            this.FeedbackEmployee.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.FeedbackEmployee.Watermark = "";
            // 
            // uiLabel_FeedbackEmployee
            // 
            this.uiLabel_FeedbackEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_FeedbackEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_FeedbackEmployee.Location = new System.Drawing.Point(33, 69);
            this.uiLabel_FeedbackEmployee.Name = "uiLabel_FeedbackEmployee";
            this.uiLabel_FeedbackEmployee.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_FeedbackEmployee.TabIndex = 85;
            this.uiLabel_FeedbackEmployee.Text = "需求單位人員";
            this.uiLabel_FeedbackEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RequestingUnit
            // 
            this.uiLabel_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingUnit.Location = new System.Drawing.Point(33, 30);
            this.uiLabel_RequestingUnit.Name = "uiLabel_RequestingUnit";
            this.uiLabel_RequestingUnit.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RequestingUnit.TabIndex = 83;
            this.uiLabel_RequestingUnit.Text = "需求單位名稱";
            this.uiLabel_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RequestingUnitString
            // 
            this.RequestingUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnit.FillDisableColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingUnit.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RequestingUnit.Location = new System.Drawing.Point(160, 30);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnit.Name = "RequestingUnitString";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnit.ShowText = false;
            this.RequestingUnit.Size = new System.Drawing.Size(200, 29);
            this.RequestingUnit.TabIndex = 82;
            this.RequestingUnit.TabStop = false;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // FT_FlowConfirmed
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(802, 460);
            this.Controls.Add(this.RequestingUnitResponse);
            this.Controls.Add(this.uiLabel_RequestingUnitResponse);
            this.Controls.Add(this.FeedbackEmployee);
            this.Controls.Add(this.uiLabel_FeedbackEmployee);
            this.Controls.Add(this.uiLabel_RequestingUnit);
            this.Controls.Add(this.RequestingUnit);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "FT_FlowConfirmed";
            this.Text = "FT_FlowConfirmed";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UITextBox RequestingUnitResponse;
        private Sunny.UI.UILabel uiLabel_RequestingUnitResponse;
        private Sunny.UI.UITextBox FeedbackEmployee;
        private Sunny.UI.UILabel uiLabel_FeedbackEmployee;
        private Sunny.UI.UILabel uiLabel_RequestingUnit;
        private Sunny.UI.UITextBox RequestingUnit;
    }
}
