﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.MaintiFlow;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_AcceptFlow : UIForm
    {
        #region fields

        private DataTable _dt;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private const string SELECT_CHECKBOX_NAME = "Selected";
        private const string HEADER_CHECKBOX_NAME = "hCheckBox";
        private CheckBox _headerCheckBox = null;
        private Color _defaultBackColor;
        private Color _defaultSelectionBackColor;

        #endregion fields

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// OK 按鈕標題。
        /// </summary>
        public string OkCaption { set => Button_OK.Text = value; }

        /// <summary>
        /// OK 按鈕符號。
        /// </summary>
        public int OkSymbol { set => Button_OK.Symbol = value; }

        /// <summary>
        /// 工單列表。
        /// </summary>
        public List<TaskOrder> Orders { get; set; }

        /// <summary>
        /// 驗證器。
        /// </summary>
        public Func<string, (bool isValid, string errorMessage)> Validator { get; set; } = null;

        /// <summary>
        /// 選取的工單ID。
        /// </summary>
        public List<string> SelectedOrder { get; set; } = new List<string>();

        /// <summary>
        /// 選取的工單ID。
        /// </summary>
        private string _selectedId = "";

        public FT_AcceptFlow(FieldName fieldName, FieldTitle fieldTitle)
        {
            InitializeComponent();
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            CommonStyles.SetButton(Button_OK);
            CommonStyles.SetButton(Button_Cancel, accent: true);

            _defaultBackColor = ADGV.DefaultCellStyle.BackColor;
            _defaultSelectionBackColor = ADGV.DefaultCellStyle.SelectionBackColor;

            ADGV.SetDoubleBuffered();
            ADGV.RowHeadersVisible = false;
            ADGV.MultiSelect = true;
            ADGV.AllowUserToAddRows = false;
            ADGV.AllowUserToDeleteRows = false;
            ADGV.AllowUserToResizeColumns = true;
            ADGV.AllowDrop = false;
            ADGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ADGV.FilterAndSortEnabled = false;
            ADGV.AllowUserToResizeRows = false;

            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
        }

        private void FT_AcceptFlow_Shown(object sender, EventArgs e)
        {
            _dt = new DataTable();
            //_dt.Columns.Add(_fieldName.TaskOrderId, typeof(int));
            _dt.Columns.Add(_fieldName.WorkOrderNo, typeof(string));
            _dt.Columns.Add(nameof(TaskOrder.CreatorFullName), typeof(string));
            _dt.Columns.Add(_fieldName.CreationDateTime, typeof(DateTime));
            _dt.Columns.Add(_fieldName.MachineId, typeof(string));
            _dt.Columns.Add(_fieldName.IssueDescription, typeof(string));

            ADGV.Columns.Clear();

            //// 建立 CheckBox 欄
            //DataGridViewCheckBoxColumn chk = new DataGridViewCheckBoxColumn
            //{
            //    Name = HEADER_CHECKBOX_NAME,
            //    HeaderText = "",
            //    Width = 30,
            //    FalseValue = false,
            //    TrueValue = true,
            //    IndeterminateValue = false,
            //};
            //ADGV.Columns.Add(chk);

            //ADGV.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    Name = _fieldName.TaskOrderId,
            //    DataPropertyName = _fieldName.TaskOrderId,
            //    HeaderText = _fieldTitle.TaskOrderId,
            //    ValueType = typeof(int),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            //    DefaultCellStyle = new DataGridViewCellStyle()
            //    {
            //        Alignment = DataGridViewContentAlignment.MiddleCenter,
            //    },
            //});

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.WorkOrderNo,
                DataPropertyName = _fieldName.WorkOrderNo,
                HeaderText = _fieldTitle.WorkOrderNo,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.Machine,
                DataPropertyName = _fieldName.FullMachineName,
                HeaderText = _fieldTitle.Machine,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.RequestingUnit,
                DataPropertyName = nameof(_fieldName.RequestingUnitString),
                HeaderText = _fieldTitle.RequestingUnit,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.Creator,
                DataPropertyName = nameof(_fieldName.CreatorHalfName),
                HeaderText = _fieldTitle.Creator,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.CreationDateTime,
                DataPropertyName = _fieldName.CreationDateTime,
                HeaderText = _fieldTitle.CreationDate,
                ValueType = typeof(DateTime),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.OutageStarted,
                DataPropertyName = _fieldName.OutageStarted,
                HeaderText = _fieldTitle.OutageStarted,
                ValueType = typeof(DateTime),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.IssueDescription,
                DataPropertyName = _fieldName.IssueDescription,
                HeaderText = _fieldTitle.IssueDescription,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            //pName = $"{_fieldName.WorkstationName}.{nameof(TaskOrder.WorkstationName.WorkstationName)}";
            //ADGV.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = _fieldName.WorkstationName,
            //    HeaderText = _fieldTitle.WorkstationName,
            //    ValueType = typeof(string),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            //    DefaultCellStyle = new DataGridViewCellStyle()
            //    {
            //        Alignment = DataGridViewContentAlignment.MiddleLeft,
            //    },
            //});
            //ADGV.SetFilterChecklistEnabled(ADGV.Columns[pName], true);

            ADGV.AutoGenerateColumns = false;
            _dt = Orders.ToDataTable();
            ADGV.DataSource = _dt;

            foreach (DataGridViewColumn col in ADGV.Columns)
            {
                ADGV.SetFilterChecklistEnabled(col, false);
                ADGV.SetFilterCustomEnabled(col, false);
                //col.ReadOnly = col.Name != HEADER_CHECKBOX_NAME;
            }

            //AddHeaderCheckBox();
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            SelectedOrder = null;
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void Button_OK_Click(object sender, EventArgs e)
        {
            //var row = ADGV.Rows
            //    .Cast<DataGridViewRow>()
            //    .Where(r => Convert.ToBoolean(r.Cells[HEADER_CHECKBOX_NAME].Value))
            //    .ToList();

            //if (row.Count == 0)
            //{
            //    MessageBox.Show("尚未勾選任何列！");
            //    return;
            //}

            //StringBuilder sb = new StringBuilder();
            //foreach (var row in row)
            //{
            //    sb.AppendLine($"{row.Cells["Name"].Value} - {row.Cells["Age"].Value}");
            //}

            //MessageBox.Show("勾選的列：\n" + sb.ToString());


            SelectedOrder = new List<string>();
            if (ADGV.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in ADGV.SelectedRows)
                {
                    string orderId = row.Cells[_fieldName.WorkOrderNo].Value.ToString();
                    if (Validator != null)
                    {
                        var (isValid, errorMessage) = Validator(orderId);
                        if (!isValid)
                        {
                            MessageBox.Show(errorMessage, "輸入錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    SelectedOrder.Add(orderId);
                }
                DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView row)
            {
                _selectedId = (string)row[_fieldName.WorkOrderNo];
                return;
            }
            _selectedId = "";
        }

        /********************
         * 首欄CheckBox
         ********************/
        /// <summary>
        /// 在標題列加上全選的 CheckBox。
        /// </summary>
        private void AddHeaderCheckBox()
        {
            _headerCheckBox = new CheckBox();
            _headerCheckBox.Size = new Size(15, 15);

            // 取得第一欄標題的顯示位置
            Rectangle rect = ADGV.GetCellDisplayRectangle(0, -1, true);
            _headerCheckBox.Location = new Point(rect.Location.X + (rect.Width - 15) / 2, rect.Location.Y + (rect.Height - 15) / 2);

            _headerCheckBox.CheckedChanged += HeaderCheckBox_CheckedChanged;
            ADGV.Controls.Add(_headerCheckBox);
        }

        /// <summary>
        /// 全選/全不選邏輯
        /// </summary>
        private void HeaderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            ADGV.EndEdit(); // 確保編輯結束
            foreach (DataGridViewRow row in ADGV.Rows)
            {
                ((DataGridViewCheckBoxCell)row.Cells[HEADER_CHECKBOX_NAME]).Value = _headerCheckBox.Checked;
                HighlightRow(row, _headerCheckBox.Checked);
            }
        }

        /// <summary>
        /// 高亮整列
        /// </summary>
        /// <param name="row"></param>
        /// <param name="isChecked"></param>
        private void HighlightRow(DataGridViewRow row, bool isChecked)
        {
            if (isChecked)
            {
                row.DefaultCellStyle.BackColor = _defaultBackColor;
                row.DefaultCellStyle.SelectionBackColor = _defaultSelectionBackColor;
            }
            else
            {
                row.DefaultCellStyle.BackColor = CommonStyles.AccentColor;
                row.DefaultCellStyle.SelectionBackColor = CommonStyles.AccentColor;
            }
        }

        /// <summary>
        /// 當使用者勾選某列時自動更新選擇狀態。
        /// </summary>
        private void ADGV_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ADGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.RowIndex >= 0 && e.ColumnIndex == ADGV.Columns[HEADER_CHECKBOX_NAME].Index)
            //{
            //    bool isChecked = Convert.ToBoolean(ADGV.Rows[e.RowIndex].Cells[HEADER_CHECKBOX_NAME].Value);
            //    HighlightRow(ADGV.Rows[e.RowIndex], isChecked);

            //    // 更新標題全選狀態
            //    bool allChecked = ADGV.Rows.Cast<DataGridViewRow>()
            //        .All(r => Convert.ToBoolean(r.Cells[HEADER_CHECKBOX_NAME].Value));

            //    _headerCheckBox.CheckedChanged -= HeaderCheckBox_CheckedChanged;
            //    _headerCheckBox.Checked = allChecked;
            //    _headerCheckBox.CheckedChanged += HeaderCheckBox_CheckedChanged;
            //}
        }

        private void ADGV_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            //if (ADGV.CurrentCell is DataGridViewCheckBoxCell)
            //    ADGV.CommitEdit(DataGridViewDataErrorContexts.Commit);
        }
    }
}
