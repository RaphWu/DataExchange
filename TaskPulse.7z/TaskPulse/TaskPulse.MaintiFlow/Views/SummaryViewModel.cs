﻿using System;
using System.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public class SummaryViewModel : ObservableValidator
    {
        [Description("維護工單編號")]
        public string WorkOrderNo { get; set; }

        [Description("編號")]
        public int OrderNo { get; set; }

        [Description("建檔人員")]
        public string CreatorName { get; set; }

        [Description("建檔日期")]
        public DateTime? CreationDate { get; set; }

        [Description("目前狀態")]
        public string Status { get; set; }

        [Description("維護單位")]
        public string MaintenanceUnit { get; set; }

        [Description("維護工程師")]
        public string Engineers { get; set; }

        [Description("機台編號")]
        public string MachineId { get; set; }

        [Description("接收時間")]
        public DateTime? AcceptedTime { get; set; }

        [Description("開始時間")]
        public DateTime? RepairStarted { get; set; }

        [Description("完成時間")]
        public DateTime? RepairCompleted { get; set; }

        [Description("維修工時")]
        public TimeSpan RepairDuration { get; set; }

        [Description("停動開始")]
        public DateTime? OutageStarted { get; set; }

        [Description("停動結束")]
        public DateTime? OutageEnded { get; set; }

        [Description("停動工時")]
        public TimeSpan OutageDuration { get; set; }

        [Description("責任歸屬")]
        public string Responsible { get; set; }

        [Description("機種")]
        public string ModelName { get; set; }

        [Description("工站")]
        public string Workstation { get; set; }

        [Description("維護類型")]
        public string IssueCategory { get; set; }

        [Description("問題描述")]
        public string IssueDescription { get; set; }

        [Description("維護內容")]
        public string Details { get; set; }

        [Description("需求單位名稱")]
        public string RequestingUnit { get; set; }

        [Description("需求單位人員工號")]
        public string RequestingEmployee { get; set; }

        [Description("需求單位回覆")]
        public string Response { get; set; }
    }
}
