﻿using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FlowTracking : UIPage
    {
        public FlowTracking()
        {
            InitializeComponent();

            uiBreadcrumb.Items.AddRange(new string[] { "接單", "維護完成", "委託者確認" });
            uiBreadcrumb.Width = 400;
            uiBreadcrumb.ItemWidth = 135;
            uiBreadcrumb.ItemIndex = 0;
        }
    }
}
