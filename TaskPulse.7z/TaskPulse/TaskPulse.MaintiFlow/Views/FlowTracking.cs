﻿//using System.Collections.Generic;
//using System.Linq;
//using Calin.TaskPulse.Core.Models;
//using Calin.TaskPulse.Entity.Contants;
//using Calin.TaskPulse.Entity.MaintiFlowMain;
//using Sunny.UI;

///*
//FT_OrderAccepted
//FT_MaintiWork
//FT_FlowConfirmed
//*/
//namespace Calin.TaskPulse.MaintiFlowMain.Views
//{
//    public partial class FlowTracking : UIPage
//    {
//        private CoreContext _coreContext;
//        private FT_AcceptFlow _acceptFlow;
//        private FT_MaintiWork _maintenanceCompleted;
//        private FT_FlowConfirmed _clientConfirmed;
//        private readonly FieldTitle _fieldTitle;

//        private List<TaskOrder> _uncompletedOrder;

//        public FlowTracking(CoreContext coreContext,
//                            FT_AcceptFlow fT_AcceptFlow,
//                            FT_MaintiWork fT_MaintenanceCompleted,
//                            FT_FlowConfirmed fT_ClientConfirmed,
//                            FieldTitle fieldTitle)
//        {
//            InitializeComponent();
//            _coreContext = coreContext;
//            _acceptFlow = fT_AcceptFlow;
//            _maintenanceCompleted = fT_MaintenanceCompleted;
//            _clientConfirmed = fT_ClientConfirmed;
//            _fieldTitle = fieldTitle;

//            uiBreadcrumb.Items.AddRange(new string[] { "接單", "維護完成", "委託者確認" });
//            uiBreadcrumb.Width = 400;
//            uiBreadcrumb.ItemWidth = 135;
//            uiBreadcrumb.ItemIndex = 0;

//            _uncompletedOrder = _coreContext.TaskOrders
//                .Where(o => o.StatusString != FlowStatus.Completed)
//                .OrderByDescending(o => o.WorkOrderNo)
//                .ToList();
//            //uiListBox_OrderList.DataSource = _uncompletedOrder
//            //    .Select(o => $"{o.WorkOrderNo} [{o.MachineString}]")
//            //    .ToList();

//            uiTabControl_Steps.AddPage(_orderAccepted);
//            uiTabControl_Steps.AddPage(_maintenanceCompleted);
//            uiTabControl_Steps.AddPage(_clientConfirmed);

//            // 下方
//            //OrderNo.DataBindings.Clear();
//            //OrderNo.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.OrderNo));
//            //uiLabel_OrderNo.Text = _fieldTitle.OrderNo;

//            //WorkOrderNo.DataBindings.Clear();
//            //WorkOrderNo.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.WorkOrderNo));
//            //uiLabel_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;

//            //CreatorName.DataBindings.Clear();
//            //CreatorName.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.CreatorName));
//            //Label_Creator.Text = _fieldTitle.CreatorName;

//            //CreationDateTime.DataBindings.Clear();
//            //CreationDateTime.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.CreationDateTime));
//            //uiLabel_CreationDate.Text = _fieldTitle.CreationDateTime;

//            //AcceptedTime.DataBindings.Clear();
//            //AcceptedTime.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.AcceptedTime));
//            //uiLabel_AcceptedTime.Text = _fieldTitle.AcceptedTime;

//            //Condition.DataBindings.Clear();
//            //Condition.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.Condition));
//            //uiLabel_Status.Text = _fieldTitle.Condition;

//            //MaintenanceUnit.DataBindings.Clear();
//            //MaintenanceUnit.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.MaintenanceUnit));
//            //uiLabel_MaintenanceUnit.Text = _fieldTitle.MaintenanceUnit;

//            //MaintenanceEngineer.DataBindings.Clear();
//            //MaintenanceEngineer.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.Engineer));
//            //uiLabel_MaintenanceEngineer.Text = _fieldTitle.Engineer;

//            //MachineList.DataBindings.Clear();
//            //MachineList.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.MachineId));
//            //Label_MachineList.Text = _fieldTitle.MachineId;

//            //ModelBuff.DataBindings.Clear();
//            //ModelBuff.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.Value));
//            //uiLabel_Model.Text = _fieldTitle.ModelBuff;

//            //WorkstationBuff.DataBindings.Clear();
//            //WorkstationBuff.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.WorkstationBuff));
//            //uiLabel_WorkStation.Text = _fieldTitle.WorkstationBuff;

//            //IssueCategoryString.DataBindings.Clear();
//            //IssueCategoryString.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.IssueCategoryString));
//            //uiLabel_IssueCategory.Text = _fieldTitle.IssueCategoryString;

//            //IssueDescription.DataBindings.Clear();
//            //IssueDescription.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.IssueDescription));
//            //Label_IssueDescription.Text = _fieldTitle.IssueDescription;

//            //Details.DataBindings.Clear();
//            //Details.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.Details));
//            //uiLabel_Details.Text = _fieldTitle.Details;

//            //RequestingUnitString.DataBindings.Clear();
//            //RequestingUnitString.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.RequestingUnitString));
//            //uiLabel_RequestingUnit.Text = _fieldTitle.RequestingUnitString;

//            //FeedbackEmployeeString.DataBindings.Clear();
//            //FeedbackEmployeeString.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.FeedbackEmployeeString));
//            //uiLabel_FeedbackEmployee.Text = _fieldTitle.FeedbackEmployeeString;

//            //Feedback.DataBindings.Clear();
//            //Feedback.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.Feedback));
//            //uiLabel_RequestingUnitResponse.Text = _fieldTitle.Feedback;

//            //RepairStarted.DataBindings.Clear();
//            //RepairStarted.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.RepairStarted));
//            //uiLabel_RepairStarted.Text = _fieldTitle.RepairStarted;

//            //RepairCompleted.DataBindings.Clear();
//            //RepairCompleted.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.RepairCompleted));
//            //uiLabel_RepairCompleted.Text = _fieldTitle.RepairCompleted;

//            //RepairDuration.DataBindings.Clear();
//            //RepairDuration.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.RepairDuration));
//            //uiLabel_RepairDuration.Text = _fieldTitle.RepairDuration;

//            //OutageStarted.DataBindings.Clear();
//            //OutageStarted.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.OutageStarted));
//            //Label_OutageStarted.Text = _fieldTitle.OutageStarted;

//            //OutageEnded.DataBindings.Clear();
//            //OutageEnded.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.OutageEnded));
//            //uiLabel_OutageEnded.Text = _fieldTitle.OutageEnded;

//            //OutageDuration.DataBindings.Clear();
//            //OutageDuration.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.OutageDuration));
//            //uiLabel_OutageDuration.Text = _fieldTitle.OutageDuration;

//            //Responsible.DataBindings.Clear();
//            //Responsible.DataBindings.Add("Text", _bs, nameof(TaskOrderViewModel.Responsible));
//            //uiLabel_Responsible.Text = _fieldTitle.Responsible;
//        }

//        private void uiBreadcrumb_ItemIndexChanged(object sender, int step)
//        {
//            uiTabControl_Steps.SelectedIndex = step;
//        }
//    }
//}
