﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Core.WinForms;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_MaintiWork : UIForm
    {
        #region fields

        private readonly ILifetimeScope _rootScope;

        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private BindingList<TaskOrder> _editBuffs;
        private TaskOrder _editBuff = null;
        //private BindingSource _bs;

        // UIDatetimePicker無法設定空值。
        // 如果它發現沒有輸入值，在失去焦點時會自動填入下面的日期時間，造成資料錯亂。
        // WinForms的DateTimePicker在網路上有自訂顯示空白的方法，
        // 但UIDatetimePicker拿掉Format屬性還限制了一些屬性設定，所以網路的方法無法使用。
        // 目前用比對法，如果DateTime值是下面這個值，視為沒有輸入。
        //private readonly DateTime ZERO_DATE_TIME = DateTime.Parse("1900/1/1 0:0");

        #endregion fields

        public List<TaskOrder> Orders { get; set; } = new List<TaskOrder>();
        public List<int> EngineerList { get; set; } = new List<int>();

        public FT_MaintiWork(ILifetimeScope lifetimeScope,
                             CoreContext coreContext,
                             ICore core,
                             MaintiFlowData maintiFlowData,
                             CoreData coreData,
                             FieldName fieldName,
                             FieldTitle fieldTitle)
        {
            InitializeComponent();
            _rootScope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            CommonStyles.SetButton(Button_Save);
            CommonStyles.SetButton(Button_Cancel, isCancel: true);

            ListBox_Orders.HoverColor = CommonStyles.HoverColor;

            //ModelWorkstation.ButtonFillColor = CommonStyles.BackColor;
            //ModelWorkstation.ButtonFillHoverColor = CommonStyles.HoverColor;
            //WorkstationName.ButtonFillColor = CommonStyles.BackColor;
            //WorkstationName.ButtonFillHoverColor = CommonStyles.HoverColor;
        }

        private void FT_MaintiWork_Load(object sender, System.EventArgs e)
        {
            cbRepairStarted.CheckedChanged += (s, e1) => { RepairStarted.ReadOnly = !cbRepairStarted.Checked; };
            cbRepairCompleted.CheckedChanged += (s, e1) => { RepairCompleted.ReadOnly = !cbRepairCompleted.Checked; };
            //cbOutageStarted.CheckedChanged += (s, e1) => { OutageStarted.ReadOnly = !cbOutageStarted.Checked; };
            cbOutageEnded.CheckedChanged += (s, e1) => { OutageEnded.ReadOnly = !cbOutageEnded.Checked; };

            Engineers.Nodes.Clear();
            foreach (var engineer in _coreData.Engineers)
            {
                TreeNode tn = new TreeNode()
                {
                    Name = engineer.EmployeeName,
                    Text = engineer.EmployeeName,
                    Tag = new SelectorInfo()
                    {
                        Id = engineer.Id,
                        Name = engineer.EmployeeName,
                    },
                };
                Engineers.Nodes.Add(tn);
            }

            var lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
            lvm.AddRange(_context.MaintenanceUnits
                .Select(m => new ListViewModel()
                {
                    NullableId = m.Id,
                    Name = m.UnitName,
                })
                .ToList());
            MaintenanceUnit.DataSource = lvm;
            MaintenanceUnit.DisplayMember = "Name";
            MaintenanceUnit.ValueMember = "NullableId";

            lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
            lvm.AddRange(_context.IssueCategories
                .Select(m => new ListViewModel()
                {
                    NullableId = m.Id,
                    Name = m.CategoryName,
                })
                .ToList());
            IssueCategory.DataSource = lvm;
            IssueCategory.DisplayMember = "Name";
            IssueCategory.ValueMember = "NullableId";

            int tabIndex = 0;
            Label_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;
            WorkOrderNo.TabIndex = ++tabIndex;
            WorkOrderNo.ReadOnly = true;

            Label_Creator.Text = _fieldTitle.Creator;
            Creator.TabIndex = ++tabIndex;
            Creator.ReadOnly = true;

            Label_CreationDate.Text = _fieldTitle.CreationDate;
            CreationDate.TabIndex = ++tabIndex;
            CreationDate.ReadOnly = true;

            Label_MachineList.Text = _fieldTitle.Machine;
            MachineList.TabIndex = ++tabIndex;
            MachineList.ReadOnly = true;

            Label_ModelWorkstation.Text = _fieldTitle.ModelWorkstationName;
            ModelWorkstation.TabIndex = ++tabIndex;

            Label_AcceptedTime.Text = _fieldTitle.AcceptedTime;
            AcceptedTime.TabIndex = ++tabIndex;
            AcceptedTime.ReadOnly = true;

            Label_RequestingUnit.Text = _fieldTitle.RequestingUnit;
            RequestingUnit.TabIndex = ++tabIndex;
            RequestingUnit.ReadOnly = true;

            Label_MaintenanceUnit.Text = _fieldTitle.MaintenanceUnit;
            MaintenanceUnit.TabIndex = ++tabIndex;

            Label_Engineers.Text = _fieldTitle.Engineer;
            Engineers.TabIndex = ++tabIndex;

            Label_IssueCategory.Text = _fieldTitle.IssueCategory;
            IssueCategory.TabIndex = ++tabIndex;

            Label_IssueDescription.Text = _fieldTitle.IssueDescription;
            IssueDescription.TabIndex = ++tabIndex;

            Label_Details.Text = _fieldTitle.Details;
            Details.TabIndex = ++tabIndex;

            Label_RepairStarted.Text = _fieldTitle.RepairStarted;
            RepairStarted.TabIndex = ++tabIndex;

            Label_RepairCompleted.Text = _fieldTitle.RepairCompleted;
            RepairCompleted.TabIndex = ++tabIndex;

            Label_OutageStarted.Text = _fieldTitle.OutageStarted;
            OutageStarted.TabIndex = ++tabIndex;
            OutageStarted.ReadOnly = true;

            Label_OutageEnded.Text = _fieldTitle.OutageEnded;
            OutageEnded.TabIndex = ++tabIndex;

            Label_RepairDuration.Text = _fieldTitle.RepairDuration;
            RepairDuration.TabIndex = ++tabIndex;
            RepairDuration.ReadOnly = true;

            Label_OutageDuration.Text = _fieldTitle.OutageDuration;
            OutageDuration.TabIndex = ++tabIndex;
            OutageDuration.ReadOnly = true;

            LoadData();
        }

        private void FT_MaintiWork_Shown(object sender, EventArgs e)
        {
            SunnyUiHelper.AdjustFormLayout(this, TLP_Content);
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button_Save_Click(object sender, EventArgs ea)
        {
            try
            {
                SaveCurrentBuff();
                for (int idx = 0; idx < _editBuffs.Count; idx++)
                {
                    var buff = _editBuffs[idx];
                    var to = _context.TaskOrders.FirstOrDefault(t => t.WorkOrderNo == buff.WorkOrderNo);
                    if (to == null)
                        throw new ArgumentNullException(buff.WorkOrderNo);

                    to.IssueDescription = buff.IssueDescription;
                    to.Details = buff.Details;
                    to.RepairStarted = buff.RepairStarted;
                    to.RepairCompleted = buff.RepairCompleted;
                    to.OutageEnded = buff.OutageEnded;

                    //to.Workstation = _core.GetWorkstation(buff.WorkstationId ?? 0);

                    // FK
                    to.WorkstationId = buff.WorkstationId;
                    to.MaintenanceUnitId = buff.MaintenanceUnitId;
                    to.IssueCategoryId = buff.IssueCategoryId;

                    // 多對多 - EngineerString
                    to.Engineers.Clear();
                    foreach (var emp in buff.Engineers)
                    {
                        var eng = _context.Employees.Find(emp.Id);
                        if (eng != null)
                            to.Engineers.Add(eng);
                    }
                }
                _context.SaveChanges();
                StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
                MessageBox.Show("維護工單已儲存！");
                Initialize();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /********************
         * 
         ********************/
        public void Initialize()
        {
            Orders = _flowData.TaskOrders
                .Where(t => t.Status == FlowStatus.InProgress
                    && (t.Creator != null || (t.Engineers != null && t.Engineers.Any())))
                .ToList();
        }

        private void LoadData()
        {
            _editBuffs = new BindingList<TaskOrder>();
            //_bs = new BindingSource();

            // Load ViewModel
            foreach (var rec in Orders)
            {
                _editBuffs.Add(new TaskOrder()
                {
                    Id = rec.Id,
                    WorkOrderNo = rec.WorkOrderNo,
                    Status = rec.Status,
                    Machine = rec.Machine,
                    WorkstationId = rec.WorkstationId,
                    Workstation = rec.Workstation,
                    Creator = rec.Creator,
                    MaintenanceUnitId = rec.MaintenanceUnitId,
                    MaintenanceUnit = rec.MaintenanceUnit,
                    Engineers = rec.Engineers,
                    AcceptedTime = rec.AcceptedTime,
                    IssueCategoryId = rec.IssueCategoryId,
                    IssueCategory = rec.IssueCategory,
                    IssueDescription = rec.IssueDescription,
                    Details = rec.Details,
                    RepairStarted = rec.RepairStarted,
                    RepairCompleted = rec.RepairCompleted,
                    RepairDuration = rec.RepairDuration,
                    RequestingUnit = rec.RequestingUnit,
                    FeedbackEmployeeId = rec.FeedbackEmployeeId,
                    Feedback = rec.Feedback,
                    OutageStarted = rec.OutageStarted,
                    OutageEnded = rec.OutageEnded,
                    OutageDuration = rec.OutageDuration,
                });
            }

            ListBox_Orders.SelectedIndexChanged -= ListBoxOrders_SelectedIndexChanged;
            ListBox_Orders.DataSource = Orders.Select(t => t.WorkOrderNo).ToList();
            ListBox_Orders.SelectedIndexChanged += ListBoxOrders_SelectedIndexChanged;

            UpdateCurrentBuffIndex();
            ReadCurrentBuff();
        }

        // 讀取新值
        private void ReadCurrentBuff()
        {
            if (_editBuff != null)
            {
                WorkOrderNo.Text = _editBuff.WorkOrderNo;
                Creator.Text = _editBuff.CreatorHalfName;
                CreationDate.Text = _editBuff.CreationDateTimeString;
                MachineList.Text = _editBuff.FullMachineName;
                ModelWorkstation.Text = _editBuff.ModelWorkstationName;
                AcceptedTime.Text = _editBuff.AcceptedTimeString;
                RequestingUnit.Text = _editBuff.RequestingUnitString;
                MaintenanceUnit.SelectedValue = _editBuff.MaintenanceUnitId ?? 0;
                IssueCategory.SelectedValue = _editBuff.IssueCategoryId ?? 0;
                IssueDescription.Text = _editBuff.IssueDescription;
                Details.Text = _editBuff.Details;
                cbRepairStarted.Checked = _editBuff.RepairStarted != null;
                cbRepairCompleted.Checked = _editBuff.RepairCompleted != null;
                //cbOutageStarted.Checked = _editBuff.OutageStarted != null;
                cbOutageStarted.Checked = true;
                cbOutageEnded.Checked = _editBuff.OutageEnded != null;
                RepairStarted.Value = _editBuff.RepairStarted ?? DateTime.Now;
                RepairCompleted.Value = _editBuff.RepairCompleted ?? DateTime.Now;
                OutageStarted.Value = _editBuff.OutageStarted ?? DateTime.Now;
                OutageEnded.Value = _editBuff.OutageEnded ?? DateTime.Now;

                RepairDuration.Text = _editBuff.RepairDurationString;
                OutageDuration.Text = _editBuff.OutageDurationString;

                Engineers.Text = _editBuff.EngineerString;
                var emps = _editBuff.EngineerString
                   .Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                   .Select(n => n.Trim())
                   .Where(n => !string.IsNullOrEmpty(n))
                   .ToList();
                foreach (TreeNode node in Engineers.Nodes)
                    node.Checked = emps.Contains(node.Text);
            }
        }

        // 儲存舊值
        private void SaveCurrentBuff()
        {
            if (_editBuff != null)
            {
                _editBuff.MaintenanceUnitId = (int?)MaintenanceUnit.SelectedValue;
                _editBuff.Engineers = _core.GetEngineers(Engineers.Text);
                _editBuff.IssueCategoryId = (int?)IssueCategory.SelectedValue;
                _editBuff.IssueDescription = IssueDescription.Text;
                _editBuff.Details = Details.Text;
                _editBuff.RepairStarted = cbRepairStarted.Checked ? RepairStarted.Value : (DateTime?)null;
                _editBuff.RepairCompleted = cbRepairCompleted.Checked ? RepairCompleted.Value : (DateTime?)null;
                _editBuff.OutageStarted = cbOutageStarted.Checked ? OutageStarted.Value : (DateTime?)null;
                _editBuff.OutageEnded = cbOutageEnded.Checked ? OutageEnded.Value : (DateTime?)null;

                var ws = _core.GetWorkstation(ModelWorkstation.Text);
                if (ws != null)
                {
                    _editBuff.WorkstationId = ws.Id;
                    _editBuff.Workstation = ws;
                }
                else
                {
                    _editBuff.WorkstationId = 0;
                    _editBuff.Workstation = null;
                }
            }
        }

        private void UpdateCurrentBuffIndex()
        {
            _editBuff = _editBuffs[ListBox_Orders.SelectedIndex];
        }

        private void ListBoxOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaveCurrentBuff();
            UpdateCurrentBuffIndex();
            ReadCurrentBuff();
        }

        #region 按鍵行為

        /********************
         * 按鍵行為
         ********************/
        private void ModelWorkstation_ButtonClick(object sender, EventArgs e)
        {
            using (var fls = _rootScope.Resolve<FlowLayoutSelector>())
            {
                fls.HideTabHeaders = false;
                fls.ShowTreeView = true;
                fls.Title = $"請選擇{_fieldTitle.Model}";
                fls.TreeViewCaption = "機種";
                fls.MultiSelection = false;
                fls.TabPageCache = _coreData.ModelWsTabPageCache;
                fls.DefaultChecked = new List<string>() { _editBuff.ModelWorkstationName };
                fls.Initialize();

                if (fls.ShowDialog() == DialogResult.OK)
                {
                    if (fls.ResultList.Count > 0)
                    {
                        SelectorInfo info = fls.ResultList[0];
                        int idx = ListBox_Orders.SelectedIndex;
                        var ws = _core.GetWorkstation(info.Id);
                        _editBuffs[idx].WorkstationId = ws.Id;
                        _editBuffs[idx].Workstation = ws;
                        _editBuffs[idx].Workstation.ModelId = ws != null && ws.ModelId != null
                            ? (int?)_core.GetModel((int)ws.ModelId).Id
                            : null;

                        var showText = new string[2];
                        showText[0] = info.Category;
                        showText[1] = info.Name;
                        ModelWorkstation.Text = string.Join(" » ", showText);
                    }
                }
            }
        }

        private void MaintenanceUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_editBuff == null)
                return;

            if (MaintenanceUnit.SelectedItem is ListViewModel select)
                _editBuff.MaintenanceUnitId = select.Id;
        }

        private void Engineers_NodesSelected(object sender, TreeNodeCollection nodes)
        {
            if (_editBuff == null)
                return;

            EngineerList.Clear();
            for (int i = 0; i < nodes.Count; i++)
            {
                var node = nodes[i];
                if (node.Checked)
                    EngineerList.Add(((SelectorInfo)node.Tag).Id);
            }
        }

        private void RepairStarted_ValueChanged(object sender, DateTime value)
        {
            if (cbRepairStarted.Checked && _editBuff != null)
            {
                if (DateTime.TryParse(RepairStarted.Text, out DateTime dt))
                    _editBuff.RepairStarted = dt;
            }
            UpdateRepairDuration();
        }

        private void RepairCompleted_ValueChanged(object sender, DateTime value)
        {
            if (cbRepairCompleted.Checked && _editBuff != null)
            {
                if (DateTime.TryParse(RepairCompleted.Text, out DateTime dt))
                    _editBuff.RepairCompleted = dt;
            }
            UpdateRepairDuration();
        }

        private void UpdateRepairDuration()
        {
            bool hasStarted = cbRepairStarted.Checked && _editBuff.RepairStarted.HasValue;
            bool hasCompleted = cbRepairCompleted.Checked && _editBuff.RepairCompleted.HasValue;

            if (!hasCompleted)
                RepairCompleted.Text = "";

            if (!hasStarted)
                RepairStarted.Text = "";

            if (hasStarted)
            {
                _editBuff.RepairDuration = hasCompleted
                    ? (TimeSpan)(_editBuff.RepairCompleted - _editBuff.RepairStarted)
                    : (TimeSpan)(DateTime.Now - _editBuff.RepairStarted);
            }
            else
            {
                _editBuff.RepairDuration = TimeSpan.Zero;
            }
            RepairDuration.Text = _editBuff.RepairDurationString;
        }

        private void OutageStarted_ValueChanged(object sender, DateTime value)
        {
            if (cbOutageStarted.Checked && _editBuff != null)
            {
                if (DateTime.TryParse(OutageStarted.Text, out DateTime dt))
                    _editBuff.OutageStarted = dt;
            }
            UpdateOutageDuration();
        }

        private void OutageEnded_ValueChanged(object sender, DateTime value)
        {
            if (cbOutageEnded.Checked && _editBuff != null)
            {
                if (DateTime.TryParse(OutageEnded.Text, out DateTime dt))
                    _editBuff.OutageEnded = dt;
            }
            UpdateOutageDuration();
        }

        private void UpdateOutageDuration()
        {
            bool hasStarted = cbOutageStarted.Checked && _editBuff.OutageStarted.HasValue;
            bool hasEnded = cbOutageEnded.Checked && _editBuff.OutageEnded.HasValue;

            if (!hasEnded)
                OutageEnded.Text = "";

            if (!hasStarted)
                OutageStarted.Text = "";

            if (hasStarted)
            {
                _editBuff.OutageDuration = hasEnded
                    ? (TimeSpan)(_editBuff.OutageEnded - _editBuff.OutageStarted)
                    : (TimeSpan)(DateTime.Now - _editBuff.OutageStarted);
            }
            else
            {
                _editBuff.OutageDuration = TimeSpan.Zero;
            }
            OutageDuration.Text = _editBuff.OutageDurationString;
        }

        #endregion 按鍵行為

        private void button_Completed_Click(object sender, EventArgs e)
        {
            SaveCurrentBuff();
            if (MessageBox.Show($"確定維護完成？\n維護工單：{_editBuff.WorkOrderNo}",
                                "請確定執行",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Question,
                                MessageBoxDefaultButton.Button2) == DialogResult.OK)
            {
                var to = _context.TaskOrders
                       .FirstOrDefault(t => t.WorkOrderNo == _editBuff.WorkOrderNo);
                to.Status = FlowStatus.Pending;
                to.FillingTime = DateTime.Now;
                _context.SaveChanges();
                StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

                MessageBox.Show($"維護工單 {_editBuff.WorkOrderNo} 已轉換至 {FlowStatus.Pending.GetDescription()} 狀態！");
                Initialize();
                LoadData();
            }
        }
    }
}
