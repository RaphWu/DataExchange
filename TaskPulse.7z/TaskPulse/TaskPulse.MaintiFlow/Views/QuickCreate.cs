﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Extensions;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class QuickCreate : UIForm
    {
        private readonly ILifetimeScope _rootScope;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly IMail _mail;
        private readonly CurrentUserContext _user;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        public QuickCreate(ILifetimeScope lifetimeScope,
                           CoreContext coreContext,
                           ICore core,
                           IMail mail,
                           CurrentUserContext currentUserContext,
                           MaintiFlowData maintiFlowData,
                           CoreData coreData,
                           MultiSelector multiSelector)
        {
            InitializeComponent();
            _rootScope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _mail = mail;
            _user = currentUserContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _mSel = multiSelector;

            CommonStyles.SetButton(btnCreate);
            CommonStyles.SetButton(btnCancel, isCancel: true);
        }

        private async void QuickCreate_Load(object sender, EventArgs e)
        {
            await LoadData();

            if (_user.CurrentUser?.DepartmentId.HasValue ?? false)
                MaintenanceUnit.SelectedValue = (int)_user.CurrentUser.DepartmentId;
            Engineers.Text = _user.IsAdmin ? "" : _user.UserName;

            var now = DateTime.Now;
            RepairStarted.Value = now;
            OutageStarted.Value = now;
            CreationDate.Value = now;
            AcceptedTime.Value = now;

            Creator.Text = _user.IsAdmin ? "" : _user.UserName;
        }

        private async Task LoadData()
        {
            var mu = await _context.MaintenanceUnits
                .OrderBy(m => m.OrderNo)
                .Select(m => new ListViewModel
                {
                    Id = m.Id,
                    Name = m.UnitName,
                })
                .ToListAsync();
            MaintenanceUnit.DataSource = mu;
            MaintenanceUnit.DisplayMember = "Name";
            MaintenanceUnit.ValueMember = "Id";

            var ic = await _context.IssueCategories
                .OrderBy(i => i.OrderNo)
                .Select(i => new ListViewModel
                {
                    Id = i.Id,
                    Name = i.CategoryName,
                })
                .ToListAsync();
            ic.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
            IssueCategory.DataSource = ic;
            IssueCategory.DisplayMember = "Name";
            IssueCategory.ValueMember = "Id";

            var ru = await _context.Departments
                .OrderBy(d => d.OrderNo)
                .Select(d => new ListViewModel
                {
                    Id = d.Id,
                    Name = d.DepartmentName,
                })
                .ToListAsync();
            ru.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
            RequestingUnit.DataSource = ru;
            RequestingUnit.DisplayMember = "Name";
            RequestingUnit.ValueMember = "Id";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {

        }

        private void MachineList_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.Machine}";
            _mSel.TreeViewCaption = "機台";
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.MachinesMultiTabPageCache;
            _mSel.DefaultChecked = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                MachineList.Text = _mSel.ResultList.Count > 0
                    ? string.Join("; ", _mSel.ResultList.Select(r => r.Name).ToArray())
                    : "";
            }
        }

        private void ModelWs_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.ModelName}";
            _mSel.TreeViewCaption = "機種";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;

            // 安全處理 ModelWs.Text：避免 NullReferenceException 並處理空字串
            var lastPart = ModelWs.Text?
                .Split(new char[] { '»', ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .LastOrDefault();
            if (string.IsNullOrWhiteSpace(lastPart))
                _mSel.DefaultChecked = new List<string>();
            else
                _mSel.DefaultChecked = new List<string> { lastPart.Trim() };

            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    CategoryInfo info = _mSel.ResultList[0];
                    var ws = _core.GetWorkstation(info.Id);
                    var model = _core.GetModel(ws.ModelId.HasValue ? (int)ws.ModelId : 0);
                    ModelWs.Text = $"{model.ModelName} » {ws.WorkstationName}";
                }
                else
                {
                    ModelWs.Text = "";
                }
            }
        }

        private void Engineers_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = false;
            _mSel.Title = $"請選擇{PropertyText.Title.Engineer}";
            _mSel.DialogWidth = 600;
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EngineerMultiTabPageCache;
            _mSel.DefaultChecked = Engineers.Text
                .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                List<string> emps = new List<string>();
                foreach (var emp in _mSel.ResultList)
                    emps.Add(emp.Name);
                Engineers.Text = string.Join("; ", emps);
            }
        }

        private void Creator_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>() { (string)Creator.Tag };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    var emp = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(emp.Category2) ? "" : $"{emp.Category2} » ";
                    displayText += $"{emp.IdString} {emp.Name}";

                    Creator.Tag = emp.Name;
                    Creator.Text = string.Join(" » ", displayText);
                }
                else
                {
                    Creator.Tag = "";
                    Creator.Text = "";
                }
            }
        }

        //private void UpdateRepairDuration()
        //{
        //    bool hasStarted = cbRepairStarted.Checked && _tovm.RepairStarted.HasValue;
        //    bool hasCompleted = cbRepairCompleted.Checked && _tovm.RepairCompleted.HasValue;

        //    if (!hasCompleted)
        //        RepairCompleted.Text = "";

        //    if (!hasStarted)
        //        RepairStarted.Text = "";

        //    if (hasStarted)
        //    {
        //        _tovm.RepairDuration = hasCompleted
        //            ? (TimeSpan)(_tovm.RepairCompleted - _tovm.RepairStarted)
        //            : (TimeSpan)(DateTime.Now - _tovm.RepairStarted);
        //    }
        //    else
        //    {
        //        _tovm.RepairDuration = TimeSpan.Zero;
        //    }
        //    RepairDuration.Text = _tovm.RepairDurationString;
        //}

        //private void RepairStarted_ValueChanged(object sender, DateTime value)
        //{
        //    if (cbRepairStarted.Checked && _tovm != null)
        //    {
        //        if (DateTime.TryParse(RepairStarted.Text, out DateTime dt))
        //            _tovm.RepairStarted = dt;
        //    }
        //    UpdateRepairDuration();
        //}
    }
}
