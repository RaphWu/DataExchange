﻿using System;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;
using static Sunny.UI.UIMeter;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class ManitiFlowMain : UIPage
    {
        private readonly ILifetimeScope _scope;

        public ManitiFlowMain(ILifetimeScope lifetimeScope)
        {
            InitializeComponent();
            _scope = lifetimeScope;

            uiButton_Summary.Text = PageCode.MaintiFlowSummary.GetDescription();
            uiButton_Summary.Symbol = 559631;
            uiButton_Summary.FillColor = CommonStyles.BackColor;
            uiButton_Summary.FillHoverColor = CommonStyles.Hover;

            uiButton_CreateFlow.Text = PageCode.CreateFlow.GetDescription();
            uiButton_CreateFlow.Symbol = 559936;
            uiButton_CreateFlow.FillColor = CommonStyles.BackColor;
            uiButton_CreateFlow.FillHoverColor = CommonStyles.Hover;
        }

        private void uiButton_Summary_Click(object sender, EventArgs e)
        {
            WeakReferenceMessenger.Default.Send(new MaintiFlowPageChangedMessage(PageCode.MaintiFlowSummary));
        }

        private void uiButton_CreateFlow_Click(object sender, EventArgs e)
        {
            using (var scope = _scope.BeginLifetimeScope())
            {
                var createFlow = scope.Resolve<CreateFlow>();
                createFlow.Title = "新建工單";
                if (createFlow.ShowDialog() == DialogResult.OK)
                {
                    var to = scope.Resolve<MaintiFlowContext>().Set<TaskOrder>().ToList();
                    var tov = scope.Resolve<TaskOrderView>();

                    tov.Title = "工單已建立";
                    tov.NewWorkOrderNo = createFlow.NewWorkOrderNo;
                    tov.Initialize();
                    tov.ShowDialog();
                }
            }
        }
    }
}
