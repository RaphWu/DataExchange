﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class TaskOrderView
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.OrderNo = new Sunny.UI.UITextBox();
            this.uiLabel_OrderNo = new Sunny.UI.UILabel();
            this.uiLabel_WorkOrderNo = new Sunny.UI.UILabel();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.uiLabel_Creator = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UITextBox();
            this.uiLabel_CreationDate = new Sunny.UI.UILabel();
            this.CreationDate = new Sunny.UI.UITextBox();
            this.DeviceList = new Sunny.UI.UITextBox();
            this.uiLabel_DeviceList = new Sunny.UI.UILabel();
            this.Model = new Sunny.UI.UITextBox();
            this.uiLabel_Model = new Sunny.UI.UILabel();
            this.Workstation = new Sunny.UI.UITextBox();
            this.uiLabel_WorkStation = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UITextBox();
            this.uiLabel_OutageStarted = new Sunny.UI.UILabel();
            this.IssueDescription = new Sunny.UI.UITextBox();
            this.uiLabel_IssueDescription = new Sunny.UI.UILabel();
            this.uiButton_Close = new Sunny.UI.UISymbolButton();
            this.SuspendLayout();
            // 
            // OrderNo
            // 
            this.OrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OrderNo.Enabled = false;
            this.OrderNo.FillDisableColor = System.Drawing.Color.White;
            this.OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OrderNo.Location = new System.Drawing.Point(154, 58);
            this.OrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.OrderNo.ShowText = false;
            this.OrderNo.Size = new System.Drawing.Size(200, 29);
            this.OrderNo.TabIndex = 0;
            this.OrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OrderNo.Watermark = "";
            // 
            // uiLabel_OrderNo
            // 
            this.uiLabel_OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OrderNo.Location = new System.Drawing.Point(27, 58);
            this.uiLabel_OrderNo.Name = "uiLabel_OrderNo";
            this.uiLabel_OrderNo.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OrderNo.TabIndex = 1;
            this.uiLabel_OrderNo.Text = "OrderNo";
            this.uiLabel_OrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_WorkOrderNo
            // 
            this.uiLabel_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_WorkOrderNo.Location = new System.Drawing.Point(27, 97);
            this.uiLabel_WorkOrderNo.Name = "uiLabel_WorkOrderNo";
            this.uiLabel_WorkOrderNo.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_WorkOrderNo.TabIndex = 3;
            this.uiLabel_WorkOrderNo.Text = "WorkOrderNo";
            this.uiLabel_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.Enabled = false;
            this.WorkOrderNo.FillDisableColor = System.Drawing.Color.White;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.WorkOrderNo.Location = new System.Drawing.Point(154, 97);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(200, 29);
            this.WorkOrderNo.TabIndex = 2;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // uiLabel_Creator
            // 
            this.uiLabel_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Creator.Location = new System.Drawing.Point(27, 136);
            this.uiLabel_Creator.Name = "uiLabel_Creator";
            this.uiLabel_Creator.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Creator.TabIndex = 5;
            this.uiLabel_Creator.Text = "Creator";
            this.uiLabel_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Creator
            // 
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.Enabled = false;
            this.Creator.FillDisableColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Creator.Location = new System.Drawing.Point(154, 136);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(200, 29);
            this.Creator.TabIndex = 4;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // uiLabel_CreationDate
            // 
            this.uiLabel_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_CreationDate.Location = new System.Drawing.Point(27, 175);
            this.uiLabel_CreationDate.Name = "uiLabel_CreationDate";
            this.uiLabel_CreationDate.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_CreationDate.TabIndex = 6;
            this.uiLabel_CreationDate.Text = "CreationDate";
            this.uiLabel_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreationDate
            // 
            this.CreationDate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CreationDate.Enabled = false;
            this.CreationDate.FillDisableColor = System.Drawing.Color.White;
            this.CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CreationDate.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CreationDate.Location = new System.Drawing.Point(154, 175);
            this.CreationDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CreationDate.MinimumSize = new System.Drawing.Size(1, 16);
            this.CreationDate.Name = "CreationDate";
            this.CreationDate.Padding = new System.Windows.Forms.Padding(5);
            this.CreationDate.ShowText = false;
            this.CreationDate.Size = new System.Drawing.Size(200, 29);
            this.CreationDate.TabIndex = 5;
            this.CreationDate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreationDate.Watermark = "";
            // 
            // DeviceList
            // 
            this.DeviceList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DeviceList.Enabled = false;
            this.DeviceList.FillDisableColor = System.Drawing.Color.White;
            this.DeviceList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.DeviceList.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.DeviceList.Location = new System.Drawing.Point(154, 214);
            this.DeviceList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.DeviceList.MinimumSize = new System.Drawing.Size(1, 16);
            this.DeviceList.Name = "DeviceList";
            this.DeviceList.Padding = new System.Windows.Forms.Padding(5);
            this.DeviceList.ShowText = false;
            this.DeviceList.Size = new System.Drawing.Size(200, 29);
            this.DeviceList.TabIndex = 7;
            this.DeviceList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.DeviceList.Watermark = "";
            // 
            // uiLabel_DeviceList
            // 
            this.uiLabel_DeviceList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_DeviceList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_DeviceList.Location = new System.Drawing.Point(27, 214);
            this.uiLabel_DeviceList.Name = "uiLabel_DeviceList";
            this.uiLabel_DeviceList.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_DeviceList.TabIndex = 8;
            this.uiLabel_DeviceList.Text = "DeviceList";
            this.uiLabel_DeviceList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Model
            // 
            this.Model.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Model.Enabled = false;
            this.Model.FillDisableColor = System.Drawing.Color.White;
            this.Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Model.Location = new System.Drawing.Point(154, 253);
            this.Model.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Model.MinimumSize = new System.Drawing.Size(1, 16);
            this.Model.Name = "Model";
            this.Model.Padding = new System.Windows.Forms.Padding(5);
            this.Model.ShowText = false;
            this.Model.Size = new System.Drawing.Size(200, 29);
            this.Model.TabIndex = 9;
            this.Model.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Model.Watermark = "";
            // 
            // uiLabel_Model
            // 
            this.uiLabel_Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Model.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Model.Location = new System.Drawing.Point(27, 253);
            this.uiLabel_Model.Name = "uiLabel_Model";
            this.uiLabel_Model.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Model.TabIndex = 10;
            this.uiLabel_Model.Text = "Model";
            this.uiLabel_Model.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Workstation
            // 
            this.Workstation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Workstation.Enabled = false;
            this.Workstation.FillDisableColor = System.Drawing.Color.White;
            this.Workstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Workstation.Location = new System.Drawing.Point(154, 292);
            this.Workstation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Workstation.MinimumSize = new System.Drawing.Size(1, 16);
            this.Workstation.Name = "Workstation";
            this.Workstation.Padding = new System.Windows.Forms.Padding(5);
            this.Workstation.ShowText = false;
            this.Workstation.Size = new System.Drawing.Size(200, 29);
            this.Workstation.TabIndex = 11;
            this.Workstation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Workstation.Watermark = "";
            // 
            // uiLabel_WorkStation
            // 
            this.uiLabel_WorkStation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_WorkStation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_WorkStation.Location = new System.Drawing.Point(27, 292);
            this.uiLabel_WorkStation.Name = "uiLabel_WorkStation";
            this.uiLabel_WorkStation.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_WorkStation.TabIndex = 12;
            this.uiLabel_WorkStation.Text = "Workstation";
            this.uiLabel_WorkStation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageStarted.Enabled = false;
            this.OutageStarted.FillDisableColor = System.Drawing.Color.White;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageStarted.Location = new System.Drawing.Point(154, 331);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(5);
            this.OutageStarted.ShowText = false;
            this.OutageStarted.Size = new System.Drawing.Size(200, 29);
            this.OutageStarted.TabIndex = 13;
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageStarted.Watermark = "";
            // 
            // uiLabel_OutageStarted
            // 
            this.uiLabel_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageStarted.Location = new System.Drawing.Point(27, 331);
            this.uiLabel_OutageStarted.Name = "uiLabel_OutageStarted";
            this.uiLabel_OutageStarted.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OutageStarted.TabIndex = 14;
            this.uiLabel_OutageStarted.Text = "OutageStarted";
            this.uiLabel_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // IssueDescription
            // 
            this.IssueDescription.CanEmpty = true;
            this.IssueDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueDescription.Enabled = false;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(154, 370);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueDescription.Multiline = true;
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(5);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(250, 85);
            this.IssueDescription.TabIndex = 26;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.IssueDescription.Watermark = "";
            // 
            // uiLabel_IssueDescription
            // 
            this.uiLabel_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueDescription.Location = new System.Drawing.Point(29, 370);
            this.uiLabel_IssueDescription.Name = "uiLabel_IssueDescription";
            this.uiLabel_IssueDescription.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_IssueDescription.TabIndex = 27;
            this.uiLabel_IssueDescription.Text = "IssueDescription";
            this.uiLabel_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiButton_Close
            // 
            this.uiButton_Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Close.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_Close.Location = new System.Drawing.Point(154, 494);
            this.uiButton_Close.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Close.Name = "uiButton_Close";
            this.uiButton_Close.Radius = 10;
            this.uiButton_Close.Size = new System.Drawing.Size(110, 35);
            this.uiButton_Close.Symbol = 61453;
            this.uiButton_Close.TabIndex = 28;
            this.uiButton_Close.Text = "關閉";
            this.uiButton_Close.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Close.Click += new System.EventHandler(this.uiButton_Close_Click);
            // 
            // TaskOrderView
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(442, 564);
            this.Controls.Add(this.uiButton_Close);
            this.Controls.Add(this.IssueDescription);
            this.Controls.Add(this.uiLabel_IssueDescription);
            this.Controls.Add(this.OutageStarted);
            this.Controls.Add(this.uiLabel_OutageStarted);
            this.Controls.Add(this.Workstation);
            this.Controls.Add(this.uiLabel_WorkStation);
            this.Controls.Add(this.Model);
            this.Controls.Add(this.uiLabel_Model);
            this.Controls.Add(this.DeviceList);
            this.Controls.Add(this.uiLabel_DeviceList);
            this.Controls.Add(this.CreationDate);
            this.Controls.Add(this.uiLabel_CreationDate);
            this.Controls.Add(this.uiLabel_Creator);
            this.Controls.Add(this.Creator);
            this.Controls.Add(this.uiLabel_WorkOrderNo);
            this.Controls.Add(this.WorkOrderNo);
            this.Controls.Add(this.uiLabel_OrderNo);
            this.Controls.Add(this.OrderNo);
            this.Name = "TaskOrderView";
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 784, 674);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UITextBox OrderNo;
        private Sunny.UI.UILabel uiLabel_OrderNo;
        private Sunny.UI.UILabel uiLabel_WorkOrderNo;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UILabel uiLabel_Creator;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UILabel uiLabel_CreationDate;
        private Sunny.UI.UITextBox CreationDate;
        private Sunny.UI.UITextBox DeviceList;
        private Sunny.UI.UILabel uiLabel_DeviceList;
        private Sunny.UI.UITextBox Model;
        private Sunny.UI.UILabel uiLabel_Model;
        private Sunny.UI.UITextBox Workstation;
        private Sunny.UI.UILabel uiLabel_WorkStation;
        private Sunny.UI.UITextBox OutageStarted;
        private Sunny.UI.UILabel uiLabel_OutageStarted;
        private Sunny.UI.UITextBox IssueDescription;
        private Sunny.UI.UILabel uiLabel_IssueDescription;
        private Sunny.UI.UISymbolButton uiButton_Close;
    }
}
