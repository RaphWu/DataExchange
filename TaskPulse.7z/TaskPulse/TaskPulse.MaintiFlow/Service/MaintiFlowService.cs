﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Autofac;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    /// <summary>
    /// 維護工單服務。
    /// </summary>
    public class MaintiFlowService : IMaintiFlow, IDisposable
    {
        private readonly ILifetimeScope _scope;
        private bool _isInitialized = false;
        private Models.Status _defaultStatus;

        /// <inheritdoc/>
        public Models.Status DefaultStatus => _defaultStatus;

        public MaintiFlowService(ILifetimeScope lifetimeScope)
        {
            _scope = lifetimeScope;
        }

        /// <summary>
        /// 釋放註冊的事件。
        /// </summary>
        public void Dispose()
        {
            StrongReferenceMessenger.Default.Unregister<CoreDataChangedNotification>(this);
        }

        /// <inheritdoc/>
        public void Initialize()
        {
            if (_isInitialized)
                return;

            using (var scope = _scope.BeginLifetimeScope())
            {
                var context = scope.Resolve<MaintiFlowContext>();
                var statuses = context.Statuses;

                UpdateFromCoreData();
                _defaultStatus = statuses.First();
            }

            // 註冊核心共用資料更新訊息。
            StrongReferenceMessenger.Default.Register<CoreDataChangedNotification>(this, (r, m) =>
            {
                UpdateFromCoreData();
            });

            _isInitialized = true;
        }

        /// <summary>
        /// 從核心共用資料更新。
        /// </summary>
        public void UpdateFromCoreData()
        {
            using (var scope = _scope.BeginLifetimeScope())
            {
                var context = scope.Resolve<MaintiFlowContext>();
                var coreData = scope.Resolve<CoreData>();
                var flowData = scope.Resolve<MaintiFlowData>();

                var emp = context.Set<Models.Employee>();
                emp.RemoveRange(emp);
                foreach (var employee in coreData.Employees)
                    emp.Add(new Models.Employee()
                    {
                        EmployeeId = employee.EmployeeId,
                        Name = employee.Name,
                        IsEngineer = employee.IsEngineer,
                    });
                flowData.Employees = context.Set<Models.Employee>()
                    .OrderBy(m => m.EmployeeId)
                    .ToList();

                var dev = context.Set<Models.Device>();
                dev.RemoveRange(dev);
                foreach (var device in coreData.Devices)
                    dev.Add(new Models.Device()
                    {
                        DeviceId = device.DeviceId,
                        DeviceName = device.DeviceName.FullName,
                    });
                flowData.DeviceList = context.Set<Models.Device>()
                    .OrderBy(m => m.DeviceName)
                    .ToList()
                    .Select(m => new KeyValuePair<string, string>(m.DeviceId, m.DeviceName))
                    .ToList();

                var model = context.Set<Models.Model>();
                model.RemoveRange(model);
                foreach (var m in coreData.Models)
                    model.Add(new Models.Model()
                    {
                        ModelName = m.ModelName,
                    });
                flowData.ModelList = context.Set<Models.Model>()
                    .OrderBy(m => m.ModelName)
                    .Select(m => m.ModelName)
                    .ToList();

                context.SaveChanges();
            }
        }
    }
}
