﻿using Autofac;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using Calin.TaskPulse.MaintiFlow.Service;
using Calin.TaskPulse.MaintiFlow.Views;

namespace Calin.TaskPulse.MaintiFlow
{
    /// <summary>
    /// 維護工單模組。
    /// </summary>
    public class MaintiFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            SplashMessenger.Post("載入維護工單模組...");

            // dialog
            builder.RegisterType<FT_CreateFlow>().ExternallyOwned();
            builder.RegisterType<TaskOrderView>().ExternallyOwned();
            builder.RegisterType<FT_AcceptFlow>().ExternallyOwned();
            builder.RegisterType<FT_MaintiWork>().ExternallyOwned();
            builder.RegisterType<FT_FlowConfirmed>().ExternallyOwned();

            // views
            builder.RegisterType<MaintiFlowPage>().InstancePerLifetimeScope();
            builder.RegisterType<ManitiFlowMain>().InstancePerLifetimeScope();
            builder.RegisterType<MaintiFlowSummary>().InstancePerLifetimeScope();

            // service
            builder.RegisterType<MaintiFlowService>().As<IMaintiFlow>().SingleInstance();

            // public NewWorkOrderNos
            builder.RegisterType<MaintiFlowData>().AsSelf().SingleInstance();

            // DbContext
            //builder.RegisterType<MaintiFlowInitializer>().As<IStartable>().SingleInstance();
            //builder.RegisterType<MaintiFlowContext>().InstancePerDependency();

            builder.RegisterBuildCallback(c =>
            {
                var maintiFLow = c.Resolve<IMaintiFlow>();
                maintiFLow.Initialize();
            });
        }
    }
}
