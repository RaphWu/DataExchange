﻿namespace Calin.TaskPulse.MaintiFlow.Events
{
    /// <summary>
    /// 維護資料庫更新訊息。
    /// </summary>
    public class MaintiFlowDataChangedNotification
    {
        public static readonly MaintiFlowDataChangedNotification Instance = new MaintiFlowDataChangedNotification();
        private MaintiFlowDataChangedNotification() { }
    }
}
