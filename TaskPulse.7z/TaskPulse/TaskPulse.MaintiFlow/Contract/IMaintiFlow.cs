﻿namespace Calin.TaskPulse.MaintiFlow.Contract
{
    /// <summary>
    /// 維護工單服務介面。
    /// </summary>
    public interface IMaintiFlow
    {
        /// <summary>
        /// 預設設備狀態。
        /// </summary>
        Models.Status DefaultStatus { get; }

        /// <summary>
        /// 從核心資料更新。
        /// </summary>
        void UpdateFromCoreData();

        /// <summary>
        /// 初始化服務。
        /// </summary>
        void Initialize();
    }
}
