﻿namespace Calin.TaskPulse.MaintiFlow.Contract
{
    /// <summary>
    /// 維護工單服務介面。
    /// </summary>
    public interface IMaintiFlow
    {
        /// <summary>
        /// 初始化服務。
        /// </summary>
        void Initialize();
    }
}
