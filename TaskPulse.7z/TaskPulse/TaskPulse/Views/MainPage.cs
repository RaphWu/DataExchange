﻿using System.Windows.Forms;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Views
{
    public partial class MainPage : UserControl
    {
        public MainPage(LoginControl loginControl)
        {
            InitializeComponent();

            //loginControl.TopLevel = false;
            //loginControl.FormBorderStyle = FormBorderStyle.None;
            loginControl.Dock = DockStyle.None;
            loginControl.Anchor = AnchorStyles.None;
            TLP.Controls.Add(loginControl);
        }
    }
}
