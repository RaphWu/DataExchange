﻿using Sunny.UI;

namespace Calin.TaskPulse.Views
{
    public partial class MainPage : UIPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
