﻿using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Views;
using Sunny.UI;

namespace Calin.TaskPulse.Views
{
    public partial class LoginForm : UIForm
    {
        public LoginForm(LoginControl loginControl)
        {
            InitializeComponent();

            loginControl.Dock = DockStyle.None;
            TLP.Controls.Add(loginControl);
        }
    }
}
