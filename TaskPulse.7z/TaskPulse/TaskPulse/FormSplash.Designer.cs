﻿namespace Calin.TaskPulse
{
    partial class FormSplash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.HeadLabel = new System.Windows.Forms.Label();
            this.MessageList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // HeadLabel
            // 
            this.HeadLabel.AutoSize = true;
            this.HeadLabel.Font = new System.Drawing.Font("標楷體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.HeadLabel.Location = new System.Drawing.Point(80, 23);
            this.HeadLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.HeadLabel.Name = "HeadLabel";
            this.HeadLabel.Size = new System.Drawing.Size(199, 19);
            this.HeadLabel.TabIndex = 0;
            this.HeadLabel.Text = "TaskPulse 載入中...";
            // 
            // MessageList
            // 
            this.MessageList.FormattingEnabled = true;
            this.MessageList.ItemHeight = 19;
            this.MessageList.Location = new System.Drawing.Point(29, 47);
            this.MessageList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MessageList.Name = "MessageList";
            this.MessageList.Size = new System.Drawing.Size(301, 308);
            this.MessageList.TabIndex = 1;
            // 
            // FormSplash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 382);
            this.Controls.Add(this.MessageList);
            this.Controls.Add(this.HeadLabel);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormSplash";
            this.Text = "FormSplash";
            this.Load += new System.EventHandler(this.FormSplash_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HeadLabel;
        private System.Windows.Forms.ListBox MessageList;
    }
}