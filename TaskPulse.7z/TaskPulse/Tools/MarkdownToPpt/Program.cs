using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Presentation;
using A = DocumentFormat.OpenXml.Drawing;

namespace MarkdownToPpt
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputMd = args.Length > 0 ? args[0] : Path.Combine("TaskPulse", "Docs", "TaskPulse_Presentation.md");
            string outputPptx = args.Length > 1 ? args[1] : "TaskPulse_Presentation.pptx";

            if (!File.Exists(inputMd))
            {
                Console.WriteLine("�䤣���J�ɮ�: " + inputMd);
                return;
            }

            string md = File.ReadAllText(inputMd);
            var slides = ParseSlides(md);

            CreatePresentation(outputPptx, slides);
            Console.WriteLine("�w���� PPTX: " + Path.GetFullPath(outputPptx));
        }

        // Slide model
        class SlideData
        {
            public string Title { get; set; }
            public List<string> Bullets { get; set; } = new List<string>();
            public string Suggestion { get; set; }
        }

        // ²��ѪR markdown ��v���G�H --- ���ΡA# �����D�A- �� bullet�A��ĳ�Ϥ���
        static List<SlideData> ParseSlides(string md)
        {
            var slides = new List<SlideData>();
            var parts = md.Split(new[] { "\n---\n", "\r\n---\r\n", "\n---\r\n", "\r\n---\n" }, StringSplitOptions.None);

            foreach (var p in parts)
            {
                var lines = p.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Select(l => l.Trim()).ToList();
                if (lines.Count == 0) continue;

                var slide = new SlideData();
                foreach (var line in lines)
                {
                    if (line.StartsWith("# "))
                    {
                        if (string.IsNullOrEmpty(slide.Title))
                            slide.Title = line.Substring(2).Trim();
                        continue;
                    }
                    if (line.StartsWith("- "))
                    {
                        slide.Bullets.Add(line.Substring(2).Trim());
                        continue;
                    }
                    if (line.StartsWith("��ĳ�Ϥ�/�Ϫ�:") || line.StartsWith("��ĳ�Ϥ�/�Ϫ�:"))
                    {
                        slide.Suggestion = line.Substring(line.IndexOf(':') + 1).Trim();
                        continue;
                    }
                }

                // �Y�L���D�A��Ĥ@�ӫD bullet ��@�����D
                if (string.IsNullOrEmpty(slide.Title))
                {
                    var firstNonBullet = lines.FirstOrDefault(l => !l.StartsWith("- ") && !l.StartsWith("��ĳ�Ϥ�/�Ϫ�:"));
                    slide.Title = firstNonBullet ?? "���R�W��v��";
                }

                slides.Add(slide);
            }

            return slides;
        }

        // �إ� PPTX�]�ϥ� Open XML�^
        static void CreatePresentation(string file, List<SlideData> slides)
        {
            if (File.Exists(file)) File.Delete(file);

            using (var presentation = PresentationDocument.Create(file, PresentationDocumentType.Presentation))
            {
                var presentationPart = presentation.AddPresentationPart();
                presentationPart.Presentation = new Presentation();

                // SlideIdList
                presentationPart.Presentation.SlideIdList = new SlideIdList();

                // Add Slide Master
                var slideMasterPart = presentationPart.AddNewPart<SlideMasterPart>();
                GenerateSlideMasterPartContent(slideMasterPart);

                // Add SlideLayoutPart
                var layoutPart = slideMasterPart.AddNewPart<SlideLayoutPart>();
                GenerateSlideLayoutPartContent(layoutPart);

                // connect layout to master
                // �ץ��G�����w�� SlideMasterPart.SlideMaster �� SlideLayoutIdList�]�קK CS1061�^
                slideMasterPart.SlideMaster.SlideLayoutIdList = new SlideLayoutIdList(
                    new SlideLayoutId() { Id = (UInt32Value)256U, RelationshipId = slideMasterPart.GetIdOfPart(layoutPart) }
                );

                // Add slide parts
                uint id = 256;
                int slideIndex = 0;
                foreach (var s in slides)
                {
                    slideIndex++;
                    var slidePart = presentationPart.AddNewPart<SlidePart>();
                    GenerateSlidePartContent(slidePart, s);

                    // use layout reference
                    slidePart.AddPart(layoutPart);

                    var slideId = new SlideId() { Id = (UInt32Value)id++, RelationshipId = presentationPart.GetIdOfPart(slidePart) };
                    presentationPart.Presentation.SlideIdList.Append(slideId);
                }

                // Create SlideMasterIdList
                presentationPart.Presentation.SlideMasterIdList = new SlideMasterIdList(new SlideMasterId() { Id = (UInt32Value)2147483648U, RelationshipId = presentationPart.GetIdOfPart(slideMasterPart) });

                presentationPart.Presentation.Save();
            }
        }

        // ����²�檺 SlideMaster ���e�]���n�����^
        static void GenerateSlideMasterPartContent(SlideMasterPart slideMasterPart)
        {
            slideMasterPart.SlideMaster = new SlideMaster(
                new CommonSlideData(new ShapeTree(
                    new NonVisualGroupShapeProperties(new NonVisualDrawingProperties() { Id = 1, Name = "" }, new NonVisualGroupShapeDrawingProperties()),
                    new GroupShapeProperties(new A.TransformGroup())
                )),
                new SlideLayoutIdList(),
                new TextStyles()
            );
        }

        // ����²�檺 SlideLayout ���e
        static void GenerateSlideLayoutPartContent(SlideLayoutPart layoutPart)
        {
            layoutPart.SlideLayout = new SlideLayout(
                new CommonSlideData(new ShapeTree(
                    new NonVisualGroupShapeProperties(new NonVisualDrawingProperties() { Id = 1, Name = "" }, new NonVisualGroupShapeDrawingProperties()),
                    new GroupShapeProperties(new A.TransformGroup())
                ))
            );
        }

        // ���ͤ@�i��v���G���D + ���� bullets�F��ĳ��b Notes�]�Ƶ��^
        static void GenerateSlidePartContent(SlidePart slidePart, SlideData data)
        {
            var slide = new Slide(new CommonSlideData(new ShapeTree()));

            var shapeTree = slide.CommonSlideData.ShapeTree;
            // ���n�D��ı�ݩ�
            shapeTree.Append(new NonVisualGroupShapeProperties(new NonVisualDrawingProperties() { Id = 1, Name = "" }, new NonVisualGroupShapeDrawingProperties()));
            shapeTree.Append(new GroupShapeProperties(new A.TransformGroup()));

            // Title shape
            uint id = 2;
            var titleShape = CreateTextShape(id++,
                offsetX: 914400, offsetY: 457200, cx: 8229600, cy: 914400,
                text: data.Title,
                fontSize: 3200);
            shapeTree.Append(titleShape);

            // Body shape for bullets
            var bodyShape = CreateTextShape(id++,
                offsetX: 914400, offsetY: 1371600, cx: 8229600, cy: 5334000,
                text: string.Join("\n", data.Bullets),
                fontSize: 2400,
                isBulleted: true);
            shapeTree.Append(bodyShape);

            slidePart.Slide = slide;

            // If suggestion exists, put into NotesPart
            if (!string.IsNullOrEmpty(data.Suggestion))
            {
                var notesPart = slidePart.AddNewPart<NotesSlidePart>();
                var notes = new NotesSlide(new CommonSlideData(new ShapeTree()));
                var notesShapeTree = notes.CommonSlideData.ShapeTree;
                notesShapeTree.Append(new NonVisualGroupShapeProperties(new NonVisualDrawingProperties() { Id = 1U, Name = "" }, new NonVisualGroupShapeDrawingProperties()));
                notesShapeTree.Append(new GroupShapeProperties(new A.TransformGroup()));

                var notesBody = CreateTextShape(2,
                    offsetX: 0, offsetY: 0, cx: 9144000, cy: 914400,
                    text: "��ĳ�Ϥ�/�Ϫ�: " + data.Suggestion,
                    fontSize: 2000,
                    isBulleted: false);
                notesShapeTree.Append(notesBody);

                notesPart.NotesSlide = notes;
            }
        }

        // �إߤ�r��� shape helper
        static Shape CreateTextShape(uint id, long offsetX, long offsetY, long cx, long cy, string text, int fontSize = 2400, bool isBulleted = false)
        {
            var shape = new Shape();

            shape.Append(new NonVisualShapeProperties(
                new NonVisualDrawingProperties() { Id = id, Name = "TextBox " + id },
                new NonVisualShapeDrawingProperties(new A.ShapeLocks() { NoGrouping = true }),
                new ApplicationNonVisualDrawingProperties(new PlaceholderShape())
            ));

            shape.Append(new ShapeProperties(new A.Transform2D(new A.Offset() { X = offsetX, Y = offsetY }, new A.Extents() { Cx = cx, Cy = cy })));

            var body = new TextBody(
                new A.BodyProperties(),
                new A.ListStyle()
            );

            if (string.IsNullOrEmpty(text))
            {
                body.Append(new A.Paragraph(new A.Run(new A.Text(""))));
            }
            else
            {
                var lines = text.Split(new[] { '\n' }, StringSplitOptions.None);
                foreach (var line in lines)
                {
                    var p = new A.Paragraph();
                    if (isBulleted)
                    {
                        p.ParagraphProperties = new A.ParagraphProperties(new A.BulletFont() { Typeface = "Arial" });
                    }
                    p.Append(new A.Run(new A.Text(line)));
                    body.Append(p);
                }
            }

            shape.Append(body);
            return shape;
        }
    }
}