﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.Helper;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    /// <summary>
    /// 維護工單。
    /// </summary>
    public class TaskOrder : ObservableObject
    {
        /// <summary>
        /// 維護工單序號。
        /// </summary>
        [Description("序號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /********************
         * 工單資料
         ********************/
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        [Description("工單編號")]
        [Required]
        [Index(IsUnique = true)]
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 維護狀態。
        /// </summary>
        [Description("狀態")]
        [Required]
        public FlowStatus Status { get; set; }
        [NotMapped]
        public int StatusId
        {
            get => (int)Status;
            set => Status = (FlowStatus)value;
        }
        [NotMapped]
        public string StatusString
        {
            get { return Status.GetDescription(); }
            set
            {
                var s = value.GetEnumByDescription<FlowStatus>();
                Status = s != default ? FlowStatus.Unknow : s;
            }
        }

        /// <summary>
        /// 機台編號。
        /// </summary>
        [Description("機台")]
        public virtual Machine Machine { get; set; } // CoreContext
        [Index]
        public int? MachineId { get; set; } // FK
        [NotMapped]
        public string MachineCode { get => Machine?.MachineCode ?? string.Empty; }
        [NotMapped]
        public string MachineName { get => Machine?.MachineName?.ModelName ?? string.Empty; }
        [NotMapped]
        public string FullMachineName =>
            string.Join(" » ", new[] { MachineCode, MachineName }.Where(s => !string.IsNullOrEmpty(s)));
        /// <summary>
        /// 從資料庫傳回機台物件。
        /// </summary>
        /// <param name="machineString">機台名稱字串，分隔符號可用 '»' 或 ',' 或 ';'，機台編號須放在最後。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>機台物件。</returns>
        public Machine GetMachine(string machineString, DbContext coreContext)
        {
            if (string.IsNullOrWhiteSpace(machineString))
                return null;

            var mCode = machineString
                .Split(new[] { '»', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())
                .Last(n => !string.IsNullOrEmpty(n));
            return coreContext.Set<Machine>().FirstOrDefault(w => w.MachineCode == mCode);
        }
        /// <summary>
        /// 從資料庫傳回機台編號對應機台的 Id。
        /// </summary>
        /// <param name="machineString">機台名稱字串，分隔符號可用 '»' 或 ',' 或 ';'，機台編號須放在最後。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>機台 Id。</returns>
        public int? GetMachineId(string machineString, DbContext coreContext)
        {
            var ma = GetMachine(machineString, coreContext);
            return ma?.Id ?? null;
        }

        /// <summary>
        /// 工站。
        /// </summary>
        [Description("工站")]
        public virtual Workstation Workstation { get; set; } // CoreContext
        [Index]
        public int? WorkstationId { get; set; } // FK
        [NotMapped]
        public string ModelName { get => Workstation?.Model?.ModelName ?? string.Empty; }
        [NotMapped]
        public string WorkstationName => Workstation?.WorkstationName ?? string.Empty;
        [NotMapped]
        [Description("機種 » 工站")]
        public string ModelWorkstationName
            => string.IsNullOrEmpty(WorkstationName) || string.IsNullOrEmpty(ModelName)
                ? string.Empty
                : string.Join(" » ", new string[] { ModelName, WorkstationName });
        /// <summary>
        /// 從資料庫傳回工站名稱對應的 Id。
        /// </summary>
        /// <param name="workstationNameString">工站名稱字串，分隔符號可用 '»' 或 ',' 或 ';'，工站名稱須放在最後。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>工站 Id。</returns>
        public int? GetWorkstationId(string workstationNameString, DbContext coreContext)
        {
            if (string.IsNullOrWhiteSpace(workstationNameString))
                return null;

            var wsName = workstationNameString
                .Split(new[] { '»', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())
                .Last(n => !string.IsNullOrEmpty(n));
            var ws = coreContext.Set<Workstation>().FirstOrDefault(w => w.WorkstationName == wsName);
            return ws?.Id ?? null;
        }

        /// <summary>
        /// 建檔人員。
        /// </summary>
        [Description("建檔人員")]
        public virtual Employee Creator { get; set; } // CoreContext
        public int CreatorId { get; set; } // FK
        [NotMapped]
        public string CreatorName => Creator != null ? Creator.EmployeeName : string.Empty;
        [NotMapped]
        public string CreatorNameWithId => Creator != null
            ? $"{Creator.EmployeeId} » {Creator.EmployeeName}"
            : string.Empty;
        [NotMapped]
        public string CreatorNameWithDepartment => Creator != null
            ? string.Join(" » ", new[] { Creator.DepartmentName, Creator.EmployeeName }
                .Where(s => !string.IsNullOrEmpty(s)))
            : string.Empty;
        [NotMapped]
        public string FullCreatorName => Creator != null
            ? string.Join(", ", new[] { Creator.EmployeeId, Creator.DepartmentName, Creator.EmployeeName }
                .Where(s => !string.IsNullOrEmpty(s)))
            : string.Empty;
        /// <summary>
        /// 從資料庫傳回建檔人員姓名對應的 Id。
        /// </summary>
        /// <param name="nameString">建檔人員姓名字串，可包含工號、部門，分隔符號可用 空格 或 ',' 或 ';'，姓名須放在最後。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>建檔人員 Id。</returns>
        /// <exception cref="ArgumentException">建檔人員在資料庫中必須已存在。</exception>
        public int GetCreatorId(string nameString, DbContext coreContext)
        {
            if (string.IsNullOrWhiteSpace(nameString))
                throw new ArgumentException("TaskOrder.GetCreatorId() 發生錯誤！");

            var name = nameString
                .Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())
                .Last(n => !string.IsNullOrEmpty(n));
            return coreContext.Set<Employee>()
                .FirstOrDefault(e => e.EmployeeName == name).Id;
        }

        /// <summary>
        /// 建檔日期。
        /// </summary> 
        [Description("建檔日期")]
        [Required]
        public DateTime CreationDateTime { get; set; }
        [NotMapped]
        public string CreationDateTimeString => CreationDateTime.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
        [NotMapped]
        public string CreationDateString => CreationDateTime.ToString("yyyy/MM/dd") ?? string.Empty;

        /********************
         * 維護部門
         ********************/
        /// <summary>
        /// 維護單位。
        /// </summary>
        [Description("維護單位")]
        public virtual MaintenanceUnit MaintenanceUnit { get; set; }
        public int? MaintenanceUnitId { get; set; } // FK
        [NotMapped]
        public string MaintenanceUnitString => MaintenanceUnit?.UnitName ?? string.Empty;
        /// <summary>
        /// 從資料庫取得維護單位名稱對應的 Id。
        /// </summary>
        /// <param name="unitName">維護單位名稱</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>維護單位 Id。</returns>
        public int? GetMaintenanceUnitId(string unitName, DbContext coreContext)
        {
            if (string.IsNullOrWhiteSpace(unitName))
                return null;

            var mu = coreContext.Set<MaintenanceUnit>()
                .FirstOrDefault(e => e.UnitName == unitName);
            return mu?.Id ?? null;
        }

        /// <summary>
        /// 維護工程師。
        /// </summary>
        [Description("工程師")]
        public virtual ICollection<Employee> Engineers { get; set; } // 多對多
        [NotMapped]
        public Dictionary<int, string> EngineerList => Engineers.ToDictionary(emp => emp.Id, emp => emp.EmployeeName);
        [NotMapped]
        public string EngineerString => Engineers != null
                ? string.Join("; ", Engineers.Select(emp => emp.EmployeeName))
                : string.Empty;
        [NotMapped]
        public string EngineerMultiString => Engineers != null
                ? string.Join(Environment.NewLine, Engineers.Select(emp => emp.EmployeeName))
                : string.Empty;
        /// <summary>
        /// 將維護工程師資料庫 Id 拆解後，從資料庫返回 Engineers List。
        /// </summary>
        /// <param name="engineerIdList">維護工程師資料庫 Id。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>Engineers List。</returns>
        public List<Employee> GetEngineers(List<int> engineerIdList, DbContext coreContext)
        {
            if (engineerIdList.Count == 0)
                return new List<Employee>();

            return coreContext.Set<Employee>()
                .Where(e => e.IsEngineer && engineerIdList.Contains(e.Id))
                .ToList();
        }
        /// <summary>
        /// 將維護工程師姓名字串拆解後，從資料庫返回 Engineers。
        /// </summary>
        /// <param name="engineerNameList">維護工程師字串，分隔符號可用 ',' 或 ';' 或 '\n'。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>Engineers 的資料庫格式資料。</returns>
        public List<Employee> GetEngineers(string engineerNameList, DbContext coreContext)
        {
            if (string.IsNullOrWhiteSpace(engineerNameList))
                return new List<Employee>();

            var emps = engineerNameList
                .Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())
                .Where(n => !string.IsNullOrEmpty(n))
                .ToList();
            return coreContext.Set<Employee>()
                .Where(e => e.IsEngineer && emps.Contains(e.EmployeeName))
                .ToList();
        }

        /// <summary>
        /// 接單時間。
        /// </summary>
        [Description("接單時間")]
        [Required]
        public DateTime AcceptedTime { get; set; }
        [NotMapped]
        public string AcceptedTimeString
        {
            get => AcceptedTime.ToString("yyyy/MM/dd HH:mm");
            set
            {
                if (DateTime.TryParse(value, out DateTime dt))
                    AcceptedTime = dt;
            }
        }

        /********************
         * 維護內容
         ********************/
        /// <summary>
        /// 維護類型。
        /// </summary>
        [Description("維護類型")]
        public virtual IssueCategory IssueCategory { get; set; }
        public int? IssueCategoryId { get; set; } // FK
        [NotMapped]
        public string IssueCategoryString { get => IssueCategory?.CategoryName ?? string.Empty; }
        /// <summary>
        /// 從資料庫傳回維護類型名稱對應的 Id。
        /// </summary>
        /// <param name="categoryName">維護類型名稱。</param>
        /// <param name="maintiFlowContext">MaintiFlowContext。</param>
        /// <returns>維護類型名稱對應的 Id。</returns>
        public int? GetIssueCategoryId(string categoryName, DbContext maintiFlowContext)
        {
            if (string.IsNullOrWhiteSpace(categoryName))
                return null;

            var ic = maintiFlowContext.Set<IssueCategory>()
                .FirstOrDefault(i => i.CategoryName == categoryName);
            return ic?.Id ?? null;
        }

        /// <summary>
        /// 問題描述。
        /// </summary>
        [Description("問題描述")]
        public string IssueDescription { get; set; }

        /// <summary>
        /// 維護內容。
        /// </summary>
        [Description("維護內容")]
        public string Details { get; set; }

        /// <summary>
        /// 維護開始時間。
        /// </summary>
        [Description("開始時間")]
        public DateTime? RepairStarted
        {
            get => _repairStarted;
            set
            {
                if (_repairStarted != value)
                {
                    _repairStarted = value;
                    RepairDurationTick = _repairCompleted.HasValue && _repairStarted.HasValue
                        ? ((TimeSpan)(_repairCompleted - _repairStarted)).Ticks
                        : 0;
                }
            }
        }
        private DateTime? _repairStarted;
        [NotMapped]
        public string RepairStartedString
        {
            get => RepairStarted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set
            {
                if (DateTime.TryParse(value, out var dt))
                    RepairStarted = (DateTime?)dt;
            }
        }

        /// <summary>
        /// 維修完成時間。
        /// </summary>
        [Description("完成時間")]
        public DateTime? RepairCompleted
        {
            get => _repairCompleted;
            set
            {
                if (_repairCompleted != value)
                {
                    _repairCompleted = value;
                    RepairDurationTick = _repairCompleted.HasValue && _repairStarted.HasValue
                        ? ((TimeSpan)(_repairCompleted - _repairStarted)).Ticks
                        : 0;
                }
            }
        }
        private DateTime? _repairCompleted;
        [NotMapped]
        public string RepairCompletedString
        {
            get => RepairCompleted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set
            {
                if (DateTime.TryParse(value, out var dt))
                    RepairCompleted = (DateTime?)dt;
            }
        }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [Description("維修工時")]
        public long RepairDurationTick { get; set; }
        [Description("維修工時")]
        [NotMapped]
        public TimeSpan RepairDuration
        {
            get => TimeSpan.FromTicks(RepairDurationTick);
            set => RepairDurationTick = value.Ticks;
        }
        [Description("維修工時")]
        [NotMapped]
        public string RepairDurationString
        {
            get
            {
                var ts = RepairDuration;
                string days = ts.Days > 0 ? $"{ts.Days}天 " : "";
                return $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    RepairDurationTick = 0;
                    return;
                }

                var input = value.Trim();

                // 支援範例格式:
                // "1天 02:30", "02:30", "1天 02:30:15", "02:30:15"
                var match = System.Text.RegularExpressions.Regex.Match(input, @"^(?:(\d+)\s*天\s*)?(\d{1,2}):(\d{2})(?::(\d{2}))?$");
                if (match.Success)
                {
                    int days = match.Groups[1].Success ? int.Parse(match.Groups[1].Value) : 0;
                    int hours = int.Parse(match.Groups[2].Value);
                    int minutes = int.Parse(match.Groups[3].Value);
                    int seconds = match.Groups[4].Success ? int.Parse(match.Groups[4].Value) : 0;

                    var ts = new TimeSpan(days, hours, minutes, seconds);
                    RepairDurationTick = ts.Ticks;
                    return;
                }

                // fallback: 嘗試 TimeSpan 解析（支援 yyyy-mm-dd hh:mm:ss 等 TimeSpan 可接受格式）
                if (TimeSpan.TryParse(input, out var parsed))
                {
                    RepairDurationTick = parsed.Ticks;
                    return;
                }

                // 解析失敗 -> 設為 0
                RepairDurationTick = 0;
            }
        }

        /// <summary>
        /// 維護工單內容填寫完成時間。
        /// </summary>
        [Description("填寫時間")]
        public DateTime? FillingTime { get; set; }
        [Description("填寫時間")]
        [NotMapped]
        public string FillingTimeString
        {
            get => FillingTime?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set => FillingTime = DateTime.TryParse(value, out var dt) ? (DateTime?)dt : null;
        }

        /********************
         * 維護申請資訊
         ********************/
        /// <summary>
        /// 需求單位名稱。
        /// </summary>
        [Description("需求單位")]
        public virtual Department RequestingUnit { get; set; }
        public int? RequestingUnitId { get; set; } // FK
        [NotMapped]
        public string RequestingUnitString { get => RequestingUnit?.DepartmentName ?? string.Empty; }
        /// <summary>
        /// 從資料庫傳回需求單位對應的 Id。
        /// </summary>
        /// <param name="unitName">需求單位名稱。</param>
        /// <param name="maintiFlowContext">MaintiFlowContext。</param>
        /// <returns>需求單位對應的 Id。</returns>
        public int? GetRequestingUnitId(string unitName, DbContext maintiFlowContext)
        {
            if (string.IsNullOrWhiteSpace(unitName))
                return null;

            var ru = maintiFlowContext.Set<Department>()
                .FirstOrDefault(i => i.DepartmentName == unitName);
            return ru?.Id ?? null;
        }

        /// <summary>
        /// 回覆人員。
        /// </summary>
        [Description("回覆人員")]
        public virtual Employee FeedbackEmployee { get; set; } // CoreContext
        public int? FeedbackEmployeeId { get; set; } // FK
        [NotMapped]
        public string FeedbackEmployeeString => FeedbackEmployee?.EmployeeName ?? string.Empty;
        [NotMapped]
        public string FeedbackEmployeeFullString => FeedbackEmployee != null
            ? (FeedbackEmployee.Department != null ? $"{FeedbackEmployee.Department.DepartmentName}, " : string.Empty) + FeedbackEmployee.EmployeeName
            : string.Empty;
        /// <summary>
        /// 從資料庫傳回回覆人員對應的 Id。
        /// </summary>
        /// <param name="name">回覆人員姓名。</param>
        /// <param name="coreContext">CoreContext。</param>
        /// <returns>回覆人員對應的 Id。</returns>
        public int? GetFeedbackEmployeeId(string name, DbContext coreContext)
        {
            if (string.IsNullOrWhiteSpace(name))
                return null;

            var ru = coreContext.Set<Employee>()
                .FirstOrDefault(i => i.EmployeeName == name);
            return ru?.Id ?? null;
        }

        /// <summary>
        /// 需求單位回覆內容。
        /// </summary>
        [Description("回覆內容")]
        public string Feedback { get; set; }

        /// <summary>
        /// 停動開始。
        /// </summary>
        [Description("停動開始")]
        public DateTime? OutageStarted
        {
            get => _outageStarted;
            set
            {
                if (_outageStarted != value)
                {
                    _outageStarted = value;
                    OutageDurationTick = _outageEnded.HasValue && _outageStarted.HasValue
                        ? ((TimeSpan)(_outageEnded - _outageStarted)).Ticks
                        : 0;
                }
            }
        }
        private DateTime? _outageStarted;
        [NotMapped]
        public string OutageStartedString
        {
            get => OutageStarted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set
            {
                if (DateTime.TryParse(value, out var dt))
                    OutageStarted = (DateTime?)dt;
            }
        }

        /// <summary>
        /// 停動結束。
        /// </summary>
        [Description("停動結束")]
        public DateTime? OutageEnded
        {
            get => _outageEnded;
            set
            {
                if (_outageEnded != value)
                {
                    _outageEnded = value;
                    OutageDurationTick = _outageEnded.HasValue && _outageStarted.HasValue
                        ? ((TimeSpan)(_outageEnded - _outageStarted)).Ticks
                        : 0;
                }
            }
        }
        private DateTime? _outageEnded;
        [NotMapped]
        public string OutageEndedString
        {
            get => OutageEnded?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty;
            set
            {
                if (DateTime.TryParse(value, out var dt))
                    OutageEnded = (DateTime?)dt;
            }
        }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [Description("停動工時")]
        public long OutageDurationTick { get; set; }
        [Description("停動工時")]
        [NotMapped]
        public TimeSpan OutageDuration
        {
            get => TimeSpan.FromTicks(OutageDurationTick);
            set => OutageDurationTick = value.Ticks;
        }
        [Description("停動工時")]
        [NotMapped]
        public string OutageDurationString
        {
            get
            {
                var ts = OutageDuration;
                string days = ts.Days > 0 ? $"{ts.Days}天 " : "";
                return $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    OutageDurationTick = 0;
                    return;
                }

                var input = value.Trim();

                // 支援範例格式:
                // "1天 02:30", "02:30", "1天 02:30:15", "02:30:15"
                var match = System.Text.RegularExpressions.Regex.Match(input, @"^(?:(\d+)\s*天\s*)?(\d{1,2}):(\d{2})(?::(\d{2}))?$");
                if (match.Success)
                {
                    int days = match.Groups[1].Success ? int.Parse(match.Groups[1].Value) : 0;
                    int hours = int.Parse(match.Groups[2].Value);
                    int minutes = int.Parse(match.Groups[3].Value);
                    int seconds = match.Groups[4].Success ? int.Parse(match.Groups[4].Value) : 0;

                    var ts = new TimeSpan(days, hours, minutes, seconds);
                    OutageDurationTick = ts.Ticks;
                    return;
                }

                // fallback: 嘗試 TimeSpan 解析（支援 yyyy-mm-dd hh:mm:ss 等 TimeSpan 可接受格式）
                if (TimeSpan.TryParse(input, out var parsed))
                {
                    OutageDurationTick = parsed.Ticks;
                    return;
                }

                // 解析失敗 -> 設為 0
                OutageDurationTick = 0;
            }
        }

        /********************
         * 其他
         ********************/
        /// <summary>
        /// 責任歸屬。
        /// </summary>
        [Description("責任歸屬")]
        public string Responsible { get; set; }
    }
}
