﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    /// <summary>
    /// 維護工單。
    /// </summary>
    public class TaskOrder
    {
        /********************
         * 工單資料
         ********************/
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        [Description("工單編號")]
        [Key]
        [Required]
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 維護狀態。
        /// </summary>
        [Description("狀態")]
        [Required]
        public Status Status { get; set; }

        /// <summary>
        /// 機台編號。
        /// </summary>
        [Description("機台")]
        public int MachineId { get; set; } // FK
        public virtual Machine Machine { get; set; } // CoreContext

        /// <summary>
        /// 工站。
        /// </summary>
        [Description("工站")]
        public int WorkstationId { get; set; } // FK
        public virtual Workstation Workstation { get; set; } // CoreContext

        /// <summary>
        /// 建檔人員。
        /// </summary>
        [Description("建檔人員")]
        public int CreatorId { get; set; } // FK
        public virtual Employee Creator { get; set; } // CoreContext
        [NotMapped]
        public string CreatorFullName => Creator != null
            ? $"{Creator.EmployeeId}, {Creator.Department}, {Creator.Name}"
            : string.Empty;

        /// <summary>
        /// 建檔日期。
        /// </summary> 
        [Description("建檔日期")]
        [Required]
        public DateTime CreationDate { get; set; }
        [NotMapped]
        public string CreationDateString => CreationDate.ToString("yyyy/MM/dd") ?? string.Empty;

        /********************
         * 維護部門
         ********************/
        /// <summary>
        /// 維護單位。
        /// </summary>
        [Description("維護單位")]
        public int? MaintenanceUnitId { get; set; } // FK
        public virtual MaintenanceUnit MaintenanceUnit { get; set; }
        [NotMapped]
        public string UnitString => MaintenanceUnit?.Name ?? string.Empty;

        /// <summary>
        /// 維護工程師。
        /// </summary>
        [Description("工程師")]
        public List<int> EmployeeIds { get; set; } // FK
        public virtual ICollection<Employee> Engineers { get; set; } // 多對多
        [NotMapped]
        public string EngineerString
        {
            get
            {
                if (Engineers != null)
                {
                    string ret = "";
                    int cnt = 0;
                    foreach (var emp in Engineers)
                    {
                        if (cnt++ > 0)
                            ret += "; ";
                        ret = emp.Name;
                    }
                    return ret;
                }
                else
                    return string.Empty;
            }
        }

        /// <summary>
        /// 接單時間。
        /// </summary>
        [Description("接單時間")]
        [Required]
        public DateTime AcceptedTime { get; set; }
        [NotMapped]
        public string AcceptedTimeString { get => AcceptedTime.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /********************
         * 維護申請資訊
         ********************/
        /// <summary>
        /// 需求單位名稱。
        /// </summary>
        [Description("需求單位")]
        public int RequestingUnitId { get; set; } // FK
        public virtual RequestingUnit RequestingUnit { get; set; }
        [NotMapped]
        public string RequestingUnitString { get => RequestingUnit?.UnitName ?? string.Empty; }

        /// <summary>
        /// 回覆人員工號。
        /// </summary>
        [Description("回覆人員")]
        public int? RequestingEmployeeId { get; set; } // FK
        public virtual Employee RequestingEmployee { get; set; } // CoreContext
        [NotMapped]
        public string RequestingEmployeeString
        {
            get
            {
                if (RequestingEmployee == null)
                    return string.Empty;
                else
                {
                    string ret = "";
                    if (RequestingEmployee.Title != null)
                        ret = $"{RequestingEmployee.Title}, ";
                    return ret + RequestingEmployee.Name;
                }
            }
        }

        /// <summary>
        /// 需求單位回覆內容。
        /// </summary>
        [Description("回覆內容")]
        public string Response { get; set; }
        //public virtual ResponseList Response { get; set; }

        /// <summary>
        /// 停動開始。
        /// </summary>
        [Description("停動開始")]
        public DateTime? OutageStarted { get; set; }
        [NotMapped]
        public string OutageStartedString { get => OutageStarted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 停動結束。
        /// </summary>
        [Description("停動結束")]
        public DateTime? OutageEnded { get; set; }
        [NotMapped]
        public string OutageEndedString { get => OutageEnded?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 停動工時 Tick。
        /// </summary>
        [Description("停動工時")]
        public long OutageDurationTick { get; set; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [Description("停動工時")]
        [NotMapped]
        public TimeSpan OutageDuration
        {
            get => TimeSpan.FromTicks(OutageDurationTick);
            set => OutageDurationTick = value.Ticks;
        }

        /********************
         * 維護內容
         ********************/
        /// <summary>
        /// 維護類型。
        /// </summary>
        [Description("維護類型")]
        public int? IssueCategoryId { get; set; } // FK
        public virtual IssueCategory IssueCategory { get; set; }
        [NotMapped]
        public string IssueCategoryString { get => IssueCategory?.CategoryName ?? string.Empty; }

        /// <summary>
        /// 問題描述。
        /// </summary>
        [Description("問題描述")]
        public string IssueDescription { get; set; }

        /// <summary>
        /// 維護內容。
        /// </summary>
        [Description("維護內容")]
        public string Details { get; set; }

        /// <summary>
        /// 維護開始時間。
        /// </summary>
        [Description("開始時間")]
        public DateTime? RepairStarted { get; set; }
        [NotMapped]
        public string RepairStartedString { get => RepairStarted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 維修完成時間。
        /// </summary>
        [Description("完成時間")]
        public DateTime? RepairCompleted { get; set; }
        [NotMapped]
        public string RepairCompletedString { get => RepairCompleted?.ToString("yyyy/MM/dd HH:mm") ?? string.Empty; }

        /// <summary>
        /// 維修工時 Tick。
        /// </summary>
        [Description("維修工時")]
        public long RepairDurationTick { get; set; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [Description("維修工時")]
        [NotMapped]
        public TimeSpan RepairDuration
        {
            get => TimeSpan.FromTicks(RepairDurationTick);
            set => RepairDurationTick = value.Ticks;
        }

        /********************
         * 其他
         ********************/
        /// <summary>
        /// 責任歸屬。
        /// </summary>
        [Description("責任歸屬")]
        public string Responsible { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        [Description("編號")]
        public int OrderNo { get; set; }
    }
}
