﻿using Autofac;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace TaskPulse.Entity
{
    public class EntityModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<CoreFieldName>().SingleInstance();
            builder.RegisterType<MaintiFlowFieldName>().AsSelf().SingleInstance();
        }
    }
}
