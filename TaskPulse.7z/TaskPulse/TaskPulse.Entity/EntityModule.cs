﻿namespace TaskPulse.Entity
{
    public class EntityModule
    {
    }
}
