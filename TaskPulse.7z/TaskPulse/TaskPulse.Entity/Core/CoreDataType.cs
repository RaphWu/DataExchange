﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Entity.Core
{
    public enum CoreDataType
    {
        AllCoreData,
        Employee,
        Machine,
        Model,
        Workstation,
    }
}
