﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Entity.Core
{
    public class CoreFieldName
    {
        public string MachineId { get; set; }
        public string MachineCategory { get; set; }
        public string MachineType { get; set; }
        public string MachineName { get; set; }
        public string Condition { get; set; }
        public string Brand { get; set; }
        public string Location { get; set; }
        public string Assets { get; set; }
        public string SerialNumber { get; set; }
        public string Barcode { get; set; }
        public string Connected { get; set; }
        public string Disposal { get; set; }
        public string Remark { get; set; }
        public string Worktations { get; set; }
    }
}
