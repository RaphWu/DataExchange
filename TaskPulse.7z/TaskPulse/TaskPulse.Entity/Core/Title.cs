﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 職稱。
    /// </summary>
    public class Title
    {
        /// <summary>
        /// 職稱代號。
        /// </summary>
        [Description("職稱代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 職稱。
        /// </summary>
        [Description("職稱")]
        [MaxLength(12)]
        public string TitleName { get; set; }

        /// <summary>
        /// 排序用。
        /// </summary>
        public int OrderNo { get; set; }

        public virtual ICollection<Employee> Employees { get; set; }
    }
}
