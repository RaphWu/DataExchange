﻿using Autofac;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            SplashMessenger.Post("載入核心模組...");

            // dialog
            builder.RegisterType<LoginControl>().ExternallyOwned();
            builder.RegisterType<CRUD>().ExternallyOwned();
            builder.RegisterType<MultiSelector>().ExternallyOwned();
            builder.RegisterType<MachineEdit>().ExternallyOwned();

            // views
            builder.RegisterType<SetupPage>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_Models>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_MachinesSummary>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_MachineInfo1>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_MachineInfo2>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_Employees>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_EmployeeInfo>().InstancePerLifetimeScope();

            builder.RegisterType<Setup_Permission>().InstancePerLifetimeScope();

            // service
            builder.RegisterType<DialogService>().InstancePerLifetimeScope().SingleInstance();
            builder.RegisterType<CoreService>().As<ICore>().SingleInstance();

            builder.RegisterType<MemoryCacheService>().SingleInstance();
            builder.RegisterType<AuthService>().As<IAuthService>().SingleInstance();
            builder.RegisterType<LogService>().As<ILogService>().SingleInstance();
            builder.RegisterType<PermissionService>().As<IPermissionService>().InstancePerLifetimeScope();
            builder.RegisterType<EmployeeService>().As<IEmployeeService>().InstancePerLifetimeScope();
            builder.RegisterType<CurrentUserService>().As<ICurrentUserService>().InstancePerDependency();

            builder.RegisterType<MailService>().As<IMail>().SingleInstance();

            // public data
            builder.RegisterType<CoreData>().SingleInstance();
            builder.RegisterType<CurrentUserContext>().SingleInstance();

            // DbContext
            builder.RegisterType<CoreContext>().InstancePerDependency();
            builder.RegisterType<CoreInitializer>().As<IStartable>().SingleInstance();

            builder.RegisterBuildCallback(async c =>
            {
                var core = c.Resolve<ICore>();
                await core.Initialize();
            });
        }
    }
}
