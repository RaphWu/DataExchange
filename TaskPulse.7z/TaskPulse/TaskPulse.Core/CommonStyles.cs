﻿using System.Drawing;
using System.Windows.Forms;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.Core
{
    /*
     * SunnyUI 的 Styles 套用似乎有些問題，
     * 非自訂的有時子物件不會繼承，
     * 如果看到不是想要的效果須要自行修改。
     */
    /// <summary>
    /// 統一的共用 Styles。
    /// </summary>
    public static class CommonStyles
    {
        #region fields

        private const int DefaultFontSize = 11;
        private static ToolTip _toolTip = new ToolTip();

        #endregion fields

        //public static Color BackColor => Color.FromArgb(80, 126, 164); // 藍灰
        public static Color BackColor => Color.FromArgb(19, 77, 77);
        public static Color HoverAccentColor => Color.FromArgb(50, 119, 119);
        public static Color AccentColor => Color.PeachPuff;
        public static Color CancelColor => Color.Firebrick;
        public static Color HoverColor => Color.SteelBlue;
        public static string FontFamily => "微軟正黑體";
        public static Font Font => new Font(FontFamily, 11f);

        public static void SetButton(Control control,
                                     string toolTip = null,
                                     int fontSize = DefaultFontSize,
                                     bool isAccent = false,
                                     bool isCancel = false)
        {
            control.Font = new Font(FontFamily, fontSize);
            if (toolTip != null)
                _toolTip.SetToolTip(control, toolTip);

            if (control is Button btn)
            {
                btn.BackColor = isCancel ? CancelColor : BackColor;
            }

            if (control is UIButton uiButton)
            {
                uiButton.BackColor = Color.Transparent;
                uiButton.FillColor = isCancel ? CancelColor : BackColor;
                uiButton.FillHoverColor = isAccent ? HoverAccentColor : HoverColor; ;
            }

            if (control is UISymbolButton uiSButton)
            {
                uiSButton.BackColor = Color.Transparent;
                uiSButton.FillColor = isCancel ? CancelColor : BackColor;
                uiSButton.FillHoverColor = isAccent ? HoverAccentColor : HoverColor; ;
            }
        }

        // CRUD按鍵
        /// <summary>
        /// 統一設定 CRUD 按鍵。
        /// </summary>
        /// <param name="control">按鍵。</param>
        /// <param name="type">C: 新增。<br/>D: 刪除。<br/>E: 編輯。<br/>M: 變更。<br/>R: 重新命名。<br/>UP: 往前/上。<br/>DOWN: 往後/下。</param>
        /// <param name="itemName">項目名稱。</param>
        public static void SetCrudButton(Control button, string type, string itemName)
        {
            button.Font = new Font(FontFamily, DefaultFontSize);
            UISymbolButton uibtn = button as UISymbolButton;
            switch (type)
            {
                case "C":
                    button.BackColor = BackColor;
                    _toolTip.SetToolTip(button, $"新增{itemName}");

                    if (uibtn != null)
                    {
                        uibtn.FillColor = BackColor;
                        uibtn.Symbol = 557669;
                    }
                    break;

                case "D":
                    button.BackColor = BackColor;
                    _toolTip.SetToolTip(button, $"刪除{itemName}");

                    if (uibtn != null)
                    {
                        uibtn.FillColor = BackColor;
                        uibtn.Symbol = 559506;
                        uibtn.SymbolOffset = new Point(-1, 1);
                    }
                    break;

                case "E":
                    button.BackColor = BackColor;
                    _toolTip.SetToolTip(button, $"編輯{itemName}");

                    if (uibtn != null)
                    {
                        uibtn.FillColor = BackColor;
                        uibtn.Symbol = 559205;
                    }
                    break;

                case "M":
                    button.BackColor = BackColor;
                    _toolTip.SetToolTip(button, $"變更{itemName}");

                    if (uibtn != null)
                    {
                        uibtn.FillColor = BackColor;
                        uibtn.Symbol = 61473;
                    }
                    break;

                case "R":
                    button.BackColor = BackColor;
                    _toolTip.SetToolTip(button, $"重新命名{itemName}");

                    if (uibtn != null)
                    {
                        uibtn.FillColor = BackColor;
                        uibtn.Symbol = 559810;
                    }
                    break;

                case "UP":
                    button.BackColor = BackColor;
                    _toolTip.SetToolTip(button, $"往前/上移動指定的{itemName}");

                    if (uibtn != null)
                    {
                        uibtn.FillColor = BackColor;
                        uibtn.Symbol = 361702;
                        uibtn.SymbolOffset = new Point(-1, 1);
                    }
                    break;

                case "DOWN":
                    if (button != null)
                    {
                        button.BackColor = BackColor;
                        _toolTip.SetToolTip(button, $"往後/下移動指定的{itemName}");
                    }
                    if (uibtn != null)
                    {
                        uibtn.FillColor = BackColor;
                        uibtn.Symbol = 361703;
                        uibtn.SymbolOffset = new Point(-1, 1);
                    }
                    break;

                default:
                    return;
            }
        }

        public static void SetCheckBox(Control control, string toolTip = null)
        {
            control.Font = new Font(FontFamily, DefaultFontSize);
            control.TabStop = false;

            if (control is UICheckBox cb)
            {
                if (toolTip != null)
                    _toolTip.SetToolTip(control, toolTip);

                cb.CheckBoxColor = BackColor;
            }
        }

        public static void SetListBox(Control control, string toolTip = null)
        {
            control.Font = new Font(FontFamily, DefaultFontSize);
            control.TabStop = false;

            if (control is UIListBox uiListBox)
            {
                uiListBox.ItemSelectBackColor = HoverColor;
                uiListBox.ScrollBarColor = BackColor;

                if (toolTip != null)
                    _toolTip.SetToolTip(control, toolTip);
            }
        }

        public static void SetAdvancedDataGridView(AdvancedDataGridView adgv, bool filterAndSort = false)
        {
            adgv.SetDoubleBuffered();
            adgv.AutoGenerateColumns = false;
            adgv.RowHeadersVisible = false;
            adgv.MultiSelect = false;
            adgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            adgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            adgv.ColumnHeadersDefaultCellStyle.BackColor = BackColor;
            adgv.DefaultCellStyle.SelectionBackColor = HoverColor;
            adgv.DefaultCellStyle.Font = Font;
            adgv.ColumnHeadersDefaultCellStyle.Font = Font;

            adgv.AllowUserToResizeColumns = true;
            adgv.AllowUserToResizeRows = false;
            adgv.AllowUserToAddRows = false;
            adgv.AllowUserToDeleteRows = false;
            adgv.AllowUserToOrderColumns = false;

            adgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            adgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            adgv.FilterAndSortEnabled = filterAndSort;
            foreach (DataGridViewColumn col in adgv.Columns)
            {
                adgv.SetFilterChecklistEnabled(col, filterAndSort);
                adgv.SetFilterCustomEnabled(col, filterAndSort);
            }

            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
        }

        /// <summary>
        /// 全域 Styles 設定。<br/>但若遇到子物件沒繼承的，仍須自行修改。
        /// </summary>
        public static void SetStyles()
        {
            UIStyles.MultiLanguageSupport = true;
            UIStyles.BuiltInResources.TryAdd(CultureInfos.zh_TW.LCID, new zh_TW_Resources());
            UIStyles.CultureInfo = CultureInfos.zh_TW;
            UIStyles.SetStyle(UIStyle.DarkBlue);
            UIStyles.InitColorful(BackColor, Color.White);
            UIStyles.DPIScale = true;
            UIStyles.GlobalFont = true;
            UIStyles.GlobalFontName = "微軟正黑體";
            UIStyles.SetDPIScale();
        }
    }
}
