﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 使用者切換訊息。
    /// </summary>
    public class CurrentUserChangedMessage
    {
        public static readonly CurrentUserChangedMessage Instance = new CurrentUserChangedMessage();
        private CurrentUserChangedMessage() { }
    }
}
