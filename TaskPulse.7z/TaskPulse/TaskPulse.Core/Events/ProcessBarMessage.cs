﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Authority.Models;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    public class ProcessBarMessage : ValueChangedMessage<int>
    {
        public ProcessBarMessage(int percent) : base(percent) { }
    }
}
