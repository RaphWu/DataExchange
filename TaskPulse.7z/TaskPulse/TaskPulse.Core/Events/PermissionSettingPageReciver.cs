﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Contants;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    public class PermissionSettingPageReciver : ValueChangedMessage<PermissionSettingInfo>
    {
        public PermissionSettingPageReciver(PermissionSettingInfo info) : base(info) { }
    }
}
