﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Contracts
{
    public interface IRegionManager
    {
        void RegisterRegion(string name, Control control);
        IRegion GetRegion(string name);
    }
}
