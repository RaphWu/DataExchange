﻿using System.Threading.Tasks;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contracts
{
    /// <summary>
    /// 使用者切換操作服務。
    /// </summary>
    public interface ICurrentUserService
    {
        /********************
         * Switch User
         ********************/
        /// <summary>
        /// 將目前使用者切換為指定使用者。
        /// </summary>
        /// <param name="user">要切換的使用者。</param>
        void SwitchCurrentUserAsync(Employee user);

        /// <summary>
        /// 將目前使用者切換為指定使用者 Id。
        /// </summary>
        Task SwitchCurrentUserAsync(int userId);

        /// <summary>
        /// 將目前使用者切換為指定員工工號。
        /// </summary>
        Task SwitchCurrentUserAsync(string employeeId);

        /********************
         * 特定使用者
         ********************/
        /// <summary>
        /// 將目前使用者切換為訪客。
        /// </summary>
        void SwitchCurrentUserToGuest();

        /// <summary>
        /// 管理員登入。
        /// </summary>
        void AdminLogin();
    }
}
