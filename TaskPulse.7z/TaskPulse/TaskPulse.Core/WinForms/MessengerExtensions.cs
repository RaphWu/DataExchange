﻿//using System;
//using System.Runtime.Remoting.Messaging;
//using System.Threading;
//using CommunityToolkit.Mvvm.Messaging;

//namespace Calin.TaskPulse.Core.WinForms
//{
//    public static class MessengerExtensions : IMessage
//    {
//        public string Text { get; }
//        public MyMessage(string text) => Text = text;

//        private static SynchronizationContext _uiContext = SynchronizationContext.Current
//           ?? throw new InvalidOperationException("必須在 UI 執行緒初始化。");

//        public static void SendOnUI<TMessage>(this StrongReferenceMessenger messenger, TMessage message)
//            where TMessage : IMessage
//        {
//            if (SynchronizationContext.Current == _uiContext)
//            {
//                messenger.Send(message);
//            }
//            else
//            {
//                _uiContext.Post(_ => messenger.Send(message), null);
//            }
//        }
//    }
//}
