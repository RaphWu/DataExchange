﻿using System;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core
{
    /// <summary>
    /// 容器建構完成後啟動。
    /// </summary>
    /// <remarks>參見: <see href="https://docs.autofac.org/en/latest/lifetime/startup.html#startable-components">Startable Components</see>。</remarks>
    public class CoreInitializer : IStartable
    {
        private readonly CoreContext _coreContext;
        private readonly CoreData _coreData;

        public CoreInitializer(CoreContext coreContext, CoreData coreData)
        {
            _coreContext = coreContext;
            _coreData = coreData;
        }

        public void Start()
        {
            try
            {
                _coreContext.Database.Initialize(force: true);
                //_coreData.Employees = _coreContext.Employees.ToList();
                _coreData.Employees = _coreContext.Set<Employee>()
                    .OrderBy(m => m.EmployeeId)
                    .ToList();
            }
            catch (DbEntityValidationException eve)
            {
                foreach (var validationErrors in eve.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        Console.WriteLine($"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}");
                    }
                }
                throw; // 可選，看你是否要繼續拋出
            }
            catch (IOException ioe)
            {
                UIMessageBox.ShowError(ioe.Message);
                Application.Exit();
            }
            catch (Exception ex)
            {
                // 檢查 inner exception 是否為 DbEntityValidationException
                var validationException = ex as DbEntityValidationException
                    ?? ex.InnerException as DbEntityValidationException;

                if (validationException != null)
                {
                    foreach (var validationErrors in validationException.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            Console.WriteLine("❌ Entity: " + validationErrors.Entry.Entity.GetType().Name);
                            Console.WriteLine("   Property: " + validationError.PropertyName);
                            Console.WriteLine("   Error: " + validationError.ErrorMessage);
                        }
                    }
                }
                else
                {
                    // 其他例外狀況
                    Console.WriteLine("🔴 一般例外：");
                    Console.WriteLine(ex.ToString());
                }

                throw;
            }
        }
    }
}
