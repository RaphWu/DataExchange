﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Calin.TaskPulse.Core.Helper
{
    public static class AESHelper
    {
        // https://www.imaegoo.com/2020/aes-key-generator/
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("XLWxJdUyIJgjMwbntzKVuTW8T7UbbaOb"); // 32*8=256 bits
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("gPhnjN2m98iVVUKQ"); // 16*8=128 bits

        public static string Encrypt(string plainText)
        {
            /*
                一次性處理整塊資料：把所有明文讀進記憶體後再加密。
                簡單直接，不需要 stream。
                適合短字串或小資料量（例如一兩 KB 以下）。
                因為完全在記憶體中進行，速度會稍快（少了 stream 層），但記憶體占用會隨明文大小線性增加。
            */
            using (var aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;

                var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                var plainBytes = Encoding.UTF8.GetBytes(plainText);

                var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                return Convert.ToBase64String(cipherBytes);
            }

            /*
                串流式處理：資料一邊寫入、一邊加密、一邊輸出。
                適合大資料（例如檔案、長字串、網路串流）。
                稍微慢一點點（多了 stream 緩衝與 writer 編碼），但能處理不受記憶體限制的大量資料。
                擴充性高（例如直接寫入檔案、網路 socket）。
             */
            //using (var aes = Aes.Create())
            //{
            //    aes.Key = Key;
            //    aes.IV = IV;
            //    using (var encryptor = aes.CreateEncryptor())
            //    using (var ms = new MemoryStream())
            //    {
            //        using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
            //        using (var sw = new StreamWriter(cs))
            //        {
            //            sw.Write(plainText);
            //        }
            //        return Convert.ToBase64String(ms.ToArray());
            //    }
            //}
        }

        public static string Decrypt(string cipherText)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = Key;
                aes.IV = IV;

                var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
                var cipherBytes = Convert.FromBase64String(cipherText);
                var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
                return Encoding.UTF8.GetString(plainBytes);
            }

            //using (var aes = Aes.Create())
            //{
            //    aes.Key = Key;
            //    aes.IV = IV;
            //    using (var decryptor = aes.CreateDecryptor())
            //    using (var ms = new MemoryStream(Convert.FromBase64String(cipherText)))
            //    using (var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
            //    using (var sr = new StreamReader(cs))
            //    {
            //        return sr.ReadToEnd();
            //    }
            //}
        }
    }
}
