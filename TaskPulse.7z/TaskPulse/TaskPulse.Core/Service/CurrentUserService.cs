﻿using System.Data.Entity;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Service
{
    /// <summary>
    /// 使用者切換操作服務。
    /// </summary>
    public class CurrentUserService : ICurrentUserService
    {
        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly IPermissionService _permission;

        public CurrentUserService(CoreContext coreContext,
                                  CurrentUserContext currentUserContext,
                                  IPermissionService permissionService)
        {
            _context = coreContext;
            _user = currentUserContext;
            _permission = permissionService;
        }

        /********************
         * Switch User
         ********************/
        /// <inheritdoc/>
        public void SwitchCurrentUserAsync(Employee user)
        {
            _user.CurrentUser = user;
            _user.Permissions = _permission.GetFullPermissions(user.EmployeeId);
            WeakReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
            WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{_user.UserName} 已登入。"));
            //Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task SwitchCurrentUserAsync(int userId)
        {
            var emp = await _context.Employees.FirstOrDefaultAsync(e => e.Id == userId);
            SwitchCurrentUserAsync(emp);
        }

        /// <inheritdoc/>
        public async Task SwitchCurrentUserAsync(string employeeId)
        {
            var emp = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employeeId);
            SwitchCurrentUserAsync(emp);
        }

        /********************
         * 特定使用者
         ********************/
        /// <inheritdoc/>
        public void SwitchCurrentUserToGuest()
        {
            _user.SetGuest();
            WeakReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
            WeakReferenceMessenger.Default.Send(new StatusBarMessage("目前為訪客權限。"));
        }

        /// <inheritdoc/>
        public void AdminLogin()
        {
            _user.SetAdmin();
            WeakReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
            WeakReferenceMessenger.Default.Send(new StatusBarMessage("歡迎管理員。"));
        }
    }
}
