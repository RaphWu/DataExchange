﻿using System;
using System.Linq;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI.Win32;

namespace Calin.TaskPulse.Core.Service
{
    public class CurrentUserService : ICurrentUserService
    {
        private readonly CoreContext _context;

        private static Employee _currentUser = null;
        private static bool _isAdmin = false;
        private static bool _isGuest = true;

        private readonly Employee _admin = new Employee() { EmployeeName = "管理員", };
        private readonly Employee _guest = new Employee() { EmployeeName = "訪客", };

        public CurrentUserService(CoreContext coreContext)
        {
            _context = coreContext;
        }

        /// <inheritdoc/>
        public int UserId => _currentUser?.Id ?? 0;

        /// <inheritdoc/>
        public string EmployeeId => _currentUser?.EmployeeId ?? "";

        /// <inheritdoc/>
        public string UserName => _currentUser?.EmployeeName ?? "";

        /// <inheritdoc/>
        public Employee User => _currentUser;

        /********************
         * Permission
         ********************/
        /// <inheritdoc/>
        public bool IsAdmin => _isAdmin;

        /// <inheritdoc/>
        public bool IsGuest => _isGuest;

        /********************
         * Switch User
         ********************/
        /// <inheritdoc/>
        public void SwitchCurrentUser(Employee user)
        {
            _currentUser = user;
            _isGuest = _currentUser == null;
            StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(int userId)
        {
            if (userId == int.MaxValue)
            {
                _isAdmin = true;
                _isGuest = false;
                _currentUser = _admin;
            }
            else
            {
                _isAdmin = false;
                _currentUser = _context.Employees.FirstOrDefault(e => e.Id == userId);
                if (_currentUser == null)
                {
                    _currentUser = _guest;
                    _isGuest = true;
                }
                else
                {
                    _isGuest = false;
                }
            }
            StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(string employeeId)
        {
            _isAdmin = false;
            _currentUser = _context.Employees.FirstOrDefault(e => e.EmployeeId == employeeId);
            if (_currentUser == null)
            {
                _currentUser = _guest;
                _isGuest = true;
            }
            else
            {
                _isGuest = false;
            }
            StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
        }

        /// <inheritdoc/>
        public void SwitchCurrentUserToGuest()
        {
            _isAdmin = false;
            _isGuest = true;
            _currentUser = _guest;
            StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
        }

        /// <inheritdoc/>
        public void AdminLogin()
        {
            SwitchCurrentUser(int.MaxValue);
        }

        ///********************
        // * Utility
        // ********************/
        ///// <inheritdoc/>
        //public HashSet<string> GetPermissionsAsync(string prefix)
        //{
        //    return _cache.GetOrCreate($"{prefix}_{EmployeeId}", policy =>
        //    {
        //        // 由同步方式取得權限，因為 MemoryCache 不支援 async lambda
        //        return _permissionService.GetUserPermissions(EmployeeId, prefix);
        //    }, TimeSpan.FromMinutes(30));
        //}
    }
}
