﻿using System.Data.Entity;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Service
{
    /// <summary>
    /// 使用者切換操作服務。
    /// </summary>
    public class CurrentUserService : ICurrentUserService
    {
        private readonly CoreContext _context;
        private readonly CurrentUserContext _userData;

        public CurrentUserService(CoreContext coreContext, CurrentUserContext currentUserContext)
        {
            _context = coreContext;
            _userData = currentUserContext;
        }

        /********************
         * Switch User
         ********************/
        /// <inheritdoc/>
        public async Task SwitchCurrentUserAsync(Employee user)
        {
            _userData.CurrentUser = user;
            StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
            await Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task SwitchCurrentUserAsync(int userId)
        {
            var emp = await _context.Employees.FirstOrDefaultAsync(e => e.Id == userId);
            await SwitchCurrentUserAsync(emp);
        }

        /// <inheritdoc/>
        public async Task SwitchCurrentUserAsync(string employeeId)
        {
            var emp = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employeeId);
            await SwitchCurrentUserAsync(emp);
        }

        /********************
         * 特定使用者
         ********************/
        /// <inheritdoc/>
        public void SwitchCurrentUserToGuest()
        {
            _userData.SetGuest();
            StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
        }

        /// <inheritdoc/>
        public void AdminLogin()
        {
            _userData.SetAdmin();
            StrongReferenceMessenger.Default.Send(CurrentUserChangedMessage.Instance);
        }
    }
}
