﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Caching;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI.Win32;

namespace Calin.TaskPulse.Core.Service
{
    public class PermissionService : IPermissionService
    {
        private readonly CoreContext _context;
        private readonly MemoryCacheService _cache;
        private readonly CoreData _coreData;
        private readonly ICurrentUserService _currentUser;
        //private readonly ConcurrentDictionary<int, List<string>> _userPermissionCache
        //= new ConcurrentDictionary<int, List<string>>();
        private static readonly string[] GuestPermissions = new[] { "Home.View", "Login.Access" };

        public PermissionService(CoreContext coreContext,
                                 MemoryCacheService cache,
                                 CoreData coreData,
                                 ICurrentUserService currentUserService)
        {
            _context = coreContext;
            _cache = cache;
            _coreData = coreData;
            _currentUser = currentUserService;
        }

        /********************
         * Permission
         ********************/
        /// <inheritdoc/>
        public HashSet<string> GetUserPermissions(string employeeId)
        {
            string cacheKey = $"UserPermissions:{employeeId}";

            return _cache.GetOrCreate(cacheKey, policy =>
            {
                var user = _context.Employees
                    .Include(u => u.Department.Permissions)
                    .Include(u => u.UserGroups)
                    //.Include(u => u.UserGroups.Select(g => g.Permissions))
                    .Include(u => u.Permissions)
                    .FirstOrDefault(u => u.EmployeeId == employeeId);
                foreach (var g in user.UserGroups)
                    _context.Entry(g).Collection(gp => gp.Permissions).Load();

                if (user == null)
                    return new HashSet<string>();

                if (_coreData.IsAdmin)
                    return new HashSet<string> { "*" };

                if (_coreData.IsGuest || !user.OnStaff)
                    return new HashSet<string>(GuestPermissions);

                var permissions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                if (user.Department?.Permissions != null)
                    permissions.UnionWith(user.Department.Permissions
                        .Select(p => $"{p.Module}:{p.Page}:{p.Control}:{p.Action}"));

                if (user.UserGroups != null)
                {
                    foreach (var g in user.UserGroups)
                    {
                        if (g.Permissions != null)
                            permissions.UnionWith(g.Permissions
                                .Select(p => $"{p.Module}:{p.Page}:{p.Control}:{p.Action}"));
                    }
                }

                if (user.Permissions != null)
                    permissions.UnionWith(user.Permissions
                        .Select(p => $"{p.Module}:{p.Page}:{p.Control}:{p.Action}"));

                return permissions;




                //if (user.Department?.Permissions != null)
                //    permissions.UnionWith(user.Department.Permissions
                //        .Select(p => string.Join(":", p.Module, p.));

                //if (user.UserGroups != null)
                //    permissions.UnionWith(user.UserGroups
                //        .Where(g => g.Permissions != null)
                //        .SelectMany(g => g.Permissions.Select(p => p.Code)));

                //if (user.Permissions != null)
                //    permissions.UnionWith(user.Permissions.Select(p => p.Code));

                //return permissions;



                //if (user.Department?.Permissions != null)
                //    foreach (var p in user.Department.Permissions)
                //        permissions.Add($"{p.Module}:{p.Page}:{p.Control}:{p.Action}");

                //if (user.UserGroups != null)
                //    foreach (var g in user.UserGroups)
                //        if (g.Permissions != null)
                //            foreach (var p in g.Permissions)
                //                permissions.Add($"{p.Module}:{p.Page}:{p.Control}:{p.Action}");

                //if (user.Permissions != null)
                //    foreach (var p in user.Permissions)
                //        permissions.Add($"{p.Module}:{p.Page}:{p.Control}:{p.Action}");

                //return permissions;





            }, TimeSpan.FromMinutes(30));


            //if (_userPermissionCache.TryGetValue(userId, out var perms))
            //    return perms;

            //var user = _db.Employees
            //    .Include("Department.Permissions")
            //    .Include("Groups.Permissions")
            //    .Include("IndividualPermissions")
            //    .SingleOrDefault(u => u.Id == userId);

            //if (user == null) return new List<string>();

            //var list = new List<Permission>();
            //if (user.Department?.Permissions != null)
            //    list.AddRange(user.Department.Permissions);

            //if (user.Groups != null)
            //    foreach (var g in user.Groups)
            //        list.AddRange(g.Permissions);

            //if (user.IndividualPermissions != null)
            //    list.AddRange(user.IndividualPermissions);

            //// 合成字串
            //var strList = list
            //    .Select(p => $"{p.Module}:{p.Page}:{p.Control}:{p.Action}")
            //    .Distinct()
            //    .ToList();

            //_userPermissionCache[userId] = strList;
            //return strList;
        }

        /// <inheritdoc/>
        public bool HasPermission(string employeeId, string permission)
        {
            if (_coreData.IsAdmin)
                return true;

            var user = _context.Employees.FirstOrDefault(u => u.EmployeeId == employeeId);
            if (user == null)
                return GuestPermissions.Any(p => IsMatch(p, permission));

            var all = GetUserPermissions(employeeId);
            return all.Any(p => IsMatch(p, permission));
        }

        /// <summary>
        /// 權限比對，支援萬用字元。
        /// </summary>
        /// <param name="granted">已授權的權限字串。</param>
        /// <param name="target">目標權限字串。</param>
        /// <returns>傳回是否匹配。</returns>
        private bool IsMatch(string granted, string target)
        {
            if (granted == "*")
                return true;

            if (granted.EndsWith(".*"))
                return target.StartsWith(granted.Substring(0, granted.Length - 2), StringComparison.OrdinalIgnoreCase);

            return string.Equals(granted, target, StringComparison.OrdinalIgnoreCase);
        }

        /********************
         * Control Access
         ********************/
        /// <inheritdoc/>
        public bool HasControlAccess(string employeeId, string controlName)
        {
            if (_coreData.IsAdmin)
                return true;

            var permissions = GetUserPermissions(employeeId);
            return permissions.Contains(controlName);
        }

        /*
         * 四階段來源支援
         *      Department → UserGroup → Individual
         *      同一個權限按來源優先級存入 Dictionary（部門 > 群組 > 個人）
         * 快取整個使用者權限集合
         *      一次查完部門、群組、個人權限
         *      查單個控制項時 O(1)
         * 權限唯一鍵
         *      使用 "Module:Page:Control:Action" 作為 key
         *      避免重複
         * 易擴展
         *      若將來新增其他來源，只需在 Dictionary 內增加來源階段即可
         */
        /// <inheritdoc/>
        public Dictionary<string, PermissionSource> GetUserPermissionSources(string employeeId)
        {
            string cacheKey = $"UserPermissionSources_{employeeId}";

            return _cache.GetOrCreate(cacheKey, policy =>
            {
                var permissionSources = new Dictionary<string, PermissionSource>();

                // 取得使用者資料及相關關聯
                var user = _context.Employees
                                   .Include(e => e.Department.Permissions)
                                   .Include(e => e.UserGroups.Select(g => g.Permissions))
                                   .Include(e => e.Permissions)
                                   .SingleOrDefault(e => e.EmployeeId == employeeId);

                if (user == null)
                    return permissionSources;

                // 部門權限
                if (user.Department?.Permissions != null)
                {
                    foreach (var p in user.Department.Permissions)
                    {
                        string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                        if (!permissionSources.ContainsKey(key))
                            permissionSources[key] = PermissionSource.Department;
                    }
                }

                // 群組權限
                if (user.UserGroups != null)
                {
                    foreach (var g in user.UserGroups)
                    {
                        if (g.Permissions != null)
                        {
                            foreach (var p in g.Permissions)
                            {
                                string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                                if (!permissionSources.ContainsKey(key))
                                    permissionSources[key] = PermissionSource.UserGroup;
                            }
                        }
                    }
                }

                // 個人權限
                if (user.Permissions != null)
                {
                    foreach (var p in user.Permissions)
                    {
                        string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                        if (!permissionSources.ContainsKey(key))
                            permissionSources[key] = PermissionSource.Employee;
                    }
                }

                return permissionSources;

            }, TimeSpan.FromMinutes(30));
        }

        /// <inheritdoc/>
        public PermissionSource GetPermissionSource(string employeeId, string module, string page, string control, string action)
        {
            var sources = GetUserPermissionSources(employeeId);
            string key = $"{module}:{page}:{control}:{action}";

            return sources.TryGetValue(key, out var source)
                ? source
                : PermissionSource.None;
        }

        /// <inheritdoc/>
        public void ClearUserPermissionSourceCache(string employeeId)
        {
            string cacheKey = $"UserPermissionSources_{employeeId}";
            _cache.Remove(cacheKey);
        }

        /********************
         * Refresh
         ********************/
        /// <inheritdoc/>
        public void RefreshUserPermissions(string employeeId)
        {
            _cache.Remove($"UserPermissions:{employeeId}");
        }

        /// <inheritdoc/>
        public void RefreshAllUserCaches()
        {
            // 避免全站暴力清除太頻繁，但這是個提供的工具
            // 取得在快取中的所有 key，MemoryCache 不直接提供列舉所有 key 的好方法，這裡示範常見模式：
            // 若你需要經常全清，考慮維護一個已快取 employeeId 列表
            // 這裡示範：清除所有 Users（從 DB 查詢）
            var allUserIds = _context.Employees
                .Select(u => u.EmployeeId)
                .ToList();
            foreach (var userId in allUserIds)
                _cache.Remove(userId);
        }

        /// <inheritdoc/>
        public void RefreshDepartmentPermissions(int departmentId)
        {
            var userIds = _context.Employees
                .Where(u => u.DepartmentId == departmentId)
                .Select(u => u.EmployeeId)
                .ToList();

            foreach (var userId in userIds)
                _cache.Remove(userId);
        }

        /// <inheritdoc/>
        public void RefreshUserGroupPermissions(int userGroupId)
        {
            var userIds = _context.Employees
                .Where(u => u.UserGroups.Any(g => g.Id == userGroupId))
                .Select(u => u.EmployeeId)
                .ToList();

            foreach (var userId in userIds)
                _cache.Remove(userId);
        }
    }
}





//// 手動清除使用者權限快取（例如權限更新時）
///// <inheritdoc/>
//public void ClearUserCache(int userId)
//{
//    _cache.Remove($"Permissions_{userId}");
//}

///********************
// * 
// ********************/
///// <inheritdoc/>
//private HashSet<string> LoadPermissionsFromDb(int userId)
//{
//    var user = _context.Employees.Include(e => e.Department)
//                            .ThenInclude(d => d.Permissions)
//                            .FirstOrDefault(e => e.Id == userId);

//    var deptPerms = user?.Department?.Permissions.Select(p => p.ControlName).ToList() ?? new List<string>();

//    var groupPerms = _context.UserGroups
//                        .Include(g => g.Permissions)
//                        .Where(g => g.Members.Any(m => m.Id == userId))
//                        .SelectMany(g => g.Permissions)
//                        .Select(p => p.ControlName)
//                        .ToList();

//    return deptPerms.Union(groupPerms).ToHashSet();
//}

///// <summary>
///// 取得使用者所有權限清單
///// </summary>
///// <param name="userId"></param>
///// <returns></returns>
//public async Task<HashSet<string>> GetUserPermissionsAsync(int userId)
//{
//    return _cache.GetOrCreate($"permissions_{userId}", () =>
//    {
//        var employee = _db.Employees
//            .Include("Department.Permissions")
//            .Include("UserGroups.Permissions")
//            .FirstOrDefault(e => e.Id == userId);

//        if (employee == null) return new List<string>();

//        var deptPerms = employee.Department?.Permissions.Select(p => p.Name).ToList() ?? new List<string>();
//        var groupPerms = employee.UserGroups
//            .SelectMany(ug => ug.Permissions)
//            .Select(p => p.Name)
//            .ToList();

//        return deptPerms.Union(groupPerms).Distinct().ToList();
//    }, TimeSpan.FromMinutes(30));
//}