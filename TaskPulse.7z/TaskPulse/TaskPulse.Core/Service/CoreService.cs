﻿using System.Linq;
using System.Text.RegularExpressions;
using Autofac;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Service
{
    public class CoreService : ICore
    {
        private readonly ILifetimeScope _scope;
        private bool _isInitialized = false;

        public CoreService(ILifetimeScope scope)
        {
            _scope = scope;
        }

        public void Initialize()
        {
            if (_isInitialized)
                return;

            UpdateCoreDataFromDb();
            _isInitialized = true;
        }

        /// <inheritdoc/>
        public void UpdateCoreDataFromDb()
        {
            using (var scope = _scope.BeginLifetimeScope())
            {
                var coreContext = scope.Resolve<CoreContext>();
                var coreData = scope.Resolve<CoreData>();

                coreData.Employees = coreContext.Employees
                    .OrderBy(x => x.EmployeeId)
                    .ToList();

                coreData.Devices = coreContext.Devices
                     .Include("DeviceName")
                     .Include("DeviceName.Type")
                     .Include("Brand")
                     .Include("Assets")
                     .Include("Location")
                     .Include("Location.Factory")
                     .Include("Condition")
                     .ToList();
                coreData.Devices = coreData.Devices
                     .Select(s =>
                     {
                         // 擷取格式：「文字 + 可選 dash + 數字」
                         var match = Regex.Match(s.DeviceId, @"^([^\d\-]+)-?(\d+)$", RegexOptions.IgnoreCase);
                         string textPart = match.Success ? match.Groups[1].Value : s.DeviceId;
                         int numberPart = (match.Success && int.TryParse(match.Groups[2].Value, out int n)) ? n : int.MaxValue;
                         return new
                         {
                             Original = s,
                             Text = textPart.ToLowerInvariant(), // 忽略大小寫排序
                             Number = numberPart                  // 確保是 int，不是 string
                         };
                     })
                    .OrderBy(x => x.Text)
                    .ThenBy(x => x.Number)
                    .Select(x => x.Original)
                    .ToList();

                coreData.Models = coreContext
                    .Models.OrderBy(x => x.ModelId)
                    .ToList();

                StrongReferenceMessenger.Default.Send(CoreDataChangedNotification.Instance);
            }
        }
    }
}
