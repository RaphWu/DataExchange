﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Service
{
    public class CoreService : ICore
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly CoreFieldName _fieldName;

        private bool _isInitialized = false;

        public CoreService(CoreContext coreContext, CoreData coreData, CoreFieldName coreFieldName)
        {
            _context = coreContext;
            _coreData = coreData;
            _fieldName = coreFieldName;
        }

        /// <inheritdoc/>
        public async Task Initialize()
        {
            if (_isInitialized)
                return;

            await UpdateCoreDataFromDb();

            _fieldName.MachineId = EnumHelper.GetDescription<Machine>(nameof(Machine.MachineId));
            _fieldName.MachineName = EnumHelper.GetDescription<Machine>(nameof(Machine.MachineName));
            _fieldName.Status = EnumHelper.GetDescription<Machine>(nameof(Machine.Status));
            _fieldName.Brand = EnumHelper.GetDescription<Machine>(nameof(Machine.Brand));
            _fieldName.Location = EnumHelper.GetDescription<Machine>(nameof(Machine.Location));
            _fieldName.Assets = EnumHelper.GetDescription<Machine>(nameof(Machine.Assets));
            _fieldName.SerialNumber = EnumHelper.GetDescription<Machine>(nameof(Machine.SerialNumber));
            _fieldName.Barcode = EnumHelper.GetDescription<Machine>(nameof(Machine.Barcode));
            _fieldName.Connected = EnumHelper.GetDescription<Machine>(nameof(Machine.Connected));
            _fieldName.Disposal = EnumHelper.GetDescription<Machine>(nameof(Machine.Disposal));
            _fieldName.Remark = EnumHelper.GetDescription<Machine>(nameof(Machine.Remark));
            _fieldName.Worktations = EnumHelper.GetDescription<Machine>(nameof(Machine.Worktations));

            _isInitialized = true;
        }

        /********************
         * public Functions
         ********************/
        /// <inheritdoc/>
        public async Task UpdateCoreDataFromDb()
        {
            // 員工名冊
            _coreData.Employees = await _context.Employees
                .OrderBy(x => x.EmployeeId)
                .ToListAsync();

            // 機台清單
            var tMachines = await _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.MachineName.MachineType)
                .Include(m => m.MachineName.MachineType.Category)
                .Include(m => m.Brand)
                .Include(m => m.Assets)
                .Include(m => m.Location)
                .Include(m => m.Status)
                .Where(m => m.Disposal == false)
                .ToListAsync();
            _coreData.Machines = tMachines
                .Select(m => new { Original = m, Key = GetMachineSortKey(m.MachineId) })
                .OrderBy(x => x.Key.Text)
                .ThenBy(x => x.Key.Number)
                .Select(x => x.Original)
                .ToList();

            // 機台分類
            _coreData.ClassifyMachines = _coreData.Machines
                .Where(m => m.MachineName != null && m.MachineName.MachineType != null && m.MachineName.MachineType.Category != null)
                .GroupBy(m => m.MachineName.MachineType.Category)
                .OrderBy(categoryGroup => categoryGroup.Key.OrderNo)
                .ToDictionary(
                    categoryGroup => categoryGroup.Key.CategoryName,
                    categoryGroup => categoryGroup
                        .GroupBy(m => m.MachineName.MachineType)
                        .OrderBy(typeGroup => typeGroup.Key.OrderNo)
                        .ToDictionary(
                            typeGroup => typeGroup.Key.TypeName,
                            typeGroup => typeGroup
                                .Select(m => m.MachineId)
                                .Distinct()
                                .ToList()
                        )
                );

            // 依機台分類建立TabPage並注入Autofac
            _coreData.MachinesTabPageCache = new Dictionary<string, List<TabPage>>();
            foreach (var maCategoryName in _coreData.ClassifyMachines.Keys)
            {
                List<TabPage> maTabPages = new List<TabPage>();
                var mTypesDict = _coreData.ClassifyMachines[maCategoryName];
                foreach (var maTypeName in mTypesDict.Keys)
                {
                    var maTabPage = new TabPage(maTypeName)
                    {
                        Name = maTypeName,
                        Font = CommonStyles.Font,
                    };
                    var maFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    maTabPage.Controls.Add(maFlow);

                    var machineIdList = mTypesDict[maTypeName];
                    List<UICheckBox> cbs = new List<UICheckBox>();
                    foreach (var machineId in machineIdList)
                    {
                        var cb = new UICheckBox
                        {
                            Text = machineId,
                            Name = machineId,
                            Checked = false,
                            AutoSize = false,
                            Width = 130,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            CheckBoxColor = CommonStyles.BackColor,
                            Tag = new { Category = maCategoryName, Type = maTypeName, MachineId = machineId }
                        };
                        cbs.Add(cb);
                    }
                    maFlow.Controls.AddRange(cbs.ToArray());
                    maTabPages.Add(maTabPage);
                }
                _coreData.MachinesTabPageCache.Add(maCategoryName, maTabPages);
            }

            // 機種清單
            var tModels = await _context.Models.ToListAsync();
            _coreData.Models = tModels
                .Select(m => new { Original = m, Key = GetModelSortKey(m.ModelName) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();

            // 工站清單
            var tWorkstations = await _context.Workstations
                .Include(w => w.Model)
                .ToListAsync();
            _coreData.Workstations = tWorkstations
                .Select(w => new { Original = w, Key = GetWorkstationSortKey(w) })
                .OrderBy(w => w.Key.ModelPriority)
                .ThenBy(w => w.Key.ModelNumber)
                .ThenBy(w => w.Key.WorkstationName)
                .Select(w => w.Original)
                .ToList();

            // 依機種分類建立TabPage並注入Autofac
            // 目前機種未分類，所以只有一頁
            _coreData.ModelsTabPageCache = new Dictionary<string, List<TabPage>>();

            string moCategoryName = "SingleCategory";
            string moTypeName = "SingleType";
            List<TabPage> moTabPages = new List<TabPage>();
            var moTabPage = new TabPage(moTypeName)
            {
                Name = moTypeName,
                Font = CommonStyles.Font,
            };
            var moFlow = new UIFlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
            };
            moTabPage.Controls.Add(moFlow);

            List<UIRadioButton> rbs = new List<UIRadioButton>();
            foreach (var item in _coreData.Models)
            {
                var rb = new UIRadioButton
                {
                    Text = item.ModelName,
                    Name = item.ModelName,
                    Checked = false,
                    AutoSize = false,
                    Width = 130,
                    Font = CommonStyles.Font,
                    Style = UIStyle.Inherited,
                    RadioButtonColor = CommonStyles.BackColor,
                    Tag = new { Category = moCategoryName, Type = moTypeName, Model = item.ModelName }
                };
                rbs.Add(rb);
            }
            moFlow.Controls.AddRange(rbs.ToArray());
            moTabPages.Add(moTabPage);
            _coreData.ModelsTabPageCache.Add("SinglePage", moTabPages);

            // 發佈資料更新通知
            StrongReferenceMessenger.Default.Send(CoreDataChangedNotification.Instance);
        }

        /// <inheritdoc/>
        public List<string> SortMachineId(IEnumerable<string> machineIds)
        {
            return machineIds
               .Select(s => new { Original = s, Key = GetMachineSortKey(s) })
               .OrderBy(x => x.Key.Text)
               .ThenBy(x => x.Key.Number)
               .Select(x => x.Original)
               .ToList();
        }

        /// <inheritdoc/>
        public List<string> SortModelNames(IEnumerable<string> modelNames)
        {
            return modelNames
                .Select(name => new { Original = name, Key = GetModelSortKey(name) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();
        }

        /// <inheritdoc/>
        public List<Workstation> SortWorkstations(IEnumerable<Workstation> workstations)
        {
            return workstations
                .OrderBy(w => GetWorkstationSortKey(w))
                .ToList();
        }

        /********************
         * Control
         ********************/
        /// <inheritdoc/>
        public void CleanUpControls(Control.ControlCollection controls)
        {
            if (controls.Count == 0)
                return;

            foreach (Control c in controls)
                c.Dispose();
            controls.Clear();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        /********************
         * private Common Functions
         ********************/
        /// <summary>
        /// MachineId 的共用排序規則。
        /// </summary>
        private (string Text, int Number) GetMachineSortKey(string machineId)
        {
            var match = Regex.Match(machineId, @"^([^\d\-]+)-?(\d+)$", RegexOptions.IgnoreCase);
            string textPart = match.Success ? match.Groups[1].Value : machineId;
            int numberPart = (match.Success && int.TryParse(match.Groups[2].Value, out int n)) ? n : int.MaxValue;
            return (textPart.ToLowerInvariant(), numberPart);

        }

        /// <summary>
        /// Model 的共用排序規則。
        /// </summary>
        private (bool IsThreeDigits, int SortKey) GetModelSortKey(string modelName)
        {
            var prefix = modelName.Split('-')[0];
            bool isThreeDigits = Regex.IsMatch(prefix, @"^\d{3}$");
            int sortKey = int.TryParse(prefix, out var n) ? n : int.MaxValue;
            return (isThreeDigits, sortKey);
        }

        /// <summary>
        /// Workstation 的共用排序規則。
        /// </summary>
        private (int ModelPriority, int ModelNumber, string WorkstationName) GetWorkstationSortKey(Workstation w)
        {
            var modelName = w.Model?.ModelName ?? "";
            var key = GetModelSortKey(modelName);

            int modelPriority = key.IsThreeDigits ? 0 : 1;
            int modelNumber = key.SortKey;
            string workstationName = w.WorkstationName ?? "";

            return (modelPriority, modelNumber, workstationName);
        }
    }
}
