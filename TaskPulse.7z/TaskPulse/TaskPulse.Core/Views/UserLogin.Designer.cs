﻿namespace Calin.TaskPulse.Core.Views
{
    partial class UserLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiButton_Cancel = new Sunny.UI.UIButton();
            this.uiButton_Login = new Sunny.UI.UIButton();
            this.uiTextBox_Password = new Sunny.UI.UITextBox();
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiAvatar1 = new Sunny.UI.UIAvatar();
            this.uiComboBox_UserName = new Sunny.UI.UIComboBox();
            this.SuspendLayout();
            // 
            // uiButton_Cancel
            // 
            this.uiButton_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.uiButton_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.uiButton_Cancel.Location = new System.Drawing.Point(137, 274);
            this.uiButton_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Cancel.Name = "uiButton_Cancel";
            this.uiButton_Cancel.Radius = 15;
            this.uiButton_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Size = new System.Drawing.Size(95, 40);
            this.uiButton_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton_Cancel.TabIndex = 4;
            this.uiButton_Cancel.Text = "取消";
            this.uiButton_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // uiButton_Login
            // 
            this.uiButton_Login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Login.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.uiButton_Login.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Login.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.uiButton_Login.Location = new System.Drawing.Point(22, 274);
            this.uiButton_Login.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Login.Name = "uiButton_Login";
            this.uiButton_Login.Radius = 15;
            this.uiButton_Login.Size = new System.Drawing.Size(95, 40);
            this.uiButton_Login.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton_Login.TabIndex = 3;
            this.uiButton_Login.Text = "登入";
            this.uiButton_Login.TipsFont = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Login.Click += new System.EventHandler(this.uiButton_Login_Click);
            // 
            // uiTextBox_Password
            // 
            this.uiTextBox_Password.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uiTextBox_Password.EnterAsTab = true;
            this.uiTextBox_Password.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiTextBox_Password.Location = new System.Drawing.Point(22, 221);
            this.uiTextBox_Password.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTextBox_Password.MinimumSize = new System.Drawing.Size(1, 16);
            this.uiTextBox_Password.Name = "uiTextBox_Password";
            this.uiTextBox_Password.Padding = new System.Windows.Forms.Padding(5);
            this.uiTextBox_Password.PasswordChar = '●';
            this.uiTextBox_Password.ShowText = false;
            this.uiTextBox_Password.Size = new System.Drawing.Size(210, 30);
            this.uiTextBox_Password.Symbol = 361572;
            this.uiTextBox_Password.TabIndex = 2;
            this.uiTextBox_Password.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiTextBox_Password.Watermark = "請輸入密碼";
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.LineSize = 3;
            this.uiLine1.Location = new System.Drawing.Point(22, 129);
            this.uiLine1.Margin = new System.Windows.Forms.Padding(4);
            this.uiLine1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(210, 30);
            this.uiLine1.TabIndex = 7;
            this.uiLine1.TabStop = false;
            this.uiLine1.Text = "使用者登入";
            // 
            // uiAvatar1
            // 
            this.uiAvatar1.BackColor = System.Drawing.Color.Transparent;
            this.uiAvatar1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiAvatar1.Location = new System.Drawing.Point(80, 35);
            this.uiAvatar1.Margin = new System.Windows.Forms.Padding(4);
            this.uiAvatar1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiAvatar1.Name = "uiAvatar1";
            this.uiAvatar1.Size = new System.Drawing.Size(95, 102);
            this.uiAvatar1.TabIndex = 6;
            this.uiAvatar1.TabStop = false;
            this.uiAvatar1.Text = "uiAvatar1";
            // 
            // uiComboBox_UserName
            // 
            this.uiComboBox_UserName.DataSource = null;
            this.uiComboBox_UserName.FillColor = System.Drawing.Color.White;
            this.uiComboBox_UserName.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiComboBox_UserName.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.uiComboBox_UserName.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiComboBox_UserName.Location = new System.Drawing.Point(22, 173);
            this.uiComboBox_UserName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboBox_UserName.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboBox_UserName.Name = "uiComboBox_UserName";
            this.uiComboBox_UserName.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboBox_UserName.ShowFilter = true;
            this.uiComboBox_UserName.Size = new System.Drawing.Size(210, 30);
            this.uiComboBox_UserName.SymbolSize = 24;
            this.uiComboBox_UserName.TabIndex = 1;
            this.uiComboBox_UserName.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboBox_UserName.Watermark = "使用者名稱";
            // 
            // Login
            // 
            this.AcceptButton = this.uiButton_Login;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.uiButton_Cancel;
            this.ClientSize = new System.Drawing.Size(256, 341);
            this.ControlBox = false;
            this.Controls.Add(this.uiComboBox_UserName);
            this.Controls.Add(this.uiButton_Cancel);
            this.Controls.Add(this.uiButton_Login);
            this.Controls.Add(this.uiTextBox_Password);
            this.Controls.Add(this.uiLine1);
            this.Controls.Add(this.uiAvatar1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Login";
            this.ShowIcon = false;
            this.Text = "TaskPulse";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TopMost = true;
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 234, 300);
            this.Activated += new System.EventHandler(this.UserLogin_Activated);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UIButton uiButton_Cancel;
        private Sunny.UI.UIButton uiButton_Login;
        private Sunny.UI.UITextBox uiTextBox_Password;
        private Sunny.UI.UILine uiLine1;
        private Sunny.UI.UIAvatar uiAvatar1;
        private Sunny.UI.UIComboBox uiComboBox_UserName;
    }
}