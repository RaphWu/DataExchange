﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Permission
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.FLP_System = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.CBr_System = new Sunny.UI.UICheckBox();
            this.uiCheckBox1 = new Sunny.UI.UICheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.uiCheckBox2 = new Sunny.UI.UICheckBox();
            this.CBe_System = new Sunny.UI.UICheckBox();
            this.Panel_System = new Sunny.UI.UITitlePanel();
            this.Panel_Mainti = new Sunny.UI.UITitlePanel();
            this.FLP_MaintiFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.CBr_Mainti = new Sunny.UI.UICheckBox();
            this.uiLine4 = new Sunny.UI.UILine();
            this.CBr_Summy = new Sunny.UI.UICheckBox();
            this.uiLine6 = new Sunny.UI.UILine();
            this.CBr_Create = new Sunny.UI.UICheckBox();
            this.CBr_Cancel = new Sunny.UI.UICheckBox();
            this.uiLine7 = new Sunny.UI.UILine();
            this.CBr_Accept = new Sunny.UI.UICheckBox();
            this.CBr_Transfer = new Sunny.UI.UICheckBox();
            this.uiLine8 = new Sunny.UI.UILine();
            this.CBr_Maintant = new Sunny.UI.UICheckBox();
            this.CBr_Confirm = new Sunny.UI.UICheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.CBe_Mainti = new Sunny.UI.UICheckBox();
            this.uiLine5 = new Sunny.UI.UILine();
            this.CBe_Summy = new Sunny.UI.UICheckBox();
            this.uiLine3 = new Sunny.UI.UILine();
            this.CBe_Create = new Sunny.UI.UICheckBox();
            this.CBe_Cancel = new Sunny.UI.UICheckBox();
            this.uiLine1 = new Sunny.UI.UILine();
            this.CBe_Accept = new Sunny.UI.UICheckBox();
            this.CBe_Transfer = new Sunny.UI.UICheckBox();
            this.uiLine2 = new Sunny.UI.UILine();
            this.CBe_Maintant = new Sunny.UI.UICheckBox();
            this.CBe_Confirm = new Sunny.UI.UICheckBox();
            this.FLP_Page = new System.Windows.Forms.FlowLayoutPanel();
            this.FLP_System.SuspendLayout();
            this.Panel_System.SuspendLayout();
            this.Panel_Mainti.SuspendLayout();
            this.FLP_MaintiFlow.SuspendLayout();
            this.FLP_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // FLP_System
            // 
            this.FLP_System.Controls.Add(this.label3);
            this.FLP_System.Controls.Add(this.CBr_System);
            this.FLP_System.Controls.Add(this.uiCheckBox1);
            this.FLP_System.Controls.Add(this.label4);
            this.FLP_System.Controls.Add(this.uiCheckBox2);
            this.FLP_System.Controls.Add(this.CBe_System);
            this.FLP_System.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FLP_System.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.FLP_System.Location = new System.Drawing.Point(1, 28);
            this.FLP_System.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.FLP_System.Name = "FLP_System";
            this.FLP_System.Padding = new System.Windows.Forms.Padding(9);
            this.FLP_System.Size = new System.Drawing.Size(238, 286);
            this.FLP_System.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 19);
            this.label3.TabIndex = 22;
            this.label3.Text = "檢視";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // CBr_System
            // 
            this.CBr_System.CheckBoxSize = 18;
            this.CBr_System.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_System.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_System.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_System.Location = new System.Drawing.Point(9, 28);
            this.CBr_System.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_System.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_System.Name = "CBr_System";
            this.CBr_System.Size = new System.Drawing.Size(29, 29);
            this.CBr_System.TabIndex = 0;
            this.CBr_System.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiCheckBox1
            // 
            this.uiCheckBox1.CheckBoxSize = 18;
            this.uiCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FLP_System.SetFlowBreak(this.uiCheckBox1, true);
            this.uiCheckBox1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiCheckBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiCheckBox1.Location = new System.Drawing.Point(9, 57);
            this.uiCheckBox1.Margin = new System.Windows.Forms.Padding(0);
            this.uiCheckBox1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiCheckBox1.Name = "uiCheckBox1";
            this.uiCheckBox1.Size = new System.Drawing.Size(29, 29);
            this.uiCheckBox1.TabIndex = 24;
            this.uiCheckBox1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(48, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 19);
            this.label4.TabIndex = 23;
            this.label4.Text = "編輯";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // uiCheckBox2
            // 
            this.uiCheckBox2.CheckBoxSize = 18;
            this.uiCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiCheckBox2.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiCheckBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiCheckBox2.Location = new System.Drawing.Point(48, 28);
            this.uiCheckBox2.Margin = new System.Windows.Forms.Padding(0);
            this.uiCheckBox2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiCheckBox2.Name = "uiCheckBox2";
            this.uiCheckBox2.Size = new System.Drawing.Size(180, 29);
            this.uiCheckBox2.TabIndex = 25;
            this.uiCheckBox2.Text = "機台管理";
            this.uiCheckBox2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_System
            // 
            this.CBe_System.CheckBoxSize = 18;
            this.CBe_System.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_System.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_System.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_System.Location = new System.Drawing.Point(48, 57);
            this.CBe_System.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_System.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_System.Name = "CBe_System";
            this.CBe_System.Size = new System.Drawing.Size(180, 29);
            this.CBe_System.TabIndex = 14;
            this.CBe_System.Text = "人員管理";
            this.CBe_System.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Panel_System
            // 
            this.Panel_System.Controls.Add(this.FLP_System);
            this.Panel_System.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Panel_System.Location = new System.Drawing.Point(264, 9);
            this.Panel_System.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Panel_System.MinimumSize = new System.Drawing.Size(1, 1);
            this.Panel_System.Name = "Panel_System";
            this.Panel_System.Padding = new System.Windows.Forms.Padding(1, 28, 1, 1);
            this.Panel_System.ShowText = false;
            this.Panel_System.Size = new System.Drawing.Size(240, 315);
            this.Panel_System.TabIndex = 3;
            this.Panel_System.Text = "系統";
            this.Panel_System.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.Panel_System.TitleHeight = 28;
            // 
            // Panel_Mainti
            // 
            this.Panel_Mainti.Controls.Add(this.FLP_MaintiFlow);
            this.Panel_Mainti.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Panel_Mainti.Location = new System.Drawing.Point(14, 9);
            this.Panel_Mainti.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Panel_Mainti.MinimumSize = new System.Drawing.Size(1, 1);
            this.Panel_Mainti.Name = "Panel_Mainti";
            this.Panel_Mainti.Padding = new System.Windows.Forms.Padding(1, 28, 1, 1);
            this.Panel_Mainti.ShowText = false;
            this.Panel_Mainti.Size = new System.Drawing.Size(240, 315);
            this.Panel_Mainti.TabIndex = 4;
            this.Panel_Mainti.Text = "維護工單";
            this.Panel_Mainti.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.Panel_Mainti.TitleHeight = 28;
            // 
            // FLP_MaintiFlow
            // 
            this.FLP_MaintiFlow.Controls.Add(this.label1);
            this.FLP_MaintiFlow.Controls.Add(this.CBr_Mainti);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine4);
            this.FLP_MaintiFlow.Controls.Add(this.CBr_Summy);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine6);
            this.FLP_MaintiFlow.Controls.Add(this.CBr_Create);
            this.FLP_MaintiFlow.Controls.Add(this.CBr_Cancel);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine7);
            this.FLP_MaintiFlow.Controls.Add(this.CBr_Accept);
            this.FLP_MaintiFlow.Controls.Add(this.CBr_Transfer);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine8);
            this.FLP_MaintiFlow.Controls.Add(this.CBr_Maintant);
            this.FLP_MaintiFlow.Controls.Add(this.CBr_Confirm);
            this.FLP_MaintiFlow.Controls.Add(this.label2);
            this.FLP_MaintiFlow.Controls.Add(this.CBe_Mainti);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine5);
            this.FLP_MaintiFlow.Controls.Add(this.CBe_Summy);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine3);
            this.FLP_MaintiFlow.Controls.Add(this.CBe_Create);
            this.FLP_MaintiFlow.Controls.Add(this.CBe_Cancel);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine1);
            this.FLP_MaintiFlow.Controls.Add(this.CBe_Accept);
            this.FLP_MaintiFlow.Controls.Add(this.CBe_Transfer);
            this.FLP_MaintiFlow.Controls.Add(this.uiLine2);
            this.FLP_MaintiFlow.Controls.Add(this.CBe_Maintant);
            this.FLP_MaintiFlow.Controls.Add(this.CBe_Confirm);
            this.FLP_MaintiFlow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FLP_MaintiFlow.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.FLP_MaintiFlow.Location = new System.Drawing.Point(1, 28);
            this.FLP_MaintiFlow.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.FLP_MaintiFlow.Name = "FLP_MaintiFlow";
            this.FLP_MaintiFlow.Padding = new System.Windows.Forms.Padding(9);
            this.FLP_MaintiFlow.Size = new System.Drawing.Size(238, 286);
            this.FLP_MaintiFlow.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 19);
            this.label1.TabIndex = 20;
            this.label1.Text = "檢視";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // CBr_Mainti
            // 
            this.CBr_Mainti.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CBr_Mainti.CheckBoxSize = 18;
            this.CBr_Mainti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_Mainti.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_Mainti.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_Mainti.Location = new System.Drawing.Point(14, 28);
            this.CBr_Mainti.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_Mainti.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_Mainti.Name = "CBr_Mainti";
            this.CBr_Mainti.Size = new System.Drawing.Size(29, 29);
            this.CBr_Mainti.TabIndex = 23;
            this.CBr_Mainti.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CBr_Mainti.CheckedChanged += new System.EventHandler(this.CBr_Mainti_CheckedChanged);
            // 
            // uiLine4
            // 
            this.uiLine4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.uiLine4.BackColor = System.Drawing.Color.Transparent;
            this.uiLine4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine4.Location = new System.Drawing.Point(14, 57);
            this.uiLine4.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine4.Name = "uiLine4";
            this.uiLine4.Size = new System.Drawing.Size(29, 4);
            this.uiLine4.TabIndex = 24;
            // 
            // CBr_Summy
            // 
            this.CBr_Summy.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CBr_Summy.CheckBoxSize = 18;
            this.CBr_Summy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_Summy.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_Summy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_Summy.Location = new System.Drawing.Point(14, 61);
            this.CBr_Summy.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_Summy.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_Summy.Name = "CBr_Summy";
            this.CBr_Summy.Size = new System.Drawing.Size(29, 29);
            this.CBr_Summy.TabIndex = 18;
            this.CBr_Summy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine6
            // 
            this.uiLine6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.uiLine6.BackColor = System.Drawing.Color.Transparent;
            this.uiLine6.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine6.Location = new System.Drawing.Point(14, 90);
            this.uiLine6.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine6.Name = "uiLine6";
            this.uiLine6.Size = new System.Drawing.Size(29, 4);
            this.uiLine6.TabIndex = 19;
            // 
            // CBr_Create
            // 
            this.CBr_Create.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CBr_Create.CheckBoxSize = 18;
            this.CBr_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_Create.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_Create.Location = new System.Drawing.Point(14, 94);
            this.CBr_Create.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_Create.Name = "CBr_Create";
            this.CBr_Create.Size = new System.Drawing.Size(29, 29);
            this.CBr_Create.TabIndex = 10;
            this.CBr_Create.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBr_Cancel
            // 
            this.CBr_Cancel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CBr_Cancel.CheckBoxSize = 18;
            this.CBr_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_Cancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_Cancel.Location = new System.Drawing.Point(14, 123);
            this.CBr_Cancel.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_Cancel.Name = "CBr_Cancel";
            this.CBr_Cancel.Size = new System.Drawing.Size(29, 29);
            this.CBr_Cancel.TabIndex = 12;
            this.CBr_Cancel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine7
            // 
            this.uiLine7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.uiLine7.BackColor = System.Drawing.Color.Transparent;
            this.uiLine7.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine7.Location = new System.Drawing.Point(14, 152);
            this.uiLine7.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine7.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine7.Name = "uiLine7";
            this.uiLine7.Size = new System.Drawing.Size(29, 4);
            this.uiLine7.TabIndex = 14;
            // 
            // CBr_Accept
            // 
            this.CBr_Accept.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CBr_Accept.CheckBoxSize = 18;
            this.CBr_Accept.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_Accept.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_Accept.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_Accept.Location = new System.Drawing.Point(14, 156);
            this.CBr_Accept.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_Accept.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_Accept.Name = "CBr_Accept";
            this.CBr_Accept.Size = new System.Drawing.Size(29, 29);
            this.CBr_Accept.TabIndex = 11;
            this.CBr_Accept.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBr_Transfer
            // 
            this.CBr_Transfer.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CBr_Transfer.CheckBoxSize = 18;
            this.CBr_Transfer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_Transfer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_Transfer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_Transfer.Location = new System.Drawing.Point(14, 185);
            this.CBr_Transfer.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_Transfer.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_Transfer.Name = "CBr_Transfer";
            this.CBr_Transfer.Size = new System.Drawing.Size(29, 29);
            this.CBr_Transfer.TabIndex = 13;
            this.CBr_Transfer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine8
            // 
            this.uiLine8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.uiLine8.BackColor = System.Drawing.Color.Transparent;
            this.uiLine8.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine8.Location = new System.Drawing.Point(14, 214);
            this.uiLine8.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine8.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine8.Name = "uiLine8";
            this.uiLine8.Size = new System.Drawing.Size(29, 4);
            this.uiLine8.TabIndex = 15;
            // 
            // CBr_Maintant
            // 
            this.CBr_Maintant.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CBr_Maintant.CheckBoxSize = 18;
            this.CBr_Maintant.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBr_Maintant.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_Maintant.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_Maintant.Location = new System.Drawing.Point(14, 218);
            this.CBr_Maintant.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_Maintant.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_Maintant.Name = "CBr_Maintant";
            this.CBr_Maintant.Size = new System.Drawing.Size(29, 29);
            this.CBr_Maintant.TabIndex = 16;
            this.CBr_Maintant.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBr_Confirm
            // 
            this.CBr_Confirm.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.CBr_Confirm.CheckBoxSize = 18;
            this.CBr_Confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FLP_MaintiFlow.SetFlowBreak(this.CBr_Confirm, true);
            this.CBr_Confirm.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBr_Confirm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBr_Confirm.Location = new System.Drawing.Point(14, 247);
            this.CBr_Confirm.Margin = new System.Windows.Forms.Padding(0);
            this.CBr_Confirm.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBr_Confirm.Name = "CBr_Confirm";
            this.CBr_Confirm.Size = new System.Drawing.Size(29, 29);
            this.CBr_Confirm.TabIndex = 17;
            this.CBr_Confirm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(48, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(180, 19);
            this.label2.TabIndex = 21;
            this.label2.Text = "編輯";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // CBe_Mainti
            // 
            this.CBe_Mainti.CheckBoxSize = 18;
            this.CBe_Mainti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Mainti.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Mainti.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Mainti.Location = new System.Drawing.Point(48, 28);
            this.CBe_Mainti.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Mainti.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Mainti.Name = "CBe_Mainti";
            this.CBe_Mainti.Size = new System.Drawing.Size(180, 29);
            this.CBe_Mainti.TabIndex = 22;
            this.CBe_Mainti.Text = "維護工單";
            this.CBe_Mainti.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CBe_Mainti.CheckedChanged += new System.EventHandler(this.CBe_Mainti_CheckedChanged);
            // 
            // uiLine5
            // 
            this.uiLine5.BackColor = System.Drawing.Color.Transparent;
            this.uiLine5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine5.Location = new System.Drawing.Point(48, 57);
            this.uiLine5.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine5.Name = "uiLine5";
            this.uiLine5.Size = new System.Drawing.Size(180, 4);
            this.uiLine5.TabIndex = 25;
            // 
            // CBe_Summy
            // 
            this.CBe_Summy.CheckBoxSize = 18;
            this.CBe_Summy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Summy.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Summy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Summy.Location = new System.Drawing.Point(48, 61);
            this.CBe_Summy.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Summy.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Summy.Name = "CBe_Summy";
            this.CBe_Summy.Size = new System.Drawing.Size(180, 29);
            this.CBe_Summy.TabIndex = 8;
            this.CBe_Summy.Text = "維護總表";
            this.CBe_Summy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine3
            // 
            this.uiLine3.BackColor = System.Drawing.Color.Transparent;
            this.uiLine3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine3.Location = new System.Drawing.Point(48, 90);
            this.uiLine3.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine3.Name = "uiLine3";
            this.uiLine3.Size = new System.Drawing.Size(180, 4);
            this.uiLine3.TabIndex = 9;
            // 
            // CBe_Create
            // 
            this.CBe_Create.CheckBoxSize = 18;
            this.CBe_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Create.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Create.Location = new System.Drawing.Point(48, 94);
            this.CBe_Create.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Create.Name = "CBe_Create";
            this.CBe_Create.Size = new System.Drawing.Size(180, 29);
            this.CBe_Create.TabIndex = 0;
            this.CBe_Create.Text = "建立工單";
            this.CBe_Create.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_Cancel
            // 
            this.CBe_Cancel.CheckBoxSize = 18;
            this.CBe_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Cancel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Cancel.Location = new System.Drawing.Point(48, 123);
            this.CBe_Cancel.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Cancel.Name = "CBe_Cancel";
            this.CBe_Cancel.Size = new System.Drawing.Size(180, 29);
            this.CBe_Cancel.TabIndex = 2;
            this.CBe_Cancel.Text = "取消工單";
            this.CBe_Cancel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.Location = new System.Drawing.Point(48, 152);
            this.uiLine1.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(180, 4);
            this.uiLine1.TabIndex = 4;
            // 
            // CBe_Accept
            // 
            this.CBe_Accept.CheckBoxSize = 18;
            this.CBe_Accept.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Accept.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Accept.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Accept.Location = new System.Drawing.Point(48, 156);
            this.CBe_Accept.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Accept.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Accept.Name = "CBe_Accept";
            this.CBe_Accept.Size = new System.Drawing.Size(180, 29);
            this.CBe_Accept.TabIndex = 1;
            this.CBe_Accept.Text = "接單";
            this.CBe_Accept.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_Transfer
            // 
            this.CBe_Transfer.CheckBoxSize = 18;
            this.CBe_Transfer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Transfer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Transfer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Transfer.Location = new System.Drawing.Point(48, 185);
            this.CBe_Transfer.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Transfer.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Transfer.Name = "CBe_Transfer";
            this.CBe_Transfer.Size = new System.Drawing.Size(180, 29);
            this.CBe_Transfer.TabIndex = 3;
            this.CBe_Transfer.Text = "工單轉換";
            this.CBe_Transfer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine2
            // 
            this.uiLine2.BackColor = System.Drawing.Color.Transparent;
            this.uiLine2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine2.Location = new System.Drawing.Point(48, 214);
            this.uiLine2.Margin = new System.Windows.Forms.Padding(0);
            this.uiLine2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(180, 4);
            this.uiLine2.TabIndex = 5;
            // 
            // CBe_Maintant
            // 
            this.CBe_Maintant.CheckBoxSize = 18;
            this.CBe_Maintant.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Maintant.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Maintant.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Maintant.Location = new System.Drawing.Point(48, 218);
            this.CBe_Maintant.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Maintant.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Maintant.Name = "CBe_Maintant";
            this.CBe_Maintant.Size = new System.Drawing.Size(180, 29);
            this.CBe_Maintant.TabIndex = 6;
            this.CBe_Maintant.Text = "維護作業";
            this.CBe_Maintant.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CBe_Confirm
            // 
            this.CBe_Confirm.CheckBoxSize = 18;
            this.CBe_Confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBe_Confirm.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CBe_Confirm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CBe_Confirm.Location = new System.Drawing.Point(48, 247);
            this.CBe_Confirm.Margin = new System.Windows.Forms.Padding(0);
            this.CBe_Confirm.MinimumSize = new System.Drawing.Size(1, 1);
            this.CBe_Confirm.Name = "CBe_Confirm";
            this.CBe_Confirm.Size = new System.Drawing.Size(180, 29);
            this.CBe_Confirm.TabIndex = 7;
            this.CBe_Confirm.Text = "確認作業";
            this.CBe_Confirm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FLP_Page
            // 
            this.FLP_Page.Controls.Add(this.Panel_Mainti);
            this.FLP_Page.Controls.Add(this.Panel_System);
            this.FLP_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FLP_Page.Location = new System.Drawing.Point(0, 0);
            this.FLP_Page.Name = "FLP_Page";
            this.FLP_Page.Padding = new System.Windows.Forms.Padding(9);
            this.FLP_Page.Size = new System.Drawing.Size(519, 335);
            this.FLP_Page.TabIndex = 5;
            // 
            // Setup_Permission
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.FLP_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Setup_Permission";
            this.Size = new System.Drawing.Size(519, 335);
            this.FLP_System.ResumeLayout(false);
            this.FLP_System.PerformLayout();
            this.Panel_System.ResumeLayout(false);
            this.Panel_Mainti.ResumeLayout(false);
            this.FLP_MaintiFlow.ResumeLayout(false);
            this.FLP_MaintiFlow.PerformLayout();
            this.FLP_Page.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel FLP_System;
        private Sunny.UI.UICheckBox CBr_System;
        private Sunny.UI.UITitlePanel Panel_System;
        private Sunny.UI.UITitlePanel Panel_Mainti;
        private System.Windows.Forms.FlowLayoutPanel FLP_MaintiFlow;
        private Sunny.UI.UICheckBox CBe_Create;
        private Sunny.UI.UICheckBox CBe_Accept;
        private Sunny.UI.UICheckBox CBe_Cancel;
        private Sunny.UI.UICheckBox CBe_Transfer;
        private Sunny.UI.UILine uiLine1;
        private Sunny.UI.UICheckBox CBe_Summy;
        private Sunny.UI.UILine uiLine3;
        private Sunny.UI.UILine uiLine2;
        private Sunny.UI.UICheckBox CBe_Maintant;
        private Sunny.UI.UICheckBox CBe_Confirm;
        private System.Windows.Forms.FlowLayoutPanel FLP_Page;
        private Sunny.UI.UICheckBox CBe_System;
        private System.Windows.Forms.Label label1;
        private Sunny.UI.UICheckBox CBr_Summy;
        private Sunny.UI.UILine uiLine6;
        private Sunny.UI.UICheckBox CBr_Create;
        private Sunny.UI.UICheckBox CBr_Cancel;
        private Sunny.UI.UILine uiLine7;
        private Sunny.UI.UICheckBox CBr_Accept;
        private Sunny.UI.UICheckBox CBr_Transfer;
        private Sunny.UI.UILine uiLine8;
        private Sunny.UI.UICheckBox CBr_Maintant;
        private Sunny.UI.UICheckBox CBr_Confirm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Sunny.UI.UICheckBox CBr_Mainti;
        private Sunny.UI.UICheckBox CBe_Mainti;
        private Sunny.UI.UILine uiLine4;
        private Sunny.UI.UILine uiLine5;
        private Sunny.UI.UICheckBox uiCheckBox1;
        private Sunny.UI.UICheckBox uiCheckBox2;
    }
}
