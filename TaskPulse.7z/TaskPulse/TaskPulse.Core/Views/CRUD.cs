﻿using System;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class CRUD : UIForm
    {
        /// <summary>
        /// 字串返回值。
        /// </summary>
        public string ResultString { get; set; }

        private readonly ICore _core;
        private Func<string, (bool isValid, string errorMessage)> _validator;

        private UITextBox _inputTextBox;
        private UITextBox _uiTextBox;

        public CRUD(ICore core)
        {
            InitializeComponent();
            _core = core;
        }

        /********************
         * Form
         ********************/
        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            ResultString = "";
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            string input = _inputTextBox.Text;

            if (_validator != null)
            {
                var (isValid, errorMessage) = _validator(input);
                if (!isValid)
                {
                    UIMessageBox.ShowMessageDialog(errorMessage, "輸入錯誤", false, UIStyle.Red);
                    _inputTextBox.Focus();
                    return;
                }
            }

            ResultString = input;
            DialogResult = DialogResult.OK;
            this.Close();
        }

        /********************
         * Functions
         ********************/
        /// <summary>
        /// 一個 TextBox 的對話框。
        /// </summary>
        /// <param name="controlName">TextBox 的 Name 屬性值。</param>
        /// <param name="defaultValue">輸入的預設值。</param>
        /// <param name="caption">輸入提示。</param>
        /// <param name="title">標題。輸入空白字串則隱藏標題列。</param>
        /// <param name="watermark">TextBox 浮水印。</param>
        public void OneTextBox(string defaultValue,
                               string caption,
                               string title = "",
                               string watermark = "",
                               Func<string, (bool isValid, string errorMessage)> validator = null)
        {
            _validator = validator;
            this.ShowTitle = !string.IsNullOrWhiteSpace(title);
            this.Text = title;

            _core.CleanUpControls(leftFLP.Controls);
            leftFLP.Controls.Add(CreateNewLabelFromTemplate(caption));

            _core.CleanUpControls(rightFLP.Controls);
            _inputTextBox = CreateNewTextBoxFromTemplate(defaultValue, watermark);
            rightFLP.Controls.Add(_inputTextBox);
            _inputTextBox.Focus();
        }

        /// <summary>
        /// 二個 TextBox 的對話框。
        /// </summary>
        /// <param name="controlName">TextBox 的 Name 屬性值。</param>
        /// <param name="newValue">輸入的預設值。</param>
        /// <param name="oldValue">原值。</param>
        /// <param name="newCaption">新值的輸入提示。</param>
        /// <param name="oldCaption">原值的輸入提示。</param>
        /// <param name="title">標題。輸入空白字串則隱藏標題列。</param>
        /// <param name="oldWatermark">輸入 TextBox 浮水印。</param>
        /// <param name="newWatermark">原值 TextBox 浮水印。</param>
        public void TwoTextBox(string newValue,
                               string oldValue,
                               string newCaption,
                               string oldCaption,
                               string title = "",
                               string newWatermark = "",
                               Func<string, (bool isValid, string errorMessage)> validator = null)
        {
            _validator = validator;
            this.ShowTitle = !string.IsNullOrWhiteSpace(title);
            this.Text = title;

            _core.CleanUpControls(leftFLP.Controls);
            leftFLP.Controls.Add(CreateNewLabelFromTemplate(oldCaption));
            leftFLP.Controls.Add(CreateNewLabelFromTemplate(newCaption));

            _core.CleanUpControls(rightFLP.Controls);
            _uiTextBox = CreateNewTextBoxFromTemplate(oldValue, "");
            _uiTextBox.ReadOnly = true;
            _uiTextBox.TabStop = false;
            rightFLP.Controls.Add(_uiTextBox);

            _inputTextBox = CreateNewTextBoxFromTemplate(newValue, newWatermark);
            rightFLP.Controls.Add(_inputTextBox);
            _inputTextBox.Focus();
        }

        /********************
         * Control Template
         ********************/
        /// <summary>
        /// Label。
        /// </summary>
        private UILabel CreateNewLabelFromTemplate(string caption)
        {
            var control = new UILabel
            {
                AutoSize = LabelTemplate.AutoSize,
                Font = LabelTemplate.Font,
                ForeColor = LabelTemplate.ForeColor,
                Location = LabelTemplate.Location,
                Size = LabelTemplate.Size,
                TextAlign = LabelTemplate.TextAlign,
                Padding = LabelTemplate.Padding,
                Margin = LabelTemplate.Margin,
                Dock = LabelTemplate.Dock,
                Cursor = LabelTemplate.Cursor,
                BackColor = LabelTemplate.BackColor,
                Text = caption,
                Visible = true
            };
            control.Font = CommonStyles.Font;
            return control;
        }

        /// <summary>
        /// TextBox
        /// </summary>
        private UITextBox CreateNewTextBoxFromTemplate(string value, string watermark = "")
        {
            var control = new UITextBox
            {
                AutoSize = TextBoxTemplate.AutoSize,
                Font = TextBoxTemplate.Font,
                ForeColor = TextBoxTemplate.ForeColor,
                Location = TextBoxTemplate.Location,
                Size = TextBoxTemplate.Size,
                TextAlignment = TextBoxTemplate.TextAlignment,
                Padding = TextBoxTemplate.Padding,
                Margin = TextBoxTemplate.Margin,
                Dock = TextBoxTemplate.Dock,
                Cursor = TextBoxTemplate.Cursor,
                BackColor = TextBoxTemplate.BackColor,
                Text = value,
                Visible = true
            };
            control.Font = CommonStyles.Font;
            return control;
        }
    }
}
