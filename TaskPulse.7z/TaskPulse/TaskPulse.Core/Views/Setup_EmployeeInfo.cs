﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_EmployeeInfo : UIUserControl
    {
        #region fields

        private readonly ILifetimeScope _scope;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly FieldTitle _fieldTitle;
        private readonly Setup_Permission _permission;

        private readonly DbSet<Department> _departments;
        private readonly DbSet<Title> _titles;

        private List<ListViewModel> _vmDepartments = null;
        private ListViewModel _vmDep = null;
        private List<ListViewModel> _vmTitles = null;
        private ListViewModel _vmTitle = null;

        #endregion fields

        public Setup_EmployeeInfo(ILifetimeScope lifetimeScope,
                                  CoreContext coreContext,
                                  CoreData coreData,
                                  FieldTitle fieldTitle,
                                  Setup_Permission permission)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _context = coreContext;
            _coreData = coreData;
            _fieldTitle = fieldTitle;
            _permission = permission;

            _departments = _context.Departments;
            _titles = _context.Titles;

            string itemName = _fieldTitle.Department;
            Label_Department.Text = itemName;
            CommonStyles.SetListBox(LB_Departments);
            CommonStyles.SetCrudButton(Department_Create, "C", itemName);
            CommonStyles.SetCrudButton(Department_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Department_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Department_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Department_Down, "DOWN", itemName);

            itemName = _fieldTitle.Title;
            Label_Title.Text = itemName;
            CommonStyles.SetListBox(LB_Titles);
            CommonStyles.SetCrudButton(Title_Create, "C", itemName);
            CommonStyles.SetCrudButton(Title_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Title_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Title_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Title_Down, "DOWN", itemName);
        }

        private async void EmployeeInfo_Load(object sender, EventArgs e)
        {
            await UpdateDepartmentView();
            await UpdateTitleView();

            //_core.CleanUpControls(TP_Permission.Controls);
            Panel_Permission.Controls.Add(_permission);
            StrongReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                new PermissionSettingInfo()
                {
                    PermissionSource = PermissionSource.Employee,
                }));
        }

        /********************
         * Department
         ********************/
        private async Task UpdateDepartmentView()
        {
            _vmDepartments = await _departments
                .Select(d => new ListViewModel()
                {
                    Id = d.Id,
                    Name = d.DepartmentName,
                })
                .ToListAsync();

            LB_Departments.DisplayMember = nameof(ListViewModel.Name);
            LB_Departments.ValueMember = nameof(ListViewModel.Id);
            LB_Departments.DataSource = _vmDepartments;
        }





        /********************
         * Title
         ********************/
        private async Task UpdateTitleView()
        {
            _vmTitles = await _titles
                .Select(d => new ListViewModel()
                {
                    Id = d.Id,
                    Name = d.TitleName,
                })
                .ToListAsync();

            LB_Titles.DisplayMember = nameof(ListViewModel.Name);
            LB_Titles.ValueMember = nameof(ListViewModel.Id);
            LB_Titles.DataSource = _vmTitles;
        }
    }
}
