﻿using System;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.NavServices;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Views
{
    public partial class SetupPage : UserControl
    {
        private readonly IRegionManager _region;
        private readonly INavigationService _navigation;
        private readonly ILifetimeScope _rootScope;
        private readonly ILifetimeScope _currentScope;
        private readonly IPermissionService _permission;

        private UserControl _currentPage;
        private PageCode _currentPageCode = PageCode.None;

        public SetupPage(IRegionManager regionManager,
                         INavigationService navigationService,
                         ILifetimeScope rootScope,
                         IPermissionService permissionService)
        {
            InitializeComponent();
            _region = regionManager;
            _navigation = navigationService;
            _rootScope = rootScope;
            _permission = permissionService;

            _region.RegisterRegion(nameof(SetupRegion), SetupRegion);
            TreeView_SetupMenu.SelectedColor = CommonStyles.BackColor;

            //WeakReferenceMessenger.Default.Register<CurrentUserChangedMessage>(this, (sender, e) =>
            //{
            bool mPerm = _permission.HasControlAccess(PermissionWords.MODULE_SETUP, PermissionWords.PAGE_MACHINE_MANAGER);
            bool ePerm = _permission.HasControlAccess(PermissionWords.MODULE_SETUP, PermissionWords.PAGE_EMPLOYEE_MANAGER);

            TreeNode parent;
            TreeNode child1;
            TreeNode child2;

            TreeView_SetupMenu.Nodes.Clear();

            /***** 維護工單 *****/

            /***** 工具委託 *****/

            /***** 專案管理 *****/

            /***** 基本資料管理 *****/
            //if (mPerm)
            //{
            parent = new TreeNode(PageCode.Machines.GetDescription());
            parent.Tag = (int)PageCode.Machines;
            TreeView_SetupMenu.Nodes.Add(parent);

            child1 = new TreeNode(PageCode.MachinesSummary.GetDescription());
            child1.Tag = (int)PageCode.MachinesSummary;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.MachineInfo1.GetDescription());
            child1.Tag = (int)PageCode.MachineInfo1;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.MachineInfo2.GetDescription());
            child1.Tag = (int)PageCode.MachineInfo2;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.Models.GetDescription());
            child1.Tag = (int)PageCode.Models;
            parent.Nodes.Add(child1);
            //}

            //if (ePerm)
            //{
            parent = new TreeNode(PageCode.EmployeesManagement.GetDescription());
            parent.Tag = (int)PageCode.EmployeesManagement;
            TreeView_SetupMenu.Nodes.Add(parent);

            child1 = new TreeNode(PageCode.Employees.GetDescription());
            child1.Tag = (int)PageCode.Employees;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.EmployeeInfo.GetDescription());
            child1.Tag = (int)PageCode.EmployeeInfo;
            parent.Nodes.Add(child1);
            //}

            TreeView_SetupMenu.ExpandAll();
            //});
        }

        private void SetupPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        private void TreeView_SetupMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (Enum.TryParse(e.Node.Tag.ToString(), out PageCode pageCode))
            {
                if (_currentPageCode == pageCode)
                    return;

                switch (pageCode)
                {
                    case PageCode.MachinesSummary:
                        _navigation.Navigate<Setup_MachinesSummary>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.MachineInfo1:
                        _navigation.Navigate<Setup_MachineInfo1>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.MachineInfo2:
                        _navigation.Navigate<Setup_MachineInfo2>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.Models:
                        _navigation.Navigate<Setup_Models>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.Employees:
                        _navigation.Navigate<Setup_Employees>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.EmployeeInfo:
                        _navigation.Navigate<Setup_EmployeeInfo>(nameof(SetupRegion), alive: true);
                        break;

                    //case PageCode.Setup_Permission:
                    //    break;

                    default:
                        return;
                }

                //_currentPage.Dock = DockStyle.Fill;
                //SetupRegion.Controls.Clear();
                //SetupRegion.Controls.Add(_currentPage);
                _currentPageCode = pageCode;
            }
        }

        private void TreeView_SetupMenu_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.IsExpanded)
                e.Node.Collapse();
            else
                e.Node.Expand();

            TreeView_SetupMenu.SelectedNode = e.Node;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                if (!DesignMode)
                    _currentScope?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
