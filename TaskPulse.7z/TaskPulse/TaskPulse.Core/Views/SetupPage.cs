﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class SetupPage : UIPage
    {
        private readonly Setup_MachinesSummary _setupMachinesSummary;
        private readonly Setup_MachineInfo1 _setupMachineInfo1;
        private readonly Setup_MachineInfo2 _setupMachineInfo2;
        private readonly Setup_Models _setupModels;

        public SetupPage(Setup_MachinesSummary setup_MachinesSummary,
                         Setup_MachineInfo1 setup_MachineInfo1,
                         Setup_MachineInfo2 setup_MachineInfo2,
                         Setup_Models setup_Models)
        {
            InitializeComponent();
            _setupMachinesSummary = setup_MachinesSummary;
            _setupMachineInfo1 = setup_MachineInfo1;
            _setupMachineInfo2 = setup_MachineInfo2;
            _setupModels = setup_Models;

            uiTreeView_SetupMenu.SelectedColor = CommonStyles.BackColor;

            TreeNode parent;
            TreeNode child1;
            TreeNode child2;

            /***** 維護工單 *****/

            parent = new TreeNode(PageCode.MachinesSummary.GetDescription());
            parent.Tag = (int)PageCode.MachinesSummary;
            uiTreeView_SetupMenu.Nodes.Add(parent);

            /***** 工具委託 *****/

            /***** 專案管理 *****/

            /***** 基本資料管理 *****/
            parent = new TreeNode("基本資料管理");
            parent.Tag = -1;
            uiTreeView_SetupMenu.Nodes.Add(parent);

            child1 = new TreeNode(PageCode.Employees.GetDescription());
            child1.Tag = (int)PageCode.Employees;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.Authority.GetDescription());
            child1.Tag = (int)PageCode.Authority;
            parent.Nodes.Add(child1);

            //parent = new TreeNode(PageCode.MaintiFlow.GetDescription());
            //parent.Tag = -1;
            //uiTreeView_SetupMenu.Nodes.Add(parent);

            child1 = new TreeNode(PageCode.Machines.GetDescription());
            child1.Tag = (int)PageCode.Machines;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.MachinesInfo1.GetDescription());
            child1.Tag = (int)PageCode.MachinesInfo1;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.MachinesInfo2.GetDescription());
            child1.Tag = (int)PageCode.MachinesInfo2;
            parent.Nodes.Add(child1);

            child1 = new TreeNode(PageCode.Models.GetDescription());
            child1.Tag = (int)PageCode.Models;
            parent.Nodes.Add(child1);

            uiTreeView_SetupMenu.ExpandAll();
        }

        private void uiTreeView_SetupMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (Enum.TryParse(e.Node.Tag.ToString(), out PageCode itemCode))
            {
                UIUserControl control = default;

                switch (itemCode)
                {
                    //case PageCode.Employees:
                    //    break;

                    //case PageCode.Authority:
                    //    break;

                    case PageCode.Models:
                        control = _setupModels;
                        break;

                    case PageCode.MachinesSummary:
                        control = _setupMachinesSummary;
                        break;

                    case PageCode.MachinesInfo1:
                        control = _setupMachineInfo1;
                        break;

                    case PageCode.MachinesInfo2:
                        control = _setupMachineInfo2;
                        break;

                    default:
                        return;
                }

                if (control != null)
                {
                    control.Dock = DockStyle.Fill;
                    panel_Setup.Controls.Clear();
                    panel_Setup.Controls.Add(control);
                }
            }
        }

        private void uiTreeView_SetupMenu_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.IsExpanded)
                e.Node.Collapse();
            else
                e.Node.Expand();

            uiTreeView_SetupMenu.SelectedNode = e.Node;
        }
    }
}
