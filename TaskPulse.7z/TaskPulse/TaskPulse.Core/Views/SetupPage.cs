﻿using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class SetupPage : UIPage
    {
        public SetupPage()
        {
            InitializeComponent();
        }
    }
}
