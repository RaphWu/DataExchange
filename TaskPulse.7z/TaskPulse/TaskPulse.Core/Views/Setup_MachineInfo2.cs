﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineInfo2 : UIUserControl
    {
        #region fields

        private readonly ILifetimeScope _scope;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly FieldTitle _fieldTitle;

        private readonly DbSet<MachineCategory> _categories;
        private readonly DbSet<MachineType> _types;
        private readonly DbSet<MachineName> _names;

        private List<ListViewModel> _vmCategories = null;
        private ListViewModel _vmCategory = null;
        private List<ListViewModel> _vmTypes = null;
        private ListViewModel _vmType = null;
        private List<ListViewModel> _vmNames = null;
        private ListViewModel _vmName = null;

        #endregion fields

        public Setup_MachineInfo2(ILifetimeScope lifetimeScope,
                                  CoreContext coreContext,
                                  CoreData coreData,
                                  FieldTitle fieldTitle)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _context = coreContext;
            _coreData = coreData;
            _fieldTitle = fieldTitle;

            _categories = _context.MachineCategories;
            _types = _context.MachineTypes;
            _names = _context.MachineNames;

            string itemName = _fieldTitle.MachineCategory;
            HeadLabel_Category.Text = itemName;
            CommonStyles.SetListBox(List_Categories);
            CommonStyles.SetCrudButton(Category_Create, "C", itemName);
            CommonStyles.SetCrudButton(Category_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Category_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Category_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Category_Down, "DOWN", itemName);

            itemName = _fieldTitle.MachineType;
            HeadLabel_Type.Text = itemName;
            CommonStyles.SetListBox(List_Types);
            CommonStyles.SetCrudButton(Type_Create, "C", itemName);
            CommonStyles.SetCrudButton(Type_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Type_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Type_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Type_Down, "DOWN", itemName);

            itemName = _fieldTitle.MachineName;
            HeadLabel_Name.Text = itemName;
            CommonStyles.SetListBox(List_Names);
            CommonStyles.SetCrudButton(Name_Create, "C", itemName);
            CommonStyles.SetCrudButton(Name_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Name_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Name_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Name_Down, "DOWN", itemName);
        }

        private async void Setup_MachineInfo2_Load(object sender, EventArgs e)
        {
            await UpdateCategoriesView();
            //await UpdateTypesView();
            //await UpdateNamesView();
        }

        #region Category

        /********************
         * Category
         ********************/
        private async Task UpdateCategoriesView()
        {
            var query = await _context.MachineCategories
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmCategories = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.CategoryName, OrderNo = b.OrderNo })
                .ToList();
            List_Categories.DataSource = null;
            List_Categories.ValueMember = nameof(ListViewModel.Id);
            List_Categories.DisplayMember = nameof(ListViewModel.Name);
            List_Categories.DataSource = _vmCategories;
        }

        private async void List_Categories_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmCategory = List_Categories.SelectedItem as ListViewModel;
            if (_vmCategory != null)
            {
                Category_Edit.Enabled = true;
                Category_Delete.Enabled = true;

                if (List_Categories.DataSource is List<ListViewModel> vmCategory)
                {
                    var vmOrderNo = vmCategory.FirstOrDefault(w => w.Id == _vmCategory.Id).OrderNo;
                    Category_Up.Enabled = vmOrderNo != vmCategory.Min(w => w.OrderNo);
                    Category_Down.Enabled = vmOrderNo != vmCategory.Max(w => w.OrderNo);
                    await UpdateTypesView();
                }
                else
                {
                    Category_Up.Enabled = false;
                    Category_Down.Enabled = false;
                }
            }
            else
            {
                Category_Edit.Enabled = false;
                Category_Delete.Enabled = false;
                Category_Up.Enabled = false;
                Category_Down.Enabled = false;
            }
        }

        private async void Category_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{_fieldTitle.MachineCategory}名稱";
            string caption = $"新{_fieldTitle.MachineCategory}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.MachineCategory}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.MachineCategory}名稱必須小於等於 30 個字元！"),
                input => _categories.Any(m => m.CategoryName == input) ? (false, $"{_fieldTitle.MachineCategory}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newMachineCategoryName = crud.Result.StringValue;
                    int maxOrderNo = _categories.Max(w => w.OrderNo);

                    _context.MachineCategories.Add(new MachineCategory()
                    {
                        CategoryName = newMachineCategoryName,
                        OrderNo = maxOrderNo + 1,
                    });
                    await _context.SaveChangesAsync();
                    await UpdateCategoriesView();
                    List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Name == newMachineCategoryName);

                    MessageBox.Show($"已增加新{_fieldTitle.MachineCategory}: {newMachineCategoryName}",
                                    $"新增成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void Category_Edit_Click(object sender, EventArgs e)
        {
            if (_vmCategory != null)
            {
                var thisCategory = _vmCategory;
                string title = $"請輸入新{_fieldTitle.MachineCategory}名稱";
                string oldCaption = $"原{_fieldTitle.MachineCategory}名稱";
                string newCaption = $"新{_fieldTitle.MachineCategory}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.MachineCategory}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.MachineCategory}名稱必須小於等於 30 個字元！"),
                    input => _categories.Any(m => m.CategoryName == input) ? (false, $"{_fieldTitle.MachineCategory}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisCategory.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        string newCategoryName = crud.Result.StringValue;

                        var newCategory = _categories.FirstOrDefault(m => m.Id == thisCategory.Id);
                        if (newCategory != null)
                        {
                            newCategory.CategoryName = newCategoryName;
                            await _context.SaveChangesAsync();
                            await UpdateCategoriesView();
                            List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == newCategory.Id);

                            MessageBox.Show($"{_fieldTitle.MachineCategory} {thisCategory.Name} 名稱已更新為 {newCategoryName}",
                                            $"更新成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private async void Category_Delete_Click(object sender, EventArgs e)
        {
            if (_vmCategory != null)
            {
                var thisCategory = _vmCategory;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {_fieldTitle.MachineCategory} {thisCategory.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetCategory = _categories.FirstOrDefault(m => m.Id == thisCategory.Id);
                    if (targetCategory != null)
                    {
                        _categories.Remove(targetCategory);
                        await _context.SaveChangesAsync();
                        await UpdateCategoriesView();

                        MessageBox.Show($"{_fieldTitle.MachineCategory} {thisCategory.Name} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Category_Up_Click(object sender, EventArgs e)
        {
            if (_vmCategory != null)
            {
                var thisVmWs = _vmCategory;
                var smallerVmWs = _vmCategories.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapCategoryOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Category_Down_Click(object sender, EventArgs e)
        {
            if (_vmCategory != null)
            {
                var thisVm = _vmCategory;
                var biggerVm = _vmCategories.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapCategoryOrderNo(thisVm.Id, biggerVm.Id);
                    List_Categories.SelectedIndex = _vmCategories.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapCategoryOrderNo(int id1, int id2)
        {
            var entity1 = _categories.FirstOrDefault(w => w.Id == id1);
            var entity2 = _categories.FirstOrDefault(w => w.Id == id2);

            (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
            await _context.SaveChangesAsync();
            await UpdateCategoriesView();
        }

        #endregion Category

        #region Type

        /********************
         * TypeName
         ********************/
        private async Task UpdateTypesView()
        {
            List_Types.DataSource = null;
            if (_vmCategory != null)
            {
                var query = await _context.MachineTypes
                    .Where(m => m.CategoryId == _vmCategory.Id)
                    .OrderBy(b => b.OrderNo)
                    .ToListAsync();
                _vmCategories = query
                    .Select(b => new ListViewModel { Id = b.Id, Name = b.TypeName, OrderNo = b.OrderNo })
                    .ToList();
                List_Types.ValueMember = nameof(ListViewModel.Id);
                List_Types.DisplayMember = nameof(ListViewModel.Name);
                List_Types.DataSource = _vmCategories;
            }
            else
            {
                _vmCategories = null;
            }
        }

        private async void List_Types_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmType = List_Types.SelectedItem as ListViewModel;
            if (_vmType != null)
            {
                Type_Edit.Enabled = true;
                Type_Delete.Enabled = true;

                if (List_Types.DataSource is List<ListViewModel> vmType)
                {
                    var vmOrderNo = vmType.FirstOrDefault(w => w.Id == _vmType.Id).OrderNo;
                    Type_Up.Enabled = vmOrderNo != vmType.Min(w => w.OrderNo);
                    Type_Down.Enabled = vmOrderNo != vmType.Max(w => w.OrderNo);
                    await UpdateNamesView();
                }
                else
                {
                    Type_Up.Enabled = false;
                    Type_Down.Enabled = false;
                }
            }
            else
            {
                Type_Edit.Enabled = false;
                Type_Delete.Enabled = false;
                Type_Up.Enabled = false;
                Type_Down.Enabled = false;
            }
        }

        private async void Type_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{_fieldTitle.MachineType}名稱";
            string caption = $"新{_fieldTitle.MachineType}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.MachineType}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.MachineType}名稱必須小於等於 30 個字元！"),
                input => _types.Any(m => m.TypeName == input) ? (false, $"{_fieldTitle.MachineType}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newTypeName = crud.Result.StringValue;
                    int maxOrderNo = _types.Max(w => w.OrderNo);

                    _context.MachineTypes.Add(new MachineType() { TypeName = newTypeName, OrderNo = maxOrderNo + 1 });
                    await _context.SaveChangesAsync();
                    await UpdateTypesView();
                    List_Types.SelectedIndex = _vmTypes.FindIndex(m => m.Name == newTypeName);

                    MessageBox.Show($"已增加新{_fieldTitle.MachineType}: {newTypeName}",
                                    $"新增成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void Type_Edit_Click(object sender, EventArgs e)
        {
            if (_vmType != null)
            {
                var thisType = _vmType;
                string title = $"請輸入新{_fieldTitle.MachineType}名稱";
                string oldCaption = $"原{_fieldTitle.MachineType}名稱";
                string newCaption = $"新{_fieldTitle.MachineType}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.MachineType}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.MachineType}名稱必須小於等於 30 個字元！"),
                    input => _types.Any(m => m.TypeName == input) ? (false, $"{_fieldTitle.MachineType}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisType.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        string newTypeName = crud.Result.StringValue;

                        var newType = _types.FirstOrDefault(m => m.Id == thisType.Id);
                        if (newType != null)
                        {
                            newType.TypeName = newTypeName;
                            await _context.SaveChangesAsync();
                            await UpdateTypesView();
                            List_Types.SelectedIndex = _vmTypes.FindIndex(m => m.Id == newType.Id);

                            MessageBox.Show($"{_fieldTitle.MachineType} {thisType.Name} 名稱已更新為 {newTypeName}",
                                            $"更新成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private async void Type_Delete_Click(object sender, EventArgs e)
        {
            if (_vmType != null)
            {
                var thisType = _vmType;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {_fieldTitle.MachineType} {thisType.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetType = _types.FirstOrDefault(m => m.Id == thisType.Id);
                    if (targetType != null)
                    {
                        _types.Remove(targetType);
                        await _context.SaveChangesAsync();
                        await UpdateTypesView();

                        MessageBox.Show($"{_fieldTitle.MachineType} {thisType.Name} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Type_Up_Click(object sender, EventArgs e)
        {
            if (_vmType != null)
            {
                var thisVmWs = _vmType;
                var smallerVmWs = _vmTypes.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapTypeOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Types.SelectedIndex = _vmTypes.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Type_Down_Click(object sender, EventArgs e)
        {
            if (_vmType != null)
            {
                var thisVm = _vmType;
                var biggerVm = _vmTypes.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapTypeOrderNo(thisVm.Id, biggerVm.Id);
                    List_Types.SelectedIndex = _vmTypes.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapTypeOrderNo(int id1, int id2)
        {
            var entity1 = _types.FirstOrDefault(w => w.Id == id1);
            var entity2 = _types.FirstOrDefault(w => w.Id == id2);

            (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
            await _context.SaveChangesAsync();
            await UpdateTypesView();
        }

        #endregion Type

        #region Name

        /********************
         * Names
         ********************/
        private async Task UpdateNamesView()
        {
            List_Names.DataSource = null;
            if (_vmType != null)
            {
                var query = await _context.MachineNames
                    .Where(m => m.TypeId == _vmType.Id)
                    .ToListAsync();
                _vmNames = query
                    .Select(b => new ListViewModel { Id = b.Id, Name = b.ModelName, OrderNo = b.OrderNo })
                    .ToList();
                List_Names.ValueMember = nameof(ListViewModel.Id);
                List_Names.DisplayMember = nameof(ListViewModel.Name);
                List_Names.DataSource = _vmNames;
            }
            else
            {
                _vmNames = null;
            }
        }

        private void List_Names_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmName = List_Names.SelectedItem as ListViewModel;
            if (_vmName != null)
            {
                Name_Edit.Enabled = true;
                Name_Delete.Enabled = true;

                if (List_Names.DataSource is List<ListViewModel> vmName)
                {
                    var vmOrderNo = vmName.FirstOrDefault(w => w.Id == _vmName.Id).OrderNo;
                    Name_Up.Enabled = vmOrderNo != vmName.Min(w => w.OrderNo);
                    Name_Down.Enabled = vmOrderNo != vmName.Max(w => w.OrderNo);
                }
                else
                {
                    Name_Up.Enabled = false;
                    Name_Down.Enabled = false;
                }
            }
            else
            {
                Name_Edit.Enabled = false;
                Name_Delete.Enabled = false;
                Name_Up.Enabled = false;
                Name_Down.Enabled = false;
            }
        }

        private async void Name_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{_fieldTitle.MachineName}名稱";
            string caption = $"新{_fieldTitle.MachineName}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.MachineName}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.MachineName}名稱必須小於等於 30 個字元！"),
                input => _names.Any(m => m.ModelName == input) ? (false, $"{_fieldTitle.MachineName}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newNameName = crud.Result.StringValue;
                    int maxOrderNo = _names.Max(w => w.OrderNo);

                    _context.MachineNames.Add(new MachineName() { ModelName = newNameName, OrderNo = maxOrderNo + 1 });
                    await _context.SaveChangesAsync();
                    await UpdateNamesView();
                    List_Names.SelectedIndex = _vmNames.FindIndex(m => m.Name == newNameName);

                    MessageBox.Show($"已增加新{_fieldTitle.MachineName}: {newNameName}",
                                    $"新增成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void Name_Edit_Click(object sender, EventArgs e)
        {
            if (_vmName != null)
            {
                var thisName = _vmName;
                string title = $"請輸入新{_fieldTitle.MachineName}名稱";
                string oldCaption = $"原{_fieldTitle.MachineName}名稱";
                string newCaption = $"新{_fieldTitle.MachineName}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.MachineName}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.MachineName}名稱必須小於等於 30 個字元！"),
                    input => _names.Any(m => m.ModelName == input) ? (false, $"{_fieldTitle.MachineName}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisName.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        string newNameName = crud.Result.StringValue;

                        var newName = _names.FirstOrDefault(m => m.Id == thisName.Id);
                        if (newName != null)
                        {
                            newName.ModelName = newNameName;
                            await _context.SaveChangesAsync();
                            await UpdateNamesView();
                            List_Names.SelectedIndex = _vmNames.FindIndex(m => m.Id == newName.Id);

                            MessageBox.Show($"{_fieldTitle.MachineName} {thisName.Name} 名稱已更新為 {newNameName}",
                                            $"更新成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private async void Name_Delete_Click(object sender, EventArgs e)
        {
            if (_vmName != null)
            {
                var thisName = _vmName;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {_fieldTitle.MachineName} {thisName.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetName = _names.FirstOrDefault(m => m.Id == thisName.Id);
                    if (targetName != null)
                    {
                        _names.Remove(targetName);
                        await _context.SaveChangesAsync();
                        await UpdateNamesView();

                        MessageBox.Show($"{_fieldTitle.MachineName} {thisName.Name} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Name_Up_Click(object sender, EventArgs e)
        {
            if (_vmName != null)
            {
                var thisVmWs = _vmName;
                var smallerVmWs = _vmNames.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapNameOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Names.SelectedIndex = _vmNames.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Name_Down_Click(object sender, EventArgs e)
        {
            if (_vmName != null)
            {
                var thisVm = _vmName;
                var biggerVm = _vmNames.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapNameOrderNo(thisVm.Id, biggerVm.Id);
                    List_Names.SelectedIndex = _vmNames.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapNameOrderNo(int id1, int id2)
        {
            var entity1 = _names.FirstOrDefault(w => w.Id == id1);
            var entity2 = _names.FirstOrDefault(w => w.Id == id2);

            (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
            await _context.SaveChangesAsync();
            await UpdateNamesView();
        }

        #endregion Name
    }
}
