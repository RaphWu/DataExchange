﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineInfo2 : UIUserControl
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly CoreFieldName _fieldName;
        private readonly CRUD _crud;

        private List<ListViewModel> _vmCategories = null;
        private ListViewModel _vmCategory = null;
        private List<ListViewModel> _vmLocs = null;
        private ListViewModel _vmLoc = null;
        private List<ListViewModel> _vmNames = null;
        private ListViewModel _vmName = null;

        #endregion fields

        public Setup_MachineInfo2(CoreContext coreContext,
                                  CoreData coreData,
                                  CoreFieldName coreFieldName,
                                  CRUD crud)
        {
            InitializeComponent();
            _context = coreContext;
            _coreData = coreData;
            _fieldName = coreFieldName;
            _crud = crud;

            // 廠牌
            HeadLabel_Category.Text = _fieldName.MachineCategory;
            List_Categories.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Categories.ScrollBarColor = CommonStyles.BackColor;

            Category_Create.FillColor = CommonStyles.BackColor;
            Category_Edit.FillColor = CommonStyles.BackColor;
            Category_Delete.FillColor = CommonStyles.BackColor;
            Category_Up.FillColor = CommonStyles.BackColor;
            Category_Down.FillColor = CommonStyles.BackColor;

            // 位置
            HeadLabel_Type.Text = _fieldName.MachineType;
            List_Types.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Types.ScrollBarColor = CommonStyles.BackColor;

            Type_Create.FillColor = CommonStyles.BackColor;
            Type_Edit.FillColor = CommonStyles.BackColor;
            Type_Delete.FillColor = CommonStyles.BackColor;
            Type_Up.FillColor = CommonStyles.BackColor;
            Type_Down.FillColor = CommonStyles.BackColor;

            // 狀態
            HeadLabel_Name.Text = _fieldName.MachineName;
            List_Names.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Names.ScrollBarColor = CommonStyles.BackColor;

            Name_Create.FillColor = CommonStyles.BackColor;
            Name_Edit.FillColor = CommonStyles.BackColor;
            Name_Delete.FillColor = CommonStyles.BackColor;
            Name_Up.FillColor = CommonStyles.BackColor;
            Name_Down.FillColor = CommonStyles.BackColor;
        }

        private async void Setup_MachineInfo2_Load(object sender, EventArgs e)
        {
            await UpdateCategoriesView();
            await UpdateTypesView();
            await UpdateNamesView();
        }

        /********************
         * Category
         ********************/
        private async Task UpdateCategoriesView()
        {
            var query = await _context.MachineCategories
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmCategories = query
                .Select(b => new ListViewModel { Key = b.Id, Value = b.CategoryName, OrderNo = b.OrderNo })
                .ToList();
            List_Categories.DataSource = null;
            List_Categories.ValueMember = nameof(ListViewModel.Key);
            List_Categories.DisplayMember = nameof(ListViewModel.Value);
            List_Categories.DataSource = _vmCategories;
        }


        /********************
         * Type
         ********************/
        private async Task UpdateTypesView()
        {
            var query = await _context.MachineTypes
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmCategories = query
                .Select(b => new ListViewModel { Key = b.Id, Value = b.TypeName, OrderNo = b.OrderNo })
                .ToList();
            List_Types.DataSource = null;
            List_Types.ValueMember = nameof(ListViewModel.Key);
            List_Types.DisplayMember = nameof(ListViewModel.Value);
            List_Types.DataSource = _vmCategories;
        }




        /********************
         * Names
         ********************/
        private async Task UpdateNamesView()
        {
            var query = await _context.MachineNames
                .ToListAsync();
            _vmNames = query
                .Select(b => new ListViewModel { Key = b.Id, Value = b.ModelName })
                .ToList();
            List_Names.DataSource = null;
            List_Names.ValueMember = nameof(ListViewModel.Key);
            List_Names.DisplayMember = nameof(ListViewModel.Value);
            List_Names.DataSource = _vmNames;
        }
    }
}
