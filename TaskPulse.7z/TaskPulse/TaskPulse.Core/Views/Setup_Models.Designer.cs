﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Models
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.WorkStation_Up = new Sunny.UI.UISymbolButton();
            this.WorkStation_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.WorkStation_Create = new Sunny.UI.UISymbolButton();
            this.WorkStation_Edit = new Sunny.UI.UISymbolButton();
            this.WorkStation_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Model_Create = new Sunny.UI.UISymbolButton();
            this.Model_Edit = new Sunny.UI.UISymbolButton();
            this.Model_Delete = new Sunny.UI.UISymbolButton();
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.dgv_Models = new Sunny.UI.UIDataGridView();
            this.dgv_Workstations = new Sunny.UI.UIDataGridView();
            this.Button_Refresh = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel_Page.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Models)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Workstations)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel3.AutoSize = true;
            this.flowLayoutPanel3.Controls.Add(this.WorkStation_Up);
            this.flowLayoutPanel3.Controls.Add(this.WorkStation_Down);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(231, 139);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel3.TabIndex = 6;
            // 
            // WorkStation_Up
            // 
            this.WorkStation_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WorkStation_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkStation_Up.Location = new System.Drawing.Point(0, 9);
            this.WorkStation_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.WorkStation_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.WorkStation_Up.Name = "WorkStation_Up";
            this.WorkStation_Up.Size = new System.Drawing.Size(30, 30);
            this.WorkStation_Up.Symbol = 361702;
            this.WorkStation_Up.SymbolSize = 32;
            this.WorkStation_Up.TabIndex = 2;
            this.WorkStation_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // WorkStation_Down
            // 
            this.WorkStation_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WorkStation_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkStation_Down.Location = new System.Drawing.Point(0, 57);
            this.WorkStation_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.WorkStation_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.WorkStation_Down.Name = "WorkStation_Down";
            this.WorkStation_Down.Size = new System.Drawing.Size(30, 30);
            this.WorkStation_Down.Symbol = 361703;
            this.WorkStation_Down.SymbolSize = 32;
            this.WorkStation_Down.TabIndex = 4;
            this.WorkStation_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.Controls.Add(this.WorkStation_Create);
            this.flowLayoutPanel4.Controls.Add(this.WorkStation_Edit);
            this.flowLayoutPanel4.Controls.Add(this.WorkStation_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(287, 629);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 5;
            // 
            // WorkStation_Create
            // 
            this.WorkStation_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WorkStation_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkStation_Create.Location = new System.Drawing.Point(9, 0);
            this.WorkStation_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.WorkStation_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.WorkStation_Create.Name = "WorkStation_Create";
            this.WorkStation_Create.Size = new System.Drawing.Size(30, 30);
            this.WorkStation_Create.Symbol = 557669;
            this.WorkStation_Create.SymbolSize = 32;
            this.WorkStation_Create.TabIndex = 2;
            this.WorkStation_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // WorkStation_Edit
            // 
            this.WorkStation_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WorkStation_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkStation_Edit.Location = new System.Drawing.Point(57, 0);
            this.WorkStation_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.WorkStation_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.WorkStation_Edit.Name = "WorkStation_Edit";
            this.WorkStation_Edit.Size = new System.Drawing.Size(30, 30);
            this.WorkStation_Edit.Symbol = 559205;
            this.WorkStation_Edit.SymbolSize = 32;
            this.WorkStation_Edit.TabIndex = 3;
            this.WorkStation_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // WorkStation_Delete
            // 
            this.WorkStation_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WorkStation_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkStation_Delete.Location = new System.Drawing.Point(105, 0);
            this.WorkStation_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.WorkStation_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.WorkStation_Delete.Name = "WorkStation_Delete";
            this.WorkStation_Delete.Size = new System.Drawing.Size(30, 30);
            this.WorkStation_Delete.Symbol = 559506;
            this.WorkStation_Delete.SymbolSize = 26;
            this.WorkStation_Delete.TabIndex = 4;
            this.WorkStation_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.Model_Create);
            this.flowLayoutPanel1.Controls.Add(this.Model_Edit);
            this.flowLayoutPanel1.Controls.Add(this.Model_Delete);
            this.flowLayoutPanel1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(39, 629);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(120, 30);
            this.flowLayoutPanel1.TabIndex = 3;
            // 
            // Model_Create
            // 
            this.Model_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Create.Location = new System.Drawing.Point(5, 0);
            this.Model_Create.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Create.Name = "Model_Create";
            this.Model_Create.Size = new System.Drawing.Size(30, 30);
            this.Model_Create.Symbol = 557669;
            this.Model_Create.SymbolSize = 32;
            this.Model_Create.TabIndex = 2;
            this.Model_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Create.Click += new System.EventHandler(this.Model_Create_Click);
            // 
            // Model_Edit
            // 
            this.Model_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Edit.Location = new System.Drawing.Point(45, 0);
            this.Model_Edit.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Edit.Name = "Model_Edit";
            this.Model_Edit.Size = new System.Drawing.Size(30, 30);
            this.Model_Edit.Symbol = 559205;
            this.Model_Edit.SymbolSize = 32;
            this.Model_Edit.TabIndex = 3;
            this.Model_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Edit.Click += new System.EventHandler(this.Model_Edit_Click);
            // 
            // Model_Delete
            // 
            this.Model_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Delete.Location = new System.Drawing.Point(85, 0);
            this.Model_Delete.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Delete.Name = "Model_Delete";
            this.Model_Delete.Size = new System.Drawing.Size(30, 30);
            this.Model_Delete.Symbol = 559506;
            this.Model_Delete.SymbolSize = 26;
            this.Model_Delete.TabIndex = 4;
            this.Model_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Delete.Click += new System.EventHandler(this.Model_Delete_Click);
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 7;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 180F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.dgv_Models, 1, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel3, 3, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.dgv_Workstations, 4, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel4, 4, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel1, 1, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.Button_Refresh, 6, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 3;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(872, 682);
            this.tableLayoutPanel_Page.TabIndex = 1;
            // 
            // dgv_Models
            // 
            this.dgv_Models.AllowUserToAddRows = false;
            this.dgv_Models.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.dgv_Models.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Models.BackgroundColor = System.Drawing.Color.White;
            this.dgv_Models.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("微軟正黑體", 11F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Models.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Models.ColumnHeadersHeight = 32;
            this.dgv_Models.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("微軟正黑體", 11F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Models.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_Models.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Models.EnableHeadersVisualStyles = false;
            this.dgv_Models.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dgv_Models.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.dgv_Models.Location = new System.Drawing.Point(12, 3);
            this.dgv_Models.Name = "dgv_Models";
            this.dgv_Models.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Models.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dgv_Models.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_Models.RowTemplate.Height = 24;
            this.dgv_Models.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_Models.SelectedIndex = -1;
            this.dgv_Models.Size = new System.Drawing.Size(174, 616);
            this.dgv_Models.StripeOddColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.dgv_Models.TabIndex = 12;
            this.dgv_Models.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_Models_CellFormatting);
            this.dgv_Models.SelectionChanged += new System.EventHandler(this.dgv_Models_SelectionChanged);
            // 
            // dgv_Workstations
            // 
            this.dgv_Workstations.AllowUserToAddRows = false;
            this.dgv_Workstations.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.dgv_Workstations.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_Workstations.BackgroundColor = System.Drawing.Color.White;
            this.dgv_Workstations.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("微軟正黑體", 11F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Workstations.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_Workstations.ColumnHeadersHeight = 32;
            this.dgv_Workstations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("微軟正黑體", 11F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Workstations.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_Workstations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Workstations.EnableHeadersVisualStyles = false;
            this.dgv_Workstations.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dgv_Workstations.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.dgv_Workstations.Location = new System.Drawing.Point(272, 3);
            this.dgv_Workstations.Name = "dgv_Workstations";
            this.dgv_Workstations.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Workstations.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dgv_Workstations.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgv_Workstations.RowTemplate.Height = 24;
            this.dgv_Workstations.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_Workstations.SelectedIndex = -1;
            this.dgv_Workstations.Size = new System.Drawing.Size(174, 616);
            this.dgv_Workstations.StripeOddColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.dgv_Workstations.TabIndex = 11;
            this.dgv_Workstations.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_Workstations_CellFormatting);
            this.dgv_Workstations.SelectionChanged += new System.EventHandler(this.dgv_Workstations_SelectionChanged);
            // 
            // Button_Refresh
            // 
            this.Button_Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Refresh.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Refresh.Location = new System.Drawing.Point(582, 200);
            this.Button_Refresh.Margin = new System.Windows.Forms.Padding(3, 200, 3, 3);
            this.Button_Refresh.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Refresh.Name = "Button_Refresh";
            this.Button_Refresh.Size = new System.Drawing.Size(120, 35);
            this.Button_Refresh.Symbol = 57386;
            this.Button_Refresh.TabIndex = 13;
            this.Button_Refresh.Text = "更新頁面";
            this.Button_Refresh.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Refresh.Click += new System.EventHandler(this.Button_Refresh_Click);
            // 
            // Setup_Models
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_Models";
            this.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Size = new System.Drawing.Size(872, 682);
            this.Load += new System.EventHandler(this.Setup_Models_Load);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.tableLayoutPanel_Page.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Models)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Workstations)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Sunny.UI.UISymbolButton Model_Create;
        private Sunny.UI.UISymbolButton Model_Edit;
        private Sunny.UI.UISymbolButton Model_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton WorkStation_Create;
        private Sunny.UI.UISymbolButton WorkStation_Edit;
        private Sunny.UI.UISymbolButton WorkStation_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private Sunny.UI.UISymbolButton WorkStation_Up;
        private Sunny.UI.UISymbolButton WorkStation_Down;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private Sunny.UI.UIDataGridView dgv_Workstations;
        private Sunny.UI.UIDataGridView dgv_Models;
        private Sunny.UI.UISymbolButton Button_Refresh;
    }
}
