﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Permission : UIUserControl, IDisposable
    {
        #region fields

        private const int SYMBOL_CHECK = 61510;
        private const int SYMBOL_UNCHECK = 559445;

        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly IPermissionService _permission;
        private readonly FieldTitle _fieldTitle;
        private string _prefix;

        private PermissionSource _permissionSource;
        private HashSet<PermissionData> _permTable;
        private int _idDepartment;
        private int _idUserGroup;
        private string _idEmployee;

        #endregion fields

        public Setup_Permission(CoreContext coreContext,
                                CurrentUserContext currentUserContext,
                                IPermissionService permissionService,
                                FieldTitle fieldTitle)
        {
            InitializeComponent();
            _context = coreContext;
            _user = currentUserContext;
            _permission = permissionService;
            _fieldTitle = fieldTitle;

            UISetup(this.Controls);

            StrongReferenceMessenger.Default.Register(this, (MessageHandler<object, PermissionSettingPageMessage>)((r, m) =>
            {
                PermissionSettingInfo info = m.Value;
                if (_permissionSource != info.PermissionSource)
                    _permissionSource = info.PermissionSource;

                switch (_permissionSource)
                {
                    case PermissionSource.Department:
                        _idDepartment = info.DepartmentId;
                        _permTable = _permission.GetDepartmentPermissions(info.DepartmentId);
                        break;
                    case PermissionSource.UserGroup:
                        _idUserGroup = info.UserGroupId;
                        _permTable = _permission.GetUserGroupPermissions(info.UserGroupId);
                        break;
                    case PermissionSource.Employee:
                        _idEmployee = info.EmployeeId;
                        _permTable = _permission.GetFullPermissions(_idEmployee);
                        break;
                    default:
                        _permTable = null;
                        return;
                }
                ApplyPermissions();
            }));

            NM_Permission.TabControl = TC_Permission;
            NM_Permission.SelectedColor = CommonStyles.AccentColor;

            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[0], SYMBOL_CHECK);
            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[1], SYMBOL_CHECK);
            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[2], SYMBOL_CHECK);
            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[3], SYMBOL_CHECK);

            TC_Permission.SelectedTab = TP_Setup;
        }

        private void UISetup(ControlCollection controls)
        {
            CommonStyles.SetButton(btn_Save);

            foreach (Control control in controls)
            {
                if (control is UITitlePanel tp)
                {
                    tp.TitleColor = CommonStyles.BackColor;
                }

                if (control is UICheckBox cb)
                {
                    CommonStyles.SetCheckBox(cb);
                }
                else if (control is UILine line)
                {
                    line.LineColor = CommonStyles.BackColor;
                }
                else if (control.HasChildren)
                {
                    UISetup(control.Controls);
                }
            }
        }

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
                StrongReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        /********************
         * 權限表
         ********************/

        private void CLearAllCheckBox()
        {




            // 維護工單
            CBe_MaintiFlowSummy.Checked = false;
            CBr_MaintiFlowSummy.Checked = false;
            CBe_Create.Checked = false;
            CBe_Cancel.Checked = false;
            CBe_Accept.Checked = false;
            CBe_Maintant.Checked = false;
            CBe_Confirm.Checked = false;

            // 設定
            CBe_MachineManager.Checked = false;
            CBr_MachineManager.Checked = false;
            CBe_EmployeeManager.Checked = false;
            CBr_EmployeeManager.Checked = false;
        }

        private void ApplyPermissions()
        {
            CLearAllCheckBox();
            foreach (var perm in _permTable)
            {
                switch (perm.Module)
                {
                    case PermissionPrefix.TOOL_QUEST:
                        break;

                    case PermissionPrefix.MECHA_TRACK:
                        break;

                    case PermissionPrefix.MAINTI_FLOW:
                        CBe_MaintiFlowSummy.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBe_MaintiFlowSummy));
                        CBr_MaintiFlowSummy.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBr_MaintiFlowSummy));
                        CBe_Create.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBe_Create));
                        CBe_Cancel.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBe_Cancel));
                        CBe_Accept.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBe_Accept));
                        CBe_Maintant.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBe_Maintant));
                        CBe_Confirm.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBe_Confirm));
                        break;

                    case PermissionPrefix.SETUP:
                        CBe_MachineManager.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBe_MachineManager));
                        CBr_MachineManager.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBr_MachineManager));
                        CBe_EmployeeManager.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBe_EmployeeManager));
                        CBr_EmployeeManager.Checked = _permission.HasControlAccess(_user.EmployeeId, nameof(CBr_EmployeeManager));
                        break;

                    case PermissionPrefix.HOME:
                        break;
                }
            }
        }

        /********************
         * NavMenu
         ********************/
        private void NM_Permission_MenuItemClick(TreeNode node, NavMenuItem item, int pageIndex)
        {
            TC_Permission.SelectedIndex = node.Index;
        }

        private void NM_Permission_NodeRightSymbolClick(object sender, TreeNode node, int index, int symbol)
        {
            TC_Permission.SelectedIndex = node.Index;
            NM_Permission.ClearNodeRightSymbol(node);
            NM_Permission.AddNodeRightSymbol(node, symbol == SYMBOL_CHECK ? SYMBOL_UNCHECK : SYMBOL_CHECK);
        }

        private void NM_Permission_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            switch (_permissionSource)
            {
                case PermissionSource.Department:
                    break;

                case PermissionSource.UserGroup:
                    break;

                case PermissionSource.Employee:
                    var emp = _context.Employees
                        .Where(u => u.EmployeeId == _idEmployee)
                        .ToList();
                    var perms = new List<PermissionData>();
                    if (CBe_MaintiFlowSummy.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.MAINTI_FLOW,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBr_MaintiFlowSummy.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.MAINTI_FLOW,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBe_Create.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.MAINTI_FLOW,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBe_Cancel.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.MAINTI_FLOW,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBe_Accept.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.MAINTI_FLOW,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBe_Maintant.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.MAINTI_FLOW,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBe_Confirm.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.MAINTI_FLOW,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });

                    if (CBe_MachineManager.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.SETUP,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBr_MachineManager.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.SETUP,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBe_EmployeeManager.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.SETUP,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });
                    if (CBr_EmployeeManager.Checked)
                        perms.Add(new PermissionData()
                        {
                            Module = PermissionPrefix.SETUP,
                            Page = nameof(CBe_MaintiFlowSummy),
                            Control = "**",
                            Action = "",
                        });

                    emp.per
                    _context.SaveChanges();
                    _permission.RefreshUserPermissions(_idEmployee);
                    break;
            }
        }

        /********************
         * 維護工單
         ********************/
    }
}
