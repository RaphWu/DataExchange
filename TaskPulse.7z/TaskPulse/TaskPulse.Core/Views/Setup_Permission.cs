﻿using System;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Permission : UserControl, IDisposable
    {
        #region fields

        private readonly IPermissionService _permission;
        private readonly FieldTitle _fieldTitle;
        private PermissionSource _permissionSource;
        private string _prefix;
        private string _employeeId;

        #endregion fields

        public Setup_Permission(IPermissionService permissionService, FieldTitle fieldTitle)
        {
            InitializeComponent();
            _permission = permissionService;
            _fieldTitle = fieldTitle;

            UISetup(this.Controls);
            StrongReferenceMessenger.Default.Register<PermissionSettingPageReciver>(this, (r, m) =>
            {
                PermissionSettingInfo info = m.Value;
                if (_permissionSource != info.PermissionSource)
                {
                    _permissionSource = info.PermissionSource;
                }
                else
                {
                    _employeeId = info.EmployeeId;
                    _permission.GetUserPermissions(_employeeId);
                }
            });
        }

        private void UISetup(ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UITitlePanel tp)
                {
                    tp.TitleColor = CommonStyles.BackColor;
                }

                if (control is UICheckBox cb)
                {
                    CommonStyles.SetCheckBox(cb);
                }
                else if (control is UILine line)
                {
                    line.LineColor = CommonStyles.BackColor;
                }
                else if (control.HasChildren)
                {
                    UISetup(control.Controls);
                }
            }
        }

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
                StrongReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        /********************
         * 維護工單
         ********************/
        private void CBe_Mainti_CheckedChanged(object sender, EventArgs e)
        {
            bool chk = !CBe_Mainti.Checked;
            CBe_Summy.Enabled = chk;
            CBr_Summy.Enabled = chk;
            CBr_Mainti.Enabled = chk;
            CBe_Create.Enabled = chk;
            CBr_Create.Enabled = chk;
            CBe_Cancel.Enabled = chk;
            CBr_Cancel.Enabled = chk;
            CBe_Accept.Enabled = chk;
            CBr_Accept.Enabled = chk;
            CBe_Transfer.Enabled = chk;
            CBr_Transfer.Enabled = chk;
            CBe_Maintant.Enabled = chk;
            CBr_Maintant.Enabled = chk;
            CBe_Confirm.Enabled = chk;
            CBr_Confirm.Enabled = chk;
        }

        private void CBr_Mainti_CheckedChanged(object sender, EventArgs e)
        {
            bool chk = !CBr_Mainti.Checked;
            CBr_Summy.Enabled = chk;
            CBr_Create.Enabled = chk;
            CBr_Cancel.Enabled = chk;
            CBr_Accept.Enabled = chk;
            CBr_Transfer.Enabled = chk;
            CBr_Maintant.Enabled = chk;
            CBr_Confirm.Enabled = chk;
        }
    }
}
