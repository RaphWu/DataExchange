﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Employees : UserControl
    {
        #region fields

        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        private List<EmployeeViewModel> _vmEmps = null;
        private DataTable _dt;
        private DataGridViewComboBoxColumn dgvComboBox;
        private BindingSource _bs = new BindingSource();

        string _thisEmployee = "";

        #endregion fields

        public Setup_Employees(IRegionManager regionManager,
                               INavigationService navigationService,
                               CoreContext coreContext,
                               CoreData coreData,
                               MultiSelector multiSelector)
        {
            InitializeComponent();
            _region = regionManager;
            _nav = navigationService;
            _context = coreContext;
            _coreData = coreData;
            _mSel = multiSelector;

            //_region.RegisterRegion(nameof(TP_Employees), TP_Employees);
            _region.RegisterRegion(nameof(panelPermission), panelPermission);

            // adgv
            _dt = new DataTable();
            _dt.Columns.Add(PropertyText.Name.EmployeeId, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Department, typeof(string));
            _dt.Columns.Add(PropertyText.Name.JobTitle, typeof(string));
            _dt.Columns.Add(PropertyText.Name.EmployeeName, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Email, typeof(string));
            _dt.Columns.Add(PropertyText.Name.IsEngineer, typeof(bool));
            _dt.Columns.Add(PropertyText.Name.EmployeeStatus, typeof(bool));
            _dt.Columns.Add(PropertyText.Name.StatusChangeAt, typeof(DateTime));

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.EmployeeId,
                DataPropertyName = nameof(EmployeeViewModel.EmployeeId),
                HeaderText = PropertyText.Title.EmployeeId,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            dgvComboBox = new DataGridViewComboBoxColumn()
            {
                DataPropertyName = nameof(EmployeeViewModel.DepartmentId),
                HeaderText = PropertyText.Title.Department,
                ValueType = typeof(string),
            };
            //dgvComboBox.Items.Add("");
            //dgvComboBox.Items.AddRange(_context.Departments.Select(d => d.DepartmentName).ToList());
            dgvComboBox.DataSource = _context.Departments
                .Select(d => new ListViewModel() { Id = d.Id, Name = d.DepartmentName })
                .ToList();
            dgvComboBox.DisplayMember = "Name";
            dgvComboBox.ValueMember = "Id";
            dgvComboBox.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
            dgvComboBox.DisplayStyleForCurrentCellOnly = true;
            adgv.Columns.Add(dgvComboBox);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.JobTitle,
                HeaderText = PropertyText.Title.JobTitle,
                ValueType = typeof(string),
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.EmployeeName,
                HeaderText = PropertyText.Title.EmployeeName,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.Email,
                HeaderText = PropertyText.Title.Email,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.CarbonCopyString,
                HeaderText = PropertyText.Title.CarbonCopies,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.IsEngineerString,
                HeaderText = PropertyText.Title.IsEngineer,
                ValueType = typeof(bool),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.EmployeeStatusName,
                HeaderText = PropertyText.Title.EmployeeStatus,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = PropertyText.Name.StatusChangeAtString,
                HeaderText = PropertyText.Title.StatusChangeAt,
                ValueType = typeof(DateTime),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            CommonStyles.SetAdvancedDataGridView(adgv, true);
            CommonStyles.SetButton(btnSave);
            CommonStyles.SetListBox(Status);
            CommonStyles.SetCheckBox(IsEngineer);
            //CommonStyles.SetCheckBox(cbStatusChangeAt);
        }

        private async void Setup_Employees_Load(object sender, EventArgs e)
        {
            await UpdateData();

            // Detail
            label_EmployeeId.Text = PropertyText.Title.EmployeeId;
            EmployeeId.DataBindings.Clear();
            EmployeeId.DataBindings.Add("Text", _bs, PropertyText.Name.EmployeeId);

            label_Department.Text = PropertyText.Title.Department;
            var dm = _context.Departments.Select(d => new ListViewModel()
            {
                Id = d.Id,
                Name = d.DepartmentName,
            }).ToList();
            dm.Insert(0, new ListViewModel() { Id = 0, Name = "" });
            Department.DataSource = dm;
            Department.DisplayMember = "Name";
            Department.ValueMember = "Id";
            Department.DataBindings.Clear();
            Department.DataBindings.Add("SelectedValue", _bs, PropertyText.Name.DepartmentId);

            label_JobTitle.Text = PropertyText.Title.JobTitle;
            var jt = _context.JobTitles.Select(j => new ListViewModel()
            {
                Id = j.Id,
                Name = j.JobTitleName,
            }).ToList();
            jt.Insert(0, new ListViewModel() { Id = 0, Name = "" });
            JobTitle.DataSource = jt;
            JobTitle.DisplayMember = "Name";
            JobTitle.ValueMember = "Id";
            JobTitle.DataBindings.Clear();
            JobTitle.DataBindings.Add("SelectedValue", _bs, PropertyText.Name.JobTitleId);

            label_EmployeeName.Text = PropertyText.Title.EmployeeName;
            EmployeeName.DataBindings.Clear();
            EmployeeName.DataBindings.Add("Text", _bs, PropertyText.Name.EmployeeName);

            label_Email.Text = PropertyText.Title.Email;
            Email.DataBindings.Clear();
            Email.DataBindings.Add("Text", _bs, PropertyText.Name.Email);

            label_CarbonCopies.Text = PropertyText.Title.CarbonCopies;
            CarbonCopies.DataBindings.Clear();
            CarbonCopies.DataBindings.Add("Text", _bs, PropertyText.Name.CarbonCopyString);

            IsEngineer.Text = PropertyText.Title.IsEngineer;
            IsEngineer.DataBindings.Clear();
            IsEngineer.DataBindings.Add("Checked", _bs, PropertyText.Name.IsEngineer);

            label_Status.Text = PropertyText.Title.EmployeeStatus;
            var es = _context.EmployeeStatuses.Select(j => new ListViewModel()
            {
                Id = j.Id,
                Name = j.StatusName,
            }).ToList();
            jt.Insert(0, new ListViewModel() { Id = 0, Name = "" });
            Status.DataSource = es;
            Status.DisplayMember = "Name";
            Status.ValueMember = "Id";
            Status.DataBindings.Clear();
            Status.DataBindings.Add("SelectedValue", _bs, PropertyText.Name.EmployeeStatusId);

            label_StatusChangeAt.Text = PropertyText.Title.StatusChangeAt;
            //cbStatusChangeAt.DataBindings.Clear();
            //cbStatusChangeAt.DataBindings.Add("Checked", _bs, PropertyText.Name.EmployeeStatusBoolean);
            StatusChangeAt.DataBindings.Clear();
            StatusChangeAt.DataBindings.Add("Text", _bs, PropertyText.Name.StatusChangeAtString);

            _nav.Navigate<Setup_Permission>(nameof(panelPermission), alive: false);

            //_core.CleanUpControls(TP_Permission.Controls);
            //TP_Permission.Controls.Add(_permission);
            //_ = WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
            //new PermissionSettingInfo()
            //    {
            //        PermissionSource = PermissionSource.Employee,
            //        EmployeeId = "",
            //    }));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            }
            base.Dispose(disposing);
        }

        private async Task UpdateData()
        {
            var query = await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.JobTitle)
                .Include(e => e.Status)
                .AsNoTracking()
                .ToListAsync();
            _vmEmps = query
                .OrderBy(e => e.Department?.OrderNo ?? int.MaxValue)
                .ThenBy(e => e.JobTitle?.OrderNo ?? int.MaxValue)
                .ThenBy(e => e.EmployeeId)
                .Select(e => new EmployeeViewModel
                {
                    EmployeeId = e.EmployeeId,
                    EmployeeName = e.EmployeeName,
                    DepartmentId = e.DepartmentId ?? 0,
                    Department = e.Department?.DepartmentName ?? string.Empty,
                    JobTitleId = e.JobTitleId ?? 0,
                    JobTitle = e.JobTitle?.JobTitleName ?? string.Empty,
                    Email = e.Email,
                    CarbonCopies = e.CarbonCopies,
                    CarbonCopyString = e.CarbonCopyString,
                    CarbonCopyList = e.CarbonCopyList,
                    IsEngineer = e.IsEngineer,
                    IsEngineerString = e.IsEngineerString,
                    Status = e.Status,
                    StatusId = e.StatusId,
                    StatusName = e.StatusName,
                    StatusBoolean = e.StatusBoolean,
                    StatusChangeAt = e.StatusChangeAt ?? DateTime.Now,
                    StatusChangeAtString = e.StatusChangeAtString,
                }).ToList();

            adgv.AutoGenerateColumns = false;
            _dt = _vmEmps.ToDataTable();
            adgv.DataSource = _dt;
            _bs.DataSource = _dt;
            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_vmEmps.Count()} 筆資料"));
        }

        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewRow row = adgv.CurrentRow;
            if (row != null)
            {
                _thisEmployee = row.Cells[PropertyText.Name.EmployeeId].Value.ToString();
                int index = _vmEmps.FindIndex(x => x.EmployeeId == _thisEmployee);
                if (index >= 0)
                    _bs.Position = index;

                _ = WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                    new PermissionSettingInfo()
                    {
                        PermissionSource = PermissionSource.Employee,
                        EmployeeId = _thisEmployee,
                    }));
            }
        }

        private async void btnSave_Click(object sender, EventArgs eventArgs)
        {
            var emp = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == _thisEmployee);
            if (emp != null)
            {
                emp.EmployeeId = _thisEmployee;
                emp.EmployeeName = EmployeeName.Text;
                emp.DepartmentId = (int)Department.SelectedValue;
                emp.JobTitleId = (int)JobTitle.SelectedIndex; // TODO: 為什麼SelectedValue值不對!?
                emp.Email = Email.Text;
                emp.IsEngineer = IsEngineer.Checked;
                emp.StatusId = (int)Status.SelectedValue;
                emp.StatusChangeAtString = string.IsNullOrEmpty(StatusChangeAt.Text) ? null : StatusChangeAt.Text;

                var ccs = CarbonCopies.Text
                    .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim())
                    .ToList();
                emp.CarbonCopies.Clear();
                foreach (var cc in ccs)
                {
                    var e = await _context.Employees.FirstOrDefaultAsync(x => x.EmployeeName == cc);
                    if (e != null)
                        emp.CarbonCopies.Add(e);
                }

                await _context.SaveChangesAsync();
                await UpdateData();
            }
        }

        private void CarbonCopies_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.CarbonCopies}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EmployeeMultiTabPageCache;
            _mSel.DefaultChecked = CarbonCopies.Text
                .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                List<string> emps = new List<string>();
                foreach (var emp in _mSel.ResultList)
                    emps.Add(emp.Name);
                CarbonCopies.Text = string.Join("; ", emps);
            }
        }
    }
}
