﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Employees : UIUserControl
    {
        #region fields

        private readonly ILifetimeScope _scope;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly CoreData _coreData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;
        private readonly Setup_Permission _permission;

        private readonly DbSet<Employee> _employees;

        private List<EmployeeViewModel> _vmEmps = null;
        private EmployeeViewModel _vmEmp = null;

        #endregion fields

        public Setup_Employees(ILifetimeScope lifetimeScope,
                               CoreContext coreContext,
                               ICore core,
                               CoreData coreData,
                               FieldName fieldName,
                               FieldTitle fieldTitle,
                               Setup_Permission permission)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _coreData = coreData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;
            _permission = permission;

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = _fieldName.EmployeeId,
                DataPropertyName = nameof(EmployeeViewModel.Id),
                HeaderText = _fieldTitle.EmployeeId,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.Department),
                HeaderText = _fieldTitle.Department,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.Title),
                HeaderText = _fieldTitle.Title,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.Name),
                HeaderText = _fieldTitle.EmployeeName,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.EMail),
                HeaderText = _fieldTitle.EMail,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.IsEngineer),
                HeaderText = _fieldTitle.IsEngineer,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(EmployeeViewModel.OnStaff),
                HeaderText = _fieldTitle.OnStaff,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });

            CommonStyles.SetAdvancedDataGridView(ADGV);
        }

        private async void Setup_Employees_Load(object sender, EventArgs e)
        {
            await UpdateEmployeesView();

            _core.CleanUpControls(TP_Permission.Controls);
            TP_Permission.Controls.Add(_permission);
            StrongReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                new PermissionSettingInfo()
                {
                    PermissionSource = PermissionSource.Employee,
                    EmployeeId = "",
                }));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                StrongReferenceMessenger.Default.Send(new DbInfoMessage(""));
            }
            base.Dispose(disposing);
        }

        private async Task UpdateEmployeesView()
        {
            var query = await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Title)
                .AsNoTracking()
                .ToListAsync();
            _vmEmps = query.Select(e => new EmployeeViewModel
            {
                Id = e.EmployeeId,
                Name = e.EmployeeName,
                Department = e.Department?.DepartmentName ?? string.Empty,
                Title = e.Title?.TitleName ?? string.Empty,
                EMail = e.EMail,
                IsEngineer = e.IsEngineerYes,
                OnStaff = e.OnStaffString,
            }).ToList();

            ADGV.AutoGenerateColumns = false;
            ADGV.DataSource = _vmEmps.ToDataTable();
            StrongReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_vmEmps.Count()} 筆資料"));
        }

        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewRow row = ADGV.CurrentRow;
            if (row != null)
            {
                string employeeId = row.Cells[_fieldName.EmployeeId].Value.ToString();
                StrongReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                    new PermissionSettingInfo()
                    {
                        PermissionSource = PermissionSource.Employee,
                        EmployeeId = employeeId,
                    }));
            }
        }
    }
}
