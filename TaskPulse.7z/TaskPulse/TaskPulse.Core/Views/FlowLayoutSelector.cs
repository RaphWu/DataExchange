﻿/*
 * 多選：
 *     建立分類TAB。
 * 單選：
 *     排序 -> 3位數字 -> 5位數字
 * 下方顯示已選取項目。分類: 項目1,項目2...
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class FlowLayoutSelector : UIForm
    {
        private const int MACHINEID_WIDTH = 140;
        private CoreData _coreData;
        private ICore _core;

        private Dictionary<string, (string Category, string Type)> _checkedMachines
            = new Dictionary<string, (string Category, string Type)>();
        private Dictionary<string, TabPage> _tabPagesCache = new Dictionary<string, TabPage>();

        private string _selectMachine = string.Empty;

        private string _categoryName = string.Empty;
        private string _typeName = string.Empty;
        private string _currentCategory;

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 是否隱藏標籤列。
        /// </summary>
        public bool HideTabHeaders
        {
            get => tabControlTypes.HideTabHeaders;
            set
            {
                if (tabControlTypes.HideTabHeaders != value)
                    tabControlTypes.HideTabHeaders = value;
            }
        }

        /// <summary>
        /// 是否允許多選。
        /// </summary>
        /// <remarks>true=多選 (使用 CheckBox)，false=單選 (使用 RadioButton)。</remarks>
        public bool MultiSelection { get; set; } = true;

        /// <summary>
        /// 預設值列表。
        /// </summary>
        public List<string> DefaultCheckedMachines { get; set; }

        /// <summary>
        /// 返回的項目。
        /// </summary>
        public List<string> ResultList { get; set; }

        ///// <summary>
        ///// 多選的顯示項目。
        ///// </summary>
        ///// <remarks>Dictionary&lt;Category, Dictionary&lt;Type, List&lt;Name&gt;&gt;&gt;</remarks>
        //public Dictionary<string, Dictionary<string, List<string>>> MultiItems
        //{
        //    get { return _multiItems; }
        //    set
        //    {
        //        if (!_multiItems.Equals(value))
        //            _multiItems = value;
        //    }
        //}
        //private Dictionary<string, Dictionary<string, List<string>>> _multiItems = new Dictionary<string, Dictionary<string, List<string>>>();

        /// <summary>
        /// 單選的顯示項目。
        /// </summary>
        public List<string> SingleItems
        {
            get { return _singleItems; }
            set
            {
                if (!_singleItems.Equals(value))
                    _singleItems = value;
            }
        }
        private List<string> _singleItems = new List<string>();

        public FlowLayoutSelector(CoreData coreData, ICore core)
        {
            InitializeComponent();
            _coreData = coreData;
            _core = core;

            label_ResultList.Text = "";

            this.AcceptButton = uiButton_OK;
            this.CancelButton = uiButton_Cancel;
        }

        private void FlowLayoutSelector_Shown(object sender, EventArgs e)
        {
            if (treeViewCategories.Nodes.Count > 0)
            {
                treeViewCategories.SelectedNode = treeViewCategories.Nodes[0];
                treeViewCategories_AfterSelect(treeViewCategories, new TreeViewEventArgs(treeViewCategories.SelectedNode));

                //if (tabControlTypes.TabPages.Count > 0)
                //{
                //    tabControlTypes.SelectedIndex = 0;
                //    tabControlTypes_SelectedIndexChanged(tabControlTypes, EventArgs.Empty);
                //}
            }
        }

        private void FlowLayoutSelector_FormClosing(object sender, FormClosingEventArgs e)
        {
            SetCheckBoxEvent(false);
            tabControlTypes.TabPages.Clear(); // 沒清掉的話，裡面的Control會全被釋放掉
        }

        public void Initialize()
        {
            tabControlTypes.TabPages.Clear();
            ResultList = new List<string>();
            SetCheckBoxToDefault();

            if (MultiSelection)
            {
                treeViewCategories.Nodes.Clear();
                foreach (var categoryName in _coreData.TabPageSelector.Keys)
                    treeViewCategories.Nodes.Add(new TreeNode(categoryName));
            }
            else
            {
                ResultList.Add(string.Empty);
                var tabPage = new TabPage("SinglePage");
                var flow = new UIFlowLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    AutoScroll = true,
                    WrapContents = true,
                };

                foreach (var text in SingleItems)
                {
                    var rb = new UIRadioButton();
                    rb.SetDPIScale();
                    rb.Width = MACHINEID_WIDTH;
                    rb.GroupIndex = 1;
                    rb.Name = text;
                    rb.Text = text;
                    rb.Checked = DefaultCheckedMachines.Count > 0 && DefaultCheckedMachines[0] == text;
                    rb.CheckedChanged += RadioButton_CheckedChanged;
                    flow.Add(rb);
                }

                tabPage.Controls.Add(flow);
                tabControlTypes.TabPages.Add(tabPage);
            }
        }

        private void treeViewCategories_AfterSelect(object sender, TreeViewEventArgs e)
        {
            this.ShowProcessForm(200);

            _loadingCheckboxes = true;
            tabControlTypes.SuspendLayout();

            var categoryName = e.Node.Text;
            tabControlTypes.TabPages.Clear();

            var typeDict = _coreData.TabPageSelector[categoryName];
            foreach (var typePage in typeDict)
                tabControlTypes.TabPages.Add(typePage);
            SetCheckBoxEvent(true);
             
            tabControlTypes.ResumeLayout();
            _loadingCheckboxes = false;

            this.HideProcessForm();
        }

        private void SetCheckBoxEvent(bool addOrSub)
        {
            _loadingCheckboxes = false;
            foreach (var categoryName in _coreData.TabPageSelector.Keys)
            {
                var typeDict = _coreData.TabPageSelector[categoryName];
                foreach (var typePage in typeDict)
                    SetCheckBoxEvent(typePage.Controls, addOrSub);
            }
            _loadingCheckboxes = true;
        }

        private void SetCheckBoxEvent(Control.ControlCollection controls, bool addOrSub)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (addOrSub)
                        cb.CheckedChanged += CheckBox_CheckedChanged;
                    else
                        cb.CheckedChanged -= CheckBox_CheckedChanged;
                }
                else if (control.HasChildren)
                {
                    SetCheckBoxEvent(control.Controls, addOrSub);
                }
            }
        }

        private void ClearAllChecked()
        {
            _loadingCheckboxes = false;
            foreach (var categoryName in _coreData.TabPageSelector.Keys)
            {
                var typeDict = _coreData.TabPageSelector[categoryName];
                foreach (var typePage in typeDict)
                    ClearAllChecked(typePage.Controls);
            }
            _loadingCheckboxes = true;
        }

        private void ClearAllChecked(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                    cb.Checked = false;
                else if (control.HasChildren)
                    ClearAllChecked(control.Controls);
            }
            _checkedMachines = new Dictionary<string, (string Category, string Type)>();
        }

        private void SetCheckBoxToDefault()
        {
            _loadingCheckboxes = false;
            _checkedMachines = new Dictionary<string, (string Category, string Type)>();
            foreach (var categoryName in _coreData.TabPageSelector.Keys)
            {
                var typeDict = _coreData.TabPageSelector[categoryName];
                foreach (var typePage in typeDict)
                    SetCheckBoxToDefault(typePage.Controls);
            }
            _loadingCheckboxes = true;
        }

        private void SetCheckBoxToDefault(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is UICheckBox cb)
                {
                    if (DefaultCheckedMachines.Contains(cb.Text))
                    {
                        if (!cb.Checked)
                            cb.Checked = true;

                        dynamic tag = cb.Tag;
                        string category = tag.Category;
                        string type = tag.Type;
                        string machineId = tag.MachineId;
                        if (!_checkedMachines.ContainsKey(machineId))
                            _checkedMachines.Add(machineId, (category, type));
                    }
                    else
                    {
                        if (cb.Checked)
                            cb.Checked = false;
                    }
                }
                else if (control.HasChildren)
                    SetCheckBoxToDefault(control.Controls);
            }
        }



        //private void tabControlTypes_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    var selectedTab = tabControlTypes.SelectedTab;
        //    if (selectedTab == null)
        //        return;
        //    var initialized = (bool)selectedTab.Tag;
        //    if (initialized)
        //        return;
        //    var typeName = selectedTab.Name;
        //    var categoryName = treeViewCategories.SelectedNode?.Text;
        //    if (categoryName == null)
        //        return;
        //    var uiflow = selectedTab.Controls.OfType<UIFlowLayoutPanel>().FirstOrDefault();
        //    if (uiflow == null)
        //        return;

        //    // 已載入就不重複載入
        //    if (initialized)
        //        return;

        //    if (!MultiItems.TryGetValue(categoryName, out var typeDict))
        //        return;
        //    if (!typeDict.TryGetValue(typeName, out var machines))
        //        return;

        //    _loadingCheckboxes = true;
        //    uiflow.SuspendLayout();
        //    var checkBoxes = new List<UICheckBox>();
        //    foreach (var machine in machines)
        //    {
        //        bool isChecked = _checkedMachines.TryGetValue(machine, out var info)
        //                && info.Category == categoryName
        //                && info.Type == typeName;

        //        var cb = new UICheckBox
        //        {
        //            AutoSize = false,
        //            Width = MACHINEID_WIDTH,
        //            Name = machine,
        //            Text = machine,
        //            Checked = isChecked,
        //            Tag = new
        //            {
        //                Category = categoryName,
        //                Type = typeName,
        //                MachineName = machine
        //            },
        //        };
        //        checkBoxes.Add(cb);

        //        // 預設勾選的機台要加入已勾選清單，避免初始狀態不同步
        //        if (cb.Checked && !_checkedMachines.ContainsKey(machine))
        //            _checkedMachines.Add(machine, (categoryName, typeName));
        //    }
        //    uiflow.Controls.AddRange(checkBoxes.ToArray());
        //    foreach (var cb in checkBoxes)
        //    {
        //        cb.SetDPIScale();
        //        cb.CheckedChanged += CheckBox_CheckedChanged;
        //    }

        //    selectedTab.Tag = true;
        //    uiflow.ResumeLayout();
        //    _loadingCheckboxes = false;
        //}

        //private void CreateCheckBoxes(UIFlowLayoutPanel uiflow, string category, string typeName, List<string> machines)
        //{
        //    _loadingCheckboxes = true;

        //    uiflow.SuspendLayout();
        //    uiflow.Controls.Clear();
        //    List<CheckBox> cbs = new List<CheckBox>();

        //    foreach (var machine in machines)
        //    {
        //        var cb = new CheckBox
        //        {
        //            Text = machine,
        //            Name = machine,
        //            Width = 150,
        //            AutoSize = false,
        //            Checked = DefaultCheckedMachines.Contains(machine),
        //            Tag = new { Category = category, Type = typeName, Machine = machine }
        //        };
        //        cbs.Add(cb);
        //    }
        //    uiflow.Controls.AddRange(cbs.ToArray());

        //    // 綁事件延後做
        //    foreach (var cb in cbs)
        //    {
        //        cb.CheckedChanged += CheckBox_CheckedChanged;
        //        // 初始化時同時加入已勾選清單
        //        if (cb.Checked && !_checkedMachines.ContainsKey(cb.Name))
        //            _checkedMachines.Add(cb.Name, (category, typeName));
        //    }

        //    uiflow.ResumeLayout();
        //    _loadingCheckboxes = false;
        //}

        private bool _loadingCheckboxes = false;

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (_loadingCheckboxes)
                return;
            if (!(sender is UICheckBox cb) || cb.Tag == null)
                return;

            dynamic tag = cb.Tag;
            string category = tag.Category;
            string type = tag.Type;
            string machineId = tag.MachineId;

            if (cb.Checked)
            {
                if (!_checkedMachines.ContainsKey(machineId))
                    _checkedMachines.Add(machineId, (category, type));
            }
            else
            {
                if (_checkedMachines.ContainsKey(machineId))
                    _checkedMachines.Remove(machineId);
            }

            var grouped = _checkedMachines
                .GroupBy(kvp => kvp.Value.Category)
                .OrderBy(g => g.Key)  // 分類排序
                .Select(categoryGroup => new
                {
                    Category = categoryGroup.Key,
                    Types = categoryGroup
                        .GroupBy(kvp => kvp.Value.Type)
                        .OrderBy(tg => tg.Key)  // 型式排序
                        .Select(typeGroup => new
                        {
                            Type = typeGroup.Key,
                            Machines = typeGroup.Select(m => m.Key).OrderBy(m => m) // 機台排序
                        })
                });

            List<string> showResultList = new List<string>();
            ResultList = new List<string>();
            foreach (var c in grouped)
            {
                foreach (var t in c.Types)
                {
                    string machines = string.Join(", ", _core.SortMachineId(t.Machines.ToList()));
                    string line = $"{c.Category} » {t.Type} » {machines}";
                    showResultList.Add(line);
                    ResultList.AddRange(t.Machines.ToList());
                }
            }
            label_ResultList.Text = string.Join("\n", showResultList);
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (sender is UIRadioButton rb)
            {
                _selectMachine = rb.Text;
                label_ResultList.Text = rb.Text;
                ResultList[0] = rb.Text;
            }
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }

    //internal class TabPageMetadata
    //{
    //    public string Type { get; set; }
    //    public bool initialized { get; set; }
    //}
}
