﻿using System;
using System.Configuration;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Helper;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class LoginControl : UIUserControl
    {
        private readonly ILifetimeScope _scope;
        private readonly ILogService _log;
        private readonly ICurrentUserService _currentUser;

        //public string[] NameList = new string[0];

        public LoginControl(ILifetimeScope lifetimeScope,
                            ILogService logService,
                            ICurrentUserService currentUserService,
                            CoreData coreData)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _log = logService;
            _currentUser = currentUserService;

            var _nameList = coreData.Employees.Select(e => new ListViewModel()
            {
                IdString = e.EmployeeId,
                Name = e.FullName
            }).ToList();
            uiComboBox_UserName.DataSource = _nameList;
            uiComboBox_UserName.DisplayMember = "Name";
            uiComboBox_UserName.ValueMember = "IdString";

            CommonStyles.SetButton(Button_Login);
            CommonStyles.SetButton(Button_Cancel, accent: true);
        }

        private async void Button_Login_Click(object sender, EventArgs e)
        {
            var appUser = ConfigurationManager.AppSettings["AdminUser"];
            var appEncryptedPassword = ConfigurationManager.AppSettings["AdminPassword"];
            var appPassword = AESHelper.Decrypt(appEncryptedPassword);
            var password = uiTextBox_Password.Text.Trim();
            var employeeId = uiComboBox_UserName.SelectedValue != null
                ? uiComboBox_UserName.SelectedValue.ToString()
                : uiComboBox_UserName.Text.Trim();

            bool pass = false;
            if (!string.IsNullOrEmpty(employeeId))
            {
                if (employeeId.ToLower() == appUser.ToLower())
                {
                    if (password == appPassword)
                    {
                        pass = true;
                        _currentUser.AdminLogin();
                        await _log.LoginAsync("", "管理員登入", $"登入時間: {DateTime.Now}");
                    }
                    else
                    {
                        pass = false;
                        _currentUser.SwitchCurrentUserToGuest();
                        await _log.LoginAsync("", "管理員登入錯誤", $"嘗試時間: {DateTime.Now}");
                    }
                }
                else
                {
                    var auth = _scope.Resolve<IAuthService>();
                    pass = await auth.ActiveDirectoryAsync(employeeId, password);
                    if (pass)
                    {
                        await _currentUser.SwitchCurrentUserAsync(employeeId);
                        Console.WriteLine("LDAP驗證成功");
                        await _log.LoginAsync(employeeId, "登入成功", "");
                    }
                    else
                    {
                        _currentUser.SwitchCurrentUserToGuest();
                        Console.WriteLine("使用者不存在於系統中");
                        await _log.LoginAsync(employeeId, "登入失敗", "使用者不存在於系統中");
                    }
                }
            }

            //DialogResult = pass ? DialogResult.OK : DialogResult.Cancel;
            //this.Close();
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            //DialogResult = DialogResult.Cancel;
            //this.Close();
        }
    }
}
