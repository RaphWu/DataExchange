﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Views.Models
{
    public class ModelView
    {
        public int ModelId { get; set; }
        public string ModelName { get; set; }
    }
}
