﻿namespace Calin.TaskPulse.Core.Views
{
    partial class FlowLayoutSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiPanel_Message = new Sunny.UI.UIPanel();
            this.label_ResultList = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.uiButton_Clear = new Sunny.UI.UISymbolButton();
            this.uiButton_OK = new Sunny.UI.UISymbolButton();
            this.uiButton_Cancel = new Sunny.UI.UISymbolButton();
            this.TLP_Content = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlTypes = new Calin.TaskPulse.Core.Views.FixIndexTabControl();
            this.treeViewCategories = new System.Windows.Forms.TreeView();
            this.label_TreeCaption = new System.Windows.Forms.Label();
            this.uiPanel_Message.SuspendLayout();
            this.panel1.SuspendLayout();
            this.TLP_Content.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiPanel_Message
            // 
            this.TLP_Content.SetColumnSpan(this.uiPanel_Message, 2);
            this.uiPanel_Message.Controls.Add(this.label_ResultList);
            this.uiPanel_Message.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiPanel_Message.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiPanel_Message.Location = new System.Drawing.Point(0, 443);
            this.uiPanel_Message.Margin = new System.Windows.Forms.Padding(0);
            this.uiPanel_Message.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel_Message.Name = "uiPanel_Message";
            this.uiPanel_Message.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPanel_Message.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiPanel_Message.Size = new System.Drawing.Size(586, 120);
            this.uiPanel_Message.TabIndex = 3;
            this.uiPanel_Message.Text = null;
            this.uiPanel_Message.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_ResultList
            // 
            this.label_ResultList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_ResultList.Location = new System.Drawing.Point(0, 0);
            this.label_ResultList.Margin = new System.Windows.Forms.Padding(3);
            this.label_ResultList.Name = "label_ResultList";
            this.label_ResultList.Padding = new System.Windows.Forms.Padding(15, 9, 0, 0);
            this.label_ResultList.Size = new System.Drawing.Size(586, 120);
            this.label_ResultList.TabIndex = 5;
            this.label_ResultList.Text = "ResultList";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.uiButton_Clear);
            this.panel1.Controls.Add(this.uiButton_OK);
            this.panel1.Controls.Add(this.uiButton_Cancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(589, 446);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(264, 114);
            this.panel1.TabIndex = 4;
            // 
            // uiButton_Clear
            // 
            this.uiButton_Clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.uiButton_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Clear.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_Clear.Location = new System.Drawing.Point(140, 66);
            this.uiButton_Clear.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Clear.Name = "uiButton_Clear";
            this.uiButton_Clear.Radius = 10;
            this.uiButton_Clear.Size = new System.Drawing.Size(100, 35);
            this.uiButton_Clear.Symbol = 362746;
            this.uiButton_Clear.TabIndex = 6;
            this.uiButton_Clear.Text = "全部清除";
            this.uiButton_Clear.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Clear.Click += new System.EventHandler(this.uiButton_Clear_Click);
            // 
            // uiButton_OK
            // 
            this.uiButton_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.uiButton_OK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.uiButton_OK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_OK.Location = new System.Drawing.Point(23, 21);
            this.uiButton_OK.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_OK.Name = "uiButton_OK";
            this.uiButton_OK.Radius = 10;
            this.uiButton_OK.Size = new System.Drawing.Size(100, 80);
            this.uiButton_OK.TabIndex = 5;
            this.uiButton_OK.Text = "確定";
            this.uiButton_OK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_OK.Click += new System.EventHandler(this.uiButton_OK_Click);
            // 
            // uiButton_Cancel
            // 
            this.uiButton_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.uiButton_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.uiButton_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.uiButton_Cancel.Location = new System.Drawing.Point(140, 21);
            this.uiButton_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Cancel.Name = "uiButton_Cancel";
            this.uiButton_Cancel.Radius = 10;
            this.uiButton_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Size = new System.Drawing.Size(100, 35);
            this.uiButton_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton_Cancel.Symbol = 361453;
            this.uiButton_Cancel.TabIndex = 4;
            this.uiButton_Cancel.Text = "取消";
            this.uiButton_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Cancel.Click += new System.EventHandler(this.uiButton_Cancel_Click);
            // 
            // TLP_Content
            // 
            this.TLP_Content.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.TLP_Content.ColumnCount = 3;
            this.TLP_Content.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.TLP_Content.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Content.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 270F));
            this.TLP_Content.Controls.Add(this.tabControlTypes, 1, 0);
            this.TLP_Content.Controls.Add(this.panel1, 2, 2);
            this.TLP_Content.Controls.Add(this.treeViewCategories, 0, 1);
            this.TLP_Content.Controls.Add(this.uiPanel_Message, 0, 2);
            this.TLP_Content.Controls.Add(this.label_TreeCaption, 0, 0);
            this.TLP_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP_Content.Location = new System.Drawing.Point(2, 35);
            this.TLP_Content.Margin = new System.Windows.Forms.Padding(30);
            this.TLP_Content.Name = "TLP_Content";
            this.TLP_Content.RowCount = 3;
            this.TLP_Content.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.TLP_Content.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Content.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.TLP_Content.Size = new System.Drawing.Size(856, 563);
            this.TLP_Content.TabIndex = 6;
            // 
            // tabControlTypes
            // 
            this.tabControlTypes.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.TLP_Content.SetColumnSpan(this.tabControlTypes, 2);
            this.tabControlTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlTypes.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tabControlTypes.HideTabHeaders = true;
            this.tabControlTypes.ItemSize = new System.Drawing.Size(100, 24);
            this.tabControlTypes.Location = new System.Drawing.Point(143, 5);
            this.tabControlTypes.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.tabControlTypes.Multiline = true;
            this.tabControlTypes.Name = "tabControlTypes";
            this.TLP_Content.SetRowSpan(this.tabControlTypes, 2);
            this.tabControlTypes.SelectedIndex = 0;
            this.tabControlTypes.Size = new System.Drawing.Size(710, 435);
            this.tabControlTypes.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tabControlTypes.TabIndex = 4;
            this.tabControlTypes.TabStop = false;
            // 
            // treeViewCategories
            // 
            this.treeViewCategories.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.treeViewCategories.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeViewCategories.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeViewCategories.FullRowSelect = true;
            this.treeViewCategories.HideSelection = false;
            this.treeViewCategories.HotTracking = true;
            this.treeViewCategories.ItemHeight = 28;
            this.treeViewCategories.Location = new System.Drawing.Point(5, 33);
            this.treeViewCategories.Margin = new System.Windows.Forms.Padding(5, 3, 3, 9);
            this.treeViewCategories.Name = "treeViewCategories";
            this.treeViewCategories.ShowRootLines = false;
            this.treeViewCategories.Size = new System.Drawing.Size(132, 401);
            this.treeViewCategories.TabIndex = 5;
            this.treeViewCategories.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewCategories_AfterSelect);
            // 
            // label_TreeCaption
            // 
            this.label_TreeCaption.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label_TreeCaption.AutoSize = true;
            this.label_TreeCaption.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_TreeCaption.Location = new System.Drawing.Point(19, 7);
            this.label_TreeCaption.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.label_TreeCaption.Name = "label_TreeCaption";
            this.label_TreeCaption.Size = new System.Drawing.Size(102, 20);
            this.label_TreeCaption.TabIndex = 6;
            this.label_TreeCaption.Text = "TreeCaption";
            this.label_TreeCaption.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // FlowLayoutSelector
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(860, 600);
            this.Controls.Add(this.TLP_Content);
            this.EscClose = true;
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "FlowLayoutSelector";
            this.Padding = new System.Windows.Forms.Padding(2, 35, 2, 2);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Title";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 800, 450);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FlowLayoutSelector_FormClosing);
            this.Shown += new System.EventHandler(this.FlowLayoutSelector_Shown);
            this.uiPanel_Message.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.TLP_Content.ResumeLayout(false);
            this.TLP_Content.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UIPanel uiPanel_Message;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton uiButton_OK;
        private Sunny.UI.UISymbolButton uiButton_Cancel;
        private System.Windows.Forms.TableLayoutPanel TLP_Content;
        private System.Windows.Forms.Label label_ResultList;
        private Sunny.UI.UISymbolButton uiButton_Clear;
        private FixIndexTabControl tabControlTypes;
        private System.Windows.Forms.TreeView treeViewCategories;
        private System.Windows.Forms.Label label_TreeCaption;
    }
}