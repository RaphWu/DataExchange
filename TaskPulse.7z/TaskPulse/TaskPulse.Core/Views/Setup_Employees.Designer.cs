﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Employees
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.adgv = new Zuby.ADGV.AdvancedDataGridView();
            this.JobTitle = new Sunny.UI.UIComboBox();
            this.Department = new Sunny.UI.UIComboBox();
            this.btnSave = new Sunny.UI.UISymbolButton();
            this.CarbonCopies = new Sunny.UI.UITextBox();
            this.IsEngineer = new Sunny.UI.UICheckBox();
            this.label_CarbonCopies = new Sunny.UI.UILabel();
            this.label_Email = new Sunny.UI.UILabel();
            this.label_JobTitle = new Sunny.UI.UILabel();
            this.Email = new Sunny.UI.UITextBox();
            this.label_Department = new Sunny.UI.UILabel();
            this.label_EmployeeName = new Sunny.UI.UILabel();
            this.EmployeeName = new Sunny.UI.UITextBox();
            this.label_EmployeeId = new Sunny.UI.UILabel();
            this.EmployeeId = new Sunny.UI.UITextBox();
            this.panelEmployee = new System.Windows.Forms.Panel();
            this.StatusChangeAt = new Sunny.UI.UIDatetimePicker();
            this.label_StatusChangeAt = new Sunny.UI.UILabel();
            this.Status = new Sunny.UI.UIComboBox();
            this.label_Status = new Sunny.UI.UILabel();
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.panelPermission = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).BeginInit();
            this.panelEmployee.SuspendLayout();
            this.TLP.SuspendLayout();
            this.SuspendLayout();
            // 
            // adgv
            // 
            this.adgv.AllowUserToAddRows = false;
            this.adgv.AllowUserToDeleteRows = false;
            this.adgv.AllowUserToResizeRows = false;
            this.adgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.adgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TLP.SetColumnSpan(this.adgv, 2);
            this.adgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adgv.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.adgv.FilterAndSortEnabled = true;
            this.adgv.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.Location = new System.Drawing.Point(3, 3);
            this.adgv.MaxFilterButtonImageHeight = 23;
            this.adgv.MultiSelect = false;
            this.adgv.Name = "adgv";
            this.adgv.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adgv.RowTemplate.Height = 24;
            this.adgv.Size = new System.Drawing.Size(1155, 407);
            this.adgv.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.TabIndex = 11;
            this.adgv.SelectionChanged += new System.EventHandler(this.ADGV_SelectionChanged);
            // 
            // JobTitle
            // 
            this.JobTitle.DataSource = null;
            this.JobTitle.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.JobTitle.FillColor = System.Drawing.Color.White;
            this.JobTitle.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.JobTitle.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.JobTitle.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.JobTitle.Location = new System.Drawing.Point(81, 96);
            this.JobTitle.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.JobTitle.MinimumSize = new System.Drawing.Size(63, 0);
            this.JobTitle.Name = "JobTitle";
            this.JobTitle.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.JobTitle.Size = new System.Drawing.Size(218, 29);
            this.JobTitle.SymbolSize = 24;
            this.JobTitle.TabIndex = 94;
            this.JobTitle.Text = "uiComboBox1";
            this.JobTitle.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.JobTitle.Watermark = "";
            // 
            // Department
            // 
            this.Department.DataSource = null;
            this.Department.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Department.FillColor = System.Drawing.Color.White;
            this.Department.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Department.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Department.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Department.Location = new System.Drawing.Point(81, 57);
            this.Department.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Department.MinimumSize = new System.Drawing.Size(63, 0);
            this.Department.Name = "Department";
            this.Department.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Department.Size = new System.Drawing.Size(218, 29);
            this.Department.SymbolSize = 24;
            this.Department.TabIndex = 93;
            this.Department.Text = "uiComboBox1";
            this.Department.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Department.Watermark = "";
            // 
            // btnSave
            // 
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnSave.Location = new System.Drawing.Point(531, 170);
            this.btnSave.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Radius = 10;
            this.btnSave.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnSave.Size = new System.Drawing.Size(140, 40);
            this.btnSave.Symbol = 61639;
            this.btnSave.TabIndex = 92;
            this.btnSave.Text = "儲存員工資料";
            this.btnSave.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // CarbonCopies
            // 
            this.CarbonCopies.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CarbonCopies.FillDisableColor = System.Drawing.Color.White;
            this.CarbonCopies.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.CarbonCopies.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CarbonCopies.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CarbonCopies.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CarbonCopies.Location = new System.Drawing.Point(81, 174);
            this.CarbonCopies.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CarbonCopies.MinimumSize = new System.Drawing.Size(1, 16);
            this.CarbonCopies.Name = "CarbonCopies";
            this.CarbonCopies.Padding = new System.Windows.Forms.Padding(5);
            this.CarbonCopies.ShowButton = true;
            this.CarbonCopies.ShowText = false;
            this.CarbonCopies.Size = new System.Drawing.Size(219, 29);
            this.CarbonCopies.TabIndex = 91;
            this.CarbonCopies.TabStop = false;
            this.CarbonCopies.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CarbonCopies.Watermark = "";
            this.CarbonCopies.ButtonClick += new System.EventHandler(this.CarbonCopies_ButtonClick);
            // 
            // IsEngineer
            // 
            this.IsEngineer.CheckBoxSize = 18;
            this.IsEngineer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.IsEngineer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IsEngineer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.IsEngineer.Location = new System.Drawing.Point(371, 135);
            this.IsEngineer.MinimumSize = new System.Drawing.Size(1, 1);
            this.IsEngineer.Name = "IsEngineer";
            this.IsEngineer.Size = new System.Drawing.Size(165, 29);
            this.IsEngineer.TabIndex = 1;
            this.IsEngineer.Text = "是否為維護工程師";
            // 
            // label_CarbonCopies
            // 
            this.label_CarbonCopies.BackColor = System.Drawing.Color.Transparent;
            this.label_CarbonCopies.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_CarbonCopies.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_CarbonCopies.Location = new System.Drawing.Point(0, 174);
            this.label_CarbonCopies.Name = "label_CarbonCopies";
            this.label_CarbonCopies.Size = new System.Drawing.Size(77, 29);
            this.label_CarbonCopies.TabIndex = 88;
            this.label_CarbonCopies.Text = "副本人員";
            this.label_CarbonCopies.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Email
            // 
            this.label_Email.BackColor = System.Drawing.Color.Transparent;
            this.label_Email.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Email.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Email.Location = new System.Drawing.Point(304, 18);
            this.label_Email.Margin = new System.Windows.Forms.Padding(0);
            this.label_Email.Name = "label_Email";
            this.label_Email.Size = new System.Drawing.Size(63, 29);
            this.label_Email.TabIndex = 14;
            this.label_Email.Text = "Email";
            this.label_Email.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_JobTitle
            // 
            this.label_JobTitle.BackColor = System.Drawing.Color.Transparent;
            this.label_JobTitle.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_JobTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_JobTitle.Location = new System.Drawing.Point(23, 96);
            this.label_JobTitle.Margin = new System.Windows.Forms.Padding(0);
            this.label_JobTitle.Name = "label_JobTitle";
            this.label_JobTitle.Size = new System.Drawing.Size(52, 29);
            this.label_JobTitle.TabIndex = 18;
            this.label_JobTitle.Text = "職稱";
            this.label_JobTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Email
            // 
            this.Email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Email.FillDisableColor = System.Drawing.Color.White;
            this.Email.FillReadOnlyColor = System.Drawing.Color.White;
            this.Email.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Email.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Email.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Email.Location = new System.Drawing.Point(371, 18);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Email.MinimumSize = new System.Drawing.Size(1, 16);
            this.Email.Name = "Email";
            this.Email.Padding = new System.Windows.Forms.Padding(5);
            this.Email.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Email.ShowText = false;
            this.Email.Size = new System.Drawing.Size(300, 29);
            this.Email.TabIndex = 13;
            this.Email.TabStop = false;
            this.Email.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Email.Watermark = "";
            // 
            // label_Department
            // 
            this.label_Department.BackColor = System.Drawing.Color.Transparent;
            this.label_Department.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Department.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Department.Location = new System.Drawing.Point(23, 57);
            this.label_Department.Margin = new System.Windows.Forms.Padding(0);
            this.label_Department.Name = "label_Department";
            this.label_Department.Size = new System.Drawing.Size(52, 29);
            this.label_Department.TabIndex = 16;
            this.label_Department.Text = "部門";
            this.label_Department.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_EmployeeName
            // 
            this.label_EmployeeName.BackColor = System.Drawing.Color.Transparent;
            this.label_EmployeeName.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_EmployeeName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_EmployeeName.Location = new System.Drawing.Point(24, 135);
            this.label_EmployeeName.Margin = new System.Windows.Forms.Padding(0);
            this.label_EmployeeName.Name = "label_EmployeeName";
            this.label_EmployeeName.Size = new System.Drawing.Size(52, 29);
            this.label_EmployeeName.TabIndex = 14;
            this.label_EmployeeName.Text = "姓名";
            this.label_EmployeeName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EmployeeName
            // 
            this.EmployeeName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EmployeeName.FillDisableColor = System.Drawing.Color.White;
            this.EmployeeName.FillReadOnlyColor = System.Drawing.Color.White;
            this.EmployeeName.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.EmployeeName.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.EmployeeName.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.EmployeeName.Location = new System.Drawing.Point(81, 135);
            this.EmployeeName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EmployeeName.MinimumSize = new System.Drawing.Size(1, 16);
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.Padding = new System.Windows.Forms.Padding(5);
            this.EmployeeName.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.EmployeeName.ShowText = false;
            this.EmployeeName.Size = new System.Drawing.Size(219, 29);
            this.EmployeeName.TabIndex = 13;
            this.EmployeeName.TabStop = false;
            this.EmployeeName.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.EmployeeName.Watermark = "";
            // 
            // label_EmployeeId
            // 
            this.label_EmployeeId.BackColor = System.Drawing.Color.Transparent;
            this.label_EmployeeId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_EmployeeId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_EmployeeId.Location = new System.Drawing.Point(23, 18);
            this.label_EmployeeId.Margin = new System.Windows.Forms.Padding(0);
            this.label_EmployeeId.Name = "label_EmployeeId";
            this.label_EmployeeId.Size = new System.Drawing.Size(52, 29);
            this.label_EmployeeId.TabIndex = 12;
            this.label_EmployeeId.Text = "工號";
            this.label_EmployeeId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // EmployeeId
            // 
            this.EmployeeId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EmployeeId.FillDisableColor = System.Drawing.Color.White;
            this.EmployeeId.FillReadOnlyColor = System.Drawing.Color.White;
            this.EmployeeId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.EmployeeId.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.EmployeeId.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.EmployeeId.Location = new System.Drawing.Point(80, 18);
            this.EmployeeId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EmployeeId.MinimumSize = new System.Drawing.Size(1, 16);
            this.EmployeeId.Name = "EmployeeId";
            this.EmployeeId.Padding = new System.Windows.Forms.Padding(5);
            this.EmployeeId.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.EmployeeId.ShowText = false;
            this.EmployeeId.Size = new System.Drawing.Size(219, 29);
            this.EmployeeId.TabIndex = 11;
            this.EmployeeId.TabStop = false;
            this.EmployeeId.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.EmployeeId.Watermark = "";
            // 
            // panelEmployee
            // 
            this.panelEmployee.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panelEmployee.Controls.Add(this.StatusChangeAt);
            this.panelEmployee.Controls.Add(this.label_StatusChangeAt);
            this.panelEmployee.Controls.Add(this.Status);
            this.panelEmployee.Controls.Add(this.label_Status);
            this.panelEmployee.Controls.Add(this.JobTitle);
            this.panelEmployee.Controls.Add(this.EmployeeId);
            this.panelEmployee.Controls.Add(this.Email);
            this.panelEmployee.Controls.Add(this.Department);
            this.panelEmployee.Controls.Add(this.label_EmployeeName);
            this.panelEmployee.Controls.Add(this.label_JobTitle);
            this.panelEmployee.Controls.Add(this.EmployeeName);
            this.panelEmployee.Controls.Add(this.IsEngineer);
            this.panelEmployee.Controls.Add(this.label_Email);
            this.panelEmployee.Controls.Add(this.CarbonCopies);
            this.panelEmployee.Controls.Add(this.btnSave);
            this.panelEmployee.Controls.Add(this.label_Department);
            this.panelEmployee.Controls.Add(this.label_CarbonCopies);
            this.panelEmployee.Controls.Add(this.label_EmployeeId);
            this.panelEmployee.Location = new System.Drawing.Point(3, 416);
            this.panelEmployee.Name = "panelEmployee";
            this.panelEmployee.Size = new System.Drawing.Size(694, 224);
            this.panelEmployee.TabIndex = 12;
            // 
            // StatusChangeAt
            // 
            this.StatusChangeAt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.StatusChangeAt.CanEmpty = true;
            this.StatusChangeAt.DateFormat = "yyyy/MM/dd";
            this.StatusChangeAt.FillColor = System.Drawing.Color.White;
            this.StatusChangeAt.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.StatusChangeAt.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.StatusChangeAt.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.StatusChangeAt.Location = new System.Drawing.Point(371, 96);
            this.StatusChangeAt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.StatusChangeAt.MaxLength = 10;
            this.StatusChangeAt.MinimumSize = new System.Drawing.Size(63, 0);
            this.StatusChangeAt.Name = "StatusChangeAt";
            this.StatusChangeAt.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.StatusChangeAt.ShowToday = true;
            this.StatusChangeAt.Size = new System.Drawing.Size(300, 29);
            this.StatusChangeAt.SymbolDropDown = 61555;
            this.StatusChangeAt.SymbolNormal = 61555;
            this.StatusChangeAt.SymbolSize = 24;
            this.StatusChangeAt.TabIndex = 99;
            this.StatusChangeAt.Text = "1900/01/01";
            this.StatusChangeAt.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.StatusChangeAt.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.StatusChangeAt.Watermark = "";
            // 
            // label_StatusChangeAt
            // 
            this.label_StatusChangeAt.BackColor = System.Drawing.Color.Transparent;
            this.label_StatusChangeAt.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_StatusChangeAt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_StatusChangeAt.Location = new System.Drawing.Point(314, 94);
            this.label_StatusChangeAt.Margin = new System.Windows.Forms.Padding(0);
            this.label_StatusChangeAt.Name = "label_StatusChangeAt";
            this.label_StatusChangeAt.Size = new System.Drawing.Size(54, 29);
            this.label_StatusChangeAt.TabIndex = 98;
            this.label_StatusChangeAt.Text = "日期";
            this.label_StatusChangeAt.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Status
            // 
            this.Status.DataSource = null;
            this.Status.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Status.FillColor = System.Drawing.Color.White;
            this.Status.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Status.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Status.Location = new System.Drawing.Point(371, 57);
            this.Status.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Status.MinimumSize = new System.Drawing.Size(63, 0);
            this.Status.Name = "Status";
            this.Status.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Status.Size = new System.Drawing.Size(300, 29);
            this.Status.SymbolSize = 24;
            this.Status.TabIndex = 96;
            this.Status.Text = "uiComboBox1";
            this.Status.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Status.Watermark = "";
            // 
            // label_Status
            // 
            this.label_Status.BackColor = System.Drawing.Color.Transparent;
            this.label_Status.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Status.Location = new System.Drawing.Point(313, 57);
            this.label_Status.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status.Name = "label_Status";
            this.label_Status.Size = new System.Drawing.Size(54, 29);
            this.label_Status.TabIndex = 95;
            this.label_Status.Text = "狀態";
            this.label_Status.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 2;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 700F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.adgv, 0, 0);
            this.TLP.Controls.Add(this.panelEmployee, 0, 1);
            this.TLP.Controls.Add(this.panelPermission, 1, 1);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 2;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 230F));
            this.TLP.Size = new System.Drawing.Size(1161, 643);
            this.TLP.TabIndex = 13;
            // 
            // panelPermission
            // 
            this.panelPermission.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPermission.Location = new System.Drawing.Point(703, 416);
            this.panelPermission.Name = "panelPermission";
            this.panelPermission.Size = new System.Drawing.Size(455, 224);
            this.panelPermission.TabIndex = 13;
            // 
            // Setup_Employees
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.TLP);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_Employees";
            this.Size = new System.Drawing.Size(1161, 643);
            this.Load += new System.EventHandler(this.Setup_Employees_Load);
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).EndInit();
            this.panelEmployee.ResumeLayout(false);
            this.TLP.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Zuby.ADGV.AdvancedDataGridView adgv;
        private Sunny.UI.UILabel label_EmployeeId;
        private Sunny.UI.UITextBox EmployeeId;
        private Sunny.UI.UILabel label_EmployeeName;
        private Sunny.UI.UITextBox EmployeeName;
        private Sunny.UI.UILabel label_JobTitle;
        private Sunny.UI.UILabel label_Department;
        private Sunny.UI.UILabel label_Email;
        private Sunny.UI.UITextBox Email;
        private Sunny.UI.UILabel label_CarbonCopies;
        private Sunny.UI.UICheckBox IsEngineer;
        private Sunny.UI.UITextBox CarbonCopies;
        private Sunny.UI.UISymbolButton btnSave;
        private Sunny.UI.UIComboBox JobTitle;
        private Sunny.UI.UIComboBox Department;
        private System.Windows.Forms.Panel panelEmployee;
        private System.Windows.Forms.TableLayoutPanel TLP;
        private System.Windows.Forms.Panel panelPermission;
        private Sunny.UI.UIComboBox Status;
        private Sunny.UI.UILabel label_Status;
        private Sunny.UI.UILabel label_StatusChangeAt;
        private Sunny.UI.UIDatetimePicker StatusChangeAt;
    }
}
