﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineInfo1 : UserControl
    {
        #region fields

        private readonly ILifetimeScope _scope;
        private readonly CoreContext _context;
        private readonly FieldTitle _fieldTitle;

        private readonly DbSet<MachineBrand> _brands;
        private readonly DbSet<MachineLocation> _locations;
        private readonly DbSet<MachineCondition> _conditions;

        private List<ListViewModel> _vmBrands = null;
        private ListViewModel _vmBrand = null;
        private List<ListViewModel> _vmLocs = null;
        private ListViewModel _vmLoc = null;
        private List<ListViewModel> _vmConds = null;
        private ListViewModel _vmCond = null;

        #endregion fields

        public Setup_MachineInfo1(ILifetimeScope lifetimeScope, CoreContext coreContext, FieldTitle fieldTitle)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _context = coreContext;
            _fieldTitle = fieldTitle;

            _brands = _context.MachineBrands;
            _locations = _context.MachineLocations;
            _conditions = _context.MachineConditions;

            string itemName = _fieldTitle.Brand;
            HeadLabel_Brand.Text = itemName;
            CommonStyles.SetListBox(List_Brands);
            CommonStyles.SetCrudButton(Brand_Create, "C", itemName);
            CommonStyles.SetCrudButton(Brand_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Brand_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Brand_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Brand_Down, "DOWN", itemName);

            itemName = _fieldTitle.Location;
            HeadLabel_Location.Text = itemName;
            CommonStyles.SetListBox(List_Locations);
            CommonStyles.SetCrudButton(Location_Create, "C", itemName);
            CommonStyles.SetCrudButton(Location_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Location_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Location_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Location_Down, "DOWN", itemName);

            itemName = _fieldTitle.Condition;
            HeadLabel_Condition.Text = itemName;
            CommonStyles.SetListBox(List_Conditions);
            CommonStyles.SetCrudButton(Condition_Create, "C", itemName);
            CommonStyles.SetCrudButton(Condition_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Condition_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Condition_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Condition_Down, "DOWN", itemName);
        }

        private async void Setup_MachineInfo1_Load(object sender, EventArgs e)
        {
            await UpdateBrandsView();
            await UpdateLocationsView();
            await UpdateConditionsView();
        }

        /********************
         * Brand
         ********************/
        private async Task UpdateBrandsView()
        {
            var query = await _brands
                .OrderBy(b => b.OrderNo)
                .AsNoTracking()
                .ToListAsync();
            _vmBrands = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.BrandName, OrderNo = b.OrderNo })
                .ToList();
            List_Brands.DataSource = null;
            List_Brands.ValueMember = nameof(ListViewModel.Id);
            List_Brands.DisplayMember = nameof(ListViewModel.Name);
            List_Brands.DataSource = _vmBrands;
        }

        private void List_Brands_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmBrand = List_Brands.SelectedItem as ListViewModel;
            if (_vmBrand != null)
            {
                Brand_Edit.Enabled = true;
                Brand_Delete.Enabled = true;

                if (List_Brands.DataSource is List<ListViewModel> vmBrand)
                {
                    var vmOrderNo = vmBrand.FirstOrDefault(w => w.Id == _vmBrand.Id).OrderNo;
                    Brand_Up.Enabled = vmOrderNo != vmBrand.Min(w => w.OrderNo);
                    Brand_Down.Enabled = vmOrderNo != vmBrand.Max(w => w.OrderNo);
                }
                else
                {
                    Brand_Up.Enabled = false;
                    Brand_Down.Enabled = false;
                }
            }
            else
            {
                Brand_Edit.Enabled = false;
                Brand_Delete.Enabled = false;
                Brand_Up.Enabled = false;
                Brand_Down.Enabled = false;
            }
        }

        private async void Brand_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{_fieldTitle.Brand}名稱";
            string caption = $"新{_fieldTitle.Brand}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.Brand}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.Brand}名稱必須小於等於 30 個字元！"),
                input => _brands.Any(m => m.BrandName == input) ? (false, $"{_fieldTitle.Brand}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newBrandName = crud.Result.StringValue;
                    int maxOrderNo = _brands.Max(w => w.OrderNo);

                    _context.MachineBrands.Add(new MachineBrand() { BrandName = newBrandName, OrderNo = maxOrderNo + 1 });
                    await _context.SaveChangesAsync();
                    await UpdateBrandsView();
                    List_Brands.SelectedIndex = _vmBrands.FindIndex(m => m.Name == newBrandName);

                    MessageBox.Show($"已增加新{_fieldTitle.Brand}: {newBrandName}",
                                    $"新增成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void Brand_Edit_Click(object sender, EventArgs e)
        {
            if (_vmBrand != null)
            {
                var thisBrand = _vmBrand;
                string title = $"請輸入新{_fieldTitle.Brand}名稱";
                string oldCaption = $"原{_fieldTitle.Brand}名稱";
                string newCaption = $"新{_fieldTitle.Brand}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.Brand}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.Brand}名稱必須小於等於 30 個字元！"),
                    input => _brands.Any(m => m.BrandName == input) ? (false, $"{_fieldTitle.Brand}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisBrand.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        string newBrandName = crud.Result.StringValue;

                        var newBrand = _brands.FirstOrDefault(m => m.Id == thisBrand.Id);
                        if (newBrand != null)
                        {
                            newBrand.BrandName = newBrandName;
                            await _context.SaveChangesAsync();
                            await UpdateBrandsView();
                            List_Brands.SelectedIndex = _vmBrands.FindIndex(m => m.Id == newBrand.Id);

                            MessageBox.Show($"{_fieldTitle.Brand} {thisBrand.Name} 名稱已更新為 {newBrandName}",
                                            $"更新成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private async void Brand_Delete_Click(object sender, EventArgs e)
        {
            if (_vmBrand != null)
            {
                var thisBrand = _vmBrand;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {_fieldTitle.Brand} {thisBrand.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetBrand = _brands.FirstOrDefault(m => m.Id == thisBrand.Id);
                    if (targetBrand != null)
                    {
                        _brands.Remove(targetBrand);
                        await _context.SaveChangesAsync();
                        await UpdateBrandsView();

                        MessageBox.Show($"{_fieldTitle.Brand} {thisBrand.Name} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Brand_Up_Click(object sender, EventArgs e)
        {
            if (_vmBrand != null)
            {
                var thisVmWs = _vmBrand;
                var smallerVmWs = _vmBrands.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapBrandOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Brands.SelectedIndex = _vmBrands.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Brand_Down_Click(object sender, EventArgs e)
        {
            if (_vmBrand != null)
            {
                var thisVm = _vmBrand;
                var biggerVm = _vmBrands.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapBrandOrderNo(thisVm.Id, biggerVm.Id);
                    List_Brands.SelectedIndex = _vmBrands.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapBrandOrderNo(int id1, int id2)
        {
            var entity1 = _brands.FirstOrDefault(w => w.Id == id1);
            var entity2 = _brands.FirstOrDefault(w => w.Id == id2);

            (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
            await _context.SaveChangesAsync();
            await UpdateBrandsView();
        }

        /********************
         * Location
         ********************/
        private async Task UpdateLocationsView()
        {
            var query = await _locations
                .OrderBy(b => b.OrderNo)
                .AsNoTracking()
                .ToListAsync();
            _vmLocs = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.LocationName, OrderNo = b.OrderNo })
                .ToList();
            List_Locations.DataSource = null;
            List_Locations.ValueMember = nameof(ListViewModel.Id);
            List_Locations.DisplayMember = nameof(ListViewModel.Name);
            List_Locations.DataSource = _vmLocs;
        }

        private void List_Locations_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmLoc = List_Locations.SelectedItem as ListViewModel;
            if (_vmLoc != null)
            {
                Location_Edit.Enabled = true;
                Location_Delete.Enabled = true;

                if (List_Locations.DataSource is List<ListViewModel> vmLocation)
                {
                    var vmOrderNo = vmLocation.FirstOrDefault(w => w.Id == _vmLoc.Id).OrderNo;
                    Location_Up.Enabled = vmOrderNo != vmLocation.Min(w => w.OrderNo);
                    Location_Down.Enabled = vmOrderNo != vmLocation.Max(w => w.OrderNo);
                }
                else
                {
                    Location_Up.Enabled = false;
                    Location_Down.Enabled = false;
                }
            }
            else
            {
                Location_Edit.Enabled = false;
                Location_Delete.Enabled = false;
                Location_Up.Enabled = false;
                Location_Down.Enabled = false;
            }
        }

        private async void Location_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{_fieldTitle.Location}名稱";
            string caption = $"新{_fieldTitle.Location}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.Location}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.Location}名稱必須小於等於 30 個字元！"),
                input => _locations.Any(m => m.LocationName == input) ? (false, $"{_fieldTitle.Location}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newLocationName = crud.Result.StringValue;
                    int maxOrderNo = _locations.Max(w => w.OrderNo);

                    _context.MachineLocations.Add(new MachineLocation() { LocationName = newLocationName, OrderNo = maxOrderNo + 1 });
                    await _context.SaveChangesAsync();
                    await UpdateLocationsView();
                    List_Locations.SelectedIndex = _vmLocs.FindIndex(m => m.Name == newLocationName);

                    MessageBox.Show($"已增加新{_fieldTitle.Location}: {newLocationName}",
                                    $"新增成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void Location_Edit_Click(object sender, EventArgs e)
        {
            if (_vmLoc != null)
            {
                var thisLocation = _vmLoc;
                string title = $"請輸入新{_fieldTitle.Location}名稱";
                string oldCaption = $"原{_fieldTitle.Location}名稱";
                string newCaption = $"新{_fieldTitle.Location}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.Location}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.Location}名稱必須小於等於 30 個字元！"),
                    input => _locations.Any(m => m.LocationName == input) ? (false, $"{_fieldTitle.Location}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisLocation.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        string newLocationName = crud.Result.StringValue;

                        var newLocation = _locations.FirstOrDefault(m => m.Id == thisLocation.Id);
                        if (newLocation != null)
                        {
                            newLocation.LocationName = newLocationName;
                            await _context.SaveChangesAsync();
                            await UpdateLocationsView();
                            List_Locations.SelectedIndex = _vmLocs.FindIndex(m => m.Id == newLocation.Id);

                            MessageBox.Show($"{_fieldTitle.Location} {thisLocation.Name} 名稱已更新為 {newLocationName}",
                                            $"更新成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private async void Location_Delete_Click(object sender, EventArgs e)
        {
            if (_vmLoc != null)
            {
                var thisLocation = _vmLoc;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {_fieldTitle.Location} {thisLocation.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetLocation = _locations.FirstOrDefault(m => m.Id == thisLocation.Id);
                    if (targetLocation != null)
                    {
                        _locations.Remove(targetLocation);
                        await _context.SaveChangesAsync();
                        await UpdateLocationsView();

                        MessageBox.Show($"{_fieldTitle.Location} {thisLocation.Name} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Location_Up_Click(object sender, EventArgs e)
        {
            if (_vmLoc != null)
            {
                var thisVmWs = _vmLoc;
                var smallerVmWs = _vmLocs.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapLocationOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Locations.SelectedIndex = _vmLocs.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Location_Down_Click(object sender, EventArgs e)
        {
            if (_vmLoc != null)
            {
                var thisVm = _vmLoc;
                var biggerVm = _vmLocs.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapLocationOrderNo(thisVm.Id, biggerVm.Id);
                    List_Locations.SelectedIndex = _vmLocs.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapLocationOrderNo(int id1, int id2)
        {
            var entity1 = _locations.FirstOrDefault(w => w.Id == id1);
            var entity2 = _locations.FirstOrDefault(w => w.Id == id2);

            (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
            await _context.SaveChangesAsync();
            await UpdateLocationsView();
        }

        /********************
         * Condition
         ********************/
        private async Task UpdateConditionsView()
        {
            var query = await _conditions
                .OrderBy(b => b.OrderNo)
                .AsNoTracking()
                .ToListAsync();
            _vmConds = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.ConditionName, OrderNo = b.OrderNo })
                .ToList();
            List_Conditions.DataSource = null;
            List_Conditions.ValueMember = nameof(ListViewModel.Id);
            List_Conditions.DisplayMember = nameof(ListViewModel.Name);
            List_Conditions.DataSource = _vmConds;
        }

        private void List_Conditions_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmCond = List_Conditions.SelectedItem as ListViewModel;
            if (_vmCond != null)
            {
                Condition_Edit.Enabled = true;
                Condition_Delete.Enabled = true;

                if (List_Conditions.DataSource is List<ListViewModel> vmCondition)
                {
                    var vmOrderNo = vmCondition.FirstOrDefault(w => w.Id == _vmCond.Id).OrderNo;
                    Condition_Up.Enabled = vmOrderNo != vmCondition.Min(w => w.OrderNo);
                    Condition_Down.Enabled = vmOrderNo != vmCondition.Max(w => w.OrderNo);
                }
                else
                {
                    Condition_Up.Enabled = false;
                    Condition_Down.Enabled = false;
                }
            }
            else
            {
                Condition_Edit.Enabled = false;
                Condition_Delete.Enabled = false;
                Condition_Up.Enabled = false;
                Condition_Down.Enabled = false;
            }
        }

        private async void Condition_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{_fieldTitle.Condition}名稱";
            string caption = $"新{_fieldTitle.Condition}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.Condition}名稱不可為空白！"),
                input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.Condition}名稱必須小於等於 30 個字元！"),
                input => _conditions.Any(m => m.ConditionName == input) ? (false, $"{_fieldTitle.Condition}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    string newConditionName = crud.Result.StringValue;
                    int maxOrderNo = _conditions.Max(w => w.OrderNo);

                    _context.MachineConditions.Add(new MachineCondition() { ConditionName = newConditionName, OrderNo = maxOrderNo + 1 });
                    await _context.SaveChangesAsync();
                    await UpdateConditionsView();
                    List_Conditions.SelectedIndex = _vmConds.FindIndex(m => m.Name == newConditionName);

                    MessageBox.Show($"已增加新{_fieldTitle.Condition}: {newConditionName}",
                                    $"新增成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }
        }

        private async void Condition_Edit_Click(object sender, EventArgs e)
        {
            if (_vmCond != null)
            {
                var thisCondition = _vmCond;
                string title = $"請輸入新{_fieldTitle.Condition}名稱";
                string oldCaption = $"原{_fieldTitle.Condition}名稱";
                string newCaption = $"新{_fieldTitle.Condition}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.Condition}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{_fieldTitle.Condition}名稱必須小於等於 30 個字元！"),
                    input => _conditions.Any(m => m.ConditionName == input) ? (false, $"{_fieldTitle.Condition}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisCondition.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (FormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        string newConditionName = crud.Result.StringValue;

                        var newCondition = _conditions.FirstOrDefault(m => m.Id == thisCondition.Id);
                        if (newCondition != null)
                        {
                            newCondition.ConditionName = newConditionName;
                            await _context.SaveChangesAsync();
                            await UpdateConditionsView();
                            List_Conditions.SelectedIndex = _vmConds.FindIndex(m => m.Id == newCondition.Id);

                            MessageBox.Show($"{_fieldTitle.Condition} {thisCondition.Name} 名稱已更新為 {newConditionName}",
                                            $"更新成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private async void Condition_Delete_Click(object sender, EventArgs e)
        {
            if (_vmCond != null)
            {
                var thisCondition = _vmCond;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {_fieldTitle.Condition} {thisCondition.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetCondition = _conditions.FirstOrDefault(m => m.Id == thisCondition.Id);
                    if (targetCondition != null)
                    {
                        _conditions.Remove(targetCondition);
                        await _context.SaveChangesAsync();
                        await UpdateConditionsView();

                        MessageBox.Show($"{_fieldTitle.Condition} {thisCondition.Name} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Condition_Up_Click(object sender, EventArgs e)
        {
            if (_vmCond != null)
            {
                var thisVmWs = _vmCond;
                var smallerVmWs = _vmConds.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapConditionOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Conditions.SelectedIndex = _vmConds.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void Condition_Down_Click(object sender, EventArgs e)
        {
            if (_vmCond != null)
            {
                var thisVm = _vmCond;
                var biggerVm = _vmConds.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapConditionOrderNo(thisVm.Id, biggerVm.Id);
                    List_Conditions.SelectedIndex = _vmConds.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapConditionOrderNo(int id1, int id2)
        {
            var entity1 = _conditions.FirstOrDefault(w => w.Id == id1);
            var entity2 = _conditions.FirstOrDefault(w => w.Id == id2);

            (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
            await _context.SaveChangesAsync();
            await UpdateConditionsView();
        }
    }
}
