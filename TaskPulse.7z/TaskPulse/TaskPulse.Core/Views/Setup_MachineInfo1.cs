﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineInfo1 : UIUserControl
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly CoreFieldName _fieldName;
        private readonly CRUD _crud;

        private List<ListViewModel> _vmBrands = null;
        private ListViewModel _vmBrand = null;
        private List<ListViewModel> _vmLocs = null;
        private ListViewModel _vmLoc = null;
        private List<ListViewModel> _vmConditions = null;
        private ListViewModel _vmCondition = null;

        #endregion fields

        public Setup_MachineInfo1(CoreContext coreContext,
                                  CoreData coreData,
                                  CoreFieldName coreFieldName,
                                  CRUD crud)
        {
            InitializeComponent();
            _context = coreContext;
            _coreData = coreData;
            _fieldName = coreFieldName;
            _crud = crud;

            // 廠牌
            HeadLabel_Brand.Text = _fieldName.Brand;
            List_Brands.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Brands.ScrollBarColor = CommonStyles.BackColor;

            Brand_Create.FillColor = CommonStyles.BackColor;
            Brand_Edit.FillColor = CommonStyles.BackColor;
            Brand_Delete.FillColor = CommonStyles.BackColor;
            Brand_Up.FillColor = CommonStyles.BackColor;
            Brand_Down.FillColor = CommonStyles.BackColor;

            // 位置
            HeadLabel_Location.Text = _fieldName.Location;
            List_Locations.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Locations.ScrollBarColor = CommonStyles.BackColor;

            Location_Create.FillColor = CommonStyles.BackColor;
            Location_Edit.FillColor = CommonStyles.BackColor;
            Location_Delete.FillColor = CommonStyles.BackColor;
            Location_Up.FillColor = CommonStyles.BackColor;
            Location_Down.FillColor = CommonStyles.BackColor;

            // 狀態
            HeadLabel_Condition.Text = _fieldName.Condition;
            List_Conditions.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Conditions.ScrollBarColor = CommonStyles.BackColor;

            Condition_Create.FillColor = CommonStyles.BackColor;
            Condition_Edit.FillColor = CommonStyles.BackColor;
            Condition_Delete.FillColor = CommonStyles.BackColor;
            Condition_Up.FillColor = CommonStyles.BackColor;
            Condition_Down.FillColor = CommonStyles.BackColor;
        }

        private async void Setup_MachineInfo1_Load(object sender, EventArgs e)
        {
            await UpdateBrandsView();
            await UpdateLocationsView();
            await UpdateConditionsView();
        }

        /********************
         * Brand
         ********************/
        private async Task UpdateBrandsView()
        {
            var query = await _context.MachineBrands
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmBrands = query
                .Select(b => new ListViewModel { Key = b.Id, Value = b.BrandName, OrderNo = b.OrderNo })
                .ToList();
            List_Brands.DataSource = null;
            List_Brands.ValueMember = nameof(ListViewModel.Key);
            List_Brands.DisplayMember = nameof(ListViewModel.Value);
            List_Brands.DataSource = _vmBrands;
        }


        /********************
         * Location
         ********************/
        private async Task UpdateLocationsView()
        {
            var query = await _context.MachineLocations
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmBrands = query
                .Select(b => new ListViewModel { Key = b.Id, Value = b.Location, OrderNo = b.OrderNo })
                .ToList();
            List_Locations.DataSource = null;
            List_Locations.ValueMember = nameof(ListViewModel.Key);
            List_Locations.DisplayMember = nameof(ListViewModel.Value);
            List_Locations.DataSource = _vmBrands;
        }




        /********************
         * Conditions
         ********************/
        private async Task UpdateConditionsView()
        {
            var query = await _context.MachineConditions
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmConditions = query
                .Select(b => new ListViewModel { Key = b.Id, Value = b.Condition, OrderNo = b.OrderNo })
                .ToList();
            List_Conditions.DataSource = null;
            List_Conditions.ValueMember = nameof(ListViewModel.Key);
            List_Conditions.DisplayMember = nameof(ListViewModel.Value);
            List_Conditions.DataSource = _vmConditions;
        }
    }
}
