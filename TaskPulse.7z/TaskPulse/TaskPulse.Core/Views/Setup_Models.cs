﻿/*
 * 編輯後ListBox不會更新的問題
 * 
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Policy;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Sunny.UI;
using static Sunny.UI.UIMeter;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Models : UIUserControl
    {
        #region fields

        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly CoreData _coreData;
        private readonly MaintiFlowFieldName _fieldName;
        private readonly CRUD _crud;

        private List<ListViewModel> _vmModels = null;
        private ListViewModel _vmModel = null;
        private List<ListViewModel> _vmWss = null;
        private ListViewModel _vmWs = null;

        #endregion fields

        public Setup_Models(CoreContext coreContext,
                            ICore core,
                            CoreData coreData,
                            MaintiFlowFieldName maintiFlowFieldName,
                            CRUD crud)
        {
            InitializeComponent();
            _context = coreContext;
            _core = core;
            _coreData = coreData;
            _fieldName = maintiFlowFieldName;
            _crud = crud;

            Button_Refresh.FillColor = CommonStyles.BackColor;

            // 機種
            HeadLabel_Model.Text = _fieldName.Model;
            List_Models.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Models.ScrollBarColor = CommonStyles.BackColor;

            Model_Create.FillColor = CommonStyles.BackColor;
            Model_Edit.FillColor = CommonStyles.BackColor;
            Model_Delete.FillColor = CommonStyles.BackColor;

            // 工站
            HeadLabel_Workstation.Text = _fieldName.Workstation;
            List_Workstations.ItemSelectBackColor = CommonStyles.SelectionBar;
            List_Workstations.ScrollBarColor = CommonStyles.BackColor;

            WorkStation_Create.FillColor = CommonStyles.BackColor;
            WorkStation_Edit.FillColor = CommonStyles.BackColor;
            WorkStation_Delete.FillColor = CommonStyles.BackColor;
            WorkStation_Up.FillColor = CommonStyles.BackColor;
            WorkStation_Down.FillColor = CommonStyles.BackColor;
        }

        private void Setup_Models_Load(object sender, EventArgs e)
        {
            UpdateModelsView();
            UpdateWorkstationsView();
            //Models_SelectionChanged();
            //Workstations_SelectionChanged();
        }

        /********************
         * Common
         ********************/
        private async void Button_Refresh_Click(object sender, EventArgs e)
        {
            await _core.UpdateCoreDataFromDb();
            UpdateModelsView();
            UpdateWorkstationsView();

            if (_vmModel != null)
                List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Key == _vmModel.Key);

            if (_vmWs != null)
                List_Workstations.SelectedIndex = _vmWss.FindIndex(w => w.Key == _vmWs.Key);
        }

        /********************
         * Models
         ********************/
        private void UpdateModelsView()
        {
            _vmModels = _coreData.Models
                .Select(m => new ListViewModel { Key = m.Id, Value = m.ModelName })
                .ToList();
            List_Models.DataSource = null;
            List_Models.ValueMember = nameof(ListViewModel.Key);
            List_Models.DisplayMember = nameof(ListViewModel.Value);
            List_Models.DataSource = _vmModels;
        }

        private void Models_SelectionChanged()
        {
            _vmModel = List_Models.SelectedItem as ListViewModel;
            if (_vmModel != null)
            {
                Model_Edit.Enabled = true;
                Model_Delete.Enabled = true;
                UpdateWorkstationsView();
            }
            else
            {
                Model_Edit.Enabled = false;
                Model_Delete.Enabled = false;
            }
        }

        private void List_Models_SelectedIndexChanged(object sender, EventArgs e)
        {
            Models_SelectionChanged();
        }

        private async void Model_Create_Click(object sender, EventArgs e)
        {
            string title = "請輸入新機種名稱";
            string caption = "新機種名稱";
            var validor = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "機種名稱不可為空白！"),
                input => input.Length <= 10 ? (true, "") : (false, "機種名稱必須小於等於 10 個字元！"),
                input => _coreData.Models.Any(m => m.ModelName == input) ? (false, "機種名稱已存在！") : (true, "")
                );

            _crud.OneTextBox("", caption, title, caption, validor);
            if (_crud.ShowDialog() == DialogResult.OK)
            {
                string newModelName = _crud.ResultString;

                _context.Models.Add(new Model() { ModelName = newModelName });
                await _context.SaveChangesAsync();
                await _core.UpdateModelsFromDb();
                UpdateModelsView();
                List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Value == newModelName);

                MessageBox.Show($"已增加新機種: {newModelName}",
                                "新增成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private async void Model_Edit_Click(object sender, EventArgs e)
        {
            if (_vmModel != null)
            {
                var thisModel = _vmModel;
                string title = "請輸入新機種名稱";
                string oldCaption = "原機種名稱";
                string newCaption = "新機種名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "機種名稱不可為空白！"),
                    input => input.Length <= 10 ? (true, "") : (false, "機種名稱必須小於等於 10 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, "機種名稱已存在！") : (true, "")
                    );

                _crud.TwoTextBox("", thisModel.Value, newCaption, oldCaption, title, newCaption, validor);
                if (_crud.ShowDialog() == DialogResult.OK)
                {
                    string newModelName = _crud.ResultString;

                    var newModel = _context.Models.FirstOrDefault(m => m.Id == thisModel.Key);
                    if (newModel != null)
                    {
                        newModel.ModelName = newModelName;
                        await _context.SaveChangesAsync();
                        await _core.UpdateModelsFromDb();
                        UpdateModelsView();
                        List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Key == newModel.Id);

                        MessageBox.Show($"機種 {thisModel.Value} 名稱已更新為 {newModelName}",
                                        "更新成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Model_Delete_Click(object sender, EventArgs e)
        {
            if (_vmModel != null)
            {
                var thisModel = _vmModel;
                if (UIMessageBox.ShowAsk2($"確定要刪除機種 {thisModel.Value} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetModel = _context.Models.FirstOrDefault(m => m.Id == thisModel.Key);
                    if (targetModel != null)
                    {
                        _context.Models.Remove(targetModel);
                        await _context.SaveChangesAsync();
                        await _core.UpdateModelsFromDb();
                        UpdateModelsView();

                        MessageBox.Show($"機種 {thisModel.Value} 已刪除",
                                        "刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        /********************
         * Workstations
         ********************/
        private void UpdateWorkstationsView()
        {
            _vmWss = _coreData.Workstations
                .Where(w => w.Model.Id == _vmModel.Key)
                .Select(w => new ListViewModel { Key = w.Id, Value = w.WorkstationName, OrderNo = w.OrderNo })
                .ToList();
            List_Workstations.DataSource = null;
            List_Workstations.ValueMember = nameof(ListViewModel.Key);
            List_Workstations.DisplayMember = nameof(ListViewModel.Value);
            List_Workstations.DataSource = _vmWss;
        }

        private void Workstations_SelectionChanged()
        {
            _vmWs = List_Workstations.SelectedItem as ListViewModel;
            if (_vmWs != null)
            {
                WorkStation_Edit.Enabled = true;
                WorkStation_Delete.Enabled = true;

                if (List_Workstations.DataSource is List<ListViewModel> vmWss)
                {
                    var wsOrderNo = vmWss.FirstOrDefault(w => w.Key == _vmWs.Key).OrderNo;
                    WorkStation_Up.Enabled = wsOrderNo != vmWss.Min(w => w.OrderNo);
                    WorkStation_Down.Enabled = wsOrderNo != vmWss.Max(w => w.OrderNo);
                }
                else
                {
                    WorkStation_Up.Enabled = false;
                    WorkStation_Down.Enabled = false;
                }
            }
            else
            {
                WorkStation_Edit.Enabled = false;
                WorkStation_Delete.Enabled = false;
                WorkStation_Up.Enabled = false;
                WorkStation_Down.Enabled = false;
            }
        }

        private void List_Workstations_SelectedIndexChanged(object sender, EventArgs e)
        {
            Workstations_SelectionChanged();
        }

        private async void WorkStation_Create_Click(object sender, EventArgs e)
        {
            string title = "請輸入新工站名稱";
            string caption = "新工站名稱";
            var validor = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "工站名稱不可為空白！"),
                input => input.Length <= 20 ? (true, "") : (false, "工站名稱必須小於等於 20 個字元！"),
                input => _coreData.Workstations.Any(m => m.WorkstationName == input) ? (false, "工站名稱已存在！") : (true, "")
                );

            _crud.OneTextBox("", caption, title, caption, validor);
            if (_crud.ShowDialog() == DialogResult.OK)
            {
                string newWorkstationName = _crud.ResultString;

                var model = _coreData.Models.FirstOrDefault(m => m.Id == _vmModel.Key);
                int maxOrderNo = _coreData.Workstations.Max(w => w.OrderNo);
                var newWs = _context.Workstations.Add(new Workstation()
                {
                    WorkstationName = newWorkstationName,
                    ModelId = model.Id,
                    OrderNo = maxOrderNo + 1,
                });
                await _context.SaveChangesAsync();
                await _core.UpdateWorkstationsFromDb();
                UpdateWorkstationsView();
                List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Key == newWs.Id);

                MessageBox.Show($"已增加新工站: {newWorkstationName}",
                                "新增成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private async void WorkStation_Edit_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                string title = "請輸入新工站名稱";
                string oldCaption = "原工站名稱";
                string newCaption = "新工站名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "工站名稱不可為空白！"),
                    input => input.Length <= 20 ? (true, "") : (false, "工站名稱必須小於等於 20 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, "工站名稱已存在！") : (true, "")
                    );

                _crud.TwoTextBox("", thisVmWs.Value, newCaption, oldCaption, title, newCaption, validor);
                if (_crud.ShowDialog() == DialogResult.OK)
                {
                    string newWorkstationName = _crud.ResultString;

                    var ws = _context.Workstations.FirstOrDefault(m => m.Id == thisVmWs.Key);
                    if (ws != null)
                    {
                        ws.WorkstationName = newWorkstationName;
                        await _context.SaveChangesAsync();
                        await _core.UpdateWorkstationsFromDb();
                        UpdateWorkstationsView();
                        List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Key == ws.Id);

                        MessageBox.Show($"工站 {thisVmWs.Value} 名稱已更新為 {newWorkstationName}",
                                        "更新成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void WorkStation_Delete_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                if (UIMessageBox.ShowAsk2($"確定要刪除工站 {thisVmWs.Value} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetWs = _context.Workstations.FirstOrDefault(m => m.Id == thisVmWs.Key);
                    if (targetWs != null)
                    {
                        _context.Workstations.Remove(targetWs);
                        await _context.SaveChangesAsync();
                        await _core.UpdateWorkstationsFromDb();
                        UpdateWorkstationsView();

                        MessageBox.Show($"工站 {thisVmWs.Value} 已刪除",
                                        "刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        /********************
         * Workstation.OrderNo
         ********************/
        private async Task ExchangeOrderNo(int wsKey1, int wsKey2)
        {
            try
            {
                var ws1 = _context.Workstations.FirstOrDefault(w => w.Id == wsKey1);
                var ws2 = _context.Workstations.FirstOrDefault(w => w.Id == wsKey2);

                (ws2.OrderNo, ws1.OrderNo) = (ws1.OrderNo, ws2.OrderNo);
                await _context.SaveChangesAsync();
                await _core.UpdateWorkstationsFromDb();
                UpdateWorkstationsView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void WorkStation_Up_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                var smallerVmWs = _vmWss.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await ExchangeOrderNo(thisVmWs.Key, smallerVmWs.Key);
                    List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Key == thisVmWs.Key);
                }
            }
        }

        private async void WorkStation_Down_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                var biggerVmWs = _vmWss.FirstOrDefault(w => w.OrderNo > thisVmWs.OrderNo);
                if (biggerVmWs != null)
                {
                    await ExchangeOrderNo(thisVmWs.Key, biggerVmWs.Key);
                    List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Key == thisVmWs.Key);
                }
            }
        }
    }
}
