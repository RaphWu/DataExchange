﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views.Models;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Models : UIUserControl
    {
        private CoreData _coreData;

        private List<ModelView> _modelViews;

        public Setup_Models(CoreData coreData)
        {
            InitializeComponent();
            _coreData = coreData;

            // 機種
            dgv_Models.AutoGenerateColumns = false;
            dgv_Models.RowHeadersVisible = false;
            dgv_Models.MultiSelect = false;
            dgv_Models.AllowUserToResizeRows = false;
            dgv_Models.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            dgv_Models.GridColor = CommonStyles.BackColor;
            dgv_Models.ScrollBarColor = CommonStyles.BackColor;
            dgv_Models.ScrollBarRectColor = CommonStyles.BackColor;

            Model_Create.FillColor = CommonStyles.BackColor;
            Model_Edit.FillColor = CommonStyles.BackColor;
            Model_Delete.FillColor = CommonStyles.BackColor;

            dgv_Models.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(Model.ModelName),
                HeaderText = "機種",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Font = new Font("Tahoma", 11f),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            // 工站
            dgv_WorkStatios.AutoGenerateColumns = false;
            dgv_WorkStatios.RowHeadersVisible = false;
            dgv_WorkStatios.MultiSelect = false;
            dgv_WorkStatios.AllowUserToResizeRows = false;
            dgv_WorkStatios.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            dgv_WorkStatios.GridColor = CommonStyles.BackColor;
            dgv_WorkStatios.ScrollBarColor = CommonStyles.BackColor;
            dgv_WorkStatios.ScrollBarRectColor = CommonStyles.BackColor;

            WorkStation_Create.FillColor = CommonStyles.BackColor;
            WorkStation_Edit.FillColor = CommonStyles.BackColor;
            WorkStation_Delete.FillColor = CommonStyles.BackColor;
            WorkStation_Up.FillColor = CommonStyles.BackColor;
            WorkStation_Down.FillColor = CommonStyles.BackColor;

            dgv_WorkStatios.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Key",
                HeaderText = "工站",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            dgv_WorkStatios.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Value",
                HeaderText = "機台",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
                ReadOnly = true,
            });
        }

        private void Setup_Models_Load(object sender, EventArgs e)
        {
            UpdateDataSource();
        }

        private void UpdateDataSource()
        {
            _modelViews = _coreData.Models
                .Select(m => new ModelView { ModelId = m.ModelId, ModelName = m.ModelName })
                .ToList();
            dgv_Models.DataSource = _modelViews;

            List<KeyValuePair<string, string>> a = new List<KeyValuePair<string, string>>()
            {
                new KeyValuePair<string, string>("工站1","機台1"),
                new KeyValuePair<string, string>("工站2","機台2"),
                new KeyValuePair<string, string>("工站3","機台3"),
                new KeyValuePair<string, string>("工站4","機台4"),
            };

            dgv_WorkStatios.DataSource = a;
        }

        /********************
         * 機種
         ********************/
        private void Model_Create_Click(object sender, EventArgs e)
        {
            //string value = "請輸入新機種代號";
            //if (this.ShowInputStringDialog(ref value, true, CodeTranslator.Current.InputString, true))
            //{
            //    this.ShowInfoDialog(value);
            //}
        }
    }
}
