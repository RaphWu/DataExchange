﻿/*
 * 編輯後ListBox不會更新的問題
 * 
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Models : UserControl
    {
        #region fields

        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly CoreData _coreData;
        private readonly FieldTitle _fieldTitle;
        private readonly CRUD _crud;

        private List<ListViewModel> _vmModels = null;
        private ListViewModel _vmModel = null;
        private List<ListViewModel> _vmWss = null;
        private ListViewModel _vmWs = null;
        private List<ListViewModel> _vmModelStatus = null;
        private ListViewModel _vmStatus = null;

        #endregion fields

        public Setup_Models(CoreContext coreContext,
                            ICore core,
                            CoreData coreData,
                            FieldTitle fieldTitle,
                            CRUD crud)
        {
            InitializeComponent();
            _context = coreContext;
            _core = core;
            _coreData = coreData;
            _fieldTitle = fieldTitle;
            _crud = crud;

            //Button_Refresh.FillColor = CommonStyles.BackColor;

            string itemName = _fieldTitle.ModelName;
            Label_Model.Text = _fieldTitle.ModelName;
            CommonStyles.SetListBox(List_Models);
            CommonStyles.SetCrudButton(Model_Create, $"C", itemName);
            CommonStyles.SetCrudButton(Model_Edit, $"E", itemName);
            CommonStyles.SetCrudButton(Model_Modify, $"M", _fieldTitle.ModelStatus);

            itemName = _fieldTitle.Workstation;
            Label_Workstation.Text = _fieldTitle.Workstation;
            CommonStyles.SetListBox(List_Workstations);
            CommonStyles.SetCrudButton(Workstation_Create, $"C", itemName);
            CommonStyles.SetCrudButton(Workstation_Edit, $"E", itemName);
            CommonStyles.SetCrudButton(Workstation_Delete, $"D", itemName);
            CommonStyles.SetCrudButton(Workstation_Up, $"UP", itemName);
            CommonStyles.SetCrudButton(Workstation_Down, $"DOWN", itemName);

            itemName = _fieldTitle.ModelStatus;
            Label_ModelStatus.Text = _fieldTitle.ModelStatus;
            CommonStyles.SetListBox(List_Workstations);
            CommonStyles.SetCrudButton(ModelStatus_Create, $"C", itemName);
            CommonStyles.SetCrudButton(ModelStatus_Edit, $"E", itemName);
            CommonStyles.SetCrudButton(ModelStatus_Delete, $"D", itemName);
            CommonStyles.SetCrudButton(ModelStatus_Up, $"UP", itemName);
            CommonStyles.SetCrudButton(ModelStatus_Down, $"DOWN", itemName);
        }

        private void Setup_Models_Load(object sender, EventArgs e)
        {
            UpdateModelsView();
            UpdateWorkstationsView();
            UpdateModelStatusView();
            //Models_SelectionChanged();
            //Workstations_SelectionChanged();
        }

        /********************
         * Common
         ********************/
        //private async void Button_Refresh_Click(object sender, EventArgs e)
        //{
        //    await _core.UpdateCoreDataCache();
        //    UpdateModelsView();
        //    UpdateWorkstationsView();

        //    if (_vmModel != null)
        //        List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Id == _vmModel.Id);

        //    if (_vmWs != null)
        //        List_Workstations.SelectedIndex = _vmWss.FindIndex(w => w.Id == _vmWs.Id);
        //}

        /********************
         * Models
         ********************/
        private void UpdateModelsView()
        {
            _vmModels = _coreData.Models
                .Select(m => new ListViewModel { Id = m.Id, Name = m.NameAndStatus })
                .ToList();
            List_Models.DataSource = null;
            List_Models.ValueMember = nameof(ListViewModel.Id);
            List_Models.DisplayMember = nameof(ListViewModel.Name);
            List_Models.DataSource = _vmModels;
        }

        private void Models_SelectionChanged()
        {
            _vmModel = List_Models.SelectedItem as ListViewModel;
            if (_vmModel != null)
            {
                Model_Edit.Enabled = true;
                Model_Modify.Enabled = true;
                UpdateWorkstationsView();
            }
            else
            {
                Model_Edit.Enabled = false;
                Model_Modify.Enabled = false;
            }
        }

        private void List_Models_SelectedIndexChanged(object sender, EventArgs e)
        {
            Models_SelectionChanged();
        }

        private async void Model_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{_fieldTitle.ModelName}名稱";
            string caption = $"新{_fieldTitle.ModelName}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.ModelName}名稱不可為空白！"),
                input => input.Length <= 10 ? (true, "") : (false, $"{_fieldTitle.ModelName}名稱必須小於等於 10 個字元！"),
                input => _coreData.Models.Any(m => m.ModelName == input) ? (false, $"{_fieldTitle.ModelName}名稱已存在！") : (true, "")
                );

            _crud.New_1TextBox(new TextBoxInfo()
            {
                Value = "",
                Caption = caption,
                WaterMark = caption
            }, title, validator);
            if (FormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
            {
                string newModelName = _crud.Result.StringValue;

                _context.Models.Add(new Model() { ModelName = newModelName });
                await _context.SaveChangesAsync();
                await _core.UpdateModelsCache();
                UpdateModelsView();
                List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Name == newModelName);

                MessageBox.Show($"已增加新{_fieldTitle.ModelName}: {newModelName}",
                                $"新增成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private async void Model_Edit_Click(object sender, EventArgs e)
        {
            if (_vmModel != null)
            {
                var thisModel = _vmModel;
                string title = $"請輸入新{_fieldTitle.ModelName}名稱";
                string oldCaption = $"原{_fieldTitle.ModelName}名稱";
                string newCaption = $"新{_fieldTitle.ModelName}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{_fieldTitle.ModelName}名稱不可為空白！"),
                    input => input.Length <= 10 ? (true, "") : (false, $"{_fieldTitle.ModelName}名稱必須小於等於 10 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, $"{_fieldTitle.ModelName}名稱已存在！") : (true, "")
                    );

                _crud.Edit_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = oldCaption,
                    WaterMark = oldCaption,
                }, new TextBoxInfo()
                {
                    Value = thisModel.Name,
                    Caption = newCaption,
                    WaterMark = newCaption,
                }, title, validor);
                if (FormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
                {
                    string newModelName = _crud.Result.StringValue;

                    var newModel = _context.Models.FirstOrDefault(m => m.Id == thisModel.Id);
                    if (newModel != null)
                    {
                        newModel.ModelName = newModelName;
                        await _context.SaveChangesAsync();
                        await _core.UpdateModelsCache();
                        UpdateModelsView();
                        List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Id == newModel.Id);

                        MessageBox.Show($"{_fieldTitle.ModelName} {thisModel.Name} 名稱已更新為 {newModelName}",
                                        $"更新成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void Model_Delete_Click(object sender, EventArgs e)
        {
            if (_vmModel != null)
            {
                string title = $"請切換 {_vmModel.Name} 狀態";
                string caption = $"{_fieldTitle.ModelName}狀態";
                List<ListViewModel> listSource = await _context.ModelStatuses
                    .Select(s => new ListViewModel()
                    {
                        Id = s.Id,
                        Name = s.Status,
                    })
                    .ToListAsync();

                _crud.Edit_1ComboBox(new ComboBoxInfo()
                {
                    ListSource = listSource,
                    Id = _vmModel.Id,
                    Caption = caption,
                    WaterMark = caption
                }, title);
                if (FormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
                {
                    var model = _context.Models.FirstOrDefault(m => m.ModelStatusId == _vmModel.Id);
                    model.ModelStatusId = listSource[_crud.Result.IntValue].Id;
                    await _context.SaveChangesAsync();
                    await _core.UpdateModelsCache();
                    UpdateModelsView();

                    MessageBox.Show($"已將{_fieldTitle.ModelName}: {model.ModelName} 變更為: {listSource[_crud.Result.IntValue].Name}",
                                    $"變更成功",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
            }

            //if (_vmModel != null)
            //{
            //    var thisModel = _vmModel;
            //    if (UIMessageBox.ShowAsk2($"確定要刪除{_fieldTitle.Model} {thisModel.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
            //    {
            //        var targetModel = _context.Models.FirstOrDefault(m => m.Id == thisModel.Id);
            //        if (targetModel != null)
            //        {
            //            _context.Models.Remove(targetModel);
            //            await _context.SaveChangesAsync();
            //            await _core.UpdateModelsCache();
            //            UpdateModelsView();

            //            MessageBox.Show($"{_fieldTitle.Model} {thisModel.Name} 已刪除",
            //                            $"刪除成功",
            //                            MessageBoxButtons.OK,
            //                            MessageBoxIcon.Information);
            //        }
            //    }
            //}
        }

        /********************
         * Workstations
         ********************/
        private void UpdateWorkstationsView()
        {
            List_Workstations.DataSource = null;
            if (_vmModel != null)
            {
                _vmWss = _coreData.Workstations
                    .Where(w => w.Model.Id == _vmModel.Id)
                    .Select(w => new ListViewModel { Id = w.Id, Name = w.WorkstationName, OrderNo = w.OrderNo })
                    .ToList();
                List_Workstations.ValueMember = nameof(ListViewModel.Id);
                List_Workstations.DisplayMember = nameof(ListViewModel.Name);
                List_Workstations.DataSource = _vmWss;
            }
            else
            {
                _vmWss = null;
            }
        }

        private void Workstations_SelectionChanged()
        {
            _vmWs = List_Workstations.SelectedItem as ListViewModel;
            if (_vmWs != null)
            {
                Workstation_Edit.Enabled = true;
                Workstation_Delete.Enabled = true;

                if (List_Workstations.DataSource is List<ListViewModel> vmWss)
                {
                    var wsOrderNo = vmWss.FirstOrDefault(w => w.Id == _vmWs.Id).OrderNo;
                    Workstation_Up.Enabled = wsOrderNo != vmWss.Min(w => w.OrderNo);
                    Workstation_Down.Enabled = wsOrderNo != vmWss.Max(w => w.OrderNo);
                }
                else
                {
                    Workstation_Up.Enabled = false;
                    Workstation_Down.Enabled = false;
                }
            }
            else
            {
                Workstation_Edit.Enabled = false;
                Workstation_Delete.Enabled = false;
                Workstation_Up.Enabled = false;
                Workstation_Down.Enabled = false;
            }
        }

        private void List_Workstations_SelectedIndexChanged(object sender, EventArgs e)
        {
            Workstations_SelectionChanged();
        }

        private async void WorkStation_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新工站名稱";
            string caption = $"新工站名稱";
            var validor = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"工站名稱不可為空白！"),
                input => input.Length <= 20 ? (true, "") : (false, $"工站名稱必須小於等於 20 個字元！"),
                input => _coreData.Workstations.Any(m => m.WorkstationName == input) ? (false, $"工站名稱已存在！") : (true, "")
                );

            _crud.New_1TextBox(new TextBoxInfo()
            {
                Value = "",
                Caption = caption,
                WaterMark = caption
            }, title, validor);
            if (FormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
            {
                string newWorkstationName = _crud.Result.StringValue;

                var model = _coreData.Models.FirstOrDefault(m => m.Id == _vmModel.Id);
                int maxOrderNo = _coreData.Workstations.Max(w => w.OrderNo);
                var newWs = _context.Workstations.Add(new Workstation()
                {
                    WorkstationName = newWorkstationName,
                    ModelId = model.Id,
                    OrderNo = maxOrderNo + 1,
                });
                await _context.SaveChangesAsync();
                await _core.UpdateWorkstationsCache();
                UpdateWorkstationsView();
                List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Id == newWs.Id);

                MessageBox.Show($"已增加新工站: {newWorkstationName}",
                                $"新增成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
            }
        }

        private async void WorkStation_Edit_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                string title = $"請輸入新工站名稱";
                string oldCaption = $"原工站名稱";
                string newCaption = $"新工站名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"工站名稱不可為空白！"),
                    input => input.Length <= 20 ? (true, "") : (false, $"工站名稱必須小於等於 20 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, $"工站名稱已存在！") : (true, "")
                    );

                _crud.Edit_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = oldCaption,
                    WaterMark = oldCaption
                }, new TextBoxInfo()
                {
                    Value = thisVmWs.Name,
                    Caption = newCaption,
                    WaterMark = newCaption
                }, title, validor);
                if (FormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
                {
                    string newWorkstationName = _crud.Result.StringValue;

                    var ws = _context.Workstations.FirstOrDefault(m => m.Id == thisVmWs.Id);
                    if (ws != null)
                    {
                        ws.WorkstationName = newWorkstationName;
                        await _context.SaveChangesAsync();
                        await _core.UpdateWorkstationsCache();
                        UpdateWorkstationsView();
                        List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Id == ws.Id);

                        MessageBox.Show($"工站 {thisVmWs.Name} 名稱已更新為 {newWorkstationName}",
                                        $"更新成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void WorkStation_Delete_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                if (UIMessageBox.ShowAsk2($"確定要刪除工站 {thisVmWs.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetWs = _context.Workstations.FirstOrDefault(m => m.Id == thisVmWs.Id);
                    if (targetWs != null)
                    {
                        _context.Workstations.Remove(targetWs);
                        await _context.SaveChangesAsync();
                        await _core.UpdateWorkstationsCache();
                        UpdateWorkstationsView();

                        MessageBox.Show($"工站 {thisVmWs.Name} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        /********************
         * WorkstationName.OrderNo
         ********************/
        private async Task SwapOrderNo(int wsKey1, int wsKey2)
        {
            try
            {
                var ws1 = _context.Workstations.FirstOrDefault(w => w.Id == wsKey1);
                var ws2 = _context.Workstations.FirstOrDefault(w => w.Id == wsKey2);

                (ws2.OrderNo, ws1.OrderNo) = (ws1.OrderNo, ws2.OrderNo);
                await _context.SaveChangesAsync();
                await _core.UpdateWorkstationsCache();
                UpdateWorkstationsView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void WorkStation_Up_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                var smallerVmWs = _vmWss.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapOrderNo(thisVmWs.Id, smallerVmWs.Id);
                    List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void WorkStation_Down_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                var biggerVmWs = _vmWss.FirstOrDefault(w => w.OrderNo > thisVmWs.OrderNo);
                if (biggerVmWs != null)
                {
                    await SwapOrderNo(thisVmWs.Id, biggerVmWs.Id);
                    List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        /********************
         * ModelStatus
         ********************/
        private async Task UpdateModelStatusView()
        {
            _vmModelStatus = await _context.ModelStatuses
                .Select(m => new ListViewModel { Id = m.Id, Name = m.Status })
                .ToListAsync();
            ListBox_ModelStatus.DataSource = null;
            ListBox_ModelStatus.ValueMember = nameof(ListViewModel.Id);
            ListBox_ModelStatus.DisplayMember = nameof(ListViewModel.Name);
            ListBox_ModelStatus.DataSource = _vmModelStatus;
        }


    }
}
