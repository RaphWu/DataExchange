﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Models : UIUserControl
    {
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly CoreData _coreData;
        private readonly CRUD _crud;

        private List<ListViewModel> _modelViews;

        public Setup_Models(CoreContext coreContext, ICore core, CoreData coreData, CRUD crud)
        {
            InitializeComponent();
            _context = coreContext;
            _core = core;
            _coreData = coreData;
            _crud = crud;

            // 機種
            dgv_Models.AutoGenerateColumns = false;
            dgv_Models.RowHeadersVisible = false;
            dgv_Models.MultiSelect = false;
            dgv_Models.AllowUserToResizeRows = false;
            dgv_Models.AllowUserToAddRows = false;
            dgv_Models.AllowUserToDeleteRows = false;
            dgv_Models.AllowUserToOrderColumns = false;
            dgv_Models.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            dgv_Models.ScrollBarColor = CommonStyles.BackColor;
            dgv_Models.DefaultCellStyle.SelectionBackColor = CommonStyles.SelectionBar;
            dgv_Models.DefaultCellStyle.Font = CommonStyles.Font;
            dgv_Models.DefaultCellStyle.Padding = new Padding(9, 0, 9, 0);
            dgv_Models.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            Model_Create.FillColor = CommonStyles.BackColor;
            Model_Edit.FillColor = CommonStyles.BackColor;
            Model_Delete.FillColor = CommonStyles.BackColor;

            dgv_Models.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Value",
                HeaderText = "機種",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
            });

            Button_Refresh.FillColor = CommonStyles.BackColor;

            // 工站
            dgv_Workstations.AutoGenerateColumns = false;
            dgv_Workstations.RowHeadersVisible = false;
            dgv_Workstations.MultiSelect = false;
            dgv_Workstations.AllowUserToResizeRows = false;
            dgv_Workstations.AllowUserToAddRows = false;
            dgv_Workstations.AllowUserToDeleteRows = false;
            dgv_Workstations.AllowUserToOrderColumns = false;
            dgv_Workstations.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            dgv_Workstations.GridColor = CommonStyles.BackColor;
            dgv_Workstations.ScrollBarColor = CommonStyles.BackColor;
            dgv_Workstations.DefaultCellStyle.SelectionBackColor = CommonStyles.SelectionBar;
            dgv_Workstations.DefaultCellStyle.Padding = new Padding(9, 0, 9, 0);
            dgv_Workstations.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            WorkStation_Create.FillColor = CommonStyles.BackColor;
            WorkStation_Edit.FillColor = CommonStyles.BackColor;
            WorkStation_Delete.FillColor = CommonStyles.BackColor;
            WorkStation_Up.FillColor = CommonStyles.BackColor;
            WorkStation_Down.FillColor = CommonStyles.BackColor;

            dgv_Workstations.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Value",
                HeaderText = "工站",
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
            });
        }

        private void Setup_Models_Load(object sender, EventArgs e)
        {
            UpdateModelsView();
            Models_SelectionChanged();
            Workstations_SelectionChanged();
        }

        private void dgv_Models_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            e.CellStyle.Font = CommonStyles.Font;
        }

        private void dgv_Workstations_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            e.CellStyle.Font = CommonStyles.Font;
        }

        /********************
         * Models
         ********************/
        private void UpdateModelsView()
        {
            _modelViews = _coreData.Models
                .Select(m => new ListViewModel { Key = m.Id, Value = m.ModelName })
                .ToList();
            dgv_Models.DataSource = null;
            dgv_Models.DataSource = _modelViews;
        }

        private void Models_SelectionChanged()
        {
            if (dgv_Models.SelectedCells.Count > 0 && dgv_Models.SelectedCells[0].Value != null)
            {
                Model_Create.Enabled = true;
                Model_Edit.Enabled = true;
                Model_Delete.Enabled = true;

                var modelName = dgv_Models.SelectedCells[0].Value.ToString();
                var wss = _coreData.Workstations
                    .Where(ws => ws.Model.ModelName == modelName)
                    .Select(ws => new ListViewModel { Key = ws.Id, Value = ws.WorkstationName })
                    .ToList();

                dgv_Workstations.DataSource = null;
                dgv_Workstations.DataSource = wss;
            }
            else
            {
                Model_Create.Enabled = false;
                Model_Edit.Enabled = false;
                Model_Delete.Enabled = false;
            }
        }

        private void dgv_Models_SelectionChanged(object sender, EventArgs e)
        {
            Models_SelectionChanged();
        }

        private async void Model_Create_Click(object sender, EventArgs e)
        {
            string title = "請輸入新機種名稱";
            string caption = "新機種名稱";
            var validor = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "機種名稱不可為空白！"),
                input => input.Length <= 10 ? (true, "") : (false, "機種名稱必須小於等於 10 個字元！"),
                input => _coreData.Models.Any(m => m.ModelName == input) ? (false, "機種名稱已存在！") : (true, "")
                );

            _crud.OneTextBox("", caption, title, caption, validor);
            if (_crud.ShowDialog() == DialogResult.OK)
            {
                string newModelName = _crud.ResultString;

                _context.Models.Add(new Model() { ModelName = newModelName });
                await _context.SaveChangesAsync();
                await _core.UpdateCoreDataFromDb();
                UpdateModelsView();

                var cell = FindCellByValue(dgv_Models, newModelName);
                if (cell != null)
                    dgv_Models.CurrentCell = cell;
            }
        }

        private async void Model_Edit_Click(object sender, EventArgs e)
        {
            if (dgv_Models.SelectedCells.Count > 0 && dgv_Models.SelectedCells[0].Value != null)
            {
                var modelName = dgv_Models.SelectedCells[0].Value.ToString();

                string title = "請輸入新機種名稱";
                string oldCaption = "原機種名稱";
                string newCaption = "新機種名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "機種名稱不可為空白！"),
                    input => input.Length <= 10 ? (true, "") : (false, "機種名稱必須小於等於 10 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, "機種名稱已存在！") : (true, "")
                    );

                _crud.TwoTextBox("", modelName, newCaption, oldCaption, title, newCaption, validor);
                if (_crud.ShowDialog() == DialogResult.OK)
                {
                    string newModelName = _crud.ResultString;

                    var model = _context.Models.FirstOrDefault(m => m.ModelName == modelName);
                    if (model != null)
                    {
                        model.ModelName = newModelName;
                        await _context.SaveChangesAsync();
                        await _core.UpdateCoreDataFromDb();
                        UpdateModelsView();

                        var cell = FindCellByValue(dgv_Models, newModelName);
                        if (cell != null)
                            dgv_Models.CurrentCell = cell;
                    }
                }
            }
        }

        private async void Model_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_Models.SelectedCells.Count > 0 && dgv_Models.SelectedCells[0].Value != null)
            {
                var modelName = dgv_Models.SelectedCells[0].Value.ToString();

                if (UIMessageBox.ShowAsk2($"確定要刪除 {modelName} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var model = _context.Models.FirstOrDefault(m => m.ModelName == modelName);
                    if (model != null)
                    {
                        _context.Models.Remove(model);
                        await _context.SaveChangesAsync();
                        await _core.UpdateCoreDataFromDb();
                        UpdateModelsView();
                    }
                }
            }
        }

        /********************
         * Workstations
         ********************/
        private void Workstations_SelectionChanged()
        {
            if (dgv_Workstations.SelectedCells.Count > 0 && dgv_Workstations.SelectedCells[0].Value != null)
            {
                WorkStation_Create.Enabled = true;
                WorkStation_Edit.Enabled = true;
                WorkStation_Delete.Enabled = true;
                WorkStation_Up.Enabled = true;
                WorkStation_Down.Enabled = true;
            }
            else
            {
                WorkStation_Create.Enabled = false;
                WorkStation_Edit.Enabled = false;
                WorkStation_Delete.Enabled = false;
                WorkStation_Up.Enabled = false;
                WorkStation_Down.Enabled = false;
            }
        }

        private void dgv_Workstations_SelectionChanged(object sender, EventArgs e)
        {
            Workstations_SelectionChanged();
        }

        /// <summary>
        /// 在 DataGridView 中搜尋指定值，找到第一個就回傳該儲存格，並選取及移動游標。
        /// 找不到時回傳 null。
        /// </summary>
        /// <param name="dgv">目標 DataGridView</param>
        /// <param name="searchValue">要搜尋的值</param>
        /// <param name="exactMatch">是否要求完全相符 (true: 完全相符, false: 包含即可)</param>
        /// <returns>找到的 DataGridViewCell 或 null</returns>
        public static DataGridViewCell FindCellByValue(DataGridView dgv, string searchValue, bool exactMatch = true)
        {
            foreach (DataGridViewRow row in dgv.Rows)
            {
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null)
                    {
                        string cellText = cell.Value.ToString();
                        bool isMatch = exactMatch ? (cellText == searchValue) : cellText.Contains(searchValue);
                        if (isMatch)
                        {
                            dgv.CurrentCell = cell;           // 移動游標到該儲存格
                            cell.Selected = true;             // 選取該儲存格
                            dgv.FirstDisplayedScrollingRowIndex = row.Index; // 捲動使其可見
                            return cell;
                        }
                    }
                }
            }

            return null; // 找不到
        }

        private async void Button_Refresh_Click(object sender, EventArgs e)
        {
            //DataGridViewCell cell = dgv_Models.CurrentCell;
            //if (cell != null)
            //    dgv_Models.CurrentCell = cell;
            await _core.UpdateCoreDataFromDb();
            UpdateModelsView();
        }
    }
}
