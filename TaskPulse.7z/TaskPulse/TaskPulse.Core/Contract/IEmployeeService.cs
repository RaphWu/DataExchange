﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contract
{
    /// <summary>
    /// 員工資料庫與權限操作。
    /// </summary>
    public interface IEmployeeService
    {
        /********************
         * database operations
         ********************/
        /// <summary>
        /// 新增員工。
        /// </summary>
        /// <param name="dto">新增員工的資訊。</param>
        /// <param name="performedByUserId">執行者工號。</param>
        Task AddEmployeeAsync(EmployeeDto dto, string performedByUserId);

        /// <summary>
        /// 編輯員工資料。
        /// </summary>
        /// <param name="emp">員工資料。</param>
        /// <param name="performedByUserId">編輯者工號。</param>
        Task EditEmployeeAsync(Employee emp, string performedByUserId);

        /// <summary>
        /// 員工離職。
        /// </summary>
        /// <param name="employeeId">離職員工ID。</param>
        /// <param name="performedByUserId">更新者工號。</param>
        Task EmployeeResignationAsync(int employeeId, string performedByUserId);

        /// <summary>
        /// 員工復職。
        /// </summary>
        /// <param name="employeeId">復職員工ID。</param>
        /// <param name="performedByUserId">更新者工號。</param>
        /// <param name="newEmployeeId">新的員工工號（若有更動）。</param>
        Task EmployeeRehireAsync(int employeeId, string performedByUserId, string newEmployeeId = "");

        /// <summary>
        /// 更新員工資料。
        /// </summary>
        /// <param name="emp">員工資料。</param>
        /// <param name="performedByUserId">更新者工號。</param>
        Task UpdateEmployeeAsync(Employee emp, string performedByUserId);

        /// <summary>
        /// 更新部門權限。
        /// </summary>
        /// <param name="departmentId">部門ID。</param>
        /// <param name="permissionIds">部門權限ID清單。</param>
        /// <param name="performedByUserId">更新者工號。</param>
        Task UpdateDepartmentPermissionsAsync(int departmentId, List<int> permissionIds, string performedByUserId);

        /// <summary>
        /// 更新使用者群組權限。
        /// </summary>
        /// <param name="groupId">群組ID。</param>
        /// <param name="permissionIds">群組權限ID清單。</param>
        /// <param name="performedByUserId">更新者工號。</param>
        Task UpdateUserGroupPermissionsAsync(int groupId, List<int> permissionIds, string performedByUserId);
    }
}
