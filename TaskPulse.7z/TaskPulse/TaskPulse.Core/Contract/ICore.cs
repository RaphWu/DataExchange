﻿namespace Calin.TaskPulse.Core.Contract
{
    public interface ICore
    {
        /// <summary>
        /// 更新員工名冊。
        /// </summary>
        void UpdateCoreDataFromDb();

        /// <summary>
        /// CoreService 初始化。
        /// </summary>
        void Initialize();
    }
}
