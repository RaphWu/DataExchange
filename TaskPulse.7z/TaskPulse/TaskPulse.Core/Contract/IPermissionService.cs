﻿using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Contract
{
    /// <summary>
    /// 使用者權限服務介面。
    /// </summary>
    /// <remarks>管理員 ID 使用 int.MaxValue。<br/>訪客 ID 為 0。</remarks>
    public interface IPermissionService
    {
        /********************
         * Permission
         ********************/
        /// <summary>
        /// 取得使用者所有權限清單。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <returns>傳回使用者的權限清單。</returns>
        HashSet<string> GetUserPermissions(string employeeId);

        /// <summary>
        /// 檢查使用者是否具有指定權限。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <param name="permission">要檢查的權限字串。</param>
        /// <returns>傳回是否具有該權限。</returns>
        bool HasPermission(string employeeId, string permission);

        /********************
         *  Control Access
         ********************/
        /// <summary>
        /// 檢查使用者對控制項是否有權限
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <param name="prefix">快取前綴字串。</param>
        /// <param name="controlName"></param>
        /// <returns>是否有權限。</returns>
        bool HasControlAccess(string employeeId, string controlName);

        /// <summary>
        /// 取得使用者所有權限來源（部門、群組、個人）。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <returns>使用者所有權限來源。</returns>
        Dictionary<string, PermissionSource> GetUserPermissionSources(string employeeId);

        /// <summary>
        /// 取得指定控制項的權限來源。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        /// <returns>指定控制項的權限來源。</returns>
        PermissionSource GetPermissionSource(string employeeId, string module, string page, string control, string action);

        /// <summary>
        /// 清除指定控制項權限來源的快取。
        /// </summary>
        void ClearUserPermissionSourceCache(string employeeId);

        /********************
         * Refresh
         ********************/
        /// <summary>
        /// 當員工權限變動時呼叫。
        /// </summary>
        /// <param name="employeeId">員工工號。</param>
        void RefreshUserPermissions(string employeeId);

        /// <summary>
        /// 當 Permission 本身被修改，清除一批或全部的使用者。
        /// </summary>
        void RefreshAllUserCaches();

        /// <summary>
        /// 當部門權限變動時呼叫，刷新該部門所有員工。
        /// </summary>
        /// <param name="departmentId">部門 Id。</param>
        void RefreshDepartmentPermissions(int departmentId);

        /// <summary>
        /// 當群組權限變動時呼叫，刷新所有屬於該群組的員工。
        /// </summary>
        /// <param name="userGroupId">群組 Id。</param>
        void RefreshUserGroupPermissions(int userGroupId);
    }
}
