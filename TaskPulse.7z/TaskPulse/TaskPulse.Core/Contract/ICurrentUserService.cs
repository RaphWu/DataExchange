﻿using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contract
{
    /// <summary>
    /// 目前使用者資訊。
    /// </summary>
    public interface ICurrentUserService
    {
        /********************
         * User
         ********************/
        /// <summary>
        /// 取得目前登入使用者的Id。
        /// </summary>
        int UserId { get; }

        /// <summary>
        /// 取得目前員工工號。
        /// </summary>
        string EmployeeId { get; }

        /// <summary>
        /// 取得目前員工姓名。
        /// </summary>
        string UserName { get; }

        /// <summary>
        /// 取得目前登入的員工資料。
        /// </summary>
        Employee User { get; }

        /********************
         * Permission
         ********************/
        /// <summary>
        /// 目前登入者是管理員。
        /// </summary>
        bool IsAdmin { get; }

        /// <summary>
        /// 沒有登入者，為訪客狀態。
        /// </summary>
        bool IsGuest { get; }

        /********************
         * Switch User
         ********************/
        /// <summary>
        /// 將目前使用者切換為指定使用者。
        /// </summary>
        /// <param name="user">要切換的使用者。</param>
        void SwitchCurrentUser(Employee user);

        /// <summary>
        /// 將目前使用者切換為指定使用者 Id。
        /// </summary>
        void SwitchCurrentUser(int userId);

        /// <summary>
        /// 將目前使用者切換為指定員工工號。
        /// </summary>
        void SwitchCurrentUser(string employeeId);

        /// <summary>
        /// 將目前使用者切換為訪客。
        /// </summary>
        void SwitchCurrentUserToGuest();

        /// <summary>
        /// 管理員登入。
        /// </summary>
        void AdminLogin();

        ///********************
        // * Utility
        // ********************/
        ///// <summary>
        ///// 取得目前使用者的權限清單。
        ///// </summary>
        ///// <param name="prefix">快取前綴字串。</param>
        ///// <returns>傳回目前使用者的權限清單。</returns>
        //HashSet<string> GetPermissionsAsync(string prefix);
    }
}
