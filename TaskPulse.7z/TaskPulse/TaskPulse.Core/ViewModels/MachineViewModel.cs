﻿using System.Collections.Generic;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.ViewModels
{
    public class MachineViewModel
    {
        public string MachineId { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public int TypeId { get; set; }
        public string TypeName { get; set; }
        public int MachineNameId { get; set; }
        public string ModelName { get; set; }
        public int ConditionId { get; set; }
        public string ConditionName { get; set; }
        public int BrandId { get; set; }
        public string BrandName { get; set; }
        public int LocationId { get; set; }
        public string LocationName { get; set; }
        public string AssetString { get; set; }
        public string AssetList { get; set; }
        public string SerialNumber { get; set; }
        public string Barcode { get; set; }
        public bool Connected { get; set; }
        public string ConnectedString { get; set; }
        public bool Disposal { get; set; }
        public string DisposalString { get; set; }
        public string Remark { get; set; }
        public string Workstations { get; set; }
    }
}
