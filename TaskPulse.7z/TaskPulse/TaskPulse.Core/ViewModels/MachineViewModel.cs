﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public class MachineViewModel
    {
        public string MachineId { get; set; }
        public string MachineName { get; set; }
        public string Status { get; set; }
        public string Brand { get; set; }
        public string Location { get; set; }
        public string Assets { get; set; }
        public string SerialNumber { get; set; }
        public string Barcode { get; set; }
        public string Connected { get; set; }
        public string Disposal { get; set; }
        public string Remark { get; set; }
        public string Worktations { get; set; }
    }
}
