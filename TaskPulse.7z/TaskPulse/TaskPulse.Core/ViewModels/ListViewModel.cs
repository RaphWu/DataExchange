﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public class ListViewModel
    {
        public int Id { get; set; }
        public int OrderNo { get; set; }
        public int? NullableId { get; set; }
        public string IdString { get; set; }
        public bool BooleanId { get; set; }
        public string Name { get; set; }
    }
}
