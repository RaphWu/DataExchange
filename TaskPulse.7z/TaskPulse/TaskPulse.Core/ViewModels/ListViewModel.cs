﻿namespace Calin.TaskPulse.Core.ViewModels
{
    public class ListViewModel
    {
        public int Key { get; set; }
        public string Value { get; set; }
        public int OrderNo { get; set; }
    }
}
