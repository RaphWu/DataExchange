﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavContracts
{
    public interface IRegionManager
    {
        void RegisterRegion(string name, Control control);
        IRegion GetRegion(string name);
    }
}
