﻿namespace Calin.TaskPulse.Core.Models.Import
{
    public class ExcelMachine
    {
        public string Id { get; set; }
        public string MachineCode { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
        public string Brand { get; set; }
        public string SerialNumber { get; set; }
        public string Assets { get; set; }
        public string Location { get; set; }
        public string Position { get; set; }
        public string Condition { get; set; }
        public string Barcode { get; set; }
        public string Connected { get; set; }
        public string Remark { get; set; }
    }
}
