﻿namespace Calin.TaskPulse.Core.Models.Import
{
    public class ExcelEmployee
    {
        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public string Title { get; set; }
        public string OnStaff { get; set; }
        public string IsEngineer { get; set; }
        public string EMail { get; set; }
    }
}
