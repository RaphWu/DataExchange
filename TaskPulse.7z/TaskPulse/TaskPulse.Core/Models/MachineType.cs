﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 機台型式清單。
    /// </summary>
    public class MachineType
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台型式名稱。
        /// </summary>
        [Description("機台型式")]
        [Required]
        [MaxLength(30)]
        public string TypeName { get; set; }

        /// <summary>
        /// 機台類別。
        /// </summary>
        [Description("類別")]
        public MachineCategory Category { get; set; }
        public int CategoryId { get; set; } // FK

        /// <summary>
        /// 排序用。
        /// </summary>
        public int OrderNo { get; set; }

        public virtual ICollection<MachineName> MachineNames { get; set; } // 機台類別
    }
}
