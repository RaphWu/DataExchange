﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.Core.Models
{
    /********************
     * SqliteDropCreateDatabaseAlways // 每次執行都刪除並重建資料庫
     * SqliteCreateDatabaseIfNotExists // 如果資料庫不存在，則建立資料庫並初始化預設資料。
     * SqliteDropCreateDatabaseWhenModelChanges // 如果模型有變更，則刪除並重建資料庫。
     ********************/
    /// <summary>
    /// Code First 初始化類別。
    /// </summary>
    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
    public class CoreInitializer : SqliteCreateDatabaseIfNotExists<CoreContext>
    {
        public CoreInitializer(DbModelBuilder modelBuilder) : base(modelBuilder)
        {
        }

        protected override void Seed(CoreContext context)
        {
            var emp = context.Set<Employee>();
            emp.Add(new Employee() { EmployeeId = "08001", Department = "工具&設計課", Name = "蔡孟堅", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08002", Department = "工具&設計課", Name = "鄭大德", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08003", Department = "工具&設計課", Name = "李起修", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08004", Department = "工具&設計課", Name = "葉柏均", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08005", Department = "工具&設計課", Name = "曾惠鈴", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08006", Department = "第一製造部", Name = "蔡素貞" });
            emp.Add(new Employee() { EmployeeId = "08007", Department = "第一製造部", Name = "張志榮" });
            emp.Add(new Employee() { EmployeeId = "08008", Department = "第一製造部", Name = "賴惠珠" });
            emp.Add(new Employee() { EmployeeId = "08009", Department = "第一製造部", Name = "侯倩玉" });
            emp.Add(new Employee() { EmployeeId = "08010", Department = "第一製造部", Name = "李雅婷" });
            emp.Add(new Employee() { EmployeeId = "08011", Department = "第一製造部", Name = "彭紹軒" });
            emp.Add(new Employee() { EmployeeId = "08012", Department = "第一製造部", Name = "黎氏鳳" });
            emp.Add(new Employee() { EmployeeId = "08013", Department = "第一製造部", Name = "阮碧幸" });
            emp.Add(new Employee() { EmployeeId = "08014", Department = "第一製造部", Name = "盧海燕" });
            emp.Add(new Employee() { EmployeeId = "08015", Department = "第一製造部", Name = "余沂霈" });
            emp.Add(new Employee() { EmployeeId = "08016", Department = "第一製造部", Name = "楊瓊瑛" });
            emp.Add(new Employee() { EmployeeId = "08017", Department = "組裝製造部", Name = "陳寶琴" });
            emp.Add(new Employee() { EmployeeId = "08018", Department = "組裝製造部", Name = "劉名峻" });
            emp.Add(new Employee() { EmployeeId = "08019", Department = "組裝製造部", Name = "黃琪雯" });
            emp.Add(new Employee() { EmployeeId = "08020", Department = "組裝製造部", Name = "黃姿蓉" });
            emp.Add(new Employee() { EmployeeId = "08021", Department = "組裝製造部", Name = "林承翰" });
            emp.Add(new Employee() { EmployeeId = "08022", Department = "組裝製造部", Name = "雷舒涵" });
            emp.Add(new Employee() { EmployeeId = "08023", Department = "組裝製造部", Name = "黃嘉惠" });
            emp.Add(new Employee() { EmployeeId = "08024", Department = "組裝製造部", Name = "蔡素真" });
            emp.Add(new Employee() { EmployeeId = "08025", Department = "組裝製造部", Name = "黃玉紅" });
            emp.Add(new Employee() { EmployeeId = "08026", Department = "組裝製造部", Name = "許凱婷" });
            emp.Add(new Employee() { EmployeeId = "08027", Department = "組裝製造部", Name = "林昆達" });
            emp.Add(new Employee() { EmployeeId = "08028", Department = "組裝製造部", Name = "晉玉樹" });
            emp.Add(new Employee() { EmployeeId = "08029", Department = "工具&設計課", Name = "謝定傑", IsEngineer = true });

            var fLoc = context.Set<Factory>();
            fLoc.Add(new Factory() { FactoryName = "本廠" });
            fLoc.Add(new Factory() { FactoryName = "區北廠" });
            fLoc.Add(new Factory() { FactoryName = "嘉義廠" });

            var dCategory = context.Set<MachineCategory>();
            dCategory.Add(new MachineCategory() { CategoryName = "分類" });

            var dType = context.Set<MachineType>();
            dType.Add(new MachineType() { TypeName = "打壓機" });
            dType.Add(new MachineType() { TypeName = "插入機" });
            dType.Add(new MachineType() { TypeName = "斜點膠機" });
            dType.Add(new MachineType() { TypeName = "桌上型點膠機" });
            dType.Add(new MachineType() { TypeName = "熔著機" });
            dType.Add(new MachineType() { TypeName = "21039自動線" });
            dType.Add(new MachineType() { TypeName = "UV照射機" });
            dType.Add(new MachineType() { TypeName = "氣動式出膠機" });
            dType.Add(new MachineType() { TypeName = "氣密檢漏儀" });
            dType.Add(new MachineType() { TypeName = "氣密自動檢測機台" });
            dType.Add(new MachineType() { TypeName = "半自動鎖附機" });
            dType.Add(new MachineType() { TypeName = "PF機" });
            dType.Add(new MachineType() { TypeName = "儀科MTF機" });
            dType.Add(new MachineType() { TypeName = "鬼影機" });
            dType.Add(new MachineType() { TypeName = "鉚合機" });
            dType.Add(new MachineType() { TypeName = "切割機" });
            dType.Add(new MachineType() { TypeName = "高度量測" });
            dType.Add(new MachineType() { TypeName = "自動組裝機" });
            dType.Add(new MachineType() { TypeName = "自動整列機" });
            dType.Add(new MachineType() { TypeName = "高速點膠機" });
            dType.Add(new MachineType() { TypeName = "自動鎖附機" });
            dType.Add(new MachineType() { TypeName = "三合一點膠機" });
            dType.Add(new MachineType() { TypeName = "貼膜機台" });
            dType.Add(new MachineType() { TypeName = "調芯機" });

            var brand = context.Set<MachineBrand>();
            brand.Add(new MachineBrand() { Name = "自製" });
            brand.Add(new MachineBrand() { Name = "晟普" });
            brand.Add(new MachineBrand() { Name = "點膠科技" });
            brand.Add(new MachineBrand() { Name = "稼動科技" });
            brand.Add(new MachineBrand() { Name = "立璽(LIHSI)" });
            brand.Add(new MachineBrand() { Name = "高興易" });
            brand.Add(new MachineBrand() { Name = "衫綺" });
            brand.Add(new MachineBrand() { Name = "勛凱" });
            brand.Add(new MachineBrand() { Name = "USHIO" });
            brand.Add(new MachineBrand() { Name = "KGN" });
            brand.Add(new MachineBrand() { Name = "MUSASHI" });
            brand.Add(new MachineBrand() { Name = "IEI(iwashitainstrumemt)" });
            brand.Add(new MachineBrand() { Name = "九驊" });
            brand.Add(new MachineBrand() { Name = "儀科" });
            brand.Add(new MachineBrand() { Name = "客戶製" });
            brand.Add(new MachineBrand() { Name = "元利盛(EVEST)" });
            brand.Add(new MachineBrand() { Name = "翔元(SYAUTO)" });
            brand.Add(new MachineBrand() { Name = "瀚升" });
            brand.Add(new MachineBrand() { Name = "儀銳" });

            var cond = context.Set<MachineCondition>();
            cond.Add(new MachineCondition() { Condition = "稼動中" });
            cond.Add(new MachineCondition() { Condition = "停動中" });
            cond.Add(new MachineCondition() { Condition = "檢討室" });
            cond.Add(new MachineCondition() { Condition = "RD檢討室" });
            cond.Add(new MachineCondition() { Condition = "微小倉庫" });
            cond.Add(new MachineCondition() { Condition = "試作線上" });

            var model = context.Set<Model>();
            model.Add(new Model() { ModelName = "其他" });
            model.Add(new Model() { ModelName = "155" });
            model.Add(new Model() { ModelName = "260" });
            model.Add(new Model() { ModelName = "271" });
            model.Add(new Model() { ModelName = "273" });
            model.Add(new Model() { ModelName = "281" });
            model.Add(new Model() { ModelName = "283" });
            model.Add(new Model() { ModelName = "366" });
            model.Add(new Model() { ModelName = "453" });
            model.Add(new Model() { ModelName = "459" });
            model.Add(new Model() { ModelName = "467" });
            model.Add(new Model() { ModelName = "561" });
            model.Add(new Model() { ModelName = "563" });
            model.Add(new Model() { ModelName = "568" });
            model.Add(new Model() { ModelName = "570" });
            model.Add(new Model() { ModelName = "575" });
            model.Add(new Model() { ModelName = "585" });
            model.Add(new Model() { ModelName = "19008" });
            model.Add(new Model() { ModelName = "20006" });
            model.Add(new Model() { ModelName = "20007" });
            model.Add(new Model() { ModelName = "20019" });
            model.Add(new Model() { ModelName = "20056" });
            model.Add(new Model() { ModelName = "21018" });
            model.Add(new Model() { ModelName = "21028" });
            model.Add(new Model() { ModelName = "21039" });
            model.Add(new Model() { ModelName = "22001" });
            model.Add(new Model() { ModelName = "23010" });
            model.Add(new Model() { ModelName = "23021" });
            model.Add(new Model() { ModelName = "23069" });
            model.Add(new Model() { ModelName = "23070" });
            model.Add(new Model() { ModelName = "23071" });
            model.Add(new Model() { ModelName = "23073" });
            model.Add(new Model() { ModelName = "24301" });
            model.Add(new Model() { ModelName = "132-07" });
            model.Add(new Model() { ModelName = "19003-04" });
            model.Add(new Model() { ModelName = "19003-06" });
            model.Add(new Model() { ModelName = "20007-AS2" });
            model.Add(new Model() { ModelName = "20007-AS3" });
            model.Add(new Model() { ModelName = "417-01" });
            model.Add(new Model() { ModelName = "417-02" });
            model.Add(new Model() { ModelName = "568-02" });

            context.SaveChanges();

            try
            {
                var devices = context.Set<Machine>();
                //var deviceName = context.Set<MachineNames>();
                var deviceName = new HashSet<(string Model, string TypeName)>(context.MachineNames
                    .Include(d => d.Type)
                    .Select(d => new { d.Model, d.Type.TypeName })
                    .AsEnumerable()
                    .Select(x => (x.Model, x.TypeName))
                    );

                var factory = new HashSet<(string Factory, string Location)>(context.Locations
                    .Include(d => d.Factory)
                    .Select(d => new { d.Factory.FactoryName, d.Location })
                    .AsEnumerable()
                    .Select(x => (x.FactoryName, x.Location))
                    );
                //var factory = context.Set<MachineLocation>();
                var assCode = context.Set<MachineAssetCode>();

                int recCount = 0;
                // 一對多
                using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                {
                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var type = data[1].Trim();
                            var mName = data[3].Trim();
                            var dKey = (mName, type);
                            if (!deviceName.Contains(dKey))
                            {
                                var device = new MachineName
                                {
                                    Type = dType.FirstOrDefault(x => x.TypeName == type),
                                    Model = mName,
                                };

                                context.MachineNames.Add(device);
                                deviceName.Add(dKey);
                            }

                            //if (deviceName.Local.FirstOrDefault(x => x.Model == mName && x.Type.TypeName == type) == null)
                            //{
                            //    deviceName.Add(new MachineNames()
                            //    {
                            //        Type = dType.FirstOrDefault(x => x.TypeName == type),
                            //        Model = mName,
                            //    });
                            //}

                            var fac = data[6].Trim();
                            var loc = data[7].Trim();
                            var fKey = (fac, loc);
                            if (!factory.Contains(fKey))
                            {
                                var newLoc = new MachineLocation
                                {
                                    Factory = fLoc.FirstOrDefault(x => x.FactoryName == fac),
                                    Location = loc,
                                };

                                context.Locations.Add(newLoc);
                                factory.Add(fKey);
                            }

                            //if (factory.FirstOrDefault(x => x.Location == loc && x.Factory.FactoryName == fac) == null)
                            //{
                            //    factory.Add(new MachineLocation()
                            //    {
                            //        Factory = fLoc.FirstOrDefault(x => x.FactoryName == fac),
                            //        Location = loc,
                            //    });
                            //}
                        }
                    }
                    context.SaveChanges();
                }

                // Machine
                using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                {
                    recCount = 0;
                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var device = new Machine();

                            string deviceId = data[0].Trim();
                            device.MachineId = deviceId;

                            var type = data[1].Trim();
                            var mName = data[3].Trim();
                            device.MachineNameId = context.MachineNames
                                .FirstOrDefault(x => x.Model == mName && x.Type.TypeName == type)?.Id ?? 0;

                            var bName = data[2].Trim();
                            device.Brand = brand.FirstOrDefault(x => x.Name == bName);
                            device.SerialNumber = data[4].Trim();

                            if (data[5].StartsWith("\""))
                                data[5] = data[5].Substring(1, data[5].Length - 2);
                            var assets = data[5].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                            .Select(x => x.Trim())
                                            .Where(x => x != "無" && !string.IsNullOrWhiteSpace(x))
                                            .Distinct()
                                            .ToList();
                            device.Assets = new List<MachineAssetCode>();
                            foreach (var a in assets)
                            {
                                if (!string.IsNullOrWhiteSpace(a))
                                    device.Assets.Add(new MachineAssetCode() { Code = a });
                            }

                            var fac = data[6].Trim();
                            var loc = data[7].Trim();
                            device.LocationId = context.Locations
                                .FirstOrDefault(x => x.Location == loc && x.Factory.FactoryName == fac)?.LocationId ?? 0;

                            var cnd = data[8].Trim();
                            device.Condition = cond.FirstOrDefault(x => x.Condition == cnd);
                            device.Barcode = data[9].Trim();
                            device.Connected = !string.IsNullOrWhiteSpace(data[10].Trim());
                            device.Remark = data[11].Trim();

                            devices.Add(device);
                        }
                    }
                    context.SaveChanges();
                }
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    Console.WriteLine($"Entity of dType '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                    }
                }

                throw; // 若你要繼續丟出錯誤
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            base.Seed(context);
        }
    }
}
