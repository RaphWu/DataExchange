﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 機台所在位置。
    /// </summary>
    public class MachineLocation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int LocationId { get; set; }

        /// <summary>
        /// 廠區。
        /// </summary>
        [Description("廠區")]
        public Factory Factory { get; set; }
        public int FactoryId { get; set; } // FK

        /// <summary>
        /// 位置。
        /// </summary>
        [Description("位置")]
        public string Location { get; set; }

        /// <summary>
        /// 廠別 - 位置。
        /// </summary>
        [NotMapped]
        public string LocPos
        {
            get
            {
                string ret = "";
                bool hasLoc = !string.IsNullOrWhiteSpace(Factory.FactoryName);
                bool hasPos = !string.IsNullOrWhiteSpace(Location);

                if (hasLoc)
                {
                    ret = Factory.FactoryName;
                    if (hasPos)
                        ret += " - ";
                }

                if (hasPos)
                    ret += Location;

                return ret;
            }
        }
    }
}
