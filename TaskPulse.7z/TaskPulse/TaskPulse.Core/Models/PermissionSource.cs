﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 權限所屬分類。
    /// </summary>
    public enum PermissionSource
    {
        None,
        Employee,
        Department,
        UserGroup,
    }
}
