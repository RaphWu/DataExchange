﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 機台狀態列表。
    /// </summary>
    public class MachineCondition
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台狀態。
        /// </summary>
        [Description("機台狀態")]
        [Required]
        public string Condition { get; set; }

        public virtual ICollection<Machine> Machines { get; set; } // Condition
    }
}
