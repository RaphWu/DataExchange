﻿namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 屬性名稱 Buffer。
    /// </summary>
    public class FieldTitle
    {
        // Module
        public string Setup { get; set; }
        public string ToolQuest { get; set; }
        public string MechaTrack { get; set; }
        public string MaintiFlow { get; set; }

        // TaskPulse.Core.CoreService.Initialize() 維護

        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; }
        public string Title { get; set; }
        public string IsEngineer { get; set; }
        public string OnStaff { get; set; }
        public string EMail { get; set; }

        public string MachineId { get; set; }
        public string MachineCategory { get; set; }
        public string MachineType { get; set; }
        public string MachineName { get; set; }
        public string MachineModel { get; set; }
        public string Condition { get; set; }
        public string Brand { get; set; }
        public string Location { get; set; }
        public string Assets { get; set; }
        public string SerialNumber { get; set; }
        public string Barcode { get; set; }
        public string Connected { get; set; }
        public string Disposal { get; set; }
        public string Remark { get; set; }
        public string Workstations { get; set; }

        // TaskPulse.MaintiFlowMain.MaintiFlowService.Initialize() 維護

        public string TaskOrderId { get; set; }
        public string WorkOrderNo { get; set; }
        public string Status { get; set; }
        public string Machine { get; set; }
        public string ModelName { get; set; }
        public string ModelStatus { get; set; }
        public string Workstation { get; set; }
        public string ModelWorkstationName { get; set; }
        public string Creator { get; set; }
        public string CreationDate { get; set; }

        public string MaintenanceUnit { get; set; }
        public string Engineer { get; set; }
        public string AcceptedTime { get; set; }
        public string IssueCategory { get; set; }
        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public string RepairStarted { get; set; }
        public string RepairCompleted { get; set; }
        public string RepairDuration { get; set; }
        public string FillingTime { get; set; }

        public string RequestingUnit { get; set; }
        public string FeedbackEmployee { get; set; }
        public string Feedback { get; set; }
        public string OutageStarted { get; set; }
        public string OutageEnded { get; set; }
        public string OutageDuration { get; set; }

        public string Responsible { get; set; }
    }
}
