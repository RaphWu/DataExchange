﻿namespace Calin.TaskPulse.Core.Models
{
    public class FieldName
    {
        // TaskPulse.Core.CoreService.Initialize() 維護

        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; }
        public string Title { get; set; }
        public string IsEngineer { get; set; }
        public string IsEngineerYes { get; set; }
        public string OnStaff { get; set; }
        public string OnStaffString { get; set; }
        public string EMail { get; set; }

        public string MachineId { get; set; }
        public string MachineCategory { get; set; }
        public string MachineType { get; set; }
        public string MachineName { get; set; }
        public string Condition { get; set; }
        public string Brand { get; set; }
        public string Location { get; set; }
        public string Assets { get; set; }
        public string AssetString { get; set; }
        public string AssetList { get; set; }
        public string SerialNumber { get; set; }
        public string Barcode { get; set; }
        public string Connected { get; set; }
        public string ConnectedString { get; set; }
        public string Disposal { get; set; }
        public string DisposalString { get; set; }
        public string Remark { get; set; }
        public string Worktations { get; set; }

        // TaskPulse.MaintiFlowMain.MaintiFlowService.Initialize() 維護

        public string TaskOrderId { get; set; }
        public string WorkOrderNo { get; set; }
        public string Status { get; set; }
        public string StatusString { get; set; }
        public string Machine { get; set; }
        public string MachineCode { get; set; }
        public string FullMachineName { get; set; }
        public string Model { get; set; }
        public string ModelStatus { get; set; }
        public string Workstation { get; set; }
        public string WorkstationName { get; set; }
        public string ModelWorkstationName { get; set; }
        public string Creator { get; set; }
        public string CreatorName { get; set; }
        public string CreatorHalfName { get; set; }
        public string CreatorFullName { get; set; }
        public string CreationDateTime { get; set; }
        public string CreationDateTimeString { get; set; }
        public string CreationDateString { get; set; }

        public string MaintenanceUnit { get; set; }
        public string MaintenanceUnitId { get; set; }
        public string MaintenanceUnitString { get; set; }
        public string UnitString { get; set; }
        public string Engineers { get; set; }
        public string EngineerString { get; set; }
        public string EngineerMultiString { get; set; }
        public string AcceptedTime { get; set; }
        public string AcceptedTimeString { get; set; }
        public string IssueCategory { get; set; }
        public string IssueCategoryId { get; set; }
        public string IssueCategoryString { get; set; }
        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public string RepairStarted { get; set; }
        public string RepairStartedString { get; set; }
        public string RepairCompleted { get; set; }
        public string RepairCompletedString { get; set; }
        public string RepairDurationTick { get; set; }
        public string RepairDuration { get; set; }
        public string RepairDurationString { get; set; }
        public string FillingTime { get; set; }
        public string FillingTimeString { get; set; }

        public string RequestingUnit { get; set; }
        public string RequestingUnitString { get; set; }
        public string FeedbackEmployee { get; set; }
        public string FeedbackEmployeeString { get; set; }
        public string Feedback { get; set; }
        public string OutageStarted { get; set; }
        public string OutageStartedString { get; set; }
        public string OutageEnded { get; set; }
        public string OutageEndedString { get; set; }
        public string OutageDurationTick { get; set; }
        public string OutageDuration { get; set; }
        public string OutageDurationString { get; set; }

        public string Responsible { get; set; }
    }
}
