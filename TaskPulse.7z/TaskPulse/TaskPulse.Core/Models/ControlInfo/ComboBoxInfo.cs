﻿using System.Collections.Generic;
using Calin.TaskPulse.Core.ViewModels;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// ComboBox 資料。
    /// </summary>
    public class ComboBoxInfo
    {
        /// <summary>
        /// 選項列表。
        /// </summary>
        public List<ListViewModel> ListSource { get; set; } = new List<ListViewModel>();

        /// <summary>
        /// ID。
        /// </summary>
        public int Id { get; set; } = 0;

        /// <summary>
        /// 標題。
        /// </summary>
        public string Caption { get; set; } = "";

        /// <summary>
        /// 浮水印文字。
        /// </summary>
        public string WaterMark { get; set; } = "";
    }
}
