﻿namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// TabPage 資料。
    /// </summary>
    public class TabPageInfo
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Name { get; set; }
    }
}
