﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 設備名稱清單。
    /// </summary>
    public class DeviceName
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 設備類別。
        /// </summary>
        [Description("設備別")]
        public DeviceType Type { get; set; }
        public int TypeId { get; set; } // FK

        /// <summary>
        /// 型號。
        /// </summary>
        [Description("型號")]
        public string Model { get; set; }

        /// <summary>
        /// 設備名稱。
        /// </summary>
        [Description("設備名稱")]
        [NotMapped]
        public string FullName
        {
            get
            {
                string ret = Type.Name;
                if (!string.IsNullOrWhiteSpace(Model))
                    ret += string.Concat(" - ", Model);
                return ret;
            }
        }

        public virtual ICollection<Device> Devices { get; set; } // 設備名稱
    }
}
