﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 資產編號。
    /// </summary>
    public class AssetCode
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 資產編號。
        /// </summary>
        [Description("資產編號")]
        [MaxLength(20)]
        public string Code { get; set; }

        public int DeviceId { get; set; } // FK
        public virtual Device Device { get; set; }
    }
}
