﻿using System.Collections.Generic;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 核心共用資料。
    /// </summary>
    public class CoreData : ObservableObject
    {
        /// <summary>
        /// 員工名冊。
        /// </summary>
        public List<Employee> Employees
        {
            get { return _employeeList; }
            set { SetProperty(ref _employeeList, value); }
        }
        private List<Employee> _employeeList = new List<Employee>();

        /// <summary>
        /// 設備列表。
        /// </summary>
        public List<Device> Devices
        {
            get { return _device; }
            set { SetProperty(ref _device, value); }
        }
        private List<Device> _device = new List<Device>();

        /// <summary>
        /// 設備列表。
        /// </summary>
        public List<Model> Models
        {
            get { return _models; }
            set { SetProperty(ref _models, value); }
        }
        private List<Model> _models = new List<Model>();
    }
}
