﻿using System.Collections.Generic;
using System.Windows.Forms;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 核心共用資料。
    /// </summary>
    public class CoreData : ObservableObject
    {
        /// <summary>
        /// 
        /// </summary>
        public System.Drawing.Font DefaultFont
        {
            get { return _defaultFont; }
            set { SetProperty(ref _defaultFont, value); }
        }
        private System.Drawing.Font _defaultFont;

        /// <summary>
        /// 員工名冊。
        /// </summary>
        public List<Employee> Employees
        {
            get { return _employeeList; }
            set { SetProperty(ref _employeeList, value); }
        }
        private List<Employee> _employeeList = new List<Employee>();

        /// <summary>
        /// 機台列表。
        /// </summary>
        public List<Machine> Machines
        {
            get { return _machine; }
            set { SetProperty(ref _machine, value); }
        }
        private List<Machine> _machine = new List<Machine>();

        /// <summary>
        /// 依種類-類型-名稱分類與排序的機台列表。
        /// </summary>
        public Dictionary<string, Dictionary<string, List<string>>> ClassifyMachines
        {
            get { return _classifyMachines; }
            set { SetProperty(ref _classifyMachines, value); }
        }
        private Dictionary<string, Dictionary<string, List<string>>> _classifyMachines;

        /// <summary>
        /// 
        /// </summary>
        public Dictionary<string, List<TabPage>> TabPageSelector
        {
            get { return _tabPageSelector; }
            set { SetProperty(ref _tabPageSelector, value); }
        }
        private Dictionary<string, List<TabPage>> _tabPageSelector;

        /// <summary>
        /// 機台列表。
        /// </summary>
        public List<Model> Models
        {
            get { return _models; }
            set { SetProperty(ref _models, value); }
        }
        private List<Model> _models = new List<Model>();
    }
}
