﻿using System.Configuration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 目前的登入者。
    /// </summary>
    public class CurrentUserContext
    {
        /// <summary>
        /// 目前登入者的資料。
        /// </summary>
        public Employee CurrentUser
        {
            get => _currentUser;
            set
            {
                _currentUser = value;
                _userId = value?.Id ?? 0;
                _employeeId = value?.EmployeeId ?? "";
                _userName = value?.EmployeeName ?? "";
                _isAdmin = _userId == int.MaxValue;
                _isGuest = value == null;
            }
        }
        private Employee _currentUser;

        /// <summary>
        /// 設定為訪客。
        /// </summary>
        public void SetGuest()
        {
            _currentUser = null;
            _userId = 0;
            _employeeId = "Guest";
            _userName = "訪客";
            _isAdmin = false;
            _isGuest = true;
        }

        /// <summary>
        /// 設定為管理員狀態。
        /// </summary>
        public void SetAdmin()
        {
            _currentUser = null;
            _userId = int.MaxValue;
            _employeeId = ConfigurationManager.AppSettings["AdminUser"];
            _userName = "管理員";
            _isAdmin = true;
            _isGuest = false;
        }

        /********************
         * Property
         ********************/
        /// <summary>
        /// 目前登入者的Id。
        /// </summary>
        public int UserId
        {
            get { return _userId; }
            set { _userId = value; }
        }
        private int _userId;

        /// <summary>
        /// 目前登入者的員工工號。
        /// </summary>
        public string EmployeeId
        {
            get { return _employeeId; }
            set { _employeeId = value; }
        }
        private string _employeeId;

        /// <summary>
        /// 目前登入者的姓名。
        /// </summary>
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }
        private string _userName;

        /// <summary>
        /// 登入者是否為管理員。
        /// </summary>
        public bool IsAdmin
        {
            get => _isAdmin;
            set => _isAdmin = value;
        }
        private bool _isAdmin;

        /// <summary>
        /// 沒有登入者，為訪客狀態。
        /// </summary>
        public bool IsGuest
        {
            get => _isGuest;
            set => _isGuest = value;
        }
        private bool _isGuest;
    }
}
