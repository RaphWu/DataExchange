﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 廠區。
    /// </summary>
    public class Factory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int FactoryId { get; set; }

        /// <summary>
        /// 廠別。
        /// </summary>
        [Description("廠別")]
        [Required]
        public string FactoryName { get; set; }

        public virtual ICollection<DeviceLocation> Factorys { get; set; } // Factory
    }
}
