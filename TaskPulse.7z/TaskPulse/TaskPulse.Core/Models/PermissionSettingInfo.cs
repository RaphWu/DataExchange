﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 權限設定介面互相傳遞訊息用。
    /// </summary>
    public class PermissionSettingInfo
    {
        /// <summary>
        /// 權限來源。
        /// </summary>
        public PermissionSource PermissionSource { get; set; }

        /// <summary>
        /// 員工工號。
        /// </summary>
        public string EmployeeId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ModuleName { get; set; }
    }
}
