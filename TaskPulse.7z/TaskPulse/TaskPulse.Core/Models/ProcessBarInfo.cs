﻿namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 狀態列進度條顯示資訊。
    /// </summary>
    public class ProcessBarInfo
    {
        /// <summary>
        /// 百分比。<br/>當傳送數字範圍為 0 ~ 100 時正常顯示進度條。<br/>傳送其它數字時關閉顯示。
        /// </summary>
        public int Percent = 0;

        /// <summary>
        /// 附加訊息，顯示在 Message 區。<br/>若為空字串，則不變更 Message 區的內容。
        /// </summary>
        public string Message = "";
    }
}
