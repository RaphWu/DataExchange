﻿using System;

namespace Calin.TaskPulse.Core.DataVerification
{
    /// <summary>
    /// 各式驗證器。
    /// </summary>
    public static class Validators
    {
        /// <summary>
        /// 鏈式多組驗證器支援。
        /// </summary>
        /// <param name="validators">驗證器組。</param>
        /// <returns>(true/false, 訊息)</returns>
        /// <remarks>用法示範:
        /// <code><![CDATA[
        /// var allowedList = new List<string> { "TP1001", "TP1002", "TP2001" };
        /// 
        /// var validator = CombineValidators(
        ///     input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, "輸入不可為空白！"),
        ///     input => input.Length <= 10 ? (true, "") : (false, "輸入必須小於等於 10 個字元！"),
        ///     input => allowedList.Contains(input)
        ///         ? (true, "") : (false, $"輸入值『{input}』不在允許清單中。")
        /// );
        /// var dialog = new InputDialog(validator);
        /// ]]></code></remarks>
        public static Func<string, (bool, string)> CombineValidators(params Func<string, (bool, string)>[] validators)
        {
            return input =>
            {
                foreach (var validator in validators)
                {
                    var (isValid, error) = validator(input);
                    if (!isValid)
                        return (false, error);
                }
                return (true, "");
            };
        }

    }
}
