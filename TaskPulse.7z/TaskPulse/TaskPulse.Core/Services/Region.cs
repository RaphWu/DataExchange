﻿using System;
using System.Windows.Forms;
using Calin.TaskPulse.Contracts;

namespace Calin.TaskPulse.Services
{
    public class Region : IRegion
    {
        public string Name { get; }
        public Control HostControl { get; }

        public Region(string name, Control host)
        {
            Name = name;
            HostControl = host;
        }

        public void ShowView(object view)
        {
            if (view is Control ctrl)
            {
                HostControl.Controls.Clear();
                ctrl.Dock = DockStyle.Fill;
                HostControl.Controls.Add(ctrl);
            }
            else
            {
                throw new ArgumentException("View must be a Control");
            }
        }

        public void Clear()
        {
            HostControl.Controls.Clear();
        }
    }
}
