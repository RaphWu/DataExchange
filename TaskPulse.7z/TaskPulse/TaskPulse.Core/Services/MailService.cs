﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using MailKit.Net.Smtp;
using MimeKit;
using Newtonsoft.Json;

namespace Calin.TaskPulse.Core.Services
{
    public class MailService : IMail
    {
        private Dictionary<string, List<Mail>> _mailList;

        public void Initialize()
        {
            try
            {
                string json = File.ReadAllText("郵件列表.json");
                if (string.IsNullOrWhiteSpace(json))
                    throw new FileNotFoundException("郵件列表.json 找不到或異常！");

                _mailList = JsonConvert.DeserializeObject<Dictionary<string, List<Mail>>>(json);
                if (_mailList == null)
                    throw new InvalidDataException("郵件列表.json 內容解析錯誤！");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <inheritdoc/>
        public async Task SendMail(string workName, string subject, string contents)
        {
            if (_mailList == null)
                return;

            if (_mailList.ContainsKey(workName))
            {
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress("維護工單系統", "sys.automate@calin.com.tw"));

                foreach (var emp in _mailList[workName])
                    message.To.Add(new MailboxAddress(emp.Name, emp.Email));

                message.Subject = subject;
                var builder = new BodyBuilder();

                contents = Regex.Replace(contents,
                    @"<table[^>]*>",
                    "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse:collapse; border:1px solid #8c8c8c;'>",
                    RegexOptions.IgnoreCase);
                contents = Regex.Replace(contents,
                    @"<caption[^>]*>",
                    "<caption style='font-weight:bold;margin-bottom:10px;'>",
                    RegexOptions.IgnoreCase);
                contents = Regex.Replace(contents,
                    @"<td[^>]*>",
                    "<td style='border:1px solid #8c8c8c;'>",
                    RegexOptions.IgnoreCase);

                builder.HtmlBody = string.Format($@"<p>維護工單系統訊息：</p><p>{contents}</p><p><span style='color:#ba372a;'><em><strong>此信件由維護工單系統自動發送，請勿回覆此信件！</strong></em></span></p>");
                message.Body = builder.ToMessageBody();

                using (var client = new SmtpClient())
                {
                    await client.ConnectAsync("calin-mails0.calin.com.tw", 25, false);
                    //await client.AuthenticateAsync("sys.automate@calin.com.tw", "#Calin@70848492");
                    await client.SendAsync(message);
                    await client.DisconnectAsync(true);
                }


                //try
                //{
                //    //tsslMsg.Text = "";
                //    System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
                //    message.From = new System.Net.Mail.MailAddress("sys.automate@calin.com.tw");

                //    //讀取收件者
                //    foreach (var emp in _mailList[workName])
                //        message.To.Add(new System.Net.Mail.MailAddress(emp.Email, emp.Name));

                //    message.Subject = subject;
                //    message.IsBodyHtml = true;
                //    contents = Regex.Replace(contents,
                //        @"<table[^>]*>",
                //        "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse:collapse; border:1px solid #8c8c8c;'>",
                //        RegexOptions.IgnoreCase);
                //    contents = Regex.Replace(contents,
                //        @"<caption[^>]*>",
                //        "<caption style='font-weight:bold;margin-bottom:10px;'>",
                //        RegexOptions.IgnoreCase);
                //    contents = Regex.Replace(contents,
                //        @"<td[^>]*>",
                //        "<td style='border:1px solid #8c8c8c;'>",
                //        RegexOptions.IgnoreCase);

                //    message.Body = contents;

                //    //////////////設定郵箱smtp伺服器 埠//////////////
                //    System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
                //    smtp.Port = 25;
                //    smtp.Host = "calin-mails0.calin.com.tw";
                //    //   smtp.EnableSsl = true; //SSL安全連線
                //    smtp.UseDefaultCredentials = false;
                //    smtp.Credentials = new System.Net.NetworkCredential("sys.automate@calin.com.tw", "#Calin@70848492"); //自動寄信公用帳號

                //    //設定郵件傳送格式
                //    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                //    smtp.Send(message);
                //    smtp.Dispose();
                //    message.Dispose();
                //}
                //catch
                //{
                //    //tsslMsg.Text = "EMAIL位址錯誤: " + ex.Message;
                //}
                //finally
                //{

                //}

            }
        }
    }
}
