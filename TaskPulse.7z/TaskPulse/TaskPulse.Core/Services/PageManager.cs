﻿//using System;
//using System.Collections.Generic;
//using Autofac;
//using Autofac.Features.OwnedInstances;
//using Sunny.UI;

//namespace Calin.TaskPulse
//{
//    public class PageManager
//    {
//        private readonly ILifetimeScope _rootScope;
//        private readonly UIForm _form;

//        // private readonly Dictionary<int, UIPage> _pages = new Dictionary<int, UIPage>();
//        private readonly Dictionary<int, IDisposable> _pageOwners = new Dictionary<int, IDisposable>(); // 追蹤 Owner
//        private readonly Dictionary<int, UIPage> _pages = new Dictionary<int, UIPage>(); // 追蹤 Page 實例

//        public PageManager(ILifetimeScope rootScope, UIForm form)
//        {
//            _rootScope = rootScope;
//            _form = form;
//        }

//        public void AddOrReplacePage<TPage>(int pageIndex) where TPage : UserControl
//        {
//            // 移除舊頁面 UI 和 Owner (如果採用 Owned<T>)
//            if (_pages.TryGetValue(pageIndex, out var oldPage))
//            {
//                // 1. 先將舊頁面從 UI 容器中移除
//                _form.RemovePage(pageIndex); // 這一行應在處置之前
//                _pages.Remove(pageIndex);

//                // 2. ⭐ 檢查並處置 Owner
//                if (_pageOwners.TryGetValue(pageIndex, out var oldOwner))
//                {
//                    // 確保舊頁面在處置前，已經從 UI 樹中完全移除
//                    // 如果 UIPage 繼承自 Control，執行以下操作，確保句柄釋放
//                    if (oldPage.IsHandleCreated)
//                    {
//                        oldPage.Dispose(); // 手動處置 WinForms 部分
//                    }

//                    // 處置 Owner，釋放 Autofac 追蹤的資源
//                    oldOwner.Dispose();
//                    _pageOwners.Remove(pageIndex);
//                }
//            }

//            // ... 解析新的 Page ...
//            var owner = _rootScope.Resolve<Owned<TPage>>();
//            var page = owner.Value;
//            // ... 

//            // 3. 加入新頁面
//            _form.AddPage(page, pageIndex);
//            _pages[pageIndex] = page;
//            _pageOwners[pageIndex] = owner;
//        }

//        public void RemovePage(int pageIndex)
//        {
//            if (_pages.TryGetValue(pageIndex, out var page))
//            {
//                _form.RemovePage(pageIndex);
//                _pages.Remove(pageIndex);

//                // ⭐ 處置 Owner，釋放 Page 實例
//                if (_pageOwners.TryGetValue(pageIndex, out var owner))
//                {
//                    owner.Dispose();
//                    _pageOwners.Remove(pageIndex);
//                }
//            }
//        }

//        public void DisposeAll()
//        {
//            // ⭐ 處置所有 Owner
//            foreach (var owner in _pageOwners.Values)
//            {
//                owner.Dispose();
//            }
//            _pageOwners.Clear();
//            _pages.Clear();
//        }
//    }


//    //public class PageManager
//    //{
//    //    private readonly ILifetimeScope _rootScope;
//    //    private readonly UIForm _form;
//    //    private readonly Dictionary<int, (UIPage Page, ILifetimeScope Scope)> _pages = new Dictionary<int, (UIPage Page, ILifetimeScope Scope)>();

//    //    public PageManager(ILifetimeScope rootScope, UIForm form)
//    //    {
//    //        _rootScope = rootScope;
//    //        _form = form;
//    //    }

//    //    public void AddOrReplacePage<TPage>(int pageIndex) where TPage : UserControl
//    //    {
//    //        // 移除舊頁面（如果有的話）
//    //        if (_pages.TryGetValue(pageIndex, out var existing))
//    //        {
//    //            _form.RemovePage(pageIndex);
//    //            existing.Scope.Dispose();
//    //            _pages.Remove(pageIndex);
//    //        }

//    //        var scope = _rootScope.BeginLifetimeScope();
//    //        var page = scope.Resolve<TPage>();
//    //        page.PageIndex = pageIndex;
//    //        page.Tag = pageIndex;
//    //        _form.AddPage(page, pageIndex);
//    //        _pages[pageIndex] = (page, scope);
//    //    }

//    //    public void RemovePage(int pageIndex)
//    //    {
//    //        if (_pages.TryGetValue(pageIndex, out var entry))
//    //        {
//    //            _form.RemovePage(pageIndex); // 移除 UI
//    //            entry.Scope.Dispose();       // 釋放資源
//    //            _pages.Remove(pageIndex);
//    //        }
//    //    }

//    //    public void DisposeAll()
//    //    {
//    //        foreach (var (page, scope) in _pages.Values)
//    //            scope.Dispose();
//    //        _pages.Clear();
//    //    }
//    //}
//}
