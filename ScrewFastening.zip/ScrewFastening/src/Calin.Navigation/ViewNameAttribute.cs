using System;
namespace Calin.Navigation
{
    /// <summary>
    /// ���w View ���W�١C
    /// </summary>
    /// <remarks>
    /// <para>
    /// �Y�����w�� Attribute�A�h�ϥ� Type.Name �@�� ViewName�C
    /// </para>
    /// <para>
    /// �ϥνd�ҡG
    /// <code>
    /// [ViewName("Dashboard")]
    /// public class DashboardView : UserControl
    /// {
    ///     // ViewName �� "Dashboard"
    /// }
    /// 
    /// public class DetailView : UserControl
    /// {
    ///     // ViewName �� "DetailView" (Type.Name)
    /// }
    /// </code>
    /// </para>
    /// </remarks>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public class ViewNameAttribute : Attribute
    {
        /// <summary>
        /// ���o View ���W�١C
        /// </summary>
        public string Name { get; }

        /// <summary>
        /// ��l�� ViewNameAttribute�C
        /// </summary>
        /// <param name="name">View ���W�١C</param>
        public ViewNameAttribute(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentNullException(nameof(name));

            Name = name;
        }
    }
}
