using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Calin.Logging.Abstractions;
using Microsoft.Extensions.Logging;

namespace Calin.Navigation
{
    /// <summary>
    /// Region �ɯ�A�ȹ�@�A��X Region �޲z�P�ɯ�\��]�L DI �����^�C
    /// </summary>
    /// <remarks>
    /// <para>���������̿���� DI �e���A�A�Ω󤣨ϥΨ̿�`�J�������C</para>
    /// <para>
    /// �ϥνd�ҡG
    /// <code>
    /// // �إ� ViewFactory
    /// Func&lt;Type, object&gt; viewFactory = type => Activator.CreateInstance(type);
    /// 
    /// // �إ� RegionNavigationSimple
    /// var navigation = new RegionNavigationSimple(viewFactory, logger);
    /// 
    /// // ���U Region
    /// navigation.RegisterRegion("MainContent", view => panel.Controls.Add((Control)view));
    /// 
    /// // �ɯ�
    /// navigation.NavigateTo&lt;DashboardView&gt;("MainContent");
    /// </code>
    /// </para>
    /// </remarks>
    public class RegionNavigationSimple : INavigation
    {
        private readonly ConcurrentDictionary<string, IRegion> _regions = new ConcurrentDictionary<string, IRegion>(StringComparer.OrdinalIgnoreCase);
        private readonly ConcurrentDictionary<string, Type> _viewNameToType = new ConcurrentDictionary<string, Type>(StringComparer.OrdinalIgnoreCase);
        private readonly ConcurrentDictionary<Type, object> _aliveViewCache = new ConcurrentDictionary<Type, object>();
        private readonly ConcurrentDictionary<object, bool> _managedViews = new ConcurrentDictionary<object, bool>();

        private readonly Func<Type, object> _viewFactory;
        private readonly ILogger<RegionNavigationSimple> _logger;
        private bool _disposed;

        /// <inheritdoc />
        public event EventHandler<NavigatingEventArgs> Navigating;

        /// <inheritdoc />
        public event EventHandler<NavigatedEventArgs> Navigated;

        /// <summary>
        /// ��l�� RegionNavigationSimple�]�L DI �����^�C
        /// </summary>
        /// <param name="viewFactory">View �u�t��ơA�Ω�Ы� View ��ҡC</param>
        /// <param name="logger">��x�O�����C</param>
        public RegionNavigationSimple(Func<Type, object> viewFactory, ILogger<RegionNavigationSimple> logger)
        {
            _viewFactory = viewFactory ?? throw new ArgumentNullException(nameof(viewFactory));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// �ϥιw�]�� Activator.CreateInstance �@�� ViewFactory ��l�ơA�óz�L Calin.Logging �� LoggingBridge ���o ILogger�C
        /// </summary>
        public RegionNavigationSimple()
            : this(type => Activator.CreateInstance(type), LoggingBridge.CreateLogger<RegionNavigationSimple>())
        {
        }

        #region Region Management

        /// <inheritdoc />
        public IEnumerable<string> RegionNames => _regions.Keys.ToList();

        /// <inheritdoc />
        public IRegion RegisterRegion(string regionName, Action<object> activationHandler, Action<object> deactivationHandler = null)
        {
            if (string.IsNullOrEmpty(regionName))
                throw new ArgumentNullException(nameof(regionName));

            if (activationHandler == null)
                throw new ArgumentNullException(nameof(activationHandler));

            ThrowIfDisposed();

            if (_regions.ContainsKey(regionName))
            {
                throw new InvalidOperationException($"Region '{regionName}' �w�g�Q���U�L�F");
            }

            var region = new Region(regionName)
            {
                ViewActivationHandler = activationHandler,
                ViewDeactivationHandler = deactivationHandler
            };

            if (!_regions.TryAdd(regionName, region))
            {
                throw new InvalidOperationException($"�L�k���U Region '{regionName}'");
            }

            _logger.LogDebug($"�w���U Region: {regionName}");
            return region;
        }

        /// <inheritdoc />
        public void UnregisterRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                throw new ArgumentNullException(nameof(regionName));

            ThrowIfDisposed();

            if (_regions.TryRemove(regionName, out var region))
            {
                region.Dispose();
                _logger.LogDebug($"�w�������U Region: {regionName}");
            }
        }

        /// <inheritdoc />
        public IRegion GetRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                return null;

            _regions.TryGetValue(regionName, out var region);
            return region;
        }

        /// <inheritdoc />
        public bool ContainsRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                return false;

            return _regions.ContainsKey(regionName);
        }

        #endregion

        #region Navigation

        /// <inheritdoc />
        public NavigationResult NavigateTo<TView>(string regionName, INavigationParameters parameters = null) where TView : class
        {
            return NavigateTo(typeof(TView), regionName, parameters);
        }

        /// <inheritdoc />
        public NavigationResult NavigateTo(Type viewType, string regionName, INavigationParameters parameters = null)
        {
            if (viewType == null)
                return NavigationResult.Failed("�����������ର null�C");

            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("�ϰ�W�٤��ର�šC");

            try
            {
                var region = GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"�ϰ� '{regionName}' ���s�b�C");
                }

                parameters = parameters ?? new NavigationParameters();
                var viewName = GetViewName(viewType);

                // Ĳ�o Navigating �ƥ�
                var navigatingArgs = new NavigatingEventArgs(regionName, viewName, viewType, parameters);
                OnNavigating(navigatingArgs);
                if (navigatingArgs.Cancel)
                {
                    _logger.LogDebug($"�ɯ�Q�ƥ����: {regionName} -> {viewName}");
                    return NavigationResult.Failed("�ɯ�Q�����C");
                }

                // �ˬd���e���ϬO�_���\�ɯ�
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    _logger.LogDebug($"�ɯ�Q���e���ϩڵ�: {regionName}");
                    return NavigationResult.Failed("�ɯ�Q���e���ϩڵ��C");
                }

                // �q�����e���ϧY�N���}
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // ����γЫطs������
                var view = ResolveView(viewType);

                // �E���s����
                region.Activate(view, viewName);

                // �O���ɯ��x
                var entry = new NavigationJournalEntry(viewName, viewType, parameters);
                region.NavigationJournal.RecordNavigation(entry);

                // �q���s���Ϥw�ɯ��
                NotifyNavigatedTo(view, parameters);

                // Ĳ�o Navigated �ƥ�
                OnNavigated(new NavigatedEventArgs(regionName, viewName, viewType, view, parameters));

                _logger.LogDebug($"�ɯ覨�\: {regionName} -> {viewName}");
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _logger.LogError($"�ɯ襢��: {regionName} -> {viewType?.Name}", ex);
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public NavigationResult NavigateTo(string regionName, string viewName, INavigationParameters parameters = null)
        {
            if (string.IsNullOrEmpty(viewName))
                return NavigationResult.Failed("View �W�٤��ର�šC");

            if (!_viewNameToType.TryGetValue(viewName, out var viewType))
            {
                return NavigationResult.Failed($"�䤣��W�� '{viewName}' �� View�A�Х��ϥ� RegisterView ���U�C");
            }

            return NavigateTo(viewType, regionName, parameters);
        }

        /// <inheritdoc />
        public NavigationResult GoBack(string regionName, INavigationParameters parameters = null)
        {
            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("�ϰ�W�٤��ର�šC");

            try
            {
                var region = GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"�ϰ� '{regionName}' ���s�b�C");
                }

                if (!region.NavigationJournal.CanGoBack)
                {
                    return NavigationResult.Failed("�L�k��^�A�ɯ��x���S���W�@���O���C");
                }

                parameters = parameters ?? new NavigationParameters();

                // �ˬd���e���ϬO�_���\�ɯ�
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    return NavigationResult.Failed("���e���ϩڵ��ɯ�C");
                }

                // �q�����e���ϧY�N���}
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // ����W�@�Ӿɯ�O��
                var entry = region.NavigationJournal.GoBack();

                // �������������
                var view = ResolveView(entry.ViewType);

                // �E������
                region.Activate(view, entry.ViewName);

                // �X�־ɯ�Ѽ�
                var mergedParameters = MergeParameters(entry.Parameters, parameters);

                // �q���s���Ϥw�ɯ��
                NotifyNavigatedTo(view, mergedParameters);

                // Ĳ�o Navigated �ƥ�
                OnNavigated(new NavigatedEventArgs(regionName, entry.ViewName, entry.ViewType, view, mergedParameters));

                _logger.LogDebug($"��^���\: {regionName} -> {entry.ViewName}");
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _logger.LogError($"��^����: {regionName}", ex);
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public NavigationResult GoForward(string regionName, INavigationParameters parameters = null)
        {
            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("�ϰ�W�٤��ର�šC");

            try
            {
                var region = GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"�ϰ� '{regionName}' ���s�b�C");
                }

                if (!region.NavigationJournal.CanGoForward)
                {
                    return NavigationResult.Failed("�L�k�e�i�A�ɯ��x���S���U�@���O���C");
                }

                parameters = parameters ?? new NavigationParameters();

                // �ˬd���e���ϬO�_���\�ɯ�
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    return NavigationResult.Failed("���e���ϩڵ��ɯ�C");
                }

                // �q�����e���ϧY�N���}
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // ����U�@�Ӿɯ�O��
                var entry = region.NavigationJournal.GoForward();

                // �������������
                var view = ResolveView(entry.ViewType);

                // �E������
                region.Activate(view, entry.ViewName);

                // �X�־ɯ�Ѽ�
                var mergedParameters = MergeParameters(entry.Parameters, parameters);

                // �q���s���Ϥw�ɯ��
                NotifyNavigatedTo(view, mergedParameters);

                // Ĳ�o Navigated �ƥ�
                OnNavigated(new NavigatedEventArgs(regionName, entry.ViewName, entry.ViewType, view, mergedParameters));

                _logger.LogDebug($"�e�i���\: {regionName} -> {entry.ViewName}");
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _logger.LogError($"�e�i����: {regionName}", ex);
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public bool CanGoBack(string regionName)
        {
            var region = GetRegion(regionName);
            return region?.NavigationJournal.CanGoBack ?? false;
        }

        /// <inheritdoc />
        public bool CanGoForward(string regionName)
        {
            var region = GetRegion(regionName);
            return region?.NavigationJournal.CanGoForward ?? false;
        }

        #endregion

        #region View State

        /// <inheritdoc />
        public string GetActiveViewName(string regionName)
        {
            var region = GetRegion(regionName);
            return region?.ActiveViewName;
        }

        /// <inheritdoc />
        public object GetActiveView(string regionName)
        {
            var region = GetRegion(regionName);
            return region?.ActiveView;
        }

        /// <inheritdoc />
        public IReadOnlyDictionary<string, string> GetAllActiveViewNames()
        {
            return _regions.ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value.ActiveViewName,
                StringComparer.OrdinalIgnoreCase);
        }

        #endregion

        #region View Release

        /// <inheritdoc />
        public void ReleaseView(object view)
        {
            if (view == null)
                return;

            var viewType = view.GetType();

            // �q�w�s������
            _aliveViewCache.TryRemove(viewType, out _);
            _managedViews.TryRemove(view, out _);

            // �p�G���Ϲ�{�F IDisposable�A�h����귽
            if (view is IDisposable disposable)
            {
                disposable.Dispose();
            }

            _logger.LogDebug($"�w�������: {viewType.Name}");
        }

        /// <inheritdoc />
        public void ReleaseView(string viewName)
        {
            if (string.IsNullOrEmpty(viewName))
                return;

            // �b�֨����M������� View
            foreach (var kvp in _aliveViewCache)
            {
                if (GetViewName(kvp.Key).Equals(viewName, StringComparison.OrdinalIgnoreCase))
                {
                    ReleaseView(kvp.Value);
                    return;
                }
            }

            // �b managed views ���M��
            foreach (var kvp in _managedViews)
            {
                if (GetViewName(kvp.Key.GetType()).Equals(viewName, StringComparison.OrdinalIgnoreCase))
                {
                    ReleaseView(kvp.Key);
                    return;
                }
            }
        }

        /// <inheritdoc />
        public void ReleaseView<TView>() where TView : class
        {
            var viewType = typeof(TView);

            if (_aliveViewCache.TryRemove(viewType, out var view))
            {
                _managedViews.TryRemove(view, out _);

                if (view is IDisposable disposable)
                {
                    disposable.Dispose();
                }

                _logger.LogDebug($"�w�������: {viewType.Name}");
            }
        }

        /// <inheritdoc />
        public void ReleaseAllViews(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                return;

            var region = GetRegion(regionName);
            if (region == null)
                return;

            // ������e���ʪ� View�]�p�G�O�D�ä[�ͩR�g���^
            var activeView = region.ActiveView;
            if (activeView != null && !GetIsAlive(activeView.GetType()))
            {
                ReleaseView(activeView);
            }

            _logger.LogDebug($"�w���� Region '{regionName}' �����Ҧ��D�ä[����");
        }

        #endregion

        #region View Registration

        /// <inheritdoc />
        public void RegisterView<TView>(string viewName = null) where TView : class
        {
            RegisterView(typeof(TView), viewName);
        }

        /// <inheritdoc />
        public void RegisterView(Type viewType, string viewName = null)
        {
            if (viewType == null)
                throw new ArgumentNullException(nameof(viewType));

            var name = viewName ?? GetViewName(viewType);
            _viewNameToType[name] = viewType;
            _logger.LogDebug($"�w���U View: {name} -> {viewType.Name}");
        }

        #endregion

        #region Dispose

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing)
            {
                // ����Ҧ� Region
                foreach (var region in _regions.Values)
                {
                    region.Dispose();
                }
                _regions.Clear();

                // ����Ҧ� managed views
                foreach (var view in _managedViews.Keys)
                {
                    if (view is IDisposable disposable)
                    {
                        disposable.Dispose();
                    }
                }
                _managedViews.Clear();

                // �M�ŧ֨�
                _aliveViewCache.Clear();
                _viewNameToType.Clear();
            }

            _disposed = true;
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Ĳ�o Navigating �ƥ�C
        /// </summary>
        protected virtual void OnNavigating(NavigatingEventArgs e)
        {
            Navigating?.Invoke(this, e);
        }

        /// <summary>
        /// Ĳ�o Navigated �ƥ�C
        /// </summary>
        protected virtual void OnNavigated(NavigatedEventArgs e)
        {
            Navigated?.Invoke(this, e);
        }

        /// <summary>
        /// �ѪR���Ϲ�ҡ]�i�мg�H�ۭq�ѪR�޿�^�C
        /// </summary>
        protected virtual object ResolveView(Type viewType)
        {
            var isAlive = GetIsAlive(viewType);

            if (isAlive)
            {
                return _aliveViewCache.GetOrAdd(viewType, type =>
                {
                    _logger.LogDebug($"�Ыإä[�ͩR�g������: {type.Name}");
                    var view = _viewFactory(type);
                    _managedViews[view] = true;
                    return view;
                });
            }
            else
            {
                _logger.LogDebug($"�Ыذϰ�ͩR�g������: {viewType.Name}");
                var view = _viewFactory(viewType);
                _managedViews[view] = false;
                return view;
            }
        }

        #endregion

        #region Private Methods

        private void ThrowIfDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(nameof(RegionNavigationSimple));
        }

        private string GetViewName(Type viewType)
        {
            var attribute = viewType.GetCustomAttribute<ViewNameAttribute>();
            return attribute?.Name ?? viewType.Name;
        }

        private bool GetIsAlive(Type viewType)
        {
            var attribute = viewType.GetCustomAttribute<ViewLifetimeAttribute>();
            return attribute?.IsAlive ?? false;
        }

        private bool CanNavigateFrom(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                return aware.OnNavigatingFrom(parameters);
            }
            return true;
        }

        private void NotifyNavigatedFrom(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                aware.OnNavigatedFrom(parameters);
            }
        }

        private void NotifyNavigatedTo(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                aware.OnNavigatedTo(parameters);
            }
        }

        private INavigationParameters MergeParameters(INavigationParameters original, INavigationParameters additional)
        {
            var merged = new NavigationParameters();

            if (original != null)
            {
                foreach (var key in original.Keys)
                {
                    merged.Add(key, original.GetValue<object>(key));
                }
            }

            if (additional != null)
            {
                foreach (var key in additional.Keys)
                {
                    merged.Add(key, additional.GetValue<object>(key));
                }
            }

            return merged;
        }

        #endregion
    }
}
