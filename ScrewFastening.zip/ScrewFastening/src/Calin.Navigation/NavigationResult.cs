using System;

namespace Calin.Navigation
{
    /// <summary>
    /// �ɯ赲�G�C
    /// </summary>
    public class NavigationResult
    {
        /// <summary>
        /// ���o�ɯ�O�_���\�C
        /// </summary>
        public bool Success { get; }

        /// <summary>
        /// ���o���~�T���]�Y�ɯ襢�ѡ^�C
        /// </summary>
        public string ErrorMessage { get; }

        /// <summary>
        /// ���o�ҥ~�]�Y�ɯ�o�ͨҥ~�^�C
        /// </summary>
        public Exception Exception { get; }

        private NavigationResult(bool success, string errorMessage = null, Exception exception = null)
        {
            Success = success;
            ErrorMessage = errorMessage;
            Exception = exception;
        }

        /// <summary>
        /// �إߦ��\���ɯ赲�G�C
        /// </summary>
        public static NavigationResult Succeeded() => new NavigationResult(true);

        /// <summary>
        /// �إߥ��Ѫ��ɯ赲�G�C
        /// </summary>
        /// <param name="errorMessage">���~�T���C</param>
        public static NavigationResult Failed(string errorMessage) => new NavigationResult(false, errorMessage);

        /// <summary>
        /// �إߥ��Ѫ��ɯ赲�G�C
        /// </summary>
        /// <param name="exception">�ҥ~�C</param>
        public static NavigationResult Failed(Exception exception) => new NavigationResult(false, exception?.Message, exception);
    }
}
