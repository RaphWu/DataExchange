//using System;
//using Autofac;

//namespace Calin.SerialPort.Examples
//{
//    /// <summary>
//    /// Autofac �̿�`�J�ϥνd�ҡC
//    /// </summary>
//    public static class AutofacExamples
//    {
//        /// <summary>
//        /// �d�� 1: �򥻪� Autofac �]�w�C
//        /// </summary>
//        public static void Example1_BasicSetup()
//        {
//            var builder = new ContainerBuilder();

//            // ���U SerialPort Module
//            builder.RegisterModule<SerialPortModule>();

//            var container = builder.Build();

//            // �ѪR SerialPortManager
//            using (var scope = container.BeginLifetimeScope())
//            {
//                var manager = scope.Resolve<ISerialPortManager>();

//                // �ϥ� manager...
//                manager.RegisterPort(new SerialPortConfig
//                {
//                    PortName = "COM1",
//                    BaudRate = 9600
//                });

//                Console.WriteLine($"�w���U {manager.PortCount} �ӳ]��");
//            }
//        }

//        /// <summary>
//        /// �d�� 2: �ۭq�]�w�� Autofac ���U�C
//        /// </summary>
//        public static void Example2_CustomConfiguration()
//        {
//            var builder = new ContainerBuilder();

//            // ��ʵ��U SerialPortManager
//            builder.RegisterType<SerialPortManager>()
//                .As<ISerialPortManager>()
//                .SingleInstance();

//            // ���U�h�� SerialPortService (�ϥΤ��P�� key)
//            builder.Register(c => new SerialPortService(new SerialPortConfig
//            {
//                PortName = "COM1",
//                BaudRate = 9600,
//                EnableAutoReconnect = true
//            }))
//            .Keyed<ISerialPortService>("Barcode")
//            .SingleInstance();

//            builder.Register(c => new SerialPortService(new SerialPortConfig
//            {
//                PortName = "COM2",
//                BaudRate = 115200,
//                EnableAutoReconnect = true,
//                EnableHeartbeat = true,
//                HeartbeatInterval = 30000,
//                HeartbeatMessage = "PING\r\n"
//            }))
//            .Keyed<ISerialPortService>("DisplacementSensor")
//            .SingleInstance();

//            var container = builder.Build();

//            using (var scope = container.BeginLifetimeScope())
//            {
//                var barcodeService = scope.ResolveKeyed<ISerialPortService>("Barcode");
//                var sensorService = scope.ResolveKeyed<ISerialPortService>("DisplacementSensor");

//                barcodeService.Open();
//                sensorService.Open();

//                Console.WriteLine("�Ҧ��A�Ȥw�Ұ�");
//            }
//        }

//        /// <summary>
//        /// �d�� 3: �b���ε{�����ϥΡ]�����u�t�۰ʤƳ����^�C
//        /// </summary>
//        public static void Example3_FactoryAutomationApp()
//        {
//            var builder = new ContainerBuilder();

//            // ���U��¦�]�I
//            builder.RegisterModule<SerialPortModule>();

//            // ���U���ΪA��
//            builder.RegisterType<BarcodeService>()
//                .AsSelf()
//                .SingleInstance();

//            builder.RegisterType<DisplacementSensorService>()
//                .AsSelf()
//                .SingleInstance();

//            builder.RegisterType<ProductionLineController>()
//                .AsSelf()
//                .SingleInstance();

//            var container = builder.Build();

//            // �Ұ�����
//            using (var scope = container.BeginLifetimeScope())
//            {
//                var controller = scope.Resolve<ProductionLineController>();
//                controller.Start();

//                Console.WriteLine("�Ͳ��u����w�Ұ�");
//                Console.WriteLine("�����N�䰱��...");
//                Console.ReadKey();

//                controller.Stop();
//            }
//        }
//    }

//    #region ���ΪA�Ƚd��

//    /// <summary>
//    /// ���X�A�ȡ]�����^�C
//    /// </summary>
//    public class BarcodeService
//    {
//        private readonly ISerialPortManager _portManager;
//        private const string BarcodePortName = "COM1";

//        public BarcodeService(ISerialPortManager portManager)
//        {
//            _portManager = portManager;
//        }

//        public void Initialize()
//        {
//            _portManager.RegisterPort(new SerialPortConfig
//            {
//                PortName = BarcodePortName,
//                BaudRate = 9600,
//                EnableAutoReconnect = true,
//                ReconnectInterval = 5000
//            });

//            _portManager.DataReceived += OnDataReceived;

//            Console.WriteLine("���X�A�Ȥw��l��");
//        }

//        private void OnDataReceived(object sender, SerialPortDataReceivedEventArgs e)
//        {
//            if (e.PortName == BarcodePortName)
//            {
//                var barcode = e.Data.Trim();
//                Console.WriteLine($"[���X] ���y��: {barcode}");
//                // �B�z���X�޿�...
//            }
//        }

//        public void Shutdown()
//        {
//            _portManager.DataReceived -= OnDataReceived;
//            _portManager.UnregisterPort(BarcodePortName);

//            Console.WriteLine("���X�A�Ȥw����");
//        }
//    }

//    /// <summary>
//    /// �첾�p�A�ȡ]�����^�C
//    /// </summary>
//    public class DisplacementSensorService
//    {
//        private readonly ISerialPortManager _portManager;
//        private const string SensorPortName = "COM2";

//        public DisplacementSensorService(ISerialPortManager portManager)
//        {
//            _portManager = portManager;
//        }

//        public void Initialize()
//        {
//            _portManager.RegisterPort(new SerialPortConfig
//            {
//                PortName = SensorPortName,
//                BaudRate = 115200,
//                EnableAutoReconnect = true,
//                ReconnectInterval = 3000,
//                EnableHeartbeat = true,
//                HeartbeatInterval = 30000,
//                HeartbeatMessage = "PING\r\n",
//                HeartbeatTimeout = 10000
//            });

//            _portManager.DataReceived += OnDataReceived;
//            _portManager.ErrorOccurred += OnError;

//            Console.WriteLine("�첾�p�A�Ȥw��l��");
//        }

//        private void OnDataReceived(object sender, SerialPortDataReceivedEventArgs e)
//        {
//            if (e.PortName == SensorPortName)
//            {
//                // �ѪR�첾���
//                if (e.Data.StartsWith("D:"))
//                {
//                    var valueStr = e.Data.Substring(2).Trim();
//                    if (double.TryParse(valueStr, out double displacement))
//                    {
//                        Console.WriteLine($"[�첾�p] ���q��: {displacement:F2} mm");
//                        // �B�z�첾���...
//                    }
//                }
//            }
//        }

//        private void OnError(object sender, SerialPortErrorEventArgs e)
//        {
//            if (e.PortName == SensorPortName)
//            {
//                Console.WriteLine($"[�첾�p] ���~: {e.ErrorMessage}");
//            }
//        }

//        public void StartMeasurement()
//        {
//            _portManager.SendData(SensorPortName, "START\r\n");
//            Console.WriteLine("[�첾�p] �}�l���q");
//        }

//        public void StopMeasurement()
//        {
//            _portManager.SendData(SensorPortName, "STOP\r\n");
//            Console.WriteLine("[�첾�p] ������q");
//        }

//        public void Shutdown()
//        {
//            StopMeasurement();
//            _portManager.DataReceived -= OnDataReceived;
//            _portManager.ErrorOccurred -= OnError;
//            _portManager.UnregisterPort(SensorPortName);

//            Console.WriteLine("�첾�p�A�Ȥw����");
//        }
//    }

//    /// <summary>
//    /// �Ͳ��u����]�����^�C
//    /// </summary>
//    public class ProductionLineController
//    {
//        private readonly BarcodeService _barcodeService;
//        private readonly DisplacementSensorService _sensorService;
//        private readonly ISerialPortManager _portManager;

//        public ProductionLineController(
//            BarcodeService barcodeService,
//            DisplacementSensorService sensorService,
//            ISerialPortManager portManager)
//        {
//            _barcodeService = barcodeService;
//            _sensorService = sensorService;
//            _portManager = portManager;
//        }

//        public void Start()
//        {
//            Console.WriteLine("=== �ҰʥͲ��u��� ===");

//            // ��l�ƩҦ��A��
//            _barcodeService.Initialize();
//            _sensorService.Initialize();

//            // �q�\���A�ܧ�
//            _portManager.StateChanged += OnPortStateChanged;

//            // �Ұʴ��q
//            _sensorService.StartMeasurement();

//            Console.WriteLine("=== �Ͳ��u����w�N�� ===");
//        }

//        public void Stop()
//        {
//            Console.WriteLine("=== ����Ͳ��u��� ===");

//            // �����Ҧ��A��
//            _sensorService.Shutdown();
//            _barcodeService.Shutdown();

//            _portManager.StateChanged -= OnPortStateChanged;

//            Console.WriteLine("=== �Ͳ��u����w���� ===");
//        }

//        private void OnPortStateChanged(object sender, SerialPortStateChangedEventArgs e)
//        {
//            Console.WriteLine($"[�t��] {e.PortName} ���A�ܧ�: {e.OldState} -> {e.NewState}");

//            if (e.NewState == SerialPortState.Fault)
//            {
//                Console.WriteLine($"[�t��] ĵ�i: {e.PortName} �o�ͬG�١A�N�۰ʭ��s");
//            }
//            else if (e.NewState == SerialPortState.Ready)
//            {
//                Console.WriteLine($"[�t��] {e.PortName} �w�N��");
//            }
//        }
//    }

//    #endregion
//}
