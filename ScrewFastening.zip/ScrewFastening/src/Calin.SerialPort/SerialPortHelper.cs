using System.Collections.Generic;

namespace Calin.SerialPort
{
    /// <summary>
    /// Helper providing static utilities for serial ports.
    /// </summary>
    public static class SerialPortHelper
    {
        /// <summary>
        /// ���o�t�ΤW�Ҧ��i�Ϊ� SerialPort �W�١C
        /// </summary>
        /// <returns>�i�Ϊ� SerialPort �W�٦C���C</returns>
        public static List<string> GetAvailablePorts()
        {
            var ports = System.IO.Ports.SerialPort.GetPortNames();
            return new List<string>(ports);
        }
    }
}
