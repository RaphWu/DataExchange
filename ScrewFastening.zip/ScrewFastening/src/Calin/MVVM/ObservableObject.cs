﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Calin.MVVM
{
    /// <summary>
    /// 提供實現 <see cref="INotifyPropertyChanged"/> 介面的基底類別，用於通知屬性值的變更。
    /// </summary>
    public abstract class ObservableObject : INotifyPropertyChanged
    {
        /// <summary>
        /// 屬性變更事件，當屬性值變更時觸發。
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// 觸發 <see cref="PropertyChanged"/> 事件以通知屬性值的變更。
        /// </summary>
        /// <param name="propertyName">發生變更的屬性名稱。
        /// 預設為呼叫此方法的屬性名稱。</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// 觸發 <see cref="PropertyChanged"/> 事件以通知多個屬性值的變更。
        /// </summary>
        /// <param name="propertyNames">發生變更的屬性名稱集合。</param>
        protected void OnPropertiesChanged(params string[] propertyNames)
        {
            foreach (var name in propertyNames)
                OnPropertyChanged(name);
        }

        /// <summary>
        /// 設定屬性值並觸發 <see cref="PropertyChanged"/> 事件。
        /// </summary>
        /// <typeparam name="T">屬性值的類型。</typeparam>
        /// <param name="backingField">屬性對應的欄位。</param>
        /// <param name="value">要設定的新值。</param>
        /// <param name="propertyName">發生變更的屬性名稱。
        /// 預設為呼叫此方法的屬性名稱。</param>
        /// <returns>如果屬性值已變更則回傳 <c>true</c>，否則回傳 <c>false</c>。</returns>
        protected bool SetProperty<T>(ref T backingField, T value, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(backingField, value))
                return false;

            backingField = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}
