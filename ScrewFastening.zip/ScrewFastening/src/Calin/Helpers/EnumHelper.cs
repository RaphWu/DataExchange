﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace Calin.Helpers
{
    /// <summary>
    /// Enum 輔助類別。
    /// </summary>
    public static class EnumHelper
    {
        /// <summary>
        /// 取得與列舉值相關聯的描述。
        /// </summary>
        /// <remarks>此方法會檢查指定的列舉值上是否存在 <see cref="DescriptionAttribute"/>。若找到該屬性，則會回傳其描述；否則方法會回傳該列舉值的字串表示。</remarks>
        /// <param name="enumValue">要取得描述的列舉值。</param>
        /// <returns>套用於該列舉值之 <see cref="DescriptionAttribute"/> 所指定的描述；若沒有描述屬性，則回傳該列舉值的名稱。</returns>
        public static string GetDescription(this Enum enumValue)
        {
            FieldInfo field = enumValue.GetType().GetField(enumValue.ToString());
            if (field == null)
                return enumValue.ToString();

            DescriptionAttribute[] array = (DescriptionAttribute[])field.GetCustomAttributes(typeof(DescriptionAttribute), inherit: false);
            if (array != null && array.Length != 0)
            {
                return array[0].Description;
            }

            return enumValue.ToString();
        }

        /// <summary>
        /// 取得屬性的 Description。
        /// </summary>
        /// <remarks>此方法會使用反射來取得指定類型中屬性的 <see cref="DescriptionAttribute"/>，並回傳其描述內容。如果該屬性不存在或沒有描述，則回傳 string.Empty。</remarks>
        /// <typeparam name="T">類型。</typeparam>
        /// <param name="propertyName">屬性名稱。</param>
        /// <returns>屬性的描述。</returns>
        public static string GetDescription<T>(string propertyName)
        {
            PropertyInfo property = typeof(T).GetProperty(propertyName);
            if (property == null)
                return string.Empty;

            return property.GetCustomAttribute<DescriptionAttribute>()?.Description ?? string.Empty;
        }

        /// <summary>
        /// 根據描述取得列舉值。
        /// </summary>
        /// <remarks>此方法會遍歷指定列舉類型的所有欄位，並檢查每個欄位上的 <see cref="DescriptionAttribute"/>。若找到描述符合的欄位，則回傳該欄位的值；若找不到，則回傳預設值。</remarks>
        /// <typeparam name="T">列舉類型。</typeparam>
        /// <param name="description">描述字串。</param>
        /// <returns>對應的列舉值，若找不到則回傳預設值。</returns>
        public static T GetEnumByDescription<T>(this string description)
        {
            foreach (FieldInfo fi in typeof(T).GetFields())
            {
                DescriptionAttribute[] attributes =
                    (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attributes.Length > 0 && attributes[0].Description == description)
                {
                    object value = fi.GetValue(null);
                    if (value is T tValue)
                        return tValue;
                }

                if (fi.Name == description)
                {
                    object value = fi.GetValue(null);
                    if (value is T tValue)
                        return tValue;
                }
            }
            return default;
        }
    }
}
