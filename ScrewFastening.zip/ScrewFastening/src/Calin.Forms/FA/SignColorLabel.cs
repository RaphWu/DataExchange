﻿using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.UI.FA
{
    /// <summary>
    /// 根據數值正負或零自動變換背景和文字顏色的 Label 控制項。
    /// </summary>
    [DefaultProperty("Value")]
    public class SignColorLabel : Label
    {
        private double _value = 0;

        [Category("Data"), Description("顯示的數值")]
        public double Value
        {
            get => _value;
            set
            {
                if (_value != value)
                {
                    _value = value;
                    UpdateDisplay();
                }
            }
        }

        private int _decimalPlaces = 3;
        [Category("Appearance"), Description("數值顯示的小數位數")]
        public int DecimalPlaces
        {
            get => _decimalPlaces;
            set
            {
                if (_decimalPlaces != value)
                {
                    _decimalPlaces = value;
                    UpdateDisplay();
                }
            }
        }

        // 顏色屬性
        [Category("Appearance"), Description("數值為零時背景顏色")]
        public Color ZeroBackColor { get; set; } = Color.LightGray;
        [Category("Appearance"), Description("數值為零時文字顏色")]
        public Color ZeroForeColor { get; set; } = Color.Black;

        [Category("Appearance"), Description("數值為正時背景顏色")]
        public Color PositiveBackColor { get; set; } = Color.LimeGreen;
        [Category("Appearance"), Description("數值為正時文字顏色")]
        public Color PositiveForeColor { get; set; } = Color.Black;

        [Category("Appearance"), Description("數值為負時背景顏色")]
        public Color NegativeBackColor { get; set; } = Color.Firebrick;
        [Category("Appearance"), Description("數值為負時文字顏色")]
        public Color NegativeForeColor { get; set; } = Color.White;

        public SignColorLabel()
        {
            AutoSize = false;
            TextAlign = ContentAlignment.MiddleCenter;
            BorderStyle = BorderStyle.FixedSingle;

            UpdateDisplay();
        }

        private void UpdateDisplay()
        {
            // 根據正負或零更新顏色和文字
            if (_value > 0)
            {
                BackColor = PositiveBackColor;
                ForeColor = PositiveForeColor;
            }
            else if (_value < 0)
            {
                BackColor = NegativeBackColor;
                ForeColor = NegativeForeColor;
            }
            else
            {
                BackColor = ZeroBackColor;
                ForeColor = ZeroForeColor;
            }

            // 更新文字
            Text = _value.ToString($"F{DecimalPlaces}");
        }
    }
}
