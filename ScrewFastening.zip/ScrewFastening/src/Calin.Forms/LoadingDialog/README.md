﻿# LoadingDialog - 載入中對話框

## 簡介

`LoadingDialog` 是一個用於顯示載入動畫的對話框，適合在執行耗時作業時使用。對話框會顯示一個平滑的旋轉動畫，並可自訂載入訊息。

## 特點

- 平滑的旋轉動畫效果
- 簡潔的視覺設計
- 可自訂載入訊息
- 簡單易用的 API
- 支援同步和非同步作業
- 自動置中顯示
- 永遠在最上層顯示

## 使用方法

### 基本用法

```csharp
LoadingDialog loadingDialog = null;
try
{
    // 顯示載入對話框
    loadingDialog = new LoadingDialog();
    loadingDialog.LoadingMessage = "正在處理資料，請稍候...";
    loadingDialog.Show();

    // 執行耗時作業
    PerformLongRunningTask();
}
catch (Exception ex)
{
    MessageBox.Show($"發生錯誤：{ex.Message}");
}
finally
{
    // 確保對話框被關閉並釋放資源
    loadingDialog?.Close();
    loadingDialog?.Dispose();
}
```

### 使用 using 語句（推薦）

```csharp
try
{
    using (var loadingDialog = new LoadingDialog())
    {
        loadingDialog.LoadingMessage = "正在儲存資料...";
        loadingDialog.Show();

        // 執行耗時作業
        await SaveDataAsync();
    }
    
    MessageBox.Show("資料儲存完成！");
}
catch (Exception ex)
{
    MessageBox.Show($"發生錯誤：{ex.Message}");
}
```

### 在非同步作業中使用

```csharp
private async Task LoadDataAsync()
{
    using (var loadingDialog = new LoadingDialog())
    {
        loadingDialog.LoadingMessage = "正在載入資料...";
        loadingDialog.Show();

        // 執行非同步耗時作業
        var data = await _dataService.GetDataAsync();
        
        // 更新 UI
        UpdateUI(data);
    }
}
```

## 實際應用範例

### 在 Form Load 事件中使用

```csharp
private async void MyForm_Load(object sender, EventArgs e)
{
    using (var loadingDialog = new LoadingDialog())
    {
        loadingDialog.LoadingMessage = "正在載入資料...";
        loadingDialog.Show();

        // 載入初始資料
        var data = await LoadInitialDataAsync();
        
        // 更新 UI
        BindDataToControls(data);
    }
}
```

### 在儲存按鈕中使用

```csharp
private async void btnSave_Click(object sender, EventArgs e)
{
    using (var loadingDialog = new LoadingDialog())
    {
        try
        {
            loadingDialog.LoadingMessage = "正在儲存資料...";
            loadingDialog.Show();

            // 儲存資料
            await _repository.SaveAsync(currentEntity);
            
            MessageBox.Show("資料已儲存！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"儲存失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
```

### 在刪除操作中使用

```csharp
private async void btnDelete_Click(object sender, EventArgs e)
{
    // 確認對話框
    var confirmResult = MessageBox.Show(
        "確定要刪除此項目嗎？", 
        "確認刪除", 
        MessageBoxButtons.YesNo, 
        MessageBoxIcon.Question);
    
    if (confirmResult != DialogResult.Yes)
        return;

    using (var loadingDialog = new LoadingDialog())
    {
        try
        {
            loadingDialog.LoadingMessage = "正在刪除資料...";
            loadingDialog.Show();

            // 執行刪除
            await _repository.DeleteAsync(selectedItem.Id);
            
            // 重新載入清單
            await RefreshListAsync();
            
            MessageBox.Show("項目已刪除！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"刪除失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
```

### 批次處理作業

```csharp
private async Task ProcessBatchAsync(IEnumerable<Item> items)
{
    using (var loadingDialog = new LoadingDialog())
    {
        var itemList = items.ToList();
        var total = itemList.Count;
        var current = 0;

        foreach (var item in itemList)
        {
            current++;
            loadingDialog.LoadingMessage = $"正在處理第 {current}/{total} 項...";
            loadingDialog.Show();

            await ProcessItemAsync(item);
        }
    }
    
    MessageBox.Show($"批次處理完成！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
}
```

## 屬性

| 屬性               | 類型       | 說明           | 預設值          |
| ---------------- | -------- | ------------ | ------------ |
| `LoadingMessage` | `string` | 設定或取得顯示的載入訊息 | "載入中，請稍候..." |

## 方法

| 方法          | 說明           |
| ----------- | ------------ |
| `Show()`    | 顯示載入對話框並開始動畫 |
| `Close()`   | 關閉載入對話框並停止動畫 |
| `Dispose()` | 釋放對話框使用的所有資源 |

## 注意事項

1. **使用 using 語句**：強烈建議使用 `using` 語句來確保對話框正確釋放資源。

2. **UI 執行緒**：對話框必須在 UI 執行緒上顯示和關閉。

3. **適用時長**：適合用於 1-10 秒的作業。如果作業時間過長，建議使用進度條對話框或提供取消功能。

4. **非同步作業**：在非同步方法中使用時，確保在 `await` 之前顯示對話框。

5. **例外處理**：使用 try-catch 確保即使發生錯誤也能正確關閉對話框。

## 設計說明

- 對話框背景為半透明深灰色（透明度 95%）
- 使用 12 個線段組成的旋轉動畫
- 每 50 毫秒更新一次動畫（每秒 20 幀）
- 每次旋轉 30 度
- 使用反鋸齒繪製確保平滑效果

## 版本歷史

- **v1.0** - 初始版本
  - 基本轉圈圈動畫
  - 可自訂訊息
  - 支援同步和非同步作業
