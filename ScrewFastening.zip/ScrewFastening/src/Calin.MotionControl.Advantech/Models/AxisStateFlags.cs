﻿using System.ComponentModel;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 軸狀態旗標列舉。
    /// </summary>
    public enum AxisStateFlags : ushort
    {
        [Description("禁用")]
        STA_AX_DISABLE = 0,

        [Description("Ready")]
        STA_AX_READY = 1,

        [Description("Stopping")]
        STA_AX_STOPPING = 2,

        [Description("Error Stop")]
        STA_AX_ERROR_STOP = 3,

        [Description("Homing")]
        STA_AX_HOMING = 4,

        [Description("PTP運動中")]
        STA_AX_PTP_MOTION = 5,

        [Description("連續運動中")]
        STA_AX_CONTI_MOTION = 6,

        [Description("同步運動中")]
        STA_AX_SYNC_MOTION = 7,

        [Description("外部控制，JOG模式")]
        STA_AX_EXT_JOG = 8,

        [Description("外部控制，MPG模式")]
        STA_AX_EXT_MPG = 9,

        [Description("暫停")]
        STA_AX_PAUSE = 10,

        [Description("Busy")]
        STA_AX_BUSY = 11,

        [Description("等候DI信號")]
        STA_AX_WAIT_DI = 12,

        [Description("等候PTP運動完成")]
        STA_AX_WAIT_PTP = 13,

        [Description("等候連續運動完成")]
        STA_AX_WAIT_VEL = 14,

        [Description("外部JOG準備中")]
        STA_AX_EXT_JOG_READY = 15,
    }
}
