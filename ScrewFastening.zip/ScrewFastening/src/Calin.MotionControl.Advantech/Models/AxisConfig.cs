﻿
using Calin.MVVM;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 軸參數配置。
    /// </summary>
    public class AxisConfig : ObservableObject
    {


        /// <summary>
        /// 從來源複製設定值。
        /// </summary>
        /// <param name="source">來源設定值。</param>
        public void CopyFrom(AxisConfig source)
        {
            if (source == null) return;


        }
    }
}
