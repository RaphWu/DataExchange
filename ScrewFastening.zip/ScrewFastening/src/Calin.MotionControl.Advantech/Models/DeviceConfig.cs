﻿using Calin.MVVM;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 裝置參數配置。
    /// </summary>
    public class DeviceConfig : ObservableObject
    {
        #region properties

        /// <summary>
        /// EMG 邏輯電位。
        /// </summary>
        public uint EmgLogic
        {
            get { return _emgLogic; }
            set { SetProperty(ref _emgLogic, value); }
        }
        private uint _emgLogic = (uint)global::Advantech.Motion.EmgLogic.NOT_SUPPORT;

        /// <summary>
        /// EMG 濾波時間 (μs)。
        /// </summary>
        public int EmgFilterTime
        {
            get { return _emgFilterTime; }
            set { SetProperty(ref _emgFilterTime, value); }
        }
        private int _emgFilterTime;

        #endregion properties

        #region Methods

        /// <summary>
        /// 從來源複製設定值。
        /// </summary>
        /// <param name="source">來源設定值。</param>
        public void CopyFrom(DeviceConfig source)
        {
            if (source == null) return;

            EmgLogic = source.EmgLogic;
            EmgFilterTime = source.EmgFilterTime;
        }

        #endregion Methods
    }
}
