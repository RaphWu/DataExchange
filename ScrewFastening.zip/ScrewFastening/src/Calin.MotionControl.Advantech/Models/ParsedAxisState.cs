﻿using System;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 解析後的軸狀態。
    /// </summary>
    public class ParsedAxisState : IEquatable<ParsedAxisState>
    {
        /// <summary>
        /// 軸命令位置。
        /// </summary>
        public double CmdPosition;

        /// <summary>
        /// 軸實際位置。
        /// </summary>
        public double ActPosition;

        /// <summary>
        /// 軸當前狀態。
        /// </summary>
        public AxisStateFlags AxisStateFlags;

        // 軸當前狀態對應的 bool 屬性
        public bool STA_AX_DISABLE = true;
        public bool STA_AX_READY = true;
        public bool STA_AX_STOPPING;
        public bool STA_AX_ERROR_STOP;
        public bool STA_AX_HOMING;
        public bool STA_AX_PTP_MOTION;
        public bool STA_AX_CONTI_MOTION;
        public bool STA_AX_SYNC_MOTION;
        public bool STA_AX_EXT_JOG;
        public bool STA_AX_EXT_MPG;
        public bool STA_AX_PAUSE;
        public bool STA_AX_BUSY;
        public bool STA_AX_WAIT_DI;
        public bool STA_AX_WAIT_PTP;
        public bool STA_AX_WAIT_VEL;
        public bool STA_AX_EXT_JOG_READY;

        /// <summary>
        /// 軸當前運動狀態。
        /// </summary>
        public AxisMotionFlags AxisMotionFlags;

        // 軸當前運動狀態對應的 bool 屬性
        public bool Stop;
        public bool CorrectBksh;
        public bool InFA;
        public bool InFL;
        public bool InACC;
        public bool InFH;
        public bool InDEC;
        public bool WaitINP;

        /// <summary>
        /// 軸的運動 I/O 狀態。
        /// </summary>
        public AxisIoFlags AxisIoFlags;

        // 軸的運動 I/O 狀態對應的 bool 屬性
        public bool RDY;
        public bool ALM;
        public bool LMT_Positive;
        public bool LMT_Negative;
        public bool ORG;
        public bool DIR;
        public bool EMG;
        public bool EZ;
        public bool LTC;
        public bool INP;
        public bool SVON;
        public bool ALRM;
        public bool SLMT_Positive;
        public bool SLMT_Negative;

        public bool Equals(ParsedAxisState other)
        {
            if (other == null) return false;
            if (ReferenceEquals(this, other)) return true;
            const double Epsilon = 1e-6;
            return Math.Abs(CmdPosition - other.CmdPosition) <= Epsilon
                && Math.Abs(ActPosition - other.ActPosition) <= Epsilon
                && AxisStateFlags == other.AxisStateFlags
                && AxisMotionFlags == other.AxisMotionFlags
                && AxisIoFlags == other.AxisIoFlags;
        }

        public override bool Equals(object obj)
            => obj is ParsedAxisState other && Equals(other);

        public override int GetHashCode()
            => ((int)AxisStateFlags * 397) ^ ((int)AxisMotionFlags * 17) ^ (int)AxisIoFlags;

        public static bool operator ==(ParsedAxisState left, ParsedAxisState right)
        {
            if (ReferenceEquals(left, right)) return true;   // 若參考相等（包含同為 null），視為相等
            if (left is null || right is null) return false; // 若任一為 null（但不同時為 null），視為不相等
            return left.Equals(right);                       // 兩者皆非 null，使用 instance Equals

            //// 先處理參考相等（包含同為 null）
            //if (ReferenceEquals(left, right)) return true;
            //// 若 left 為 null（而 right 不為 null），則不相等
            //if (ReferenceEquals(left, null)) return false;
            //// left 非 null，安全地呼叫 instance Equals
            //return left.Equals(right);
        }

        public static bool operator !=(ParsedAxisState left, ParsedAxisState right)
        {
            return !(left == right);
        }
    }
}
