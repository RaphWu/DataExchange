﻿using System;
using System.Collections.ObjectModel;
using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.MVVM;

namespace Calin.MotionControl.Advantech.Services
{
    // 裝置(Device)與控制卡(Board)操作
    // 裝置設定檔操作
    public partial class AcmService : ObservableObject, IAcmService_Device
    {
        #region Fields

        private bool _noError = true;
        private bool _isRollback = false;

        /// <summary>
        /// 裝置句柄。
        /// </summary>
        private IntPtr _deviceHandle = IntPtr.Zero;

        /// <summary>
        /// 控制卡是否初始化。
        /// </summary>
        private bool _boardInit = false;

        /// <summary>
        /// 有效裝置數量。
        /// </summary>
        private uint _deviceCount = 0;

        /// <summary>
        /// 可用裝置列表。
        /// </summary>
        private readonly ObservableCollection<DeviceInfo> _availableDevices = new ObservableCollection<DeviceInfo>();

        /// <summary>
        /// 裝置設定檔。
        /// </summary>
        private DeviceConfig _deviceConfig = new DeviceConfig();

        #endregion Fields

        #region properties
        public uint DeviceCount => _deviceCount;
        public ObservableCollection<DeviceInfo> AvailableDevices => _availableDevices;
        public IntPtr DeviceHandle => _deviceHandle;
        public bool IsBoardInit => _boardInit;
        public uint DaqDiMaxChannel => _daqDiMaxChannel;
        public uint DaqDoMaxChannel => _daqDoMaxChannel;

        public DeviceConfig DeviceConfig
        {
            get { return _deviceConfig; }
            private set { SetProperty(ref _deviceConfig, value); }
        }

        #endregion properties

        #region methods

        /// <inheritdoc/>
        public bool GetAvailableDevs()
        {
            DEV_LIST[] availableDevices = new DEV_LIST[Motion.MAX_DEVICES];
            ErrCode = (uint)Motion.mAcm_GetAvailableDevs(availableDevices, Motion.MAX_DEVICES, ref _deviceCount);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "無法取得裝置編號及名稱列表！")) return false;
            if (_deviceCount <= 0)
            {
                SetErr($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "找不到任何可用的裝置！");
                return false;
            }

            _availableDevices.Clear();
            for (int i = 0; i < _deviceCount; i++)
                _availableDevices.Add(new DeviceInfo()
                {
                    DeviceName = availableDevices[i].DeviceName,
                    DeviceNumber = availableDevices[i].DeviceNum,
                    NumofSubDevice = availableDevices[i].NumofSubDevice,
                });

            // TODO: 取得數位輸入/輸出最大通道數
            //ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqDoMaxChan, ref _daqDoMaxChannel);
            //if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "取得數位輸出最大通道數失敗！"))
            //    return 0;

            //ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqDiMaxChan, ref _daqDiMaxChannel);
            //if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "取得數位輸入最大通道數失敗！"))
            //    return 0;

            return true;
        }

        /// <inheritdoc/>
        public bool BoardClose()
        {
            if (_boardInit)
            {
                ushort[] axisState = new ushort[32];
                int axisNo;

                PollingStop();

                for (axisNo = 0; axisNo < _axisCount; axisNo++)
                {
                    // 取得軸的當前狀態
                    ErrCode = Motion.mAcm_AxGetState(_axisHandles[axisNo], ref axisState[axisNo]);
                    if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"無法取得軸 {axisNo + 1} 的當前狀態！")) return false;

                    if (axisState[axisNo] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // 重置座標軸狀態。如果座標軸處於 ErrorStop 狀態，呼叫此函數後，其狀態將變更為 Ready
                        ErrCode = Motion.mAcm_AxResetError(_axisHandles[axisNo]);
                        if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"無法重置軸 {axisNo + 1} 的座標軸狀態！")) return false;
                    }

                    // 命令軸減速直至停止
                    ErrCode = Motion.mAcm_AxStopDec(_axisHandles[axisNo]);
                    if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"軸 {axisNo + 1} 減速至停的動作失敗！")) return false;
                }

                for (axisNo = 0; axisNo < _axisCount; axisNo++)
                {
                    ErrCode = Motion.mAcm_AxClose(ref _axisHandles[axisNo]);
                    if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"軸 {axisNo + 1} 關閉失敗！")) return false;
                }
                _axisCount = 0;

                ErrCode = Motion.mAcm_DevClose(ref _deviceHandle);
                if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", "裝置關閉失敗！")) return false;

                _deviceHandle = IntPtr.Zero;
                _boardInit = false;
            }
            return true;
        }

        /// <inheritdoc/>
        public bool BoardOpen(uint deviceNum)
        {
            ErrCode = Motion.mAcm_DevOpen(deviceNum, ref _deviceHandle);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", "裝置開啟失敗！"))
                return false;

            ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DevAxesCount, ref _axisCount);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", "無法取得控制卡上的軸數量！"))
                return false;

            if (_axisCount == 0)
            {
                SetErr($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", "控制卡軸數量為 0，無法進行後續操作！");
                return false;
            }

            // init arrays
            _axisHandles = new IntPtr[_axisCount];
            _servoOn = new bool[_axisCount];
            _rawAxisStates = new RawAxisState[_axisCount];
            _parsedAxisStates = new ParsedAxisState[_axisCount];

            for (int axisNo = 0; axisNo < _axisCount; axisNo++)
            {
                _servoOn[axisNo] = false;
                _rawAxisStates[axisNo] = new RawAxisState();
                _parsedAxisStates[axisNo] = new ParsedAxisState();

                ErrCode = Motion.mAcm_AxOpen(_deviceHandle, (ushort)axisNo, ref _axisHandles[axisNo]);
                if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", $"軸 {axisNo + 1} 開啟失敗！"))
                    return false;

                // 設定命令位置及實際位置為 0
                ErrCode = Motion.mAcm_AxSetCmdPosition(_axisHandles[axisNo], 0.0);
                ErrCode = Motion.mAcm_AxSetActualPosition(_axisHandles[axisNo], 0.0);
            }

            _boardInit = true;
            return true;
        }

        #endregion methods

        #region Advantech內建

        /// <inheritdoc/>
        public bool LoadCfg(string filePath)
        {
            if (!_boardInit)
            {
                SetErr($"{nameof(IAcmService_Device)}.{nameof(LoadCfg)}", "控制卡尚未開啟");
                return false;
            }

            ErrCode = Motion.mAcm_DevLoadConfig(_deviceHandle, filePath);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(LoadCfg)}", "裝置Config檔載入失敗！")) return false;

            return true;
        }

        #endregion Advantech內建

        #region Configs

        /// <inheritdoc/>
        public bool GetDeviceConfig()
        {
            if (!_boardInit)
            {
                SetErr($"{nameof(IAcmService_Device)}.{nameof(GetDeviceConfig)}", "控制卡尚未開啟");
                return false;
            }

            // 讀取硬體設定至 DeviceConfig
            uint emgLogic = 0;
            ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.CFG_DevEmgLogic, ref emgLogic);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(GetDeviceConfig)}", "讀取 EMG 邏輯電位 失敗！")) return false;
            DeviceConfig.EmgLogic = emgLogic;

            int emgFilterTime = 0;
            ErrCode = Motion.mAcm_GetI32Property(_deviceHandle, (uint)PropertyID.CFG_DevEmgFilterTime, ref emgFilterTime);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(GetDeviceConfig)}", "讀取 EMG 濾波時間 失敗！")) return false;
            DeviceConfig.EmgFilterTime = emgFilterTime;

            return true;
        }

        /// <inheritdoc/>
        public void ApplyDeviceConfig(DeviceConfig config)
        {
            if (config == null) return;

            // 寫入硬體
            ErrCode = Motion.mAcm_SetU32Property(_deviceHandle, (uint)PropertyID.CFG_DevEmgLogic, config.EmgLogic);
            if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(ApplyDeviceConfig)}", "寫入 EMG 邏輯電位 失敗！")) _noError = false;

            if (_noError)
            {
                ErrCode = Motion.mAcm_SetI32Property(_deviceHandle, (uint)PropertyID.CFG_DevEmgFilterTime, config.EmgFilterTime);
                if (CheckErr($"{nameof(IAcmService_Device)}.{nameof(ApplyDeviceConfig)}", "寫入 EMG 濾波時間 失敗！")) _noError = false;
            }

            // END
            if (_isRollback)
            {
                if (_noError)
                {
                    SetErr((uint)ErrorCode.InvalidParameter, $"{nameof(IAcmService_Device)}.{nameof(ApplyDeviceConfig)}", "套用裝置設定失敗，已回復原本設定！");
                }
                else
                {
                    SetErr((uint)ErrorCode.InvalidParameter, $"{nameof(IAcmService_Device)}.{nameof(ApplyDeviceConfig)}", "套用裝置設定失敗，也無法回復原本設定！");
                }
                return;
            }

            if (!_noError)
            {
                _noError = true;
                _isRollback = true;
                ApplyDeviceConfig(DeviceConfig); // rollback
                return;
            }

            // 儲存至本地
            _noError = true;
            _isRollback = false;
            DeviceConfig.CopyFrom(config);
        }

        #endregion Configs
    }
}
