﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using Advantech.Motion;
using Calin.Helpers;
using Calin.MotionControl.Advantech.Constants;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.MotionControl.Advantech.ViewModels;
using Calin.MVVM;

namespace Calin.MotionControl.Advantech.Services
{
    /// <summary>
    /// Advantech ACM 服務。
    /// </summary>
    public partial class AcmService : ObservableObject, IAcm
    {
        #region Fields

        private const string AcmCfgFileName = "AcmConfig.json";
        private readonly AcmConfig _acmConfig;

        /// <summary>
        /// 數位輸入最大通道數。
        /// </summary>
        private uint _daqDiMaxChannel;

        /// <summary>
        /// 數位輸出最大通道數。
        /// </summary>
        private uint _daqDoMaxChannel;

        #endregion Fields

        #region Properties

        public AcmConfig Config { get; } = new AcmConfig();

        #endregion Properties

        #region ctor

        public AcmService(AcmConfig acmConfig)
        {
            _acmConfig = acmConfig;

            uint homeMode;
            AcmContants.HomeModeList.Clear();
            homeMode = (uint)HomeMode.MODE1_Abs;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE2_Lmt;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE3_Ref;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE4_Abs_Ref;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE5_Abs_NegRef;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE6_Lmt_Ref;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE7_AbsSearch;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE8_LmtSearch;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE9_AbsSearch_Ref;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE10_AbsSearch_NegRef;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE11_LmtSearch_Ref;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE12_AbsSearchReFind;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE13_LmtSearchReFind;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE14_AbsSearchReFind_Ref;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE15_AbsSearchReFind_NegRef;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
            homeMode = (uint)HomeMode.MODE16_LmtSearchReFind_Ref;
            AcmContants.HomeModeList.Add(new UintStringPair() { Id = homeMode, Name = GetHomeModeName(homeMode), });
        }

        #endregion ctor

        #region Methods

        /// <inheritdoc/>
        public bool Initialize()
        {
            if (!GetAvailableDevs()) return false;
            if (!BoardOpen(_availableDevices[0].DeviceNumber)) return false;

            if (_boardInit)
            {
                LoadConfig();
                for (int axisNo = 0; axisNo < _axisCount; axisNo++)
                {
                    ServoOn(axisNo);
                }
            }
            return _boardInit;
        }

        /// <inheritdoc/>
        public void LoadConfig()
        {
            if (!_boardInit) return;

            bool loadFromFile = false;
            AcmConfig config = null;
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, AcmCfgFileName);
            if (File.Exists(path))
            {
                try
                {
                    config = JsonFileHelper.Read<AcmConfig>(path);
                    loadFromFile = true;
                }
                catch (Exception ex)
                {
                    // 讀取失敗：不要立刻覆寫檔案（避免讀取中出錯就覆蓋原始檔）
                    Console.WriteLine($"DaqLoadConfig: failed to read config file '{path}': {ex}");
                    config = null;
                }
            }

            if (config == null)
            {
                config = new AcmConfig();
                config.AxisConfigs = new ObservableCollection<AxisConfig>();
                for (int axisNo = 0; axisNo < _axisCount; axisNo++)
                    config.AxisConfigs.Add(new AxisConfig());
                loadFromFile = false;
            }

            // 硬體配置優先於檔案配置
            if (GetDeviceSetting())
                loadFromFile = false;
            if (GetAxisConfigsFile())
                loadFromFile = false;

            if (!loadFromFile)
                SaveConfig(config);

            _acmConfig.DeviceConfig.CopyFrom(config.DeviceConfig);
            for (int axisNo = 0; axisNo < _axisCount; axisNo++)
            {
                if (_acmConfig.AxisConfigs[axisNo].AxisId < 0)
                    _acmConfig.AxisConfigs[axisNo].AxisId = axisNo;
                _acmConfig.AxisConfigs[axisNo].CopyFrom(config.AxisConfigs[axisNo]);
            }
        }

        /// <inheritdoc/>
        public void SaveConfig(AcmConfig config)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, AcmCfgFileName);
            JsonFileHelper.Save(path, config);
        }
    }

    #endregion Methods
}
