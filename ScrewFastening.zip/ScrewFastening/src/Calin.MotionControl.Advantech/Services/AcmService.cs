﻿using Calin.MotionControl.Advantech.Contracts;
using Calin.MVVM;

namespace Calin.MotionControl.Advantech.Services
{
    /// <summary>
    /// Advantech ACM 服務。
    /// </summary>
    public partial class AcmService : ObservableObject, IAcm
    {
        #region Fields

        private const string CfgFileName = "AdvantechAcmCfg.json";

        /// <summary>
        /// 數位輸入最大通道數。
        /// </summary>
        private uint _daqDiMaxChannel;

        /// <summary>
        /// 數位輸出最大通道數。
        /// </summary>
        private uint _daqDoMaxChannel;

        #endregion Fields

        #region Properties
        #endregion Properties

        #region Methods

        public bool Initialize()
        {
            if (!GetAvailableDevs()) return false;
            if (!BoardOpen(_availableDevices[0].DeviceNumber)) return false;

            //if (_boardInit)
            //{
            //    _servoOn = new bool[_axisCount];
            //    _rawAxisStates = new RawAxisState[_axisCount];
            //    _parsedAxisStates = new ParsedAxisState[_axisCount];

            //    for (int axisNo = 0; axisNo < _axisCount; axisNo++)
            //    {
            //        _servoOn[axisNo] = false;
            //        _rawAxisStates[axisNo] = new RawAxisState();
            //        _parsedAxisStates[axisNo] = new ParsedAxisState();

            //        ServoOn(axisNo);
            //    }
            //}
            return _boardInit;
        }
    }

    #endregion Methods
}
