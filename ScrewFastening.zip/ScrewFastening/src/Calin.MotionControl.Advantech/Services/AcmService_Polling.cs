﻿using System;
using System.Diagnostics;
using System.Threading;
using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Services
{
    // 控制卡狀態讀取/更新服務。
    public partial class AcmService : IAcmService_Polling
    {
        #region Fields

        private Thread _motionCardStatusThread;
        private Thread _parseThread;
        private CancellationTokenSource _pollingCts;

        #endregion Fields

        #region Properties

        public event EventHandler<AcmStatusUpdatedEventArgs> AcmStatusUpdated;

        #endregion Properties

        #region Methods

        /// <inheritdoc/>
        public void PollingStop()
        {
            /*
             - 以 CancellationToken 與 WaitHandle 進行喚醒/等待。
             - 先發出取消，接著以 Join 等待兩條執行緒結束。
             - 最後才 Dispose CancellationTokenSource。
            */

            // 發出取消通知（若已被 Dispose，忽略例外）
            try
            {
                _pollingCts?.Cancel();
            }
            catch (ObjectDisposedException)
            {
                // Cancellation token source 已被處置，忽略
            }

            const int JoinTimeoutMs = 2000;

            // 等待 monitoring 執行緒結束
            try
            {
                if (_motionCardStatusThread != null && _motionCardStatusThread.IsAlive)
                    _motionCardStatusThread.Join(JoinTimeoutMs);
            }
            catch (Exception)
            {
                // 忽略等待期間可能的例外
            }

            // 等待 parse 執行緒結束
            try
            {
                if (_parseThread != null && _parseThread.IsAlive)
                    _parseThread.Join(JoinTimeoutMs);
            }
            catch (Exception)
            {
                // 忽略等待期間可能的例外
            }

            // 清理 CancellationTokenSource（在 Join 完成後再 Dispose）
            try
            {
                _pollingCts?.Dispose();
            }
            catch (ObjectDisposedException)
            {
                // 已被處置，忽略
            }
            finally
            {
                _pollingCts = null;
            }

            // 清除執行緒引用
            _motionCardStatusThread = null;
            _parseThread = null;
        }

        /// <inheritdoc/>
        public void PollingStart()
        {
            _pollingCts = new CancellationTokenSource();

            _parseThread = new Thread(() => ParseProc(_pollingCts.Token));
            _parseThread.IsBackground = true;
            _parseThread.Priority = ThreadPriority.Normal;
            _parseThread.Start();

            _motionCardStatusThread = new Thread(() => MotionCardStatusProc(_pollingCts.Token));
            _motionCardStatusThread.IsBackground = true;
            _motionCardStatusThread.Priority = ThreadPriority.Highest;
            _motionCardStatusThread.Start();
        }

        #endregion Methods

        #region Polling Procedures

        /// <summary>
        /// 運動控制卡狀態讀取程序。
        /// </summary>
        /// <param name="token">取消令牌。</param>
        private void MotionCardStatusProc(CancellationToken token)
        {
            var sw = Stopwatch.StartNew();
            long ticksPerMs = Stopwatch.Frequency / 3;
            long nextTick = sw.ElapsedTicks;
            var spin = new SpinWait();

            while (!token.IsCancellationRequested)
            {
                long now = sw.ElapsedTicks;
                if (now >= nextTick)
                {
                    nextTick += ticksPerMs;
                    spin.Reset();

                    for (int axisNo = 0; axisNo < _axisCount; axisNo++)
                    {
                        var axisState = _rawAxisStates[axisNo];

                        double cmdPos = default;
                        ErrCode = Motion.mAcm_AxGetCmdPosition(_axisHandles[axisNo], ref cmdPos);
                        if (ErrorOccurred($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的命令位置！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.CmdPosition = cmdPos;

                        double actPos = default;
                        ErrCode = Motion.mAcm_AxGetActualPosition(_axisHandles[axisNo], ref actPos);
                        if (ErrorOccurred($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的實際位置！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.ActPosition = actPos;

                        // 軸狀態
                        ushort acmAxisState = default;
                        ErrCode = Motion.mAcm_AxGetState(_axisHandles[axisNo], ref acmAxisState);
                        if (ErrorOccurred($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.AxisState = (AxisState)acmAxisState;

                        // 軸運動狀態
                        uint acmAxisMotionStatus = default;
                        ErrCode = Motion.mAcm_AxGetMotionStatus(_axisHandles[axisNo], ref acmAxisMotionStatus);
                        if (ErrorOccurred($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的運動狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.AxisMotionStatus = acmAxisMotionStatus;

                        // 軸IO狀態
                        uint acmAxisIoStatus = default;
                        ErrCode = Motion.mAcm_AxGetMotionIO(_axisHandles[axisNo], ref acmAxisIoStatus);
                        if (ErrorOccurred($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的 I/O 狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.AxisIoStatus = acmAxisIoStatus;

                        //// DI狀態
                        //byte[] daqDiStatus = new byte[8];
                        //ErrCode = Motion.mAcm_DaqDiGetBytes(_axisHandles[axisNo], 0, 7, daqDiStatus);
                        //if (ErrorOccurred($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的 DI 狀態！"))
                        //{
                        //    token.ThrowIfCancellationRequested();
                        //    continue;
                        //}
                        //axisState.AxisDi = daqDiStatus;

                        //// DO狀態
                        //byte[] daqDoStatus = new byte[8];
                        //ErrCode = Motion.mAcm_DaqDoGetBytes(_axisHandles[axisNo], 0, 7, daqDoStatus);
                        //if (ErrorOccurred($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的 DI 狀態！"))
                        //{
                        //    token.ThrowIfCancellationRequested();
                        //    continue;
                        //}
                        //axisState.AxisDo = daqDoStatus;

                        _rawAxisStates[axisNo] = axisState;
                    }

                    // 用於須快速反應的停止條件
                    //if (torque >= TorqueLimit)
                    //{
                    //    EmergencyStop();
                    //}
                }
                else
                {
                    spin.SpinOnce();
                }
            }
        }

        /// <summary>
        /// 解析程序。
        /// </summary>
        /// <param name="token">取消令牌。</param>
        private void ParseProc(CancellationToken token)
        {
            int axisNo = 0;
            while (!token.IsCancellationRequested)
            {
                bool dataChanged = false;

                if (_parsedAxisStates[axisNo].CmdPosition != _rawAxisStates[axisNo].CmdPosition)
                {
                    _parsedAxisStates[axisNo].CmdPosition = _rawAxisStates[axisNo].CmdPosition;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].ActPosition != _rawAxisStates[axisNo].ActPosition)
                {
                    _parsedAxisStates[axisNo].ActPosition = _rawAxisStates[axisNo].ActPosition;
                    dataChanged = true;
                }

                var axisState = (AxisStateFlags)_rawAxisStates[axisNo].AxisState;
                if (_parsedAxisStates[axisNo].AxisStateFlags != axisState)
                {
                    _parsedAxisStates[axisNo].AxisStateFlags = axisState;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_DISABLE != (axisState == AxisStateFlags.STA_AX_DISABLE))
                {
                    _parsedAxisStates[axisNo].STA_AX_DISABLE = !_parsedAxisStates[axisNo].STA_AX_DISABLE;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_READY != (axisState == AxisStateFlags.STA_AX_READY))
                {
                    _parsedAxisStates[axisNo].STA_AX_READY = !_parsedAxisStates[axisNo].STA_AX_READY;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_STOPPING != (axisState == AxisStateFlags.STA_AX_STOPPING))
                {
                    _parsedAxisStates[axisNo].STA_AX_STOPPING = !_parsedAxisStates[axisNo].STA_AX_STOPPING;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_ERROR_STOP != (axisState == AxisStateFlags.STA_AX_ERROR_STOP))
                {
                    _parsedAxisStates[axisNo].STA_AX_ERROR_STOP = !_parsedAxisStates[axisNo].STA_AX_ERROR_STOP;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_HOMING != (axisState == AxisStateFlags.STA_AX_HOMING))
                {
                    _parsedAxisStates[axisNo].STA_AX_HOMING = !_parsedAxisStates[axisNo].STA_AX_HOMING;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_PTP_MOTION != (axisState == AxisStateFlags.STA_AX_PTP_MOTION))
                {
                    _parsedAxisStates[axisNo].STA_AX_PTP_MOTION = !_parsedAxisStates[axisNo].STA_AX_PTP_MOTION;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_CONTI_MOTION != (axisState == AxisStateFlags.STA_AX_CONTI_MOTION))
                {
                    _parsedAxisStates[axisNo].STA_AX_CONTI_MOTION = !_parsedAxisStates[axisNo].STA_AX_CONTI_MOTION;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_SYNC_MOTION != (axisState == AxisStateFlags.STA_AX_SYNC_MOTION))
                {
                    _parsedAxisStates[axisNo].STA_AX_SYNC_MOTION = !_parsedAxisStates[axisNo].STA_AX_SYNC_MOTION;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_EXT_JOG != (axisState == AxisStateFlags.STA_AX_EXT_JOG))
                {
                    _parsedAxisStates[axisNo].STA_AX_EXT_JOG = !_parsedAxisStates[axisNo].STA_AX_EXT_JOG;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_EXT_MPG != (axisState == AxisStateFlags.STA_AX_EXT_MPG))
                {
                    _parsedAxisStates[axisNo].STA_AX_EXT_MPG = !_parsedAxisStates[axisNo].STA_AX_EXT_MPG;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_PAUSE != (axisState == AxisStateFlags.STA_AX_PAUSE))
                {
                    _parsedAxisStates[axisNo].STA_AX_PAUSE = !_parsedAxisStates[axisNo].STA_AX_PAUSE;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_BUSY != (axisState == AxisStateFlags.STA_AX_BUSY))
                {
                    _parsedAxisStates[axisNo].STA_AX_BUSY = !_parsedAxisStates[axisNo].STA_AX_BUSY;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_WAIT_DI != (axisState == AxisStateFlags.STA_AX_WAIT_DI))
                {
                    _parsedAxisStates[axisNo].STA_AX_WAIT_DI = !_parsedAxisStates[axisNo].STA_AX_WAIT_DI;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_WAIT_PTP != (axisState == AxisStateFlags.STA_AX_WAIT_PTP))
                {
                    _parsedAxisStates[axisNo].STA_AX_WAIT_PTP = !_parsedAxisStates[axisNo].STA_AX_WAIT_PTP;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_WAIT_VEL != (axisState == AxisStateFlags.STA_AX_WAIT_VEL))
                {
                    _parsedAxisStates[axisNo].STA_AX_WAIT_VEL = !_parsedAxisStates[axisNo].STA_AX_WAIT_VEL;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].STA_AX_EXT_JOG_READY != (axisState == AxisStateFlags.STA_AX_EXT_JOG_READY))
                {
                    _parsedAxisStates[axisNo].STA_AX_EXT_JOG_READY = !_parsedAxisStates[axisNo].STA_AX_EXT_JOG_READY;
                    dataChanged = true;
                }

                const uint AxisMotionMask = (uint)(
                    AxisMotionFlags.Stop | AxisMotionFlags.CorrectBksh |
                    AxisMotionFlags.InFA | AxisMotionFlags.InFL | AxisMotionFlags.InACC |
                    AxisMotionFlags.InFH | AxisMotionFlags.InDEC | AxisMotionFlags.WaitINP);
                var axisMotionFlags = _rawAxisStates[axisNo].AxisMotionStatus & AxisMotionMask;
                if (_parsedAxisStates[axisNo].AxisMotionFlags != (AxisMotionFlags)axisMotionFlags)
                {
                    _parsedAxisStates[axisNo].AxisMotionFlags = (AxisMotionFlags)axisMotionFlags;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].Stop != ((axisMotionFlags & (uint)AxisMotionFlags.Stop) != 0))
                {
                    _parsedAxisStates[axisNo].Stop = !_parsedAxisStates[axisNo].Stop;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].CorrectBksh != ((axisMotionFlags & (uint)AxisMotionFlags.CorrectBksh) != 0))
                {
                    _parsedAxisStates[axisNo].CorrectBksh = !_parsedAxisStates[axisNo].CorrectBksh;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].InFA != ((axisMotionFlags & (uint)AxisMotionFlags.InFA) != 0))
                {
                    _parsedAxisStates[axisNo].InFA = !_parsedAxisStates[axisNo].InFA;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].InFL != ((axisMotionFlags & (uint)AxisMotionFlags.InFL) != 0))
                {
                    _parsedAxisStates[axisNo].InFL = !_parsedAxisStates[axisNo].InFL;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].InACC != ((axisMotionFlags & (uint)AxisMotionFlags.InACC) != 0))
                {
                    _parsedAxisStates[axisNo].InACC = !_parsedAxisStates[axisNo].InACC;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].InFH != ((axisMotionFlags & (uint)AxisMotionFlags.InFH) != 0))
                {
                    _parsedAxisStates[axisNo].InFH = !_parsedAxisStates[axisNo].InFH;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].InDEC != ((axisMotionFlags & (uint)AxisMotionFlags.InDEC) != 0))
                {
                    _parsedAxisStates[axisNo].InDEC = !_parsedAxisStates[axisNo].InDEC;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].WaitINP != ((axisMotionFlags & (uint)AxisMotionFlags.WaitINP) != 0))
                {
                    _parsedAxisStates[axisNo].WaitINP = !_parsedAxisStates[axisNo].WaitINP;
                    dataChanged = true;
                }

                const uint AxisIoMask = (uint)(
                    AxisIoFlags.RDY | AxisIoFlags.ALM | AxisIoFlags.LMT_Positive | AxisIoFlags.LMT_Negative |
                    AxisIoFlags.ORG | AxisIoFlags.DIR | AxisIoFlags.EMG | AxisIoFlags.EZ | AxisIoFlags.LTC |
                    AxisIoFlags.INP | AxisIoFlags.SVON | AxisIoFlags.ALRM |
                    AxisIoFlags.SLMT_Positive | AxisIoFlags.SLMT_Negative);
                var axisIoFlags = _rawAxisStates[axisNo].AxisIoStatus & AxisIoMask;
                if (_parsedAxisStates[axisNo].AxisIoFlags != (AxisIoFlags)axisIoFlags)
                {
                    _parsedAxisStates[axisNo].AxisIoFlags = (AxisIoFlags)axisIoFlags;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].RDY != ((axisIoFlags & (uint)AxisIoFlags.RDY) != 0))
                {
                    _parsedAxisStates[axisNo].RDY = !_parsedAxisStates[axisNo].RDY;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].ALM != ((axisIoFlags & (uint)AxisIoFlags.ALM) != 0))
                {
                    _parsedAxisStates[axisNo].ALM = !_parsedAxisStates[axisNo].ALM;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].LMT_Positive != ((axisIoFlags & (uint)AxisIoFlags.LMT_Positive) != 0))
                {
                    _parsedAxisStates[axisNo].LMT_Positive = !_parsedAxisStates[axisNo].LMT_Positive;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].LMT_Negative != ((axisIoFlags & (uint)AxisIoFlags.LMT_Negative) != 0))
                {
                    _parsedAxisStates[axisNo].LMT_Negative = !_parsedAxisStates[axisNo].LMT_Negative;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].ORG != ((axisIoFlags & (uint)AxisIoFlags.ORG) != 0))
                {
                    _parsedAxisStates[axisNo].ORG = !_parsedAxisStates[axisNo].ORG;
                    dataChanged = true;
                }

                //bool org = (axisIoFlags & (uint)AxisIoFlags.ORG) != 0;
                //if ((org && !_parsedAxisStates[axisNo].ORG) || (!org && _parsedAxisStates[axisNo].ORG))
                //{
                //    _parsedAxisStates[axisNo].ORG = !_parsedAxisStates[axisNo].ORG;
                //    dataChanged = true;
                //}


                if (_parsedAxisStates[axisNo].DIR != ((axisIoFlags & (uint)AxisIoFlags.DIR) != 0))
                {
                    _parsedAxisStates[axisNo].DIR = !_parsedAxisStates[axisNo].DIR;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].EMG != ((axisIoFlags & (uint)AxisIoFlags.EMG) != 0))
                {
                    _parsedAxisStates[axisNo].EMG = !_parsedAxisStates[axisNo].EMG;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].EZ != ((axisIoFlags & (uint)AxisIoFlags.EZ) != 0))
                {
                    _parsedAxisStates[axisNo].EZ = !_parsedAxisStates[axisNo].EZ;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].LTC != ((axisIoFlags & (uint)AxisIoFlags.LTC) != 0))
                {
                    _parsedAxisStates[axisNo].LTC = !_parsedAxisStates[axisNo].LTC;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].INP != ((axisIoFlags & (uint)AxisIoFlags.INP) != 0))
                {
                    _parsedAxisStates[axisNo].INP = !_parsedAxisStates[axisNo].INP;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].SVON != ((axisIoFlags & (uint)AxisIoFlags.SVON) != 0))
                {
                    _parsedAxisStates[axisNo].SVON = !_parsedAxisStates[axisNo].SVON;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].ALRM != ((axisIoFlags & (uint)AxisIoFlags.ALRM) != 0))
                {
                    _parsedAxisStates[axisNo].ALRM = !_parsedAxisStates[axisNo].ALRM;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].SLMT_Positive != ((axisIoFlags & (uint)AxisIoFlags.SLMT_Positive) != 0))
                {
                    _parsedAxisStates[axisNo].SLMT_Positive = !_parsedAxisStates[axisNo].SLMT_Positive;
                    dataChanged = true;
                }
                if (_parsedAxisStates[axisNo].SLMT_Negative != ((axisIoFlags & (uint)AxisIoFlags.SLMT_Negative) != 0))
                {
                    _parsedAxisStates[axisNo].SLMT_Negative = !_parsedAxisStates[axisNo].SLMT_Negative;
                    dataChanged = true;
                }

                if (dataChanged)
                {
                    AcmStatusUpdated?.Invoke(this, new AcmStatusUpdatedEventArgs(axisNo, _parsedAxisStates[axisNo]));
                }

                // 下一軸 & wait 同原本邏輯
                if (++axisNo >= _axisCount) axisNo = 0;
                try
                {
                    if (token.WaitHandle.WaitOne(20)) break;
                }
                catch (ObjectDisposedException) { break; }
            }
        }

        #endregion Polling Procedures

        /// <summary>
        /// 緊急停止。
        /// </summary>
        /// <remarks></remarks>
        private void EmergencyStop()
        {
            // 只做停機，不寫 log，不更新 UI
        }

        /// <summary>
        /// 
        /// </summary>
        private void StopWhenConditions()
        {

        }
    }
}
