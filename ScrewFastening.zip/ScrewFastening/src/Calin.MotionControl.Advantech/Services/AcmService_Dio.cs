﻿using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.MotionControl.Advantech.Services
{
    public partial class AcmService : IAcmService_Dio
    {
        public void ReadDi()
        {
            byte data = default;
            ErrCode = Motion.mAcm_AxDiGetByte(_axisHandles[0], 0, ref data);
            ErrCode = Motion.mAcm_AxDiGetByte(_axisHandles[0], 1, ref data);
            ErrCode = Motion.mAcm_AxDiGetByte(_axisHandles[0], 2, ref data);
            ErrCode = Motion.mAcm_AxDiGetByte(_axisHandles[0], 3, ref data);
        }
    }
}
