﻿using System;
using System.Collections.Generic;
using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Contracts
{
    /// <summary>
    /// 裝置操作服務介面。
    /// </summary>
    public interface IAcmService_Device
    {
        #region properties

        /// <summary>
        /// 裝置數量。
        /// </summary>
        uint DeviceCount { get; }

        /// <summary>
        /// 可用裝置列表。
        /// </summary>
        List<DeviceInfo> AvailableDevices { get; }

        /// <summary>
        /// 裝置句柄。
        /// </summary>
        IntPtr DeviceHandle { get; }

        /// <summary>
        /// 控制卡是否初始化。
        /// </summary>
        bool IsBoardInit { get; }

        /// <summary>
        /// 伺服是否開啟。
        /// </summary>
        bool IsServoOn { get; }

        /// <summary>
        /// 數位輸入最大通道數。
        /// </summary>
        uint DaqDiMaxChannel { get; }

        /// <summary>
        /// 數位輸出最大通道數。
        /// </summary>
        uint DaqDoMaxChannel { get; }

        #endregion properties

        #region methods

        /// <summary>
        /// 取得已成功載入驅動裝置的裝置編號和名稱列表。
        /// </summary>
        /// <remarks>呼叫完記得檢查 Success 或 !Success 屬性。</remarks>
        /// <returns>可用裝置數量。</returns>
        uint GetAvailableDevs();

        /// <summary>
        /// 關閉控制卡及所含的全部軸。
        /// </summary>
        /// <returns>執行結果是否成功。</returns>
        bool BoardClose();

        /// <summary>
        /// 開啟控制卡及所含的全部軸。
        /// </summary>
        /// <param name="deviceNum"></param>
        /// <returns>執行結果是否成功。</returns>
        bool BoardOpen(uint deviceNum);

        /// <summary>
        /// 開啟所有軸伺服。
        /// </summary>
        /// <returns>執行結果是否成功。</returns>
        bool ServoOn();

        /// <summary>
        /// 關閉所有軸伺服。
        /// </summary>
        /// <returns>執行結果是否成功。</returns>
        bool ServoOff();

        /// <summary>
        /// 載入裝置設定檔。
        /// </summary>
        /// <param name="filePath">裝置設定檔路徑及名稱。</param>
        /// <returns>是否載入成功。</returns>
        bool LoadCfg(string filePath);

        #endregion methods
    }
}
