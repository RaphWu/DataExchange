﻿using System;
using Calin.MotionControl.Advantech.Services;

namespace Calin.MotionControl.Advantech.Contracts
{
    /// <summary>
    /// 控制卡狀態讀取/更新服務介面。
    /// </summary>
    public interface IAcmService_Polling
    {
        /// <summary>
        /// 控制卡狀態更新事件。
        /// </summary>
        event EventHandler<AcmStatusUpdatedEventArgs> AcmStatusUpdated;

        /// <summary>
        /// 停止輪詢程序。
        /// </summary>
        void PollingStop();

        /// <summary>
        /// 啟動輪詢程序。
        /// </summary>
        void PollingStart();
    }
}
