﻿using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Contracts
{
    /// <summary>
    /// 軸操作服務介面。
    /// </summary>
    public interface IAcmService_Axis
    {
        #region Properties

        uint AxisCount { get; }
        bool IsServoOn(int axisNo);

        ParsedAxisState[] AxisStates { get; }

        #endregion Properties

        #region Axis Parameters

        bool GetAxisVelLow(int axisNo, ref double axisVelLow);

        bool SetAxisVelLow(int axisNo, double value);

        bool GetAxisVelHigh(int axisNo, ref double axisVelHigh);

        bool SetAxisVelHigh(int axisNo, double value);

        bool GetAxisAcc(int axisNo, ref double axisAcc);

        bool SetAxisAcc(int axisNo, double value);

        bool GetAxisDec(int axisNo, ref double axisDec);

        bool SetAxisDec(int axisNo, double value);

        bool GetAxisJerk(int axisNo, ref double axisJerk);

        bool SetAxisJerk(int axisNo, double value);

        bool SetCmdPosition(int axisNo, double position);

        bool SetActPosition(int axisNo, double position);

        #endregion Axis Parameters

        #region Methods

        bool ServoOn(int axisNo);

        bool ServoOff(int axisNo);

        bool AxisStop(int axisNo);

        bool AxisStopEmg(int axisNo);

        #endregion Methods

        #region Motion

        bool MoveAbsolute(int axisNo, double position);

        bool MoveRelative(int axisNo, double distance);

        // Home

        bool ApplyHomeParameters(int axisNo);

        bool AxisHome(int axisNo);

        #endregion Motion

        #region Helpers

        string GetHomeModeName(uint homeMode);

        string GetHomeModeDescription(uint homeMode);

        #endregion Helpers

        #region Configs

        bool GetAxisConfigsFile();

        void ApplyAxisSetting(AxisConfig config);

        #endregion Configs

        bool ApplyMoveParameters(int axisNo);

        void ResetError();
    }
}
