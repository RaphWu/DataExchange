﻿using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Contracts
{
    // TODO: 註解重整
    /// <summary>
    /// Acm 錯誤訊息服務介面。
    /// </summary>
    /// <remarks>使用方法：
    /// <pre><code>
    /// 內部函數呼叫 ACM 函數的返回值直接賦值給 ErrCode 屬性，其它屬性即會自動設定。
    /// 1. Success 和 !Success 屬性可用於檢查是否發生錯誤。
    /// 2. ErrMessage 屬性可用於取得錯誤訊息。(Success 時為空字串)
    /// 
    /// 程式庫內使用範例：
    /// ErrCode = mAcm_Function(...);
    /// return CheckErr($"{nameof(AcmService)}.FuncName, "錯誤詳細資訊");
    ///   或
    /// return CheckErr($"{nameof(AcmService)}."錯誤詳細資訊");
    ///   或
    /// if (CheckErr($"{nameof(AcmService)}."錯誤詳細資訊"))
    /// {
    ///     Console.WriteLine($"Error {errManager.ErrCode}: {errManager.ErrMessage}\n{errManager.ErrDetail}");
    /// }
    /// ```
    /// 外部的應用程式可以這樣使用：
    /// 
    /// </code></pre></remarks>
    public interface IAcmService_ErrManager
    {
        #region Properties

        /// <summary>
        /// 呼叫是否成功。
        /// </summary>
        bool Success { get; }

        /// <summary>
        /// 錯誤訊息結構。
        /// </summary>
        AcmResult AcmResult { get; }

        #endregion Properties

        #region Methods

        /// <summary>
        /// 重置軸錯誤狀態。
        /// </summary>
        /// <param name="axisNo">軸編號 (0 ~ AxisCount-1)。</param>
        /// <returns>是否成功重置。</returns>
        bool ResetAxisState(int axisNo);

        #endregion Methods
    }
}
