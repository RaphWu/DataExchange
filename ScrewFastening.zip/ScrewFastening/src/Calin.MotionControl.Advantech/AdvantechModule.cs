﻿using Autofac;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Services;

namespace Calin.MotionControl.Advantech
{
    /// <summary>
    /// ACM 的 AtuoFac 模組。
    /// </summary>
    public class AdvantechModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<AcmService>()
                .As<IAcm>()
                .SingleInstance();

            //builder.RegisterBuildCallback(async c =>
            //{
            //    var core = c.Resolve<ICore>();
            //    await core.Initialize();
            //});
        }
    }
}
