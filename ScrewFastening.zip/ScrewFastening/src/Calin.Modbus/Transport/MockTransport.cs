using System;
using System.Collections.Generic;
using Calin.Logging.Abstractions;
using Calin.Modbus.Enums;
using Calin.Modbus.Protocol;
using Microsoft.Extensions.Logging;

namespace Calin.Modbus.Transport
{
    /// <summary>
    /// MODBUS �����ǿ�h�C
    /// ��@ IModbusTransport�A���� Stateful �� MODBUS Slave �����\��C
    /// </summary>
    /// <remarks>
    /// �����O�Ω�椸���ջP�}�o���q�A�L�ݯu�ꪺ SerialPort �w��C
    /// �䴩�h�ئ欰�Ҧ��H�������P�����~���ҡC
    /// </remarks>
    public class MockTransport : IModbusTransport
    {
        private bool _isOpen;
        private readonly ILogger<MockTransport> _logger;
        private readonly object _lockObject = new object();

        /// <summary>
        /// ���o�O���Ȧs����ơC
        /// Key: ��}, Value: ��
        /// </summary>
        public Dictionary<ushort, ushort> HoldingRegisters { get; } = new Dictionary<ushort, ushort>();

        /// <summary>
        /// ���o�u�骬�A��ơC
        /// Key: ��}, Value: ���A
        /// </summary>
        public Dictionary<ushort, bool> Coils { get; } = new Dictionary<ushort, bool>();

        /// <summary>
        /// ���o��J�Ȧs����ơ]��Ū�^�C
        /// Key: ��}, Value: ��
        /// </summary>
        public Dictionary<ushort, ushort> InputRegisters { get; } = new Dictionary<ushort, ushort>();

        /// <summary>
        /// ���o������J���A�]��Ū�^�C
        /// Key: ��}, Value: ���A
        /// </summary>
        public Dictionary<ushort, bool> DiscreteInputs { get; } = new Dictionary<ushort, bool>();

        /// <summary>
        /// ���o�γ]�w���� Slave ��}�C
        /// </summary>
        public byte SlaveAddress { get; set; } = 1;

        /// <summary>
        /// ���o�γ]�w�欰�Ҧ��C
        /// </summary>
        public MockTransportBehavior Behavior { get; set; } = MockTransportBehavior.Normal;

        /// <summary>
        /// ���o�ǿ�h�O�_�w�}�ҡC
        /// </summary>
        public bool IsOpen => _isOpen;

        /// <summary>
        /// ���o�ǿ����ҬO�_�w�q�L�C
        /// </summary>
        /// <remarks>
        /// MockTransport �û��^�� true�]�������\���ҡ^�C
        /// </remarks>
        public bool IsTransmissionVerified => _isOpen;

        /// <summary>
        /// ���o�γ]�w�q�T�O�ɮɶ��]�@���^�C
        /// </summary>
        public int Timeout { get; set; } = 1000;

        /// <summary>
        /// ���o�̫�o�e���ШD Frame�C
        /// </summary>
        public string LastRequestFrame { get; private set; }

        /// <summary>
        /// ���o�̫�^�Ǫ��^�� Frame�C
        /// </summary>
        public string LastResponseFrame { get; private set; }

        /// <summary>
        /// ���o�ШD���v�O���C
        /// </summary>
        public List<string> RequestHistory { get; } = new List<string>();

        /// <summary>
        /// �إ� MockTransport ��ҡC
        /// </summary>
        public MockTransport()
        {
            _logger = LoggingBridge.CreateLogger<MockTransport>();
        }

        /// <summary>
        /// �}�Ҷǿ�s�u�C
        /// </summary>
        public bool Open()
        {
            _logger.LogDebug("MockTransport �w�}�ҡC");
            _isOpen = true;
            return true;
        }

        /// <summary>
        /// �����ǿ�s�u�C
        /// </summary>
        public void Close()
        {
            _logger.LogDebug("MockTransport �w�����C");
            _isOpen = false;
        }

        /// <summary>
        /// �ǰe MODBUS ASCII Frame �õ��ݦ^���C
        /// </summary>
        /// <param name="requestFrame">���㪺 MODBUS ASCII �ШD Frame�C</param>
        /// <returns>���㪺 MODBUS ASCII �^�� Frame�C</returns>
        public string SendAndReceive(string requestFrame)
        {
            if (!_isOpen)
            {
                _logger.LogError("SendAndReceive failed: transport is not open.");
                throw new InvalidOperationException("Transport is not open.");
            }

            lock (_lockObject)
            {
                LastRequestFrame = requestFrame;
                RequestHistory.Add(requestFrame);

                _logger.LogDebug("MockTransport ����ШD�G{Frame}", requestFrame.TrimEnd('\r', '\n'));

                // �ھڦ欰�Ҧ��B�z
                switch (Behavior)
                {
                    case MockTransportBehavior.Timeout:
                        _logger.LogDebug("MockTransport �����O�ɡC");
                        throw new TimeoutException($"Simulated timeout after {Timeout}ms.");

                    case MockTransportBehavior.LrcError:
                        _logger.LogDebug("MockTransport ���� LRC ���~�C");
                        return BuildLrcErrorResponse(requestFrame);

                    case MockTransportBehavior.IllegalFunction:
                        _logger.LogDebug("MockTransport ���� IllegalFunction ���~�C");
                        return BuildExceptionResponse(requestFrame, ModbusErrorCode.IllegalFunction);

                    case MockTransportBehavior.IllegalAddress:
                        _logger.LogDebug("MockTransport ���� IllegalDataAddress ���~�C");
                        return BuildExceptionResponse(requestFrame, ModbusErrorCode.IllegalDataAddress);

                    case MockTransportBehavior.IllegalDataValue:
                        _logger.LogDebug("MockTransport ���� IllegalDataValue ���~�C");
                        return BuildExceptionResponse(requestFrame, ModbusErrorCode.IllegalDataValue);

                    case MockTransportBehavior.SlaveDeviceFailure:
                        _logger.LogDebug("MockTransport ���� SlaveDeviceFailure ���~�C");
                        return BuildExceptionResponse(requestFrame, ModbusErrorCode.SlaveDeviceFailure);

                    case MockTransportBehavior.Normal:
                    default:
                        return ProcessRequest(requestFrame);
                }
            }
        }

        /// <summary>
        /// �M�ű����w�İϡC
        /// </summary>
        public void ClearBuffer()
        {
            // Mock ���ݭn��ڲM��
        }

        /// <summary>
        /// �]�w�O���Ȧs���ȡC
        /// </summary>
        /// <param name="address">��}�C</param>
        /// <param name="value">�ȡC</param>
        public void SetHoldingRegister(ushort address, ushort value)
        {
            HoldingRegisters[address] = value;
        }

        /// <summary>
        /// �]�w�h�ӫO���Ȧs���ȡC
        /// </summary>
        /// <param name="startAddress">�_�l��}�C</param>
        /// <param name="values">�Ȱ}�C�C</param>
        public void SetHoldingRegisters(ushort startAddress, ushort[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                HoldingRegisters[(ushort)(startAddress + i)] = values[i];
            }
        }

        /// <summary>
        /// �]�w�u�骬�A�C
        /// </summary>
        /// <param name="address">��}�C</param>
        /// <param name="value">���A�C</param>
        public void SetCoil(ushort address, bool value)
        {
            Coils[address] = value;
        }

        /// <summary>
        /// �]�w�h�ӽu�骬�A�C
        /// </summary>
        /// <param name="startAddress">�_�l��}�C</param>
        /// <param name="values">���A�}�C�C</param>
        public void SetCoils(ushort startAddress, bool[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                Coils[(ushort)(startAddress + i)] = values[i];
            }
        }

        /// <summary>
        /// �]�w��J�Ȧs���ȡC
        /// </summary>
        /// <param name="address">��}�C</param>
        /// <param name="value">�ȡC</param>
        public void SetInputRegister(ushort address, ushort value)
        {
            InputRegisters[address] = value;
        }

        /// <summary>
        /// �]�w������J���A�C
        /// </summary>
        /// <param name="address">��}�C</param>
        /// <param name="value">���A�C</param>
        public void SetDiscreteInput(ushort address, bool value)
        {
            DiscreteInputs[address] = value;
        }

        /// <summary>
        /// ���o�O���Ȧs���ȡC
        /// </summary>
        /// <param name="address">��}�C</param>
        /// <returns>�Ȧs���ȡA�p�G���s�b�h�^�� 0�C</returns>
        public ushort GetHoldingRegister(ushort address)
        {
            return HoldingRegisters.TryGetValue(address, out ushort value) ? value : (ushort)0;
        }

        /// <summary>
        /// ���o�u�骬�A�C
        /// </summary>
        /// <param name="address">��}�C</param>
        /// <returns>�u�骬�A�A�p�G���s�b�h�^�� false�C</returns>
        public bool GetCoil(ushort address)
        {
            return Coils.TryGetValue(address, out bool value) && value;
        }

        /// <summary>
        /// ���m�Ҧ���ƻP�]�w�C
        /// </summary>
        public void Reset()
        {
            _logger.LogDebug("MockTransport reset.");
            HoldingRegisters.Clear();
            Coils.Clear();
            InputRegisters.Clear();
            DiscreteInputs.Clear();
            RequestHistory.Clear();
            Behavior = MockTransportBehavior.Normal;
            LastRequestFrame = null;
            LastResponseFrame = null;
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        public void Dispose()
        {
            Close();
        }

        #region Private Methods

        /// <summary>
        /// �B�z�ШD�ò��ͦ^���C
        /// </summary>
        private string ProcessRequest(string requestFrame)
        {
            // ���� Frame �榡
            if (string.IsNullOrEmpty(requestFrame) ||
                requestFrame[0] != ':' ||
                !requestFrame.EndsWith("\r\n"))
            {
                throw new ArgumentException("Invalid MODBUS ASCII frame format.");
            }

            // ���� Hex ���e
            string hexContent = requestFrame.Substring(1, requestFrame.Length - 3);

            // ���� LRC
            if (!LrcCalculator.VerifyFromAsciiHex(hexContent))
            {
                throw new ArgumentException("LRC verification failed in request.");
            }

            // �ѪR�ШD
            byte[] data = AsciiCodec.AsciiHexToBytes(hexContent.Substring(0, hexContent.Length - 2));
            byte slaveAddress = data[0];
            byte functionCode = data[1];

            // �ˬd Slave ��}
            if (slaveAddress != SlaveAddress)
            {
                // ���O�o�� Slave ���ШD�A���^���]�����u��欰�^
                throw new TimeoutException("Slave address mismatch - no response.");
            }

            string response;
            switch ((FunctionCode)functionCode)
            {
                case FunctionCode.ReadCoils:
                    response = HandleReadCoils(slaveAddress, data);
                    break;

                case FunctionCode.ReadDiscreteInputs:
                    response = HandleReadDiscreteInputs(slaveAddress, data);
                    break;

                case FunctionCode.ReadHoldingRegisters:
                    response = HandleReadHoldingRegisters(slaveAddress, data);
                    break;

                case FunctionCode.ReadInputRegisters:
                    response = HandleReadInputRegisters(slaveAddress, data);
                    break;

                case FunctionCode.WriteSingleCoil:
                    response = HandleWriteSingleCoil(slaveAddress, data);
                    break;

                case FunctionCode.WriteSingleRegister:
                    response = HandleWriteSingleRegister(slaveAddress, data);
                    break;

                default:
                    response = BuildExceptionResponse(requestFrame, ModbusErrorCode.IllegalFunction);
                    break;
            }

            LastResponseFrame = response;
            _logger.LogDebug("MockTransport sending response: {Frame}", response.TrimEnd('\r', '\n'));
            return response;
        }

        /// <summary>
        /// �B�zŪ���u��ШD (FC 01)�C
        /// </summary>
        private string HandleReadCoils(byte slaveAddress, byte[] data)
        {
            ushort startAddress = (ushort)((data[2] << 8) | data[3]);
            ushort quantity = (ushort)((data[4] << 8) | data[5]);

            int byteCount = (quantity + 7) / 8;
            byte[] responseData = new byte[byteCount];

            for (int i = 0; i < quantity; i++)
            {
                ushort address = (ushort)(startAddress + i);
                if (Coils.TryGetValue(address, out bool value) && value)
                {
                    int byteIndex = i / 8;
                    int bitIndex = i % 8;
                    responseData[byteIndex] |= (byte)(1 << bitIndex);
                }
            }

            return BuildReadResponse(slaveAddress, (byte)FunctionCode.ReadCoils, responseData);
        }

        /// <summary>
        /// �B�zŪ��������J�ШD (FC 02)�C
        /// </summary>
        private string HandleReadDiscreteInputs(byte slaveAddress, byte[] data)
        {
            ushort startAddress = (ushort)((data[2] << 8) | data[3]);
            ushort quantity = (ushort)((data[4] << 8) | data[5]);

            int byteCount = (quantity + 7) / 8;
            byte[] responseData = new byte[byteCount];

            for (int i = 0; i < quantity; i++)
            {
                ushort address = (ushort)(startAddress + i);
                if (DiscreteInputs.TryGetValue(address, out bool value) && value)
                {
                    int byteIndex = i / 8;
                    int bitIndex = i % 8;
                    responseData[byteIndex] |= (byte)(1 << bitIndex);
                }
            }

            return BuildReadResponse(slaveAddress, (byte)FunctionCode.ReadDiscreteInputs, responseData);
        }

        /// <summary>
        /// �B�zŪ���O���Ȧs���ШD (FC 03)�C
        /// </summary>
        private string HandleReadHoldingRegisters(byte slaveAddress, byte[] data)
        {
            ushort startAddress = (ushort)((data[2] << 8) | data[3]);
            ushort quantity = (ushort)((data[4] << 8) | data[5]);

            byte[] responseData = new byte[quantity * 2];

            for (int i = 0; i < quantity; i++)
            {
                ushort address = (ushort)(startAddress + i);
                ushort value = GetHoldingRegister(address);
                responseData[i * 2] = (byte)(value >> 8);
                responseData[i * 2 + 1] = (byte)(value & 0xFF);
            }

            return BuildReadResponse(slaveAddress, (byte)FunctionCode.ReadHoldingRegisters, responseData);
        }

        /// <summary>
        /// �B�zŪ����J�Ȧs���ШD (FC 04)�C
        /// </summary>
        private string HandleReadInputRegisters(byte slaveAddress, byte[] data)
        {
            ushort startAddress = (ushort)((data[2] << 8) | data[3]);
            ushort quantity = (ushort)((data[4] << 8) | data[5]);

            byte[] responseData = new byte[quantity * 2];

            for (int i = 0; i < quantity; i++)
            {
                ushort address = (ushort)(startAddress + i);
                ushort value = InputRegisters.TryGetValue(address, out ushort v) ? v : (ushort)0;
                responseData[i * 2] = (byte)(value >> 8);
                responseData[i * 2 + 1] = (byte)(value & 0xFF);
            }

            return BuildReadResponse(slaveAddress, (byte)FunctionCode.ReadInputRegisters, responseData);
        }

        /// <summary>
        /// �B�z�g�J��@�u��ШD (FC 05)�C
        /// </summary>
        private string HandleWriteSingleCoil(byte slaveAddress, byte[] data)
        {
            ushort address = (ushort)((data[2] << 8) | data[3]);
            ushort value = (ushort)((data[4] << 8) | data[5]);

            bool coilValue = value == 0xFF00;
            Coils[address] = coilValue;

            // Echo response
            return BuildEchoResponse(slaveAddress, (byte)FunctionCode.WriteSingleCoil, data);
        }

        /// <summary>
        /// �B�z�g�J��@�Ȧs���ШD (FC 06)�C
        /// </summary>
        private string HandleWriteSingleRegister(byte slaveAddress, byte[] data)
        {
            ushort address = (ushort)((data[2] << 8) | data[3]);
            ushort value = (ushort)((data[4] << 8) | data[5]);

            HoldingRegisters[address] = value;

            // Echo response
            return BuildEchoResponse(slaveAddress, (byte)FunctionCode.WriteSingleRegister, data);
        }

        /// <summary>
        /// �إ�Ū���^�� Frame�C
        /// </summary>
        private string BuildReadResponse(byte slaveAddress, byte functionCode, byte[] data)
        {
            var allBytes = new List<byte>
            {
                slaveAddress,
                functionCode,
                (byte)data.Length
            };
            allBytes.AddRange(data);

            byte[] messageBytes = allBytes.ToArray();
            byte lrc = LrcCalculator.Calculate(messageBytes);

            string hexMessage = AsciiCodec.BytesToAsciiHex(messageBytes);
            string hexLrc = AsciiCodec.ByteToAsciiHex(lrc);

            return $":{hexMessage}{hexLrc}\r\n";
        }

        /// <summary>
        /// �إ� Echo �^�� Frame�C
        /// </summary>
        private string BuildEchoResponse(byte slaveAddress, byte functionCode, byte[] originalData)
        {
            var allBytes = new List<byte>
            {
                slaveAddress,
                functionCode
            };
            // �[�J��}�M�ȡ]4 bytes�^
            for (int i = 2; i < 6 && i < originalData.Length; i++)
            {
                allBytes.Add(originalData[i]);
            }

            byte[] messageBytes = allBytes.ToArray();
            byte lrc = LrcCalculator.Calculate(messageBytes);

            string hexMessage = AsciiCodec.BytesToAsciiHex(messageBytes);
            string hexLrc = AsciiCodec.ByteToAsciiHex(lrc);

            return $":{hexMessage}{hexLrc}\r\n";
        }

        /// <summary>
        /// �إ� Exception Response Frame�C
        /// </summary>
        private string BuildExceptionResponse(string requestFrame, ModbusErrorCode errorCode)
        {
            // �q�ШD�����o Slave Address �M Function Code
            string hexContent = requestFrame.Substring(1, requestFrame.Length - 3);
            byte[] data = AsciiCodec.AsciiHexToBytes(hexContent.Substring(0, 4));
            byte slaveAddress = data[0];
            byte functionCode = (byte)(data[1] | 0x80); // �]�w�̰���

            byte[] messageBytes = { slaveAddress, functionCode, (byte)errorCode };
            byte lrc = LrcCalculator.Calculate(messageBytes);

            string hexMessage = AsciiCodec.BytesToAsciiHex(messageBytes);
            string hexLrc = AsciiCodec.ByteToAsciiHex(lrc);

            LastResponseFrame = $":{hexMessage}{hexLrc}\r\n";
            return LastResponseFrame;
        }

        /// <summary>
        /// �إߧt�����~ LRC ���^�� Frame�C
        /// </summary>
        private string BuildLrcErrorResponse(string requestFrame)
        {
            // �q�ШD�����o��T�ëإߥ��`�^��
            string hexContent = requestFrame.Substring(1, requestFrame.Length - 3);
            byte[] data = AsciiCodec.AsciiHexToBytes(hexContent.Substring(0, 4));
            byte slaveAddress = data[0];
            byte functionCode = data[1];

            // �إ�²�檺�^�����e
            byte[] messageBytes = { slaveAddress, functionCode, 0x02, 0x00, 0x00 };
            byte lrc = LrcCalculator.Calculate(messageBytes);

            // �G�N�ϥο��~�� LRC
            byte wrongLrc = (byte)(lrc ^ 0xFF);

            string hexMessage = AsciiCodec.BytesToAsciiHex(messageBytes);
            string hexLrc = AsciiCodec.ByteToAsciiHex(wrongLrc);

            LastResponseFrame = $":{hexMessage}{hexLrc}\r\n";
            return LastResponseFrame;
        }

        #endregion
    }
}
