using System;
using Calin.Logging.Abstractions;
using Calin.Modbus.Enums;
using Calin.Modbus.Exceptions;
using Calin.Modbus.Models;
using Calin.Modbus.Protocol;
using Calin.Modbus.Transport;
using Microsoft.Extensions.Logging;

namespace Calin.Modbus.Core
{
    /// <summary>
    /// MODBUS �Ȥ�ݹ�@�C
    /// �զX Request�BProtocol�BTransport�A���� MODBUS �q�T�\��C
    /// </summary>
    public class ModbusClient : IModbus, IDisposable
    {
        private readonly IModbusTransport _transport;
        private readonly ILogger<ModbusClient> _logger;
        private bool _disposed;
        private readonly object _lockObject = new object();

        /// <summary>
        /// ���o�γ]�w�q�T�O�ɮɶ��]�@���^�C
        /// </summary>
        public int Timeout
        {
            get => _transport.Timeout;
            set => _transport.Timeout = value;
        }

        /// <summary>
        /// ���o�γ]�w���զ��ơC
        /// </summary>
        public int RetryCount { get; set; } = 3;

        /// <summary>
        /// ���o�γ]�w���ն��j�]�@���^�C
        /// </summary>
        public int RetryDelay { get; set; } = 100;

        /// <summary>
        /// ���o�O�_�w�s�u�C
        /// </summary>
        public bool IsConnected => _transport?.IsOpen ?? false;

        /// <summary>
        /// ���o�ǿ����ҬO�_�w�q�L�C
        /// </summary>
        public bool IsTransmissionVerified => _transport?.IsTransmissionVerified ?? false;

        /// <summary>
        /// �إ� ModbusClient ��ҡC
        /// </summary>
        /// <param name="transport">MODBUS �ǿ�h�C</param>
        /// <exception cref="ArgumentNullException">�� transport �� null �ɩߥX�C</exception>
        public ModbusClient(IModbusTransport transport)
        {
            _transport = transport ?? throw new ArgumentNullException(nameof(transport));
            _logger = LoggingBridge.CreateLogger<ModbusClient>();
        }

        /// <summary>
        /// �}�ҳs�u�C
        /// </summary>
        public bool Connect()
        {
            _logger.LogInformation("�s�u�� MODBUS �]��...");
            var result = _transport.Open();
            if (result)
            {
                _logger.LogInformation("MODBUS �s�u�w�إߡC");
            }
            else
            {
                _logger.LogWarning("�L�k�إ� MODBUS �s�u�C");
            }
            return result;
        }

        /// <summary>
        /// ���_�s�u�C
        /// </summary>
        public void Disconnect()
        {
            _logger.LogInformation("�P MODBUS �]�Ƥ��_�s�u...");
            _transport.Close();
        }

        /// <summary>
        /// Ū���O���Ȧs�� (Function Code 03)�C
        /// </summary>
        public ModbusResponse ReadHoldingRegisters(byte slaveAddress, ushort startAddress, ushort quantity)
        {
            var request = ModbusRequest.CreateReadHoldingRegisters(slaveAddress, startAddress, quantity);
            return Execute(request);
        }

        /// <summary>
        /// Ū����J�Ȧs�� (Function Code 04)�C
        /// </summary>
        public ModbusResponse ReadInputRegisters(byte slaveAddress, ushort startAddress, ushort quantity)
        {
            var request = new ModbusRequest
            {
                SlaveAddress = slaveAddress,
                FunctionCode = FunctionCode.ReadInputRegisters,
                StartAddress = startAddress,
                Quantity = quantity
            };
            return Execute(request);
        }

        /// <summary>
        /// Ū���u�� (Function Code 01)�C
        /// </summary>
        public ModbusResponse ReadCoils(byte slaveAddress, ushort startAddress, ushort quantity)
        {
            var request = ModbusRequest.CreateReadCoils(slaveAddress, startAddress, quantity);
            return Execute(request);
        }

        /// <summary>
        /// Ū��������J (Function Code 02)�C
        /// </summary>
        public ModbusResponse ReadDiscreteInputs(byte slaveAddress, ushort startAddress, ushort quantity)
        {
            var request = new ModbusRequest
            {
                SlaveAddress = slaveAddress,
                FunctionCode = FunctionCode.ReadDiscreteInputs,
                StartAddress = startAddress,
                Quantity = quantity
            };
            return Execute(request);
        }

        /// <summary>
        /// �g�J��@�Ȧs�� (Function Code 06)�C
        /// </summary>
        public ModbusResponse WriteSingleRegister(byte slaveAddress, ushort address, ushort value)
        {
            var request = ModbusRequest.CreateWriteSingleRegister(slaveAddress, address, value);
            return Execute(request);
        }

        /// <summary>
        /// �g�J��@�u�� (Function Code 05)�C
        /// </summary>
        public ModbusResponse WriteSingleCoil(byte slaveAddress, ushort address, bool value)
        {
            var request = ModbusRequest.CreateWriteSingleCoil(slaveAddress, address, value);
            return Execute(request);
        }

        /// <summary>
        /// ���� MODBUS �ШD�C
        /// </summary>
        public ModbusResponse Execute(ModbusRequest request)
        {
            if (request == null)
            {
                _logger.LogError("���楢�ѡGrequest �� null�C");
                throw new ArgumentNullException(nameof(request));
            }

            if (!IsConnected)
            {
                _logger.LogError("���楢�ѡG�|���s�u�C");
                throw new InvalidOperationException("Not connected. Call Connect() first.");
            }

            // �ˬd�ǿ����Ҫ����A
            if (!IsTransmissionVerified)
            {
                _logger.LogError("���楢�ѡG�ǿ����ҥ��q�L�C");
                throw new InvalidOperationException("Transmission verification failed. Please check serial port parameters.");
            }

            _logger.LogDebug("���� MODBUS �ШD�GSlaveAddress={SlaveAddress}, FunctionCode={FunctionCode}, StartAddress={StartAddress}",
                request.SlaveAddress, request.FunctionCode, request.StartAddress);

            lock (_lockObject)
            {
                Exception lastException = null;

                for (int attempt = 0; attempt <= RetryCount; attempt++)
                {
                    try
                    {
                        // �إ߽ШD Frame
                        string requestFrame = ModbusAsciiFrame.BuildRequestFrame(request);

                        // �ǰe�õ��ݦ^��
                        string responseFrame = _transport.SendAndReceive(requestFrame);

                        // �ѪR�^��
                        var response = ModbusAsciiFrame.ParseResponseFrame(
                            responseFrame,
                            request.SlaveAddress,
                            request.FunctionCode);

                        // �ˬd�O�_�� Exception Response
                        if (response.IsException)
                        {
                            _logger.LogWarning("���� MODBUS �ҥ~�^���GErrorCode={ErrorCode}", response.ErrorCode);
                            throw ModbusException.FromErrorCode(response.ErrorCode);
                        }

                        _logger.LogDebug("MODBUS �ШD���榨�\�C");
                        return response;
                    }
                    catch (TimeoutException)
                    {
                        _logger.LogWarning("MODBUS �O�ɡG���� {Attempt}/{RetryCount}", attempt + 1, RetryCount + 1);
                        lastException = new ModbusTimeoutException(Timeout, attempt);
                        if (attempt < RetryCount)
                        {
                            System.Threading.Thread.Sleep(RetryDelay);
                        }
                    }
                    catch (ModbusException)
                    {
                        // MODBUS Exception ���ݭn����
                        throw;
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "MODBUS �q�T���~�G���� {Attempt}/{RetryCount}�G{Message}",
                            attempt + 1, RetryCount + 1, ex.Message);
                        lastException = new ModbusException($"Communication error: {ex.Message}", ex);
                        if (attempt < RetryCount)
                        {
                            System.Threading.Thread.Sleep(RetryDelay);
                        }
                    }
                }

                // �ߥX�̫᪺�ҥ~
                if (lastException is ModbusException modbusEx)
                {
                    throw modbusEx;
                }
                throw new ModbusTimeoutException(Timeout, RetryCount);
            }
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _logger.LogDebug("���� ModbusClient...");
                    _transport?.Dispose();
                }
                _disposed = true;
            }
        }

        /// <summary>
        /// �Ѻc�禡�C
        /// </summary>
        ~ModbusClient()
        {
            Dispose(false);
        }
    }
}
