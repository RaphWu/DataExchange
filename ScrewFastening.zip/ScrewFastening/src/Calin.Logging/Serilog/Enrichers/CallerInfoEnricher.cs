// ===================================================================
// Calin.Logging.Serilog
// 
// CallerInfoEnricher - �[�J�I�s�̸�T�� Enricher
// ===================================================================

using System;
using System.Diagnostics;
using System.IO;
using Serilog.Core;
using Serilog.Events;

namespace Calin.Logging.Serilog.Enrichers
{
    /// <summary>
    /// �[�J�I�s�̸�T�� Enricher�]FileName�BLineNumber�BMethodName�^�C
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>�`�N�G�� Enricher �|���į�v�T�A�ȫ�ĳ�b Debug ���ҨϥΡC</b>
    /// </para>
    /// <para>
    /// <b>�����O�u���b App �ϥΡCDevice NuGet ���i�ϥΡC</b>
    /// </para>
    /// </remarks>
    public sealed class CallerInfoEnricher : ILogEventEnricher
    {
        /// <inheritdoc />
        public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
        {
            var stackTrace = new StackTrace(true);
            var frames = stackTrace.GetFrames();

            if (frames == null) return;

            // ���L Serilog ���� frames
            foreach (var frame in frames)
            {
                var method = frame.GetMethod();
                if (method == null) continue;

                var declaringType = method.DeclaringType;
                if (declaringType == null) continue;

                var ns = declaringType.Namespace ?? string.Empty;

                // ���L Serilog ���� namespace
                if (ns.StartsWith("Serilog", StringComparison.Ordinal) ||
                    ns.StartsWith("Microsoft.Extensions.Logging", StringComparison.Ordinal) ||
                    ns.StartsWith("Calin.Logging.Serilog", StringComparison.Ordinal) ||
                    ns.StartsWith("Calin.Logging.Abstractions", StringComparison.Ordinal))
                {
                    continue;
                }

                var fileName = frame.GetFileName();
                var lineNumber = frame.GetFileLineNumber();
                var methodName = method.Name;

                if (!string.IsNullOrEmpty(fileName))
                {
                    logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("CallerFileName", Path.GetFileName(fileName)));
                }

                if (lineNumber > 0)
                {
                    logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("CallerLineNumber", lineNumber));
                }

                if (!string.IsNullOrEmpty(methodName))
                {
                    logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("CallerMethodName", methodName));
                }

                break;
            }
        }
    }
}
