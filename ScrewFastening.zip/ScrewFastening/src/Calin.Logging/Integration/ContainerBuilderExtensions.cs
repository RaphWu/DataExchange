// ===================================================================
// Calin.Logging.Integration
// 
// ContainerBuilderExtensions - Autofac ContainerBuilder �X�R��k
// ===================================================================

using Autofac;
using Microsoft.Extensions.Logging;

namespace Calin.Logging.Integration
{
    /// <summary>
    /// ContainerBuilder �X�R��k�C
    /// </summary>
    /// <remarks>
    /// <b>�����O�u���b App �ϥΡCDevice NuGet ���i�ϥΡC</b>
    /// </remarks>
    public static class ContainerBuilderExtensions
    {
        /// <summary>
        /// ���U Logging �A�ȡ]�ϥΫ��w�� LoggerFactory�^�C
        /// </summary>
        /// <param name="builder">ContainerBuilder�C</param>
        /// <param name="loggerFactory">LoggerFactory ��ҡC</param>
        /// <returns>ContainerBuilder�C</returns>
        public static ContainerBuilder RegisterLogging(
            this ContainerBuilder builder,
            ILoggerFactory loggerFactory)
        {
            builder.RegisterModule(new LoggingModule(loggerFactory));
            return builder;
        }

        /// <summary>
        /// ���U Logging �A�ȡ]�۰ʱq LoggingBridge ���o�^�C
        /// </summary>
        /// <param name="builder">ContainerBuilder�C</param>
        /// <returns>ContainerBuilder�C</returns>
        /// <remarks>
        /// �ϥΦ���k�ɡA�ݽT�O LoggingBridge �w�g��l�ơC
        /// </remarks>
        public static ContainerBuilder RegisterLogging(this ContainerBuilder builder)
        {
            builder.RegisterModule(new LoggingModule());
            return builder;
        }
    }
}
