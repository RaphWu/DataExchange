﻿namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// Keyence DL-RS1A GT2 系列指令介面。
    /// </summary>
    public interface IDL_RS1A_GT2_Commands
    {
        /// <summary>
        /// 讀取所有值指令。
        /// </summary>
        /// <returns>是否傳送成功。</returns>
        bool ReadValue();

        /// <summary>
        /// 讀取原始值指令。
        /// </summary>
        /// <param name="id">ID編號。</param>
        /// <returns>是否傳送成功。</returns>
        bool ReadRaw(int id);

        //void SendCommand(string command);
    }
}
