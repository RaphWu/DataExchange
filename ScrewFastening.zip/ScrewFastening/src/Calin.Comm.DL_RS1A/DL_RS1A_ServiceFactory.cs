using System;
using Calin.Logging.Abstractions;
using Calin.SerialPort;
using Microsoft.Extensions.Logging;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// DL-RS1A �A�Ȥu�t��@�C
    /// �t�d�إ� DL-RS1A ��ҡC
    /// </summary>
    /// <remarks>
    /// �����O�� Singleton�A�i�Q Autofac ���U�� SingleInstance�C
    /// �u�t�������������� DL-RS1A ��Ҫ��ѦҡC
    /// </remarks>
    public class DL_RS1A_ServiceFactory : IDL_RS1A_ServiceFactory
    {
        private readonly ISerialPortServiceFactory _serialPortServiceFactory;
        private readonly ILogger<DL_RS1A_ServiceFactory> _logger;

        /// <summary>
        /// �إ� DL_RS1A_ServiceFactory ��ҡC
        /// </summary>
        /// <param name="serialPortServiceFactory">SerialPort �A�Ȥu�t�C</param>
        /// <exception cref="ArgumentNullException">�� serialPortServiceFactory �� null �ɩߥX�C</exception>
        public DL_RS1A_ServiceFactory(ISerialPortServiceFactory serialPortServiceFactory)
        {
            _serialPortServiceFactory = serialPortServiceFactory ?? throw new ArgumentNullException(nameof(serialPortServiceFactory));
            _logger = LoggingBridge.CreateLogger<DL_RS1A_ServiceFactory>();
        }

        /// <inheritdoc />
        public IDL_RS1A Create(DL_RS1A_Config dlrs1aConfig)
        {
            if (dlrs1aConfig == null)
            {
                _logger.LogError("�إߥ��ѡGdlrs1aConfig �� null�C");
                throw new ArgumentNullException(nameof(dlrs1aConfig));
            }

            _logger.LogInformation("�إ� DL-RS1A �A�ȡAPortName: {PortName}, SensorType: {SensorType}",
                dlrs1aConfig.PortName, dlrs1aConfig.SensorType);

            var serialPortConfig = new SerialPortConfig
            {
                PortName = dlrs1aConfig.PortName,
                BaudRate = dlrs1aConfig.BaudRate,
                DataBits = dlrs1aConfig.DataBits,
                Parity = dlrs1aConfig.Parity,
                StopBits = dlrs1aConfig.StopBits,
                ReadTimeout = dlrs1aConfig.ReadTimeout,
                WriteTimeout = dlrs1aConfig.WriteTimeout,
                EnableAsciiLineMode = true,
                AsciiLineTerminator = "\r\n",
                EnableAutoReconnect = true,
                EnableHeartbeat = false,
            };

            var serialPortService = _serialPortServiceFactory.Create(serialPortConfig);

            return new DL_RS1A_Service(dlrs1aConfig, serialPortService);
        }

        /// <inheritdoc />
        public IDL_RS1A CreateAndOpen(DL_RS1A_Config dlrs1aConfig)
        {
            var dlrs1a = Create(dlrs1aConfig);

            try
            {
                _logger.LogInformation("���ն}�� DL-RS1A �s�u�APortName: {PortName}", dlrs1aConfig.PortName);

                if (!dlrs1a.Open())
                {
                    _logger.LogError("�L�k�}�� DL-RS1A �s�u�APortName: {PortName}", dlrs1aConfig.PortName);
                    dlrs1a.Dispose();
                    return null;
                }

                _logger.LogInformation("���\�}�� DL-RS1A �s�u�APortName: {PortName}", dlrs1aConfig.PortName);
                return dlrs1a;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "�}�� DL-RS1A �s�u�ɵo�Ϳ��~�APortName: {PortName}", dlrs1aConfig.PortName);
                dlrs1a.Dispose();
                return null;
            }
        }
    }
}
