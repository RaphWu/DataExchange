﻿namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// Keyence DL_RS1A 支援的感測器類型。
    /// </summary>
    public enum KeyenceSensorType
    {
        None,
        IL,
        IB,
        IG,
        GT,
        GT2,
    }
}
