namespace Calin.ScrewFastening.ProcessFlow.Templates
{
    /// <summary>
    /// �u���ѧO�X�`�ơC
    /// </summary>
    public static class ProcessIds
    {
        public const string Z_AXIS_MOVE = "Z_AXIS_MOVE";
        public const string R_AXIS_MOVE = "R_AXIS_MOVE";
        public const string DUAL_AXIS_MOVE = "DUAL_AXIS_MOVE";

        public const string GATE_MARK_SEARCH = "GATE_MARK_SEARCH";
        public const string GATE_MARK_CYLINDER= "GATE_MARK_CYLINDER";

        public const string HEIGHT_DISPLACEMENT = "HEIGHT_DISPLACEMENT";

        public const string SYSTEM_HOMEING = "SYSTEM_HOMEING";
        public const string DELAY = "DELAY";
    }
}
