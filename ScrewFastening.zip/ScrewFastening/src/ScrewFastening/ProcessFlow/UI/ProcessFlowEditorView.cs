using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.ScrewFastening.Constants;
using Calin.ScrewFastening.ProcessFlow.Core;
using Calin.ScrewFastening.ProcessFlow.Editor;
using Calin.ScrewFastening.ProcessFlow.Registry;
using Calin.ScrewFastening.ProcessFlow.Templates;

namespace Calin.ScrewFastening.ProcessFlow.UI
{
    public partial class ProcessFlowEditorView : UserControl
    {
        private ILifetimeScope _scope;
        private IProcessRegistry _registry;

        // ���
        private List<ProcessStepEntity> _processSteps = new List<ProcessStepEntity>();
        private IProcessEditor _currentEditor;
        private ProcessStepEntity _selectedStep;
        private bool _isLoading;

        /// <summary>
        /// �y�{�ܧ�ƥ�C
        /// </summary>
        public event EventHandler FlowChanged;

        /// <summary>
        /// Designer �Ϋغc�l�]���`�J�̿�^�C
        /// </summary>
        public ProcessFlowEditorView()
        {
            InitializeComponent();

            if (!DesignMode)
            {
                InitializeGridColumns();
                ApplyStyles();
                UpdateButtonStates();
            }
        }

        public ProcessFlowEditorView(ILifetimeScope scope, IProcessRegistry registry) : this()
        {
            SetDependencies(scope, registry);
        }

        /// <summary>
        /// �ѥ~���`�J�̿�]�b designer ��l�ƫ�^�C
        /// </summary>
        public void SetDependencies(ILifetimeScope scope, IProcessRegistry registry)
        {
            _scope = scope ?? throw new ArgumentNullException(nameof(scope));
            _registry = registry ?? throw new ArgumentNullException(nameof(registry));

            if (!DesignMode)
            {
                LoadProcessSource();
                RefreshProcessList();
                UpdateButtonStates();
            }
        }

        /// <summary>
        /// ���o�ثe�y�{�B�J�C
        /// </summary>
        public IReadOnlyList<ProcessStepEntity> GetSteps() => _processSteps.AsReadOnly();

        /// <summary>
        /// ���J�y�{�B�J�C
        /// </summary>
        public void LoadSteps(IEnumerable<ProcessStepEntity> steps)
        {
            _processSteps = steps?.Select(s => s.Clone()).ToList() ?? new List<ProcessStepEntity>();
            RefreshProcessList();
        }

        /// <summary>
        /// �M���y�{�C
        /// </summary>
        public void ClearSteps()
        {
            _processSteps.Clear();
            RefreshProcessList();
            ClearEditor();
        }

        private void ApplyStyles()
        {
            // ���O�d�쥻�� CommonStyle �]�w�A���令�w�� designer �ئn��������]�w
            _lblSourceTitle.Font = CommonStyle.TextFontBold;
            _lblSourceTitle.BackColor = CommonStyle.BgHeader;
            _lblSourceTitle.ForeColor = CommonStyle.FgHeader;
            _lblSourceTitle.Padding = new Padding(5, 0, 0, 0);

            _lblListTitle.Font = CommonStyle.TextFontBold;
            _lblListTitle.BackColor = CommonStyle.BgHeader;
            _lblListTitle.ForeColor = CommonStyle.FgHeader;
            _lblListTitle.Padding = new Padding(5, 0, 0, 0);

            _lblEditorTitle.Font = CommonStyle.TextFontBold;
            _lblEditorTitle.BackColor = CommonStyle.BgHeader;
            _lblEditorTitle.ForeColor = CommonStyle.FgHeader;
            _lblEditorTitle.Padding = new Padding(5, 0, 0, 0);

            dgvProcessList.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dgvProcessList.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvProcessList.AutoGenerateColumns = false;
            dgvProcessList.ReadOnly = false;
            dgvProcessList.DefaultCellStyle.SelectionBackColor = Color.SteelBlue;
            dgvProcessList.DefaultCellStyle.SelectionForeColor = Color.White;
        }

        private void InitializeGridColumns()
        {
            // Designer �ɤ��@�w�|�t�m Column�F�o�̥H�{���X�ɻ��A���M�O���i�Q UI �s�边�վ�䥦�ݩ�
            if (dgvProcessList.Columns.Count > 0) return;

            dgvProcessList.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "OrderNo",
                HeaderText = "#",
                DataPropertyName = "OrderNo",
                Width = 40,
                ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                },
            });

            dgvProcessList.Columns.Add(new DataGridViewCheckBoxColumn
            {
                Name = "Enabled",
                HeaderText = "�ҥ�",
                DataPropertyName = "Enabled",
                Width = 50
            });

            dgvProcessList.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ProcessId",
                HeaderText = "�u��",
                DataPropertyName = "ProcessId",
                Width = 100,
                ReadOnly = true
            });

            dgvProcessList.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Summary",
                HeaderText = "�K�n",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                ReadOnly = true
            });
        }

        private void LoadProcessSource()
        {
            if (_registry == null) return;

            var descriptors = _registry.GetAll();
            ProcessDescriptor desc;

            tvProcessSource.BeginUpdate();
            try
            {
                tvProcessSource.Nodes.Clear();
                TreeNode categoryNode;
                TreeNode node;

                // ����: Z
                categoryNode = new TreeNode("�b����") { Tag = null };

                desc = _registry.GetById(ProcessIds.Z_AXIS_MOVE);
                node = new TreeNode(desc.DisplayName) { Tag = desc };
                categoryNode.Nodes.Add(node);

                desc = _registry.GetById(ProcessIds.R_AXIS_MOVE);
                node = new TreeNode(desc.DisplayName) { Tag = desc };
                categoryNode.Nodes.Add(node);

                desc = _registry.GetById(ProcessIds.DUAL_AXIS_MOVE);
                node = new TreeNode(desc.DisplayName) { Tag = desc };
                categoryNode.Nodes.Add(node);

                tvProcessSource.Nodes.Add(categoryNode);
                categoryNode.Expand();

                // �����G�M��
                categoryNode = new TreeNode("�M��") { Tag = null };

                desc = _registry.GetById(ProcessIds.GATE_MARK_SEARCH);
                node = new TreeNode(desc.DisplayName) { Tag = desc };
                categoryNode.Nodes.Add(node);

                desc = _registry.GetById(ProcessIds.GATE_MARK_CYLINDER);
                node = new TreeNode(desc.DisplayName) { Tag = desc };
                categoryNode.Nodes.Add(node);

                tvProcessSource.Nodes.Add(categoryNode);
                categoryNode.Expand();

                // �����G��I
                categoryNode = new TreeNode("��I") { Tag = null };

                node = new TreeNode("��I") { Tag = null };
                categoryNode.Nodes.Add(node);

                tvProcessSource.Nodes.Add(categoryNode);
                categoryNode.Expand();

                // ����: ��L
                categoryNode = new TreeNode("��L") { Tag = null };

                desc = _registry.GetById(ProcessIds.DELAY);
                node = new TreeNode(desc.DisplayName) { Tag = desc };
                categoryNode.Nodes.Add(node);

                tvProcessSource.Nodes.Add(categoryNode);
                categoryNode.Expand();

                UpdateButtonStates();
            }
            finally
            {
                tvProcessSource.EndUpdate();
            }
        }

        private void RefreshProcessList()
        {
            _isLoading = true;
            try
            {
                dgvProcessList.Rows.Clear();

                foreach (var step in _processSteps)
                {
                    var rowIndex = dgvProcessList.Rows.Add();
                    var row = dgvProcessList.Rows[rowIndex];
                    row.Tag = step;
                    row.Cells["OrderNo"].Value = step.OrderNo;
                    row.Cells["Enabled"].Value = step.Enabled;
                    row.Cells["ProcessId"].Value = GetDisplayName(step.ProcessId);
                    row.Cells["Summary"].Value = GetParamSummary(step);
                }

                UpdateButtonStates();
            }
            finally
            {
                _isLoading = false;
            }
        }

        private string GetDisplayName(string processId)
        {
            var desc = _registry?.GetById(processId);
            return desc?.DisplayName ?? processId;
        }

        private string GetParamSummary(ProcessStepEntity step)
        {
            if (string.IsNullOrEmpty(step.ParamJson))
                return string.Empty;

            var desc = _registry?.GetById(step.ProcessId);
            if (desc?.SummaryFormatter != null)
            {
                try
                {
                    return desc.SummaryFormatter(step.ParamJson) ?? string.Empty;
                }
                catch
                {
                    // ignore
                }
            }

            var summary = step.ParamJson.Replace("{", "").Replace("}", "").Replace("\"", "");
            return summary.Length > 50 ? summary.Substring(0, 47) + "..." : summary;
        }

        private void RecalculateOrderNo()
        {
            for (int i = 0; i < _processSteps.Count; i++)
            {
                _processSteps[i].OrderNo = i + 1;
            }
        }

        private ProcessDescriptor GetSelectedProcessDescriptor()
        {
            var node = tvProcessSource?.SelectedNode;
            return node?.Tag as ProcessDescriptor;
        }

        private void UpdateButtonStates()
        {
            var hasSelection = dgvProcessList.SelectedRows.Count > 0;
            var selectedIndex = hasSelection ? dgvProcessList.SelectedRows[0].Index : -1;

            _btnRemove.Enabled = hasSelection;
            _btnMoveUp.Enabled = hasSelection && selectedIndex > 0;
            _btnMoveDown.Enabled = hasSelection && selectedIndex < _processSteps.Count - 1;

            _btnAdd.Enabled = GetSelectedProcessDescriptor() != null;
        }

        // Event Handlers

        private void TvProcessSource_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node?.Tag is ProcessDescriptor)
                AddSelectedProcess();
        }

        private void TvProcessSource_AfterSelect(object sender, TreeViewEventArgs e)
        {
            UpdateButtonStates();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            AddSelectedProcess();
        }

        private void AddSelectedProcess()
        {
            if (_registry == null) return;

            var descriptor = GetSelectedProcessDescriptor();
            if (descriptor != null)
            {
                var step = new ProcessStepEntity
                {
                    OrderNo = _processSteps.Count + 1,
                    ProcessId = descriptor.ProcessId,
                    ParamJson = descriptor.DefaultParamJson,
                    Enabled = true
                };

                _processSteps.Add(step);
                RefreshProcessList();
                OnFlowChanged();

                dgvProcessList.ClearSelection();
                dgvProcessList.Rows[dgvProcessList.Rows.Count - 1].Selected = true;
            }
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            if (dgvProcessList.SelectedRows.Count > 0)
            {
                var index = dgvProcessList.SelectedRows[0].Index;
                _processSteps.RemoveAt(index);
                RecalculateOrderNo();
                RefreshProcessList();
                ClearEditor();
                OnFlowChanged();
            }
        }

        private void BtnMoveUp_Click(object sender, EventArgs e)
        {
            if (dgvProcessList.SelectedRows.Count > 0)
            {
                var index = dgvProcessList.SelectedRows[0].Index;
                if (index > 0)
                {
                    var temp = _processSteps[index];
                    _processSteps[index] = _processSteps[index - 1];
                    _processSteps[index - 1] = temp;
                    RecalculateOrderNo();
                    RefreshProcessList();
                    OnFlowChanged();

                    dgvProcessList.ClearSelection();
                    dgvProcessList.Rows[index - 1].Selected = true;
                }
            }
        }

        private void BtnMoveDown_Click(object sender, EventArgs e)
        {
            if (dgvProcessList.SelectedRows.Count > 0)
            {
                var index = dgvProcessList.SelectedRows[0].Index;
                if (index < _processSteps.Count - 1)
                {
                    var temp = _processSteps[index];
                    _processSteps[index] = _processSteps[index + 1];
                    _processSteps[index + 1] = temp;
                    RecalculateOrderNo();
                    RefreshProcessList();
                    OnFlowChanged();

                    dgvProcessList.ClearSelection();
                    dgvProcessList.Rows[index + 1].Selected = true;
                }
            }
        }

        private void DgvProcessList_SelectionChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;

            UpdateButtonStates();

            if (dgvProcessList.SelectedRows.Count > 0)
            {
                var row = dgvProcessList.SelectedRows[0];
                _selectedStep = row.Tag as ProcessStepEntity;
                LoadEditor(_selectedStep);
            }
            else
            {
                _selectedStep = null;
                ClearEditor();
            }
        }

        private void DgvProcessList_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgvProcessList.CurrentCell is DataGridViewCheckBoxCell)
            {
                dgvProcessList.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void DgvProcessList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (_isLoading || e.RowIndex < 0) return;

            if (dgvProcessList.Columns[e.ColumnIndex].Name == "Enabled")
            {
                var row = dgvProcessList.Rows[e.RowIndex];
                var step = row.Tag as ProcessStepEntity;
                if (step != null)
                {
                    step.Enabled = (bool)row.Cells["Enabled"].Value;
                    OnFlowChanged();
                }
            }
        }

        private void LoadEditor(ProcessStepEntity step)
        {
            if (_scope == null)
            {
                // �|���`�J�̿�A�]�p���q�Ϊ�l�ƫe���������C
                return;
            }

            if (step == null)
            {
                ClearEditor();
                return;
            }

            try
            {
                if (_currentEditor != null)
                {
                    _currentEditor.ParamChanged -= CurrentEditor_ParamChanged;
                    if (_currentEditor is Control ctrl)
                    {
                        pnlEditorHost.Controls.Remove(ctrl);
                        ctrl.Dispose();
                    }
                }

                _currentEditor = _scope.ResolveKeyed<IProcessEditor>(step.ProcessId);

                if (_currentEditor is Control editorControl)
                {
                    editorControl.Dock = DockStyle.Fill;
                    pnlEditorHost.Controls.Add(editorControl);
                }

                _currentEditor.Load(step.ParamJson);
                _currentEditor.ParamChanged += CurrentEditor_ParamChanged;

                var desc = _registry?.GetById(step.ProcessId);
                _lblEditorTitle.Text = $"�Ѽƽs�� - {desc?.DisplayName ?? step.ProcessId}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"���J�s�边����: {ex.Message}", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearEditor()
        {
            if (_currentEditor != null)
            {
                _currentEditor.ParamChanged -= CurrentEditor_ParamChanged;
                if (_currentEditor is Control ctrl)
                {
                    pnlEditorHost.Controls.Remove(ctrl);
                    ctrl.Dispose();
                }
                _currentEditor = null;
            }

            if (_lblEditorTitle != null)
            {
                _lblEditorTitle.Text = "�Ѽƽs��";
            }

            _selectedStep = null;
        }

        private void CurrentEditor_ParamChanged(object sender, EventArgs e)
        {
            if (_selectedStep != null && _currentEditor != null)
            {
                _selectedStep.ParamJson = _currentEditor.Save();

                foreach (DataGridViewRow row in dgvProcessList.Rows)
                {
                    if (row.Tag == _selectedStep)
                    {
                        row.Cells["Summary"].Value = GetParamSummary(_selectedStep);
                        break;
                    }
                }

                OnFlowChanged();
            }
        }

        protected virtual void OnFlowChanged()
        {
            FlowChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
