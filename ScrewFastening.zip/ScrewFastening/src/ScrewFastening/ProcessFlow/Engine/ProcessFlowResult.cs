﻿using System;

namespace Calin.ScrewFastening.ProcessFlow.Engine
{
    /// <summary>
    /// 流程執行結果。
    /// </summary>
    public class ProcessFlowResult
    {
        public bool Success { get; }
        public int TotalSteps { get; }
        public int ExecutedSteps { get; }
        public int FailedStepIndex { get; }
        public string ErrorMessage { get; }
        public Exception Exception { get; }

        private ProcessFlowResult(bool success, int totalSteps, int executedSteps, int failedStepIndex = -1, string errorMessage = null, Exception exception = null)
        {
            Success = success;
            TotalSteps = totalSteps;
            ExecutedSteps = executedSteps;
            FailedStepIndex = failedStepIndex;
            ErrorMessage = errorMessage;
            Exception = exception;
        }

        public static ProcessFlowResult Succeeded(int totalSteps, int executedSteps)
            => new ProcessFlowResult(true, totalSteps, executedSteps);

        public static ProcessFlowResult Failed(int totalSteps, int executedSteps, int failedStepIndex, string errorMessage, Exception exception = null)
            => new ProcessFlowResult(false, totalSteps, executedSteps, failedStepIndex, errorMessage, exception);

        public static ProcessFlowResult Cancelled(int totalSteps, int executedSteps)
            => new ProcessFlowResult(false, totalSteps, executedSteps, -1, "流程已被取消");
    }
}
