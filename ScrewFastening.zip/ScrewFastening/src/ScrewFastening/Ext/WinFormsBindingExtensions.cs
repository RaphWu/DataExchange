﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.ScrewFastening.Ext
{
    internal static class WinFormsBindingExtensions
    {
        /// <summary>
        /// 將 Control.Text 綁定到 double (或可轉成 double 的數值) 屬性，並以 "F3" 格式顯示到小數點後 3 位。
        /// </summary>
        /// <param name="control">欲綁定的 Control。</param>
        /// <param name="source">資料來源物件。</param>
        /// <param name="doublePropertyName">來源物件的 double 屬性名稱。</param>
        /// <param name="clearExistingBindings">是否清除 Control 上現有的 DataBindings。</param>
        public static Binding BindTextToDoubleWith3Digits(
            this Control control,
            object source,
            string doublePropertyName,
            bool clearExistingBindings = false)
        {
            if (control is null) throw new ArgumentNullException(nameof(control));
            if (source is null) throw new ArgumentNullException(nameof(source));
            if (string.IsNullOrWhiteSpace(doublePropertyName)) throw new ArgumentException("Property name is required.", nameof(doublePropertyName));

            if (clearExistingBindings)
                control.DataBindings.Clear();

            var binding = new Binding(
                propertyName: nameof(Control.Text),
                dataSource: source,
                dataMember: doublePropertyName,
                formattingEnabled: true,
                dataSourceUpdateMode: DataSourceUpdateMode.Never);

            binding.Format += (_, e) =>
            {
                // 先把資料來源值格式化成要顯示的字串
                string text;
                if (e.Value is null)
                {
                    text = string.Empty;
                }
                else if (e.Value is double d)
                {
                    text = d.ToString("F3");
                }
                else
                {
                    try
                    {
                        var converted = Convert.ToDouble(e.Value);
                        text = converted.ToString("F3");
                    }
                    catch
                    {
                        text = e.Value.ToString();
                    }
                }

                // WinForms Binding 可能在背景執行緒回呼 Format，導致把值推到控制項時跨執行緒例外
                // 如果不在 UI 執行緒：改用 BeginInvoke 自己設 Text，並取消本次 binding 的套用
                if (control.IsHandleCreated && control.InvokeRequired)
                {
                    try
                    {
                        control.BeginInvoke((Action)(() =>
                        {
                            if (!control.IsDisposed)
                                control.Text = text;
                        }));
                    }
                    catch
                    {
                        // 控制項關閉/Handle 釋放期間可能丟例外，直接吞掉避免連鎖錯誤
                    }

                    e.Value = control.Text; // 避免 Binding 直接在目前執行緒寫入 UI
                    return;
                }

                // UI thread：正常交給 Binding 套用
                e.Value = text;
            };

            control.DataBindings.Add(binding);
            return binding;
        }

        /// <summary>
        /// 將 Control.BackColor 綁定到 bool 屬性，並用 Format 轉換成 Color。
        /// </summary>
        /// <param name="control">欲綁定的 Control。</param>
        /// <param name="source">資料來源物件。</param>
        /// <param name="boolPropertyName">來源物件的 bool 屬性名稱。</param>
        /// <param name="trueColor">當 bool 為 true 時的顏色。</param>
        /// <param name="falseColor">當 bool 為 false 時的顏色。</param>
        /// <param name="clearExistingBindings">是否清除 Control 上現有的 DataBindings。</param>
        public static Binding BindBackColorToBool(
            this Control control,
            object source,
            string boolPropertyName,
            Color trueColor,
            Color falseColor,
            bool clearExistingBindings = false)
        {
            if (control is null) throw new ArgumentNullException(nameof(control));
            if (source is null) throw new ArgumentNullException(nameof(source));
            if (string.IsNullOrWhiteSpace(boolPropertyName)) throw new ArgumentException("Property name is required.", nameof(boolPropertyName));

            if (clearExistingBindings)
                control.DataBindings.Clear();

            var binding = new Binding(
                propertyName: nameof(Control.BackColor),
                dataSource: source,
                dataMember: boolPropertyName,
                formattingEnabled: true,
                dataSourceUpdateMode: DataSourceUpdateMode.Never);

            binding.Format += (_, e) =>
            {
                var value = e.Value;
                var on = value is bool b && b;
                e.Value = on ? trueColor : falseColor;
            };

            control.DataBindings.Add(binding);
            return binding;
        }

        /// <summary>
        /// 將 Control.BackColor 綁定到數值門檻（事件驅動版本）。
        /// </summary>
        /// <remarks>
        /// 使用 INotifyPropertyChanged 事件驅動更新，只在 value/limitLow/limitHigh 變更時更新 UI，
        /// 避免每次 Format 都呼叫委派造成的效能負擔。
        /// </remarks>
        /// <param name="control">欲綁定的 Control。</param>
        /// <param name="source">資料來源物件（必須實作 INotifyPropertyChanged）。</param>
        /// <param name="valuePropertyName">來源物件的數值屬性名稱。</param>
        /// <param name="limitLowPropertyName">來源物件的下限屬性名稱。</param>
        /// <param name="limitHighPropertyName">來源物件的上限屬性名稱。</param>
        /// <param name="betweenColor">介於 L 與 H 時使用的顏色（預設區間顏色）。</param>
        /// <param name="aboveColor">高於等於 H 時使用的顏色。</param>
        /// <param name="belowColor">低於 L 時使用的顏色。</param>
        /// <returns>IDisposable 可用於手動取消訂閱。</returns>
        public static IDisposable BindBackColorToThresholds(
            this Control control,
            INotifyPropertyChanged source,
            string valuePropertyName,
            string limitLowPropertyName,
            string limitHighPropertyName,
            Color betweenColor,
            Color aboveColor,
            Color belowColor)
        {
            if (control is null) throw new ArgumentNullException(nameof(control));
            if (source is null) throw new ArgumentNullException(nameof(source));
            if (string.IsNullOrWhiteSpace(valuePropertyName)) throw new ArgumentException("Property name is required.", nameof(valuePropertyName));
            if (string.IsNullOrWhiteSpace(limitLowPropertyName)) throw new ArgumentException("Property name is required.", nameof(limitLowPropertyName));
            if (string.IsNullOrWhiteSpace(limitHighPropertyName)) throw new ArgumentException("Property name is required.", nameof(limitHighPropertyName));

            // 取得屬性的反射資訊（只取一次）
            var sourceType = source.GetType();
            var valueProp = sourceType.GetProperty(valuePropertyName);
            var limitLowProp = sourceType.GetProperty(limitLowPropertyName);
            var limitHighProp = sourceType.GetProperty(limitHighPropertyName);

            if (valueProp == null) throw new ArgumentException($"Property '{valuePropertyName}' not found on source.", nameof(valuePropertyName));
            if (limitLowProp == null) throw new ArgumentException($"Property '{limitLowPropertyName}' not found on source.", nameof(limitLowPropertyName));
            if (limitHighProp == null) throw new ArgumentException($"Property '{limitHighPropertyName}' not found on source.", nameof(limitHighPropertyName));

            // 讀取 double 值的 helper
            double ReadDouble(System.Reflection.PropertyInfo prop, double fallback)
            {
                try
                {
                    var v = prop.GetValue(source);
                    if (v is null) return fallback;
                    if (v is double d) return d;
                    return Convert.ToDouble(v);
                }
                catch
                {
                    return fallback;
                }
            }

            // 套用顏色到 UI（處理跨執行緒）
            void ApplyColor(Color color)
            {
                if (control.IsDisposed) return;

                if (control.IsHandleCreated && control.InvokeRequired)
                {
                    try
                    {
                        control.BeginInvoke((Action)(() =>
                        {
                            if (!control.IsDisposed)
                                control.BackColor = color;
                        }));
                    }
                    catch
                    {
                        // 忽略 BeginInvoke 期間可能的例外
                    }
                }
                else
                {
                    control.BackColor = color;
                }
            }

            // 更新邏輯：根據 value/limitLow/limitHigh 決定顏色
            void Update()
            {
                var val = ReadDouble(valueProp, 0);
                var low = ReadDouble(limitLowProp, double.NegativeInfinity);
                var high = ReadDouble(limitHighProp, double.PositiveInfinity);

                Color chosen;
                if (val >= high)
                    chosen = aboveColor;
                else if (val < low)
                    chosen = belowColor;
                else
                    chosen = betweenColor;

                ApplyColor(chosen);
            }

            // 初始套用一次
            Update();

            // 事件處理：只監聽 value/limitLow/limitHigh 三個屬性
            PropertyChangedEventHandler handler = (_, e) =>
            {
                if (string.IsNullOrEmpty(e?.PropertyName) ||
                    e.PropertyName == valuePropertyName ||
                    e.PropertyName == limitLowPropertyName ||
                    e.PropertyName == limitHighPropertyName)
                {
                    Update();
                }
            };

            source.PropertyChanged += handler;

            // 在 control disposed 時自動解除訂閱
            EventHandler disposedHandler = null;
            disposedHandler = (_, __) =>
            {
                source.PropertyChanged -= handler;
                control.Disposed -= disposedHandler;
            };
            control.Disposed += disposedHandler;

            // 回傳 IDisposable 供手動取消訂閱
            return new Subscription(() =>
            {
                try { source.PropertyChanged -= handler; } catch { }
                try { control.Disposed -= disposedHandler; } catch { }
            });
        }

        /// <summary>
        /// 將 Control.BorderColor 綁定到數值門檻（事件驅動版本）。
        /// </summary>
        /// <remarks>
        /// 使用 INotifyPropertyChanged 事件驅動更新，只在 value/limitLow/limitHigh 變更時更新 UI，
        /// 避免每次 Format 都呼叫委派造成的效能負擔。
        /// </remarks>
        /// <param name="control">欲綁定的 Control（必須有 BorderColor 屬性）。</param>
        /// <param name="source">資料來源物件（必須實作 INotifyPropertyChanged）。</param>
        /// <param name="valuePropertyName">來源物件的數值屬性名稱。</param>
        /// <param name="limitLowPropertyName">來源物件的下限屬性名稱。</param>
        /// <param name="limitHighPropertyName">來源物件的上限屬性名稱。</param>
        /// <param name="betweenColor">介於 L 與 H 時使用的顏色（預設區間顏色）。</param>
        /// <param name="aboveColor">高於等於 H 時使用的顏色。</param>
        /// <param name="belowColor">低於 L 時使用的顏色。</param>
        /// <returns>IDisposable 可用於手動取消訂閱。</returns>
        public static IDisposable BindBorderColorToThresholds(
            this Control control,
            INotifyPropertyChanged source,
            string valuePropertyName,
            string limitLowPropertyName,
            string limitHighPropertyName,
            Color betweenColor,
            Color aboveColor,
            Color belowColor)
        {
            if (control is null) throw new ArgumentNullException(nameof(control));
            if (source is null) throw new ArgumentNullException(nameof(source));
            if (string.IsNullOrWhiteSpace(valuePropertyName)) throw new ArgumentException("Property name is required.", nameof(valuePropertyName));
            if (string.IsNullOrWhiteSpace(limitLowPropertyName)) throw new ArgumentException("Property name is required.", nameof(limitLowPropertyName));
            if (string.IsNullOrWhiteSpace(limitHighPropertyName)) throw new ArgumentException("Property name is required.", nameof(limitHighPropertyName));

            // 取得屬性的反射資訊（只取一次）
            var sourceType = source.GetType();
            var valueProp = sourceType.GetProperty(valuePropertyName);
            var limitLowProp = sourceType.GetProperty(limitLowPropertyName);
            var limitHighProp = sourceType.GetProperty(limitHighPropertyName);

            if (valueProp == null) throw new ArgumentException($"Property '{valuePropertyName}' not found on source.", nameof(valuePropertyName));
            if (limitLowProp == null) throw new ArgumentException($"Property '{limitLowPropertyName}' not found on source.", nameof(limitLowPropertyName));
            if (limitHighProp == null) throw new ArgumentException($"Property '{limitHighPropertyName}' not found on source.", nameof(limitHighPropertyName));

            // 取得 BorderColor 屬性（只取一次）
            const string borderColorPropertyName = "BorderColor";
            var borderColorProp = control.GetType().GetProperty(borderColorPropertyName);

            // 讀取 double 值的 helper
            double ReadDouble(System.Reflection.PropertyInfo prop, double fallback)
            {
                try
                {
                    var v = prop.GetValue(source);
                    if (v is null) return fallback;
                    if (v is double d) return d;
                    return Convert.ToDouble(v);
                }
                catch
                {
                    return fallback;
                }
            }

            // 套用顏色到 UI（處理跨執行緒）
            void ApplyColor(Color color)
            {
                if (control.IsDisposed) return;
                if (borderColorProp == null || !borderColorProp.CanWrite || !borderColorProp.PropertyType.IsAssignableFrom(typeof(Color))) return;

                if (control.IsHandleCreated && control.InvokeRequired)
                {
                    try
                    {
                        control.BeginInvoke((Action)(() =>
                        {
                            if (!control.IsDisposed)
                            {
                                try
                                {
                                    borderColorProp.SetValue(control, color);
                                }
                                catch
                                {
                                    // 忽略反射設定失敗
                                }
                            }
                        }));
                    }
                    catch
                    {
                        // 忽略 BeginInvoke 期間可能的例外
                    }
                }
                else
                {
                    try
                    {
                        borderColorProp.SetValue(control, color);
                    }
                    catch
                    {
                        // 忽略反射設定失敗
                    }
                }
            }

            // 更新邏輯：根據 value/limitLow/limitHigh 決定顏色
            void Update()
            {
                var val = ReadDouble(valueProp, 0);
                var low = ReadDouble(limitLowProp, double.NegativeInfinity);
                var high = ReadDouble(limitHighProp, double.PositiveInfinity);

                Color chosen;
                if (val >= high)
                    chosen = aboveColor;
                else if (val < low)
                    chosen = belowColor;
                else
                    chosen = betweenColor;

                ApplyColor(chosen);
            }

            // 初始套用一次
            Update();

            // 事件處理：只監聽 value/limitLow/limitHigh 三個屬性
            PropertyChangedEventHandler handler = (_, e) =>
            {
                if (string.IsNullOrEmpty(e?.PropertyName) ||
                    e.PropertyName == valuePropertyName ||
                    e.PropertyName == limitLowPropertyName ||
                    e.PropertyName == limitHighPropertyName)
                {
                    Update();
                }
            };

            source.PropertyChanged += handler;

            // 在 control disposed 時自動解除訂閱
            EventHandler disposedHandler = null;
            disposedHandler = (_, __) =>
            {
                source.PropertyChanged -= handler;
                control.Disposed -= disposedHandler;
            };
            control.Disposed += disposedHandler;

            // 回傳 IDisposable 供手動取消訂閱
            return new Subscription(() =>
            {
                try { source.PropertyChanged -= handler; } catch { }
                try { control.Disposed -= disposedHandler; } catch { }
            });
        }

        /// <summary>
        /// 簡單 IDisposable 實作，用於取消訂閱。
        /// </summary>
        private sealed class Subscription : IDisposable
        {
            private Action _dispose;

            public Subscription(Action dispose)
            {
                _dispose = dispose ?? throw new ArgumentNullException(nameof(dispose));
            }

            public void Dispose()
            {
                var d = System.Threading.Interlocked.Exchange(ref _dispose, null);
                d?.Invoke();
            }
        }
    }
}
