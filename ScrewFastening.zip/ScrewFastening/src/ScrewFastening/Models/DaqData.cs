﻿namespace Calin.ScrewFastening.Models
{
    /// <summary>
    /// 資料擷取裝置 (DAQ) 資料模型。
    /// </summary>
    /// <remarks>DAQ設定，會儲存成 .JSON 檔。</remarks>
    public class DaqData
    {
        public string DeviceCode { get; set; } = "USB-4704,BID#0";

        // USB4704 設定
        public double ClockRate { get; set; } = 1000.0;
        public int SectionLength { get; set; } = 256;

        // 扭力計上下限設定
        public int TorqueChannel { get; set; } = 0;
        public double TorqueLimitH { get; set; } = 20.0;
        public double TorqueLimitL { get; set; } = 10.0;

        // 尋邊
        public string GateMarkPort { get; set; } = "DO0";
        public double AngleCompensation { get; set; } = 0.0;
    }
}
