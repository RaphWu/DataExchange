﻿using Calin.MVVM;

namespace Calin.ScrewFastening.Models
{
    /// <summary>
    /// 綁定資料模型。
    /// </summary>
    /// <remarks>UI顯示用資料。</remarks>
    public class BindingData : ObservableObject
    {
        #region 作業狀態

        /// <summary>
        /// 量測中。
        /// </summary>
        public bool IsMeasuring
        {
            get { return _isMeasuring; }
            set { SetProperty(ref _isMeasuring, value); }
        }
        private bool _isMeasuring = false;

        #endregion 作業狀態

        #region 軸卡

        /// <summary>
        /// Z軸是否啟用。
        /// </summary>
        public bool ZAxisActive
        {
            get { return _zAxisActive; }
            set { SetProperty(ref _zAxisActive, value); }
        }
        private bool _zAxisActive;

        /// <summary>
        /// Z軸目前座標。
        /// </summary>
        public double ZAxisCoor
        {
            get { return _zAxisCoor; }
            set { SetProperty(ref _zAxisCoor, value); }
        }
        private double _zAxisCoor;

        /// <summary>
        /// R軸是否啟用。
        /// </summary>
        public bool RAxisActive
        {
            get { return _rAxisActive; }
            set { SetProperty(ref _rAxisActive, value); }
        }
        private bool _rAxisActive;

        /// <summary>
        /// R軸目前轉速(RPM)。
        /// </summary>
        public double RPM
        {
            get { return _rpm; }
            set { SetProperty(ref _rpm, value); }
        }
        private double _rpm;

        /// <summary>
        /// R軸目前角度。
        /// </summary>
        public double Angle
        {
            get { return _angle; }
            set { SetProperty(ref _angle, value); }
        }
        private double _angle;

        #endregion 軸卡

        #region 扭力計

        /// <summary>
        /// 扭力計是否啟用。
        /// </summary>
        public bool TorqueMeterActive
        {
            get { return _torqueMeterActive; }
            set { SetProperty(ref _torqueMeterActive, value); }
        }
        private bool _torqueMeterActive = false;

        /// <summary>
        /// 扭力計讀數。
        /// </summary>
        public double TorqueValue
        {
            get { return _torqueValue; }
            set { SetProperty(ref _torqueValue, value); }
        }
        private double _torqueValue;
        public double TorqueValue1;

        /// <summary>
        /// 扭力計最終值。
        /// </summary>
        public double TorqueFinalValue
        {
            get { return _torqueFinalValue; }
            set { SetProperty(ref _torqueFinalValue, value); }
        }
        private double _torqueFinalValue;

        /// <summary>
        /// 扭力計最大值。
        /// </summary>
        public double TorqueMaxValue
        {
            get { return _torqueMaxValue; }
            set { SetProperty(ref _torqueMaxValue, value); }
        }
        private double _torqueMaxValue;

        /// <summary>
        /// 扭力計上限值。
        /// </summary>
        public double TorqueLimitH
        {
            get { return _torqueLimitH; }
            set { SetProperty(ref _torqueLimitH, value); }
        }
        private double _torqueLimitH;

        /// <summary>
        /// 扭力計下限值。
        /// </summary>
        public double TorqueLimitL
        {
            get { return _torqueLimitL; }
            set { SetProperty(ref _torqueLimitL, value); }
        }
        private double _torqueLimitL;

        #endregion 扭力計

        #region 高度計

        /// <summary>
        /// 高度計是否啟用。
        /// </summary>
        public bool HeightDisplacementActive
        {
            get { return _heightDisplacementActive; }
            set { SetProperty(ref _heightDisplacementActive, value); }
        }
        private bool _heightDisplacementActive = false;

        /// <summary>
        /// 高度計讀數。
        /// </summary>
        public double HeightDisplacementValue
        {
            get { return _heightDisplacementValue; }
            set { SetProperty(ref _heightDisplacementValue, value); }
        }
        private double _heightDisplacementValue;

        /// <summary>
        /// 高度計最終值。
        /// </summary>
        public double HeightDisplacementFinalValue
        {
            get { return _heightDisplacementFinalValue; }
            set { SetProperty(ref _heightDisplacementFinalValue, value); }
        }
        private double _heightDisplacementFinalValue;

        /// <summary>
        /// 高度計最大值。
        /// </summary>
        public double HeightDisplacementMaxValue
        {
            get { return _heightDisplacementMaxValue; }
            set { SetProperty(ref _heightDisplacementMaxValue, value); }
        }
        private double _heightDisplacementMaxValue;

        /// <summary>
        /// 高度計上限值。
        /// </summary>
        public double HeightDisplacementLimitH
        {
            get { return _heightDisplacementLimitH; }
            set { SetProperty(ref _heightDisplacementLimitH, value); }
        }
        private double _heightDisplacementLimitH;

        /// <summary>
        /// 高度計下限值。
        /// </summary>
        public double HeightDisplacementLimitL
        {
            get { return _heightDisplacementLimitL; }
            set { SetProperty(ref _heightDisplacementLimitL, value); }
        }
        private double _heightDisplacementLimitL;

        #endregion 高度計

        #region USB4704

        /// <summary>
        /// DAQ I/O 是否啟用。
        /// </summary>
        public bool DaqIoActive
        {
            get { return _daqIoActive; }
            set { SetProperty(ref _daqIoActive, value); }
        }
        private bool _daqIoActive = false;

        //public bool DI0
        //{
        //    get { return _di0; }
        //    set { SetProperty(ref _di0, value); }
        //}
        //private bool _di0;

        //public bool DI1
        //{
        //    get { return _di1; }
        //    set { SetProperty(ref _di1, value); }
        //}
        //private bool _di1;

        //public bool DI2
        //{
        //    get { return _di2; }
        //    set { SetProperty(ref _di2, value); }
        //}
        //private bool _di2;

        //public bool DI3
        //{
        //    get { return _di3; }
        //    set { SetProperty(ref _di3, value); }
        //}
        //private bool _di3;

        //public bool DI4
        //{
        //    get { return _di4; }
        //    set { SetProperty(ref _di4, value); }
        //}
        //private bool _di4;

        //public bool DI5
        //{
        //    get { return _di5; }
        //    set { SetProperty(ref _di5, value); }
        //}
        //private bool _di5;

        //public bool DI6
        //{
        //    get { return _di6; }
        //    set { SetProperty(ref _di6, value); }
        //}
        //private bool _di6;

        //public bool DI7
        //{
        //    get { return _di7; }
        //    set { SetProperty(ref _di7, value); }
        //}
        //private bool _di7;

        #endregion USB4704

#if DEBUG
        /// <summary>
        /// 扭力計碼表讀取時間。
        /// </summary>
        public double TorqueStopwatch
        {
            get { return _torqueStopwatch; }
            set { SetProperty(ref _torqueStopwatch, value); }
        }
        private double _torqueStopwatch;

        public bool WaitForRecevieTorque = false;

        /// <summary>
        /// 高度計碼表讀取時間。
        /// </summary>
        public double HeightDisplacementStopwatch
        {
            get { return _heightDisplacementStopwatch; }
            set { SetProperty(ref _heightDisplacementStopwatch, value); }
        }
        private double _heightDisplacementStopwatch;

        public int WaitForReceiveHeightDisplacement = 0;
#endif
    }
}
