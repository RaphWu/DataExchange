﻿namespace Calin.ScrewFastening.Views
{
    partial class ManualPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.NumPosRel = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.NumPosAbs = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnMove = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.RbMpg = new System.Windows.Forms.RadioButton();
            this.RbJog = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxExtPulseNum = new System.Windows.Forms.NumericUpDown();
            this.checkBoxEnExtSel = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxOutPlsMd = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxExtMstSrc = new System.Windows.Forms.ComboBox();
            this.StatePanel = new System.Windows.Forms.GroupBox();
            this.BtnResetPos = new System.Windows.Forms.Button();
            this.TbActPos = new System.Windows.Forms.TextBox();
            this.TbCmdPos = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.PbBusy = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.PbErrStop = new System.Windows.Forms.PictureBox();
            this.PbStop = new System.Windows.Forms.PictureBox();
            this.PbReady = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.PBoxEz = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.PBoxHELNegative = new System.Windows.Forms.PictureBox();
            this.PBoxHELPositive = new System.Windows.Forms.PictureBox();
            this.PBoxOrg = new System.Windows.Forms.PictureBox();
            this.PBoxAlm = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.TboxCurrentState = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.RbRel = new System.Windows.Forms.RadioButton();
            this.RbAbs = new System.Windows.Forms.RadioButton();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosRel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosAbs)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textBoxExtPulseNum)).BeginInit();
            this.StatePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbBusy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbErrStop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbStop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbReady)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxEz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxHELNegative)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxHELPositive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxOrg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxAlm)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.NumPosRel);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.NumPosAbs);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.BtnStop);
            this.groupBox3.Controls.Add(this.BtnMove);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(19, 17);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(233, 133);
            this.groupBox3.TabIndex = 41;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "PTP 運動";
            // 
            // NumPosRel
            // 
            this.NumPosRel.DecimalPlaces = 3;
            this.NumPosRel.Location = new System.Drawing.Point(82, 54);
            this.NumPosRel.Name = "NumPosRel";
            this.NumPosRel.Size = new System.Drawing.Size(125, 23);
            this.NumPosRel.TabIndex = 29;
            this.NumPosRel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 28;
            this.label1.Text = "相對位置";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // NumPosAbs
            // 
            this.NumPosAbs.DecimalPlaces = 3;
            this.NumPosAbs.Location = new System.Drawing.Point(82, 25);
            this.NumPosAbs.Name = "NumPosAbs";
            this.NumPosAbs.Size = new System.Drawing.Size(125, 23);
            this.NumPosAbs.TabIndex = 27;
            this.NumPosAbs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumPosAbs.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "絕對位置";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(128, 92);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(79, 25);
            this.BtnStop.TabIndex = 25;
            this.BtnStop.Text = "停止";
            this.BtnStop.UseVisualStyleBackColor = true;
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(27, 92);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(79, 25);
            this.BtnMove.TabIndex = 20;
            this.BtnMove.Text = "移動至目標";
            this.BtnMove.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RbMpg);
            this.groupBox2.Controls.Add(this.RbJog);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(395, 169);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(232, 60);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "外部驅動模式";
            // 
            // RbMpg
            // 
            this.RbMpg.AutoSize = true;
            this.RbMpg.Location = new System.Drawing.Point(109, 26);
            this.RbMpg.Name = "RbMpg";
            this.RbMpg.Size = new System.Drawing.Size(100, 20);
            this.RbMpg.TabIndex = 1;
            this.RbMpg.Text = "MPG (手搖輪)";
            this.RbMpg.UseVisualStyleBackColor = true;
            // 
            // RbJog
            // 
            this.RbJog.AutoSize = true;
            this.RbJog.Checked = true;
            this.RbJog.Location = new System.Drawing.Point(30, 26);
            this.RbJog.Name = "RbJog";
            this.RbJog.Size = new System.Drawing.Size(49, 20);
            this.RbJog.TabIndex = 0;
            this.RbJog.TabStop = true;
            this.RbJog.Text = "JOG";
            this.RbJog.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxExtPulseNum);
            this.groupBox1.Controls.Add(this.checkBoxEnExtSel);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.comboBoxOutPlsMd);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.comboBoxExtMstSrc);
            this.groupBox1.Enabled = false;
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(395, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(309, 148);
            this.groupBox1.TabIndex = 39;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "外部驅動設定";
            // 
            // textBoxExtPulseNum
            // 
            this.textBoxExtPulseNum.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.textBoxExtPulseNum.Location = new System.Drawing.Point(109, 56);
            this.textBoxExtPulseNum.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.textBoxExtPulseNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.textBoxExtPulseNum.Name = "textBoxExtPulseNum";
            this.textBoxExtPulseNum.Size = new System.Drawing.Size(102, 23);
            this.textBoxExtPulseNum.TabIndex = 42;
            this.textBoxExtPulseNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxExtPulseNum.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // checkBoxEnExtSel
            // 
            this.checkBoxEnExtSel.AutoSize = true;
            this.checkBoxEnExtSel.Location = new System.Drawing.Point(109, 115);
            this.checkBoxEnExtSel.Name = "checkBoxEnExtSel";
            this.checkBoxEnExtSel.Size = new System.Drawing.Size(98, 20);
            this.checkBoxEnExtSel.TabIndex = 37;
            this.checkBoxEnExtSel.Text = "使用外部驅動";
            this.checkBoxEnExtSel.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(217, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 16);
            this.label6.TabIndex = 37;
            this.label6.Text = "(1-10000)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 16);
            this.label5.TabIndex = 41;
            this.label5.Text = "外部驅動脈衝數";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 16);
            this.label4.TabIndex = 40;
            this.label4.Text = "脈衝輸出模式";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxOutPlsMd
            // 
            this.comboBoxOutPlsMd.FormattingEnabled = true;
            this.comboBoxOutPlsMd.Items.AddRange(new object[] {
            "OUT/DIR",
            "OUT/DIR，OUT負邏輯",
            "OUT/DIR，DIR負邏輯",
            "OUT/DIR，OUT&DIR負邏輯",
            "CW/CCW",
            "CW/CCW，CW&CCW負邏輯",
            "A/B相位",
            "B/A相位"});
            this.comboBoxOutPlsMd.Location = new System.Drawing.Point(109, 85);
            this.comboBoxOutPlsMd.Name = "comboBoxOutPlsMd";
            this.comboBoxOutPlsMd.Size = new System.Drawing.Size(172, 24);
            this.comboBoxOutPlsMd.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 38;
            this.label3.Text = "外部驅動來源";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxExtMstSrc
            // 
            this.comboBoxExtMstSrc.FormattingEnabled = true;
            this.comboBoxExtMstSrc.Location = new System.Drawing.Point(109, 26);
            this.comboBoxExtMstSrc.Name = "comboBoxExtMstSrc";
            this.comboBoxExtMstSrc.Size = new System.Drawing.Size(172, 24);
            this.comboBoxExtMstSrc.TabIndex = 37;
            // 
            // StatePanel
            // 
            this.StatePanel.Controls.Add(this.BtnResetPos);
            this.StatePanel.Controls.Add(this.TbActPos);
            this.StatePanel.Controls.Add(this.TbCmdPos);
            this.StatePanel.Controls.Add(this.label2);
            this.StatePanel.Controls.Add(this.label9);
            this.StatePanel.Controls.Add(this.label7);
            this.StatePanel.Controls.Add(this.PbBusy);
            this.StatePanel.Controls.Add(this.label8);
            this.StatePanel.Controls.Add(this.label11);
            this.StatePanel.Controls.Add(this.label12);
            this.StatePanel.Controls.Add(this.label13);
            this.StatePanel.Controls.Add(this.pictureBox2);
            this.StatePanel.Controls.Add(this.PbErrStop);
            this.StatePanel.Controls.Add(this.PbStop);
            this.StatePanel.Controls.Add(this.PbReady);
            this.StatePanel.Controls.Add(this.label14);
            this.StatePanel.Controls.Add(this.PBoxEz);
            this.StatePanel.Controls.Add(this.label15);
            this.StatePanel.Controls.Add(this.label16);
            this.StatePanel.Controls.Add(this.label17);
            this.StatePanel.Controls.Add(this.label18);
            this.StatePanel.Controls.Add(this.PBoxHELNegative);
            this.StatePanel.Controls.Add(this.PBoxHELPositive);
            this.StatePanel.Controls.Add(this.PBoxOrg);
            this.StatePanel.Controls.Add(this.PBoxAlm);
            this.StatePanel.Controls.Add(this.label20);
            this.StatePanel.Controls.Add(this.BtnResetErr);
            this.StatePanel.Controls.Add(this.TboxCurrentState);
            this.StatePanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.StatePanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.StatePanel.Location = new System.Drawing.Point(689, 266);
            this.StatePanel.Margin = new System.Windows.Forms.Padding(4);
            this.StatePanel.Name = "StatePanel";
            this.StatePanel.Padding = new System.Windows.Forms.Padding(4);
            this.StatePanel.Size = new System.Drawing.Size(201, 342);
            this.StatePanel.TabIndex = 60;
            this.StatePanel.TabStop = false;
            this.StatePanel.Text = "目前狀態";
            // 
            // BtnResetPos
            // 
            this.BtnResetPos.Location = new System.Drawing.Point(111, 302);
            this.BtnResetPos.Margin = new System.Windows.Forms.Padding(4);
            this.BtnResetPos.Name = "BtnResetPos";
            this.BtnResetPos.Size = new System.Drawing.Size(74, 25);
            this.BtnResetPos.TabIndex = 80;
            this.BtnResetPos.Text = "位置歸零";
            this.BtnResetPos.UseVisualStyleBackColor = true;
            // 
            // TbActPos
            // 
            this.TbActPos.Location = new System.Drawing.Point(75, 218);
            this.TbActPos.Name = "TbActPos";
            this.TbActPos.ReadOnly = true;
            this.TbActPos.Size = new System.Drawing.Size(110, 23);
            this.TbActPos.TabIndex = 79;
            this.TbActPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbCmdPos
            // 
            this.TbCmdPos.Location = new System.Drawing.Point(75, 189);
            this.TbCmdPos.Name = "TbCmdPos";
            this.TbCmdPos.ReadOnly = true;
            this.TbCmdPos.Size = new System.Drawing.Size(110, 23);
            this.TbCmdPos.TabIndex = 78;
            this.TbCmdPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 222);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 16);
            this.label2.TabIndex = 77;
            this.label2.Text = "實際位置";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 193);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 16);
            this.label9.TabIndex = 76;
            this.label9.Text = "命令位置";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(133, 62);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 16);
            this.label7.TabIndex = 75;
            this.label7.Text = "Busy";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PbBusy
            // 
            this.PbBusy.BackColor = System.Drawing.Color.Gray;
            this.PbBusy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbBusy.Location = new System.Drawing.Point(111, 61);
            this.PbBusy.Margin = new System.Windows.Forms.Padding(4);
            this.PbBusy.Name = "PbBusy";
            this.PbBusy.Size = new System.Drawing.Size(18, 18);
            this.PbBusy.TabIndex = 74;
            this.PbBusy.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(133, 155);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 16);
            this.label8.TabIndex = 73;
            this.label8.Text = "X";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(133, 124);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 16);
            this.label11.TabIndex = 72;
            this.label11.Text = "ErrStop";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(133, 93);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 16);
            this.label12.TabIndex = 71;
            this.label12.Text = "Stop";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(133, 31);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 16);
            this.label13.TabIndex = 70;
            this.label13.Text = "Ready";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Gray;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(111, 154);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(18, 18);
            this.pictureBox2.TabIndex = 69;
            this.pictureBox2.TabStop = false;
            // 
            // PbErrStop
            // 
            this.PbErrStop.BackColor = System.Drawing.Color.Gray;
            this.PbErrStop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbErrStop.Location = new System.Drawing.Point(111, 123);
            this.PbErrStop.Margin = new System.Windows.Forms.Padding(4);
            this.PbErrStop.Name = "PbErrStop";
            this.PbErrStop.Size = new System.Drawing.Size(18, 18);
            this.PbErrStop.TabIndex = 68;
            this.PbErrStop.TabStop = false;
            // 
            // PbStop
            // 
            this.PbStop.BackColor = System.Drawing.Color.Gray;
            this.PbStop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbStop.Location = new System.Drawing.Point(111, 92);
            this.PbStop.Margin = new System.Windows.Forms.Padding(4);
            this.PbStop.Name = "PbStop";
            this.PbStop.Size = new System.Drawing.Size(18, 18);
            this.PbStop.TabIndex = 67;
            this.PbStop.TabStop = false;
            // 
            // PbReady
            // 
            this.PbReady.BackColor = System.Drawing.Color.Gray;
            this.PbReady.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbReady.Location = new System.Drawing.Point(111, 30);
            this.PbReady.Margin = new System.Windows.Forms.Padding(4);
            this.PbReady.Name = "PbReady";
            this.PbReady.Size = new System.Drawing.Size(18, 18);
            this.PbReady.TabIndex = 66;
            this.PbReady.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(51, 61);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 16);
            this.label14.TabIndex = 65;
            this.label14.Text = "Z相";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PBoxEz
            // 
            this.PBoxEz.BackColor = System.Drawing.Color.Gray;
            this.PBoxEz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxEz.Location = new System.Drawing.Point(29, 60);
            this.PBoxEz.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxEz.Name = "PBoxEz";
            this.PBoxEz.Size = new System.Drawing.Size(18, 18);
            this.PBoxEz.TabIndex = 64;
            this.PBoxEz.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(51, 154);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 16);
            this.label15.TabIndex = 63;
            this.label15.Text = "負極限";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(51, 123);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 62;
            this.label16.Text = "正極限";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(51, 92);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(31, 16);
            this.label17.TabIndex = 61;
            this.label17.Text = "原點";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(51, 30);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(31, 16);
            this.label18.TabIndex = 60;
            this.label18.Text = "警報";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PBoxHELNegative
            // 
            this.PBoxHELNegative.BackColor = System.Drawing.Color.Gray;
            this.PBoxHELNegative.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxHELNegative.Location = new System.Drawing.Point(29, 153);
            this.PBoxHELNegative.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxHELNegative.Name = "PBoxHELNegative";
            this.PBoxHELNegative.Size = new System.Drawing.Size(18, 18);
            this.PBoxHELNegative.TabIndex = 59;
            this.PBoxHELNegative.TabStop = false;
            // 
            // PBoxHELPositive
            // 
            this.PBoxHELPositive.BackColor = System.Drawing.Color.Gray;
            this.PBoxHELPositive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxHELPositive.Location = new System.Drawing.Point(29, 122);
            this.PBoxHELPositive.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxHELPositive.Name = "PBoxHELPositive";
            this.PBoxHELPositive.Size = new System.Drawing.Size(18, 18);
            this.PBoxHELPositive.TabIndex = 58;
            this.PBoxHELPositive.TabStop = false;
            // 
            // PBoxOrg
            // 
            this.PBoxOrg.BackColor = System.Drawing.Color.Gray;
            this.PBoxOrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxOrg.Location = new System.Drawing.Point(29, 91);
            this.PBoxOrg.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxOrg.Name = "PBoxOrg";
            this.PBoxOrg.Size = new System.Drawing.Size(18, 18);
            this.PBoxOrg.TabIndex = 57;
            this.PBoxOrg.TabStop = false;
            // 
            // PBoxAlm
            // 
            this.PBoxAlm.BackColor = System.Drawing.Color.Gray;
            this.PBoxAlm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxAlm.Location = new System.Drawing.Point(29, 29);
            this.PBoxAlm.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxAlm.Name = "PBoxAlm";
            this.PBoxAlm.Size = new System.Drawing.Size(18, 18);
            this.PBoxAlm.TabIndex = 56;
            this.PBoxAlm.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(25, 252);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 16);
            this.label20.TabIndex = 33;
            this.label20.Text = "狀態";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(20, 302);
            this.BtnResetErr.Margin = new System.Windows.Forms.Padding(4);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(74, 25);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "異常重置";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            // 
            // TboxCurrentState
            // 
            this.TboxCurrentState.Location = new System.Drawing.Point(20, 271);
            this.TboxCurrentState.Margin = new System.Windows.Forms.Padding(4);
            this.TboxCurrentState.Name = "TboxCurrentState";
            this.TboxCurrentState.ReadOnly = true;
            this.TboxCurrentState.Size = new System.Drawing.Size(165, 23);
            this.TboxCurrentState.TabIndex = 30;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.RbRel);
            this.groupBox10.Controls.Add(this.RbAbs);
            this.groupBox10.Location = new System.Drawing.Point(46, 169);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(181, 53);
            this.groupBox10.TabIndex = 70;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "移動模式";
            // 
            // RbRel
            // 
            this.RbRel.AutoSize = true;
            this.RbRel.Location = new System.Drawing.Point(88, 23);
            this.RbRel.Margin = new System.Windows.Forms.Padding(4);
            this.RbRel.Name = "RbRel";
            this.RbRel.Size = new System.Drawing.Size(73, 20);
            this.RbRel.TabIndex = 35;
            this.RbRel.Text = "相對位置";
            this.RbRel.UseVisualStyleBackColor = true;
            // 
            // RbAbs
            // 
            this.RbAbs.AutoSize = true;
            this.RbAbs.Checked = true;
            this.RbAbs.Location = new System.Drawing.Point(10, 23);
            this.RbAbs.Margin = new System.Windows.Forms.Padding(4);
            this.RbAbs.Name = "RbAbs";
            this.RbAbs.Size = new System.Drawing.Size(73, 20);
            this.RbAbs.TabIndex = 36;
            this.RbAbs.TabStop = true;
            this.RbAbs.Text = "絕對位置";
            this.RbAbs.UseVisualStyleBackColor = true;
            // 
            // ManualPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.StatePanel);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ManualPage";
            this.Size = new System.Drawing.Size(1000, 660);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosRel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosAbs)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textBoxExtPulseNum)).EndInit();
            this.StatePanel.ResumeLayout(false);
            this.StatePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbBusy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbErrStop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbStop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbReady)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxEz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxHELNegative)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxHELPositive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxOrg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxAlm)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown NumPosRel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown NumPosAbs;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnMove;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton RbMpg;
        private System.Windows.Forms.RadioButton RbJog;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown textBoxExtPulseNum;
        private System.Windows.Forms.CheckBox checkBoxEnExtSel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxOutPlsMd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxExtMstSrc;
        private System.Windows.Forms.GroupBox StatePanel;
        private System.Windows.Forms.Button BtnResetPos;
        private System.Windows.Forms.TextBox TbActPos;
        private System.Windows.Forms.TextBox TbCmdPos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox PbBusy;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox PbErrStop;
        private System.Windows.Forms.PictureBox PbStop;
        private System.Windows.Forms.PictureBox PbReady;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.PictureBox PBoxEz;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox PBoxHELNegative;
        private System.Windows.Forms.PictureBox PBoxHELPositive;
        private System.Windows.Forms.PictureBox PBoxOrg;
        private System.Windows.Forms.PictureBox PBoxAlm;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.TextBox TboxCurrentState;
        private System.Windows.Forms.GroupBox groupBox10;
        public System.Windows.Forms.RadioButton RbRel;
        public System.Windows.Forms.RadioButton RbAbs;
    }
}
