﻿using System;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.ScrewFastening.Ext;
using Calin.ScrewFastening.Models;
using Calin.ScrewFastening.Services;
using Calin.Navigation;

namespace Calin.ScrewFastening.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class MainPage : UserControl
    {
        #region Fields

        private readonly IScrewFastening _lockingMachine;
        private readonly RawData _rawData;
        private readonly BindingData _bindingData;
        private readonly LmData _lmData;

        private readonly Color _belowColor = Color.Transparent;
        private readonly Color _betweenColor = Color.LightGreen;
        private readonly Color _aboveColor = Color.Red;

        private System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();

        // Buffers
        private double _heightDisplacementValue = double.MaxValue;
        private double _heightDisplacementMaxValue = double.MaxValue;
        private double _heightDisplacementFinalValue = double.MaxValue;
        private double _heightDisplacementLimitH = double.MaxValue;
        private double _heightDisplacementLimitL = double.MaxValue;
        private double _torqueValue = double.MaxValue;
        private double _torqueMaxValue = double.MaxValue;
        private double _torqueFinalValue = double.MaxValue;
        private double _torqueLimitH = double.MaxValue;
        private double _torqueLimitL = double.MaxValue;

        #endregion Fields

        public MainPage(IScrewFastening lockingMachine, RawData rawData, BindingData bindingData, LmData lmData)
        {
            _lockingMachine = lockingMachine;
            _rawData = rawData;
            _bindingData = bindingData;
            _lmData = lmData;

            InitializeComponent();

            //indTorqueLimitH.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueLimitH), true);
            //indTorqueLimitL.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueLimitL), true);
            //indTorqueValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueValue), true);
            //indTorqueFinalValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueFinalValue), true);
            //indTorqueMaxValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueMaxValue), true);

            //indTorqueValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.TorqueValue),
            //    nameof(BindingData.TorqueLimitL),
            //    nameof(BindingData.TorqueLimitH),
            //    _betweenColor, _aboveColor, _belowColor);
            //indTorqueFinalValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.TorqueFinalValue),
            //    nameof(BindingData.TorqueLimitL),
            //    nameof(BindingData.TorqueLimitH),
            //    _betweenColor, _aboveColor, _belowColor);
            //indTorqueMaxValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.TorqueMaxValue),
            //    nameof(BindingData.TorqueLimitL),
            //    nameof(BindingData.TorqueLimitH),
            //    _betweenColor, _aboveColor, _belowColor);

            //indHeightDisplacementLimitH.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementLimitH), true);
            //indHeightDisplacementLimitL.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementLimitL), true);
            //indHeightDisplacementValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementValue), true);
            //indHeightDisplacementFinalValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementFinalValue), true);
            //indHeightDisplacementMaxValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementMaxValue), true);

            //indHeightDisplacementValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.HeightDisplacementValue),
            //    nameof(BindingData.HeightDisplacementLimitL),
            //    nameof(BindingData.HeightDisplacementLimitH),
            //    _betweenColor, _aboveColor, _belowColor);
            //indHeightDisplacementFinalValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.HeightDisplacementFinalValue),
            //    nameof(BindingData.HeightDisplacementLimitL),
            //    nameof(BindingData.HeightDisplacementLimitH),
            //    _betweenColor, _aboveColor, _belowColor);
            //indHeightDisplacementMaxValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.HeightDisplacementMaxValue),
            //    nameof(BindingData.HeightDisplacementLimitL),
            //    nameof(BindingData.HeightDisplacementLimitH),
            //    _betweenColor, _aboveColor, _belowColor);

            indHeightDisplacementValue.DataBindings.Clear();
            indHeightDisplacementValue.DataBindings.Add("ThresholdAbove", _bindingData,
                nameof(BindingData.HeightDisplacementLimitH));
            indHeightDisplacementValue.DataBindings.Add("ThresholdBelow", _bindingData,
                nameof(BindingData.HeightDisplacementLimitL));
            indHeightDisplacementMaxValue.DataBindings.Clear();
            indHeightDisplacementMaxValue.DataBindings.Add("ThresholdAbove", _bindingData,
                nameof(BindingData.HeightDisplacementLimitH));
            indHeightDisplacementMaxValue.DataBindings.Add("ThresholdBelow", _bindingData,
                nameof(BindingData.HeightDisplacementLimitL));
            indHeightDisplacementFinalValue.DataBindings.Clear();
            indHeightDisplacementFinalValue.DataBindings.Add("ThresholdAbove", _bindingData,
                nameof(BindingData.HeightDisplacementLimitH));
            indHeightDisplacementFinalValue.DataBindings.Add("ThresholdBelow", _bindingData,
                nameof(BindingData.HeightDisplacementLimitL));

            indTorqueValue.DataBindings.Clear();
            indTorqueValue.DataBindings.Add("ThresholdAbove", _bindingData,
                nameof(BindingData.TorqueLimitH));
            indTorqueValue.DataBindings.Add("ThresholdBelow", _bindingData,
                nameof(BindingData.TorqueLimitL));
            indTorqueMaxValue.DataBindings.Clear();
            indTorqueMaxValue.DataBindings.Add("ThresholdAbove", _bindingData,
                nameof(BindingData.TorqueLimitH));
            indTorqueMaxValue.DataBindings.Add("ThresholdBelow", _bindingData,
                nameof(BindingData.TorqueLimitL));
            indTorqueFinalValue.DataBindings.Clear();
            indTorqueFinalValue.DataBindings.Add("ThresholdAbove", _bindingData,
                nameof(BindingData.TorqueLimitH));
            indTorqueFinalValue.DataBindings.Add("ThresholdBelow", _bindingData,
                nameof(BindingData.TorqueLimitL));

#if DEBUG
            var indHeightDisplacementStopwatch = new Label();
            indHeightDisplacementStopwatch.Font = new Font("Consolas", 9F);
            indHeightDisplacementStopwatch.Location = new Point(7, 112);
            indHeightDisplacementStopwatch.BackColor = Color.Transparent;
            indHeightDisplacementStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementStopwatch), true);
            gbHeightDisplacement.Controls.Add(indHeightDisplacementStopwatch);

            var indTorqueStopwatch = new Label();
            indTorqueStopwatch.Font = new Font("Consolas", 9F);
            indTorqueStopwatch.Location = new Point(7, 112);
            indTorqueStopwatch.BackColor = Color.Transparent;
            indTorqueStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueStopwatch), true);
            gbTorqueMeter.Controls.Add(indTorqueStopwatch);
#endif

            _timer.Interval = _lmData.uiScanTimeInterval;
            _timer.Tick += (async (s, e) =>
            {
                #region 作業狀態

                _bindingData.IsMeasuring = _rawData.IsMeasuring;

                #endregion 作業狀態

                #region 軸卡

                _bindingData.ZAxisCoor = _rawData.ZAxisCoor;
                _bindingData.RPM = _rawData.RPM;
                _bindingData.Angle = _rawData.Angle;

                #endregion 軸卡

                #region 扭力計

                _bindingData.TorqueValue = _rawData.TorqueValue;
                _bindingData.TorqueFinalValue = _rawData.TorqueFinalValue;
                _bindingData.TorqueMaxValue = _rawData.TorqueMaxValue;
                _bindingData.TorqueLimitH = _rawData.TorqueLimitH;
                _bindingData.TorqueLimitL = _rawData.TorqueLimitL;

                #endregion 扭力計

                #region 高度計

                _bindingData.HeightDisplacementValue = _rawData.HeightDisplacementValue;
                _bindingData.HeightDisplacementFinalValue = _rawData.HeightDisplacementFinalValue;
                _bindingData.HeightDisplacementMaxValue = _rawData.HeightDisplacementMaxValue;
                _bindingData.HeightDisplacementLimitH = _rawData.HeightDisplacementLimitH;
                _bindingData.HeightDisplacementLimitL = _rawData.HeightDisplacementLimitL;

                #endregion 高度計

                #region USB4704

                //_bindingData.DI0 = _rawData.DI0;
                //_bindingData.DI1 = _rawData.DI1;
                //_bindingData.DI2 = _rawData.DI2;
                //_bindingData.DI3 = _rawData.DI3;
                //_bindingData.DI4 = _rawData.DI4;
                //_bindingData.DI5 = _rawData.DI5;
                //_bindingData.DI6 = _rawData.DI6;
                //_bindingData.DI7 = _rawData.DI7;

                #endregion USB4704

#if DEBUG
                _bindingData.HeightDisplacementStopwatch = _rawData.HeightDisplacementStopwatch;
                _bindingData.TorqueStopwatch = _rawData.TorqueStopwatch;
#endif

                // HeightDisplacement
                if (_heightDisplacementLimitH != _bindingData.HeightDisplacementLimitH)
                {
                    _heightDisplacementLimitH = _bindingData.HeightDisplacementLimitH;
                    lbHeightDisplacementLimitH.Text = _bindingData.HeightDisplacementLimitH.ToString("F3");
                }
                if (_heightDisplacementLimitL != _bindingData.HeightDisplacementLimitL)
                {
                    _heightDisplacementLimitL = _bindingData.HeightDisplacementLimitL;
                    lbHeightDisplacementLimitL.Text = _bindingData.HeightDisplacementLimitL.ToString("F3");
                }
                if (_heightDisplacementValue != _bindingData.HeightDisplacementValue)
                {
                    _heightDisplacementValue = _bindingData.HeightDisplacementValue;
                    indHeightDisplacementValue.Text = _bindingData.HeightDisplacementValue.ToString("F3");

                    if (_bindingData.HeightDisplacementValue > _bindingData.HeightDisplacementMaxValue)
                        _bindingData.HeightDisplacementMaxValue = _bindingData.HeightDisplacementValue;
                    if (_bindingData.IsMeasuring && (_bindingData.HeightDisplacementValue > _bindingData.HeightDisplacementFinalValue))
                        _bindingData.HeightDisplacementFinalValue = _bindingData.HeightDisplacementValue;

                    if (_bindingData.HeightDisplacementValue >= _bindingData.HeightDisplacementLimitH)
                        indHeightDisplacementValue.BackColor = _aboveColor;
                    else if (_bindingData.HeightDisplacementValue <= _bindingData.HeightDisplacementLimitL)
                        indHeightDisplacementValue.BackColor = _belowColor;
                    else if (indHeightDisplacementValue.BackColor != _betweenColor)
                        indHeightDisplacementValue.BackColor = _betweenColor;
                }
                if (_heightDisplacementMaxValue != _bindingData.HeightDisplacementMaxValue)
                {
                    _heightDisplacementMaxValue = _bindingData.HeightDisplacementMaxValue;
                    indHeightDisplacementMaxValue.Text = _bindingData.HeightDisplacementMaxValue.ToString("F3");

                    if (_bindingData.HeightDisplacementMaxValue >= _bindingData.HeightDisplacementLimitH)
                        indHeightDisplacementMaxValue.BackColor = _aboveColor;
                    else if (_bindingData.HeightDisplacementMaxValue <= _bindingData.HeightDisplacementLimitL)
                        indHeightDisplacementMaxValue.BackColor = _belowColor;
                    else if (indHeightDisplacementMaxValue.BackColor != _betweenColor)
                        indHeightDisplacementMaxValue.BackColor = _betweenColor;
                }
                if (_heightDisplacementFinalValue != _bindingData.HeightDisplacementFinalValue)
                {
                    _heightDisplacementFinalValue = _bindingData.HeightDisplacementFinalValue;
                    indHeightDisplacementFinalValue.Text = _bindingData.HeightDisplacementFinalValue.ToString("F3");

                    if (_bindingData.HeightDisplacementFinalValue >= _bindingData.HeightDisplacementLimitH)
                        indHeightDisplacementFinalValue.BackColor = _aboveColor;
                    else if (_bindingData.HeightDisplacementFinalValue <= _bindingData.HeightDisplacementLimitL)
                        indHeightDisplacementFinalValue.BackColor = _belowColor;
                    else if (indHeightDisplacementFinalValue.BackColor != _betweenColor)
                        indHeightDisplacementFinalValue.BackColor = _betweenColor;
                }

                // Torque
                if (_torqueLimitH != _bindingData.TorqueLimitH)
                {
                    _torqueLimitH = _bindingData.TorqueLimitH;
                    lbTorqueLimitH.Text = _bindingData.TorqueLimitH.ToString("F3");
                }
                if (_torqueLimitL != _bindingData.TorqueLimitL)
                {
                    _torqueLimitL = _bindingData.TorqueLimitL;
                    lbTorqueLimitL.Text = _bindingData.TorqueLimitL.ToString("F3");
                }
                if (_torqueValue != _bindingData.TorqueValue)
                {
                    _torqueValue = _bindingData.TorqueValue;
                    indTorqueValue.Text = _bindingData.TorqueValue.ToString("F3");

                    if (_bindingData.TorqueValue > _bindingData.TorqueMaxValue)
                        _bindingData.TorqueMaxValue = _bindingData.TorqueValue;
                    if (_bindingData.IsMeasuring && (_bindingData.TorqueValue > _bindingData.TorqueFinalValue))
                        _bindingData.TorqueFinalValue = _bindingData.TorqueValue;

                    if (_bindingData.TorqueValue >= _bindingData.TorqueLimitH)
                        indTorqueValue.BackColor = _aboveColor;
                    else if (_bindingData.TorqueValue <= _bindingData.TorqueLimitL)
                        indTorqueValue.BackColor = _belowColor;
                    else if (indTorqueValue.BackColor != _betweenColor)
                        indTorqueValue.BackColor = _betweenColor;
                }
                if (_torqueMaxValue != _bindingData.TorqueMaxValue)
                {
                    _torqueMaxValue = _bindingData.TorqueMaxValue;
                    indTorqueMaxValue.Text = _bindingData.TorqueMaxValue.ToString("F3");

                    if (_bindingData.TorqueMaxValue >= _bindingData.TorqueLimitH)
                        indTorqueMaxValue.BackColor = _aboveColor;
                    else if (_bindingData.TorqueMaxValue <= _bindingData.TorqueLimitL)
                        indTorqueMaxValue.BackColor = _belowColor;
                    else if (indTorqueMaxValue.BackColor != _betweenColor)
                        indTorqueMaxValue.BackColor = _betweenColor;
                }
                if (_torqueFinalValue != _bindingData.TorqueFinalValue)
                {
                    _torqueFinalValue = _bindingData.TorqueFinalValue;
                    indTorqueFinalValue.Text = _bindingData.TorqueFinalValue.ToString("F3");

                    if (_bindingData.TorqueFinalValue >= _bindingData.TorqueLimitH)
                        indTorqueFinalValue.BackColor = _aboveColor;
                    else if (_bindingData.TorqueFinalValue <= _bindingData.TorqueLimitL)
                        indTorqueFinalValue.BackColor = _belowColor;
                    else if (indTorqueFinalValue.BackColor != _betweenColor)
                        indTorqueFinalValue.BackColor = _betweenColor;
                }

#if DEBUG
                indHeightDisplacementStopwatch.Text = _bindingData.HeightDisplacementStopwatch.ToString("F3");
                indTorqueStopwatch.Text = _bindingData.TorqueStopwatch.ToString("F3");

                //var indTorqueStopwatch = new Label();
                //indTorqueStopwatch.Font = new Font("Consolas", 9F);
                //indTorqueStopwatch.Location = new Point(7, 121);
                //indTorqueStopwatch.BackColor = Color.Transparent;
                //indTorqueStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                //    nameof(BindingData.TorqueStopwatch), true);
                //gbTorqueMeter.Controls.Add(indTorqueStopwatch);
#endif

                await Task.CompletedTask;
            });
            _timer.Start();
        }

        private void cbIsMeasuring_Click(object sender, EventArgs e)
        {
            //var check = !cbIsMeasuring.Checked;
            //cbIsMeasuring.Checked = check;
            _rawData.IsMeasuring = cbIsMeasuring.Checked;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            _lockingMachine.ClearMeasureData();
        }

        private void btnTest1_Click(object sender, EventArgs e)
        {
            _lockingMachine.DaqStartAcquisition();
        }

        private void btnTest2_Click(object sender, EventArgs e)
        {
            _lockingMachine.DaqStopAcquisition();
        }
    }
}
