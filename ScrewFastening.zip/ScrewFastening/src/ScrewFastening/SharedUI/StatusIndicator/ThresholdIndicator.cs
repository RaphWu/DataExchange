﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.ScrewFastening.SharedUI.StatusIndicator
{
    public enum ComparisonType
    {
        GreaterThan,
        GreaterThanOrEqual,
        LessThan,
        LessThanOrEqual
    }

    [DefaultProperty(nameof(Value))]
    public class ThresholdIndicator : UserControl
    {
        private readonly Label _label;

        private Font _scaledFont;
        private string _lastText;
        private Size _lastSize;
        private Font _lastBaseFont;

        public ThresholdIndicator()
        {
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw |
                ControlStyles.UserPaint,
                true);

            _label = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter
            };

            Controls.Add(_label);

            Size = new Size(60, 25);
            BorderStyle = BorderStyle.FixedSingle;
            TabStop = false;
        }

        private double _value;
        [Category("Data")]
        public double Value
        {
            get => _value;
            set
            {
                if (_value == value) return;
                _value = value;
                UpdateDisplay();
            }
        }

        private int _decimalPlaces = 3;
        [Category("Appearance")]
        public int DecimalPlaces
        {
            get => _decimalPlaces;
            set
            {
                if (_decimalPlaces == value) return;
                _decimalPlaces = Math.Max(0, value);
                UpdateDisplay();
            }
        }

        private double _thresholdAbove = 100;
        [Category("Behavior")]
        public double ThresholdAbove
        {
            get => _thresholdAbove;
            set
            {
                if (_thresholdAbove == value) return;
                _thresholdAbove = value;
                UpdateDisplay();
            }
        }

        private double _thresholdBelow;
        [Category("Behavior")]
        public double ThresholdBelow
        {
            get => _thresholdBelow;
            set
            {
                if (_thresholdBelow == value) return;
                _thresholdBelow = value;
                UpdateDisplay();
            }
        }

        private ComparisonType _aboveComparison = ComparisonType.GreaterThan;
        [Category("Behavior")]
        public ComparisonType AboveComparison
        {
            get => _aboveComparison;
            set
            {
                if (_aboveComparison == value) return;
                _aboveComparison = value;
                UpdateDisplay();
            }
        }

        private ComparisonType _belowComparison = ComparisonType.LessThan;
        [Category("Behavior")]
        public ComparisonType BelowComparison
        {
            get => _belowComparison;
            set
            {
                if (_belowComparison == value) return;
                _belowComparison = value;
                UpdateDisplay();
            }
        }

        [Category("Appearance")]
        public Color AboveBackColor { get; set; } = Color.Firebrick;

        [Category("Appearance")]
        public Color AboveForeColor { get; set; } = Color.White;

        [Category("Appearance")]
        public Color BetweenBackColor { get; set; } = Color.LimeGreen;

        [Category("Appearance")]
        public Color BetweenForeColor { get; set; } = Color.Black;

        [Category("Appearance")]
        public Color BelowBackColor { get; set; } = Color.Gainsboro;

        [Category("Appearance")]
        public Color BelowForeColor { get; set; } = Color.Black;

        private Color _borderColor = Color.Black;
        [Category("Appearance")]
        public Color BorderColor
        {
            get => _borderColor;
            set
            {
                if (_borderColor == value) return;
                _borderColor = value;
                Invalidate();
            }
        }

        private bool _autoScaleText;
        [Category("Appearance")]
        public bool AutoScaleText
        {
            get => _autoScaleText;
            set
            {
                if (_autoScaleText == value) return;
                _autoScaleText = value;
                ClearFontCache();
                UpdateDisplay();
            }
        }

        public override Font Font
        {
            get => base.Font;
            set
            {
                if (Equals(base.Font, value)) return;
                base.Font = value;
                ClearFontCache();
                UpdateDisplay();
            }
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            ClearFontCache();
            UpdateDisplay();
        }

        private void UpdateDisplay()
        {
            if (IsDisposed) return;

            string text = Value.ToString($"F{DecimalPlaces}");
            _label.Text = text;

            bool isAbove = _aboveComparison == ComparisonType.GreaterThan
                ? Value > ThresholdAbove
                : Value >= ThresholdAbove;

            bool isBelow = _belowComparison == ComparisonType.LessThan
                ? Value < ThresholdBelow
                : Value <= ThresholdBelow;

            if (isAbove)
            {
                _label.BackColor = AboveBackColor;
                _label.ForeColor = AboveForeColor;
            }
            else if (isBelow)
            {
                _label.BackColor = BelowBackColor;
                _label.ForeColor = BelowForeColor;
            }
            else
            {
                _label.BackColor = BetweenBackColor;
                _label.ForeColor = BetweenForeColor;
            }

            ApplyFont(text);
        }

        private void ApplyFont(string text)
        {
            if (!AutoScaleText)
            {
                _label.Font = base.Font;
                return;
            }

            if (_scaledFont != null &&
                text == _lastText &&
                _label.ClientSize == _lastSize &&
                base.Font == _lastBaseFont)
            {
                _label.Font = _scaledFont;
                return;
            }

            _scaledFont?.Dispose();
            _scaledFont = CreateAutoScaledFont(text, _label.ClientSize, base.Font);

            _lastText = text;
            _lastSize = _label.ClientSize;
            _lastBaseFont = base.Font;

            _label.Font = _scaledFont;
        }

        private static Font CreateAutoScaledFont(string text, Size bounds, Font baseFont)
        {
            float min = 4f;
            float max = baseFont.Size;
            float best = min;

            using (Graphics g = Graphics.FromHwnd(IntPtr.Zero))
            {
                while (min <= max)
                {
                    float mid = (min + max) / 2f;
                    using (var testFont = new Font(baseFont.FontFamily, mid, baseFont.Style))
                    {
                        Size size = TextRenderer.MeasureText(g, text, testFont);
                        if (size.Width <= bounds.Width && size.Height <= bounds.Height)
                        {
                            best = mid;
                            min = mid + 0.5f;
                        }
                        else
                        {
                            max = mid - 0.5f;
                        }
                    }
                }
            }

            return new Font(baseFont.FontFamily, best, baseFont.Style);
        }

        private void ClearFontCache()
        {
            _scaledFont?.Dispose();
            _scaledFont = null;
            _lastText = null;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using (var pen = new Pen(BorderColor))
            {
                e.Graphics.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _scaledFont?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
