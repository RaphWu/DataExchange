﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.ScrewFastening.SharedUI
{
    /// <summary>
    /// 分隔線控制項。
    /// </summary>
    /// <remarks>依 Dock 自動判斷水平或垂直顯示一條細線分隔區域。</remarks>
    public class Separator : Control
    {
        private const int Thickness = 2;

        public Separator()
        {
            SetStyle(
                ControlStyles.UserPaint |
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.Opaque,
                true);

            TabStop = false;
            Dock = DockStyle.Top;
            Height = Thickness;
        }

        protected override void OnDockChanged(EventArgs e)
        {
            base.OnDockChanged(e);
            FixSize();
            Invalidate();
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            FixSize();
        }

        private void FixSize()
        {
            switch (Dock)
            {
                case DockStyle.Left:
                case DockStyle.Right:
                    Width = Thickness;
                    break;

                case DockStyle.Top:
                case DockStyle.Bottom:
                default:
                    Height = Thickness;
                    break;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;

            using (var dark = new Pen(SystemColors.ControlDark))
            using (var light = new Pen(SystemColors.ControlLightLight))
            {
                if (Dock == DockStyle.Left || Dock == DockStyle.Right)
                {
                    // 垂直線
                    g.DrawLine(dark, 0, 0, 0, Height - 1);
                    g.DrawLine(light, 1, 0, 1, Height - 1);
                }
                else
                {
                    // 水平線
                    g.DrawLine(dark, 0, 0, Width - 1, 0);
                    g.DrawLine(light, 0, 1, Width - 1, 1);
                }
            }
        }
    }
}
