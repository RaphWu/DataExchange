﻿# Calin.DAQ.USB4704

`Calin.DAQ.USB4704` 是一個用於與 Advantech USB-4704 數據採集 (Data Acquisition) 設備進行通訊與數位 I/O 操作的 .NET 類別庫。

- 多目標框架：`net462` / `net48` / `net8.0`
- 以 Advantech DAQNavi / BDaq API（`Automation.BDaq4.dll`）存取硬體
- 支援 Autofac 依賴注入

## 系統需求 / 前置作業

1. 已安裝 Advantech DAQNavi（或包含 `Automation.BDaq4.dll` 的相依元件）。
2. 已連接 USB-4704，並確認在 DAQNavi/Device Manager 中可辨識。
3. 應用程式需能找到 `Automation.BDaq4.dll`（本專案以本機參考 `Reference` 方式引入）。

> 注意：本庫本身不會透過 NuGet 自動下載 Advantech 的 `Automation.BDaq4.dll`；你必須自行確保 DLL 可被建置與部署。

## 相依套件（依 `Calin.DAQ.USB4704.csproj` 整理）

### 目標框架（TargetFrameworks）

- `net462;net48;net8.0`

### NuGet 套件（PackageReference）

| 套件名稱                 | 版本    | 說明                        |
| -------------------- | ----- | ------------------------- |
| `Calin.Abstractions` | 0.0.2 | 共用介面/型別（含 `ICalinLogger`） |
| `Calin.SerialPort`   | 0.0.6 | 串列埠通訊功能                   |
| `Autofac`            | 9.0.0 | 依賴注入容器（選用）                |

### 本機參考（Reference）

- `Automation.BDaq4`：Advantech DAQNavi / BDaq 主要 API（透過 `HintPath` 指向工作區內的 DLL）。

## 專案結構

```
Calin.DAQ.USB4704/
├── IUsb4704.cs                  # USB4704 服務介面（SerialPort 通訊）
├── IUsb4704Dio.cs               # USB4704 DIO 介面（BDaq API）
├── IUsb4704ServiceFactory.cs    # 服務工廠介面
├── Usb4704Config.cs             # 設定類別
├── Usb4704Dio.cs                # DIO 實作（BDaq API）
├── Usb4704Service.cs            # 服務實作（SerialPort 通訊）
├── Usb4704ServiceFactory.cs     # 服務工廠實作
├── Usb4704Module.cs             # Autofac 模組
├── Usb4704Response.cs           # 回應資料類別
├── Usb4704ResponseEventArgs.cs  # 回應事件參數
├── Usb4704ErrorEventArgs.cs     # 錯誤事件參數
└── Usb4704Streaming.cs          # 串流功能（保留）
```

## 快速開始

### 1) 參考此專案 / 套件

- 若在同一個 solution：直接以專案參考加入 `Calin.DAQ.USB4704`。
- 若以 NuGet 形式使用：請引用你們建置出的套件，並同時確保目標機器具備 `Automation.BDaq4.dll`。

### 2) 初始化裝置

使用 `Usb4704Dio.Usb4704DioInit(deviceCode)` 初始化，其中 `deviceCode` 會傳入 `new DeviceInformation(deviceCode)`。
常見格式類似：`"USB-4704,BID#0"`（實際字串以 DAQNavi 的裝置列表為準）。

### 3) 讀寫數位 I/O

- 讀取整個 port：`ReadDigital(port, out byte data)`
- 寫入整個 port：`WriteDigital(port, byte data)`
- 讀取單一 bit：`ReadDigitalBit(port, bitPos, out byte bitValue)`
- 寫入單一 bit：`WriteDigitalBit(port, bitPos, byte bitValue)`

## 設定類別 `Usb4704Config`

| 屬性             | 類型         | 預設值                | 說明                          |
| -------------- | ---------- | ------------------ | --------------------------- |
| `DeviceCode`   | `string`   | `"USB-4704,BID#0"` | 裝置代碼（ProductID,BID#BoardID） |
| `PortName`     | `string`   | `"COM1"`           | COM Port 名稱                 |
| `BaudRate`     | `int`      | `19200`            | 鮑率                          |
| `DataBits`     | `int`      | `8`                | 資料位元數                       |
| `Parity`       | `Parity`   | `None`             | 同位位元                        |
| `StopBits`     | `StopBits` | `One`              | 停止位元                        |
| `ReadTimeout`  | `int`      | `1000`             | 讀取逾時（毫秒）                    |
| `WriteTimeout` | `int`      | `1000`             | 寫入逾時（毫秒）                    |

## 使用範例

以下範例示範：初始化 → 讀取 DI → 寫入 DO。日誌介面 `ICalinLogger` 來自 `Calin.Abstractions`；實務上請用你在系統中既有的 logger 實作（例如你們的 NLog/Serilog 包裝）。

### 範例 1：直接使用 `Usb4704Dio`（BDaq API）

```csharp
using System;
using Automation.BDaq;
using Calin.Abstractions.Logging;
using Calin.DAQ.USB4704;

class Program
{
    static void Main()
    {
        // 使用你專案中的 ICalinLogger 實作
        ICalinLogger logger = GetLogger(); // 例如 NLogCalinLogger, SerilogCalinLogger 等

        using var dio = new Usb4704Dio(logger);

        // deviceCode 請依 DAQNavi 實際顯示為準
        if (!dio.Usb4704DioInit("USB-4704,BID#0"))
        {
            Console.WriteLine("USB-4704 初始化失敗");
            return;
        }

        // 讀取 DI (port 0)
        ErrorCode ec = dio.ReadDigital(0, out byte di);
        if (ec != ErrorCode.Success)
        {
            Console.WriteLine($"ReadDigital failed: {ec}");
            return;
        }

        Console.WriteLine($"DI port0 = 0x{di:X2}");

        // 寫入 DO (port 0) - 範例：翻轉第 0 bit
        byte doData = (byte)(di ^ 0x01);
        ec = dio.WriteDigital(0, doData);
        if (ec != ErrorCode.Success)
        {
            Console.WriteLine($"WriteDigital failed: {ec}");
            return;
        }

        Console.WriteLine($"DO port0 <= 0x{doData:X2}");
    }

    static ICalinLogger GetLogger()
    {
        // 請替換為你專案中的 logger 實作
        throw new NotImplementedException();
    }
}
```

### 範例 2：使用工廠 `Usb4704ServiceFactory`（SerialPort 通訊）

`Usb4704ServiceFactory` 用於建立 `IUsb4704` 服務實例，適用於需要透過 SerialPort 進行通訊的場景。

```csharp
using System;
using Calin.DAQ.USB4704;
using Calin.SerialPort;

class Program
{
    static void Main()
    {
        // 建立 SerialPort 工廠
        var serialPortFactory = new SerialPortServiceFactory();

        // 建立 USB4704 工廠
        var factory = new Usb4704ServiceFactory(serialPortFactory);

        // 設定
        var config = new Usb4704Config
        {
            DeviceCode = "USB-4704,BID#0",
            PortName = "COM3",
            BaudRate = 19200,
            DataBits = 8,
            Parity = Parity.None,
            StopBits = StopBits.One,
            ReadTimeout = 1000,
            WriteTimeout = 1000,
        };

        // 建立並開啟連線
        using IUsb4704 usb4704 = factory.CreateAndOpen(config);

        Console.WriteLine($"Connected: {usb4704.IsConnected}");

        // 訂閱事件
        usb4704.ResponseReceived += (sender, e) =>
        {
            Console.WriteLine($"Response: {e.Response.RawData}");
        };

        usb4704.ErrorOccurred += (sender, e) =>
        {
            Console.WriteLine($"Error: {e.ErrorMessage}");
        };

        // ... 進行通訊操作 ...
    }
}
```

### 範例 3：使用 Autofac 依賴注入（推薦）

本專案提供 `Usb4704Module`，可快速完成 Autofac 註冊。

#### 3.1 使用 `Usb4704Module` 快速註冊

```csharp
using Autofac;
using Calin.Abstractions.Logging;
using Calin.DAQ.USB4704;

class Program
{
    static void Main()
    {
        var builder = new ContainerBuilder();

        // 註冊你的 Logger（必須）
        builder.RegisterInstance(yourLogger).As<ICalinLogger>();

        // 使用 Usb4704Module 快速註冊所有服務
        // 會自動註冊：
        // - ISerialPortServiceFactory (SingleInstance)
        // - IUsb4704ServiceFactory (SingleInstance)
        // - IUsb4704Dio (InstancePerDependency)
        builder.RegisterModule<Usb4704Module>();

        var container = builder.Build();

        // 取得 DIO 服務
        using var dio = container.Resolve<IUsb4704Dio>();
        dio.Usb4704DioInit("USB-4704,BID#0");

        // 或取得工廠建立 SerialPort 服務
        var factory = container.Resolve<IUsb4704ServiceFactory>();
        var config = new Usb4704Config
        {
            DeviceCode = "USB-4704,BID#0",
            PortName = "COM3",
        };
        using var usb4704 = factory.CreateAndOpen(config);
    }
}
```

#### 3.2 手動註冊（細粒度控制）

```csharp
using Autofac;
using Calin.Abstractions.Logging;
using Calin.DAQ.USB4704;
using Calin.SerialPort;

class Program
{
    static void Main()
    {
        var builder = new ContainerBuilder();

        // 註冊 Logger
        builder.RegisterInstance(yourLogger).As<ICalinLogger>();

        // 註冊 SerialPort 工廠
        builder.RegisterType<SerialPortServiceFactory>()
               .As<ISerialPortServiceFactory>()
               .SingleInstance();

        // 註冊 USB4704 服務工廠
        builder.RegisterType<Usb4704ServiceFactory>()
               .As<IUsb4704ServiceFactory>()
               .SingleInstance();

        // 註冊 USB4704 DIO（每次解析都建立新實例）
        builder.RegisterType<Usb4704Dio>()
               .As<IUsb4704Dio>()
               .InstancePerDependency();

        var container = builder.Build();

        // 使用服務
        var dioFactory = container.Resolve<IUsb4704ServiceFactory>();
        var dio = container.Resolve<IUsb4704Dio>();
    }
}
```

#### 3.3 WinForms / WPF 應用程式整合範例

```csharp
using System;
using System.Windows.Forms;
using Autofac;
using Calin.Abstractions.Logging;
using Calin.DAQ.USB4704;

static class Program
{
    public static IContainer Container { get; private set; }

    [STAThread]
    static void Main()
    {
        // 建立 DI 容器
        var builder = new ContainerBuilder();

        // 註冊 Logger
        builder.RegisterInstance(new YourCalinLogger()).As<ICalinLogger>();

        // 註冊 USB4704 模組
        builder.RegisterModule<Usb4704Module>();

        // 註冊 Form
        builder.RegisterType<MainForm>().AsSelf();

        Container = builder.Build();

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        using (var scope = Container.BeginLifetimeScope())
        {
            var mainForm = scope.Resolve<MainForm>();
            Application.Run(mainForm);
        }
    }
}

public partial class MainForm : Form
{
    private readonly IUsb4704Dio _dio;
    private readonly IUsb4704ServiceFactory _factory;

    public MainForm(IUsb4704Dio dio, IUsb4704ServiceFactory factory)
    {
        _dio = dio;
        _factory = factory;
        InitializeComponent();
    }

    private void MainForm_Load(object sender, EventArgs e)
    {
        // 初始化 DIO
        if (!_dio.Usb4704DioInit("USB-4704,BID#0"))
        {
            MessageBox.Show("USB-4704 初始化失敗");
        }
    }
}
```

## `Usb4704Module` 註冊內容

`Usb4704Module` 會自動註冊以下服務：

| 介面                          | 實作                         | 生命週期                    |
| --------------------------- | -------------------------- | ----------------------- |
| `ISerialPortServiceFactory` | `SerialPortServiceFactory` | `SingleInstance`（如尚未註冊） |
| `IUsb4704ServiceFactory`    | `Usb4704ServiceFactory`    | `SingleInstance`        |
| `IUsb4704Dio`               | `Usb4704Dio`               | `InstancePerDependency` |

## 常見問題

### `Usb4704DioInit` 失敗

- 確認 DAQNavi 是否有安裝、裝置是否存在。
- 確認 `deviceCode` 是否正確（格式：`"ProductID,BID#BoardID"`）。
- 確認程式執行環境可載入 `Automation.BDaq4.dll`。

### `CreateAndOpen` 拋出 `InvalidOperationException`

- 確認 COM Port 名稱是否正確。
- 確認 COM Port 沒有被其他程式占用。
- 確認 USB-4704 裝置已正確連接。

### Autofac 解析失敗

- 確認已註冊 `ICalinLogger`（`Usb4704Dio` 建構子需要）。
- 確認已註冊 `Usb4704Module` 或手動註冊所有必要服務。

## 版本歷史

### v0.0.3

2026.01.29

- 完成 Streaming 實作。
- NuGet 包已內含 `Automation.BDaq4.dll`（透過本機參考方式引入）。

### v0.0.2

2026.01.26

- 移除 Caln.SerialPort 依賴
- 提供 Autofac 模組（`Usb4704Module`）
- 支援數位輸入（DI）與數位輸出（DO）功能

### v0.0.1

2026.01.23

- 初始版本

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
