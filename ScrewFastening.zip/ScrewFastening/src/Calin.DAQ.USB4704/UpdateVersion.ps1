﻿param(
	[string]$currentVersion,
	[string]$filePath
)

# 取得 version.txt 的路徑
$versionFile = "$PSScriptRoot\version.txt"

# 解析版本號
$parts = $currentVersion -split "\."
$major = [int]$parts[0]
$minor = [int]$parts[1]
$patch = [int]$parts[2]

# 版本號遞增邏輯
$patch++
$newVersion = "$major.$minor.$patch"

# 更新 AssemblyInfo.cs
$content = Get-Content $filePath
$content = $content -replace '\[assembly: AssemblyVersion\(".*?"\)\]', "[assembly: AssemblyVersion(`"$newVersion`")]"
$content = $content -replace '\[assembly: AssemblyFileVersion\(".*?"\)\]', "[assembly: AssemblyFileVersion(`"$newVersion`")]"
Set-Content -Path $filePath -Value $content

# 更新 .csproj
if (Test-Path $csprojFilePath) {
    Write-Host "Updating .csproj version..."
    $csprojContent = Get-Content $csprojFilePath

    if ($csprojContent -match '<Version>.*?</Version>') {
        $csprojContent = $csprojContent -replace '<Version>.*?</Version>', "<Version>$newVersion</Version>"
    } else {
        # 若找不到 Version 節點，插入一個
        $csprojContent = $csprojContent -replace '</PropertyGroup>', "  <Version>$newVersion</Version>`n</PropertyGroup>"
    }

    Set-Content -Path $csprojFilePath -Value $csprojContent
}

# 更新 version.txt
Set-Content -Path $versionFile -Value $newVersion

Write-Output $newVersion
