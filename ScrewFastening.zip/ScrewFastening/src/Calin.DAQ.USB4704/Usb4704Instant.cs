﻿using System;
using System.Diagnostics;
using System.Threading;
using Automation.BDaq;
using Calin.Logging.Abstractions;
using Microsoft.Extensions.Logging;

namespace Calin.DAQ.USB4704
{
    public class Usb4704Instant : IUsb4704Instant
    {
        #region Fields

        private readonly ILogger<Usb4704Instant> _logger = LoggingBridge.CreateLogger<Usb4704Instant>();
        private InstantAiCtrl _instantAiCtrl = new InstantAiCtrl();

        private int _channelCountMax;
        private double _dataScaled;

        private readonly Stopwatch _instantStopwatch = new Stopwatch();
        private CancellationTokenSource _cts;

        #endregion Fields

        #region Events

        public event EventHandler DataReady = null;

        #endregion Events

        #region Properties

        public int ChannelCountMax => _channelCountMax;

        #endregion Properties

        #region ctor

        public Usb4704Instant()
        {
        }

        #endregion ctor

        #region Methods

        public bool Usb4704InstantInit(string deviceCode = "")
        {
            if (string.IsNullOrWhiteSpace(deviceCode))
                deviceCode = "DemoDevice,BID#0";

            _instantAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
            if (!_instantAiCtrl.Initialized)
            {
                _logger.LogWarning($"裝置開啟失敗：{nameof(Usb4704InstantInit)}");
                _instantAiCtrl.Dispose();
                return false;
            }

            _channelCountMax = _instantAiCtrl.Features.ChannelCountMax;
            return true;
        }

        /// <inheritdoc/>
        public void Dispose()
        {
            _instantAiCtrl.Dispose();
            GC.SuppressFinalize(this);
        }

        /// <inheritdoc/>
        public void SetSignalType(int ch, AiSignalType signalType)
        {
            _instantAiCtrl.Channels[ch].SignalType = signalType;
        }

        /// <inheritdoc/>
        public void SetValueRange(int ch, ValueRange valueRange)
        {
            _instantAiCtrl.Channels[ch].ValueRange = valueRange;
        }

        /// <inheritdoc/>
        public ErrorCode ReadInstantData(int channel, out double instantData)
        {
            if (channel > _channelCountMax)
                channel = 0;
            ErrorCode err = _instantAiCtrl.Read(channel, out instantData);
            if (err != ErrorCode.Success)
                HandleError(err);
            return err;
        }

        #endregion Methods

        #region Private Methods

        private void HandleError(ErrorCode err)
        {
            if ((err >= ErrorCode.ErrorHandleNotValid) && (err != ErrorCode.Success))
                _logger.LogError(String.Concat("USB-4704異常！錯誤碼：0x", ((int)err).ToString("X8")));
        }

        #endregion Private Methods
    }
}
