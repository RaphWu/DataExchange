﻿namespace Calin.DAQ.USB4704
{
    public interface IUsb4704Dio
    {
        #region DIO

        /// <summary>
        /// 初始化 USB-4704 的數位輸入埠。
        /// </summary>
        /// <param name="deviceCode">裝置代碼。</param>
        /// <returns>初始化是否成功。</returns>
        bool Usb4704DioInit(string deviceCode = "");

        /// <summary>
        /// 釋放資源。
        /// </summary>
        void Dispose();

        #endregion DIO

        #region Digital Input

        /// <summary>
        /// 讀取指定埠的數位輸入值。
        /// </summary>
        /// <param name="port">埠號。</param>
        /// <param name="data">讀取到的數位輸入值。</param>
        /// <returns>錯誤代碼。</returns>
        bool ReadDigital(int port, out byte data);

        /// <summary>
        /// 讀取指定埠和位元位置的數位輸入位元值。
        /// </summary>
        /// <param name="port">埠號。</param>
        /// <param name="bitPos">位元位置。</param>
        /// <param name="bitValue">讀取到的數位輸入位元值。</param>
        /// <returns>錯誤代碼。</returns>
        bool ReadDigitalBit(int port, int bitPos, out byte bitValue);

        #endregion Digital Input

        #region Digital Output

        /// <summary>
        /// 寫入指定埠的數位輸出值。
        /// </summary>
        /// <param name="port">埠號。</param>
        /// <param name="data">數位輸出值。</param>
        /// <returns>錯誤代碼。</returns>
        bool WriteDigital(int port, byte data);

        /// <summary>
        /// 寫入指定埠和位元位置的數位輸出位元值。
        /// </summary>
        /// <param name="port">埠號。</param>
        /// <param name="bitPos">位元位置。</param>
        /// <param name="bitValue">數位輸出位元值。</param>
        /// <returns>錯誤代碼。</returns>
        bool WriteDigitalBit(int port, int bitPos, byte bitValue);

        #endregion Digital Output
    }
}