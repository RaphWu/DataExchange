﻿using Calin.Comm.DL_RS1A;
using Calin.MVVM;

namespace Calin.ScrewFastening.Models
{
    /// <summary>
    /// DL-RS1A 資料模型。
    /// </summary>
    /// <remarks>DL-RS1A 設定，會儲存成 .JSON 檔。</remarks>
    public class Dlrs1aData : ObservableObject
    {
        #region DL-RS1A 設定

        public DL_RS1A_Config Dlrs1aConfig { get; set; } = new DL_RS1A_Config();

        #endregion DL-RS1A 設定

        #region 高度計

        /// <summary>
        /// 高度計是否啟用。
        /// </summary>
        public bool HeightDisplacementActive
        {
            get { return _heightDisplacementActive; }
            set { SetProperty(ref _heightDisplacementActive, value); }
        }
        private bool _heightDisplacementActive = false;

        /// <summary>
        /// 高度計讀數。
        /// </summary>
        public double HeightDisplacementValue
        {
            get { return _heightDisplacementValue; }
            set { SetProperty(ref _heightDisplacementValue, value); }
        }
        private double _heightDisplacementValue;

        /// <summary>
        /// 高度計最終值。
        /// </summary>
        public double HeightDisplacementFinalValue
        {
            get { return _heightDisplacementFinalValue; }
            set { SetProperty(ref _heightDisplacementFinalValue, value); }
        }
        private double _heightDisplacementFinalValue;

        /// <summary>
        /// 高度計最大值。
        /// </summary>
        public double HeightDisplacementMaxValue
        {
            get { return _heightDisplacementMaxValue; }
            set { SetProperty(ref _heightDisplacementMaxValue, value); }
        }
        private double _heightDisplacementMaxValue;

        /// <summary>
        /// 高度計上限值。
        /// </summary>
        public double HeightDisplacementLimitH
        {
            get { return _heightDisplacementLimitH; }
            set { SetProperty(ref _heightDisplacementLimitH, value); }
        }
        private double _heightDisplacementLimitH = 20.0;

        /// <summary>
        /// 高度計下限值。
        /// </summary>
        public double HeightDisplacementLimitL
        {
            get { return _heightDisplacementLimitL; }
            set { SetProperty(ref _heightDisplacementLimitL, value); }
        }
        private double _heightDisplacementLimitL = 10.0;

        #endregion 高度計 

#if DEBUG
        /// <summary>
        /// 高度計碼表讀取時間。
        /// </summary>
        public double HeightDisplacementStopwatch
        {
            get { return _heightDisplacementStopwatch; }
            set { SetProperty(ref _heightDisplacementStopwatch, value); }
        }
        private double _heightDisplacementStopwatch;

        public int WaitForReceiveHeightDisplacement = 0;
#endif
    }
}
