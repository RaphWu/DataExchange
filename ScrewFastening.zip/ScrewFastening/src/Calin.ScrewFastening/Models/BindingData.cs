﻿using Calin.MVVM;

namespace Calin.ScrewFastening.Models
{
    /// <summary>
    /// 綁定資料模型。
    /// </summary>
    /// <remarks>UI顯示用資料。</remarks>
    public class BindingData : ObservableObject
    {
        #region 作業狀態

        /// <summary>
        /// 量測中。
        /// </summary>
        public bool IsMeasuring
        {
            get { return _isMeasuring; }
            set { SetProperty(ref _isMeasuring, value); }
        }
        private bool _isMeasuring = false;

        #endregion 作業狀態

        #region 扭力計

        #endregion 扭力計

        #region USB4704

        /// <summary>
        /// DAQ I/O 是否啟用。
        /// </summary>
        public bool DaqIoActive
        {
            get { return _daqIoActive; }
            set { SetProperty(ref _daqIoActive, value); }
        }
        private bool _daqIoActive = false;

        //public bool DI0
        //{
        //    get { return _di0; }
        //    set { SetProperty(ref _di0, value); }
        //}
        //private bool _di0;

        //public bool DI1
        //{
        //    get { return _di1; }
        //    set { SetProperty(ref _di1, value); }
        //}
        //private bool _di1;

        //public bool DI2
        //{
        //    get { return _di2; }
        //    set { SetProperty(ref _di2, value); }
        //}
        //private bool _di2;

        //public bool DI3
        //{
        //    get { return _di3; }
        //    set { SetProperty(ref _di3, value); }
        //}
        //private bool _di3;

        //public bool DI4
        //{
        //    get { return _di4; }
        //    set { SetProperty(ref _di4, value); }
        //}
        //private bool _di4;

        //public bool DI5
        //{
        //    get { return _di5; }
        //    set { SetProperty(ref _di5, value); }
        //}
        //private bool _di5;

        //public bool DI6
        //{
        //    get { return _di6; }
        //    set { SetProperty(ref _di6, value); }
        //}
        //private bool _di6;

        //public bool DI7
        //{
        //    get { return _di7; }
        //    set { SetProperty(ref _di7, value); }
        //}
        //private bool _di7;

        #endregion USB4704

    }
}
