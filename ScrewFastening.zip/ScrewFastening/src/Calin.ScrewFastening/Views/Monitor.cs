﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Calin.Helpers;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.Navigation;
using Calin.ScrewFastening.Models;
using Calin.UI.Extensions;
using Calin.UI.FA;

namespace Calin.ScrewFastening.Views
{
    /// <summary>
    /// 表示監控運動控制卡狀態的使用者控制項，提供軸狀態、運動狀態和軸 I/O 的即時指示。
    /// </summary>
    internal struct SingleMapping
    {
        public int Index;
        public string Description;
    }

    /// <summary>
    /// 提供一個用於監控運動控制卡狀態的使用者控制項，包含軸狀態、運動狀態和軸 I/O 的指示燈，並定期更新顯示以反映最新的狀態資訊。
    /// </summary>
    [ViewLifetime(IsAlive = true)]
    public partial class Monitor : UserControl
    {
        #region Fields

        private readonly IAcm _acm;
        private readonly MotionCardData _mcData;
        private readonly System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();

        // 軸狀態旗標Buffers
        private bool[] STA_AX_DISABLE = new bool[2];
        private bool[] STA_AX_READY = new bool[2];
        private bool[] STA_AX_STOPPING = new bool[2];
        private bool[] STA_AX_ERROR_STOP = new bool[2];
        private bool[] STA_AX_HOMING = new bool[2];
        private bool[] STA_AX_PTP_MOTION = new bool[2];
        private bool[] STA_AX_CONTI_MOTION = new bool[2];
        private bool[] STA_AX_SYNC_MOTION = new bool[2];
        private bool[] STA_AX_EXT_JOG = new bool[2];
        private bool[] STA_AX_EXT_MPG = new bool[2];
        private bool[] STA_AX_PAUSE = new bool[2];
        private bool[] STA_AX_BUSY = new bool[2];
        private bool[] STA_AX_WAIT_DI = new bool[2];
        private bool[] STA_AX_WAIT_PTP = new bool[2];
        private bool[] STA_AX_WAIT_VEL = new bool[2];
        private bool[] STA_AX_EXT_JOG_READY = new bool[2];

        // 軸運動旗標Buffers
        private bool[] Stop = new bool[2];
        private bool[] CorrectBksh = new bool[2];
        private bool[] InFA = new bool[2];
        private bool[] InFL = new bool[2];
        private bool[] InACC = new bool[2];
        private bool[] InFH = new bool[2];
        private bool[] InDEC = new bool[2];
        private bool[] WaitINP = new bool[2];

        // 軸的運動 I/O 旗標Buffers
        private bool[] RDY = new bool[2];
        private bool[] ALM = new bool[2];
        private bool[] LMT_Positive = new bool[2];
        private bool[] LMT_Negative = new bool[2];
        private bool[] ORG = new bool[2];
        private bool[] DIR = new bool[2];
        private bool[] EMG = new bool[2];
        private bool[] EZ = new bool[2];
        private bool[] LTC = new bool[2];
        private bool[] INP = new bool[2];
        private bool[] SVON = new bool[2];
        private bool[] ALRM = new bool[2];
        private bool[] SLMT_Positive = new bool[2];
        private bool[] SLMT_Negative = new bool[2];

        #endregion Fields

        public Monitor(IAcm acm, MotionCardData motionCardData)
        {
            _acm = acm;
            _mcData = motionCardData;

            InitializeComponent();

            Dictionary<AxisStateFlags, SingleMapping> axisStatusCaptin = new Dictionary<AxisStateFlags, SingleMapping>();
            Dictionary<AxisMotionFlags, SingleMapping> axisMotionStatusCaption = new Dictionary<AxisMotionFlags, SingleMapping>();
            Dictionary<AxisIoFlags, SingleMapping> axisIoStatusCaption = new Dictionary<AxisIoFlags, SingleMapping>();

            // 初始化運動控制卡狀態指示燈
            int idx = 0;
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_DISABLE, new SingleMapping
            {
                Index = idx++,
                Description = AxisStateFlags.STA_AX_DISABLE.GetDescription()
            });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_READY, new SingleMapping
            {
                Index = idx++,
                Description = AxisStateFlags.STA_AX_READY.GetDescription()
            });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_STOPPING, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_STOPPING.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_ERROR_STOP, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_ERROR_STOP.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_HOMING, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_HOMING.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_PTP_MOTION, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_PTP_MOTION.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_CONTI_MOTION, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_CONTI_MOTION.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_SYNC_MOTION, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_SYNC_MOTION.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_EXT_JOG, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_EXT_JOG.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_EXT_MPG, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_EXT_MPG.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_PAUSE, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_PAUSE.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_BUSY, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_BUSY.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_WAIT_DI, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_WAIT_DI.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_WAIT_PTP, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_WAIT_PTP.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_WAIT_VEL, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_WAIT_VEL.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_EXT_JOG_READY, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_EXT_JOG_READY.GetDescription() });

            axisMotionStatusCaption.Add(AxisMotionFlags.Stop, new SingleMapping { Index = idx++, Description = AxisMotionFlags.Stop.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.CorrectBksh, new SingleMapping { Index = idx++, Description = AxisMotionFlags.CorrectBksh.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InFA, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InFA.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InFL, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InFL.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InACC, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InACC.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InFH, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InFH.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InDEC, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InDEC.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.WaitINP, new SingleMapping { Index = idx++, Description = AxisMotionFlags.WaitINP.GetDescription() });

            axisIoStatusCaption.Add(AxisIoFlags.RDY, new SingleMapping { Index = idx++, Description = AxisIoFlags.RDY.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.ALM, new SingleMapping { Index = idx++, Description = AxisIoFlags.ALM.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.LMT_Positive, new SingleMapping { Index = idx++, Description = AxisIoFlags.LMT_Positive.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.LMT_Negative, new SingleMapping { Index = idx++, Description = AxisIoFlags.LMT_Negative.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.ORG, new SingleMapping { Index = idx++, Description = AxisIoFlags.ORG.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.DIR, new SingleMapping { Index = idx++, Description = AxisIoFlags.DIR.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.EMG, new SingleMapping { Index = idx++, Description = AxisIoFlags.EMG.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.EZ, new SingleMapping { Index = idx++, Description = AxisIoFlags.EZ.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.LTC, new SingleMapping { Index = idx++, Description = AxisIoFlags.LTC.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.INP, new SingleMapping { Index = idx++, Description = AxisIoFlags.INP.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.SVON, new SingleMapping { Index = idx++, Description = AxisIoFlags.SVON.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.ALRM, new SingleMapping { Index = idx++, Description = AxisIoFlags.ALRM.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.SLMT_Positive, new SingleMapping { Index = idx++, Description = AxisIoFlags.SLMT_Positive.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.SLMT_Negative, new SingleMapping { Index = idx++, Description = AxisIoFlags.SLMT_Negative.GetDescription() });

            var axisColumnCount = new List<int>
            {
                axisStatusCaptin.Count(),
                axisMotionStatusCaption.Count(),
                axisIoStatusCaption.Count()
            };
            var axisColumnHeaderName = new List<string>
            {
                "軸狀態",
                "運動狀態",
                "軸I/O"
            };

            axis1Indicator.Columns = axisColumnCount;
            axis1Indicator.ColumnHeaders = axisColumnHeaderName;
            var axis1ItemList = new List<MultiCircularIndicator.IndicatorItem>();
            foreach (var item in axisStatusCaptin)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            foreach (var item in axisMotionStatusCaption)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            foreach (var item in axisIoStatusCaption)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            axis1Indicator.SetIndicators(axis1ItemList);
            axis1Indicator.Size = axis1Indicator.GetPreferredSize();

            axis2Indicator.Columns = axisColumnCount;
            axis2Indicator.ColumnHeaders = axisColumnHeaderName;
            var axis2ItemList = new List<MultiCircularIndicator.IndicatorItem>();
            foreach (var item in axisStatusCaptin)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            foreach (var item in axisMotionStatusCaption)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            foreach (var item in axisIoStatusCaption)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            axis2Indicator.SetIndicators(axis2ItemList);
            axis2Indicator.Size = axis2Indicator.GetPreferredSize();

            //pbDI0.BindBackColorToBool(_bindingData, nameof(BindingData.DI0), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI1.BindBackColorToBool(_bindingData, nameof(BindingData.DI1), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI2.BindBackColorToBool(_bindingData, nameof(BindingData.DI2), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI3.BindBackColorToBool(_bindingData, nameof(BindingData.DI3), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI4.BindBackColorToBool(_bindingData, nameof(BindingData.DI4), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI5.BindBackColorToBool(_bindingData, nameof(BindingData.DI5), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI6.BindBackColorToBool(_bindingData, nameof(BindingData.DI6), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI7.BindBackColorToBool(_bindingData, nameof(BindingData.DI7), CommonStyle.SignalOn, CommonStyle.SignalOff, true);

            int axisNo = 0;
            _timer.Interval = 25;
            _timer.Tick += ((s, asue) =>
            {
                ThreadExt.RunOnUiThread(() =>
                {
                    axisNo ^= 0x01;
                    if (axisNo == 0)
                        axis1Indicator.BeginUpdate();
                    else
                        axis2Indicator.BeginUpdate();

                    int index = default;

                    // 軸狀態
                    if (STA_AX_DISABLE[axisNo] != _mcData.STA_AX_DISABLE[axisNo])
                    {
                        STA_AX_DISABLE[axisNo] = _mcData.STA_AX_DISABLE[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_DISABLE].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }

                    if (STA_AX_READY[axisNo] != _mcData.STA_AX_READY[axisNo])
                    {
                        STA_AX_READY[axisNo] = _mcData.STA_AX_READY[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_READY].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_STOPPING[axisNo] != _mcData.STA_AX_STOPPING[axisNo])
                    {
                        STA_AX_STOPPING[axisNo] = _mcData.STA_AX_STOPPING[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_STOPPING].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_ERROR_STOP[axisNo] != _mcData.STA_AX_ERROR_STOP[axisNo])
                    {
                        STA_AX_ERROR_STOP[axisNo] = _mcData.STA_AX_ERROR_STOP[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_ERROR_STOP].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_HOMING[axisNo] != _mcData.STA_AX_HOMING[axisNo])
                    {
                        STA_AX_HOMING[axisNo] = _mcData.STA_AX_HOMING[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_HOMING].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_PTP_MOTION[axisNo] != _mcData.STA_AX_PTP_MOTION[axisNo])
                    {
                        STA_AX_PTP_MOTION[axisNo] = _mcData.STA_AX_PTP_MOTION[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_PTP_MOTION].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_CONTI_MOTION[axisNo] != _mcData.STA_AX_CONTI_MOTION[axisNo])
                    {
                        STA_AX_CONTI_MOTION[axisNo] = _mcData.STA_AX_CONTI_MOTION[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_CONTI_MOTION].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_SYNC_MOTION[axisNo] != _mcData.STA_AX_SYNC_MOTION[axisNo])
                    {
                        STA_AX_SYNC_MOTION[axisNo] = _mcData.STA_AX_SYNC_MOTION[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_SYNC_MOTION].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_EXT_JOG[axisNo] != _mcData.STA_AX_EXT_JOG[axisNo])
                    {
                        STA_AX_EXT_JOG[axisNo] = _mcData.STA_AX_EXT_JOG[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_EXT_JOG].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_EXT_MPG[axisNo] != _mcData.STA_AX_EXT_MPG[axisNo])
                    {
                        STA_AX_EXT_MPG[axisNo] = _mcData.STA_AX_EXT_MPG[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_EXT_MPG].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_PAUSE[axisNo] != _mcData.STA_AX_PAUSE[axisNo])
                    {
                        STA_AX_PAUSE[axisNo] = _mcData.STA_AX_PAUSE[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_PAUSE].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_BUSY[axisNo] != _mcData.STA_AX_BUSY[axisNo])
                    {
                        STA_AX_BUSY[axisNo] = _mcData.STA_AX_BUSY[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_BUSY].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_WAIT_DI[axisNo] != _mcData.STA_AX_WAIT_DI[axisNo])
                    {
                        STA_AX_WAIT_DI[axisNo] = _mcData.STA_AX_WAIT_DI[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_WAIT_DI].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_WAIT_PTP[axisNo] != _mcData.STA_AX_WAIT_PTP[axisNo])
                    {
                        STA_AX_WAIT_PTP[axisNo] = _mcData.STA_AX_WAIT_PTP[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_WAIT_PTP].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_WAIT_VEL[axisNo] != _mcData.STA_AX_WAIT_VEL[axisNo])
                    {
                        STA_AX_WAIT_VEL[axisNo] = _mcData.STA_AX_WAIT_VEL[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_WAIT_VEL].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (STA_AX_EXT_JOG_READY[axisNo] != _mcData.STA_AX_EXT_JOG_READY[axisNo])
                    {
                        STA_AX_EXT_JOG_READY[axisNo] = _mcData.STA_AX_EXT_JOG_READY[axisNo];
                        index = axisStatusCaptin[AxisStateFlags.STA_AX_EXT_JOG_READY].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }

                    // 軸運動狀態
                    if (Stop[axisNo] != _mcData.Stop[axisNo])
                    {
                        Stop[axisNo] = _mcData.Stop[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.Stop].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (CorrectBksh[axisNo] != _mcData.CorrectBksh[axisNo])
                    {
                        CorrectBksh[axisNo] = _mcData.CorrectBksh[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.CorrectBksh].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (InFA[axisNo] != _mcData.InFA[axisNo])
                    {
                        InFA[axisNo] = _mcData.InFA[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.InFA].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (InFL[axisNo] != _mcData.InFL[axisNo])
                    {
                        InFL[axisNo] = _mcData.InFL[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.InFL].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (InACC[axisNo] != _mcData.InACC[axisNo])
                    {
                        InACC[axisNo] = _mcData.InACC[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.InACC].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (InACC[axisNo] != _mcData.InACC[axisNo])
                    {
                        InACC[axisNo] = _mcData.InACC[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.InACC].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (InFH[axisNo] != _mcData.InFH[axisNo])
                    {
                        InFH[axisNo] = _mcData.InFH[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.InFH].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (InDEC[axisNo] != _mcData.InDEC[axisNo])
                    {
                        InDEC[axisNo] = _mcData.InDEC[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.InDEC].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (WaitINP[axisNo] != _mcData.WaitINP[axisNo])
                    {
                        WaitINP[axisNo] = _mcData.WaitINP[axisNo];
                        index = axisMotionStatusCaption[AxisMotionFlags.WaitINP].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }

                    // 軸 I/O
                    if (RDY[axisNo] != _mcData.RDY[axisNo])
                    {
                        RDY[axisNo] = _mcData.RDY[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.RDY].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (ALM[axisNo] != _mcData.ALM[axisNo])
                    {
                        ALM[axisNo] = _mcData.ALM[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.ALM].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (LMT_Positive[axisNo] != _mcData.LMT_Positive[axisNo])
                    {
                        LMT_Positive[axisNo] = _mcData.LMT_Positive[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.LMT_Positive].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (LMT_Negative[axisNo] != _mcData.LMT_Negative[axisNo])
                    {
                        LMT_Negative[axisNo] = _mcData.LMT_Negative[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.LMT_Negative].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (ORG[axisNo] != _mcData.ORG[axisNo])
                    {
                        ORG[axisNo] = _mcData.ORG[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.ORG].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (DIR[axisNo] != _mcData.DIR[axisNo])
                    {
                        DIR[axisNo] = _mcData.DIR[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.DIR].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (EMG[axisNo] != _mcData.EMG[axisNo])
                    {
                        EMG[axisNo] = _mcData.EMG[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.EMG].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (EZ[axisNo] != _mcData.EZ[axisNo])
                    {
                        EZ[axisNo] = _mcData.EZ[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.EZ].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (LTC[axisNo] != _mcData.LTC[axisNo])
                    {
                        LTC[axisNo] = _mcData.LTC[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.LTC].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (INP[axisNo] != _mcData.INP[axisNo])
                    {
                        INP[axisNo] = _mcData.INP[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.INP].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (SVON[axisNo] != _mcData.SVON[axisNo])
                    {
                        SVON[axisNo] = _mcData.SVON[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.SVON].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (ALRM[axisNo] != _mcData.ALRM[axisNo])
                    {
                        ALRM[axisNo] = _mcData.ALRM[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.ALRM].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (SLMT_Positive[axisNo] != _mcData.SLMT_Positive[axisNo])
                    {
                        SLMT_Positive[axisNo] = _mcData.SLMT_Positive[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.SLMT_Positive].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }
                    if (SLMT_Negative[axisNo] != _mcData.SLMT_Negative[axisNo])
                    {
                        SLMT_Negative[axisNo] = _mcData.SLMT_Negative[axisNo];
                        index = axisIoStatusCaption[AxisIoFlags.SLMT_Negative].Index;
                        if (axisNo == 0)
                            axis1Indicator.UpdateIndicator(index, true);
                        else
                            axis2Indicator.UpdateIndicator(index, true);
                    }

                    if (axisNo == 0)
                        axis1Indicator.EndUpdate();
                    else
                        axis2Indicator.EndUpdate();
                });
            });
            _timer.Start();
        }
    }
}
