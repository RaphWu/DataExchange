﻿namespace Calin.ScrewFastening.Views
{
    partial class SetupPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tbTorqueLimitL = new System.Windows.Forms.NumericUpDown();
            this.tbTorqueLimitH = new System.Windows.Forms.NumericUpDown();
            this.button6 = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.numAngleCompensation = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cbGateMarkCylinder = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cbTorqueMeterPort = new System.Windows.Forms.ComboBox();
            this.btnUpdateUsb4704 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.numSectionLength = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.numClockRate = new System.Windows.Forms.NumericUpDown();
            this.tpSensor = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Gb_HeightDisplacement = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbHeightDispLimitL = new System.Windows.Forms.NumericUpDown();
            this.tbHeightDispLimitH = new System.Windows.Forms.NumericUpDown();
            this.BtnHeightDispReconnect = new System.Windows.Forms.Button();
            this.CbHeightDispDataBits = new System.Windows.Forms.ComboBox();
            this.label_StopBits = new System.Windows.Forms.Label();
            this.CbHeightDispStopBits = new System.Windows.Forms.ComboBox();
            this.label_DataBits = new System.Windows.Forms.Label();
            this.label_Parity = new System.Windows.Forms.Label();
            this.CbHeightDispParity = new System.Windows.Forms.ComboBox();
            this.label_BaudRate = new System.Windows.Forms.Label();
            this.CbHeightDispBaudRate = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.CbHeightDispCom = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.RbTCurver = new System.Windows.Forms.RadioButton();
            this.RbSCurver = new System.Windows.Forms.RadioButton();
            this.tbUsb4704DeviceCode = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.VelSetupPanel = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.NumVelL = new System.Windows.Forms.NumericUpDown();
            this.NumVelH = new System.Windows.Forms.NumericUpDown();
            this.NumAcc = new System.Windows.Forms.NumericUpDown();
            this.NumDec = new System.Windows.Forms.NumericUpDown();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.numLead = new System.Windows.Forms.NumericUpDown();
            this.tpOther = new System.Windows.Forms.TabPage();
            this.DevicePanel = new System.Windows.Forms.GroupBox();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.CbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnServoOn = new System.Windows.Forms.Button();
            this.BtnUpdatePortNames = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.HomePanel = new System.Windows.Forms.GroupBox();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.NumCrossDis = new System.Windows.Forms.NumericUpDown();
            this.BtnStop = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.BtnHome = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.CbSwitchMode = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.RbHelHigh = new System.Windows.Forms.RadioButton();
            this.RbHelLow = new System.Windows.Forms.RadioButton();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.RbOrgHigh = new System.Windows.Forms.RadioButton();
            this.RbOrgLow = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.RbEzLow = new System.Windows.Forms.RadioButton();
            this.RbEzHigh = new System.Windows.Forms.RadioButton();
            this.CbHomeMode = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.CbDir = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpMotionCard = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.cbEmgLogic = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.numEmgFilterTime = new System.Windows.Forms.NumericUpDown();
            this.label47 = new System.Windows.Forms.Label();
            this.BtnSetParam = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbTorqueLimitL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbTorqueLimitH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAngleCompensation)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSectionLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numClockRate)).BeginInit();
            this.tpSensor.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.Gb_HeightDisplacement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbHeightDispLimitL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbHeightDispLimitH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            this.VelSetupPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).BeginInit();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLead)).BeginInit();
            this.tpOther.SuspendLayout();
            this.DevicePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.HomePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumCrossDis)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpMotionCard.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numEmgFilterTime)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(157, 66);
            this.button4.Margin = new System.Windows.Forms.Padding(0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(45, 23);
            this.button4.TabIndex = 171;
            this.button4.Text = "取得";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(157, 32);
            this.button5.Margin = new System.Windows.Forms.Padding(0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(45, 23);
            this.button5.TabIndex = 170;
            this.button5.Text = "取得";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.Location = new System.Drawing.Point(128, 71);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(34, 17);
            this.label26.TabIndex = 168;
            this.label26.Text = "mm";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.tbTorqueLimitL);
            this.groupBox3.Controls.Add(this.tbTorqueLimitH);
            this.groupBox3.Location = new System.Drawing.Point(265, 18);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(220, 110);
            this.groupBox3.TabIndex = 85;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "扭力計參數設定";
            // 
            // label25
            // 
            this.label25.Location = new System.Drawing.Point(128, 37);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(34, 17);
            this.label25.TabIndex = 169;
            this.label25.Text = "mm";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label21.Location = new System.Drawing.Point(9, 70);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(34, 17);
            this.label21.TabIndex = 167;
            this.label21.Text = "下限";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label22.Location = new System.Drawing.Point(9, 36);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(34, 17);
            this.label22.TabIndex = 166;
            this.label22.Text = "上限";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbTorqueLimitL
            // 
            this.tbTorqueLimitL.DecimalPlaces = 3;
            this.tbTorqueLimitL.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.tbTorqueLimitL.Location = new System.Drawing.Point(46, 66);
            this.tbTorqueLimitL.Name = "tbTorqueLimitL";
            this.tbTorqueLimitL.Size = new System.Drawing.Size(79, 23);
            this.tbTorqueLimitL.TabIndex = 165;
            this.tbTorqueLimitL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbTorqueLimitL.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // tbTorqueLimitH
            // 
            this.tbTorqueLimitH.DecimalPlaces = 3;
            this.tbTorqueLimitH.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.tbTorqueLimitH.Location = new System.Drawing.Point(46, 32);
            this.tbTorqueLimitH.Name = "tbTorqueLimitH";
            this.tbTorqueLimitH.Size = new System.Drawing.Size(79, 23);
            this.tbTorqueLimitH.TabIndex = 164;
            this.tbTorqueLimitH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbTorqueLimitH.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.tbTorqueLimitH.ValueChanged += new System.EventHandler(this.TbTorqueLimitH_ValueChanged);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(184, 57);
            this.button6.Margin = new System.Windows.Forms.Padding(0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(45, 23);
            this.button6.TabIndex = 173;
            this.button6.Text = "取得";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.Location = new System.Drawing.Point(158, 59);
            this.label28.Margin = new System.Windows.Forms.Padding(0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(18, 17);
            this.label28.TabIndex = 165;
            this.label28.Text = "度";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numAngleCompensation
            // 
            this.numAngleCompensation.DecimalPlaces = 1;
            this.numAngleCompensation.Location = new System.Drawing.Point(78, 57);
            this.numAngleCompensation.Name = "numAngleCompensation";
            this.numAngleCompensation.Size = new System.Drawing.Size(80, 23);
            this.numAngleCompensation.TabIndex = 161;
            this.numAngleCompensation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(20, 60);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 16);
            this.label27.TabIndex = 155;
            this.label27.Text = "尋邊補償";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 16);
            this.label7.TabIndex = 152;
            this.label7.Text = "尋邊氣缸";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbGateMarkCylinder
            // 
            this.cbGateMarkCylinder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGateMarkCylinder.FormattingEnabled = true;
            this.cbGateMarkCylinder.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbGateMarkCylinder.Items.AddRange(new object[] {
            "DO0",
            "DO1",
            "DO2",
            "DO3",
            "DO4",
            "DO5",
            "DO6",
            "DO7"});
            this.cbGateMarkCylinder.Location = new System.Drawing.Point(78, 26);
            this.cbGateMarkCylinder.Name = "cbGateMarkCylinder";
            this.cbGateMarkCylinder.Size = new System.Drawing.Size(113, 24);
            this.cbGateMarkCylinder.TabIndex = 151;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button6);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.numAngleCompensation);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.cbGateMarkCylinder);
            this.groupBox4.Location = new System.Drawing.Point(509, 18);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(248, 95);
            this.groupBox4.TabIndex = 86;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "尋邊設定";
            // 
            // label36
            // 
            this.label36.Location = new System.Drawing.Point(10, 30);
            this.label36.Margin = new System.Windows.Forms.Padding(0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(75, 23);
            this.label36.TabIndex = 178;
            this.label36.Text = "扭力計連接";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbTorqueMeterPort
            // 
            this.cbTorqueMeterPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTorqueMeterPort.FormattingEnabled = true;
            this.cbTorqueMeterPort.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbTorqueMeterPort.Location = new System.Drawing.Point(87, 29);
            this.cbTorqueMeterPort.Name = "cbTorqueMeterPort";
            this.cbTorqueMeterPort.Size = new System.Drawing.Size(115, 24);
            this.cbTorqueMeterPort.TabIndex = 177;
            // 
            // btnUpdateUsb4704
            // 
            this.btnUpdateUsb4704.Location = new System.Drawing.Point(67, 125);
            this.btnUpdateUsb4704.Margin = new System.Windows.Forms.Padding(0);
            this.btnUpdateUsb4704.Name = "btnUpdateUsb4704";
            this.btnUpdateUsb4704.Size = new System.Drawing.Size(85, 27);
            this.btnUpdateUsb4704.TabIndex = 176;
            this.btnUpdateUsb4704.Text = "更新設備";
            this.btnUpdateUsb4704.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.Location = new System.Drawing.Point(181, 93);
            this.label33.Margin = new System.Windows.Forms.Padding(0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(34, 17);
            this.label33.TabIndex = 175;
            this.label33.Text = "Hz";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label34.Location = new System.Drawing.Point(10, 89);
            this.label34.Margin = new System.Windows.Forms.Padding(0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(75, 23);
            this.label34.TabIndex = 174;
            this.label34.Text = "數據段長度";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numSectionLength
            // 
            this.numSectionLength.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.numSectionLength.Location = new System.Drawing.Point(87, 89);
            this.numSectionLength.Maximum = new decimal(new int[] {
            88888,
            0,
            0,
            0});
            this.numSectionLength.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numSectionLength.Name = "numSectionLength";
            this.numSectionLength.Size = new System.Drawing.Size(91, 23);
            this.numSectionLength.TabIndex = 173;
            this.numSectionLength.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numSectionLength.Value = new decimal(new int[] {
            256,
            0,
            0,
            0});
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(181, 64);
            this.label32.Margin = new System.Windows.Forms.Padding(0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(34, 17);
            this.label32.TabIndex = 172;
            this.label32.Text = "Hz";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label35
            // 
            this.label35.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label35.Location = new System.Drawing.Point(10, 60);
            this.label35.Margin = new System.Windows.Forms.Padding(0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(75, 23);
            this.label35.TabIndex = 166;
            this.label35.Text = "取樣頻率";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numClockRate
            // 
            this.numClockRate.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.numClockRate.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numClockRate.Location = new System.Drawing.Point(87, 60);
            this.numClockRate.Maximum = new decimal(new int[] {
            47619,
            0,
            0,
            0});
            this.numClockRate.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numClockRate.Name = "numClockRate";
            this.numClockRate.Size = new System.Drawing.Size(91, 23);
            this.numClockRate.TabIndex = 164;
            this.numClockRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numClockRate.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // tpSensor
            // 
            this.tpSensor.Controls.Add(this.groupBox5);
            this.tpSensor.Controls.Add(this.groupBox4);
            this.tpSensor.Controls.Add(this.groupBox3);
            this.tpSensor.Controls.Add(this.Gb_HeightDisplacement);
            this.tpSensor.Location = new System.Drawing.Point(4, 25);
            this.tpSensor.Name = "tpSensor";
            this.tpSensor.Padding = new System.Windows.Forms.Padding(3);
            this.tpSensor.Size = new System.Drawing.Size(992, 631);
            this.tpSensor.TabIndex = 1;
            this.tpSensor.Text = "量測裝罝";
            this.tpSensor.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.cbTorqueMeterPort);
            this.groupBox5.Controls.Add(this.btnUpdateUsb4704);
            this.groupBox5.Controls.Add(this.label33);
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.numSectionLength);
            this.groupBox5.Controls.Add(this.label32);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.numClockRate);
            this.groupBox5.Location = new System.Drawing.Point(265, 156);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(220, 167);
            this.groupBox5.TabIndex = 172;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "資料擷取模組設定";
            // 
            // Gb_HeightDisplacement
            // 
            this.Gb_HeightDisplacement.Controls.Add(this.button3);
            this.Gb_HeightDisplacement.Controls.Add(this.button2);
            this.Gb_HeightDisplacement.Controls.Add(this.label24);
            this.Gb_HeightDisplacement.Controls.Add(this.label23);
            this.Gb_HeightDisplacement.Controls.Add(this.label6);
            this.Gb_HeightDisplacement.Controls.Add(this.label5);
            this.Gb_HeightDisplacement.Controls.Add(this.tbHeightDispLimitL);
            this.Gb_HeightDisplacement.Controls.Add(this.tbHeightDispLimitH);
            this.Gb_HeightDisplacement.Controls.Add(this.BtnHeightDispReconnect);
            this.Gb_HeightDisplacement.Controls.Add(this.CbHeightDispDataBits);
            this.Gb_HeightDisplacement.Controls.Add(this.label_StopBits);
            this.Gb_HeightDisplacement.Controls.Add(this.CbHeightDispStopBits);
            this.Gb_HeightDisplacement.Controls.Add(this.label_DataBits);
            this.Gb_HeightDisplacement.Controls.Add(this.label_Parity);
            this.Gb_HeightDisplacement.Controls.Add(this.CbHeightDispParity);
            this.Gb_HeightDisplacement.Controls.Add(this.label_BaudRate);
            this.Gb_HeightDisplacement.Controls.Add(this.CbHeightDispBaudRate);
            this.Gb_HeightDisplacement.Controls.Add(this.label9);
            this.Gb_HeightDisplacement.Controls.Add(this.CbHeightDispCom);
            this.Gb_HeightDisplacement.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Gb_HeightDisplacement.Location = new System.Drawing.Point(20, 18);
            this.Gb_HeightDisplacement.Name = "Gb_HeightDisplacement";
            this.Gb_HeightDisplacement.Size = new System.Drawing.Size(220, 305);
            this.Gb_HeightDisplacement.TabIndex = 84;
            this.Gb_HeightDisplacement.TabStop = false;
            this.Gb_HeightDisplacement.Text = "高度計參數設定";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(159, 266);
            this.button3.Margin = new System.Windows.Forms.Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(45, 23);
            this.button3.TabIndex = 167;
            this.button3.Text = "取得";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(159, 233);
            this.button2.Margin = new System.Windows.Forms.Padding(0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(45, 23);
            this.button2.TabIndex = 166;
            this.button2.Text = "取得";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label24.Location = new System.Drawing.Point(128, 236);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 17);
            this.label24.TabIndex = 165;
            this.label24.Text = "mm";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label23.Location = new System.Drawing.Point(128, 270);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(34, 17);
            this.label23.TabIndex = 164;
            this.label23.Text = "mm";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label6.Location = new System.Drawing.Point(10, 270);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 17);
            this.label6.TabIndex = 163;
            this.label6.Text = "下限";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label5.Location = new System.Drawing.Point(10, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 17);
            this.label5.TabIndex = 162;
            this.label5.Text = "上限";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbHeightDispLimitL
            // 
            this.tbHeightDispLimitL.DecimalPlaces = 3;
            this.tbHeightDispLimitL.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.tbHeightDispLimitL.Location = new System.Drawing.Point(46, 266);
            this.tbHeightDispLimitL.Name = "tbHeightDispLimitL";
            this.tbHeightDispLimitL.Size = new System.Drawing.Size(80, 23);
            this.tbHeightDispLimitL.TabIndex = 161;
            this.tbHeightDispLimitL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHeightDispLimitL.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // tbHeightDispLimitH
            // 
            this.tbHeightDispLimitH.DecimalPlaces = 3;
            this.tbHeightDispLimitH.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.tbHeightDispLimitH.Location = new System.Drawing.Point(46, 232);
            this.tbHeightDispLimitH.Name = "tbHeightDispLimitH";
            this.tbHeightDispLimitH.Size = new System.Drawing.Size(80, 23);
            this.tbHeightDispLimitH.TabIndex = 160;
            this.tbHeightDispLimitH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHeightDispLimitH.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // BtnHeightDispReconnect
            // 
            this.BtnHeightDispReconnect.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnHeightDispReconnect.Location = new System.Drawing.Point(45, 181);
            this.BtnHeightDispReconnect.Name = "BtnHeightDispReconnect";
            this.BtnHeightDispReconnect.Size = new System.Drawing.Size(145, 31);
            this.BtnHeightDispReconnect.TabIndex = 159;
            this.BtnHeightDispReconnect.Text = "重新連接";
            this.BtnHeightDispReconnect.UseVisualStyleBackColor = true;
            this.BtnHeightDispReconnect.Click += new System.EventHandler(this.BtnHeightDispReconnect_Click);
            // 
            // CbHeightDispDataBits
            // 
            this.CbHeightDispDataBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbHeightDispDataBits.FormattingEnabled = true;
            this.CbHeightDispDataBits.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbHeightDispDataBits.Location = new System.Drawing.Point(108, 116);
            this.CbHeightDispDataBits.Name = "CbHeightDispDataBits";
            this.CbHeightDispDataBits.Size = new System.Drawing.Size(82, 25);
            this.CbHeightDispDataBits.TabIndex = 158;
            this.CbHeightDispDataBits.SelectedIndexChanged += new System.EventHandler(this.CbHeightDispDataBits_SelectedIndexChanged);
            // 
            // label_StopBits
            // 
            this.label_StopBits.AutoSize = true;
            this.label_StopBits.Location = new System.Drawing.Point(47, 151);
            this.label_StopBits.Name = "label_StopBits";
            this.label_StopBits.Size = new System.Drawing.Size(58, 17);
            this.label_StopBits.TabIndex = 156;
            this.label_StopBits.Text = "StopBits";
            this.label_StopBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CbHeightDispStopBits
            // 
            this.CbHeightDispStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbHeightDispStopBits.FormattingEnabled = true;
            this.CbHeightDispStopBits.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbHeightDispStopBits.Location = new System.Drawing.Point(108, 147);
            this.CbHeightDispStopBits.Name = "CbHeightDispStopBits";
            this.CbHeightDispStopBits.Size = new System.Drawing.Size(82, 25);
            this.CbHeightDispStopBits.TabIndex = 155;
            this.CbHeightDispStopBits.SelectedIndexChanged += new System.EventHandler(this.CbHeightDispStopBits_SelectedIndexChanged);
            // 
            // label_DataBits
            // 
            this.label_DataBits.AutoSize = true;
            this.label_DataBits.Location = new System.Drawing.Point(46, 120);
            this.label_DataBits.Name = "label_DataBits";
            this.label_DataBits.Size = new System.Drawing.Size(59, 17);
            this.label_DataBits.TabIndex = 154;
            this.label_DataBits.Text = "DataBits";
            this.label_DataBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Parity
            // 
            this.label_Parity.AutoSize = true;
            this.label_Parity.Location = new System.Drawing.Point(62, 89);
            this.label_Parity.Name = "label_Parity";
            this.label_Parity.Size = new System.Drawing.Size(43, 17);
            this.label_Parity.TabIndex = 152;
            this.label_Parity.Text = "Parity";
            this.label_Parity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CbHeightDispParity
            // 
            this.CbHeightDispParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbHeightDispParity.FormattingEnabled = true;
            this.CbHeightDispParity.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbHeightDispParity.Location = new System.Drawing.Point(108, 85);
            this.CbHeightDispParity.Name = "CbHeightDispParity";
            this.CbHeightDispParity.Size = new System.Drawing.Size(82, 25);
            this.CbHeightDispParity.TabIndex = 151;
            this.CbHeightDispParity.SelectedIndexChanged += new System.EventHandler(this.CbHeightDispParity_SelectedIndexChanged);
            // 
            // label_BaudRate
            // 
            this.label_BaudRate.AutoSize = true;
            this.label_BaudRate.Location = new System.Drawing.Point(39, 58);
            this.label_BaudRate.Name = "label_BaudRate";
            this.label_BaudRate.Size = new System.Drawing.Size(66, 17);
            this.label_BaudRate.TabIndex = 150;
            this.label_BaudRate.Text = "BaudRate";
            this.label_BaudRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CbHeightDispBaudRate
            // 
            this.CbHeightDispBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbHeightDispBaudRate.FormattingEnabled = true;
            this.CbHeightDispBaudRate.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbHeightDispBaudRate.Location = new System.Drawing.Point(108, 54);
            this.CbHeightDispBaudRate.Name = "CbHeightDispBaudRate";
            this.CbHeightDispBaudRate.Size = new System.Drawing.Size(82, 25);
            this.CbHeightDispBaudRate.TabIndex = 149;
            this.CbHeightDispBaudRate.SelectedIndexChanged += new System.EventHandler(this.CbHeightDispBaudRate_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(71, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 17);
            this.label9.TabIndex = 148;
            this.label9.Text = "Port";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CbHeightDispCom
            // 
            this.CbHeightDispCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbHeightDispCom.FormattingEnabled = true;
            this.CbHeightDispCom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbHeightDispCom.Location = new System.Drawing.Point(108, 23);
            this.CbHeightDispCom.Name = "CbHeightDispCom";
            this.CbHeightDispCom.Size = new System.Drawing.Size(82, 25);
            this.CbHeightDispCom.TabIndex = 145;
            this.CbHeightDispCom.SelectedIndexChanged += new System.EventHandler(this.CbHeightDispCom_SelectedIndexChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(176, 343);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(29, 15);
            this.label31.TabIndex = 50;
            this.label31.Text = "mm";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(30, 343);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 16);
            this.label30.TabIndex = 48;
            this.label30.Text = "安全高度";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.DecimalPlaces = 1;
            this.numericUpDown6.Location = new System.Drawing.Point(88, 340);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(85, 23);
            this.numericUpDown6.TabIndex = 49;
            this.numericUpDown6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown6.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // RbTCurver
            // 
            this.RbTCurver.AutoSize = true;
            this.RbTCurver.Checked = true;
            this.RbTCurver.Location = new System.Drawing.Point(21, 23);
            this.RbTCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbTCurver.Name = "RbTCurver";
            this.RbTCurver.Size = new System.Drawing.Size(68, 20);
            this.RbTCurver.TabIndex = 35;
            this.RbTCurver.TabStop = true;
            this.RbTCurver.Text = "T型曲線";
            this.RbTCurver.UseVisualStyleBackColor = true;
            // 
            // RbSCurver
            // 
            this.RbSCurver.AutoSize = true;
            this.RbSCurver.Location = new System.Drawing.Point(103, 23);
            this.RbSCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbSCurver.Name = "RbSCurver";
            this.RbSCurver.Size = new System.Drawing.Size(68, 20);
            this.RbSCurver.TabIndex = 36;
            this.RbSCurver.Text = "S型曲線";
            this.RbSCurver.UseVisualStyleBackColor = true;
            // 
            // tbUsb4704DeviceCode
            // 
            this.tbUsb4704DeviceCode.Location = new System.Drawing.Point(620, 53);
            this.tbUsb4704DeviceCode.Name = "tbUsb4704DeviceCode";
            this.tbUsb4704DeviceCode.Size = new System.Drawing.Size(149, 23);
            this.tbUsb4704DeviceCode.TabIndex = 154;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(175, 121);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 15);
            this.label8.TabIndex = 47;
            this.label8.Text = "PPU/sec²";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(175, 92);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 15);
            this.label10.TabIndex = 46;
            this.label10.Text = "PPU/sec²";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // VelSetupPanel
            // 
            this.VelSetupPanel.Controls.Add(this.label8);
            this.VelSetupPanel.Controls.Add(this.label10);
            this.VelSetupPanel.Controls.Add(this.label11);
            this.VelSetupPanel.Controls.Add(this.label12);
            this.VelSetupPanel.Controls.Add(this.NumVelL);
            this.VelSetupPanel.Controls.Add(this.NumVelH);
            this.VelSetupPanel.Controls.Add(this.NumAcc);
            this.VelSetupPanel.Controls.Add(this.NumDec);
            this.VelSetupPanel.Controls.Add(this.groupBox11);
            this.VelSetupPanel.Controls.Add(this.label16);
            this.VelSetupPanel.Controls.Add(this.label17);
            this.VelSetupPanel.Controls.Add(this.label18);
            this.VelSetupPanel.Controls.Add(this.label19);
            this.VelSetupPanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.VelSetupPanel.Location = new System.Drawing.Point(20, 22);
            this.VelSetupPanel.Margin = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Name = "VelSetupPanel";
            this.VelSetupPanel.Padding = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Size = new System.Drawing.Size(245, 218);
            this.VelSetupPanel.TabIndex = 57;
            this.VelSetupPanel.TabStop = false;
            this.VelSetupPanel.Text = "基本速率設定";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(175, 61);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 15);
            this.label11.TabIndex = 45;
            this.label11.Text = "PPU/sec";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(175, 30);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 15);
            this.label12.TabIndex = 44;
            this.label12.Text = "PPU/sec";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // NumVelL
            // 
            this.NumVelL.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelL.Location = new System.Drawing.Point(72, 26);
            this.NumVelL.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelL.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelL.Name = "NumVelL";
            this.NumVelL.Size = new System.Drawing.Size(100, 23);
            this.NumVelL.TabIndex = 43;
            this.NumVelL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelL.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // NumVelH
            // 
            this.NumVelH.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelH.Location = new System.Drawing.Point(72, 57);
            this.NumVelH.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelH.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelH.Name = "NumVelH";
            this.NumVelH.Size = new System.Drawing.Size(100, 23);
            this.NumVelH.TabIndex = 42;
            this.NumVelH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelH.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // NumAcc
            // 
            this.NumAcc.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumAcc.Location = new System.Drawing.Point(72, 88);
            this.NumAcc.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumAcc.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumAcc.Name = "NumAcc";
            this.NumAcc.Size = new System.Drawing.Size(100, 23);
            this.NumAcc.TabIndex = 41;
            this.NumAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumAcc.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // NumDec
            // 
            this.NumDec.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumDec.Location = new System.Drawing.Point(72, 117);
            this.NumDec.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumDec.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumDec.Name = "NumDec";
            this.NumDec.Size = new System.Drawing.Size(100, 23);
            this.NumDec.TabIndex = 40;
            this.NumDec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumDec.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.RbTCurver);
            this.groupBox11.Controls.Add(this.RbSCurver);
            this.groupBox11.Location = new System.Drawing.Point(17, 150);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(209, 53);
            this.groupBox11.TabIndex = 37;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "速度曲線類型";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(26, 120);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 32;
            this.label16.Text = "減速度";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(26, 91);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 16);
            this.label17.TabIndex = 30;
            this.label17.Text = "加速度";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 60);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 16);
            this.label18.TabIndex = 28;
            this.label18.Text = "運轉速度";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(14, 29);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 16);
            this.label19.TabIndex = 26;
            this.label19.Text = "起始速度";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numLead
            // 
            this.numLead.DecimalPlaces = 2;
            this.numLead.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numLead.Location = new System.Drawing.Point(72, 26);
            this.numLead.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numLead.Name = "numLead";
            this.numLead.Size = new System.Drawing.Size(100, 23);
            this.numLead.TabIndex = 43;
            this.numLead.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numLead.Value = new decimal(new int[] {
            125,
            0,
            0,
            131072});
            // 
            // tpOther
            // 
            this.tpOther.Controls.Add(this.DevicePanel);
            this.tpOther.Controls.Add(this.BtnUpdatePortNames);
            this.tpOther.Controls.Add(this.tbUsb4704DeviceCode);
            this.tpOther.Controls.Add(this.label29);
            this.tpOther.Location = new System.Drawing.Point(4, 25);
            this.tpOther.Name = "tpOther";
            this.tpOther.Size = new System.Drawing.Size(992, 631);
            this.tpOther.TabIndex = 2;
            this.tpOther.Text = "其他";
            this.tpOther.UseVisualStyleBackColor = true;
            // 
            // DevicePanel
            // 
            this.DevicePanel.Controls.Add(this.BtnLoadCfg);
            this.DevicePanel.Controls.Add(this.label43);
            this.DevicePanel.Controls.Add(this.CbAvailableDevice);
            this.DevicePanel.Controls.Add(this.BtnOpenBoard);
            this.DevicePanel.Controls.Add(this.BtnCloseBoard);
            this.DevicePanel.Controls.Add(this.BtnServoOn);
            this.DevicePanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.DevicePanel.Location = new System.Drawing.Point(17, 15);
            this.DevicePanel.Margin = new System.Windows.Forms.Padding(4);
            this.DevicePanel.Name = "DevicePanel";
            this.DevicePanel.Padding = new System.Windows.Forms.Padding(4);
            this.DevicePanel.Size = new System.Drawing.Size(285, 140);
            this.DevicePanel.TabIndex = 159;
            this.DevicePanel.TabStop = false;
            this.DevicePanel.Text = "PCI-1220U 運動控制卡設定";
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(162, 64);
            this.BtnLoadCfg.Margin = new System.Windows.Forms.Padding(4);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(100, 25);
            this.BtnLoadCfg.TabIndex = 32;
            this.BtnLoadCfg.Text = "載入CFG檔";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(21, 32);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(55, 16);
            this.label43.TabIndex = 13;
            this.label43.Text = "可用裝置";
            // 
            // CbAvailableDevice
            // 
            this.CbAvailableDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbAvailableDevice.FormattingEnabled = true;
            this.CbAvailableDevice.Location = new System.Drawing.Point(79, 28);
            this.CbAvailableDevice.Margin = new System.Windows.Forms.Padding(4);
            this.CbAvailableDevice.Name = "CbAvailableDevice";
            this.CbAvailableDevice.Size = new System.Drawing.Size(183, 24);
            this.CbAvailableDevice.TabIndex = 14;
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(22, 64);
            this.BtnOpenBoard.Margin = new System.Windows.Forms.Padding(4);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "控制卡開啟";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(22, 97);
            this.BtnCloseBoard.Margin = new System.Windows.Forms.Padding(4);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "控制卡關閉";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            // 
            // BtnServoOn
            // 
            this.BtnServoOn.Location = new System.Drawing.Point(162, 97);
            this.BtnServoOn.Margin = new System.Windows.Forms.Padding(4);
            this.BtnServoOn.Name = "BtnServoOn";
            this.BtnServoOn.Size = new System.Drawing.Size(100, 25);
            this.BtnServoOn.TabIndex = 17;
            this.BtnServoOn.Text = "Servo On";
            this.BtnServoOn.UseVisualStyleBackColor = true;
            // 
            // BtnUpdatePortNames
            // 
            this.BtnUpdatePortNames.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnUpdatePortNames.Location = new System.Drawing.Point(509, 100);
            this.BtnUpdatePortNames.Name = "BtnUpdatePortNames";
            this.BtnUpdatePortNames.Size = new System.Drawing.Size(145, 31);
            this.BtnUpdatePortNames.TabIndex = 158;
            this.BtnUpdatePortNames.Text = "更新埠列表";
            this.BtnUpdatePortNames.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.Location = new System.Drawing.Point(506, 53);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(112, 23);
            this.label29.TabIndex = 153;
            this.label29.Text = "USB4704 裝置代碼";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label44
            // 
            this.label44.Location = new System.Drawing.Point(15, 30);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(55, 16);
            this.label44.TabIndex = 26;
            this.label44.Text = "導程";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(196, 182);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(55, 15);
            this.label48.TabIndex = 60;
            this.label48.Text = "PPU/sec²";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(196, 153);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(55, 15);
            this.label49.TabIndex = 59;
            this.label49.Text = "PPU/sec²";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(196, 122);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(51, 15);
            this.label50.TabIndex = 58;
            this.label50.Text = "PPU/sec";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(196, 91);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(51, 15);
            this.label51.TabIndex = 57;
            this.label51.Text = "PPU/sec";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown5.Location = new System.Drawing.Point(93, 87);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown5.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown5.TabIndex = 56;
            this.numericUpDown5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown5.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown7.Location = new System.Drawing.Point(93, 118);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown7.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown7.TabIndex = 55;
            this.numericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown7.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown8.Location = new System.Drawing.Point(93, 149);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown8.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown8.TabIndex = 54;
            this.numericUpDown8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown8.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.radioButton3);
            this.groupBox15.Controls.Add(this.radioButton4);
            this.groupBox15.Location = new System.Drawing.Point(38, 211);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox15.Size = new System.Drawing.Size(209, 53);
            this.groupBox15.TabIndex = 52;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "速度曲線類型";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Checked = true;
            this.radioButton3.Location = new System.Drawing.Point(21, 23);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(68, 20);
            this.radioButton3.TabIndex = 35;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "T型曲線";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(103, 23);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(68, 20);
            this.radioButton4.TabIndex = 36;
            this.radioButton4.Text = "S型曲線";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // HomePanel
            // 
            this.HomePanel.Controls.Add(this.label48);
            this.HomePanel.Controls.Add(this.label49);
            this.HomePanel.Controls.Add(this.label50);
            this.HomePanel.Controls.Add(this.label51);
            this.HomePanel.Controls.Add(this.numericUpDown5);
            this.HomePanel.Controls.Add(this.numericUpDown7);
            this.HomePanel.Controls.Add(this.numericUpDown8);
            this.HomePanel.Controls.Add(this.numericUpDown9);
            this.HomePanel.Controls.Add(this.groupBox15);
            this.HomePanel.Controls.Add(this.label52);
            this.HomePanel.Controls.Add(this.label53);
            this.HomePanel.Controls.Add(this.label54);
            this.HomePanel.Controls.Add(this.label55);
            this.HomePanel.Controls.Add(this.NumCrossDis);
            this.HomePanel.Controls.Add(this.BtnStop);
            this.HomePanel.Controls.Add(this.label37);
            this.HomePanel.Controls.Add(this.BtnHome);
            this.HomePanel.Controls.Add(this.label38);
            this.HomePanel.Controls.Add(this.CbSwitchMode);
            this.HomePanel.Controls.Add(this.label39);
            this.HomePanel.Controls.Add(this.groupBox9);
            this.HomePanel.Controls.Add(this.CbHomeMode);
            this.HomePanel.Controls.Add(this.label41);
            this.HomePanel.Controls.Add(this.CbDir);
            this.HomePanel.Controls.Add(this.label42);
            this.HomePanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.HomePanel.Location = new System.Drawing.Point(293, 22);
            this.HomePanel.Name = "HomePanel";
            this.HomePanel.Size = new System.Drawing.Size(286, 575);
            this.HomePanel.TabIndex = 60;
            this.HomePanel.TabStop = false;
            this.HomePanel.Text = "原點復歸";
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown9.Location = new System.Drawing.Point(93, 178);
            this.numericUpDown9.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown9.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown9.TabIndex = 53;
            this.numericUpDown9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown9.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(47, 181);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(43, 16);
            this.label52.TabIndex = 51;
            this.label52.Text = "減速度";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(47, 152);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(43, 16);
            this.label53.TabIndex = 50;
            this.label53.Text = "加速度";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(35, 121);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(55, 16);
            this.label54.TabIndex = 49;
            this.label54.Text = "運轉速度";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(35, 90);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(55, 16);
            this.label55.TabIndex = 48;
            this.label55.Text = "起始速度";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // NumCrossDis
            // 
            this.NumCrossDis.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumCrossDis.Location = new System.Drawing.Point(92, 507);
            this.NumCrossDis.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumCrossDis.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumCrossDis.Name = "NumCrossDis";
            this.NumCrossDis.Size = new System.Drawing.Size(120, 23);
            this.NumCrossDis.TabIndex = 42;
            this.NumCrossDis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumCrossDis.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(154, 540);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(82, 25);
            this.BtnStop.TabIndex = 39;
            this.BtnStop.Text = "停止";
            this.BtnStop.UseVisualStyleBackColor = true;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(217, 510);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(30, 16);
            this.label37.TabIndex = 41;
            this.label37.Text = "PPU";
            // 
            // BtnHome
            // 
            this.BtnHome.Location = new System.Drawing.Point(36, 540);
            this.BtnHome.Name = "BtnHome";
            this.BtnHome.Size = new System.Drawing.Size(82, 25);
            this.BtnHome.TabIndex = 38;
            this.BtnHome.Text = "復歸";
            this.BtnHome.UseVisualStyleBackColor = true;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(34, 509);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 16);
            this.label38.TabIndex = 40;
            this.label38.Text = "跨越距離";
            // 
            // CbSwitchMode
            // 
            this.CbSwitchMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbSwitchMode.FormattingEnabled = true;
            this.CbSwitchMode.Items.AddRange(new object[] {
            "Level On",
            "Level Off",
            "Rising Edge",
            "Falling Edge"});
            this.CbSwitchMode.Location = new System.Drawing.Point(92, 476);
            this.CbSwitchMode.Name = "CbSwitchMode";
            this.CbSwitchMode.Size = new System.Drawing.Size(162, 24);
            this.CbSwitchMode.TabIndex = 39;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(34, 480);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(55, 16);
            this.label39.TabIndex = 38;
            this.label39.Text = "停止模式";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Controls.Add(this.groupBox12);
            this.groupBox9.Controls.Add(this.groupBox13);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox9.Location = new System.Drawing.Point(14, 273);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(255, 189);
            this.groupBox9.TabIndex = 37;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "屬性設定";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.RbHelHigh);
            this.groupBox10.Controls.Add(this.RbHelLow);
            this.groupBox10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox10.Location = new System.Drawing.Point(12, 128);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(230, 45);
            this.groupBox10.TabIndex = 39;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "極限信號邏輯";
            // 
            // RbHelHigh
            // 
            this.RbHelHigh.AutoSize = true;
            this.RbHelHigh.Location = new System.Drawing.Point(123, 19);
            this.RbHelHigh.Name = "RbHelHigh";
            this.RbHelHigh.Size = new System.Drawing.Size(85, 20);
            this.RbHelHigh.TabIndex = 40;
            this.RbHelHigh.Text = "高電位觸發";
            this.RbHelHigh.UseVisualStyleBackColor = true;
            // 
            // RbHelLow
            // 
            this.RbHelLow.AutoSize = true;
            this.RbHelLow.Checked = true;
            this.RbHelLow.Location = new System.Drawing.Point(20, 19);
            this.RbHelLow.Name = "RbHelLow";
            this.RbHelLow.Size = new System.Drawing.Size(85, 20);
            this.RbHelLow.TabIndex = 41;
            this.RbHelLow.TabStop = true;
            this.RbHelLow.Text = "低電位觸發";
            this.RbHelLow.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.RbOrgHigh);
            this.groupBox12.Controls.Add(this.RbOrgLow);
            this.groupBox12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox12.Location = new System.Drawing.Point(12, 77);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(230, 45);
            this.groupBox12.TabIndex = 39;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "原點信號邏輯";
            // 
            // RbOrgHigh
            // 
            this.RbOrgHigh.AutoSize = true;
            this.RbOrgHigh.Location = new System.Drawing.Point(123, 19);
            this.RbOrgHigh.Name = "RbOrgHigh";
            this.RbOrgHigh.Size = new System.Drawing.Size(85, 20);
            this.RbOrgHigh.TabIndex = 42;
            this.RbOrgHigh.Text = "高電位觸發";
            this.RbOrgHigh.UseVisualStyleBackColor = true;
            // 
            // RbOrgLow
            // 
            this.RbOrgLow.AutoSize = true;
            this.RbOrgLow.Checked = true;
            this.RbOrgLow.Location = new System.Drawing.Point(20, 19);
            this.RbOrgLow.Name = "RbOrgLow";
            this.RbOrgLow.Size = new System.Drawing.Size(85, 20);
            this.RbOrgLow.TabIndex = 43;
            this.RbOrgLow.TabStop = true;
            this.RbOrgLow.Text = "低電位觸發";
            this.RbOrgLow.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.RbEzLow);
            this.groupBox13.Controls.Add(this.RbEzHigh);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(12, 26);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(230, 45);
            this.groupBox13.TabIndex = 38;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Z相信號邏輯";
            // 
            // RbEzLow
            // 
            this.RbEzLow.AutoSize = true;
            this.RbEzLow.Checked = true;
            this.RbEzLow.Location = new System.Drawing.Point(20, 20);
            this.RbEzLow.Name = "RbEzLow";
            this.RbEzLow.Size = new System.Drawing.Size(85, 20);
            this.RbEzLow.TabIndex = 39;
            this.RbEzLow.TabStop = true;
            this.RbEzLow.Text = "低電位觸發";
            this.RbEzLow.UseVisualStyleBackColor = true;
            // 
            // RbEzHigh
            // 
            this.RbEzHigh.AutoSize = true;
            this.RbEzHigh.Location = new System.Drawing.Point(123, 20);
            this.RbEzHigh.Name = "RbEzHigh";
            this.RbEzHigh.Size = new System.Drawing.Size(85, 20);
            this.RbEzHigh.TabIndex = 38;
            this.RbEzHigh.Text = "高電位觸發";
            this.RbEzHigh.UseVisualStyleBackColor = true;
            // 
            // CbHomeMode
            // 
            this.CbHomeMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbHomeMode.FormattingEnabled = true;
            this.CbHomeMode.Items.AddRange(new object[] {
            "MODE1_Abs",
            "MODE2_Lmt",
            "MODE3_Ref",
            "MODE4_Abs_Ref",
            "MODE5_Abs_NegRef",
            "MODE6_Lmt_Ref",
            "MODE7_AbsSearch",
            "MODE8_LmtSearch",
            "MODE9_AbsSearch_Ref",
            "MODE10_AbsSearch_NegRef",
            "MODE11_LmtSearch_Ref",
            "MODE12_AbsSearchReFind",
            "MODE13_LmtSearchReFind",
            "MODE14_AbsSearchReFind_Ref",
            "MODE15_AbsSearchReFind_NegRef",
            "MODE16_LmtSearchReFind_Ref"});
            this.CbHomeMode.Location = new System.Drawing.Point(53, 51);
            this.CbHomeMode.Name = "CbHomeMode";
            this.CbHomeMode.Size = new System.Drawing.Size(207, 24);
            this.CbHomeMode.TabIndex = 23;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(19, 55);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(31, 16);
            this.label41.TabIndex = 22;
            this.label41.Text = "模式";
            // 
            // CbDir
            // 
            this.CbDir.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbDir.FormattingEnabled = true;
            this.CbDir.Items.AddRange(new object[] {
            "正方向",
            "負方向"});
            this.CbDir.Location = new System.Drawing.Point(53, 22);
            this.CbDir.Name = "CbDir";
            this.CbDir.Size = new System.Drawing.Size(207, 24);
            this.CbDir.TabIndex = 21;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(19, 25);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(31, 16);
            this.label42.TabIndex = 20;
            this.label42.Text = "方向";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.HomePanel);
            this.groupBox7.Controls.Add(this.button1);
            this.groupBox7.Controls.Add(this.groupBox6);
            this.groupBox7.Controls.Add(this.VelSetupPanel);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.numericUpDown6);
            this.groupBox7.Location = new System.Drawing.Point(12, 12);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(640, 607);
            this.groupBox7.TabIndex = 60;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "旋入軸(Z)";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(205, 340);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 23);
            this.button1.TabIndex = 51;
            this.button1.Text = "取得";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label40);
            this.groupBox6.Controls.Add(this.numLead);
            this.groupBox6.Controls.Add(this.label44);
            this.groupBox6.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox6.Location = new System.Drawing.Point(20, 256);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(245, 67);
            this.groupBox6.TabIndex = 59;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "螺桿設定";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(175, 30);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(50, 15);
            this.label40.TabIndex = 48;
            this.label40.Text = "mm/rev";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(72, 211);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(100, 25);
            this.button7.TabIndex = 53;
            this.button7.Text = "設定/取得參數";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Location = new System.Drawing.Point(17, 150);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(209, 53);
            this.groupBox2.TabIndex = 52;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "速度曲線類型";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(21, 23);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(68, 20);
            this.radioButton1.TabIndex = 35;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "T型曲線";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(103, 23);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(68, 20);
            this.radioButton2.TabIndex = 36;
            this.radioButton2.Text = "S型曲線";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(175, 121);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 15);
            this.label13.TabIndex = 51;
            this.label13.Text = "PPU/sec²";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(175, 92);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 15);
            this.label14.TabIndex = 50;
            this.label14.Text = "PPU/sec²";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(175, 61);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 15);
            this.label15.TabIndex = 49;
            this.label15.Text = "PPU/sec";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(175, 30);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 15);
            this.label20.TabIndex = 48;
            this.label20.Text = "PPU/sec";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpMotionCard);
            this.tabControl1.Controls.Add(this.tpSensor);
            this.tabControl1.Controls.Add(this.tpOther);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1000, 660);
            this.tabControl1.TabIndex = 83;
            // 
            // tpMotionCard
            // 
            this.tpMotionCard.Controls.Add(this.groupBox14);
            this.tpMotionCard.Controls.Add(this.BtnSetParam);
            this.tpMotionCard.Controls.Add(this.groupBox8);
            this.tpMotionCard.Controls.Add(this.groupBox7);
            this.tpMotionCard.Location = new System.Drawing.Point(4, 25);
            this.tpMotionCard.Name = "tpMotionCard";
            this.tpMotionCard.Padding = new System.Windows.Forms.Padding(9);
            this.tpMotionCard.Size = new System.Drawing.Size(992, 631);
            this.tpMotionCard.TabIndex = 0;
            this.tpMotionCard.Text = "運動控制卡";
            this.tpMotionCard.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.cbEmgLogic);
            this.groupBox14.Controls.Add(this.label45);
            this.groupBox14.Controls.Add(this.label46);
            this.groupBox14.Controls.Add(this.numEmgFilterTime);
            this.groupBox14.Controls.Add(this.label47);
            this.groupBox14.Location = new System.Drawing.Point(691, 352);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(289, 102);
            this.groupBox14.TabIndex = 61;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "EMG緊急停止";
            // 
            // cbEmgLogic
            // 
            this.cbEmgLogic.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEmgLogic.FormattingEnabled = true;
            this.cbEmgLogic.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.cbEmgLogic.Location = new System.Drawing.Point(76, 31);
            this.cbEmgLogic.Name = "cbEmgLogic";
            this.cbEmgLogic.Size = new System.Drawing.Size(191, 24);
            this.cbEmgLogic.TabIndex = 187;
            // 
            // label45
            // 
            this.label45.Location = new System.Drawing.Point(17, 32);
            this.label45.Margin = new System.Windows.Forms.Padding(0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(86, 23);
            this.label45.TabIndex = 188;
            this.label45.Text = "EMG電位";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label46
            // 
            this.label46.Location = new System.Drawing.Point(186, 66);
            this.label46.Margin = new System.Windows.Forms.Padding(0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(34, 17);
            this.label46.TabIndex = 186;
            this.label46.Text = "μs";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numEmgFilterTime
            // 
            this.numEmgFilterTime.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.numEmgFilterTime.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numEmgFilterTime.Location = new System.Drawing.Point(100, 62);
            this.numEmgFilterTime.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numEmgFilterTime.Name = "numEmgFilterTime";
            this.numEmgFilterTime.Size = new System.Drawing.Size(84, 23);
            this.numEmgFilterTime.TabIndex = 184;
            this.numEmgFilterTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numEmgFilterTime.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label47
            // 
            this.label47.Font = new System.Drawing.Font("微軟正黑體", 9F);
            this.label47.Location = new System.Drawing.Point(17, 62);
            this.label47.Margin = new System.Windows.Forms.Padding(0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(89, 23);
            this.label47.TabIndex = 185;
            this.label47.Text = "EMG濾波時間";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // BtnSetParam
            // 
            this.BtnSetParam.Location = new System.Drawing.Point(780, 566);
            this.BtnSetParam.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSetParam.Name = "BtnSetParam";
            this.BtnSetParam.Size = new System.Drawing.Size(129, 31);
            this.BtnSetParam.TabIndex = 48;
            this.BtnSetParam.Text = "儲存參數";
            this.BtnSetParam.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.groupBox1);
            this.groupBox8.Location = new System.Drawing.Point(691, 12);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(289, 284);
            this.groupBox8.TabIndex = 61;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "轉動軸(R)";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.numericUpDown2);
            this.groupBox1.Controls.Add(this.numericUpDown3);
            this.groupBox1.Controls.Add(this.numericUpDown4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(22, 23);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(245, 249);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本速率設定";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(72, 26);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown1.TabIndex = 43;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(72, 57);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown2.TabIndex = 42;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown2.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(72, 88);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown3.TabIndex = 41;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown3.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown4.Location = new System.Drawing.Point(72, 117);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown4.TabIndex = 40;
            this.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown4.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 120);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "減速度";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 91);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 30;
            this.label2.Text = "加速度";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 60);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "運轉速度";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 29);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 26;
            this.label4.Text = "起始速度";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SetupPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SetupPage";
            this.Size = new System.Drawing.Size(1000, 660);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tbTorqueLimitL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbTorqueLimitH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numAngleCompensation)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSectionLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numClockRate)).EndInit();
            this.tpSensor.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.Gb_HeightDisplacement.ResumeLayout(false);
            this.Gb_HeightDisplacement.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbHeightDispLimitL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbHeightDispLimitH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            this.VelSetupPanel.ResumeLayout(false);
            this.VelSetupPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numLead)).EndInit();
            this.tpOther.ResumeLayout(false);
            this.tpOther.PerformLayout();
            this.DevicePanel.ResumeLayout(false);
            this.DevicePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.HomePanel.ResumeLayout(false);
            this.HomePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumCrossDis)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tpMotionCard.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numEmgFilterTime)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown tbTorqueLimitL;
        private System.Windows.Forms.NumericUpDown tbTorqueLimitH;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown numAngleCompensation;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbGateMarkCylinder;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cbTorqueMeterPort;
        private System.Windows.Forms.Button btnUpdateUsb4704;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown numSectionLength;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown numClockRate;
        private System.Windows.Forms.TabPage tpSensor;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox Gb_HeightDisplacement;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown tbHeightDispLimitL;
        private System.Windows.Forms.NumericUpDown tbHeightDispLimitH;
        private System.Windows.Forms.Button BtnHeightDispReconnect;
        private System.Windows.Forms.ComboBox CbHeightDispDataBits;
        private System.Windows.Forms.Label label_StopBits;
        private System.Windows.Forms.ComboBox CbHeightDispStopBits;
        private System.Windows.Forms.Label label_DataBits;
        private System.Windows.Forms.Label label_Parity;
        private System.Windows.Forms.ComboBox CbHeightDispParity;
        private System.Windows.Forms.Label label_BaudRate;
        private System.Windows.Forms.ComboBox CbHeightDispBaudRate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox CbHeightDispCom;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        public System.Windows.Forms.RadioButton RbTCurver;
        public System.Windows.Forms.RadioButton RbSCurver;
        private System.Windows.Forms.TextBox tbUsb4704DeviceCode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox VelSetupPanel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown NumVelL;
        private System.Windows.Forms.NumericUpDown NumVelH;
        private System.Windows.Forms.NumericUpDown NumAcc;
        private System.Windows.Forms.NumericUpDown NumDec;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown numLead;
        private System.Windows.Forms.TabPage tpOther;
        private System.Windows.Forms.GroupBox DevicePanel;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox CbAvailableDevice;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnServoOn;
        private System.Windows.Forms.Button BtnUpdatePortNames;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.GroupBox groupBox15;
        public System.Windows.Forms.RadioButton radioButton3;
        public System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox HomePanel;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.NumericUpDown NumCrossDis;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button BtnHome;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox CbSwitchMode;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton RbHelHigh;
        private System.Windows.Forms.RadioButton RbHelLow;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.RadioButton RbOrgHigh;
        private System.Windows.Forms.RadioButton RbOrgLow;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.RadioButton RbEzLow;
        private System.Windows.Forms.RadioButton RbEzHigh;
        private System.Windows.Forms.ComboBox CbHomeMode;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox CbDir;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.RadioButton radioButton1;
        public System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpMotionCard;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox cbEmgLogic;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.NumericUpDown numEmgFilterTime;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button BtnSetParam;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}
