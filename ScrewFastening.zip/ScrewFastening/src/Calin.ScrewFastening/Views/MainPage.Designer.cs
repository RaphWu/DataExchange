﻿namespace Calin.ScrewFastening.Views
{
    partial class MainPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTest2 = new System.Windows.Forms.Button();
            this.btnTest1 = new System.Windows.Forms.Button();
            this.cbIsMeasuring = new System.Windows.Forms.CheckBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.gbTorqueMeter = new System.Windows.Forms.GroupBox();
            this.indTorqueFinalValue = new Calin.UI.FA.ThresholdIndicator();
            this.indTorqueMaxValue = new Calin.UI.FA.ThresholdIndicator();
            this.indTorqueValue = new Calin.UI.FA.ThresholdIndicator();
            this.lbTorqueLimitL = new System.Windows.Forms.Label();
            this.lbTorqueLimitH = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbHeightDisplacementLimitH = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbHeightDisplacementLimitL = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.gbHeightDisplacement = new System.Windows.Forms.GroupBox();
            this.indHeightDisplacementFinalValue = new Calin.UI.FA.ThresholdIndicator();
            this.indHeightDisplacementMaxValue = new Calin.UI.FA.ThresholdIndicator();
            this.indHeightDisplacementValue = new Calin.UI.FA.ThresholdIndicator();
            this.gbTorqueMeter.SuspendLayout();
            this.gbHeightDisplacement.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTest2
            // 
            this.btnTest2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTest2.Location = new System.Drawing.Point(733, 607);
            this.btnTest2.Name = "btnTest2";
            this.btnTest2.Size = new System.Drawing.Size(75, 23);
            this.btnTest2.TabIndex = 75;
            this.btnTest2.Text = "Test 2";
            this.btnTest2.UseVisualStyleBackColor = true;
            this.btnTest2.Click += new System.EventHandler(this.btnTest2_Click);
            // 
            // btnTest1
            // 
            this.btnTest1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTest1.Location = new System.Drawing.Point(814, 607);
            this.btnTest1.Name = "btnTest1";
            this.btnTest1.Size = new System.Drawing.Size(75, 23);
            this.btnTest1.TabIndex = 74;
            this.btnTest1.Text = "Test 1";
            this.btnTest1.UseVisualStyleBackColor = true;
            this.btnTest1.Click += new System.EventHandler(this.btnTest1_Click);
            // 
            // cbIsMeasuring
            // 
            this.cbIsMeasuring.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cbIsMeasuring.AutoSize = true;
            this.cbIsMeasuring.Location = new System.Drawing.Point(894, 581);
            this.cbIsMeasuring.Name = "cbIsMeasuring";
            this.cbIsMeasuring.Size = new System.Drawing.Size(63, 20);
            this.cbIsMeasuring.TabIndex = 73;
            this.cbIsMeasuring.Text = "鎖付中";
            this.cbIsMeasuring.UseVisualStyleBackColor = true;
            this.cbIsMeasuring.Click += new System.EventHandler(this.cbIsMeasuring_Click);
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Location = new System.Drawing.Point(895, 607);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 72;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label12.Location = new System.Drawing.Point(378, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 38);
            this.label12.TabIndex = 11;
            this.label12.Text = "最終值";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gbTorqueMeter
            // 
            this.gbTorqueMeter.Controls.Add(this.indTorqueFinalValue);
            this.gbTorqueMeter.Controls.Add(this.indTorqueMaxValue);
            this.gbTorqueMeter.Controls.Add(this.indTorqueValue);
            this.gbTorqueMeter.Controls.Add(this.label12);
            this.gbTorqueMeter.Controls.Add(this.lbTorqueLimitL);
            this.gbTorqueMeter.Controls.Add(this.lbTorqueLimitH);
            this.gbTorqueMeter.Controls.Add(this.label19);
            this.gbTorqueMeter.Controls.Add(this.label20);
            this.gbTorqueMeter.Controls.Add(this.label21);
            this.gbTorqueMeter.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.gbTorqueMeter.Location = new System.Drawing.Point(19, 157);
            this.gbTorqueMeter.Margin = new System.Windows.Forms.Padding(4);
            this.gbTorqueMeter.Name = "gbTorqueMeter";
            this.gbTorqueMeter.Padding = new System.Windows.Forms.Padding(4);
            this.gbTorqueMeter.Size = new System.Drawing.Size(455, 130);
            this.gbTorqueMeter.TabIndex = 71;
            this.gbTorqueMeter.TabStop = false;
            this.gbTorqueMeter.Text = "扭力";
            // 
            // indTorqueFinalValue
            // 
            this.indTorqueFinalValue.AboveBackColor = System.Drawing.Color.Firebrick;
            this.indTorqueFinalValue.AboveComparison = Calin.UI.FA.ComparisonType.GreaterThan;
            this.indTorqueFinalValue.AboveForeColor = System.Drawing.Color.White;
            this.indTorqueFinalValue.AutoScaleText = false;
            this.indTorqueFinalValue.BelowBackColor = System.Drawing.Color.Gainsboro;
            this.indTorqueFinalValue.BelowComparison = Calin.UI.FA.ComparisonType.LessThan;
            this.indTorqueFinalValue.BelowForeColor = System.Drawing.Color.Black;
            this.indTorqueFinalValue.BetweenBackColor = System.Drawing.Color.LimeGreen;
            this.indTorqueFinalValue.BetweenForeColor = System.Drawing.Color.Black;
            this.indTorqueFinalValue.BorderColor = System.Drawing.Color.Black;
            this.indTorqueFinalValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.indTorqueFinalValue.DecimalPlaces = 3;
            this.indTorqueFinalValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.indTorqueFinalValue.Location = new System.Drawing.Point(276, 75);
            this.indTorqueFinalValue.Name = "indTorqueFinalValue";
            this.indTorqueFinalValue.Size = new System.Drawing.Size(100, 38);
            this.indTorqueFinalValue.TabIndex = 79;
            this.indTorqueFinalValue.TabStop = false;
            this.indTorqueFinalValue.ThresholdAbove = 100D;
            this.indTorqueFinalValue.ThresholdBelow = 0D;
            this.indTorqueFinalValue.Value = 0D;
            // 
            // indTorqueMaxValue
            // 
            this.indTorqueMaxValue.AboveBackColor = System.Drawing.Color.Firebrick;
            this.indTorqueMaxValue.AboveComparison = Calin.UI.FA.ComparisonType.GreaterThan;
            this.indTorqueMaxValue.AboveForeColor = System.Drawing.Color.White;
            this.indTorqueMaxValue.AutoScaleText = false;
            this.indTorqueMaxValue.BelowBackColor = System.Drawing.Color.Gainsboro;
            this.indTorqueMaxValue.BelowComparison = Calin.UI.FA.ComparisonType.LessThan;
            this.indTorqueMaxValue.BelowForeColor = System.Drawing.Color.Black;
            this.indTorqueMaxValue.BetweenBackColor = System.Drawing.Color.LimeGreen;
            this.indTorqueMaxValue.BetweenForeColor = System.Drawing.Color.Black;
            this.indTorqueMaxValue.BorderColor = System.Drawing.Color.Black;
            this.indTorqueMaxValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.indTorqueMaxValue.DecimalPlaces = 3;
            this.indTorqueMaxValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.indTorqueMaxValue.Location = new System.Drawing.Point(276, 33);
            this.indTorqueMaxValue.Name = "indTorqueMaxValue";
            this.indTorqueMaxValue.Size = new System.Drawing.Size(100, 38);
            this.indTorqueMaxValue.TabIndex = 78;
            this.indTorqueMaxValue.TabStop = false;
            this.indTorqueMaxValue.ThresholdAbove = 100D;
            this.indTorqueMaxValue.ThresholdBelow = 0D;
            this.indTorqueMaxValue.Value = 0D;
            // 
            // indTorqueValue
            // 
            this.indTorqueValue.AboveBackColor = System.Drawing.Color.Firebrick;
            this.indTorqueValue.AboveComparison = Calin.UI.FA.ComparisonType.GreaterThan;
            this.indTorqueValue.AboveForeColor = System.Drawing.Color.White;
            this.indTorqueValue.AutoScaleText = false;
            this.indTorqueValue.BelowBackColor = System.Drawing.Color.Gainsboro;
            this.indTorqueValue.BelowComparison = Calin.UI.FA.ComparisonType.LessThan;
            this.indTorqueValue.BelowForeColor = System.Drawing.Color.Black;
            this.indTorqueValue.BetweenBackColor = System.Drawing.Color.LimeGreen;
            this.indTorqueValue.BetweenForeColor = System.Drawing.Color.Black;
            this.indTorqueValue.BorderColor = System.Drawing.Color.Black;
            this.indTorqueValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.indTorqueValue.DecimalPlaces = 3;
            this.indTorqueValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.indTorqueValue.Location = new System.Drawing.Point(165, 33);
            this.indTorqueValue.Name = "indTorqueValue";
            this.indTorqueValue.Size = new System.Drawing.Size(105, 80);
            this.indTorqueValue.TabIndex = 77;
            this.indTorqueValue.TabStop = false;
            this.indTorqueValue.ThresholdAbove = 100D;
            this.indTorqueValue.ThresholdBelow = 0D;
            this.indTorqueValue.Value = 0D;
            // 
            // lbTorqueLimitL
            // 
            this.lbTorqueLimitL.BackColor = System.Drawing.Color.White;
            this.lbTorqueLimitL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueLimitL.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbTorqueLimitL.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbTorqueLimitL.Location = new System.Drawing.Point(59, 75);
            this.lbTorqueLimitL.Name = "lbTorqueLimitL";
            this.lbTorqueLimitL.Size = new System.Drawing.Size(100, 38);
            this.lbTorqueLimitL.TabIndex = 7;
            this.lbTorqueLimitL.Text = "888.888";
            this.lbTorqueLimitL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTorqueLimitH
            // 
            this.lbTorqueLimitH.BackColor = System.Drawing.Color.White;
            this.lbTorqueLimitH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueLimitH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbTorqueLimitH.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbTorqueLimitH.Location = new System.Drawing.Point(59, 33);
            this.lbTorqueLimitH.Name = "lbTorqueLimitH";
            this.lbTorqueLimitH.Size = new System.Drawing.Size(100, 38);
            this.lbTorqueLimitH.TabIndex = 6;
            this.lbTorqueLimitH.Text = "888.888";
            this.lbTorqueLimitH.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label19.Location = new System.Drawing.Point(378, 33);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 38);
            this.label19.TabIndex = 5;
            this.label19.Text = "最大值";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label20.Location = new System.Drawing.Point(7, 75);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(50, 38);
            this.label20.TabIndex = 3;
            this.label20.Text = "下限";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label21.Location = new System.Drawing.Point(7, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(50, 38);
            this.label21.TabIndex = 2;
            this.label21.Text = "上限";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbHeightDisplacementLimitH
            // 
            this.lbHeightDisplacementLimitH.BackColor = System.Drawing.Color.White;
            this.lbHeightDisplacementLimitH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHeightDisplacementLimitH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbHeightDisplacementLimitH.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbHeightDisplacementLimitH.Location = new System.Drawing.Point(59, 33);
            this.lbHeightDisplacementLimitH.Name = "lbHeightDisplacementLimitH";
            this.lbHeightDisplacementLimitH.Size = new System.Drawing.Size(100, 38);
            this.lbHeightDisplacementLimitH.TabIndex = 6;
            this.lbHeightDisplacementLimitH.Text = "888.888";
            this.lbHeightDisplacementLimitH.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label14.Location = new System.Drawing.Point(378, 33);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 38);
            this.label14.TabIndex = 5;
            this.label14.Text = "最大值";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label15.Location = new System.Drawing.Point(7, 75);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 38);
            this.label15.TabIndex = 3;
            this.label15.Text = "下限";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label10.Location = new System.Drawing.Point(378, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 38);
            this.label10.TabIndex = 11;
            this.label10.Text = "最終值";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbHeightDisplacementLimitL
            // 
            this.lbHeightDisplacementLimitL.BackColor = System.Drawing.Color.White;
            this.lbHeightDisplacementLimitL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHeightDisplacementLimitL.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbHeightDisplacementLimitL.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbHeightDisplacementLimitL.Location = new System.Drawing.Point(59, 75);
            this.lbHeightDisplacementLimitL.Name = "lbHeightDisplacementLimitL";
            this.lbHeightDisplacementLimitL.Size = new System.Drawing.Size(100, 38);
            this.lbHeightDisplacementLimitL.TabIndex = 7;
            this.lbHeightDisplacementLimitL.Text = "888.888";
            this.lbHeightDisplacementLimitL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label16.Location = new System.Drawing.Point(7, 33);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 38);
            this.label16.TabIndex = 2;
            this.label16.Text = "上限";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gbHeightDisplacement
            // 
            this.gbHeightDisplacement.Controls.Add(this.indHeightDisplacementFinalValue);
            this.gbHeightDisplacement.Controls.Add(this.indHeightDisplacementMaxValue);
            this.gbHeightDisplacement.Controls.Add(this.indHeightDisplacementValue);
            this.gbHeightDisplacement.Controls.Add(this.label10);
            this.gbHeightDisplacement.Controls.Add(this.lbHeightDisplacementLimitL);
            this.gbHeightDisplacement.Controls.Add(this.lbHeightDisplacementLimitH);
            this.gbHeightDisplacement.Controls.Add(this.label14);
            this.gbHeightDisplacement.Controls.Add(this.label15);
            this.gbHeightDisplacement.Controls.Add(this.label16);
            this.gbHeightDisplacement.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.gbHeightDisplacement.Location = new System.Drawing.Point(19, 19);
            this.gbHeightDisplacement.Margin = new System.Windows.Forms.Padding(4);
            this.gbHeightDisplacement.Name = "gbHeightDisplacement";
            this.gbHeightDisplacement.Padding = new System.Windows.Forms.Padding(4);
            this.gbHeightDisplacement.Size = new System.Drawing.Size(455, 130);
            this.gbHeightDisplacement.TabIndex = 70;
            this.gbHeightDisplacement.TabStop = false;
            this.gbHeightDisplacement.Text = "高度 (mm)";
            // 
            // indHeightDisplacementFinalValue
            // 
            this.indHeightDisplacementFinalValue.AboveBackColor = System.Drawing.Color.Firebrick;
            this.indHeightDisplacementFinalValue.AboveComparison = Calin.UI.FA.ComparisonType.GreaterThan;
            this.indHeightDisplacementFinalValue.AboveForeColor = System.Drawing.Color.White;
            this.indHeightDisplacementFinalValue.AutoScaleText = false;
            this.indHeightDisplacementFinalValue.BelowBackColor = System.Drawing.Color.Gainsboro;
            this.indHeightDisplacementFinalValue.BelowComparison = Calin.UI.FA.ComparisonType.LessThan;
            this.indHeightDisplacementFinalValue.BelowForeColor = System.Drawing.Color.Black;
            this.indHeightDisplacementFinalValue.BetweenBackColor = System.Drawing.Color.LimeGreen;
            this.indHeightDisplacementFinalValue.BetweenForeColor = System.Drawing.Color.Black;
            this.indHeightDisplacementFinalValue.BorderColor = System.Drawing.Color.Black;
            this.indHeightDisplacementFinalValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.indHeightDisplacementFinalValue.DecimalPlaces = 3;
            this.indHeightDisplacementFinalValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.indHeightDisplacementFinalValue.Location = new System.Drawing.Point(276, 75);
            this.indHeightDisplacementFinalValue.Name = "indHeightDisplacementFinalValue";
            this.indHeightDisplacementFinalValue.Size = new System.Drawing.Size(100, 38);
            this.indHeightDisplacementFinalValue.TabIndex = 81;
            this.indHeightDisplacementFinalValue.TabStop = false;
            this.indHeightDisplacementFinalValue.ThresholdAbove = 100D;
            this.indHeightDisplacementFinalValue.ThresholdBelow = 0D;
            this.indHeightDisplacementFinalValue.Value = 0D;
            // 
            // indHeightDisplacementMaxValue
            // 
            this.indHeightDisplacementMaxValue.AboveBackColor = System.Drawing.Color.Firebrick;
            this.indHeightDisplacementMaxValue.AboveComparison = Calin.UI.FA.ComparisonType.GreaterThan;
            this.indHeightDisplacementMaxValue.AboveForeColor = System.Drawing.Color.White;
            this.indHeightDisplacementMaxValue.AutoScaleText = false;
            this.indHeightDisplacementMaxValue.BelowBackColor = System.Drawing.Color.Gainsboro;
            this.indHeightDisplacementMaxValue.BelowComparison = Calin.UI.FA.ComparisonType.LessThan;
            this.indHeightDisplacementMaxValue.BelowForeColor = System.Drawing.Color.Black;
            this.indHeightDisplacementMaxValue.BetweenBackColor = System.Drawing.Color.LimeGreen;
            this.indHeightDisplacementMaxValue.BetweenForeColor = System.Drawing.Color.Black;
            this.indHeightDisplacementMaxValue.BorderColor = System.Drawing.Color.Black;
            this.indHeightDisplacementMaxValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.indHeightDisplacementMaxValue.DecimalPlaces = 3;
            this.indHeightDisplacementMaxValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.indHeightDisplacementMaxValue.Location = new System.Drawing.Point(276, 33);
            this.indHeightDisplacementMaxValue.Name = "indHeightDisplacementMaxValue";
            this.indHeightDisplacementMaxValue.Size = new System.Drawing.Size(100, 38);
            this.indHeightDisplacementMaxValue.TabIndex = 80;
            this.indHeightDisplacementMaxValue.TabStop = false;
            this.indHeightDisplacementMaxValue.ThresholdAbove = 100D;
            this.indHeightDisplacementMaxValue.ThresholdBelow = 0D;
            this.indHeightDisplacementMaxValue.Value = 0D;
            // 
            // indHeightDisplacementValue
            // 
            this.indHeightDisplacementValue.AboveBackColor = System.Drawing.Color.Firebrick;
            this.indHeightDisplacementValue.AboveComparison = Calin.UI.FA.ComparisonType.GreaterThan;
            this.indHeightDisplacementValue.AboveForeColor = System.Drawing.Color.White;
            this.indHeightDisplacementValue.AutoScaleText = false;
            this.indHeightDisplacementValue.BelowBackColor = System.Drawing.Color.Gainsboro;
            this.indHeightDisplacementValue.BelowComparison = Calin.UI.FA.ComparisonType.LessThan;
            this.indHeightDisplacementValue.BelowForeColor = System.Drawing.Color.Black;
            this.indHeightDisplacementValue.BetweenBackColor = System.Drawing.Color.LimeGreen;
            this.indHeightDisplacementValue.BetweenForeColor = System.Drawing.Color.Black;
            this.indHeightDisplacementValue.BorderColor = System.Drawing.Color.Black;
            this.indHeightDisplacementValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.indHeightDisplacementValue.DecimalPlaces = 3;
            this.indHeightDisplacementValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.indHeightDisplacementValue.Location = new System.Drawing.Point(165, 33);
            this.indHeightDisplacementValue.Name = "indHeightDisplacementValue";
            this.indHeightDisplacementValue.Size = new System.Drawing.Size(105, 80);
            this.indHeightDisplacementValue.TabIndex = 78;
            this.indHeightDisplacementValue.TabStop = false;
            this.indHeightDisplacementValue.ThresholdAbove = 100D;
            this.indHeightDisplacementValue.ThresholdBelow = 0D;
            this.indHeightDisplacementValue.Value = 0D;
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnTest2);
            this.Controls.Add(this.btnTest1);
            this.Controls.Add(this.cbIsMeasuring);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.gbTorqueMeter);
            this.Controls.Add(this.gbHeightDisplacement);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainPage";
            this.Padding = new System.Windows.Forms.Padding(15);
            this.Size = new System.Drawing.Size(1000, 660);
            this.gbTorqueMeter.ResumeLayout(false);
            this.gbHeightDisplacement.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnTest2;
        private System.Windows.Forms.Button btnTest1;
        private System.Windows.Forms.CheckBox cbIsMeasuring;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox gbTorqueMeter;
        private System.Windows.Forms.Label lbTorqueLimitL;
        private System.Windows.Forms.Label lbTorqueLimitH;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbHeightDisplacementLimitH;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbHeightDisplacementLimitL;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox gbHeightDisplacement;
        private Calin.UI.FA.ThresholdIndicator indTorqueFinalValue;
        private Calin.UI.FA.ThresholdIndicator indTorqueMaxValue;
        private Calin.UI.FA.ThresholdIndicator indTorqueValue;
        private Calin.UI.FA.ThresholdIndicator indHeightDisplacementValue;
        private Calin.UI.FA.ThresholdIndicator indHeightDisplacementFinalValue;
        private Calin.UI.FA.ThresholdIndicator indHeightDisplacementMaxValue;
    }
}
