﻿using Calin.ScrewFastening.ProcessFlow.Editor;
using Calin.ScrewFastening.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.ScrewFastening.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// 延遲工序參數編輯器。
    /// </summary>
    public partial class DelayEditor : ProcessEditorBase
    {
        public override string ProcessId => ProcessIds.DELAY;

        public DelayEditor()
        {
            InitializeComponent();

            numDelayMs.ValueChanged += (s, e) => OnParamChanged();
            tbDescription.TextChanged += (s, e) => OnParamChanged();
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new DelayParam()
                : JsonConvert.DeserializeObject<DelayParam>(paramJson) ?? new DelayParam();

            numDelayMs.Value = param.DelayMilliseconds;
            tbDescription.Text = param.Description ?? "";
        }

        public override string Save()
        {
            var param = new DelayParam
            {
                DelayMilliseconds = (int)numDelayMs.Value,
                Description = tbDescription.Text
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (numDelayMs.Value < 0)
                return "延遲時間不可為負數";

            return null;
        }
    }
}
