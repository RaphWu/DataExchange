﻿using System;

namespace Calin.ScrewFastening.ProcessFlow.Engine
{
    /// <summary>
    /// 工序執行結果。
    /// </summary>
    public class ProcessExecutionResult
    {
        /// <summary>
        /// 是否執行成功。
        /// </summary>
        public bool Success { get; }

        /// <summary>
        /// 錯誤訊息（若執行失敗）。
        /// </summary>
        public string ErrorMessage { get; }

        /// <summary>
        /// 例外（若執行發生例外）。
        /// </summary>
        public Exception Exception { get; }

        private ProcessExecutionResult(bool success, string errorMessage = null, Exception exception = null)
        {
            Success = success;
            ErrorMessage = errorMessage;
            Exception = exception;
        }

        /// <summary>
        /// 建立成功的執行結果。
        /// </summary>
        public static ProcessExecutionResult Succeeded() => new ProcessExecutionResult(true);

        /// <summary>
        /// 建立失敗的執行結果。
        /// </summary>
        public static ProcessExecutionResult Failed(string errorMessage)
            => new ProcessExecutionResult(false, errorMessage);

        /// <summary>
        /// 建立失敗的執行結果。
        /// </summary>
        public static ProcessExecutionResult Failed(Exception exception)
            => new ProcessExecutionResult(false, exception?.Message, exception);
    }
}
