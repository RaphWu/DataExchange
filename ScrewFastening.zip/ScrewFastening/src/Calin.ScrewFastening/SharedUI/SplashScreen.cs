﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Calin.ScrewFastening.SharedUI
{
    /// <summary>
    /// 啟動畫面。
    /// </summary>
    public partial class SplashScreen : Form
    {
        // 啟用無標題列拖曳窗體的功能
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        #region fields

        /// <summary>
        /// 儲存顯示訊息的清單。
        /// </summary>
        private readonly List<string> _msg = new List<string>();

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;

        /// <summary>
        /// 當使用者點擊退出按鈕時觸發的事件。
        /// </summary>
        public event EventHandler AbortClicked;

        #endregion fields

        /// <summary>
        /// 初始化 <see cref="SplashScreen"/> 類別的新執行個體。
        /// </summary>
        public SplashScreen()
        {
            InitializeComponent();

            this.FormBorderStyle = FormBorderStyle.None;
            EnableDragging(this);
        }

        /// <summary>
        /// 在啟動畫面關閉時執行的事件處理方法。
        /// </summary>
        private void SplashScreen_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 關閉訊息傳遞系統
            SplashMessenger.Shutdown();
        }

        /// <summary>
        /// 在啟動畫面載入時執行的事件處理方法。
        /// </summary>
        private void SplashScreen_Load(object sender, EventArgs e)
        {
            // 初始化訊息傳遞系統，將訊息新增到顯示清單中
            SplashMessenger.Initialize(SynchronizationContext.Current, msg => AddMessage(msg));
        }

        /// <summary>
        /// 新增一則訊息到顯示清單中。
        /// </summary>
        /// <param name="msg">要新增的訊息。</param>
        public void AddMessage(string msg)
        {
            _msg.Insert(0, msg);
            string displayMsg = string.Join(Environment.NewLine, _msg.Take(9).Reverse());

            if (msgList.InvokeRequired)
                msgList.Invoke(new Action(() => msgList.Text = displayMsg));
            else
                msgList.Text = displayMsg;
        }

        /// <summary>
        /// 啟用表單或控制項的拖曳功能。
        /// </summary>
        /// <param name="control">要啟用拖曳功能的控制項。</param>
        private void EnableDragging(Control control)
        {
            control.MouseDown += (s, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    ReleaseCapture();
                    SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                }
            };

            // 遞歸處理子控制項
            foreach (Control child in control.Controls)
            {
                EnableDragging(child);
            }
        }

        /// <summary>
        /// 退出按鈕的點擊事件。
        /// </summary>
        private void AbortLoading_Click(object sender, EventArgs e)
        {
            AbortClicked?.Invoke(this, EventArgs.Empty);
        }
    }
}
