﻿using Calin.ScrewFastening.Models;

namespace Calin.ScrewFastening.Services
{
    /// <summary>
    /// 高度計服務介面。
    /// </summary>
    public interface IScrewFastening_Dlrs1a
    {
        /// <summary>
        /// 初始化 DL_RS1A 位移計。
        /// </summary>
        void Dlrs1aInit();

        /// <summary>
        /// 關閉 DL_RS1A 位移計。
        /// </summary>
        void Dlrs1aClose();

        /// <summary>
        /// 儲存 DL_RS1A 配置。
        /// </summary>
        void Dlrs1aSaveConfig(Dlrs1aData config);

        /// <summary>
        /// 載入 DL_RS1A 配置。
        /// </summary>
        /// <returns>DL_RS1A 配置。</returns>
        void Dlrs1aLoadConfig();
    }
}