﻿using Calin.ScrewFastening.Models;

namespace Calin.ScrewFastening.Services
{
    public interface IScrewFastening_DAQ
    {
        /// <summary>
        /// 初始化 DL_RS1A 位移計。
        /// </summary>
        void DaqInit();

        /// <summary>
        /// 關閉 DL_RS1A 位移計。
        /// </summary>
        void DaqClose();

        /// <summary>
        /// 儲存 DL_RS1A 配置。
        /// </summary>
        void DaqSaveConfig(DaqData config);

        /// <summary>
        /// 載入 DL_RS1A 配置。
        /// </summary>
        /// <returns>DL_RS1A 配置。</returns>
        void DaqLoadConfig();

        /// <summary>
        /// 開始資料擷取。
        /// </summary>
        void DaqStartAcquisition();

        /// <summary>
        /// 停止資料擷取。
        /// </summary>
        void DaqStopAcquisition();
    }
}
