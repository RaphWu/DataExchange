﻿namespace Calin.ScrewFastening.Views
{
    partial class Monitor
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Monitor));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbMotionCard = new System.Windows.Forms.TabPage();
            this.dioIndicator = new Calin.UI.FA.MultiCircularIndicator();
            this.BtnStopEmg = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.BtnStopDec = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btnSetParam = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.axis2Indicator = new Calin.UI.FA.MultiCircularIndicator();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.axis1Indicator = new Calin.UI.FA.MultiCircularIndicator();
            this.tbIO = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tbMotionCard.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tbIO.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbMotionCard);
            this.tabControl1.Controls.Add(this.tbIO);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1000, 706);
            this.tabControl1.TabIndex = 27;
            // 
            // tbMotionCard
            // 
            this.tbMotionCard.Controls.Add(this.dioIndicator);
            this.tbMotionCard.Controls.Add(this.BtnStopEmg);
            this.tbMotionCard.Controls.Add(this.button1);
            this.tbMotionCard.Controls.Add(this.BtnStopDec);
            this.tbMotionCard.Controls.Add(this.button10);
            this.tbMotionCard.Controls.Add(this.button8);
            this.tbMotionCard.Controls.Add(this.button9);
            this.tbMotionCard.Controls.Add(this.btnSetParam);
            this.tbMotionCard.Controls.Add(this.groupBox2);
            this.tbMotionCard.Controls.Add(this.groupBox1);
            this.tbMotionCard.Location = new System.Drawing.Point(4, 25);
            this.tbMotionCard.Name = "tbMotionCard";
            this.tbMotionCard.Padding = new System.Windows.Forms.Padding(15);
            this.tbMotionCard.Size = new System.Drawing.Size(992, 677);
            this.tbMotionCard.TabIndex = 0;
            this.tbMotionCard.Text = "運動控制卡";
            this.tbMotionCard.UseVisualStyleBackColor = true;
            // 
            // dioIndicator
            // 
            this.dioIndicator.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dioIndicator.BackColor = System.Drawing.Color.Transparent;
            this.dioIndicator.BorderColor = System.Drawing.Color.Black;
            this.dioIndicator.ColumnHeaders = ((System.Collections.Generic.List<string>)(resources.GetObject("dioIndicator.ColumnHeaders")));
            this.dioIndicator.Columns = ((System.Collections.Generic.List<int>)(resources.GetObject("dioIndicator.Columns")));
            this.dioIndicator.ColumnSpacing = 8;
            this.dioIndicator.HeaderBottomSpacing = 6;
            this.dioIndicator.HeaderFont = new System.Drawing.Font("微軟正黑體", 9F);
            this.dioIndicator.HeaderHeight = 22;
            this.dioIndicator.HeaderLineColor = System.Drawing.Color.DarkGray;
            this.dioIndicator.HeaderLineThickness = 2;
            this.dioIndicator.HeaderTextColor = System.Drawing.Color.Black;
            this.dioIndicator.HoverColor = System.Drawing.Color.Yellow;
            this.dioIndicator.IndicatorSize = 20;
            this.dioIndicator.Location = new System.Drawing.Point(431, 501);
            this.dioIndicator.Name = "dioIndicator";
            this.dioIndicator.OffColor = System.Drawing.Color.DimGray;
            this.dioIndicator.OnColor = System.Drawing.Color.Lime;
            this.dioIndicator.RowSpacing = 4;
            this.dioIndicator.Size = new System.Drawing.Size(385, 157);
            this.dioIndicator.TabIndex = 2;
            this.dioIndicator.Text = "multiCircularIndicator1";
            this.dioIndicator.TextColor = System.Drawing.Color.Black;
            this.dioIndicator.TextSpacing = 5;
            // 
            // BtnStopEmg
            // 
            this.BtnStopEmg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnStopEmg.BackColor = System.Drawing.Color.LightSalmon;
            this.BtnStopEmg.Location = new System.Drawing.Point(107, 628);
            this.BtnStopEmg.Margin = new System.Windows.Forms.Padding(4);
            this.BtnStopEmg.Name = "BtnStopEmg";
            this.BtnStopEmg.Size = new System.Drawing.Size(110, 30);
            this.BtnStopEmg.TabIndex = 69;
            this.BtnStopEmg.Text = "緊急停止";
            this.BtnStopEmg.UseVisualStyleBackColor = false;
            this.BtnStopEmg.Click += new System.EventHandler(this.BtnStopEmg_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Location = new System.Drawing.Point(225, 627);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(129, 31);
            this.button1.TabIndex = 80;
            this.button1.Text = "Output Test";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtnStopDec
            // 
            this.BtnStopDec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnStopDec.Location = new System.Drawing.Point(107, 592);
            this.BtnStopDec.Margin = new System.Windows.Forms.Padding(4);
            this.BtnStopDec.Name = "BtnStopDec";
            this.BtnStopDec.Size = new System.Drawing.Size(110, 30);
            this.BtnStopDec.TabIndex = 68;
            this.BtnStopDec.Text = "減速停止";
            this.BtnStopDec.UseVisualStyleBackColor = true;
            this.BtnStopDec.Click += new System.EventHandler(this.BtnStopDec_Click);
            // 
            // button10
            // 
            this.button10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button10.Location = new System.Drawing.Point(18, 537);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(131, 25);
            this.button10.TabIndex = 68;
            this.button10.Text = "ALARM RESET";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button8
            // 
            this.button8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button8.Location = new System.Drawing.Point(18, 623);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(82, 25);
            this.button8.TabIndex = 67;
            this.button8.Text = "ServoOFF";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button9.Location = new System.Drawing.Point(18, 592);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 25);
            this.button9.TabIndex = 66;
            this.button9.Text = "ServoON";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // btnSetParam
            // 
            this.btnSetParam.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSetParam.Location = new System.Drawing.Point(225, 586);
            this.btnSetParam.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetParam.Name = "btnSetParam";
            this.btnSetParam.Size = new System.Drawing.Size(129, 31);
            this.btnSetParam.TabIndex = 65;
            this.btnSetParam.Text = "Move Down 10";
            this.btnSetParam.UseVisualStyleBackColor = true;
            this.btnSetParam.Click += new System.EventHandler(this.btnSetParam_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.axis2Indicator);
            this.groupBox2.Location = new System.Drawing.Point(426, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox2.Size = new System.Drawing.Size(395, 493);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "旋轉軸(R)";
            // 
            // axis2Indicator
            // 
            this.axis2Indicator.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.axis2Indicator.BackColor = System.Drawing.Color.Transparent;
            this.axis2Indicator.BorderColor = System.Drawing.Color.Black;
            this.axis2Indicator.ColumnHeaders = ((System.Collections.Generic.List<string>)(resources.GetObject("axis2Indicator.ColumnHeaders")));
            this.axis2Indicator.Columns = ((System.Collections.Generic.List<int>)(resources.GetObject("axis2Indicator.Columns")));
            this.axis2Indicator.ColumnSpacing = 8;
            this.axis2Indicator.HeaderBottomSpacing = 6;
            this.axis2Indicator.HeaderFont = new System.Drawing.Font("微軟正黑體", 9F);
            this.axis2Indicator.HeaderHeight = 22;
            this.axis2Indicator.HeaderLineColor = System.Drawing.Color.DarkGray;
            this.axis2Indicator.HeaderLineThickness = 2;
            this.axis2Indicator.HeaderTextColor = System.Drawing.Color.Black;
            this.axis2Indicator.HoverColor = System.Drawing.Color.Yellow;
            this.axis2Indicator.IndicatorSize = 20;
            this.axis2Indicator.Location = new System.Drawing.Point(5, 19);
            this.axis2Indicator.Name = "axis2Indicator";
            this.axis2Indicator.OffColor = System.Drawing.Color.DimGray;
            this.axis2Indicator.OnColor = System.Drawing.Color.Lime;
            this.axis2Indicator.RowSpacing = 4;
            this.axis2Indicator.Size = new System.Drawing.Size(385, 300);
            this.axis2Indicator.TabIndex = 1;
            this.axis2Indicator.Text = "multiCircularIndicator1";
            this.axis2Indicator.TextColor = System.Drawing.Color.Black;
            this.axis2Indicator.TextSpacing = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.axis1Indicator);
            this.groupBox1.Location = new System.Drawing.Point(18, 18);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(395, 493);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "旋入軸(Z)";
            // 
            // axis1Indicator
            // 
            this.axis1Indicator.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.axis1Indicator.BackColor = System.Drawing.Color.Transparent;
            this.axis1Indicator.BorderColor = System.Drawing.Color.Black;
            this.axis1Indicator.ColumnHeaders = ((System.Collections.Generic.List<string>)(resources.GetObject("axis1Indicator.ColumnHeaders")));
            this.axis1Indicator.Columns = ((System.Collections.Generic.List<int>)(resources.GetObject("axis1Indicator.Columns")));
            this.axis1Indicator.ColumnSpacing = 8;
            this.axis1Indicator.HeaderBottomSpacing = 6;
            this.axis1Indicator.HeaderFont = new System.Drawing.Font("微軟正黑體", 9F);
            this.axis1Indicator.HeaderHeight = 22;
            this.axis1Indicator.HeaderLineColor = System.Drawing.Color.DarkGray;
            this.axis1Indicator.HeaderLineThickness = 2;
            this.axis1Indicator.HeaderTextColor = System.Drawing.Color.Black;
            this.axis1Indicator.HoverColor = System.Drawing.Color.Yellow;
            this.axis1Indicator.IndicatorSize = 20;
            this.axis1Indicator.Location = new System.Drawing.Point(5, 19);
            this.axis1Indicator.Name = "axis1Indicator";
            this.axis1Indicator.OffColor = System.Drawing.Color.DimGray;
            this.axis1Indicator.OnColor = System.Drawing.Color.Lime;
            this.axis1Indicator.RowSpacing = 4;
            this.axis1Indicator.Size = new System.Drawing.Size(385, 300);
            this.axis1Indicator.TabIndex = 0;
            this.axis1Indicator.Text = "multiCircularIndicator1";
            this.axis1Indicator.TextColor = System.Drawing.Color.Black;
            this.axis1Indicator.TextSpacing = 5;
            // 
            // tbIO
            // 
            this.tbIO.Controls.Add(this.label13);
            this.tbIO.Controls.Add(this.label15);
            this.tbIO.Controls.Add(this.label7);
            this.tbIO.Controls.Add(this.label9);
            this.tbIO.Controls.Add(this.label11);
            this.tbIO.Controls.Add(this.label5);
            this.tbIO.Controls.Add(this.label3);
            this.tbIO.Controls.Add(this.label2);
            this.tbIO.Location = new System.Drawing.Point(4, 25);
            this.tbIO.Name = "tbIO";
            this.tbIO.Padding = new System.Windows.Forms.Padding(3);
            this.tbIO.Size = new System.Drawing.Size(992, 631);
            this.tbIO.TabIndex = 1;
            this.tbIO.Text = "週邊IO";
            this.tbIO.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(929, 168);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 21);
            this.label13.TabIndex = 23;
            this.label13.Text = "DI7";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(929, 146);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 21);
            this.label15.TabIndex = 22;
            this.label15.Text = "DI6";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(929, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 21);
            this.label7.TabIndex = 21;
            this.label7.Text = "DI5";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(929, 102);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 21);
            this.label9.TabIndex = 20;
            this.label9.Text = "DI4";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(929, 80);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 21);
            this.label11.TabIndex = 19;
            this.label11.Text = "DI3";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(929, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 21);
            this.label5.TabIndex = 18;
            this.label5.Text = "DI2";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(929, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 21);
            this.label3.TabIndex = 17;
            this.label3.Text = "DI1";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(929, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 21);
            this.label2.TabIndex = 16;
            this.label2.Text = "DI0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Monitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Monitor";
            this.Size = new System.Drawing.Size(1000, 706);
            this.tabControl1.ResumeLayout(false);
            this.tbMotionCard.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tbIO.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbMotionCard;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tbIO;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private UI.FA.MultiCircularIndicator axis1Indicator;
        private UI.FA.MultiCircularIndicator axis2Indicator;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btnSetParam;
        private System.Windows.Forms.Button BtnStopEmg;
        private System.Windows.Forms.Button BtnStopDec;
        private System.Windows.Forms.Button button1;
        private UI.FA.MultiCircularIndicator dioIndicator;
    }
}
