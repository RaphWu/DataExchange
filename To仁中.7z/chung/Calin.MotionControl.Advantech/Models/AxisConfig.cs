﻿using Calin.MVVM;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 軸參數配置。
    /// </summary>
    public class AxisConfig : ObservableObject
    {
        /// <summary>
        /// 軸名稱。
        /// </summary>
        public string AxisName { get; set; }

        #region Curver

        /// <summary>
        /// 
        /// </summary>
        public uint AxJerk
        {
            get { return _axJerk; }
            set { SetProperty(ref _axJerk, value); }
        }
        private uint _axJerk;

        #endregion Curver

        #region Move

        /// <summary>
        /// 
        /// </summary>
        public double AxVelLow
        {
            get { return _axVelLow; }
            set { SetProperty(ref _axVelLow, value); }
        }
        private double _axVelLow;

        /// <summary>
        /// 
        /// </summary>
        public double AxVelHigh
        {
            get { return _axVelHigh; }
            set { SetProperty(ref _axVelHigh, value); }
        }
        private double _axVelHigh;

        /// <summary>
        /// 
        /// </summary>
        public double AxAcc
        {
            get { return _axAcc; }
            set { SetProperty(ref _axAcc, value); }
        }
        private double _axAcc;

        /// <summary>
        /// 
        /// </summary>
        public double AxDec
        {
            get { return _axDec; }
            set { SetProperty(ref _axDec, value); }
        }
        private double _axDec;

        #endregion Move

        #region Home

        /// <summary>
        /// 回原點模式。
        /// </summary>
        public uint HomeMode
        {
            get { return _homeMode; }
            set { SetProperty(ref _homeMode, value); }
        }
        private uint _homeMode;

        /// <summary>
        /// 回原點方向。
        /// </summary>
        public uint HomeDir
        {
            get { return _homeDir; }
            set { SetProperty(ref _homeDir, value); }
        }
        private uint _homeDir;

        /// <summary>
        /// 
        /// </summary>
        public double AxHomeVelLow
        {
            get { return _axHomeVelLow; }
            set { SetProperty(ref _axHomeVelLow, value); }
        }
        private double _axHomeVelLow;

        /// <summary>
        /// 
        /// </summary>
        public double AxHomeVelHigh
        {
            get { return _axHomeVelHigh; }
            set { SetProperty(ref _axHomeVelHigh, value); }
        }
        private double _axHomeVelHigh;

        /// <summary>
        /// 
        /// </summary>
        public double AxHomeAcc
        {
            get { return _axHomeAcc; }
            set { SetProperty(ref _axHomeAcc, value); }
        }
        private double _axHomeAcc;

        /// <summary>
        /// 
        /// </summary>
        public double AxHomeDec
        {
            get { return _axHomeDec; }
            set { SetProperty(ref _axHomeDec, value); }
        }
        private double _axHomeDec;

        /// <summary>
        /// 
        /// </summary>
        public uint AxHomeEzLogic
        {
            get { return _axHomeEzLogic; }
            set { SetProperty(ref _axHomeEzLogic, value); }
        }
        private uint _axHomeEzLogic;

        /// <summary>
        /// 
        /// </summary>
        public uint AxHomeOrgLogic
        {
            get { return _axHomeOrgLogic; }
            set { SetProperty(ref _axHomeOrgLogic, value); }
        }
        private uint _axHomeOrgLogic;

        /// <summary>
        /// 
        /// </summary>
        public uint AxHomeElLogic
        {
            get { return _axHomeElLogic; }
            set { SetProperty(ref _axHomeElLogic, value); }
        }
        private uint _axHomeElLogic;

        /// <summary>
        /// 
        /// </summary>
        public uint AxHomeExSwitchMode
        {
            get { return _axHomeExSwitchMode; }
            set { SetProperty(ref _axHomeExSwitchMode, value); }
        }
        private uint _axHomeExSwitchMode;

        /// <summary>
        /// 
        /// </summary>
        public double AxHomeCrossDistance
        {
            get { return _axHomeCrossDistance; }
            set { SetProperty(ref _axHomeCrossDistance, value); }
        }
        private double _axHomeCrossDistance;

        #endregion Home

        #region Methods

        /// <summary>
        /// 從來源複製設定值。
        /// </summary>
        /// <param name="source">來源設定值。</param>
        public void CopyFrom(AxisConfig source)
        {
            if (source == null) return;

            // Curver
            AxJerk = source.AxJerk;

            // move
            AxVelLow = source.AxVelLow;
            AxVelHigh = source.AxVelHigh;
            AxAcc = source.AxAcc;
            AxDec = source.AxDec;

            // home
            HomeMode = source.HomeMode;
            HomeDir = source.HomeDir;
            AxHomeVelLow = source.AxHomeVelLow;
            AxHomeVelHigh = source.AxHomeVelHigh;
            AxHomeAcc = source.AxHomeAcc;
            AxHomeDec = source.AxHomeDec;
            AxHomeEzLogic = source.AxHomeEzLogic;
            AxHomeOrgLogic = source.AxHomeOrgLogic;
            AxHomeElLogic = source.AxHomeElLogic;
            AxHomeExSwitchMode = source.AxHomeExSwitchMode;
            AxHomeCrossDistance = source.AxHomeCrossDistance;
        }

        #endregion Methods
    }
}
