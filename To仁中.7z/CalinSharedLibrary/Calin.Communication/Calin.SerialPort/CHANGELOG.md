﻿# **0.1.0**: 初始版本。

## 2025.12.18

1) ASCII 傳送（Service + Manager 都有）
	- SerialPortService.SendAscii(string data)：以 ASCII 編碼送出（不加行尾）
	- SerialPortService.SendAsciiLine(string line)：送出並自動加上行尾（預設 &#x0a;）
	- SerialPortManager.SendAscii(portName, data) / SendAsciiLine(portName, line)：代理呼叫，符合 SendData 風格
2) ASCII 接收（行模式 / 非行模式）
	- 預設啟用 行模式：收到資料後會依 AsciiLineTerminator 分割成多行，每一行都會觸發一次 DataReceived
	- 若關閉行模式：就維持「收到一段就觸發一次」(不切行)
3) 可設定項目（放在 SerialPortConfig）
	新增：
	- TextEncoding：Ascii / Utf8（預設 Ascii）
	- AsciiLineTerminator：預設 "&#x0a;"
	- EnableAsciiLineMode：預設 true
	- AsciiReceiveBufferLimit：預設 8192，避免一直累積導致記憶體成長
	- GetTextEncoding()：取得對應的 System.Text.Encoding
	並已更新 Clone() 將上述參數一起複製。
4) 介面已補齊
	- ISerialPortService：加入 SendAscii、SendAsciiLine
	- ISerialPortManager：加入 SendAscii、SendAsciiLine

## 2025.12.17

第一版。
