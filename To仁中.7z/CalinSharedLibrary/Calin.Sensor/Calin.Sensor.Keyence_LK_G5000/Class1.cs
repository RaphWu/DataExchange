﻿namespace Calin.Sensor.Keyence_LK_G5000
{
    public class Class1
    {

    }
}
