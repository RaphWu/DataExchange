﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.CSharp.Demo.Services
{
    public enum AppTheme
    {
        Default,
        Light,
        Dark
    }
}
