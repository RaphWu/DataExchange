﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace Calin.CSharp.Helpers
{
    /// <summary>
    /// Enum 輔助函數。
    /// </summary>
    public static class EnumHelper
    {
        /// <summary>
        /// 取得列舉值的描述。
        /// </summary>
        /// <remarks>此方法會檢查指定的列舉值上是否存在 <see cref="DescriptionAttribute"/>。若找到該屬性，則會回傳其描述；否則方法會回傳該列舉值的字串表示。</remarks>
        /// <param name="enumValue">要取得描述的列舉值。</param>
        /// <returns>套用於該列舉值之 <see cref="DescriptionAttribute"/> 所指定的描述；若沒有描述屬性，則回傳該列舉值的名稱。</returns>
        public static string GetDescription(this Enum enumValue)
        {
            DescriptionAttribute[] array = (DescriptionAttribute[])enumValue.GetType().GetField(enumValue.ToString()).GetCustomAttributes(typeof(DescriptionAttribute), inherit: false);
            if (array != null && array.Length != 0)
            {
                return array[0].Description;
            }

            return enumValue.ToString();
        }

        /// <summary>
        /// 取得類別屬性的描述。
        /// </summary>
        /// <remarks>此方法會檢查指定的屬性上是否存在 <see cref="DescriptionAttribute"/>。若找到該屬性，則會回傳其描述；否則方法會回傳 null。</remarks>
        /// <typeparam name="T">資料物件。</typeparam>
        /// <param name="propertyName">屬性名稱。</param>
        /// <returns>屬性的描述。</returns>
        public static string GetDescription<T>(string propertyName)
        {
            PropertyInfo property = typeof(T).GetProperty(propertyName);
            if (property == null)
            {
                return null;
            }

            return property.GetCustomAttribute<DescriptionAttribute>()?.Description;
        }

        /// <summary>
        /// 根據描述取得列舉值。
        /// </summary>
        /// <remarks>此方法會遍歷指定列舉類型的所有欄位，並檢查每個欄位上的 <see cref="DescriptionAttribute"/>。若找到描述符合的欄位，則回傳該欄位的值；若找不到，則回傳預設值。</remarks>
        /// <typeparam name="T">列舉類型。</typeparam>
        /// <param name="description">描述字串。</param>
        /// <returns>對應的列舉值，若找不到則回傳預設值。</returns>
        public static T GetEnumByDescription<T>(this string description)
        {
            foreach (FieldInfo fi in typeof(T).GetFields())
            {
                DescriptionAttribute[] attributes =
                    (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attributes.Length > 0 && attributes[0].Description == description)
                    return (T)fi.GetValue(null);

                if (fi.Name == description)
                    return (T)fi.GetValue(null);
            }
            //throw new ArgumentException($"找不到描述：{description}");
            return default;
        }
    }
}
