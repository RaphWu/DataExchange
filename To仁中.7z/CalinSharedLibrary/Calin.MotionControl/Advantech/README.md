﻿# 研華通用運動 (ACM) 架構

# 官方簡介

- 為了統一所有研華運動設備的用戶接口，研華運動設備採用了新的軟體架構，名為「通用運動架構 」。
- 該架構定義了所有用戶介面和具有的所有運動功能，包括單一軸和多軸。這種統一的程式設計平台使用戶能夠以相同的方式操作設備。
- 架構包括三層：**裝置驅動層**、**整合層** 和 **應用層**。用戶無需了解如何操作特定設備的特定驅動，只需了解通用運動驅動即可。即使支援該架構的設備發生變化，應用也無需修改。
- 研華通用運動 (ACM) 架構定義了三種操作對象：設備、軸心和群組。每種物件都擁有自己的方法、屬性和狀態。
- 所有操作都可透過呼叫對應 ACM API 來完成。設備、軸和群組的常用呼叫流程由通用運動架構進行定義。詳細資訊請參考 “ 呼叫流程”。

---

# 檔案架構

---

# AcmStatus 運動狀態

在使用運動控制卡之前，必須配置一些參數（例如速度、ALM 訊號、左限位和右限位）。配置軸卡屬性的過程稱為系統配置過程 (system configuration process)。

AcmStatus 檔案定義了研華通用運動架構 (ACM) 中所有的狀態值。這些狀態值用於表示設備、軸和群組的當前狀態，並可用於監控和控制運動過程。

|函數|說明|
|---|---|
|`Acm_AxGetState` |取得軸的目前狀態，將傳回 16 位元的狀態值。|
|`Acm_AxGetMotionStatus` |取得軸的目前運動狀態，將傳回 32 位元的軸當前運動狀態值。|

當打開板卡，打開軸後，正常情況下，軸的狀態將為 `Ready` 。只有當軸的狀態為 `Ready` 時，才能執行新的運動操作，如連續運動。
當開啟板卡未開啟軸時，軸的狀態為停用(`STA_AX_DISABLE`), 此時執行運動操作將會報錯。

## 軸速度

|函數|說明|
|---|---|
|`Acm_AxChangeVel`|當軸在運動過程中，指令軸改變運轉速度。|
|`Acm_AxGetCmdVelocity`|取得指定軸的目前運行速度。|
|`Acm_AxChangeVelEx`|改變運轉軸的運轉速度、加速度、減速度。|
|`Acm_AxChangeVelExByRate`|依比率改變運轉軸的運轉速度、加速度、減速度。|
|`Acm_AxChangeVelByRate`|依比例改變運轉軸的運轉速度。|

- 開啟板卡和軸後，可設定 / 取得軸的當前速度值，如初速、加速度、運轉速度。
- 設定的速度參數不能大於運動軸的最大速度參數，否則會報錯，例如配置軸的最大速度(`CFG_AxMaxVel`) 為 10000，設定軸的運轉速度(`PAR_AxVelHigh`) 為 11000，運行時將會提示報錯。
- 在軸的運轉過程中，可呼叫函數改變運行軸的 **運轉速度**、**加速度**、**減速度**。

## 編碼器

|函數|說明|
|---|---|
|`Acm_AxSetCmdPosition`|設定指定軸的理論(指令)位置。|
|`Acm_AxSetActualPosition`|設定指定軸的實際(回饋)位置。|
|`Acm_AxGetCmdPosition`|取得指定軸的目前理論(指令)位置。|
|`Acm_AxGetActualPosition`|取得指定軸的目前實際(回饋)位置。|
|`Acm_AxGetState`|取得軸的目前狀態。|

## 軸的運動 I/O 狀態

|函數|說明|
|---|---|
|`Acm_AxGetMotionIO`|取得軸的運動 I/O 狀態，傳回 32 位元的狀態值。|

驅動器警報標誌、限位觸發標誌觸發以後，不會自動清除 0。只有當產生異常的原因消
除後，呼叫 `Acm_AxResetError` 函數，軸的狀態變成 `Ready`。

## 群組狀態

|函數|說明|
|---|---|
|`Acm_GpGetState`|取得群組的目前狀態，將傳回 16 位元的群組狀態值。|

當打開板卡，打開軸後，需要呼叫函數添加軸到群組中，當群組中軸的數量大於等於
1 時，正常情況下，群組的狀態將為 `Ready`，此時可執行群組操作。當群組的狀態為
`Disable` 時，此時執行群組運動操作將會報錯。

## 群組速度

|函數|說明|
|---|---|
|`Acm_GpGetCmdVel`|取得群組的目前的速度值|

闆卡初始化後，可設定 / 取得群組的目前速度值，如初速度，加速度，運行速度。運行過程中，可呼叫 `Acm_GpGetCmdVel` 函數取得群組的目前速度值。

---

# 軸運動

## Single-axis motion 單軸運動

單軸運動是指單軸的移動，包括以下幾種模式：
- P2P motion 點對點運動。
- Continuous motion 連續運動。
- Change position motion 位置改變運動。
- Change velocity motion 速度改變運動。
- Simultaneous start/stop motion 同步啟動/停止運動。
- Imposed motion 強制運動。
- Jog motion 點動運動。
- Homing 歸位運動。

### 點對點運動

P.75

|函數|說明|
|---|---|
|Acm_AxMoveAbs|單軸的絕對點到點運動。|
|Acm_AxMoveRel|單軸的相對點到點運動。|
|Acm_AxSetCmdPosition|設定指定軸的理論(指令)位置。|
|Acm_AxSetActualPosition|設定指定軸的實際(回饋)位置。|
|Acm_AxGetCmdPosition|取得指定軸的目前理論(指令)位置。|
|Acm_AxGetActualPosition|取得指定軸的目前實際(回饋)位置。|
|Acm_AxGetCmdVelocity|取得目前軸的理論(指令)速度。|
|Acm_AxStopDec|指令軸以設定的減速停止運行。|
|Acm_AxStopEmg|指令軸立刻停止（無減速）。|
|Acm_AxStopDecEx|下達停止指令時可指定減速度。|
|Acm_AxGetState|取得軸的目前狀態。|
|Acm_AxResetError|重設軸的狀態。|
|Acm_SetU32Property|設定屬性值(屬性值為無符號32位元整數)。|
|Acm_SetI32Property|設定屬性值(屬性值為有符號32位元整數)。|
|Acm_SetF64Property|設定屬性值(屬性值為Double型)。|
|Acm_GetU32Property|取得屬性值(屬性值為無符號32位元整數)。|
|Acm_GetI32Property|取得屬性值(屬性值為有符號32位元整數)。|
|Acm_GetF64Property|取得屬性值(屬性值為Double型)。|

|參數|說明|
|---|---|
|PAR_AxVelLow|設定/取得此軸的初始速度(起始速度)。|
|PAR_AxVelHigh|設定/取得該軸的運轉速度。|
|PAR_AxAcc|設定/取得該軸的加速度。|
|PAR_AxDec|設定/取得該軸的減速度。|
|PAR_AxJerk|設定/取得速度曲線的類型：T/S型曲線。|

|配置|說明|
|---|---|
|CFG_AxMaxVel|配置運動軸的最大速度。|
|CFG_AxMaxAcc|配置運動軸的最大加速度。|
|CFG_AxMaxDec|配置運動軸的最大減速。|

- 當軸的狀態為 `Ready` 時，將能執行點到點運動。
- 點到點運動分為兩種：**相對運動** 和 **絕對運動**。
	- 相對運動：以目前的理論指令位置為參考位置作位置的移動。
	- 絕對運動：以絕對零點指令位置為參考位置作位置的移動。
- 點到點運動模式下，可單獨設定各軸的目標位置、初速、加速度等運動參數，各軸獨立運作或停止。在運動過程中，可改變目標位置和運行速度。
- 流程圖在 5.2.2.3 節 (P.77)。

### 連續運動

P.78

|參數|說明|
|---|---|
|PAR_AxVelLow|設定/取得該軸的低速度(起始速度)。|
|PAR_AxVelHigh|設定/取得此軸的高速度(驅動速度)。|
|PAR_AxAcc|設定/取得該軸的加速度。|
|PAR_AxDec|設定/取得該軸的減速度。|
|PAR_AxJerk|設定速度曲線的類型：T/S型曲線。|

|配置|說明|
|---|---|
|CFG_AxMaxVel|配置運動軸的最大速度。|
|CFG_AxMaxAcc|配置運動軸的最大加速度。|
|CFG_AxMaxDec|配置運動軸的最大減速。|

- 連續運動指命令軸依規定速度和方向執行沒有終點的運動。
- 執行連續運動過程中，可單獨設定各軸的速度參數。如初速度、加速度等。各軸將獨立運行或停止。
- 連續運動過程中，可改變運轉軸的運轉速度。
- 執行連續運動時，軸的狀態必須為 `Ready`。軸的狀態可透過 `Acm_AxGetState` 函數取得。
- 流桯圖在 5.2.3.3 (P.79)。

### 位置改變運動

P.81

|函數|說明|
|---|---|
|Acm_AxChangePos|改變執行點到點運動軸的終點位置。|
|Acm_AxMoveAbs|單軸的絕對點到點運動。|
|Acm_AxMoveRel|單軸的相對點到點運動。|
|Acm_AxSetCmdPosition|設定指定軸的理論(指令)位置。|
|Acm_AxGetCmdPosition|取得指定軸的目前理論(指令)位置。|
|Acm_AxSetActualPosition|設定指定軸的實際(回饋)位置。|
|Acm_AxGetActualPosition|取得指定軸的目前實際(回饋)位置。|
|Acm_AxStopDec|指令軸依設定減速減速停止。|
|Acm_AxStopEmg|指令軸立刻停止（無減速）。|
|Acm_AxStopDecEx|下達停止指令時可指定減速度。|
|Acm_AxGetState|取得軸的目前狀態。|
|Acm_AxResetError|重設軸的狀態。。|
|Acm_SetU32Property|設定屬性值(屬性值為UInt32位元整數)。|
|Acm_SetI32Property|設定屬性值(屬性值為Int32位元整數)。|
|Acm_SetF64Property|設定屬性值(屬性值為Double型)。|
|Acm_GetU32Property|取得屬性值(屬性值為UInt32位元整數)。|
|Acm_GetI32Property|取得屬性值(屬性值為Int32位元整數)。|
|Acm_GetF64Property|取得屬性值(屬性值為Double型)。|

|參數|說明|
|---|---|
|PAR_AxVelLow|設定/取得該軸的低速度(起始速度)。|
|PAR_AxVelHigh|設定/取得此軸的高速度(驅動速度)。|
|PAR_AxAcc|設定/取得該軸的加速度。|
|PAR_AxDec|設定/取得該軸的減速度。|
|PAR_AxJerk|設定速度曲線的類型：T/S型曲線。|

|配置|說明|
|---|---|
|CFG_AxMaxVel|配置運動軸的最大速度。|
|CFG_AxMaxAcc|配置運動軸的最大加速度。|
|CFG_AxMaxDec|配置運動軸的最大減速。|

- 變位運動指軸在執行點到點運動過程中, 可改變點到點運動的目標位置。
- 當呼叫 `ChangePos` 函數改變運行軸的目標位置時，執行結果與軸的當前運動位置有關：
	- 當 Change 的位置大於目前運動位置時，將運行到Change 的位置。
	- 當 Change 的位置小於初始設定的目標位置，運行結果與軸的目前位置有關。見 P.82 圖：
- 流程圖位於 5.2.4.3 節 (P.83)。

### 速度改變運動

P.84

|函數|說明|
|---|---|
|Acm_AxMoveVel|軸以規定速度進行沒有終點的運動。|
|Acm_AxMoveAbs|開始單軸的絕對點到點運動。|
|Acm_AxMoveRel|開始單軸的相對點到點運動。|
|Acm_AxChangeVel|當軸在運動過程中，指令軸改變速度。|
|Acm_AxChangeVelEx|改變運轉軸的運轉速度、加速度、減速度。|
|Acm_AxChangeVelByRate|依照設定的比例改變目前軸的運轉速度。|
|Acm_AxChangeVelExByRate|依比率改變軸運轉速度、加速度、減速度。|
|Acm_AxGetCmdVelocity|取得指定軸的目前理論速度。|
|Acm_AxSetCmdPosition|設定指定軸的理論位置。|
|Acm_AxGetCmdPosition|取得指定軸的目前理論位置。|
|Acm_AxSetActualPosition|設定指定軸的實際位置。|
|Acm_AxGetActualPosition|取得指定軸的目前實際位置。|
|Acm_AxStopDec|指令軸減速停止。|
|Acm_AxStopEmg|指令軸立刻停止（無減速）。|
|Acm_AxStopDecEx|下達停止指令時可指定減速度。|
|Acm_AxGetState|取得軸的目前狀態。。|
|Acm_AxResetError|重設軸的狀態。。|
|Acm_SetU32Property|設定屬性值(屬性值為無符號32位元整數)。|
|Acm_SetI32Property|設定屬性值(屬性值為有符號32位元整數)。|
|Acm_SetF64Property|設定屬性值(屬性值為Double型)。|
|Acm_GetU32Property|取得屬性值(屬性值為無符號32位元整數)。|
|Acm_GetI32Property|取得屬性值(屬性值為有符號32位元整數)。|
|Acm_GetF64Property|取得屬性值(屬性值為Double型)。|

|參數|說明|
|---|---|
|PAR_AxVelLow|設定/取得該軸的低速度(起始速度)。|
|PAR_AxVelHigh|設定/取得此軸的高速度(驅動速度)。|
|PAR_AxAcc|設定/取得該軸的加速度。|
|PAR_AxDec|設定/取得該軸的減速度。|
|PAR_AxJerk|設定速度曲線的類型：T/S型曲線。|

|配置|說明|
|---|---|
|CFG_AxMaxVel|配置運動軸的最大速度。|
|CFG_AxMaxAcc|配置運動軸的最大加速度。|
|CFG_AxMaxDec|配置運動軸的最大減速。|

- 變速運動指當軸執行點到點運動或連續運動時，改變目前軸的運轉速度、加速度、減速度。**改變的速度需大於初速**。
- 呼叫 `Acm_AxChangeVel` 函數改變指定軸的運行速度。若命令成功下達，下次運動之前沒有重新設定運行速度，新的運行速度會作用到下次運動中。
- 呼叫 `Acm_AxChangeVelEx` 函數改變運行速度、加速度、減速度。若命令成功下達，下次運動前沒有重新設定運動速度，則新的運行速度會作用到下次運動。
- 若新的加速度、減速度設定為 `0`，則使用上一次設定的加速度或減速度值。
- 呼叫 `Acm_AxChangeVelExByRate` 函數根據比率改變運行速度，同時改變加速度和減速度。
- 新的速度，加速度和減速度僅對目前運動有效。若新的加速度減速度為 `0`，則使用上一次設定的加速度或減速度值。
- 呼叫 `Acm_AxChangeVelByRate` 函數根據比率改變運行速度。新的速度僅對當前運動有效。
- 流程圖在 5.2.5.3 節 (P.86)。

### 同步啟動/停止運動

P.87

|函數|說明|
|---|---|
|Acm_AxSimStartSuspendAbs|設定軸為等待做相對點到點運動狀態。|
|Acm_AxSimStartSuspendRel|設定軸為等待做絕對點到點運動狀態。|
|Acm_AxSimStartSuspendVel|設定軸為等待做連續運動狀態。。|
|Acm_AxSimStart|啟動所有等待啟動觸發的軸。。|
|Acm_AxSimStop|停止所有觸發的軸。|
|Acm_AxSetCmdPosition|設定指定軸的理論位置。|
|Acm_AxGetCmdPosition|取得指定軸的目前理論位置。|
|Acm_AxSetActualPosition|設定指定軸的實際位置。|
|Acm_AxGetActualPosition|取得指定軸的目前實際位置。|
|Acm_AxGetCmdVelocity|取得目前軸的理論(指令)速度。|
|Acm_AxGetState|取得軸的運動狀態。|
|Acm_AxResetError|重設軸的狀態。。|
|Acm_SetU32Property|設定屬性值(屬性值為無符號32位元整數)。|
|Acm_SetI32Property|設定屬性值(屬性值為有符號32位元整數)。|
|Acm_SetF64Property|設定屬性值(屬性值為Double型)。|
|Acm_GetU32Property|取得屬性值(屬性值為無符號32位元整數)。|
|Acm_GetI32Property|取得屬性值(屬性值為有符號32位元整數)。|
|Acm_GetF64Property|取得屬性值(屬性值為Double型)。|

|參數|說明|
|---|---|


|配置|說明|
|---|---|


|特性|說明|
|---|---|


### 強制運動




### 點動運動




### 歸位運動


