﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    public class AcmService : IAcm
    {
        public AcmService(AcmConfig acmConfig)
        {
        }

        public void initialize()
        {

        }


        public void StopMotion()
        {

        }
    }
}
