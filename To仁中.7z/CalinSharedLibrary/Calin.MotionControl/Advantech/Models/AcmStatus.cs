﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.MC.Advantech.Models
{
    public class AcmStatus : ObservableObject
    {
        #region fields

        // 軸當前狀態
        private bool _sta_AX_DISABLE;
        private bool _sta_AX_READY;
        private bool _sta_AX_STOPPING;
        private bool _sta_AX_ERROR_STOP;
        private bool _sta_AX_HOMING;
        private bool _sta_AX_PTP_MOT;
        private bool _sta_AX_CONTI_MOT;
        private bool _sta_AX_SYNC_MOT;
        private bool _sta_AX_EXT_JOG;
        private bool _sta_AX_EXT_MPG;
        private bool _sta_AX_PAUSE;
        private bool _sta_AX_BUSY;
        private bool _sta_AX_WAIT_DI;
        private bool _sta_AX_WAIT_PTP;
        private bool _sta_AX_WAIT_VEL;
        private bool _sta_AX_EXT_JOG_READY;

        // 軸當前運動狀態
        private string _stop;
        private string _res1;
        private string _waitERC;
        private string _res2;
        private string _correctBksh;
        private string _res3;
        private string _inFA;
        private string _inFL;
        private string _inACC;
        private string _inFH;
        private string _inDEC;
        private string _waitINP;

        // 軸速度
        private string _ft_AxMaxVel;
        private string _ft_AxMaxAcc;
        private string _ft_AxMaxDec;
        private string _ft_AxMaxJerk;
        private string _cfg_AxMaxVel;
        private string _cfg_AxMaxAcc;
        private string _cfg_AxMaxDec;
        private string _cfg_AxMaxJerk;
        private string _par_AxVelLow;
        private string _par_AxVelHigh;
        private string _par_AxAcc;
        private string _par_AxDec;
        private string _par_AxJerk;

        // 軸的運動 I/O 狀態
        private string _RDY;
        private string _ALM;
        private string _LMT_Positive;
        private string _LMT_Negative;
        private string _ORG;
        private string _DIR;
        private string _EMG;
        private string _PCS;
        private string _ERC;
        private string _EZ;
        private string _CLR;
        private string _LTC;
        private string _SD;
        private string _INP;
        private string _SVON;
        private string _ALRM;
        private string _SLMT_Positive;
        private string _SLMT_Negative;
        private string _CMP;
        private string _CAMDO;

        // 群組狀態
        private string _sta_GP_DISABLE;
        private string _sta_GP_READY;
        private string _sta_GP_STOPPING;
        private string _sta_GP_ERROR_STOP;
        private string _sta_GP_MOTION;
        private string _sta_GP_AX_MOTION;
        private string _sta_GP_MOTION_PATH;
        private string _sta_GP_PAUSE;
        private string _sta_GP_BUSY;

        // 群組速度
        private string _par_GpVelLow;
        private string _par_GpVelHigh;
        private string _par_GpAcc;
        private string _par_GpDec;
        private string _par_GpJerk;

        #endregion fields

        #region 軸當前狀態

        /// <summary>
        /// 軸被停用，使用者可開啟並激活。
        /// </summary>
        public bool STA_AX_DISABLE
        {
            get { return _sta_AX_DISABLE; }
            set { SetProperty(ref _sta_AX_DISABLE, value); }
        }

        /// <summary>
        /// 軸已準備就緒，等待新的指令。
        /// </summary>
        public bool STA_AX_READY
        {
            get { return _sta_AX_READY; }
            set { SetProperty(ref _sta_AX_READY, value); }
        }

        /// <summary>
        /// 軸停止。
        /// </summary>
        public bool STA_AX_STOPPING
        {
            get { return _sta_AX_STOPPING; }
            set { SetProperty(ref _sta_AX_STOPPING, value); }
        }

        /// <summary>
        /// 出現錯誤，軸停止。
        /// </summary>
        public bool STA_AX_ERROR_STOP
        {
            get { return _sta_AX_ERROR_STOP; }
            set { SetProperty(ref _sta_AX_ERROR_STOP, value); }
        }

        /// <summary>
        /// 軸正在執行返回原點運動。
        /// </summary>
        public bool STA_AX_HOMING
        {
            get { return _sta_AX_HOMING; }
            set { SetProperty(ref _sta_AX_HOMING, value); }
        }

        /// <summary>
        /// 軸正在執行 PTP 運動。
        /// </summary>
        public bool STA_AX_PTP_MOT
        {
            get { return _sta_AX_PTP_MOT; }
            set { SetProperty(ref _sta_AX_PTP_MOT, value); }
        }

        /// <summary>
        /// 軸正在執行連續運動。
        /// </summary>
        public bool STA_AX_CONTI_MOT
        {
            get { return _sta_AX_CONTI_MOT; }
            set { SetProperty(ref _sta_AX_CONTI_MOT, value); }
        }

        /// <summary>
        /// 軸在一個群組中，群組正在執行插補運動；或軸是一個從軸，正在執行 E-cam/E-gear/Gantry 運動。
        /// </summary>
        public bool STA_AX_SYNC_MOT
        {
            get { return _sta_AX_SYNC_MOT; }
            set { SetProperty(ref _sta_AX_SYNC_MOT, value); }
        }

        /// <summary>
        /// 軸由外部訊號控制執行 JOG 模式運動中。
        /// </summary>
        public bool STA_AX_EXT_JOG
        {
            get { return _sta_AX_EXT_JOG; }
            set { SetProperty(ref _sta_AX_EXT_JOG, value); }
        }

        /// <summary>
        /// 軸由外部訊號控制。當外部訊號啟動時，軸將執行 MPG 模式運動。
        /// </summary>
        public bool STA_AX_EXT_MPG
        {
            get { return _sta_AX_EXT_MPG; }
            set { SetProperty(ref _sta_AX_EXT_MPG, value); }
        }

        /// <summary>
        /// 軸暫停。
        /// </summary>
        public bool STA_AX_PAUSE
        {
            get { return _sta_AX_PAUSE; }
            set { SetProperty(ref _sta_AX_PAUSE, value); }
        }

        /// <summary>
        /// 軸忙碌中，前一個指令尚未處理完成。
        /// </summary>
        public bool STA_AX_BUSY
        {
            get { return _sta_AX_BUSY; }
            set { SetProperty(ref _sta_AX_BUSY, value); }
        }

        /// <summary>
        /// 軸在等待指定的DI訊號。
        /// </summary>
        public bool STA_AX_WAIT_DI
        {
            get { return _sta_AX_WAIT_DI; }
            set { SetProperty(ref _sta_AX_WAIT_DI, value); }
        }

        /// <summary>
        /// 軸在等待其他軸點對點運動完成。
        /// </summary>
        public bool STA_AX_WAIT_PTP
        {
            get { return _sta_AX_WAIT_PTP; }
            set { SetProperty(ref _sta_AX_WAIT_PTP, value); }
        }

        /// <summary>
        /// 軸在等待其他軸連續運動完成。
        /// </summary>
        public bool STA_AX_WAIT_VEL
        {
            get { return _sta_AX_WAIT_VEL; }
            set { SetProperty(ref _sta_AX_WAIT_VEL, value); }
        }

        /// <summary>
        /// 軸由外部訊號控制。當外部訊號啟動時，軸將執行 JOG 模式運動。
        /// </summary>
        public bool STA_AX_EXT_JOG_READY
        {
            get { return _sta_AX_EXT_JOG_READY; }
            set { SetProperty(ref _sta_AX_EXT_JOG_READY, value); }
        }

        #endregion 軸當前狀態

        #region 軸當前運動狀態

        /// <summary>
        /// 停止。
        /// </summary>
        public string Stop
        {
            get { return _stop; }
            set { SetProperty(ref _stop, value); }
        }

        /// <summary>
        /// 保留。
        /// </summary>
        public string Res1
        {
            get { return _res1; }
            set { SetProperty(ref _res1, value); }
        }

        /// <summary>
        /// 等待ERC 完成。
        /// </summary>
        public string WaitERC
        {
            get { return _waitERC; }
            set { SetProperty(ref _waitERC, value); }
        }

        /// <summary>
        /// 保留。
        /// </summary>
        public string Res2
        {
            get { return _res2; }
            set { SetProperty(ref _res2, value); }
        }

        /// <summary>
        /// 背隙補償。
        /// </summary>
        public string CorrectBksh
        {
            get { return _correctBksh; }
            set { SetProperty(ref _correctBksh, value); }
        }

        /// <summary>
        /// 保留。
        /// </summary>
        public string Res3
        {
            get { return _res3; }
            set { SetProperty(ref _res3, value); }
        }

        /// <summary>
        /// 處於特定速度中 = FA。
        /// </summary>
        public string InFA
        {
            get { return _inFA; }
            set { SetProperty(ref _inFA, value); }
        }

        /// <summary>
        /// 處於低速中 = FL。
        /// </summary>
        public string InFL
        {
            get { return _inFL; }
            set { SetProperty(ref _inFL, value); }
        }

        /// <summary>
        /// 加速中。
        /// </summary>
        public string InACC
        {
            get { return _inACC; }
            set { SetProperty(ref _inACC, value); }
        }

        /// <summary>
        /// 處於最大速度 = FH。
        /// </summary>
        public string InFH
        {
            get { return _inFH; }
            set { SetProperty(ref _inFH, value); }
        }

        /// <summary>
        /// 減速中。
        /// </summary>
        public string InDEC
        {
            get { return _inDEC; }
            set { SetProperty(ref _inDEC, value); }
        }

        /// <summary>
        /// 到位等待。
        /// </summary>
        public string WaitINP
        {
            get { return _waitINP; }
            set { SetProperty(ref _waitINP, value); }
        }

        #endregion 軸當前運動狀態

        #region 軸速度

        /// <summary>
        /// 取得軸支援的最大速度。
        /// </summary>
        public string FT_AxMaxVel
        {
            get { return _ft_AxMaxVel; }
            set { SetProperty(ref _ft_AxMaxVel, value); }
        }

        /// <summary>
        /// 取得軸支援的最大加速度。
        /// </summary>
        public string FT_AxMaxAcc
        {
            get { return _ft_AxMaxAcc; }
            set { SetProperty(ref _ft_AxMaxAcc, value); }
        }

        /// <summary>
        /// 取得軸支援的最大減速度。
        /// </summary>
        public string FT_AxMaxDec
        {
            get { return _ft_AxMaxDec; }
            set { SetProperty(ref _ft_AxMaxDec, value); }
        }

        /// <summary>
        /// 取得軸支援的最大減速度。
        /// </summary>
        public string FT_AxMaxJerk
        {
            get { return _ft_AxMaxJerk; }
            set { SetProperty(ref _ft_AxMaxJerk, value); }
        }

        /// <summary>
        /// 配置運動軸的最大速度。
        /// </summary>
        public string CFG_AxMaxVel
        {
            get { return _cfg_AxMaxVel; }
            set { SetProperty(ref _cfg_AxMaxVel, value); }
        }

        /// <summary>
        /// 配置運動軸的最大加速度。
        /// </summary>
        public string CFG_AxMaxAcc
        {
            get { return _cfg_AxMaxAcc; }
            set { SetProperty(ref _cfg_AxMaxAcc, value); }
        }

        /// <summary>
        /// 配置運動軸的最大減速。
        /// </summary>
        public string CFG_AxMaxDec
        {
            get { return _cfg_AxMaxDec; }
            set { SetProperty(ref _cfg_AxMaxDec, value); }
        }

        /// <summary>
        /// 取得運動軸的最大加加速度配置。
        /// </summary>
        public string CFG_AxMaxJerk
        {
            get { return _cfg_AxMaxJerk; }
            set { SetProperty(ref _cfg_AxMaxJerk, value); }
        }

        /// <summary>
        /// 設定 / 取得該軸的起始速度。
        /// </summary>
        public string PAR_AxVelLow
        {
            get { return _par_AxVelLow; }
            set { SetProperty(ref _par_AxVelLow, value); }
        }

        /// <summary>
        /// 設定 / 取得該軸的運轉速度。
        /// </summary>
        public string PAR_AxVelHigh
        {
            get { return _par_AxVelHigh; }
            set { SetProperty(ref _par_AxVelHigh, value); }
        }

        /// <summary>
        /// 設定 / 取得該軸的加速度。
        /// </summary>
        public string PAR_AxAcc
        {
            get { return _par_AxAcc; }
            set { SetProperty(ref _par_AxAcc, value); }
        }

        /// <summary>
        /// 設定 / 取得該軸的減速度。
        /// </summary>
        public string PAR_AxDec
        {
            get { return _par_AxDec; }
            set { SetProperty(ref _par_AxDec, value); }
        }

        /// <summary>
        /// 設定速度曲線的類型：T 形曲線或 S 形曲線。
        /// </summary>
        public string PAR_AxJerk
        {
            get { return _par_AxJerk; }
            set { SetProperty(ref _par_AxJerk, value); }
        }

        #endregion 軸速度

        #region 軸的運動 I/O 狀態

        /// <summary>
        /// 針腳輸入。
        /// </summary>
        public string RDY
        {
            get { return _RDY; }
            set { SetProperty(ref _RDY, value); }
        }

        /// <summary>
        /// 警報訊號輸入。
        /// </summary>
        public string ALM
        {
            get { return _ALM; }
            set { SetProperty(ref _ALM, value); }
        }

        /// <summary>
        /// 限位開關+。
        /// </summary>
        public string LMT_Positive
        {
            get { return _LMT_Positive; }
            set { SetProperty(ref _LMT_Positive, value); }
        }

        /// <summary>
        /// 限位開關-。
        /// </summary>
        public string LMT_Negative
        {
            get { return _LMT_Negative; }
            set { SetProperty(ref _LMT_Negative, value); }
        }

        /// <summary>
        /// 原始開關。
        /// </summary>
        public string ORG
        {
            get { return _ORG; }
            set { SetProperty(ref _ORG, value); }
        }

        /// <summary>
        /// DIR輸出。
        /// </summary>
        public string DIR
        {
            get { return _DIR; }
            set { SetProperty(ref _DIR, value); }
        }

        /// <summary>
        /// 緊急訊號輸入。
        /// </summary>
        public string EMG
        {
            get { return _EMG; }
            set { SetProperty(ref _EMG, value); }
        }

        /// <summary>
        /// PCS訊號輸入。
        /// </summary>
        public string PCS
        {
            get { return _PCS; }
            set { SetProperty(ref _PCS, value); }
        }

        /// <summary>
        /// 輸出偏誤計數器清除訊號至伺服馬達驅動。
        /// </summary>
        public string ERC
        {
            get { return _ERC; }
            set { SetProperty(ref _ERC, value); }
        }

        /// <summary>
        /// 編碼器Z訊號。
        /// </summary>
        public string EZ
        {
            get { return _EZ; }
            set { SetProperty(ref _EZ, value); }
        }

        /// <summary>
        /// 外部輸入至清除位置計數器。
        /// </summary>
        public string CLR
        {
            get { return _CLR; }
            set { SetProperty(ref _CLR, value); }
        }

        /// <summary>
        /// 鎖存訊號輸入。
        /// </summary>
        public string LTC
        {
            get { return _LTC; }
            set { SetProperty(ref _LTC, value); }
        }

        /// <summary>
        /// 減速訊號輸入。
        /// </summary>
        public string SD
        {
            get { return _SD; }
            set { SetProperty(ref _SD, value); }
        }

        /// <summary>
        /// 到位訊號輸入。
        /// </summary>
        public string INP
        {
            get { return _INP; }
            set { SetProperty(ref _INP, value); }
        }

        /// <summary>
        /// 伺服開啟（OUT6）。
        /// </summary>
        public string SVON
        {
            get { return _SVON; }
            set { SetProperty(ref _SVON, value); }
        }

        /// <summary>
        /// 警報重設輸出狀態。
        /// </summary>
        public string ALRM
        {
            get { return _ALRM; }
            set { SetProperty(ref _ALRM, value); }
        }

        /// <summary>
        /// 軟體限位+。
        /// </summary>
        public string SLMT_Positive
        {
            get { return _SLMT_Positive; }
            set { SetProperty(ref _SLMT_Positive, value); }
        }

        /// <summary>
        /// 軟體限位-。
        /// </summary>
        public string SLMT_Negative
        {
            get { return _SLMT_Negative; }
            set { SetProperty(ref _SLMT_Negative, value); }
        }

        /// <summary>
        /// 比較訊號。
        /// </summary>
        public string CMP
        {
            get { return _CMP; }
            set { SetProperty(ref _CMP, value); }
        }

        /// <summary>
        /// 凸輪區間DO。
        /// </summary>
        public string CAMDO
        {
            get { return _CAMDO; }
            set { SetProperty(ref _CAMDO, value); }
        }

        #endregion 軸的運動 I/O 狀態

        #region 群組狀態

        /// <summary>
        /// 群組狀態為Disable，無法執行群組運動。
        /// </summary>
        public string STA_GP_DISABLE
        {
            get { return _sta_GP_DISABLE; }
            set { SetProperty(ref _sta_GP_DISABLE, value); }
        }

        /// <summary>
        /// 群組已準備好，等待新的指令。
        /// </summary>
        public string STA_GP_READY
        {
            get { return _sta_GP_READY; }
            set { SetProperty(ref _sta_GP_READY, value); }
        }

        /// <summary>
        /// 群組停止。
        /// </summary>
        public string STA_GP_STOPPING
        {
            get { return _sta_GP_STOPPING; }
            set { SetProperty(ref _sta_GP_STOPPING, value); }
        }

        /// <summary>
        /// 出現錯誤，群組停止。
        /// </summary>
        public string STA_GP_ERROR_STOP
        {
            get { return _sta_GP_ERROR_STOP; }
            set { SetProperty(ref _sta_GP_ERROR_STOP, value); }
        }

        /// <summary>
        /// 群組正在運行。
        /// </summary>
        public string STA_GP_MOTION
        {
            get { return _sta_GP_MOTION; }
            set { SetProperty(ref _sta_GP_MOTION, value); }
        }

        /// <summary>
        /// 不支援。
        /// </summary>
        public string STA_GP_AX_MOTION
        {
            get { return _sta_GP_AX_MOTION; }
            set { SetProperty(ref _sta_GP_AX_MOTION, value); }
        }

        /// <summary>
        /// 群組正在執行Path運動。
        /// </summary>
        public string STA_GP_MOTION_PATH
        {
            get { return _sta_GP_MOTION_PATH; }
            set { SetProperty(ref _sta_GP_MOTION_PATH, value); }
        }

        /// <summary>
        /// 群組暫停。
        /// </summary>
        public string STA_GP_PAUSE
        {
            get { return _sta_GP_PAUSE; }
            set { SetProperty(ref _sta_GP_PAUSE, value); }
        }

        /// <summary>
        /// 群組忙碌中，前一個指令尚未處理完成。
        /// </summary>
        public string STA_GP_BUSY
        {
            get { return _sta_GP_BUSY; }
            set { SetProperty(ref _sta_GP_BUSY, value); }
        }

        #endregion 群組狀態

        #region 群組速度

        /// <summary>
        /// 設定 / 取得此軸的初始速度 ( 起始速度)。
        /// </summary>
        public string PAR_GpVelLow
        {
            get { return _par_GpVelLow; }
            set { SetProperty(ref _par_GpVelLow, value); }
        }

        /// <summary>
        /// 設定 / 取得該軸的運轉速度。
        /// </summary>
        public string PAR_GpVelHigh
        {
            get { return _par_GpVelHigh; }
            set { SetProperty(ref _par_GpVelHigh, value); }
        }

        /// <summary>
        /// 設定 / 取得該軸的加速度。
        /// </summary>
        public string PAR_GpAcc
        {
            get { return _par_GpAcc; }
            set { SetProperty(ref _par_GpAcc, value); }
        }

        /// <summary>
        /// 設定 / 取得該軸的減速度。
        /// </summary>
        public string PAR_GpDec
        {
            get { return _par_GpDec; }
            set { SetProperty(ref _par_GpDec, value); }
        }

        /// <summary>
        /// 設定 / 取得速度曲線的類型：T/S 型曲線。
        /// </summary>
        public string PAR_GpJerk
        {
            get { return _par_GpJerk; }
            set { SetProperty(ref _par_GpJerk, value); }
        }

        #endregion 群組速度
    }
}
