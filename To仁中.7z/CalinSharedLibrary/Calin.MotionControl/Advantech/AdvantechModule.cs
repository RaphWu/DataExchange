﻿using Autofac;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;
using Calin.MC.Advantech.Services;

namespace Calin.MC.Advantech
{
    public class AdvantechModule : Module
    {
        public AcmConfig AcmConfig { get; set; }

        protected override void Load(ContainerBuilder builder)
        {
            if (AcmConfig != null)
            {
                builder.Register(c => new AcmService(AcmConfig))
                    .As<IAcm>()
                    .SingleInstance();
            }
            else
            {
                builder.Register(c => new AcmService(c.Resolve<AcmConfig>()))
                    .As<IAcm>()
                    .InstancePerDependency();
            }

            var container = builder.Build();

            //builder.RegisterBuildCallback(async c =>
            //{
            //    var core = c.Resolve<ICore>();
            //    await core.Initialize();
            //});
        }
    }
}
