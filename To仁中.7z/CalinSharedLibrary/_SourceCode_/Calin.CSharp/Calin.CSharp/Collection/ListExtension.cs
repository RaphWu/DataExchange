﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;

namespace Calin.CSharp.Collection
{
    /// <summary>
    /// List擴充功能。
    /// </summary>
    public static class ListExtension
    {
        /// <summary>
        /// List&lt;T&gt; 轉換 DataTable。
        /// </summary>
        /// <param name="items">待轉換的 List&lt;T&gt;</param>
        /// <returns>轉換後的 DataTable</returns>
        public static DataTable ListToDataTable<T>(List<T> items)
        {
            var dataTable = new DataTable(typeof(T).Name);

            // 建立欄位（根據屬性）
            foreach (var prop in typeof(T).GetProperties())
            {
                var propType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                dataTable.Columns.Add(prop.Name, propType);
            }

            // 加入每一筆資料
            foreach (var item in items)
            {
                var values = new object[typeof(T).GetProperties().Length];
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = typeof(T).GetProperties()[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        /// <summary>
        /// 將 DataTable 轉換成 List&lt;T&gt;。
        /// </summary>
        /// <param name="dt">待轉換的 DataTable。</param>
        /// <returns>轉換後的 List&lt;T&gt;。</returns>
        /// <remarks>程式碼來源: <see href="https://stackoverflow.com/questions/1427484/convert-datatable-to-listt">Convert DataTable to List&lt;T&gt;</see>。</remarks>
        public static List<T> DataTableToList<T>(DataTable dt)
        {
            List<string> columnNames = dt.Columns.Cast<DataColumn>()
                                                 .Select(c => c.ColumnName)
                                                 .ToList();
            var properties = typeof(T).GetProperties();

            return dt.AsEnumerable().Select(row =>
            {
                var objT = Activator.CreateInstance<T>();
                foreach (var pro in properties)
                {
                    if (columnNames.Contains(pro.Name))
                    {
                        PropertyInfo pI = objT.GetType().GetProperty(pro.Name);
                        pro.SetValue(objT, row[pro.Name] == DBNull.Value ? null : Convert.ChangeType(row[pro.Name], pI.PropertyType));
                    }
                }
                return objT;
            }).ToList();
        }
    }
}