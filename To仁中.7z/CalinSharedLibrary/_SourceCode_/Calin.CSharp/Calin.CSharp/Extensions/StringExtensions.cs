﻿using System.Globalization;

namespace Calin.CSharp.Extensions
{
    /// <summary>
    /// string 擴充功能。
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// 將字串改成字首大寫。
        /// </summary>
        public static string ToTitleCase(this string str)
        {
            if (string.IsNullOrWhiteSpace(str)) return str;
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower());
        }
    }
}
