﻿using System.Drawing;
using System.Windows.Forms;

namespace Calin.WinForm
{
    public static class UISettings
    {
        /// <summary>
        /// 設定預設字型為微軟正黑體，11pt。
        /// </summary>
        public static readonly Font DefaultFont = new Font("Microsoft JhengHei", 11F);
        public static readonly Font DefaultToolStripFont = new Font("Microsoft JhengHei", 9F);

        /// <summary>
        /// 套用預設字型為微軟正黑體，11pt。<br/>
        /// 套用預設 ToolStrip 字型為微軟正黑體，9pt。
        /// </summary>
        /// <param name="ctrl">控制項。</param>
        /// <remarks>
        /// 使用方法:
        /// <code>
        /// public partial class Form1 : Form
        /// {
        ///     public Form1()
        ///     {
        ///         InitializeComponent();
        ///         UISettings.ApplyGlobalFont(this); // 套用到整個表單
        ///     }
        /// }
        /// </code>
        /// </remarks>
        public static void ApplyGlobalFont(Control ctrl)
        {
            if (ctrl == null) return;

            // 一般控制項
            if (ctrl.Font == Control.DefaultFont)
                ctrl.Font = DefaultFont;

            // ToolStrip / MenuStrip / StatusStrip
            if (ctrl is ToolStrip toolStrip)
            {
                foreach (ToolStripItem item in toolStrip.Items)
                {
                    if (item.Font == Control.DefaultFont)
                        item.Font = DefaultFont;
                }
            }

            // ListView
            if (ctrl is ListView listView)
                if (listView.Font == Control.DefaultFont)
                    listView.Font = DefaultFont;

            // TreeView + TreeNode
            if (ctrl is TreeView treeView)
            {
                if (treeView.Font == Control.DefaultFont)
                    treeView.Font = DefaultFont;

                foreach (TreeNode node in treeView.Nodes)
                    ApplyFontToTreeNode(node);
            }

            // DataGridView 各部分
            if (ctrl is DataGridView dgv)
            {
                if (dgv.DefaultCellStyle.Font == null || dgv.DefaultCellStyle.Font == Control.DefaultFont)
                    dgv.DefaultCellStyle.Font = DefaultFont;

                if (dgv.ColumnHeadersDefaultCellStyle.Font == null || dgv.ColumnHeadersDefaultCellStyle.Font == Control.DefaultFont)
                    dgv.ColumnHeadersDefaultCellStyle.Font = DefaultFont;

                if (dgv.RowHeadersDefaultCellStyle.Font == null || dgv.RowHeadersDefaultCellStyle.Font == Control.DefaultFont)
                    dgv.RowHeadersDefaultCellStyle.Font = DefaultFont;

                if (dgv.RowsDefaultCellStyle.Font == null || dgv.RowsDefaultCellStyle.Font == Control.DefaultFont)
                    dgv.RowsDefaultCellStyle.Font = DefaultFont;
            }

            // ListBox
            if (ctrl is ListBox listBox)
                if (listBox.Font == Control.DefaultFont)
                    listBox.Font = DefaultFont;

            // ComboBox
            if (ctrl is ComboBox comboBox)
                if (comboBox.Font == Control.DefaultFont)
                    comboBox.Font = DefaultFont;

            // TabControl
            if (ctrl is TabControl tabControl)
                if (tabControl.Font == Control.DefaultFont)
                    tabControl.Font = DefaultFont;

            // 遞迴處理子控制項
            foreach (Control child in ctrl.Controls)
                ApplyGlobalFont(child);
        }

        /// <summary>
        /// 遞迴處理 TreeNode 的 NodeFont。
        /// </summary>
        private static void ApplyFontToTreeNode(TreeNode node)
        {
            // 如果尚未指定 NodeFont，則使用預設字體
            if (node.NodeFont == null || node.NodeFont == Control.DefaultFont)
                node.NodeFont = DefaultFont;

            // 遞迴子節點
            foreach (TreeNode child in node.Nodes)
                ApplyFontToTreeNode(child);
        }
    }
}
