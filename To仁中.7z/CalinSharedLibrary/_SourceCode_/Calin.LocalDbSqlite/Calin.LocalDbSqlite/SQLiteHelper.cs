﻿using System.Data;
using System.Data.SQLite;
using System.IO;

namespace Calin.LocalDbSqlite
{
    /// <summary>
    /// SQLite操作包裝。
    /// </summary>
    public static class SQLiteHelper
    {
        /********************
         * Database
         ********************/
        /// <inheritdoc/>
        public static SQLiteConnection OpenConnection(string fullFileName)
        {
            return OpenConnection(Path.GetDirectoryName(fullFileName), Path.GetFileName(fullFileName));
        }

        /// <inheritdoc/>
        public static SQLiteConnection OpenConnection(string dbDirectory, string dbfileName)
        {
            if (string.IsNullOrWhiteSpace(dbDirectory) || string.IsNullOrWhiteSpace(dbfileName))
                return null;

            string fullPath = Path.Combine(dbDirectory, dbfileName);
            if (!File.Exists(fullPath))
                CreateDatabase(dbDirectory, dbfileName);

            var conn = new SQLiteConnection()
            {
                ConnectionString = $"Data Source={fullPath};Version=3;New=False;Compress=True;FailIfMissing=True;"
            };

            if (conn == null)
                return null;

            if (conn.State == ConnectionState.Open)
                conn.Close();
            conn.Open();

            return conn;
        }

        /// <inheritdoc/>
        public static bool CreateDatabase(string dbDirectory, string dbfileName)
        {
            if (string.IsNullOrWhiteSpace(dbDirectory) || string.IsNullOrWhiteSpace(dbfileName))
                return false;

            if (!Directory.Exists(dbDirectory))
                Directory.CreateDirectory(dbDirectory);

            if (!File.Exists(Path.Combine(dbDirectory, dbfileName)))
            {
                var conn = new SQLiteConnection()
                {
                    ConnectionString = $"Data Source={Path.Combine(dbDirectory, dbfileName)};Version=3;New=True;Compress=True;"
                };
                conn?.Open();
                conn?.Close();
            }
            return true;
        }

        /// <inheritdoc/>
        public static void Close(SQLiteConnection conn)
        {
            if (conn != null && conn.State == ConnectionState.Open)
                conn.Close();
        }

        /// <inheritdoc/>
        public static void Vaccum(SQLiteConnection conn)
        {
            if (conn != null && conn.State == ConnectionState.Open)
            {
                SQLiteCommand command = conn.CreateCommand();
                command.CommandText = "VACUUM;";
                command.ExecuteNonQuery();
            }
        }

        /********************
         * Table
         ********************/
        /// <inheritdoc/>
        public static void CreateTable(SQLiteConnection conn, string sqlCreateTable)
        {
            if (conn == null || conn.State != ConnectionState.Open || string.IsNullOrEmpty(sqlCreateTable))
                return;

            var command = new SQLiteCommand(sqlCreateTable, conn);
            var trans = conn.BeginTransaction();
            try
            {
                command.Transaction = trans;
                command.ExecuteNonQuery();
                trans.Commit();
            }
            catch
            {
                trans.Rollback();
                throw;
            }
        }

        /// <inheritdoc/>
        public static bool IsTableExist(SQLiteConnection conn, string tableName)
        {
            if (conn != null && (conn.State == ConnectionState.Open || !string.IsNullOrEmpty(tableName)))
                return conn.GetSchema("Tables").Select($"Table_Name='{tableName}'").Length > 0;
            return false;
        }

        /********************
         * Other
         ********************/
        /// <inheritdoc/>
        public static int GetMaxValue(SQLiteConnection conn, string tableName, string columnName)
        {
            if (conn == null
                || conn.State != ConnectionState.Open
                || string.IsNullOrWhiteSpace(tableName)
                || string.IsNullOrWhiteSpace(columnName))
                return -1;

            if (!IsTableExist(conn, tableName))
                return -1;

            string query = $"SELECT MAX({columnName}) FROM {tableName}";
            SQLiteCommand selectMaxCmd = new SQLiteCommand(query, conn);
            SQLiteDataReader dataReader = selectMaxCmd.ExecuteReader();

            int maxID = -1;
            while (dataReader.Read())
                maxID = int.Parse(dataReader.GetValue(0).ToString());

            return maxID;
        }
    }
}
