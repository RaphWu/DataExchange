﻿# Calin.SQLite 1.0.1
2025-09-30
- x86 改回 AnyCPU
- 套件名稱由 Calin.SQLite 改為 Calin.LocalDbSqlite
- 相依性套件由 System.Data.SQLite 改為 System.Data.SQLite.Core

# Calin.SQLite 1.0.0
2025-09-25
- 初版
