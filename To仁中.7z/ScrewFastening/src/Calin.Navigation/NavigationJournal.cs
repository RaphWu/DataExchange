using System;
using System.Collections.Generic;
using System.Linq;

namespace Calin.Navigation
{
    /// <summary>
    /// �ɯ���v��x��@�C
    /// </summary>
    public class NavigationJournal : INavigationJournal
    {
        private readonly List<NavigationJournalEntry> _entries = new List<NavigationJournalEntry>();
        private int _currentIndex = -1;

        /// <inheritdoc />
        public NavigationJournalEntry CurrentEntry
        {
            get
            {
                if (_currentIndex >= 0 && _currentIndex < _entries.Count)
                {
                    return _entries[_currentIndex];
                }
                return null;
            }
        }

        /// <inheritdoc />
        public bool CanGoBack => _currentIndex > 0;

        /// <inheritdoc />
        public bool CanGoForward => _currentIndex < _entries.Count - 1;

        /// <inheritdoc />
        public IReadOnlyList<NavigationJournalEntry> Entries => _entries.AsReadOnly();

        /// <inheritdoc />
        public void RecordNavigation(NavigationJournalEntry entry)
        {
            if (entry == null)
                throw new ArgumentNullException(nameof(entry));

            // �p�G���b�̫�A�����᭱�����ء]�s�ɯ�|�л\�e�i���v�^
            if (_currentIndex < _entries.Count - 1)
            {
                _entries.RemoveRange(_currentIndex + 1, _entries.Count - _currentIndex - 1);
            }

            _entries.Add(entry);
            _currentIndex = _entries.Count - 1;
        }

        /// <inheritdoc />
        public NavigationJournalEntry GoBack()
        {
            if (!CanGoBack)
                throw new InvalidOperationException("�L�k��h�A�w�b���v�������_�l��m�C");

            _currentIndex--;
            return CurrentEntry;
        }

        /// <inheritdoc />
        public NavigationJournalEntry GoForward()
        {
            if (!CanGoForward)
                throw new InvalidOperationException("�L�k�e�i�A�w�b���v�������̫��m�C");

            _currentIndex++;
            return CurrentEntry;
        }

        /// <inheritdoc />
        public void Clear()
        {
            _entries.Clear();
            _currentIndex = -1;
        }

        /// <inheritdoc />
        public NavigationJournalEntry GetEntryByViewName(string viewName)
        {
            if (string.IsNullOrEmpty(viewName))
                return null;

            return _entries.FirstOrDefault(e =>
                string.Equals(e.ViewName, viewName, StringComparison.OrdinalIgnoreCase));
        }
    }
}
