﻿namespace Calin.MotionControl.Advantech.ViewModels
{
    /// <summary>
    /// int-string (Id-Name) 配對結構.
    /// </summary>
    public class IntStringPair
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
