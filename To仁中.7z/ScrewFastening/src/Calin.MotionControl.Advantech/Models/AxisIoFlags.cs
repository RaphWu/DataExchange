﻿using System;
using System.ComponentModel;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 軸的運動 I/O 旗標列舉。
    /// </summary>
    [Flags]
    public enum AxisIoFlags : uint
    {
        [Description("RDY")]
        RDY = 1 << 0,

        [Description("ALM")]
        ALM = 1 << 1,

        [Description("極限開關+")]
        LMT_Positive = 1 << 2,

        [Description("極限開關-")]
        LMT_Negative = 1 << 3,

        [Description("原點")]
        ORG = 1 << 4,

        [Description("DIR")]
        DIR = 1 << 5,

        [Description("緊急停止")]
        EMG = 1 << 6,

        [Description("編碼器Z相")]
        EZ = 1 << 7,

        [Description("鎖存訊號")]
        LTC = 1 << 11,

        [Description("INP到位訊號")]
        INP = 1 << 13,

        [Description("伺服ON")]
        SVON = 1 << 14,

        [Description("警報復位")]
        ALRM = 1 << 15,

        [Description("軟體極限+")]
        SLMT_Positive = 1 << 16,

        [Description("軟體極限-")]
        SLMT_Negative = 1 << 17,
    }
}
