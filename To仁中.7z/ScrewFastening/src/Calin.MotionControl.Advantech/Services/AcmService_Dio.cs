﻿using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;

namespace Calin.MotionControl.Advantech.Services
{
    // 數位輸入輸出服務
    public partial class AcmService : IAcmService_Dio
    {
        /// <inheritdoc/>
        public bool GenDoEnable()
        {
            bool noErr = true;
            for (int axisNo = 0; axisNo < _axisCount; axisNo++)
            {
                ErrCode = Motion.mAcm_SetU32Property(_axisHandles[axisNo], (uint)PropertyID.CFG_AxGenDoEnable, 1);
                if (!Success)
                {
                    AddErrInfo($"{nameof(IAcmService_Dio)}.{nameof(GenDoEnable)}", $"無法啟用軸 {axisNo + 1} 的通用數位輸出功能！");
                    noErr = false;
                }
            }
            return noErr;
        }

        /// <inheritdoc/>
        public bool GenDoDisable()
        {
            bool noErr = true;
            for (int axisNo = 0; axisNo < _axisCount; axisNo++)
            {
                ErrCode = Motion.mAcm_SetU32Property(_axisHandles[axisNo], (uint)PropertyID.CFG_AxGenDoEnable, 0);
                if (!Success)
                {
                    AddErrInfo($"{nameof(IAcmService_Dio)}.{nameof(GenDoDisable)}", $"無法停用軸 {axisNo + 1} 的通用數位輸出功能！");
                    noErr = false;
                }
            }
            return noErr;
        }

        /// <inheritdoc/>
        public void ReadDi()
        {
            byte data = default;
            ErrCode = Motion.mAcm_AxDiGetByte(_axisHandles[0], 0, ref data);
            ErrCode = Motion.mAcm_AxDiGetByte(_axisHandles[0], 1, ref data);
            ErrCode = Motion.mAcm_AxDiGetByte(_axisHandles[0], 2, ref data);
            ErrCode = Motion.mAcm_AxDiGetByte(_axisHandles[0], 3, ref data);
        }
    }
}
