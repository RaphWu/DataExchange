﻿using System;
using System.Collections.ObjectModel;
using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.MVVM;

namespace Calin.MotionControl.Advantech.Services
{
    // 裝置(Device)與控制卡(Board)操作
    // 裝置設定檔操作
    public partial class AcmService : ObservableObject, IAcmService_Device
    {
        #region Fields

        /// <summary>
        /// 裝置句柄。
        /// </summary>
        private IntPtr _deviceHandle = IntPtr.Zero;

        /// <summary>
        /// 控制卡是否初始化。
        /// </summary>
        private bool _boardInit = false;

        /// <summary>
        /// 有效裝置數量。
        /// </summary>
        private uint _deviceCount = 0;

        /// <summary>
        /// 可用裝置列表。
        /// </summary>
        private readonly ObservableCollection<DeviceInfo> _availableDevices = new ObservableCollection<DeviceInfo>();

        #endregion Fields

        #region properties
        public uint DeviceCount => _deviceCount;
        public ObservableCollection<DeviceInfo> AvailableDevices => _availableDevices;
        public IntPtr DeviceHandle => _deviceHandle;
        public bool IsBoardInit => _boardInit;
        public uint DaqDiMaxChannel => _daqDiMaxChannel;
        public uint DaqDoMaxChannel => _daqDoMaxChannel;

        #endregion properties

        #region methods

        /// <inheritdoc/>
        public bool GetAvailableDevs()
        {
            DEV_LIST[] availableDevices = new DEV_LIST[Motion.MAX_DEVICES];
            ErrCode = (uint)Motion.mAcm_GetAvailableDevs(availableDevices, Motion.MAX_DEVICES, ref _deviceCount);
            if (!Success)
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "無法取得裝置編號及名稱列表！");
                return false;
            }
            if (_deviceCount <= 0)
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "找不到任何可用的裝置！");
                return false;
            }

            _availableDevices.Clear();
            for (int i = 0; i < _deviceCount; i++)
                _availableDevices.Add(new DeviceInfo()
                {
                    DeviceName = availableDevices[i].DeviceName,
                    DeviceNumber = availableDevices[i].DeviceNum,
                    NumofSubDevice = availableDevices[i].NumofSubDevice,
                });

            // TODO: 取得數位輸入/輸出最大通道數
            //ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqDoMaxChan, ref _daqDoMaxChannel);
            //if (ErrorOccurred($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "取得數位輸出最大通道數失敗！"))
            //    return 0;

            //ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DaqDiMaxChan, ref _daqDiMaxChannel);
            //if (ErrorOccurred($"{nameof(IAcmService_Device)}.{nameof(GetAvailableDevs)}", "取得數位輸入最大通道數失敗！"))
            //    return 0;

            return true;
        }

        /// <inheritdoc/>
        public bool BoardClose()
        {
            if (_boardInit)
            {
                ushort[] axisState = new ushort[_axisCount];
                int axisNo;

                PollingStop();

                for (axisNo = 0; axisNo < _axisCount; axisNo++)
                {
                    AxisStop(axisNo); // 確認軸在停止狀態
                    ServoOff(axisNo); // 關閉伺服
                }

                for (axisNo = 0; axisNo < _axisCount; axisNo++)
                {
                    ErrCode = Motion.mAcm_AxClose(ref _axisHandles[axisNo]);
                    if (!Success)
                        AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", $"軸 {axisNo + 1} 關閉失敗！");
                }
                _axisCount = 0;

                ErrCode = Motion.mAcm_DevClose(ref _deviceHandle);
                if (!Success)
                {
                    AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(BoardClose)}", "裝置關閉失敗！");
                    return false;
                }

                _deviceHandle = IntPtr.Zero;
                _boardInit = false;
            }
            return true;
        }

        /// <inheritdoc/>
        public bool BoardOpen(uint deviceNum)
        {
            ErrCode = Motion.mAcm_DevOpen(deviceNum, ref _deviceHandle);
            if (!Success)
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", $"裝置編號 {deviceNum} 開啟失敗！");
                return false;
            }

            ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.FT_DevAxesCount, ref _axisCount);
            if (!Success)
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", "無法取得控制卡上的軸數量！");
                return false;
            }
            if (_axisCount == 0)
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", $"裝置編號 {deviceNum} 開啟失敗：控制卡軸數量為 0！");
                return false;
            }

            // init arrays
            _axisHandles = new IntPtr[_axisCount];
            _servoOn = new bool[_axisCount];
            _rawAxisStates = new RawAxisState[_axisCount];
            _parsedAxisStates = new ParsedAxisState[_axisCount];
            _acmConfig.AxisConfigs = new ObservableCollection<AxisConfig>();

            for (int axisNo = 0; axisNo < _axisCount; axisNo++)
            {
                _servoOn[axisNo] = false;
                _rawAxisStates[axisNo] = new RawAxisState();
                _parsedAxisStates[axisNo] = new ParsedAxisState();
                _acmConfig.AxisConfigs.Add(new AxisConfig());

                ErrCode = Motion.mAcm_AxOpen(_deviceHandle, (ushort)axisNo, ref _axisHandles[axisNo]);
                if (!Success)
                {
                    AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(BoardOpen)}", $"軸 {axisNo + 1} 開啟失敗！");
                    return false;
                }

                // 設定命令位置及實際位置為 0
                ErrCode = Motion.mAcm_AxSetCmdPosition(_axisHandles[axisNo], 0.0);
                ErrCode = Motion.mAcm_AxSetActualPosition(_axisHandles[axisNo], 0.0);
            }

            _boardInit = true;
            return true;
        }

        #endregion methods

        #region Advantech內建

        /// <inheritdoc/>
        public bool LoadCfg(string filePath)
        {
            if (!_boardInit)
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(LoadCfg)}", "控制卡尚未開啟");
                return false;
            }

            //ErrCode = Motion.mAcm_DevLoadConfig(_deviceHandle, filePath);
            //if (ErrorOccurred($"{nameof(IAcmService_Device)}.{nameof(LoadCfg)}", "裝置Config檔載入失敗！")) return false;

            return true;
        }

        #endregion Advantech內建

        #region Configs

        /// <inheritdoc/>
        public DeviceConfig LoadDeviceSetting()
        {
            var config = new DeviceConfig();

            uint emgLogic = 0;
            ErrCode = Motion.mAcm_GetU32Property(_deviceHandle, (uint)PropertyID.CFG_DevEmgLogic, ref emgLogic);
            if (Success)
            {
                config.EmgLogic = emgLogic;
            }
            else
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(GetDeviceConfigFile)}", "讀取 EMG 邏輯電位失敗！");
                return null;
            }

            int emgFilterTime = 0;
            ErrCode = Motion.mAcm_GetI32Property(_deviceHandle, (uint)PropertyID.CFG_DevEmgFilterTime, ref emgFilterTime);
            if (Success)
            {
                config.EmgFilterTime = emgFilterTime;
            }
            else
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(GetDeviceConfigFile)}", "讀取 EMG 濾波時間失敗！");
                return null;
            }

            return config;
        }

        /// <inheritdoc/>
        public void ApplyDeviceSetting(DeviceConfig config)
        {
            if (config == null) return;

            bool noError = false;
            bool _isRollback = false;

            do
            {
                ErrCode = Motion.mAcm_SetU32Property(_deviceHandle, (uint)PropertyID.CFG_DevEmgLogic, config.EmgLogic);
                if (!Success)
                {
                    AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(ApplyDeviceSetting)}", "寫入 EMG 邏輯電位失敗！");
                    break;
                }

                ErrCode = Motion.mAcm_SetI32Property(_deviceHandle, (uint)PropertyID.CFG_DevEmgFilterTime, config.EmgFilterTime);
                if (!Success)
                {
                    AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(ApplyDeviceSetting)}", "寫入 EMG 濾波時間失敗！");
                    break;
                }

                noError = true;
            } while (false);

            if (_isRollback)
            {
                if (noError)
                {
                    AddErrInfo((uint)ErrorCode.InvalidParameter, $"{nameof(IAcmService_Device)}.{nameof(ApplyDeviceSetting)}", "套用裝置設定失敗，已回復原本設定！");
                }
                else
                {
                    AddErrInfo((uint)ErrorCode.InvalidParameter, $"{nameof(IAcmService_Device)}.{nameof(ApplyDeviceSetting)}", "套用裝置設定失敗，也無法回復原本設定！");
                }
                DeviceConfig.CopyFrom(config);
                return;
            }

            if (!noError)
            {
                noError = true;
                _isRollback = true;
                ApplyDeviceSetting(DeviceConfig); // rollback
                return;
            }

            // 儲存至本地
            noError = true;
            _isRollback = false;
        }

        /// <inheritdoc/>
        public bool GetDeviceConfigFile(ref DeviceConfig config)
        {
            if (!_boardInit)
            {
                AddErrInfo($"{nameof(IAcmService_Device)}.{nameof(GetDeviceConfigFile)}", "控制卡尚未開啟");
                return false;
            }

            return true;
        }

        #endregion Configs
    }
}
