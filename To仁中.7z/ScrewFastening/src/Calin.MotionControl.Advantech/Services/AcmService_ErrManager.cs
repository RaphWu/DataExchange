﻿using System.Text;
using Advantech.Motion;
using Calin.Logging.Abstractions;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Microsoft.Extensions.Logging;

namespace Calin.MotionControl.Advantech.Services
{
    // 錯誤管理
    public partial class AcmService : IAcmService_ErrManager
    {
        #region fields

        private const int MaxError = 100;
        private readonly ILogger<AcmService> _logger = LoggingBridge.CreateLogger<AcmService>();

        private bool _success;
        private AcmResult _acmResult = new AcmResult();

        #endregion fields

        #region Properties

        public bool Success => _success;

        public AcmResult AcmResult => _acmResult;

        /// <summary>
        /// 接收方法呼叫的回傳值，然後設定是否成功、訊息、詳細資訊。
        /// </summary>
        internal uint ErrCode
        {
            get => _acmResult.ErrCode;
            set
            {
                _success = value == (int)ErrorCode.SUCCESS;

                if (!_success)
                {
                    _acmResult.ErrCode = value;
                    _acmResult.CallerName = "";
                    _acmResult.Message = GetErrorMessage(value);
                    _acmResult.AdditionalMessage = "";
                }

                _logger.LogError("Error:0x{ErrorCode},{Message},",
                    _acmResult.ErrCode.ToString("X8"),
                    _acmResult.Message);
            }
        }

        #endregion Properties

        #region Methods

        private string GetErrorMessage(uint errCode)
        {
            StringBuilder sb = new StringBuilder("", MaxError);
            return Motion.mAcm_GetErrorMessage(errCode, sb, MaxError)
                ? sb.ToString()
                : $"無法取得錯誤代碼 0x{errCode:8X} 的訊息，請查閱手冊或詢問原廠。";
        }

        /// <inheritdoc/>
        public bool ResetAxisState(int axisNo)
        {
            ErrCode = Motion.mAcm_AxResetError(_axisHandles[axisNo]);
            if (!Success)
                AddErrInfo($"{nameof(IAcmService_ErrManager)}.{nameof(ResetAxisState)}", $"無法重置軸 {axisNo + 1} 的座標軸狀態！");
            return Success;
        }

        #endregion

        #region Internal Methods

        ///// <summary>
        ///// 檢查是否有錯誤發生，並設定附加詳細資訊。
        ///// </summary>
        ///// <remarks>注意：只有在有錯誤發生時才會設定呼叫者名稱及錯誤詳細資訊，以避免過多的變數設定動作。</remarks>
        ///// <param name="callerName">呼叫者名稱。</param>
        ///// <param name="additionalMsg">附加錯誤資訊。</param>
        ///// <returns>是否有錯誤發生。</returns>
        //internal bool ErrorOccurred(string callerName, string additionalMsg = "")
        //{
        //    if (!Success)
        //    {
        //        _acmResult.AdditionalMessage = additionalMsg;
        //        _acmResult.CallerName = callerName;
        //        return true;
        //    }
        //    return false;
        //}

        ///// <summary>
        ///// 檢查是否有錯誤發生，並設定附加詳細資訊。
        ///// </summary>
        ///// <param name="additionalMsg">附加錯誤資訊。</param>
        ///// <returns>是否有錯誤發生。</returns>
        //internal bool ErrorOccurred(string additionalMsg = "")
        //{
        //    return ErrorOccurred("", additionalMsg);
        //}

        /// <summary>
        /// 設定錯誤訊息。
        /// </summary>
        /// <remarks>
        /// 有時控制回報沒有問題，但程式仍無法運作，
        /// 比如使用 PropertyID.FT_DevAxesCount 取得軸數為零時，不會報錯，但沒有軸可以動作。
        /// </remarks>
        /// <param name="callerName">呼叫者名稱。</param>
        /// <param name="additionalMsg">附加錯誤資訊。</param>
        internal void AddErrInfo(uint errCode, string callerName, string additionalMsg = "")
        {
            _acmResult.ErrCode = errCode;
            _acmResult.CallerName = callerName;
            _acmResult.Message = GetErrorMessage(errCode);
            _acmResult.AdditionalMessage = additionalMsg;
        }

        /// <summary>
        /// 設定錯誤訊息。
        /// </summary>
        /// <remarks>
        /// 有時控制回報沒有問題，但程式仍無法運作，
        /// 比如使用 PropertyID.FT_DevAxesCount 取得軸數為零時，不會報錯，但沒有軸可以動作。
        /// </remarks>
        /// <param name="callerName">呼叫者名稱。</param>
        /// <param name="additionalMsg">附加錯誤資訊。</param>
        internal void AddErrInfo(string callerName, string additionalMsg = "")
        {
            AddErrInfo((uint)ErrorCode.SUCCESS, callerName, additionalMsg);
        }

        #endregion Internal Methods









        ///// <summary>
        ///// 錯誤訊息表。
        ///// </summary>
        //internal Dictionary<int, ErrManager> errorMessages = new Dictionary<int, ErrManager>();

        ///// <inheritdoc/>
        //public ErrManager GetErrMessage(int code)
        //{
        //    return errorMessages.TryGetValue(code, out var errMessage)
        //        ? errMessage
        //        : new ErrMessage("查無代碼", $"錯誤訊息表沒有錯誤代碼 0x{code:8X} 的資訊，請查閱手冊。");
        //}

        ///// <summary>
        ///// 設定錯誤訊息表。
        ///// </summary>
        //internal void ConfigErrorMessages()
        //{
        //    errorMessages.Add(0x00000000, new ErrMessage("SUCCESS"));
        //}
    }
}
