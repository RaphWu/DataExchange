﻿using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Contracts
{
    /// <summary>
    /// Acm 服務介面。
    /// </summary>
    public interface IAcm :
        IAcmService_Device, IAcmService_Axis, IAcmService_Group,
        IAcmService_Dio,
        IAcmService_Polling, IAcmService_Manual, IAcmService_ErrManager
    {
        #region properties

        /// <summary>
        /// 運動控制卡參數配置。
        /// </summary>
        AcmConfig Config { get; }

        #endregion properties

        #region Methods

        /// <summary>
        /// 初始化 Advantech ACM 控制卡。
        /// </summary>
        /// <remarks>這是給應用程式第一次初始化使用，包含運動控制卡啟動及首次讀取所有參數，不含啟動Polling。</remarks>
        /// <returns>是否成功初始化。</returns>
        bool Initialize();

        /// <summary>
        /// 載入運動控制卡參數配置。
        /// </summary>
        void LoadHwSetting();

        /// <summary>
        /// 儲存運動控制卡參數配置。
        /// </summary>
        /// <param name="config"></param>
        void SaveConfig(AcmConfig config);

        #endregion Methods
    }
}
