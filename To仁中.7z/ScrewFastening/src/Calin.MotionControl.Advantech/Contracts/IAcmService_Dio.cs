﻿namespace Calin.MotionControl.Advantech.Contracts
{
    public interface IAcmService_Dio
    {
        void ReadDi();
    }
}
