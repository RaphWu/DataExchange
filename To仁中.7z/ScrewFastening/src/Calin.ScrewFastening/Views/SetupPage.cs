﻿using System;
using System.Windows.Forms;
using Advantech.Motion;
using Calin.MotionControl.Advantech.Constants;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.Navigation;
using Calin.ScrewFastening.Models;
using Calin.ScrewFastening.Services;
using Calin.SerialPort;

namespace Calin.ScrewFastening.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class SetupPage : UserControl
    {
        #region Fields

        private readonly IScrewFastening _lockingMachine;
        private readonly IAcm _acm;
        private readonly LmData _lmData;
        private readonly RawData _rawData;
        private readonly AcmConfig _mcData;
        private readonly Dlrs1aData _dispData;
        private readonly DaqData _daqData;

        private bool _isUpdateBackground = true;
        private bool _isLoading = true;

        #endregion Fields

        #region ctor

        public SetupPage(
            IScrewFastening device,
            IAcm acm,
            LmData lmData,
            RawData rawData,
            AcmConfig acmConfig,
            Dlrs1aData dlrs1aData,
            DaqData daqData)
        {
            _lockingMachine = device;
            _acm = acm;
            _lmData = lmData;
            _rawData = rawData;
            _mcData = acmConfig;
            _dispData = dlrs1aData;
            _daqData = daqData;

            InitializeComponent();

            // 量測裝置

            cbHeightDispCom.Items.Clear();
            if (_lmData.comPortList.Count > 0)
                cbHeightDispCom.Items.AddRange(_lmData.comPortList.ToArray());
            //CbDlrs1aBaudRate.Items.AddRange(_dispData.heightDispConfig.BaudRateList.Select(x => x.ToString()).ToArray());
            //CbDlrs1aDataBits.Items.AddRange(_dispData.heightDispConfig.DataBitsList.Select(x => x.ToString()).ToArray());
            cbHeightDispBaudRate.Items.AddRange(new object[] { 4800, 9600, 19200, 38400, 57600, 115200 });
            cbHeightDispDataBits.Items.AddRange(new object[] { 5, 6, 7, 8, 9 });
            cbHeightDispParity.Items.AddRange(Enum.GetNames(typeof(Parity)));
            cbHeightDispStopBits.Items.AddRange(Enum.GetNames(typeof(StopBits)));

            cbTorqueMeterPort.Items.Clear();
            for (int ch = 0; ch < _lmData.usb4704Streaming.ChannelCountMax; ch += 2)
                cbTorqueMeterPort.Items.Add($"通道 AI{ch}~AI{ch + 1}");

            // 其他

            // Load Settings

            MotionCardLoad();
            Dlrs1aLoad();
            DaqLoad();
            _isLoading = false;
        }

        #endregion ctor

        #region Motion Card

        private void MotionCardLoad()
        {
            if (_acm.IsBoardInit)
            {
                // EMG
                cbEmgLogic.Items.Clear();
                cbEmgLogic.DataSource = AcmContants.EmgLogicList;
                cbEmgLogic.DisplayMember = "Name";
                cbEmgLogic.ValueMember = "Id";
                cbEmgLogic.SelectedValue = _mcData.DeviceConfig.EmgLogic;
                numEmgFilterTime.Value = _mcData.DeviceConfig.EmgFilterTime;

                // home
                cbHomeMode.Items.Clear();
                cbHomeMode.DataSource = AcmContants.HomeModeList;
                cbHomeMode.DisplayMember = "Name";
                cbHomeMode.ValueMember = "Id";
                cbHomeMode.SelectedIndex = (int)_mcData.AxisConfigs[0].HomeMode;

                cbHomeDir.Items.Clear();
                cbHomeDir.DataSource = AcmContants.HomeDirList;
                cbHomeDir.DisplayMember = "Name";
                cbHomeDir.ValueMember = "Id";
                cbHomeDir.SelectedIndex = (int)_mcData.AxisConfigs[0].HomeDir;

                cbHomeSwitchMode.Items.Clear();
                cbHomeSwitchMode.DataSource = AcmContants.ExSwitchModeList;
                cbHomeSwitchMode.DisplayMember = "Name";
                cbHomeSwitchMode.ValueMember = "Id";
                cbHomeSwitchMode.SelectedIndex = (int)_mcData.AxisConfigs[0].AxHomeExSwitchMode;

                numHomeVelL.Value = (decimal)_mcData.AxisConfigs[0].AxHomeVelLow;
                numHomeVelH.Value = (decimal)_mcData.AxisConfigs[0].AxHomeVelHigh;
                numHomeAcc.Value = (decimal)_mcData.AxisConfigs[0].AxHomeAcc;
                numHomeDec.Value = (decimal)_mcData.AxisConfigs[0].AxHomeDec;
                if (_mcData.AxisConfigs[0].AxHomeEzLogic == (uint)EZLogic.EZ_ACT_LOW)
                    rbHomeEzLow.Checked = true;
                else
                    rbHomeEzHigh.Checked = true;
                if (_mcData.AxisConfigs[0].AxHomeOrgLogic == (uint)ORGLogic.ORG_ACT_LOW)
                    rbHomeOrgLow.Checked = true;
                else
                    rbHomeOrgHigh.Checked = true;
                if (_mcData.AxisConfigs[0].AxHomeElLogic == (uint)EZLogic.EZ_ACT_LOW)
                    rbHomeHelLow.Checked = true;
                else
                    rbHomeHelHigh.Checked = true;
                //numHomeCrossDis.Value = (decimal)_mcData.AxisConfigs[0].AxHomeCrossDistance;
            }
            else
            {
                // EMG
                cbEmgLogic.Items.Clear();
                numEmgFilterTime.Value = (decimal)0.0;

                // home
                numHomeVelL.Value = (decimal)0.0;
                numHomeVelH.Value = (decimal)0.0;
                numHomeAcc.Value = (decimal)0.0;
                numHomeDec.Value = (decimal)0.0;
                numHomeCrossDis.Value = (decimal)0.0;
                rbHomeEzLow.Checked = true;
                rbHomeOrgLow.Checked = true;
                rbHomeHelLow.Checked = true;
            }
        }

        #endregion Motion Card

        #region Height Displacement

        private void Dlrs1aLoad()
        {
            _isUpdateBackground = true;

            tbUsb4704DeviceCode.Text = _daqData.DeviceCode;

            cbHeightDispCom.Text = _dispData.Dlrs1aConfig.PortName;
            cbHeightDispBaudRate.Text = _dispData.Dlrs1aConfig.BaudRate.ToString();
            cbHeightDispDataBits.Text = _dispData.Dlrs1aConfig.DataBits.ToString();
            cbHeightDispParity.Text = _dispData.Dlrs1aConfig.Parity.ToString();
            cbHeightDispStopBits.Text = _dispData.Dlrs1aConfig.StopBits.ToString();

            tbHeightDispLimitH.Value = (decimal)_dispData.HeightDisplacementLimitH;
            tbHeightDispLimitL.Value = (decimal)_dispData.HeightDisplacementLimitL;

            _isUpdateBackground = false;
        }

        private void CbHeightDispCom_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            if (_dispData.Dlrs1aConfig.PortName != cbHeightDispCom.Text)
            {
                _dispData.Dlrs1aConfig.PortName = cbHeightDispCom.Text;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void CbHeightDispBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var baudRate = int.Parse(cbHeightDispBaudRate.Text);
            if (_dispData.Dlrs1aConfig.BaudRate != baudRate)
            {
                _dispData.Dlrs1aConfig.BaudRate = baudRate;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void CbHeightDispParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var parity = (Parity)Enum.Parse(typeof(Parity), cbHeightDispParity.Text);
            if (_dispData.Dlrs1aConfig.Parity != parity)
            {
                _dispData.Dlrs1aConfig.Parity = parity;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void CbHeightDispDataBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var dataBits = int.Parse(cbHeightDispDataBits.Text);
            if (_dispData.Dlrs1aConfig.DataBits != dataBits)
            {
                _dispData.Dlrs1aConfig.DataBits = dataBits;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void CbHeightDispStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var stopBits = (StopBits)Enum.Parse(typeof(StopBits), cbHeightDispStopBits.Text);
            if (_dispData.Dlrs1aConfig.StopBits != stopBits)
            {
                _dispData.Dlrs1aConfig.StopBits = stopBits;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void TbHeightDispLimitH_ValueChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var height = (double)tbHeightDispLimitH.Value;
            if (_dispData.HeightDisplacementLimitH != height)
            {
                _dispData.HeightDisplacementLimitH = height;
                _rawData.HeightDisplacementLimitH = height;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }
        private void TbHeightDispLimitL_ValueChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var height = (double)tbHeightDispLimitL.Value;
            if (_dispData.HeightDisplacementLimitL != height)
            {
                _dispData.HeightDisplacementLimitL = height;
                _rawData.HeightDisplacementLimitL = height;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void BtnHeightDispReconnect_Click(object sender, EventArgs e)
        {
            _lockingMachine.Dlrs1aClose();
            _lockingMachine.Dlrs1aInit();
        }

        private void BtnUpdatePortNames_Click(object sender, EventArgs e)
        {
            _lockingMachine.UpdateComPortList();

            var com = cbHeightDispCom.Text;
            cbHeightDispCom.Items.Clear();
            if (_lmData.comPortList.Count > 0)
                cbHeightDispCom.Items.AddRange(_lmData.comPortList.ToArray());

            if (_lmData.comPortList.Contains(com))
                cbHeightDispCom.Text = com;
        }

        #endregion Height Displacement

        #region DAQ/尋邊

        private void DaqLoad()
        {
            var portCount = cbTorqueMeterPort.Items.Count;
            var channelIndex = _daqData.TorqueChannel / 2;
            if (portCount > 0 && channelIndex < portCount)
                cbTorqueMeterPort.SelectedIndex = channelIndex;
            tbTorqueLimitH.Value = (decimal)_daqData.TorqueLimitH;
            tbTorqueLimitL.Value = (decimal)_daqData.TorqueLimitL;
            cbGateMarkCylinder.Text = _daqData.GateMarkPort;
        }

        private void TbTorqueLimitH_ValueChanged(object sender, EventArgs e)
        {
            _daqData.TorqueLimitH = (double)tbTorqueLimitH.Value;
            _rawData.TorqueLimitH = _daqData.TorqueLimitH;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void TbTorqueLimitL_ValueChanged(object sender, EventArgs e)
        {
            _daqData.TorqueLimitL = (double)tbTorqueLimitL.Value;
            _rawData.TorqueLimitL = _daqData.TorqueLimitL;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void CbGateMarkCylinder_SelectedIndexChanged(object sender, EventArgs e)
        {
            _daqData.GateMarkPort = cbGateMarkCylinder.Text;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void BtnGateMarkExtend_Click(object sender, EventArgs e)
        {
            // TODO: 目前只針對USB4704，需修改支援運動控制卡
            int index = 0;
            string input = cbGateMarkCylinder.Text;
            while (index < input.Length && !char.IsDigit(input[index]))
                index++;

            string portName = input.Substring(0, index);
            byte portNumber = byte.Parse(input.Substring(index));
            _lmData.dio.WriteDigital(0, (byte)(1 << portNumber));
        }

        private void BtnGateMarkRetract_Click(object sender, EventArgs e)
        {
            _lmData.dio.WriteDigital(0, 0);
        }

        #endregion DAQ/尋邊

        #region USB4704

        private void cbTorqueMeterPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            _daqData.TorqueChannel = cbTorqueMeterPort.SelectedIndex * 2;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void numClockRate_ValueChanged(object sender, EventArgs e)
        {
            _daqData.ClockRate = (double)numClockRate.Value;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void numSectionLength_ValueChanged(object sender, EventArgs e)
        {
            _daqData.SectionLength = (int)numSectionLength.Value;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void btnUpdateUsb4704_Click(object sender, EventArgs e)
        {
            _lmData.usb4704Streaming.SetChannelStart(_daqData.TorqueChannel);
            _lmData.usb4704Streaming.SetClockRate(_daqData.ClockRate);
            _lmData.usb4704Streaming.SetSectionLength(_daqData.SectionLength);
        }

        #endregion USB4704

        private void btnHome_Click(object sender, EventArgs e)
        {
            _acm.ApplyHomeParameters(0);
            _acm.AxisHome(0);
        }

        private void cbHomeMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;

            var sIdx = cbHomeMode.SelectedIndex;
            if (sIdx >= 0 && sIdx < AcmContants.HomeModeList.Count)
            {
                _mcData.AxisConfigs[0].HomeMode = AcmContants.HomeModeList[sIdx].Id;
                _acm.SaveConfig(_mcData);
            }
        }

        private void cbHomeDir_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;

            var sIdx = cbHomeDir.SelectedIndex;
            if (sIdx >= 0 && sIdx < AcmContants.HomeDirList.Count)
            {
                _mcData.AxisConfigs[0].HomeDir = AcmContants.HomeDirList[sIdx].Id;
                _acm.SaveConfig(_mcData);
            }
        }

        private void numHomeVelL_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxHomeVelLow = (double)numHomeVelL.Value;
            _acm.SaveConfig(_mcData);
        }

        private void numHomeVelH_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxHomeVelHigh = (double)numHomeVelH.Value;
            _acm.SaveConfig(_mcData);
        }

        private void numHomeAcc_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxHomeAcc = (double)numHomeAcc.Value;
            _acm.SaveConfig(_mcData);
        }

        private void numHomeDec_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxHomeDec = (double)numHomeDec.Value;
            _acm.SaveConfig(_mcData);
        }

        private void rbHomeEzLow_CheckedChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxHomeEzLogic = (uint)(rbHomeEzLow.Checked ? EZLogic.EZ_ACT_LOW : EZLogic.EZ_ACT_HIGH);
            _acm.SaveConfig(_mcData);
        }

        private void rbHomeOrgLow_CheckedChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxHomeOrgLogic = (uint)(rbHomeOrgLow.Checked ? ORGLogic.ORG_ACT_LOW : ORGLogic.ORG_ACT_HIGH);
            _acm.SaveConfig(_mcData);
        }

        private void rbHomeHelLow_CheckedChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxHomeElLogic = (uint)(rbHomeHelLow.Checked ? EZLogic.EZ_ACT_LOW : EZLogic.EZ_ACT_HIGH);
            _acm.SaveConfig(_mcData);
        }

        private void cbHomeSwitchMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            var sIdx = cbHomeSwitchMode.SelectedIndex;
            if (sIdx >= 0 && sIdx < AcmContants.ExSwitchModeList.Count)
            {
                _mcData.AxisConfigs[0].AxHomeExSwitchMode = AcmContants.ExSwitchModeList[sIdx].Id;
                _acm.SaveConfig(_mcData);
            }
        }

        private void numHomeCrossDis_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxHomeCrossDistance = (double)numHomeCrossDis.Value;
            _acm.SaveConfig(_mcData);
        }

        private void rbTCurver_CheckedChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxJerk = (uint)(rbTCurver.Checked ? 0 : 1);
            _acm.SaveConfig(_mcData);
        }

        private void numVelL_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxVelLow = (double)numVelL.Value;
            _acm.SaveConfig(_mcData);
        }

        private void numVelH_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxVelHigh = (double)numVelH.Value;
            _acm.SaveConfig(_mcData);
        }

        private void numAcc_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxAcc = (double)numAcc.Value;
            _acm.SaveConfig(_mcData);
        }

        private void numDec_ValueChanged(object sender, EventArgs e)
        {
            if (_isLoading) return;
            _mcData.AxisConfigs[0].AxDec = (double)numDec.Value;
            _acm.SaveConfig(_mcData);
        }
    }
}