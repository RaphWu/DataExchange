﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.Navigation;
using Calin.ScrewFastening.Models;
using Calin.ScrewFastening.Services;
using Calin.UI.Extensions;

namespace Calin.ScrewFastening.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class MainPage : UserControl
    {
        #region Fields

        private readonly IScrewFastening _lockingMachine;
        private readonly RawData _rawData;
        private readonly LmData _lmData;
        private readonly MotionCardData _mcData;
        private readonly DaqData _daqData;
        private readonly Dlrs1aData _dlrs1aData;
        private readonly BindingData _bindingData;

        private readonly Color _belowColor = Color.Transparent;
        private readonly Color _betweenColor = Color.LightGreen;
        private readonly Color _aboveColor = Color.Red;

        private System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();

        // Buffers
        private double _heightDisplacementValue = double.MaxValue;
        private double _heightDisplacementMaxValue = double.MaxValue;
        private double _heightDisplacementFinalValue = double.MaxValue;
        private double _heightDisplacementLimitH = double.MaxValue;
        private double _heightDisplacementLimitL = double.MaxValue;
        private double _torqueValue = double.MaxValue;
        private double _torqueMaxValue = double.MaxValue;
        private double _torqueFinalValue = double.MaxValue;
        private double _torqueLimitH = double.MaxValue;
        private double _torqueLimitL = double.MaxValue;

        #endregion Fields

        public MainPage(
            IScrewFastening lockingMachine,
            RawData rawData,
            LmData lmData,
            MotionCardData motionCardData,
            DaqData daqData,
            Dlrs1aData dlrs1AData,
            BindingData bindingData)
        {
            _lockingMachine = lockingMachine;
            _rawData = rawData;
            _lmData = lmData;
            _mcData = motionCardData;
            _daqData = daqData;
            _dlrs1aData = dlrs1AData;
            _bindingData = bindingData;

            InitializeComponent();

            //indTorqueLimitH.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueLimitH), true);
            //indTorqueLimitL.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueLimitL), true);
            //indTorqueValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueValue), true);
            //indTorqueFinalValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueFinalValue), true);
            //indTorqueMaxValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.TorqueMaxValue), true);

            //indTorqueValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.TorqueValue),
            //    nameof(BindingData.TorqueLimitL),
            //    nameof(BindingData.TorqueLimitH),
            //    _betweenColor, _aboveColor, _belowColor);
            //indTorqueFinalValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.TorqueFinalValue),
            //    nameof(BindingData.TorqueLimitL),
            //    nameof(BindingData.TorqueLimitH),
            //    _betweenColor, _aboveColor, _belowColor);
            //indTorqueMaxValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.TorqueMaxValue),
            //    nameof(BindingData.TorqueLimitL),
            //    nameof(BindingData.TorqueLimitH),
            //    _betweenColor, _aboveColor, _belowColor);

            //indHeightDisplacementLimitH.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementLimitH), true);
            //indHeightDisplacementLimitL.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementLimitL), true);
            //indHeightDisplacementValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementValue), true);
            //indHeightDisplacementFinalValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementFinalValue), true);
            //indHeightDisplacementMaxValue.BindTextToDoubleWith3Digits(_bindingData,
            //    nameof(BindingData.HeightDisplacementMaxValue), true);

            //indHeightDisplacementValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.HeightDisplacementValue),
            //    nameof(BindingData.HeightDisplacementLimitL),
            //    nameof(BindingData.HeightDisplacementLimitH),
            //    _betweenColor, _aboveColor, _belowColor);
            //indHeightDisplacementFinalValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.HeightDisplacementFinalValue),
            //    nameof(BindingData.HeightDisplacementLimitL),
            //    nameof(BindingData.HeightDisplacementLimitH),
            //    _betweenColor, _aboveColor, _belowColor);
            //indHeightDisplacementMaxValue.BindBackColorToThresholds(_bindingData,
            //    nameof(BindingData.HeightDisplacementMaxValue),
            //    nameof(BindingData.HeightDisplacementLimitL),
            //    nameof(BindingData.HeightDisplacementLimitH),
            //    _betweenColor, _aboveColor, _belowColor);

            indHeightDisplacementValue.DataBindings.Clear();
            indHeightDisplacementValue.DataBindings.Add("ThresholdAbove", _dlrs1aData,
                nameof(Dlrs1aData.HeightDisplacementLimitH));
            indHeightDisplacementValue.DataBindings.Add("ThresholdBelow", _dlrs1aData,
                nameof(Dlrs1aData.HeightDisplacementLimitL));
            indHeightDisplacementMaxValue.DataBindings.Clear();
            indHeightDisplacementMaxValue.DataBindings.Add("ThresholdAbove", _dlrs1aData,
                nameof(Dlrs1aData.HeightDisplacementLimitH));
            indHeightDisplacementMaxValue.DataBindings.Add("ThresholdBelow", _dlrs1aData,
                nameof(Dlrs1aData.HeightDisplacementLimitL));
            indTorqueFinalValue.DataBindings.Clear();
            indTorqueFinalValue.DataBindings.Add("ThresholdAbove", _dlrs1aData,
                nameof(Dlrs1aData.HeightDisplacementLimitH));
            indTorqueFinalValue.DataBindings.Add("ThresholdBelow", _dlrs1aData,
                nameof(Dlrs1aData.HeightDisplacementLimitL));

            indTorqueValue.DataBindings.Clear();
            indTorqueValue.DataBindings.Add("ThresholdAbove", _daqData,
                nameof(DaqData.TorqueLimitH));
            indTorqueValue.DataBindings.Add("ThresholdBelow", _daqData,
                nameof(DaqData.TorqueLimitL));
            indTorqueMaxValue.DataBindings.Clear();
            indTorqueMaxValue.DataBindings.Add("ThresholdAbove", _daqData,
                nameof(DaqData.TorqueLimitH));
            indTorqueMaxValue.DataBindings.Add("ThresholdBelow", _daqData,
                nameof(DaqData.TorqueLimitL));
            indTorqueFinalValue.DataBindings.Clear();
            indTorqueFinalValue.DataBindings.Add("ThresholdAbove", _daqData,
                nameof(DaqData.TorqueLimitH));
            indTorqueFinalValue.DataBindings.Add("ThresholdBelow", _daqData,
                nameof(DaqData.TorqueLimitL));

#if DEBUG
            var indHeightDisplacementStopwatch = new Label();
            indHeightDisplacementStopwatch.Font = new Font("Consolas", 9F);
            indHeightDisplacementStopwatch.Location = new Point(7, 112);
            indHeightDisplacementStopwatch.BackColor = Color.Transparent;
            indHeightDisplacementStopwatch.BindTextToDoubleWith3Digits(_dlrs1aData,
                nameof(Dlrs1aData.HeightDisplacementStopwatch), true);
            gbHeightDisplacement.Controls.Add(indHeightDisplacementStopwatch);

            var indTorqueStopwatch = new Label();
            indTorqueStopwatch.Font = new Font("Consolas", 9F);
            indTorqueStopwatch.Location = new Point(7, 112);
            indTorqueStopwatch.BackColor = Color.Transparent;
            indTorqueStopwatch.BindTextToDoubleWith3Digits(_daqData,
                nameof(DaqData.TorqueStopwatch), true);
            gbTorqueMeter.Controls.Add(indTorqueStopwatch);
#endif

            _timer.Interval = 20;
            _timer.Tick += (async (s, e) =>
            {
                #region 作業狀態

                _bindingData.IsMeasuring = _rawData.IsMeasuring;

                #endregion 作業狀態

                #region 運動控制卡

                _mcData.ZAxisActCoor = _rawData.ZAxisCoor;
                _mcData.RPM = _rawData.RPM;
                _mcData.Angle = _rawData.Angle;

                #endregion 運動控制卡

                #region 扭力計

                _daqData.TorqueValue = _rawData.TorqueValue;
                _daqData.TorqueFinalValue = _rawData.TorqueFinalValue;
                _daqData.TorqueMaxValue = _rawData.TorqueMaxValue;
                _daqData.TorqueLimitH = _rawData.TorqueLimitH;
                _daqData.TorqueLimitL = _rawData.TorqueLimitL;

                #endregion 扭力計

                #region 高度計

                _dlrs1aData.HeightDisplacementValue = _rawData.HeightDisplacementValue;
                _dlrs1aData.HeightDisplacementFinalValue = _rawData.HeightDisplacementFinalValue;
                _dlrs1aData.HeightDisplacementMaxValue = _rawData.HeightDisplacementMaxValue;
                _dlrs1aData.HeightDisplacementLimitH = _rawData.HeightDisplacementLimitH;
                _dlrs1aData.HeightDisplacementLimitL = _rawData.HeightDisplacementLimitL;

                #endregion 高度計

                #region USB4704

                //_bindingData.DI0 = _rawData.DI0;
                //_bindingData.DI1 = _rawData.DI1;
                //_bindingData.DI2 = _rawData.DI2;
                //_bindingData.DI3 = _rawData.DI3;
                //_bindingData.DI4 = _rawData.DI4;
                //_bindingData.DI5 = _rawData.DI5;
                //_bindingData.DI6 = _rawData.DI6;
                //_bindingData.DI7 = _rawData.DI7;

                #endregion USB4704

#if DEBUG
                _dlrs1aData.HeightDisplacementStopwatch = _rawData.HeightDisplacementStopwatch;
                _daqData.TorqueStopwatch = _rawData.TorqueStopwatch;
#endif

                // HeightDisplacement
                if (_heightDisplacementLimitH != _dlrs1aData.HeightDisplacementLimitH)
                {
                    _heightDisplacementLimitH = _dlrs1aData.HeightDisplacementLimitH;
                    lbHeightDisplacementLimitH.Text = _dlrs1aData.HeightDisplacementLimitH.ToString("F3");
                }
                if (_heightDisplacementLimitL != _dlrs1aData.HeightDisplacementLimitL)
                {
                    _heightDisplacementLimitL = _dlrs1aData.HeightDisplacementLimitL;
                    lbHeightDisplacementLimitL.Text = _dlrs1aData.HeightDisplacementLimitL.ToString("F3");
                }
                if (_heightDisplacementValue != _dlrs1aData.HeightDisplacementValue)
                {
                    _heightDisplacementValue = _dlrs1aData.HeightDisplacementValue;
                    indHeightDisplacementValue.Value = _dlrs1aData.HeightDisplacementValue;

                    if (_dlrs1aData.HeightDisplacementValue > _dlrs1aData.HeightDisplacementMaxValue)
                        _dlrs1aData.HeightDisplacementMaxValue = _dlrs1aData.HeightDisplacementValue;
                    if (_bindingData.IsMeasuring && (_dlrs1aData.HeightDisplacementValue > _dlrs1aData.HeightDisplacementFinalValue))
                        _dlrs1aData.HeightDisplacementFinalValue = _dlrs1aData.HeightDisplacementValue;

                    if (_dlrs1aData.HeightDisplacementValue >= _dlrs1aData.HeightDisplacementLimitH)
                        indHeightDisplacementValue.BackColor = _aboveColor;
                    else if (_dlrs1aData.HeightDisplacementValue <= _dlrs1aData.HeightDisplacementLimitL)
                        indHeightDisplacementValue.BackColor = _belowColor;
                    else if (indHeightDisplacementValue.BackColor != _betweenColor)
                        indHeightDisplacementValue.BackColor = _betweenColor;
                }
                if (_heightDisplacementMaxValue != _dlrs1aData.HeightDisplacementMaxValue)
                {
                    _heightDisplacementMaxValue = _dlrs1aData.HeightDisplacementMaxValue;
                    indHeightDisplacementMaxValue.Value = _dlrs1aData.HeightDisplacementMaxValue;

                    if (_dlrs1aData.HeightDisplacementMaxValue >= _dlrs1aData.HeightDisplacementLimitH)
                        indHeightDisplacementMaxValue.BackColor = _aboveColor;
                    else if (_dlrs1aData.HeightDisplacementMaxValue <= _dlrs1aData.HeightDisplacementLimitL)
                        indHeightDisplacementMaxValue.BackColor = _belowColor;
                    else if (indHeightDisplacementMaxValue.BackColor != _betweenColor)
                        indHeightDisplacementMaxValue.BackColor = _betweenColor;
                }
                if (_heightDisplacementFinalValue != _dlrs1aData.HeightDisplacementFinalValue)
                {
                    _heightDisplacementFinalValue = _dlrs1aData.HeightDisplacementFinalValue;
                    indHeightDisplacementFinalValue.Value = _dlrs1aData.HeightDisplacementFinalValue;

                    if (_dlrs1aData.HeightDisplacementFinalValue >= _dlrs1aData.HeightDisplacementLimitH)
                        indHeightDisplacementFinalValue.BackColor = _aboveColor;
                    else if (_dlrs1aData.HeightDisplacementFinalValue <= _dlrs1aData.HeightDisplacementLimitL)
                        indHeightDisplacementFinalValue.BackColor = _belowColor;
                    else if (indHeightDisplacementFinalValue.BackColor != _betweenColor)
                        indHeightDisplacementFinalValue.BackColor = _betweenColor;
                }

                // Torque
                if (_torqueLimitH != _daqData.TorqueLimitH)
                {
                    _torqueLimitH = _daqData.TorqueLimitH;
                    lbTorqueLimitH.Text = _daqData.TorqueLimitH.ToString("F3");
                }
                if (_torqueLimitL != _daqData.TorqueLimitL)
                {
                    _torqueLimitL = _daqData.TorqueLimitL;
                    lbTorqueLimitL.Text = _daqData.TorqueLimitL.ToString("F3");
                }
                if (_torqueValue != _daqData.TorqueValue)
                {
                    _torqueValue = _daqData.TorqueValue;
                    indTorqueValue.Value = _daqData.TorqueValue;

                    if (_daqData.TorqueValue > _daqData.TorqueMaxValue)
                        _daqData.TorqueMaxValue = _daqData.TorqueValue;
                    if (_bindingData.IsMeasuring && (_daqData.TorqueValue > _daqData.TorqueFinalValue))
                        _daqData.TorqueFinalValue = _daqData.TorqueValue;

                    if (_daqData.TorqueValue >= _daqData.TorqueLimitH)
                        indTorqueValue.BackColor = _aboveColor;
                    else if (_daqData.TorqueValue <= _daqData.TorqueLimitL)
                        indTorqueValue.BackColor = _belowColor;
                    else if (indTorqueValue.BackColor != _betweenColor)
                        indTorqueValue.BackColor = _betweenColor;
                }
                if (_torqueMaxValue != _daqData.TorqueMaxValue)
                {
                    _torqueMaxValue = _daqData.TorqueMaxValue;
                    indTorqueMaxValue.Value = _daqData.TorqueMaxValue;

                    if (_daqData.TorqueMaxValue >= _daqData.TorqueLimitH)
                        indTorqueMaxValue.BackColor = _aboveColor;
                    else if (_daqData.TorqueMaxValue <= _daqData.TorqueLimitL)
                        indTorqueMaxValue.BackColor = _belowColor;
                    else if (indTorqueMaxValue.BackColor != _betweenColor)
                        indTorqueMaxValue.BackColor = _betweenColor;
                }
                if (_torqueFinalValue != _daqData.TorqueFinalValue)
                {
                    _torqueFinalValue = _daqData.TorqueFinalValue;
                    indTorqueFinalValue.Value = _daqData.TorqueFinalValue;

                    if (_daqData.TorqueFinalValue >= _daqData.TorqueLimitH)
                        indTorqueFinalValue.BackColor = _aboveColor;
                    else if (_daqData.TorqueFinalValue <= _daqData.TorqueLimitL)
                        indTorqueFinalValue.BackColor = _belowColor;
                    else if (indTorqueFinalValue.BackColor != _betweenColor)
                        indTorqueFinalValue.BackColor = _betweenColor;
                }

#if DEBUG
                indHeightDisplacementStopwatch.Text = _dlrs1aData.HeightDisplacementStopwatch.ToString("F3");
                indTorqueStopwatch.Text = _daqData.TorqueStopwatch.ToString("F3");

                //var indTorqueStopwatch = new Label();
                //indTorqueStopwatch.Font = new Font("Consolas", 9F);
                //indTorqueStopwatch.Location = new Point(7, 121);
                //indTorqueStopwatch.BackColor = Color.Transparent;
                //indTorqueStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                //    nameof(BindingData.TorqueStopwatch), true);
                //gbTorqueMeter.Controls.Add(indTorqueStopwatch);
#endif

                await Task.CompletedTask;
            });
            _timer.Start();
        }

        private void cbIsMeasuring_Click(object sender, EventArgs e)
        {
            //var check = !cbIsMeasuring.Checked;
            //cbIsMeasuring.Checked = check;
            _rawData.IsMeasuring = cbIsMeasuring.Checked;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            _lockingMachine.ClearMeasureData();
        }

        private void btnTest1_Click(object sender, EventArgs e)
        {
            _lockingMachine.DaqStartAcquisition();
        }

        private void btnTest2_Click(object sender, EventArgs e)
        {
            _lockingMachine.DaqStopAcquisition();
        }
    }
}
