﻿using System.Windows.Forms;

namespace Calin.ScrewFastening.Views
{
    public partial class ManualPage : UserControl
    {
        public ManualPage()
        {
            InitializeComponent();
        }
    }
}
