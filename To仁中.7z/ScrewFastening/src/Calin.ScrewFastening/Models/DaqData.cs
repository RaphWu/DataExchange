﻿using Calin.MVVM;

namespace Calin.ScrewFastening.Models
{
    /// <summary>
    /// 資料擷取裝置 (DAQ) 資料模型。
    /// </summary>
    /// <remarks>DAQ設定，會儲存成 .JSON 檔。</remarks>
    public class DaqData : ObservableObject
    {
        #region USB4704 設定

        public string DeviceCode { get; set; } = "USB-4704,BID#0";

        /// <summary>
        /// 
        /// </summary>
        public double ClockRate
        {
            get { return _clockRate; }
            set { SetProperty(ref _clockRate, value); }
        }
        private double _clockRate = 1000.0;

        /// <summary>
        /// 
        /// </summary>
        public int SectionLength
        {
            get { return _sectionLength; }
            set { SetProperty(ref _sectionLength, value); }
        }
        private int _sectionLength = 256;

        #endregion USB4704 設定

        #region 扭力計

        /// <summary>
        /// 扭力計是否啟用。
        /// </summary>
        public bool TorqueMeterActive
        {
            get { return _torqueMeterActive; }
            set { SetProperty(ref _torqueMeterActive, value); }
        }
        private bool _torqueMeterActive = false;

        /// <summary>
        /// 
        /// </summary>
        public int TorqueChannel
        {
            get { return _torqueChannel; }
            set { SetProperty(ref _torqueChannel, value); }
        }
        private int _torqueChannel = 0;

        /// <summary>
        /// 扭力計讀數。
        /// </summary>
        public double TorqueValue
        {
            get { return _torqueValue; }
            set { SetProperty(ref _torqueValue, value); }
        }
        private double _torqueValue;
        public double TorqueValue1;

        /// <summary>
        /// 扭力計最終值。
        /// </summary>
        public double TorqueFinalValue
        {
            get { return _torqueFinalValue; }
            set { SetProperty(ref _torqueFinalValue, value); }
        }
        private double _torqueFinalValue;

        /// <summary>
        /// 扭力計最大值。
        /// </summary>
        public double TorqueMaxValue
        {
            get { return _torqueMaxValue; }
            set { SetProperty(ref _torqueMaxValue, value); }
        }
        private double _torqueMaxValue;

        /// <summary>
        /// 扭力計上限值。
        /// </summary>
        public double TorqueLimitH
        {
            get { return _torqueLimitH; }
            set { SetProperty(ref _torqueLimitH, value); }
        }
        private double _torqueLimitH = 20.0;

        /// <summary>
        /// 扭力計下限值。
        /// </summary>
        public double TorqueLimitL
        {
            get { return _torqueLimitL; }
            set { SetProperty(ref _torqueLimitL, value); }
        }
        private double _torqueLimitL = 10.0;

        #endregion 扭力計

        #region 尋邊

        /// <summary>
        /// 
        /// </summary>
        public string GateMarkPort
        {
            get { return _gateMarkPort; }
            set { SetProperty(ref _gateMarkPort, value); }
        }
        private string _gateMarkPort = "DO0";

        /// <summary>
        /// 補償角度。
        /// </summary>
        public double AngleCompensation
        {
            get { return _angleCompensation; }
            set { SetProperty(ref _angleCompensation, value); }
        }
        private double _angleCompensation = 0.0;

        #endregion 尋邊

#if DEBUG
        /// <summary>
        /// 扭力計碼表讀取時間。
        /// </summary>
        public double TorqueStopwatch
        {
            get { return _torqueStopwatch; }
            set { SetProperty(ref _torqueStopwatch, value); }
        }
        private double _torqueStopwatch;

        public bool WaitForRecevieTorque = false;
#endif
    }
}
