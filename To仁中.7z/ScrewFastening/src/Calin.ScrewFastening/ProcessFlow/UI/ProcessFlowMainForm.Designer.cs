namespace Calin.ScrewFastening.ProcessFlow.UI
{
    partial class ProcessFlowMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.ToolStrip _toolStrip;
        private System.Windows.Forms.ToolStripButton _btnNew;
        private System.Windows.Forms.ToolStripButton _btnOpen;
        private System.Windows.Forms.ToolStripButton _btnSave;
        private System.Windows.Forms.ToolStripSeparator _separator1;
        private System.Windows.Forms.ToolStripButton _btnValidate;
        private System.Windows.Forms.StatusStrip _statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel _lblStatus;
        private System.Windows.Forms.ToolStripProgressBar _progressBar;
        private ProcessFlowEditorView _editorView;

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._toolStrip = new System.Windows.Forms.ToolStrip();
            this._btnNew = new System.Windows.Forms.ToolStripButton();
            this._btnOpen = new System.Windows.Forms.ToolStripButton();
            this._btnSave = new System.Windows.Forms.ToolStripButton();
            this._separator1 = new System.Windows.Forms.ToolStripSeparator();
            this._btnValidate = new System.Windows.Forms.ToolStripButton();
            this._statusStrip = new System.Windows.Forms.StatusStrip();
            this._lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this._progressBar = new System.Windows.Forms.ToolStripProgressBar();
            this._editorView = new Calin.ScrewFastening.ProcessFlow.UI.ProcessFlowEditorView();
            this._toolStrip.SuspendLayout();
            this._statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // _toolStrip
            // 
            this._toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._btnNew,
            this._btnOpen,
            this._btnSave,
            this._separator1,
            this._btnValidate});
            this._toolStrip.Location = new System.Drawing.Point(0, 0);
            this._toolStrip.Name = "_toolStrip";
            this._toolStrip.Size = new System.Drawing.Size(800, 25);
            this._toolStrip.TabIndex = 0;
            // 
            // _btnNew
            // 
            this._btnNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._btnNew.Name = "_btnNew";
            this._btnNew.Size = new System.Drawing.Size(71, 22);
            this._btnNew.Text = "�إ߷s�y�{";
            this._btnNew.Click += new System.EventHandler(this.BtnNew_Click);
            // 
            // _btnOpen
            // 
            this._btnOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._btnOpen.Name = "_btnOpen";
            this._btnOpen.Size = new System.Drawing.Size(83, 22);
            this._btnOpen.Text = "�}�Ҭy�{�ɮ�";
            this._btnOpen.Click += new System.EventHandler(this.BtnOpen_Click);
            // 
            // _btnSave
            // 
            this._btnSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._btnSave.Name = "_btnSave";
            this._btnSave.Size = new System.Drawing.Size(83, 22);
            this._btnSave.Text = "�x�s�y�{�ɮ�";
            this._btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // _separator1
            // 
            this._separator1.Name = "_separator1";
            this._separator1.Size = new System.Drawing.Size(6, 25);
            // 
            // _btnValidate
            // 
            this._btnValidate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this._btnValidate.Name = "_btnValidate";
            this._btnValidate.Size = new System.Drawing.Size(71, 22);
            this._btnValidate.Text = "���Ҭy�{";
            this._btnValidate.Click += new System.EventHandler(this.BtnValidate_Click);
            // 
            // _statusStrip
            // 
            this._statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._lblStatus,
            this._progressBar});
            this._statusStrip.Location = new System.Drawing.Point(0, 428);
            this._statusStrip.Name = "_statusStrip";
            this._statusStrip.Size = new System.Drawing.Size(800, 22);
            this._statusStrip.TabIndex = 1;
            // 
            // _lblStatus
            // 
            this._lblStatus.Name = "_lblStatus";
            this._lblStatus.Size = new System.Drawing.Size(585, 17);
            this._lblStatus.Spring = true;
            this._lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // _progressBar
            // 
            this._progressBar.Name = "_progressBar";
            this._progressBar.Size = new System.Drawing.Size(200, 16);
            this._progressBar.Visible = false;
            // 
            // _editorView
            // 
            this._editorView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._editorView.Location = new System.Drawing.Point(0, 25);
            this._editorView.Name = "_editorView";
            this._editorView.Size = new System.Drawing.Size(800, 403);
            this._editorView.TabIndex = 2;
            // 
            // ProcessFlowMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._editorView);
            this.Controls.Add(this._toolStrip);
            this.Controls.Add(this._statusStrip);
            this.Name = "ProcessFlowMainForm";
            this.Size = new System.Drawing.Size(800, 450);
            this._toolStrip.ResumeLayout(false);
            this._toolStrip.PerformLayout();
            this._statusStrip.ResumeLayout(false);
            this._statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}
