using System;
using System.Collections.Generic;
using System.Linq;
using Calin.ScrewFastening.ProcessFlow.Core;

namespace Calin.ScrewFastening.ProcessFlow.Registry
{
    /// <summary>
    /// �u�ǵ��U����@�C
    /// </summary>
    public class ProcessRegistry : IProcessRegistry
    {
        private readonly Dictionary<string, ProcessDescriptor> _descriptors
            = new Dictionary<string, ProcessDescriptor>(StringComparer.OrdinalIgnoreCase);

        /// <inheritdoc />
        public void Register(ProcessDescriptor descriptor)
        {
            if (descriptor == null)
                throw new ArgumentNullException(nameof(descriptor));

            if (string.IsNullOrEmpty(descriptor.ProcessId))
                throw new ArgumentException("ProcessId ���i����", nameof(descriptor));

            _descriptors[descriptor.ProcessId] = descriptor;
        }

        /// <inheritdoc />
        public IReadOnlyList<ProcessDescriptor> GetAll()
        {
            return _descriptors.Values.ToList().AsReadOnly();
        }

        /// <inheritdoc />
        public ProcessDescriptor GetById(string processId)
        {
            if (string.IsNullOrEmpty(processId))
                return null;

            _descriptors.TryGetValue(processId, out var descriptor);
            return descriptor;
        }

        /// <inheritdoc />
        public bool Contains(string processId)
        {
            if (string.IsNullOrEmpty(processId))
                return false;

            return _descriptors.ContainsKey(processId);
        }
    }
}
