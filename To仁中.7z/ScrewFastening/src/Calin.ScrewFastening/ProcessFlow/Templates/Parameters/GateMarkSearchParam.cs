﻿namespace Calin.ScrewFastening.ProcessFlow.Templates.Parameters
{
    /// <summary>
    /// 尋邊參數。
    /// </summary>
    public class GateMarkSearchParam
    {
        /// <summary>
        /// 補正角度。
        /// </summary>
        public double AngleCompensation { get; set; } = 0.0;

        /// <summary>
        /// 尋邊嘗試次數。
        /// </summary>
        public int SearchAttempts { get; set; } = 3;

        /// <summary>
        /// 超時時間（毫秒）。
        /// </summary>
        public int TimeoutMilliseconds { get; set; } = 5000;
    }
}
