﻿using System.Windows.Forms;
using Calin.ScrewFastening.ProcessFlow.Editor;
using Calin.ScrewFastening.ProcessFlow.Engine;
using Calin.ScrewFastening.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.ScrewFastening.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// 高度計讀取與範圍判斷工序參數編輯器。
    /// </summary>
    public partial class HeightDisplacementEditor : ProcessEditorBase
    {
        public override string ProcessId => ProcessIds.HEIGHT_DISPLACEMENT;

        public HeightDisplacementEditor()
        {
            InitializeComponent();

            // 下拉選單項目
            cmbInRangeAction.Items.Clear();
            cmbInRangeAction.Items.AddRange(new object[]
            {
                new ActionItem(SensorCheckAction.None, "無動作"),
                new ActionItem(SensorCheckAction.Continue, "繼續流程"),
                new ActionItem(SensorCheckAction.StopFlow, "停止流程"),
                new ActionItem(SensorCheckAction.TriggerAlarm, "觸發警報")
            });
            cmbInRangeAction.DisplayMember = "DisplayName";

            cmbOutOfRangeAction.Items.Clear();
            cmbOutOfRangeAction.Items.AddRange(new object[]
            {
                new ActionItem(SensorCheckAction.None, "無動作"),
                new ActionItem(SensorCheckAction.Continue, "繼續流程"),
                new ActionItem(SensorCheckAction.StopFlow, "停止流程"),
                new ActionItem(SensorCheckAction.TriggerAlarm, "觸發警報")
            });
            cmbOutOfRangeAction.DisplayMember = "DisplayName";

            // 事件繫結
            numMinValue.ValueChanged += (s, e) => OnParamChanged();
            numMaxValue.ValueChanged += (s, e) => OnParamChanged();
            cmbInRangeAction.SelectedIndexChanged += (s, e) => OnParamChanged();
            cmbOutOfRangeAction.SelectedIndexChanged += (s, e) => OnParamChanged();

            if (cmbInRangeAction.Items.Count > 0 && cmbInRangeAction.SelectedIndex < 0)
                cmbInRangeAction.SelectedIndex = 0;
            if (cmbOutOfRangeAction.Items.Count > 0 && cmbOutOfRangeAction.SelectedIndex < 0)
                cmbOutOfRangeAction.SelectedIndex = 0;
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new HeightDisplacementParam()
                : JsonConvert.DeserializeObject<HeightDisplacementParam>(paramJson) ?? new HeightDisplacementParam();

            numMinValue.Value = (decimal)param.MinValue;
            numMaxValue.Value = (decimal)param.MaxValue;

            SelectActionItem(cmbInRangeAction, param.InRangeAction);
            SelectActionItem(cmbOutOfRangeAction, param.OutOfRangeAction);
        }

        public override string Save()
        {
            var param = new HeightDisplacementParam
            {
                MinValue = (double)numMinValue.Value,
                MaxValue = (double)numMaxValue.Value,
                InRangeAction = GetSelectedAction(cmbInRangeAction),
                OutOfRangeAction = GetSelectedAction(cmbOutOfRangeAction)
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (numMinValue.Value > numMaxValue.Value)
                return "最小值不可大於最大值";

            return null;
        }

        private void SelectActionItem(ComboBox comboBox, SensorCheckAction action)
        {
            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                if (comboBox.Items[i] is ActionItem item && item.Action == action)
                {
                    comboBox.SelectedIndex = i;
                    return;
                }
            }
            if (comboBox.Items.Count > 0)
                comboBox.SelectedIndex = 0;
        }

        private SensorCheckAction GetSelectedAction(ComboBox comboBox)
        {
            return (comboBox.SelectedItem as ActionItem)?.Action ?? SensorCheckAction.None;
        }

        private class ActionItem
        {
            public SensorCheckAction Action { get; }
            public string DisplayName { get; }

            public ActionItem(SensorCheckAction action, string displayName)
            {
                Action = action;
                DisplayName = displayName;
            }

            public override string ToString() => DisplayName;
        }
    }
}
