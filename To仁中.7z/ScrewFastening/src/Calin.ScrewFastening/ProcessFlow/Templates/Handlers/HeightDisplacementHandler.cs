using System;
using System.Threading;
using System.Threading.Tasks;
using Calin.ScrewFastening.ProcessFlow.Engine;
using Calin.ScrewFastening.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.ScrewFastening.ProcessFlow.Templates.Handlers
{
    /// <summary>
    /// ���׭pŪ���P�d��P�_�u�ǳB�z���C
    /// </summary>
    public class HeightDisplacementHandler : IProcessHandler
    {
        public async Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken cancellationToken)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<HeightDisplacementParam>(paramJson);
                if (param == null)
                    return ProcessExecutionResult.Failed("�ѼƸѪR����");

                // �������׭pŪ���]������Τ����I�s���׭p API�^
                await Task.Delay(100, cancellationToken);

                // �������׭p�ȡ]������Τ����q�w��Ū���^
                var random = new Random();
                var sensorValue = param.MinValue + random.NextDouble() * (param.MaxValue - param.MinValue + 20) - 10;

                var isInRange = sensorValue >= param.MinValue && sensorValue <= param.MaxValue;
                var action = isInRange ? param.InRangeAction : param.OutOfRangeAction;

                switch (action)
                {
                    case SensorCheckAction.Continue:
                        return ProcessExecutionResult.Succeeded();

                    case SensorCheckAction.StopFlow:
                        return ProcessExecutionResult.Failed($"���׭p {param.SensorId} �� {sensorValue:F2} Ĳ�o����y�{");

                    case SensorCheckAction.TriggerAlarm:
                        // ������Τ���Ĳ�oĵ���t��
                        return ProcessExecutionResult.Failed($"���׭p {param.SensorId} �� {sensorValue:F2} Ĳ�oĵ��");

                    case SensorCheckAction.None:
                    default:
                        return ProcessExecutionResult.Succeeded();
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                return ProcessExecutionResult.Failed(ex);
            }
        }

        public string ValidateParam(string paramJson)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<HeightDisplacementParam>(paramJson);
                if (param == null)
                    return "�ѼƤ��i����";

                if (string.IsNullOrEmpty(param.SensorId))
                    return "���׭p�ѧO�X���i����";

                if (param.MinValue > param.MaxValue)
                    return "�̤p�Ȥ��i�j��̤j��";

                return null;
            }
            catch (Exception ex)
            {
                return $"�ѼƮ榡���~: {ex.Message}";
            }
        }
    }
}
