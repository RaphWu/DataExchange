﻿namespace Calin.ScrewFastening.Services
{
    public interface IScrewFastening : IScrewFastening_Dlrs1a, IScrewFastening_DAQ
    {
        /// <summary>
        /// 清除量測資料。
        /// </summary>
        void ClearMeasureData();

        /// <summary>
        /// 取得系統可用的 COM 埠清單。
        /// </summary>
        void UpdateComPortList();
    }
}
