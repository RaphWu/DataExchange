﻿using Autofac;
using Calin.UI.Dialog;

namespace Calin.UI
{
    public class FormsModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule<DialogModule>();
            builder.RegisterType<LoadingDialog>().ExternallyOwned();
        }
    }
}
