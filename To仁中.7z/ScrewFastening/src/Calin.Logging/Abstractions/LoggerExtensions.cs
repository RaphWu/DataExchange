// ===================================================================
// Calin.Logging.Abstractions
// 
// Logger �X�R��k - �]�Ƭ������K�Q��k
// ===================================================================

using System;
using Microsoft.Extensions.Logging;

namespace Calin.Logging.Abstractions
{
    /// <summary>
    /// ILogger �X�R��k�A���ѳ]�Ƭ������K�Q Log ��k�C
    /// </summary>
    public static class LoggerExtensions
    {
        /// <summary>
        /// �O���]�ƾާ@�}�l�C
        /// </summary>
        /// <param name="logger">Logger ��ҡC</param>
        /// <param name="operationName">�ާ@�W�١C</param>
        /// <param name="deviceId">�]�� ID�C</param>
        public static void LogDeviceOperationStart(
            this ILogger logger,
            string operationName,
            string deviceId)
        {
            logger.LogInformation(
                "�]�ƾާ@�}�l | Operation: {OperationName}, DeviceId: {DeviceId}",
                operationName,
                deviceId);
        }

        /// <summary>
        /// �O���]�ƾާ@�����C
        /// </summary>
        /// <param name="logger">Logger ��ҡC</param>
        /// <param name="operationName">�ާ@�W�١C</param>
        /// <param name="deviceId">�]�� ID�C</param>
        /// <param name="elapsedMs">�Ӯɡ]�@���^�C</param>
        public static void LogDeviceOperationComplete(
            this ILogger logger,
            string operationName,
            string deviceId,
            long elapsedMs)
        {
            logger.LogInformation(
                "�]�ƾާ@���� | Operation: {OperationName}, DeviceId: {DeviceId}, ElapsedMs: {ElapsedMs}",
                operationName,
                deviceId,
                elapsedMs);
        }

        /// <summary>
        /// �O���]�ƾާ@���ѡC
        /// </summary>
        /// <param name="logger">Logger ��ҡC</param>
        /// <param name="operationName">�ާ@�W�١C</param>
        /// <param name="deviceId">�]�� ID�C</param>
        /// <param name="exception">�ҥ~�C</param>
        public static void LogDeviceOperationFailed(
            this ILogger logger,
            string operationName,
            string deviceId,
            Exception exception)
        {
            logger.LogError(
                exception,
                "�]�ƾާ@���� | Operation: {OperationName}, DeviceId: {DeviceId}",
                operationName,
                deviceId);
        }

        /// <summary>
        /// �O���]�Ƴs�u���A�ܧ�C
        /// </summary>
        /// <param name="logger">Logger ��ҡC</param>
        /// <param name="deviceId">�]�� ID�C</param>
        /// <param name="isConnected">�O�_�w�s�u�C</param>
        /// <param name="portName">�s����W�١]�i��^�C</param>
        public static void LogDeviceConnectionChanged(
            this ILogger logger,
            string deviceId,
            bool isConnected,
            string portName = null)
        {
            if (isConnected)
            {
                logger.LogInformation(
                    "�]�Ƥw�s�u | DeviceId: {DeviceId}, PortName: {PortName}",
                    deviceId,
                    portName ?? "N/A");
            }
            else
            {
                logger.LogWarning(
                    "�]�Ƥw�_�u | DeviceId: {DeviceId}, PortName: {PortName}",
                    deviceId,
                    portName ?? "N/A");
            }
        }

        /// <summary>
        /// �O���]�Ƴq�T��ơ]Debug �h�š^�C
        /// </summary>
        /// <param name="logger">Logger ��ҡC</param>
        /// <param name="direction">��V�]Send/Receive�^�C</param>
        /// <param name="deviceId">�]�� ID�C</param>
        /// <param name="data">��Ƥ��e�C</param>
        public static void LogDeviceCommunication(
            this ILogger logger,
            string direction,
            string deviceId,
            string data)
        {
            logger.LogDebug(
                "�]�Ƴq�T | Direction: {Direction}, DeviceId: {DeviceId}, Data: {Data}",
                direction,
                deviceId,
                data);
        }
    }
}
