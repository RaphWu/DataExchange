﻿using Calin.DAQ.USB4704;
using Calin.Abstractions.Logging;
using Calin.Extensions;
using Automation.BDaq;

namespace T22Demo
{
    public partial class Form1 : Form
    {
        private readonly ICalinLogger _logger;
        private readonly IUsb4704Dio _usb4704Dio;
        private readonly IUsb4704Instant _usb4704Instant;

        private readonly System.Windows.Forms.Timer _dioTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _instantTimer = new System.Windows.Forms.Timer();

        private byte portAValue;
        private byte portBValue;
        private byte outPortValue = 0x00;

        public Form1(ICalinLogger calinLogger, IUsb4704Dio usb4704Dio, IUsb4704Instant usb4704Instant)
        {
            _logger = calinLogger;
            _usb4704Dio = usb4704Dio;
            _usb4704Instant = usb4704Instant;

            _usb4704Dio.Usb4704DioInit("USB-4704,BID#0");
            _usb4704Instant.Usb4704InstantInit("USB-4704,BID#0");

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int pbId = 0; pbId < 8; pbId++)
            {
                var ctl = this.Controls.Find($"out{pbId:X2}", true).FirstOrDefault();
                ctl.Click += new EventHandler(out_Click);
            }
            _usb4704Dio.WriteDigital(0, outPortValue);

            _dioTimer.Tick += Timer_Tick;
            _dioTimer.Interval = 200;
            //_timer.Start();
        }

        private System.Drawing.Color _onColor = System.Drawing.Color.Gold;
        private System.Drawing.Color _offColor = System.Drawing.Color.Transparent;

        private void Timer_Tick(object sender, EventArgs e)
        {
            var err0 = _usb4704Dio.ReadDigital(0, out portAValue);
            var err1 = _usb4704Dio.ReadDigital(1, out portBValue);

            pb00.BackColor = (portAValue & 0x01) != 0 ? _onColor : _offColor;
            pb01.BackColor = (portAValue & 0x02) != 0 ? _onColor : _offColor;
            pb02.BackColor = (portAValue & 0x04) != 0 ? _onColor : _offColor;
            pb03.BackColor = (portAValue & 0x08) != 0 ? _onColor : _offColor;
            pb04.BackColor = (portAValue & 0x11) != 0 ? _onColor : _offColor;
            pb05.BackColor = (portAValue & 0x12) != 0 ? _onColor : _offColor;
            pb06.BackColor = (portAValue & 0x14) != 0 ? _onColor : _offColor;
            pb07.BackColor = (portAValue & 0x18) != 0 ? _onColor : _offColor;

            pb10.BackColor = (portBValue & 0x01) != 0 ? _onColor : _offColor;
            pb11.BackColor = (portBValue & 0x02) != 0 ? _onColor : _offColor;
            pb12.BackColor = (portBValue & 0x04) != 0 ? _onColor : _offColor;
            pb13.BackColor = (portBValue & 0x08) != 0 ? _onColor : _offColor;
            pb14.BackColor = (portBValue & 0x11) != 0 ? _onColor : _offColor;
            pb15.BackColor = (portBValue & 0x12) != 0 ? _onColor : _offColor;
            pb16.BackColor = (portBValue & 0x14) != 0 ? _onColor : _offColor;
            pb17.BackColor = (portBValue & 0x18) != 0 ? _onColor : _offColor;
        }

        private void out_Click(object sender, EventArgs e)
        {
            string pbName = ((PictureBox)sender).Name;
            byte pbId = byte.Parse(pbName.Substring(3), System.Globalization.NumberStyles.HexNumber);
            byte mask = (byte)(0x01 << pbId);
            outPortValue = (byte)(outPortValue ^ mask);
            _usb4704Dio.WriteDigital(0, outPortValue);
            ((PictureBox)sender).BackColor = (outPortValue & mask) != 0 ? _onColor : _offColor;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _instantTimer.Interval = 20;
            _instantTimer.Tick += ((s, e) =>
            {
                var err = _usb4704Instant.ReadInstantData(0, out double instantData);
                if (err == ErrorCode.Success)
                    ThreadExt.RunOnUiThread(() => { label1.Text = instantData.ToString("F3"); });
                else
                    _instantTimer.Stop();
            });
            _instantTimer.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _instantTimer.Stop();
        }
    }
}
