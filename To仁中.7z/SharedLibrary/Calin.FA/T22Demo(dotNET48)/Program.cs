using Autofac;
using Calin.Abstractions;
using Calin.Abstractions.Logging;
using Calin.DAQ.USB4704;

namespace T22Demo
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var builder = new ContainerBuilder();
            builder.RegisterModule<AbstractionsModule>();
            builder.RegisterModule<Usb4704Module>();
            var container = builder.Build();

            var logger = container.Resolve<ICalinLogger>();
            var usb4704Dio = container.Resolve<IUsb4704Dio>();
            var usb4704Instant = container.Resolve<IUsb4704Instant>();

            // Pass the resolved dependency to the Form1 constructor
            Application.Run(new Form1(logger, usb4704Dio, usb4704Instant));
        }
    }
}