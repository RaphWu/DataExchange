﻿namespace T22Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pb07 = new System.Windows.Forms.PictureBox();
            this.PortHex0 = new System.Windows.Forms.Label();
            this.PortNum0 = new System.Windows.Forms.Label();
            this.pb06 = new System.Windows.Forms.PictureBox();
            this.pb04 = new System.Windows.Forms.PictureBox();
            this.pb05 = new System.Windows.Forms.PictureBox();
            this.pb00 = new System.Windows.Forms.PictureBox();
            this.pb01 = new System.Windows.Forms.PictureBox();
            this.pb02 = new System.Windows.Forms.PictureBox();
            this.pb03 = new System.Windows.Forms.PictureBox();
            this.pb10 = new System.Windows.Forms.PictureBox();
            this.pb11 = new System.Windows.Forms.PictureBox();
            this.pb12 = new System.Windows.Forms.PictureBox();
            this.pb13 = new System.Windows.Forms.PictureBox();
            this.pb14 = new System.Windows.Forms.PictureBox();
            this.pb15 = new System.Windows.Forms.PictureBox();
            this.pb16 = new System.Windows.Forms.PictureBox();
            this.PortHex1 = new System.Windows.Forms.Label();
            this.PortNum1 = new System.Windows.Forms.Label();
            this.pb17 = new System.Windows.Forms.PictureBox();
            this.out00 = new System.Windows.Forms.PictureBox();
            this.out01 = new System.Windows.Forms.PictureBox();
            this.out02 = new System.Windows.Forms.PictureBox();
            this.out03 = new System.Windows.Forms.PictureBox();
            this.out04 = new System.Windows.Forms.PictureBox();
            this.out05 = new System.Windows.Forms.PictureBox();
            this.out06 = new System.Windows.Forms.PictureBox();
            this.out07 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pb07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.out00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.out01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.out02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.out03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.out04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.out05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.out06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.out07)).BeginInit();
            this.SuspendLayout();
            // 
            // pb07
            // 
            this.pb07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb07.Location = new System.Drawing.Point(53, 23);
            this.pb07.Name = "pb07";
            this.pb07.Size = new System.Drawing.Size(24, 24);
            this.pb07.TabIndex = 1;
            this.pb07.TabStop = false;
            // 
            // PortHex0
            // 
            this.PortHex0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PortHex0.Location = new System.Drawing.Point(272, 23);
            this.PortHex0.Name = "PortHex0";
            this.PortHex0.Size = new System.Drawing.Size(24, 24);
            this.PortHex0.TabIndex = 5;
            this.PortHex0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PortNum0
            // 
            this.PortNum0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PortNum0.Location = new System.Drawing.Point(23, 23);
            this.PortNum0.Name = "PortNum0";
            this.PortNum0.Size = new System.Drawing.Size(24, 24);
            this.PortNum0.TabIndex = 4;
            this.PortNum0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb06
            // 
            this.pb06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb06.Location = new System.Drawing.Point(80, 23);
            this.pb06.Name = "pb06";
            this.pb06.Size = new System.Drawing.Size(24, 24);
            this.pb06.TabIndex = 6;
            this.pb06.TabStop = false;
            // 
            // pb04
            // 
            this.pb04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb04.Location = new System.Drawing.Point(134, 23);
            this.pb04.Name = "pb04";
            this.pb04.Size = new System.Drawing.Size(24, 24);
            this.pb04.TabIndex = 8;
            this.pb04.TabStop = false;
            // 
            // pb05
            // 
            this.pb05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb05.Location = new System.Drawing.Point(107, 23);
            this.pb05.Name = "pb05";
            this.pb05.Size = new System.Drawing.Size(24, 24);
            this.pb05.TabIndex = 7;
            this.pb05.TabStop = false;
            // 
            // pb00
            // 
            this.pb00.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb00.Location = new System.Drawing.Point(242, 23);
            this.pb00.Name = "pb00";
            this.pb00.Size = new System.Drawing.Size(24, 24);
            this.pb00.TabIndex = 12;
            this.pb00.TabStop = false;
            // 
            // pb01
            // 
            this.pb01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb01.Location = new System.Drawing.Point(215, 23);
            this.pb01.Name = "pb01";
            this.pb01.Size = new System.Drawing.Size(24, 24);
            this.pb01.TabIndex = 11;
            this.pb01.TabStop = false;
            // 
            // pb02
            // 
            this.pb02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb02.Location = new System.Drawing.Point(188, 23);
            this.pb02.Name = "pb02";
            this.pb02.Size = new System.Drawing.Size(24, 24);
            this.pb02.TabIndex = 10;
            this.pb02.TabStop = false;
            // 
            // pb03
            // 
            this.pb03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb03.Location = new System.Drawing.Point(161, 23);
            this.pb03.Name = "pb03";
            this.pb03.Size = new System.Drawing.Size(24, 24);
            this.pb03.TabIndex = 9;
            this.pb03.TabStop = false;
            // 
            // pb10
            // 
            this.pb10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb10.Location = new System.Drawing.Point(242, 53);
            this.pb10.Name = "pb10";
            this.pb10.Size = new System.Drawing.Size(24, 24);
            this.pb10.TabIndex = 22;
            this.pb10.TabStop = false;
            // 
            // pb11
            // 
            this.pb11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb11.Location = new System.Drawing.Point(215, 53);
            this.pb11.Name = "pb11";
            this.pb11.Size = new System.Drawing.Size(24, 24);
            this.pb11.TabIndex = 21;
            this.pb11.TabStop = false;
            // 
            // pb12
            // 
            this.pb12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb12.Location = new System.Drawing.Point(188, 53);
            this.pb12.Name = "pb12";
            this.pb12.Size = new System.Drawing.Size(24, 24);
            this.pb12.TabIndex = 20;
            this.pb12.TabStop = false;
            // 
            // pb13
            // 
            this.pb13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb13.Location = new System.Drawing.Point(161, 53);
            this.pb13.Name = "pb13";
            this.pb13.Size = new System.Drawing.Size(24, 24);
            this.pb13.TabIndex = 19;
            this.pb13.TabStop = false;
            // 
            // pb14
            // 
            this.pb14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb14.Location = new System.Drawing.Point(134, 53);
            this.pb14.Name = "pb14";
            this.pb14.Size = new System.Drawing.Size(24, 24);
            this.pb14.TabIndex = 18;
            this.pb14.TabStop = false;
            // 
            // pb15
            // 
            this.pb15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb15.Location = new System.Drawing.Point(107, 53);
            this.pb15.Name = "pb15";
            this.pb15.Size = new System.Drawing.Size(24, 24);
            this.pb15.TabIndex = 17;
            this.pb15.TabStop = false;
            // 
            // pb16
            // 
            this.pb16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb16.Location = new System.Drawing.Point(80, 53);
            this.pb16.Name = "pb16";
            this.pb16.Size = new System.Drawing.Size(24, 24);
            this.pb16.TabIndex = 16;
            this.pb16.TabStop = false;
            // 
            // PortHex1
            // 
            this.PortHex1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PortHex1.Location = new System.Drawing.Point(272, 53);
            this.PortHex1.Name = "PortHex1";
            this.PortHex1.Size = new System.Drawing.Size(24, 24);
            this.PortHex1.TabIndex = 15;
            this.PortHex1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PortNum1
            // 
            this.PortNum1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PortNum1.Location = new System.Drawing.Point(23, 53);
            this.PortNum1.Name = "PortNum1";
            this.PortNum1.Size = new System.Drawing.Size(24, 24);
            this.PortNum1.TabIndex = 14;
            this.PortNum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb17
            // 
            this.pb17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb17.Location = new System.Drawing.Point(53, 53);
            this.pb17.Name = "pb17";
            this.pb17.Size = new System.Drawing.Size(24, 24);
            this.pb17.TabIndex = 13;
            this.pb17.TabStop = false;
            // 
            // out00
            // 
            this.out00.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.out00.Location = new System.Drawing.Point(242, 101);
            this.out00.Name = "out00";
            this.out00.Size = new System.Drawing.Size(24, 24);
            this.out00.TabIndex = 30;
            this.out00.TabStop = false;
            // 
            // out01
            // 
            this.out01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.out01.Location = new System.Drawing.Point(215, 101);
            this.out01.Name = "out01";
            this.out01.Size = new System.Drawing.Size(24, 24);
            this.out01.TabIndex = 29;
            this.out01.TabStop = false;
            // 
            // out02
            // 
            this.out02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.out02.Location = new System.Drawing.Point(188, 101);
            this.out02.Name = "out02";
            this.out02.Size = new System.Drawing.Size(24, 24);
            this.out02.TabIndex = 28;
            this.out02.TabStop = false;
            // 
            // out03
            // 
            this.out03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.out03.Location = new System.Drawing.Point(161, 101);
            this.out03.Name = "out03";
            this.out03.Size = new System.Drawing.Size(24, 24);
            this.out03.TabIndex = 27;
            this.out03.TabStop = false;
            // 
            // out04
            // 
            this.out04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.out04.Location = new System.Drawing.Point(134, 101);
            this.out04.Name = "out04";
            this.out04.Size = new System.Drawing.Size(24, 24);
            this.out04.TabIndex = 26;
            this.out04.TabStop = false;
            // 
            // out05
            // 
            this.out05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.out05.Location = new System.Drawing.Point(107, 101);
            this.out05.Name = "out05";
            this.out05.Size = new System.Drawing.Size(24, 24);
            this.out05.TabIndex = 25;
            this.out05.TabStop = false;
            // 
            // out06
            // 
            this.out06.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.out06.Location = new System.Drawing.Point(80, 101);
            this.out06.Name = "out06";
            this.out06.Size = new System.Drawing.Size(24, 24);
            this.out06.TabIndex = 24;
            this.out06.TabStop = false;
            // 
            // out07
            // 
            this.out07.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.out07.Location = new System.Drawing.Point(53, 101);
            this.out07.Name = "out07";
            this.out07.Size = new System.Drawing.Size(24, 24);
            this.out07.TabIndex = 23;
            this.out07.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(35, 141);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 28);
            this.button1.TabIndex = 31;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(35, 175);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 28);
            this.button2.TabIndex = 32;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(123, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 59);
            this.label1.TabIndex = 33;
            this.label1.Text = "label1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 218);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.out00);
            this.Controls.Add(this.out01);
            this.Controls.Add(this.out02);
            this.Controls.Add(this.out03);
            this.Controls.Add(this.out04);
            this.Controls.Add(this.out05);
            this.Controls.Add(this.out06);
            this.Controls.Add(this.out07);
            this.Controls.Add(this.pb10);
            this.Controls.Add(this.pb11);
            this.Controls.Add(this.pb12);
            this.Controls.Add(this.pb13);
            this.Controls.Add(this.pb14);
            this.Controls.Add(this.pb15);
            this.Controls.Add(this.pb16);
            this.Controls.Add(this.PortHex1);
            this.Controls.Add(this.PortNum1);
            this.Controls.Add(this.pb17);
            this.Controls.Add(this.pb00);
            this.Controls.Add(this.pb01);
            this.Controls.Add(this.pb02);
            this.Controls.Add(this.pb03);
            this.Controls.Add(this.pb04);
            this.Controls.Add(this.pb05);
            this.Controls.Add(this.pb06);
            this.Controls.Add(this.PortHex0);
            this.Controls.Add(this.PortNum0);
            this.Controls.Add(this.pb07);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.out00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.out01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.out02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.out03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.out04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.out05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.out06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.out07)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox pb07;
        private Label PortHex0;
        private Label PortNum0;
        private PictureBox pb06;
        private PictureBox pb04;
        private PictureBox pb05;
        private PictureBox pb00;
        private PictureBox pb01;
        private PictureBox pb02;
        private PictureBox pb03;
        private PictureBox pb10;
        private PictureBox pb11;
        private PictureBox pb12;
        private PictureBox pb13;
        private PictureBox pb14;
        private PictureBox pb15;
        private PictureBox pb16;
        private Label PortHex1;
        private Label PortNum1;
        private PictureBox pb17;
        private PictureBox out00;
        private PictureBox out01;
        private PictureBox out02;
        private PictureBox out03;
        private PictureBox out04;
        private PictureBox out05;
        private PictureBox out06;
        private PictureBox out07;
        private Button button1;
        private Button button2;
        private Label label1;
    }
}