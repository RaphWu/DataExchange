﻿# Calin.SignalProcessing

`Calin.SignalProcessing` 是一個用於信號處理的函式庫，提供各種工具和演算法來分析和處理信號數據。

## 相依套件

### 必要

- `Calin.Abstractions`：提供基礎介面與共用型別。

### 選用

- `Autofac`：依賴注入容器，用於管理日誌元件的生命週期與解析。
  - 專案有提供模組註冊檔，可透過 `NavigationModule` 快速完成註冊。

## 版本歷史

### v0.0.1

2026.01.

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
