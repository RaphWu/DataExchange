﻿namespace Calin.SignalProcessing.Filters
{
    // 最初由 Wouter Bulten 以 <see href="https://github.com/wouterbulten/kalmanjs/blob/master/contrib/java/KalmanFilter.java">Java</see> 編寫。<br/>
    // 由 domino 改寫為 <see href="https://github.com/blueskit/KalmanFilter">C# 版</see>。

    /// <summary>
    /// 一維資料的卡爾曼濾波器簡單實作。
    /// </summary>
    public partial class FilterService : IKalmanFilter
    {
        private double A = 1;
        private double B = 0;
        private double C = 1;

        private double R;
        private double Q;

        private double cov = double.NaN;
        private double x = double.NaN;

        /// <summary>
        /// 建構函式。
        /// </summary>
        /// <param name="R">R: 過程噪聲 Process noise。</param>
        /// <param name="Q">Q: 測量噪聲 Measurement noise。</param>
        /// <param name="A">A: 狀態向量 State vector。</param>
        /// <param name="B">B: 控制向量 Control vector。</param>
        /// <param name="C">C: 測量向量 Measurement vector。</param>
        public FilterService(double R, double Q, double A, double B, double C)
        {
            this.R = R;
            this.Q = Q;

            this.A = A;
            this.B = B;
            this.C = C;

            this.cov = double.NaN;
            this.x = double.NaN; // 無噪聲的估計信號
        }

        /// <summary>
        /// 建構函式。
        /// </summary>
        /// <param name="R">R: 過程噪聲 Process noise。</param>
        /// <param name="Q">Q: 測量噪聲 Measurement noise。</param>
        public FilterService(double R, double Q)
        {
            this.R = R;
            this.Q = Q;
        }

        /// <inheritdoc/>
        public double Filter(double measurement, double u)
        {
            if (double.IsNaN(this.x))
            {
                this.x = (1 / this.C) * measurement;
                this.cov = (1 / this.C) * this.Q * (1 / this.C);
            }
            else
            {
                double predX = (this.A * this.x) + (this.B * u);
                double predCov = ((this.A * this.cov) * this.A) + this.R;

                // 卡爾曼增益
                double K = predCov * this.C * (1 / ((this.C * predCov * this.C) + this.Q));

                // 修正
                this.x = predX + K * (measurement - (this.C * predX));
                this.cov = predCov - (K * this.C * predCov);
            }
            return this.x;
        }

        /// <inheritdoc/>
        public double Filter(double measurement)
        {
            double u = 0;
            if (double.IsNaN(this.x))
            {
                this.x = (1 / this.C) * measurement;
                this.cov = (1 / this.C) * this.Q * (1 / this.C);
            }
            else
            {
                double predX = (this.A * this.x) + (this.B * u);
                double predCov = ((this.A * this.cov) * this.A) + this.R;

                // 卡爾曼增益
                double K = predCov * this.C * (1 / ((this.C * predCov * this.C) + this.Q));

                // 修正
                this.x = predX + K * (measurement - (this.C * predX));
                this.cov = predCov - (K * this.C * predCov);
            }
            return this.x;
        }

        /// <inheritdoc/>
        public double LastMeasurement()
        {
            return this.x;
        }

        /// <inheritdoc/>
        public void SetMeasurementNoise(double noise)
        {
            this.Q = noise;
        }

        /// <inheritdoc/>
        public void SetProcessNoise(double noise)
        {
            this.R = noise;
        }
    }
}
