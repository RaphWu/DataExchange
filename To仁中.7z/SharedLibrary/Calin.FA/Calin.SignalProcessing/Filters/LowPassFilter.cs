﻿namespace Calin.SignalProcessing.Filters
{
    /// <summary>
    /// 低通濾波器。
    /// </summary>
    public partial class FilterService : ILowPassFilter
    {
        #region 一階低通濾波器

        //tex:
        //一階低通濾波公式如下：
        //$$ y_n = \alpha x_n \times (1-\alpha) \times y_{n-1} $$
        //也可以寫作：
        //$$ y_n = y_{n-1} + \alpha(x_n - y_{n-1}) $$
        //其中：
        //$$ \alpha = \frac{T_s}{T_s+RC} = \frac{T_s}{T_s + \frac{1}{2\pi f_c}} = \frac{2\pi f_c T_s}{2\pi f_c T_s + 1} $$
        //參數說明：$y_n$ 為本次濾波輸出值，$y_{n-1}$ 為上次濾波輸出值，$x_n$ 為本次取樣值。$T_S$ 為取樣週期，$f_c$ 為截止頻率。 $\alpha$ 範圍為 [0,1]。

        // 參考文章：<see href="https://blog.csdn.net/qq_37662088/article/details/125075600">一阶低通滤波的C语言实现</see>。

        /// <inheritdoc/>
        public double LPF1(double xin, double fc, double Ts)
        {
            var data = FilterData.Instance;

            if (data.fisrt_xin)
            {
                data.fisrt_xin = false;
                data.lpf1_yout = xin;
            }

            double b = data.Const_2pi * fc * Ts;
            data.alpha = b / (b + 1);

            double outputValue = data.lpf1_yout + data.alpha * (xin - data.lpf1_yout);
            data.lpf1_yout = outputValue;
            return outputValue;
        }

        #endregion 一階低通濾波器

        #region 二階低通濾波器

        // 參考文章：<see href="https://blog.csdn.net/wwwyue1985/article/details/133243741">关于二阶低通滤波的C代码及入门测试。</see>
        // 參考文章：<see href="https://www.cnblogs.com/tuxinbang/p/10705443.html">二阶滤波器原理及算法程序</see>。

        /// <inheritdoc/>
        public double LowPassFilter2(double xin, double fc, double Ts)
        {
            var data = FilterData.Instance;

            //double fc = 200; // 截止頻率
            //const double Const_TS = 0.0001; // 採樣週期 1/10k = 100us

            double wc = data.Const_2pi * fc; // 2πfc
            double dampingRatio = 0.707;     // 阻尼比

            double lpf2_b0 = wc * wc * Ts * Ts;
            double lpf2_a0 = 4 + 4 * dampingRatio * wc * Ts + lpf2_b0;
            double lpf2_a1 = -8 + 2 * lpf2_b0;
            double lpf2_a2 = lpf2_b0 + 4 - 4 * dampingRatio * wc * Ts;

            data.lpf2_xin[2] = xin;
            data.lpf2_yout[2] = (lpf2_b0 * data.lpf2_xin[2] + 2 * lpf2_b0 * data.lpf2_xin[1] + lpf2_b0 * data.lpf2_xin[0] - lpf2_a1 * data.lpf2_yout[1] - lpf2_a2 * data.lpf2_yout[0]) / lpf2_a0;
            data.lpf2_xin[0] = data.lpf2_xin[1];
            data.lpf2_xin[1] = data.lpf2_xin[2];
            data.lpf2_yout[0] = data.lpf2_yout[1];
            data.lpf2_yout[1] = data.lpf2_yout[2];

            return data.lpf2_yout[2];
        }

        #endregion 二階低通濾波器
    }
}
