﻿//namespace Calin.SignalProcessing.Filters
//{
//    public class MovingAverageFilter
//    {
//    }
//}
