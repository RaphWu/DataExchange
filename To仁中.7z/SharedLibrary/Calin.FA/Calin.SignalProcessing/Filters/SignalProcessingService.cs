﻿namespace Calin.SignalProcessing.Filters
{
    public partial class FilterService
    {
    }
}
