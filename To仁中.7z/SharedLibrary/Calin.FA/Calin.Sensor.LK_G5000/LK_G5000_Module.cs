﻿namespace Calin.Sensor.LK_G5000
{
    public class LK_G5000_Module
    {

    }
}
