﻿# Calin.Sensor.LK_G5000

Calin.Sensor.LK_G5000 是一個用於與 Keyence LK-G5000 系列雷射位移傳感器進行通信和數據處理的庫。該庫提供了簡單易用的接口，允許用戶輕鬆地從傳感器獲取測量數據並進行分析。

## 相依套件

### 必要

- `Calin.Abstractions`：提供基礎介面與共用型別。
- `Calin.SerialPort`：提供串列埠通信功能。

### 選用

- `Autofac`：依賴注入容器，用於管理日誌元件的生命週期與解析。
  - 專案有提供模組註冊檔，可透過 `NavigationModule` 快速完成註冊。

## 版本歷史

### v0.0.1

2026.01.

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
