﻿# Calin.Csharp 1.0.3
2025-10-07
- 新增自動版本遞增功能
- EnumHelper 新增 `public static string GetDescription<T>(string propertyName)`

# Calin.Csharp 1.0.1
2025-09-30
- x86改回AnyCPU

# Calin.Csharp 1.0.0
2025-09-25
- 初版
