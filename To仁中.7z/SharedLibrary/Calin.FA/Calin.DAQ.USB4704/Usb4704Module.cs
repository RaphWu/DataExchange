﻿using Autofac;
using Calin.Abstractions;
using Calin.Abstractions.Logging;

namespace Calin.DAQ.USB4704
{
    /// <summary>
    /// Autofac 模組，用於註冊 USB4704 DAQ 通訊相關的依賴項。
    /// </summary>
    public class Usb4704Module : Module
    {
        /// <summary>
        /// 覆寫 Autofac 的 <see cref="Module.Load"/> 方法，註冊 USB4704 的依賴項。
        /// </summary>
        /// <param name="builder">Autofac 的容器建構器，用於註冊依賴項。</param>
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule<AbstractionsModule>()
                .IfNotRegistered(typeof(ICalinLogger));

            builder.RegisterType<Usb4704Dio>()
                .As<IUsb4704Dio>()
                .InstancePerDependency();

            builder.RegisterType<Usb4704Streaming>()
                .As<IUsb4704Streaming>()
                .InstancePerDependency();

            builder.RegisterType<Usb4704Instant>()
                .As<IUsb4704Instant>()
                .InstancePerDependency();
        }
    }
}
