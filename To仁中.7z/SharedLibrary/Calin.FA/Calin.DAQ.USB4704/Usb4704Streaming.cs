﻿using Automation.BDaq;
using Calin.Abstractions.Logging;

namespace Calin.DAQ.USB4704
{
    public class Usb4704Streaming : IUsb4704Streaming
    {
        #region Fields

        private readonly ICalinLogger _logger;
        private WaveformAiCtrl _waveformAiCtrl = new WaveformAiCtrl();

        private int _channelCountMax;
        private int _sectionLength;

        private bool _dataValid = false;
        private double[] _dataScaled;
        //private List<double> _streamingPlotData_Time;
        //private List<double> _streamingPlotData_Timestamp;
        //private List<double> _streamingPlotData_Measure;
        //private List<double> _streamingPlotData_Kalman;
        //private List<double> _streamingPlotData_Lpf1_1;
        //private List<double> _streamingPlotData_Lpf2_1;
        //private List<double> _streamingPlotData_Lpf2_2;

        #endregion Fields

        #region Events

        public event EventHandler DataReady = null;

        #endregion Events

        #region Properties

        public double[] AcquiredDataArray
        {
            get
            {
                _dataValid = false;
                return _dataScaled;
            }
        }

        public int AcquiredDataCount => _dataValid ? _dataScaled.Length : 0;
        public int ChannelCountMax => _channelCountMax;
        public int SectionLength => _sectionLength;

        #endregion Properties

        #region ctor

        public Usb4704Streaming(ICalinLogger calinLogger)
        {
            _logger = calinLogger;
        }

        #endregion ctor

        #region Methods

        public bool Usb4704StreamingInit(string deviceCode = "")
        {
            if (string.IsNullOrWhiteSpace(deviceCode))
                deviceCode = "DemoDevice,BID#0";

            _waveformAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
            if (!_waveformAiCtrl.Initialized)
            {
                _logger.Warning($"裝置開啟失敗：{nameof(Usb4704StreamingInit)}");
                _waveformAiCtrl.Dispose();
                return false;
            }

            _channelCountMax = _waveformAiCtrl.Features.ChannelCountMax;
            _sectionLength = _waveformAiCtrl.Record.SectionLength;
            _dataScaled = new double[_sectionLength];
            return true;
        }

        /// <inheritdoc/>
        public void Dispose()
        {
            _waveformAiCtrl.Dispose();
            GC.SuppressFinalize(this);
        }

        /// <inheritdoc/>
        public void StartAcquisition()
        {
            if (_waveformAiCtrl.Initialized)
            {
                ErrorCode err = _waveformAiCtrl.Prepare();
                if (err == ErrorCode.Success)
                {
                    _waveformAiCtrl.DataReady += new EventHandler<BfdAiEventArgs>(WaveformAiCtrl_DataReady);
                    _waveformAiCtrl.CacheOverflow += new EventHandler<BfdAiEventArgs>(WaveformAiCtrl_CacheOverflow);
                    _waveformAiCtrl.Overrun += new EventHandler<BfdAiEventArgs>(WaveformAiCtrl_Overrun);

                    err = _waveformAiCtrl.Start();
                }

                if (err != ErrorCode.Success)
                {
                    HandleError(err);
                    return;
                }
            }
        }

        /// <inheritdoc/>
        public void StopAcquisition()
        {
            _dataValid = false;

            _waveformAiCtrl.DataReady -= new EventHandler<BfdAiEventArgs>(WaveformAiCtrl_DataReady);
            _waveformAiCtrl.CacheOverflow -= new EventHandler<BfdAiEventArgs>(WaveformAiCtrl_CacheOverflow);
            _waveformAiCtrl.Overrun -= new EventHandler<BfdAiEventArgs>(WaveformAiCtrl_Overrun);

            ErrorCode err = _waveformAiCtrl.Stop();
            if (err != ErrorCode.Success)
            {
                HandleError(err);
                return;
            }

            Array.Clear(_dataScaled, 0, _dataScaled.Length);
        }

        /// <inheritdoc/>
        public void SetClockRate(double clockRate)
        {
            _waveformAiCtrl.Conversion.ClockRate = clockRate;
        }

        /// <inheritdoc/>
        public void SetSectionLength(int sectionLength)
        {
            _waveformAiCtrl.Record.SectionLength = sectionLength;
        }

        /// <inheritdoc/>
        public void SetSignalType(int ch, AiSignalType signalType)
        {
            _waveformAiCtrl.Channels[ch].SignalType = signalType;
        }

        /// <inheritdoc/>
        public void SetValueRange(int ch, ValueRange valueRange)
        {
            _waveformAiCtrl.Channels[ch].ValueRange = valueRange;
        }

        /// <inheritdoc/>
        public void SetChannelStart(int ch)
        {
            _waveformAiCtrl.Conversion.ChannelStart = ch;
        }

        #endregion Methods

        #region Private Methods

        private void WaveformAiCtrl_DataReady(object sender, BfdAiEventArgs args)
        {
            try
            {
                if (_waveformAiCtrl.State == ControlState.Idle)
                    return;

                if (_dataScaled.Length < args.Count)
                    _dataScaled = new double[args.Count];
                //_streamingTotalData += args.Count;

                ErrorCode err = ErrorCode.Success;
                err = _waveformAiCtrl.GetData(args.Count, _dataScaled);
                _dataValid = err == ErrorCode.Success;
                if (!_dataValid && err != ErrorCode.WarningRecordEnd)
                {
                    HandleError(err);
                    return;
                }
                else
                {
                    DataReady?.Invoke(this, EventArgs.Empty);
                }

                //foreach (var data in _dataScaled)
                //{
                //    _streamingPlotData_Measure.Add(Math.Round(data, 3));
                //    //_streamingPlotData_Kalman.Add(Math.Round(_filterKalman.Filter(data, 0.0), 3));
                //    //_streamingPlotData_Lpf1_1.Add(Math.Round(FilterLowPass.LPF1_1(data, CutoffFreq, ClockRate), 3));
                //    //_streamingPlotData_Lpf2_1.Add(Math.Round(FilterLowPass.LPF2_1(data, CutoffFreq, ClockRate), 3));
                //    //_streamingPlotData_Lpf2_2.Add(Math.Round(FilterLowPass.LPF2_2(data, CutoffFreq, ClockRate), 3));
                //} 
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
            }
        }

        private void WaveformAiCtrl_CacheOverflow(object sender, BfdAiEventArgs args)
        {
            throw new NotImplementedException();
        }

        private void WaveformAiCtrl_Overrun(object sender, BfdAiEventArgs args)
        {
            throw new NotImplementedException();
        }

        private void HandleError(ErrorCode err)
        {
            if ((err >= ErrorCode.ErrorHandleNotValid) && (err != ErrorCode.Success))
                _logger.Error(String.Concat("USB-4704異常！錯誤碼：0x", err.ToString("X8")));
        }

        #endregion Private Methods
    }
}
