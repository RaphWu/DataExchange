﻿using Automation.BDaq;

namespace Calin.DAQ.USB4704
{
    /// <summary>
    /// 定義 USB-4704 即時資料擷取的介面。
    /// </summary>
    public interface IUsb4704Instant
    {
        /// <summary>
        /// 初始化即時資料擷取。
        /// </summary>
        /// <param name="deviceCode">裝置代碼，若未提供則使用預設值。</param>
        /// <returns>若初始化成功則回傳 <c>true</c>，否則回傳 <c>false</c>。</returns>
        bool Usb4704InstantInit(string deviceCode = "");

        /// <summary>
        /// 讀取指定通道的即時資料。
        /// </summary>
        /// <param name="channel">欲讀取資料的通道編號。</param>
        /// <param name="instantData">輸出參數，回傳讀取到的即時資料值。</param>
        /// <returns>回傳 <see cref="ErrorCode"/>，表示操作的執行結果。</returns>
        ErrorCode ReadInstantData(int channel, out double instantData);
    }
}
