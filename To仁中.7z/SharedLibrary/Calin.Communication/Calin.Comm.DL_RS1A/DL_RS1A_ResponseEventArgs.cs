﻿using System;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// DL-RS1A 回應事件參數。
    /// </summary>
    public class DL_RS1A_ResponseEventArgs : EventArgs
    {
        /// <summary>
        /// 取得回應資料。
        /// </summary>
        public DL_RS1A_Response Response { get; }

        /// <summary>
        /// 取得事件發生時間。
        /// </summary>
        public DateTime Timestamp { get; }

        /// <summary>
        /// 建立 DL-RS1A 回應事件參數。
        /// </summary>
        /// <param name="response">回應資料。</param>
        public DL_RS1A_ResponseEventArgs(DL_RS1A_Response response)
        {
            Response = response ?? throw new ArgumentNullException(nameof(response));
            Timestamp = DateTime.Now;
        }
    }
}
