using System;
using System.Collections.Generic;
using Calin.Logging.Abstractions;
using Calin.SerialPort;
using Microsoft.Extensions.Logging;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// Keyence DL-RS1A RS-232 �q�T��@�C
    /// �ϥ� SerialPort �i��q�T�C
    /// </summary>
    public partial class DL_RS1A_Service : IDL_RS1A
    {
        private readonly DL_RS1A_Config _config;
        private readonly ISerialPortService _serialPortService;
        private readonly ILogger<DL_RS1A_Service> _logger;
        private bool _disposed;

        public event EventHandler<DL_RS1A_ResponseEventArgs> ResponseReceived;
        public event EventHandler<DL_RS1A_ErrorEventArgs> ErrorOccurred;

        /// <summary>
        /// �إ� DL_RS1A ��ҡC
        /// </summary>
        /// <param name="config">DL-RS1A �]�w�C</param>
        /// <param name="serialPortService">SerialPort �A�ȡC</param>
        /// <exception cref="ArgumentNullException">���ѼƬ� null �ɩߥX�C</exception>
        /// <exception cref="ArgumentException">���P�����������䴩�ɩߥX�C</exception>
        internal DL_RS1A_Service(DL_RS1A_Config config, ISerialPortService serialPortService)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _serialPortService = serialPortService ?? throw new ArgumentNullException(nameof(serialPortService));
            _logger = LoggingBridge.CreateLogger<DL_RS1A_Service>();

            // TODO: �ثe�u��@ "M0" ���O�A�ҥH�ȮɬO�q�Ϊ��C
            // �p�G��@��L���O�A�i��ݭn�ھڷP�������������P�B�z�C
            //if (config.SensorType != KeyenceSensorType.GT2 && config.SensorType != KeyenceSensorType.GT)
            //{
            //    throw new ArgumentException("���{���w�ثe�u�䴩 Keyence GT2/GT �t�C�P�����I", nameof(config));
            //}

            _logger.LogDebug("�إ� DL_RS1A_Service�APortName: {PortName}, SensorType: {SensorType}", 
                config.PortName, config.SensorType);

            SubscribeEvents();
        }

        /// <summary>
        /// ���o�]�w�C
        /// </summary>
        public DL_RS1A_Config Config => _config;

        /// <inheritdoc />
        public bool IsConnected => _serialPortService?.IsOpen ?? false;

        /// <inheritdoc />
        public bool IsTransmissionVerified => _serialPortService?.IsTransmissionVerified ?? false;

        /// <inheritdoc />
        public bool Open()
        {
            try
            {
                _logger.LogInformation("�}�� DL-RS1A �s�u�APortName: {PortName}", _config.PortName);
                var result = _serialPortService.Open();
                if (result)
                {
                    _logger.LogInformation("DL-RS1A �s�u�w�}�ҡC");
                }
                else
                {
                    _logger.LogWarning("�L�k�}�� DL-RS1A �s�u�C");
                }
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "�}�� DL-RS1A �s�u�ɵo�Ϳ��~�C");
                return false;
            }
        }

        /// <inheritdoc />
        public void Close()
        {
            try
            {
                _logger.LogInformation("���� DL-RS1A �s�u�APortName: {PortName}", _config.PortName);
                _serialPortService.Close();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "���� DL-RS1A �s�u�ɵo�Ϳ��~�C");
            }
        }

        /// <summary>
        /// �ǰe�r���ơC
        /// </summary>
        /// <param name="data">�n�ǰe���r���ơC</param>
        /// <returns>�O�_���\�ǰe�C</returns>
        private bool SendData(string data)
        {
            try
            {
                _logger.LogDebug("�ǰe��ơG{Data}", data?.TrimEnd('\r', '\n'));
                return _serialPortService.SendData(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "�ǰe��Ʈɵo�Ϳ��~�C");
                return false;
            }
        }

        /// <summary>
        /// �ǰe�줸�ո�ơC
        /// </summary>
        /// <param name="data">�n�ǰe���줸�ո�ơC</param>
        /// <returns>�O�_���\�ǰe�C</returns>
        private bool SendData(byte[] data)
        {
            try
            {
                _logger.LogDebug("�ǰe�줸�ո�ơA���סG{Length}", data?.Length ?? 0);
                return _serialPortService.SendData(data);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "�ǰe�줸�ո�Ʈɵo�Ϳ��~�C");
                return false;
            }
        }

        /// <summary>
        /// �q�\ SerialPort �ƥ�C
        /// </summary>
        private void SubscribeEvents()
        {
            if (_serialPortService is SerialPortService service)
            {
                service.DataReceived += OnSerialPortDataReceived;
                service.ErrorOccurred += OnSerialPortErrorOccurred;
            }
        }

        /// <summary>
        /// �����q�\ SerialPort �ƥ�C
        /// </summary>
        private void UnsubscribeEvents()
        {
            if (_serialPortService is SerialPortService service)
            {
                service.DataReceived -= OnSerialPortDataReceived;
                service.ErrorOccurred -= OnSerialPortErrorOccurred;
            }
        }

        private void OnSerialPortDataReceived(object sender, SerialPortDataReceivedEventArgs e)
        {
            if (string.IsNullOrEmpty(e.Data))
                return;

            try
            {
                _logger.LogDebug("�����ơG{Data}", e.Data?.TrimEnd('\r', '\n'));
                var response = ParseResponse(e.Data);
                if (response != null)
                {
                    OnResponseReceived(response);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "�ѪR�^����Ʈɵo�Ϳ��~�C");
            }
        }

        /// <summary>
        /// �ѪR DL-RS1A �^����ơC
        /// </summary>
        /// <param name="data">��l�^���r��C</param>
        /// <returns>�ѪR�᪺�^������A�ѪR���Ѯɦ^�� null�C</returns>
        private DL_RS1A_Response ParseResponse(string data)
        {
            var trimmedData = data.Trim();

            // �ˬd���~�^�� (�Ҧp: ER,01)
            if (trimmedData.StartsWith("ER,", StringComparison.OrdinalIgnoreCase))
            {
                var errorCode = trimmedData.Length > 3 ? trimmedData.Substring(3).Trim() : string.Empty;
                _logger.LogWarning("������~�^���GErrorCode={ErrorCode}", errorCode);
                return new DL_RS1A_Response
                {
                    IsSuccess = false,
                    ErrorCode = errorCode,
                    RawData = data
                };
            }

            // �ѪR���`�^�� (�Ҧp: +00001.234 �� -00001.234 �Φh����ƥH�r�����j)
            var values = trimmedData.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            var parsedValues = new List<double>();

            foreach (var value in values)
            {
                if (TryParseValue(value.Trim(), out double parsedValue))
                {
                    parsedValues.Add(parsedValue);
                }
            }

            return new DL_RS1A_Response
            {
                IsSuccess = true,
                Values = parsedValues.ToArray(),
                RawData = data
            };
        }

        /// <summary>
        /// ���ոѪR�ƭȦr��C
        /// </summary>
        /// <param name="valueString">�ƭȦr��C</param>
        /// <param name="result">�ѪR���G�C</param>
        /// <returns>�O�_���\�ѪR�C</returns>
        private bool TryParseValue(string valueString, out double result)
        {
            result = 0;

            if (string.IsNullOrWhiteSpace(valueString))
                return false;

            // �B�z GT2 �P�����^�Ǯ榡 (�Ҧp: +00001.234)
            return double.TryParse(valueString,
                System.Globalization.NumberStyles.AllowLeadingSign |
                System.Globalization.NumberStyles.AllowDecimalPoint,
                System.Globalization.CultureInfo.InvariantCulture,
                out result);
        }

        /// <summary>
        /// ������^����Ĳ�o�C
        /// </summary>
        /// <param name="response">�^����ơC</param>
        protected virtual void OnResponseReceived(DL_RS1A_Response response)
        {
            ResponseReceived?.Invoke(this, new DL_RS1A_ResponseEventArgs(response));
        }

        private void OnSerialPortErrorOccurred(object sender, SerialPortErrorEventArgs e)
        {
            _logger.LogError("SerialPort �o�Ϳ��~�G{ErrorType} - {ErrorMessage}", e.ErrorType, e.ErrorMessage);
            ErrorOccurred?.Invoke(this, new DL_RS1A_ErrorEventArgs(
                e.PortName,
                e.ErrorType,
                e.ErrorMessage,
                e.Exception,
                e.Timestamp));
        }

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        /// <param name="disposing">�O�_���b����C</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;

            if (disposing)
            {
                _logger.LogDebug("���� DL_RS1A_Service...");
                UnsubscribeEvents();
                _serialPortService?.Dispose();
            }

            _disposed = true;
        }
    }
}
