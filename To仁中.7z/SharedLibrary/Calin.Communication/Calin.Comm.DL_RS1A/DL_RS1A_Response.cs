﻿using System;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// DL-RS1A 回應資料。
    /// </summary>
    public class DL_RS1A_Response
    {
        /// <summary>
        /// 取得或設定是否成功。
        /// </summary>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// 取得或設定錯誤碼。
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// 取得或設定解析後的數值陣列。
        /// </summary>
        public double[] Values { get; set; } = Array.Empty<double>();

        /// <summary>
        /// 取得或設定原始資料。
        /// </summary>
        public string RawData { get; set; }

        /// <summary>
        /// 取得第一個數值（如果存在）。
        /// </summary>
        public double? FirstValue => Values?.Length > 0 ? Values[0] : (double?)null;
    }
}
