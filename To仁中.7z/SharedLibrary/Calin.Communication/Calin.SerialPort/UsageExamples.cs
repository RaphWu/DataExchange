using System;
using Autofac;

namespace Calin.SerialPort.Examples
{
    /// <summary>
    /// Calin.SerialPort �ϥνd�ҡC
    /// </summary>
    public static class UsageExamples
    {
        /// <summary>
        /// �إ� Autofac �e���C
        /// </summary>
        private static IContainer CreateContainer()
        {
            var builder = new ContainerBuilder();
            builder.RegisterModule<SerialPortModule>();
            return builder.Build();
        }

        /// <summary>
        /// �d�� 1: �d�ߥi�Ϊ� SerialPort�C
        /// </summary>
        public static void Example1_ListAvailablePorts()
        {
            using (var container = CreateContainer())
            {
                // �q Manager ���o
                var manager = container.Resolve<ISerialPortManager>();
                var availablePorts = manager.GetAvailablePorts();

                Console.WriteLine("�t�ΤW�i�Ϊ� SerialPort:");
                if (availablePorts.Count == 0)
                {
                    Console.WriteLine("  ����������� SerialPort");
                }
                else
                {
                    foreach (var port in availablePorts)
                    {
                        Console.WriteLine($"  - {port}");
                    }
                }

                // �q Factory / Service ���o
                var factory = container.Resolve<ISerialPortServiceFactory>();
                var service = factory.Create("COM1");
                var ports = SerialPortHelper.GetAvailablePorts();
                service.Dispose();
            }
        }

        /// <summary>
        /// �d�� 2: �ϥ� Factory �إ߳�@ SerialPort�C
        /// </summary>
        public static void Example2_SinglePortWithFactory()
        {
            using (var container = CreateContainer())
            {
                var factory = container.Resolve<ISerialPortServiceFactory>();

                // �إ߳]�w
                var config = new SerialPortConfig
                {
                    PortName = "COM1",
                    BaudRate = 9600,
                    DataBits = 8,
                    Parity = Parity.None,
                    StopBits = StopBits.One,
                    EnableAutoReconnect = true,
                    ReconnectInterval = 5000,
                    EnableTransmissionVerification = true,
                    TransmissionTestMessage = "PING\r\n",
                    TransmissionTestTimeout = 3000
                };

                // �إ� SerialPort �A��
                var service = factory.Create(config);

                // �q�\�ƥ�
                service.StateChanged += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���A�ܧ�: {e.OldState} -> {e.NewState}");
                    if (!string.IsNullOrEmpty(e.ErrorMessage))
                    {
                        Console.WriteLine($"  ���~�T��: {e.ErrorMessage}");
                    }
                };

                service.DataReceived += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] �������: {e.Data}");
                    Console.WriteLine($"  �줸�ռ�: {e.RawData.Length}");
                    Console.WriteLine($"  �ɶ��W�O: {e.Timestamp:yyyy-MM-dd HH:mm:ss.fff}");
                };

                service.ErrorOccurred += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���~ ({e.ErrorType}): {e.ErrorMessage}");
                    if (e.Exception != null)
                    {
                        Console.WriteLine($"  �ҥ~�Ա�: {e.Exception}");
                    }
                };

                // �}�ҳs�u
                if (service.Open())
                {
                    Console.WriteLine("�s�u���\");
                    Console.WriteLine($"IsTransmissionVerified: {service.IsTransmissionVerified}");

                    if (service.IsTransmissionVerified)
                    {
                        // �ǰe�r����
                        service.SendData("Hello SerialPort!\r\n");

                        // �ǰe�줸�ո��
                        byte[] data = { 0x01, 0x02, 0x03, 0x04 };
                        service.SendData(data);
                    }

                    Console.WriteLine("�����N�䵲��...");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("�s�u����");
                }

                service.Dispose();
            }
        }

        /// <summary>
        /// �d�� 3: �ϥ� Manager �޲z�h�ӳ]�ơC
        /// </summary>
        public static void Example3_MultipleDevicesWithManager()
        {
            using (var container = CreateContainer())
            {
                var manager = container.Resolve<ISerialPortManager>();

                // �q�\����ƥ�
                manager.StateChanged += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���A: {e.NewState}");
                };

                manager.DataReceived += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���: {e.Data}");
                };

                manager.ErrorOccurred += (sender, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ���~: {e.ErrorMessage}");
                };

                // ���d�ߥi�Ϊ� Port
                var availablePorts = manager.GetAvailablePorts();
                Console.WriteLine($"��� {availablePorts.Count} �ӥi�Ϊ� SerialPort");

                // ���U���X�� (COM1)
                manager.RegisterPort(new SerialPortConfig
                {
                    PortName = "COM1",
                    BaudRate = 9600,
                    EnableAutoReconnect = true,
                    ReconnectInterval = 5000
                });

                // ���U�첾�p (COM2)
                manager.RegisterPort(new SerialPortConfig
                {
                    PortName = "COM2",
                    BaudRate = 115200,
                    EnableAutoReconnect = true,
                    ReconnectInterval = 3000,
                    EnableHeartbeat = true,
                    HeartbeatInterval = 30000,
                    HeartbeatMessage = "PING\r\n",
                    HeartbeatTimeout = 10000
                });

                // �ǰe��ƨ�S�w Port
                manager.SendData("COM1", "SCAN\r\n");
                manager.SendData("COM2", "READ\r\n");

                // �s����ƨ�Ҧ� Port
                int successCount = manager.BroadcastData("STATUS\r\n");
                Console.WriteLine($"�s�����\�ǰe�� {successCount} �ӳ]��");

                // �d�ߩҦ� Port �����A
                var states = manager.GetAllPortStates();
                Console.WriteLine("\n�Ҧ��]�ƪ��A:");
                foreach (var kvp in states)
                {
                    Console.WriteLine($"  {kvp.Key}: {kvp.Value}");
                }

                Console.WriteLine("\n�����N�䵲��...");
                Console.ReadKey();

                // Manager �|�b Dispose �ɦ۰�����Ҧ� SerialPort
            }
        }

        /// <summary>
        /// �d�� 4: �ϥΤ߸��˴��C
        /// </summary>
        public static void Example4_HeartbeatMonitoring()
        {
            using (var container = CreateContainer())
            {
                var factory = container.Resolve<ISerialPortServiceFactory>();

                var config = new SerialPortConfig
                {
                    PortName = "COM1",
                    BaudRate = 9600,
                    EnableAutoReconnect = true,
                    EnableHeartbeat = true,
                    HeartbeatInterval = 30000,      // 30 ���o�e�@��
                    HeartbeatMessage = "PING\r\n",  // �߸��T��
                    HeartbeatTimeout = 10000        // 10 �����S����^���������`
                };

                var service = factory.Create(config);

                service.StateChanged += (sender, e) =>
                {
                    if (e.NewState == SerialPortState.Fault)
                    {
                        Console.WriteLine("������s�u���`�A�N�۰ʭ��s...");
                    }
                    else if (e.NewState == SerialPortState.Ready)
                    {
                        Console.WriteLine("�s�u�w�N��");
                    }
                };

                service.DataReceived += (sender, e) =>
                {
                    // �p�G���� PONG �^���A���ܤ߸����`
                    if (e.Data.Contains("PONG"))
                    {
                        Console.WriteLine("�߸����`");
                    }
                };

                service.Open();

                Console.WriteLine("�߸��ʱ��w�ҰʡA�����N�䵲��...");
                Console.ReadKey();

                service.Dispose();
            }
        }

        /// <summary>
        /// �d�� 5: �ϥ� CreateAndOpen �ֳt�إߡC
        /// </summary>
        public static void Example5_CreateAndOpen()
        {
            using (var container = CreateContainer())
            {
                var factory = container.Resolve<ISerialPortServiceFactory>();

                try
                {
                    // �إߨæ۰ʶ}�ҳs�u
                    using (var service = factory.CreateAndOpen(new SerialPortConfig
                    {
                        PortName = "COM1",
                        BaudRate = 9600
                    }))
                    {
                        Console.WriteLine($"�s�u���A: {service.State}");
                        Console.WriteLine($"�ǿ�����: {service.IsTransmissionVerified}");

                        if (service.IsTransmissionVerified)
                        {
                            service.SendData("Hello!");
                        }

                        Console.WriteLine("�����N�䵲��...");
                        Console.ReadKey();
                    }
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine($"�L�k�}�ҳs�u: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// �d�� 6: �B�z���X���q�T�C
        /// </summary>
        public static void Example6_BarcodeScanner()
        {
            using (var container = CreateContainer())
            {
                var factory = container.Resolve<ISerialPortServiceFactory>();

                var config = new SerialPortConfig
                {
                    PortName = "COM3",
                    BaudRate = 9600,
                    DataBits = 8,
                    Parity = Parity.None,
                    StopBits = StopBits.One,
                    EnableAutoReconnect = true,
                    EnableAsciiLineMode = true,  // �ҥΦ�Ҧ��A�۰ʥH����Ÿ�����
                    AsciiLineTerminator = "\r\n"
                };

                var service = factory.Create(config);
                
                service.DataReceived += (sender, e) =>
                {
                    var barcode = e.Data.Trim();
                    Console.WriteLine($"���y����X: {barcode}");

                    // ���ұ��X�榡
                    if (ValidateBarcode(barcode))
                    {
                        ProcessBarcode(barcode);
                    }
                    else
                    {
                        Console.WriteLine($"�L�Ī����X�榡: {barcode}");
                    }
                };

                service.ErrorOccurred += (sender, e) =>
                {
                    Console.WriteLine($"���X�����~: {e.ErrorMessage}");
                };

                if (service.Open())
                {
                    Console.WriteLine("���X���w�N��");
                    Console.WriteLine("�б��y���X...");
                    Console.ReadKey();
                }

                service.Dispose();
            }
        }

        /// <summary>
        /// �d�� 7: �b���ε{�����O���ϥΨ̿�`�J�C
        /// </summary>
        public static void Example7_DependencyInjectionInClass()
        {
            using (var container = CreateContainer())
            {
                // �����q�e�����o DeviceController
                var factory = container.Resolve<ISerialPortServiceFactory>();
                var manager = container.Resolve<ISerialPortManager>();

                var controller = new DeviceController(factory, manager);
                controller.InitializeDevices();

                Console.WriteLine("�����N�䵲��...");
                Console.ReadKey();
            }
        }

        #region Helper Methods

        private static bool ValidateBarcode(string barcode)
        {
            // ²�檺���X���ҡ]������ھڨ���ݨD��@�^
            return !string.IsNullOrWhiteSpace(barcode) && barcode.Length >= 8;
        }

        private static void ProcessBarcode(string barcode)
        {
            // �B�z���X�޿�]������ھڨ���ݨD��@�^
            Console.WriteLine($"�B�z���X: {barcode}");
        }

        #endregion

        #region Sample Classes

        /// <summary>
        /// �]�Ʊ���d�����O�C
        /// </summary>
        public class DeviceController
        {
            private readonly ISerialPortServiceFactory _factory;
            private readonly ISerialPortManager _manager;

            public DeviceController(
                ISerialPortServiceFactory factory,
                ISerialPortManager manager)
            {
                _factory = factory;
                _manager = manager;
            }

            public void InitializeDevices()
            {
                // �d�ߥi�Ϊ� SerialPort
                var availablePorts = _manager.GetAvailablePorts();
                Console.WriteLine($"��� {availablePorts.Count} �ӥi�Ϊ� SerialPort");

                // �q�\�ƥ�
                _manager.DataReceived += (s, e) =>
                {
                    Console.WriteLine($"[{e.PortName}] ����: {e.Data}");
                };

                // �ϥ� Manager �޲z�h�ӳ]��
                if (availablePorts.Count >= 1)
                {
                    _manager.RegisterPort(new SerialPortConfig 
                    { 
                        PortName = availablePorts[0],
                        EnableTransmissionVerification = false
                    });
                }

                if (availablePorts.Count >= 2)
                {
                    _manager.RegisterPort(new SerialPortConfig 
                    { 
                        PortName = availablePorts[1],
                        EnableTransmissionVerification = false
                    });
                }

                Console.WriteLine($"�w���U {_manager.PortCount} �ӳ]��");
            }

            public ISerialPortService CreateTemporaryConnection(string portName)
            {
                // �ϥ� Factory �إ��{�ɳs�u
                return _factory.Create(portName);
            }
        }

        #endregion
    }
}
