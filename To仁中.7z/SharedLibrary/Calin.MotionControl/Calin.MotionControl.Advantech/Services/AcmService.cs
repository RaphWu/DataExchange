﻿using System;
using System.Collections.Generic;
using Calin.Logging.Abstractions;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Microsoft.Extensions.Logging;

namespace Calin.MotionControl.Advantech.Services
{
    /// <summary>
    /// Advantech ACM 服務。
    /// </summary>
    public partial class AcmService : IAcm
    {
        #region fields

        private readonly ILogger<AcmService> _logger = LoggingBridge.CreateLogger<AcmService>();

#pragma warning disable IDE1006 // 命名樣式

        /********************
         * devices
         ********************/
        /// <summary>
        /// 裝置編號。
        /// </summary>
        private uint m_DeviceNum = 0;

        /// <summary>
        /// 裝置句柄。
        /// </summary>
        private nint m_DeviceHandle = IntPtr.Zero;

        /// <summary>
        /// 控制卡是否初始化。
        /// </summary>
        private bool m_BoardInit = false;

        /// <summary>
        /// 伺服是否開啟。
        /// </summary>
        private bool m_ServoOn = false;

        private uint m_DeviceCount = 0; // 有效裝置數量
        private List<DeviceInfo> m_AvailableDevices = new List<DeviceInfo>(); // 有效裝置列表

        /********************
         * axises
         ********************/
        /// <summary>
        /// 有效軸數量。
        /// </summary>
        private uint m_AxisCount = 0;

        /// <summary>
        /// 各軸句柄。
        /// </summary>
        private nint[] m_AxisHandles = new nint[32];

#pragma warning restore IDE1006 // 命名樣式
        #endregion fields
    }
}
