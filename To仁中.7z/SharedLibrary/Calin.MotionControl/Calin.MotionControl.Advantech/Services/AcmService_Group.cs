﻿using Calin.MotionControl.Advantech.Contracts;

namespace Calin.MotionControl.Advantech.Services
{
    // 群組操作
    public partial class AcmService : IAcmService_Group
    {
    }
}
