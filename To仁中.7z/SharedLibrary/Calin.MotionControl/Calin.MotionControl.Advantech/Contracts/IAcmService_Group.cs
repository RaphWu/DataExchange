﻿namespace Calin.MotionControl.Advantech.Contracts
{
    /// <summary>
    /// 群組操作服務介面。
    /// </summary>
    public interface IAcmService_Group
    {
    }
}
