﻿namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// Acm 設定。
    /// </summary>
    public class AcmConfig
    {
    }
}
