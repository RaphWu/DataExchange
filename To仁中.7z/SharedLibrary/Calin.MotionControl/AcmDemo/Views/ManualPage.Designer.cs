﻿namespace AcmDemo.Views
{
    partial class ManualPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxExtPulseNum = new System.Windows.Forms.NumericUpDown();
            this.checkBoxEnExtSel = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxOutPlsMd = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxExtMstSrc = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.RbMpg = new System.Windows.Forms.RadioButton();
            this.RbJog = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.NumPosRel = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.NumPosAbs = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnMove = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textBoxExtPulseNum)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosRel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosAbs)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxExtPulseNum);
            this.groupBox1.Controls.Add(this.checkBoxEnExtSel);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.comboBoxOutPlsMd);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.comboBoxExtMstSrc);
            this.groupBox1.Enabled = false;
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(395, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(309, 148);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "外部驅動設定";
            // 
            // textBoxExtPulseNum
            // 
            this.textBoxExtPulseNum.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.textBoxExtPulseNum.Location = new System.Drawing.Point(109, 56);
            this.textBoxExtPulseNum.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.textBoxExtPulseNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.textBoxExtPulseNum.Name = "textBoxExtPulseNum";
            this.textBoxExtPulseNum.Size = new System.Drawing.Size(102, 23);
            this.textBoxExtPulseNum.TabIndex = 42;
            this.textBoxExtPulseNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxExtPulseNum.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // checkBoxEnExtSel
            // 
            this.checkBoxEnExtSel.AutoSize = true;
            this.checkBoxEnExtSel.Location = new System.Drawing.Point(109, 115);
            this.checkBoxEnExtSel.Name = "checkBoxEnExtSel";
            this.checkBoxEnExtSel.Size = new System.Drawing.Size(98, 20);
            this.checkBoxEnExtSel.TabIndex = 37;
            this.checkBoxEnExtSel.Text = "使用外部驅動";
            this.checkBoxEnExtSel.UseVisualStyleBackColor = true;
            this.checkBoxEnExtSel.CheckedChanged += new System.EventHandler(this.checkBoxEnExtSel_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(217, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 16);
            this.label6.TabIndex = 37;
            this.label6.Text = "(1-10000)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 16);
            this.label5.TabIndex = 41;
            this.label5.Text = "外部驅動脈衝數";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 16);
            this.label4.TabIndex = 40;
            this.label4.Text = "脈衝輸出模式";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxOutPlsMd
            // 
            this.comboBoxOutPlsMd.FormattingEnabled = true;
            this.comboBoxOutPlsMd.Items.AddRange(new object[] {
            "OUT/DIR",
            "OUT/DIR，OUT負邏輯",
            "OUT/DIR，DIR負邏輯",
            "OUT/DIR，OUT&DIR負邏輯",
            "CW/CCW",
            "CW/CCW，CW&CCW負邏輯",
            "A/B相位",
            "B/A相位"});
            this.comboBoxOutPlsMd.Location = new System.Drawing.Point(109, 85);
            this.comboBoxOutPlsMd.Name = "comboBoxOutPlsMd";
            this.comboBoxOutPlsMd.Size = new System.Drawing.Size(172, 24);
            this.comboBoxOutPlsMd.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 38;
            this.label3.Text = "外部驅動來源";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // comboBoxExtMstSrc
            // 
            this.comboBoxExtMstSrc.FormattingEnabled = true;
            this.comboBoxExtMstSrc.Location = new System.Drawing.Point(109, 26);
            this.comboBoxExtMstSrc.Name = "comboBoxExtMstSrc";
            this.comboBoxExtMstSrc.Size = new System.Drawing.Size(172, 24);
            this.comboBoxExtMstSrc.TabIndex = 37;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RbMpg);
            this.groupBox2.Controls.Add(this.RbJog);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(395, 167);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(232, 60);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "外部驅動模式";
            // 
            // RbMpg
            // 
            this.RbMpg.AutoSize = true;
            this.RbMpg.Location = new System.Drawing.Point(109, 26);
            this.RbMpg.Name = "RbMpg";
            this.RbMpg.Size = new System.Drawing.Size(100, 20);
            this.RbMpg.TabIndex = 1;
            this.RbMpg.Text = "MPG (手搖輪)";
            this.RbMpg.UseVisualStyleBackColor = true;
            // 
            // RbJog
            // 
            this.RbJog.AutoSize = true;
            this.RbJog.Checked = true;
            this.RbJog.Location = new System.Drawing.Point(30, 26);
            this.RbJog.Name = "RbJog";
            this.RbJog.Size = new System.Drawing.Size(49, 20);
            this.RbJog.TabIndex = 0;
            this.RbJog.TabStop = true;
            this.RbJog.Text = "JOG";
            this.RbJog.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.NumPosRel);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.NumPosAbs);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.BtnStop);
            this.groupBox3.Controls.Add(this.BtnMove);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(19, 15);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(233, 133);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "PTP 運動";
            // 
            // NumPosRel
            // 
            this.NumPosRel.DecimalPlaces = 3;
            this.NumPosRel.Location = new System.Drawing.Point(82, 54);
            this.NumPosRel.Name = "NumPosRel";
            this.NumPosRel.Size = new System.Drawing.Size(125, 23);
            this.NumPosRel.TabIndex = 29;
            this.NumPosRel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 28;
            this.label1.Text = "相對位置";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // NumPosAbs
            // 
            this.NumPosAbs.DecimalPlaces = 3;
            this.NumPosAbs.Location = new System.Drawing.Point(82, 25);
            this.NumPosAbs.Name = "NumPosAbs";
            this.NumPosAbs.Size = new System.Drawing.Size(125, 23);
            this.NumPosAbs.TabIndex = 27;
            this.NumPosAbs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumPosAbs.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "絕對位置";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(128, 92);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(79, 25);
            this.BtnStop.TabIndex = 25;
            this.BtnStop.Text = "停止";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(27, 92);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(79, 25);
            this.BtnMove.TabIndex = 20;
            this.BtnMove.Text = "移動至目標";
            this.BtnMove.UseVisualStyleBackColor = true;
            this.BtnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // ManualPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ManualPage";
            this.Size = new System.Drawing.Size(720, 475);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textBoxExtPulseNum)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosRel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosAbs)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private CheckBox checkBoxEnExtSel;
        private Label label6;
        private Label label5;
        private Label label4;
        private ComboBox comboBoxOutPlsMd;
        private Label label3;
        private ComboBox comboBoxExtMstSrc;
        private NumericUpDown textBoxExtPulseNum;
        private GroupBox groupBox2;
        private RadioButton RbMpg;
        private RadioButton RbJog;
        private GroupBox groupBox3;
        private NumericUpDown NumPosRel;
        private Label label1;
        private NumericUpDown NumPosAbs;
        private Label label10;
        private Button BtnStop;
        private Button BtnMove;
    }
}
