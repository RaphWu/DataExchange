﻿using System.Diagnostics.Eventing.Reader;
using System.Text;
using AcmDemo.Constants;
using AcmDemo.Events;
using AcmDemo.Exts;
using AcmDemo.Models;
using AcmDemo.Services;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.MotionControl.Advantech.Services;
using Calin.Navigation;
using CommunityToolkit.Mvvm.Messaging;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class ToolPanel : Form, INavigationAware
    {
        #region Fields

        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        private readonly AcmParams _acmParams;

        #endregion Fields

        #region Properties

        // 當工具面板是由使用者按關閉按鈕關閉時觸發的事件，
        // 因此時父視窗無法檢知，故父視窗要訂閱此事件才能執行相關動作。
        public event EventHandler? ToolPanelHidden = null;

        #endregion Properties

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            if (CbAvailableDevice.Items.Count == 0 && _acm.DeviceCount > 0)
            {
                foreach (var dev in _acm.AvailableDevices)
                    CbAvailableDevice.Items.Add($"{dev.DeviceNum} - {dev.DeviceName}");
            }
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            return true;
        }

        #endregion INavigationAware

        #region Constructor

        public ToolPanel(IDemoService demoService, IAcm acm, AcmParams acmParams)
        {
            _demoService = demoService;
            _acm = acm;
            _acmParams = acmParams;

            InitializeComponent();

            StatePanel.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            DevicePanel.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            VelSetupPanel.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            LbAxisList.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
            ButtonPanel.DataBindings.Add(
                "Enabled",
                _acmParams,
                nameof(AcmParams.DeviceEnable),
                false,
                DataSourceUpdateMode.OnPropertyChanged);
        }

        #endregion Constructor

        #region Form Event

        private void MainPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                ToolPanelHidden?.Invoke(this, EventArgs.Empty);
                return;
            }
        }

        private void LoadData()
        {
            NumVelL.Value = (decimal)_acmParams.AxisConfigs[_acmParams.AxisNo].VelLow;
            NumVelH.Value = (decimal)_acmParams.AxisConfigs[_acmParams.AxisNo].VelHigh;
            NumAcc.Value = (decimal)_acmParams.AxisConfigs[_acmParams.AxisNo].Acceleration;
            NumDec.Value = (decimal)_acmParams.AxisConfigs[_acmParams.AxisNo].Deceleration;
            if (_acmParams.AxisConfigs[_acmParams.AxisNo].Jerk == 0.0)
                RbTCurver.Checked = true;
            else
                RbSCurver.Checked = true;
            if (_acmParams.AxisConfigs[_acmParams.AxisNo].AbsOrRel == AxisMovementMode.Absolute)
                RbAbs.Checked = true;
            else
                RbRel.Checked = true;
        }

        #endregion Form Event

        #region Device & Board

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            if (!_acm.IsBoardInit)
            {
                MessageBox.Show("控制卡尚未開啟，無需關閉。", "訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!_acm.BoardClose())
            {
                _demoService.ShowErrMsg($"控制卡關閉失敗！");
                return;
            }

            LbAxisList.Items.Clear();
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            if (_acm.IsBoardInit)
            {
                MessageBox.Show("控制卡尚未開啟，無需關閉。", "訊息", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!_acm.BoardOpen())
            {
                MessageBox.Show("控制卡開啟失敗！", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LbAxisList.Items.Clear();
            _acmParams.AxisStatuses.Clear();
            for (int axisNo = 0; axisNo < _acm.AxisCount; axisNo++)
            {
                string axisName = $"軸 {axisNo + 1}";
                _acmParams.AxisStatuses.Add(new AxisStatus());
                LbAxisList.Items.Add(axisName);
            }
            LbAxisList.SelectedIndex = 0;

            _acm.AcmStatusUpdated += AcmStatusUpdated;
        }

        private void BtnSetParam_Click(object sender, EventArgs e)
        {
            int axisNo = _acmParams.AxisNo;
            var config = _acmParams.AxisConfigs[_acmParams.AxisNo];
            StringBuilder sb = new StringBuilder();

            // 設定軸速率 (Unit: PPU/sec).
            if (_acm.SetAxisVelLow(axisNo, Convert.ToDouble(NumVelL.Text)))
                config.VelLow = (double)NumVelL.Value;
            else
                sb.AppendLine($"軸 {axisNo + 1} 設定起始速度 VelLow 失敗！");

            if (_acm.SetAxisVelHigh(axisNo, Convert.ToDouble(NumVelH.Text)))
                config.VelHigh = (double)NumVelH.Value;
            else
                sb.AppendLine($"軸 {axisNo + 1} 設定運轉速度 VelHigh 失敗！");

            // 設定加減速度 (Unit: PPU/sec^2).
            if (_acm.SetAxisAcc(axisNo, Convert.ToDouble(NumAcc.Text)))
                NumAcc.Value = (decimal)config.Acceleration;
            else
                sb.AppendLine($"軸 {axisNo + 1} 設定加速度失敗！");

            if (_acm.SetAxisDec(axisNo, Convert.ToDouble(NumDec.Text)))
                NumDec.Value = (decimal)config.Deceleration;
            else
                sb.AppendLine($"軸 {axisNo + 1} 設定減速度失敗！");

            // 設定速度曲線型態 0:T-Curve 1:S-Curve
            if (_acm.SetAxisJerk(axisNo, RbTCurver.Checked ? 0.0 : 1.0))
                config.Jerk = RbTCurver.Checked ? 0.0 : 1.0;
            else
                sb.AppendLine($"軸 {axisNo + 1} 設定速度曲線型態失敗！");

            if (sb.Length > 0)
                MessageBox.Show(sb.ToString(), "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);

            GetAxisVelParam();
        }

        /// <summary>
        /// 取得軸速率相關參數。
        /// </summary>
        private void GetAxisVelParam()
        {
            int axisNo = _acmParams.AxisNo;
            var config = _acmParams.AxisConfigs[_acmParams.AxisNo];

            var velLow = _acm.GetAxisVelLow(axisNo);
            if (velLow.IsSuccess)
            {
                NumVelL.Value = (decimal)velLow.Value;
                config.VelLow = velLow.Value;
            }
            else
            {
                NumVelL.Value = (decimal)config.VelLow;
            }

            var velHigh = _acm.GetAxisVelHigh(axisNo);
            if (velHigh.IsSuccess)
            {
                NumVelH.Value = (decimal)velHigh.Value;
                config.VelHigh = velHigh.Value;
            }
            else
            {
                NumVelH.Value = (decimal)config.VelHigh;
            }

            var acc = _acm.GetAxisAcc(axisNo);
            if (acc.IsSuccess)
            {
                NumAcc.Value = (decimal)acc.Value;
                config.Acceleration = acc.Value;
            }
            else
            {
                NumAcc.Value = (decimal)config.Acceleration;
            }

            var dec = _acm.GetAxisDec(axisNo);
            if (dec.IsSuccess)
            {
                NumDec.Value = (decimal)dec.Value;
                config.Deceleration = dec.Value;
            }
            else
            {
                NumDec.Value = (decimal)config.Deceleration;
            }
            var jerk = _acm.GetAxisJerk(axisNo);
            if (jerk.IsSuccess)
            {
                if (jerk.Value == 0.0)
                    RbTCurver.Checked = true;
                else
                    RbSCurver.Checked = true;
                config.Jerk = jerk.Value;
            }
            else
            {
                if (config.Jerk == 0.0)
                    RbTCurver.Checked = true;
                else
                    RbSCurver.Checked = true;
            }
        }

        private void BtnResetErr_Click(object sender, EventArgs e)
        {
            if (!_acm.ResetAxisState(_acmParams.AxisNo))
            {
                _demoService.ShowErrMsg($"軸 {_acmParams.AxisNo + 1} 狀態重置失敗！");
                return;
            }
        }

        private void BtnServoOn_Click(object sender, EventArgs e)
        {
            if (_acm.IsServoOn)
            {
                if (!_acm.ServoOff())
                    _demoService.ShowErrMsg("伺服關閉失敗！");
            }
            else
            {
                if (!_acm.ServoOn())
                    _demoService.ShowErrMsg("伺服開啟失敗！");
            }
        }

        private void AcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs e)
        {
            if (_acm.AxisCount > 0)
            {
                if (_acmParams.AxisStatuses.Count > e.AxisNo)
                {
                    var status = _acmParams.AxisStatuses[e.AxisNo];

                    // 座標更新
                    status.CmdPosition = e.AxisState.CmdPosition;
                    status.ActPosition = e.AxisState.ActPosition;

                    // 軸狀態更新
                    var sf = e.AxisState.StateFlags;
                    status.STA_AX_DISABLE = sf.HasFlag(StateFlags.STA_AX_DISABLE);
                    status.STA_AX_READY = sf.HasFlag(StateFlags.STA_AX_READY);
                    status.STA_AX_STOPPING = sf.HasFlag(StateFlags.STA_AX_STOPPING);
                    status.STA_AX_ERROR_STOP = sf.HasFlag(StateFlags.STA_AX_ERROR_STOP);
                    status.STA_AX_HOMING = sf.HasFlag(StateFlags.STA_AX_HOMING);
                    status.STA_AX_PTP_MOT = sf.HasFlag(StateFlags.STA_AX_PTP_MOT);
                    status.STA_AX_CONTI_MOT = sf.HasFlag(StateFlags.STA_AX_CONTI_MOT);
                    status.STA_AX_SYNC_MOT = sf.HasFlag(StateFlags.STA_AX_SYNC_MOT);
                    status.STA_AX_EXT_JOG = sf.HasFlag(StateFlags.STA_AX_EXT_JOG);
                    status.STA_AX_EXT_MPG = sf.HasFlag(StateFlags.STA_AX_EXT_MPG);
                    status.STA_AX_PAUSE = sf.HasFlag(StateFlags.STA_AX_PAUSE);
                    status.STA_AX_BUSY = sf.HasFlag(StateFlags.STA_AX_BUSY);
                    status.STA_AX_WAIT_DI = sf.HasFlag(StateFlags.STA_AX_WAIT_DI);
                    status.STA_AX_WAIT_PTP = sf.HasFlag(StateFlags.STA_AX_WAIT_PTP);
                    status.STA_AX_WAIT_VEL = sf.HasFlag(StateFlags.STA_AX_WAIT_VEL);
                    status.STA_AX_EXT_JOG_READY = sf.HasFlag(StateFlags.STA_AX_EXT_JOG_READY);

                    // 軸運動狀態更新
                    var mf = e.AxisState.MotionFlags;
                    status.Stop = mf.HasFlag(MotionFlags.Stop);
                    status.WaitERC = mf.HasFlag(MotionFlags.WaitERC);
                    status.CorrectBksh = mf.HasFlag(MotionFlags.CorrectBksh);
                    status.InFA = mf.HasFlag(MotionFlags.InFA);
                    status.InFL = mf.HasFlag(MotionFlags.InFL);
                    status.InACC = mf.HasFlag(MotionFlags.InACC);
                    status.InFH = mf.HasFlag(MotionFlags.InFH);
                    status.InDEC = mf.HasFlag(MotionFlags.InDEC);
                    status.WaitINP = mf.HasFlag(MotionFlags.WaitINP);

                    // 軸IO更新
                    var iof = e.AxisState.IoFlags;
                    status.RDY = iof.HasFlag(IoFlags.RDY);
                    status.ALM = iof.HasFlag(IoFlags.ALM);
                    status.LMT_Positive = iof.HasFlag(IoFlags.LMT_Positive);
                    status.LMT_Negative = iof.HasFlag(IoFlags.LMT_Negative);
                    status.ORG = iof.HasFlag(IoFlags.ORG);
                    status.DIR = iof.HasFlag(IoFlags.DIR);
                    status.EMG = iof.HasFlag(IoFlags.EMG);
                    status.PCS = iof.HasFlag(IoFlags.PCS);
                    status.ERC = iof.HasFlag(IoFlags.ERC);
                    status.EZ = iof.HasFlag(IoFlags.EZ);
                    status.CLR = iof.HasFlag(IoFlags.CLR);
                    status.LTC = iof.HasFlag(IoFlags.LTC);
                    status.SD = iof.HasFlag(IoFlags.SD);
                    status.INP = iof.HasFlag(IoFlags.INP);
                    status.SVON = iof.HasFlag(IoFlags.SVON);
                    status.ALRM = iof.HasFlag(IoFlags.ALRM);
                    status.SLMT_Positive = iof.HasFlag(IoFlags.SLMT_Positive);
                    status.SLMT_Negative = iof.HasFlag(IoFlags.SLMT_Negative);
                    status.CMP = iof.HasFlag(IoFlags.CMP);
                    status.CAMDO = iof.HasFlag(IoFlags.CAMDO);

                    // 更新燈號
                    TboxCurrentState.Text = sf.ToString();
                    TbCmdPos.Text = status.CmdPosition.ToString("F3");
                    TbActPos.Text = status.ActPosition.ToString("F3");

                    PBoxAlm.BackColor = status.ALM ? CommonStyle.AlarmLight : CommonStyle.LightOff;
                    PBoxEz.BackColor = status.EZ ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PBoxOrg.BackColor = status.ORG ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PBoxHELPositive.BackColor = status.LMT_Positive ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PBoxHELNegative.BackColor = status.LMT_Negative ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PbReady.BackColor = status.STA_AX_READY ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PbBusy.BackColor = status.STA_AX_BUSY ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PbStop.BackColor = status.STA_AX_STOPPING ? CommonStyle.LightOn : CommonStyle.LightOff;
                    PbErrStop.BackColor = status.STA_AX_ERROR_STOP ? CommonStyle.AlarmLight : CommonStyle.LightOff;
                }
                else
                {
                    TboxCurrentState.Text = "";
                    PBoxAlm.BackColor = CommonStyle.LightOff;
                    PBoxEz.BackColor = CommonStyle.LightOff;
                    PBoxOrg.BackColor = CommonStyle.LightOff;
                    PBoxHELPositive.BackColor = CommonStyle.LightOff;
                    PBoxHELNegative.BackColor = CommonStyle.LightOff;
                    PbReady.BackColor = CommonStyle.LightOff;
                    PbBusy.BackColor = CommonStyle.LightOff;
                    PbStop.BackColor = CommonStyle.LightOff;
                    PbErrStop.BackColor = CommonStyle.LightOff;
                }
            }
        }

        #endregion Device & Board

        #region Axis

        private void BtnStopDec_Click(object sender, EventArgs e)
        {
            if (!_acm.AxisStop(_acmParams.AxisNo))
                _demoService.ShowErrMsg($"軸 {_acmParams.AxisNo + 1} 減速停止失敗！");
        }

        private void BtnStopEmg_Click(object sender, EventArgs e)
        {
            if (!_acm.AxisStopEmg(_acmParams.AxisNo))
                _demoService.ShowErrMsg($"軸 {_acmParams.AxisNo + 1} 緊急停止失敗！");
        }

        private void BtnResetPos_Click(object sender, EventArgs e)
        {
            if (_acm.SetCmdPosition(_acmParams.AxisNo, 0.0))
                _demoService.ShowErrMsg($"軸 {_acmParams.AxisNo + 1} 命令位置重置失敗！");

            if (_acm.SetActPosition(_acmParams.AxisNo, 0.0))
                _demoService.ShowErrMsg($"軸 {_acmParams.AxisNo + 1} 實際位置重置失敗！");
        }

        private void LbAxisList_SelectedIndexChanged(object sender, EventArgs e)
        {
            _acmParams.AxisNo = LbAxisList.SelectedIndex;
            LoadData();

            // 發送軸變更訊息給需要的頁面。
            _ = WeakReferenceMessenger.Default.Send(new AxisChangedMessage(_acmParams.AxisNo));

            //var alarmBinding = new Binding(
            //    "BackColor",
            //    _acmParams,
            //    $"{nameof(AcmParams.AxisStatuses)}[{_acmParams.AxisNo}].{nameof(AxisStatus.Alarm)}",
            //    true,
            //    DataSourceUpdateMode.OnPropertyChanged)
            //{
            //    FormattingEnabled = true
            //};
            //alarmBinding.Format += (sender, e) =>
            //{
            //    try
            //    {
            //        bool alarm = false;
            //        if (e.Value is bool b)
            //            alarm = b;
            //        else if (e.Value != null)
            //            alarm = Convert.ToBoolean(e.Value);
            //        e.Value = alarm ? CommonStyle.LightOn : CommonStyle.LightOff;
            //    }
            //    catch
            //    {
            //        // 如果轉換失敗，回退到深灰色
            //        e.Value = CommonStyle.LightOff;
            //    }
            //};
            //PBoxAlm.DataBindings.Clear();
            //PBoxAlm.DataBindings.Add(alarmBinding);
        }

        private void RbAbs_CheckedChanged(object sender, EventArgs e)
        {
            _acmParams.AxisConfigs[_acmParams.AxisNo].AbsOrRel = AxisMovementMode.Absolute;
        }

        private void RbRel_CheckedChanged(object sender, EventArgs e)
        {
            _acmParams.AxisConfigs[_acmParams.AxisNo].AbsOrRel = AxisMovementMode.Relative;
        }

        #endregion Axis

        #region Configuration File

        private void BtnLoadCfg_Click(object sender, EventArgs e)
        {
            string rootDir = AppDomain.CurrentDomain.BaseDirectory;
            OpenFileDialog ofd = new OpenFileDialog
            {
                Title = "載入研華運動控制卡配置檔",
                Filter = "研華運動控制卡配置檔 (*.cfg)|*.cfg",
                DefaultExt = "cfg",
                InitialDirectory = rootDir,
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                if (!_acm.LoadCfg(ofd.FileName))
                    _demoService.ShowErrMsg("控制卡開啟失敗！");
            }
        }

        #endregion Configuration File

#if DEBUG

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            _acmParams.DeviceEnable = checkBox1.Checked;

            if (_acmParams.AxisStatuses.Count == 0)
            {
                _acmParams.AxisStatuses.Add(new AxisStatus());
                _acmParams.AxisStatuses.Add(new AxisStatus());
            }

            if (_acmParams.AxisConfigs.Count == 0)
            {
                _acmParams.AxisConfigs.Add(new AxisConfig());
                _acmParams.AxisConfigs.Add(new AxisConfig());
            }

            LbAxisList.Items.Clear();
            LbAxisList.Items.Add($"軸1");
            LbAxisList.Items.Add($"軸2");
            LbAxisList.SelectedIndex = 0;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            _acmParams.AxisNo = 0;
            PBoxAlm.BackColor = checkBox2.Checked ? CommonStyle.LightOn : CommonStyle.LightOff;
        }

#endif
    }
}
