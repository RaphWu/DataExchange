﻿using System.Security.Cryptography;
using System.Text;

namespace Calin.Helpers
{
    /// <summary>
    /// 提供加密、解密及雜湊處理的輔助工具類別。
    /// </summary>
    public static class SecurityHelper
    {
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("Your32ByteLengthKeyHere!");
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("16ByteIVVector!");

        /// <summary>
        /// 使用 AES 加密演算法加密純文字。
        /// </summary>
        /// <param name="plainText">要加密的純文字。</param>
        /// <returns>加密後的字串（Base64 編碼）。</returns>
        public static string EncryptAES(string plainText)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = Key; aes.IV = IV;
                using (var ms = new MemoryStream())
                using (var cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
                using (var sw = new StreamWriter(cs))
                {
                    sw.Write(plainText); sw.Flush(); cs.FlushFinalBlock();
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        /// <summary>
        /// 使用 AES 加密演算法解密密文。
        /// </summary>
        /// <param name="cipherText">要解密的密文（Base64 編碼）。</param>
        /// <returns>解密後的純文字。</returns>
        public static string DecryptAES(string cipherText)
        {
            var buffer = Convert.FromBase64String(cipherText);
            using (var aes = Aes.Create())
            {
                aes.Key = Key; aes.IV = IV;
                using (var ms = new MemoryStream(buffer))
                using (var cs = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read))
                using (var sr = new StreamReader(cs))
                {
                    return sr.ReadToEnd();
                }
            }
        }

        /// <summary>
        /// 使用 PBKDF2 演算法產生密碼的雜湊值。
        /// </summary>
        /// <param name="password">要雜湊的密碼。</param>
        /// <returns>包含鹽值與雜湊值的 Base64 編碼字串。</returns>
        public static string HashPassword(string password)
        {
            using (var rfc = new Rfc2898DeriveBytes(password, 16, 10000))
            {
                var salt = rfc.Salt;
                var hash = rfc.GetBytes(32);
                var result = new byte[48];
                Buffer.BlockCopy(salt, 0, result, 0, 16);
                Buffer.BlockCopy(hash, 0, result, 16, 32);
                return Convert.ToBase64String(result);
            }
        }

        /// <summary>
        /// 驗證密碼是否與雜湊值相符。
        /// </summary>
        /// <param name="password">要驗證的密碼。</param>
        /// <param name="hashed">包含鹽值與雜湊值的 Base64 編碼字串。</param>
        /// <returns>如果密碼驗證成功則為 true，否則為 false。</returns>
        public static bool VerifyPassword(string password, string hashed)
        {
            var bytes = Convert.FromBase64String(hashed);
            var salt = new byte[16]; Buffer.BlockCopy(bytes, 0, salt, 0, 16);
            var hash = new byte[32]; Buffer.BlockCopy(bytes, 16, hash, 0, 32);
            using (var rfc = new Rfc2898DeriveBytes(password, salt, 10000))
            {
                return rfc.GetBytes(32).SequenceEqual(hash);
            }
        }
    }
}
