﻿ Calin

## 簡介

`Calin` 是一個針對 .NET 的工具模組，包含各種通用擴充方法與 Helper，協助開發者提升開發效率與程式品質。

## 目標框架（Target Frameworks）

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

## 相依套件

### 必要

- 無

### 選用

- Newtonsoft.Json
  - JSON 序列化/反序列化。
  - 只有在需要使用 `JsonFileHelper` 時再安裝。

## API 列表

以下列出 `Calin` 專案內的主要 helper/extension API，說明用途、主要參數與回傳值：

### 1. 套件簡介

提供常用的檔案、列舉、字串、集合與安全性輔助工具，無需額外設定即可使用。適用於 WinForms / Console / Service 類型專案。

### 2. 快速開始

```csharp
var data = JsonFileHelper.Read<MyConfig>("config.json");
```

### 3. 功能分類總覽

#### JSON / 檔案

- `JsonFileHelper`
  - JSON 檔案同步讀寫

#### Enum

- `EnumHelper`
  - 列舉 Description 取得與反查

#### Security

- `AESHelper`
  - AES 加解密（固定 Key/IV）
- `SecurityHelper`
  - AES + PBKDF2 封裝介面

#### Collections

- `CollectionsExtensions`
  - IList 與 DataTable 互轉

#### String

- `StringExtensions`
  - Split、清理、快速分割、依字元數換行

#### UI（WinForms）

- `ThreadExtensions`
  - UI 執行緒安全呼叫

### 4. 相依性說明

- 無強制依賴 DI Framework
- WinForms 專用 API 僅在使用時需要 System.Windows.Forms

## 版本歷史

### v0.0.3

2026.01.23

- 將功能獨立的模組抽出為獨立專案，只留下基礎設施與通用擴充方法：
  - 減少龐大無謂的 NuGet 依賴。
  - 應用程式引用時有更多的彈性。
- 新增 `JsonFileHelper`，用於 JSON 格式的檔案操作。
- 移除支援 .NET Framework 4.5。

### v0.0.2

2026.01.22

- 新增支援 .NET Framework 4.5。

### v0.0.1

2026.01.15

- 將原本的 Calin.CSharp 及 Calin.WinForm 合併為 Calin。
- 分類為 Framework 與 Infrastructure 兩大模組，詳細內容查看各資料夾。

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
