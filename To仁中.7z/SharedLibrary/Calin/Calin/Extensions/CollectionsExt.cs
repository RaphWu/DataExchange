﻿using System.Data;
using System.Reflection;

namespace Calin.Extensions
{
    /// <summary>
    /// 集合擴充方法。
    /// </summary>
    public static class CollectionsExt
    {
        /// <summary>
        /// 將泛型集合轉換為 <see cref="DataTable"/>。
        /// </summary>
        /// <typeparam name="TSource">集合中元素的類型。</typeparam>
        /// <param name="data">要轉換的泛型集合。</param>
        /// <returns>包含集合資料的 <see cref="DataTable"/>。</returns>
        public static DataTable ToDataTable<TSource>(this IList<TSource> data)
        {
            DataTable dataTable = new DataTable(typeof(TSource).Name);
            PropertyInfo[] properties = typeof(TSource).GetProperties(BindingFlags.Instance | BindingFlags.Public);
            foreach (PropertyInfo propertyInfo in properties)
            {
                dataTable.Columns.Add(propertyInfo.Name, Nullable.GetUnderlyingType(propertyInfo.PropertyType) ?? propertyInfo.PropertyType);
            }

            foreach (TSource datum in data)
            {
                object?[] array2 = new object?[properties.Length];
                for (int j = 0; j < properties.Length; j++)
                {
                    array2[j] = properties[j].GetValue(datum, null);
                }

                dataTable.Rows.Add(array2);
            }

            return dataTable;
        }

        /// <summary>
        /// 將 <see cref="DataTable"/> 轉換為泛型集合。
        /// </summary>
        /// <typeparam name="T">集合中元素的類型，必須有無參數建構函式。</typeparam>
        /// <param name="dataTable">要轉換的 <see cref="DataTable"/>。</param>
        /// <returns>包含資料列的泛型集合。</returns>
        public static List<T> ToList<T>(this DataTable dataTable) where T : new()
        {
            var properties = typeof(T).GetProperties();
            var list = new List<T>();
            foreach (DataRow row in dataTable.Rows)
            {
                var obj = new T();
                foreach (var prop in properties)
                {
                    if (dataTable.Columns.Contains(prop.Name) && row[prop.Name] != DBNull.Value)
                    {
                        prop.SetValue(obj, row[prop.Name]);
                    }
                }
                list.Add(obj);
            }
            return list;
        }
    }
}