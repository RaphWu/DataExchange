﻿# Calin.Logging

## 概述

`Calin.Logging` 日誌基礎設施模組提供完整的 Serilog 日誌功能，支援多分類路由。

## 設計原則

- 以 Serilog 為唯一內建實作
- 提供簡化的 `ICalinLogger` 介面，不暴露第三方框架型別
- 避免將 Serilog 設定責任擴散至應用層或業務模組
- 使用端只關心可注入、可使用的 Logger，不關心其建立細節
- 相容 .NET Framework 4.6.2 桌面環境
- 可跨模組、跨層重用，不受 UI 框架限制

## 目標框架（Target Frameworks）

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

## 相依套件

### 必要

- `Calin.Abstractions`：提供基礎介面與共用型別。

### 選用

- `Autofac`：依賴注入容器，用於管理日誌元件的生命週期與解析。
  - 專案有提供模組註冊檔，可透過 `LoggingModule` 快速完成註冊。

### 僅內部使用

- Serilog
- Serilog.Sinks.File
- Serilog.Formatting.Compact
- Serilog.Enrichers.Environment
- Serilog.Enrichers.Process
- Serilog.Extensions.Logging
- Microsoft.Extensions.Logging

## 架構

```text
Calin.Abstractions/
└── Logging/
    ├── ICalinLogger.cs        # 日誌抽象介面（不暴露第三方型別）
    ├── NoOpLogger.cs          # 空實作（內部使用）
    └── CalinLoggerFactory.cs  # 工廠方法

Calin.Logging/
├── CalinLogger.cs             # ICalinLogger 的 Serilog 實作
├── LogCategories.cs           # 日誌分類常數定義（穩定 API 契約）
├── LogContextExtensions.cs    # LogContext 輔助擴充方法
├── LoggingBootstrapper.cs     # Serilog 初始化入口
├── LoggingModule.cs           # Autofac 日誌註冊 Module
├── LoggingOptions.cs          # 初始化選項
├── Internal/
│   ├── CategoryFilters.cs     # Category 路由 Filter（內部使用）
│   └── SinkConfigurator.cs    # Sink 組裝器（內部使用）
└── Examples/
    └── LoggingUsageExamples.cs # 使用範例
```

## 核心元件責任

| 元件                     | 責任                                                             |
| ---------------------- | -------------------------------------------------------------- |
| `ICalinLogger`         | 簡化的日誌抽象介面，不暴露任何第三方框架型別                                         |
| `CalinLogger`          | ICalinLogger 的 Serilog 實作                                      |
| `LoggingBootstrapper`  | 統一初始化 Logging Infrastructure、建立與設定 Serilog Logger、對外只暴露單一初始化入口 |
| `LoggingModule`        | 註冊所有 Logging 相關服務（不包含 Sink、Filter、路徑或 Rolling 策略）              |
| `LogCategories`        | 定義穩定跨模組共用的日誌分類契約                                               |
| `LogContextExtensions` | 提供便利方法設定日誌 Category                                            |
| `LoggingOptions`       | 初始化選項（日誌目錄、應用程式名稱）                                             |
| `Internal/*`           | Sink 組裝、Filter 判斷（僅供 Logging Infrastructure 內部使用）              |

## 快速開始

### 1. 在程式進入點初始化

```csharp
using Calin.Logging;
using Autofac;

static void Main()
{
    try
    {
        // 1. 初始化日誌系統（必須最先執行）
        LoggingBootstrapper.Initialize(new LoggingOptions
        {
            LogDirectory = "logs",
            ApplicationName = "MyApplication"
        });
        
        // 2. 初始化 Autofac 容器
        var builder = new ContainerBuilder();
        builder.RegisterModule<LoggingModule>();
        // builder.RegisterModule<其他Module>();
        var container = builder.Build();
        
        // 3. 啟動應用程式
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        using (var scope = container.BeginLifetimeScope())
        {
            var mainForm = scope.Resolve<MainForm>();
            Application.Run(mainForm);
        }
    }
    catch (Exception ex)
    {
        Log.Fatal(ex, "應用程式發生未處理的例外");
    }
    finally
    {
        // 4. 關閉日誌系統
        LoggingBootstrapper.Shutdown();
    }
}
```

### 2. 使用 ICalinLogger（建議）

`ICalinLogger` 是簡化的日誌介面，適用於大多數場景：

```csharp
using Calin.Abstractions.Logging;

public class MyService
{
    private readonly ICalinLogger _logger;
    
    public MyService(ICalinLogger logger)
    {
        _logger = logger;
    }
    
    public void DoSomething()
    {
        _logger.Debug("開始處理");
        _logger.Information("處理完成");
    }
    
    public void HandleError()
    {
        try
        {
            // 執行操作
        }
        catch (Exception ex)
        {
            _logger.Error("處理過程發生錯誤", ex);
        }
    }
}
```

### 3. 使用 Serilog.ILogger（進階）

需要結構化日誌、Category 路由時使用：

```csharp
using Serilog;
using Calin.Logging;

public class MyService
{
    private readonly ILogger _logger;
    
    public MyService(ILogger logger)
    {
        _logger = logger.ForContext<MyService>();
    }
    
    public void DoSomething()
    {
        // 一般日誌（寫入 information.txt）
        _logger.Information("執行操作");
        
        // 使用者操作日誌（寫入 user_activity.json）
        using (LogContextExtensions.WithUserActivity())
        {
            _logger.Information("使用者 {UserId} 執行重要操作", userId);
        }
        
        // 資料庫操作日誌（寫入 database_event.json）
        using (LogContextExtensions.WithDatabase())
        {
            _logger.Information("新增資料，Id={Id}", entity.Id);
        }
    }
}
```

### 非 Autofac 使用範例

若不想部署 `Autofac`，可以呼叫 `ManualLoggingExample.CreateLoggerWithoutAutofac` 來初始化 `LoggingBootstrapper`：

```csharp
var logger = ManualLoggingExample.CreateLoggerWithoutAutofac(new LoggingOptions
{
    LogDirectory = "logs",
    ApplicationName = "MyApp"
});

var example = new CalinLoggerExample(logger);
example.DoSomething();
```

這樣一來可以在完全不註冊 DI 容器的情境下，直接使用 `CalinLogger` 提供的簡化介面。

## 日誌分類

| 分類           | 常數                           | 語意定義                   |
| ------------ | ---------------------------- | ---------------------- |
| UserActivity | `LogCategories.UserActivity` | 使用者登入、登出、權限變更、關鍵操作與其結果 |
| Database     | `LogCategories.Database`     | 資料存取、交易、連線、效能量測與錯誤     |
| Business     | `LogCategories.Business`     | 業務流程狀態、規則判斷與決策結果       |
| System       | `LogCategories.System`       | 系統啟動、關閉、背景服務與生命週期事件    |

## 日誌檔案

| 檔案                          | 格式           | 保留天數  | 說明                                    |
| --------------------------- | ------------ | ----- | ------------------------------------- |
| `logs/information.txt`      | Text         | 15 天  | 一般資訊（排除 UserActivity、Database、System） |
| `logs/error_log_.txt`       | Text         | 90 天  | 錯誤與例外（Error 以上）                       |
| `logs/user_activity.json`   | Compact JSON | 90 天  | 使用者操作（Audit Log）                      |
| `logs/database_event.json`  | Compact JSON | 90 天  | 資料庫操作                                 |
| `logs/system_lifecycle.txt` | Text         | 30 天  | 系統生命週期事件                              |
| `logs/fatal.txt`            | Text         | 180 天 | 致命錯誤事件                                |

## 日誌等級策略

- **Global MinimumLevel**: Debug
- **Override**:
  - Microsoft → Warning
  - System → Warning

## Enrich 資訊

日誌自動包含以下 Enrichment：

- Application（應用程式名稱）
- MachineName（機器名稱）
- ProcessId（程序 ID）

## DI 註冊

LoggingModule 註冊以下服務：

| 服務                                            | 生命週期                  | 說明                     |
| --------------------------------------------- | --------------------- | ---------------------- |
| `ICalinLogger`                                | SingleInstance        | 建議使用的主要日誌介面            |
| `Serilog.ILogger`                             | SingleInstance        | 進階使用，支援結構化日誌與 Category |
| `Microsoft.Extensions.Logging.ILoggerFactory` | SingleInstance        | 與 MEL 整合               |
| `Microsoft.Extensions.Logging.ILogger`        | InstancePerDependency | 與 MEL 整合               |

### 自訂 Logger 實作

可在註冊 LoggingModule 前註冊自訂的 ICalinLogger：

```csharp
var builder = new ContainerBuilder();

// 註冊自訂 Logger（可選）
builder.RegisterInstance(myCustomLogger).As<ICalinLogger>().SingleInstance();

// 註冊 LoggingModule（如果已註冊 ICalinLogger，則使用已註冊的）
builder.RegisterModule<LoggingModule>();
```

### 使用 NoOpLogger

如果不需要日誌輸出，可使用 NoOpLogger：

```csharp
using Calin.Abstractions.Logging;

var builder = new ContainerBuilder();
builder.RegisterInstance(CalinLoggerFactory.CreateNoOpLogger())
    .As<ICalinLogger>()
    .SingleInstance();
```

## 使用規範

### ? 正確用法

```csharp
// 使用 LogContextExtensions 設定分類
using (LogContextExtensions.WithUserActivity())
{
    _logger.Information("使用者 {UserId} 登入", userId);
}

// 或使用 LogContext.PushProperty
using (LogContext.PushProperty("Category", LogCategories.UserActivity))
{
    _logger.Information("使用者 {UserId} 登入", userId);
}
```

### ? 錯誤用法

```csharp
// 嚴禁直接使用字串
using (LogContext.PushProperty("Category", "UserActivity")) // 錯誤！
{
    _logger.Information("使用者登入");
}

// 嚴禁將分類寫在訊息中
_logger.Information("[UserActivity] 使用者登入"); // 錯誤！

// 嚴禁在應用程式建立 LoggerConfiguration
var config = new LoggerConfiguration(); // 錯誤！
```

## 初始化行為

- **可重入**：多次呼叫 `Initialize()` 只產生一次有效設定
- **行為明確**：初始化狀態可透過 `LoggingBootstrapper.IsInitialized` 查詢
- **可預期**：初始化後 Logger 可透過 DI 或 `Log.Logger` 取得

## 明確禁止事項

### 應用程式或模組

- 不得 `new LoggerConfiguration()`
- 不得設定 Sink 或 Filter
- 不得操作 `Log.Logger`（除了讀取）

### Library / NuGet

- 不得在靜態建構式中初始化 Serilog
- 不得假設特定 App.config 設定存在

## 注意事項

1. **初始化順序**：`LoggingBootstrapper.Initialize()` 必須在所有其他初始化之前執行
2. **關閉順序**：`LoggingBootstrapper.Shutdown()` 必須在應用程式結束時呼叫
3. **Category 常數**：Category 值為日誌路由契約，不得隨意變更
4. **Filter 實作**：Filter 使用 `ScalarValue` 正確判斷 Category，不使用 `ToString()`

---

## 何時需要 MEL？

`Microsoft.Extensions.Logging`（簡稱 **MEL**）是一個 **通用的 .NET 日誌抽象介面與框架**，它本身不寫日誌，而是提供一套標準介面（`ILogger`、`ILoggerFactory` 等）讓你 **可以換底層日誌實作**（Serilog、NLog、Log4Net…）。

何時需要 MEL 可以拆解如下：

### 1. 當你需要 **DI + 模組化、可替換 Logger**

- 如果你希望：
  - 各模組注入 `ILogger<T>` 而不用直接依賴 Serilog
  - 將來可能換底層 Logger（例如從 Serilog 換 NLog）
  - 方便與 ASP.NET Core 或其他 .NET Standard Library 共用 Logging API

就需要 MEL，因為它提供標準介面：

```csharp
public class MyService
{
    private readonly ILogger<MyService> _logger;
    public MyService(ILogger<MyService> logger)
    {
        _logger = logger;
    }
}
```

> 這樣寫的 Service 不知道底層是 Serilog、NLog 還是其他。

### 2. 當你只想用 Serilog 而不打算換其他 Logger

- 你 **不一定要用 MEL**
- 可以直接注入 `Serilog.ILogger` 或使用 `Log.Logger` 全域靜態
- MEL 在這種情況下只是多一層抽象，對你的專案使用上沒有立即好處

> 適合小型或內部專案，或者你確定永遠用 Serilog

### 3. 當你想使用 **現成套件 / Library**

- 許多 NuGet Library（例如 CommunityToolkit.Mvvm、EF Core、ASP.NET Core）使用 MEL `ILogger<T>`
- 如果你想這些 Library 的日誌能統一導到 Serilog，你就必須：
  - 注入 `ILoggerFactory`（MEL）
  - 使用 `SerilogLoggerProvider` 將 Serilog 與 MEL 接上

```csharp
var loggerFactory = LoggerFactory.Create(builder =>
{
    builder.AddSerilog();
});
```

### 4. 實務建議

| 條件                            | 建議                                                                  |
| ----------------------------- | ------------------------------------------------------------------- |
| 你想只用 Serilog，內部專案             | **不需要 MEL**，直接注入 `Serilog.ILogger`                                  |
| 你想讓 Library、DI 模組、共用程式碼也可統一注入 | **需要 MEL**，透過 `ILogger<T>` 注入，並用 `SerilogLoggerProvider` 連接 Serilog |
| 你未來可能換 Logger                 | **必須 MEL**，這樣 Service / Library 不依賴具體 Logger                        |

> 建議保留 **MEL 層**，主要是為了 **跨模組注入統一 Logger**，而不是為了多 Logger 支援。

**一句話總結**：

- **Microsoft.Extensions.Logging 不是必須的**，但在大型專案或多模組共用場景中，它提供了 **統一介面 + 可替換性 + 與 Library 兼容性**，建議保留。

### Serilog + MEL + Autofac DI 的依賴關係示意圖

呈現 LoggingModule、Bootstrapper、ILogger\<T>、SerilogLoggerProvider 之間的關係與流程。

```mermaid
graph TD
    subgraph AppStartup["WinForm App 啟動"]
        A["呼叫 LoggingBootstrapper.Initialize()"]
        B[建立 Autofac Container]
        C["註冊其他 Module (Business, Database...)"]
    end

    subgraph Infrastructure["Calin.Logging"]
        LB[LoggingBootstrapper]
        LM[LoggingModule]
        MEL[Microsoft.Extensions.Logging.ILogger\<T> / ILoggerFactory]
        SerilogProvider[SerilogLoggerProvider]
        SerilogLogger[Serilog.ILogger]
        Categories[LogCategories & Filter & Sink]
    end

    %% 初始化流程
    A --> LB
    LB --> SerilogLogger
    LB --> Categories

    %% DI 註冊
    LM --> MEL
    MEL --> SerilogProvider
    SerilogProvider --> SerilogLogger

    %% 其他模組依賴
    C --> MEL
    C --> LM
```

#### 說明

1. **App 啟動**
    - 首先呼叫 `LoggingBootstrapper.Initialize()` 確保 Serilog 已初始化
    - 建立 Autofac Container 並註冊其他模組
2. **Infrastructure**
    - `LoggingBootstrapper` 負責建立 `Serilog.ILogger` 實例，配置 Sink、Filter、Category
    - `LoggingModule` 負責將 `ILogger<T>` 和 `ILoggerFactory` 註冊到 DI
    - `SerilogLoggerProvider` 將 MEL 與 Serilog 實例接上，讓各模組可以安全注入
3. **其他模組**
    - 不需要直接依賴 Serilog
    - 只注入 `ILogger<T>`（MEL 介面），底層透過 SerilogProvider 使用 Serilog 實作

這個圖表把 **初始化順序**、**DI 注入路徑**、**Serilog 實例位置**都標明了，能清楚看到：

- **LoggingBootstrapper** → 初始化 Serilog
- **LoggingModule** → 註冊 MEL 到 DI
- **其他模組** → 注入 ILogger，安全使用

---

## 關於 LogContext

在 Serilog 中，`LogContext` 是用來 **在日誌上下文中附加臨時屬性（Properties）** 的機制。使用它有幾個重要好處，尤其適合你的跨模組、分類嚴格的 Logging Infrastructure。

### 1. 動態附加屬性到單次日誌

- 透過 `LogContext.PushProperty("Category", LogCategories.Xxx)`，你可以在 **特定程式區段** 自動附加屬性。
- 好處：
  - 不用在每條訊息文字中硬寫分類或模組名稱
  - 保證所有日誌資料結構一致，可由 Filter / Sink 判斷路由
  - 支援 **using / IDisposable** 範圍管理，屬性只在區塊內有效

```csharp
using (LogContext.PushProperty("Category", LogCategories.UserActivity))
{
    _logger.Information("使用者登入成功");
}
```

- 這樣，該訊息自動帶上 Category = UserActivity，Sink 可依此路由，不需手動解析文字。

### 2. 避免靜態 / 全域屬性污染

- 如果你直接在 Logger 建構時或全域 Context 附加屬性：
  - 所有日誌都會帶上同一個 Category
  - 無法針對單次操作設定不同屬性
- `LogContext.PushProperty` 允許 **局部作用域、區塊級別的屬性覆蓋**

### 3. 支援跨方法、跨呼叫鏈追蹤

- 對於大型專案或 Service / UI / Background Task 跨多方法呼叫：
  - 可以在方法入口 PushProperty，呼叫過程中所有日誌都自動帶上該屬性
  - 適合 **TraceId / UserId / SessionId** 等跨模組追蹤

```csharp
public void HandleUserLogin(User user)
{
    using (LogContext.PushProperty("UserId", user.Id))
    using (LogContext.PushProperty("Category", LogCategories.UserActivity))
    {
        _logger.Information("開始處理登入");
        ValidateUser(user);
        _logger.Information("登入成功");
    }
}
```

- 所有日誌自動帶上 UserId 和 Category，不需每條訊息重複寫。

### 4. 與 Sink / Filter 配合

- 你在 PROMPT 中設計的 **Category Filter Routing**：
  - Sink 可以檢查 `Category` 屬性值
  - 只把 UserActivity 送到 JSON Audit Log
  - Database 事件送到 Database Sink
- 如果不用 `LogContext`：
  - 只能透過訊息文字解析，容易錯誤、維護困難
  - 或必須寫大量重複程式碼在每條訊息

### 5. 總結好處

1. **自動化屬性注入**：不用每條訊息手動加分類
2. **範圍控制**：局部 PushProperty，自動消失，避免污染全域日誌
3. **跨方法追蹤**：支援多層呼叫鏈附加上下文屬性
4. **Sink 路由友好**：讓 Filter / Sink 可以依屬性路由
5. **程式碼整潔**：日誌訊息專注於語意，而分類、追蹤屬性由 LogContext 管理

**結論**：

`LogContextExtensions` 是 **實現 Category Filter、UserActivity / Database / Business / System 分類、跨模組追蹤的核心工具**，能保持日誌乾淨、一致、可擴充，也完全符合你的設計原則。

## 版本歷史

### v0.0.1

2026.01.23

- 由 Calin.Framework 抽出為獨立模組。
- 新增 Calin.Abstractions.ICalinLogger 共用抽象介面，詳見 Calin.Abstractions.Logging 的 README 說明。

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
