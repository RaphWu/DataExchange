// ===================================================================
// Calin.Logging.Serilog
// 
// SerilogLoggerFactoryBuilder - �إ� Serilog LoggerFactory
//
// �d���G
//   - ���� Fluent API �إ� Serilog LoggerFactory
//   - �ʸ� Serilog �]�w�Ӹ`
//   - �u���b App �� Composition Root �ϥ�
// ===================================================================

using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Events;
using Serilog.Formatting.Compact;

namespace Calin.Logging.Serilog;

/// <summary>
/// Serilog LoggerFactory �غc���C
/// </summary>
/// <remarks>
/// <para>
/// <b>�����O�u���b App �� Composition Root �ϥΡC</b>
/// Device NuGet ���藍�i�ϥΦ����O�C
/// </para>
/// <example>
/// <code>
/// var loggerFactory = new SerilogLoggerFactoryBuilder()
///     .SetMinimumLevel(LogEventLevel.Debug)
///     .AddConsole()
///     .AddFile("logs/app.log")
///     .EnableThreadEnricher()
///     .Build();
/// </code>
/// </example>
/// </remarks>
public sealed class SerilogLoggerFactoryBuilder
{
    private readonly LoggerConfiguration _loggerConfiguration;
    private LogEventLevel _minimumLevel = LogEventLevel.Information;
    private bool _consoleEnabled;
    private bool _debugEnabled;
    private string? _filePath;
    private string? _jsonFilePath;
    private long _fileSizeLimitBytes = 10 * 1024 * 1024; // 10 MB
    private int _retainedFileCountLimit = 31;
    private RollingInterval _rollingInterval = RollingInterval.Day;

    // Enrichers
    private bool _threadEnricherEnabled;
    private bool _environmentEnricherEnabled;
    private bool _processEnricherEnabled;
    private bool _applicationNameEnricherEnabled;
    private string? _applicationName;

    /// <summary>
    /// ��l�� SerilogLoggerFactoryBuilder�C
    /// </summary>
    public SerilogLoggerFactoryBuilder()
    {
        _loggerConfiguration = new LoggerConfiguration();
    }

    /// <summary>
    /// �]�w�̤p Log �h�šC
    /// </summary>
    /// <param name="level">�̤p�h�šC</param>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder SetMinimumLevel(LogEventLevel level)
    {
        _minimumLevel = level;
        return this;
    }

    /// <summary>
    /// �ҥ� Console Sink�C
    /// </summary>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder AddConsole()
    {
        _consoleEnabled = true;
        return this;
    }

    /// <summary>
    /// �ҥ� Debug Sink�]��X�� Visual Studio Output Window�^�C
    /// </summary>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder AddDebug()
    {
        _debugEnabled = true;
        return this;
    }

    /// <summary>
    /// �ҥ� File Sink�]��r�榡�^�C
    /// </summary>
    /// <param name="filePath">�ɮ׸��|�C</param>
    /// <param name="fileSizeLimitBytes">�ɮפj�p����]�줸�ա^�C</param>
    /// <param name="retainedFileCountLimit">�O�d�ɮ׼ƶq�C</param>
    /// <param name="rollingInterval">�u�ʶ��j�C</param>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder AddFile(
        string filePath,
        long fileSizeLimitBytes = 10 * 1024 * 1024,
        int retainedFileCountLimit = 31,
        RollingInterval rollingInterval = RollingInterval.Day)
    {
        _filePath = filePath;
        _fileSizeLimitBytes = fileSizeLimitBytes;
        _retainedFileCountLimit = retainedFileCountLimit;
        _rollingInterval = rollingInterval;
        return this;
    }

    /// <summary>
    /// �ҥ� JSON File Sink�]���c�Ʈ榡�^�C
    /// </summary>
    /// <param name="filePath">�ɮ׸��|�C</param>
    /// <param name="fileSizeLimitBytes">�ɮפj�p����]�줸�ա^�C</param>
    /// <param name="retainedFileCountLimit">�O�d�ɮ׼ƶq�C</param>
    /// <param name="rollingInterval">�u�ʶ��j�C</param>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder AddJsonFile(
        string filePath,
        long fileSizeLimitBytes = 10 * 1024 * 1024,
        int retainedFileCountLimit = 31,
        RollingInterval rollingInterval = RollingInterval.Day)
    {
        _jsonFilePath = filePath;
        _fileSizeLimitBytes = fileSizeLimitBytes;
        _retainedFileCountLimit = retainedFileCountLimit;
        _rollingInterval = rollingInterval;
        return this;
    }

    /// <summary>
    /// �ҥ� Thread Enricher�]�[�J ThreadId�^�C
    /// </summary>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder EnableThreadEnricher()
    {
        _threadEnricherEnabled = true;
        return this;
    }

    /// <summary>
    /// �ҥ� Environment Enricher�]�[�J MachineName�BUserName�^�C
    /// </summary>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder EnableEnvironmentEnricher()
    {
        _environmentEnricherEnabled = true;
        return this;
    }

    /// <summary>
    /// �ҥ� Process Enricher�]�[�J ProcessId�BProcessName�^�C
    /// </summary>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder EnableProcessEnricher()
    {
        _processEnricherEnabled = true;
        return this;
    }

    /// <summary>
    /// �ҥ� Application Name Enricher�]�[�J ApplicationName�^�C
    /// </summary>
    /// <param name="applicationName">���ε{���W�١C</param>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder EnableApplicationNameEnricher(string applicationName)
    {
        _applicationNameEnricherEnabled = true;
        _applicationName = applicationName;
        return this;
    }

    /// <summary>
    /// �ҥΩҦ� Enricher�C
    /// </summary>
    /// <param name="applicationName">���ε{���W�١C</param>
    /// <returns>Builder ��ҡC</returns>
    public SerilogLoggerFactoryBuilder EnableAllEnrichers(string applicationName)
    {
        return EnableThreadEnricher()
            .EnableEnvironmentEnricher()
            .EnableProcessEnricher()
            .EnableApplicationNameEnricher(applicationName);
    }

    /// <summary>
    /// �إ� LoggerFactory�C
    /// </summary>
    /// <returns>ILoggerFactory ��ҡC</returns>
    /// <exception cref="InvalidOperationException">���]�w���� Sink�C</exception>
    public ILoggerFactory Build()
    {
        // ���Ҧܤ֦��@�� Sink
        if (!_consoleEnabled && !_debugEnabled && string.IsNullOrEmpty(_filePath) && string.IsNullOrEmpty(_jsonFilePath))
        {
            throw new InvalidOperationException("�ܤֻݭn�ҥΤ@�� Sink�]Console�BDebug �� File�^�C");
        }

        // �]�w�̤p�h��
        _loggerConfiguration.MinimumLevel.Is(_minimumLevel);

        // �]�w Enrichers
        ConfigureEnrichers();

        // �]�w Sinks
        ConfigureSinks();

        // �إ� Serilog Logger
        var serilogLogger = _loggerConfiguration.CreateLogger();

        // �]�w���� Logger�]�Ѥ����ϥΡ^
        Log.Logger = serilogLogger;

        // �إ� Microsoft.Extensions.Logging.ILoggerFactory
        var loggerFactory = LoggerFactory.Create(builder =>
        {
            builder.ClearProviders();
            builder.AddSerilog(serilogLogger, dispose: true);
        });

        return loggerFactory;
    }

    private void ConfigureEnrichers()
    {
        if (_threadEnricherEnabled)
        {
            _loggerConfiguration.Enrich.WithThreadId();
        }

        if (_environmentEnricherEnabled)
        {
            _loggerConfiguration.Enrich.WithMachineName();
            _loggerConfiguration.Enrich.WithEnvironmentUserName();
        }

        if (_processEnricherEnabled)
        {
            _loggerConfiguration.Enrich.WithProcessId();
            _loggerConfiguration.Enrich.WithProcessName();
        }

        if (_applicationNameEnricherEnabled && !string.IsNullOrEmpty(_applicationName))
        {
            _loggerConfiguration.Enrich.WithProperty("ApplicationName", _applicationName);
        }

        // �[�J FromLogContext �H�䴩 Scope
        _loggerConfiguration.Enrich.FromLogContext();
    }

    private void ConfigureSinks()
    {
        const string outputTemplate = "[{Timestamp:HH:mm:ss.fff} {Level:u3}] [{SourceContext}] {Message:lj}{NewLine}{Exception}";

        if (_consoleEnabled)
        {
            _loggerConfiguration.WriteTo.Console(outputTemplate: outputTemplate);
        }

        if (_debugEnabled)
        {
            _loggerConfiguration.WriteTo.Debug(outputTemplate: outputTemplate);
        }

        if (!string.IsNullOrEmpty(_filePath))
        {
            _loggerConfiguration.WriteTo.File(
                path: _filePath,
                rollingInterval: _rollingInterval,
                fileSizeLimitBytes: _fileSizeLimitBytes,
                retainedFileCountLimit: _retainedFileCountLimit,
                outputTemplate: outputTemplate,
                shared: true);
        }

        if (!string.IsNullOrEmpty(_jsonFilePath))
        {
            _loggerConfiguration.WriteTo.File(
                formatter: new CompactJsonFormatter(),
                path: _jsonFilePath,
                rollingInterval: _rollingInterval,
                fileSizeLimitBytes: _fileSizeLimitBytes,
                retainedFileCountLimit: _retainedFileCountLimit,
                shared: true);
        }
    }
}
