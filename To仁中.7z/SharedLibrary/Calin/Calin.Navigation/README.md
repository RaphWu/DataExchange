﻿# Calin.Navigation

## 介紹

`Calin.Navigation` 是負責頁面導航的模組。它提供了 Region 導向的導航架構，支援多重視窗、多分頁（Tab）與區域（Region）導向的頁面管理。

## 目標框架（Target Frameworks）

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0 (`net8.0-windows`)

## 相依套件

### 必要

- `Calin.Abstractions`：提供基礎介面與共用型別。

### 選用

- `Autofac`：依賴注入容器，用於管理日誌元件的生命週期與解析。
  - 專案有提供模組註冊檔，可透過 `NavigationModule` 快速完成註冊。

## 整體架構流程圖

```mermaid
flowchart TB
    subgraph UI["UI Layer"]
        Form["Form / Window"]
        Panel["Panel / TabPage"]
        UserControl["UserControl (View)"]
    end

    subgraph Navigation["Navigation Module"]
        RegionManager["RegionManager<br/>(Region 管理)"]
        NavigationService["NavigationService<br/>(導航服務)"]
        NavigationJournal["NavigationJournal<br/>(歷史紀錄)"]
    end

    subgraph DI["Autofac DI"]
        LifetimeScope["LifetimeScope"]
        ViewResolver["View 解析"]
    end

    Form -->|註冊 Region| RegionManager
    NavigationService -->|協作| RegionManager
    NavigationService -->|記錄| NavigationJournal
    NavigationService -->|解析 View| LifetimeScope
    LifetimeScope -->|建立| UserControl
    RegionManager -->|管理| Panel
    Panel -->|容納| UserControl
```

## 核心元件

### 設計重點

| 元件                        | 職責            | 注意事項               |
| ------------------------- | ------------- | ------------------ |
| **IRegion**               | UI 容器抽象       | 對應 Panel、TabPage 等 |
| **IRegionManager**        | Region 生命週期管理 | 單例，管理所有 Region     |
| **INavigationService**    | 導航操作介面        | 單例，處理導航邏輯          |
| **INavigationJournal**    | 導航歷史紀錄        | 每個 Region 各自維護     |
| **INavigationAware**      | 導航事件通知        | View 可選實作          |
| **INavigationParameters** | 參數傳遞          | Key-Value 存取       |

## Region 註冊

### 說明

Region 是邏輯上的 UI 容器，可對應 Form、Panel、TabPage 等實際 UI 元件。透過 `IRegionManager` 註冊 Region 後，即可使用 `INavigationService` 在該 Region 內進行導航。

### 使用方法

```csharp
public class MainForm : Form
{
    private readonly IRegionManager _regionManager;
    private readonly Panel _contentPanel;
    
    public MainForm(IRegionManager regionManager)
    {
        _regionManager = regionManager;
        _contentPanel = new Panel { Dock = DockStyle.Fill };
        Controls.Add(_contentPanel);
        
        // 註冊 Region
        _regionManager.RegisterRegion(
            "MainContent",  // Region 名稱
            view =>         // 啟動 View 時的處理
            {
                _contentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    _contentPanel.Controls.Add(control);
                }
            },
            view =>         // 停用 View 時的處理（可選）
            {
                if (view is Control control)
                {
                    _contentPanel.Controls.Remove(control);
                }
            });
    }
}
```

## 頁面導航

### 說明

`INavigationService` 提供統一的導航介面，支援導航至指定頁面、前進/後退、傳遞參數等功能。

### 使用方法

```csharp
public class NavigationController
{
    private readonly INavigationService _navigationService;
    
    public NavigationController(INavigationService navigationService)
    {
        _navigationService = navigationService;
    }
    
    public void NavigateToDetail(int itemId)
    {
        // 建立導航參數
        var parameters = new NavigationParameters();
        parameters.Add("ItemId", itemId);
        parameters.Add("Mode", "Edit");
        
        // 導航至 DetailView
        var result = _navigationService.NavigateTo<DetailView>(
            "MainContent",  // Region 名稱
            1001,           // 頁面識別碼
            parameters);    // 導航參數
        
        if (!result.Success)
        {
            MessageBox.Show($"導航失敗: {result.ErrorMessage}");
        }
    }
    
    public void GoBack()
    {
        if (_navigationService.CanGoBack("MainContent"))
        {
            _navigationService.GoBack("MainContent");
        }
    }
    
    public void GoForward()
    {
        if (_navigationService.CanGoForward("MainContent"))
        {
            _navigationService.GoForward("MainContent");
        }
    }
}
```

## INavigationAware 介面

### 說明

View 可實作 `INavigationAware` 介面以接收導航事件通知，用於初始化、狀態保存與資源釋放。

### 使用方法

```csharp
public class DetailView : UserControl, INavigationAware
{
    private readonly ILogger _logger;
    private int _itemId;
    private bool _hasUnsavedChanges;
    
    public DetailView(ILogger logger)
    {
        _logger = logger;
    }
    
    // 導航進入時呼叫
    public void OnNavigatedTo(INavigationParameters parameters)
    {
        _itemId = parameters.GetValue<int>("ItemId");
        var mode = parameters.GetValue<string>("Mode");
        
        _logger.Information("進入 DetailView, ItemId: {ItemId}", _itemId);
        LoadData(_itemId);
    }
    
    // 導航離開後呼叫
    public void OnNavigatedFrom(INavigationParameters parameters)
    {
        _logger.Information("離開 DetailView");
    }
    
    // 導航離開前呼叫，可取消導航
    public bool OnNavigatingFrom(INavigationParameters parameters)
    {
        if (_hasUnsavedChanges)
        {
            var result = MessageBox.Show(
                "有未儲存的變更，確定要離開嗎？",
                "確認",
                MessageBoxButtons.YesNo);
            
            return result == DialogResult.Yes;
        }
        
        return true; // 允許導航
    }
}
```

## View 生命週期管理

### 說明

使用 `ViewLifetimeAttribute` 控制 View 的生命週期行為：

| IsAlive | 行為                    | 適用場景       |
| ------- | --------------------- | ---------- |
| `true`  | 全域生命週期，導航離開後不釋放       | 主頁面、儀表板    |
| `false` | 區域生命週期，Region 釋放時自動釋放 | 編輯頁面、暫時性頁面 |

### 使用方法

```csharp
// 全域生命週期：View 會被快取
[ViewLifetime(IsAlive = true)]
public class DashboardView : UserControl, INavigationAware
{
    // 此 View 只會建立一次，後續導航會重用同一個實例
    public void OnNavigatedTo(INavigationParameters parameters)
    {
        // 每次導航進入時重新整理資料
        RefreshData();
    }
    
    public void OnNavigatedFrom(INavigationParameters parameters) { }
    public bool OnNavigatingFrom(INavigationParameters parameters) => true;
}

// 區域生命週期：每次導航都建立新實例
[ViewLifetime(IsAlive = false)]
public class EditItemView : UserControl, INavigationAware
{
    // 此 View 每次導航都會建立新實例
    public void OnNavigatedTo(INavigationParameters parameters) { }
    public void OnNavigatedFrom(INavigationParameters parameters) { }
    public bool OnNavigatingFrom(INavigationParameters parameters) => true;
}
```

## 多 Region 支援

### 說明

支援同時存在多個 Region，可用於多重視窗或分頁結構。

### 使用方法

```csharp
public class MultiRegionForm : Form
{
    private readonly IRegionManager _regionManager;
    private readonly INavigationService _navigationService;
    private readonly Panel _leftPanel;
    private readonly Panel _rightPanel;
    
    public MultiRegionForm(IRegionManager regionManager, INavigationService navigationService)
    {
        _regionManager = regionManager;
        _navigationService = navigationService;

        // 建立 UI
        _leftPanel = new Panel { Dock = DockStyle.Left, Width = 200 };
        _rightPanel = new Panel { Dock = DockStyle.Fill };
        Controls.Add(_rightPanel);
        Controls.Add(_leftPanel);

        // 註冊多個 Region
        _regionManager.RegisterRegion("NavigationPanel", view =>
        {
            _leftPanel.Controls.Clear();
            if (view is Control c)
            {
                c.Dock = DockStyle.Fill;
                _leftPanel.Controls.Add(c);
            }
        });

        _regionManager.RegisterRegion("MainContent", view =>
        {
            _rightPanel.Controls.Clear();
            if (view is Control c)
            {
                c.Dock = DockStyle.Fill;
                _rightPanel.Controls.Add(c);
            }
        });
    }
    
    public void NavigateInMultipleRegions()
    {
        // 在左側 Region 顯示選單
        _navigationService.NavigateTo<MenuView>("NavigationPanel", 100);
        
        // 在右側 Region 顯示內容
        _navigationService.NavigateTo<ContentView>("MainContent", 200);
        
        // 查詢各 Region 的活動頁面
        var allPageIds = _regionManager.GetAllActivePageIds();
        // 結果: { "NavigationPanel": 100, "MainContent": 200 }
    }
}
```

## 頁面識別碼

### 說明

每次導航時需傳遞一個 `int` 作為頁面識別碼，用於追蹤和查詢目前各 Region 的活動頁面。

### 使用方法

```csharp
// 定義頁面識別碼常數
public static class PageIds
{
    public const int Dashboard = 1000;
    public const int MachineList = 1001;
    public const int MachineDetail = 1002;
    public const int WorkOrderList = 2001;
    public const int WorkOrderDetail = 2002;
}

// 使用頁面識別碼
_navigationService.NavigateTo<DashboardView>("MainContent", PageIds.Dashboard);

// 查詢活動頁面識別碼
var activePageId = _navigationService.GetActivePageId("MainContent");
if (activePageId == PageIds.Dashboard)
{
    // 目前在儀表板
}
```

## Autofac 註冊

### 服務註冊

導航服務已在 `NavigationModule` 中自動註冊：

```csharp
public class NavigationModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        // RegionManager (SingleInstance)
        builder.RegisterType<RegionManager>()
            .As<IRegionManager>()
            .SingleInstance();

        // NavigationService (SingleInstance)
        builder.RegisterType<NavigationService>()
            .As<INavigationService>()
            .SingleInstance();
    }
}
```

### View 註冊

View 需要在 Autofac 中註冊才能被導航服務解析：

```csharp
public class ViewModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterType<DashboardView>()
            .AsSelf()
            .InstancePerDependency();
        
        builder.RegisterType<DetailView>()
            .AsSelf()
            .InstancePerDependency();
        
        builder.RegisterType<EditItemView>()
            .AsSelf()
            .InstancePerDependency();
    }
}
```

### 非 Autofac 使用範例

如果不希望依賴 Autofac，可以透過 `NavigationManualExample` 手動建立 `RegionManager`：

```csharp
var regionManager = NavigationManualExample.CreateRegionManager();
NavigationManualExample.RegisterMainRegion(regionManager, view =>
{
    // 將 view 加入自訂的容器或記錄目前視圖
});
```

此片段展示如何在簡單的 Windows Forms 中註冊區域，並直接使用 `RegionManager` 控制導航邏輯。

## 介面參考

| 介面                      | 說明                            |
| ----------------------- | ----------------------------- |
| `IRegion`               | Region 介面，代表邏輯上的 UI 容器        |
| `IRegionManager`        | Region 管理介面，管理所有 Region 的生命週期 |
| `INavigationService`    | 導航服務介面，提供統一的導航操作              |
| `INavigationJournal`    | 導航歷史紀錄介面，支援 Back/Forward      |
| `INavigationAware`      | 導航事件通知介面，用於接收導航事件             |
| `INavigationParameters` | 導航參數介面，用於頁面間傳遞資料              |

## 版本歷史

### v0.0.1

2026.01.23

- 由 Calin.Framework 抽出為獨立模組。
- 移除對 Calin.Logging 的依賴，改為依賴 Calin.Abstractions.Logging。

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
