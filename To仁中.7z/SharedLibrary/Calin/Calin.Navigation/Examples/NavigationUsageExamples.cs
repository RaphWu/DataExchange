#if DEBUG

/*
 * ���d���ɬ��ª� Calin.Navigation v0.0.1 �M��ק�L�Ӫ��C
 */

using Calin.Logging.Abstractions;

namespace Calin.Navigation.Examples
{
    /// <summary>
    /// �`�� Region �W�ٱ`�ơC
    /// </summary>
    internal class RegionNamesExample
    {
        internal const string MainRegion = "MainRegion";
        internal const string NavigationPanel = "NavigationPanel";
    }

    /// <summary>
    /// �ɯ�A�Ȩϥνd�ҡC
    /// </summary>
    /// <remarks>
    /// <para>�����O�ȥΩ�i�ܾɯ�A�Ȫ��ϥΤ覡�A�����b�Ͳ����Ҥ������ϥΡC</para>
    /// </remarks>
    public static class NavigationUsageExamples
    {
        #region Region ���U�d��

        /// <summary>
        /// �i�ܦp����U Region�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class MainForm : Form
        /// {
        ///     private readonly IRegionNavigation _navigation;
        ///     private readonly Panel _contentPanel;
        ///     
        ///     public MainForm(IRegionNavigation navigation)
        ///     {
        ///         _navigation = navigation;
        ///         _contentPanel = new Panel { Dock = DockStyle.Fill };
        ///         Controls.Add(_contentPanel);
        ///         
        ///         // ���U Region�A�N Panel �@�� UI �e��
        ///         _navigation.RegisterRegion(
        ///             nameof(MainContent),
        ///             view =>
        ///             {
        ///                 // �Ұ� View �ɡG�M���¤��e�å[�J�s View
        ///                 _contentPanel.Controls.Clear();
        ///                 if (view is Control control)
        ///                 {
        ///                     control.Dock = DockStyle.Fill;
        ///                     _contentPanel.Controls.Add(control);
        ///                 }
        ///             },
        ///             view =>
        ///             {
        ///                 // ���� View �ɡG�q�e������
        ///                 if (view is Control control)
        ///                 {
        ///                     _contentPanel.Controls.Remove(control);
        ///                 }
        ///             });
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void RegisterRegionExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �ɯ�d��

        /// <summary>
        /// �i�ܦp��i��򥻾ɯ�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class NavigationController
        /// {
        ///     private readonly IRegionNavigation _navigation;
        ///     
        ///     public NavigationController(IRegionNavigation navigation)
        ///     {
        ///         _navigation = navigation;
        ///     }
        ///     
        ///     public void NavigateToDetail(int itemId)
        ///     {
        ///         // �إ߾ɯ�Ѽ�
        ///         var parameters = new NavigationParameters();
        ///         parameters.Add("ItemId", itemId);
        ///         parameters.Add("Mode", "Edit");
        ///         
        ///         // �ϥΪx���ɯ�� DetailView
        ///         var result = _navigation.NavigateTo&lt;DetailView&gt;(
        ///             RegionNamesExample.MainContent,  // Region �W��
        ///             parameters);    // �ɯ�Ѽ�
        ///         
        ///         if (!result.Success)
        ///         {
        ///             MessageBox.Show($"�ɯ襢��: {result.ErrorMessage}");
        ///         }
        ///     }
        ///     
        ///     public void NavigateByViewName()
        ///     {
        ///         // �ϥ� ViewName �ɯ�]�ݥ����U View�^
        ///         _navigation.RegisterView&lt;DashboardView&gt;(nameof(Dashboard));
        ///         _navigation.NavigateTo(RegionNamesExample.MainContent, nameof(Dashboard));
        ///     }
        ///     
        ///     public void GoBack()
        ///     {
        ///         if (_navigation.CanGoBack(RegionNamesExample.MainContent))
        ///         {
        ///             _navigation.GoBack(RegionNamesExample.MainContent);
        ///         }
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void NavigationExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �ɯ�ƥ�d��

        /// <summary>
        /// �i�ܦp���ť�ɯ�ƥ�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class NavigationMonitor
        /// {
        ///     public NavigationMonitor(IRegionNavigation navigation)
        ///     {
        ///         // �ɯ�e�ƥ�]�i�����ɯ�^
        ///         navigation.Navigating += (sender, e) =>
        ///         {
        ///             Console.WriteLine($"�ǳƾɯ��: {e.TargetViewName}");
        ///             
        ///             // �i�ھڱ�������ɯ�
        ///             if (e.TargetViewName == "RestrictedView")
        ///             {
        ///                 e.Cancel = true;
        ///             }
        ///         };
        ///         
        ///         // �ɯ觹���ƥ�
        ///         navigation.Navigated += (sender, e) =>
        ///         {
        ///             Console.WriteLine($"�w�ɯ��: {e.ViewName}");
        ///         };
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void NavigationEventExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region INavigationAware ��@�d��

        /// <summary>
        /// �i�ܦp���@ INavigationAware �����C
        /// </summary>
        /// <example>
        /// <code>
        /// public class DetailView : UserControl, INavigationAware
        /// {
        ///     private readonly ILogger _logger;
        ///     private int _itemId;
        ///     private bool _hasUnsavedChanges;
        ///     
        ///     public DetailView(ILogger logger)
        ///     {
        ///         _logger = logger;
        ///     }
        ///     
        ///     public void OnNavigatedTo(INavigationParameters parameters)
        ///     {
        ///         // �ɯ�i�J�ɪ���l��
        ///         _itemId = parameters.GetValue&lt;int&gt;("ItemId");
        ///         var mode = parameters.GetValue&lt;string&gt;("Mode");
        ///         
        ///         _logger.Information("�i�J DetailView, ItemId: {ItemId}, Mode: {Mode}", _itemId, mode);
        ///         
        ///         // ���J���
        ///         LoadData(_itemId);
        ///     }
        ///     
        ///     public void OnNavigatedFrom(INavigationParameters parameters)
        ///     {
        ///         // �ɯ����}�ɫO�s���A�βM�z�귽
        ///         _logger.Information("���} DetailView");
        ///     }
        ///     
        ///     public bool OnNavigatingFrom(INavigationParameters parameters)
        ///     {
        ///         // �ˬd�O�_�����x�s���ܧ�
        ///         if (_hasUnsavedChanges)
        ///         {
        ///             var result = MessageBox.Show(
        ///                 "�����x�s���ܧ�A�T�w�n���}�ܡH",
        ///                 "�T�{",
        ///                 MessageBoxButtons.YesNo);
        ///             
        ///             return result == DialogResult.Yes;
        ///         }
        ///         
        ///         return true; // ���\�ɯ�
        ///     }
        ///     
        ///     private void LoadData(int itemId)
        ///     {
        ///         // ���J���ظ��
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void NavigationAwareExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region ViewLifetime �ݩʽd��

        /// <summary>
        /// �i�ܦp��ϥ� ViewLifetime �ݩʱ��� View �ͩR�g���C
        /// </summary>
        /// <example>
        /// <code>
        /// // IsAlive = true: View �|�Q�֨��A�ɯ����}�ᤣ����
        /// [ViewLifetime(IsAlive = true)]
        /// public class DashboardView : UserControl, INavigationAware
        /// {
        ///     // �� View �u�|�إߤ@���A����ɯ�|���ΦP�@�ӹ��
        ///     // �A�X��D�n�����B�����O���ݭn�O�����A������
        ///     
        ///     public void OnNavigatedTo(INavigationParameters parameters)
        ///     {
        ///         // �C���ɯ�i�J�ɷ|�Q�I�s
        ///         // �i�Ω󭫷s��z���
        ///     }
        ///     
        ///     public void OnNavigatedFrom(INavigationParameters parameters) { }
        ///     public bool OnNavigatingFrom(INavigationParameters parameters) => true;
        /// }
        /// 
        /// // IsAlive = false (�w�]): View �|�b Region ����ɦ۰�����
        /// [ViewLifetime(IsAlive = false)]
        /// public class EditItemView : UserControl, INavigationAware
        /// {
        ///     // �� View �C���ɯ賣�|�إ߷s���
        ///     // �A�X��s�譶���B�Ȯɩʭ���
        ///     
        ///     public void OnNavigatedTo(INavigationParameters parameters) { }
        ///     public void OnNavigatedFrom(INavigationParameters parameters) { }
        ///     public bool OnNavigatingFrom(INavigationParameters parameters) => true;
        /// }
        /// </code>
        /// </example>
        public static void ViewLifetimeExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region ViewName �ݩʽd��

        /// <summary>
        /// �i�ܦp��ϥ� ViewName �ݩʡC
        /// </summary>
        /// <example>
        /// <code>
        /// // �ϥ� ViewNameAttribute ���w�W��
        /// [ViewName("Dashboard")]
        /// public class DashboardView : UserControl
        /// {
        ///     // ViewName �� "Dashboard"
        /// }
        /// 
        /// // �����w�h�ϥ� Type.Name
        /// public class DetailView : UserControl
        /// {
        ///     // ViewName �� "DetailView"
        /// }
        /// 
        /// // �ϥΤ覡
        /// public void Example(IRegionNavigation navigation)
        /// {
        ///     // ���U View ��i�H�ϥ� ViewName �ɯ�
        ///     navigation.RegisterView&lt;DashboardView&gt;();
        ///     navigation.NavigateTo(nameof(MainContent), "Dashboard");
        ///     
        ///     // �Ϊ����ϥ� Type.Name
        ///     navigation.RegisterView&lt;DetailView&gt;();
        ///     navigation.NavigateTo(nameof(MainContent), "DetailView");
        /// }
        /// </code>
        /// </example>
        public static void ViewNameExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region ���� View �d��

        /// <summary>
        /// �i�ܦp������ View�C
        /// </summary>
        /// <example>
        /// <code>
        /// public void ReleaseViewExamples(IRegionNavigation navigation, object viewInstance)
        /// {
        ///     // �̹������
        ///     navigation.ReleaseView(viewInstance);
        ///     
        ///     // �� ViewName ����
        ///     navigation.ReleaseView(nameof(Dashboard));
        ///     
        ///     // ����������
        ///     navigation.ReleaseView&lt;DashboardView&gt;();
        ///     
        ///     // ������w Region ���Ҧ��D�ä[�ͩR�g���� View
        ///     navigation.ReleaseAllViews(nameof(MainContent));
        /// }
        /// </code>
        /// </example>
        public static void ReleaseViewExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region �h Region �d��

        /// <summary>
        /// �i�ܦp��ϥΦh�� Region�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class MultiRegionForm : Form
        /// {
        ///     private readonly IRegionNavigation _navigation;
        ///     private readonly Panel _leftPanel;
        ///     private readonly Panel _rightPanel;
        ///     
        ///     public MultiRegionForm(IRegionNavigation navigation)
        ///     {
        ///         _navigation = navigation;
        ///         
        ///         InitializeComponents();
        ///         RegisterRegions();
        ///     }
        ///     
        ///     private void InitializeComponents()
        ///     {
        ///         // �إ� UI ����
        ///         _leftPanel = new Panel { Dock = DockStyle.Left, Width = 200 };
        ///         _rightPanel = new Panel { Dock = DockStyle.Fill };
        ///         
        ///         Controls.Add(_rightPanel);
        ///         Controls.Add(_leftPanel);
        ///     }
        ///     
        ///     private void RegisterRegions()
        ///     {
        ///         // �����ɯ譱�O Region
        ///         _navigation.RegisterRegion(nameof(NavigationPanel), view =>
        ///         {
        ///             _leftPanel.Controls.Clear();
        ///             if (view is Control c) { c.Dock = DockStyle.Fill; _leftPanel.Controls.Add(c); }
        ///         });
        ///         
        ///         // �k���D�n���e Region
        ///         _navigation.RegisterRegion(nameof(MainContent), view =>
        ///         {
        ///             _rightPanel.Controls.Clear();
        ///             if (view is Control c) { c.Dock = DockStyle.Fill; _rightPanel.Controls.Add(c); }
        ///         });
        ///     }
        ///     
        ///     public void NavigateInMultipleRegions()
        ///     {
        ///         // �b���� Region ��ܿ��
        ///         _navigation.NavigateTo&lt;MenuView&gt;(nameof(NavigationPanel));
        ///         
        ///         // �b�k�� Region ��ܤ��e
        ///         _navigation.NavigateTo&lt;ContentView&gt;(nameof(MainContent));
        ///         
        ///         // �d�ߦU Region ������ View
        ///         var allViewNames = _navigation.GetAllActiveViewNames();
        ///         // allViewNames = { nameof(NavigationPanel): nameof(MenuView), nameof(MainContent): nameof(ContentView) }
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void MultiRegionExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion

        #region Autofac ���U�d��

        /// <summary>
        /// �i�ܦp��b Autofac �����U View�C
        /// </summary>
        /// <example>
        /// <code>
        /// public class ViewModule : Module
        /// {
        ///     protected override void Load(ContainerBuilder builder)
        ///     {
        ///         // ���U View (InstancePerDependency)
        ///         // �C���ѪR���|�إ߷s���
        ///         builder.RegisterType&lt;DashboardView&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///         
        ///         builder.RegisterType&lt;DetailView&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///         
        ///         builder.RegisterType&lt;EditItemView&gt;()
        ///             .AsSelf()
        ///             .InstancePerDependency();
        ///     }
        /// }
        /// 
        /// // �ϥΤ覡
        /// public void ConfigureContainer()
        /// {
        ///     var builder = new ContainerBuilder();
        ///     builder.RegisterModule&lt;NavigationModule&gt;();
        ///     builder.RegisterModule&lt;ViewModule&gt;();
        ///     var container = builder.Build();
        ///     
        ///     var navigation = container.Resolve&lt;IRegionNavigation&gt;();
        /// }
        /// </code>
        /// </example>
        public static void AutofacRegistrationExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion


        #region �D DI �ϥνd��

        /// <summary>
        /// ����²�檺��ʽd�ҡA�i�ܦp��b���ϥ� DI �ɫإ� RegionNavigation�C
        /// �ϥηs�� Calin.Logging�]�z�L LoggingBridge ���o ILogger�^�C
        /// </summary>
        public static class NavigationManualExample
        {
            /// <summary>
            /// �إߤ��̿� DI �� RegionNavigation ��ҡC
            /// </summary>
            /// <returns>IRegionNavigation ��ҡC</returns>
            public static INavigation CreateRegionNavigation()
            {
                // �ϥ� Activator �@���w�] ViewFactory�A�óz�L LoggingBridge ���o ILogger
                return new RegionNavigationSimple(type => Activator.CreateInstance(type), LoggingBridge.CreateLogger<RegionNavigationSimple>());
            }

            /// <summary>
            /// �ϥΦۭq ViewFactory �إ� RegionNavigation ��ҡC
            /// </summary>
            /// <param name="viewFactory">View �u�t��ơC</param>
            /// <returns>IRegionNavigation ��ҡC</returns>
            public static INavigation CreateRegionNavigation(Func<Type, object> viewFactory)
            {
                return new RegionNavigationSimple(viewFactory, LoggingBridge.CreateLogger<RegionNavigationSimple>());
            }

            /// <summary>
            /// ���U�D�n���e Region ���d�ҡC
            /// </summary>
            /// <param name="navigation">�ɯ�A�ȡC</param>
            /// <param name="viewRenderer">View ��V�e���C</param>
            public static void RegisterMainRegion(INavigation navigation, Action<object> viewRenderer)
            {
                navigation.RegisterRegion(
                    RegionNamesExample.MainRegion,
                        view => viewRenderer?.Invoke(view));
            }

            /// <summary>
            /// ����ϥνd�ҡC
            /// </summary>
            /// <example>
            /// <code>
            /// // �إ߾ɯ�A��
            /// var navigation = NavigationManualExample.CreateRegionNavigation();
            /// 
            /// // �ϥΦۭq ViewFactory
            /// var navigationWithFactory = NavigationManualExample.CreateRegionNavigation(
            ///     type => Activator.CreateInstance(type));
            /// 
            /// // ���U Region
            /// NavigationManualExample.RegisterMainRegion(navigation, view =>
            /// {
            ///     if (view is Control control)
            ///     {
            ///         panel.Controls.Clear();
            ///         panel.Controls.Add(control);
            ///     }
            /// });
            /// 
            /// // �ɯ�
            /// navigation.NavigateTo&lt;DashboardView&gt;(RegionNamesExample.MainContent);
            /// </code>
            /// </example>
            public static void FullExample()
            {
                // �d�ҵ{���X�A�аѾ\�W�� XML ����
            }
        }

        #endregion

        #region View �W�٬d�߽d��

        /// <summary>
        /// �i�ܦp��d�߬��� View �W�١C
        /// </summary>
        /// <example>
        /// <code>
        /// public void QueryActiveViewNames(IRegionNavigation navigation)
        /// {
        ///     // �d�߳�@ Region ������ View �W��
        ///     var viewName = navigation.GetActiveViewName(nameof(MainContent));
        ///     if (viewName == nameof(DashboardView))
        ///     {
        ///         // �ثe�b�����O
        ///     }
        ///     
        ///     // �d�ߩҦ� Region ������ View �W��
        ///     var allViewNames = navigation.GetAllActiveViewNames();
        ///     foreach (var kvp in allViewNames)
        ///     {
        ///         Console.WriteLine($"Region: {kvp.Key}, View: {kvp.Value}");
        ///     }
        /// }
        /// </code>
        /// </example>
        public static void QueryActiveViewNamesExample()
        {
            // �d�ҵ{���X�A�аѾ\�W�� XML ����
        }

        #endregion
    }
}

#endif
