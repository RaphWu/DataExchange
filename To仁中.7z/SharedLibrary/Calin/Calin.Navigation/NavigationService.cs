﻿using System.Collections.Concurrent;
using System.Reflection;
using Autofac;
using Calin.Abstractions.Logging;

namespace Calin.Navigation
{
    /// <summary>
    /// 提供導航功能，管理區域中的視圖導航。
    /// </summary>
    public class NavigationService : INavigationService
    {
        private readonly IRegionManager _regionManager;
        private readonly ILifetimeScope _lifetimeScope;
        private readonly ICalinLogger _logger;

        // 用於保存 IsAlive = true 的視圖實例
        private readonly ConcurrentDictionary<Type, object> _aliveViewCache = new ConcurrentDictionary<Type, object>();

        // 保存 IsAlive = false 的視圖及其對應的 LifetimeScope
        private readonly ConcurrentDictionary<object, ILifetimeScope> _viewScopes = new ConcurrentDictionary<object, ILifetimeScope>();

        /// <summary>
        /// 初始化導航服務。
        /// </summary>
        /// <param name="regionManager">區域管理器。</param>
        /// <param name="lifetimeScope">Autofac 的依賴注入範圍。</param>
        /// <param name="logger">日誌記錄器。</param>
        public NavigationService(IRegionManager regionManager, ILifetimeScope lifetimeScope, ICalinLogger logger)
        {
            _regionManager = regionManager ?? throw new ArgumentNullException(nameof(regionManager));
            _lifetimeScope = lifetimeScope ?? throw new ArgumentNullException(nameof(lifetimeScope));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <inheritdoc />
        public NavigationResult NavigateTo<TView>(string regionName, int pageId, INavigationParameters parameters = null) where TView : class
        {
            return NavigateTo(typeof(TView), regionName, pageId, parameters);
        }

        /// <inheritdoc />
        public NavigationResult NavigateTo(Type viewType, string regionName, int pageId, INavigationParameters parameters = null)
        {
            if (viewType == null)
                return NavigationResult.Failed("視圖類型不能為 null。");

            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("區域名稱不能為空。");

            try
            {
                var region = _regionManager.GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"區域 '{regionName}' 不存在。");
                }

                parameters = parameters ?? new NavigationParameters();

                // 檢查當前視圖是否允許導航
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    _logger.Debug($"導航被當前視圖拒絕: {regionName}");
                    return NavigationResult.Failed("導航被當前視圖拒絕。");
                }

                // 通知當前視圖即將離開
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // 獲取或創建新的視圖
                var view = ResolveView(viewType);

                // 激活新視圖
                region.Activate(view, pageId);

                // 記錄導航日誌
                var entry = new NavigationJournalEntry(pageId, viewType, parameters);
                region.NavigationJournal.RecordNavigation(entry);

                // 通知新視圖已導航到
                NotifyNavigatedTo(view, parameters);

                _logger.Debug($"導航成功: {regionName} -> {viewType.Name}, PageId: {pageId}");
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _logger.Error($"導航失敗: {regionName} -> {viewType?.Name}", ex);
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public NavigationResult GoBack(string regionName, INavigationParameters parameters = null)
        {
            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("區域名稱不能為空。");

            try
            {
                var region = _regionManager.GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"區域 '{regionName}' 不存在。");
                }

                if (!region.NavigationJournal.CanGoBack)
                {
                    return NavigationResult.Failed("無法返回，導航日誌中沒有上一頁記錄。");
                }

                parameters = parameters ?? new NavigationParameters();

                // 檢查當前視圖是否允許導航
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    return NavigationResult.Failed("當前視圖拒絕導航。");
                }

                // 通知當前視圖即將離開
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // 獲取上一個導航記錄
                var entry = region.NavigationJournal.GoBack();

                // 獲取對應的視圖
                var view = ResolveView(entry.ViewType);

                // 激活視圖
                region.Activate(view, entry.PageId);

                // 合併導航參數
                var mergedParameters = MergeParameters(entry.Parameters, parameters);

                // 通知新視圖已導航到
                NotifyNavigatedTo(view, mergedParameters);

                _logger.Debug($"返回成功: {regionName} -> {entry.ViewType.Name}, PageId: {entry.PageId}");
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _logger.Error($"返回失敗: {regionName}", ex);
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public NavigationResult GoForward(string regionName, INavigationParameters parameters = null)
        {
            if (string.IsNullOrEmpty(regionName))
                return NavigationResult.Failed("區域名稱不能為空。");

            try
            {
                var region = _regionManager.GetRegion(regionName);
                if (region == null)
                {
                    return NavigationResult.Failed($"區域 '{regionName}' 不存在。");
                }

                if (!region.NavigationJournal.CanGoForward)
                {
                    return NavigationResult.Failed("無法前進，導航日誌中沒有下一頁記錄。");
                }

                parameters = parameters ?? new NavigationParameters();

                // 檢查當前視圖是否允許導航
                if (!CanNavigateFrom(region.ActiveView, parameters))
                {
                    return NavigationResult.Failed("當前視圖拒絕導航。");
                }

                // 通知當前視圖即將離開
                NotifyNavigatedFrom(region.ActiveView, parameters);

                // 獲取下一個導航記錄
                var entry = region.NavigationJournal.GoForward();

                // 獲取對應的視圖
                var view = ResolveView(entry.ViewType);

                // 激活視圖
                region.Activate(view, entry.PageId);

                // 合併導航參數
                var mergedParameters = MergeParameters(entry.Parameters, parameters);

                // 通知新視圖已導航到
                NotifyNavigatedTo(view, mergedParameters);

                _logger.Debug($"前進成功: {regionName} -> {entry.ViewType.Name}, PageId: {entry.PageId}");
                return NavigationResult.Succeeded();
            }
            catch (Exception ex)
            {
                _logger.Error($"前進失敗: {regionName}", ex);
                return NavigationResult.Failed(ex);
            }
        }

        /// <inheritdoc />
        public bool CanGoBack(string regionName)
        {
            var region = _regionManager.GetRegion(regionName);
            return region?.NavigationJournal.CanGoBack ?? false;
        }

        /// <inheritdoc />
        public bool CanGoForward(string regionName)
        {
            var region = _regionManager.GetRegion(regionName);
            return region?.NavigationJournal.CanGoForward ?? false;
        }

        /// <inheritdoc />
        public int? GetActivePageId(string regionName)
        {
            return _regionManager.GetActivePageId(regionName);
        }

        /// <inheritdoc />
        public object GetActiveView(string regionName)
        {
            var region = _regionManager.GetRegion(regionName);
            return region?.ActiveView;
        }

        /// <inheritdoc />
        public void ReleaseView(object view)
        {
            if (view == null)
                return;

            var viewType = view.GetType();

            // 從緩存中移除
            _aliveViewCache.TryRemove(viewType, out _);

            // 釋放 LifetimeScope
            if (_viewScopes.TryRemove(view, out var scope))
            {
                scope.Dispose();
            }

            // 如果視圖實現了 IDisposable，則釋放資源
            if (view is IDisposable disposable)
            {
                disposable.Dispose();
            }

            _logger.Debug($"已釋放視圖: {viewType.Name}");
        }

        /// <summary>
        /// 獲取或創建視圖實例。
        /// </summary>
        private object ResolveView(Type viewType)
        {
            var isAlive = GetIsAlive(viewType);

            if (isAlive)
            {
                // 從緩存中獲取或創建永久實例
                return _aliveViewCache.GetOrAdd(viewType, type =>
                {
                    _logger.Debug($"創建永久生命週期視圖: {type.Name}");
                    return _lifetimeScope.Resolve(type);
                });
            }
            else
            {
                // 創建新的 LifetimeScope 並解析視圖
                var scope = _lifetimeScope.BeginLifetimeScope();
                var view = scope.Resolve(viewType);
                _viewScopes[view] = scope;

                _logger.Debug($"創建區域生命週期視圖: {viewType.Name}");
                return view;
            }
        }

        /// <summary>
        /// 獲取視圖的 IsAlive 設置。
        /// </summary>
        private bool GetIsAlive(Type viewType)
        {
            var attribute = viewType.GetCustomAttribute<ViewLifetimeAttribute>();
            return attribute?.IsAlive ?? false;
        }

        /// <summary>
        /// 檢查是否可以從當前視圖導航。
        /// </summary>
        private bool CanNavigateFrom(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                return aware.OnNavigatingFrom(parameters);
            }
            return true;
        }

        /// <summary>
        /// 通知當前視圖即將離開。
        /// </summary>
        private void NotifyNavigatedFrom(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                aware.OnNavigatedFrom(parameters);
            }
        }

        /// <summary>
        /// 通知新視圖已導航到。
        /// </summary>
        private void NotifyNavigatedTo(object view, INavigationParameters parameters)
        {
            if (view is INavigationAware aware)
            {
                aware.OnNavigatedTo(parameters);
            }
        }

        /// <summary>
        /// 合併導航參數。
        /// </summary>
        private INavigationParameters MergeParameters(INavigationParameters original, INavigationParameters additional)
        {
            var merged = new NavigationParameters();

            if (original != null)
            {
                foreach (var key in original.Keys)
                {
                    merged.Add(key, original.GetValue<object>(key));
                }
            }

            if (additional != null)
            {
                foreach (var key in additional.Keys)
                {
                    merged.Add(key, additional.GetValue<object>(key));
                }
            }

            return merged;
        }
    }
}





