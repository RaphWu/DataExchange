namespace Calin.Navigation
{
    /// <summary>
    /// �ɯ�ƥ�ѼơC
    /// </summary>
    public class NavigatingEventArgs : EventArgs
    {
        /// <summary>
        /// ���o Region �W�١C
        /// </summary>
        public string RegionName { get; }

        /// <summary>
        /// ���o�ؼ� View �W�١C
        /// </summary>
        public string TargetViewName { get; }

        /// <summary>
        /// ���o�ؼ� View �����C
        /// </summary>
        public Type TargetViewType { get; }

        /// <summary>
        /// ���o�ɯ�ѼơC
        /// </summary>
        public INavigationParameters Parameters { get; }

        /// <summary>
        /// ���o�γ]�w�O�_�����ɯ�C
        /// </summary>
        public bool Cancel { get; set; }

        /// <summary>
        /// ��l�� NavigatingEventArgs�C
        /// </summary>
        public NavigatingEventArgs(string regionName, string targetViewName, Type targetViewType, INavigationParameters parameters)
        {
            RegionName = regionName;
            TargetViewName = targetViewName;
            TargetViewType = targetViewType;
            Parameters = parameters;
        }
    }

    /// <summary>
    /// �ɯ觹���ƥ�ѼơC
    /// </summary>
    public class NavigatedEventArgs : EventArgs
    {
        /// <summary>
        /// ���o Region �W�١C
        /// </summary>
        public string RegionName { get; }

        /// <summary>
        /// ���o View �W�١C
        /// </summary>
        public string ViewName { get; }

        /// <summary>
        /// ���o View �����C
        /// </summary>
        public Type ViewType { get; }

        /// <summary>
        /// ���o View ��ҡC
        /// </summary>
        public object View { get; }

        /// <summary>
        /// ���o�ɯ�ѼơC
        /// </summary>
        public INavigationParameters Parameters { get; }

        /// <summary>
        /// ��l�� NavigatedEventArgs�C
        /// </summary>
        public NavigatedEventArgs(string regionName, string viewName, Type viewType, object view, INavigationParameters parameters)
        {
            RegionName = regionName;
            ViewName = viewName;
            ViewType = viewType;
            View = view;
            Parameters = parameters;
        }
    }
}
