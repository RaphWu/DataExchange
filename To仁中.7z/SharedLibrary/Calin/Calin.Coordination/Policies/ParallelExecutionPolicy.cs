namespace Calin.Coordination.Policies
{
    /// <summary>
    /// ������浦���C
    /// �P�ɰ���Ҧ� Task�A���ݥ��������C
    /// </summary>
    public class ParallelExecutionPolicy : ExecutionPolicyBase
    {
        private readonly int _maxDegreeOfParallelism;

        /// <inheritdoc/>
        public override string PolicyName => "Parallel";

        /// <summary>
        /// ��l�ƥ�����浦���C
        /// </summary>
        /// <param name="maxDegreeOfParallelism">�̤j����סC0 �έt�ƪ��ܤ�����C</param>
        public ParallelExecutionPolicy(int maxDegreeOfParallelism = 0)
        {
            _maxDegreeOfParallelism = maxDegreeOfParallelism;
        }

        /// <inheritdoc/>
        public override async Task ExecuteAsync(
            CoordinationSession session,
            IEnumerable<TaskKey> taskKeys,
            Func<TaskKey, ITaskHandler> handlerResolver,
            CancellationToken cancellationToken = default)
        {
            var tasks = taskKeys.ToList();

            if (_maxDegreeOfParallelism > 0)
            {
                await ExecuteWithThrottlingAsync(session, tasks, handlerResolver, cancellationToken);
            }
            else
            {
                await ExecuteAllParallelAsync(session, tasks, handlerResolver, cancellationToken);
            }
        }

        private async Task ExecuteAllParallelAsync(
            CoordinationSession session,
            List<TaskKey> taskKeys,
            Func<TaskKey, ITaskHandler> handlerResolver,
            CancellationToken cancellationToken)
        {
            var executionTasks = new List<Task>();

            foreach (var taskKey in taskKeys)
            {
                var handler = handlerResolver(taskKey);
                if (handler == null)
                {
                    session.MarkTaskFailed(taskKey,
                        new InvalidOperationException($"No handler registered for task '{taskKey}'."));
                    continue;
                }

                executionTasks.Add(ExecuteSingleTaskAsync(session, taskKey, handler, cancellationToken));
            }

            await Task.WhenAll(executionTasks);
        }

        private async Task ExecuteWithThrottlingAsync(
            CoordinationSession session,
            List<TaskKey> taskKeys,
            Func<TaskKey, ITaskHandler> handlerResolver,
            CancellationToken cancellationToken)
        {
            using (var semaphore = new SemaphoreSlim(_maxDegreeOfParallelism))
            {
                var executionTasks = new List<Task>();

                foreach (var taskKey in taskKeys)
                {
                    await semaphore.WaitAsync(cancellationToken);

                    var handler = handlerResolver(taskKey);
                    if (handler == null)
                    {
                        session.MarkTaskFailed(taskKey,
                            new InvalidOperationException($"No handler registered for task '{taskKey}'."));
                        semaphore.Release();
                        continue;
                    }

                    executionTasks.Add(ExecuteWithSemaphoreAsync(session, taskKey, handler, semaphore, cancellationToken));
                }

                await Task.WhenAll(executionTasks);
            }
        }

        private async Task ExecuteWithSemaphoreAsync(
            CoordinationSession session,
            TaskKey taskKey,
            ITaskHandler handler,
            SemaphoreSlim semaphore,
            CancellationToken cancellationToken)
        {
            try
            {
                await ExecuteSingleTaskAsync(session, taskKey, handler, cancellationToken);
            }
            finally
            {
                semaphore.Release();
            }
        }
    }
}
