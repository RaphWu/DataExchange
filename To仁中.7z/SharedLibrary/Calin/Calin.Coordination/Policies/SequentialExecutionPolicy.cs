namespace Calin.Coordination.Policies
{
    /// <summary>
    /// ���ǰ��浦���C
    /// �̧ǰ���Ҧ� Task�A�@�ӧ�����~����U�@�ӡC
    /// </summary>
    public class SequentialExecutionPolicy : ExecutionPolicyBase
    {
        /// <inheritdoc/>
        public override string PolicyName => "Sequential";

        /// <inheritdoc/>
        public override async Task ExecuteAsync(
            CoordinationSession session,
            IEnumerable<TaskKey> taskKeys,
            Func<TaskKey, ITaskHandler> handlerResolver,
            CancellationToken cancellationToken = default)
        {
            foreach (var taskKey in taskKeys)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var handler = handlerResolver(taskKey);
                if (handler == null)
                {
                    session.MarkTaskFailed(taskKey,
                        new InvalidOperationException($"No handler registered for task '{taskKey}'."));
                    continue;
                }

                await ExecuteSingleTaskAsync(session, taskKey, handler, cancellationToken);
            }
        }
    }
}
