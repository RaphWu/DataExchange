using Autofac;
using Autofac.Builder;

namespace Calin.Coordination
{
    /// <summary>
    /// ��ծج[�� Autofac �X�R��k�C
    /// </summary>
    public static class CoordinationContainerBuilderExtensions
    {
        /// <summary>
        /// ���U Task Handler�C
        /// </summary>
        /// <typeparam name="THandler">Handler �������C</typeparam>
        /// <param name="builder">�e���غc���C</param>
        /// <returns>���U�غc���C</returns>
        public static IRegistrationBuilder<THandler, ConcreteReflectionActivatorData, SingleRegistrationStyle>
            RegisterTaskHandler<THandler>(this ContainerBuilder builder)
            where THandler : class, ITaskHandler
        {
            return builder.RegisterType<THandler>()
                .As<ITaskHandler>()
                .SingleInstance();
        }

        /// <summary>
        /// ���U Task �M�g�����C
        /// </summary>
        /// <typeparam name="TStrategy">�����������C</typeparam>
        /// <param name="builder">�e���غc���C</param>
        /// <returns>���U�غc���C</returns>
        public static IRegistrationBuilder<TStrategy, ConcreteReflectionActivatorData, SingleRegistrationStyle>
            RegisterTaskMappingStrategy<TStrategy>(this ContainerBuilder builder)
            where TStrategy : class, ITaskMappingStrategy
        {
            return builder.RegisterType<TStrategy>()
                .As<ITaskMappingStrategy>()
                .SingleInstance();
        }

        /// <summary>
        /// ���U���浦���C
        /// </summary>
        /// <typeparam name="TPolicy">�����������C</typeparam>
        /// <param name="builder">�e���غc���C</param>
        /// <returns>���U�غc���C</returns>
        public static IRegistrationBuilder<TPolicy, ConcreteReflectionActivatorData, SingleRegistrationStyle>
            RegisterExecutionPolicy<TPolicy>(this ContainerBuilder builder)
            where TPolicy : class, IExecutionPolicy
        {
            return builder.RegisterType<TPolicy>()
                .As<IExecutionPolicy>()
                .SingleInstance();
        }

        /// <summary>
        /// ���U���G�o���̡C
        /// </summary>
        /// <typeparam name="TPublisher">�o���̪������C</typeparam>
        /// <param name="builder">�e���غc���C</param>
        /// <returns>���U�غc���C</returns>
        public static IRegistrationBuilder<TPublisher, ConcreteReflectionActivatorData, SingleRegistrationStyle>
            RegisterResultPublisher<TPublisher>(this ContainerBuilder builder)
            where TPublisher : class, IResultPublisher
        {
            return builder.RegisterType<TPublisher>()
                .As<IResultPublisher>()
                .SingleInstance();
        }
    }
}
