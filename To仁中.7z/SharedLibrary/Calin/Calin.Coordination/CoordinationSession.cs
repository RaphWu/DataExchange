namespace Calin.Coordination
{
    /// <summary>
    /// ��� Session ����@�C
    /// �l�ܳ榸��սШD�����檬�A�P���G�C
    /// </summary>
    public class CoordinationSession : ICoordinationSession
    {
        private readonly HashSet<TaskKey> _requiredTasks;
        private readonly HashSet<TaskKey> _completedTasks;
        private readonly Dictionary<TaskKey, Exception> _failedTasks;
        private readonly object _syncLock = new object();

        /// <inheritdoc/>
        public string SessionId { get; }

        /// <inheritdoc/>
        public ICoordinationRequest Request { get; }

        /// <inheritdoc/>
        public CoordinationSessionState State { get; private set; }

        /// <inheritdoc/>
        public IReadOnlyCollection<TaskKey> RequiredTasks
        {
            get { lock (_syncLock) { return _requiredTasks.ToList().AsReadOnly(); } }
        }

        /// <inheritdoc/>
        public IReadOnlyCollection<TaskKey> CompletedTasks
        {
            get { lock (_syncLock) { return _completedTasks.ToList().AsReadOnly(); } }
        }

        /// <inheritdoc/>
        public IReadOnlyCollection<TaskKey> PendingTasks
        {
            get
            {
                lock (_syncLock)
                {
                    return _requiredTasks
                        .Except(_completedTasks)
                        .Except(_failedTasks.Keys)
                        .ToList()
                        .AsReadOnly();
                }
            }
        }

        /// <inheritdoc/>
        public IReadOnlyDictionary<TaskKey, Exception> FailedTasks
        {
            get { lock (_syncLock) { return new Dictionary<TaskKey, Exception>(_failedTasks); } }
        }

        /// <inheritdoc/>
        public bool IsFinished => State == CoordinationSessionState.Completed
                                || State == CoordinationSessionState.Faulted
                                || State == CoordinationSessionState.Cancelled;

        /// <inheritdoc/>
        public bool IsSuccessful => State == CoordinationSessionState.Completed && _failedTasks.Count == 0;

        /// <inheritdoc/>
        public DateTime CreatedAt { get; }

        /// <inheritdoc/>
        public DateTime? StartedAt { get; private set; }

        /// <inheritdoc/>
        public DateTime? FinishedAt { get; private set; }

        /// <inheritdoc/>
        public TimeSpan? Duration => StartedAt.HasValue && FinishedAt.HasValue
            ? FinishedAt.Value - StartedAt.Value
            : null;

        /// <summary>
        /// ��l�ƨ�� Session�C
        /// </summary>
        /// <param name="request">Ĳ�o�� Session ���ШD�C</param>
        /// <param name="requiredTasks">�����ݰ��檺 TaskKey ���X�C</param>
        public CoordinationSession(ICoordinationRequest request, IEnumerable<TaskKey> requiredTasks)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));
            if (requiredTasks == null)
                throw new ArgumentNullException(nameof(requiredTasks));

            SessionId = Guid.NewGuid().ToString("N");
            Request = request;
            CreatedAt = DateTime.Now;
            State = CoordinationSessionState.Created;

            _requiredTasks = new HashSet<TaskKey>(requiredTasks);
            _completedTasks = new HashSet<TaskKey>();
            _failedTasks = new Dictionary<TaskKey, Exception>();
        }

        /// <summary>
        /// �аO Session �}�l����C
        /// </summary>
        internal void MarkStarted()
        {
            lock (_syncLock)
            {
                if (State != CoordinationSessionState.Created)
                    return;

                State = CoordinationSessionState.Running;
                StartedAt = DateTime.Now;
            }
        }

        /// <summary>
        /// �аO���w Task �w�����C
        /// </summary>
        /// <param name="taskKey">�w������ TaskKey�C</param>
        internal void MarkTaskCompleted(TaskKey taskKey)
        {
            lock (_syncLock)
            {
                if (!_requiredTasks.Contains(taskKey))
                    return;

                _completedTasks.Add(taskKey);
            }
        }

        /// <summary>
        /// �аO���w Task ���楢�ѡC
        /// </summary>
        /// <param name="taskKey">���Ѫ� TaskKey�C</param>
        /// <param name="exception">�o�ͪ��ҥ~�C</param>
        internal void MarkTaskFailed(TaskKey taskKey, Exception exception)
        {
            lock (_syncLock)
            {
                if (!_requiredTasks.Contains(taskKey))
                    return;

                _failedTasks[taskKey] = exception;
            }
        }

        /// <summary>
        /// �аO Session �w�����C
        /// </summary>
        internal void MarkCompleted()
        {
            lock (_syncLock)
            {
                if (IsFinished)
                    return;

                State = _failedTasks.Count > 0
                    ? CoordinationSessionState.Faulted
                    : CoordinationSessionState.Completed;
                FinishedAt = DateTime.Now;
            }
        }

        /// <summary>
        /// �аO Session �o�Ϳ��~�C
        /// </summary>
        internal void MarkFaulted()
        {
            lock (_syncLock)
            {
                if (IsFinished)
                    return;

                State = CoordinationSessionState.Faulted;
                FinishedAt = DateTime.Now;
            }
        }

        /// <summary>
        /// �аO Session �w�����C
        /// </summary>
        internal void MarkCancelled()
        {
            lock (_syncLock)
            {
                if (IsFinished)
                    return;

                State = CoordinationSessionState.Cancelled;
                FinishedAt = DateTime.Now;
            }
        }

        /// <inheritdoc/>
        public override string ToString()
        {
            return $"Session[{SessionId}] State={State}, " +
                   $"Tasks: {_completedTasks.Count}/{_requiredTasks.Count} completed, " +
                   $"{_failedTasks.Count} failed";
        }
    }
}
