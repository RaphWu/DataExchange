namespace Calin.Coordination
{
    /// <summary>
    /// �w�q��յ��G�������C
    /// </summary>
    public interface ICoordinationResult
    {
        /// <summary>
        /// ���o��� Session�C
        /// </summary>
        ICoordinationSession Session { get; }

        /// <summary>
        /// ���o��լO�_���\�C
        /// </summary>
        bool IsSuccess { get; }

        /// <summary>
        /// ���o�Ҧ����楢�Ѫ� Task �P�ҥ~�C
        /// </summary>
        IReadOnlyDictionary<TaskKey, Exception> Errors { get; }
    }

    /// <summary>
    /// ��յ��G����@�C
    /// </summary>
    public class CoordinationResult : ICoordinationResult
    {
        /// <inheritdoc/>
        public ICoordinationSession Session { get; }

        /// <inheritdoc/>
        public bool IsSuccess { get; }

        /// <inheritdoc/>
        public IReadOnlyDictionary<TaskKey, Exception> Errors { get; }

        /// <summary>
        /// ��l�ƨ�յ��G�C
        /// </summary>
        /// <param name="session">��� Session�C</param>
        public CoordinationResult(ICoordinationSession session)
        {
            Session = session ?? throw new ArgumentNullException(nameof(session));
            IsSuccess = session.IsSuccessful;
            Errors = session.FailedTasks;
        }
    }
}
