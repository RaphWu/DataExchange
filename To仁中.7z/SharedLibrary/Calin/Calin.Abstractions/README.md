﻿# Calin.Abstractions

## 概述

`Calin.Abstractions` 提供 Calin 模組系統的共用抽象介面，不包含任何第三方套件相依。

## 設計原則

- 不暴露任何第三方框架型別（如 Serilog、Autofac、MEL）
- 作為 Core 層專案的唯一相依
- 介面簡潔，僅提供必要功能

## 目標框架（Target Frameworks）

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

## 命名空間結構

```text
Calin.Abstractions/
├── AbstractionsModule.cs       # Autofac 註冊模組（提供預設 No-Op 註冊）
└── Logging/
    ├── ICalinLogger.cs         # 日誌抽象介面
    ├── NoOpLogger.cs           # 空實作（內部使用）
    └── CalinLoggerFactory.cs   # 工廠方法
```

---

## Logging 抽象

### ICalinLogger

簡化的日誌介面，提供四個基本方法：

```csharp
public interface ICalinLogger
{
    void Debug(string message);
    void Information(string message);
    void Warning(string message);
    void Error(string message, Exception? ex = null);
}
```

### 使用方式

Core 專案只需引用 `Calin.Abstractions`，注入 `ICalinLogger`：

```csharp
using Calin.Abstractions.Logging;

public class MyService
{
    private readonly ICalinLogger _logger;
    
    public MyService(ICalinLogger logger)
    {
        _logger = logger;
    }
    
    public void DoWork()
    {
        _logger.Information("開始處理");
        
        try
        {
            // 執行操作
        }
        catch (Exception ex)
        {
            _logger.Error("處理失敗", ex);
        }
    }
}
```

### NoOpLogger

如果不需要日誌輸出，可使用 `CalinLoggerFactory.CreateNoOpLogger()`：

```csharp
using Calin.Abstractions.Logging;

var noOpLogger = CalinLoggerFactory.CreateNoOpLogger();
var service = new MyService(noOpLogger);
```

---

## Autofac 註冊（AbstractionsModule）

為了讓未引用 `Calin.Logging` 的應用仍可在 DI 中解析 `ICalinLogger`，本專案提供 `AbstractionsModule`：

- 會將 `ICalinLogger` 註冊為 `No-Op` 預設實作
- 使用 `IfNotRegistered(typeof(ICalinLogger))`，因此若 Composition Root 同時註冊了 `Calin.Logging` 的 `LoggingModule`，真實實作會優先生效

> 注意：`Calin.Abstractions` 的設計原則仍是不讓「抽象介面」暴露第三方型別；DI 註冊檔僅供 Composition Root 使用。

使用範例（Composition Root）：

```csharp
using Autofac;
using Calin.Abstractions;

var builder = new ContainerBuilder();
builder.RegisterModule<AbstractionsModule>();
```

## 與 Calin.Logging 的關係

| 層級  | 專案                 | 說明                  |
| --- | ------------------ | ------------------- |
| 抽象層 | Calin.Abstractions | 定義介面，對使用者不暴露第三方框架型別 |
| 實作層 | Calin.Logging      | Serilog 實作，包含完整功能   |

- **Core 專案**（如 Calin.Coordination、Calin.Navigation）僅引用 `Calin.Abstractions`
- **App / Composition Root** 引用 `Calin.Logging` 並註冊 `LoggingModule`
- 若只註冊 `AbstractionsModule`，則 `ICalinLogger` 會解析為 No-Op logger

## 驗收條件

- Core 專案可獨立編譯，不依賴 Logging Infrastructure
- 抽象層對一般使用者不可見
- 注入 `ICalinLogger` 後可直接使用，不需額外初始化

## 版本歷史

### v0.0.3

2026.01.30

- 命名合理化與簡化的修改：
  - `Calin.Extensions` 下的擴充方法結尾從 `Extensions` 改為 `Ext`。例如從 `StringExtensions` 改為 `StringExt`。
  - 命名空間 `Calin.Helper` 改為 `Calin.Helpers`。
- 新增 `Calin.MVVM.ObservableObject`，作為實現 `INotifyPropertyChanged` 介面的基底類別，用於通知屬性值的變更。

### v0.0.2

2026.01.26

- 新增 AbstractionsModule，提供 Autofac 註冊模組。

### v0.0.1

2026.01.25

- 初版。

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
