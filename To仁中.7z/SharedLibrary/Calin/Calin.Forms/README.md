﻿# Calin.Forms

## 介紹

`Calin.Forms` 是一個 WinForm 常用的對話框類別庫，提供了多種自訂化的對話框功能，方便開發者在 Windows Forms 應用程式中使用。

## 目標框架（Target Frameworks）

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0 (`net8.0-windows`)

## 相依套件

### 必要

- `Microsoft.Extensions.Logging.Abstractions`：提供 `ILogger` 介面與相關抽象類別。
    - 注意：為保持與 .NET Framework 4.6.2 的相容性，使用版本為 `8.0.0`。
- `Calin.Logging`：日誌記錄功能，用於記錄導航過程中的重要事件與錯誤。

### 選用

- `Autofac`：依賴注入容器，用於管理對話框元件的生命週期與解析。
  - 專案有提供模組註冊檔，可透過 `FormsModule` 快速完成註冊。

## 模組說明

- **Calin.Forms.Dialog**：提供基本的對話框功能，支援多種自訂化選項，適用於一般訊息提示或確認操作。
- **Calin.Forms.LoadingDialog**：提供載入中對話框，適用於顯示長時間操作的進度或等待狀態。

### 非 Autofac 使用範例

如果不使用 Autofac，亦可手動建立元件，例如直接顯示 `LoadingDialog`，不需依賴任何 DI 容器：

```csharp
FormsManualExample.ShowLoadingDialogWhile(() =>
{
    // 執行同步工作，例如載入設定或初始化資料
}, "系統啟動中...");
```

此範例位於 `Calin.Forms/Examples/FormsManualExample.cs`，示範不安裝 Autofac 時如何直接顯示 loading 畫面。

## 版本歷史

### v0.0.1

2026.01.23

- 由 Calin.Framework 抽出為獨立模組。
- 移除對 Calin.Logging 的依賴，改為依賴 Calin.Abstractions.Logging。

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
