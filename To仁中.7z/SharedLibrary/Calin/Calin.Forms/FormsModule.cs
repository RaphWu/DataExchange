﻿using Autofac;
using Calin.Forms.Dialog;

namespace Calin.Forms
{
    public class FormsModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterModule<DialogModule>();
            builder.RegisterType<LoadingDialog>().ExternallyOwned();
        }
    }
}
