﻿
# TaskPulse Dialog Module

## 介紹

TaskPulse Dialog 模組是 `Calin.Forms` 命名空間下負責對話框管理的子模組。它提供了可擴充、可測試、低耦合的對話框管理架構，支援模態與非模態對話框。

## 整體架構流程圖

```mermaid
flowchart TB
    subgraph UI["UI Layer"]
        Controller["Controller / ViewModel"]
        DialogContent["Dialog Content<br/>(UserControl)"]
        DialogWindow["Dialog Window<br/>(Form)"]
    end

    subgraph Dialog["Dialog Module"]
        DialogService["DialogService<br/>(對話框服務)"]
        DialogWindowFactory["DialogWindowFactory<br/>(視窗工廠)"]
    end

    subgraph DI["Autofac DI"]
        LifetimeScope["LifetimeScope"]
    end

    Controller -->|ShowDialog| DialogService
    DialogService -->|建立視窗| DialogWindowFactory
    DialogService -->|解析內容| LifetimeScope
    LifetimeScope -->|建立| DialogContent
    DialogWindowFactory -->|建立| DialogWindow
    DialogWindow -->|容納| DialogContent
```

## 核心元件

### 設計重點

| 元件                    | 職責      | 注意事項         |
| --------------------- | ------- | ------------ |
| **IDialogService**    | 對話框管理介面 | 單例，處理顯示邏輯    |
| **IDialogAware**      | 對話框事件通知 | 對話框內容需實作     |
| **IDialogParameters** | 參數傳遞    | Key-Value 存取 |
| **IDialogResult**     | 返回結果封裝  | 包含結果類型與參數    |
| **IDialogWindow**     | 視窗抽象    | 與 UI 框架解耦    |
| **DialogBase**        | 對話框基底類別 | 簡化實作         |

## 模態對話框

### 說明

模態對話框會阻塞父視窗，直到對話框關閉。適用於需要使用者回應的場景。

### 使用方法

```csharp
public class OrderController
{
    private readonly IDialogService _dialogService;
    
    public OrderController(IDialogService dialogService)
    {
        _dialogService = dialogService;
    }
    
    public void DeleteOrder(int orderId)
    {
        // 建立參數
        var parameters = new DialogParameters();
        parameters.Add("Title", "確認刪除");
        parameters.Add("Message", $"確定要刪除訂單 #{orderId} 嗎？");
        parameters.Add("OrderId", orderId);
        
        // 顯示模態對話框
        var result = _dialogService.ShowDialog<ConfirmDeleteDialog>(parameters);
        
        if (result.Result == ButtonResult.OK)
        {
            // 使用者點擊確認，執行刪除
            ExecuteDelete(orderId);
        }
    }
}
```

## 非模態對話框

### 說明

非模態對話框不會阻塞父視窗，允許使用者同時操作其他視窗。適用於進度顯示、通知等場景。

### 使用方法

```csharp
public class DataController
{
    private readonly IDialogService _dialogService;
    
    public DataController(IDialogService dialogService)
    {
        _dialogService = dialogService;
    }
    
    public void StartLongOperation()
    {
        // 建立參數
        var parameters = new DialogParameters();
        parameters.Add("Title", "處理中");
        parameters.Add("Message", "正在處理資料，請稍候...");
        
        // 顯示非模態對話框
        _dialogService.ShowModeless<ProgressDialog>(parameters, result =>
        {
            // 對話框關閉時的回呼
            if (result.Result == ButtonResult.Cancel)
            {
                CancelOperation();
            }
        });
        
        // 開始非同步操作
        StartAsyncOperation();
    }
}
```

## 自定義對話框

### 說明

繼承 `DialogBase` 類別可快速建立自定義對話框。

### 使用方法

```csharp
public class InputDialog : DialogBase
{
    private Label lblMessage;
    private TextBox txtInput;
    private Button btnOK;
    private Button btnCancel;
    
    public InputDialog()
    {
        Title = "輸入";
        InitializeComponents();
    }
    
    private void InitializeComponents()
    {
        Size = new Size(300, 150);
        
        lblMessage = new Label
        {
            Location = new Point(10, 10),
            Size = new Size(280, 20),
            Text = "請輸入內容："
        };
        
        txtInput = new TextBox
        {
            Location = new Point(10, 35),
            Size = new Size(280, 25)
        };
        
        btnOK = new Button
        {
            Location = new Point(120, 70),
            Size = new Size(80, 30),
            Text = "確定"
        };
        btnOK.Click += BtnOK_Click;
        
        btnCancel = new Button
        {
            Location = new Point(210, 70),
            Size = new Size(80, 30),
            Text = "取消"
        };
        btnCancel.Click += BtnCancel_Click;
        
        Controls.AddRange(new Control[] { lblMessage, txtInput, btnOK, btnCancel });
    }
    
    protected override void OnDialogOpenedCore(IDialogParameters parameters)
    {
        // 從參數取得預設值
        if (parameters.TryGetValue<string>("Message", out var message))
        {
            lblMessage.Text = message;
        }
        
        if (parameters.TryGetValue<string>("DefaultValue", out var defaultValue))
        {
            txtInput.Text = defaultValue;
        }
    }
    
    public override bool CanCloseDialog()
    {
        // 可加入驗證邏輯
        return true;
    }
    
    private void BtnOK_Click(object sender, EventArgs e)
    {
        // 建立返回參數
        var resultParams = new DialogParameters();
        resultParams.Add("InputValue", txtInput.Text);
        
        // 關閉對話框
        CloseDialog(ButtonResult.OK, resultParams);
    }
    
    private void BtnCancel_Click(object sender, EventArgs e)
    {
        CloseDialog(ButtonResult.Cancel);
    }
}
```

## IDialogAware 介面

### 說明

對話框內容需實作 `IDialogAware` 介面以接收開啟與關閉事件。

### 介面方法

| 方法               | 說明             |
| ---------------- | -------------- |
| `OnDialogOpened` | 對話框開啟時呼叫，用於初始化 |
| `CanCloseDialog` | 檢查是否可以關閉對話框    |
| `OnDialogClosed` | 對話框關閉後呼叫，用於清理  |
| `CloseRequested` | 請求關閉對話框的事件     |

### 使用方法

```csharp
public class ConfirmDialog : UserControl, IDialogAware
{
    public string Title { get; set; } = "確認";
    public event EventHandler<DialogCloseRequestedEventArgs> CloseRequested;
    
    public void OnDialogOpened(IDialogParameters parameters)
    {
        var message = parameters.GetValue<string>("Message");
        labelMessage.Text = message;
    }
    
    public bool CanCloseDialog()
    {
        return true;
    }
    
    public void OnDialogClosed()
    {
        // 清理資源
    }
    
    private void btnOK_Click(object sender, EventArgs e)
    {
        var result = new DialogResult(ButtonResult.OK);
        CloseRequested?.Invoke(this, new DialogCloseRequestedEventArgs(result));
    }
    
    private void btnCancel_Click(object sender, EventArgs e)
    {
        var result = new DialogResult(ButtonResult.Cancel);
        CloseRequested?.Invoke(this, new DialogCloseRequestedEventArgs(result));
    }
}
```

## 參數傳遞

### 說明

使用 `IDialogParameters` 在對話框之間傳遞參數。

### 使用方法

```csharp
// 傳遞參數
var parameters = new DialogParameters();
parameters.Add("ProductId", 123);
parameters.Add("ProductName", "測試產品");
parameters.Add("Categories", new List<string> { "A", "B", "C" });

var result = _dialogService.ShowDialog<ProductEditDialog>(parameters);

// 接收返回參數
if (result.Result == ButtonResult.OK)
{
    var editedProduct = result.Parameters.GetValue<Product>("EditedProduct");
    var isModified = result.Parameters.GetValue<bool>("IsModified");
}
```

## 訊息對話框

### 說明

`IDialogService` 提供快速顯示訊息對話框的方法。

### 使用方法

```csharp
// 顯示資訊訊息
_dialogService.ShowMessage("操作已完成。", "資訊");

// 顯示確認對話框
if (_dialogService.ShowConfirm("確定要刪除嗎？", "確認"))
{
    // 使用者點擊「是」
}

// 顯示選擇對話框
var result = _dialogService.ShowMessage(
    "是否儲存變更？",
    "確認",
    MessageDialogButtons.YesNoCancel);

switch (result)
{
    case ButtonResult.Yes:
        SaveChanges();
        break;
    case ButtonResult.No:
        DiscardChanges();
        break;
    case ButtonResult.Cancel:
        // 取消操作
        break;
}
```

## Autofac 註冊

### 服務註冊

對話框服務已在 `DialogModule` 中自動註冊：

```csharp
public class DialogModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        // WinForms 對話框視窗工廠 (SingleInstance)
        builder.RegisterType<WinFormsDialogWindowFactory>()
            .As<IDialogWindowFactory>()
            .SingleInstance();

        // DialogService (SingleInstance)
        builder.RegisterType<DialogService>()
            .As<IDialogService>()
            .SingleInstance();
    }
}
```

### 對話框註冊

自定義對話框需要在 Autofac 中註冊：

```csharp
public class CustomDialogModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterType<ConfirmDeleteDialog>()
            .AsSelf()
            .InstancePerDependency();
        
        builder.RegisterType<InputDialog>()
            .AsSelf()
            .InstancePerDependency();
        
        builder.RegisterType<ProductEditDialog>()
            .AsSelf()
            .InstancePerDependency();
    }
}
```

## 擴充性

### 自定義視窗工廠

若需支援其他 UI 框架，可實作 `IDialogWindowFactory`：

```csharp
// WPF 範例
public class WpfDialogWindowFactory : IDialogWindowFactory
{
    public IDialogWindow CreateDialogWindow()
    {
        return new WpfDialogWindow();
    }
}

// 註冊時替換
builder.RegisterType<WpfDialogWindowFactory>()
    .As<IDialogWindowFactory>()
    .SingleInstance();
```

## 介面參考

| 介面                     | 說明        |
| ---------------------- | --------- |
| `IDialogService`       | 對話框服務介面   |
| `IDialogAware`         | 對話框事件通知介面 |
| `IDialogParameters`    | 參數傳遞介面    |
| `IDialogResult`        | 返回結果介面    |
| `IDialogWindow`        | 對話框視窗抽象介面 |
| `IDialogWindowFactory` | 對話框視窗工廠介面 |
