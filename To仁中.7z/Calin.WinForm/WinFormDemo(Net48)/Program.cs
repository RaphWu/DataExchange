using Autofac;
using Calin.Framework.Navigation;
using Calin.MessageSystem.Presenter.Dialog;
using Calin.MessageSystem.Presenter.Tip;
using Calin.WinFormDemo_Net48.ProcessFlow;
using Calin.WinFormDemo_Net48.ProcessFlow.UI;

namespace Calin.WinFormDemo_Net48
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var builder = new ContainerBuilder();

            builder.RegisterModule<WinFormModule>();
            builder.RegisterModule<NavigationModule>();
            builder.RegisterModule<ProcessFlowModule>();

            builder.RegisterType<MessageDialogPresenter>().AsSelf().SingleInstance();
            builder.RegisterType<MessageTipPresenter>().AsSelf().SingleInstance();

            // views
            builder.RegisterType<MainForm>().AsSelf().InstancePerDependency();
            builder.RegisterType<View1>().AsSelf().InstancePerDependency();
            builder.RegisterType<View2>().AsSelf().InstancePerDependency();
            builder.RegisterType<View3>().AsSelf().InstancePerDependency();

            // ProcessFlow UI
            builder.RegisterType<ProcessFlowMainForm>().AsSelf().InstancePerDependency();
            builder.RegisterType<ProcessFlowEditorView>().AsSelf().InstancePerDependency();

            var container = builder.Build();

            // �i�����Ұʪ���GMainForm �� ProcessFlowMainForm
            // Application.Run(container.Resolve<MainForm>());
            Application.Run(container.Resolve<ProcessFlowMainForm>());
        }
    }
}