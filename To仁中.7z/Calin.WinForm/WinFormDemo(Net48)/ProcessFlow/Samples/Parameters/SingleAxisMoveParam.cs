namespace Calin.WinFormDemo_Net48.ProcessFlow.Samples.Parameters
{
    /// <summary>
    /// ��b���ʰѼơC
    /// </summary>
    public class SingleAxisMoveParam
    {
        /// <summary>
        /// �b�N���C
        /// </summary>
        public string AxisId { get; set; } = "X";

        /// <summary>
        /// �ؼЮy�СC
        /// </summary>
        public double TargetPosition { get; set; }

        /// <summary>
        /// ���ʳt�ס]���Gmm/s�^�C
        /// </summary>
        public double Speed { get; set; } = 100;

        /// <summary>
        /// �[�t�ס]���Gmm/s?�^�C
        /// </summary>
        public double Acceleration { get; set; } = 500;
    }
}
