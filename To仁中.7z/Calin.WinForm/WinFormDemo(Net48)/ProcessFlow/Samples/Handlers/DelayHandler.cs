using System.Text.Json;
using Calin.WinFormDemo_Net48.ProcessFlow.Engine;
using Calin.WinFormDemo_Net48.ProcessFlow.Samples.Parameters;

namespace Calin.WinFormDemo_Net48.ProcessFlow.Samples.Handlers
{
    /// <summary>
    /// ���𵥫ݤu�ǳB�z���C
    /// </summary>
    public class DelayHandler : IProcessHandler
    {
        public async Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken cancellationToken)
        {
            try
            {
                var param = JsonSerializer.Deserialize<DelayParam>(paramJson);
                if (param == null)
                    return ProcessExecutionResult.Failed("�ѼƸѪR����");

                await Task.Delay(param.DelayMilliseconds, cancellationToken);

                return ProcessExecutionResult.Succeeded();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                return ProcessExecutionResult.Failed(ex);
            }
        }

        public string ValidateParam(string paramJson)
        {
            try
            {
                var param = JsonSerializer.Deserialize<DelayParam>(paramJson);
                if (param == null)
                    return "�ѼƤ��i����";

                if (param.DelayMilliseconds < 0)
                    return "����ɶ����i���t��";

                return null;
            }
            catch (Exception ex)
            {
                return $"�ѼƮ榡���~: {ex.Message}";
            }
        }
    }
}
