using System.Text.Json;
using Calin.WinFormDemo_Net48.ProcessFlow.Engine;
using Calin.WinFormDemo_Net48.ProcessFlow.Samples.Parameters;

namespace Calin.WinFormDemo_Net48.ProcessFlow.Samples.Handlers
{
    /// <summary>
    /// ��b���ʤu�ǳB�z���C
    /// </summary>
    public class SingleAxisMoveHandler : IProcessHandler
    {
        public async Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken cancellationToken)
        {
            try
            {
                var param = JsonSerializer.Deserialize<SingleAxisMoveParam>(paramJson);
                if (param == null)
                    return ProcessExecutionResult.Failed("�ѼƸѪR����");

                // �����b���ʡ]������Τ����I�s���x���� API�^
                var moveTime = Math.Abs(param.TargetPosition) / param.Speed * 1000;
                var simulatedDelay = Math.Min((int)moveTime, 2000);

                await Task.Delay(simulatedDelay, cancellationToken);

                return ProcessExecutionResult.Succeeded();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                return ProcessExecutionResult.Failed(ex);
            }
        }

        public string ValidateParam(string paramJson)
        {
            try
            {
                var param = JsonSerializer.Deserialize<SingleAxisMoveParam>(paramJson);
                if (param == null)
                    return "�ѼƤ��i����";

                if (string.IsNullOrEmpty(param.AxisId))
                    return "�b�N�����i����";

                if (param.Speed <= 0)
                    return "�t�ץ����j�� 0";

                if (param.Acceleration <= 0)
                    return "�[�t�ץ����j�� 0";

                return null;
            }
            catch (Exception ex)
            {
                return $"�ѼƮ榡���~: {ex.Message}";
            }
        }
    }
}
