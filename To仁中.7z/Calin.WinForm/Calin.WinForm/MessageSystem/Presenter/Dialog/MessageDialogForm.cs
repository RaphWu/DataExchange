using System;
using System.Drawing;
using System.Windows.Forms;
using Calin.MessageSystem.Core;

namespace Calin.MessageSystem.Presenter.Dialog
{
    /// <summary>
    /// �T����ܮص����C
    /// </summary>
    internal class MessageDialogForm : Form
    {
        private readonly string _title;
        private readonly string _content;
        private readonly MessageStyle _style;
        private readonly MessageLayoutResult _layout;
        private readonly MessageIcon _icon;
        private readonly DialogButtonSet _buttonSet;
        private readonly Button[] _buttons;

        private DialogResultValue _resultValue = DialogResultValue.None;
        private int _hoveredButtonIndex = -1;

        /// <summary>
        /// ��ܮص��G�ȡC
        /// </summary>
        public DialogResultValue ResultValue => _resultValue;

        /// <summary>
        /// �إ߰T����ܮءC
        /// </summary>
        public MessageDialogForm(
            string title,
            string content,
            MessageStyle style,
            MessageIcon icon,
            DialogButtonSet buttonSet)
        {
            _title = title ?? string.Empty;
            _content = content ?? string.Empty;
            _style = style ?? MessageStyle.CreateDialogDefault();
            _icon = icon ?? MessageIcon.None;
            _buttonSet = buttonSet ?? DialogButtonSet.OK;

            _layout = MessageLayoutEngine.CalculateDialog(_style, _title, _content, _icon, _buttonSet);
            _buttons = new Button[_buttonSet.Count];

            InitializeForm();
            InitializeButtons();
        }

        private void InitializeForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            BackColor = _style.ContentBackColor;
            Size = _layout.TotalSize;
            MinimizeBox = false;
            MaximizeBox = false;
            KeyPreview = true;

            // ���\�����i�Q�즲
            MouseDown += OnFormMouseDown;

            // �B�z��L�ƥ�
            KeyDown += OnFormKeyDown;
        }

        private void InitializeButtons()
        {
            var buttons = _buttonSet.Buttons;

            for (var i = 0; i < buttons.Count; i++)
            {
                var buttonDef = buttons[i];
                var buttonBounds = _layout.ButtonBounds[i];

                var button = new Button
                {
                    Text = buttonDef.Text,
                    Font = buttonDef.Font ?? _style.ButtonFont ?? SystemFonts.DefaultFont,
                    ForeColor = buttonDef.ForeColor.IsEmpty ? _style.ButtonForeColor : buttonDef.ForeColor,
                    BackColor = buttonDef.BackColor.IsEmpty ? _style.ButtonBackColor : buttonDef.BackColor,
                    FlatStyle = FlatStyle.Flat,
                    Bounds = buttonBounds,
                    Tag = buttonDef,
                    TabIndex = i
                };

                button.FlatAppearance.BorderSize = 0;
                button.FlatAppearance.MouseOverBackColor = _style.ButtonHoverBackColor;

                button.Click += OnButtonClick;

                if (buttonDef.IsDefault)
                {
                    AcceptButton = button;
                }

                if (buttonDef.IsCancel)
                {
                    CancelButton = button;
                }

                _buttons[i] = button;
                Controls.Add(button);
            }
        }

        private void OnButtonClick(object sender, EventArgs e)
        {
            var button = (Button)sender;
            var buttonDef = (DialogButtonDefinition)button.Tag;
            _resultValue = buttonDef.ResultValue;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void OnFormMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && _layout.HasTitle && _layout.TitleAreaBounds.Contains(e.Location))
            {
                // ���\�즲���D�C
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void OnFormKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                var cancelButton = _buttonSet.GetCancelButton();
                if (cancelButton != null)
                {
                    _resultValue = cancelButton.ResultValue;
                    DialogResult = DialogResult.Cancel;
                    Close();
                }
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;

            // ø�s���D�ϰ�
            if (_layout.HasTitle)
            {
                using (var brush = new SolidBrush(_style.TitleBackColor))
                {
                    g.FillRectangle(brush, _layout.TitleAreaBounds);
                }

                TextRenderer.DrawText(
                    g,
                    _title,
                    _style.TitleFont,
                    _layout.TitleBounds,
                    _style.TitleForeColor,
                    MessageLayoutEngine.GetTextFormatFlags());
            }

            // ø�s���e�ϰ�I��
            using (var brush = new SolidBrush(_style.ContentBackColor))
            {
                g.FillRectangle(brush, _layout.ContentAreaBounds);
            }

            // ø�s�ϥ�
            if (_layout.HasIcon)
            {
                var iconImage = _icon.GetImage();
                if (iconImage != null)
                {
                    g.DrawImage(iconImage, _layout.IconBounds);
                }
            }

            // ø�s���e��r
            TextRenderer.DrawText(
                g,
                _content,
                _style.ContentFont,
                _layout.ContentBounds,
                _style.ContentForeColor,
                MessageLayoutEngine.GetTextFormatFlags());

            // ø�s���s�ϰ�I��
            if (_layout.HasButtonArea)
            {
                using (var brush = new SolidBrush(_style.ButtonAreaBackColor))
                {
                    g.FillRectangle(brush, _layout.ButtonAreaBounds);
                }
            }

            // ø�s���
            if (_style.BorderWidth > 0)
            {
                using (var pen = new Pen(_style.BorderColor, _style.BorderWidth))
                {
                    g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
                }
            }
        }

        #region Windows API for dragging

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        #endregion
    }
}
