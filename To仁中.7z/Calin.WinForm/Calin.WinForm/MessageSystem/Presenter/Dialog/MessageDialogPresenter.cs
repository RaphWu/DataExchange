using System.Windows.Forms;
using Calin.MessageSystem.Core;

namespace Calin.MessageSystem.Presenter.Dialog
{
    /// <summary>
    /// �T����ܮ� Presenter�A�t�d��ܹ�ܮبê�^���G�C
    /// </summary>
    public class MessageDialogPresenter
    {
        private MessageStyle _defaultStyle;

        /// <summary>
        /// ���o�γ]�w�w�]�˦��C
        /// </summary>
        public MessageStyle DefaultStyle
        {
            get { return _defaultStyle ?? MessageStyle.CreateDialogDefault(); }
            set { _defaultStyle = value; }
        }

        /// <summary>
        /// ��ܰT����ܮءC
        /// </summary>
        /// <param name="content">���e��r</param>
        /// <returns>��ܮص��G</returns>
        public DialogResultValue Show(string content)
        {
            return Show(null, content, MessageIcon.None, DialogButtonSet.OK, DefaultStyle);
        }

        /// <summary>
        /// ��ܰT����ܮءC
        /// </summary>
        /// <param name="content">���e��r</param>
        /// <param name="title">���D</param>
        /// <returns>��ܮص��G</returns>
        public DialogResultValue Show(string content, string title)
        {
            return Show(title, content, MessageIcon.None, DialogButtonSet.OK, DefaultStyle);
        }

        /// <summary>
        /// ��ܰT����ܮءC
        /// </summary>
        /// <param name="content">���e��r</param>
        /// <param name="title">���D</param>
        /// <param name="icon">�ϥ�</param>
        /// <returns>��ܮص��G</returns>
        public DialogResultValue Show(string content, string title, MessageIcon icon)
        {
            return Show(title, content, icon, DialogButtonSet.OK, DefaultStyle);
        }

        /// <summary>
        /// ��ܰT����ܮءC
        /// </summary>
        /// <param name="content">���e��r</param>
        /// <param name="title">���D</param>
        /// <param name="icon">�ϥ�</param>
        /// <param name="buttonSet">���s���X</param>
        /// <returns>��ܮص��G</returns>
        public DialogResultValue Show(string content, string title, MessageIcon icon, DialogButtonSet buttonSet)
        {
            return Show(title, content, icon, buttonSet, DefaultStyle);
        }

        /// <summary>
        /// ��ܰT����ܮءC
        /// </summary>
        /// <param name="title">���D</param>
        /// <param name="content">���e��r</param>
        /// <param name="icon">�ϥ�</param>
        /// <param name="buttonSet">���s���X</param>
        /// <param name="style">�ۭq�˦�</param>
        /// <returns>��ܮص��G</returns>
        public DialogResultValue Show(
            string title,
            string content,
            MessageIcon icon,
            DialogButtonSet buttonSet,
            MessageStyle style)
        {
            var effectiveStyle = style ?? DefaultStyle;

            using (var form = new MessageDialogForm(title, content, effectiveStyle, icon, buttonSet))
            {
                form.ShowDialog();
                return form.ResultValue;
            }
        }

        /// <summary>
        /// ��ܰT����ܮء]���w�������^�C
        /// </summary>
        public DialogResultValue Show(
            IWin32Window owner,
            string title,
            string content,
            MessageIcon icon,
            DialogButtonSet buttonSet,
            MessageStyle style)
        {
            var effectiveStyle = style ?? DefaultStyle;

            using (var form = new MessageDialogForm(title, content, effectiveStyle, icon, buttonSet))
            {
                form.ShowDialog(owner);
                return form.ResultValue;
            }
        }

        #region �K����k

        /// <summary>
        /// ��ܸ�T��ܮءC
        /// </summary>
        public DialogResultValue ShowInformation(string content, string title = "��T")
        {
            return Show(title, content, MessageIcon.Information, DialogButtonSet.OK, DefaultStyle);
        }

        /// <summary>
        /// ���ĵ�i��ܮءC
        /// </summary>
        public DialogResultValue ShowWarning(string content, string title = "ĵ�i")
        {
            return Show(title, content, MessageIcon.Warning, DialogButtonSet.OK, DefaultStyle);
        }

        /// <summary>
        /// ��ܿ��~��ܮءC
        /// </summary>
        public DialogResultValue ShowError(string content, string title = "���~")
        {
            return Show(title, content, MessageIcon.Error, DialogButtonSet.OK, DefaultStyle);
        }

        /// <summary>
        /// ��ܽT�{��ܮء]�O/�_�^�C
        /// </summary>
        public DialogResultValue ShowConfirm(string content, string title = "�T�{")
        {
            return Show(title, content, MessageIcon.Question, DialogButtonSet.YesNo, DefaultStyle);
        }

        /// <summary>
        /// ��ܽT�{��ܮء]�O/�_/�����^�C
        /// </summary>
        public DialogResultValue ShowConfirmWithCancel(string content, string title = "�T�{")
        {
            return Show(title, content, MessageIcon.Question, DialogButtonSet.YesNoCancel, DefaultStyle);
        }

        #endregion

        /// <summary>
        /// ���]���w�]�˦��C
        /// </summary>
        public void ResetToDefaultStyle()
        {
            _defaultStyle = null;
        }
    }
}
