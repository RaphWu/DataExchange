using System;
using System.Drawing;

namespace Calin.MessageSystem.Core
{
    /// <summary>
    /// �T���ϥ������C
    /// </summary>
    public enum MessageIconType
    {
        /// <summary>
        /// �L�ϥܡC
        /// </summary>
        None,

        /// <summary>
        /// ��T�ϥܡC
        /// </summary>
        Information,

        /// <summary>
        /// ĵ�i�ϥܡC
        /// </summary>
        Warning,

        /// <summary>
        /// ���~�ϥܡC
        /// </summary>
        Error,

        /// <summary>
        /// ���D�ϥܡC
        /// </summary>
        Question,

        /// <summary>
        /// ���\�ϥܡC
        /// </summary>
        Success,

        /// <summary>
        /// �ۭq�ϥܡC
        /// </summary>
        Custom
    }

    /// <summary>
    /// �T���ϥܡA�䴩�t�ιϥܩΦۭq�Ϥ��C
    /// </summary>
    public class MessageIcon
    {
        /// <summary>
        /// �ϥ������C
        /// </summary>
        public MessageIconType IconType { get; private set; }

        /// <summary>
        /// �ۭq�Ϥ��]�� IconType �� Custom �ɨϥΡ^�C
        /// </summary>
        public Image CustomImage { get; private set; }

        /// <summary>
        /// �ϥܤؤo�C
        /// </summary>
        public Size Size { get; set; } = new Size(32, 32);

        private MessageIcon(MessageIconType iconType, Image customImage = null)
        {
            IconType = iconType;
            CustomImage = customImage;
        }

        /// <summary>
        /// �L�ϥܡC
        /// </summary>
        public static MessageIcon None => new MessageIcon(MessageIconType.None);

        /// <summary>
        /// ��T�ϥܡC
        /// </summary>
        public static MessageIcon Information => new MessageIcon(MessageIconType.Information);

        /// <summary>
        /// ĵ�i�ϥܡC
        /// </summary>
        public static MessageIcon Warning => new MessageIcon(MessageIconType.Warning);

        /// <summary>
        /// ���~�ϥܡC
        /// </summary>
        public static MessageIcon Error => new MessageIcon(MessageIconType.Error);

        /// <summary>
        /// ���D�ϥܡC
        /// </summary>
        public static MessageIcon Question => new MessageIcon(MessageIconType.Question);

        /// <summary>
        /// ���\�ϥܡC
        /// </summary>
        public static MessageIcon Success => new MessageIcon(MessageIconType.Success);

        /// <summary>
        /// �ۭq�ϥܡC
        /// </summary>
        /// <param name="image">�ۭq�Ϥ�</param>
        public static MessageIcon Custom(Image image)
        {
            if (image == null)
            {
                throw new ArgumentNullException(nameof(image));
            }
            return new MessageIcon(MessageIconType.Custom, image);
        }


        /// <summary>
        /// ���o�t�ιϥܹϤ��C
        /// </summary>
        public Image GetImage()
        {
            if (IconType == MessageIconType.Custom)
            {
                return CustomImage;
            }

            if (IconType == MessageIconType.None)
            {
                return null;
            }

            // �ϥΨt�ιϥ�
            Icon systemIcon;
            switch (IconType)
            {
                case MessageIconType.Information:
                    systemIcon = SystemIcons.Information;
                    break;
                case MessageIconType.Warning:
                    systemIcon = SystemIcons.Warning;
                    break;
                case MessageIconType.Error:
                    systemIcon = SystemIcons.Error;
                    break;
                case MessageIconType.Question:
                    systemIcon = SystemIcons.Question;
                    break;
                case MessageIconType.Success:
                    systemIcon = SystemIcons.Information; // �ϥ� Information �@�� Success
                    break;
                default:
                    return null;
            }

            return systemIcon.ToBitmap();
        }

        /// <summary>
        /// �O�_���ϥܡC
        /// </summary>
        public bool HasIcon => IconType != MessageIconType.None;
    }
}
