using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Calin.MessageSystem.Core
{
    /// <summary>
    /// ��ܮث��s���X�A���ѹw�]���s�զX�C
    /// </summary>
    public class DialogButtonSet
    {
        private readonly List<DialogButtonDefinition> _buttons;

        /// <summary>
        /// ���s���X�C
        /// </summary>
        public ReadOnlyCollection<DialogButtonDefinition> Buttons => _buttons.AsReadOnly();

        /// <summary>
        /// �إߪŪ����s���X�C
        /// </summary>
        public DialogButtonSet()
        {
            _buttons = new List<DialogButtonDefinition>();
        }

        /// <summary>
        /// �إߥ]�t���w���s�����X�C
        /// </summary>
        /// <param name="buttons">���s�w�q</param>
        public DialogButtonSet(params DialogButtonDefinition[] buttons)
        {
            _buttons = new List<DialogButtonDefinition>(buttons);
        }

        /// <summary>
        /// �s�W���s�C
        /// </summary>
        /// <param name="button">���s�w�q</param>
        /// <returns>���s���X�]�䴩�즡�I�s�^</returns>
        public DialogButtonSet Add(DialogButtonDefinition button)
        {
            _buttons.Add(button);
            return this;
        }

        /// <summary>
        /// ���o�w�]���s�]IsDefault = true�^�C
        /// </summary>
        public DialogButtonDefinition GetDefaultButton()
        {
            foreach (var button in _buttons)
            {
                if (button.IsDefault)
                {
                    return button;
                }
            }
            return _buttons.Count > 0 ? _buttons[0] : null;
        }

        /// <summary>
        /// ���o�������s�]IsCancel = true�^�C
        /// </summary>
        public DialogButtonDefinition GetCancelButton()
        {
            foreach (var button in _buttons)
            {
                if (button.IsCancel)
                {
                    return button;
                }
            }
            return null;
        }

        /// <summary>
        /// ���s�ƶq�C
        /// </summary>
        public int Count => _buttons.Count;

        #region �w�]���s���X

        /// <summary>
        /// �T�w���s�C
        /// </summary>
        public static DialogButtonSet OK => new DialogButtonSet(DialogButtonDefinition.OK);

        /// <summary>
        /// �T�w + �������s�C
        /// </summary>
        public static DialogButtonSet OKCancel => new DialogButtonSet(
            DialogButtonDefinition.OK,
            DialogButtonDefinition.Cancel);

        /// <summary>
        /// �O + �_���s�C
        /// </summary>
        public static DialogButtonSet YesNo => new DialogButtonSet(
            DialogButtonDefinition.Yes,
            DialogButtonDefinition.No);

        /// <summary>
        /// �O + �_ + �������s�C
        /// </summary>
        public static DialogButtonSet YesNoCancel => new DialogButtonSet(
            DialogButtonDefinition.Yes,
            DialogButtonDefinition.No,
            DialogButtonDefinition.Cancel);

        /// <summary>
        /// ���� + �������s�C
        /// </summary>
        public static DialogButtonSet RetryCancel => new DialogButtonSet(
            DialogButtonDefinition.Retry,
            DialogButtonDefinition.Cancel);

        /// <summary>
        /// ���� + ���� + �������s�C
        /// </summary>
        public static DialogButtonSet AbortRetryIgnore => new DialogButtonSet(
            DialogButtonDefinition.Abort,
            DialogButtonDefinition.Retry,
            DialogButtonDefinition.Ignore);

        #endregion

        #region �إߦۭq���s���X

        /// <summary>
        /// �إߦۭq���s���X�C
        /// </summary>
        /// <param name="button1Text">���s1��r</param>
        /// <param name="button1Result">���s1���G</param>
        /// <returns>���s���X</returns>
        public static DialogButtonSet Create(string button1Text, DialogResultValue button1Result = DialogResultValue.Custom1)
        {
            return new DialogButtonSet(
                new DialogButtonDefinition(button1Text, button1Result) { IsDefault = true });
        }

        /// <summary>
        /// �إߦۭq���s���X�C
        /// </summary>
        public static DialogButtonSet Create(
            string button1Text, DialogResultValue button1Result,
            string button2Text, DialogResultValue button2Result)
        {
            return new DialogButtonSet(
                new DialogButtonDefinition(button1Text, button1Result) { IsDefault = true },
                new DialogButtonDefinition(button2Text, button2Result) { IsCancel = true });
        }

        /// <summary>
        /// �إߦۭq���s���X�C
        /// </summary>
        public static DialogButtonSet Create(
            string button1Text, DialogResultValue button1Result,
            string button2Text, DialogResultValue button2Result,
            string button3Text, DialogResultValue button3Result)
        {
            return new DialogButtonSet(
                new DialogButtonDefinition(button1Text, button1Result) { IsDefault = true },
                new DialogButtonDefinition(button2Text, button2Result),
                new DialogButtonDefinition(button3Text, button3Result) { IsCancel = true });
        }

        #endregion
    }
}
