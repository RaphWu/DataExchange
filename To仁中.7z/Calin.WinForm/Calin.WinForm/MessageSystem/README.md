﻿# Calin.Infrastructure.MessageSystem

提供完整訊息通知系統，包含 Toast、Dialog、MessageTip 三種訊息形式。

# 樣式屬性完整說明

以下是樣式屬性的完整說明，幫助您快速了解如何自訂訊息樣式：

| 區域     | 屬性                     | 類型             | 說明               |
| ------ | ---------------------- | -------------- | ---------------- |
| **標題** | `TitleFont`            | `Font`         | 標題字體             |
|        | `TitleForeColor`       | `Color`        | 標題文字顏色           |
|        | `TitleBackColor`       | `Color`        | 標題背景色            |
|        | `TitleHeight`          | `int`          | 標題區域高度（0=自動）     |
| **內容** | `ContentFont`          | `Font`         | 內容字體             |
|        | `ContentForeColor`     | `Color`        | 內容文字顏色           |
|        | `ContentBackColor`     | `Color`        | 內容背景色            |
| **按鈕** | `ButtonFont`           | `Font`         | 按鈕字體             |
|        | `ButtonForeColor`      | `Color`        | 按鈕文字顏色           |
|        | `ButtonBackColor`      | `Color`        | 按鈕背景色            |
|        | `ButtonHoverBackColor` | `Color`        | 按鈕懸停背景色          |
|        | `ButtonAreaBackColor`  | `Color`        | 按鈕區域背景色          |
|        | `ButtonHeight`         | `int`          | 按鈕高度             |
|        | `ButtonSpacing`        | `int`          | 按鈕間距             |
| **圖示** | `IconSize`             | `Size`         | 圖示尺寸             |
|        | `IconPosition`         | `IconPosition` | 圖示位置（Left/Right） |
| **佈局** | `Padding`              | `Padding`      | 內邊距              |
|        | `Spacing`              | `int`          | 元素間距             |
|        | `MinWidth`             | `int`          | 最小寬度             |
|        | `MaxWidth`             | `int`          | 最大寬度             |
|        | `BorderColor`          | `Color`        | 邊框顏色             |
|        | `BorderWidth`          | `int`          | 邊框寬度             |

# 目標框架

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0 (Windows)

# NuGet 依賴

- AutoFac

# 命名空間與責任圖

```text
Calin.Infrastructure.MessageSystem
├─ Core/                              # 共用核心，提供樣式、佈局計算、按鈕模型
│   ├─ MessageStyle.cs                # 標題列、內容、按鈕字型、字體大小、顏色、Padding、Spacing
│   ├─ MessageLayoutEngine.cs         # 計算 Title / Content / Button / Icon 尺寸與位置
│   ├─ DialogButtonDefinition.cs      # 按鈕邏輯定義
│   └─ DialogButtonSet.cs             # 一組按鈕的集合、Default / Cancel 設定
│
├─ Presenter/                         # 具體訊息呈現層
│   ├─ Toast/
│   │   ├─ ToastForm.cs               # 只負責顯示 Toast 視窗
│   │   └─ ToastManager.cs            # 負責堆疊、位置計算、生命週期管理
│   ├─ Dialog/
│   │   ├─ MessageDialogPresenter.cs  # 顯示 Dialog，套用 DialogButtonSet
│   │   └─ ButtonPanel.cs             # 按鈕排列與 Icon 排版
│   └─ Tip/
│       └─ MessageTipPresenter.cs     # 控件上方提示
│
└─ Module/                            # DI 注冊模組
    └─ WinFormModule.cs               # AutoFac 註冊 Presenter / Manager
```

# 系統架構

以下是系統架構的簡要說明：
- **Core**：負責樣式、佈局計算及按鈕模型的核心邏輯。
- **Presenter**：負責具體的訊息呈現，包括 Toast、Dialog 和 Tip。
- **Module**：提供 DI 模組，便於依賴注入。

```mermaid
graph LR
    subgraph Core["MessageSystem.Core"]
        MS[MessageStyle]
        MLE[MessageLayoutEngine]
        MLR[MessageLayoutResult]
        MI[MessageIcon]
        DBD[DialogButtonDefinition]
        DBS[DialogButtonSet]
    end

    subgraph Presenters["MessageSystem.Presenter"]
        subgraph Toast
            TM[ToastManager]
            TF[ToastForm]
        end
        subgraph Dialog
            MDP[MessageDialogPresenter]
            MDF[MessageDialogForm]
        end
        subgraph Tip
            MTP[MessageTipPresenter]
            MTF[MessageTipForm]
        end
    end

    subgraph DI["MessageSystem.DI"]
        MSM[MessageSystemModule]
    end

    MS --> MLE
    MI --> MLE
    DBS --> MLE
    MLE --> MLR
    
    MLR --> TF
    MLR --> MDF
    MLR --> MTF
    
    MSM --> MDP
    MSM --> MTP
```

# 範例代碼

以下範例代碼展示了如何使用 `Calin.Infrastructure.MessageSystem`，更多範例請參考 `MessageSystemUsageExamples` 類別。

# Toast Notification

在螢幕右下角顯示短暫的訊息通知，不搶焦點。

## 基本使用

```csharp
using Calin.Infrastructure.MessageSystem.Presenter.Toast;

// 顯示預設 3 秒的 Toast
ToastManager.ShowToast("操作成功！");

// 顯示指定秒數的 Toast
ToastManager.ShowToast("檔案已儲存", 5);

// 連續顯示多個 Toast（會自動往上堆疊）
ToastManager.ShowToast("第一則通知", 4);
ToastManager.ShowToast("第二則通知", 4);

// 關閉所有 Toast
ToastManager.CloseAll();
```

## 自訂樣式

```csharp
using Calin.Infrastructure.MessageSystem.Core;
using Calin.Infrastructure.MessageSystem.Presenter.Toast;

// 成功樣式（綠色）
var successStyle = new MessageStyle
{
    ContentFont = new Font("Microsoft JhengHei", 10f),
    ContentBackColor = Color.FromArgb(39, 174, 96),
    ContentForeColor = Color.White,
    Padding = new Padding(16),
    MinWidth = 150,
    MaxWidth = 350
};

// 錯誤樣式（紅色）
var errorStyle = new MessageStyle
{
    ContentFont = new Font("Microsoft JhengHei", 10f, FontStyle.Bold),
    ContentBackColor = Color.FromArgb(192, 57, 43),
    ContentForeColor = Color.White,
    Padding = new Padding(16),
    MinWidth = 150,
    MaxWidth = 350
};

ToastManager.ShowToast("操作成功！", 3, successStyle);
ToastManager.ShowToast("發生錯誤！", 5, errorStyle);
```

## 設定全域預設樣式

```csharp
ToastManager.DefaultStyle = new MessageStyle
{
    ContentFont = new Font("Microsoft JhengHei", 11f),
    ContentBackColor = Color.FromArgb(40, 40, 40),
    ContentForeColor = Color.LightGreen,
    Padding = new Padding(20),
    MinWidth = 180,
    MaxWidth = 400
};

// 重設為預設樣式
ToastManager.ResetToDefaultStyle();
```

# Message Dialog

顯示模態對話框，支援自訂按鈕、圖示、標題和樣式。

## 基本使用

```csharp
using Calin.Infrastructure.MessageSystem.Core;
using Calin.Infrastructure.MessageSystem.Presenter.Dialog;

// 透過 DI 取得 Presenter
var dialog = container.Resolve<MessageDialogPresenter>();

// 顯示簡單訊息
dialog.Show("操作已完成");

// 顯示帶標題的訊息
dialog.Show("檔案已儲存成功", "儲存結果");

// 顯示帶圖示的訊息
dialog.Show("請確認是否繼續？", "確認", MessageIcon.Question);

// 便捷方法
dialog.ShowInformation("這是資訊訊息");
dialog.ShowWarning("這是警告訊息");
dialog.ShowError("這是錯誤訊息");

// 確認對話框
var result = dialog.ShowConfirm("確定要刪除嗎？");
if (result == DialogResultValue.Yes)
{
    // 使用者點擊「是」
}
```

## DialogButtonSet 使用

```csharp
// 使用預設按鈕集合
var result = dialog.Show("內容", "標題", MessageIcon.Question, DialogButtonSet.YesNoCancel);

// 建立自訂按鈕
var customButtons = DialogButtonSet.Create(
    "儲存", DialogResultValue.Custom1,
    "不儲存", DialogResultValue.Custom2,
    "取消", DialogResultValue.Cancel);

var result = dialog.Show("是否儲存變更？", "儲存", MessageIcon.Question, customButtons);

switch (result)
{
    case DialogResultValue.Custom1:
        // 儲存
        break;
    case DialogResultValue.Custom2:
        // 不儲存
        break;
    case DialogResultValue.Cancel:
        // 取消
        break;
}
```

## 自訂按鈕樣式

```csharp
var buttonSet = new DialogButtonSet();

// 新增自訂樣式按鈕
buttonSet.Add(new DialogButtonDefinition("確定", DialogResultValue.OK)
{
    IsDefault = true,
    Font = new Font("Microsoft JhengHei", 10f, FontStyle.Bold),
    ForeColor = Color.White,
    BackColor = Color.FromArgb(0, 122, 204),
    MinWidth = 100
});

buttonSet.Add(new DialogButtonDefinition("取消", DialogResultValue.Cancel)
{
    IsCancel = true,
    Font = new Font("Microsoft JhengHei", 10f),
    ForeColor = Color.Black,
    BackColor = Color.FromArgb(230, 230, 230)
});

dialog.Show("確定要執行嗎？", "確認", MessageIcon.Question, buttonSet);
```

## 自訂對話框樣式

```csharp
var style = new MessageStyle
{
    // 標題樣式
    TitleFont = new Font("Microsoft JhengHei", 12f, FontStyle.Bold),
    TitleForeColor = Color.White,
    TitleBackColor = Color.FromArgb(0, 122, 204),
    TitleHeight = 40,

    // 內容樣式
    ContentFont = new Font("Microsoft JhengHei", 10f),
    ContentForeColor = Color.Black,
    ContentBackColor = Color.White,

    // 按鈕樣式
    ButtonFont = new Font("Microsoft JhengHei", 9f),
    ButtonForeColor = Color.White,
    ButtonBackColor = Color.FromArgb(0, 122, 204),
    ButtonHoverBackColor = Color.FromArgb(0, 102, 184),
    ButtonAreaBackColor = Color.FromArgb(240, 240, 240),
    ButtonHeight = 32,
    ButtonSpacing = 10,

    // 佈局
    Padding = new Padding(20),
    Spacing = 15,
    MinWidth = 350,
    MaxWidth = 500,
    BorderColor = Color.FromArgb(0, 122, 204),
    BorderWidth = 2
};

dialog.Show("標題", "內容", MessageIcon.Information, DialogButtonSet.OK, style);
```

# Message Tip

在控制項附近顯示提示訊息，類似 ToolTip 但可完全自訂樣式。

## 基本使用

```csharp
using Calin.Infrastructure.MessageSystem.Presenter.Tip;

// 透過 DI 取得 Presenter
var tip = container.Resolve<MessageTipPresenter>();

// 在控制項下方顯示提示
tip.ShowBelow(textBox, "請輸入有效的 Email");

// 在控制項上方顯示提示
tip.ShowAbove(button, "點擊送出表單");

// 在控制項右側顯示提示
tip.ShowRight(label, "必填欄位");

// 在控制項左側顯示提示
tip.ShowLeft(control, "提示訊息");

// 隱藏特定控制項的提示
tip.Hide(textBox);

// 隱藏所有提示
tip.HideAll();
```

## 自訂樣式

```csharp
var errorTipStyle = new MessageStyle
{
    ContentFont = new Font("Microsoft JhengHei", 9f),
    ContentBackColor = Color.FromArgb(255, 200, 200),
    ContentForeColor = Color.DarkRed,
    Padding = new Padding(8),
    BorderColor = Color.Red,
    BorderWidth = 1,
    MinWidth = 100,
    MaxWidth = 250
};

tip.Show(textBox, "輸入格式錯誤", TipPosition.Below, 5, errorTipStyle, MessageIcon.Error);
```

# AutoFac DI 註冊

## 註冊方式

```csharp
using Autofac;
using Calin.Infrastructure.MessageSystem.DI;

var builder = new ContainerBuilder();

// 註冊 MessageSystem 模組
builder.RegisterModule<MessageSystemModule>();

var container = builder.Build();
```

---

更多範例請參考 `MessageSystemUsageExamples` 類別。
