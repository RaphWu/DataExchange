﻿namespace Calin.Service
{
    // TODO: 註解重整
    /// <summary>
    /// WinForm 錯誤訊息服務介面。
    /// </summary>
    /// <remarks>使用方法：
    /// <pre><code>
    /// 內部函數呼叫 ACM 函數的返回值直接賦值給 ErrCode 屬性，其它屬性即會自動設定。
    /// 1. NoError 和 HasError 屬性可用於檢查是否發生錯誤。
    /// 2. ErrMessage 屬性可用於取得錯誤訊息。(NoError 時為空字串)
    /// 
    /// 程式庫內使用範例：
    /// ErrCode = mAcm_Function(...);
    /// return CheckErr($"{nameof(AcmService)}.FuncName, "錯誤詳細資訊");
    ///   或
    /// return CheckErr($"{nameof(AcmService)}."錯誤詳細資訊");
    ///   或
    /// if (CheckErr($"{nameof(AcmService)}."錯誤詳細資訊"))
    /// {
    ///     Console.WriteLine($"Error {errManager.ErrCode}: {errManager.ErrMessage}\n{errManager.ErrDetail}");
    /// }
    /// ```
    /// 外部的應用程式可以這樣使用：
    /// 
    /// </code></pre></remarks>
    public interface IWinForm
    {
        #region Properties

        /// <summary>
        /// 無錯誤發生。
        /// </summary>
        bool NoError { get; }

        /// <summary>
        /// 有錯誤發生。
        /// </summary>
        bool HasError { get; }

        /// <summary>
        /// 錯誤代碼。
        /// </summary>
        int ErrCode { get; internal set; }

        /// <summary>
        /// 錯誤訊息。
        /// </summary>
        string ErrMessage { get; }

        /// <summary>
        /// 引發錯誤的呼叫者名稱。
        /// </summary>
        string ErrCallerName { get; }

        #endregion Properties

        #region Internal Methods

        /// <summary>
        /// 設定錯誤。
        /// </summary>
        /// <param name="errCode"></param>
        /// <param name="errMsg"></param>
        /// <param name="callerName"></param>
        void SetError(int errCode, string errMsg, string callerName = "");

        /// <summary>
        /// 清除錯誤訊息。
        /// </summary>
        void ClearErr();

        #endregion Internal Methods
    }
}
