﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    /// <summary>
    /// 維護工單服務。
    /// </summary>
    public class MaintiFlowService : IMaintiFlow, IDisposable
    {
        private readonly MaintiFlowContext _context;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;
        private readonly MaintiFlowFieldName _fieldName;

        private bool _isInitialized = false;
        private Models.Status _defaultStatus;

        /// <inheritdoc/>
        public Models.Status DefaultStatus => _defaultStatus;

        public MaintiFlowService(MaintiFlowContext maintiFlowContext,
                                 CoreData coreData,
                                 MaintiFlowData maintiFlowData,
                                 MaintiFlowFieldName maintiFlowFieldName)
        {
            _context = maintiFlowContext;
            _coreData = coreData;
            _flowData = maintiFlowData;
            _fieldName = maintiFlowFieldName;
        }

        /// <summary>
        /// 釋放註冊的事件。
        /// </summary>
        public void Dispose()
        {
            StrongReferenceMessenger.Default.Unregister<CoreDataChangedNotification>(this);
        }

        /// <inheritdoc/>
        public void Initialize()
        {
            if (_isInitialized)
                return;

            var statuses = _context.Statuses;

            UpdateFromCoreData();
            _defaultStatus = statuses.First();

            _flowData.Engineers = _coreData.Employees
                .Where(e => e.IsEngineer)
                .Select(e => new Engineer
                {
                    EmployeeId = e.EmployeeId,
                    Name = e.Name,
                    Department = e.Department,
                    Title = e.Title
                })
                .ToList();

            _fieldName.OrderNo = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OrderNo));
            _fieldName.WorkOrderNo = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.WorkOrderNo));
            _fieldName.Creator = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Creator));
            _fieldName.CreationDate = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.CreationDate));
            _fieldName.AcceptedTime = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.AcceptedTime));
            _fieldName.Status = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Status));
            _fieldName.MaintenanceUnit = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.MaintenanceUnit));
            _fieldName.MaintenanceEngineers = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.MaintenanceEngineers));
            _fieldName.Machine = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderMachines));
            _fieldName.Model = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.ModelName));
            _fieldName.Workstation = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Workstation));
            _fieldName.IssueCategory = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.IssueCategory));
            _fieldName.IssueDescription = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.IssueDescription));
            _fieldName.Details = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Details));
            _fieldName.RequestingUnit = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RequestingUnit));
            _fieldName.RequestingEmployee = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RequestingEmployee));
            _fieldName.RequestingUnitResponse = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RequestingUnitResponse));
            _fieldName.RepairStarted = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RepairStarted));
            _fieldName.RepairCompleted = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RepairCompleted));
            _fieldName.RepairDuration = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.RepairDuration));
            _fieldName.OutageStarted = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OutageStarted));
            _fieldName.OutageEnded = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OutageEnded));
            _fieldName.OutageDuration = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.OutageDuration));

            // 註冊核心共用資料更新訊息。
            StrongReferenceMessenger.Default.Register<CoreDataChangedNotification>(this, (r, m) =>
            {
                UpdateFromCoreData();
            });

            _isInitialized = true;
        }

        /// <summary>
        /// 從核心共用資料更新。
        /// </summary>
        public void UpdateFromCoreData()
        {
            var emp = _context.Set<Models.Employee>();
            emp.RemoveRange(emp);
            foreach (var employee in _coreData.Employees)
                emp.Add(new Models.Employee()
                {
                    EmployeeId = employee.EmployeeId,
                    Name = employee.Name,
                    Department = employee.Department,
                    Title = employee.Title,
                    IsEngineer = employee.IsEngineer,
                });
            _flowData.Employees = _context.Set<Models.Employee>()
                .OrderBy(m => m.EmployeeId)
                .ToList();

            var dev = _context.Set<Models.Machine>();
            dev.RemoveRange(dev);
            foreach (var device in _coreData.Machines)
                dev.Add(new Models.Machine()
                {
                    MachineId = device.MachineId,
                    MachineName = device.MachineName.FullName,
                });
            _flowData.MachineList = _context.Set<Models.Machine>()
                .OrderBy(m => m.MachineName)
                .ToList()
                .Select(m => new KeyValuePair<string, string>(m.MachineId, m.MachineName))
                .ToList();

            var model = _context.Set<Models.Model>();
            model.RemoveRange(model);
            foreach (var m in _coreData.Models)
                model.Add(new Models.Model()
                {
                    ModelName = m.ModelName,
                });
            _flowData.ModelList = _context.Set<Models.Model>()
                .OrderBy(m => m.ModelName)
                .Select(m => m.ModelName)
                .ToList();

            _context.SaveChanges();
        }
    }
}
