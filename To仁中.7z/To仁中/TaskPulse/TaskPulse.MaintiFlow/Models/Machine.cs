﻿//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace Calin.TaskPulse.MaintiFlow.Models
//{
//    /// <summary>
//    /// 機台編號。
//    /// </summary>
//    public class MachineId
//    {
//        [Key]
//        [DatabaseGenerated(DatabaseGeneratedOption.None)]
//        public string MachineId { get; set; }

//        public string MachineName { get; set; }

//        public virtual ICollection<MachineId> TaskOrderMachines { get; set; }
//    }
//}
