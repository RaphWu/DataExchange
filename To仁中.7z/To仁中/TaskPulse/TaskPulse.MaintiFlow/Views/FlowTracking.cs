﻿using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.MaintiFlow.Contants;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

/*
FT_OrderAccepted
FT_MaintenanceCompleted
FT_ClientConfirmed
*/
namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FlowTracking : UIPage
    {
        private MaintiFlowContext _flowContext;
        private FT_OrderAccepted _orderAccepted;
        private FT_MaintenanceCompleted _maintenanceCompleted;
        private FT_ClientConfirmed _clientConfirmed;
        private readonly MaintiFlowFieldName _fieldName;

        private List<TaskOrder> _uncompletedOrder;

        public FlowTracking(MaintiFlowContext maintiFlowContext,
                            FT_OrderAccepted fT_OrderAccepted,
                            FT_MaintenanceCompleted fT_MaintenanceCompleted,
                            FT_ClientConfirmed fT_ClientConfirmed,
                            MaintiFlowFieldName maintiFlowFieldName)
        {
            InitializeComponent();
            _flowContext = maintiFlowContext;
            _orderAccepted = fT_OrderAccepted;
            _maintenanceCompleted = fT_MaintenanceCompleted;
            _clientConfirmed = fT_ClientConfirmed;
            _fieldName = maintiFlowFieldName;

            uiBreadcrumb.Items.AddRange(new string[] { "接單", "維護完成", "委託者確認" });
            uiBreadcrumb.Width = 400;
            uiBreadcrumb.ItemWidth = 135;
            uiBreadcrumb.ItemIndex = 0;

            _uncompletedOrder = _flowContext.TaskOrders
                .Where(o => o.Status != Status.Finished)
                .OrderByDescending(o => o.WorkOrderNo)
                .ToList();
            //uiListBox_OrderList.DataSource = _uncompletedOrder
            //    .Select(o => $"{o.WorkOrderNo} [{o.MachineString}]")
            //    .ToList();

            uiTabControl_Steps.AddPage(_orderAccepted);
            uiTabControl_Steps.AddPage(_maintenanceCompleted);
            uiTabControl_Steps.AddPage(_clientConfirmed);

            // 下方
            //OrderNo.DataBindings.Clear();
            //OrderNo.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.OrderNo));
            //uiLabel_OrderNo.Text = _fieldName.OrderNo;

            //WorkOrderNo.DataBindings.Clear();
            //WorkOrderNo.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.WorkOrderNo));
            //uiLabel_WorkOrderNo.Text = _fieldName.WorkOrderNo;

            //Creator.DataBindings.Clear();
            //Creator.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.CreatorName));
            //uiLabel_Creator.Text = _fieldName.Creator;

            //CreationDate.DataBindings.Clear();
            //CreationDate.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.CreationDate));
            //uiLabel_CreationDate.Text = _fieldName.CreationDate;

            //AcceptedTime.DataBindings.Clear();
            //AcceptedTime.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.AcceptedTime));
            //uiLabel_AcceptedTime.Text = _fieldName.AcceptedTime;

            //Status.DataBindings.Clear();
            //Status.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Status));
            //uiLabel_Status.Text = _fieldName.Status;

            //MaintenanceUnit.DataBindings.Clear();
            //MaintenanceUnit.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.MaintenanceUnit));
            //uiLabel_MaintenanceUnit.Text = _fieldName.MaintenanceUnit;

            //MaintenanceEngineer.DataBindings.Clear();
            //MaintenanceEngineer.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.MaintenanceEngineers));
            //uiLabel_MaintenanceEngineer.Text = _fieldName.MaintenanceEngineers;

            //MachineList.DataBindings.Clear();
            //MachineList.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.MachineId));
            //uiLabel_MachineList.Text = _fieldName.MachineId;

            //Model.DataBindings.Clear();
            //Model.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.ModelName));
            //uiLabel_Model.Text = _fieldName.Model;

            //Workstation.DataBindings.Clear();
            //Workstation.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Workstation));
            //uiLabel_WorkStation.Text = _fieldName.Workstation;

            //IssueCategory.DataBindings.Clear();
            //IssueCategory.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.IssueCategory));
            //uiLabel_IssueCategory.Text = _fieldName.IssueCategory;

            //IssueDescription.DataBindings.Clear();
            //IssueDescription.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.IssueDescription));
            //uiLabel_IssueDescription.Text = _fieldName.IssueDescription;

            //Details.DataBindings.Clear();
            //Details.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Details));
            //uiLabel_Details.Text = _fieldName.Details;

            //RequestingUnit.DataBindings.Clear();
            //RequestingUnit.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RequestingUnit));
            //uiLabel_RequestingUnit.Text = _fieldName.RequestingUnit;

            //RequestingEmployee.DataBindings.Clear();
            //RequestingEmployee.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RequestingEmployee));
            //uiLabel_RequestingEmployee.Text = _fieldName.RequestingEmployee;

            //RequestingUnitResponse.DataBindings.Clear();
            //RequestingUnitResponse.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RequestingUnitResponse));
            //uiLabel_RequestingUnitResponse.Text = _fieldName.RequestingUnitResponse;

            //RepairStarted.DataBindings.Clear();
            //RepairStarted.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RepairStarted));
            //uiLabel_RepairStarted.Text = _fieldName.RepairStarted;

            //RepairCompleted.DataBindings.Clear();
            //RepairCompleted.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RepairCompleted));
            //uiLabel_RepairCompleted.Text = _fieldName.RepairCompleted;

            //RepairDuration.DataBindings.Clear();
            //RepairDuration.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.RepairDuration));
            //uiLabel_RepairDuration.Text = _fieldName.RepairDuration;

            //OutageStarted.DataBindings.Clear();
            //OutageStarted.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.OutageStarted));
            //uiLabel_OutageStarted.Text = _fieldName.OutageStarted;

            //OutageEnded.DataBindings.Clear();
            //OutageEnded.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.OutageEnded));
            //uiLabel_OutageEnded.Text = _fieldName.OutageEnded;

            //OutageDuration.DataBindings.Clear();
            //OutageDuration.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.OutageDuration));
            //uiLabel_OutageDuration.Text = _fieldName.OutageDuration;

            //Responsible.DataBindings.Clear();
            //Responsible.DataBindings.Add("Text", _bs, nameof(SummaryViewModel.Responsible));
            //uiLabel_Responsible.Text = _fieldName.Responsible;
        }

        private void uiBreadcrumb_ItemIndexChanged(object sender, int step)
        {
            uiTabControl_Steps.SelectedIndex = step;
        }
    }
}
