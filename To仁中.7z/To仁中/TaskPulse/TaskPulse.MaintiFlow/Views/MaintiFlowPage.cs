﻿using System;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowPage : UIPage
    {
        private readonly ManitiFlowMain _manitiFlowMain;
        private readonly MaintiFlowSummary _manitiFlowSummary;

        public MaintiFlowPage(ManitiFlowMain manitiFlowMain, MaintiFlowSummary manitiFlowSummary)
        {
            InitializeComponent();
            _manitiFlowMain = manitiFlowMain;
            _manitiFlowSummary = manitiFlowSummary;

            /********************
             * Menu
             ********************/
            TreeNode node1;
            int pageIndex;
            string pageCaption;

            pageIndex = (int)PageCode.MaintiFlow;
            pageCaption = TextList.Menu;
            node1 = uiNavMenu.CreateNode(pageCaption, 558834, 24, pageIndex);
            node1.Tag = pageIndex;

            pageIndex = (int)PageCode.MaintiFlowSummary;
            pageCaption = PageCode.MaintiFlowSummary.GetDescription();
            node1 = uiNavMenu.CreateNode(pageCaption, 559631, 24, pageIndex);
            node1.Tag = pageIndex;

            uiTabControl_Content.AddPage(_manitiFlowMain);
            uiTabControl_Content.AddPage(_manitiFlowSummary);
            uiTabControl_Content.SelectedIndex = 0;

            //pageIndex = (int)PageCode.EditFlow;
            //pageCaption = PageCode.EditFlow.GetDescription();
            //node1 = uiNavMenu.CreateNode(pageCaption, 108, 24, pageIndex);
            //node1.Tag = pageIndex;
            //uiButton_EditFlow.Text = pageCaption;
            //uiButton_EditFlow.Symbol = 108;

            //pageIndex = (int)PageCode.DeleteFlow;
            //pageCaption = PageCode.DeleteFlow.GetDescription();
            //node1 = uiNavMenu.CreateNode(pageCaption, 559691, 24, pageIndex);
            //node1.Tag = pageIndex;
            //uiButton_DeleteFlow.Text = pageCaption;
            //uiButton_DeleteFlow.Symbol = 559691;

            //pageIndex = (int)PageCode.CreateFlow;
            //pageCaption = PageCode.CreateFlow.GetDescription();

#if DEBUG
            //csv.Load();
#endif
        }

        private void SwitchPage(PageCode pageCode)
        {
            Control ctl = null;

            switch (pageCode)
            {
                case PageCode.MaintiFlow:
                    uiTabControl_Content.SelectedIndex = 0;
                    break;

                case PageCode.MaintiFlowSummary:
                    uiTabControl_Content.SelectedIndex = 1;
                    break;

                    //case PageCode.NewFlow:
                    //    ctl = _createFlow;
                    //    break;
            }

            //if (ctl != null)
            //{
            //    uiPanel_Nav.Controls.Clear();
            //    ctl.Dock = DockStyle.Fill;
            //    uiPanel_Nav.Controls.Add(ctl);
            //}
        }

        private void uiNavMenu_MenuItemClick(TreeNode node, NavMenuItem item, int pageIndex)
        {
            SwitchPage((PageCode)Enum.Parse(typeof(PageCode), pageIndex.ToString()));
        }

        private void uiPanel_Header_Click(object sender, EventArgs e)
        {

        }
    }
}
