﻿using System.Drawing;
using Sunny.UI;

namespace Calin.TaskPulse.Core
{
    public static class CommonStyles
    {
        public static Color BackColor => Color.FromArgb(80, 126, 164);
        public static Color Hover => Color.FromArgb(102, 161, 209);

        public static void SetStyles()
        {
            UIStyles.MultiLanguageSupport = true;
            UIStyles.BuiltInResources.TryAdd(CultureInfos.zh_TW.LCID, new zh_TW_Resources());
            UIStyles.CultureInfo = CultureInfos.zh_TW;
            UIStyles.SetStyle(UIStyle.DarkBlue);
            UIStyles.InitColorful(BackColor, Color.White); // 藍灰
            UIStyles.DPIScale = true;
            UIStyles.GlobalFont = true;
            UIStyles.GlobalFontName = "微軟正黑體";
            UIStyles.SetDPIScale();
        }
    }
}
