﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Core.Authority
{
    /// <summary>
    /// 權限表。
    /// </summary>
    public class AuthorizationTable : ObservableObject
    {
        /********************
         * 系統
         ********************/
        /// <summary>
        /// 權限管理。
        /// </summary>
        public bool AuthorityManager
        {
            get { return _authorityManager; }
            set { SetProperty(ref _authorityManager, value); }
        }
        private bool _authorityManager;

        /********************
         * 選單
         ********************/
        /// <summary>
        /// 工具委託操作。
        /// </summary>
        public bool ToolQuest
        {
            get { return _toolQuest; }
            set { SetProperty(ref _toolQuest, value); }
        }
        private bool _toolQuest;

        /// <summary>
        /// 專案管理操作。
        /// </summary>
        public bool MechaTrack
        {
            get { return _mechaTrack; }
            set { SetProperty(ref _mechaTrack, value); }
        }
        private bool _mechaTrack;

        /// <summary>
        /// 維護工單操作。
        /// </summary>
        public bool MaintiFlow
        {
            get { return _maintiFlow; }
            set { SetProperty(ref _maintiFlow, value); }
        }
        private bool _maintiFlow;
    }
}
