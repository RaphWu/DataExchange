﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class FlowLayoutSelector : UIForm
    {
        private const string Flow_Layout_Panel_NAME = "flowLayout";
        private int _tabIndex;
        private int _itemIndex;
        private Dictionary<int, ItemState> _selected;
        private int _lastSelected = -1;

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 是否隱藏標籤列。
        /// </summary>
        public bool HideTabHeaders
        {
            get => tabMenu.HideTabHeaders;
            set
            {
                if (tabMenu.HideTabHeaders != value)
                    tabMenu.HideTabHeaders = value;
            }
        }

        /// <summary>
        /// 是否允許多選。
        /// </summary>
        /// <remarks>true=多選 (使用 CheckBox)，false=單選 (使用 RadioButton)。</remarks>
        public bool MultiSelection { get; set; } = true;

        /// <summary>
        /// 返回的項目。亦可用來做預設值。
        /// </summary>
        public List<string> ResultList { get; set; } = new List<string>();

        /// <summary>
        /// 顯示的項目。
        /// </summary>
        public Dictionary<string, List<string>> Items
        {
            get { return _items; }
            set
            {
                if (!_items.Equals(value))
                    _items = value;
            }
        }
        private Dictionary<string, List<string>> _items = new Dictionary<string, List<string>>();

        public void Initialize()
        {
            tabMenu.TabPages.Clear();
            _selected = new Dictionary<int, ItemState>();
            _lastSelected = -1;

            _tabIndex = 0;
            _itemIndex = 0;
            foreach (var item in Items)
            {
                if (item.Value.Count == 0)
                    continue;

                string flpName = $"{Flow_Layout_Panel_NAME}{_tabIndex}";

                var page = new TabPage(item.Key);
                page.Name = $"page{_tabIndex}";

                var flp = new UIFlowLayoutPanel()
                {
                    Name = flpName,
                    Dock = DockStyle.Fill,
                    AutoScroll = true,
                    WrapContents = true,
                };

                if (MultiSelection)
                {
                    foreach (var text in item.Value)
                    {
                        bool isSelected = ResultList.Count > 0 && ResultList.Contains(text);

                        var ctl = new UICheckBox();
                        ctl.SetDPIScale();
                        ctl.Width = 150;
                        ctl.Name = text;
                        ctl.Text = text;
                        ctl.Checked = isSelected;
                        ctl.Tag = _itemIndex;
                        ctl.CheckedChanged += Ctl_CheckedChanged;
                        flp.Controls.Add(ctl);
                        _selected[_itemIndex++] = new ItemState
                        {
                            Name = text,
                            IsChecked = isSelected,
                        };
                    }
                }
                else
                {
                    foreach (var text in item.Value)
                    {
                        bool isSelected = ResultList.Count > 0 && ResultList.Contains(text);

                        var ctl = new UIRadioButton();
                        ctl.SetDPIScale();
                        ctl.Width = 160;
                        ctl.GroupIndex = 1;
                        ctl.Name = text;
                        ctl.Text = text;
                        ctl.Checked = isSelected;
                        ctl.Tag = _itemIndex;
                        ctl.CheckedChanged += Ctl_CheckedChanged;
                        flp.Controls.Add(ctl);
                        _selected[_itemIndex++] = new ItemState
                        {
                            Name = text,
                            IsChecked = isSelected,
                        };
                    }
                }

                page.Controls.Add(flp);
                tabMenu.TabPages.Add(page);
                _tabIndex++;
            }
        }

        private void Ctl_CheckedChanged(object sender, EventArgs e)
        {
            if (sender is UICheckBox cCtl)
            {
                int index = (int)cCtl.Tag;
                _selected[index].IsChecked = cCtl.Checked;
                _lastSelected = index;
            }
            else if (sender is UIRadioButton rCtl)
            {
                if (_lastSelected >= 0)
                    _selected[_lastSelected].IsChecked = false;

                int index = (int)rCtl.Tag;
                _selected[index].IsChecked = rCtl.Checked;
                _lastSelected = index;
            }
        }

        public FlowLayoutSelector()
        {
            InitializeComponent();

            this.AcceptButton = uiButton_OK;
            this.CancelButton = uiButton_Cancel;
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            ResultList = _selected
                .Where(x => x.Value.IsChecked)
                .Select(x => x.Value.Name)
                .ToList();

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
