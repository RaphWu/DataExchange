﻿using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Service
{
    public class CoreService : ICore
    {
        private readonly CoreContext _coreContext;
        private readonly CoreData _coreData;
        private bool _isInitialized = false;

        public CoreService(CoreContext coreContext, CoreData coreData)
        {
            _coreContext = coreContext;
            _coreData = coreData;
        }

        /// <inheritdoc/>
        public void Initialize()
        {
            if (_isInitialized)
                return;

            UpdateCoreDataFromDb();
            _isInitialized = true;
        }

        /********************
         * public Functions
         ********************/
        /// <inheritdoc/>
        public void UpdateCoreDataFromDb()
        {
            // 員工名冊
            _coreData.Employees = _coreContext.Employees
                .OrderBy(x => x.EmployeeId)
                .ToList();

            // 機台清單
            _coreData.Machines = _coreContext.Machines
                .Include("MachineName")
                .Include("MachineName.Type")
                .Include("MachineName.Type.Category")
                .Include("Brand")
                .Include("Assets")
                .Include("Location")
                .Include("Location.Factory")
                .Include("Condition")
                .Where(m => m.Disposal == false)
                .ToList()
                .Select(m => new { Original = m, Key = GetMachineSortKey(m.MachineId) })
                .OrderBy(x => x.Key.Text)
                .ThenBy(x => x.Key.Number)
                .Select(x => x.Original)
                .ToList();

            // 機台分類
            _coreData.ClassifyMachines = _coreData.Machines
                .Where(m => m.MachineName != null && m.MachineName.Type != null && m.MachineName.Type.Category != null)
                .GroupBy(m => m.MachineName.Type.Category)
                .OrderBy(categoryGroup => categoryGroup.Key.OrderNo)
                .ToDictionary(
                    categoryGroup => categoryGroup.Key.CategoryName,
                    categoryGroup => categoryGroup
                        .GroupBy(m => m.MachineName.Type)
                        .OrderBy(typeGroup => typeGroup.Key.OrderNo)
                        .ToDictionary(
                            typeGroup => typeGroup.Key.TypeName,
                            typeGroup => typeGroup
                                .Select(m => m.MachineId)
                                .Distinct()
                                .ToList()
                        )
                );

            // 依機台分類建立TabPage並注入Autofac
            _coreData.MachinesTabPageCache = new Dictionary<string, List<TabPage>>();
            foreach (var maCategoryName in _coreData.ClassifyMachines.Keys)
            {
                List<TabPage> maTabPages = new List<TabPage>();
                var mTypesDict = _coreData.ClassifyMachines[maCategoryName];
                foreach (var maTypeName in mTypesDict.Keys)
                {
                    var maTabPage = new TabPage(maTypeName)
                    {
                        Name = maTypeName,
                        Font = CommonStyles.Font,
                    };
                    var maFlow = new UIFlowLayoutPanel
                    {
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    maTabPage.Controls.Add(maFlow);

                    var machineIdList = mTypesDict[maTypeName];
                    List<UICheckBox> cbs = new List<UICheckBox>();
                    foreach (var machineId in machineIdList)
                    {
                        var cb = new UICheckBox
                        {
                            Text = machineId,
                            Name = machineId,
                            Checked = false,
                            AutoSize = false,
                            Width = 130,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            CheckBoxColor = CommonStyles.BackColor,
                            Tag = new { Category = maCategoryName, Type = maTypeName, MachineId = machineId }
                        };
                        cbs.Add(cb);
                    }
                    maFlow.Controls.AddRange(cbs.ToArray());
                    maTabPages.Add(maTabPage);
                }
                _coreData.MachinesTabPageCache.Add(maCategoryName, maTabPages);
            }

            // 機種清單
            _coreData.Models = _coreContext.Models.ToList()
                .Select(m => new { Original = m, Key = GetModelSortKey(m.ModelName) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();

            // 依機種分類建立TabPage並注入Autofac
            // 目前機種未分類，所以只有一頁
            _coreData.ModelsTabPageCache = new Dictionary<string, List<TabPage>>();

            string moCategoryName = "SingleCategory";
            string moTypeName = "SingleType";
            List<TabPage> moTabPages = new List<TabPage>();
            var moTabPage = new TabPage(moTypeName)
            {
                Name = moTypeName,
                Font = CommonStyles.Font,
            };
            var moFlow = new UIFlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
            };
            moTabPage.Controls.Add(moFlow);

            List<UIRadioButton> rbs = new List<UIRadioButton>();
            foreach (var item in _coreData.Models)
            {
                var rb = new UIRadioButton
                {
                    Text = item.ModelName,
                    Name = item.ModelName,
                    Checked = false,
                    AutoSize = false,
                    Width = 130,
                    Font = CommonStyles.Font,
                    Style = UIStyle.Inherited,
                    RadioButtonColor = CommonStyles.BackColor,
                    Tag = new { Category = moCategoryName, Type = moTypeName, Model = item.ModelName }
                };
                rbs.Add(rb);
            }
            moFlow.Controls.AddRange(rbs.ToArray());
            moTabPages.Add(moTabPage);
            _coreData.ModelsTabPageCache.Add("SinglePage", moTabPages);

            // 發佈資料更新通知
            StrongReferenceMessenger.Default.Send(CoreDataChangedNotification.Instance);
        }

        /// <inheritdoc/>
        public List<string> SortMachineId(List<string> machineIds)
        {
            return machineIds
               .Select(s => new { Original = s, Key = GetMachineSortKey(s) })
               .OrderBy(x => x.Key.Text)
               .ThenBy(x => x.Key.Number)
               .Select(x => x.Original)
               .ToList();
        }

        /// <inheritdoc/>
        public List<string> SortModelNames(List<string> modelNames)
        {
            return modelNames
                .Select(name => new { Original = name, Key = GetModelSortKey(name) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();
        }

        /********************
         * Common Functions
         ********************/
        /// <summary>
        /// MachineId 的共用排序規則。
        /// </summary>
        private (string Text, int Number) GetMachineSortKey(string machineId)
        {
            var match = Regex.Match(machineId, @"^([^\d\-]+)-?(\d+)$", RegexOptions.IgnoreCase);
            string textPart = match.Success ? match.Groups[1].Value : machineId;
            int numberPart = (match.Success && int.TryParse(match.Groups[2].Value, out int n)) ? n : int.MaxValue;
            return (textPart.ToLowerInvariant(), numberPart);

        }

        /// <summary>
        /// Model 的共用排序規則。
        /// </summary>
        private (bool IsThreeDigits, int SortKey) GetModelSortKey(string modelName)
        {
            var prefix = modelName.Split('-')[0];
            bool isThreeDigits = Regex.IsMatch(prefix, @"^\d{3}$");
            int sortKey = int.TryParse(prefix, out var n) ? n : int.MaxValue;
            return (isThreeDigits, sortKey);
        }
    }
}
