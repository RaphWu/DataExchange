﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 機台類別。
    /// </summary>
    public class MachineCategory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台類別名稱。
        /// </summary>
        [Description("機台類別")]
        [Required]
        public string CategoryName { get; set; }

        /// <summary>
        /// 排序用。
        /// </summary>
        public int OrderNo { get; set; }

        public virtual ICollection<MachineType> MachineCategorys { get; set; } // 機台型式
    }
}
