﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 機台名稱。
    /// </summary>
    public class MachineName
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台型號。
        /// </summary>
        [Description("型號")]
        [MaxLength(50)]
        public string Model { get; set; }

        /// <summary>
        /// 機台型式。
        /// </summary>
        [Description("型式")]
        public MachineType Type { get; set; }
        public int TypeId { get; set; } // FK

        /// <summary>
        /// 機台名稱。
        /// </summary>
        [Description("機台名稱")]
        [NotMapped]
        public string FullName
        {
            get
            {
                string ret = Type.TypeName;
                if (!string.IsNullOrWhiteSpace(Model))
                    ret += string.Concat(" - ", Model);
                return ret;
            }
        }

        public virtual ICollection<Machine> Machines { get; set; } // 機台名稱
    }
}
