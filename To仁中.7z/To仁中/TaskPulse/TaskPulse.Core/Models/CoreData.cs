﻿using System.Collections.Generic;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 核心共用資料。
    /// </summary>
    public class CoreData : ObservableObject
    {
        /// <summary>
        /// 員工名冊。
        /// </summary>
        public List<Employee> Employees
        {
            get { return _employeeList; }
            set { SetProperty(ref _employeeList, value); }
        }
        private List<Employee> _employeeList = new List<Employee>();

        /// <summary>
        /// 機台列表。
        /// </summary>
        public List<Machine> Machines
        {
            get { return _machine; }
            set { SetProperty(ref _machine, value); }
        }
        private List<Machine> _machine = new List<Machine>();

        /// <summary>
        /// 機台列表。
        /// </summary>
        public List<Model> Models
        {
            get { return _models; }
            set { SetProperty(ref _models, value); }
        }
        private List<Model> _models = new List<Model>();
    }
}
