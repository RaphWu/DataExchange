﻿using System.Windows.Forms;

namespace TC100Test
{
    /// <summary>
    /// WinForm 相關擴充功能。
    /// </summary>
    public static class Extension
    {
        /// <summary>
        /// WinForm 跨執行緒修改 Control。
        /// </summary>
        /// <param name="control">Control 物件。</param>
        /// <param name="action">要執行的動作。</param>
        public static void InvokeIfRequired(this Control control, MethodInvoker action)
        {
            if (control.InvokeRequired)
                control.Invoke(action);
            else
                action();
        }
    }
}
