﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace ToyoCylinder
{
    /// <summary>
    /// 為支援屬性變更通知的物件提供一個基底類別。
    /// </summary>
    /// <remarks>此類實現了 <see cref="INotifyPropertyChanged"/> 接口，使衍生類別能夠在屬性值發生變化時通知訂閱者。<br />
    /// 它包含一種機制，必要時可以在 UI 執行緒上引發 <see cref="PropertyChanged"/> 事件，從而確保與 UI 元件互動時的執行緒安全性。</remarks>
    public abstract class BindableBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        internal void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            if (Application.OpenForms.Count > 0)
            {
                var form = Application.OpenForms[0];
                if (form.InvokeRequired)
                {
                    form.Invoke(new Action(() =>
                    {
                        if (PropertyChanged != null)
                            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                    }));
                }
                else
                {
                    if (PropertyChanged != null)
                        PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                }
            }
        }
    }
}
