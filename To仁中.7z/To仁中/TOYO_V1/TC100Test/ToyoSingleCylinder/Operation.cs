﻿namespace ToyoCylinder
{
    /********************
     * 電動缸操作
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 伺服 ON。
        /// </summary>
        public void ServoOn()
        {
            SendRequestFrame(CallerId.Command, GetFrame(0x06, 0x2011, 0));
        }

        /// <summary>                                           
        /// 伺服 OFF。                                          
        /// </summary>                                          
        public void ServoOff()
        {
            SendRequestFrame(CallerId.Command, GetFrame(0x06, 0x2011, 1));
        }

        /// <summary>                                           
        /// 警報重置。                                           
        /// </summary>                                          
        public void AlarmReset()
        {
            SendRequestFrame(CallerId.Command, GetFrame(0x06, 0x201E, 6));
            SendRequestFrame(CallerId.Command, GetFrame(0x06, 0x201E, 7));
        }
    }
}
