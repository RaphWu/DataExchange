﻿namespace ToyoCylinder
{
    /// <summary>
    /// 命令呼叫者代碼。
    /// </summary>
    internal enum CallerId
    {
        Initializer,    // 初始化 / 開通權限
        Command,        // 一般命令
        ReadStatus,     // 讀取狀態
        PortOut,        // 讀取輸出訊號
        PortIn,         // 讀取輸入訊號
        ErrorHistories, // 讀取錯誤履歷
    }
}
