﻿using System;
using System.Threading;

namespace ToyoCylinder
{
    /// <summary>
    /// 線程安全、多任務共用及可重用的 CancellationTokenSource 封裝。
    /// </summary>
    public class ReusableCancellationTokenSource : IDisposable
    {
        private readonly object _lock = new object();
        private CancellationTokenSource _cts = new CancellationTokenSource();
        private bool _disposed;

        /// <summary>
        /// 取得主 Token，通常用在簡單情境。
        /// </summary>
        public CancellationToken Token
        {
            get
            {
                lock (_lock)
                {
                    return _cts.Token;
                }
            }
        }

        /// <summary>
        /// 建立一個新的子 Token，會跟隨主控 CTS 一起被取消。
        /// </summary>
        public CancellationToken CreateLinkedToken()
        {
            lock (_lock)
            {
                if (_disposed)
                    throw new ObjectDisposedException("ReusableCancellationTokenSource");

                // 建立一個與目前 _cts 相連的子 CTS
                var linked = CancellationTokenSource.CreateLinkedTokenSource(_cts.Token);
                return linked.Token;
            }
        }

        /// <summary>
        /// 取消所有任務。
        /// </summary>
        public void Cancel()
        {
            lock (_lock)
            {
                if (!_disposed)
                {
                    _cts.Cancel();
                }
            }
        }

        /// <summary>
        /// 重置，讓新任務能用新的 Token。
        /// </summary>
        public void Reset()
        {
            lock (_lock)
            {
                if (_disposed) throw new ObjectDisposedException("ReusableCancellationTokenSource");

                _cts.Dispose();
                _cts = new CancellationTokenSource();
            }
        }

        /// <summary>
        /// 釋放
        /// </summary>
        public void Dispose()
        {
            lock (_lock)
            {
                if (_disposed) return;
                _disposed = true;
                _cts.Dispose();
            }
        }
    }
}
