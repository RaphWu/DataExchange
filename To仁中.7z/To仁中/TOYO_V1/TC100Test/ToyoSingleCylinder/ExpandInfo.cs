﻿using System;

namespace ToyoCylinder
{
    /********************
     * 非功能性擴充資訊
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 程式庫運行時間。
        /// </summary>
        public TimeSpan ExceuteTime
        {
            get { return _exceuteTime; }
            internal set
            {
                if (_exceuteTime != value)
                {
                    _exceuteTime = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private TimeSpan _exceuteTime;

#if DEBUG
        /// <summary>
        /// 取得 Debug 用的訊息。
        /// </summary>
        public DebugMessage DebugMessage
        {
            get { return _debugMessage; }
        }
#endif
    }
}
