﻿using System;
using System.Threading.Tasks;

namespace ToyoCylinder
{
    /********************
     * 運動控制相關操作
     ********************/
    public partial class ToyoSingleCylinder
    {
        /// <summary>
        /// 判斷運動是否已達指定位置。
        /// </summary>
        /// <param name="position">要比對的座標。</param>
        /// <param name="checkTimeOut">是否要檢查逾時？</param>
        /// <returns>true:已達指定位置, false:位置不動超過3秒鐘。</returns>
        private async Task<bool> InPosition(double position, bool checkTimeOut = true)
        {
            DateTime mark = DateTime.Now;
            double lastPos = 0.0;

            while (true)
            {
                if (ActionStatus == 0
                    && InpStatus == 1
                    && Math.Abs(CmdNowPos - position) <= 0.01
                    && Math.Abs(EcdPos - position) <= 0.01)
                    return true;
                else
                { // TODO: 頂住時，馬達狀態是ON/OFF?
                    if (checkTimeOut && Math.Abs(lastPos - EcdPos) < 10.0)
                    {
                        TimeSpan ts = DateTime.Now - mark;
                        if (ts.TotalMilliseconds > 3000)
                            return false;
                    }
                    else
                    {
                        mark = DateTime.Now;
                        lastPos = EcdPos;
                    }
                    await Task.Delay(10);
                }
            }
        }

        /********************
         * 基本動作指令
         ********************/
        /// <summary>
        /// 緊急停止。
        /// </summary>
        public void EmergencyStop()
        {
            HighPriorityRequest(CallerId.Command, 0x06, 0x201E, 9);
        }

        /// <summary>
        /// 減速停止。
        /// </summary>
        public void DeceleratesToStop()
        {
            HighPriorityRequest(CallerId.Command, 0x06, 0x201E, 8);
        }

        /// <summary>
        /// 原點復歸。
        /// </summary>
        public async Task OriginReturn()
        {
            InMotion = true;
            HighPriorityRequest(CallerId.Command, 0x06, 0x201E, 3);
            await InPosition(0.0, checkTimeOut: false);
            InMotion = false;
        }

        /********************
         * 運動指令
         ********************/
        #region 運動參數

        /// <summary>
        /// 設定 + 方向的推壓。
        /// </summary>
        /// <param name="push">推壓，0.0~100.0，為扭力值的比例設定值。</param>
        public void SetPushCw(double push)
        {
            SendRequestFrame(CallerId.Command, string.Concat(":01060400", ((int)(push * 10)).ToString("X4")));
        }

        /// <summary>
        /// 設定 - 方向的推壓。
        /// </summary>
        /// <param name="push">推壓，0.0~100.0，為扭力值的比例設定值。</param>
        public void SetPushCcw(double push)
        {
            SendRequestFrame(CallerId.Command, string.Concat(":01060401", ((int)(push * 10)).ToString("X4")));
        }

        /// <summary>
        /// 設定雙方向的推壓。
        /// </summary>
        /// <param name="pushCw">+ 方向的推壓，0.0~100.0，為扭力值的比例設定值。</param>
        /// <param name="pushCcw">- 方向的推壓，0.0~100.0，為扭力值的比例設定值。</param>
        public void SetPush(double pushCw, double pushCcw)
        {
            SetPushCw(pushCw);
            SetPushCcw(pushCcw);
        }

        /// <summary>
        /// 設定運動速度。
        /// </summary>
        /// <param name="speed">運動速度，0~100，為最高速度的百分比設定值。</param>
        public void SetSpeed(int speed)
        {
            SendRequestFrame(CallerId.Command, string.Concat(":01062014", speed.ToString("X4")));
        }

        #endregion

        #region ABS

        /// <summary>
        /// ABS 絕對位置運動。
        /// </summary>
        /// <param name="coordinate">目標位置，單位 mm。</param>
        /// <returns>true:已達指定位置, false:位置不動超過3秒鐘。</returns>
        public async Task<bool> AbsMove(double coordinate)
        {
            InMotion = true;

            SendRequestFrame(CallerId.Command, string.Concat(":01102002000204", ((int)(coordinate * 100)).ToString("X8")));
            SendRequestFrame(CallerId.Command, ":0106201E0001");

            bool ret = await InPosition(coordinate);
            InMotion = false;
            return ret;
        }

        /// <summary>
        /// ABS 絕對位置運動。
        /// </summary>
        /// <param name="coordinate">目標位置，單位 mm。</param>
        /// <param name="speed">運動速度，0~100，為最高速度的百分比設定值。</param>
        /// <param name="push">推壓，0.0~100.0，為扭力值的比例設定值。</param>
        /// <returns>true:已達指定位置, false:位置不動超過3秒鐘。</returns>
        public async Task<bool> AbsMove(double coordinate, int speed, double push)
        {
            InMotion = true;
            SetSpeed(speed);
            SetPush(push, push);
            return await AbsMove(coordinate);
        }

        #endregion

        #region INC

        /// <summary>
        /// INC 相對位置運動。
        /// </summary>
        /// <param name="offset">移動量，單位 mm。</param>
        /// <returns>true:已達指定位置, false:位置不動超過3秒鐘。</returns>
        public async Task<bool> IncMove(double offset)
        {
            InMotion = true;

            SendRequestFrame(CallerId.Command, string.Concat(":01102000000204", ((int)(offset * 100)).ToString("X8")));
            SendRequestFrame(CallerId.Command, ":0106201E0000");

            bool ret = await InPosition(CmdNowPos + offset);
            InMotion = false;
            return ret;
        }

        /// <summary>
        /// INC 相對位置運動。
        /// </summary>
        /// <param name="offset">移動量，單位 mm。</param>
        /// <param name="speed">運動速度，0~100，為最高速度的百分比設定值。</param>
        /// <param name="push">推壓，0.0~100.0，為扭力值的比例設定值。</param>
        /// <returns>true:已達指定位置, false:位置不動超過3秒鐘。</returns>
        public async Task<bool> IncMove(double offset, int speed, double push)
        {
            InMotion = true;
            SetSpeed(speed);
            SetPush(push, push);
            return await IncMove(offset);
        }

        #endregion

        #region JOG

        //public void JogCwStart()
        //{
        //    SendRequestFrame(CallerId.Command, 0x06, 0x201E, 11);
        //}

        //public void JogCwStop()
        //{
        //    SendRequestFrame(CallerId.Command, 0x06, 0x201E, 0);
        //}

        //public void JogCcwStart()
        //{
        //    SendRequestFrame(CallerId.Command, 0x06, 0x201E, 12);
        //}

        //public void JogCcwStop()
        //{
        //    SendRequestFrame(CallerId.Command, 0x06, 0x201E, 0);
        //}

        #endregion
    }
}
