﻿namespace ToyoCylinder
{
    /// <summary>
    /// 輸入訊號。
    /// </summary>
    public class PortIn : BindableBase
    {
        /// <summary>
        /// 輸入訊號 01。
        /// </summary>
        /// <remarks>ORG。</remarks>
        public bool PortIn01
        {
            get { return _portIn01; }
            set
            {
                if (_portIn01 != value)
                {
                    _portIn01 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn01;

        /// <summary>
        /// 輸入訊號 02。
        /// </summary>
        /// <remarks>SERVO ON/OFF。</remarks>
        public bool PortIn02
        {
            get { return _portIn02; }
            set
            {
                if (_portIn02 != value)
                {
                    _portIn02 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn02;

        /// <summary>
        /// 輸入訊號 03。
        /// </summary>
        /// <remarks>ALR_RESET。</remarks>
        public bool PortIn03
        {
            get { return _portIn03; }
            set
            {
                if (_portIn03 != value)
                {
                    _portIn03 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn03;

        /// <summary>
        /// 輸入訊號 04。
        /// </summary>
        /// <remarks>START。</remarks>
        public bool PortIn04
        {
            get { return _portIn04; }
            set
            {
                if (_portIn04 != value)
                {
                    _portIn04 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn04;

        /// <summary>
        /// 輸入訊號 05。
        /// </summary>
        /// <remarks>PRGSEL0。</remarks>
        public bool PortIn05
        {
            get { return _portIn05; }
            set
            {
                if (_portIn05 != value)
                {
                    _portIn05 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn05;

        /// <summary>
        /// 輸入訊號 06。
        /// </summary>
        /// <remarks>PRGSEL1。</remarks>
        public bool PortIn06
        {
            get { return _portIn06; }
            set
            {
                if (_portIn06 != value)
                {
                    _portIn06 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn06;

        /// <summary>
        /// 輸入訊號 07。
        /// </summary>
        /// <remarks>PRGSEL2。</remarks>
        public bool PortIn07
        {
            get { return _portIn07; }
            set
            {
                if (_portIn07 != value)
                {
                    _portIn07 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn07;

        /// <summary>
        /// 輸入訊號 08。
        /// </summary>
        /// <remarks>PRGSEL3。</remarks>
        public bool PortIn08
        {
            get { return _portIn08; }
            set
            {
                if (_portIn08 != value)
                {
                    _portIn08 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn08;

        /// <summary>
        /// 輸入訊號 09。
        /// </summary>
        /// <remarks>LOCK。</remarks>
        public bool PortIn09
        {
            get { return _portIn09; }
            set
            {
                if (_portIn09 != value)
                {
                    _portIn09 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn09;

        /// <summary>
        /// 輸入訊號 10。
        /// </summary>
        /// <remarks>MANUAL。</remarks>
        public bool PortIn10
        {
            get { return _portIn10; }
            set
            {
                if (_portIn10 != value)
                {
                    _portIn10 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn10;

        /// <summary>
        /// 輸入訊號 11。
        /// </summary>
        /// <remarks>IN11。</remarks>
        public bool PortIn11
        {
            get { return _portIn11; }
            set
            {
                if (_portIn11 != value)
                {
                    _portIn11 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn11;

        /// <summary>
        /// 輸入訊號 12。
        /// </summary>
        /// <remarks>IN12。</remarks>
        public bool PortIn12
        {
            get { return _portIn12; }
            set
            {
                if (_portIn12 != value)
                {
                    _portIn12 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn12;

        /// <summary>
        /// 輸入訊號 13。
        /// </summary>
        /// <remarks>IN13。</remarks>
        public bool PortIn13
        {
            get { return _portIn13; }
            set
            {
                if (_portIn13 != value)
                {
                    _portIn13 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn13;

        /// <summary>
        /// 輸入訊號 14。
        /// </summary>
        /// <remarks>IN14。</remarks>
        public bool PortIn14
        {
            get { return _portIn14; }
            set
            {
                if (_portIn14 != value)
                {
                    _portIn14 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portIn14;
    }
}
