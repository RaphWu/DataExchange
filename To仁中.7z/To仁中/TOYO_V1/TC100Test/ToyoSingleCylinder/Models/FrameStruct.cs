﻿namespace ToyoCylinder
{
    /// <summary>
    /// 表示包含有關呼叫者和訊息幀的資料結構。
    /// </summary>
    internal struct FrameStruct
    {
        /// <summary>
        /// 命令呼叫者代碼。
        /// </summary>
        internal CallerId CallerId { get; set; }

        /// <summary>
        /// Modbus 訊息幀的位元組陣列。
        /// </summary>
        internal byte[] Frame { get; set; }
    }
}
