﻿namespace ToyoCylinder
{
    /********************
     * 電動缸狀態。(開放給外部的變數與函數)
     ********************/
    public partial class ToyoSingleCylinder
    {
        /********************
         * 狀態查詢
         ********************/
        /// <summary>
        /// 電動缸是否準備好接收指令？
        /// </summary>
        /// <returns>true=準備好，false=尚未準備好。</returns>
        public bool Ready
        {
            get
            {
                return _sp != null && _sp.IsOpen
                                && _servoStatus             // Servo ON
                                && _statusPortOut.PortOut01 // 原點
                                && _actionStatus == 0       // 動作狀態
                                && _inpStatus == 1          // 到位訊號狀態
                                && !_inMotion;              // 電動缸運動命令已停止
            }
        }

        /// <summary>
        /// 電動缸是否準備好接收指令的文字訊息。
        /// </summary>
        public string ReadyMessage
        {
            get { return Ready ? "電動缸已準備好" : "電動缸尚未準備好"; }
        }

        /// <summary>
        /// 電動缸是否準備好回原點？
        /// </summary>
        /// <returns>true=準備好，false=尚未準備好。</returns>
        public bool ReadyToOriginReturn
        {
            get { return _sp != null && _sp.IsOpen && _servoStatus; }
        }

        /// <summary>
        /// 電動缸是否開啟中？
        /// </summary>
        public bool IsOpen
        {
            get { return _sp != null && _sp.IsOpen; }
        }

        /********************
         * 電動缸IO腳位
         ********************/
        /// <summary>
        /// 輸出腳位。
        /// </summary>
        public PortOut PortOut
        {
            get { return _statusPortOut; }
        }

        /// <summary>
        /// 輸入腳位。
        /// </summary>
        public PortIn PortIn
        {
            get { return _statusPortIn; }
        }

        /// <summary>
        /// 伺服狀態 ON/FF。
        /// </summary>
        public bool ServoStatus
        {
            get { return _servoStatus; }
            private set
            {
                if (_servoStatus != value)
                {
                    _servoStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    //NotifyPropertyChanged(nameof(ServoStatusMessage));
                    NotifyPropertyChanged("Ready");
                    NotifyPropertyChanged("ServoStatusMessage");
                }
            }
        }
        private bool _servoStatus;

        /// <summary>
        /// 伺服狀態 ON/FF 的文字訊息。
        /// </summary>
        public string ServoStatusMessage
        {
            get { return ServoStatus ? "伺服ON" : "伺服OFF"; }
        }

        /// <summary>
        /// 動作狀態。
        /// </summary>
        public int ActionStatus
        {
            get { return _actionStatus; }
            private set
            {
                if (_actionStatus != value)
                {
                    _actionStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private int _actionStatus;

        public string ActionStatusMessage
        {
            get { return ActionStatus == 0 ? "停止" : ActionStatus == 1 ? "動作中" : "異常停止"; }
        }

        /// <summary>
        /// 到位訊號狀態。
        /// </summary>
        public int InpStatus
        {
            get { return _inpStatus; }
            private set
            {
                if (_inpStatus != value)
                {
                    _inpStatus = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private int _inpStatus;

        public string InpStatusMessage
        {
            get { return InpStatus == 1 ? "位置已在設定範圍內" : "尚未到達設定範圍內"; }
        }

        /// <summary>
        /// 扭力極限狀態。
        /// </summary>
        public int TrqLmtStatus
        {
            get { return _trqLmtStatus; }
            private set
            {
                if (_trqLmtStatus != value)
                {
                    _trqLmtStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _trqLmtStatus;

        public string TrqLmtStatusMessage
        {
            get { return TrqLmtStatus == 1 ? "已在設定範圍內" : "未到設定範圍內"; }
        }

        /// <summary>
        /// 警報狀態。
        /// </summary>
        public int AlarmStatus
        {
            get { return _alarmStatus; }
            private set
            {
                if (_alarmStatus != value)
                {
                    _alarmStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _alarmStatus;

        /// <summary>
        /// 警報狀態說明。
        /// </summary>
        public string AlarmStatusMessage
        {
            get
            {
                switch (_alarmStatus)
                {
                    case 0:
                        return "無警報";
                    case 1:
                        return "Loop error";
                    case 2:
                        return "Full Count";
                    case 3:
                        return "過速度";
                    case 4:
                        return "增益值調整不良";
                    case 5:
                        return "過電壓";
                    case 6:
                        return "初期化異常";
                    case 7:
                        return "EEPROM 異常";
                    case 8:
                        return "主迴路電源電壓不足";
                    case 9:
                        return "過電流";
                    case 10:
                        return "回生異常";
                    case 11:
                        return "緊急停止";
                    case 12:
                        return "馬達斷線";
                    case 13:
                        return "編碼器斷線";
                    case 14:
                        return "保護電流值";
                    case 15:
                        return "電源再投入";
                    case 16:
                        return "動作超時";
                    default:
                        return "不明錯誤";
                }
            }
        }

        /// <summary>
        /// 故障狀態。
        /// </summary>
        public int ErrorStatus
        {
            get { return _errorStatus; }
            private set
            {
                if (_errorStatus != value)
                {
                    _errorStatus = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _errorStatus;

        /// <summary>
        /// 故障狀態說明。
        /// </summary>
        public string ErrorStatusMessage
        {
            get
            {
                switch (_errorStatus)
                {
                    case 0:
                        return "沒有錯誤";
                    case 1:
                        return "在動作中接收動作指令";
                    case 2:
                        return "上下限錯誤";
                    case 3:
                        return "位置錯誤";
                    case 4:
                        return "格式錯誤";
                    case 5:
                        return "控制模式錯誤";
                    case 6:
                        return "斷電重開";
                    case 7:
                        return "初始化未完成";
                    case 8:
                        return "Servo ON/OFF 錯誤";
                    case 9:
                        return "LOCK";
                    case 10:
                        return "軟體極限";
                    case 11:
                        return "參數寫入權限不足";
                    case 12:
                        return "原點復歸未完成";
                    case 13:
                        return "剎車已解除";
                    default:
                        return "不明錯誤";
                }
            }
        }

        /// <summary>
        /// 馬達轉速 RPM。
        /// </summary>
        public int MonRpm
        {
            get { return _monRpm; }
            private set
            {
                if (_monRpm != value)
                {
                    _monRpm = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private int _monRpm;

        ///// <summary>
        ///// 馬達轉速。
        ///// </summary>
        //[Description("馬達轉速")]
        //public int MonSpeed { get; set; }

        /// <summary>
        /// 馬達電流值。
        /// </summary>
        public double MonCurrent
        {
            get { return _monCurrent; }
            private set
            {
                if (_monCurrent != value)
                {
                    _monCurrent = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _monCurrent;

        /// <summary>
        /// 指令現在位置。
        /// </summary>
        public double CmdNowPos
        {
            get { return _cmdNowPos; }
            private set
            {
                if (_cmdNowPos != value)
                {
                    _cmdNowPos = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _cmdNowPos;

        /// <summary>
        /// 編碼器位置。
        /// </summary>
        public double EcdPos
        {
            get { return _ecdPos; }
            private set
            {
                if (_ecdPos != value)
                {
                    _ecdPos = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private double _ecdPos;

        /********************
         * 運動狀態
         ********************/
        /// <summary>
        /// 電動缸運動命令是否在執行中？
        /// </summary>
        public bool InMotion
        {
            get { return _inMotion; }
            private set
            {
                if (_inMotion != value)
                {
                    _inMotion = value;
                    NotifyPropertyChanged();
                    //NotifyPropertyChanged(nameof(Ready));
                    NotifyPropertyChanged("Ready");
                }
            }
        }
        private bool _inMotion;

        /********************
         * 其它查詢
         ********************/

        //public List<string> ErrorHistories()
        //{
        //    return _errorHistories;
        //}
    }
}
