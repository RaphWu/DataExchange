﻿namespace ToyoCylinder
{
    /// <summary>
    /// 輸出訊號。
    /// </summary>
    public class PortOut : BindableBase
    {
        /// <summary>
        /// 輸出訊號 01。
        /// </summary>
        /// <remarks>ORG-S。</remarks>
        public bool PortOut01
        {
            get { return _portOut01; }
            set
            {
                if (_portOut01 != value)
                {
                    _portOut01 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut01;

        /// <summary>
        /// 輸出訊號 02。
        /// </summary>
        /// <remarks>INPOSITION。</remarks>
        public bool PortOut02
        {
            get { return _portOut02; }
            set
            {
                if (_portOut02 != value)
                {
                    _portOut02 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut02;

        /// <summary>
        /// 輸出訊號 03。
        /// </summary>
        /// <remarks>READY。</remarks>
        public bool PortOut03
        {
            get { return _portOut03; }
            set
            {
                if (_portOut03 != value)
                {
                    _portOut03 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut03;

        /// <summary>
        /// 輸出訊號 04。
        /// </summary>
        /// <remarks>SERVO-S。</remarks>
        public bool PortOut04
        {
            get { return _portOut04; }
            set
            {
                if (_portOut04 != value)
                {
                    _portOut04 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut04;

        /// <summary>
        /// 輸出訊號 05。
        /// </summary>
        /// <remarks>PRGSEL0-S。</remarks>
        public bool PortOut05
        {
            get { return _portOut05; }
            set
            {
                if (_portOut05 != value)
                {
                    _portOut05 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut05;

        /// <summary>
        /// 輸出訊號 06。
        /// </summary>
        /// <remarks>PRGSEL1-S。</remarks>
        public bool PortOut06
        {
            get { return _portOut06; }
            set
            {
                if (_portOut06 != value)
                {
                    _portOut06 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut06;

        /// <summary>
        /// 輸出訊號 07。
        /// </summary>
        /// <remarks>ALARM。</remarks>
        public bool PortOut07
        {
            get { return _portOut07; }
            set
            {
                if (_portOut07 != value)
                {
                    _portOut07 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut07;

        /// <summary>
        /// 輸出訊號 08。
        /// </summary>
        /// <remarks>MOVE。</remarks>
        public bool PortOut08
        {
            get { return _portOut08; }
            set
            {
                if (_portOut08 != value)
                {
                    _portOut08 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut08;

        /// <summary>
        /// 輸出訊號 09。
        /// </summary>
        /// <remarks>OUT9。</remarks>
        public bool PortOut09
        {
            get { return _portOut09; }
            set
            {
                if (_portOut09 != value)
                {
                    _portOut09 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut09;

        /// <summary>
        /// 輸出訊號 10。
        /// </summary>
        /// <remarks>OUT10。</remarks>
        public bool PortOut10
        {
            get { return _portOut10; }
            set
            {
                if (_portOut10 != value)
                {
                    _portOut10 = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _portOut10;
    }
}