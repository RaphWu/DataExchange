﻿#if DEBUG

namespace ToyoCylinder
{
    /********************
     * DEBUG 用訊息，在 DEBUG 狀態時可擷取訊息用於顯示在畫面上。
     ********************/
    public class DebugMessage : BindableBase
    {
        /// <summary>
        /// 傳送的訊息幀。
        /// </summary>
        public string RequestFrame
        {
            get { return _requestFrame; }
            set
            {
                if (_requestFrame != value)
                {
                    _requestFrame = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _requestFrame;

        /// <summary>
        /// 接收的訊息幀。
        /// </summary>
        public string ResponseFrame
        {
            get { return _responseFrame; }
            set
            {
                if (_responseFrame != value)
                {
                    _responseFrame = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _responseFrame;

        /// <summary>
        /// 一般的 Console 訊息。
        /// </summary>
        public string ConsoleMessage
        {
            get { return _consoleMessage; }
            set
            {
                if (_consoleMessage != value)
                {
                    _consoleMessage = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _consoleMessage;

        /// <summary>
        /// 錯誤訊息。
        /// </summary>
        public string ErrorMessage
        {
            get { return _errorMessage; }
            set
            {
                if (_errorMessage != value)
                {
                    _errorMessage = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private string _errorMessage;
    }
}

#endif