﻿using System;

namespace Calin.TaskPulse.Core.ViewModels
{
    public class SummaryViewModel
    {
        public string WorkOrderNo { get; set; }
        public string Status { get; set; }
        public string MachineId { get; set; }
        public string ModelName { get; set; }
        public string Workstation { get; set; }
        public string Creator { get; set; }
        public DateTime? CreationDate { get; set; }
        public string CreationDateString { get; set; }

        public string MaintenanceUnit { get; set; }
        public string Engineers { get; set; }
        public DateTime? AcceptedTime { get; set; }
        public string AcceptedTimeString { get; set; }
        public string IssueCategory { get; set; }
        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public DateTime? RepairStarted { get; set; }
        public string RepairStartedString { get; set; }
        public DateTime? RepairCompleted { get; set; }
        public string RepairCompletedString { get; set; }
        public TimeSpan RepairDuration { get; set; }
        public string RepairDurationString { get; set; }
        public string FillingTimeString { get; set; }

        public string RequestingUnit { get; set; }
        public string RequestingUnitString { get; set; }
        public string RequestingEmployee { get; set; }
        public string RequestingEmployeeString { get; set; }
        public string Response { get; set; }
        public DateTime? OutageStarted { get; set; }
        public string OutageStartedString { get; set; }
        public DateTime? OutageEnded { get; set; }
        public string OutageEndedString { get; set; }
        public TimeSpan OutageDuration { get; set; }
        public string OutageDurationString { get; set; }

        public string Responsible { get; set; }
        public int OrderNo { get; set; }
    }
}
