﻿namespace Calin.TaskPulse.Core.Models
{
    public class ExcelFlow
    {
        public string Id { get; set; }
        public string WorkOrderNo { get; set; }
        public string Creator { get; set; }
        public string CreationDateTime { get; set; }
        public string MaintenanceUnit { get; set; }
        public string Engineers { get; set; }
        public string MachineId { get; set; }
        public string AcceptedTime { get; set; }
        public string RepairStarted { get; set; }
        public string RepairCompleted { get; set; }
        public string RepairDuration { get; set; }
        public string OutageStarted { get; set; }
        public string OutageEnded { get; set; }
        public string OutageDuration { get; set; }
        public string Responsible { get; set; }
        public string Model { get; set; }
        public string Workstation { get; set; }
        public string IssueCategory { get; set; }
        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public string RequestingUnit { get; set; }
        public string FeedbackEmployee { get; set; }
        public string Status { get; set; }
        public string Feedback { get; set; }
    }
}
