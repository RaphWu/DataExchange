﻿using System.Data.Entity;

namespace Calin.TaskPulse.Core.Models
{
    public class CoreContext : DbContext
    {
        public CoreContext() : base("name=CoreContext") { }

        public DbSet<Authorization> AuthorizationTable { get; set; }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<FactoryLocationList> Factorys { get; set; }
        public DbSet<FactoryPositionList> Positions { get; set; }
        public DbSet<DeviceTypeList> DeviceTypes { get; set; }
        public DbSet<DeviceNameList> DeviceNames { get; set; }
        public DbSet<BrandList> DeviceBrands { get; set; }
        public DbSet<AssetList> AssetLists { get; set; }

        public DbSet<DeviceConditionList> DeviceConditions { get; set; }

        public DbSet<Device> Devices { get; set; } // 所有設備清單

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new CoreInitializer(modelBuilder));

            /********************
             * 設備
             ********************/
            // 設備類別 一對多: DeviceNameList.DeviceType → DeviceTypeList.Id
            modelBuilder.Entity<DeviceNameList>()
                .HasRequired(d => d.Type)
                .WithMany(e => e.DeviceTypes)
                .HasForeignKey(t => t.TypeId)
                .WillCascadeOnDelete(false);

            // 設備名稱 一對多: Device.DeviceName → DeviceNameList.Devices
            modelBuilder.Entity<Device>()
                .HasRequired(d => d.DeviceName)
                .WithMany(e => e.Devices)
                .HasForeignKey(t => t.DeviceNameId)
                .WillCascadeOnDelete(false);

            // 廠牌 一對多: Device.Brand → BrandList.Brands
            modelBuilder.Entity<Device>()
                .HasRequired(d => d.Brand)
                .WithMany(e => e.Brands)
                .HasForeignKey(t => t.BrandId)
                .WillCascadeOnDelete(false);

            // 位置 一對多: FactoryPositionList.Location → FactoryLocationList.Factorys
            modelBuilder.Entity<FactoryPositionList>()
                .HasRequired(d => d.Location)
                .WithMany(e => e.Factorys)
                .HasForeignKey(t => t.LocationId)
                .WillCascadeOnDelete(false);

            // 設備狀態 一對多: Device.Condition → DeviceConditionList.Conditions
            modelBuilder.Entity<Device>()
                .HasRequired(d => d.Condition)
                .WithMany(e => e.Conditions)
                .HasForeignKey(t => t.ConditionId)
                .WillCascadeOnDelete(false);

            // 資產編號 多對一: Device.Assets → AssetList.Device
            modelBuilder.Entity<AssetList>()
                .HasRequired(a => a.Device)
                .WithMany(d => d.Assets)
                .HasForeignKey(a => a.DeviceId)
                .WillCascadeOnDelete(false);
        }
    }
}
