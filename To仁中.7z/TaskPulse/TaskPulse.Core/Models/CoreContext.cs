﻿using System.Data.Entity;

namespace Calin.TaskPulse.Core.Models
{
    public class CoreContext : DbContext
    {
        public CoreContext() : base("name=CoreContext") { }

        public DbSet<Authorization> AuthorizationTable { get; set; }
        public DbSet<Employee> Employees { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer(new CoreInitializer(modelBuilder));
        }
    }
}
