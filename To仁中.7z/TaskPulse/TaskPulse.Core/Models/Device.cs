﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 設備資料。
    /// </summary>
    public class Device
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 設備編號。
        /// </summary>
        [Description("設備編號")]
        public string DeviceId { get; set; }

        /// <summary>
        /// 設備名稱。
        /// </summary>
        [Description("設備名稱")]
        public DeviceNameList DeviceName { get; set; }
        public int DeviceNameId { get; set; } // FK

        /// <summary>
        /// 廠牌。
        /// </summary>
        [Description("廠牌")]
        public BrandList Brand { get; set; }
        public int BrandId { get; set; } // FK

        /// <summary>
        /// 設備序號。
        /// </summary>
        [Description("設備序號")]
        public string SerialNumber { get; set; }

        /// <summary>
        /// 資產編號。
        /// </summary>
        [Description("資產編號")]
        public virtual ICollection<AssetList> Assets { get; set; }

        /// <summary>
        /// 位置。
        /// </summary>
        [Description("位置")]
        public FactoryPositionList Location { get; set; }
        public int LocationId { get; set; } // FK

        /// <summary>
        /// 設備狀態。
        /// </summary>
        [Description("設備狀態")]
        public DeviceConditionList Condition { get; set; }
        public int ConditionId { get; set; } // FK

        /// <summary>
        /// 條碼。
        /// </summary>
        [Description("條碼")]
        public string Barcode { get; set; }

        /// <summary>
        /// 能否連網。
        /// </summary>
        [Description("能否連網")]
        public bool Connected { get; set; }

        /// <summary>
        /// 備註。
        /// </summary>
        [Description("備註")]
        public string Remark { get; set; }
    }
}
