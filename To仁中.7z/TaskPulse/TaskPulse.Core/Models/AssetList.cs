﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    public class AssetList
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [MaxLength(20)]
        public string AssetCode { get; set; }  // 原本的 AssetId 字串

        public int DeviceId { get; set; } // FK
        public virtual Device Device { get; set; }
    }
}
