﻿using System.Collections.Generic;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 核心共用資料。
    /// </summary>
    public class CoreData : ObservableObject
    {
        /// <summary>
        /// 員工名冊。
        /// </summary>
        public List<Employee> EmployeeList
        {
            get { return _employeeList; }
            set { SetProperty(ref _employeeList, value); }
        }
        private List<Employee> _employeeList;
    }
}
