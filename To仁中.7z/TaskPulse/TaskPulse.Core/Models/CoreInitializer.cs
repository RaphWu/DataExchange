﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using SQLite.CodeFirst;

namespace Calin.TaskPulse.Core.Models
{
    /********************
     * SqliteDropCreateDatabaseAlways // 每次執行都刪除並重建資料庫
     * SqliteCreateDatabaseIfNotExists // 如果資料庫不存在，則建立資料庫並初始化預設資料。
     * SqliteDropCreateDatabaseWhenModelChanges // 如果模型有變更，則刪除並重建資料庫。
     ********************/
    /// <summary>
    /// Code First 初始化類別。
    /// </summary>
    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
    public class CoreInitializer : SqliteCreateDatabaseIfNotExists<CoreContext>
    {
        public CoreInitializer(DbModelBuilder modelBuilder) : base(modelBuilder)
        {
        }

        protected override void Seed(CoreContext context)
        {
            var emp = context.Set<Employee>();
            emp.Add(new Employee() { EmployeeId = "08001", Department = "工具&設計課", Name = "蔡孟堅", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08002", Department = "工具&設計課", Name = "鄭大德", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08003", Department = "工具&設計課", Name = "李起修", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08004", Department = "工具&設計課", Name = "葉柏均", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08005", Department = "工具&設計課", Name = "曾惠鈴", IsEngineer = true });
            emp.Add(new Employee() { EmployeeId = "08006", Department = "第一製造部", Name = "蔡素貞" });
            emp.Add(new Employee() { EmployeeId = "08007", Department = "第一製造部", Name = "張志榮" });
            emp.Add(new Employee() { EmployeeId = "08008", Department = "第一製造部", Name = "賴惠珠" });
            emp.Add(new Employee() { EmployeeId = "08009", Department = "第一製造部", Name = "侯倩玉" });
            emp.Add(new Employee() { EmployeeId = "08010", Department = "第一製造部", Name = "李雅婷" });
            emp.Add(new Employee() { EmployeeId = "08011", Department = "第一製造部", Name = "彭紹軒" });
            emp.Add(new Employee() { EmployeeId = "08012", Department = "第一製造部", Name = "黎氏鳳" });
            emp.Add(new Employee() { EmployeeId = "08013", Department = "第一製造部", Name = "阮碧幸" });
            emp.Add(new Employee() { EmployeeId = "08014", Department = "第一製造部", Name = "盧海燕" });
            emp.Add(new Employee() { EmployeeId = "08015", Department = "第一製造部", Name = "余沂霈" });
            emp.Add(new Employee() { EmployeeId = "08016", Department = "第一製造部", Name = "楊瓊瑛" });
            emp.Add(new Employee() { EmployeeId = "08017", Department = "組裝製造部", Name = "陳寶琴" });
            emp.Add(new Employee() { EmployeeId = "08018", Department = "組裝製造部", Name = "劉名峻" });
            emp.Add(new Employee() { EmployeeId = "08019", Department = "組裝製造部", Name = "黃琪雯" });
            emp.Add(new Employee() { EmployeeId = "08020", Department = "組裝製造部", Name = "黃姿蓉" });
            emp.Add(new Employee() { EmployeeId = "08021", Department = "組裝製造部", Name = "林承翰" });
            emp.Add(new Employee() { EmployeeId = "08022", Department = "組裝製造部", Name = "雷舒涵" });
            emp.Add(new Employee() { EmployeeId = "08023", Department = "組裝製造部", Name = "黃嘉惠" });
            emp.Add(new Employee() { EmployeeId = "08024", Department = "組裝製造部", Name = "蔡素真" });
            emp.Add(new Employee() { EmployeeId = "08025", Department = "組裝製造部", Name = "黃玉紅" });
            emp.Add(new Employee() { EmployeeId = "08026", Department = "組裝製造部", Name = "許凱婷" });
            emp.Add(new Employee() { EmployeeId = "08027", Department = "組裝製造部", Name = "林昆達" });
            emp.Add(new Employee() { EmployeeId = "08028", Department = "組裝製造部", Name = "晉玉樹" });
            emp.Add(new Employee() { EmployeeId = "08029", Department = "工具&設計課", Name = "謝定傑", IsEngineer = true });

            var fll = context.Set<FactoryLocationList>();
            fll.Add(new FactoryLocationList() { Location = "本廠" });
            fll.Add(new FactoryLocationList() { Location = "區北廠" });
            fll.Add(new FactoryLocationList() { Location = "嘉義廠" });

            var dtl = context.Set<DeviceTypeList>();
            dtl.Add(new DeviceTypeList() { Name = "打壓機" });
            dtl.Add(new DeviceTypeList() { Name = "插入機" });
            dtl.Add(new DeviceTypeList() { Name = "斜點膠機" });
            dtl.Add(new DeviceTypeList() { Name = "桌上型點膠機" });
            dtl.Add(new DeviceTypeList() { Name = "中壓式熔著機" });
            dtl.Add(new DeviceTypeList() { Name = "21039自動線" });
            dtl.Add(new DeviceTypeList() { Name = "21040自動線" });
            dtl.Add(new DeviceTypeList() { Name = "21041自動線" });
            dtl.Add(new DeviceTypeList() { Name = "21042自動線" });
            dtl.Add(new DeviceTypeList() { Name = "21043自動線" });
            dtl.Add(new DeviceTypeList() { Name = "21044自動線" });
            dtl.Add(new DeviceTypeList() { Name = "21045自動線" });
            dtl.Add(new DeviceTypeList() { Name = "UV照射機" });
            dtl.Add(new DeviceTypeList() { Name = "氣動式出膠機" });
            dtl.Add(new DeviceTypeList() { Name = "氣密檢漏儀" });
            dtl.Add(new DeviceTypeList() { Name = "氣密自動檢測設備" });
            dtl.Add(new DeviceTypeList() { Name = "半自動鎖附機" });
            dtl.Add(new DeviceTypeList() { Name = "PF機" });
            dtl.Add(new DeviceTypeList() { Name = "儀科MTF機" });
            dtl.Add(new DeviceTypeList() { Name = "鬼影機" });
            dtl.Add(new DeviceTypeList() { Name = "鉚合機" });
            dtl.Add(new DeviceTypeList() { Name = "切割機" });
            dtl.Add(new DeviceTypeList() { Name = "高度量測" });
            dtl.Add(new DeviceTypeList() { Name = "自動組裝機" });
            dtl.Add(new DeviceTypeList() { Name = "自動整列機" });
            dtl.Add(new DeviceTypeList() { Name = "高速點膠機" });
            dtl.Add(new DeviceTypeList() { Name = "自動鎖附機" });
            dtl.Add(new DeviceTypeList() { Name = "三合一點膠機" });
            dtl.Add(new DeviceTypeList() { Name = "貼膜設備" });
            dtl.Add(new DeviceTypeList() { Name = "調芯機" });

            var dbl = context.Set<BrandList>();
            dbl.Add(new BrandList() { Name = "自製" });
            dbl.Add(new BrandList() { Name = "晟普" });
            dbl.Add(new BrandList() { Name = "點膠科技" });
            dbl.Add(new BrandList() { Name = "稼動科技" });
            dbl.Add(new BrandList() { Name = "立璽(LIHSI)" });
            dbl.Add(new BrandList() { Name = "高興易" });
            dbl.Add(new BrandList() { Name = "衫綺" });
            dbl.Add(new BrandList() { Name = "勛凱" });
            dbl.Add(new BrandList() { Name = "USHIO" });
            dbl.Add(new BrandList() { Name = "KGN" });
            dbl.Add(new BrandList() { Name = "MUSASHI" });
            dbl.Add(new BrandList() { Name = "IEI(iwashitainstrumemt)" });
            dbl.Add(new BrandList() { Name = "九驊" });
            dbl.Add(new BrandList() { Name = "儀科" });
            dbl.Add(new BrandList() { Name = "客戶製" });
            dbl.Add(new BrandList() { Name = "元利盛(EVEST)" });
            dbl.Add(new BrandList() { Name = "翔元(SYAUTO)" });
            dbl.Add(new BrandList() { Name = "瀚升" });
            dbl.Add(new BrandList() { Name = "儀銳" });

            var dcl = context.Set<DeviceConditionList>();
            dcl.Add(new DeviceConditionList() { Condition = "稼動中" });
            dcl.Add(new DeviceConditionList() { Condition = "停動中" });
            dcl.Add(new DeviceConditionList() { Condition = "檢討室" });
            dcl.Add(new DeviceConditionList() { Condition = "RD檢討室" });
            dcl.Add(new DeviceConditionList() { Condition = "微小倉庫" });
            dcl.Add(new DeviceConditionList() { Condition = "試作線上" });

            context.SaveChanges();

            int recCount = 0;
            try
            {
                using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                {
                    var devices = context.Set<Device>();
                    var dnl = context.Set<DeviceNameList>();
                    var fpl = context.Set<FactoryPositionList>();
                    var ass = context.Set<AssetList>();

                    while (sr.Peek() != -1)
                    {
                        recCount++;
                        string[] data = sr.ReadLine().Split('\t');

                        if (recCount > 1) // 去掉標題
                        {
                            var device = new Device();
                            context.Devices.Add(device);
                            context.SaveChanges();

                            string deviceId = data[0].Trim();
                            device.DeviceId = deviceId;

                            var dType = data[1].Trim();
                            var mName = data[3].Trim();
                            var oName = dnl.FirstOrDefault(x => x.Model == mName && x.Type.Name == dType);
                            if (oName == null)
                            {
                                var odType = dtl.FirstOrDefault(x => x.Name == dType);
                                oName = new DeviceNameList()
                                {
                                    Type = odType,
                                    Model = mName,
                                };
                                dnl.Add(oName);
                                context.SaveChanges();
                            }
                            device.DeviceName = oName;

                            var bName = data[2].Trim();
                            device.Brand = dbl.FirstOrDefault(x => x.Name == bName);
                            device.SerialNumber = data[4].Trim();

                            if (data[5].StartsWith("\""))
                                data[5] = data[5].Substring(1, data[5].Length - 2);
                            var assets = data[5].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                            .Select(x => x.Trim())
                                            .Where(x => x != "無" && !string.IsNullOrWhiteSpace(x))
                                            .Distinct()
                                            .ToList();
                            var iAss = new List<AssetList>();
                            foreach (var a in assets)
                            {
                                if (!string.IsNullOrWhiteSpace(a))
                                {
                                    var oAss = ass.FirstOrDefault(x => x.AssetCode == a);
                                    if (oAss == null)
                                    {
                                        oAss = new AssetList()
                                        {
                                            DeviceId = device.Id,
                                            AssetCode = a,
                                        };
                                        ass.Add(oAss);
                                        context.SaveChanges();
                                    }
                                    iAss.Add(oAss);
                                }
                            }
                            device.Assets = (iAss.Count > 0) ? iAss : null;

                            var loc = data[6].Trim();
                            var pos = data[7].Trim();
                            var opos = fpl.FirstOrDefault(x => x.Position == pos && x.Location.Location == loc);
                            if (opos == null)
                            {
                                opos = new FactoryPositionList()
                                {
                                    Location = fll.FirstOrDefault(x => x.Location == loc),
                                    Position = pos,
                                };
                                fpl.Add(opos);
                                context.SaveChanges();
                            }
                            device.Location = opos;

                            var cond = data[8].Trim();
                            device.Condition = dcl.FirstOrDefault(x => x.Condition == cond);
                            device.Barcode = data[9].Trim();
                            device.Connected = !string.IsNullOrWhiteSpace(data[10].Trim());
                            device.Remark = data[11].Trim();

                            context.SaveChanges();
                        }
                    }
                }
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    Console.WriteLine($"Entity of type '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                    }
                }

                throw; // 若你要繼續丟出錯誤
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            base.Seed(context);
        }
    }
}
