﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 廠牌清單。
    /// </summary>
    public class BrandList
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 廠牌。
        /// </summary>
        [Description("廠牌")]
        [Required]
        public string Name { get; set; }

        public virtual ICollection<Device> Brands { get; set; } // 廠牌
    }
}
