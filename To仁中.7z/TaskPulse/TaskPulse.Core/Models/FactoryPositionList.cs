﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 設備所在位置。
    /// </summary>
    public class FactoryPositionList
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PositionId { get; set; }

        /// <summary>
        /// 廠區。
        /// </summary>
        [Description("廠區")]
        public FactoryLocationList Location { get; set; }
        public int LocationId { get; set; } // FK

        /// <summary>
        /// 位置。
        /// </summary>
        [Description("位置")]
        public string Position { get; set; }

        /// <summary>
        /// 廠別 - 位置。
        /// </summary>
        [NotMapped]
        public string LocPos
        {
            get
            {
                string ret = "";
                bool hasLoc = !string.IsNullOrWhiteSpace(Location.Location);
                bool hasPos = !string.IsNullOrWhiteSpace(Position);

                if (hasLoc)
                {
                    ret = Location.Location;
                    if (hasPos)
                        ret += " - ";
                }

                if (hasPos)
                    ret += Position;

                return ret;
            }
        }
    }
}
