﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 設備類別清單。
    /// </summary>
    public class DeviceTypeList
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 設備類別名稱。
        /// </summary>
        [Description("設備別名稱")]
        [Required]
        public string Name { get; set; }

        public virtual ICollection<DeviceNameList> DeviceTypes { get; set; } // 設備類別
    }
}
