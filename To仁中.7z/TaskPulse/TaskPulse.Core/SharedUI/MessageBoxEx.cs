﻿using System.Drawing;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.SharedUI
{
    public class MessageBoxEx
    {
        public static DialogResult Show(string text)
        {
            return Show(text, string.Empty, MessageBoxButtons.OK, MessageBoxIcon.None, 11, Color.Black, Color.White);
        }

        public static DialogResult Show(string text, string caption)
        {
            return Show(text, caption, MessageBoxButtons.OK, MessageBoxIcon.None, 11, Color.Black, Color.White);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons)
        {
            return Show(text, caption, buttons, MessageBoxIcon.None, 11, Color.Black, Color.White);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return Show(text, caption, buttons, icon, 11, Color.Black, Color.White);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, float fontSize)
        {
            return Show(text, caption, buttons, icon, fontSize, Color.Black, Color.White);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, float fontSize, Color foreColor)
        {
            return Show(text, caption, buttons, icon, fontSize, foreColor, Color.White);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, float fontSize, Color foreColor, Color backColor)
        {
            using (var form = new MessageBoxExForm())
            {
                form.Title = caption;
                form.MessageText = text;
                form.MessageButtons = buttons;
                form.MessageIcon = icon;
                form.FontSize = fontSize;
                form.ForegroundColor = foreColor;
                form.BackgroundColor = backColor;
                form.SetupMessageBox();
                return form.ShowDialog();
            }
        }

        private class MessageBoxExForm : Form
        {
            public string Title { get; set; }
            public string MessageText { get; set; }
            public MessageBoxButtons MessageButtons { get; set; }
            public MessageBoxIcon MessageIcon { get; set; }
            public float FontSize { get; set; }
            public Color ForegroundColor { get; set; }
            public Color BackgroundColor { get; set; }

            private Label lblTitle;
            private Label lblMessage;
            private PictureBox picIcon;
            private Panel panelButtons;

            public MessageBoxExForm()
            {
                this.FormBorderStyle = FormBorderStyle.None;
                this.StartPosition = FormStartPosition.CenterScreen;
                this.MaximizeBox = false;
                this.MinimizeBox = false;
                this.ShowInTaskbar = false;
                this.BackColor = BackgroundColor;
                this.AutoSize = true;
                this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            }

            public void SetupMessageBox()
            {
                TableLayoutPanel tlp = new TableLayoutPanel();
                tlp.RowCount = 3;
                tlp.ColumnCount = 2;
                tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
                tlp.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, 60f));
                tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60f));
                tlp.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
                tlp.BackColor = Color.White;
                tlp.AutoSize = true;
                tlp.AutoSizeMode = AutoSizeMode.GrowAndShrink;
                this.Controls.Add(tlp);

                // Title
                lblTitle = new Label();
                lblTitle.Text = Title;
                lblTitle.TextAlign = ContentAlignment.MiddleLeft;
                lblTitle.Margin = new Padding(0);
                lblTitle.Padding = new Padding(12, 0, 12, 0);
                lblTitle.Dock = DockStyle.Fill;
                lblTitle.Font = new Font(CommonStyles.FontFamily, 12f);
                lblTitle.ForeColor = Color.White;
                lblTitle.BackColor = CommonStyles.BackColor;
                tlp.Controls.Add(lblTitle, 0, 0);
                tlp.SetColumnSpan(lblTitle, 2);

                // 圖示
                picIcon = new PictureBox();
                picIcon.Location = new Point(20, 20);
                picIcon.Size = new Size(32, 32);
                picIcon.SizeMode = PictureBoxSizeMode.StretchImage;
                picIcon.Margin = new Padding(0, 9, 0, 0);
                picIcon.Anchor = AnchorStyles.Top;
                tlp.Controls.Add(picIcon, 0, 1);

                Icon messageIcon = GetMessageBoxIcon(MessageIcon);
                if (messageIcon != null)
                {
                    picIcon.Image = messageIcon.ToBitmap();
                    picIcon.Visible = true;
                }
                else
                {
                    picIcon.Visible = false;
                }

                // 訊息文字
                lblMessage = new Label();
                lblMessage.Text = MessageText;
                lblMessage.TextAlign = ContentAlignment.TopLeft;
                lblMessage.MinimumSize = new Size(120, 70);
                lblMessage.AutoSize = true;
                lblMessage.Dock = DockStyle.Fill;
                lblMessage.Font = CommonStyles.Font;
                lblMessage.Padding = new Padding(9, 12, 9, 9);
                lblMessage.ForeColor = ForegroundColor;
                lblMessage.BackColor = BackgroundColor;
                lblMessage.BackColor = Color.LightBlue;
                tlp.Controls.Add(lblMessage, 1, 1);

                // 按鈕面板
                panelButtons = new Panel();
                panelButtons.Dock = DockStyle.Fill;
                panelButtons.BackColor = Color.WhiteSmoke;
                tlp.Controls.Add(panelButtons, 0, 2);
                tlp.SetColumnSpan(panelButtons, 2);

                CreateButtons();
            }

            private void CreateButtons()
            {
                Button[] buttons = null;
                int buttonWidth = 100;
                int buttonHeight = 30;
                int spacing = 10;

                switch (MessageButtons)
                {
                    case MessageBoxButtons.OK:
                        buttons = new Button[1];
                        buttons[0] = CreateButton("確定", DialogResult.OK);
                        CommonStyles.SetButton(buttons[0]);
                        break;

                    case MessageBoxButtons.OKCancel:
                        buttons = new Button[2];
                        buttons[0] = CreateButton("確定", DialogResult.OK);
                        buttons[1] = CreateButton("取消", DialogResult.Cancel);
                        CommonStyles.SetButton(buttons[0]);
                        CommonStyles.SetButton(buttons[1], isCancel: true);
                        this.CancelButton = buttons[1];
                        break;

                    case MessageBoxButtons.YesNo:
                        buttons = new Button[2];
                        buttons[0] = CreateButton("是(&Y)", DialogResult.Yes);
                        buttons[1] = CreateButton("否(&N)", DialogResult.No);
                        CommonStyles.SetButton(buttons[0]);
                        CommonStyles.SetButton(buttons[1], isCancel: true);
                        this.CancelButton = buttons[1];
                        break;

                    case MessageBoxButtons.YesNoCancel:
                        buttons = new Button[3];
                        buttons[0] = CreateButton("是(&Y)", DialogResult.Yes);
                        buttons[1] = CreateButton("否(&N)", DialogResult.No);
                        buttons[2] = CreateButton("取消", DialogResult.Cancel);
                        CommonStyles.SetButton(buttons[0]);
                        CommonStyles.SetButton(buttons[1]);
                        CommonStyles.SetButton(buttons[2], isCancel: true);
                        this.CancelButton = buttons[2];
                        break;

                    case MessageBoxButtons.RetryCancel:
                        buttons = new Button[2];
                        buttons[0] = CreateButton("重試(&R)", DialogResult.Retry);
                        buttons[1] = CreateButton("取消", DialogResult.Cancel);
                        CommonStyles.SetButton(buttons[0]);
                        CommonStyles.SetButton(buttons[1], isCancel: true);
                        this.CancelButton = buttons[1];
                        break;

                    case MessageBoxButtons.AbortRetryIgnore:
                        buttons = new Button[3];
                        buttons[0] = CreateButton("中止(&A)", DialogResult.Abort);
                        buttons[1] = CreateButton("重試(&R)", DialogResult.Retry);
                        buttons[2] = CreateButton("略過(&I)", DialogResult.Ignore);
                        CommonStyles.SetButton(buttons[0]);
                        CommonStyles.SetButton(buttons[1]);
                        CommonStyles.SetButton(buttons[2]);
                        this.CancelButton = buttons[0];
                        break;
                }

                if (buttons != null && buttons.Length > 0)
                {
                    int totalWidth = buttons.Length * buttonWidth + (buttons.Length - 1) * spacing;
                    int startX = (panelButtons.ClientSize.Width - totalWidth) / 2;
                    int centerY = (panelButtons.ClientSize.Height - buttonHeight) / 2;

                    for (int i = 0; i < buttons.Length; i++)
                    {
                        buttons[i].Size = new Size(buttonWidth, buttonHeight);
                        buttons[i].Location = new Point(startX + i * (buttonWidth + spacing), centerY);
                        buttons[i].Anchor = AnchorStyles.None;
                        panelButtons.Controls.Add(buttons[i]);
                    }

                    //for (int i = 0; i < buttons.Length; i++)
                    //{
                    //    buttons[i].Location = new Point(i * (buttonWidth + spacing), 0);
                    //    buttons[i].Size = new Size(buttonWidth, buttonHeight);
                    //    panelButtons.Controls.Add(buttons[i]);
                    //}
                }
            }

            private Button CreateButton(string text, DialogResult result)
            {
                var button = new Button();
                button.Text = text;
                button.DialogResult = result;
                button.Margin = new Padding(9);
                button.FlatStyle = FlatStyle.System;
                return button;
            }

            private Icon GetMessageBoxIcon(MessageBoxIcon icon)
            {
                switch (icon)
                {
                    case MessageBoxIcon.Error:
                        return SystemIcons.Error;
                    case MessageBoxIcon.Question:
                        return SystemIcons.Question;
                    case MessageBoxIcon.Warning:
                        return SystemIcons.Warning;
                    case MessageBoxIcon.Information:
                        return SystemIcons.Information;
                    default:
                        return null;
                }
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                ControlPaint.DrawBorder(
                    e.Graphics,
                    this.ClientRectangle,
                    CommonStyles.BackColor,
                    ButtonBorderStyle.Solid);
            }
        }
    }
}
