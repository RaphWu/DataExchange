﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 機種快取已更新通知。
    /// </summary>
    public class NotifyModelCacheUpdated
    {
        public static readonly NotifyModelCacheUpdated Instance = new NotifyModelCacheUpdated();
        private NotifyModelCacheUpdated() { }
    }
}
