﻿using Calin.TaskPulse.Core.Authority.Models;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 使用者切換訊息。
    /// </summary>
    public class LoggedInUserChangedMessage : ValueChangedMessage<CurrentAuthority>
    {
        public LoggedInUserChangedMessage(CurrentAuthority ca) : base(ca) { }
    }
}
