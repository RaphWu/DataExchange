﻿namespace Calin.TaskPulse.Core.Contract
{
    public interface ICrudService
    {
    }
}
