﻿namespace Calin.TaskPulse.Core.Contract
{
    public interface ICore
    {
        /// <summary>
        /// 更新員工名冊。
        /// </summary>
        void UpdateEmplyees();
    }
}
