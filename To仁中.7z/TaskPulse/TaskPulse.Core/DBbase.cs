﻿namespace Calin.TaskPulse.Core
{
    /// <summary>
    /// 資料庫 基本資訊。
    /// </summary>
    public static class DBbase
    {
        /// <summary>
        /// 資料庫檔案的副檔名。
        /// </summary>
        public const string DB_ExtFileName = ".db";

        /// <summary>
        /// SQLite資料庫檔案的副檔名。
        /// </summary>
        public const string SQLite_ExtFileName = ".sqlite";

        /// <summary>
        /// EXCEL檔案的副檔名。
        /// </summary>
        public const string Excel_ExtFileName = ".xlsx";

        /// <summary>
        /// 目前工作目錄 = 資料存放位置。
        /// </summary>
        public static string Directory_Base = System.AppContext.BaseDirectory;
        //public static string Directory_Base = AppDomain.CurrentDomain.BaseDirectory;
        //public static readonly string Directory_Base = Environment.CurrentDirectory;

        /********************
         * 資料夾
         ********************/
        /// <summary>
        /// System資料庫檔名。
        /// </summary>
        public static string DbName_System = $"TaskPulse{SQLite_ExtFileName}";
    }
}
