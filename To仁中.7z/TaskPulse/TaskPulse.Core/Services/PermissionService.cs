﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Services
{
    public class PermissionService : IPermissionService
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MemoryCacheService _cache;
        private readonly CurrentUserContext _user;
        //private readonly ConcurrentDictionary<int, List<string>> _userPermissionCache
        //= new ConcurrentDictionary<int, List<string>>();

        public PermissionService(CoreContext coreContext,
                                 CoreData coreData,
                                 MemoryCacheService cache,
                                 CurrentUserContext currentUserContext)
        {
            _context = coreContext;
            _coreData = coreData;
            _cache = cache;
            _user = currentUserContext;
        }

        /********************
         * from CurrentUserContext
         * 為了一些
         ********************/
        /// <inheritdoc/>
        public bool IsAdmin => _user.IsAdmin;

        /// <inheritdoc/>
        public bool IsGuest => _user.IsGuest;

        /********************
         * Employee Permissions
         ********************/
        /// <inheritdoc/>
        public HashSet<PermissionData> GetFullPermissions(string employeeId)
        {
            //string cacheKey = $"UserPermissions:{employeeId}";
            //return _cache.GetOrCreate(cacheKey, policy =>
            //{
            var user = _context.Employees
               .Include(u => u.Department.Permissions)
               .Include(u => u.Permissions)
               .Include(u => u.UserGroups.Select(g => g.Permissions))
               .AsNoTracking()
               .FirstOrDefault(u => u.EmployeeId == employeeId);

            if (user == null || user.StatusId != _coreData.IsActiveEmployee)
                return new HashSet<PermissionData>();

            if (user.Id == int.MaxValue)
                return new HashSet<PermissionData> { new PermissionData { PermissionString = "*" } };

            var permissions = new HashSet<PermissionData>();

            // 部門權限
            permissions.UnionWith(ToPermissionDataSet(user.Department.Permissions));

            // 群組權限
            if (user.UserGroups.Count > 0)
            {
                foreach (var g in user.UserGroups)
                    permissions.UnionWith(ToPermissionDataSet(g.Permissions));
            }

            // 使用者個人權限
            permissions.UnionWith(ToPermissionDataSet(user.Permissions));

            return permissions;
            //}, TimeSpan.FromMinutes(30));
        }

        /// <inheritdoc/>
        public HashSet<PermissionData> GetUserPermissions(string employeeId)
        {
            string cacheKey = $"UserPermissions:{employeeId}";
            return _cache.GetOrCreate(cacheKey, policy =>
            {
                var user = _context.Employees
                    .Include(u => u.Department.Permissions)
                    .Include(u => u.UserGroups)
                    .Include(u => u.Permissions)
                    .FirstOrDefault(u => u.EmployeeId == employeeId);

                if (user == null || user.StatusId != _coreData.IsActiveEmployee)
                    return new HashSet<PermissionData>();

                if (user.Id == int.MaxValue)
                    return new HashSet<PermissionData> { new PermissionData { PermissionString = "*" } };

                return ToPermissionDataSet(user.Permissions);
            }, TimeSpan.FromMinutes(30));
        }

        /// <inheritdoc/>
        public bool HasPermission(string employeeId, string permission)
        {
            if (_user.IsAdmin)
                return true;

            var user = _context.Employees.FirstOrDefault(u => u.EmployeeId == employeeId);
            if (user == null)
                return false;

            var all = GetFullPermissions(employeeId);
            return all.Any(p => IsMatch(p, permission));
        }

        /********************
         * Department Permissions
         ********************/
        /// <inheritdoc/>
        public HashSet<PermissionData> GetDepartmentPermissions(int departmentId)
        {
            string cacheKey = $"DepartmentPermissions:{departmentId}";
            return _cache.GetOrCreate(cacheKey, policy =>
            {
                var dept = _context.Departments
                    .Include(d => d.Permissions)
                    .FirstOrDefault(u => u.Id == departmentId);
                return ToPermissionDataSet(dept?.Permissions);
            }, TimeSpan.FromMinutes(30));
        }

        /********************
         * UserGroup Permissions
         ********************/
        /// <inheritdoc/>
        public HashSet<PermissionData> GetUserGroupPermissions(int groupId)
        {
            string cacheKey = $"UserGroupPermissions:{groupId}";
            return _cache.GetOrCreate(cacheKey, policy =>
            {
                var group = _context.UserGroups
                    .Include(g => g.Permissions)
                    .FirstOrDefault(u => u.Id == groupId);
                return ToPermissionDataSet(group?.Permissions);
            }, TimeSpan.FromMinutes(30));
        }

        /********************
         * Utilities
         ********************/
        /// <inheritdoc/>
        public async Task CleanOrphanPermissions()
        {
            await _context.Database.ExecuteSqlCommandAsync(@"
                DELETE FROM Permissions
                WHERE Id NOT IN (
                    SELECT DISTINCT PermissionId FROM EmployeePermissions
                    UNION
                    SELECT DISTINCT PermissionId FROM DepartmentPermissions
                    UNION
                    SELECT DISTINCT PermissionId FROM UserGroupPermissions
                )");

            //var orphanPerms = await _context.Permissions
            //    .Where(p =>
            //        !p.Employees.Any() &&
            //        !p.Departments.Any() &&
            //        !p.UserGroups.Any())
            //    .ToListAsync();

            //if (orphanPerms.Any())
            //{
            //    foreach (var perm in orphanPerms)
            //    {
            //        // 確保中介表無關聯資料
            //        _context.Entry(perm).Collection(p => p.Employees).Load();
            //        _context.Entry(perm).Collection(p => p.Departments).Load();
            //        _context.Entry(perm).Collection(p => p.UserGroups).Load();

            //        perm.Employees.Clear();
            //        perm.Departments.Clear();
            //        perm.UserGroups.Clear();

            //        _context.Permissions.Remove(perm);
            //    }

            //    await _context.SaveChangesAsync();
            //}
        }

        /// <summary>
        /// 將 EF 實體轉成權限集合。
        /// </summary>
        /// <param name="permissions"></param>
        /// <returns></returns>
        private HashSet<PermissionData> ToPermissionDataSet(IEnumerable<Permission> permissions)
        {
            var result = new HashSet<PermissionData>();
            if (permissions == null)
                return result;

            foreach (var p in permissions)
            {
                result.Add(new PermissionData
                {
                    Id = p.Id,
                    Module = p.Module,
                    Page = p.Page,
                    Control = p.Control,
                    Action = p.Action,
                    PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}"
                });
            }
            return result;
        }

        /// <summary>
        /// 權限比對，支援萬用字元。
        /// </summary>
        /// <param name="granted">已授權的權限字串。</param>
        /// <param name="target">目標權限字串。</param>
        /// <returns>傳回是否匹配。</returns>
        private bool IsMatch(PermissionData p, string permission)
        {
            if (p == null || string.IsNullOrEmpty(permission))
                return false;

            if (p.PermissionString == "*")
                return true;

            var parts = permission.Split(':');
            if (parts.Length != 4)
                return false;

            return string.Equals(p.Module, parts[0], StringComparison.OrdinalIgnoreCase)
                && string.Equals(p.Page, parts[1], StringComparison.OrdinalIgnoreCase)
                && string.Equals(p.Control, parts[2], StringComparison.OrdinalIgnoreCase)
                && string.Equals(p.Action, parts[3], StringComparison.OrdinalIgnoreCase);
        }

        /********************
         * Control Access
         ********************/
        /// <summary>
        /// 1. 提取並統一權限比對邏輯到 private helper `HasControlAccessInternal`：
        ///    - 若 current user 為 Admin，直接回傳 true。
        ///    - 若使用者權限集合為 null 或空，回傳 false。
        ///    - 逐一檢查使用者的 PermissionData，跳過 null 條目。
        ///    - 若 PermissionString 為 "*"，回傳 true (全域允許)。
        ///    - 對每個 segment (Module, Page, Control) 依序檢查：
        ///        * 若 permission segment 為 "**"，表示任何後續層級皆允許 -> 回傳 true。
        ///        * 若 permission segment 為 "*"，表示此層級任意值皆可 -> 視為 match，繼續檢查下一層級。
        ///        * 否則：若 caller 傳入對應 target 為 null，表示 caller 要求「任意」 -> 視為 match；
        ///               否則比較 permission 與 target 是否相等，不相等則跳到下一個 permission。
        ///    - 當到 action 層級時：
        ///        * 若 caller 傳入 action 為 null (表示 caller 僅檢查到 control/page/module 層級即可)，
        ///          回傳 true（代表找到符合的 permission）
        ///        * 否則依原邏輯比對 action (支援 "**", "*", 精確比對)。
        /// 2. 將原先四參數 public 方法改為呼叫 helper 以保持原本的細節與萬用字支援。
        /// 3. 將其餘三個 overload 簡化為傳遞 null 表示該層級為「任意」，以達到 O(1) 的查詢邏輯並統一行為。
        /// 4. 保持 StringComparison.OrdinalIgnoreCase，並避免重複程式碼。 
        /// </summary>
        /// <param name="module"></param>
        /// <param name="page"></param>
        /// <param name="control"></param>
        /// <param name="action"></param>
        /// <returns>是否有權限。</returns>
        private bool HasControlAccessInternal(string module, string page, string control, string action)
        {
            if (_user.IsAdmin)
                return true;

            if (_user.Permissions == null || !_user.Permissions.Any())
                return false;

            var cmp = StringComparison.OrdinalIgnoreCase;

            foreach (var p in _user.Permissions)
            {
                if (p == null)
                    continue;

                if (string.Equals(p.PermissionString, "*", cmp))
                    return true;

                // Module 層級
                if (string.Equals(p.Module, "**", cmp))
                    return true;
                else if (!string.Equals(p.Module, "*", cmp))
                {
                    if (module != null)
                    {
                        if (!string.Equals(p.Module, module, cmp))
                            continue;
                    }
                    // module == null 表示 caller 不關心 module，視為 match
                }

                // Page 層級
                if (string.Equals(p.Page, "**", cmp))
                    return true;
                else if (!string.Equals(p.Page, "*", cmp))
                {
                    if (page != null)
                    {
                        if (!string.Equals(p.Page, page, cmp))
                            continue;
                    }
                    // page == null 表示 caller 不關心 page，視為 match
                }

                // Control 層級
                if (string.Equals(p.Control, "**", cmp))
                    return true;
                else if (!string.Equals(p.Control, "*", cmp))
                {
                    if (control != null)
                    {
                        if (!string.Equals(p.Control, control, cmp))
                            continue;
                    }
                    // control == null 表示 caller 不關心 control，視為 match
                }

                // Action 層級
                // 若 caller 傳入 action 為 null，表示不需要比對 action（只檢查到 control 層級即可）
                if (action == null)
                    return true;

                if (string.Equals(p.Action, "**", cmp))
                    return true;
                if (string.Equals(p.Action, "*", cmp))
                    return true;
                if (string.Equals(p.Action, action, cmp))
                    return true;
            }

            return false;
        }

        /// <inheritdoc/>
        public bool HasControlAccess(string module, string page, string control, string action)
        {
            return HasControlAccessInternal(module, page, control, action);
        }

        /// <inheritdoc/>
        public bool HasControlAccess(string module, string page, string control)
        {
            // 傳入 action = null 表示「忽略 action 層級」，只檢查到 control 層級
            return HasControlAccessInternal(module, page, control, null);
        }

        /// <inheritdoc/>
        public bool HasControlAccess(string module, string page)
        {
            // 傳入 control = null, action = null 表示只檢查到 page 層級
            return HasControlAccessInternal(module, page, null, null);
        }

        /// <inheritdoc/>
        public bool HasControlAccess(string module)
        {
            // 傳入 page = null, control = null, action = null 表示只檢查到 module 層級
            return HasControlAccessInternal(module, null, null, null);
        }

        /*
         * 四階段來源支援
         *      Department → UserGroup → Individual
         *      同一個權限按來源優先級存入 Dictionary（部門 > 群組 > 個人）
         * 快取整個使用者權限集合
         *      一次查完部門、群組、個人權限
         *      查單個控制項時 O(1)
         * 權限唯一鍵
         *      使用 "Module:Page:Control:Action" 作為 key
         *      避免重複
         * 易擴展
         *      若將來新增其他來源，只需在 Dictionary 內增加來源階段即可
         */
        /// <inheritdoc/>
        public Dictionary<string, PermissionSource> GetPermissionSources(string employeeId)
        {
            string cacheKey = $"UserPermissionSources_{employeeId}";

            return _cache.GetOrCreate(cacheKey, policy =>
            {
                var permissionSources = new Dictionary<string, PermissionSource>();

                // 取得使用者資料及相關關聯
                var user = _context.Employees
                                   .Include(e => e.Department.Permissions)
                                   .Include(e => e.UserGroups.Select(g => g.Permissions))
                                   .Include(e => e.Permissions)
                                   .SingleOrDefault(e => e.EmployeeId == employeeId);

                if (user == null)
                    return permissionSources;

                // 部門權限
                if (user.Department?.Permissions != null)
                {
                    foreach (var p in user.Department.Permissions)
                    {
                        string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                        if (!permissionSources.ContainsKey(key))
                            permissionSources[key] = PermissionSource.Department;
                    }
                }

                // 群組權限
                if (user.UserGroups != null)
                {
                    foreach (var g in user.UserGroups)
                    {
                        if (g.Permissions != null)
                        {
                            foreach (var p in g.Permissions)
                            {
                                string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                                if (!permissionSources.ContainsKey(key))
                                    permissionSources[key] = PermissionSource.UserGroup;
                            }
                        }
                    }
                }

                // 個人權限
                if (user.Permissions != null)
                {
                    foreach (var p in user.Permissions)
                    {
                        string key = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}";
                        if (!permissionSources.ContainsKey(key))
                            permissionSources[key] = PermissionSource.Employee;
                    }
                }

                return permissionSources;

            }, TimeSpan.FromMinutes(30));
        }

        /// <inheritdoc/>
        public PermissionSource GetPermissionSource(string employeeId, string module, string page, string control, string action)
        {
            var sources = GetPermissionSources(employeeId);
            string key = $"{module}:{page}:{control}:{action}";

            return sources.TryGetValue(key, out var source)
                ? source
                : PermissionSource.None;
        }

        /// <inheritdoc/>
        public void ClearUserPermissionSourceCache(string employeeId)
        {
            string cacheKey = $"UserPermissionSources_{employeeId}";
            _cache.Remove(cacheKey);
        }

        /********************
         * Refresh
         ********************/
        /// <inheritdoc/>
        public void RefreshDepartmentPermissions(int departmentId)
        {
            string cacheKey = $"DepartmentPermissions:{departmentId}";
            _cache.Remove(cacheKey);
        }

        /// <inheritdoc/>
        public void RefreshUserGroupPermissions(int userGroupId)
        {
            _cache.Remove($"UserGroupPermissions:{userGroupId}");
        }

        /// <inheritdoc/>
        public void RefreshUserPermissions(string employeeId)
        {
            _cache.Remove($"UserPermissions:{employeeId}");
        }

        /********************
         * 轉換
         ********************/
        /// <inheritdoc/>
        public string LevelToString(string module, string page, string control, string action)
        {
            return $"{module}:{page}:{control}:{action}";
        }

        /// <inheritdoc/>
        public (string module, string page, string control, string action) StringToLevel(string permission)
        {
            var parts = permission?.Split(':').Select(p => p.Trim()).ToArray();
            if (parts == null || parts.Length != 4)
                throw new ArgumentException("permission format must be 'module:page:control:action'");
            return (parts[0], parts[1], parts[2], parts[3]);
        }
    }
}
