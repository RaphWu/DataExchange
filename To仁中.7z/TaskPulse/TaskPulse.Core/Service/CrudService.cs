﻿using Calin.TaskPulse.Core.Contract;

namespace Calin.TaskPulse.Core.Service
{
    public class CrudService : ICrudService
    {
        //    #region fields

        //    private readonly CRUD _crud;

        //    public CrudService(CRUD crud)
        //    {
        //        _crud = crud;
        //    }

        //    #endregion fields

        //    public async Task<(bool, string)> Create(string defaultValue,
        //                             string caption,
        //                             string title,
        //                             string watermark,
        //                             Func<string, (bool isValid, string errorMessage)> validator = null)
        //    {
        //        _crud.OneTextBox(defaultValue, caption, title, caption, validator);
        //        if (_crud.ShowDialog() == DialogResult.OK)
        //        {
        //            MessageBox.Show($"已增加新機種: {newName}",
        //                            "新增成功",
        //                            MessageBoxButtons.OK,
        //                            MessageBoxIcon.Information);
        //            return (true, _crud.ResultString);
        //        }
        //        else
        //        {
        //            return (false, "");
        //        }
        //    }
    }
}
