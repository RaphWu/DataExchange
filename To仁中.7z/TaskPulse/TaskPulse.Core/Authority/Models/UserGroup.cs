﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.Authority
{
    // https://www.uu-lian.com/c2cntpage-c2_356141-c2-8931-21975.html

    /// <summary>
    /// 使用者群組分類。
    /// </summary>
    public enum UserGroup
    {
        [Description("訪客")]
        Guest = 1,

        [Description("員工")]
        Employee = 0x00FF,

        [Description("系統管理員")]
        Admin = 0xFFFF,

        ///********************
        // * 維護部門
        // ********************/
        //[Description("維護部門主管")]
        //MaintenanceManager = 999,

        //[Description("維護工程師")]
        //MaintenanceEngineer = 999,

        ///********************
        // * 研發部門
        // ********************/
        //[Description("研發人員")]
        //RD = 999,

        ///********************
        // * 採購
        // ********************/
        //[Description("採購主管")]
        //ProcurementManager = 1,

        //[Description("採購人員")]
        //Purchasing = 1,

        ///********************
        // * 生產線
        // ********************/
        //[Description("製造主管")]
        //ProductionManager = 1,

        //[Description("產線幹部")]
        //ProductionSupervisor = 1,

        //[Description("訪客")]
        //Operator = 1,
    }
}
