﻿namespace Calin.TaskPulse.Core.Authority.Constants
{
    /// <summary>
    /// 資料庫名稱與定義 - 權限系統。
    /// </summary>
    internal class DB_Authority
    {
        internal const string TableName_Authorization = "DepartmentAuthorization";
        internal const string CreateTableSQL_Authorization = @"CREATE TABLE IF NOT EXISTS [DepartmentAuthorization](
[Key] INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
[OrderNo] INTEGER,
[User] TEXT NOT NULL DEFAULT 'Unknown',
[Password] TEXT NOT NULL,
[DepartmentAuthorization] TEXT NOT NULL);";

        internal const string TableName_Authority = "Authority";
        internal const string CreateTableSQL_Authority = @"CREATE TABLE IF NOT EXISTS [Authority](
[Key] INTEGER,
[InputDetectInterval] INTEGER DEFAULT 5);";
    }
}
