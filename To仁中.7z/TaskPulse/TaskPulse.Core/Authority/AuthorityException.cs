﻿using System;
using System.Runtime.Serialization;

namespace Calin.TaskPulse.Core.Authority
{
    /// <summary>
    /// 權限自訂例外。
    /// </summary>
    internal class AuthorityException : Exception, ISerializable
    {
        public AuthorityException() : base("Authority Error!") { }
        public AuthorityException(string message) : base(message) { }
        public AuthorityException(string message, Exception inner) : base(message, inner) { }
        protected AuthorityException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
