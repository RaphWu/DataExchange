﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class FlowLayoutSelector : UIForm
    {
        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 是否允許多選。
        /// </summary>
        /// <remarks>true=多選 (使用 CheckBox)，false=單選 (使用 RadioButton)。</remarks>
        public bool MultiSelection { get; set; }

        /// <summary>
        /// 返回的項目。
        /// </summary>
        public List<int> ResultList { get; set; }

        /// <summary>
        /// 顯示的項目。
        /// </summary>
        public List<KeyValuePair<int, string>> DisplayList
        {
            set
            {
                uiFlowLayout_List.Clear();
                if (value != null)
                {
                    foreach (var item in value)
                    {
                        if (MultiSelection)
                        {
                            var ctl = new UICheckBox();
                            ctl.SetDPIScale();
                            ctl.Name = item.Key.ToString();
                            ctl.Text = item.Value;
                            ctl.Width = 160;
                            uiFlowLayout_List.Add(ctl);
                        }
                        else
                        {
                            var ctl = new UIRadioButton();
                            ctl.GroupIndex = 0;
                            ctl.SetDPIScale();
                            ctl.Name = item.Key.ToString();
                            ctl.Text = item.Value;
                            ctl.Width = 160;
                            uiFlowLayout_List.Add(ctl);
                        }
                    }
                }
            }
        }

        public FlowLayoutSelector()
        {
            InitializeComponent();
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            ResultList = new List<int>();
            foreach (Control control in uiFlowLayout_List.Controls)
            {
                if (control is FlowLayoutPanel flp)
                {
                    //foreach (var cb in flp.Controls)
                    //{
                    if (MultiSelection)
                    {
                        ResultList = flp.Controls
                            .OfType<UICheckBox>()
                            .Where(cb => cb.Checked)
                            .Select(cb => int.Parse(cb.Name))
                            .ToList();
                    }
                    else
                    {
                        ResultList = flp.Controls
                            .OfType<UIRadioButton>()
                            .Where(rb => rb.Checked)
                            .Select(rb => int.Parse(rb.Name))
                            .ToList();
                    }
                    //}
                }
            }

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
