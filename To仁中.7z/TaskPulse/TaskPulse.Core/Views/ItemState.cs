﻿namespace Calin.TaskPulse.Core.Views
{
    public class ItemState
    {
        public bool IsChecked { get; set; }
        public string Name { get; set; }
        public string Type { get; set; } // 型式
        public string Catalog { get; set; } // 類別
    }
}
