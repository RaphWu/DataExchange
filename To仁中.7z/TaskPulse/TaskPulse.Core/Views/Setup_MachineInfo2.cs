﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineInfo2 : UIUserControl
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly FieldTitle _fieldTitle;
        private readonly CRUD _crud;

        private List<ListViewModel> _vmCategories = null;
        private ListViewModel _vmCategory = null;
        private List<ListViewModel> _vmLocs = null;
        private ListViewModel _vmLoc = null;
        private List<ListViewModel> _vmNames = null;
        private ListViewModel _vmName = null;

        #endregion fields

        public Setup_MachineInfo2(CoreContext coreContext,
                                  CoreData coreData,
                                  FieldTitle fieldTitle,
                                  CRUD crud)
        {
            InitializeComponent();
            _context = coreContext;
            _coreData = coreData;
            _fieldTitle = fieldTitle;
            _crud = crud;

            string itemName = _fieldTitle.MachineCategory;
            HeadLabel_Category.Text = itemName;
            CommonStyles.SetListBox(List_Categories);
            CommonStyles.SetCrudButton(Category_Create, "C", itemName);
            CommonStyles.SetCrudButton(Category_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Category_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Category_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Category_Down, "DOWN", itemName);

            itemName = _fieldTitle.MachineType;
            HeadLabel_Type.Text = itemName;
            CommonStyles.SetListBox(List_Types);
            CommonStyles.SetCrudButton(Type_Create, "C", itemName);
            CommonStyles.SetCrudButton(Type_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Type_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Type_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Type_Down, "DOWN", itemName);

            itemName = _fieldTitle.MachineName;
            HeadLabel_Name.Text = itemName;
            CommonStyles.SetListBox(List_Names);
            CommonStyles.SetCrudButton(Name_Create, "C", itemName);
            CommonStyles.SetCrudButton(Name_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Name_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Name_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Name_Down, "DOWN", itemName);
        }

        private async void Setup_MachineInfo2_Load(object sender, EventArgs e)
        {
            await UpdateCategoriesView();
            await UpdateTypesView();
            await UpdateNamesView();
        }

        /********************
         * Category
         ********************/
        private async Task UpdateCategoriesView()
        {
            var query = await _context.MachineCategories
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmCategories = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.CategoryName, OrderNo = b.OrderNo })
                .ToList();
            List_Categories.DataSource = null;
            List_Categories.ValueMember = nameof(ListViewModel.Id);
            List_Categories.DisplayMember = nameof(ListViewModel.Name);
            List_Categories.DataSource = _vmCategories;
        }


        /********************
         * Type
         ********************/
        private async Task UpdateTypesView()
        {
            var query = await _context.MachineTypes
                .OrderBy(b => b.OrderNo)
                .ToListAsync();
            _vmCategories = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.TypeName, OrderNo = b.OrderNo })
                .ToList();
            List_Types.DataSource = null;
            List_Types.ValueMember = nameof(ListViewModel.Id);
            List_Types.DisplayMember = nameof(ListViewModel.Name);
            List_Types.DataSource = _vmCategories;
        }




        /********************
         * Names
         ********************/
        private async Task UpdateNamesView()
        {
            var query = await _context.MachineNames
                .ToListAsync();
            _vmNames = query
                .Select(b => new ListViewModel { Id = b.Id, Name = b.ModelName })
                .ToList();
            List_Names.DataSource = null;
            List_Names.ValueMember = nameof(ListViewModel.Id);
            List_Names.DisplayMember = nameof(ListViewModel.Name);
            List_Names.DataSource = _vmNames;
        }
    }
}
