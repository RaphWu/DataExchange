﻿using System;
using System.Windows.Forms;
using Sunny.UI;

public static class DateTimePickerExtensions
{
    /// <summary>
    /// 綁定可空 DateTime 屬性到 DateTimePicker，null 顯示空白
    /// </summary>
    public static void BindNullableDateTime(this UIDatetimePicker picker, object dataSource, string dataMember)
    {
        if (picker == null) throw new ArgumentNullException(nameof(picker));
        if (dataSource == null) throw new ArgumentNullException(nameof(dataSource));
        if (string.IsNullOrEmpty(dataMember)) throw new ArgumentNullException(nameof(dataMember));

        picker.DateFormat = ""; // 初始空白

        var binding = new Binding("Value", dataSource, dataMember, true, DataSourceUpdateMode.OnPropertyChanged);

        binding.Format += (s, e) =>
        {
            if (e.Value is DateTime dt)
            {
                e.Value = dt;
                picker.DateFormat = "yyyy/MM/dd HH:mm"; // 有值顯示格式
            }
            else
            {
                picker.DateFormat = ""; // null 顯示空白
                e.Value = DateTime.Now; // Value 不能為 null，給個臨時值
            }
        };

        binding.Parse += (s, e) =>
        {
            // 如果使用者沒有選日期，返回 null
            if (picker.DateFormat == "")
                e.Value = null;
            else
                e.Value = e.Value;
        };

        picker.DataBindings.Clear();
        picker.DataBindings.Add(binding);
    }
}
