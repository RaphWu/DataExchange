﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.Contants
{
    /// <summary>
    /// 頁面代號。
    /// </summary>
    public enum PageCode
    {
        None = 0,

        /********************
         * 管理員
         ********************/
        [Description("權限管理")]
        AuthorityManager = 1,


        /********************
         * 主頁面
         ********************/
        [Description("主頁面")]
        MainPage = 100,

        /********************
         * 工具委託
         ********************/
        [Description("工具委託")]
        ToolQuest = 200,

        /********************
         * 專案管理
         ********************/
        [Description("專案管理")]
        MechaTrack = 300,

        /********************
         * 維護工單
         ********************/
        [Description("維護工單")]
        MaintiFlow = 400,

        [Description("維護總表")]
        MaintiFlowSummary = 401,

        [Description("新建工單")]
        CreateFlow = 402,

        //[Description("修改工單")]
        //EditFlow = 403,

        //[Description("刪除工單")]
        //DeleteFlow = 404,

        /********************
         * 設定
         ********************/
        [Description("使用者")]
        User = 500,

        [Description("登入")]
        Login = 501,

        [Description("登出")]
        Logout = 502,

        [Description("切換使用者")]
        SwitchUser = 503,
    }
}
