﻿using Autofac;
using Calin.TaskPulse.ToolQuest.Views;

namespace Calin.TaskPulse.ToolQuest
{
    public class ToolQuestMoudle : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<ToolQuestPage>().AsSelf();
        }
    }
}
