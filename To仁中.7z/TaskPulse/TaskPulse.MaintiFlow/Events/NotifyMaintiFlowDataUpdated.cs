﻿namespace Calin.TaskPulse.MaintiFlow.Events
{
    /// <summary>
    /// 維護資料庫更新訊息。
    /// </summary>
    public class NotifyMaintiFlowDataUpdated
    {
        public static readonly NotifyMaintiFlowDataUpdated Instance = new NotifyMaintiFlowDataUpdated();
        private NotifyMaintiFlowDataUpdated() { }
    }
}
