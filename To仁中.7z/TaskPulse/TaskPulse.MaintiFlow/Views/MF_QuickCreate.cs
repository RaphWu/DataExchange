﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Extensions;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using MailKit.Search;
using Sunny.UI;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MF_QuickCreate : UIForm
    {
        private readonly ILifetimeScope _rootScope;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly IMail _mail;
        private readonly CurrentUserContext _user;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        private TaskOrderViewModel _tovm = new TaskOrderViewModel();
        //private BindingSource _bs = new BindingSource();

        public MF_QuickCreate(ILifetimeScope lifetimeScope,
                           CoreContext coreContext,
                           ICore core,
                           IMail mail,
                           CurrentUserContext currentUserContext,
                           MaintiFlowData maintiFlowData,
                           CoreData coreData,
                           MultiSelector multiSelector)
        {
            InitializeComponent();
            _rootScope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _mail = mail;
            _user = currentUserContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _mSel = multiSelector;

            CommonStyles.SetButton(btnCreate);
            CommonStyles.SetButton(btnCancel, isCancel: true);
        }

        private async void QuickCreate_Load(object sender, EventArgs e)
        {
            /********************
             * 
             ********************/
            var mu = await _context.MaintenanceUnits
                .OrderBy(m => m.OrderNo)
                .Select(m => new ListViewModel
                {
                    Id = m.Id,
                    Name = m.UnitName,
                })
                .ToListAsync();
            mu.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
            MaintenanceUnit.DataSource = mu;
            MaintenanceUnit.DisplayMember = "Name";
            MaintenanceUnit.ValueMember = "Id";

            var ic = await _context.IssueCategories
                .OrderBy(i => i.OrderNo)
                .Select(i => new ListViewModel
                {
                    Id = i.Id,
                    Name = i.CategoryName,
                })
                .ToListAsync();
            ic.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
            IssueCategory.DataSource = ic;
            IssueCategory.DisplayMember = "Name";
            IssueCategory.ValueMember = "Id";

            var ru = await _context.Departments
                .OrderBy(d => d.OrderNo)
                .Select(d => new ListViewModel
                {
                    Id = d.Id,
                    Name = d.DepartmentName,
                })
                .ToListAsync();
            ru.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
            RequestingUnit.DataSource = ru;
            RequestingUnit.DisplayMember = "Name";
            RequestingUnit.ValueMember = "Id";

            /********************
             * 
             ********************/
            _tovm = new TaskOrderViewModel();

            if (_user.CurrentUser?.DepartmentId.HasValue ?? false)
                _tovm.MaintenanceUnitId = (int)_user.CurrentUser.DepartmentId;
            _tovm.CreatorName = _user.IsAdmin ? "" : _user.UserName;
            _tovm.EngineerString = _tovm.CreatorName;
            Creator.Text = _user.IsAdmin ? "" : _user.UserName;

            var now = DateTime.Now;
            _tovm.CreationDateTime = now;
            _tovm.AcceptedTime = now;

            _tovm.RepairStarted = now;
            _tovm.RepairCompleted = null;
            _tovm.OutageStarted = now;
            _tovm.OutageEnded = null;

            //_bs.DataSource = _tovm;
            //_bs.MoveFirst();

            /********************
             * 
             ********************/
            Label_MachineList.Text = PropertyText.Title.Machine;
            MachineCode.DataBindings.Clear();
            MachineCode.DataBindings.Add("Text", _tovm, PropertyText.Name.MachineCode, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_ModelWs.Text = PropertyText.Title.ModelWsName;
            ModelWs.DataBindings.Clear();
            ModelWs.DataBindings.Add("Text", _tovm, PropertyText.Name.ModelWsName, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
            MaintenanceUnit.DataBindings.Clear();
            MaintenanceUnit.DataBindings.Add("SelectedValue", _tovm, PropertyText.Name.MaintenanceUnitId, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_Engineers.Text = PropertyText.Title.Engineer;
            Engineers.DataBindings.Clear();
            Engineers.DataBindings.Add("Text", _tovm, PropertyText.Name.EngineerString, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_IssueCategory.Text = PropertyText.Title.IssueCategory;
            IssueCategory.DataBindings.Clear();
            IssueCategory.DataBindings.Add("SelectedValue", _tovm, PropertyText.Name.IssueCategoryId, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_RepairStarted.Text = PropertyText.Title.RepairStarted;
            RepairStarted.DataBindings.Clear();
            RepairStarted.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairStartedString, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
            RepairCompleted.DataBindings.Clear();
            RepairCompleted.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairCompletedString, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_RepairDuration.Text = PropertyText.Title.RepairDuration;
            RepairDuration.DataBindings.Clear();
            RepairDuration.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairDurationString, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_OutageStarted.Text = PropertyText.Title.OutageStarted;
            OutageStarted.DataBindings.Clear();
            OutageStarted.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageStartedString, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_OutageEnded.Text = PropertyText.Title.OutageEnded;
            OutageEnded.DataBindings.Clear();
            OutageEnded.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageEndedString, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_OutageDuration.Text = PropertyText.Title.OutageDuration;
            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageDurationString, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
            RequestingUnit.DataBindings.Clear();
            RequestingUnit.DataBindings.Add("SelectedValue", _tovm, PropertyText.Name.RequestingUnitId, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_Creator.Text = PropertyText.Title.Creator;
            Creator.DataBindings.Clear();
            Creator.DataBindings.Add("Text", _tovm, PropertyText.Name.CreatorName, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_CreationDate.Text = PropertyText.Title.CreationDateTime;
            CreationDateTime.DataBindings.Clear();
            CreationDateTime.DataBindings.Add("Value", _tovm, PropertyText.Name.CreationDateTime, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
            AcceptedTime.DataBindings.Clear();
            AcceptedTime.DataBindings.Add("Value", _tovm, PropertyText.Name.AcceptedTime, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_IssueDescription.Text = PropertyText.Title.IssueDescription;
            IssueDescription.DataBindings.Clear();
            IssueDescription.DataBindings.Add("Text", _tovm, PropertyText.Name.IssueDescription, true, DataSourceUpdateMode.OnPropertyChanged);

            Label_Details.Text = PropertyText.Title.Details;
            Details.DataBindings.Clear();
            Details.DataBindings.Add("Text", _tovm, PropertyText.Name.Details, true, DataSourceUpdateMode.OnPropertyChanged);


            //Label_FeedbackEmployee.Text = PropertyText.Title.FeedbackEmployee;
            //FeedbackEmployee.DataBindings.Clear();
            //FeedbackEmployee.DataBindings.Add("Text", _tovm, PropertyText.Name.FeedbackEmployeeString, true, DataSourceUpdateMode.OnPropertyChanged);

            //Label_RequestingUnitResponse.Text = PropertyText.Title.Feedback;
            //RequestingUnitFeedback.DataBindings.Clear();
            //RequestingUnitFeedback.DataBindings.Add("Text", _tovm, PropertyText.Name.Feedback, true, DataSourceUpdateMode.OnPropertyChanged);

            //Label_FillingTime.Text = PropertyText.Title.FillingTime;
            //FillingTime.DataBindings.Clear();
            //FillingTime.DataBindings.Add("Value", _tovm, PropertyText.Name.FillingTime, true, DataSourceUpdateMode.OnPropertyChanged);

            //Label_Responsible.Text = PropertyText.Title.Responsible;
            //Responsible.DataBindings.Clear();
            //Responsible.DataBindings.Add("Text", _tovm, PropertyText.Name.Responsible, true, DataSourceUpdateMode.OnPropertyChanged);

        }

        //private async Task LoadData()
        //{
        //    var mu = await _context.MaintenanceUnits
        //        .OrderBy(m => m.OrderNo)
        //        .Select(m => new ListViewModel
        //        {
        //            Id = m.Id,
        //            Name = m.UnitName,
        //        })
        //        .ToListAsync();
        //    MaintenanceUnit.DataSource = mu;
        //    MaintenanceUnit.DisplayMember = "Name";
        //    MaintenanceUnit.ValueMember = "Id";

        //    var ic = await _context.IssueCategories
        //        .OrderBy(i => i.OrderNo)
        //        .Select(i => new ListViewModel
        //        {
        //            Id = i.Id,
        //            Name = i.CategoryName,
        //        })
        //        .ToListAsync();
        //    ic.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
        //    IssueCategory.DataSource = ic;
        //    IssueCategory.DisplayMember = "Name";
        //    IssueCategory.ValueMember = "Id";

        //    var ru = await _context.Departments
        //        .OrderBy(d => d.OrderNo)
        //        .Select(d => new ListViewModel
        //        {
        //            Id = d.Id,
        //            Name = d.DepartmentName,
        //        })
        //        .ToListAsync();
        //    ru.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
        //    RequestingUnit.DataSource = ru;
        //    RequestingUnit.DisplayMember = "Name";
        //    RequestingUnit.ValueMember = "Id";
        //}

        private void btnCancel_Click(object sender, EventArgs ea)
        {
            this.Close();
        }

        private async void btnCreate_Click(object sender, EventArgs ea)
        {
            // 拆解機台編號
            var machineList = MachineCode.Text
                .Split(new char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();

            var creator = _coreData.Employees.FirstOrDefault(c => c.EmployeeName == (string)Creator.Text);

            // 錯誤檢查
            StringBuilder err = new StringBuilder();

            if (string.IsNullOrWhiteSpace(RequestingUnit.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.RequestingUnit}！");

            if (string.IsNullOrWhiteSpace(Creator.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.Creator}！");
            else if (creator == null)
                err.AppendLine($"查無此人：{Creator.Tag}！");

            if (string.IsNullOrWhiteSpace(MachineCode.Text))
            {
                err.AppendLine($"沒有輸入 {PropertyText.Title.Machine}！");
            }
            else
            {
                foreach (var mId in machineList)
                    if (_coreData.Machines.FindIndex(x => x.MachineCode == mId) == -1)
                        err.AppendLine($"{PropertyText.Title.Machine}不存在: {mId}");
            }

            if (string.IsNullOrEmpty(OutageStarted.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.OutageStarted}！");

            if (err.Length > 0)
            {
                err.Append("\n注意：資料尚未儲存！");
                MessageBox.Show(err.ToString(),
                    "輸入資料不正確",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            try
            {
                var deviceList = new List<Machine>();

                // 計算新工單號
                var tos = _context.TaskOrders;
                var _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                var _lastWorkOrderNo = tos
                    .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                    .Select(w => w.WorkOrderNo)
                    .AsEnumerable()
                    .Select(o => int.TryParse(o.Substring(8, 3), out int val) ? val : 0)
                    .DefaultIfEmpty(0)
                    .Max();

                // 加入資料庫
                int rUnitId = (int)RequestingUnit.SelectedValue;

                var newTaskOrders = new List<TaskOrder>();
                for (int no = 1; no <= machineList.Count; no++)
                {
                    string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                    string machineId = machineList[no - 1];

                    var to = new TaskOrder()
                    {
                        WorkOrderNo = newWorkOrderNo,
                        CreatorId = (int)(_context.Employees.FirstOrDefault(e => e.EmployeeName == _tovm.CreatorName)?.Id),
                        RequestingUnitId = _tovm.RequestingUnitId,
                        Status = FlowStatus.NewTaskOrder,
                        MachineId = _context.Machines.FirstOrDefault(x => x.MachineCode == machineId)?.Id,

                        CreationDateTime = (DateTime)_tovm.CreationDateTime,
                        AcceptedTime = (DateTime)_tovm.AcceptedTime,

                        RepairStartedString = _tovm.RepairStartedString,
                        RepairCompletedString = _tovm.RepairCompletedString,
                        RepairDurationString = _tovm.RepairDurationString,
                        OutageStartedString = _tovm.OutageStartedString,
                        OutageEndedString = _tovm.OutageEndedString,
                        OutageDurationString = _tovm.OutageDurationString,

                        MaintenanceUnitId = _tovm.MaintenanceUnitId,
                        IssueCategoryId = _tovm.IssueCategoryId,
                        IssueDescription = _tovm.IssueDescription,
                        Details = _tovm.Details,
                    };

                    to.Engineers = to.GetEngineers(StringExtensions.SplitCleanFast(_tovm.EngineerString, '»', ';', ','), _context);
                    to.WorkstationId = to.GetWorkstationId(_tovm.ModelWsName, _context);

                    _context.TaskOrders.Add(to);
                    newTaskOrders.Add(to);
                }

                await _context.SaveChangesAsync();
                _ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("資料已儲存。"));

                // send email
                StringBuilder mail = new StringBuilder();
                mail.Append("<table><caption>新建工單</caption>");

                var ruId = newTaskOrders[0].RequestingUnitId;
                mail.Append("<tr>");
                mail.Append("<td>需求單位</td>");
                mail.Append($"<td>{_context.Departments.FirstOrDefault(r => r.Id == ruId).DepartmentName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>工單建立者</td>");
                mail.Append($"<td>{creator.EmployeeName}</td>");
                mail.Append("</tr>");

                List<string> oms = new List<string>();
                foreach (var wo in newTaskOrders)
                    oms.Add($"{wo.WorkOrderNo}: {wo.FullMachineName}");

                mail.Append("<tr>");
                mail.Append("<td>新增工單</td>");
                mail.Append($"<td>{string.Join("<br/>", oms)}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>建立時間</td>");
                mail.Append($"<td>{newTaskOrders[0].CreationDateString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動時間</td>");
                mail.Append($"<td>{newTaskOrders[0].OutageStartedString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>問題描述</td>");
                mail.Append($"<td>{newTaskOrders[0].IssueDescription}</td>");
                mail.Append("</tr>");
                mail.Append("</table>");

                //var mailList = new HashSet<int>() { 19 };
                var mailList = new HashSet<int>(newTaskOrders[0].Engineers.Select(emp => emp.Id).ToList())
                    {
                        creator.Id
                    };
                _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                               $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][新建工單] {creator.EmployeeName} 新建 {newTaskOrders.Count} 張維護工單。",
                               mail.ToString());

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void MachineList_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.Machine}";
            _mSel.TreeViewCaption = "機台";
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.MachinesMultiTabPageCache;
            _mSel.DefaultChecked = MachineCode.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                MachineCode.Text = _mSel.ResultList.Count > 0
                    ? string.Join("; ", _mSel.ResultList.Select(r => r.Name).ToArray())
                    : "";
            }
        }

        private void ModelWs_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.ModelName}";
            _mSel.TreeViewCaption = "機種";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;

            // 安全處理 ModelWs.Text：避免 NullReferenceException 並處理空字串
            var lastPart = ModelWs.Text?
                .Split(new char[] { '»', ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .LastOrDefault();
            if (string.IsNullOrWhiteSpace(lastPart))
                _mSel.DefaultChecked = new List<string>();
            else
                _mSel.DefaultChecked = new List<string> { lastPart.Trim() };

            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    CategoryInfo info = _mSel.ResultList[0];
                    var ws = _core.GetWorkstation(info.Id);
                    var model = _core.GetModel(ws.ModelId.HasValue ? (int)ws.ModelId : 0);
                    ModelWs.Text = $"{model.ModelName} » {ws.WorkstationName}";
                }
                else
                {
                    ModelWs.Text = "";
                }
            }
        }

        private void Engineers_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = false;
            _mSel.Title = $"請選擇{PropertyText.Title.Engineer}";
            _mSel.DialogWidth = 600;
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EngineerMultiTabPageCache;
            _mSel.DefaultChecked = Engineers.Text
                .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                List<string> emps = new List<string>();
                foreach (var emp in _mSel.ResultList)
                    emps.Add(emp.Name);
                Engineers.Text = string.Join("; ", emps);
            }
        }

        private void Creator_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>() { (string)Creator.Text };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    var emp = _mSel.ResultList[0];
                    Creator.Text = emp.Name;
                }
                else
                {
                    Creator.Text = "";
                }
            }
        }

        private void RepairStarted_ValueChanged(object sender, DateTime value)
        {
            if (_tovm != null)
            {
                _tovm.RepairStarted = DateTime.TryParse(RepairStarted.Text, out DateTime dt)
                    ? dt
                    : (DateTime?)null;
            }
            UpdateRepairDuration();
        }

        private void RepairCompleted_ValueChanged(object sender, DateTime value)
        {
            if (_tovm != null)
            {
                _tovm.RepairCompleted = DateTime.TryParse(RepairCompleted.Text, out DateTime dt)
                    ? dt
                    : (DateTime?)null;
            }
            UpdateRepairDuration();
        }

        private void UpdateRepairDuration()
        {
            //bool hasStarted = cbRepairStarted.Checked && _tovm.RepairStarted.HasValue;
            //bool hasCompleted = cbRepairCompleted.Checked && _tovm.RepairCompleted.HasValue;

            //if (!hasStarted)
            //    RepairStarted.Text = "";

            //if (!hasCompleted)
            //    RepairCompleted.Text = "";

            if (_tovm.RepairStarted != null)
            {
                _tovm.RepairDuration = _tovm.RepairCompleted != null
                    ? (TimeSpan)(_tovm.RepairCompleted - _tovm.RepairStarted)
                    : (TimeSpan)(DateTime.Now - _tovm.RepairStarted);
            }
            else
            {
                _tovm.RepairDuration = TimeSpan.Zero;
            }
            string days = _tovm.RepairDuration.Days > 0 ? $"{_tovm.RepairDuration.Days}天 " : "";
            RepairDuration.Text = $"{days}{_tovm.RepairDuration.Hours:D2}:{_tovm.RepairDuration.Minutes:D2}";
        }

        private void OutageStarted_ValueChanged(object sender, DateTime value)
        {
            if (_tovm != null)
            {
                _tovm.OutageStarted = DateTime.TryParse(OutageStarted.Text, out DateTime dt)
                    ? dt
                    : (DateTime?)null;
            }
            UpdateOutageDuration();
        }

        private void OutageEnded_ValueChanged(object sender, DateTime value)
        {
            if (_tovm != null)
            {
                _tovm.OutageEnded = DateTime.TryParse(OutageEnded.Text, out DateTime dt)
                    ? dt
                    : (DateTime?)null;
            }
            UpdateOutageDuration();
        }

        private void UpdateOutageDuration()
        {
            //bool hasStarted = cbOutageStarted.Checked && _tovm.OutageStarted.HasValue;
            //bool hasEnded = cbOutageEnded.Checked && _tovm.OutageEnded.HasValue;

            //if (!hasStarted)
            //    OutageStarted.Text = "";

            //if (!hasEnded)
            //    OutageEnded.Text = "";

            if (_tovm.OutageStarted != null)
            {
                _tovm.OutageDuration = _tovm.OutageEnded != null
                    ? (TimeSpan)(_tovm.OutageEnded - _tovm.OutageStarted)
                    : (TimeSpan)(DateTime.Now - _tovm.OutageStarted);
            }
            else
            {
                _tovm.OutageDuration = TimeSpan.Zero;
            }
            string days = _tovm.OutageDuration.Days > 0 ? $"{_tovm.OutageDuration.Days}天 " : "";
            OutageDuration.Text = $"{days}{_tovm.OutageDuration.Hours:D2}:{_tovm.OutageDuration.Minutes:D2}";
        }
    }
}
