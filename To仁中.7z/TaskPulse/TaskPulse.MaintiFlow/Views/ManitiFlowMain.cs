﻿using System;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.MaintiFlow.Events;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class ManitiFlowMain : UIPage
    {
        private readonly CreateFlow _createFlow;

        public ManitiFlowMain(CreateFlow createFlow)
        {
            InitializeComponent();

            _createFlow = createFlow;

            uiButton_Summary.Text = PageCode.MaintiFlowSummary.GetDescription();
            uiButton_Summary.Symbol = 559631;
            uiButton_Summary.FillColor = CommonStyles.BackColor;
            uiButton_Summary.FillHoverColor = CommonStyles.Hover;

            uiButton_CreateFlow.Text = PageCode.CreateFlow.GetDescription();
            uiButton_CreateFlow.Symbol = 559936;
            uiButton_CreateFlow.FillColor = CommonStyles.BackColor;
            uiButton_CreateFlow.FillHoverColor = CommonStyles.Hover;
        }

        private void uiButton_Summary_Click(object sender, EventArgs e)
        {
            WeakReferenceMessenger.Default.Send(new MaintiFlowPageChangedMessage(PageCode.MaintiFlowSummary));
        }

        private void uiButton_CreateFlow_Click(object sender, EventArgs e)
        {
            _createFlow.Title = "新建工單";

            string machineString = "";
            if (_createFlow.ShowDialog() == DialogResult.OK)
            {
                //foreach (var item in _flowLayoutSelector.ResultList)
                //{
                //    if (machineString != "")
                //        machineString += "; ";
                //    machineString += _flowData.DeviceList.First(x => x.Key == item).Value;
                //}
            }
        }
    }
}
