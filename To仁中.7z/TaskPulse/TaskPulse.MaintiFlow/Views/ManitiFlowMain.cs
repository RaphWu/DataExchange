﻿using System;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.MaintiFlow.Contract;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class ManitiFlowMain : UIPage
    {
        private readonly CoreContext _context;
        private readonly IMaintiFlow _maintiFlow;

        public ManitiFlowMain(CoreContext coreContext, IMaintiFlow maintiFlow)
        {
            InitializeComponent();
            _context = coreContext;
            _maintiFlow = maintiFlow;

            CommonStyles.SetButton(Button_CreateFlow, fontSize: 14);
            Button_CreateFlow.Text = PageCode.CreateFlow.GetDescription();

            CommonStyles.SetButton(Button_CancelFlow, fontSize: 14);
            Button_CreateFlow.Text = PageCode.CancelFlow.GetDescription();

            CommonStyles.SetButton(Button_AcceptFlow, fontSize: 14);
            Button_CreateFlow.Text = PageCode.AcceptFlow.GetDescription();

            CommonStyles.SetButton(Button_FlowCompleted, fontSize: 14);
            Button_CreateFlow.Text = PageCode.FlowCompleted.GetDescription();

            CommonStyles.SetButton(Button_FlowConfirmed, fontSize: 14);
            Button_CreateFlow.Text = PageCode.FlowConfirmed.GetDescription();

        }

        private void Button_CreateFlow_Click(object sender, EventArgs e)
        {
            _maintiFlow.CreateNewFlow();
        }
    }
}
