﻿using System;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.MaintiFlow.Contract;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class ManitiFlowMain : UIPage
    {
        private readonly CoreContext _context;
        private readonly IMaintiFlow _maintiFlow;

        public ManitiFlowMain(CoreContext coreContext, IMaintiFlow maintiFlow)
        {
            InitializeComponent();
            _context = coreContext;
            _maintiFlow = maintiFlow;

            Button_CreateFlow.Text = PageCode.CreateFlow.GetDescription();
            Button_AcceptFlow.Text = PageCode.AcceptFlow.GetDescription();
            Button_MaintiWork.Text = PageCode.MaintiWork.GetDescription();
            Button_FlowConfirmed.Text = PageCode.FlowConfirmed.GetDescription();
            Button_CancelFlow.Text = PageCode.CancelFlow.GetDescription();
        }

        private void Button_CreateFlow_Click(object sender, EventArgs e)
        {
            _maintiFlow.CreateNewFlow();
        }

        private async void Button_CancelFlow_Click(object sender, EventArgs e)
        {
            await _maintiFlow.CancelFlow();
        }

        private async void Button_AcceptFlow_Click(object sender, EventArgs e)
        {
            await _maintiFlow.AcceptFlow();
        }

        private async void Button_MaintiWork_Click(object sender, EventArgs e)
        {
            await _maintiFlow.MaintiWork();
        }

        private async void Button_FlowConfirmed_Click(object sender, EventArgs e)
        {
            await _maintiFlow.FlowConfirmed();
        }
    }
}
