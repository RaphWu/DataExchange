﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class ManitiFlowMain
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Button_CreateFlow = new Sunny.UI.UISymbolButton();
            this.Button_AcceptFlow = new Sunny.UI.UISymbolButton();
            this.Button_MaintiWork = new Sunny.UI.UISymbolButton();
            this.Button_FlowConfirmed = new Sunny.UI.UISymbolButton();
            this.Button_CancelFlow = new Sunny.UI.UISymbolButton();
            this.SuspendLayout();
            // 
            // Button_CreateFlow
            // 
            this.Button_CreateFlow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_CreateFlow.FillColor = System.Drawing.Color.Teal;
            this.Button_CreateFlow.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.Button_CreateFlow.Location = new System.Drawing.Point(88, 58);
            this.Button_CreateFlow.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_CreateFlow.Name = "Button_CreateFlow";
            this.Button_CreateFlow.Radius = 14;
            this.Button_CreateFlow.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_CreateFlow.Size = new System.Drawing.Size(210, 150);
            this.Button_CreateFlow.Symbol = 559936;
            this.Button_CreateFlow.SymbolSize = 86;
            this.Button_CreateFlow.TabIndex = 16;
            this.Button_CreateFlow.Text = "CreateFlow";
            this.Button_CreateFlow.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Button_CreateFlow.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_CreateFlow.Click += new System.EventHandler(this.Button_CreateFlow_Click);
            // 
            // Button_AcceptFlow
            // 
            this.Button_AcceptFlow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_AcceptFlow.FillColor = System.Drawing.Color.SteelBlue;
            this.Button_AcceptFlow.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.Button_AcceptFlow.Location = new System.Drawing.Point(377, 58);
            this.Button_AcceptFlow.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_AcceptFlow.Name = "Button_AcceptFlow";
            this.Button_AcceptFlow.Radius = 14;
            this.Button_AcceptFlow.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_AcceptFlow.Size = new System.Drawing.Size(210, 150);
            this.Button_AcceptFlow.Symbol = 362038;
            this.Button_AcceptFlow.SymbolSize = 86;
            this.Button_AcceptFlow.TabIndex = 21;
            this.Button_AcceptFlow.Text = "AcceptFlow";
            this.Button_AcceptFlow.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Button_AcceptFlow.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_AcceptFlow.Click += new System.EventHandler(this.Button_AcceptFlow_Click);
            // 
            // Button_MaintiWork
            // 
            this.Button_MaintiWork.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_MaintiWork.FillColor = System.Drawing.Color.Chocolate;
            this.Button_MaintiWork.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.Button_MaintiWork.Location = new System.Drawing.Point(377, 244);
            this.Button_MaintiWork.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_MaintiWork.Name = "Button_MaintiWork";
            this.Button_MaintiWork.Radius = 14;
            this.Button_MaintiWork.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_MaintiWork.Size = new System.Drawing.Size(210, 150);
            this.Button_MaintiWork.Symbol = 559510;
            this.Button_MaintiWork.SymbolSize = 86;
            this.Button_MaintiWork.TabIndex = 23;
            this.Button_MaintiWork.Text = "FT_MaintiWork";
            this.Button_MaintiWork.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Button_MaintiWork.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_MaintiWork.Click += new System.EventHandler(this.Button_MaintiWork_Click);
            // 
            // Button_FlowConfirmed
            // 
            this.Button_FlowConfirmed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_FlowConfirmed.FillColor = System.Drawing.Color.Navy;
            this.Button_FlowConfirmed.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.Button_FlowConfirmed.Location = new System.Drawing.Point(377, 430);
            this.Button_FlowConfirmed.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_FlowConfirmed.Name = "Button_FlowConfirmed";
            this.Button_FlowConfirmed.Radius = 20;
            this.Button_FlowConfirmed.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_FlowConfirmed.Size = new System.Drawing.Size(210, 150);
            this.Button_FlowConfirmed.Symbol = 361442;
            this.Button_FlowConfirmed.SymbolSize = 86;
            this.Button_FlowConfirmed.TabIndex = 24;
            this.Button_FlowConfirmed.Text = "FlowConfirmed";
            this.Button_FlowConfirmed.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Button_FlowConfirmed.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_FlowConfirmed.Click += new System.EventHandler(this.Button_FlowConfirmed_Click);
            // 
            // Button_CancelFlow
            // 
            this.Button_CancelFlow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_CancelFlow.FillColor = System.Drawing.Color.Maroon;
            this.Button_CancelFlow.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.Button_CancelFlow.Location = new System.Drawing.Point(88, 431);
            this.Button_CancelFlow.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_CancelFlow.Name = "Button_CancelFlow";
            this.Button_CancelFlow.Radius = 20;
            this.Button_CancelFlow.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_CancelFlow.Size = new System.Drawing.Size(210, 150);
            this.Button_CancelFlow.Symbol = 361453;
            this.Button_CancelFlow.SymbolSize = 86;
            this.Button_CancelFlow.TabIndex = 25;
            this.Button_CancelFlow.Text = "CancelFlow";
            this.Button_CancelFlow.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Button_CancelFlow.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_CancelFlow.Click += new System.EventHandler(this.Button_CancelFlow_Click);
            // 
            // ManitiFlowMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(716, 651);
            this.Controls.Add(this.Button_CancelFlow);
            this.Controls.Add(this.Button_FlowConfirmed);
            this.Controls.Add(this.Button_MaintiWork);
            this.Controls.Add(this.Button_AcceptFlow);
            this.Controls.Add(this.Button_CreateFlow);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "ManitiFlowMain";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 11F);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UISymbolButton Button_CreateFlow;
        private Sunny.UI.UISymbolButton Button_AcceptFlow;
        private Sunny.UI.UISymbolButton Button_MaintiWork;
        private Sunny.UI.UISymbolButton Button_FlowConfirmed;
        private Sunny.UI.UISymbolButton Button_CancelFlow;
    }
}
