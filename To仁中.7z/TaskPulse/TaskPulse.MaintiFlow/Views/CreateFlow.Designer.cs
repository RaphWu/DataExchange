﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class CreateFlow
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.uiButton_OK = new Sunny.UI.UISymbolButton();
            this.uiButton_Cancel = new Sunny.UI.UISymbolButton();
            this.uiPanel_BasicData = new Sunny.UI.UITitlePanel();
            this.Model = new Sunny.UI.UITextBox();
            this.uiLabel_Model = new Sunny.UI.UILabel();
            this.MachineId = new Sunny.UI.UITextBox();
            this.uiLabel_MachineId = new Sunny.UI.UILabel();
            this.uiLabel_CreationDate = new Sunny.UI.UILabel();
            this.CreationDate = new Sunny.UI.UIDatePicker();
            this.Creator = new Sunny.UI.UIComboBox();
            this.uiLabel_Creator = new Sunny.UI.UILabel();
            this.uiLabel_WorkOrderNo = new Sunny.UI.UILabel();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.uiPanel_BasicData.SuspendLayout();
            this.SuspendLayout();
            // 
            // uiButton_OK
            // 
            this.uiButton_OK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_OK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_OK.Location = new System.Drawing.Point(561, 653);
            this.uiButton_OK.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_OK.Name = "uiButton_OK";
            this.uiButton_OK.Radius = 10;
            this.uiButton_OK.Size = new System.Drawing.Size(110, 35);
            this.uiButton_OK.TabIndex = 3;
            this.uiButton_OK.Text = "確定";
            this.uiButton_OK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_OK.Click += new System.EventHandler(this.uiButton_OK_Click);
            // 
            // uiButton_Cancel
            // 
            this.uiButton_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.uiButton_Cancel.Location = new System.Drawing.Point(691, 653);
            this.uiButton_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Cancel.Name = "uiButton_Cancel";
            this.uiButton_Cancel.Radius = 10;
            this.uiButton_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.uiButton_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.uiButton_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uiButton_Cancel.Size = new System.Drawing.Size(110, 35);
            this.uiButton_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.uiButton_Cancel.Symbol = 361453;
            this.uiButton_Cancel.TabIndex = 2;
            this.uiButton_Cancel.Text = "取消";
            this.uiButton_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Cancel.Click += new System.EventHandler(this.uiButton_Cancel_Click);
            // 
            // uiPanel_BasicData
            // 
            this.uiPanel_BasicData.Controls.Add(this.Model);
            this.uiPanel_BasicData.Controls.Add(this.uiLabel_Model);
            this.uiPanel_BasicData.Controls.Add(this.MachineId);
            this.uiPanel_BasicData.Controls.Add(this.uiLabel_MachineId);
            this.uiPanel_BasicData.Controls.Add(this.uiLabel_CreationDate);
            this.uiPanel_BasicData.Controls.Add(this.CreationDate);
            this.uiPanel_BasicData.Controls.Add(this.Creator);
            this.uiPanel_BasicData.Controls.Add(this.uiLabel_Creator);
            this.uiPanel_BasicData.Controls.Add(this.uiLabel_WorkOrderNo);
            this.uiPanel_BasicData.Controls.Add(this.WorkOrderNo);
            this.uiPanel_BasicData.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiPanel_BasicData.Location = new System.Drawing.Point(25, 56);
            this.uiPanel_BasicData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel_BasicData.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel_BasicData.Name = "uiPanel_BasicData";
            this.uiPanel_BasicData.Padding = new System.Windows.Forms.Padding(1, 35, 1, 1);
            this.uiPanel_BasicData.ShowText = false;
            this.uiPanel_BasicData.Size = new System.Drawing.Size(411, 470);
            this.uiPanel_BasicData.TabIndex = 11;
            this.uiPanel_BasicData.Text = "基本資料";
            this.uiPanel_BasicData.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Model
            // 
            this.Model.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model.Location = new System.Drawing.Point(134, 127);
            this.Model.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Model.MinimumSize = new System.Drawing.Size(1, 16);
            this.Model.Name = "Model";
            this.Model.Padding = new System.Windows.Forms.Padding(5);
            this.Model.ShowButton = true;
            this.Model.ShowText = false;
            this.Model.Size = new System.Drawing.Size(250, 29);
            this.Model.TabIndex = 20;
            this.Model.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Model.Watermark = "";
            this.Model.ButtonClick += new System.EventHandler(this.Model_ButtonClick);
            // 
            // uiLabel_Model
            // 
            this.uiLabel_Model.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Model.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Model.Location = new System.Drawing.Point(9, 127);
            this.uiLabel_Model.Name = "uiLabel_Model";
            this.uiLabel_Model.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_Model.TabIndex = 19;
            this.uiLabel_Model.Text = "DeviceId";
            this.uiLabel_Model.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // DeviceId
            // 
            this.MachineId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineId.Location = new System.Drawing.Point(134, 88);
            this.MachineId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineId.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineId.Name = "DeviceId";
            this.MachineId.Padding = new System.Windows.Forms.Padding(5);
            this.MachineId.ShowButton = true;
            this.MachineId.ShowText = false;
            this.MachineId.Size = new System.Drawing.Size(250, 29);
            this.MachineId.TabIndex = 18;
            this.MachineId.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineId.Watermark = "";
            this.MachineId.ButtonClick += new System.EventHandler(this.MachineId_ButtonClick);
            // 
            // uiLabel_MachineId
            // 
            this.uiLabel_MachineId.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MachineId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MachineId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MachineId.Location = new System.Drawing.Point(9, 88);
            this.uiLabel_MachineId.Name = "uiLabel_MachineId";
            this.uiLabel_MachineId.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_MachineId.TabIndex = 17;
            this.uiLabel_MachineId.Text = "DeviceId";
            this.uiLabel_MachineId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_CreationDate
            // 
            this.uiLabel_CreationDate.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_CreationDate.Location = new System.Drawing.Point(9, 389);
            this.uiLabel_CreationDate.Name = "uiLabel_CreationDate";
            this.uiLabel_CreationDate.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_CreationDate.TabIndex = 16;
            this.uiLabel_CreationDate.Text = "CreationDate";
            this.uiLabel_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreationDate
            // 
            this.CreationDate.FillColor = System.Drawing.Color.White;
            this.CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CreationDate.Location = new System.Drawing.Point(134, 388);
            this.CreationDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CreationDate.MaxLength = 10;
            this.CreationDate.MinimumSize = new System.Drawing.Size(63, 0);
            this.CreationDate.Name = "CreationDate";
            this.CreationDate.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.CreationDate.Size = new System.Drawing.Size(150, 29);
            this.CreationDate.SymbolDropDown = 61555;
            this.CreationDate.SymbolNormal = 61555;
            this.CreationDate.SymbolSize = 24;
            this.CreationDate.TabIndex = 15;
            this.CreationDate.Text = "2025-10-07";
            this.CreationDate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreationDate.Value = new System.DateTime(2025, 10, 7, 14, 27, 56, 392);
            this.CreationDate.Watermark = "";
            // 
            // Creator
            // 
            this.Creator.DataSource = null;
            this.Creator.FillColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Creator.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Creator.Location = new System.Drawing.Point(134, 49);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(63, 0);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Creator.ShowFilter = true;
            this.Creator.Size = new System.Drawing.Size(250, 29);
            this.Creator.SymbolSize = 24;
            this.Creator.TabIndex = 14;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // uiLabel_Creator
            // 
            this.uiLabel_Creator.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Creator.Location = new System.Drawing.Point(9, 49);
            this.uiLabel_Creator.Name = "uiLabel_Creator";
            this.uiLabel_Creator.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_Creator.TabIndex = 13;
            this.uiLabel_Creator.Text = "Creator";
            this.uiLabel_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_WorkOrderNo
            // 
            this.uiLabel_WorkOrderNo.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_WorkOrderNo.Location = new System.Drawing.Point(9, 350);
            this.uiLabel_WorkOrderNo.Name = "uiLabel_WorkOrderNo";
            this.uiLabel_WorkOrderNo.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_WorkOrderNo.TabIndex = 12;
            this.uiLabel_WorkOrderNo.Text = "WorkOrderNo";
            this.uiLabel_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.Location = new System.Drawing.Point(134, 349);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(150, 29);
            this.WorkOrderNo.TabIndex = 11;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // CreateFlow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(842, 732);
            this.Controls.Add(this.uiPanel_BasicData);
            this.Controls.Add(this.uiButton_OK);
            this.Controls.Add(this.uiButton_Cancel);
            this.Name = "CreateFlow";
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 1141, 732);
            this.uiPanel_BasicData.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UISymbolButton uiButton_OK;
        private Sunny.UI.UISymbolButton uiButton_Cancel;
        private Sunny.UI.UITitlePanel uiPanel_BasicData;
        private Sunny.UI.UILabel uiLabel_CreationDate;
        private Sunny.UI.UIDatePicker CreationDate;
        private Sunny.UI.UIComboBox Creator;
        private Sunny.UI.UILabel uiLabel_Creator;
        private Sunny.UI.UILabel uiLabel_WorkOrderNo;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UILabel uiLabel_MachineId;
        private Sunny.UI.UITextBox MachineId;
        private Sunny.UI.UITextBox Model;
        private Sunny.UI.UILabel uiLabel_Model;
    }
}
