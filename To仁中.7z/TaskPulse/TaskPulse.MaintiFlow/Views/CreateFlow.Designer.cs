﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class CreateFlow
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.IssueDescription = new Sunny.UI.UITextBox();
            this.uiLabel_IssueDescription = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UIDatetimePicker();
            this.uiLabel_OutageStarted = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.uiLabel_MachineList = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UIComboBox();
            this.uiLabel_Creator = new Sunny.UI.UILabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Button_Cancel = new Sunny.UI.UISymbolButton();
            this.Button_OK = new Sunny.UI.UISymbolButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // IssueDescription
            // 
            this.IssueDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(143, 135);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueDescription.Multiline = true;
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(5);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(250, 85);
            this.IssueDescription.TabIndex = 36;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.IssueDescription.Watermark = "";
            // 
            // uiLabel_IssueDescription
            // 
            this.uiLabel_IssueDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueDescription.Location = new System.Drawing.Point(56, 135);
            this.uiLabel_IssueDescription.Name = "uiLabel_IssueDescription";
            this.uiLabel_IssueDescription.Size = new System.Drawing.Size(80, 29);
            this.uiLabel_IssueDescription.TabIndex = 37;
            this.uiLabel_IssueDescription.Text = "IssueDescription";
            this.uiLabel_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.DateFormat = "yyyy-MM-dd HH:mm";
            this.OutageStarted.FillColor = System.Drawing.Color.White;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.Location = new System.Drawing.Point(143, 96);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MaxLength = 16;
            this.OutageStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.OutageStarted.Size = new System.Drawing.Size(250, 29);
            this.OutageStarted.SymbolDropDown = 61555;
            this.OutageStarted.SymbolNormal = 61555;
            this.OutageStarted.SymbolSize = 24;
            this.OutageStarted.TabIndex = 35;
            this.OutageStarted.Text = "2025-10-13 10:39";
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.OutageStarted.Value = new System.DateTime(2025, 10, 13, 10, 39, 6, 671);
            this.OutageStarted.Watermark = "";
            // 
            // uiLabel_OutageStarted
            // 
            this.uiLabel_OutageStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageStarted.Location = new System.Drawing.Point(56, 96);
            this.uiLabel_OutageStarted.Name = "uiLabel_OutageStarted";
            this.uiLabel_OutageStarted.Size = new System.Drawing.Size(80, 29);
            this.uiLabel_OutageStarted.TabIndex = 34;
            this.uiLabel_OutageStarted.Text = "OutageStarted";
            this.uiLabel_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.Location = new System.Drawing.Point(143, 57);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ShowButton = true;
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(250, 29);
            this.MachineList.TabIndex = 29;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            this.MachineList.ButtonClick += new System.EventHandler(this.MachineId_ButtonClick);
            // 
            // uiLabel_MachineList
            // 
            this.uiLabel_MachineList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MachineList.Location = new System.Drawing.Point(56, 57);
            this.uiLabel_MachineList.Name = "uiLabel_MachineList";
            this.uiLabel_MachineList.Size = new System.Drawing.Size(80, 29);
            this.uiLabel_MachineList.TabIndex = 28;
            this.uiLabel_MachineList.Text = "MachineList";
            this.uiLabel_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Creator
            // 
            this.Creator.DataSource = null;
            this.Creator.FillColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Creator.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Creator.Location = new System.Drawing.Point(143, 18);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MaxDropDownItems = 12;
            this.Creator.MinimumSize = new System.Drawing.Size(63, 0);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Creator.ShowFilter = true;
            this.Creator.Size = new System.Drawing.Size(250, 29);
            this.Creator.SymbolSize = 24;
            this.Creator.TabIndex = 27;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // uiLabel_Creator
            // 
            this.uiLabel_Creator.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.uiLabel_Creator.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Creator.Location = new System.Drawing.Point(56, 18);
            this.uiLabel_Creator.Name = "uiLabel_Creator";
            this.uiLabel_Creator.Size = new System.Drawing.Size(80, 29);
            this.uiLabel_Creator.TabIndex = 26;
            this.uiLabel_Creator.Text = "Creator";
            this.uiLabel_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(20, 48);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 71F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(421, 321);
            this.tableLayoutPanel1.TabIndex = 38;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Button_OK);
            this.panel1.Controls.Add(this.Button_Cancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(103, 253);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(315, 65);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.AutoSize = true;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.Controls.Add(this.Creator);
            this.panel2.Controls.Add(this.IssueDescription);
            this.panel2.Controls.Add(this.uiLabel_Creator);
            this.panel2.Controls.Add(this.uiLabel_IssueDescription);
            this.panel2.Controls.Add(this.uiLabel_MachineList);
            this.panel2.Controls.Add(this.OutageStarted);
            this.panel2.Controls.Add(this.MachineList);
            this.panel2.Controls.Add(this.uiLabel_OutageStarted);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(397, 225);
            this.panel2.TabIndex = 1;
            // 
            // Button_Cancel
            // 
            this.Button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Button_Cancel.Location = new System.Drawing.Point(190, 15);
            this.Button_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Cancel.Name = "Button_Cancel";
            this.Button_Cancel.Radius = 10;
            this.Button_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_Cancel.Size = new System.Drawing.Size(110, 35);
            this.Button_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.Button_Cancel.Symbol = 361453;
            this.Button_Cancel.TabIndex = 2;
            this.Button_Cancel.Text = "取消";
            this.Button_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Cancel.Click += new System.EventHandler(this.uiButton_Cancel_Click);
            // 
            // Button_OK
            // 
            this.Button_OK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_OK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_OK.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_OK.Location = new System.Drawing.Point(60, 15);
            this.Button_OK.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_OK.Name = "Button_OK";
            this.Button_OK.Radius = 10;
            this.Button_OK.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_OK.Size = new System.Drawing.Size(110, 35);
            this.Button_OK.TabIndex = 3;
            this.Button_OK.Text = "確定";
            this.Button_OK.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_OK.Click += new System.EventHandler(this.uiButton_OK_Click);
            // 
            // CreateFlow
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(450, 377);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CreateFlow";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 1141, 732);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UITextBox IssueDescription;
        private Sunny.UI.UILabel uiLabel_IssueDescription;
        private Sunny.UI.UIDatetimePicker OutageStarted;
        private Sunny.UI.UILabel uiLabel_OutageStarted;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UILabel uiLabel_MachineList;
        private Sunny.UI.UIComboBox Creator;
        private Sunny.UI.UILabel uiLabel_Creator;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton Button_OK;
        private Sunny.UI.UISymbolButton Button_Cancel;
    }
}
