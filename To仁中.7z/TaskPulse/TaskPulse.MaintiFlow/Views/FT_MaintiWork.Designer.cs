﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class FT_MaintiWork
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.Button_Save = new Sunny.UI.UISymbolButton();
            this.Button_Cancel = new Sunny.UI.UISymbolButton();
            this.TLP_Content = new System.Windows.Forms.TableLayoutPanel();
            this.ListBox_Orders = new Sunny.UI.UIListBox();
            this.panel_Items = new System.Windows.Forms.Panel();
            this.IssueCategory = new Sunny.UI.UIComboBox();
            this.Engineers = new Sunny.UI.UIComboTreeView();
            this.MaintenanceUnit = new Sunny.UI.UIComboBox();
            this.Label_RequestingUnit = new Sunny.UI.UILabel();
            this.RequestingUnit = new Sunny.UI.UITextBox();
            this.RepairStarted = new Sunny.UI.UIDatetimePicker();
            this.OutageEnded = new Sunny.UI.UIDatetimePicker();
            this.RepairCompleted = new Sunny.UI.UIDatetimePicker();
            this.OutageDuration = new Sunny.UI.UITextBox();
            this.RepairDuration = new Sunny.UI.UITextBox();
            this.Label_OutageDuration = new Sunny.UI.UILabel();
            this.Label_RepairDuration = new Sunny.UI.UILabel();
            this.Label_OutageEnded = new Sunny.UI.UILabel();
            this.Label_RepairCompleted = new Sunny.UI.UILabel();
            this.Label_RepairStarted = new Sunny.UI.UILabel();
            this.IssueDescription = new Sunny.UI.UITextBox();
            this.Label_IssueDescription = new Sunny.UI.UILabel();
            this.AcceptedTime = new Sunny.UI.UITextBox();
            this.Label_AcceptedTime = new Sunny.UI.UILabel();
            this.Label_IssueCategory = new Sunny.UI.UILabel();
            this.Label_Engineers = new Sunny.UI.UILabel();
            this.Label_MaintenanceUnit = new Sunny.UI.UILabel();
            this.Label_OutageStarted = new Sunny.UI.UILabel();
            this.Workstation = new Sunny.UI.UITextBox();
            this.Label_Workstation = new Sunny.UI.UILabel();
            this.Model = new Sunny.UI.UITextBox();
            this.Label_Model = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.Label_MachineList = new Sunny.UI.UILabel();
            this.CreationDate = new Sunny.UI.UITextBox();
            this.Label_CreationDate = new Sunny.UI.UILabel();
            this.Label_Creator = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UITextBox();
            this.Label_WorkOrderNo = new Sunny.UI.UILabel();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.Label_OrderNo = new Sunny.UI.UILabel();
            this.OrderNo = new Sunny.UI.UITextBox();
            this.Details = new Sunny.UI.UITextBox();
            this.Label_Details = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UIDatetimePicker();
            this.panel1.SuspendLayout();
            this.TLP_Content.SuspendLayout();
            this.panel_Items.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Button_Save);
            this.panel1.Controls.Add(this.Button_Cancel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 574);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(984, 70);
            this.panel1.TabIndex = 0;
            // 
            // Button_Save
            // 
            this.Button_Save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Save.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Save.Location = new System.Drawing.Point(716, 20);
            this.Button_Save.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Save.Name = "Button_Save";
            this.Button_Save.Radius = 10;
            this.Button_Save.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_Save.Size = new System.Drawing.Size(110, 35);
            this.Button_Save.Symbol = 61639;
            this.Button_Save.TabIndex = 7;
            this.Button_Save.Text = "儲存";
            this.Button_Save.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Save.Click += new System.EventHandler(this.Button_Save_Click);
            // 
            // Button_Cancel
            // 
            this.Button_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Cancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Button_Cancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Button_Cancel.Location = new System.Drawing.Point(846, 20);
            this.Button_Cancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.Button_Cancel.Name = "Button_Cancel";
            this.Button_Cancel.Radius = 10;
            this.Button_Cancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Button_Cancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.Button_Cancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Button_Cancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Button_Cancel.Size = new System.Drawing.Size(110, 35);
            this.Button_Cancel.Style = Sunny.UI.UIStyle.Custom;
            this.Button_Cancel.Symbol = 361453;
            this.Button_Cancel.TabIndex = 6;
            this.Button_Cancel.Text = "取消";
            this.Button_Cancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Button_Cancel.Click += new System.EventHandler(this.Button_Cancel_Click);
            // 
            // TLP_Content
            // 
            this.TLP_Content.ColumnCount = 2;
            this.TLP_Content.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.TLP_Content.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Content.Controls.Add(this.ListBox_Orders, 0, 0);
            this.TLP_Content.Controls.Add(this.panel_Items, 1, 0);
            this.TLP_Content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP_Content.Location = new System.Drawing.Point(0, 35);
            this.TLP_Content.Name = "TLP_Content";
            this.TLP_Content.RowCount = 1;
            this.TLP_Content.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP_Content.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.TLP_Content.Size = new System.Drawing.Size(984, 539);
            this.TLP_Content.TabIndex = 1;
            // 
            // ListBox_Orders
            // 
            this.ListBox_Orders.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ListBox_Orders.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ListBox_Orders.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.ListBox_Orders.ItemSelectForeColor = System.Drawing.Color.White;
            this.ListBox_Orders.Location = new System.Drawing.Point(4, 5);
            this.ListBox_Orders.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ListBox_Orders.MinimumSize = new System.Drawing.Size(1, 1);
            this.ListBox_Orders.Name = "ListBox_Orders";
            this.ListBox_Orders.Padding = new System.Windows.Forms.Padding(2);
            this.ListBox_Orders.ShowText = false;
            this.ListBox_Orders.Size = new System.Drawing.Size(192, 529);
            this.ListBox_Orders.TabIndex = 0;
            this.ListBox_Orders.Text = "uiListBox1";
            this.ListBox_Orders.SelectedIndexChanged += new System.EventHandler(this.ListBox_Orders_SelectedIndexChanged);
            // 
            // panel_Items
            // 
            this.panel_Items.Controls.Add(this.OutageStarted);
            this.panel_Items.Controls.Add(this.IssueCategory);
            this.panel_Items.Controls.Add(this.Engineers);
            this.panel_Items.Controls.Add(this.MaintenanceUnit);
            this.panel_Items.Controls.Add(this.Label_RequestingUnit);
            this.panel_Items.Controls.Add(this.RequestingUnit);
            this.panel_Items.Controls.Add(this.RepairStarted);
            this.panel_Items.Controls.Add(this.OutageEnded);
            this.panel_Items.Controls.Add(this.RepairCompleted);
            this.panel_Items.Controls.Add(this.OutageDuration);
            this.panel_Items.Controls.Add(this.RepairDuration);
            this.panel_Items.Controls.Add(this.Label_OutageDuration);
            this.panel_Items.Controls.Add(this.Label_RepairDuration);
            this.panel_Items.Controls.Add(this.Label_OutageEnded);
            this.panel_Items.Controls.Add(this.Label_RepairCompleted);
            this.panel_Items.Controls.Add(this.Label_RepairStarted);
            this.panel_Items.Controls.Add(this.IssueDescription);
            this.panel_Items.Controls.Add(this.Label_IssueDescription);
            this.panel_Items.Controls.Add(this.AcceptedTime);
            this.panel_Items.Controls.Add(this.Label_AcceptedTime);
            this.panel_Items.Controls.Add(this.Label_IssueCategory);
            this.panel_Items.Controls.Add(this.Label_Engineers);
            this.panel_Items.Controls.Add(this.Label_MaintenanceUnit);
            this.panel_Items.Controls.Add(this.Label_OutageStarted);
            this.panel_Items.Controls.Add(this.Workstation);
            this.panel_Items.Controls.Add(this.Label_Workstation);
            this.panel_Items.Controls.Add(this.Model);
            this.panel_Items.Controls.Add(this.Label_Model);
            this.panel_Items.Controls.Add(this.MachineList);
            this.panel_Items.Controls.Add(this.Label_MachineList);
            this.panel_Items.Controls.Add(this.CreationDate);
            this.panel_Items.Controls.Add(this.Label_CreationDate);
            this.panel_Items.Controls.Add(this.Label_Creator);
            this.panel_Items.Controls.Add(this.Creator);
            this.panel_Items.Controls.Add(this.Label_WorkOrderNo);
            this.panel_Items.Controls.Add(this.WorkOrderNo);
            this.panel_Items.Controls.Add(this.Label_OrderNo);
            this.panel_Items.Controls.Add(this.OrderNo);
            this.panel_Items.Controls.Add(this.Details);
            this.panel_Items.Controls.Add(this.Label_Details);
            this.panel_Items.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Items.Location = new System.Drawing.Point(203, 3);
            this.panel_Items.Name = "panel_Items";
            this.panel_Items.Size = new System.Drawing.Size(778, 533);
            this.panel_Items.TabIndex = 1;
            // 
            // IssueCategory
            // 
            this.IssueCategory.DataSource = null;
            this.IssueCategory.FillColor = System.Drawing.Color.White;
            this.IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.IssueCategory.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.IssueCategory.Location = new System.Drawing.Point(130, 287);
            this.IssueCategory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueCategory.MinimumSize = new System.Drawing.Size(63, 0);
            this.IssueCategory.Name = "IssueCategory";
            this.IssueCategory.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.IssueCategory.Size = new System.Drawing.Size(250, 29);
            this.IssueCategory.SymbolSize = 24;
            this.IssueCategory.TabIndex = 87;
            this.IssueCategory.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.IssueCategory.Watermark = "";
            // 
            // Engineers
            // 
            this.Engineers.CheckBoxes = true;
            this.Engineers.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Engineers.FillColor = System.Drawing.Color.White;
            this.Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Engineers.Location = new System.Drawing.Point(130, 248);
            this.Engineers.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Engineers.MinimumSize = new System.Drawing.Size(63, 0);
            this.Engineers.Name = "Engineers";
            this.Engineers.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Engineers.ShowSelectedAllCheckBox = false;
            this.Engineers.Size = new System.Drawing.Size(250, 29);
            this.Engineers.SymbolSize = 24;
            this.Engineers.TabIndex = 87;
            this.Engineers.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Engineers.Watermark = "";
            this.Engineers.NodesSelected += new Sunny.UI.UIComboTreeView.OnNodesSelected(this.Engineers_NodesSelected);
            // 
            // MaintenanceUnit
            // 
            this.MaintenanceUnit.DataSource = null;
            this.MaintenanceUnit.FillColor = System.Drawing.Color.White;
            this.MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceUnit.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.Location = new System.Drawing.Point(130, 209);
            this.MaintenanceUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaintenanceUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.MaintenanceUnit.Name = "MaintenanceUnit";
            this.MaintenanceUnit.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.MaintenanceUnit.Size = new System.Drawing.Size(250, 29);
            this.MaintenanceUnit.SymbolSize = 24;
            this.MaintenanceUnit.TabIndex = 86;
            this.MaintenanceUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceUnit.Watermark = "";
            this.MaintenanceUnit.SelectedIndexChanged += new System.EventHandler(this.MaintenanceUnit_SelectedIndexChanged);
            // 
            // Label_RequestingUnit
            // 
            this.Label_RequestingUnit.BackColor = System.Drawing.Color.Transparent;
            this.Label_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RequestingUnit.Location = new System.Drawing.Point(398, 14);
            this.Label_RequestingUnit.Name = "Label_RequestingUnit";
            this.Label_RequestingUnit.Size = new System.Drawing.Size(120, 29);
            this.Label_RequestingUnit.TabIndex = 85;
            this.Label_RequestingUnit.Text = "需求單位";
            this.Label_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RequestingUnit
            // 
            this.RequestingUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnit.FillDisableColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingUnit.Location = new System.Drawing.Point(525, 14);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnit.Name = "RequestingUnit";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnit.ShowText = false;
            this.RequestingUnit.Size = new System.Drawing.Size(228, 29);
            this.RequestingUnit.TabIndex = 84;
            this.RequestingUnit.TabStop = false;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // RepairStarted
            // 
            this.RepairStarted.DateFormat = "yyyy-MM-dd HH:mm";
            this.RepairStarted.FillColor = System.Drawing.Color.White;
            this.RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairStarted.Location = new System.Drawing.Point(525, 209);
            this.RepairStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairStarted.MaxLength = 16;
            this.RepairStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.RepairStarted.Name = "RepairStarted";
            this.RepairStarted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.RepairStarted.ShowToday = true;
            this.RepairStarted.Size = new System.Drawing.Size(200, 29);
            this.RepairStarted.SymbolDropDown = 61555;
            this.RepairStarted.SymbolNormal = 61555;
            this.RepairStarted.SymbolSize = 24;
            this.RepairStarted.TabIndex = 83;
            this.RepairStarted.Text = "2025-10-27 14:57";
            this.RepairStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairStarted.Value = new System.DateTime(2025, 10, 27, 14, 57, 57, 567);
            this.RepairStarted.Watermark = "";
            this.RepairStarted.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.RepairStarted_ValueChanged);
            // 
            // OutageEnded
            // 
            this.OutageEnded.DateFormat = "yyyy-MM-dd HH:mm";
            this.OutageEnded.FillColor = System.Drawing.Color.White;
            this.OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageEnded.Location = new System.Drawing.Point(525, 390);
            this.OutageEnded.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageEnded.MaxLength = 16;
            this.OutageEnded.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageEnded.Name = "OutageEnded";
            this.OutageEnded.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.OutageEnded.ShowToday = true;
            this.OutageEnded.Size = new System.Drawing.Size(200, 29);
            this.OutageEnded.SymbolDropDown = 61555;
            this.OutageEnded.SymbolNormal = 61555;
            this.OutageEnded.SymbolSize = 24;
            this.OutageEnded.TabIndex = 83;
            this.OutageEnded.Text = "2025-10-27 14:57";
            this.OutageEnded.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageEnded.Value = new System.DateTime(2025, 10, 27, 14, 57, 57, 567);
            this.OutageEnded.Watermark = "";
            this.OutageEnded.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.OutageEnded_ValueChanged);
            // 
            // RepairCompleted
            // 
            this.RepairCompleted.DateFormat = "yyyy-MM-dd HH:mm";
            this.RepairCompleted.FillColor = System.Drawing.Color.White;
            this.RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairCompleted.Location = new System.Drawing.Point(525, 248);
            this.RepairCompleted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairCompleted.MaxLength = 16;
            this.RepairCompleted.MinimumSize = new System.Drawing.Size(63, 0);
            this.RepairCompleted.Name = "RepairCompleted";
            this.RepairCompleted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.RepairCompleted.ShowToday = true;
            this.RepairCompleted.Size = new System.Drawing.Size(200, 29);
            this.RepairCompleted.SymbolDropDown = 61555;
            this.RepairCompleted.SymbolNormal = 61555;
            this.RepairCompleted.SymbolSize = 24;
            this.RepairCompleted.TabIndex = 82;
            this.RepairCompleted.Text = "2025-10-27 14:57";
            this.RepairCompleted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairCompleted.Value = new System.DateTime(2025, 10, 27, 14, 57, 57, 567);
            this.RepairCompleted.Watermark = "";
            this.RepairCompleted.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.RepairCompleted_ValueChanged);
            // 
            // OutageDuration
            // 
            this.OutageDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageDuration.FillDisableColor = System.Drawing.Color.White;
            this.OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageDuration.Location = new System.Drawing.Point(525, 429);
            this.OutageDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageDuration.Name = "OutageDuration";
            this.OutageDuration.Padding = new System.Windows.Forms.Padding(5);
            this.OutageDuration.ShowText = false;
            this.OutageDuration.Size = new System.Drawing.Size(200, 29);
            this.OutageDuration.TabIndex = 79;
            this.OutageDuration.TabStop = false;
            this.OutageDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageDuration.Watermark = "";
            // 
            // RepairDuration
            // 
            this.RepairDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairDuration.FillDisableColor = System.Drawing.Color.White;
            this.RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairDuration.Location = new System.Drawing.Point(525, 287);
            this.RepairDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairDuration.Name = "RepairDuration";
            this.RepairDuration.Padding = new System.Windows.Forms.Padding(5);
            this.RepairDuration.ShowText = false;
            this.RepairDuration.Size = new System.Drawing.Size(200, 29);
            this.RepairDuration.TabIndex = 71;
            this.RepairDuration.TabStop = false;
            this.RepairDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairDuration.Watermark = "";
            // 
            // Label_OutageDuration
            // 
            this.Label_OutageDuration.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageDuration.Location = new System.Drawing.Point(398, 429);
            this.Label_OutageDuration.Name = "Label_OutageDuration";
            this.Label_OutageDuration.Size = new System.Drawing.Size(120, 29);
            this.Label_OutageDuration.TabIndex = 81;
            this.Label_OutageDuration.Text = "停動工時";
            this.Label_OutageDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairDuration
            // 
            this.Label_RepairDuration.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairDuration.Location = new System.Drawing.Point(398, 287);
            this.Label_RepairDuration.Name = "Label_RepairDuration";
            this.Label_RepairDuration.Size = new System.Drawing.Size(120, 29);
            this.Label_RepairDuration.TabIndex = 73;
            this.Label_RepairDuration.Text = "維護工時";
            this.Label_RepairDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageEnded
            // 
            this.Label_OutageEnded.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageEnded.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageEnded.Location = new System.Drawing.Point(398, 390);
            this.Label_OutageEnded.Name = "Label_OutageEnded";
            this.Label_OutageEnded.Size = new System.Drawing.Size(120, 29);
            this.Label_OutageEnded.TabIndex = 76;
            this.Label_OutageEnded.Text = "停動結束時間";
            this.Label_OutageEnded.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairCompleted
            // 
            this.Label_RepairCompleted.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairCompleted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairCompleted.Location = new System.Drawing.Point(398, 248);
            this.Label_RepairCompleted.Name = "Label_RepairCompleted";
            this.Label_RepairCompleted.Size = new System.Drawing.Size(120, 29);
            this.Label_RepairCompleted.TabIndex = 70;
            this.Label_RepairCompleted.Text = "維護完成時間";
            this.Label_RepairCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairStarted
            // 
            this.Label_RepairStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairStarted.Location = new System.Drawing.Point(398, 209);
            this.Label_RepairStarted.Name = "Label_RepairStarted";
            this.Label_RepairStarted.Size = new System.Drawing.Size(120, 29);
            this.Label_RepairStarted.TabIndex = 67;
            this.Label_RepairStarted.Text = "維護開始時間";
            this.Label_RepairStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // IssueDescription
            // 
            this.IssueDescription.CanEmpty = true;
            this.IssueDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(130, 326);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueDescription.Multiline = true;
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(5);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(250, 85);
            this.IssueDescription.TabIndex = 72;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.IssueDescription.Watermark = "";
            // 
            // Label_IssueDescription
            // 
            this.Label_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueDescription.Location = new System.Drawing.Point(5, 326);
            this.Label_IssueDescription.Name = "Label_IssueDescription";
            this.Label_IssueDescription.Size = new System.Drawing.Size(118, 29);
            this.Label_IssueDescription.TabIndex = 74;
            this.Label_IssueDescription.Text = "問題描述";
            this.Label_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AcceptedTime
            // 
            this.AcceptedTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AcceptedTime.FillDisableColor = System.Drawing.Color.White;
            this.AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.AcceptedTime.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.AcceptedTime.Location = new System.Drawing.Point(525, 131);
            this.AcceptedTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AcceptedTime.MinimumSize = new System.Drawing.Size(1, 16);
            this.AcceptedTime.Name = "AcceptedTime";
            this.AcceptedTime.Padding = new System.Windows.Forms.Padding(5);
            this.AcceptedTime.ShowText = false;
            this.AcceptedTime.Size = new System.Drawing.Size(228, 29);
            this.AcceptedTime.TabIndex = 47;
            this.AcceptedTime.TabStop = false;
            this.AcceptedTime.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.AcceptedTime.Watermark = "";
            // 
            // Label_AcceptedTime
            // 
            this.Label_AcceptedTime.BackColor = System.Drawing.Color.Transparent;
            this.Label_AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_AcceptedTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_AcceptedTime.Location = new System.Drawing.Point(398, 131);
            this.Label_AcceptedTime.Name = "Label_AcceptedTime";
            this.Label_AcceptedTime.Size = new System.Drawing.Size(120, 29);
            this.Label_AcceptedTime.TabIndex = 49;
            this.Label_AcceptedTime.Text = "接單時間";
            this.Label_AcceptedTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_IssueCategory
            // 
            this.Label_IssueCategory.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueCategory.Location = new System.Drawing.Point(3, 287);
            this.Label_IssueCategory.Name = "Label_IssueCategory";
            this.Label_IssueCategory.Size = new System.Drawing.Size(120, 29);
            this.Label_IssueCategory.TabIndex = 64;
            this.Label_IssueCategory.Text = "維護類型";
            this.Label_IssueCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Engineers
            // 
            this.Label_Engineers.BackColor = System.Drawing.Color.Transparent;
            this.Label_Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Engineers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Engineers.Location = new System.Drawing.Point(3, 248);
            this.Label_Engineers.Name = "Label_Engineers";
            this.Label_Engineers.Size = new System.Drawing.Size(120, 29);
            this.Label_Engineers.TabIndex = 57;
            this.Label_Engineers.Text = "維護工程師";
            this.Label_Engineers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_MaintenanceUnit
            // 
            this.Label_MaintenanceUnit.BackColor = System.Drawing.Color.Transparent;
            this.Label_MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MaintenanceUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MaintenanceUnit.Location = new System.Drawing.Point(3, 209);
            this.Label_MaintenanceUnit.Name = "Label_MaintenanceUnit";
            this.Label_MaintenanceUnit.Size = new System.Drawing.Size(120, 29);
            this.Label_MaintenanceUnit.TabIndex = 53;
            this.Label_MaintenanceUnit.Text = "維護單位";
            this.Label_MaintenanceUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageStarted
            // 
            this.Label_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageStarted.Location = new System.Drawing.Point(398, 351);
            this.Label_OutageStarted.Name = "Label_OutageStarted";
            this.Label_OutageStarted.Size = new System.Drawing.Size(120, 29);
            this.Label_OutageStarted.TabIndex = 63;
            this.Label_OutageStarted.Text = "停動開始時間";
            this.Label_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Workstation
            // 
            this.Workstation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Workstation.FillDisableColor = System.Drawing.Color.White;
            this.Workstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Workstation.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Workstation.Location = new System.Drawing.Point(130, 170);
            this.Workstation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Workstation.MinimumSize = new System.Drawing.Size(1, 16);
            this.Workstation.Name = "Workstation";
            this.Workstation.Padding = new System.Windows.Forms.Padding(5);
            this.Workstation.ShowButton = true;
            this.Workstation.ShowText = false;
            this.Workstation.Size = new System.Drawing.Size(250, 29);
            this.Workstation.TabIndex = 55;
            this.Workstation.TabStop = false;
            this.Workstation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Workstation.Visible = false;
            this.Workstation.Watermark = "";
            this.Workstation.ButtonClick += new System.EventHandler(this.Workstation_ButtonClick);
            // 
            // Label_Workstation
            // 
            this.Label_Workstation.BackColor = System.Drawing.Color.Transparent;
            this.Label_Workstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Workstation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Workstation.Location = new System.Drawing.Point(3, 170);
            this.Label_Workstation.Name = "Label_Workstation";
            this.Label_Workstation.Size = new System.Drawing.Size(120, 29);
            this.Label_Workstation.TabIndex = 58;
            this.Label_Workstation.Text = "工站";
            this.Label_Workstation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Label_Workstation.Visible = false;
            // 
            // Model
            // 
            this.Model.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Model.FillDisableColor = System.Drawing.Color.White;
            this.Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Model.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Model.Location = new System.Drawing.Point(130, 131);
            this.Model.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Model.MinimumSize = new System.Drawing.Size(1, 16);
            this.Model.Name = "Model";
            this.Model.Padding = new System.Windows.Forms.Padding(5);
            this.Model.ShowButton = true;
            this.Model.ShowText = false;
            this.Model.Size = new System.Drawing.Size(250, 29);
            this.Model.TabIndex = 52;
            this.Model.TabStop = false;
            this.Model.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Model.Watermark = "";
            this.Model.ButtonClick += new System.EventHandler(this.Model_ButtonClick);
            // 
            // Label_Model
            // 
            this.Label_Model.BackColor = System.Drawing.Color.Transparent;
            this.Label_Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Model.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Model.Location = new System.Drawing.Point(3, 131);
            this.Label_Model.Name = "Label_Model";
            this.Label_Model.Size = new System.Drawing.Size(120, 29);
            this.Label_Model.TabIndex = 54;
            this.Label_Model.Text = "機種";
            this.Label_Model.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.FillDisableColor = System.Drawing.Color.White;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MachineList.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.MachineList.Location = new System.Drawing.Point(130, 92);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(250, 29);
            this.MachineList.TabIndex = 46;
            this.MachineList.TabStop = false;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            // 
            // Label_MachineList
            // 
            this.Label_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.Label_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MachineList.Location = new System.Drawing.Point(3, 92);
            this.Label_MachineList.Name = "Label_MachineList";
            this.Label_MachineList.Size = new System.Drawing.Size(120, 29);
            this.Label_MachineList.TabIndex = 48;
            this.Label_MachineList.Text = "機台編號";
            this.Label_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreationDate
            // 
            this.CreationDate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CreationDate.FillDisableColor = System.Drawing.Color.White;
            this.CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CreationDate.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CreationDate.Location = new System.Drawing.Point(525, 92);
            this.CreationDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CreationDate.MinimumSize = new System.Drawing.Size(1, 16);
            this.CreationDate.Name = "CreationDate";
            this.CreationDate.Padding = new System.Windows.Forms.Padding(5);
            this.CreationDate.ShowText = false;
            this.CreationDate.Size = new System.Drawing.Size(228, 29);
            this.CreationDate.TabIndex = 42;
            this.CreationDate.TabStop = false;
            this.CreationDate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreationDate.Watermark = "";
            // 
            // Label_CreationDate
            // 
            this.Label_CreationDate.BackColor = System.Drawing.Color.Transparent;
            this.Label_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_CreationDate.Location = new System.Drawing.Point(398, 92);
            this.Label_CreationDate.Name = "Label_CreationDate";
            this.Label_CreationDate.Size = new System.Drawing.Size(120, 29);
            this.Label_CreationDate.TabIndex = 44;
            this.Label_CreationDate.Text = "建檔日期";
            this.Label_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Creator
            // 
            this.Label_Creator.BackColor = System.Drawing.Color.Transparent;
            this.Label_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Creator.Location = new System.Drawing.Point(398, 53);
            this.Label_Creator.Name = "Label_Creator";
            this.Label_Creator.Size = new System.Drawing.Size(120, 29);
            this.Label_Creator.TabIndex = 43;
            this.Label_Creator.Text = "建檔人員";
            this.Label_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Creator
            // 
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.FillDisableColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Creator.Location = new System.Drawing.Point(525, 53);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(228, 29);
            this.Creator.TabIndex = 40;
            this.Creator.TabStop = false;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // Label_WorkOrderNo
            // 
            this.Label_WorkOrderNo.BackColor = System.Drawing.Color.Transparent;
            this.Label_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_WorkOrderNo.Location = new System.Drawing.Point(3, 53);
            this.Label_WorkOrderNo.Name = "Label_WorkOrderNo";
            this.Label_WorkOrderNo.Size = new System.Drawing.Size(120, 29);
            this.Label_WorkOrderNo.TabIndex = 38;
            this.Label_WorkOrderNo.Text = "維護工單編號";
            this.Label_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.FillDisableColor = System.Drawing.Color.White;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.WorkOrderNo.Location = new System.Drawing.Point(130, 53);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(250, 29);
            this.WorkOrderNo.TabIndex = 37;
            this.WorkOrderNo.TabStop = false;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // Label_OrderNo
            // 
            this.Label_OrderNo.BackColor = System.Drawing.Color.Transparent;
            this.Label_OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OrderNo.Location = new System.Drawing.Point(3, 14);
            this.Label_OrderNo.Margin = new System.Windows.Forms.Padding(0);
            this.Label_OrderNo.Name = "Label_OrderNo";
            this.Label_OrderNo.Size = new System.Drawing.Size(120, 29);
            this.Label_OrderNo.TabIndex = 36;
            this.Label_OrderNo.Text = "序號";
            this.Label_OrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OrderNo
            // 
            this.OrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OrderNo.FillDisableColor = System.Drawing.Color.White;
            this.OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OrderNo.Location = new System.Drawing.Point(130, 14);
            this.OrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.OrderNo.ShowText = false;
            this.OrderNo.Size = new System.Drawing.Size(250, 29);
            this.OrderNo.TabIndex = 35;
            this.OrderNo.TabStop = false;
            this.OrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OrderNo.Watermark = "";
            // 
            // Details
            // 
            this.Details.CanEmpty = true;
            this.Details.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Details.Location = new System.Drawing.Point(130, 421);
            this.Details.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Details.MinimumSize = new System.Drawing.Size(1, 16);
            this.Details.Multiline = true;
            this.Details.Name = "Details";
            this.Details.Padding = new System.Windows.Forms.Padding(5);
            this.Details.ShowText = false;
            this.Details.Size = new System.Drawing.Size(250, 85);
            this.Details.TabIndex = 77;
            this.Details.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.Details.Watermark = "";
            // 
            // Label_Details
            // 
            this.Label_Details.BackColor = System.Drawing.Color.Transparent;
            this.Label_Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Details.Location = new System.Drawing.Point(5, 421);
            this.Label_Details.Name = "Label_Details";
            this.Label_Details.Size = new System.Drawing.Size(118, 29);
            this.Label_Details.TabIndex = 78;
            this.Label_Details.Text = "維護內容";
            this.Label_Details.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.DateFormat = "yyyy-MM-dd HH:mm";
            this.OutageStarted.FillColor = System.Drawing.Color.White;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.Location = new System.Drawing.Point(525, 351);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MaxLength = 16;
            this.OutageStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.OutageStarted.ShowToday = true;
            this.OutageStarted.Size = new System.Drawing.Size(200, 29);
            this.OutageStarted.SymbolDropDown = 61555;
            this.OutageStarted.SymbolNormal = 61555;
            this.OutageStarted.SymbolSize = 24;
            this.OutageStarted.TabIndex = 84;
            this.OutageStarted.Text = "2025-10-27 14:57";
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageStarted.Value = new System.DateTime(2025, 10, 27, 14, 57, 57, 567);
            this.OutageStarted.Watermark = "";
            this.OutageStarted.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.OutageStarted_ValueChanged);
            // 
            // FT_MaintiWork
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(984, 644);
            this.Controls.Add(this.TLP_Content);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FT_MaintiWork";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "維護作業";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 1023, 675);
            this.Load += new System.EventHandler(this.FT_MaintiWork_Load);
            this.panel1.ResumeLayout(false);
            this.TLP_Content.ResumeLayout(false);
            this.panel_Items.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton Button_Save;
        private Sunny.UI.UISymbolButton Button_Cancel;
        private System.Windows.Forms.TableLayoutPanel TLP_Content;
        private Sunny.UI.UIListBox ListBox_Orders;
        private System.Windows.Forms.Panel panel_Items;
        private Sunny.UI.UITextBox OutageDuration;
        private Sunny.UI.UITextBox RepairDuration;
        private Sunny.UI.UILabel Label_OutageDuration;
        private Sunny.UI.UILabel Label_RepairDuration;
        private Sunny.UI.UILabel Label_OutageEnded;
        private Sunny.UI.UILabel Label_RepairCompleted;
        private Sunny.UI.UILabel Label_RepairStarted;
        private Sunny.UI.UITextBox IssueDescription;
        private Sunny.UI.UILabel Label_IssueDescription;
        private Sunny.UI.UITextBox AcceptedTime;
        private Sunny.UI.UILabel Label_AcceptedTime;
        private Sunny.UI.UILabel Label_IssueCategory;
        private Sunny.UI.UILabel Label_Engineers;
        private Sunny.UI.UILabel Label_MaintenanceUnit;
        private Sunny.UI.UILabel Label_OutageStarted;
        private Sunny.UI.UITextBox Workstation;
        private Sunny.UI.UILabel Label_Workstation;
        private Sunny.UI.UITextBox Model;
        private Sunny.UI.UILabel Label_Model;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UILabel Label_MachineList;
        private Sunny.UI.UITextBox CreationDate;
        private Sunny.UI.UILabel Label_CreationDate;
        private Sunny.UI.UILabel Label_Creator;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UILabel Label_WorkOrderNo;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UILabel Label_OrderNo;
        private Sunny.UI.UITextBox OrderNo;
        private Sunny.UI.UITextBox Details;
        private Sunny.UI.UILabel Label_Details;
        private Sunny.UI.UIDatetimePicker RepairCompleted;
        private Sunny.UI.UIDatetimePicker OutageEnded;
        private Sunny.UI.UIDatetimePicker RepairStarted;
        private Sunny.UI.UILabel Label_RequestingUnit;
        private Sunny.UI.UITextBox RequestingUnit;
        private Sunny.UI.UIComboBox MaintenanceUnit;
        private Sunny.UI.UIComboTreeView Engineers;
        private Sunny.UI.UIComboBox IssueCategory;
        private Sunny.UI.UIDatetimePicker OutageStarted;
    }
}
