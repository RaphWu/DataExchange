﻿/*
 * 工程師開單 vs 線上人員開單分開。
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Events;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class CreateFlow : UIForm
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly FieldTitle _fieldTitle;
        private readonly FlowLayoutSelector _flowLayoutSelector;

        private string _todayPrefix;
        private int _lastWorkOrderNo;

        #endregion fields

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 新建工單的工單號。
        /// </summary>
        public List<TaskOrder> NewWorkOrderNos { get; set; } = new List<TaskOrder>();

        public CreateFlow(CoreContext CoreContext,
                          CoreData coreData,
                          FieldTitle fieldTitle,
                          FlowLayoutSelector flowLayoutSelector)
        {
            InitializeComponent();
            _context = CoreContext;
            _coreData = coreData;
            _fieldTitle = fieldTitle;
            _flowLayoutSelector = flowLayoutSelector;

            CommonStyles.SetButton(Button_OK);
            CommonStyles.SetButton(Button_Cancel, accent: true);

            this.AcceptButton = Button_OK;
            this.CancelButton = Button_Cancel;
        }

        private void CreateFlow_Load(object sender, EventArgs e)
        {
            string caption;

            caption = _fieldTitle.RequestingUnit;
            Label_RequestingUnit.Text = caption;
            RequestingUnit.Watermark = caption;
            var rUnitList = _context.RequestingUnits
                .Select(r => new { r.Id, Display = r.UnitName, })
                .ToList();
            RequestingUnit.DataSource = rUnitList;
            RequestingUnit.DisplayMember = "Display";
            RequestingUnit.ValueMember = "Id";

            caption = _fieldTitle.Creator;
            Label_Creator.Text = caption;
            var employeeList = _coreData.Employees
                .Select(emp => new
                {
                    emp.EmployeeId,
                    Display = $"{emp.EmployeeId}, {emp.Department.DepartmentName}, {emp.Name}",
                })
                .ToList();
            Creator.DataSource = employeeList;
            Creator.DisplayMember = "Display";
            Creator.ValueMember = "EmployeeId";
            Creator.Watermark = caption;

            caption = _fieldTitle.Machine;
            Label_MachineList.Text = caption;
            MachineList.Watermark = caption;
            MachineList.ButtonFillColor = CommonStyles.BackColor;
            MachineList.ButtonFillHoverColor = CommonStyles.HoverColor;

            caption = _fieldTitle.OutageStarted;
            Label_OutageStarted.Text = caption;
            OutageStarted.Watermark = caption;
            OutageStarted.Value = DateTime.Now;

            caption = _fieldTitle.IssueDescription;
            Label_IssueDescription.Text = caption;
            IssueDescription.Watermark = caption;
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            // 需求單位
            if (string.IsNullOrWhiteSpace(RequestingUnit.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{Label_RequestingUnit.Text}！");
                return;
            }

            // 拆解機台編號
            var machineList = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();

            // 錯誤檢查
            if (string.IsNullOrWhiteSpace(Creator.Text))
            {
                UIMessageBox.ShowError2($"{Label_Creator.Text}必須要選擇一人！");
                return;
            }
            if (string.IsNullOrWhiteSpace(MachineList.Text))
            {
                UIMessageBox.ShowError2($"必須選擇{Label_MachineList.Text}！");
                return;
            }
            else
            {
                foreach (var mId in machineList)
                    if (_coreData.Machines.FindIndex(x => x.MachineId == mId) == -1)
                    {
                        UIMessageBox.ShowError2($"{Label_MachineList.Text}不存在: {mId}");
                        return;
                    }
            }
            //if (string.IsNullOrWhiteSpace(ModelWs.Text))
            //{
            //    UIMessageBox.ShowError2($"必須選擇{uiLabel_ModelWs.Text}！");
            //    return;
            //}
            //else
            //{
            //    if (_coreData.Models.FindIndex(x => x.ModelName == ModelWs.Text) == -1)
            //    {
            //        UIMessageBox.ShowError2($"{uiLabel_ModelWs.Text}不存在: {ModelWs.Text}");
            //        return;
            //    }
            //}

            try
            {
                var deviceList = new List<Machine>();

                // 計算新工單號
                _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                var tos = _context.TaskOrders;
                int lastOrderNo = tos.Select(x => x.OrderNo).Max();
                _lastWorkOrderNo = tos
                    .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                    .Select(w => w.WorkOrderNo)
                    .AsEnumerable()
                    .Select(o => int.TryParse(o.Substring(8, 3), out int val) ? val : 0)
                    .DefaultIfEmpty(0)
                    .Max();

                // 加入資料庫
                NewWorkOrderNos.Clear();

                int creatorId = _coreData.Employees.
                    FirstOrDefault(c => c.EmployeeId == (string)Creator.SelectedValue).Id;
                int rUnitId = (int)RequestingUnit.SelectedValue;
                for (int no = 1; no <= machineList.Count; no++)
                {
                    string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                    string machineId = machineList[no - 1];
                    var to = new TaskOrder()
                    {
                        OrderNo = lastOrderNo + no,
                        WorkOrderNo = newWorkOrderNo,
                        CreationDate = DateTime.Today,
                        Machine = _context.Machines.FirstOrDefault(x => x.MachineId == machineId),
                        IssueDescription = IssueDescription.Text,

                        CreatorId = creatorId,
                        Status = OrderStatus.NewTaskOrder,
                        AcceptedTime = DateTime.Now,
                        OutageStarted = OutageStarted.Value,
                        RequestingUnitId = rUnitId,

                        WorkstationId = 0,
                        MaintenanceUnitId = 0,
                        IssueCategoryId = 0,
                        Details = "",
                        RequestingEmployeeId = 0,
                        Response = "",
                        Responsible = "",
                    };
                    _context.TaskOrders.Add(to);
                    NewWorkOrderNos.Add(to);
                }
                _context.SaveChanges();

                StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void MachineId_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.HideTabHeaders = false;
            _flowLayoutSelector.ShowTreeView = true;
            _flowLayoutSelector.Title = $"請選擇{_fieldTitle.Machine}";
            _flowLayoutSelector.MultiSelection = true;
            _flowLayoutSelector.TabPageCache = _coreData.MachinesMultiTabPageCache;
            _flowLayoutSelector.DefaultChecked = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _flowLayoutSelector.Initialize();

            //if (Core.Views.FormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                if (_flowLayoutSelector.ResultList.Count > 0)
                {
                    //string deviceString = "";
                    //foreach (var info in _flowLayoutSelector.ResultList)
                    //{
                    //    if (deviceString != "")
                    //        deviceString += "; ";
                    //    deviceString += info.Name;
                    //}
                    //MachineList.Text = deviceString;
                    MachineList.Text = string.Join("; ", _flowLayoutSelector.ResultList.Select(r => r.Name).ToArray());
                }
                else
                {
                    MachineList.Text = "";
                }
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            Creator.Text = "";
            MachineList.Text = "";
            OutageStarted.Value = DateTime.Now;
            IssueDescription.Text = "";
        }
    }
}
