﻿using System;
using System.Linq;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class CreateFlow : UIForm
    {
        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;
        private readonly FlowLayoutSelector _flowLayoutSelector;

        public CreateFlow(CoreData coreData, MaintiFlowData flowData, FlowLayoutSelector flowLayoutSelector)
        {
            InitializeComponent();
            _coreData = coreData;
            _flowData = flowData;
            _flowLayoutSelector = flowLayoutSelector;

            uiPanel_BasicData.TitleColor = CommonStyles.BackColor;
            uiButton_OK.FillColor = CommonStyles.BackColor;
            uiButton_OK.FillHoverColor = CommonStyles.Hover;

            /********************
             * Controls
             ********************/
            string caption;

            //caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.WorkOrderNo));
            //uiLabel_WorkOrderNo.Text = caption;
            //WorkOrderNo.Watermark = caption;

            //caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.CreationDate));
            //uiLabel_CreationDate.Text = caption;
            //CreationDate.Watermark = caption;

            caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Creator));
            uiLabel_Creator.Text = caption;
            var employeeList = _coreData.EmployeeList
                .Select(e => new
                {
                    e.EmployeeId,
                    Display = $"{e.EmployeeId}, {e.Department}, {e.Name}"
                })
                .ToList();
            Creator.DataSource = employeeList;
            Creator.DisplayMember = "Display";
            Creator.ValueMember = "EmployeeId";
            Creator.Watermark = caption;

            caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderDevices));
            uiLabel_MachineId.Text = caption;
            MachineId.Watermark = caption;
            MachineId.ButtonFillColor = CommonStyles.BackColor;
            MachineId.ButtonFillHoverColor = CommonStyles.Hover;

            caption = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Model));
            uiLabel_Model.Text = caption;
            Model.Watermark = caption;
            Model.ButtonFillColor = CommonStyles.BackColor;
            Model.ButtonFillHoverColor = CommonStyles.Hover;
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {

        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void MachineId_NodesSelected(object sender, TreeNodeCollection nodes)
        {
            MachineId.Text = string.Empty;

            foreach (TreeNode item in nodes)
            {
                if (item.Checked)
                    MachineId.Text += item.Text + ";";
            }
        }

        private void MachineId_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.Title = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.TaskOrderDevices));
            _flowLayoutSelector.MultiSelection = true;
            _flowLayoutSelector.DisplayList = _flowData.DeviceList;

            string machineString = "";
            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                foreach (var item in _flowLayoutSelector.ResultList)
                {
                    if (machineString != "")
                        machineString += "; ";
                    machineString += _flowData.DeviceList.First(x => x.Key == item).Value;
                }
            }
            MachineId.Text = machineString;
        }

        private void Model_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.Title = EnumHelper.GetDescription<TaskOrder>(nameof(TaskOrder.Model));
            _flowLayoutSelector.MultiSelection = false;
            _flowLayoutSelector.DisplayList = _flowData.ModelList;

            string modelString = "";
            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                foreach (var item in _flowLayoutSelector.ResultList)
                {
                    if (modelString != "")
                        modelString += "; ";
                    modelString += _flowData.ModelList.First(x => x.Key == item).Value;
                }
            }
            Model.Text = modelString;
        }
    }
}
