﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class MaintiFlowSummary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiPanel_Detail = new Sunny.UI.UIPanel();
            this.TextBox_FillingTime = new Sunny.UI.UITextBox();
            this.Label_FillingTime = new Sunny.UI.UILabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.EditModeSwitch = new Sunny.UI.UISwitch();
            this.uiButton_Delete = new Sunny.UI.UISymbolButton();
            this.RequestingUnitResponse = new Sunny.UI.UITextBox();
            this.uiLabel_Responsible = new Sunny.UI.UILabel();
            this.OutageDuration = new Sunny.UI.UITextBox();
            this.Responsible = new Sunny.UI.UITextBox();
            this.uiLabel_RequestingUnitResponse = new Sunny.UI.UILabel();
            this.RequestingEmployee = new Sunny.UI.UITextBox();
            this.RepairDuration = new Sunny.UI.UITextBox();
            this.uiLabel_OutageDuration = new Sunny.UI.UILabel();
            this.uiLabel_RepairDuration = new Sunny.UI.UILabel();
            this.uiLabel_RequestingEmployee = new Sunny.UI.UILabel();
            this.OutageEnded = new Sunny.UI.UITextBox();
            this.uiLabel_OutageEnded = new Sunny.UI.UILabel();
            this.RepairCompleted = new Sunny.UI.UITextBox();
            this.uiLabel_RequestingUnit = new Sunny.UI.UILabel();
            this.RequestingUnit = new Sunny.UI.UITextBox();
            this.uiLabel_RepairCompleted = new Sunny.UI.UILabel();
            this.RepairStarted = new Sunny.UI.UITextBox();
            this.uiLabel_RepairStarted = new Sunny.UI.UILabel();
            this.IssueDescription = new Sunny.UI.UITextBox();
            this.uiLabel_IssueDescription = new Sunny.UI.UILabel();
            this.AcceptedTime = new Sunny.UI.UITextBox();
            this.uiLabel_AcceptedTime = new Sunny.UI.UILabel();
            this.IssueCategory = new Sunny.UI.UITextBox();
            this.uiLabel_IssueCategory = new Sunny.UI.UILabel();
            this.MaintenanceEngineer = new Sunny.UI.UITextBox();
            this.uiLabel_MaintenanceEngineer = new Sunny.UI.UILabel();
            this.MaintenanceUnit = new Sunny.UI.UITextBox();
            this.uiLabel_MaintenanceUnit = new Sunny.UI.UILabel();
            this.Status = new Sunny.UI.UITextBox();
            this.uiLabel_Status = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UITextBox();
            this.uiLabel_OutageStarted = new Sunny.UI.UILabel();
            this.Workstation = new Sunny.UI.UITextBox();
            this.uiLabel_WorkStation = new Sunny.UI.UILabel();
            this.Model = new Sunny.UI.UITextBox();
            this.uiLabel_Model = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.uiLabel_MachineList = new Sunny.UI.UILabel();
            this.CreationDate = new Sunny.UI.UITextBox();
            this.uiLabel_CreationDate = new Sunny.UI.UILabel();
            this.uiLabel_Creator = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UITextBox();
            this.uiLabel_WorkOrderNo = new Sunny.UI.UILabel();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.uiLabel_OrderNo = new Sunny.UI.UILabel();
            this.OrderNo = new Sunny.UI.UITextBox();
            this.Details = new Sunny.UI.UITextBox();
            this.uiLabel_Details = new Sunny.UI.UILabel();
            this.panel_Grid = new System.Windows.Forms.Panel();
            this.ADGV = new Zuby.ADGV.AdvancedDataGridView();
            this.uiPanel_Detail.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel_Grid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ADGV)).BeginInit();
            this.SuspendLayout();
            // 
            // uiPanel_Detail
            // 
            this.uiPanel_Detail.Controls.Add(this.TextBox_FillingTime);
            this.uiPanel_Detail.Controls.Add(this.Label_FillingTime);
            this.uiPanel_Detail.Controls.Add(this.panel1);
            this.uiPanel_Detail.Controls.Add(this.RequestingUnitResponse);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_Responsible);
            this.uiPanel_Detail.Controls.Add(this.OutageDuration);
            this.uiPanel_Detail.Controls.Add(this.Responsible);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_RequestingUnitResponse);
            this.uiPanel_Detail.Controls.Add(this.RequestingEmployee);
            this.uiPanel_Detail.Controls.Add(this.RepairDuration);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_OutageDuration);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_RepairDuration);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_RequestingEmployee);
            this.uiPanel_Detail.Controls.Add(this.OutageEnded);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_OutageEnded);
            this.uiPanel_Detail.Controls.Add(this.RepairCompleted);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_RequestingUnit);
            this.uiPanel_Detail.Controls.Add(this.RequestingUnit);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_RepairCompleted);
            this.uiPanel_Detail.Controls.Add(this.RepairStarted);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_RepairStarted);
            this.uiPanel_Detail.Controls.Add(this.IssueDescription);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_IssueDescription);
            this.uiPanel_Detail.Controls.Add(this.AcceptedTime);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_AcceptedTime);
            this.uiPanel_Detail.Controls.Add(this.IssueCategory);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_IssueCategory);
            this.uiPanel_Detail.Controls.Add(this.MaintenanceEngineer);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_MaintenanceEngineer);
            this.uiPanel_Detail.Controls.Add(this.MaintenanceUnit);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_MaintenanceUnit);
            this.uiPanel_Detail.Controls.Add(this.Status);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_Status);
            this.uiPanel_Detail.Controls.Add(this.OutageStarted);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_OutageStarted);
            this.uiPanel_Detail.Controls.Add(this.Workstation);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_WorkStation);
            this.uiPanel_Detail.Controls.Add(this.Model);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_Model);
            this.uiPanel_Detail.Controls.Add(this.MachineList);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_MachineList);
            this.uiPanel_Detail.Controls.Add(this.CreationDate);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_CreationDate);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_Creator);
            this.uiPanel_Detail.Controls.Add(this.Creator);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_WorkOrderNo);
            this.uiPanel_Detail.Controls.Add(this.WorkOrderNo);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_OrderNo);
            this.uiPanel_Detail.Controls.Add(this.OrderNo);
            this.uiPanel_Detail.Controls.Add(this.Details);
            this.uiPanel_Detail.Controls.Add(this.uiLabel_Details);
            this.uiPanel_Detail.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.uiPanel_Detail.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiPanel_Detail.Location = new System.Drawing.Point(0, 298);
            this.uiPanel_Detail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel_Detail.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel_Detail.Name = "uiPanel_Detail";
            this.uiPanel_Detail.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPanel_Detail.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.uiPanel_Detail.Size = new System.Drawing.Size(1259, 416);
            this.uiPanel_Detail.TabIndex = 1;
            this.uiPanel_Detail.Text = null;
            this.uiPanel_Detail.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TextBox_FillingTime
            // 
            this.TextBox_FillingTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBox_FillingTime.FillDisableColor = System.Drawing.Color.White;
            this.TextBox_FillingTime.FillReadOnlyColor = System.Drawing.Color.White;
            this.TextBox_FillingTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.TextBox_FillingTime.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.TextBox_FillingTime.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.TextBox_FillingTime.Location = new System.Drawing.Point(498, 363);
            this.TextBox_FillingTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TextBox_FillingTime.MinimumSize = new System.Drawing.Size(1, 16);
            this.TextBox_FillingTime.Name = "TextBox_FillingTime";
            this.TextBox_FillingTime.Padding = new System.Windows.Forms.Padding(5);
            this.TextBox_FillingTime.ReadOnly = true;
            this.TextBox_FillingTime.ShowText = false;
            this.TextBox_FillingTime.Size = new System.Drawing.Size(200, 29);
            this.TextBox_FillingTime.TabIndex = 33;
            this.TextBox_FillingTime.TabStop = false;
            this.TextBox_FillingTime.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.TextBox_FillingTime.Watermark = "";
            // 
            // Label_FillingTime
            // 
            this.Label_FillingTime.BackColor = System.Drawing.Color.Transparent;
            this.Label_FillingTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_FillingTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_FillingTime.Location = new System.Drawing.Point(371, 363);
            this.Label_FillingTime.Name = "Label_FillingTime";
            this.Label_FillingTime.Size = new System.Drawing.Size(120, 29);
            this.Label_FillingTime.TabIndex = 34;
            this.Label_FillingTime.Text = "填寫時間";
            this.Label_FillingTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.EditModeSwitch);
            this.panel1.Controls.Add(this.uiButton_Delete);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1116, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(143, 416);
            this.panel1.TabIndex = 34;
            // 
            // EditModeSwitch
            // 
            this.EditModeSwitch.ActiveText = "編輯";
            this.EditModeSwitch.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.EditModeSwitch.InActiveText = "唯讀";
            this.EditModeSwitch.Location = new System.Drawing.Point(21, 359);
            this.EditModeSwitch.MinimumSize = new System.Drawing.Size(1, 1);
            this.EditModeSwitch.Name = "EditModeSwitch";
            this.EditModeSwitch.Size = new System.Drawing.Size(99, 33);
            this.EditModeSwitch.TabIndex = 2;
            this.EditModeSwitch.Visible = false;
            this.EditModeSwitch.ValueChanged += new Sunny.UI.UISwitch.OnValueChanged(this.EditModeSwitch_ValueChanged);
            // 
            // uiButton_Delete
            // 
            this.uiButton_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.uiButton_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Delete.FillColor = System.Drawing.Color.Brown;
            this.uiButton_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_Delete.Location = new System.Drawing.Point(20, 146);
            this.uiButton_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Delete.Name = "uiButton_Delete";
            this.uiButton_Delete.Radius = 10;
            this.uiButton_Delete.Size = new System.Drawing.Size(100, 45);
            this.uiButton_Delete.Symbol = 559691;
            this.uiButton_Delete.TabIndex = 1;
            this.uiButton_Delete.Text = "刪除";
            this.uiButton_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Delete.Visible = false;
            this.uiButton_Delete.Click += new System.EventHandler(this.uiButton_Delete_Click);
            // 
            // RequestingUnitResponse
            // 
            this.RequestingUnitResponse.CanEmpty = true;
            this.RequestingUnitResponse.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnitResponse.FillReadOnlyColor = System.Drawing.Color.White;
            this.RequestingUnitResponse.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnitResponse.Location = new System.Drawing.Point(860, 319);
            this.RequestingUnitResponse.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnitResponse.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnitResponse.Multiline = true;
            this.RequestingUnitResponse.Name = "RequestingUnitResponse";
            this.RequestingUnitResponse.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnitResponse.ReadOnly = true;
            this.RequestingUnitResponse.ShowText = false;
            this.RequestingUnitResponse.Size = new System.Drawing.Size(250, 85);
            this.RequestingUnitResponse.TabIndex = 32;
            this.RequestingUnitResponse.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.RequestingUnitResponse.Watermark = "";
            // 
            // uiLabel_Responsible
            // 
            this.uiLabel_Responsible.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Responsible.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Responsible.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Responsible.Location = new System.Drawing.Point(18, 363);
            this.uiLabel_Responsible.Name = "uiLabel_Responsible";
            this.uiLabel_Responsible.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Responsible.TabIndex = 12;
            this.uiLabel_Responsible.Text = "責任歸屬";
            this.uiLabel_Responsible.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageDuration
            // 
            this.OutageDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageDuration.FillDisableColor = System.Drawing.Color.White;
            this.OutageDuration.FillReadOnlyColor = System.Drawing.Color.White;
            this.OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageDuration.Location = new System.Drawing.Point(498, 285);
            this.OutageDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageDuration.Name = "OutageDuration";
            this.OutageDuration.Padding = new System.Windows.Forms.Padding(5);
            this.OutageDuration.ReadOnly = true;
            this.OutageDuration.ShowText = false;
            this.OutageDuration.Size = new System.Drawing.Size(200, 29);
            this.OutageDuration.TabIndex = 31;
            this.OutageDuration.TabStop = false;
            this.OutageDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageDuration.Watermark = "";
            // 
            // Responsible
            // 
            this.Responsible.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Responsible.FillDisableColor = System.Drawing.Color.White;
            this.Responsible.FillReadOnlyColor = System.Drawing.Color.White;
            this.Responsible.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Responsible.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Responsible.Location = new System.Drawing.Point(145, 363);
            this.Responsible.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Responsible.MinimumSize = new System.Drawing.Size(1, 16);
            this.Responsible.Name = "Responsible";
            this.Responsible.Padding = new System.Windows.Forms.Padding(5);
            this.Responsible.ReadOnly = true;
            this.Responsible.ShowText = false;
            this.Responsible.Size = new System.Drawing.Size(200, 29);
            this.Responsible.TabIndex = 11;
            this.Responsible.TabStop = false;
            this.Responsible.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Responsible.Watermark = "";
            // 
            // uiLabel_RequestingUnitResponse
            // 
            this.uiLabel_RequestingUnitResponse.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RequestingUnitResponse.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingUnitResponse.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingUnitResponse.Location = new System.Drawing.Point(735, 319);
            this.uiLabel_RequestingUnitResponse.Name = "uiLabel_RequestingUnitResponse";
            this.uiLabel_RequestingUnitResponse.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_RequestingUnitResponse.TabIndex = 33;
            this.uiLabel_RequestingUnitResponse.Text = "需求單位回覆";
            this.uiLabel_RequestingUnitResponse.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RequestingEmployeeString
            // 
            this.RequestingEmployee.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingEmployee.FillDisableColor = System.Drawing.Color.White;
            this.RequestingEmployee.FillReadOnlyColor = System.Drawing.Color.White;
            this.RequestingEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingEmployee.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingEmployee.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RequestingEmployee.Location = new System.Drawing.Point(860, 280);
            this.RequestingEmployee.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingEmployee.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingEmployee.Name = "RequestingEmployeeString";
            this.RequestingEmployee.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingEmployee.ReadOnly = true;
            this.RequestingEmployee.ShowText = false;
            this.RequestingEmployee.Size = new System.Drawing.Size(200, 29);
            this.RequestingEmployee.TabIndex = 23;
            this.RequestingEmployee.TabStop = false;
            this.RequestingEmployee.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingEmployee.Watermark = "";
            // 
            // RepairDuration
            // 
            this.RepairDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairDuration.FillDisableColor = System.Drawing.Color.White;
            this.RepairDuration.FillReadOnlyColor = System.Drawing.Color.White;
            this.RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairDuration.Location = new System.Drawing.Point(498, 168);
            this.RepairDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairDuration.Name = "RepairDuration";
            this.RepairDuration.Padding = new System.Windows.Forms.Padding(5);
            this.RepairDuration.ReadOnly = true;
            this.RepairDuration.ShowText = false;
            this.RepairDuration.Size = new System.Drawing.Size(200, 29);
            this.RepairDuration.TabIndex = 27;
            this.RepairDuration.TabStop = false;
            this.RepairDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairDuration.Watermark = "";
            // 
            // uiLabel_OutageDuration
            // 
            this.uiLabel_OutageDuration.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageDuration.Location = new System.Drawing.Point(371, 285);
            this.uiLabel_OutageDuration.Name = "uiLabel_OutageDuration";
            this.uiLabel_OutageDuration.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OutageDuration.TabIndex = 32;
            this.uiLabel_OutageDuration.Text = "停動工時";
            this.uiLabel_OutageDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RepairDuration
            // 
            this.uiLabel_RepairDuration.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairDuration.Location = new System.Drawing.Point(371, 168);
            this.uiLabel_RepairDuration.Name = "uiLabel_RepairDuration";
            this.uiLabel_RepairDuration.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RepairDuration.TabIndex = 28;
            this.uiLabel_RepairDuration.Text = "維護工時";
            this.uiLabel_RepairDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RequestingEmployee
            // 
            this.uiLabel_RequestingEmployee.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RequestingEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingEmployee.Location = new System.Drawing.Point(733, 280);
            this.uiLabel_RequestingEmployee.Name = "uiLabel_RequestingEmployee";
            this.uiLabel_RequestingEmployee.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RequestingEmployee.TabIndex = 24;
            this.uiLabel_RequestingEmployee.Text = "需求單位人員";
            this.uiLabel_RequestingEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageEnded
            // 
            this.OutageEnded.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageEnded.FillDisableColor = System.Drawing.Color.White;
            this.OutageEnded.FillReadOnlyColor = System.Drawing.Color.White;
            this.OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageEnded.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageEnded.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageEnded.Location = new System.Drawing.Point(498, 246);
            this.OutageEnded.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageEnded.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageEnded.Name = "OutageEnded";
            this.OutageEnded.Padding = new System.Windows.Forms.Padding(5);
            this.OutageEnded.ReadOnly = true;
            this.OutageEnded.ShowText = false;
            this.OutageEnded.Size = new System.Drawing.Size(200, 29);
            this.OutageEnded.TabIndex = 29;
            this.OutageEnded.TabStop = false;
            this.OutageEnded.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageEnded.Watermark = "";
            // 
            // uiLabel_OutageEnded
            // 
            this.uiLabel_OutageEnded.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageEnded.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageEnded.Location = new System.Drawing.Point(371, 246);
            this.uiLabel_OutageEnded.Name = "uiLabel_OutageEnded";
            this.uiLabel_OutageEnded.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OutageEnded.TabIndex = 30;
            this.uiLabel_OutageEnded.Text = "停動結束時間";
            this.uiLabel_OutageEnded.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RepairCompleted
            // 
            this.RepairCompleted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairCompleted.FillDisableColor = System.Drawing.Color.White;
            this.RepairCompleted.FillReadOnlyColor = System.Drawing.Color.White;
            this.RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairCompleted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairCompleted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairCompleted.Location = new System.Drawing.Point(498, 129);
            this.RepairCompleted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairCompleted.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairCompleted.Name = "RepairCompleted";
            this.RepairCompleted.Padding = new System.Windows.Forms.Padding(5);
            this.RepairCompleted.ReadOnly = true;
            this.RepairCompleted.ShowText = false;
            this.RepairCompleted.Size = new System.Drawing.Size(200, 29);
            this.RepairCompleted.TabIndex = 25;
            this.RepairCompleted.TabStop = false;
            this.RepairCompleted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairCompleted.Watermark = "";
            // 
            // uiLabel_RequestingUnit
            // 
            this.uiLabel_RequestingUnit.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingUnit.Location = new System.Drawing.Point(733, 241);
            this.uiLabel_RequestingUnit.Name = "uiLabel_RequestingUnit";
            this.uiLabel_RequestingUnit.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RequestingUnit.TabIndex = 22;
            this.uiLabel_RequestingUnit.Text = "需求單位名稱";
            this.uiLabel_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RequestingUnitString
            // 
            this.RequestingUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnit.FillDisableColor = System.Drawing.Color.White;
            this.RequestingUnit.FillReadOnlyColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingUnit.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RequestingUnit.Location = new System.Drawing.Point(860, 241);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnit.Name = "RequestingUnitString";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnit.ReadOnly = true;
            this.RequestingUnit.ShowText = false;
            this.RequestingUnit.Size = new System.Drawing.Size(200, 29);
            this.RequestingUnit.TabIndex = 21;
            this.RequestingUnit.TabStop = false;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // uiLabel_RepairCompleted
            // 
            this.uiLabel_RepairCompleted.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairCompleted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairCompleted.Location = new System.Drawing.Point(371, 129);
            this.uiLabel_RepairCompleted.Name = "uiLabel_RepairCompleted";
            this.uiLabel_RepairCompleted.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RepairCompleted.TabIndex = 26;
            this.uiLabel_RepairCompleted.Text = "維護完成時間";
            this.uiLabel_RepairCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RepairStarted
            // 
            this.RepairStarted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairStarted.FillDisableColor = System.Drawing.Color.White;
            this.RepairStarted.FillReadOnlyColor = System.Drawing.Color.White;
            this.RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairStarted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairStarted.Location = new System.Drawing.Point(498, 90);
            this.RepairStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairStarted.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairStarted.Name = "RepairStarted";
            this.RepairStarted.Padding = new System.Windows.Forms.Padding(5);
            this.RepairStarted.ReadOnly = true;
            this.RepairStarted.ShowText = false;
            this.RepairStarted.Size = new System.Drawing.Size(200, 29);
            this.RepairStarted.TabIndex = 23;
            this.RepairStarted.TabStop = false;
            this.RepairStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairStarted.Watermark = "";
            // 
            // uiLabel_RepairStarted
            // 
            this.uiLabel_RepairStarted.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairStarted.Location = new System.Drawing.Point(371, 90);
            this.uiLabel_RepairStarted.Name = "uiLabel_RepairStarted";
            this.uiLabel_RepairStarted.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_RepairStarted.TabIndex = 24;
            this.uiLabel_RepairStarted.Text = "維護開始時間";
            this.uiLabel_RepairStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // IssueDescription
            // 
            this.IssueDescription.CanEmpty = true;
            this.IssueDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueDescription.FillReadOnlyColor = System.Drawing.Color.White;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(860, 51);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueDescription.Multiline = true;
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(5);
            this.IssueDescription.ReadOnly = true;
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(250, 85);
            this.IssueDescription.TabIndex = 28;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.IssueDescription.Watermark = "";
            // 
            // uiLabel_IssueDescription
            // 
            this.uiLabel_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueDescription.Location = new System.Drawing.Point(735, 51);
            this.uiLabel_IssueDescription.Name = "uiLabel_IssueDescription";
            this.uiLabel_IssueDescription.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_IssueDescription.TabIndex = 29;
            this.uiLabel_IssueDescription.Text = "問題描述";
            this.uiLabel_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AcceptedTime
            // 
            this.AcceptedTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AcceptedTime.FillDisableColor = System.Drawing.Color.White;
            this.AcceptedTime.FillReadOnlyColor = System.Drawing.Color.White;
            this.AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.AcceptedTime.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.AcceptedTime.Location = new System.Drawing.Point(145, 324);
            this.AcceptedTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AcceptedTime.MinimumSize = new System.Drawing.Size(1, 16);
            this.AcceptedTime.Name = "AcceptedTime";
            this.AcceptedTime.Padding = new System.Windows.Forms.Padding(5);
            this.AcceptedTime.ReadOnly = true;
            this.AcceptedTime.ShowText = false;
            this.AcceptedTime.Size = new System.Drawing.Size(200, 29);
            this.AcceptedTime.TabIndex = 15;
            this.AcceptedTime.TabStop = false;
            this.AcceptedTime.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.AcceptedTime.Watermark = "";
            // 
            // uiLabel_AcceptedTime
            // 
            this.uiLabel_AcceptedTime.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_AcceptedTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_AcceptedTime.Location = new System.Drawing.Point(18, 324);
            this.uiLabel_AcceptedTime.Name = "uiLabel_AcceptedTime";
            this.uiLabel_AcceptedTime.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_AcceptedTime.TabIndex = 16;
            this.uiLabel_AcceptedTime.Text = "接單時間";
            this.uiLabel_AcceptedTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // IssueCategoryString
            // 
            this.IssueCategory.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueCategory.FillDisableColor = System.Drawing.Color.White;
            this.IssueCategory.FillReadOnlyColor = System.Drawing.Color.White;
            this.IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.IssueCategory.Location = new System.Drawing.Point(860, 12);
            this.IssueCategory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueCategory.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueCategory.Name = "IssueCategoryString";
            this.IssueCategory.Padding = new System.Windows.Forms.Padding(5);
            this.IssueCategory.ReadOnly = true;
            this.IssueCategory.ShowText = false;
            this.IssueCategory.Size = new System.Drawing.Size(200, 29);
            this.IssueCategory.TabIndex = 21;
            this.IssueCategory.TabStop = false;
            this.IssueCategory.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.IssueCategory.Watermark = "";
            // 
            // uiLabel_IssueCategory
            // 
            this.uiLabel_IssueCategory.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueCategory.Location = new System.Drawing.Point(733, 12);
            this.uiLabel_IssueCategory.Name = "uiLabel_IssueCategory";
            this.uiLabel_IssueCategory.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_IssueCategory.TabIndex = 22;
            this.uiLabel_IssueCategory.Text = "維護類型";
            this.uiLabel_IssueCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MaintenanceEngineer
            // 
            this.MaintenanceEngineer.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaintenanceEngineer.FillDisableColor = System.Drawing.Color.White;
            this.MaintenanceEngineer.FillReadOnlyColor = System.Drawing.Color.White;
            this.MaintenanceEngineer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceEngineer.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaintenanceEngineer.Location = new System.Drawing.Point(498, 51);
            this.MaintenanceEngineer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaintenanceEngineer.MinimumSize = new System.Drawing.Size(1, 16);
            this.MaintenanceEngineer.Name = "MaintenanceEngineer";
            this.MaintenanceEngineer.Padding = new System.Windows.Forms.Padding(5);
            this.MaintenanceEngineer.ReadOnly = true;
            this.MaintenanceEngineer.ShowText = false;
            this.MaintenanceEngineer.Size = new System.Drawing.Size(200, 29);
            this.MaintenanceEngineer.TabIndex = 19;
            this.MaintenanceEngineer.TabStop = false;
            this.MaintenanceEngineer.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceEngineer.Watermark = "";
            // 
            // uiLabel_MaintenanceEngineer
            // 
            this.uiLabel_MaintenanceEngineer.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MaintenanceEngineer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MaintenanceEngineer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MaintenanceEngineer.Location = new System.Drawing.Point(371, 51);
            this.uiLabel_MaintenanceEngineer.Name = "uiLabel_MaintenanceEngineer";
            this.uiLabel_MaintenanceEngineer.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_MaintenanceEngineer.TabIndex = 20;
            this.uiLabel_MaintenanceEngineer.Text = "維護工程師";
            this.uiLabel_MaintenanceEngineer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MaintenanceUnit
            // 
            this.MaintenanceUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaintenanceUnit.FillDisableColor = System.Drawing.Color.White;
            this.MaintenanceUnit.FillReadOnlyColor = System.Drawing.Color.White;
            this.MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaintenanceUnit.Location = new System.Drawing.Point(498, 12);
            this.MaintenanceUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaintenanceUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.MaintenanceUnit.Name = "MaintenanceUnit";
            this.MaintenanceUnit.Padding = new System.Windows.Forms.Padding(5);
            this.MaintenanceUnit.ReadOnly = true;
            this.MaintenanceUnit.ShowText = false;
            this.MaintenanceUnit.Size = new System.Drawing.Size(200, 29);
            this.MaintenanceUnit.TabIndex = 17;
            this.MaintenanceUnit.TabStop = false;
            this.MaintenanceUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceUnit.Watermark = "";
            // 
            // uiLabel_MaintenanceUnit
            // 
            this.uiLabel_MaintenanceUnit.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MaintenanceUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MaintenanceUnit.Location = new System.Drawing.Point(371, 12);
            this.uiLabel_MaintenanceUnit.Name = "uiLabel_MaintenanceUnit";
            this.uiLabel_MaintenanceUnit.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_MaintenanceUnit.TabIndex = 18;
            this.uiLabel_MaintenanceUnit.Text = "維護單位";
            this.uiLabel_MaintenanceUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // StatusString
            // 
            this.Status.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Status.FillDisableColor = System.Drawing.Color.White;
            this.Status.FillReadOnlyColor = System.Drawing.Color.White;
            this.Status.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Status.Location = new System.Drawing.Point(145, 168);
            this.Status.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Status.MinimumSize = new System.Drawing.Size(1, 16);
            this.Status.Name = "StatusString";
            this.Status.Padding = new System.Windows.Forms.Padding(5);
            this.Status.ReadOnly = true;
            this.Status.ShowText = false;
            this.Status.Size = new System.Drawing.Size(200, 29);
            this.Status.TabIndex = 15;
            this.Status.TabStop = false;
            this.Status.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Status.Watermark = "";
            // 
            // uiLabel_Status
            // 
            this.uiLabel_Status.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Status.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Status.Location = new System.Drawing.Point(18, 168);
            this.uiLabel_Status.Name = "uiLabel_Status";
            this.uiLabel_Status.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Status.TabIndex = 16;
            this.uiLabel_Status.Text = "狀態";
            this.uiLabel_Status.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageStarted.FillDisableColor = System.Drawing.Color.White;
            this.OutageStarted.FillReadOnlyColor = System.Drawing.Color.White;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageStarted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageStarted.Location = new System.Drawing.Point(498, 207);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(5);
            this.OutageStarted.ReadOnly = true;
            this.OutageStarted.ShowText = false;
            this.OutageStarted.Size = new System.Drawing.Size(200, 29);
            this.OutageStarted.TabIndex = 21;
            this.OutageStarted.TabStop = false;
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageStarted.Watermark = "";
            // 
            // uiLabel_OutageStarted
            // 
            this.uiLabel_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageStarted.Location = new System.Drawing.Point(371, 207);
            this.uiLabel_OutageStarted.Name = "uiLabel_OutageStarted";
            this.uiLabel_OutageStarted.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OutageStarted.TabIndex = 22;
            this.uiLabel_OutageStarted.Text = "停動開始時間";
            this.uiLabel_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkstationName
            // 
            this.Workstation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Workstation.FillDisableColor = System.Drawing.Color.White;
            this.Workstation.FillReadOnlyColor = System.Drawing.Color.White;
            this.Workstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Workstation.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Workstation.Location = new System.Drawing.Point(145, 285);
            this.Workstation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Workstation.MinimumSize = new System.Drawing.Size(1, 16);
            this.Workstation.Name = "WorkstationName";
            this.Workstation.Padding = new System.Windows.Forms.Padding(5);
            this.Workstation.ReadOnly = true;
            this.Workstation.ShowText = false;
            this.Workstation.Size = new System.Drawing.Size(200, 29);
            this.Workstation.TabIndex = 19;
            this.Workstation.TabStop = false;
            this.Workstation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Workstation.Watermark = "";
            // 
            // uiLabel_WorkStation
            // 
            this.uiLabel_WorkStation.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_WorkStation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_WorkStation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_WorkStation.Location = new System.Drawing.Point(18, 285);
            this.uiLabel_WorkStation.Name = "uiLabel_WorkStation";
            this.uiLabel_WorkStation.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_WorkStation.TabIndex = 20;
            this.uiLabel_WorkStation.Text = "工站";
            this.uiLabel_WorkStation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ModelWorkstation
            // 
            this.Model.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Model.FillDisableColor = System.Drawing.Color.White;
            this.Model.FillReadOnlyColor = System.Drawing.Color.White;
            this.Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Model.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Model.Location = new System.Drawing.Point(145, 246);
            this.Model.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Model.MinimumSize = new System.Drawing.Size(1, 16);
            this.Model.Name = "ModelWorkstation";
            this.Model.Padding = new System.Windows.Forms.Padding(5);
            this.Model.ReadOnly = true;
            this.Model.ShowText = false;
            this.Model.Size = new System.Drawing.Size(200, 29);
            this.Model.TabIndex = 17;
            this.Model.TabStop = false;
            this.Model.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Model.Watermark = "";
            // 
            // uiLabel_Model
            // 
            this.uiLabel_Model.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Model.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Model.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Model.Location = new System.Drawing.Point(18, 246);
            this.uiLabel_Model.Name = "uiLabel_Model";
            this.uiLabel_Model.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Model.TabIndex = 18;
            this.uiLabel_Model.Text = "機種";
            this.uiLabel_Model.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.FillDisableColor = System.Drawing.Color.White;
            this.MachineList.FillReadOnlyColor = System.Drawing.Color.White;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MachineList.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.MachineList.Location = new System.Drawing.Point(145, 207);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ReadOnly = true;
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(200, 29);
            this.MachineList.TabIndex = 15;
            this.MachineList.TabStop = false;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            // 
            // uiLabel_MachineList
            // 
            this.uiLabel_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MachineList.Location = new System.Drawing.Point(18, 207);
            this.uiLabel_MachineList.Name = "uiLabel_MachineList";
            this.uiLabel_MachineList.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_MachineList.TabIndex = 16;
            this.uiLabel_MachineList.Text = "機台編號";
            this.uiLabel_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreationDate
            // 
            this.CreationDate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CreationDate.FillDisableColor = System.Drawing.Color.White;
            this.CreationDate.FillReadOnlyColor = System.Drawing.Color.White;
            this.CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CreationDate.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CreationDate.Location = new System.Drawing.Point(145, 129);
            this.CreationDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CreationDate.MinimumSize = new System.Drawing.Size(1, 16);
            this.CreationDate.Name = "CreationDate";
            this.CreationDate.Padding = new System.Windows.Forms.Padding(5);
            this.CreationDate.ReadOnly = true;
            this.CreationDate.ShowText = false;
            this.CreationDate.Size = new System.Drawing.Size(200, 29);
            this.CreationDate.TabIndex = 12;
            this.CreationDate.TabStop = false;
            this.CreationDate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreationDate.Watermark = "";
            // 
            // uiLabel_CreationDate
            // 
            this.uiLabel_CreationDate.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_CreationDate.Location = new System.Drawing.Point(18, 129);
            this.uiLabel_CreationDate.Name = "uiLabel_CreationDate";
            this.uiLabel_CreationDate.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_CreationDate.TabIndex = 14;
            this.uiLabel_CreationDate.Text = "建檔日期";
            this.uiLabel_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_Creator
            // 
            this.uiLabel_Creator.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Creator.Location = new System.Drawing.Point(18, 90);
            this.uiLabel_Creator.Name = "uiLabel_Creator";
            this.uiLabel_Creator.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_Creator.TabIndex = 13;
            this.uiLabel_Creator.Text = "建檔人員";
            this.uiLabel_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreatorName
            // 
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.FillDisableColor = System.Drawing.Color.White;
            this.Creator.FillReadOnlyColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Creator.Location = new System.Drawing.Point(145, 90);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "CreatorName";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ReadOnly = true;
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(200, 29);
            this.Creator.TabIndex = 11;
            this.Creator.TabStop = false;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // uiLabel_WorkOrderNo
            // 
            this.uiLabel_WorkOrderNo.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_WorkOrderNo.Location = new System.Drawing.Point(18, 51);
            this.uiLabel_WorkOrderNo.Name = "uiLabel_WorkOrderNo";
            this.uiLabel_WorkOrderNo.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_WorkOrderNo.TabIndex = 10;
            this.uiLabel_WorkOrderNo.Text = "維護工單編號";
            this.uiLabel_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.FillDisableColor = System.Drawing.Color.White;
            this.WorkOrderNo.FillReadOnlyColor = System.Drawing.Color.White;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.WorkOrderNo.Location = new System.Drawing.Point(145, 51);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.WorkOrderNo.ReadOnly = true;
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(200, 29);
            this.WorkOrderNo.TabIndex = 9;
            this.WorkOrderNo.TabStop = false;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // uiLabel_OrderNo
            // 
            this.uiLabel_OrderNo.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OrderNo.Location = new System.Drawing.Point(18, 12);
            this.uiLabel_OrderNo.Margin = new System.Windows.Forms.Padding(0);
            this.uiLabel_OrderNo.Name = "uiLabel_OrderNo";
            this.uiLabel_OrderNo.Size = new System.Drawing.Size(120, 29);
            this.uiLabel_OrderNo.TabIndex = 8;
            this.uiLabel_OrderNo.Text = "序號";
            this.uiLabel_OrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OrderNo
            // 
            this.OrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OrderNo.FillDisableColor = System.Drawing.Color.White;
            this.OrderNo.FillReadOnlyColor = System.Drawing.Color.White;
            this.OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OrderNo.Location = new System.Drawing.Point(145, 12);
            this.OrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.OrderNo.ReadOnly = true;
            this.OrderNo.ShowText = false;
            this.OrderNo.Size = new System.Drawing.Size(200, 29);
            this.OrderNo.TabIndex = 7;
            this.OrderNo.TabStop = false;
            this.OrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OrderNo.Watermark = "";
            // 
            // Details
            // 
            this.Details.CanEmpty = true;
            this.Details.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Details.FillReadOnlyColor = System.Drawing.Color.White;
            this.Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Details.Location = new System.Drawing.Point(860, 146);
            this.Details.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Details.MinimumSize = new System.Drawing.Size(1, 16);
            this.Details.Multiline = true;
            this.Details.Name = "Details";
            this.Details.Padding = new System.Windows.Forms.Padding(5);
            this.Details.ReadOnly = true;
            this.Details.ShowText = false;
            this.Details.Size = new System.Drawing.Size(250, 85);
            this.Details.TabIndex = 30;
            this.Details.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.Details.Watermark = "";
            // 
            // uiLabel_Details
            // 
            this.uiLabel_Details.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Details.Location = new System.Drawing.Point(735, 146);
            this.uiLabel_Details.Name = "uiLabel_Details";
            this.uiLabel_Details.Size = new System.Drawing.Size(118, 29);
            this.uiLabel_Details.TabIndex = 31;
            this.uiLabel_Details.Text = "維護內容";
            this.uiLabel_Details.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel_Grid
            // 
            this.panel_Grid.Controls.Add(this.ADGV);
            this.panel_Grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Grid.Location = new System.Drawing.Point(0, 0);
            this.panel_Grid.Name = "panel_Grid";
            this.panel_Grid.Size = new System.Drawing.Size(1259, 298);
            this.panel_Grid.TabIndex = 3;
            // 
            // ADGV
            // 
            this.ADGV.AllowUserToAddRows = false;
            this.ADGV.AllowUserToDeleteRows = false;
            this.ADGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ADGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ADGV.FilterAndSortEnabled = true;
            this.ADGV.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.ADGV.Location = new System.Drawing.Point(0, 0);
            this.ADGV.MaxFilterButtonImageHeight = 23;
            this.ADGV.MultiSelect = false;
            this.ADGV.Name = "ADGV";
            this.ADGV.ReadOnly = true;
            this.ADGV.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ADGV.RowTemplate.Height = 24;
            this.ADGV.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ADGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ADGV.Size = new System.Drawing.Size(1259, 298);
            this.ADGV.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.ADGV.TabIndex = 3;
            this.ADGV.SelectionChanged += new System.EventHandler(this.adgv_SelectionChanged);
            // 
            // MaintiFlowSummary
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.panel_Grid);
            this.Controls.Add(this.uiPanel_Detail);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "MaintiFlowSummary";
            this.Size = new System.Drawing.Size(1259, 714);
            this.Load += new System.EventHandler(this.MaintiFlowSummary_Load);
            this.VisibleChanged += new System.EventHandler(this.MaintiFlowSummary_VisibleChanged);
            this.Leave += new System.EventHandler(this.MaintiFlowSummary_Leave);
            this.uiPanel_Detail.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel_Grid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ADGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UIPanel uiPanel_Detail;
        private Sunny.UI.UITextBox CreationDate;
        private Sunny.UI.UILabel uiLabel_CreationDate;
        private Sunny.UI.UILabel uiLabel_Creator;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UILabel uiLabel_WorkOrderNo;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UILabel uiLabel_OrderNo;
        private Sunny.UI.UITextBox OrderNo;
        private Sunny.UI.UITextBox OutageStarted;
        private Sunny.UI.UILabel uiLabel_OutageStarted;
        private Sunny.UI.UITextBox Workstation;
        private Sunny.UI.UILabel uiLabel_WorkStation;
        private Sunny.UI.UITextBox Model;
        private Sunny.UI.UILabel uiLabel_Model;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UILabel uiLabel_MachineList;
        private Sunny.UI.UITextBox Status;
        private Sunny.UI.UILabel uiLabel_Status;
        private Sunny.UI.UITextBox MaintenanceUnit;
        private Sunny.UI.UILabel uiLabel_MaintenanceUnit;
        private Sunny.UI.UITextBox MaintenanceEngineer;
        private Sunny.UI.UILabel uiLabel_MaintenanceEngineer;
        private Sunny.UI.UITextBox AcceptedTime;
        private Sunny.UI.UILabel uiLabel_AcceptedTime;
        private Sunny.UI.UITextBox IssueCategory;
        private Sunny.UI.UILabel uiLabel_IssueCategory;
        private Sunny.UI.UITextBox IssueDescription;
        private Sunny.UI.UILabel uiLabel_IssueDescription;
        private Sunny.UI.UITextBox Details;
        private Sunny.UI.UILabel uiLabel_Details;
        private Sunny.UI.UITextBox RequestingUnit;
        private Sunny.UI.UILabel uiLabel_RequestingUnit;
        private Sunny.UI.UITextBox RequestingEmployee;
        private Sunny.UI.UILabel uiLabel_RequestingEmployee;
        private Sunny.UI.UITextBox RequestingUnitResponse;
        private Sunny.UI.UILabel uiLabel_RequestingUnitResponse;
        private Sunny.UI.UITextBox RepairDuration;
        private Sunny.UI.UILabel uiLabel_RepairDuration;
        private Sunny.UI.UITextBox RepairCompleted;
        private Sunny.UI.UILabel uiLabel_RepairCompleted;
        private Sunny.UI.UITextBox RepairStarted;
        private Sunny.UI.UILabel uiLabel_RepairStarted;
        private Sunny.UI.UITextBox OutageDuration;
        private Sunny.UI.UILabel uiLabel_OutageDuration;
        private Sunny.UI.UITextBox OutageEnded;
        private Sunny.UI.UILabel uiLabel_OutageEnded;
        private System.Windows.Forms.Panel panel_Grid;
        private Zuby.ADGV.AdvancedDataGridView ADGV;
        private System.Windows.Forms.Panel panel1;
        private Sunny.UI.UISymbolButton uiButton_Delete;
        private Sunny.UI.UISwitch EditModeSwitch;
        private Sunny.UI.UILabel uiLabel_Responsible;
        private Sunny.UI.UITextBox Responsible;
        private Sunny.UI.UITextBox TextBox_FillingTime;
        private Sunny.UI.UILabel Label_FillingTime;
    }
}