﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class MaintiFlowSummary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiPanel_Detail = new Sunny.UI.UIPanel();
            this.adgv = new Zuby.ADGV.AdvancedDataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).BeginInit();
            this.SuspendLayout();
            // 
            // uiPanel_Detail
            // 
            this.uiPanel_Detail.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.uiPanel_Detail.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiPanel_Detail.Location = new System.Drawing.Point(0, 508);
            this.uiPanel_Detail.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel_Detail.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel_Detail.Name = "uiPanel_Detail";
            this.uiPanel_Detail.Size = new System.Drawing.Size(1148, 206);
            this.uiPanel_Detail.TabIndex = 1;
            this.uiPanel_Detail.Text = null;
            this.uiPanel_Detail.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // adgv
            // 
            this.adgv.AllowUserToOrderColumns = true;
            this.adgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adgv.FilterAndSortEnabled = true;
            this.adgv.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.Location = new System.Drawing.Point(0, 0);
            this.adgv.MaxFilterButtonImageHeight = 23;
            this.adgv.MultiSelect = false;
            this.adgv.Name = "adgv";
            this.adgv.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adgv.RowTemplate.Height = 24;
            this.adgv.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.adgv.Size = new System.Drawing.Size(1148, 508);
            this.adgv.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.TabIndex = 2;
            // 
            // MaintiFlowSummary
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.adgv);
            this.Controls.Add(this.uiPanel_Detail);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "MaintiFlowSummary";
            this.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.Size = new System.Drawing.Size(1148, 714);
            this.Text = "MaintiFlowSummary";
            this.Load += new System.EventHandler(this.MaintiFlowSummary_Load);
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UIPanel uiPanel_Detail;
        private Zuby.ADGV.AdvancedDataGridView adgv;
    }
}