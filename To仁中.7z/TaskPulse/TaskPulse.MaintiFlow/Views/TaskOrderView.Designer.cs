﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class TaskOrderView
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_WorkOrderNo = new Sunny.UI.UILabel();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.Label_Creator = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UITextBox();
            this.Label_CreationDate = new Sunny.UI.UILabel();
            this.CreationDate = new Sunny.UI.UITextBox();
            this.MachineList = new Sunny.UI.UITextBox();
            this.Label_MachineList = new Sunny.UI.UILabel();
            this.OutageStarted = new Sunny.UI.UITextBox();
            this.Label_OutageStarted = new Sunny.UI.UILabel();
            this.IssueDescription = new Sunny.UI.UITextBox();
            this.Label_IssueDescription = new Sunny.UI.UILabel();
            this.uiButton_Close = new Sunny.UI.UISymbolButton();
            this.Label_RequestingUnit = new Sunny.UI.UILabel();
            this.RequestingUnit = new Sunny.UI.UITextBox();
            this.SuspendLayout();
            // 
            // Label_WorkOrderNo
            // 
            this.Label_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_WorkOrderNo.Location = new System.Drawing.Point(20, 55);
            this.Label_WorkOrderNo.Name = "Label_WorkOrderNo";
            this.Label_WorkOrderNo.Size = new System.Drawing.Size(83, 29);
            this.Label_WorkOrderNo.TabIndex = 3;
            this.Label_WorkOrderNo.Text = "工單編號";
            this.Label_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.FillDisableColor = System.Drawing.Color.White;
            this.WorkOrderNo.FillReadOnlyColor = System.Drawing.Color.White;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.WorkOrderNo.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.WorkOrderNo.Location = new System.Drawing.Point(110, 55);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.WorkOrderNo.ReadOnly = true;
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(282, 124);
            this.WorkOrderNo.TabIndex = 2;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // Label_Creator
            // 
            this.Label_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Creator.Location = new System.Drawing.Point(20, 228);
            this.Label_Creator.Name = "Label_Creator";
            this.Label_Creator.Size = new System.Drawing.Size(83, 29);
            this.Label_Creator.TabIndex = 5;
            this.Label_Creator.Text = "建檔人員";
            this.Label_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreatorName
            // 
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.FillDisableColor = System.Drawing.Color.White;
            this.Creator.FillReadOnlyColor = System.Drawing.Color.White;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Creator.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.Creator.Location = new System.Drawing.Point(110, 228);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "CreatorName";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ReadOnly = true;
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(282, 29);
            this.Creator.TabIndex = 4;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // Label_CreationDate
            // 
            this.Label_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_CreationDate.Location = new System.Drawing.Point(20, 267);
            this.Label_CreationDate.Name = "Label_CreationDate";
            this.Label_CreationDate.Size = new System.Drawing.Size(83, 29);
            this.Label_CreationDate.TabIndex = 6;
            this.Label_CreationDate.Text = "建檔日期";
            this.Label_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreationDate
            // 
            this.CreationDate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CreationDate.FillDisableColor = System.Drawing.Color.White;
            this.CreationDate.FillReadOnlyColor = System.Drawing.Color.White;
            this.CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CreationDate.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.CreationDate.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.CreationDate.Location = new System.Drawing.Point(110, 267);
            this.CreationDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CreationDate.MinimumSize = new System.Drawing.Size(1, 16);
            this.CreationDate.Name = "CreationDate";
            this.CreationDate.Padding = new System.Windows.Forms.Padding(5);
            this.CreationDate.ReadOnly = true;
            this.CreationDate.ShowText = false;
            this.CreationDate.Size = new System.Drawing.Size(282, 29);
            this.CreationDate.TabIndex = 5;
            this.CreationDate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreationDate.Watermark = "";
            // 
            // MachineList
            // 
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.FillDisableColor = System.Drawing.Color.White;
            this.MachineList.FillReadOnlyColor = System.Drawing.Color.White;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MachineList.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.MachineList.Location = new System.Drawing.Point(110, 306);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ReadOnly = true;
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(282, 29);
            this.MachineList.TabIndex = 7;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            // 
            // Label_MachineList
            // 
            this.Label_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MachineList.Location = new System.Drawing.Point(20, 306);
            this.Label_MachineList.Name = "Label_MachineList";
            this.Label_MachineList.Size = new System.Drawing.Size(83, 29);
            this.Label_MachineList.TabIndex = 8;
            this.Label_MachineList.Text = "機台";
            this.Label_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageStarted
            // 
            this.OutageStarted.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageStarted.FillDisableColor = System.Drawing.Color.White;
            this.OutageStarted.FillReadOnlyColor = System.Drawing.Color.White;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageStarted.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.OutageStarted.Location = new System.Drawing.Point(110, 345);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(5);
            this.OutageStarted.ReadOnly = true;
            this.OutageStarted.ShowText = false;
            this.OutageStarted.Size = new System.Drawing.Size(282, 29);
            this.OutageStarted.TabIndex = 13;
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageStarted.Watermark = "";
            // 
            // Label_OutageStarted
            // 
            this.Label_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageStarted.Location = new System.Drawing.Point(20, 345);
            this.Label_OutageStarted.Name = "Label_OutageStarted";
            this.Label_OutageStarted.Size = new System.Drawing.Size(83, 29);
            this.Label_OutageStarted.TabIndex = 14;
            this.Label_OutageStarted.Text = "停動開始";
            this.Label_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // IssueDescription
            // 
            this.IssueDescription.CanEmpty = true;
            this.IssueDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IssueDescription.FillReadOnlyColor = System.Drawing.Color.White;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.IssueDescription.Location = new System.Drawing.Point(110, 384);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 16);
            this.IssueDescription.Multiline = true;
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(5);
            this.IssueDescription.ReadOnly = true;
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(282, 85);
            this.IssueDescription.TabIndex = 26;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.IssueDescription.Watermark = "";
            // 
            // Label_IssueDescription
            // 
            this.Label_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueDescription.Location = new System.Drawing.Point(22, 384);
            this.Label_IssueDescription.Name = "Label_IssueDescription";
            this.Label_IssueDescription.Size = new System.Drawing.Size(81, 29);
            this.Label_IssueDescription.TabIndex = 27;
            this.Label_IssueDescription.Text = "問題描述";
            this.Label_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiButton_Close
            // 
            this.uiButton_Close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.uiButton_Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiButton_Close.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiButton_Close.Location = new System.Drawing.Point(154, 491);
            this.uiButton_Close.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiButton_Close.Name = "uiButton_Close";
            this.uiButton_Close.Radius = 10;
            this.uiButton_Close.Size = new System.Drawing.Size(110, 35);
            this.uiButton_Close.Symbol = 61453;
            this.uiButton_Close.TabIndex = 28;
            this.uiButton_Close.Text = "關閉";
            this.uiButton_Close.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiButton_Close.Click += new System.EventHandler(this.uiButton_Close_Click);
            // 
            // Label_RequestingUnit
            // 
            this.Label_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RequestingUnit.Location = new System.Drawing.Point(20, 189);
            this.Label_RequestingUnit.Name = "Label_RequestingUnit";
            this.Label_RequestingUnit.Size = new System.Drawing.Size(83, 29);
            this.Label_RequestingUnit.TabIndex = 30;
            this.Label_RequestingUnit.Text = "需求單位";
            this.Label_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RequestingUnitString
            // 
            this.RequestingUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnit.FillDisableColor = System.Drawing.Color.White;
            this.RequestingUnit.FillReadOnlyColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingUnit.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.RequestingUnit.Location = new System.Drawing.Point(110, 189);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnit.Name = "RequestingUnitString";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnit.ReadOnly = true;
            this.RequestingUnit.ShowText = false;
            this.RequestingUnit.Size = new System.Drawing.Size(282, 29);
            this.RequestingUnit.TabIndex = 29;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // TaskOrderView
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(431, 548);
            this.ControlBox = false;
            this.Controls.Add(this.Label_RequestingUnit);
            this.Controls.Add(this.RequestingUnit);
            this.Controls.Add(this.uiButton_Close);
            this.Controls.Add(this.IssueDescription);
            this.Controls.Add(this.Label_IssueDescription);
            this.Controls.Add(this.OutageStarted);
            this.Controls.Add(this.Label_OutageStarted);
            this.Controls.Add(this.MachineList);
            this.Controls.Add(this.Label_MachineList);
            this.Controls.Add(this.CreationDate);
            this.Controls.Add(this.Label_CreationDate);
            this.Controls.Add(this.Label_Creator);
            this.Controls.Add(this.Creator);
            this.Controls.Add(this.Label_WorkOrderNo);
            this.Controls.Add(this.WorkOrderNo);
            this.EscClose = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TaskOrderView";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 784, 674);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UILabel Label_WorkOrderNo;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UILabel Label_Creator;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UILabel Label_CreationDate;
        private Sunny.UI.UITextBox CreationDate;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UILabel Label_MachineList;
        private Sunny.UI.UITextBox OutageStarted;
        private Sunny.UI.UILabel Label_OutageStarted;
        private Sunny.UI.UITextBox IssueDescription;
        private Sunny.UI.UILabel Label_IssueDescription;
        private Sunny.UI.UISymbolButton uiButton_Close;
        private Sunny.UI.UILabel Label_RequestingUnit;
        private Sunny.UI.UITextBox RequestingUnit;
    }
}
