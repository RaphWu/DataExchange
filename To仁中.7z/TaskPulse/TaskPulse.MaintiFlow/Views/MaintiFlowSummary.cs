﻿/*
 * 資料查詢改為非同步。
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;
using Zuby.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UIPage
    {
        private readonly CoreContext _context;
        private readonly MaintiFlowData _flowData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private List<SummaryViewModel> _svm;
        private DataTable _dt;
        private BindingSource _bs = new BindingSource();

        public MaintiFlowSummary(CoreContext coreContext, MaintiFlowData maintiFlowData, FieldName fieldName, FieldTitle fieldTitle)
        {
            InitializeComponent();
            _context = coreContext;
            _flowData = maintiFlowData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            ADGV.SetDoubleBuffered();
            ADGV.MultiSelect = false;
            ADGV.AllowUserToAddRows = false;
            ADGV.AllowUserToDeleteRows = false;
            ADGV.AllowDrop = false;
            ADGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ADGV.RowHeadersWidth = 20;
            AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
            AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

            _dt = new DataTable();
            SwitchEditMode(false);

            StrongReferenceMessenger.Default.Register<MaintiFlowCacheChangedNotification>(this, async (r, m) =>
            {
                await UpdateData();
            });
        }

        private void MaintiFlowSummary_FormClosing(object sender, FormClosingEventArgs e)
        {
            StrongReferenceMessenger.Default.Unregister<MaintiFlowCacheChangedNotification>(this);
        }

        private async void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            ADGV.AutoGenerateColumns = false; // 這行要在UpdateData()之前，不然表格會亂掉
            await UpdateData();

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.OrderNo,
                HeaderText = _fieldTitle.OrderNo,
                ValueType = typeof(int),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.OrderNo], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.WorkOrderNo,
                HeaderText = _fieldTitle.WorkOrderNo,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.WorkOrderNo], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.Creator,
                HeaderText = _fieldTitle.Creator,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.Creator], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.CreationDate,
                HeaderText = _fieldTitle.CreationDate,
                ValueType = typeof(DateTime),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.CreationDate], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.Status,
                HeaderText = _fieldTitle.Status,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.Status], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.MaintenanceUnit,
                HeaderText = _fieldTitle.MaintenanceUnit,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.MaintenanceUnit], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.Engineers,
                HeaderText = _fieldTitle.Engineer,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.Engineers], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.MachineId,
                HeaderText = _fieldTitle.MachineId,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.MachineId], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.Workstation,
                HeaderText = _fieldTitle.Workstation,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.Workstation], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.Model,
                HeaderText = _fieldTitle.Model,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterChecklistEnabled(ADGV.Columns[_fieldName.Model], true);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.RepairDuration,
                HeaderText = _fieldTitle.RepairDuration,
                ValueType = typeof(TimeSpan),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterCustomEnabled(ADGV.Columns[_fieldName.RepairDuration], false);

            ADGV.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = _fieldName.OutageDuration,
                HeaderText = _fieldTitle.OutageDuration,
                ValueType = typeof(TimeSpan),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            ADGV.SetFilterCustomEnabled(ADGV.Columns[_fieldName.OutageDuration], false);

            // TimeSpan的Format須另外設定
            ADGV.CellFormatting += (s, e) =>
            {
                if (ADGV.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                    && e.Value is TimeSpan ts)
                {
                    string days = ts.Days > 0 ? $"{ts.Days}d " : "";
                    e.Value = $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
                    e.FormattingApplied = true;
                }
            };

            // 下方
            OrderNo.DataBindings.Clear();
            OrderNo.DataBindings.Add("Text", _bs, _fieldName.OrderNo);
            uiLabel_OrderNo.Text = _fieldTitle.OrderNo;

            WorkOrderNo.DataBindings.Clear();
            WorkOrderNo.DataBindings.Add("Text", _bs, _fieldName.WorkOrderNo);
            uiLabel_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;

            Creator.DataBindings.Clear();
            Creator.DataBindings.Add("Text", _bs, _fieldName.Creator);
            uiLabel_Creator.Text = _fieldTitle.Creator;

            CreationDate.DataBindings.Clear();
            CreationDate.DataBindings.Add("Text", _bs, _fieldName.CreationDateString);
            uiLabel_CreationDate.Text = _fieldTitle.CreationDate;

            AcceptedTime.DataBindings.Clear();
            AcceptedTime.DataBindings.Add("Text", _bs, _fieldName.AcceptedTimeString);
            uiLabel_AcceptedTime.Text = _fieldTitle.AcceptedTime;

            Status.DataBindings.Clear();
            Status.DataBindings.Add("Text", _bs, _fieldName.Status);
            uiLabel_Status.Text = _fieldTitle.Status;

            MaintenanceUnit.DataBindings.Clear();
            MaintenanceUnit.DataBindings.Add("Text", _bs, _fieldName.MaintenanceUnit);
            uiLabel_MaintenanceUnit.Text = _fieldTitle.MaintenanceUnit;

            MaintenanceEngineer.DataBindings.Clear();
            MaintenanceEngineer.DataBindings.Add("Text", _bs, _fieldName.Engineers);
            uiLabel_MaintenanceEngineer.Text = _fieldTitle.Engineer;

            MachineList.DataBindings.Clear();
            MachineList.DataBindings.Add("Text", _bs, _fieldName.MachineId);
            uiLabel_MachineList.Text = _fieldTitle.Machine;

            Model.DataBindings.Clear();
            Model.DataBindings.Add("Text", _bs, _fieldName.Model);
            uiLabel_Model.Text = _fieldTitle.Model;

            Workstation.DataBindings.Clear();
            Workstation.DataBindings.Add("Text", _bs, _fieldName.Workstation);
            uiLabel_WorkStation.Text = _fieldTitle.Workstation;

            IssueCategory.DataBindings.Clear();
            IssueCategory.DataBindings.Add("Text", _bs, _fieldName.IssueCategory);
            uiLabel_IssueCategory.Text = _fieldTitle.IssueCategory;

            IssueDescription.DataBindings.Clear();
            IssueDescription.DataBindings.Add("Text", _bs, _fieldName.IssueDescription);
            uiLabel_IssueDescription.Text = _fieldTitle.IssueDescription;

            Details.DataBindings.Clear();
            Details.DataBindings.Add("Text", _bs, _fieldName.Details);
            uiLabel_Details.Text = _fieldTitle.Details;

            RequestingUnit.DataBindings.Clear();
            RequestingUnit.DataBindings.Add("Text", _bs, _fieldName.RequestingUnit);
            uiLabel_RequestingUnit.Text = _fieldTitle.RequestingUnit;

            RequestingEmployee.DataBindings.Clear();
            RequestingEmployee.DataBindings.Add("Text", _bs, _fieldName.RequestingEmployeeString);
            uiLabel_RequestingEmployee.Text = _fieldTitle.RequestingEmployee;

            RequestingUnitResponse.DataBindings.Clear();
            RequestingUnitResponse.DataBindings.Add("Text", _bs, _fieldName.Response);
            uiLabel_RequestingUnitResponse.Text = _fieldTitle.Response;

            RepairStarted.DataBindings.Clear();
            RepairStarted.DataBindings.Add("Text", _bs, _fieldName.RepairStartedString);
            uiLabel_RepairStarted.Text = _fieldTitle.RepairStarted;

            RepairCompleted.DataBindings.Clear();
            RepairCompleted.DataBindings.Add("Text", _bs, _fieldName.RepairCompletedString);
            uiLabel_RepairCompleted.Text = _fieldTitle.RepairCompleted;

            RepairDuration.DataBindings.Clear();
            RepairDuration.DataBindings.Add("Text", _bs, _fieldName.RepairDurationString);
            uiLabel_RepairDuration.Text = _fieldTitle.RepairDuration;

            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add("Text", _bs, _fieldName.FillingTimeString);
            uiLabel_OutageDuration.Text = _fieldTitle.FillingTime;

            OutageStarted.DataBindings.Clear();
            OutageStarted.DataBindings.Add("Text", _bs, _fieldName.OutageStartedString);
            uiLabel_OutageStarted.Text = _fieldTitle.OutageStarted;

            OutageEnded.DataBindings.Clear();
            OutageEnded.DataBindings.Add("Text", _bs, _fieldName.OutageEndedString);
            uiLabel_OutageEnded.Text = _fieldTitle.OutageEnded;

            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add("Text", _bs, _fieldName.OutageDurationString);
            uiLabel_OutageDuration.Text = _fieldTitle.OutageDuration;

            Responsible.DataBindings.Clear();
            Responsible.DataBindings.Add("Text", _bs, _fieldName.Responsible);
            uiLabel_Responsible.Text = _fieldTitle.Responsible;
        }

        private async Task UpdateData()
        {
            var taskOrders = await _context.TaskOrders
                .Include(t => t.Machine)
                .Include(t => t.Creator)
                .Include(t => t.Workstation.Model)
                .Include(t => t.MaintenanceUnit)
                .Include(t => t.RequestingUnit)
                .Include(t => t.IssueCategory)
                .OrderByDescending(u => u.OrderNo)
                .ToListAsync();

            _svm = taskOrders.Select(u => new SummaryViewModel
            {
                WorkOrderNo = u.WorkOrderNo,
                Status = u.Status.GetDescription(),
                MachineId = u.Machine?.MachineId ?? string.Empty,
                ModelName = u.Workstation?.Model?.ModelName ?? string.Empty,
                Workstation = u.Workstation?.WorkstationName ?? string.Empty,
                Creator = u.Creator?.Name ?? string.Empty,
                CreationDate = u.CreationDate,
                CreationDateString = u.CreationDateString,

                MaintenanceUnit = u.MaintenanceUnit?.UnitName ?? string.Empty,
                Engineers = u.Engineers != null && u.Engineers.Any()
                    ? string.Join(", ", u.Engineers.Select(emp => emp.Name))
                    : string.Empty,
                AcceptedTime = u.AcceptedTime,
                AcceptedTimeString = u.AcceptedTimeString,
                IssueCategory = u.IssueCategory?.CategoryName ?? string.Empty,
                IssueDescription = u.IssueDescription,
                Details = u.Details,
                RepairStarted = u.RepairStarted,
                RepairStartedString = u.RepairStartedString,
                RepairCompleted = u.RepairCompleted,
                RepairCompletedString = u.RepairCompletedString,
                RepairDuration = u.RepairDuration,
                RepairDurationString = u.RepairDurationString,
                FillingTimeString = u.FillingTimeString,

                RequestingUnit = u.RequestingUnit?.UnitName ?? string.Empty,
                RequestingEmployee = u.RequestingEmployee != null
                    ? $"{(u.RequestingEmployee.Title != null ? u.RequestingEmployee.Title + ", " : string.Empty)}{u.RequestingEmployee.Name}"
                    : string.Empty,
                RequestingEmployeeString = u.RequestingEmployeeString,
                Response = u.Response,
                OutageStarted = u.OutageStarted,
                OutageStartedString = u.OutageStartedString,
                OutageEnded = u.OutageEnded,
                OutageEndedString = u.OutageEndedString,
                OutageDuration = u.OutageDuration,
                OutageDurationString = u.OutageDurationString,

                Responsible = u.Responsible,
                OrderNo = u.OrderNo
            }).ToList();

            _bs.DataSource = _svm;
            _dt = _svm.ToDataTable();
            ADGV.DataSource = _dt;
        }

        /********************
         * 編輯模式
         ********************/
        private void SwitchEditMode(bool editMode)
        {
            EditModeSwitch.Active = editMode;
            ADGV.SelectionMode = editMode ? DataGridViewSelectionMode.CellSelect : DataGridViewSelectionMode.FullRowSelect;
            ADGV.ReadOnly = !editMode;
            ADGV.Refresh();
        }

        private void EditModeSwitch_ValueChanged(object sender, bool value)
        {
            SwitchEditMode(value);
        }

        /********************
         * ADGV
         ********************/
        private void adgv_SelectionChanged(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                int selectedOrderNo = Convert.ToInt32(drv["OrderNo"]);
                int index = _svm.FindIndex(x => x.OrderNo == selectedOrderNo);
                if (index >= 0)
                    _bs.Position = index;
            }
        }

        private void uiButton_Edit_Click(object sender, EventArgs e)
        {
        }

        private void uiButton_Delete_Click(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                string selectedKey = drv["WorkOrderNo"].ToString();
                var item = _svm.FirstOrDefault(x => x.WorkOrderNo == selectedKey);
                if (item != null)
                {
                    string msg = $"確定刪除這筆資料嗎？\n\n{_fieldTitle.OrderNo}: {item.OrderNo}\n{_fieldTitle.WorkOrderNo}: {item.WorkOrderNo}\n{_fieldTitle.Creator}: {item.Creator}\n{_fieldTitle.Model}: {item.ModelName}";
                    if (MessageBox.Show(msg, "刪除確認",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Warning,
                                        MessageBoxDefaultButton.Button2)
                        == DialogResult.Yes)
                    {
                        var entity = _context.TaskOrders.FirstOrDefault(x => x.WorkOrderNo == item.WorkOrderNo);
                        if (entity != null)
                        {
                            try
                            {
                                _context.TaskOrders.Remove(entity);
                                _context.SaveChanges();

                                _svm.Remove(item);

                                foreach (DataRow row in _dt.Rows)
                                {
                                    if (row["WorkOrderNo"].ToString() == selectedKey)
                                    {
                                        _dt.Rows.Remove(row);
                                        break;
                                    }
                                }

                                _bs.ResetBindings(false);

                                MessageBox.Show($"{_fieldTitle.WorkOrderNo}: {item.WorkOrderNo} 已刪除！");
                            }
                            //catch (DbUpdateConcurrencyException duce)
                            //{
                            //    emsg = "資料庫命令不會影響預期的資料列數目。";
                            //}
                            //catch (DbUpdateException due)
                            //{
                            //    emsg = "傳送更新至資料庫時發生錯誤。";
                            //}
                            //catch (DbEntityValidationException deve)
                            //{
                            //    emsg = "儲存已中止，因為實體屬性值的驗證失敗。";
                            //}
                            //catch (NotSupportedException nse)
                            //{
                            //    emsg = "嘗試使用不支援的行為，例如在相同的內容實例上同時執行多個非同步命令。";
                            //}
                            //catch (ObjectDisposedException ode)
                            //{
                            //    emsg = "內容或連線已處置。";
                            //}
                            //catch (InvalidOperationException ioe)
                            //{
                            //    emsg = "嘗試在將命令傳送至資料庫之前或之後，嘗試處理內容中的實體時發生一些錯誤。";
                            //}
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "資料庫變更失敗");
                            }
                        }
                    }
                }
            }
        }
    }
}
