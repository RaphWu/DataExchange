﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contract;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_MaintiWork : UIForm
    {
        #region fields

        private readonly ILifetimeScope _rootScope;

        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private BindingList<TaskOrderViewModel> _editBuffs;
        private TaskOrderViewModel _editBuff = null;
        private BindingSource _bs;

        #endregion fields

        public List<TaskOrder> Orders { get; set; } = new List<TaskOrder>();
        public List<int> EngineerList { get; set; } = new List<int>();

        public FT_MaintiWork(ILifetimeScope lifetimeScope,
                             CoreContext coreContext,
                             ICore core,
                             MaintiFlowData maintiFlowData,
                             CoreData coreData,
                             FieldName fieldName,
                             FieldTitle fieldTitle)
        {
            InitializeComponent();
            _rootScope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            CommonStyles.SetButton(Button_Save);
            CommonStyles.SetButton(Button_Cancel, accent: true);

            ListBox_Orders.HoverColor = CommonStyles.HoverColor;

            //ModelWorkstation.ButtonFillColor = CommonStyles.BackColor;
            //ModelWorkstation.ButtonFillHoverColor = CommonStyles.HoverColor;
            //WorkstationName.ButtonFillColor = CommonStyles.BackColor;
            //WorkstationName.ButtonFillHoverColor = CommonStyles.HoverColor;
        }

        private void FT_MaintiWork_Load(object sender, System.EventArgs e)
        {
            Engineers.Nodes.Clear();
            foreach (var engineer in _coreData.Engineers)
            {
                TreeNode tn = new TreeNode()
                {
                    Name = engineer.Name,
                    Text = engineer.Name,
                    Tag = new SelectorInfo()
                    {
                        Id = engineer.Id,
                        Name = engineer.Name,
                    },
                };
                Engineers.Nodes.Add(tn);
            }

            MaintenanceUnit.DataSource = _context.MaintenanceUnits
                .Select(m => new ListViewModel()
                {
                    NullableId = m.Id,
                    Name = m.UnitName,
                })
                .ToList();
            MaintenanceUnit.DisplayMember = "Name";
            MaintenanceUnit.ValueMember = "NullableId";

            IssueCategory.DataSource = _context.IssueCategories
             .Select(m => new ListViewModel()
             {
                 NullableId = m.Id,
                 Name = m.CategoryName,
             })
             .ToList();
            IssueCategory.DisplayMember = "Name";
            IssueCategory.ValueMember = "NullableId";

            int tabIndex = 0;
            Label_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;
            WorkOrderNo.TabIndex = ++tabIndex;
            WorkOrderNo.ReadOnly = true;

            Label_Creator.Text = _fieldTitle.Creator;
            Creator.TabIndex = ++tabIndex;
            Creator.ReadOnly = true;

            Label_CreationDate.Text = _fieldTitle.CreationDate;
            CreationDate.TabIndex = ++tabIndex;
            CreationDate.ReadOnly = true;

            Label_MachineList.Text = _fieldTitle.Machine;
            MachineList.TabIndex = ++tabIndex;
            MachineList.ReadOnly = true;

            Label_ModelWorkstation.Text = _fieldTitle.ModelWorkstationName;
            ModelWorkstation.TabIndex = ++tabIndex;

            Label_AcceptedTime.Text = _fieldTitle.AcceptedTime;
            AcceptedTime.TabIndex = ++tabIndex;
            AcceptedTime.ReadOnly = true;

            Label_RequestingUnit.Text = _fieldTitle.RequestingUnit;
            RequestingUnit.TabIndex = ++tabIndex;
            RequestingUnit.ReadOnly = true;

            Label_MaintenanceUnit.Text = _fieldTitle.MaintenanceUnit;
            MaintenanceUnit.TabIndex = ++tabIndex;

            Label_Engineers.Text = _fieldTitle.Engineer;
            Engineers.TabIndex = ++tabIndex;

            Label_IssueCategory.Text = _fieldTitle.IssueCategory;
            IssueCategory.TabIndex = ++tabIndex;

            Label_IssueDescription.Text = _fieldTitle.IssueDescription;
            IssueDescription.TabIndex = ++tabIndex;

            Label_Details.Text = _fieldTitle.Details;
            Details.TabIndex = ++tabIndex;

            Label_RepairStarted.Text = _fieldTitle.RepairStarted;
            RepairStarted.TabIndex = ++tabIndex;

            Label_RepairCompleted.Text = _fieldTitle.RepairCompleted;
            RepairCompleted.TabIndex = ++tabIndex;

            Label_OutageStarted.Text = _fieldTitle.OutageStarted;
            OutageStarted.TabIndex = ++tabIndex;
            OutageStarted.ReadOnly = true;

            Label_OutageEnded.Text = _fieldTitle.OutageEnded;
            OutageEnded.TabIndex = ++tabIndex;

            Label_RepairDuration.Text = _fieldTitle.RepairDuration;
            RepairDuration.TabIndex = ++tabIndex;
            RepairDuration.ReadOnly = true;

            Label_OutageDuration.Text = _fieldTitle.OutageDuration;
            OutageDuration.TabIndex = ++tabIndex;
            OutageDuration.ReadOnly = true;







            LoadData();

            // Binding
            //int tabIndex = 0;
            //Label_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;
            //WorkOrderNo.DataBindings.Clear();
            //WorkOrderNo.DataBindings.Add("Text", _bs, _fieldName.WorkOrderNo);
            //WorkOrderNo.TabIndex = ++tabIndex;
            //WorkOrderNo.ReadOnly = true;

            //Label_Creator.Text = _fieldTitle.Creator;
            //Creator.DataBindings.Clear();
            //Creator.DataBindings.Add("Text", _bs, _fieldName.CreatorHalfName);
            //Creator.TabIndex = ++tabIndex;
            //Creator.ReadOnly = true;

            //Label_CreationDate.Text = _fieldTitle.CreationDate;
            //CreationDate.DataBindings.Clear();
            //CreationDate.DataBindings.Add("Text", _bs, _fieldName.CreationDateString);
            //CreationDate.TabIndex = ++tabIndex;
            //CreationDate.ReadOnly = true;

            //Label_MachineList.Text = _fieldTitle.Machine;
            //MachineList.DataBindings.Clear();
            //MachineList.DataBindings.Add("Text", _bs, _fieldName.FullMachineName);
            //MachineList.TabIndex = ++tabIndex;
            //MachineList.ReadOnly = true;

            //Label_ModelWorkstation.Text = _fieldTitle.ModelWorkstationName;
            //ModelWorkstation.DataBindings.Clear();
            //ModelWorkstation.DataBindings.Add("Text", _bs, _fieldName.ModelWorkstationName);
            //ModelWorkstation.TabIndex = ++tabIndex;

            //Label_AcceptedTime.Text = _fieldTitle.AcceptedTime;
            //AcceptedTime.DataBindings.Clear();
            //AcceptedTime.DataBindings.Add("Text", _bs, _fieldName.AcceptedTimeString);
            //AcceptedTime.TabIndex = ++tabIndex;
            //AcceptedTime.ReadOnly = true;

            //Label_RequestingUnit.Text = _fieldTitle.RequestingUnit;
            //RequestingUnit.DataBindings.Clear();
            //RequestingUnit.DataBindings.Add("Text", _bs, _fieldName.RequestingUnitString);
            //RequestingUnit.TabIndex = ++tabIndex;
            //RequestingUnit.ReadOnly = true;

            ///*****/

            //Label_MaintenanceUnit.Text = _fieldTitle.MaintenanceUnit;
            //MaintenanceUnit.DataBindings.Clear();
            //MaintenanceUnit.DataBindings.Add("SelectedValue", _bs, _fieldName.MaintenanceUnitId);
            //MaintenanceUnit.TabIndex = ++tabIndex;

            //Label_Engineers.Text = _fieldTitle.Engineer;
            //Engineers.DataBindings.Clear();
            //Engineers.DataBindings.Add("Text", _bs, _fieldName.EngineerString);
            //Engineers.TabIndex = ++tabIndex;

            //Label_IssueCategory.Text = _fieldTitle.IssueCategory;
            //IssueCategory.DataBindings.Clear();
            //IssueCategory.DataBindings.Add("SelectedValue", _bs, _fieldName.IssueCategoryId);
            //IssueCategory.TabIndex = ++tabIndex;

            //Label_IssueDescription.Text = _fieldTitle.IssueDescription;
            //IssueDescription.DataBindings.Clear();
            //IssueDescription.DataBindings.Add("Text", _bs, _fieldName.IssueDescription);
            //IssueDescription.TabIndex = ++tabIndex;

            //Label_Details.Text = _fieldTitle.Details;
            //Details.DataBindings.Clear();
            //Details.DataBindings.Add("Text", _bs, _fieldName.Details);
            //Details.TabIndex = ++tabIndex;

            //Label_RepairStarted.Text = _fieldTitle.RepairStarted;
            //RepairStarted.DataBindings.Clear();
            //RepairStarted.DataBindings.Add("Text", _bs, _fieldName.RepairStartedString);
            //RepairStarted.TabIndex = ++tabIndex;

            //Label_RepairCompleted.Text = _fieldTitle.RepairCompleted;
            //RepairCompleted.DataBindings.Clear();
            //RepairCompleted.DataBindings.Add("Text", _bs, _fieldName.RepairCompletedString);
            //RepairCompleted.TabIndex = ++tabIndex;

            //Label_OutageStarted.Text = _fieldTitle.OutageStarted;
            //OutageStarted.DataBindings.Clear();
            //OutageStarted.DataBindings.Add("Text", _bs, _fieldName.OutageStartedString);
            //OutageStarted.TabIndex = ++tabIndex;
            //OutageStarted.ReadOnly = true;

            //Label_OutageEnded.Text = _fieldTitle.OutageEnded;
            //OutageEnded.DataBindings.Clear();
            //OutageEnded.DataBindings.Add("Text", _bs, _fieldName.OutageEndedString);
            //OutageEnded.TabIndex = ++tabIndex;

            //Label_RepairDuration.Text = _fieldTitle.RepairDuration;
            //RepairDuration.DataBindings.Clear();
            //RepairDuration.DataBindings.Add("Text", _bs, _fieldName.RepairDurationString);
            //RepairDuration.TabIndex = ++tabIndex;
            //RepairDuration.ReadOnly = true;

            //Label_OutageDuration.Text = _fieldTitle.OutageDuration;
            //OutageDuration.DataBindings.Clear();
            //OutageDuration.DataBindings.Add("Text", _bs, _fieldName.OutageDurationString);
            //OutageDuration.TabIndex = ++tabIndex;
            //OutageDuration.ReadOnly = true;
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button_Save_Click(object sender, EventArgs ea)
        {
            for (int idx = 0; idx < _editBuffs.Count; idx++)
            {
                //    var buff = _editBuffs[idx];
                //    var order = Orders[idx];

                //    if (string.IsNullOrWhiteSpace(ModelWorkstation.Text))
                //        _editBuff.WorkstationName = null;
                //    else
                //    {
                //        var mw = ModelWorkstation.Text
                //            .Split(new[] { '»' }, StringSplitOptions.RemoveEmptyEntries)
                //            .Select(x => x.Trim())
                //            .ToArray();
                //        if (mw.Count() == 2)
                //            _editBuff.WorkstationId = _coreData.Workstations
                //                .FirstOrDefault(w => w.WorkstationName == mw[1]).Id;
                //    }

                //    var omu = _flowData.TaskOrders
                //        .FirstOrDefault(i => i.MaintenanceUnitId == (int)MaintenanceUnit.SelectedValue)
                //        .MaintenanceUnit;
                //    _editBuff.MaintenanceUnit = omu;

                //    var eNames = EngineerString.Text.Split(';').Select(er => er.Trim()).ToList();
                //    _editBuff.EngineerString = new List<Employee>();
                //    foreach (var eName in eNames)
                //    {
                //        var oer = _coreData.Employees.FirstOrDefault(er => er.Name == eName);
                //        if (oer != null)
                //            _editBuff.EngineerString.Add(oer);
                //    }

                //    _editBuff.IssueCategoryId = (int?)IssueCategoryString.SelectedValue;
                //    _editBuff.IssueDescription = IssueDescription.Text;
                //    _editBuff.Details = Details.Text;
                //    _editBuff.RepairStartedString = RepairStarted.Text;
                //    _editBuff.RepairCompletedString = RepairCompleted.Text;
                //    _editBuff.OutageEndedString = OutageEnded.Text;


                //    order.WorkOrderNo = buff.WorkOrderNo;
                //    order.StatusString = buff.StatusString;
                //    order.CreatorName = buff.CreatorName;
                //    order.CreationDate = buff.CreationDate;
                //    order.IssueCategoryString = buff.IssueCategoryString;
                //    order.IssueDescription = buff.IssueDescription;
                //    order.Details = buff.Details;
                //    order.RepairStarted = buff.RepairStarted;
                //    order.RepairCompleted = buff.RepairCompleted;
                //    order.RepairDuration = buff.RepairDuration;
                //    order.AcceptedTime = buff.AcceptedTime;
                //    order.Response = buff.Response;
                //    order.OutageStarted = buff.OutageStarted;
                //    order.OutageEnded = buff.OutageEnded;
                //    order.OutageDuration = buff.OutageDuration;
                //    order.OrderNo = buff.OrderNo;

                //    // FK
                //    order.MachineId = buff.MachineId;
                //    order.WorkstationId = buff.WorkstationId;
                //    order.RequestingUnitId = buff.RequestingUnitId;
                //    order.MaintenanceUnitId = buff.MaintenanceUnitId;

                //    // 多對多 - EngineerString
                //    order.EngineerString.Clear();
                //    foreach (var id in EngineerList)
                //    {
                //        var eng = _context.Employees.Find(id); // Attach 確保是在同一個 DbContext
                //        if (eng != null)
                //            order.EngineerString.Add(eng);
                //    }
                //}
                //_context.SaveChanges();
                //this.Close();
            }
        }

        /********************
         * 
         ********************/
        public void Initialize()
        {
            //_editBuffs = new BindingList<TaskOrderViewModel>();
            //_bs = new BindingSource();
        }

        private void LoadData()
        {
            _editBuffs = new BindingList<TaskOrderViewModel>();
            _bs = new BindingSource();

            // Load ViewModel
            foreach (var rec in Orders)
            {
                _editBuffs.Add(new TaskOrderViewModel()
                {
                    Id = rec.Id,
                    WorkOrderNo = rec.WorkOrderNo,
                    Status = rec.Status,
                    FullMachineName = rec.FullMachineName,
                    WorkstationId = rec.WorkstationId,
                    ModelWorkstationName = rec.ModelWorkstationName,
                    CreatorHalfName = rec.CreatorHalfName,
                    CreationDate = rec.CreationDate,
                    MaintenanceUnitString = rec.MaintenanceUnitString,
                    EngineerString = rec.EngineerString + (rec.Engineers != null ? ";" : ""),
                    AcceptedTime = rec.AcceptedTime,
                    IssueCategoryString = rec.IssueCategoryString,
                    IssueDescription = rec.IssueDescription,
                    Details = rec.Details,
                    RepairStartedString = rec.RepairStartedString,
                    RepairCompletedString = rec.RepairCompletedString,
                    RepairDuration = rec.RepairDuration,
                    RequestingUnitId = rec.RequestingUnitId,
                    RequestingEmployeeId = rec.RequestingEmployeeId,
                    Response = rec.Response,
                    OutageStartedString = rec.OutageStartedString,
                    OutageEndedString = rec.OutageEndedString,
                    OutageDuration = rec.OutageDuration,
                    OrderNo = rec.OrderNo,
                });
            }

            ListBox_Orders.SelectedIndexChanged -= ListBoxOrders_SelectedIndexChanged;
            ListBox_Orders.DataSource = Orders.Select(t => t.WorkOrderNo).ToList();
            _bs.DataSource = _editBuffs;
            ListBox_Orders.SelectedIndexChanged += ListBoxOrders_SelectedIndexChanged;
        }

        private void ListBoxOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_editBuff != null)
            {
                // 儲存舊值
                _editBuff.ModelWorkstationName = ModelWorkstation.Text;
                _editBuff.MaintenanceUnitId = (int?)MaintenanceUnit.SelectedValue;
                _editBuff.EngineerString = Engineers.Text;
                _editBuff.IssueCategoryId = (int?)IssueCategory.SelectedValue;
                _editBuff.IssueDescription = IssueDescription.Text;
                _editBuff.Details = Details.Text;
                _editBuff.RepairStartedString = RepairStarted.Text;
                _editBuff.RepairCompletedString = RepairCompleted.Text;
                _editBuff.OutageEndedString = OutageEnded.Text;
            }

            // 切換buff
            _editBuff = _editBuffs[ListBox_Orders.SelectedIndex];
            _bs.Position = ListBox_Orders.SelectedIndex;

            // 讀取新值
            WorkOrderNo.Text = _editBuff.WorkOrderNo;
            Creator.Text = _editBuff.CreatorHalfName;
            CreationDate.Text = _editBuff.CreationDateString;
            MachineList.Text = _editBuff.FullMachineName;
            ModelWorkstation.Text = _editBuff.ModelWorkstationName;
            AcceptedTime.Text = _editBuff.AcceptedTimeString;
            RequestingUnit.Text = _editBuff.RequestingUnitString;
            MaintenanceUnit.SelectedValue = _editBuff.MaintenanceUnitId ?? 0;
            IssueCategory.SelectedValue = _editBuff.IssueCategoryId ?? 0;
            IssueDescription.Text = _editBuff.IssueDescription;
            Details.Text = _editBuff.Details;
            RepairStarted.Text = _editBuff.RepairStartedString;
            RepairCompleted.Text = _editBuff.RepairCompletedString;
            OutageStarted.Text = _editBuff.OutageStartedString;
            OutageEnded.Text = _editBuff.OutageEndedString;
            RepairDuration.Text = _editBuff.RepairDurationString;
            OutageDuration.Text = _editBuff.OutageDurationString;

            Engineers.Text = _editBuff.EngineerString;
            var emps = _editBuff.EngineerString
               .Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
               .Select(n => n.Trim())
               .Where(n => !string.IsNullOrEmpty(n))
               .ToList();
            foreach (TreeNode node in Engineers.Nodes)
                node.Checked = emps.Contains(node.Text);
        }

        #region 按鍵行為

        /********************
         * 按鍵行為
         ********************/
        private void ModelWorkstation_ButtonClick(object sender, EventArgs e)
        {
            using (var fls = _rootScope.Resolve<FlowLayoutSelector>())
            {
                fls.HideTabHeaders = false;
                fls.ShowTreeView = true;
                fls.Title = $"請選擇{_fieldTitle.Model}";
                fls.TreeViewCaption = "機種";
                fls.MultiSelection = false;
                fls.TabPageCache = _coreData.ModelWsTabPageCache;
                fls.DefaultChecked = new List<string>() { _editBuff.ModelWorkstationName };
                fls.Initialize();

                if (fls.ShowDialog() == DialogResult.OK)
                {
                    if (fls.ResultList.Count > 0)
                    {
                        SelectorInfo info = fls.ResultList[0];
                        int idx = ListBox_Orders.SelectedIndex;
                        var ws = _core.GetWorkstation(info.Id);
                        _editBuffs[idx].WorkstationId = ws.Id;
                        _editBuffs[idx].Workstation = ws;
                        _editBuffs[idx].Workstation.ModelId = ws != null && ws.ModelId != null
                            ? (int?)_core.GetModel((int)ws.ModelId).Id
                            : null;

                        var showText = new string[2];
                        showText[0] = info.Category;
                        showText[1] = info.Name;
                        ModelWorkstation.Text = string.Join(" » ", showText);
                    }
                }
            }
        }

        private void MaintenanceUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_editBuff == null)
                return;

            if (MaintenanceUnit.SelectedItem is ListViewModel select)
                _editBuff.MaintenanceUnitId = select.Id;
        }

        private void Engineers_NodesSelected(object sender, TreeNodeCollection nodes)
        {
            if (_editBuff == null)
                return;

            EngineerList.Clear();
            for (int i = 0; i < nodes.Count; i++)
            {
                var node = nodes[i];
                if (node.Checked)
                    EngineerList.Add(((SelectorInfo)node.Tag).Id);
            }
        }

        private void RepairStarted_TextChanged(object sender, EventArgs e)
        {
            if (_editBuff != null)
            {
                if (DateTime.TryParse(RepairStarted.Text, out DateTime dt))
                    _editBuff.RepairStarted = dt;

                if (_editBuff.RepairCompleted != null && _editBuff.RepairStarted != null)
                    RepairDuration.Text = _editBuff.RepairDurationString;
                else
                    _editBuff.RepairDuration = TimeSpan.Zero;
            }
        }

        private void RepairCompleted_TextChanged(object sender, EventArgs e)
        {
            if (_editBuff != null)
            {
                if (DateTime.TryParse(RepairCompleted.Text, out DateTime dt))
                    _editBuff.RepairCompleted = dt;

                if (_editBuff.RepairCompleted != null && _editBuff.RepairStarted != null)
                    RepairDuration.Text = _editBuff.RepairDurationString;
                else
                    _editBuff.RepairDuration = TimeSpan.Zero;
            }
        }

        private void OutageStarted_TextChanged(object sender, EventArgs e)
        {
            if (_editBuff != null)
            {
                if (DateTime.TryParse(OutageStarted.Text, out DateTime dt))
                    _editBuff.OutageStarted = dt;

                if (_editBuff.OutageEnded != null && _editBuff.OutageStarted != null)
                    OutageDuration.Text = _editBuff.OutageDurationString;
                else
                    _editBuff.OutageDuration = TimeSpan.Zero;
            }
        }

        private void OutageEnded_TextChanged(object sender, EventArgs e)
        {
            if (_editBuff != null)
            {
                if (DateTime.TryParse(OutageEnded.Text, out DateTime dt))
                    _editBuff.OutageEnded = dt;

                if (_editBuff.OutageEnded != null && _editBuff.OutageStarted != null)
                    OutageDuration.Text = _editBuff.OutageDurationString;
                else
                    _editBuff.OutageDuration = TimeSpan.Zero;
            }
        }

        #endregion 按鍵行為
    }
}
