﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Models;
using Sunny.UI;
using Sunny.UI.Win32;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class FT_MaintiWork : UIForm
    {
        private readonly CoreContext _context;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly FlowLayoutSelector _flowLayoutSelector;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private BindingList<TaskOrder> _editBuffs;
        private TaskOrder _editBuff = null;
        private BindingSource _bs;

        public List<TaskOrder> Orders { get; set; } = new List<TaskOrder>();
        public List<int> EngineerList { get; set; } = new List<int>();

        public FT_MaintiWork(CoreContext coreContext,
                             MaintiFlowData maintiFlowData,
                             CoreData coreData,
                             FlowLayoutSelector flowLayoutSelector,
                             FieldName fieldName,
                             FieldTitle fieldTitle)
        {
            InitializeComponent();
            _context = coreContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _flowLayoutSelector = flowLayoutSelector;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            CommonStyles.SetButton(Button_Save);
            CommonStyles.SetButton(Button_Cancel, accent: true);

            ListBox_Orders.HoverColor = CommonStyles.HoverColor;

            //Model.ButtonFillColor = CommonStyles.BackColor;
            //Model.ButtonFillHoverColor = CommonStyles.HoverColor;
            //Workstation.ButtonFillColor = CommonStyles.BackColor;
            //Workstation.ButtonFillHoverColor = CommonStyles.HoverColor;
        }

        /********************
         * Form
         ********************/
        private void FT_MaintiWork_Load(object sender, System.EventArgs e)
        {
            LoadData();
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button_Save_Click(object sender, EventArgs ea)
        {
            for (int idx = 0; idx < _editBuffs.Count; idx++)
            {
                var edit = _editBuffs[idx];
                var order = Orders[idx];

                order.WorkOrderNo = edit.WorkOrderNo;
                order.Status = edit.Status;
                order.Creator = edit.Creator;
                order.CreationDate = edit.CreationDate;
                order.IssueCategory = edit.IssueCategory;
                order.IssueDescription = edit.IssueDescription;
                order.Details = edit.Details;
                order.RepairStarted = edit.RepairStarted;
                order.RepairCompleted = edit.RepairCompleted;
                order.RepairDuration = edit.RepairDuration;
                order.AcceptedTime = edit.AcceptedTime;
                order.Response = edit.Response;
                order.OutageStarted = edit.OutageStarted;
                order.OutageEnded = edit.OutageEnded;
                order.OutageDuration = edit.OutageDuration;
                order.OrderNo = edit.OrderNo;

                // FK
                order.MachineId = edit.MachineId;
                order.WorkstationId = edit.WorkstationId;
                order.RequestingUnitId = edit.RequestingUnitId;
                order.MaintenanceUnitId = edit.MaintenanceUnitId;

                // 多對多 - Engineers
                order.Engineers.Clear();
                foreach (var id in EngineerList)
                {
                    var eng = _context.Employees.Find(id); // Attach 確保是在同一個 DbContext
                    if (eng != null)
                        order.Engineers.Add(eng);
                }
            }
            _context.SaveChanges();
            this.Close();
        }

        /********************
         * 
         ********************/
        public void Initialize()
        {
            _bs = new BindingSource();
            _editBuffs = new BindingList<TaskOrder>();
        }

        private void LoadData()
        {
            foreach (var rec in Orders)
            {
                _editBuffs.Add(new TaskOrder()
                {
                    Id = rec.Id,
                    WorkOrderNo = rec.WorkOrderNo,
                    Status = rec.Status,
                    MachineId = rec.MachineId,
                    Machine = _coreData.Machines.FirstOrDefault(m => m.Id == rec.MachineId),
                    Workstation = rec.Workstation,
                    WorkstationId = rec.WorkstationId,
                    Creator = rec.Creator,
                    CreatorId = rec.CreatorId,
                    CreationDate = rec.CreationDate,
                    MaintenanceUnit = rec.MaintenanceUnit,
                    MaintenanceUnitId = rec.MaintenanceUnitId,
                    Engineers = rec.Engineers,
                    AcceptedTime = rec.AcceptedTime,
                    IssueCategory = rec.IssueCategory,
                    IssueCategoryId = rec.IssueCategoryId,
                    IssueDescription = rec.IssueDescription,
                    Details = rec.Details,
                    RepairStarted = rec.RepairStarted,
                    RepairCompleted = rec.RepairCompleted,
                    RepairDuration = rec.RepairDuration,
                    RequestingUnit = rec.RequestingUnit,
                    RequestingUnitId = rec.RequestingUnitId,
                    RequestingEmployee = rec.RequestingEmployee,
                    RequestingEmployeeId = rec.RequestingEmployeeId,
                    Response = rec.Response,
                    OutageStarted = rec.OutageStarted,
                    OutageEnded = rec.OutageEnded,
                    OutageDuration = rec.OutageDuration,
                    OrderNo = rec.OrderNo,
                });
            }
            int tabIndex = 0;

            ListBox_Orders.DataSource = Orders.Select(t => t.WorkOrderNo).ToList();
            _bs.DataSource = _editBuffs;

            WorkOrderNo.DataBindings.Clear();
            WorkOrderNo.DataBindings.Add("Text", _bs, _fieldName.WorkOrderNo);
            WorkOrderNo.ReadOnly = true;
            WorkOrderNo.TabIndex = ++tabIndex;
            Label_WorkOrderNo.Text = _fieldTitle.WorkOrderNo;

            Creator.DataBindings.Clear();
            Creator.DataBindings.Add("Text", _bs, _fieldName.CreatorHalfName);
            Creator.ReadOnly = true;
            Creator.TabIndex = ++tabIndex;
            Label_Creator.Text = _fieldTitle.Creator;

            CreationDate.DataBindings.Clear();
            CreationDate.DataBindings.Add("Text", _bs, _fieldName.CreationDateString);
            CreationDate.ReadOnly = true;
            CreationDate.TabIndex = ++tabIndex;
            Label_CreationDate.Text = _fieldTitle.CreationDate;

            MachineList.DataBindings.Clear();
            MachineList.DataBindings.Add("Text", _bs, _fieldName.FullMachineName);
            MachineList.ReadOnly = true;
            MachineList.TabIndex = ++tabIndex;
            Label_MachineList.Text = _fieldTitle.Machine;

            Model.DataBindings.Clear();
            Model.DataBindings.Add("Text", _bs, _fieldName.ModelWorkstationName);
            Model.TabIndex = ++tabIndex;
            Label_Model.Text = _fieldTitle.ModelWorkstationName;

            //Workstation.DataBindings.Clear();
            //Workstation.DataBindings.Add("Text", _bs, _fieldName.Workstation);
            //Workstation.TabIndex = ++tabIndex;
            //Label_Workstation.Text = _fieldTitle.Workstation;

            AcceptedTime.DataBindings.Clear();
            AcceptedTime.DataBindings.Add("Text", _bs, _fieldName.AcceptedTimeString);
            AcceptedTime.ReadOnly = true;
            AcceptedTime.TabIndex = ++tabIndex;
            Label_AcceptedTime.Text = _fieldTitle.AcceptedTime;

            RequestingUnit.DataBindings.Clear();
            RequestingUnit.DataBindings.Add("Text", _bs, _fieldName.RequestingUnitString);
            RequestingUnit.ReadOnly = true;
            RequestingUnit.TabIndex = ++tabIndex;
            Label_RequestingUnit.Text = _fieldTitle.RequestingUnit;

            /*****/

            Binding b;

            MaintenanceUnit.DataBindings.Clear();
            MaintenanceUnit.DataBindings.Add("Text", _bs, _fieldName.MaintenanceUnit);
            MaintenanceUnit.DataSource = _context.MaintenanceUnits
                .Select(m => new ListViewModel()
                {
                    Id = m.Id,
                    Name = m.UnitName,
                })
                .ToList();
            MaintenanceUnit.DisplayMember = "Name";
            MaintenanceUnit.ValueMember = "Id";
            MaintenanceUnit.TabIndex = ++tabIndex;
            Label_MaintenanceUnit.Text = _fieldTitle.MaintenanceUnit;

            Engineers.DataBindings.Clear();
            Engineers.DataBindings.Add("Text", _bs, _fieldName.EngineerString);
            Engineers.TabIndex = ++tabIndex;
            Engineers.Nodes.Clear();
            foreach (var engineer in _coreData.Engineers)
            {
                TreeNode tn = new TreeNode()
                {
                    Name = engineer.Name,
                    Text = engineer.Name,
                    Tag = new SelectorInfo()
                    {
                        Id = engineer.Id,
                        Name = engineer.Name,
                    },
                };
                Engineers.Nodes.Add(tn);
            }
            Label_Engineers.Text = _fieldTitle.Engineer;

            IssueCategory.DataBindings.Clear();
            IssueCategory.DataBindings.Add("Text", _bs, _fieldName.IssueCategory);
            IssueCategory.DataSource = _context.IssueCategories
                .Select(m => new ListViewModel()
                {
                    Id = m.Id,
                    Name = m.CategoryName,
                })
                .ToList();
            IssueCategory.DisplayMember = "Name";
            IssueCategory.ValueMember = "Id";
            IssueCategory.TabIndex = ++tabIndex;
            Label_IssueCategory.Text = _fieldTitle.IssueCategory;

            IssueDescription.DataBindings.Clear();
            IssueDescription.DataBindings.Add("Text", _bs, _fieldName.IssueDescription);
            IssueDescription.TabIndex = ++tabIndex;
            Label_IssueDescription.Text = _fieldTitle.IssueDescription;

            Details.DataBindings.Clear();
            Details.DataBindings.Add("Text", _bs, _fieldName.Details);
            Details.TabIndex = ++tabIndex;
            Label_Details.Text = _fieldTitle.Details;

            //b = new Binding("Value", _bs, _fieldName.RepairStarted, true);
            //b.Format += (s, e) =>
            //{
            //        e.Value = _editBuff.RepairStartedString;
            //};
            ////b.Parse += (s, e) =>
            ////{
            ////    if ((DateTime)e.Value == DateTimePicker.MinimumDateTime)
            ////        e.Value = null;
            ////};
            //RepairStarted.DataBindings.Add(b);
            RepairStarted.DataBindings.Clear();
            //RepairStarted.DataBindings.Add("Value", _bs, _fieldName.RepairStarted);
            RepairStarted.DataBindings.Add("Text", _bs, _fieldName.RepairStartedString);
            RepairStarted.TabIndex = ++tabIndex;
            Label_RepairStarted.Text = _fieldTitle.RepairStarted;

            //b = new Binding("Value", _bs, _fieldName.RepairCompleted, true);
            //b.Format += (s, e) =>
            //{
            //    e.Value = _editBuff.RepairCompletedString;
            //};
            //RepairCompleted.DataBindings.Add(b);
            RepairCompleted.DataBindings.Clear();
            //RepairCompleted.DataBindings.Add("Value", _bs, _fieldName.RepairCompleted);
            RepairCompleted.DataBindings.Add("Text", _bs, _fieldName.RepairCompletedString);
            RepairCompleted.TabIndex = ++tabIndex;
            Label_RepairCompleted.Text = _fieldTitle.RepairCompleted;

            OutageStarted.DataBindings.Clear();
            //OutageStarted.DataBindings.Add("Value", _bs, _fieldName.OutageStarted);
            OutageStarted.DataBindings.Add("Text", _bs, _fieldName.OutageStartedString);
            OutageStarted.ReadOnly = true;
            OutageStarted.TabIndex = ++tabIndex;
            Label_OutageStarted.Text = _fieldTitle.OutageStarted;

            OutageEnded.DataBindings.Clear();
            //OutageEnded.DataBindings.Add("Value", _bs, _fieldName.OutageEnded);
            OutageEnded.DataBindings.Add("Text", _bs, _fieldName.OutageEndedString);
            OutageEnded.TabIndex = ++tabIndex;
            Label_OutageEnded.Text = _fieldTitle.OutageEnded;

            RepairDuration.DataBindings.Clear();
            RepairDuration.DataBindings.Add("Text", _bs, _fieldName.RepairDurationString);
            RepairDuration.ReadOnly = true;
            RepairDuration.TabIndex = ++tabIndex;
            Label_RepairDuration.Text = _fieldTitle.RepairDuration;

            OutageDuration.DataBindings.Clear();
            OutageDuration.DataBindings.Add("Text", _bs, _fieldName.OutageDurationString);
            OutageDuration.ReadOnly = true;
            OutageDuration.TabIndex = ++tabIndex;
            Label_OutageDuration.Text = _fieldTitle.OutageDuration;
        }

        private void ListBox_Orders_SelectedIndexChanged(object sender, EventArgs e)
        {
            _editBuff = _editBuffs[ListBox_Orders.SelectedIndex];
            _bs.Position = ListBox_Orders.SelectedIndex;
        }

        #region 按鍵行為

        /********************
         * 按鍵行為
         ********************/
        private void Model_ButtonClick(object sender, EventArgs e)
        {
            _flowLayoutSelector.HideTabHeaders = true;
            _flowLayoutSelector.ShowTreeView = true;
            _flowLayoutSelector.Title = $"請選擇{_fieldTitle.Model}";
            _flowLayoutSelector.MultiSelection = false;
            _flowLayoutSelector.TabPageCache = _coreData.ModelWsTabPageCache;
            _flowLayoutSelector.DefaultChecked = new List<string>() { _editBuff.WorkstationName };
            _flowLayoutSelector.Initialize();

            if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            {
                if (_flowLayoutSelector.ResultList.Count > 0)
                {
                    SelectorInfo info = _flowLayoutSelector.ResultList[0];
                    int idx = ListBox_Orders.SelectedIndex;
                    _editBuffs[idx].WorkstationId = info.Id;
                    _editBuffs[idx].Workstation = _coreData.Workstations.FirstOrDefault(w => w.Id == info.Id);
                    _editBuffs[idx].Workstation.Model = _coreData.Models.FirstOrDefault(m => m.ModelName == info.Category);

                    var showText = new string[2];
                    showText[0] = info.Category;
                    showText[1] = info.Name;
                    Model.Text = string.Join(" » ", showText);
                }
            }
        }
        //private void Model_ButtonClick(object sender, EventArgs e)
        //{
        //    SelectorInfo idList;
        //    _flowLayoutSelector.HideTabHeaders = true;
        //    _flowLayoutSelector.ShowTreeView = false;
        //    _flowLayoutSelector.Title = $"請選擇{_fieldTitle.Model}";
        //    _flowLayoutSelector.MultiSelection = false;
        //    _flowLayoutSelector.TabPageCache = _coreData.ModelTabPageCache;
        //    _flowLayoutSelector.DefaultChecked = new List<string>() { ((SelectorInfo)Model.Tag).Name };
        //    _flowLayoutSelector.Initialize();

        //    if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
        //    {
        //        if (_flowLayoutSelector.ResultList.Count > 0)
        //        {
        //            idList = _flowLayoutSelector.ResultList[0];
        //            var ws = _context.Models.FirstOrDefault(m => m.Id == idList.Id);

        //            var taskOrder = new TaskOrder { Id = _editBuff.Id };
        //            _context.TaskOrders.Attach(taskOrder);
        //            taskOrder.WorkstationId = null;

        //            _context.Entry(taskOrder).Property(t => t.WorkstationId).IsModified = true;
        //            _context.SaveChanges();

        //            Model.Text = idList.Name;
        //            isChanged = true;
        //        }
        //    }
        //}

        private void Workstation_ButtonClick(object sender, EventArgs e)
        {
            //const string COMMON_NAME = "WS";
            //Dictionary<string, List<TabPage>> tabPageCache = new Dictionary<string, List<TabPage>>();
            //List<TabPage> tabPages = new List<TabPage>();
            //TabPage tabPage = new TabPage(COMMON_NAME)
            //{
            //    Name = COMMON_NAME,
            //    Font = CommonStyles.Font,
            //};
            //UIFlowLayoutPanel flp = new UIFlowLayoutPanel()
            //{
            //    Dock = DockStyle.Fill,
            //    AutoScroll = true,
            //};
            //tabPage.Controls.Add(flp);

            //var wss = _context.Workstations
            //    .Where(w => w.Model.ModelName == Model.Text)
            //    .Select(w => new SelectorInfo()
            //    {
            //        Id = w.Id,
            //        Category = COMMON_NAME,
            //        Type = COMMON_NAME,
            //        Name = Workstation.Name,
            //    })
            //    .ToList();
            //List<UIRadioButton> rbs = new List<UIRadioButton>();
            //foreach (var ws in wss)
            //{
            //    var rb = new UIRadioButton
            //    {
            //        GroupIndex = 1,
            //        Text = ws.Name,
            //        Name = ws.Name,
            //        Checked = false,
            //        AutoSize = false,
            //        Width = 150,
            //        Font = CommonStyles.Font,
            //        Style = UIStyle.Inherited,
            //        RadioButtonColor = CommonStyles.BackColor,
            //        Tag = ws,
            //    };
            //    rbs.Add(rb);
            //}
            //flp.Controls.AddRange(rbs.ToArray());
            //tabPages.Add(tabPage);
            //tabPageCache.Add(COMMON_NAME, tabPages);

            //_flowLayoutSelector.HideTabHeaders = true;
            //_flowLayoutSelector.ShowTreeView = false;
            //_flowLayoutSelector.Title = $"請選擇{_fieldTitle.Workstation}";
            //_flowLayoutSelector.MultiSelection = false;
            //_flowLayoutSelector.TabPageCache = tabPageCache;
            //_flowLayoutSelector.DefaultChecked = new List<string>() { Workstation.Text };
            //_flowLayoutSelector.Initialize();

            //if (_flowLayoutSelector.ShowDialog() == DialogResult.OK)
            //{
            //    if (_flowLayoutSelector.ResultList.Count > 0)
            //    {
            //        var idList = _flowLayoutSelector.ResultList[0];
            //        var ws = new Workstation { Id = idList.Id }; // 不從 DB 查
            //        _context.TaskOrders.Attach(ws);
            //        _context.Entry(ws).Property(w => w.Id).IsModified = true;
            //        _context.SaveChanges();

            //        Workstation.Text = idList.Name;
            //        isChanged = true;
            //    }
            //}
        }

        private void MaintenanceUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_editBuff == null)
                return;

            if (MaintenanceUnit.SelectedItem is ListViewModel select)
                _editBuff.MaintenanceUnitId = select.Id;
        }

        private void Engineers_NodesSelected(object sender, TreeNodeCollection nodes)
        {
            if (_editBuff == null)
                return;

            EngineerList.Clear();
            for (int i = 0; i < nodes.Count; i++)
            {
                var node = nodes[i];
                if (node.Checked)
                    EngineerList.Add(((SelectorInfo)node.Tag).Id);
            }
        }

        private void RepairStarted_TextChanged(object sender, EventArgs e)
        {
            if (DateTime.TryParse(RepairStarted.Text, out DateTime dt))
                _editBuff.RepairStarted = dt;

            if (_editBuff.RepairCompleted != null && _editBuff.RepairStarted != null)
                RepairDuration.Text = _editBuff.RepairDurationString;
            //_editBuff.RepairDuration = (TimeSpan)(_editBuff.RepairCompleted - _editBuff.RepairStarted);
            else
                _editBuff.RepairDuration = TimeSpan.Zero;
        }

        private void RepairCompleted_TextChanged(object sender, EventArgs e)
        {
            if (DateTime.TryParse(RepairCompleted.Text, out DateTime dt))
                _editBuff.RepairCompleted = dt;

            if (_editBuff.RepairCompleted != null && _editBuff.RepairStarted != null)
                RepairDuration.Text = _editBuff.RepairDurationString;
            //_editBuff.RepairDuration = (TimeSpan)(_editBuff.RepairCompleted - _editBuff.RepairStarted);
            else
                _editBuff.RepairDuration = TimeSpan.Zero;
        }

        private void OutageStarted_TextChanged(object sender, EventArgs e)
        {
            if (DateTime.TryParse(OutageStarted.Text, out DateTime dt))
                _editBuff.OutageStarted = dt;

            if (_editBuff.OutageEnded != null && _editBuff.OutageStarted != null)
                OutageDuration.Text = _editBuff.OutageDurationString;
            //_editBuff.OutageDuration = (TimeSpan)(_editBuff.OutageEnded - _editBuff.OutageStarted);
            else
                _editBuff.OutageDuration = TimeSpan.Zero;
        }

        private void OutageEnded_TextChanged(object sender, EventArgs e)
        {
            if (DateTime.TryParse(OutageEnded.Text, out DateTime dt))
                _editBuff.OutageEnded = dt;

            if (_editBuff.OutageEnded != null && _editBuff.OutageStarted != null)
                OutageDuration.Text = _editBuff.OutageDurationString;
            //_editBuff.OutageDuration = (TimeSpan)(_editBuff.OutageEnded - _editBuff.OutageStarted);
            else
                _editBuff.OutageDuration = TimeSpan.Zero;
        }

        #endregion 按鍵行為
    }
}
