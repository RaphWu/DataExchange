﻿using System;
using System.Data.Entity.Infrastructure;
using System.Windows.Forms;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contract;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowPage : UIPage
    {
        private readonly ICore _core;
        private readonly ManitiFlowMain _manitiFlowMain;
        private readonly MaintiFlowSummary _manitiFlowSummary;

        private PageCode _currentPage = PageCode.None;

        public MaintiFlowPage(ICore core,  
                              ManitiFlowMain manitiFlowMain,
                              MaintiFlowSummary manitiFlowSummary)
        {
            InitializeComponent();
            _core = core;
            _manitiFlowMain = manitiFlowMain;
            _manitiFlowSummary = manitiFlowSummary;

            /********************
             * Menu
             ********************/
            TreeNode node1;
            int pageIndex;
            string pageCaption;

            pageIndex = (int)PageCode.MaintiFlowMain;
            pageCaption = TextList.Menu;
            node1 = uiNavMenu.CreateNode(pageCaption, 98, 24, pageIndex);
            node1.Tag = pageIndex;

            pageIndex = (int)PageCode.MaintiFlowSummary;
            pageCaption = PageCode.MaintiFlowSummary.GetDescription();
            node1 = uiNavMenu.CreateNode(pageCaption, 557582, 24, pageIndex);
            node1.Tag = pageIndex;

            //pageIndex = (int)PageCode.FlowTracking;
            //pageCaption = PageCode.FlowTracking.GetDescription();
            //node1 = uiNavMenu.CreateNode(pageCaption, 361734, 24, pageIndex);
            //node1.Tag = pageIndex;

            //uiTabControl_Content.AddPage(_manitiFlowMain);
            //uiTabControl_Content.AddPage(_manitiFlowSummary);
            ////uiTabControl_Content.AddPage(_flowTracking);
            //uiTabControl_Content.SelectedIndex = 0;

            //pageIndex = (int)PageCode.EditFlow;
            //pageCaption = PageCode.EditFlow.GetDescription();
            //node1 = uiNavMenu.CreateNode(pageCaption, 108, 24, pageIndex);
            //node1.Tag = pageIndex;
            //uiButton_EditFlow.Text = pageCaption;
            //uiButton_EditFlow.Symbol = 108;

            //pageIndex = (int)PageCode.DeleteFlow;
            //pageCaption = PageCode.DeleteFlow.GetDescription();
            //node1 = uiNavMenu.CreateNode(pageCaption, 559691, 24, pageIndex);
            //node1.Tag = pageIndex;
            //uiButton_DeleteFlow.Text = pageCaption;
            //uiButton_DeleteFlow.Symbol = 559691;

            //pageIndex = (int)PageCode.CreateFlow;
            //pageCaption = PageCode.CreateFlow.GetDescription();

            SwitchPage(PageCode.MaintiFlowMain);
#if DEBUG
            //csv.Load();
#endif
        }

        private void SwitchPage(PageCode pageCode)
        {
            UIUserControl ctl;
            if (_currentPage == pageCode)
                return;

            switch (pageCode)
            {
                case PageCode.MaintiFlowMain:
                    ctl = _manitiFlowMain;
                    break;

                case PageCode.MaintiFlowSummary:
                    ctl = _manitiFlowSummary;
                    break;

                //case PageCode.FlowTracking:
                //    uiTabControl_Content.SelectedIndex = 2;
                //    break;
                default:
                    return;
            }

            ctl.Dock = DockStyle.Fill;
            Panel_Nav.Controls.Clear();
            Panel_Nav.Controls.Add(ctl);
            _currentPage = pageCode;
        }

        private void uiNavMenu_MenuItemClick(TreeNode node, NavMenuItem item, int pageIndex)
        {
            SwitchPage((PageCode)Enum.Parse(typeof(PageCode), pageIndex.ToString()));
        }

        private void uiPanel_Header_Click(object sender, EventArgs e)
        {

        }
    }
}
