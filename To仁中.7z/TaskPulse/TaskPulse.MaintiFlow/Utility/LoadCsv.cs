﻿using Calin.TaskPulse.MaintiFlow.Models;

#if DEBUG

namespace Calin.TaskPulse.MaintiFlow.Utility
{
    public class LoadCsv
    {
        private readonly MaintiFlowContext _context;

        public LoadCsv(MaintiFlowContext context)
        {
            _context = context;
        }

        internal void Load()
        {
            //try
            //{
            //    int recCount = 1;
            //    using (var sr = new StreamReader("設備維修履歷(Sample).txt", Encoding.Default))
            //    {
            //        string[] sList;

            //        var tos = _context.Set<TaskOrder>();
            //        var em = _context.Set<Employee>();
            //        var ma = _context.Set<Device>();
            //        var st = _context.Set<Status>();
            //        var mu = _context.Set<MaintenanceUnit>();
            //        var ic = _context.Set<IssueCategory>();
            //        var ru = _context.Set<RequestingUnit>();

            //        try
            //        {
            //            while (sr.Peek() != -1)
            //            {
            //                string[] data = sr.ReadLine().Split('\t');

            //                if (recCount > 1) // 去掉標題
            //                {
            //                    var to = new TaskOrder();
            //                    to.OrderNo = int.Parse(data[0]);
            //                    to.WorkOrderNo = data[1].Trim();

            //                    if (!string.IsNullOrWhiteSpace(data[2]))
            //                    {
            //                        string name = data[2].Trim();
            //                        to.Creator = em.FirstOrDefault(x => x.Name == name);
            //                    }
            //                    else
            //                    {
            //                        to.Creator = null;
            //                    }

            //                    to.CreationDate = DateTime.Parse(data[3]);

            //                    if (!string.IsNullOrWhiteSpace(data[4]))
            //                    {
            //                        string name = data[4].Trim();
            //                        to.MaintenanceUnit = mu.FirstOrDefault(x => x.Name == name);
            //                    }
            //                    else
            //                    {
            //                        to.MaintenanceUnit = null;
            //                    }

            //                    sList = data[5].Split('/');
            //                    to.MaintenanceEngineers = new List<TaskOrderEngineer>();
            //                    foreach (var d5 in sList)
            //                    {
            //                        var emId = em.FirstOrDefault(e => e.Name == d5 && e.IsEngineer == true);
            //                        if (emId != null)
            //                            to.MaintenanceEngineers.Add(new TaskOrderEngineer()
            //                            {
            //                                WorkOrderNo = to.WorkOrderNo,
            //                                EmployeeId = emId.EmployeeId,
            //                            });
            //                    }

            //                    // data[6] 可能為「機台名稱_機台名稱_...」
            //                    var d6 = data[6].Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries)
            //                                    .Select(x => x.Trim())
            //                                    .Where(x => !string.IsNullOrWhiteSpace(x))
            //                                    .Distinct() // 同一筆資料若重複，不要重複加
            //                                    .ToList();
            //                    to.TaskOrderDevices = new List<TaskOrderDevice>();
            //                    foreach (var d_6 in d6)
            //                    {
            //                        // 先找目前追蹤中的暫存實體，再找資料庫已存在的
            //                        var machine = ma.Local.FirstOrDefault(x => x.DeviceName == d_6)
            //                                   ?? ma.FirstOrDefault(x => x.DeviceName == d_6);

            //                        // 若完全不存在則建立新實體
            //                        if (machine == null)
            //                        {
            //                            machine = new Device { DeviceName = d_6 };
            //                            ma.Add(machine);
            //                        }

            //                        // 使用導航屬性關聯，不要直接操作外鍵ID
            //                        to.TaskOrderDevices.Add(new TaskOrderDevice
            //                        {
            //                            TaskOrder = to,
            //                            Device = machine
            //                        });
            //                    }

            //                    //var d6 = data[6].Split('_').ToList();
            //                    //var existingMachines = ma.ToList();
            //                    //var localMachines = new List<Device>();
            //                    //to.TaskOrderDevices = new List<TaskOrderDevice>();
            //                    //foreach (var d_6 in d6)
            //                    //{
            //                    //    if (string.IsNullOrWhiteSpace(d_6)) continue;

            //                    //    // 先從資料庫找，再從目前追蹤的暫存實體中找
            //                    //    var machine = ma.Local.FirstOrDefault(x => x.DeviceName == d_6)
            //                    //               ?? existingMachines.FirstOrDefault(x => x.DeviceName == d_6);

            //                    //    if (machine == null)
            //                    //    {
            //                    //        machine = new Device() { DeviceName = d_6 };
            //                    //        ma.Add(machine);
            //                    //        existingMachines.Add(machine); // 更新快取
            //                    //    }

            //                    //    to.TaskOrderDevices.Add(new TaskOrderDevice()
            //                    //    {
            //                    //        TaskOrder = to,     // 建議直接設關聯
            //                    //        Device = machine,  // 不要用 DeviceId（因為還沒存時是0）
            //                    //    });

            //                    //    //var existing = existingMachines.FirstOrDefault(x => x.DeviceName == d_6)
            //                    //    //    ?? localMachines.FirstOrDefault(x => x.DeviceName == d_6);

            //                    //    //if (existing == null)
            //                    //    //{
            //                    //    //    existing = new Device() { DeviceName = d_6 };
            //                    //    //    ma.Add(existing);
            //                    //    //    localMachines.Add(existing);
            //                    //    //}

            //                    //    //var d__6 = ma.FirstOrDefault(x => x.DeviceName == d_6);
            //                    //    //if (d__6 == null)
            //                    //    //    d__6 = ma.Add(new Device() { DeviceName = d_6 });
            //                    //    //to.TaskOrderDevices.Add(new TaskOrderDevice()
            //                    //    //{
            //                    //    //    WorkOrderNo = to.WorkOrderNo,
            //                    //    //    DeviceId = d__6.DeviceId,
            //                    //    //});
            //                    //}

            //                    to.AcceptedTime = DateTime.Parse(string.Concat(data[3], " ", data[7]));

            //                    if (DateTime.TryParse(string.Concat(data[3], " ", data[8]), out DateTime rs))
            //                        to.RepairStarted = rs;
            //                    else
            //                        to.RepairStarted = null;

            //                    if (DateTime.TryParse(string.Concat(data[3], " ", data[9]), out DateTime rc))
            //                        to.RepairCompleted = rc;
            //                    else
            //                        to.RepairCompleted = null;

            //                    if (int.TryParse(data[10], out int rd))
            //                        to.RepairDuration = TimeSpan.FromMinutes(rd);
            //                    else
            //                    {
            //                        if (rs == null || rc == null)
            //                            to.RepairDuration = null;
            //                        else
            //                            to.RepairDuration = rc - rs;
            //                    }

            //                    if (DateTime.TryParse(string.Concat(data[3], " ", data[11]), out DateTime os))
            //                        to.OutageStarted = os;
            //                    else
            //                        to.OutageStarted = null;

            //                    if (DateTime.TryParse(string.Concat(data[3], " ", data[12]), out DateTime oe))
            //                        to.OutageEnded = oe;
            //                    else
            //                        to.OutageEnded = null;

            //                    if (int.TryParse(data[13], out int od))
            //                        to.OutageDuration = TimeSpan.FromMinutes(od);
            //                    else
            //                    {
            //                        if (rs == null || rc == null)
            //                            to.OutageDuration = null;
            //                        else
            //                            to.OutageDuration = oe - os;
            //                    }

            //                    to.Model = data[15].Trim();
            //                    to.Workstation = data[16].Trim().Split(',');

            //                    if (!string.IsNullOrWhiteSpace(data[17]))
            //                    {
            //                        string name = data[17].Trim();
            //                        to.IssueCategory = ic.FirstOrDefault(x => x.CategoryName == name);
            //                    }
            //                    else
            //                    {
            //                        to.IssueCategory = null;
            //                    }

            //                    to.IssueDescription = data[18].Trim();
            //                    to.Details = data[19].Trim();

            //                    if (!string.IsNullOrWhiteSpace(data[20]))
            //                    {
            //                        string name = data[20].Trim();
            //                        to.RequestingUnit = ru.FirstOrDefault(x => x.Name == name);
            //                    }
            //                    else
            //                    {
            //                        to.RequestingUnit = null;
            //                    }

            //                    if (!string.IsNullOrWhiteSpace(data[21]))
            //                    {
            //                        string name = data[21].Trim();
            //                        to.RequestingEmployee = em.FirstOrDefault(x => x.Name == name);
            //                    }
            //                    else
            //                    {
            //                        to.RequestingEmployee = null;
            //                    }

            //                    if (!string.IsNullOrWhiteSpace(data[22]))
            //                    {
            //                        string name = data[22].Trim();
            //                        to.Status = st.FirstOrDefault(x => x.StatusName == name);
            //                    }
            //                    if (to.Status == null)
            //                        to.Status = st.FirstOrDefault(x => x.StatusName == "待處理");

            //                    to.RequestingUnitResponse = data[23].Trim();

            //                    tos.Add(to);
            //                }

            //                recCount++;
            //            }
            //            _context.SaveChanges();
            //        }
            //        catch (DbEntityValidationException ex)
            //        {
            //            foreach (var eve in ex.EntityValidationErrors)
            //            {
            //                Console.WriteLine($"Entity of type '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

            //                foreach (var ve in eve.ValidationErrors)
            //                {
            //                    Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
            //                }
            //            }

            //            throw; // 若你要繼續丟出錯誤
            //        }
            //        catch (Exception ex)
            //        {
            //            Console.WriteLine(ex.ToString());
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.ToString());
            //}
        }
    }
}

#endif