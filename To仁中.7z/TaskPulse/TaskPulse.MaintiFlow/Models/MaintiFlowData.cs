﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    public class MaintiFlowData : ObservableObject
    {
        /// <summary>
        /// 機台編號列表。
        /// </summary>
        public List<KeyValuePair<int, string>> MachineList
        {
            get { return _machineList; }
            set { SetProperty(ref _machineList, value); }
        }
        private List<KeyValuePair<int, string>> _machineList;

        /// <summary>
        /// 機種列表。
        /// </summary>
        public List<KeyValuePair<int, string>> ModelList
        {
            get { return _modelList; }
            set { SetProperty(ref _modelList, value); }
        }
        private List<KeyValuePair<int, string>> _modelList;
    }
}
