﻿using System.Collections.Generic;
using Calin.TaskPulse.Entity.MaintiFlow;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護工單共用資料。
    /// </summary>
    public class MaintiFlowData : ObservableObject
    {
        /// <summary>
        /// 全部維護工單。
        /// </summary>
        public List<TaskOrder> TaskOrder
        {
            get { return _taskOrder; }
            set { SetProperty(ref _taskOrder, value); }
        }
        private List<TaskOrder> _taskOrder;

        /// <summary>
        /// 
        /// </summary>
        public List<TaskOrder> PropertyName
        {
            get { return _PropertyName; }
            set { SetProperty(ref _PropertyName, value); }
        }
        private List<TaskOrder> _PropertyName;

        ///// <summary>
        ///// 員工名冊。
        ///// </summary>
        //public List<EmployeeBuff> Employees // EF關聯用。因為多了導航屬性，所以另建，小心維護
        //{
        //    get { return _employees; }
        //    set { SetProperty(ref _employees, value); }
        //}
        //private List<EmployeeBuff> _employees;

        ///// <summary>
        ///// 維護工程師名冊。
        ///// </summary>
        //public List<Engineer> Engineers
        //{
        //    get { return _engineers; }
        //    set { SetProperty(ref _engineers, value); }
        //}
        //private List<Engineer> _engineers;

        ///// <summary>
        ///// 顯示用機台編號列表。
        ///// </summary>
        //public List<KeyValuePair<string, string>> MachineList
        //{
        //    get { return _machineList; }
        //    set { SetProperty(ref _machineList, value); }
        //}
        //private List<KeyValuePair<string, string>> _machineList;

        ///// <summary>
        ///// 顯示用工站列表。
        ///// </summary>
        //public List<WorkstationBuff> Workstations
        //{
        //    get { return _workstations; }
        //    set { SetProperty(ref _workstations, value); }
        //}
        //private List<WorkstationBuff> _workstations;
    }
}
