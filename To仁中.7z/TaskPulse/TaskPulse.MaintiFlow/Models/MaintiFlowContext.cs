﻿//using System.Data.Entity;
//using Calin.TaskPulse.Core.Models;
//using Calin.TaskPulse.Entity.Core;
//using Calin.TaskPulse.Entity.MaintiFlow;

//namespace Calin.TaskPulse.MaintiFlow.Models
//{
//    /// <summary>
//    /// 資料庫區。
//    /// </summary>
//    public class MaintiFlowContext : DbContext
//    {
//        private readonly CoreContext _coreContext;

//        public MaintiFlowContext(CoreContext coreContext) : base("name=MaintiFlowContext")
//        {
//            _coreContext = coreContext;

//            //if (System.IO.File.Exists("MaintiFlowDB.db"))
//            //    System.IO.File.Delete("MaintiFlowDB.db");

//            //Database.SetInitializer(new CreateDatabaseIfNotExists<MaintiFlowContext>());
//            //Database.SetInitializer(new DropCreateDatabaseAlways<MaintiFlowContext>());
//            //Database.SetInitializer<MaintiFlowContext>(null);
//            //Database.CreateIfNotExists();
//        }

//        /////***** TaskOrder.Core *****/
//        //public DbSet<Department> Departments { get; set; }
//        //public DbSet<Title> Titles { get; set; }
//        //public DbSet<Employee> Employees { get; set; }
//        //public DbSet<Workstation> Workstations { get; set; }
//        //public DbSet<Model> Models { get; set; }

//        ///***** 需求單位 *****/
//        //public DbSet<RequestingUnit> RequestingUnits { get; set; }

//        ///***** 維護單位 *****/
//        //public DbSet<IssueCategory> IssueCategories { get; set; }
//        //public DbSet<MaintenanceUnit> MaintenanceUnits { get; set; }

//        ///***** TaskOrder *****/
//        //public DbSet<TaskOrder> TaskOrders { get; set; }

//        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
//        //{
//        //    Database.SetInitializer(new MaintiFlowInitializer(modelBuilder, _coreContext));

//        //    var taskorder = modelBuilder.Entity<TaskOrder>();
//        //    taskorder.HasKey(t => t.WorkOrderNo);

//        //    /***** 需求單位 *****/
//        //    // 需求單位 一對多: TaskOrder.RequestingUnit → RequestingUnit.TaskOrderEngineers
//        //    taskorder.HasRequired(t => t.RequestingUnit)
//        //             .WithMany(ru => ru.TaskOrders)
//        //             .HasForeignKey(t => t.RequestingUnitId)
//        //             .WillCascadeOnDelete(false);

//        //    // 回覆人員 一對多: TaskOrder.RequestingEmployee → Core.Employee.RequestingTaskOrders
//        //    taskorder.HasOptional(t => t.RequestingEmployee)
//        //           .WithMany(ru => ru.RequestingEmployeeTaskOrders)
//        //           .HasForeignKey(t => t.RequestingEmployeeId)
//        //           .WillCascadeOnDelete(false);

//        //    /***** 維護單位 *****/
//        //    // 維護類型 一對多: TaskOrderEngineers.IssueCategory → IssueCategory.TaskOrderEngineers
//        //    taskorder.HasOptional(t => t.IssueCategory)
//        //             .WithMany(ic => ic.TaskOrders)
//        //             .HasForeignKey(t => t.IssueCategoryId)
//        //             .WillCascadeOnDelete(false);

//        //    // 維護單位 一對多: TaskOrder.MaintenanceUnit → MaintenanceUnit.TaskOrders
//        //    taskorder.HasOptional(t => t.MaintenanceUnit)
//        //             .WithMany(mu => mu.TaskOrders)
//        //             .HasForeignKey(t => t.Key)
//        //             .WillCascadeOnDelete(false);

//        //    /***** TaskOrder.Core *****/
//        //    // 部門 一對多: Employee.Department → Department.Employees
//        //    modelBuilder.Entity<Employee>()
//        //        .HasRequired(t => t.Department)
//        //        .WithMany(e => e.Employees)
//        //        .HasForeignKey(t => t.Key)
//        //        .WillCascadeOnDelete(false);

//        //    // 職稱 一對多: Employee.Title → Title.Employees
//        //    modelBuilder.Entity<Employee>()
//        //        .HasOptional(t => t.Title)
//        //        .WithMany(e => e.Employees)
//        //        .HasForeignKey(t => t.Key)
//        //        .WillCascadeOnDelete(false);

//        //    // 建檔人員 一對多: TaskOrder.Creator → Employee.CreatedTaskOrders
//        //    taskorder.HasRequired(t => t.Creator)
//        //             .WithMany(e => e.CreaterTaskOrders)
//        //             .HasForeignKey(t => t.CreatorId)
//        //             .WillCascadeOnDelete(false);

//        //    // 維護工程師 多對多 TaskOrder.Creator ↔ Employee.CreatedTaskOrders
//        //    taskorder.HasMany(m => m.Engineers)
//        //             .WithMany(e => e.EngineerTaskOrders)
//        //             .Map(m =>
//        //             {
//        //                 m.ToTable("TaskOrderEngineers");
//        //                 m.MapLeftKey("EmployeeIds");
//        //                 m.MapRightKey("EmployeeId");
//        //             });

//        //    // 工站 一對多: TaskOrder.Workstation → Workstation.TaskOrders
//        //    taskorder
//        //        .HasRequired(t => t.Workstation)
//        //        .WithMany(w => w.TaskOrders)
//        //        .HasForeignKey(t => t.Key)
//        //        .WillCascadeOnDelete(false);

//        //    // 機種 一對多: Workstation.Model → Model.Worktations
//        //    modelBuilder.Entity<Workstation>()
//        //        .HasRequired(w => w.Model)
//        //        .WithMany(m => m.Worktations)
//        //        .HasForeignKey(w => w.Key)
//        //        .WillCascadeOnDelete(false);
//        //}
//    }
//}
