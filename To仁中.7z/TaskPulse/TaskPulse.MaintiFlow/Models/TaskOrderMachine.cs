﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    public class TaskOrderMachine
    {
        [Key, Column(Order = 0)]
        public string WorkOrderNo { get; set; }   // FK，指向 TaskOrder.WorkOrderNo
        public virtual TaskOrder TaskOrder { get; set; }

        [Key, Column(Order = 1)]
        public int MachineId { get; set; }        // FK，指向 Machine.MachineId
        public virtual Machine Machine { get; set; }
    }
}
