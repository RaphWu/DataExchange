﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.MaintiFlow.Models
{
    /// <summary>
    /// 維護工單。
    /// </summary>
    public class TaskOrder
    {
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        [Description("維護工單編號")]
        [Key]
        [Required]
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        [Description("編號")]
        public int OrderNo { get; set; }

        /// <summary>
        /// 建檔人員。
        /// </summary>
        [Description("建檔人員")]
        public Employee Creator { get; set; }
        public string CreatorId { get; set; } // FK

        /// <summary>
        /// 建檔日期。
        /// </summary>
        [Description("建檔日期")]
        [Required]
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// 目前狀態。
        /// </summary>
        [Description("目前狀態")]
        [Required]
        public Status Status { get; set; }

        /// <summary>
        /// 維護單位。
        /// </summary>
        [Description("維護單位")]
        public virtual MaintenanceUnit MaintenanceUnit { get; set; }
        public int? MaintenanceUnitId { get; set; } // FK

        /// <summary>
        /// 維護工程師。
        /// </summary>
        [Description("維護工程師")]
        public virtual ICollection<TaskOrderEngineer> MaintenanceEngineers { get; set; }

        /// <summary>
        /// 機台編號。
        /// </summary>
        [Description("機台編號")]
        public virtual ICollection<TaskOrderDevice> TaskOrderDevices { get; set; }

        /// <summary>
        /// 接收時間。
        /// </summary>
        [Description("接收時間")]
        [Required]
        public DateTime AcceptedTime { get; set; }

        /// <summary>
        /// 維修開始時間。
        /// </summary>
        [Description("開始時間")]
        public DateTime? RepairStarted { get; set; }

        /// <summary>
        /// 維修完成時間。
        /// </summary>
        [Description("完成時間")]
        public DateTime? RepairCompleted { get; set; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [Description("維修工時")]
        public string RepairDurationString { get; set; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [Description("維修工時")]
        [NotMapped]
        public TimeSpan? RepairDuration
        {
            get => TimeSpan.Parse(RepairDurationString);
            set => RepairDurationString = value.ToString();
        }

        /// <summary>
        /// 停動開始。
        /// </summary>
        [Description("停動開始")]
        public DateTime? OutageStarted { get; set; }

        /// <summary>
        /// 停動結束。
        /// </summary>
        [Description("停動結束")]
        public DateTime? OutageEnded { get; set; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [Description("停動工時")]
        public string OutageDurationString { get; set; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [Description("停動工時")]
        [NotMapped]
        public TimeSpan? OutageDuration
        {
            get => TimeSpan.Parse(OutageDurationString);
            set => OutageDurationString = value.ToString();
        }

        /// <summary>
        /// 責任歸屬。
        /// </summary>
        [Description("責任歸屬")]
        public string Responsible { get; set; }

        /// <summary>
        /// 機種。
        /// </summary>
        [Description("機種")]
        public Model Model { get; set; }
        public int ModelId { get; set; } // FK

        /// <summary>
        /// 工站。
        /// </summary>
        [Description("工站")]
        public string[] Workstation { get; set; }

        /// <summary>
        /// 維護類型。
        /// </summary>
        [Description("維護類型")]
        public virtual IssueCategory IssueCategory { get; set; }
        public int? IssueCategoryId { get; set; } // FK

        /// <summary>
        /// 問題描述。
        /// </summary>
        [Description("問題描述")]
        public string IssueDescription { get; set; }

        /// <summary>
        /// 維護內容。
        /// </summary>
        [Description("維護內容")]
        public string Details { get; set; }

        /// <summary>
        /// 需求單位名稱。
        /// </summary>
        [Description("需求單位名稱")]
        public virtual RequestingUnit RequestingUnit { get; set; }
        public int? RequestingUnitId { get; set; } // FK

        /// <summary>
        /// 需求單位人員工號。
        /// </summary>
        [Description("需求單位人員工號")]
        public virtual Employee RequestingEmployee { get; set; }
        public string RequestingEmployeeId { get; set; } // FK

        /// <summary>
        /// 需求單位回覆。
        /// </summary>
        [Description("需求單位回覆")]
        public string RequestingUnitResponse { get; set; }
    }
}
