﻿using Autofac;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Models;
using Calin.TaskPulse.MaintiFlow.Service;
using Calin.TaskPulse.MaintiFlow.Views;

namespace Calin.TaskPulse.MaintiFlow
{
    /// <summary>
    /// 維護工單模組。
    /// </summary>
    public class MaintiFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // views
            builder.RegisterType<MaintiFlowPage>().AsSelf().PropertiesAutowired();
            builder.RegisterType<ManitiFlowMain>().AsSelf().PropertiesAutowired();
            builder.RegisterType<MaintiFlowSummary>().AsSelf().PropertiesAutowired();
            builder.RegisterType<CreateFlow>().AsSelf().PropertiesAutowired();
            builder.RegisterType<TaskOrderView>().AsSelf();
            builder.RegisterType<FT_AcceptFlow>().AsSelf().PropertiesAutowired();
            builder.RegisterType<FT_MaintiWork>().AsSelf().PropertiesAutowired();
            builder.RegisterType<FT_FlowConfirmed>().AsSelf().PropertiesAutowired();

            // service
            builder.RegisterType<MaintiFlowService>().As<IMaintiFlow>().SingleInstance();

            // public NewWorkOrderNos
            builder.RegisterType<MaintiFlowData>().AsSelf().SingleInstance();

            // DbContext
            //builder.RegisterType<MaintiFlowInitializer>().As<IStartable>().SingleInstance();
            //builder.RegisterType<MaintiFlowContext>().InstancePerDependency();

            builder.RegisterBuildCallback(c =>
            {
                var maintiFLow = c.Resolve<IMaintiFlow>();
                maintiFLow.Initialize();
            });
        }
    }
}
