﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Views;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public partial class MaintiFlowService : ITaskOrderAction
    {
        /// <inheritdoc/>
        public bool CreateNewFlow()
        {
            _createFlow.Title = "新建工單";
            if (_createFlow.ShowDialog() == DialogResult.OK)
            {
                StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

                _taskOrderView.Title = "工單已建立";
                _taskOrderView.NewWorkOrderNos = _createFlow.NewWorkOrderNos;
                _taskOrderView.Initialize();
                Core.Views.FormEx.ShowDialogWithMask(_taskOrderView);
                return true;
            }

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> CancelFlow()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.NewTaskOrder).ToList();
            if (to.Any())
            {
                _acceptFlow.Title = "取消工單";
                _acceptFlow.OkCaption = "取消工單";
                _acceptFlow.Orders = to;
                //if (Core.Views.FormEx.ShowDialogWithMask(_acceptFlow) == DialogResult.OK)
                //{
                //    //var to = _context.TaskOrders.FirstOrDefault(t => t.Id == _acceptFlow.SelectedOrder);
                //    var to = _acceptFlow.SelectedOrder;
                //    if (to != null)
                //    {
                //        to.Status = OrderStatus.Completed;
                //        await _context.SaveChangesAsync();
                //        StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
                //    }
                //}
                return true;
            }
            else
            {
                MessageBox.Show("無可取消的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> AcceptFlow()
        {
            var tos = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.NewTaskOrder).ToList();
            if (tos.Any())
            {
                _acceptFlow.Title = "接單";
                _acceptFlow.OkCaption = "接單";
                _acceptFlow.Orders = tos;
                if (Core.Views.FormEx.ShowDialogWithMask(_acceptFlow) == DialogResult.OK)
                {
                    TaskOrder to;
                    string empName = default;
                    List<string> pickOrderNames = new List<string>();
                    foreach (string orderId in _acceptFlow.SelectedOrder)
                    {
                        to = _context.TaskOrders.FirstOrDefault(t => t.WorkOrderNo == orderId);
                        to.Status = OrderStatus.InProgress;
                        empName = to.CreatorName;
                        pickOrderNames.Add(to.WorkOrderNo);

                        var empId = _coreData.Employees.FirstOrDefault(e => e.Id == to.CreatorId)?.Id;
                        if (empId != null)
                        {
                            var emp = _context.Employees.Find(empId);
                            if (emp != null)
                            {
                                to.Engineers = new List<Employee> { emp };
                                StrongReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Employee));
                            }
                        }
                    }
                    await _context.SaveChangesAsync();
                    StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

                    MessageBox.Show($"{empName} 已接單: {string.Join(", ", pickOrderNames.ToArray())}",
                                    "提示",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有新的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> MaintiWork()
        {
            var tos = _flowData.TaskOrders
                .Where(t => t.Status == OrderStatus.InProgress
                    && (t.Creator != null || (t.Engineers != null && t.Engineers.Any())))
                .ToList();

            if (tos.Any())
            {
                var engs = tos
                    .Where(t => t.CreatorId != null)
                    .SelectMany(t => new[] { (int)t.CreatorId }
                        .Concat(t.Engineers?.Select(e => e.Id) ?? Enumerable.Empty<int>()))
                    .Distinct()
                    .ToList();

                _maintiWork.Orders = tos;
                _maintiWork.Initialize();

                //if (Core.Views.FormEx.ShowDialogWithMask(_maintiWork) == DialogResult.OK)
                if (_maintiWork.ShowDialog() == DialogResult.OK)
                {
                    //var to = _context.TaskOrders.FirstOrDefault(t => t.Id == _acceptFlow.SelectedOrder.Id);
                    //if (to != null)
                    //{
                    //    to.Status = OrderStatus.InProgress;
                    //    var empId = _coreData.Employees.FirstOrDefault(e => e.Id == to.CreatorId)?.Id;
                    //    if (empId != null)
                    //    {
                    //        var t = _context.Employees.Find(empId);
                    //        if (t != null)
                    //            to.Engineer = new List<Employee> { t };
                    //    }
                    //    await _context.SaveChangesAsync();
                    //StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
                    //    MessageBox.Show($"{to.Creator.Name} 已接單: {to.WorkOrderNo}", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //}
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有維護中的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> FlowConfirmed()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.Pending).ToList();
            if (to.Any())
            {


                await _context.SaveChangesAsync();
                StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
            }
            else
            {
                MessageBox.Show("沒有待確認的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return false;
        }
    }
}
