﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Views;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public partial class MaintiFlowService : ITaskOrderAction
    {
        /// <inheritdoc/>
        public async Task<bool> CreateNewFlow()
        {
            _createFlow.Title = "新建工單";

            if (_createFlow.ShowDialog() == DialogResult.OK)
            {
                _taskOrderView.Title = "工單已建立";
                _taskOrderView.NewWorkOrderNos = _createFlow.NewWorkOrderNos;
                _taskOrderView.Initialize();
                FormEx.ShowDialogWithMask(_taskOrderView);
                return true;
            }

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> CancelFlow(int orderId)
        {

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> AcceptFlow(int orderId)
        {

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> FlowCompleted(int orderId)
        {

            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> FlowConfirmed(int orderId)
        {

            return false;
        }
    }
}
