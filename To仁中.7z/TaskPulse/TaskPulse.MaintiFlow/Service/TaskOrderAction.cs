﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Views;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public partial class MaintiFlowService : ITaskOrderAction
    {
        /// <inheritdoc/>
        public bool CreateNewFlow()
        {
            using (var createFlow = _rootScope.Resolve<CreateFlow>())
            {
                createFlow.Title = "新建工單";
                if (createFlow.ShowDialog() == DialogResult.OK)
                {
                    StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

                    using (var taskOrderView = _rootScope.Resolve<TaskOrderView>())
                    {
                        taskOrderView.Title = "工單已建立";
                        taskOrderView.NewWorkOrderNos = createFlow.NewWorkOrderNos;
                        taskOrderView.Initialize();
                        Core.Views.FormEx.ShowDialogWithMask(taskOrderView);
                        return true;
                    }
                }
            }
            return false;
        }

        /// <inheritdoc/>
        public async Task<bool> CancelFlow()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.NewTaskOrder).ToList();
            if (to.Any())
            {
                using (var acceptFlow = _rootScope.Resolve<FT_AcceptFlow>())
                {
                    acceptFlow.Title = "取消工單";
                    acceptFlow.OkCaption = "取消工單";
                    acceptFlow.Orders = to;
                    //if (Core.Views.FormEx.ShowDialogWithMask(acceptFlow) == DialogResult.OK)
                    //{
                    //    //var to = _context.TaskOrders.FirstOrDefault(t => t.Id == acceptFlow.SelectedOrder);
                    //    var to = acceptFlow.SelectedOrder;
                    //    if (to != null)
                    //    {
                    //        to.StatusString = OrderStatus.Completed;
                    //        await _context.SaveChangesAsync();
                    //        StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
                    //    }
                    //}
                    return true;
                }
            }
            else
            {
                MessageBox.Show("無可取消的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> AcceptFlow()
        {
            var tos = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.NewTaskOrder).ToList();
            if (tos.Any())
            {
                using (var acceptFlow = _rootScope.Resolve<FT_AcceptFlow>())
                {
                    acceptFlow.Title = "接單";
                    acceptFlow.OkCaption = "接單";
                    acceptFlow.Orders = tos;
                    if (Core.Views.FormEx.ShowDialogWithMask(acceptFlow) == DialogResult.OK)
                    {
                        TaskOrder to;
                        string empName = default;
                        List<string> pickOrderNames = new List<string>();
                        foreach (string orderId in acceptFlow.SelectedOrder)
                        {
                            to = _context.TaskOrders.FirstOrDefault(t => t.WorkOrderNo == orderId);
                            to.Status = OrderStatus.InProgress;
                            empName = to.CreatorName;
                            pickOrderNames.Add(to.WorkOrderNo);

                            var empId = _coreData.Employees.FirstOrDefault(e => e.Id == to.CreatorId)?.Id;
                            if (empId != null)
                            {
                                var emp = _context.Employees.Find(empId);
                                if (emp != null)
                                {
                                    to.Engineers = new List<Employee> { emp };
                                    StrongReferenceMessenger.Default.Send(new CoreDataChangedNotification(CoreDataType.Employee));
                                }
                            }
                        }
                        await _context.SaveChangesAsync();
                        StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);

                        MessageBox.Show($"{empName} 已接單: {string.Join(", ", pickOrderNames.ToArray())}",
                                        "提示",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有新的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> MaintiWork()
        {
            var tos = _flowData.TaskOrders
                .Where(t => t.Status == OrderStatus.InProgress
                    && (t.Creator != null || (t.Engineers != null && t.Engineers.Any())))
                .ToList();

            if (tos.Any())
            {
                using (var maintiWork = _rootScope.Resolve<FT_MaintiWork>())
                {
                    var engs = tos
                    .SelectMany(t => new[] { t.CreatorId }
                        .Concat(t.Engineers?.Select(e => e.Id) ?? Enumerable.Empty<int>()))
                    .Distinct()
                    .ToList();

                    maintiWork.Orders = tos;
                    maintiWork.Initialize();

                    //if (Core.Views.FormEx.ShowDialogWithMask(maintiWork) == DialogResult.OK)
                    if (maintiWork.ShowDialog() == DialogResult.OK)
                    {
                        //var to = _context.TaskOrders.FirstOrDefault(t => t.Id == acceptFlow.SelectedOrder.Id);
                        //if (to != null)
                        //{
                        //    to.StatusString = OrderStatus.InProgress;
                        //    var empId = _coreData.Employees.FirstOrDefault(e => e.Id == to.CreatorId)?.Id;
                        //    if (empId != null)
                        //    {
                        //        var t = _context.Employees.Find(empId);
                        //        if (t != null)
                        //            to.Engineer = new List<Employee> { t };
                        //    }
                        //    await _context.SaveChangesAsync();
                        //StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
                        //    MessageBox.Show($"{to.CreatorName.Name} 已接單: {to.WorkOrderNo}", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //}
                    }
                }
                return true;
            }
            else
            {
                MessageBox.Show("沒有維護中的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <inheritdoc/>
        public async Task<bool> FlowConfirmed()
        {
            var to = _flowData.TaskOrders.Where(t => t.Status == OrderStatus.Pending).ToList();
            if (to.Any())
            {
                using (var flowConfirmed = _rootScope.Resolve<FT_FlowConfirmed>())
                {


                    await _context.SaveChangesAsync();
                    StrongReferenceMessenger.Default.Send(MaintiFlowDataChangedNotification.Instance);
                }
            }
            else
            {
                MessageBox.Show("沒有待確認的工單", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return false;
        }
    }
}
