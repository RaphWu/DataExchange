﻿using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    public class MaintiFlowService
    {
        private readonly MaintiFlowContext _context;
        private readonly CoreContext _coreContext;

        public MaintiFlowService(MaintiFlowContext context, CoreContext coreContext)
        {
            _context = context;
            _coreContext = coreContext;

            // 註冊使用者切換事件
            StrongReferenceMessenger.Default.Register<CoreDataChangedMessage>(this, (r, m) =>
            {
                UpdateCoreData(m.Value);
            });
            _coreContext = coreContext;
        }

        private void UpdateCoreData(CoreData value)
        {

            var ep = _context.Set<Models.Employee>();
            foreach (var employee in _coreContext.Employees)
                ep.Add(new Models.Employee()
                {
                    EmployeeId = employee.EmployeeId,
                    Name = employee.Name,
                    IsEngineer = employee.IsEngineer,
                });

            //ep.Add(new Employee() { EmployeeId = "08001", Name = "蔡孟堅", IsEngineer = true });
            //ep.Add(new Employee() { EmployeeId = "08002", Name = "鄭大德", IsEngineer = true });
            //ep.Add(new Employee() { EmployeeId = "08003", Name = "李起修", IsEngineer = true });
            //ep.Add(new Employee() { EmployeeId = "08004", Name = "葉柏均", IsEngineer = true });
            //ep.Add(new Employee() { EmployeeId = "08005", Name = "曾惠鈴", IsEngineer = true });
            //ep.Add(new Employee() { EmployeeId = "08006", Name = "蔡素貞" });
            //ep.Add(new Employee() { EmployeeId = "08007", Name = "張志榮" });
            //ep.Add(new Employee() { EmployeeId = "08008", Name = "賴惠珠" });
            //ep.Add(new Employee() { EmployeeId = "08009", Name = "侯倩玉" });
            //ep.Add(new Employee() { EmployeeId = "08010", Name = "李雅婷" });
            //ep.Add(new Employee() { EmployeeId = "08011", Name = "彭紹軒" });
            //ep.Add(new Employee() { EmployeeId = "08012", Name = "黎氏鳳" });
            //ep.Add(new Employee() { EmployeeId = "08013", Name = "阮碧幸" });
            //ep.Add(new Employee() { EmployeeId = "08014", Name = "盧海燕" });
            //ep.Add(new Employee() { EmployeeId = "08015", Name = "余沂霈" });
            //ep.Add(new Employee() { EmployeeId = "08016", Name = "楊瓊瑛" });
            //ep.Add(new Employee() { EmployeeId = "08017", Name = "陳寶琴" });
            //ep.Add(new Employee() { EmployeeId = "08018", Name = "劉名峻" });
            //ep.Add(new Employee() { EmployeeId = "08019", Name = "黃琪雯" });
            //ep.Add(new Employee() { EmployeeId = "08020", Name = "黃姿蓉" });
            //ep.Add(new Employee() { EmployeeId = "08021", Name = "林承翰" });
            //ep.Add(new Employee() { EmployeeId = "08022", Name = "雷舒涵" });
            //ep.Add(new Employee() { EmployeeId = "08023", Name = "黃嘉惠" });
            //ep.Add(new Employee() { EmployeeId = "08024", Name = "蔡素真" });
            //ep.Add(new Employee() { EmployeeId = "08025", Name = "黃玉紅" });
            //ep.Add(new Employee() { EmployeeId = "08026", Name = "許凱婷" });
            //ep.Add(new Employee() { EmployeeId = "08027", Name = "林昆達" });
            //ep.Add(new Employee() { EmployeeId = "08028", Name = "晉玉樹" });
            //ep.Add(new Employee() { EmployeeId = "08029", Name = "謝定傑", IsEngineer = true });

            _context.SaveChanges();
        }
    }
}
