﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Contract;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using Calin.TaskPulse.MaintiFlow.Views;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI.Win32;

namespace Calin.TaskPulse.MaintiFlow.Service
{
    /// <summary>
    /// 維護工單服務。
    /// </summary>
    public partial class MaintiFlowService : IDisposable, IMaintiFlow
    {
        private readonly CoreContext _context;
        private readonly CurrentAuthority _authority;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;
        private readonly FieldName _fieldName;
        private readonly FieldTitle _fieldTitle;

        private readonly CreateFlow _createFlow;
        private readonly TaskOrderView _taskOrderView;
        private readonly FT_AcceptFlow _acceptFlow;
        private readonly FT_MaintiWork _maintiWork;
        private readonly FT_FlowConfirmed _flowConfirmed;

        private bool _isInitialized = false;

        public MaintiFlowService(CoreContext coreContext,
                                 CurrentAuthority currentAuthority,
                                 CoreData coreData,
                                 MaintiFlowData maintiFlowData,
                                 FieldName fieldName,
                                 FieldTitle fieldTitle,
                                 CreateFlow createFlow,
                                 TaskOrderView taskOrderView,
                                 FT_AcceptFlow fT_AcceptFlow,
                                 FT_MaintiWork fT_MaintiWork,
                                 FT_FlowConfirmed fT_FlowConfirmed)
        {
            _context = coreContext;
            _authority = currentAuthority;
            _coreData = coreData;
            _flowData = maintiFlowData;
            _fieldName = fieldName;
            _fieldTitle = fieldTitle;

            _createFlow = createFlow;
            _taskOrderView = taskOrderView;
            _acceptFlow = fT_AcceptFlow;
            _maintiWork = fT_MaintiWork;
            _flowConfirmed = fT_FlowConfirmed;
        }

        /// <summary>
        /// 釋放註冊的事件。
        /// </summary>
        public void Dispose()
        {
            StrongReferenceMessenger.Default.Unregister<CoreDataChangedNotification>(this);
            StrongReferenceMessenger.Default.Unregister<MaintiFlowDataChangedNotification>(this);
        }

        /// <inheritdoc/>
        public async Task Initialize()
        {
            if (_isInitialized)
                return;

            //UpdateModelsCache();

            //_flowData.Engineer = _coreData.Employees
            //    .Where(e => e.IsEngineer)
            //    .Select(e => new Engineer
            //    {
            //        EmployeeId = e.EmployeeId,
            //        UnitName = e.UnitName,
            //        Department = e.Department,
            //        Title = e.Title
            //    })
            //    .ToList();

            _fieldName.WorkOrderNo = nameof(TaskOrder.WorkOrderNo);
            _fieldName.Status = nameof(TaskOrder.Status);
            _fieldName.Machine = nameof(TaskOrder.Machine);
            _fieldName.MachineCode = nameof(TaskOrder.MachineCode);
            _fieldName.FullMachineName = nameof(TaskOrder.FullMachineName);
            _fieldName.Model = nameof(Model.ModelName);
            _fieldName.Workstation = nameof(TaskOrder.Workstation);
            _fieldName.Creator = nameof(TaskOrder.Creator);
            _fieldName.CreatorFullName = nameof(TaskOrder.CreatorFullName);
            _fieldName.CreationDate = nameof(TaskOrder.CreationDate);
            _fieldName.CreationDateString = nameof(TaskOrder.CreationDateString);

            _fieldName.MaintenanceUnit = nameof(TaskOrder.MaintenanceUnit);
            _fieldName.UnitString = nameof(TaskOrder.UnitString);
            _fieldName.Engineers = nameof(TaskOrder.Engineers);
            _fieldName.EngineerString = nameof(TaskOrder.EngineerString);
            _fieldName.EngineerList = nameof(TaskOrder.EngineerList);
            _fieldName.AcceptedTime = nameof(TaskOrder.AcceptedTime);
            _fieldName.AcceptedTimeString = nameof(TaskOrder.AcceptedTimeString);
            _fieldName.IssueCategory = nameof(TaskOrder.IssueCategory);
            _fieldName.IssueCategoryString = nameof(TaskOrder.IssueCategoryString);
            _fieldName.IssueDescription = nameof(TaskOrder.IssueDescription);
            _fieldName.Details = nameof(TaskOrder.Details);
            _fieldName.RepairStarted = nameof(TaskOrder.RepairStarted);
            _fieldName.RepairStartedString = nameof(TaskOrder.RepairStartedString);
            _fieldName.RepairCompleted = nameof(TaskOrder.RepairCompleted);
            _fieldName.RepairCompletedString = nameof(TaskOrder.RepairCompletedString);
            _fieldName.RepairDurationTick = nameof(TaskOrder.RepairDurationTick);
            _fieldName.RepairDuration = nameof(TaskOrder.RepairDuration);
            _fieldName.RepairDurationString = nameof(TaskOrder.RepairDurationString);
            _fieldName.FillingTime = nameof(TaskOrder.FillingTime);
            _fieldName.FillingTimeString = nameof(TaskOrder.FillingTimeString);

            _fieldName.RequestingUnit = nameof(TaskOrder.RequestingUnit);
            _fieldName.RequestingUnitString = nameof(TaskOrder.RequestingUnitString);
            _fieldName.RequestingEmployee = nameof(TaskOrder.RequestingEmployee);
            _fieldName.RequestingEmployeeString = nameof(TaskOrder.RequestingEmployeeString);
            _fieldName.Response = nameof(TaskOrder.Response);
            _fieldName.OutageStarted = nameof(TaskOrder.OutageStarted);
            _fieldName.OutageStartedString = nameof(TaskOrder.OutageStartedString);
            _fieldName.OutageEnded = nameof(TaskOrder.OutageEnded);
            _fieldName.OutageEndedString = nameof(TaskOrder.OutageEndedString);
            _fieldName.OutageDurationTick = nameof(TaskOrder.OutageDurationTick);
            _fieldName.OutageDuration = nameof(TaskOrder.OutageDuration);
            _fieldName.OutageDurationString = nameof(TaskOrder.OutageDurationString);

            _fieldName.Responsible = nameof(TaskOrder.Responsible);
            _fieldName.OrderNo = nameof(TaskOrder.OrderNo);

            _fieldTitle.WorkOrderNo = EnumHelper.GetDescription<TaskOrder>(_fieldName.WorkOrderNo);
            _fieldTitle.Status = EnumHelper.GetDescription<TaskOrder>(_fieldName.Status);
            _fieldTitle.Machine = EnumHelper.GetDescription<TaskOrder>(_fieldName.Machine);
            _fieldTitle.Model = EnumHelper.GetDescription<Model>(_fieldName.Model);
            _fieldTitle.Workstation = EnumHelper.GetDescription<TaskOrder>(_fieldName.Workstation);
            _fieldTitle.Creator = EnumHelper.GetDescription<TaskOrder>(_fieldName.Creator);
            _fieldTitle.CreationDate = EnumHelper.GetDescription<TaskOrder>(_fieldName.CreationDate);

            _fieldTitle.MaintenanceUnit = EnumHelper.GetDescription<TaskOrder>(_fieldName.MaintenanceUnit);
            _fieldTitle.Engineer = EnumHelper.GetDescription<TaskOrder>(_fieldName.Engineers);
            _fieldTitle.AcceptedTime = EnumHelper.GetDescription<TaskOrder>(_fieldName.AcceptedTime);
            _fieldTitle.IssueCategory = EnumHelper.GetDescription<TaskOrder>(_fieldName.IssueCategory);
            _fieldTitle.IssueDescription = EnumHelper.GetDescription<TaskOrder>(_fieldName.IssueDescription);
            _fieldTitle.Details = EnumHelper.GetDescription<TaskOrder>(_fieldName.Details);
            _fieldTitle.RepairStarted = EnumHelper.GetDescription<TaskOrder>(_fieldName.RepairStarted);
            _fieldTitle.RepairCompleted = EnumHelper.GetDescription<TaskOrder>(_fieldName.RepairCompleted);
            _fieldTitle.RepairDuration = EnumHelper.GetDescription<TaskOrder>(_fieldName.RepairDuration);
            _fieldTitle.FillingTime = EnumHelper.GetDescription<TaskOrder>(_fieldName.FillingTime);

            _fieldTitle.RequestingUnit = EnumHelper.GetDescription<TaskOrder>(_fieldName.RequestingUnit);
            _fieldTitle.RequestingEmployee = EnumHelper.GetDescription<TaskOrder>(_fieldName.RequestingEmployee);
            _fieldTitle.Response = EnumHelper.GetDescription<TaskOrder>(_fieldName.Response);
            _fieldTitle.OutageStarted = EnumHelper.GetDescription<TaskOrder>(_fieldName.OutageStarted);
            _fieldTitle.OutageEnded = EnumHelper.GetDescription<TaskOrder>(_fieldName.OutageEnded);
            _fieldTitle.OutageDuration = EnumHelper.GetDescription<TaskOrder>(_fieldName.OutageDuration);

            _fieldTitle.Responsible = EnumHelper.GetDescription<TaskOrder>(_fieldName.Responsible);
            _fieldTitle.OrderNo = EnumHelper.GetDescription<TaskOrder>(_fieldName.OrderNo);

            // 註冊核心共用資料更新訊息。
            StrongReferenceMessenger.Default.Register<CoreDataChangedNotification>(this, async (r, m) =>
            {
                await UpdateCache();
            });
            StrongReferenceMessenger.Default.Register<MaintiFlowDataChangedNotification>(this, async (r, m) =>
            {
                await UpdateCache();
            });

            await UpdateCache();
            _isInitialized = true;
        }

        /// <inheritdoc/>
        public async Task UpdateCache()
        {
            _flowData.TaskOrders = await _context.TaskOrders
                .Include(t => t.Machine)
                .Include(t => t.Workstation.Model)
                .Include(t => t.Creator.Department)
                .Include(t => t.Engineers)
                .Include(t => t.MaintenanceUnit)
                .Include(t => t.IssueCategory)
                .Include(t => t.RequestingUnit)
                .Include(t => t.RequestingEmployee)
                .AsNoTracking()
                .ToListAsync();

            StrongReferenceMessenger.Default.Send(MaintiFlowCacheChangedNotification.Instance);
        }
    }
}
