﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Autofac;
using Calin.CSharp.Helpers;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Authority;
using Calin.TaskPulse.Core.Authority.Models;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.MaintiFlow.Views;
using Calin.TaskPulse.MechaTrack.Views;
using Calin.TaskPulse.ToolQuest.Views;
using Calin.TaskPulse.Views;
using Calin.WinForm;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse
{
    public partial class MainForm : UIForm
    {
        private readonly PageManager _pageManager;
        private readonly IAuthority _authority;
        private readonly ILifetimeScope _lifetimeScope;

        private bool _isAdmin = false;
        private bool _isGuest = false;

        private PageCode _currentNavItem = PageCode.None; // 目前選單項目

        private readonly System.Windows.Forms.Timer _idleTimer; // 無動作計時器
        private bool _idleTriggered = false; // 是否已經觸發過

        public MainForm(IAuthority authority, ILifetimeScope lifetimeScope)
        {
            InitializeComponent();
            _authority = authority;
            _lifetimeScope = lifetimeScope;

            _pageManager = new PageManager(lifetimeScope, this);

            // 註冊使用者切換事件
            StrongReferenceMessenger.Default.Register<LoggedInUserChangedMessage>(this, (r, m) =>
            {
                SetAuthority(m.Value);
            });

            //註冊頁面切換事件
            StrongReferenceMessenger.Default.Register<ProcessBarMessage>(this, (r, m) =>
            {
                SetProcessBar(m.Value);
            });

            CommonStyles.SetStyles();

            // 固定的選單 (設定)
            const string userMenuName = "userMenuItem";
            int pageIndex = (int)PageCode.User;
            TreeNode node1 = rNavBar.CreateNode(PageCode.User.GetDescription(), pageIndex);
            lNavBar.SetNodePageIndex(node1, pageIndex);
            lNavBar.SetNodeSymbol(node1, 361459);
            node1.Name = userMenuName;
            node1.Tag = pageIndex;

#if DEBUG
            // 管理員模式方便測試
            _authority.SwitchAuthority("admin", CSharp.Security.MD5.GetMD5Hash(""));

            //var core = scope.Resolve<ICore>();
            //core.UpdateModelsCache();
#else
            // 訪客模式
            Logout();
#endif

            ResizeScreen();

            _idleTimer = new Timer { Interval = 2000 };
            _idleTimer.Tick += idleTimer_Tick;
            // 先關閉功能 _idleTimer.Start();
        }

        private void SetProcessBar(int value)
        {
            if (value < 0)
            {
                uiProcessBar.ShowValue = false;
            }
            else
            {
                if (!uiProcessBar.ShowValue)
                    uiProcessBar.ShowValue = true;
                uiProcessBar.Value = value;
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            UISettings.ApplyGlobalFont(this);

            //this.MouseMove += OnUserInput;
            //this.KeyDown += OnUserInput;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.KeyDown -= OnUserInput;
            this.MouseMove -= OnUserInput;

            StrongReferenceMessenger.Default.UnregisterAll(this);
            _pageManager.DisposeAll();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
        }

        /// <summary>
        /// 調整視窗大小。
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1440;
            const int TARGET_HEIGHT = 900;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        /********************
         * 操作模式 & 頁面載入
         ********************/
        /// <summary>
        /// 因應權限變更，設定相關選單與頁面。
        /// </summary>
        /// <param name="authority">目前使用者的權限表。</param>
        private void SetAuthority(CurrentAuthority authority)
        {
            TreeNode node1, node2;
            int pageIndex;

            _isAdmin = authority.IsAdmin;
            _isGuest = authority.IsGuest;

            /********************
             * 右側副選單
             ********************/
            // 使用者選單
            node1 = rNavBar.Nodes[0];
            node1.Text = authority.CurrentUserTitle;
            node1.Nodes.Clear();

            if (_isAdmin)
            {
                node1.BackColor = Color.Red;
                node1.ForeColor = Color.Red;
                rNavBar.SetNodeSymbol(node1, 362718);
            }
            else if (_isGuest)
            {
                node1.ForeColor = Color.Gray;
                rNavBar.SetNodeSymbol(node1, 362720);
            }
            else
            {
                node1.ForeColor = Color.Green;
                rNavBar.SetNodeSymbol(node1, 362716);
            }

            // 使用者選單 -> 登入/登出
            if (_isGuest)
            {
                pageIndex = (int)PageCode.Login;
                node2 = rNavBar.CreateChildNode(node1, PageCode.Login.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 560023);
                node2.Tag = pageIndex;
            }
            else
            {
                pageIndex = (int)PageCode.Logout;
                node2 = rNavBar.CreateChildNode(node1, PageCode.Logout.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 559834);
                node2.Tag = pageIndex;

                pageIndex = (int)PageCode.SwitchUser;
                node2 = rNavBar.CreateChildNode(node1, PageCode.SwitchUser.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 362720);
                node2.Tag = pageIndex;
            }

            // 設定
            if (_isAdmin)
            {
                pageIndex = (int)PageCode.Setup;
                _pageManager.AddOrReplacePage<SetupPage>(pageIndex);
                node2 = rNavBar.CreateChildNode(node1, PageCode.Setup.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 361459);
                node2.Tag = pageIndex;
            }

            rNavBar.Refresh();

            /********************
             * 左側主選單
             ********************/
            lNavBar.Nodes.Clear();
            uiTabControl.RemoveAllPages();

            //// 主頁面
            //pageIndex = (int)PageCode.MainPage;
            //_pageManager.AddOrReplacePage<MainPage>(pageIndex);
            //node1 = lNavBar.CreateNode(PageCode.MainPage.GetDescription(), pageIndex);
            //lNavBar.SetNodePageIndex(node1, pageIndex);
            //lNavBar.SetNodeSymbol(node1, 559530);
            //node1.Tag = pageIndex;

            // 維護工單
            if (authority.IsAdmin || authority.CurrentAuthotization.MechaTrack)
            {
                pageIndex = (int)PageCode.MaintiFlowMain;
                _pageManager.AddOrReplacePage<MaintiFlowPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.MaintiFlowMain.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 361613);
                node1.Tag = pageIndex;
            }

            // 專案管理
            if (authority.IsAdmin || authority.CurrentAuthotization.MechaTrack)
            {
                pageIndex = (int)PageCode.MechaTrack;
                _pageManager.AddOrReplacePage<MechaTrackPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.MechaTrack.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 261474);
                node1.Tag = pageIndex;
            }

            // 工具委託
            if (authority.IsAdmin || authority.CurrentAuthotization.ToolQuest)
            {
                pageIndex = (int)PageCode.ToolQuest;
                _pageManager.AddOrReplacePage<ToolQuestPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.ToolQuest.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 362133);
                node1.Tag = pageIndex;
            }

            //// 設定
            //pageIndex = (int)PageCode.Setup;
            //_pageManager.AddOrReplacePage<SetupPage>(pageIndex);
            //node1 = lNavBar.CreateNode(PageCode.Setup.GetDescription(), pageIndex);
            //lNavBar.SetNodePageIndex(node1, pageIndex);
            //lNavBar.SetNodeSymbol(node1, 361459);
            //node1.Tag = pageIndex;

            if (lNavBar.SelectedIndex == -1)
                lNavBar.SelectedIndex = 0;

            lNavBar.SelectedIndex = 0;
            lNavBar.Refresh();
            uiTabControl.Refresh();

            if (_isGuest) // 設定無動作偵測
                _idleTriggered = false;
        }

        /// <summary>
        /// 登入對話框。
        /// </summary>
        private void Login()
        {
            DialogInfo user = new DialogInfo();
            using (var dlg = new UserLogin())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    user = dlg.DialogInfo;
                    var ret = _authority.Authenticate(user.NewName, user.NewPassword);
                }
            }

            //using (var scope = _lifetimeScope.BeginLifetimeScope())
            //{
            //    var authority = scope.Resolve<IAuthority>();
            //    if (!authority.SwitchAuthorityByDialog())
            //    {
            //        SetAuthority(scope.Resolve<CurrentAuthority>());
            //    }
            //}
        }

        /// <summary>
        /// 登出。
        /// </summary>
        private void Logout()
        {
            using (var scope = _lifetimeScope.BeginLifetimeScope())
            {
                var authority = scope.Resolve<IAuthority>();
                authority.SwitchAuthorityToGuest();
            }
        }

        /// <summary>
        /// 點擊右選單。
        /// </summary>
        /// <param name="itemText">選單文字。</param>
        /// <param name="menuIndex">選項索引。</param>
        /// <param name="pageIndex">頁面索引。</param>
        private void uiNavBar_Right_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            if (Enum.TryParse(pageIndex.ToString(), out PageCode pageCode))
            {
                switch (pageCode)
                {
                    case PageCode.Login:
                        Login();
                        break;

                    case PageCode.Logout:
                        Logout();
                        break;

                    case PageCode.SwitchUser:
                        Login();
                        break;

                    case PageCode.Setup:
                        SelectPage(pageIndex);
                        break;
                }
            }
        }

        /// <summary>
        /// 點擊導覽列選單。
        /// </summary>
        /// <param name="itemText">選單文字。</param>
        /// <param name="menuIndex">選項索引。</param>
        /// <param name="pageIndex">頁面索引。</param>
        private void uiNavBar_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            SwitchPage(pageIndex);
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageCode">頁面代碼。</param>
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentNavItem == pageCode && PageCode.Login != pageCode)
                return;

            SwitchPage((int)pageCode);
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageIndex">頁面索引。</param>
        private void SwitchPage(int pageIndex)
        {
            if (Enum.TryParse(pageIndex.ToString(), out PageCode pageCode))
            {
                switch (pageCode)
                {
                    case PageCode.MainPage:
                    case PageCode.ToolQuest:
                    case PageCode.MechaTrack:
                    case PageCode.MaintiFlowMain:
                        SelectPage(pageIndex);
                        break;
                }
            }
        }

        ///// <summary>
        ///// 載入頁面。
        ///// </summary>
        ///// <param name="page">頁面物件。</param>
        //private void LoadPage(UIForm page)
        //{
        //    uiPanel_Content.Controls.Clear();
        //    if (page != null)
        //    {

        //        page.Dock = DockStyle.Fill;
        //        uiPanel_Content.Controls.Add(page);
        //    }
        //}

        /********************
         * 無動作偵測
         ********************/
        private void OnUserInput(object sender, EventArgs e)
        {
            // ResetIdleTimer
            if (!_isGuest) return;

            _idleTimer.Stop();
            _idleTimer.Start();
            _idleTriggered = false;
        }

        private void idleTimer_Tick(object sender, EventArgs e)
        {
            if (!_idleTriggered)
            {
                _idleTriggered = true;
                Login();
            }
        }

        /********************
         * 系統事件
         ********************/
        private void clockTimer_Tick(object sender, EventArgs e)
        {
            Clock.Text = DateTime.Now.DateTimeString();
        }
    }
}
