﻿```mermaid
classDiagram
%% Calin.TaskPulse.Entity.Core
class Workstation { +int Id }
class Model { +int Id }
class ModelStatus { +int Id }
class MachineCategory { +int Id }
class MachineType { +int Id }
class MachineName { +int Id }
class Machine { +int Id }
class MachineCondition { +int Id }
class MachineBrand { +int Id }
class MachineLocation { +int Id }
class Employee { +int Id }
class Department { +int Id }
class JobTitle { +int Id }
class UserGroup { +int Id }
class EmployeeStatus { +int Id }
class Permission { +int Id }

%% Calin.TaskPulse.Entity.MaintiFlow
class TaskOrder { +int Id }
class IssueCategory { +int Id }
class MaintenanceUnit { +int Id }

%% Core namespace relationships
ModelStatus "1" <-- "0..*" Model : models
Model "1" <-- "0..*" Workstation : workstations
MachineCategory "1" <-- "0..*" MachineType : machineTypes
MachineType "1" <-- "0..*" MachineName : machineNames
MachineName "1" <-- "0..*" Machine : machines
MachineCondition "1" <-- "0..*" Machine : machines
MachineBrand "0..1" <-- "0..*" Machine : machines
MachineLocation "0..1" <-- "0..*" Machine : machines
Machine "0..*" -- "0..*" Workstation : machines_workstations

Department "1" <-- "0..*" Employee : employees
JobTitle "1" <-- "0..*" Employee : employees
EmployeeStatus "1" <-- "0..*" Employee : employees

%% Permissions & groups (many-to-many)
Employee "0..*" -- "0..*" Permission : permissions
Department "0..*" -- "0..*" Permission : permissions
UserGroup "0..*" -- "0..*" Permission : permissions
UserGroup "1" <-- "0..*" Employee : members

%% Employee self relation (carbon copies)
Employee "0..*" -- "0..*" Employee : carbonCopies

%% MaintiFlow relationships
Workstation "1" <-- "0..*" TaskOrder : taskOrders
Machine "0..1" <-- "0..*" TaskOrder : taskOrders
TaskOrder "0..*" -- "1" Employee : creator
TaskOrder "0..*" -- "0..*" Employee : engineers
TaskOrder "0..*" -- "0..1" MaintenanceUnit : maintenanceUnit
TaskOrder "0..*" -- "0..1" IssueCategory : issueCategory
TaskOrder "0..*" -- "0..1" Department : requestingUnit
TaskOrder "0..*" -- "0..1" Employee : feedbackEmployee
```