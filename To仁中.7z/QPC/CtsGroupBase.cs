﻿using System;
using System.Threading;

namespace QPC
{
    public abstract class CtsGroupBase : IDisposable
    {
        private CancellationTokenSource _cts;

        protected CancellationToken Token => _cts.Token;

        protected CtsGroupBase()
        {
            CreateNewCts();
        }

        protected void CreateNewCts()
        {
            _cts?.Dispose();
            _cts = new CancellationTokenSource();
        }

        public void CancelAll()
        {
            if (_cts == null || _cts.IsCancellationRequested)
                return;

            _cts.Cancel();
        }

        public void RestartAll()
        {
            CancelAll();
            CreateNewCts();
            OnRestart();
        }

        protected abstract void OnRestart();

        public void Dispose()
        {
            _cts?.Cancel();
            _cts?.Dispose();
        }
    }
}
