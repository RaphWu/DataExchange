﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QPC
{
    /// <summary>
    /// 表單的主類別，負責初始化計時器和處理高解析度計時相關邏輯。
    /// </summary>
    public partial class Form1 : Form
    {
        private CancellationTokenSource _cts;
        private CancellationToken Token => _cts.Token;

        private WinTimer _winFormTimer;
        private UltraHighAccurateTimer _ultraHighAccurateTimer;
        private HighAccurateTimer _highAccurateTimer;

        private BindingList<string> _bsWinTimer = new BindingList<string>();
        private BindingList<string> _bsUltraHighAccurateTimer = new BindingList<string>();
        private BindingList<string> _bsHighAccurateTimer = new BindingList<string>();

        private Stopwatch _stopwatch;

        /// <summary>
        /// 指示是否支援高解析度計時。
        /// </summary>
        private bool _isHighResolution = false;

        /// <summary>
        /// 計時器的頻率（每秒的計數）。
        /// </summary>
        private long _frequency;

        /// <summary>
        /// 每個計數對應的奈秒數。
        /// </summary>
        private long _nanosecPerTick;

        public Form1()
        {
            InitializeComponent();

            ResetData();

            var _dgvWinTimer = new BufferedDataGridView()
            {
                Dock = DockStyle.Fill
            };
            panel1.Controls.Add(_dgvWinTimer);
            _dgvWinTimer.VirtualMode = true;
            _dgvWinTimer.ReadOnly = true;
            _dgvWinTimer.AllowUserToAddRows = false;
            _dgvWinTimer.AllowUserToDeleteRows = false;
            _dgvWinTimer.RowHeadersVisible = false;
            _dgvWinTimer.AutoGenerateColumns = false;
            _dgvWinTimer.DataSource = _bsWinTimer;

            var _dgvUltraHighAccurateTimer = new BufferedDataGridView()
            {
                Dock = DockStyle.Fill
            };
            panel2.Controls.Add(_dgvUltraHighAccurateTimer);
            _dgvUltraHighAccurateTimer.VirtualMode = true;
            _dgvUltraHighAccurateTimer.ReadOnly = true;
            _dgvUltraHighAccurateTimer.AllowUserToAddRows = false;
            _dgvUltraHighAccurateTimer.AllowUserToDeleteRows = false;
            _dgvUltraHighAccurateTimer.RowHeadersVisible = false;
            _dgvUltraHighAccurateTimer.AutoGenerateColumns = false;
            _dgvUltraHighAccurateTimer.DataSource = _bsUltraHighAccurateTimer;

            var _dgvHighAccurateTimer = new BufferedDataGridView()
            {
                Dock = DockStyle.Fill
            };
            panel3.Controls.Add(_dgvHighAccurateTimer);
            _dgvHighAccurateTimer.VirtualMode = true;
            _dgvHighAccurateTimer.ReadOnly = true;
            _dgvHighAccurateTimer.AllowUserToAddRows = false;
            _dgvHighAccurateTimer.AllowUserToDeleteRows = false;
            _dgvHighAccurateTimer.RowHeadersVisible = false;
            _dgvHighAccurateTimer.AutoGenerateColumns = false;
            _dgvHighAccurateTimer.DataSource = _bsHighAccurateTimer;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _cts?.Cancel();
            _cts?.Dispose();
            base.OnFormClosing(e);
        }

        private void ResetData()
        {
            _bsWinTimer.Clear();
            _bsUltraHighAccurateTimer.Clear();
            _bsHighAccurateTimer.Clear();
        }

        private void CreateNewCts()
        {
            _cts?.Dispose();
            _cts = new CancellationTokenSource();
        }

        private void CreateWorkers()
        {
            _winFormTimer = new WinTimer(Token);
            _winFormTimer.Tick += (sender) =>
            {
                _bsWinTimer.Add(_winFormTimer.)
            };

            var dgvultraHighAccurateTimer = new UltraHighAccurateTimer(Token);
            dgvultraHighAccurateTimer.Tick += (sender) =>
            {
                // Handle UltraHighAccurateTimer tick event
            };

            var dgvhighAccurateTimer = new HighAccurateTimer(Token);
            dgvhighAccurateTimer.Tick += (sender) =>
            {
                // Handle HighAccurateTimer tick event
            };
        }

        private void StartAll()
        {
            CreateNewCts();
            CreateWorkers();

            _winFormTimer.Start();
            _ultraHighAccurateTimer.Start();
            _highAccurateTimer.Start();

            _stopwatch.Restart();
        }

        private void CancelAll()
        {
            if (_cts != null && _cts.IsCancellationRequested)
                return;

            _cts?.Cancel();

            _stopwatch.Stop();

            _winFormTimer.Start();
            _ultraHighAccurateTimer.Start();
            _highAccurateTimer.Start();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            StartAll();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            CancelAll();
        }
    }
}
