﻿using System.Threading;

namespace QPC
{
    public abstract class CtsBase
    {
        protected CancellationToken Token { get; }

        protected CtsBase(CancellationToken token)
        {
            Token = token;
        }

        public abstract void Start();
    }
}
