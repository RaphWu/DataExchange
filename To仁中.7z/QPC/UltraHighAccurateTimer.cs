﻿using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Threading;

namespace QPC
{
    /// <summary>
    /// 手動計時器類別，透過迴圈模擬計時器功能。
    /// 使用執行緒池創建新執行緒，並將執行緒優先級設置為最高以確保精確度。
    /// Nocky Tian @ 2008-3-16
    /// </summary>
    public class UltraHighAccurateTimer : CtsBase
    {
        public delegate void ManualTimerEventHandler(object sender);
        public event ManualTimerEventHandler Tick;

        /// <summary>
        /// 記錄 QueryPerformanceFrequency() 的結果。
        /// </summary>
        private long clockFrequency;

        /// <summary>
        /// 指示計時器是否正在運行。
        /// </summary>
        //private bool running = false;

        /// <summary>
        /// 計時器的執行緒。
        /// </summary>
        private Thread timerThread;

        /// <summary>
        /// 計時器的間隔時間（ms）。
        /// </summary>
        private int intervalMs;

        /// <summary>
        /// 設定或取得計時器的間隔時間（ms）。
        /// </summary>
        public int Interval
        {
            get { return intervalMs; }
            set
            {
                intervalMs = value;
                intevalTicks = (long)((double)value * (double)clockFrequency / (double)1000);
            }
        }

        /// <summary>
        /// 記錄計時器的間隔時間（以計數為單位）。
        /// </summary>
        private long intevalTicks;

        /// <summary>
        /// 使用 P/Invoke 調用 QueryPerformanceCounter 函數以取得當前性能計數器值。
        /// </summary>
        /// <param name="lpPerformanceCount">接收當前性能計數器值的變數。</param>
        /// <returns>如果成功，返回 true；否則返回 false。</returns>
        [DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

        /// <summary>
        /// 使用 P/Invoke 調用 QueryPerformanceFrequency 函數以取得性能計數器的頻率。
        /// </summary>
        /// <param name="lpFrequency">接收性能計數器頻率的變數。</param>
        /// <returns>如果成功，返回 true；否則返回 false。</returns>
        [DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceFrequency(out long lpFrequency);

        /// <summary>
        /// 初始化 <see cref="UltraHighAccurateTimer"/> 類別的新執行個體。
        /// </summary>
        /// <exception cref="Win32Exception">當 QueryPerformanceFrequency() 不被支援時拋出。</exception>
        public UltraHighAccurateTimer(CancellationToken token) : base(token)
        {
            if (QueryPerformanceFrequency(out clockFrequency) == false)
            {
                throw new Win32Exception("QueryPerformanceFrequency() 函數不被支援");
            }
        }

        /// <summary>
        /// 計時器的主執行緒邏輯。
        /// </summary>
        private void ThreadProc(CancellationToken token)
        {
            GetTick(out long currTime);

            // 設定下一次觸發的時間
            long nextTriggerTime = currTime + intevalTicks;

            while (!token.IsCancellationRequested)
            {
                while (currTime < nextTriggerTime)
                    GetTick(out currTime);

                // 更新下一次觸發的時間
                nextTriggerTime = currTime + intevalTicks;
                Tick?.Invoke(this);
            }
        }

        /// <summary>
        /// 取得當前的性能計數器值。
        /// </summary>
        /// <param name="currentTickCount">接收當前性能計數器值的變數。</param>
        /// <returns>如果成功，返回 true；否則拋出例外。</returns>
        /// <exception cref="Win32Exception">當 QueryPerformanceCounter() 失敗時拋出。</exception>
        public bool GetTick(out long currentTickCount)
        {
            if (QueryPerformanceCounter(out currentTickCount) == false)
                throw new Win32Exception("QueryPerformanceCounter() 失敗！");
            else
                return true;
        }

        /// <summary>
        /// 啟動計時器。
        /// </summary>
        public override void Start()
        {
            if (Token.IsCancellationRequested)
                return;

            timerThread = new Thread(() => ThreadProc(Token));
            timerThread.Name = "HighAccuracyTimer";
            timerThread.IsBackground = true;
            timerThread.Priority = ThreadPriority.Highest;
            timerThread.Start();
        }
    }
}
