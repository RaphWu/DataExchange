﻿using System;

namespace Calin.SerialPort
{
    /// <summary>
    /// SerialPort 狀態變更事件參數。
    /// </summary>
    public class SerialPortStateChangedEventArgs : EventArgs
    {
        /// <summary>
        /// 取得 SerialPort 的名稱。
        /// </summary>
        public string PortName { get; }

        /// <summary>
        /// 取得之前的狀態。
        /// </summary>
        public SerialPortState OldState { get; }

        /// <summary>
        /// 取得新的狀態。
        /// </summary>
        public SerialPortState NewState { get; }

        /// <summary>
        /// 取得錯誤訊息（如果有）。
        /// </summary>
        public string ErrorMessage { get; }

        /// <summary>
        /// 建立 SerialPort 狀態變更事件參數。
        /// </summary>
        public SerialPortStateChangedEventArgs(string portName, SerialPortState oldState, SerialPortState newState, string errorMessage = null)
        {
            PortName = portName;
            OldState = oldState;
            NewState = newState;
            ErrorMessage = errorMessage;
        }
    }
}