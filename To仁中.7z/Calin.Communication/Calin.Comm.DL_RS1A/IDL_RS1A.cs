﻿using System;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// Keyence DL-RS1A RS-232 通訊介面。
    /// </summary>
    public interface IDL_RS1A : IDL_RS1A_GT2_Commands, IDisposable
    {
        /// <summary>
        /// 取得是否已連線。
        /// </summary>
        bool IsConnected { get; }

        /// <summary>
        /// 開啟連線。
        /// </summary>
        /// <returns>是否成功開啟。</returns>
        bool Open();

        /// <summary>
        /// 關閉連線。
        /// </summary>
        void Close();

        /// <summary>
        /// 回應接收事件。
        /// </summary>
        event EventHandler<DL_RS1A_ResponseEventArgs> ResponseReceived;

        /// <summary>
        /// 錯誤發生事件。
        /// </summary>
        event EventHandler<DL_RS1A_ErrorEventArgs> ErrorOccurred;
    }
}
