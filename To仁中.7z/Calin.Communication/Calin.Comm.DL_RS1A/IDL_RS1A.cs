﻿using System;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// Keyence DL-RS1A RS-232 通訊介面。
    /// </summary>
    public interface IDL_RS1A : IDL_RS1A_GT2_Commands, IDisposable
    {
        /// <summary>
        /// 取得是否已連線。
        /// </summary>
        bool IsConnected { get; }

        /// <summary>
        /// 取得傳輸驗證是否已通過。
        /// </summary>
        /// <remarks>
        /// 當底層 SerialPort 的 EnableTransmissionVerification 為 true 且驗證成功時為 true。
        /// 當未啟用傳輸驗證時，此屬性會在 IsConnected 為 true 時返回 true。
        /// </remarks>
        bool IsTransmissionVerified { get; }

        /// <summary>
        /// 開啟連線。
        /// </summary>
        /// <returns>是否成功開啟。</returns>
        bool Open();

        /// <summary>
        /// 關閉連線。
        /// </summary>
        void Close();

        ///// <summary>
        ///// 傳送字串資料。
        ///// </summary>
        ///// <param name="data">要傳送的字串資料。</param>
        ///// <returns>是否成功傳送。</returns>
        //bool SendData(string data);

        ///// <summary>
        ///// 傳送位元組資料。
        ///// </summary>
        ///// <param name="data">要傳送的位元組資料。</param>
        ///// <returns>是否成功傳送。</returns>
        //bool SendData(byte[] data);

        /// <summary>
        /// 回應接收事件。
        /// </summary>
        event EventHandler<DL_RS1A_ResponseEventArgs> ResponseReceived;

        /// <summary>
        /// 錯誤發生事件。
        /// </summary>
        event EventHandler<DL_RS1A_ErrorEventArgs> ErrorOccurred;
    }
}
