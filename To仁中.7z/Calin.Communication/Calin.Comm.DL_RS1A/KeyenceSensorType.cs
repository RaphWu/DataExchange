﻿namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// Keyence 感測器類型。
    /// </summary>
    public enum KeyenceSensorType
    {
        None,
        IL,
        IB,
        IG,
        GT,
        GT2,
    }
}
