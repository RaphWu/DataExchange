﻿namespace Calin.Comm.DL_RS1A
{
    // Keyence DL-RS1A GT2 指令集實作。
    public partial class DL_RS1A_Service : IDL_RS1A_GT2_Commands
    {

        public bool ReadAll()
        {
            string command = "M0\r\n";
            return SendData(command);
        }

        public bool ReadRaw(int id)
        {
            string command = $"SR,{id:d2},{(int)Gt2DataNumbers.CalculationDisplayValue:d3}\r\n";
            return SendData(command);
        }

        private enum Gt2DataNumbers : int
        {
            // Read-only data
            ComparatorValue = 000,                  // 比較器值
            CalculationDisplayValue = 001,          // 計算顯示值
            RawValue = 002,                         // 原始值
            PeakValueDuringSamplingPeriod = 003,    // 採樣期間峰值
            BottomValueDuringSamplingPeriod = 004,  // 採樣期間谷值
            ControlOutput = 005,                    // 控制輸出
            SensorAmplifierErrorState = 006,        // 感測放大器錯誤狀態
            RawValueOfMainUnitId00 = 010,           // 主單元（ID：00）原始值
            RawValueOfExpansionUnitId01 = 011,      // 擴充單元（編號：01）原始值
            RawValueOfExpansionUnitId02 = 012,      // 擴充單元（編號：02）原始值
            RawValueOfExpansionUnitId03 = 013,      // 擴充單元（編號：03）原始值
            RawValueOfExpansionUnitId04 = 014,      // 擴充單元（編號：04）原始值
            RawValueOfExpansionUnitId05 = 015,      // 擴充單元（編號：05）原始值
            RawValueOfExpansionUnitId06 = 016,      // 擴充單元（編號：06）原始值
            RawValueOfExpansionUnitId07 = 017,      // 擴充單元（編號：07）原始值
            RawValueOfExpansionUnitId08 = 018,      // 擴充單元（編號：08）原始值
            RawValueOfExpansionUnitId09 = 019,      // 擴充單元（編號：09）原始值
            RawValueOfExpansionUnitId10 = 020,      // 擴充單元（編號：10）原始值
            RawValueOfExpansionUnitId11 = 021,      // 擴充單元（編號：11）原始值
            RawValueOfExpansionUnitId12 = 022,      // 擴充單元（編號：12）原始值
            RawValueOfExpansionUnitId13 = 023,      // 擴充單元（編號：13）原始值
            RawValueOfExpansionUnitId14 = 024,      // 擴充單元（編號：14）原始值

            // Read/write data
            PerformPresetRequest = 050,                     // 執行預設請求
            BankSwitchingState = 051,                       // Bank切換狀態
            TimingStatus = 052,                             // 時序狀態
            ResetRequest = 053,                             // 復歸請求
            InitialResetRequest = 054,                      // 初始復歸請求
            ErrorClearRequest = 055,                        // 錯誤清除請求
            Keylock = 056,                                  // 按鍵鎖定
            BarDisplayMode = 057,                           // 條形顯示模式
            Bank0HhSetting = 060,                           // Bank0高位設置
            Bank0HighSetting = 061,                         // Bank0高位設置
            Bank0LowSetting = 062,                          // Bank0低位設置
            Bank0LlSetting = 063,                           // Bank0低位設置
            Bank0PresetValue = 064,                         // Bank0預設值
            Bank1HhSetting = 065,                           // Bank1高位設置
            Bank1HighSetting = 066,                         // Bank1高位設置
            Bank1LowSetting = 067,                          // Bank1低位設置
            Bank1LlSetting = 068,                           // Bank1低位設置
            Bank1PresetValue = 069,                         // Bank1預設值
            Bank2HhSetting = 070,                           // Bank2高位設置
            Bank2HighSetting = 071,                         // Bank2高位設置
            Bank2LowSetting = 072,                          // Bank2低位設置
            Bank2LlSetting = 073,                           // Bank2低位設置
            Bank2PresetValue = 074,                         // Bank2預設值
            Bank3HhSetting = 075,                           // Bank3高位設置
            Bank3HighSetting = 076,                         // Bank3高位設定
            Bank3LowSetting = 077,                          // Bank3低電平設置
            Bank3LlSetting = 078,                           // Bank3低電平設置
            Bank3PresetValue = 079,                         // Bank3預設值
            CalculationSetting = 100,                       // 計算設定
            DetectionMode = 101,                            // 檢測模式
            HoldUpdateMethod = 102,                         // 保持更新方式
            ResponseTime = 103,                             // 回應時間
            TimingType = 104,                               // 定時類型
            Self_TimingLevel = 105,                         // 自定時電平
            Self_TimingDelayType = 106,                     // 自定時延遲類型
            User_SpecifiedDelayTime = 107,                  // 使用者指定延遲時間
            StaticHoldDelayStableDetermination = 108,       // 靜態保持延遲穩定性判定
            StaticHoldDelayStableRange = 109,               // 靜態保持延遲穩定性範圍
            MeasurementIncrease_DecreaseDirection = 110,    // 測量增減方向
            Multiplier = 111,                               // 乘法器
            OutputMode = 112,                               // 輸出模式
            DisplayResolution = 113,                        // 顯示分辨率
            Hysteresis = 114,                               // 滯後
            SimultaneousInputSetting = 115,                 // 同時輸入設定
            SpecialOutputSetting = 116,                     // 特殊輸出設定
            LimitOutputSwitch_HH_Position = 117,            // 限位輸出開關(Hh)位置
            LimitOutputSwitch_LL_Position = 118,            // 限位輸出開關(Ll)位置
            SelectPresetData = 120,                         // 選擇預設數據
            PresetMemory = 121,                             // 預設記憶體
            PresetPoint = 122,                              // 預設點
            Power_SavingFunction = 123,                     // 省電功能
            JamDetectionFunction = 124,                     // 卡紙偵測功能
            JamDetectionPosition = 125,                     // 卡紙偵測位置
            BatchSetting = 126,                             // 批量設定
            AnalogRangeSetting = 130,                       // 類比量程設定
            FreeRangeSettingHi = 131,                       // 自由量程設定（高）
            FreeRangeSettingLo = 132,                       // 自由量程設定（低）
        }
    }
}
