using System;
using System.Collections.Generic;
using Calin.SerialPort;

namespace Calin.Comm.DL_RS1A
{
    /// <summary>
    /// Keyence DL-RS1A RS-232 �q�T��@�C
    /// �ϥ� SerialPort �i��q�T�C
    /// </summary>
    public partial class DL_RS1A_Service : IDL_RS1A
    {
        private readonly DL_RS1A_Config _config;
        private readonly ISerialPortService _serialPortService;
        private bool _disposed;

        public event EventHandler<DL_RS1A_ResponseEventArgs> ResponseReceived;
        public event EventHandler<DL_RS1A_ErrorEventArgs> ErrorOccurred;

        /// <summary>
        /// �إ� DL_RS1A ��ҡC
        /// </summary>
        /// <param name="config">DL-RS1A �]�w�C</param>
        /// <param name="serialPortService">SerialPort �A�ȡC</param>
        /// <exception cref="ArgumentNullException">���ѼƬ� null �ɩߥX�C</exception>
        /// <exception cref="ArgumentException">���P�����������䴩�ɩߥX�C</exception>
        internal DL_RS1A_Service(DL_RS1A_Config config, ISerialPortService serialPortService)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
            _serialPortService = serialPortService ?? throw new ArgumentNullException(nameof(serialPortService));

            if (config.SensorType != KeyenceSensorType.GT2 && config.SensorType != KeyenceSensorType.GT)
            {
                throw new ArgumentException("���{���w�ثe�u�䴩 Keyence GT2/GT �t�C�P�����I", nameof(config));
            }

            SubscribeEvents();
        }

        /// <summary>
        /// ���o�]�w�C
        /// </summary>
        public DL_RS1A_Config Config => _config;

        /// <inheritdoc />
        public bool IsConnected => _serialPortService?.IsOpen ?? false;

        /// <inheritdoc />
        public bool IsTransmissionVerified => _serialPortService?.IsTransmissionVerified ?? false;

        /// <inheritdoc />
        public bool Open()
        {
            try
            {
                return _serialPortService.Open();
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <inheritdoc />
        public void Close()
        {
            try
            {
                _serialPortService.Close();
            }
            catch (Exception)
            {
                // Ignore
            }
        }

        /// <summary>
        /// �ǰe�r���ơC
        /// </summary>
        /// <param name="data">�n�ǰe���r���ơC</param>
        /// <returns>�O�_���\�ǰe�C</returns>
        private bool SendData(string data)
        {
            try
            {
                return _serialPortService.SendData(data);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// �ǰe�줸�ո�ơC
        /// </summary>
        /// <param name="data">�n�ǰe���줸�ո�ơC</param>
        /// <returns>�O�_���\�ǰe�C</returns>
        private bool SendData(byte[] data)
        {
            try
            {
                return _serialPortService.SendData(data);
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// �q�\ SerialPort �ƥ�C
        /// </summary>
        private void SubscribeEvents()
        {
            if (_serialPortService is SerialPortService service)
            {
                service.DataReceived += OnSerialPortDataReceived;
                service.ErrorOccurred += OnSerialPortErrorOccurred;
            }
        }

        /// <summary>
        /// �����q�\ SerialPort �ƥ�C
        /// </summary>
        private void UnsubscribeEvents()
        {
            if (_serialPortService is SerialPortService service)
            {
                service.DataReceived -= OnSerialPortDataReceived;
                service.ErrorOccurred -= OnSerialPortErrorOccurred;
            }
        }

        private void OnSerialPortDataReceived(object sender, SerialPortDataReceivedEventArgs e)
        {
            if (string.IsNullOrEmpty(e.Data))
                return;

            try
            {
                var response = ParseResponse(e.Data);
                if (response != null)
                {
                    OnResponseReceived(response);
                }
            }
            catch (Exception)
            {
                // �ѪR���ѡA����
            }
        }

        /// <summary>
        /// �ѪR DL-RS1A �^����ơC
        /// </summary>
        /// <param name="data">��l�^���r��C</param>
        /// <returns>�ѪR�᪺�^������A�ѪR���Ѯɦ^�� null�C</returns>
        private DL_RS1A_Response ParseResponse(string data)
        {
            //if (string.IsNullOrWhiteSpace(data))
            //    return null;

            var trimmedData = data.Trim();

            // �ˬd���~�^�� (�Ҧp: ER,01)
            if (trimmedData.StartsWith("ER,", StringComparison.OrdinalIgnoreCase))
            {
                var errorCode = trimmedData.Length > 3 ? trimmedData.Substring(3).Trim() : string.Empty;
                return new DL_RS1A_Response
                {
                    IsSuccess = false,
                    ErrorCode = errorCode,
                    RawData = data
                };
            }

            // �ѪR���`�^�� (�Ҧp: +00001.234 �� -00001.234 �Φh����ƥH�r�����j)
            var values = trimmedData.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            var parsedValues = new List<double>();

            foreach (var value in values)
            {
                if (TryParseValue(value.Trim(), out double parsedValue))
                {
                    parsedValues.Add(parsedValue);
                }
            }

            return new DL_RS1A_Response
            {
                IsSuccess = true,
                Values = parsedValues.ToArray(),
                RawData = data
            };
        }

        /// <summary>
        /// ���ոѪR�ƭȦr��C
        /// </summary>
        /// <param name="valueString">�ƭȦr��C</param>
        /// <param name="result">�ѪR���G�C</param>
        /// <returns>�O�_���\�ѪR�C</returns>
        private bool TryParseValue(string valueString, out double result)
        {
            result = 0;

            if (string.IsNullOrWhiteSpace(valueString))
                return false;

            // �B�z GT2 �P�����^�Ǯ榡 (�Ҧp: +00001.234)
            return double.TryParse(valueString,
                System.Globalization.NumberStyles.AllowLeadingSign |
                System.Globalization.NumberStyles.AllowDecimalPoint,
                System.Globalization.CultureInfo.InvariantCulture,
                out result);
        }

        /// <summary>
        /// ������^����Ĳ�o�C
        /// </summary>
        /// <param name="response">�^����ơC</param>
        protected virtual void OnResponseReceived(DL_RS1A_Response response)
        {
            ResponseReceived?.Invoke(this, new DL_RS1A_ResponseEventArgs(response));
        }

        private void OnSerialPortErrorOccurred(object sender, SerialPortErrorEventArgs e)
        {
            ErrorOccurred?.Invoke(this, new DL_RS1A_ErrorEventArgs(
                e.PortName,
                e.ErrorType,
                e.ErrorMessage,
                e.Exception,
                e.Timestamp));
        }

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        /// <param name="disposing">�O�_���b����C</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed) return;

            if (disposing)
            {
                UnsubscribeEvents();
                _serialPortService?.Dispose();
            }

            _disposed = true;
        }
    }
}