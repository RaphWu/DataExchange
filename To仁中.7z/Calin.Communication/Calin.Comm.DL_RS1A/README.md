﻿# Calin.Comm.DL_RS1A

## 簡介

`Calin.Comm.DL_RS1A` 是用於 Keyence DL-RS1A 的 .NET RS-232 通訊函式庫，基於 `Calin.SerialPort` 進行串列埠通訊。目前支援 Keyence GT2/GT 系列感測器。

## 功能說明

- **SerialPort 通訊** - 使用 `Calin.SerialPort` 進行底層通訊
- **Factory 模式** - 透過工廠建立 DL-RS1A 實例，支援多設備同時存在
- **支援 Autofac 依賴注入** - 方便應用層整合
- **GT2/GT 系列指令** - 支援 Keyence GT2/GT 系列感測器通訊指令

## 目標框架

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

## 相依套件

- **Calin.SerialPort** - 串列埠通訊模組
- **Autofac** - 依賴注入框架

## 架構設計

```mermaid
graph TB
    subgraph Application Layer
        App[應用程式]
    end
    
    subgraph DI Container
        Module[DL_RS1A_Module]
        DLFactory[IDL_RS1A_ServiceFactory]
        SPFactory[ISerialPortServiceFactory]
    end
    
    subgraph Instance Layer
        DL1[DL_RS1A COM1]
        DL2[DL_RS1A COM2]
    end
    
    subgraph Hardware
        COM1[Keyence DL-RS1A #1]
        COM2[Keyence DL-RS1A #2]
    end
    
    App --> Module
    Module --> DLFactory
    Module --> SPFactory
    DLFactory --> DL1
    DLFactory --> DL2
    DL1 --> COM1
    DL2 --> COM2
```

### 設計原則

| 類別 | 生命週期 | 說明 |
|------|----------|------|
| `DL_RS1A_Module` | - | Autofac 模組，僅負責型別註冊 |
| `IDL_RS1A_ServiceFactory` | SingleInstance | 工廠，負責建立 DL_RS1A |
| `DL_RS1A` | InstancePerDependency | 代表單一設備，由 Factory 建立 |

## 檔案結構

```markdown
Calin.Comm.DL_RS1A/
├── IDL_RS1A.cs                  // DL-RS1A 介面
├── DL_RS1A.cs                   // DL-RS1A 實作
├── DL_RS1A_Config.cs            // DL-RS1A 設定
├── IDL_RS1A_ServiceFactory.cs   // 工廠介面
├── DL_RS1A_ServiceFactory.cs    // 工廠實作
├── DL_RS1A_Module.cs            // Autofac 模組
├── KeyenceSensorType.cs         // 感測器類型列舉
├── IDL_RS1A_GT2_Commands.cs     // GT2 指令介面
├── DL_RS1A_GT2_Commands.cs      // GT2 指令實作
└── README.md                    // 說明文件
```

## 快速開始

### 1. 使用 Autofac 依賴注入

```csharp
using Autofac;
using Calin.Comm.DL_RS1A;

// 建立 Autofac 容器
var builder = new ContainerBuilder();
builder.RegisterModule<DL_RS1A_Module>();
var container = builder.Build();

// 取得 Factory
var factory = container.Resolve<IDL_RS1A_ServiceFactory>();

// 使用 DL_RS1A_Config 建立
var config = new DL_RS1A_Config
{
    SensorType = KeyenceSensorType.GT2,
    IdNumber = 1,
    SensorName = "GT2 Sensor",
    PortName = "COM1",
    BaudRate = 9600,
    DataBits = 8,
    Parity = RJCP.IO.Ports.Parity.None,
    StopBits = RJCP.IO.Ports.StopBits.One
};

using (var device = factory.Create(config))
{
    // 開啟連線
    if (device.Open())
    {
        Console.WriteLine("DL-RS1A 連線成功");
        
        // 呼叫 IDL_RS1A 的方法來操作設備
        // 例如: device.SomeCommand();
        
        Console.ReadKey();
    }
}
```

### 2. 使用 CreateAndOpen 快速建立

```csharp
var factory = container.Resolve<IDL_RS1A_ServiceFactory>();

var config = new DL_RS1A_Config
{
    SensorType = KeyenceSensorType.GT2,
    PortName = "COM1",
    BaudRate = 9600
};

try
{
    using (var device = factory.CreateAndOpen(config))
    {
        // 呼叫 IDL_RS1A 的方法來操作設備
        Console.ReadKey();
    }
}
catch (InvalidOperationException ex)
{
    Console.WriteLine($"無法開啟連線: {ex.Message}");
}
```

### 3. 多設備同時使用

```csharp
var factory = container.Resolve<IDL_RS1A_ServiceFactory>();

var config1 = new DL_RS1A_Config 
{ 
    SensorType = KeyenceSensorType.GT2,
    IdNumber = 1,
    PortName = "COM1", 
    BaudRate = 9600 
};

var config2 = new DL_RS1A_Config 
{ 
    SensorType = KeyenceSensorType.GT2,
    IdNumber = 2,
    PortName = "COM2", 
    BaudRate = 9600 
};

// 建立多個 DL-RS1A 實例
var device1 = factory.Create(config1);
var device2 = factory.Create(config2);

device1.Open();
device2.Open();

// 呼叫 IDL_RS1A 的方法來操作設備

// 使用完畢後釋放
device1.Dispose();
device2.Dispose();
```

## DL_RS1A_Config 設定

| 參數 | 型別 | 預設值 | 說明 |
|------|------|--------|------|
| SensorType | KeyenceSensorType | None | 感測器類型（目前支援 GT2/GT） |
| IdNumber | int | 1 | 設備 ID 編號 |
| SensorName | string | "" | 感測器名稱 |
| PortName | string | "COM1" | COM Port 名稱 |
| BaudRate | int | 9600 | 鮑率 |
| DataBits | int | 8 | 資料位元數 |
| Parity | Parity | None | 同位位元 |
| StopBits | StopBits | One | 停止位元 |
| ReadTimeout | int | 1000 | 讀取逾時（毫秒） |
| WriteTimeout | int | 1000 | 寫入逾時（毫秒） |

## 支援的感測器類型

| 類型 | 說明 |
|------|------|
| `KeyenceSensorType.GT2` | Keyence GT2 系列感測器 |
| `KeyenceSensorType.GT` | Keyence GT 系列感測器 |

## 注意事項

- 使用完畢後請記得呼叫 `Dispose()` 或使用 `using` 語句釋放資源
- Factory 建立的實例需由呼叫者負責 Dispose
- APP 透過 `IDL_RS1A` 介面的方法來操作設備
- 目前僅支援 GT2/GT 系列感測器，其他類型會拋出 `ArgumentException`

## 版本歷史

### v0.0.2

2026.01.20

- 新增 `IsTransmissionVerified` 屬性至 `IDL_RS1A`
- `SerialPortTransport` 現在會檢查底層 SerialPort 的傳輸驗證狀態

### v0.0.1

- 初始版本
- 支援 SerialPort 通訊
- 實作 Factory 模式
- 支援 Autofac 依賴注入
- 支援 GT2/GT 系列感測器

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.