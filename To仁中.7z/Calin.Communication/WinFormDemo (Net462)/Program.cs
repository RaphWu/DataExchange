﻿using System;
using System.Windows.Forms;
using Autofac;
using Calin.Comm.DL_RS1A;

namespace WinFormDemo_Net48
{
    internal static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var builder = new ContainerBuilder();
            builder.RegisterType<WinFormDemo_Net48>().AsSelf().InstancePerLifetimeScope();
            builder.RegisterModule<DL_RS1A_Module>();
            var container = builder.Build();

            Application.Run(container.Resolve<WinFormDemo_Net48>());
        }
    }
}
