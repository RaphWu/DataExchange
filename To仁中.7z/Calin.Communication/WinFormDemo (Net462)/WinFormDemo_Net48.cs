﻿using System.Windows.Forms;
using Calin.Comm.DL_RS1A;
using Krypton.Toolkit;

namespace WinFormDemo_Net48
{
    public partial class WinFormDemo_Net48 : KryptonForm
    {
        private readonly IDL_RS1A _dlrs1a;

        public WinFormDemo_Net48(IDL_RS1A_ServiceFactory rS1A_ServiceFactory)
        {
            InitializeComponent();

            var config = new DL_RS1A_Config
            {
                SensorType = KeyenceSensorType.GT2,
                PortName = "COM1",
                IdNumber = 1,
                BaudRate = 9600,
                DataBits = 8,
                Parity = RJCP.IO.Ports.Parity.None,
                StopBits = RJCP.IO.Ports.StopBits.One,
            };

            _dlrs1a = rS1A_ServiceFactory.Create(config);
            if (_dlrs1a.IsConnected)
            {
                MessageBox.Show("DL-RS1A 連線成功");

                _dlrs1a.ResponseReceived += ResponseReceived;
            }
            else
            {
                MessageBox.Show("DL-RS1A 連線失敗");
            }
        }

        private void WinFormDemo_Net48_FormClosing(object sender, FormClosingEventArgs e)
        {
            _dlrs1a.ResponseReceived -= ResponseReceived;
            _dlrs1a.Dispose();
        }

        private void ResponseReceived(object sender, DL_RS1A_ResponseEventArgs e)
        {
            if (e.Response.IsSuccess)
            {
                var values = e.Response.Values[2];
                BtnClick.Text = values.ToString();
            }
            else
            {
                BtnClick.Text = $"Error: {e.Response.ErrorCode}";
            }
        }
    }
}
