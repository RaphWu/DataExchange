﻿using System.Windows.Forms;
using Calin.Comm.DL_RS1A;
using Krypton.Toolkit;

namespace WinFormDemo_Net48
{
    public partial class WinFormDemo_Net48 : KryptonForm
    {
        private readonly IDL_RS1A _dlrs1a;

        public WinFormDemo_Net48(IDL_RS1A_ServiceFactory rS1A_ServiceFactory)
        {
            InitializeComponent();

            var config = new DL_RS1A_Config
            {
                SensorType = KeyenceSensorType.GT2,
                PortName = "COM5",
                IdNumber = 1,
                BaudRate = 38400,
                DataBits = 8,
                Parity = RJCP.IO.Ports.Parity.None,
                StopBits = RJCP.IO.Ports.StopBits.One,
            };

            _dlrs1a = rS1A_ServiceFactory.CreateAndOpen(config);
            if (_dlrs1a.IsTransmissionVerified)
            {
                MessageBox.Show("DL-RS1A 連線成功");

                _dlrs1a.ResponseReceived += ResponseReceived;

                Timer timer = new Timer();
                timer.Interval = 20;
                timer.Tick += (s, e) =>
                {
                    //_dlrs1a.SendData($"M0\r\n");
                    //_dlrs1a.ReadRaw(1);
                    _dlrs1a.ReadAll();
                };
                timer.Start();
            }
            else
            {
                MessageBox.Show("DL-RS1A 連線失敗");
            }
        }

        private void WinFormDemo_Net48_FormClosing(object sender, FormClosingEventArgs e)
        {
            _dlrs1a.ResponseReceived -= ResponseReceived;
            _dlrs1a.Dispose();
        }

        private void ResponseReceived(object sender, DL_RS1A_ResponseEventArgs e)
        {
            if (e.Response.IsSuccess)
            {
                var values = e.Response.Values[0];
                BtnClick.Text = values.ToString("F3");
            }
            else
            {
                BtnClick.Text = $"Error: {e.Response.ErrorCode}";
            }
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            _dlrs1a.Close();
            MessageBox.Show($"_dlrs1a.IsConnected = {_dlrs1a.IsConnected.ToString()}");
        }
    }
}
