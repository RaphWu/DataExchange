﻿using Autofac;
using Calin.Modbus.Core;
using Calin.Modbus.Transport;
using Calin.SerialPort;

namespace Calin.Modbus
{
    /// <summary>
    /// MODBUS Autofac 模組。
    /// 提供 MODBUS 相關服務的依賴注入註冊。
    /// </summary>
    /// <remarks>
    /// 使用範例：
    /// <code>
    /// // 使用 MockTransport（用於測試和開發）
    /// var builder = new ContainerBuilder();
    /// builder.RegisterModule(new ModbusModule(useMockTransport: true));
    /// var container = builder.Build();
    /// var modbus = container.Resolve&lt;IModbus&gt;();
    /// 
    /// // 使用 SerialPortTransport（用於實際通訊）
    /// var builder = new ContainerBuilder();
    /// builder.RegisterModule(new ModbusModule(useMockTransport: false));
    /// builder.RegisterModule(new SerialPortModule());
    /// var container = builder.Build();
    /// var modbus = container.Resolve&lt;IModbus&gt;();
    /// </code>
    /// </remarks>
    public class ModbusModule : Module
    {
        /// <summary>
        /// 取得或設定是否使用 MockTransport。
        /// 當設為 true 時，使用 MockTransport；
        /// 當設為 false 時，使用 SerialPortTransport。
        /// 預設為 false。
        /// </summary>
        public bool UseMockTransport { get; set; } = false;

        /// <summary>
        /// 取得或設定預設的 Mock Slave 位址。
        /// 僅在 UseMockTransport = true 時有效。
        /// 預設為 1。
        /// </summary>
        public byte MockSlaveAddress { get; set; } = 1;

        /// <summary>
        /// 取得或設定預設的逾時時間（毫秒）。
        /// 預設為 1000。
        /// </summary>
        public int DefaultTimeout { get; set; } = 1000;

        /// <summary>
        /// 取得或設定預設的重試次數。
        /// 預設為 3。
        /// </summary>
        public int DefaultRetryCount { get; set; } = 3;

        /// <summary>
        /// 建立 ModbusModule 實例。
        /// </summary>
        public ModbusModule()
        {
        }

        /// <summary>
        /// 建立 ModbusModule 實例。
        /// </summary>
        /// <param name="useMockTransport">是否使用 MockTransport。</param>
        public ModbusModule(bool useMockTransport)
        {
            UseMockTransport = useMockTransport;
        }

        /// <summary>
        /// 載入模組設定。
        /// </summary>
        protected override void Load(ContainerBuilder builder)
        {
            if (UseMockTransport)
            {
                // 註冊 MockTransport
                builder.Register(c =>
                {
                    var mock = new MockTransport
                    {
                        SlaveAddress = MockSlaveAddress,
                        Timeout = DefaultTimeout
                    };
                    return mock;
                })
                .As<IModbusTransport>()
                .As<MockTransport>()
                .SingleInstance();
            }
            else
            {
                // 註冊 SerialPortTransport
                // 需要先註冊 ISerialPortService（來自 Calin.SerialPort）
                builder.Register(c =>
                {
                    var serialPortService = c.Resolve<ISerialPortService>();
                    var transport = new SerialPortTransport(serialPortService)
                    {
                        Timeout = DefaultTimeout
                    };
                    return transport;
                })
                .As<IModbusTransport>()
                .SingleInstance();
            }

            // 註冊 ModbusClient
            builder.Register(c =>
            {
                var transport = c.Resolve<IModbusTransport>();
                var client = new ModbusClient(transport)
                {
                    RetryCount = DefaultRetryCount
                };
                return client;
            })
            .As<IModbus>()
            .As<ModbusClient>()
            .SingleInstance();
        }
    }
}
