﻿using Autofac;
using Calin.Modbus.Core;
using Calin.SerialPort;

namespace Calin.Modbus
{
    /// <summary>
    /// MODBUS Autofac 模組。
    /// 提供 MODBUS 相關服務的依賴注入註冊。
    /// </summary>
    /// <remarks>
    /// <code>
    /// 設計原則：
    /// - Module 僅負責型別註冊，不做設備實例決策
    /// - 代表設備或連線的類別（ModbusClient、Transport）不使用 SingleInstance
    /// - 管理或建立設備的類別（Factory、Manager）使用 SingleInstance
    /// - Module 可被多次 RegisterModule 而不影響結果（Idempotent）
    /// </code>
    /// <para>使用範例：</para>
    /// <code>
    /// // 註冊模組
    /// var builder = new ContainerBuilder();
    /// builder.RegisterModule&lt;SerialPortModule&gt;();
    /// builder.RegisterModule&lt;ModbusModule&gt;();
    /// var container = builder.Build();
    /// 
    /// // 使用 Factory 建立 ModbusClient
    /// var factory = container.Resolve&lt;IModbusClientFactory&gt;();
    /// 
    /// // 建立使用 SerialPort 的 ModbusClient
    /// var config = new SerialPortConfig { PortName = "COM1", BaudRate = 9600 };
    /// var modbus1 = factory.CreateWithSerialPortConfig(config);
    /// 
    /// // 建立使用 Mock 的 ModbusClient（用於測試）
    /// var modbus2 = factory.CreateMock(out var mockTransport, slaveAddress: 1);
    /// mockTransport.SetHoldingRegister(0, 1234);
    /// 
    /// // 或使用 Manager 管理多個 ModbusClient
    /// var manager = container.Resolve&lt;IModbusClientManager&gt;();
    /// manager.Register("Device1", modbus1);
    /// manager.Register("Device2", modbus2);
    /// </code>
    /// </remarks>
    public class ModbusModule : Module
    {
        /// <summary>
        /// 載入模組設定。
        /// </summary>
        /// <remarks>
        /// <para>註冊項目：</para>
        /// <code>
        /// - IModbusClientFactory / ModbusClientFactory (SingleInstance)
        /// - IModbusClientManager / ModbusClientManager (SingleInstance)
        /// </code>
        /// <para>注意：</para>
        /// <code>
        /// - ModbusClient 不在此註冊，應透過 Factory 建立
        /// - IModbusTransport 不在此註冊，應透過 Factory 建立
        /// - 此模組依賴 SerialPortModule，建議一起註冊
        /// </code></remarks>
        protected override void Load(ContainerBuilder builder)
        {
            // 註冊 ModbusClientFactory 為 SingleInstance
            // Factory 負責建立 ModbusClient，本身不持有實例
            builder.Register(c =>
            {
                // 嘗試解析 ISerialPortServiceFactory，若不存在則傳入 null
                ISerialPortServiceFactory serialPortFactory = null;
                if (c.IsRegistered<ISerialPortServiceFactory>())
                {
                    serialPortFactory = c.Resolve<ISerialPortServiceFactory>();
                }
                return new ModbusClientFactory(serialPortFactory);
            })
            .As<IModbusClientFactory>()
            .SingleInstance()
            .IfNotRegistered(typeof(IModbusClientFactory));

            // 註冊 ModbusClientManager 為 SingleInstance
            // Manager 負責管理多個 ModbusClient 的生命週期
            builder.RegisterType<ModbusClientManager>()
                .As<IModbusClientManager>()
                .SingleInstance()
                .IfNotRegistered(typeof(IModbusClientManager));
        }
    }
}
