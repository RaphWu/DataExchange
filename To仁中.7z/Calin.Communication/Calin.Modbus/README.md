﻿# Calin.Modbus

MODBUS 類別庫，支援 MODBUS ASCII 通訊協定。

## 目錄

- [專案架構](#專案架構)
- [架構圖](#架構圖)
- [各層職責](#各層職責)
- [相依套件](#相依套件)
- [安裝與設定](#安裝與設定)
- [使用範例](#使用範例)
- [Autofac 切換 Transport](#autofac-切換-transport)
- [時序圖](#時序圖)
- [MockTransport 使用](#mocktransport-使用)
- [錯誤處理](#錯誤處理)
- [未來擴充方向](#未來擴充方向)

## 專案架構

```
Calin.Modbus/
├── Core/
│   ├── IModbus.cs              # MODBUS 客戶端介面
│   └── ModbusClient.cs         # MODBUS 客戶端實作
├── Enums/
│   ├── FunctionCode.cs         # MODBUS 功能碼 (01, 02, 03, 04, 05, 06)
│   ├── ModbusErrorCode.cs      # MODBUS 錯誤碼
│   └── MockTransportBehavior.cs # Mock 行為模式
├── Exceptions/
│   ├── ModbusException.cs      # MODBUS 專用例外
│   └── ModbusTimeoutException.cs # 逾時例外
├── Models/
│   ├── ModbusRequest.cs        # 請求模型
│   └── ModbusResponse.cs       # 回應模型
├── Protocol/
│   ├── AsciiCodec.cs           # ASCII Hex 編解碼
│   ├── LrcCalculator.cs        # LRC 計算器
│   └── ModbusAsciiFrame.cs     # MODBUS ASCII Frame 組裝與解析
├── Transport/
│   ├── IModbusTransport.cs     # 傳輸層抽象介面
│   ├── MockTransport.cs        # Stateful 模擬傳輸層
│   └── SerialPortTransport.cs  # SerialPort 傳輸層
├── Properties/
│   └── AssemblyInfo.cs         # 組件資訊
├── ModbusModule.cs             # Autofac 模組
├── README.md                   # 完整說明文件
├── version.txt                 # 版本號
└── UpdateVersion.ps1           # 版本更新腳本
```

## 架構圖

```mermaid
graph TB
    subgraph Application Layer
        App[應用程式]
    end
    
    subgraph Core Layer
        IModbus[IModbus 介面]
        ModbusClient[ModbusClient]
    end
    
    subgraph Protocol Layer
        Frame[ModbusAsciiFrame]
        LRC[LrcCalculator]
        Codec[AsciiCodec]
    end
    
    subgraph Transport Layer
        ITransport[IModbusTransport]
        SerialPort[SerialPortTransport]
        Mock[MockTransport]
    end
    
    subgraph External
        HW[硬體設備]
        CalinSP[Calin.SerialPort]
    end
    
    App --> IModbus
    IModbus -.-> ModbusClient
    ModbusClient --> Frame
    Frame --> LRC
    Frame --> Codec
    ModbusClient --> ITransport
    ITransport -.-> SerialPort
    ITransport -.-> Mock
    SerialPort --> CalinSP
    CalinSP --> HW
```

## 各層職責

### Core Layer

| 類別 | 職責 |
|------|------|
| `IModbus` | 對外公開的 MODBUS 操作介面 |
| `ModbusClient` | 實作 IModbus，組合 Protocol 與 Transport |

### Protocol Layer

| 類別 | 職責 |
|------|------|
| `ModbusAsciiFrame` | MODBUS ASCII Frame 組裝與解析 |
| `LrcCalculator` | LRC 計算與驗證 |
| `AsciiCodec` | Byte 與 ASCII Hex 轉換 |

### Transport Layer

| 類別 | 職責 |
|------|------|
| `IModbusTransport` | 傳輸層抽象介面 |
| `SerialPortTransport` | 使用 Calin.SerialPort 進行串列埠通訊 |
| `MockTransport` | Stateful 模擬 MODBUS Slave，用於測試與開發 |

### Models / Enums

| 類別 | 職責 |
|------|------|
| `FunctionCode` | MODBUS 功能碼列舉 (01, 02, 03, 04, 05, 06) |
| `ModbusErrorCode` | MODBUS Exception Code 列舉 |
| `ModbusRequest` | 請求資料模型 |
| `ModbusResponse` | 回應資料模型 |
| `MockTransportBehavior` | Mock 行為模式 |

### Exceptions

| 類別 | 職責 |
|------|------|
| `ModbusException` | MODBUS 專用例外（包含 Exception Code） |
| `ModbusTimeoutException` | 通訊逾時例外 |

## 相依套件

- **Autofac** - 依賴注入框架
- **Newtonsoft.Json** - JSON 序列化
- **Calin.SerialPort** - 串列埠通訊模組

## 安裝與設定

### 使用 NuGet

```powershell
Install-Package Calin.Modbus
```

### 專案參考

```xml
<ItemGroup>
    <ProjectReference Include="..\Calin.Modbus\Calin.Modbus.csproj" />
</ItemGroup>
```

## 使用範例

### 基本使用（MockTransport）

```csharp
using Autofac;
using Calin.Modbus;
using Calin.Modbus.Core;
using Calin.Modbus.Transport;

// 建立 Autofac 容器
var builder = new ContainerBuilder();
builder.RegisterModule(new ModbusModule(useMockTransport: true));
var container = builder.Build();

// 取得 MockTransport 並初始化資料
var mock = container.Resolve<MockTransport>();
mock.SetHoldingRegister(0, 1234);
mock.SetHoldingRegister(1, 5678);
mock.SetCoil(0, true);
mock.SetCoil(1, false);

// 取得 MODBUS 客戶端
var modbus = container.Resolve<IModbus>();
modbus.Connect();

// 讀取保持暫存器
var response = modbus.ReadHoldingRegisters(1, 0, 2);
if (response.IsSuccess)
{
    Console.WriteLine($"Register 0: {response.RegisterValues[0]}"); // 1234
    Console.WriteLine($"Register 1: {response.RegisterValues[1]}"); // 5678
}

// 讀取線圈
var coilResponse = modbus.ReadCoils(1, 0, 2);
if (coilResponse.IsSuccess)
{
    Console.WriteLine($"Coil 0: {coilResponse.CoilValues[0]}"); // true
    Console.WriteLine($"Coil 1: {coilResponse.CoilValues[1]}"); // false
}

// 寫入暫存器
modbus.WriteSingleRegister(1, 0, 9999);

// 寫入線圈
modbus.WriteSingleCoil(1, 0, false);
```

### 使用 SerialPortTransport

```csharp
using Autofac;
using Calin.Modbus;
using Calin.Modbus.Core;
using Calin.SerialPort;

// 建立 Autofac 容器
var builder = new ContainerBuilder();

// 註冊 SerialPort 設定
builder.Register(c => new SerialPortConfig
{
    PortName = "COM1",
    BaudRate = 9600,
    DataBits = 7,
    Parity = RJCP.IO.Ports.Parity.Even,
    StopBits = RJCP.IO.Ports.StopBits.One,
    ReadTimeout = 1000
}).SingleInstance();

// 註冊 SerialPort 服務
builder.Register(c => new SerialPortService(c.Resolve<SerialPortConfig>()))
    .As<ISerialPortService>()
    .SingleInstance();

// 註冊 MODBUS 模組（使用 SerialPortTransport）
builder.RegisterModule(new ModbusModule(useMockTransport: false));

var container = builder.Build();

// 使用 MODBUS 客戶端
var modbus = container.Resolve<IModbus>();

if (modbus.Connect())
{
    try
    {
        // 讀取暫存器
        var response = modbus.ReadHoldingRegisters(1, 0, 10);
        if (response.IsSuccess)
        {
            foreach (var value in response.RegisterValues)
            {
                Console.WriteLine($"Value: {value}");
            }
        }
    }
    finally
    {
        modbus.Disconnect();
    }
}
```

## Autofac 切換 Transport

### 方法一：建構函式參數

```csharp
// 使用 MockTransport
builder.RegisterModule(new ModbusModule(useMockTransport: true));

// 使用 SerialPortTransport
builder.RegisterModule(new ModbusModule(useMockTransport: false));
```

### 方法二：屬性設定

```csharp
builder.RegisterModule(new ModbusModule
{
    UseMockTransport = true,
    MockSlaveAddress = 1,
    DefaultTimeout = 2000,
    DefaultRetryCount = 5
});
```

### 方法三：根據環境變數切換

```csharp
bool useMock = Environment.GetEnvironmentVariable("USE_MOCK_MODBUS") == "true";
builder.RegisterModule(new ModbusModule(useMockTransport: useMock));
```

### 方法四：手動註冊 Transport

```csharp
var builder = new ContainerBuilder();

// 手動註冊 MockTransport
var mockTransport = new MockTransport { SlaveAddress = 1 };
mockTransport.SetHoldingRegister(0, 1234);
builder.RegisterInstance(mockTransport)
    .As<IModbusTransport>()
    .As<MockTransport>();

// 註冊 ModbusClient（不使用 ModbusModule）
builder.RegisterType<ModbusClient>()
    .As<IModbus>()
    .SingleInstance();
```

## 時序圖

### 讀取保持暫存器

```mermaid
sequenceDiagram
    participant App as 應用程式
    participant Client as ModbusClient
    participant Frame as ModbusAsciiFrame
    participant Transport as IModbusTransport
    participant Slave as MODBUS Slave
    
    App->>Client: ReadHoldingRegisters(1, 0, 2)
    Client->>Frame: BuildRequestFrame(request)
    Frame-->>Client: ":01030000000200\r\n"
    Client->>Transport: SendAndReceive(frame)
    Transport->>Slave: 傳送請求
    Slave-->>Transport: 回傳回應
    Transport-->>Client: ":010304000004D2...\r\n"
    Client->>Frame: ParseResponseFrame(response)
    Frame-->>Client: ModbusResponse
    Client-->>App: ModbusResponse
```

### Exception Response 處理

```mermaid
sequenceDiagram
    participant App as 應用程式
    participant Client as ModbusClient
    participant Transport as IModbusTransport
    participant Slave as MODBUS Slave
    
    App->>Client: ReadHoldingRegisters(1, 9999, 1)
    Client->>Transport: SendAndReceive(frame)
    Transport->>Slave: 傳送請求
    Slave-->>Transport: Exception Response (0x83 0x02)
    Transport-->>Client: ":018302...\r\n"
    Client->>Client: 檢測 Exception Response
    Client--xApp: throw ModbusException(IllegalDataAddress)
```

## MockTransport 使用

### 初始化模擬資料

```csharp
var mock = container.Resolve<MockTransport>();

// 設定保持暫存器
mock.SetHoldingRegister(0, 1234);
mock.SetHoldingRegisters(10, new ushort[] { 100, 200, 300 });

// 設定線圈
mock.SetCoil(0, true);
mock.SetCoils(10, new bool[] { true, false, true });

// 設定輸入暫存器（唯讀）
mock.SetInputRegister(0, 5678);

// 設定離散輸入（唯讀）
mock.SetDiscreteInput(0, true);
```

### 模擬錯誤情境

```csharp
var mock = container.Resolve<MockTransport>();

// 模擬逾時
mock.Behavior = MockTransportBehavior.Timeout;
try
{
    modbus.ReadHoldingRegisters(1, 0, 1);
}
catch (ModbusTimeoutException ex)
{
    Console.WriteLine("逾時正確觸發");
}

// 模擬 LRC 錯誤
mock.Behavior = MockTransportBehavior.LrcError;
try
{
    modbus.ReadHoldingRegisters(1, 0, 1);
}
catch (ModbusException ex)
{
    Console.WriteLine("LRC 錯誤正確觸發");
}

// 模擬非法功能碼
mock.Behavior = MockTransportBehavior.IllegalFunction;
try
{
    modbus.ReadHoldingRegisters(1, 0, 1);
}
catch (ModbusException ex)
{
    Console.WriteLine($"Exception Code: {ex.ErrorCode}"); // IllegalFunction
}

// 模擬非法位址
mock.Behavior = MockTransportBehavior.IllegalAddress;
try
{
    modbus.ReadHoldingRegisters(1, 0, 1);
}
catch (ModbusException ex)
{
    Console.WriteLine($"Exception Code: {ex.ErrorCode}"); // IllegalDataAddress
}

// 恢復正常模式
mock.Behavior = MockTransportBehavior.Normal;
```

### 查看請求歷史

```csharp
var mock = container.Resolve<MockTransport>();

// 執行一些操作
modbus.ReadHoldingRegisters(1, 0, 1);
modbus.WriteSingleRegister(1, 0, 1234);

// 查看請求歷史
foreach (var request in mock.RequestHistory)
{
    Console.WriteLine($"Request: {request}");
}

// 查看最後的請求與回應
Console.WriteLine($"Last Request: {mock.LastRequestFrame}");
Console.WriteLine($"Last Response: {mock.LastResponseFrame}");

// 重置
mock.Reset();
```

## 錯誤處理

### ModbusException

```csharp
try
{
    var response = modbus.ReadHoldingRegisters(1, 0, 1);
}
catch (ModbusTimeoutException ex)
{
    Console.WriteLine($"通訊逾時: {ex.TimeoutMilliseconds}ms, 重試 {ex.RetryCount} 次");
}
catch (ModbusException ex) when (ex.IsModbusExceptionResponse)
{
    Console.WriteLine($"MODBUS Exception: {ex.ErrorCode} - {ex.Message}");
}
catch (ModbusException ex)
{
    Console.WriteLine($"MODBUS 錯誤: {ex.Message}");
}
```

### 錯誤碼對照表

| ErrorCode | 說明 |
|-----------|------|
| 0x01 | IllegalFunction - 不支援的功能碼 |
| 0x02 | IllegalDataAddress - 無效的位址 |
| 0x03 | IllegalDataValue - 無效的資料值 |
| 0x04 | SlaveDeviceFailure - 從站設備故障 |
| 0x05 | Acknowledge - 請求已接受，需要較長處理時間 |
| 0x06 | SlaveDeviceBusy - 從站忙碌 |
| 0x08 | MemoryParityError - 記憶體同位錯誤 |
| 0x0A | GatewayPathUnavailable - 閘道路徑不可用 |
| 0x0B | GatewayTargetDeviceFailedToRespond - 閘道目標無回應 |

## MODBUS ASCII 規格

### Frame 格式

```
:[Address][Function][Data][LRC][CR][LF]
```

| 欄位 | 長度 | 說明 |
|------|------|------|
| Start | 1 字元 | ':' (0x3A) |
| Address | 2 字元 | Slave 位址 (01-F7) |
| Function | 2 字元 | 功能碼 |
| Data | N 字元 | 資料（依功能碼而定） |
| LRC | 2 字元 | 縱向冗餘檢查 |
| End | 2 字元 | CR LF (0x0D 0x0A) |

### LRC 計算

1. 將 Address + Function + Data 的所有位元組相加
2. 取二補數（Two's Complement）
3. 結果為一個位元組

### 支援的功能碼

| Code | 名稱 | 說明 |
|------|------|------|
| 0x01 | Read Coils | 讀取線圈 |
| 0x02 | Read Discrete Inputs | 讀取離散輸入 |
| 0x03 | Read Holding Registers | 讀取保持暫存器 |
| 0x04 | Read Input Registers | 讀取輸入暫存器 |
| 0x05 | Write Single Coil | 寫入單一線圈 |
| 0x06 | Write Single Register | 寫入單一暫存器 |

## 未來擴充方向

### MODBUS RTU

```csharp
// 未來可新增 ModbusRtuFrame
public class ModbusRtuFrame
{
    // RTU 使用 CRC-16 而非 LRC
    public static byte[] BuildRequestFrame(ModbusRequest request);
    public static ModbusResponse ParseResponseFrame(byte[] frame);
}

// RTU Transport
public class RtuTransport : IModbusTransport
{
    // Binary 傳輸而非 ASCII
}
```

### MODBUS TCP

```csharp
// TCP Frame 包含 MBAP Header
public class ModbusTcpFrame
{
    public ushort TransactionId { get; set; }
    public ushort ProtocolId { get; set; } // 0x0000
    public ushort Length { get; set; }
    public byte UnitId { get; set; }
}

// TCP Transport
public class TcpTransport : IModbusTransport
{
    private TcpClient _client;
    
    public TcpTransport(string host, int port = 502);
}
```

### 擴充 ModbusModule

```csharp
public class ModbusModule : Module
{
    public ModbusProtocol Protocol { get; set; } = ModbusProtocol.Ascii;
    
    // ModbusProtocol.Ascii -> AsciiTransport
    // ModbusProtocol.Rtu -> RtuTransport
    // ModbusProtocol.Tcp -> TcpTransport
}
```

## 授權

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
