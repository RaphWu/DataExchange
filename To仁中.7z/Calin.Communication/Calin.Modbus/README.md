﻿# Calin.Modbus

MODBUS 類別庫，支援 MODBUS ASCII 通訊協定，基於 `Calin.SerialPort` 進行串列埠通訊。

## 目標框架

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

## 相依套件

- **Calin.SerialPort** - 串列埠通訊模組
- **Autofac** - 依賴注入框架
- **Newtonsoft.Json**

## 專案架構

```csharp
Calin.Modbus/
├── Core/
│   ├── IModbus.cs                  # MODBUS 客戶端介面
│   ├── ModbusClient.cs             # MODBUS 客戶端實作
│   ├── ModbusClientConfig.cs       # 客戶端設定
│   ├── IModbusClientFactory.cs     # 工廠介面
│   ├── ModbusClientFactory.cs      # 工廠實作
│   ├── IModbusClientManager.cs     # 管理器介面
│   └── ModbusClientManager.cs      # 管理器實作
├── Enums/
│   ├── FunctionCode.cs             # MODBUS 功能碼
│   ├── ModbusErrorCode.cs          # MODBUS 錯誤碼
│   └── MockTransportBehavior.cs    # Mock 行為模式
├── Exceptions/
│   ├── ModbusException.cs          # MODBUS 例外
│   └── ModbusTimeoutException.cs   # 逾時例外
├── Models/
│   ├── ModbusRequest.cs            # 請求模型
│   └── ModbusResponse.cs           # 回應模型
├── Protocol/
│   ├── AsciiCodec.cs               # ASCII Hex 編解碼
│   ├── LrcCalculator.cs            # LRC 計算器
│   └── ModbusAsciiFrame.cs         # MODBUS ASCII Frame
├── Transport/
│   ├── IModbusTransport.cs         # 傳輸層介面
│   ├── MockTransport.cs            # 模擬傳輸層
│   └── SerialPortTransport.cs      # SerialPort 傳輸層
├── ModbusModule.cs                 # Autofac 模組
└── README.md                       # 說明文件
```

## 架構圖

```mermaid
graph TB
    subgraph Application Layer
        App[應用程式]
    end
    
    subgraph DI Container
        Module[ModbusModule]
        Factory[IModbusClientFactory]
        Manager[IModbusClientManager]
    end
    
    subgraph Client Layer
        Client1[ModbusClient 1]
        Client2[ModbusClient 2]
    end
    
    subgraph Transport Layer
        Transport1[SerialPortTransport COM1]
        Transport2[SerialPortTransport COM2]
        MockT[MockTransport]
    end
    
    subgraph Protocol Layer
        Frame[ModbusAsciiFrame]
        LRC[LrcCalculator]
    end
    
    subgraph SerialPort Layer
        SP1[SerialPortService COM1]
        SP2[SerialPortService COM2]
    end
    
    App --> Module
    Module --> Factory
    Module --> Manager
    Factory --> Client1
    Factory --> Client2
    Manager --> Client1
    Manager --> Client2
    Client1 --> Transport1
    Client2 --> Transport2
    Client1 --> Frame
    Client2 --> Frame
    Frame --> LRC
    Transport1 --> SP1
    Transport2 --> SP2
```

## 設計原則

### Singleton vs Instance

| 類別 | 生命週期 | 說明 |
|------|----------|------|
| `ModbusModule` | - | Autofac 模組，僅負責型別註冊 |
| `IModbusClientFactory` | SingleInstance | 工廠，負責建立 ModbusClient |
| `IModbusClientManager` | SingleInstance | 管理器，負責管理多個 ModbusClient |
| `ModbusClient` | InstancePerDependency | 代表單一通訊會話，由 Factory 建立 |
| `IModbusTransport` | InstancePerDependency | 代表單一傳輸通道，由 Factory 建立 |

> **重要設計準則**：
> - 代表設備或連線的類別（ModbusClient、Transport）**不可為 Singleton**
> - 管理或建立設備的類別（Factory、Manager）**才可為 Singleton**
> - Module **不在內部決定**設備參數（COM Port、SlaveAddress、Timeout）

### Module 設計原則

- Module 僅負責型別註冊，不做設備實例決策
- Module 可被多次 RegisterModule 而不影響結果（Idempotent）
- 不使用 static 狀態來防止重複註冊

## 各層職責

### Core Layer

| 類別 | 職責 |
|------|------|
| `IModbus` | 對外公開的 MODBUS 操作介面 |
| `ModbusClient` | 實作 IModbus，組合 Protocol 與 Transport |
| `ModbusClientConfig` | 客戶端設定（Timeout、RetryCount 等） |
| `IModbusClientFactory` | 工廠介面，建立 ModbusClient |
| `ModbusClientFactory` | 工廠實作 |
| `IModbusClientManager` | 管理器介面，管理多個 ModbusClient |
| `ModbusClientManager` | 管理器實作 |

### IModbus 介面屬性

| 屬性 | 型別 | 說明 |
|------|------|------|
| `Timeout` | int | 通訊逾時時間（毫秒） |
| `RetryCount` | int | 重試次數 |
| `IsConnected` | bool | 是否已連線（Transport 已開啟） |
| `IsTransmissionVerified` | bool | 傳輸驗證是否已通過 |

### Protocol Layer

| 類別 | 職責 |
|------|------|
| `ModbusAsciiFrame` | MODBUS ASCII Frame 組裝與解析 |
| `LrcCalculator` | LRC 計算與驗證 |
| `AsciiCodec` | Byte 與 ASCII Hex 轉換 |

### Transport Layer

| 類別 | 職責 |
|------|------|
| `IModbusTransport` | 傳輸層抽象介面 |
| `SerialPortTransport` | 使用 Calin.SerialPort 進行串列埠通訊 |
| `MockTransport` | Stateful 模擬 MODBUS Slave，用於測試與開發 |

### IModbusTransport 介面屬性

| 屬性 | 型別 | 說明 |
|------|------|------|
| `IsOpen` | bool | 傳輸層是否已開啟 |
| `IsTransmissionVerified` | bool | 傳輸驗證是否已通過 |
| `Timeout` | int | 通訊逾時時間（毫秒） |

## 相依套件

- **Autofac** - 依賴注入框架
- **Newtonsoft.Json** - JSON 序列化
- **Calin.SerialPort** - 串列埠通訊模組

## 安裝與設定

### 使用 NuGet

```powershell
Install-Package Calin.Modbus
```

### 專案參考

```xml
<ItemGroup>
    <ProjectReference Include="..\Calin.Modbus\Calin.Modbus.csproj" />
</ItemGroup>
```

## 使用範例

### 使用 Factory 建立 ModbusClient

```csharp
using Autofac;
using Calin.Modbus;
using Calin.Modbus.Core;
using Calin.SerialPort;

// 建立 Autofac 容器
var builder = new ContainerBuilder();
builder.RegisterModule<SerialPortModule>();
builder.RegisterModule<ModbusModule>();
var container = builder.Build();

// 取得 Factory
var factory = container.Resolve<IModbusClientFactory>();

// 方法 1: 使用 SerialPortConfig 建立
var modbus = factory.CreateWithSerialPortConfig(
    new SerialPortConfig 
    { 
        PortName = "COM1", 
        BaudRate = 9600,
        DataBits = 7,
        Parity = RJCP.IO.Ports.Parity.Even
    },
    new ModbusClientConfig
    {
        Timeout = 1000,
        RetryCount = 3
    }
);

// 連線並使用
if (modbus.Connect())
{
    // 檢查傳輸驗證狀態
    if (modbus.IsTransmissionVerified)
    {
        var response = modbus.ReadHoldingRegisters(1, 0, 10);
        if (response.IsSuccess)
        {
            foreach (var value in response.RegisterValues)
            {
                Console.WriteLine($"Value: {value}");
            }
        }
    }
    else
    {
        Console.WriteLine("傳輸驗證失敗，請檢查串口參數！");
    }
    
    modbus.Disconnect();
}

// 釋放資源
((IDisposable)modbus).Dispose();
```

## 傳輸驗證

`Calin.Modbus` 整合了 `Calin.SerialPort` 的傳輸驗證功能，可在連線後自動驗證串口參數是否正確。

### 驗證流程

1. 當 `ModbusClient.Connect()` 被呼叫時，底層的 `SerialPortService.Open()` 會執行
2. 如果 `SerialPortConfig.EnableTransmissionVerification` 為 `true`（預設），會自動發送測試訊息並等待回應
3. 驗證結果會反映在 `IsTransmissionVerified` 屬性

### 檢查驗證狀態

```csharp
var modbus = factory.CreateWithSerialPortConfig(
    new SerialPortConfig 
    { 
        PortName = "COM1", 
        BaudRate = 9600,
        // 傳輸驗證預設為啟用
        EnableTransmissionVerification = true,
        TransmissionTestMessage = "",  // 空字串表示僅等待接收任何資料
        TransmissionTestTimeout = 2000
    },
    new ModbusClientConfig { Timeout = 1000 }
);

if (modbus.Connect())
{
    Console.WriteLine($"IsConnected: {modbus.IsConnected}");
    Console.WriteLine($"IsTransmissionVerified: {modbus.IsTransmissionVerified}");
    
    if (modbus.IsTransmissionVerified)
    {
        // 可以安全地進行 MODBUS 通訊
        var response = modbus.ReadHoldingRegisters(1, 0, 1);
    }
    else
    {
        // 參數可能不正確，可能無法正確通訊
        Console.WriteLine("警告：傳輸驗證未通過");
    }
}
```

### 停用傳輸驗證

若設備無法在連線後立即回傳資料，可停用傳輸驗證：

```csharp
var modbus = factory.CreateWithSerialPortConfig(
    new SerialPortConfig 
    { 
        PortName = "COM1", 
        BaudRate = 9600,
        EnableTransmissionVerification = false  // 停用傳輸驗證
    },
    new ModbusClientConfig { Timeout = 1000 }
);
```

### 狀態判斷邏輯

| 條件 | `IsConnected` | `IsTransmissionVerified` |
|------|---------------|--------------------------|
| 未連線 | false | false |
| 連線成功，驗證通過 | true | true |
| 連線成功，驗證失敗 | true | false |
| 未啟用驗證，連線成功 | true | true |
| 使用 MockTransport | true | true（永遠通過） |

### 使用 Mock 進行測試

```csharp
var factory = container.Resolve<IModbusClientFactory>();

// 建立 Mock 並取得 MockTransport 實例
var modbus = factory.CreateMock(out var mockTransport, slaveAddress: 1);

// MockTransport 的 IsTransmissionVerified 永遠為 true
Console.WriteLine($"Mock IsTransmissionVerified: {modbus.IsTransmissionVerified}"); // true

// 設定模擬資料
mockTransport.SetHoldingRegister(0, 1234);
mockTransport.SetHoldingRegister(1, 5678);
mockTransport.SetCoil(0, true);

// 連線並讀取
modbus.Connect();
var response = modbus.ReadHoldingRegisters(1, 0, 2);
Console.WriteLine($"Register 0: {response.RegisterValues[0]}"); // 1234
Console.WriteLine($"Register 1: {response.RegisterValues[1]}"); // 5678

// 模擬錯誤
mockTransport.Behavior = MockTransportBehavior.Timeout;
try
{
    modbus.ReadHoldingRegisters(1, 0, 1);
}
catch (ModbusTimeoutException)
{
    Console.WriteLine("逾時正確觸發");
}
```

## 多設備同時存在範例

這是重構後的核心功能：**同時建立多個 ModbusClient，使用不同的 SerialPort**。

```csharp
using Autofac;
using Calin.Modbus;
using Calin.Modbus.Core;
using Calin.SerialPort;

// 建立 Autofac 容器
var builder = new ContainerBuilder();
builder.RegisterModule<SerialPortModule>();
builder.RegisterModule<ModbusModule>();
var container = builder.Build();

// 取得 Factory 和 Manager
var factory = container.Resolve<IModbusClientFactory>();
var manager = container.Resolve<IModbusClientManager>();

// 建立第一個 ModbusClient (COM1, Slave 1)
var modbus1 = factory.CreateWithSerialPortConfig(
    new SerialPortConfig { PortName = "COM1", BaudRate = 9600 },
    new ModbusClientConfig { Name = "Device1" }
);

// 建立第二個 ModbusClient (COM2, Slave 2)
var modbus2 = factory.CreateWithSerialPortConfig(
    new SerialPortConfig { PortName = "COM2", BaudRate = 115200 },
    new ModbusClientConfig { Name = "Device2" }
);

// 建立第三個 ModbusClient (Mock, 用於測試)
var modbus3 = factory.CreateMock(out var mockTransport, slaveAddress: 1);
mockTransport.SetHoldingRegister(0, 9999);

// 使用 Manager 管理所有 Client
manager.Register("PLC_A", modbus1);
manager.Register("PLC_B", modbus2);
manager.Register("MockPLC", modbus3);

// 連線所有設備
manager.ConnectAll();

// 查看連線狀態與傳輸驗證狀態
var states = manager.GetAllConnectionStates();
foreach (var kvp in states)
{
    var client = manager.GetClient(kvp.Key);
    Console.WriteLine($"{kvp.Key}: Connected={kvp.Value}, Verified={client?.IsTransmissionVerified}");
}

// 透過 Manager 操作特定設備
var response = manager.ReadHoldingRegisters("MockPLC", 1, 0, 1);
Console.WriteLine($"MockPLC Register 0: {response.RegisterValues[0]}"); // 9999

// 也可以直接操作
var device1 = manager.GetClient("PLC_A");
if (device1 != null && device1.IsConnected && device1.IsTransmissionVerified)
{
    var resp = device1.ReadHoldingRegisters(1, 0, 10);
    // 處理回應...
}

// 程式結束時，Manager 會自動釋放所有資源
// 或手動釋放
manager.Dispose();
```

### 時序圖：多設備同時存在

```mermaid
sequenceDiagram
    participant App as 應用程式
    participant Factory as ModbusClientFactory
    participant Manager as ModbusClientManager
    participant Client1 as ModbusClient 1
    participant Client2 as ModbusClient 2
    participant Trans1 as Transport COM1
    participant Trans2 as Transport COM2
    
    App->>Factory: CreateWithSerialPortConfig(COM1)
    Factory-->>App: ModbusClient 1
    
    App->>Factory: CreateWithSerialPortConfig(COM2)
    Factory-->>App: ModbusClient 2
    
    App->>Manager: Register("PLC_A", client1)
    App->>Manager: Register("PLC_B", client2)
    
    App->>Manager: ConnectAll()
    Manager->>Client1: Connect()
    Client1->>Trans1: Open()
    Manager->>Client2: Connect()
    Client2->>Trans2: Open()
    
    App->>Manager: ReadHoldingRegisters("PLC_A", ...)
    Manager->>Client1: ReadHoldingRegisters(...)
    Client1->>Trans1: SendAndReceive(frame)
    Trans1-->>Client1: response
    Client1-->>Manager: ModbusResponse
    Manager-->>App: ModbusResponse
```

## Autofac 整合

### 標準註冊方式

```csharp
var builder = new ContainerBuilder();

// 註冊 SerialPort 模組（ModbusModule 依賴此模組）
builder.RegisterModule<SerialPortModule>();

// 註冊 Modbus 模組
builder.RegisterModule<ModbusModule>();

var container = builder.Build();

// Factory 和 Manager 都是 SingleInstance
var factory = container.Resolve<IModbusClientFactory>();
var manager = container.Resolve<IModbusClientManager>();
```

### Module 可重複註冊

```csharp
var builder = new ContainerBuilder();

// 重複註冊不會造成問題
builder.RegisterModule<SerialPortModule>();
builder.RegisterModule<SerialPortModule>(); // 安全，使用 IfNotRegistered

builder.RegisterModule<ModbusModule>();
builder.RegisterModule<ModbusModule>(); // 安全，使用 IfNotRegistered

var container = builder.Build();
```

### 在應用程式中使用

```csharp
public class ModbusDeviceService
{
    private readonly IModbusClientFactory _factory;
    private readonly IModbusClientManager _manager;

    public ModbusDeviceService(
        IModbusClientFactory factory,
        IModbusClientManager manager)
    {
        _factory = factory;
        _manager = manager;
    }

    public void InitializeDevices(IEnumerable<DeviceConfig> configs)
    {
        foreach (var config in configs)
        {
            var client = _factory.CreateWithSerialPortConfig(
                config.SerialPortConfig,
                config.ModbusConfig
            );
            
            _manager.Register(config.Name, client);
        }
        
        _manager.ConnectAll();
        
        // 檢查傳輸驗證狀態
        foreach (var config in configs)
        {
            var client = _manager.GetClient(config.Name);
            if (client != null && !client.IsTransmissionVerified)
            {
                Console.WriteLine($"警告: {config.Name} 傳輸驗證未通過");
            }
        }
    }

    public ushort[] ReadRegisters(string deviceName, byte slave, ushort address, ushort count)
    {
        var client = _manager.GetClient(deviceName);
        if (client == null || !client.IsTransmissionVerified)
            return null;
            
        var response = _manager.ReadHoldingRegisters(deviceName, slave, address, count);
        return response.IsSuccess ? response.RegisterValues : null;
    }
}
```

## MockTransport 使用

### 初始化模擬資料

```csharp
var factory = container.Resolve<IModbusClientFactory>();
var modbus = factory.CreateMock(out var mock, slaveAddress: 1);

// 設定保持暫存器
mock.SetHoldingRegister(0, 1234);
mock.SetHoldingRegisters(10, new ushort[] { 100, 200, 300 });

// 設定線圈
mock.SetCoil(0, true);
mock.SetCoils(10, new bool[] { true, false, true });

// 設定輸入暫存器（唯讀）
mock.SetInputRegister(0, 5678);

// 設定離散輸入（唯讀）
mock.SetDiscreteInput(0, true);
```

### 模擬錯誤情境

```csharp
// 模擬逾時
mock.Behavior = MockTransportBehavior.Timeout;

// 模擬 LRC 錯誤
mock.Behavior = MockTransportBehavior.LrcError;

// 模擬非法功能碼
mock.Behavior = MockTransportBehavior.IllegalFunction;

// 模擬非法位址
mock.Behavior = MockTransportBehavior.IllegalAddress;

// 恢復正常模式
mock.Behavior = MockTransportBehavior.Normal;
```

## 錯誤處理

```csharp
try
{
    var response = modbus.ReadHoldingRegisters(1, 0, 1);
}
catch (InvalidOperationException ex) when (ex.Message.Contains("Transmission verification"))
{
    Console.WriteLine("傳輸驗證失敗，請檢查串口參數");
}
catch (ModbusTimeoutException ex)
{
    Console.WriteLine($"通訊逾時: {ex.TimeoutMilliseconds}ms, 重試 {ex.RetryCount} 次");
}
catch (ModbusException ex) when (ex.IsModbusExceptionResponse)
{
    Console.WriteLine($"MODBUS Exception: {ex.ErrorCode} - {ex.Message}");
}
catch (ModbusException ex)
{
    Console.WriteLine($"MODBUS 錯誤: {ex.Message}");
}
```

### 錯誤碼對照表

| ErrorCode | 說明 |
|-----------|------|
| 0x01 | IllegalFunction - 不支援的功能碼 |
| 0x02 | IllegalDataAddress - 無效的位址 |
| 0x03 | IllegalDataValue - 無效的資料值 |
| 0x04 | SlaveDeviceFailure - 從站設備故障 |
| 0x05 | Acknowledge - 請求已接受，需要較長處理時間 |
| 0x06 | SlaveDeviceBusy - 從站忙碌 |

## MODBUS ASCII 規格

### Frame 格式

```csharp
:[Address][Function][Data][LRC][CR][LF]
```

| 欄位 | 長度 | 說明 |
|------|------|------|
| Start | 1 字元 | ':' (0x3A) |
| Address | 2 字元 | Slave 位址 (01-F7) |
| Function | 2 字元 | 功能碼 |
| Data | N 字元 | 資料（依功能碼而定） |
| LRC | 2 字元 | 縱向冗餘檢查 |
| End | 2 字元 | CR LF (0x0D 0x0A) |

### 支援的功能碼

| Code | 名稱 | 說明 |
|------|------|------|
| 0x01 | Read Coils | 讀取線圈 |
| 0x02 | Read Discrete Inputs | 讀取離散輸入 |
| 0x03 | Read Holding Registers | 讀取保持暫存器 |
| 0x04 | Read Input Registers | 讀取輸入暫存器 |
| 0x05 | Write Single Coil | 寫入單一線圈 |
| 0x06 | Write Single Register | 寫入單一暫存器 |

## 未來擴充方向

### MODBUS RTU

```csharp
// RTU 使用 CRC-16 而非 LRC
public class ModbusRtuFrame { ... }
public class RtuTransport : IModbusTransport { ... }
```

### MODBUS TCP

```csharp
// TCP Frame 包含 MBAP Header
public class ModbusTcpFrame { ... }
public class TcpTransport : IModbusTransport { ... }
```

## 版本歷史

### v0.0.3

2026.01.20

- 新增 `IsTransmissionVerified` 屬性至 `IModbus`、`IModbusTransport`
- `SerialPortTransport` 現在會檢查底層 SerialPort 的傳輸驗證狀態
- `ModbusClient.Execute()` 會在傳輸驗證失敗時拋出例外
- `MockTransport.IsTransmissionVerified` 永遠返回 `true`

### v0.0.2

- 新增 `IModbusClientFactory` 介面與實作
- 新增 `IModbusClientManager` 介面與實作
- 新增 `ModbusClientConfig` 設定類別
- 重構 `ModbusModule`，移除所有業務狀態屬性
- Module 現在是 Idempotent，可安全重複註冊
- 支援多設備同時存在

### v0.0.1

2025.12.18

- ASCII 傳送（Service + Manager 都有）
	- SerialPortService.SendAscii(string data)：以 ASCII 編碼送出（不加行尾）
	- SerialPortService.SendAsciiLine(string line)：送出並自動加上行尾（預設 \r\n）
	- SerialPortManager.SendAscii(portName, data) / SendAsciiLine(portName, line)：代理呼叫，符合 SendData 風格
- ASCII 接收（行模式 / 非行模式）
	- 預設啟用 行模式：收到資料後會依 AsciiLineTerminator 分割成多行，每一行都會觸發一次 DataReceived
	- 若關閉行模式：就維持「收到一段就觸發一次」(不切行)
- 可設定項目（放在 SerialPortConfig）新增：
	- TextEncoding：Ascii / Utf8（預設 Ascii）
	- AsciiLineTerminator：預設 "\r\n"
	- EnableAsciiLineMode：預設 true
	- AsciiReceiveBufferLimit：預設 8192，避免一直累積導致記憶體成長
	- GetTextEncoding()：取得對應的 System.Text.Encoding，並已更新 Clone() 將上述參數一起複製。
- 介面已補齊
	- ISerialPortService：加入 SendAscii、SendAsciiLine
	- ISerialPortManager：加入 SendAscii、SendAsciiLine

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
