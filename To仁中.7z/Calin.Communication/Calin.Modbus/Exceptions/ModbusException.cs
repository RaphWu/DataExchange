using System;
using Calin.Modbus.Enums;

namespace Calin.Modbus.Exceptions
{
    /// <summary>
    /// MODBUS �M�Ψҥ~���O�C
    /// �ʸ� MODBUS �q�T�L�{���o�ͪ��U�ؿ��~�C
    /// </summary>
    [Serializable]
    public class ModbusException : Exception
    {
        /// <summary>
        /// ���o MODBUS ���~�X�C
        /// </summary>
        public ModbusErrorCode ErrorCode { get; }

        /// <summary>
        /// ���o�O�_�� MODBUS Exception Response�C
        /// </summary>
        public bool IsModbusExceptionResponse => ErrorCode != ModbusErrorCode.None;

        /// <summary>
        /// �إ� ModbusException ��ҡC
        /// </summary>
        /// <param name="message">���~�T���C</param>
        public ModbusException(string message)
            : base(message)
        {
            ErrorCode = ModbusErrorCode.None;
        }

        /// <summary>
        /// �إ� ModbusException ��ҡC
        /// </summary>
        /// <param name="message">���~�T���C</param>
        /// <param name="errorCode">MODBUS ���~�X�C</param>
        public ModbusException(string message, ModbusErrorCode errorCode)
            : base(message)
        {
            ErrorCode = errorCode;
        }

        /// <summary>
        /// �إ� ModbusException ��ҡC
        /// </summary>
        /// <param name="message">���~�T���C</param>
        /// <param name="innerException">�����ҥ~�C</param>
        public ModbusException(string message, Exception innerException)
            : base(message, innerException)
        {
            ErrorCode = ModbusErrorCode.None;
        }

        /// <summary>
        /// �إ� ModbusException ��ҡC
        /// </summary>
        /// <param name="message">���~�T���C</param>
        /// <param name="errorCode">MODBUS ���~�X�C</param>
        /// <param name="innerException">�����ҥ~�C</param>
        public ModbusException(string message, ModbusErrorCode errorCode, Exception innerException)
            : base(message, innerException)
        {
            ErrorCode = errorCode;
        }

        /// <summary>
        /// �q MODBUS ���~�X�إ� Exception Response �ҥ~�C
        /// </summary>
        /// <param name="errorCode">MODBUS ���~�X�C</param>
        /// <returns>ModbusException ��ҡC</returns>
        public static ModbusException FromErrorCode(ModbusErrorCode errorCode)
        {
            string message = GetErrorMessage(errorCode);
            return new ModbusException(message, errorCode);
        }

        /// <summary>
        /// �إ߹O�ɨҥ~�C
        /// </summary>
        /// <param name="timeoutMs">�O�ɮɶ��]�@���^�C</param>
        /// <returns>ModbusException ��ҡC</returns>
        public static ModbusException Timeout(int timeoutMs)
        {
            return new ModbusException($"MODBUS communication timeout after {timeoutMs}ms.");
        }

        /// <summary>
        /// �إ� LRC ���~�ҥ~�C
        /// </summary>
        /// <returns>ModbusException ��ҡC</returns>
        public static ModbusException LrcError()
        {
            return new ModbusException("LRC verification failed. Data may be corrupted.");
        }

        /// <summary>
        /// �إߨ�w���ҿ��~�ҥ~�C
        /// </summary>
        /// <param name="details">���~�Ա��C</param>
        /// <returns>ModbusException ��ҡC</returns>
        public static ModbusException ProtocolError(string details)
        {
            return new ModbusException($"MODBUS protocol validation error: {details}");
        }

        /// <summary>
        /// ���o���~�X���������~�T���C
        /// </summary>
        private static string GetErrorMessage(ModbusErrorCode errorCode)
        {
            switch (errorCode)
            {
                case ModbusErrorCode.IllegalFunction:
                    return "Illegal Function: The function code received is not supported by the slave.";
                case ModbusErrorCode.IllegalDataAddress:
                    return "Illegal Data Address: The data address received is not an allowable address for the slave.";
                case ModbusErrorCode.IllegalDataValue:
                    return "Illegal Data Value: The value contained in the query data field is not acceptable.";
                case ModbusErrorCode.SlaveDeviceFailure:
                    return "Slave Device Failure: An unrecoverable error occurred while the slave was attempting to perform the requested action.";
                case ModbusErrorCode.Acknowledge:
                    return "Acknowledge: The slave has accepted the request but needs a long time to process it.";
                case ModbusErrorCode.SlaveDeviceBusy:
                    return "Slave Device Busy: The slave is engaged in processing a long-duration command.";
                case ModbusErrorCode.MemoryParityError:
                    return "Memory Parity Error: The slave detected a parity error in memory.";
                case ModbusErrorCode.GatewayPathUnavailable:
                    return "Gateway Path Unavailable: The gateway was unable to allocate an internal communication path.";
                case ModbusErrorCode.GatewayTargetDeviceFailedToRespond:
                    return "Gateway Target Device Failed to Respond: No response was obtained from the target device.";
                default:
                    return $"Unknown MODBUS error code: 0x{(byte)errorCode:X2}";
            }
        }

        /// <summary>
        /// ���o�ҥ~���r����ܡC
        /// </summary>
        public override string ToString()
        {
            if (IsModbusExceptionResponse)
            {
                return $"ModbusException [ErrorCode=0x{(byte)ErrorCode:X2} ({ErrorCode})]: {Message}";
            }
            return $"ModbusException: {Message}";
        }
    }
}
