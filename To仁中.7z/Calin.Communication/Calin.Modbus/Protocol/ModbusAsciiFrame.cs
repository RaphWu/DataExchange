using System;
using System.Collections.Generic;
using Calin.Modbus.Enums;
using Calin.Modbus.Exceptions;
using Calin.Modbus.Models;

namespace Calin.Modbus.Protocol
{
    /// <summary>
    /// MODBUS ASCII Frame �ո˻P�ѪR���C
    /// �B�z MODBUS ASCII ��w�� Frame �榡�C
    /// </summary>
    /// <remarks>
    /// MODBUS ASCII Frame �榡�G
    /// :[Address][Function][Data][LRC][CR][LF]
    /// 
    /// - ':' = �_�l�r�� (0x3A)
    /// - Address = 2 �� ASCII �r�� (Slave ��})
    /// - Function = 2 �� ASCII �r�� (�\��X)
    /// - Data = N �� ASCII �r�� (��ơA���ר̥\��X�өw)
    /// - LRC = 2 �� ASCII �r�� (�a�V���l�ˬd)
    /// - CR = 0x0D
    /// - LF = 0x0A
    /// </remarks>
    public class ModbusAsciiFrame
    {
        /// <summary>
        /// MODBUS ASCII �_�l�r���C
        /// </summary>
        public const char StartCharacter = ':';

        /// <summary>
        /// MODBUS ASCII �����r�� (CRLF)�C
        /// </summary>
        public const string EndCharacters = "\r\n";

        /// <summary>
        /// �q ModbusRequest �إ� MODBUS ASCII Frame�C
        /// </summary>
        /// <param name="request">MODBUS �ШD�C</param>
        /// <returns>���㪺 MODBUS ASCII Frame �r��C</returns>
        /// <exception cref="ArgumentNullException">�� request �� null �ɩߥX�C</exception>
        /// <exception cref="ArgumentException">�� request �]�t�L�İѼƮɩߥX�C</exception>
        public static string BuildRequestFrame(ModbusRequest request)
        {
            if (request == null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            ValidateRequest(request);

            byte[] pduData = BuildPduData(request);
            return BuildFrame(request.SlaveAddress, (byte)request.FunctionCode, pduData);
        }

        /// <summary>
        /// �إ� MODBUS ASCII Frame�C
        /// </summary>
        /// <param name="slaveAddress">Slave ��}�C</param>
        /// <param name="functionCode">�\��X�C</param>
        /// <param name="data">��Ʀ줸�հ}�C�C</param>
        /// <returns>���㪺 MODBUS ASCII Frame �r��C</returns>
        public static string BuildFrame(byte slaveAddress, byte functionCode, byte[] data)
        {
            // �զX�Ҧ��줸�ա]���t ':' �M CRLF�^
            var allBytes = new List<byte>
            {
                slaveAddress,
                functionCode
            };

            if (data != null && data.Length > 0)
            {
                allBytes.AddRange(data);
            }

            byte[] messageBytes = allBytes.ToArray();

            // �p�� LRC
            byte lrc = LrcCalculator.Calculate(messageBytes);

            // �ഫ�� ASCII Hex
            string hexMessage = AsciiCodec.BytesToAsciiHex(messageBytes);
            string hexLrc = AsciiCodec.ByteToAsciiHex(lrc);

            // �զX���� Frame
            return $"{StartCharacter}{hexMessage}{hexLrc}{EndCharacters}";
        }

        /// <summary>
        /// �ѪR MODBUS ASCII Response Frame�C
        /// </summary>
        /// <param name="frame">���㪺 MODBUS ASCII Frame �r��C</param>
        /// <param name="expectedSlaveAddress">�w���� Slave ��}�C</param>
        /// <param name="expectedFunctionCode">�w�����\��X�C</param>
        /// <returns>�ѪR�᪺ ModbusResponse�C</returns>
        /// <exception cref="ModbusException">�� Frame �榡���~�����ҥ��ѮɩߥX�C</exception>
        public static ModbusResponse ParseResponseFrame(string frame, byte expectedSlaveAddress, FunctionCode expectedFunctionCode)
        {
            // ���� Frame �榡
            ValidateFrameFormat(frame);

            // �����_�l�r���M�����r��
            string hexContent = ExtractHexContent(frame);

            // ���� LRC
            if (!LrcCalculator.VerifyFromAsciiHex(hexContent))
            {
                throw new ModbusException("LRC verification failed.", ModbusErrorCode.None);
            }

            // �ѪR���e�]���t LRC�^
            string hexData = hexContent.Substring(0, hexContent.Length - 2);
            byte[] data = AsciiCodec.AsciiHexToBytes(hexData);

            if (data.Length < 2)
            {
                throw new ModbusException("Response frame too short.", ModbusErrorCode.None);
            }

            byte slaveAddress = data[0];
            byte functionCode = data[1];

            // ���� Slave ��}
            if (slaveAddress != expectedSlaveAddress)
            {
                throw new ModbusException($"Slave address mismatch. Expected: {expectedSlaveAddress}, Received: {slaveAddress}", ModbusErrorCode.None);
            }

            // �ˬd�O�_�� Exception Response
            bool isException = (functionCode & 0x80) != 0;
            if (isException)
            {
                byte originalFunctionCode = (byte)(functionCode & 0x7F);
                if (originalFunctionCode != (byte)expectedFunctionCode)
                {
                    throw new ModbusException($"Function code mismatch in exception response. Expected: {expectedFunctionCode}, Received: 0x{originalFunctionCode:X2}", ModbusErrorCode.None);
                }

                if (data.Length < 3)
                {
                    throw new ModbusException("Exception response missing error code.", ModbusErrorCode.None);
                }

                ModbusErrorCode errorCode = (ModbusErrorCode)data[2];
                var exceptionResponse = ModbusResponse.CreateException(slaveAddress, expectedFunctionCode, errorCode);
                exceptionResponse.RawFrame = frame;
                return exceptionResponse;
            }

            // ���ҥ\��X
            if (functionCode != (byte)expectedFunctionCode)
            {
                throw new ModbusException($"Function code mismatch. Expected: {expectedFunctionCode}, Received: 0x{functionCode:X2}", ModbusErrorCode.None);
            }

            // �����^�����
            byte[] responseData = new byte[data.Length - 2];
            Array.Copy(data, 2, responseData, 0, responseData.Length);

            var response = ModbusResponse.CreateSuccess(slaveAddress, expectedFunctionCode, responseData);
            response.RawFrame = frame;

            // �ھڥ\��X�ѪR�S�w���
            ParseResponseData(response, expectedFunctionCode);

            return response;
        }

        /// <summary>
        /// ���� Frame �榡�C
        /// </summary>
        private static void ValidateFrameFormat(string frame)
        {
            if (string.IsNullOrEmpty(frame))
            {
                throw new ModbusException("Frame is null or empty.", ModbusErrorCode.None);
            }

            if (frame[0] != StartCharacter)
            {
                throw new ModbusException($"Frame must start with '{StartCharacter}'.", ModbusErrorCode.None);
            }

            if (!frame.EndsWith(EndCharacters))
            {
                throw new ModbusException("Frame must end with CRLF.", ModbusErrorCode.None);
            }

            // �̤p���סG: + Address(2) + Function(2) + LRC(2) + CRLF(2) = 9
            if (frame.Length < 9)
            {
                throw new ModbusException("Frame too short.", ModbusErrorCode.None);
            }
        }

        /// <summary>
        /// ���� Hex ���e�]���t�_�l�r���M�����r���^�C
        /// </summary>
        private static string ExtractHexContent(string frame)
        {
            // ���� ':' �M '\r\n'
            return frame.Substring(1, frame.Length - 3);
        }

        /// <summary>
        /// ���ҽШD�ѼơC
        /// </summary>
        private static void ValidateRequest(ModbusRequest request)
        {
            if (request.SlaveAddress < 1 || request.SlaveAddress > 247)
            {
                throw new ArgumentException("Slave address must be between 1 and 247.", nameof(request));
            }

            switch (request.FunctionCode)
            {
                case FunctionCode.ReadCoils:
                case FunctionCode.ReadDiscreteInputs:
                    if (request.Quantity < 1 || request.Quantity > 2000)
                    {
                        throw new ArgumentException("Quantity for coils must be between 1 and 2000.", nameof(request));
                    }
                    break;

                case FunctionCode.ReadHoldingRegisters:
                case FunctionCode.ReadInputRegisters:
                    if (request.Quantity < 1 || request.Quantity > 125)
                    {
                        throw new ArgumentException("Quantity for registers must be between 1 and 125.", nameof(request));
                    }
                    break;

                case FunctionCode.WriteSingleCoil:
                    if (request.CoilValue == null)
                    {
                        throw new ArgumentException("CoilValue is required for WriteSingleCoil.", nameof(request));
                    }
                    break;

                case FunctionCode.WriteSingleRegister:
                    if (request.WriteValue == null)
                    {
                        throw new ArgumentException("WriteValue is required for WriteSingleRegister.", nameof(request));
                    }
                    break;
            }
        }

        /// <summary>
        /// �إ� PDU ��ơC
        /// </summary>
        private static byte[] BuildPduData(ModbusRequest request)
        {
            var data = new List<byte>();

            switch (request.FunctionCode)
            {
                case FunctionCode.ReadCoils:
                case FunctionCode.ReadDiscreteInputs:
                case FunctionCode.ReadHoldingRegisters:
                case FunctionCode.ReadInputRegisters:
                    // Starting Address (2 bytes) + Quantity (2 bytes)
                    data.Add((byte)(request.StartAddress >> 8));
                    data.Add((byte)(request.StartAddress & 0xFF));
                    data.Add((byte)(request.Quantity >> 8));
                    data.Add((byte)(request.Quantity & 0xFF));
                    break;

                case FunctionCode.WriteSingleCoil:
                    // Coil Address (2 bytes) + Value (2 bytes: 0xFF00 = ON, 0x0000 = OFF)
                    data.Add((byte)(request.StartAddress >> 8));
                    data.Add((byte)(request.StartAddress & 0xFF));
                    if (request.CoilValue == true)
                    {
                        data.Add(0xFF);
                        data.Add(0x00);
                    }
                    else
                    {
                        data.Add(0x00);
                        data.Add(0x00);
                    }
                    break;

                case FunctionCode.WriteSingleRegister:
                    // Register Address (2 bytes) + Value (2 bytes)
                    data.Add((byte)(request.StartAddress >> 8));
                    data.Add((byte)(request.StartAddress & 0xFF));
                    ushort value = request.WriteValue ?? 0;
                    data.Add((byte)(value >> 8));
                    data.Add((byte)(value & 0xFF));
                    break;

                default:
                    throw new NotSupportedException($"Function code {request.FunctionCode} is not supported.");
            }

            return data.ToArray();
        }

        /// <summary>
        /// �ѪR�^����ơC
        /// </summary>
        private static void ParseResponseData(ModbusResponse response, FunctionCode functionCode)
        {
            if (response.Data == null || response.Data.Length == 0)
            {
                return;
            }

            switch (functionCode)
            {
                case FunctionCode.ReadCoils:
                case FunctionCode.ReadDiscreteInputs:
                    ParseCoilResponse(response);
                    break;

                case FunctionCode.ReadHoldingRegisters:
                case FunctionCode.ReadInputRegisters:
                    ParseRegisterResponse(response);
                    break;

                case FunctionCode.WriteSingleCoil:
                case FunctionCode.WriteSingleRegister:
                    // Echo response, no additional parsing needed
                    break;
            }
        }

        /// <summary>
        /// �ѪR�u��^���C
        /// </summary>
        private static void ParseCoilResponse(ModbusResponse response)
        {
            if (response.Data.Length < 1)
            {
                return;
            }

            byte byteCount = response.Data[0];
            var coils = new List<bool>();

            for (int i = 1; i < response.Data.Length && i <= byteCount + 1; i++)
            {
                byte b = response.Data[i];
                for (int bit = 0; bit < 8; bit++)
                {
                    coils.Add((b & (1 << bit)) != 0);
                }
            }

            response.CoilValues = coils.ToArray();
        }

        /// <summary>
        /// �ѪR�Ȧs���^���C
        /// </summary>
        private static void ParseRegisterResponse(ModbusResponse response)
        {
            if (response.Data.Length < 1)
            {
                return;
            }

            byte byteCount = response.Data[0];
            int registerCount = byteCount / 2;
            var registers = new List<ushort>();

            for (int i = 0; i < registerCount; i++)
            {
                int offset = 1 + (i * 2);
                if (offset + 1 < response.Data.Length)
                {
                    ushort value = (ushort)((response.Data[offset] << 8) | response.Data[offset + 1]);
                    registers.Add(value);
                }
            }

            response.RegisterValues = registers.ToArray();
        }
    }
}
