﻿using Autofac;

namespace Calin.Comm.Keyence_DL_RS1A
{
    public class DL_RS1A_Module : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<DL_RS1A>()
                .As<IDL_RS1A>()
                .SingleInstance();
        }
    }
}
