﻿namespace Calin.Comm.Keyence_DL_RS1A
{
    public class DL_RS1A : IDL_RS1A
    {
    }
}
