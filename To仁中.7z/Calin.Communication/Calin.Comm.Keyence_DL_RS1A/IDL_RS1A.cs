﻿namespace Calin.Comm.Keyence_DL_RS1A
{
    public interface IDL_RS1A
    {
    }
}
