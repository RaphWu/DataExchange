﻿# Calin

## 簡介

`Calin` 是佳凌科技工具/設計課內部使用的 **C# / Windows Forms 組件庫**，目標是提供一套可重用、可組合、可維護的基礎模組，協助團隊在桌面應用程式中更一致地處理：

- 導航（Region / Page / History）
- 協調式工作流程（Task Coordination / Policy）
- 日誌（Serilog + Microsoft.Extensions.Logging 整合）
- 對話框（Dialog）
- 常用擴充方法與 WinForms 輔助元件

本專案採用 **多目標框架**，支援舊專案（.NET Framework）與新專案（.NET 8 for Windows）的共存。

## 目標框架（Target Frameworks）

- .NET Framework 4.5
- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0 (`net8.0-windows`)

## NuGet 依賴

> 實際使用依模組而定。以下為本倉庫常見依賴。

- `Autofac`：依賴注入容器（Module/Extensions 註冊）
- `Serilog` 與周邊套件：檔案輸出、Compact JSON、Enricher、與 MEL 整合
- `Microsoft.Extensions.Logging`：統一 logging API（便於注入 `ILogger<T>`）

## 專案結構

```csharp
Calin/
├── Framework/
│   ├── Coordination/     # 任務協調框架：Request/Session/Policy/Publisher
│   ├── Dialog/           # WinForms 對話框服務：Modal/Modeless、參數與回傳
│   ├── Logging/          # Serilog + MEL 整合：Bootstrapper、Category、DI Module
│   └── Navigation/       # Region 導航：RegionManager、NavigationService、Journal
├── Infrastructure/
│   ├── Extensions/       # 通用擴充方法（Thread/String/Collections...）
│   ├── Helper/           # 常用 Helper（Enum/Security/Password/AES...）
│   ├── LoadingDialog/    # 載入中對話框元件
│   └── Service/          # WinForms 相關服務抽象與實作
└── README.md             # 本文件
```

## 快速開始（建議整合方式）

### 1) 以 Autofac 組合 Calin 的模組

Calin 內多數功能以 Autofac `Module` 形式提供，建議在應用程式啟動階段統一註冊。

- `CalinModule`：聚合入口（若專案內提供/使用）
- `Framework/*/*Module`：各功能模組的 Autofac 註冊

> 可參考各模組 `Examples` 目錄的範例程式。

### 2) Logging 初始化位置

Logging 通常需要在 DI 建置與主程式啟動前初始化，並在程式結束時 Shutdown。詳見 Logging 模組 README。

## 模組一覽（含指引）

> 若模組內已有專屬說明文件（README），請以該文件為主要且最新的使用指南。本 README 只提供總覽與入口。

### Framework

#### Navigation（Region 導航）

- 用途：在 WinForms 中提供類 Prism Region 的導航概念，支援 PageId、History（Back/Forward）、參數傳遞與 View 生命週期。
- 範例：`Framework/Navigation/Examples/NavigationUsageExamples.cs`
- 文件：`Framework/Navigation/README.md`

#### Coordination（工作協調/流程策略）

- 用途：將「任務調度、重試、併發、逾時、結果發布」等橫切需求抽離成可配置策略。
- 範例：`Framework/Coordination/Examples/*`
- 文件：`Framework/Coordination/README.md`

#### Dialog（對話框服務）

- 用途：提供一致的對話框呼叫方式（含參數傳遞與關閉回傳），支援 Modal 與 Modeless。
- 範例：`Framework/Dialog/Examples/DialogUsageExamples.cs`
- 文件：`Framework/Dialog/README.md`

#### Logging（日誌基礎設施）

- 用途：封裝 Serilog 設定、檔案輸出與分類（Category），並與 `Microsoft.Extensions.Logging` 串接以便注入 `ILogger<T>`。
- 範例：`Framework/Logging/Examples/LoggingUsageExamples.cs`
- 文件：`Framework/Logging/README.md`

### Infrastructure

#### Extensions（通用擴充方法）

- `Infrastructure/Extensions/ThreadExtensions.cs`
  - `InvokeIfRequired`：需要跨執行緒時 marshal 回 UI thread。
  - `BeginInvokeIfRequired`：以非同步方式 marshal 回 UI thread。
- 其他：`StringExtensions`、`CollectionsExtensions`…

#### Helper（常用工具）

- `AESHelper` / `PasswordHelper` / `SecurityHelper`：加解密、密碼處理等輔助
- `EnumHelper`：列舉處理工具

> 注意：安全相關 Helper 的使用需符合公司密碼/金鑰管理政策，避免在程式碼或設定檔中硬編碼敏感資訊。

#### LoadingDialog（載入中對話框）

- 用途：在耗時操作時顯示載入動畫與提示文字。
- 文件：`Infrastructure/LoadingDialog/LoadingDialog.README.md`

#### Service（WinForms 服務抽象）

- `Infrastructure/Service/IWinForm.cs` / `WinFormService.cs`：封裝 WinForms 常用行為（依實作而定）。

## 範例程式（Examples）

本專案多數模組提供範例程式，建議從下列位置開始：

- `Framework/Navigation/Examples/NavigationUsageExamples.cs`
- `Framework/Coordination/Examples/*`
- `Framework/Dialog/Examples/DialogUsageExamples.cs`
- `Framework/Logging/Examples/LoggingUsageExamples.cs`

## 版本歷史

### v0.0.2

2026.01.22

- 新增支援 .NET Framework 4.5。
- 移除 Newtonsoft.Json 依賴。

### v0.0.1

2026.01.15

- 將原本的 Calin.CSharp 及 Calin.WinForm 合併為 Calin。
- 分類為 Framework 與 Infrastructure 兩大模組，詳細內容查看各資料夾。

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
