﻿# Calin

## 簡介

Calin 是佳凌科技工具/設計課內部使用，用於 C# 及 Windows Forms 應用程式開發的組件庫，旨在提供一套高效、易用且功能豐富的工具，幫助開發者快速構建現代化的桌面應用程式。該組件庫包含多種功能模組，涵蓋導航系統、多執行緒操作擴展、載入對話框等，旨在提升開發效率與應用程式的穩定性。

## 目標框架

Calin 支援以下目標框架：

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

此多框架支持確保了組件庫在不同版本的 .NET 平台上均能穩定運行，滿足多樣化的開發需求。

## NuGet 依賴

Calin 使用以下 NuGet 套件來實現其功能：

- **AutoFac**: 提供靈活的依賴注入容器。
- **Newtonsoft.Json**: 用於 JSON 的序列化與反序列化。
- **Serilog**: 高效能的日誌記錄框架。
  - **Serilog.Sinks.File**: 支持將日誌輸出到文件。
  - **Serilog.Formatting.Compact**: 提供緊湊格式的日誌輸出。
  - **Serilog.Enrichers.Process**: 增強日誌內容，包含進程相關資訊。
  - **Serilog.Enrichers.Environment**: 增強日誌內容，包含環境相關資訊。
  - **Serilog.Extensions.Logging**: 與 Microsoft.Extensions.Logging 集成。
- **Microsoft.Extensions.Logging**: 提供標準化的日誌記錄接口。

這些依賴確保了 Calin 的功能模組具有高效能與可擴展性。

## 主要功能

### Navigation

提供靈活的導航系統，支持多種導航模式，方便用戶在應用程式中切換不同的視圖和頁面。

- **特性**:
  - 支持多層級導航。
  - 提供簡單易用的 API。
- **使用範例**:
  - 詳細說明請參考 [Navigation README](./Navigation/README.md)。
  - 使用範例請參考 `Navigation\Examples\NavigationUsageExamples.cs`。

### ThreadExtensions

提供一組擴展方法，簡化多執行緒操作，提升應用程式的響應速度和穩定性。

| 函數 | 說明 |
|---|---|
| `InvokeIfRequired` | 如果控制項需要跨執行緒呼叫，則在 UI 執行緒上執行指定的動作。 |
| `BeginInvokeIfRequired` | 在 UI 執行緒上執行指定的動作。 |

- **特性**:
  - 簡化跨執行緒操作的代碼。
  - 提升應用程式的穩定性。

### LoadingDialog

提供一個簡單易用的載入對話框，方便在長時間操作時向用戶顯示等待動畫。

- **特性**:
  - 支持自定義樣式與文字。
  - 簡單易用的 API。
- **使用場景**:
  - 長時間的數據加載。
  - 後台任務執行時的用戶提示。

## 開發指南

### 專案結構

- **Calin**: 核心組件庫，包含所有功能模組。
- **Examples**: 使用範例，展示如何在應用程式中集成與使用 Calin 的功能。

### 貢獻

歡迎開發者提交問題回報與功能請求，並參與專案的開發與改進。

### 聯繫方式

如有任何問題，請聯繫佳凌科技內部技術支持團隊。
