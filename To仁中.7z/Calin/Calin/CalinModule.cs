﻿using Autofac;
using Calin.Framework.Coordination;
using Calin.Framework.Dialog;
using Calin.Framework.Logging;
using Calin.Framework.Navigation;
using Calin.Infrastructure.LoadingDialog;
using Calin.Infrastructure.Service;

namespace Calin
{
    public class CalinModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // Modules
            builder.RegisterModule<NavigationModule>();
            builder.RegisterModule<CoordinationModule>();
            builder.RegisterModule<DialogModule>();
            builder.RegisterModule<LoggingModule>();

            // Services
            builder.RegisterType<WinFormService>().As<IWinForm>().SingleInstance();

            // Dialogs
            builder.RegisterType<LoadingDialog>().AsSelf().ExternallyOwned();
        }
    }
}
