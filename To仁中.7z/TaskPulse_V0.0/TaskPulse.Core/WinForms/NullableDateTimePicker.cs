﻿using System;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.WinForms
{
    public class NullableDateTimePicker : DateTimePicker
    {
        private bool _isNull = true;
        private string _customFormat = " ";

        public new DateTime? Value
        {
            get => _isNull ? (DateTime?)null : base.Value;
            set
            {
                if (value.HasValue)
                {
                    _isNull = false;
                    base.Value = value.Value;
                    this.Format = DateTimePickerFormat.Short;
                }
                else
                {
                    _isNull = true;
                    this.Format = DateTimePickerFormat.Custom;
                    this.CustomFormat = _customFormat;
                }
            }
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                this.Value = null;
            }
        }

        protected override void OnValueChanged(EventArgs eventargs)
        {
            base.OnValueChanged(eventargs);
            if (!_isNull)
            {
                this.Format = DateTimePickerFormat.Short;
            }
        }
    }
}
