﻿using System;
using System.Threading;

namespace Calin.TaskPulse.Core.Services
{
    public static class SplashMessenger
    {
        private static SynchronizationContext _uiContext;
        private static Action<string> _messageHandler;

        public static void Initialize(SynchronizationContext context, Action<string> handler)
        {
            _uiContext = context;
            _messageHandler = handler;
        }

        public static void Post(string message)
        {
            if (_uiContext == null)
                return;

            _uiContext.Post(_ =>
            {
                _messageHandler?.Invoke(message);
            }, null);
        }
    }
}
