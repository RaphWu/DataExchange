//using System.Collections.Generic;

//namespace Calin.TaskPulse.Core.ViewModels
//{
//    /// <summary>
//    /// �@�� ViewModel �޲z�� - �� Autofac �޲z�� SingleInstance�C
//    /// �t�d�޲z�Ҧ��@�ɪ� ViewModel ��ҡA�T�O�h�� View �ϥΦP�@�� ViewModel�C
//    /// </summary>
//    public class SharedViewModelManager : ISharedViewModelManager
//    {
//        private readonly object _lock = new object();

//        // �x�s�@�ɪ� ViewModel ���
//        private readonly Dictionary<int, SharedEmployeeViewModel> _employeeViewModels;
//        private readonly Dictionary<int, SharedMachineViewModel> _machineViewModels;
//        private readonly Dictionary<int, SharedTaskOrderViewModel> _workOrderViewModels;

//        /// <summary>
//        /// �غc�禡�]�� Autofac �I�s�^
//        /// </summary>
//        public SharedViewModelManager()
//        {
//            _employeeViewModels = new Dictionary<int, SharedEmployeeViewModel>();
//            _machineViewModels = new Dictionary<int, SharedMachineViewModel>();
//            _workOrderViewModels = new Dictionary<int, SharedTaskOrderViewModel>();
//        }

//        #region Employee ViewModel

//        /// <summary>
//        /// ���o�Ϋإ߭��u ViewModel
//        /// </summary>
//        public SharedEmployeeViewModel GetOrCreateEmployeeViewModel(int employeeId, EmployeeDto dto = null)
//        {
//            lock (_lock)
//            {
//                if (!_employeeViewModels.ContainsKey(employeeId))
//                {
//                    var viewModel = dto != null
//                        ? new SharedEmployeeViewModel(dto)
//                        : new SharedEmployeeViewModel();
//                    _employeeViewModels[employeeId] = viewModel;
//                }
//                else if (dto != null)
//                {
//                    // �p�G�w�s�b�A��s���
//                    _employeeViewModels[employeeId].LoadFromDto(dto);
//                }

//                return _employeeViewModels[employeeId];
//            }
//        }

//        /// <summary>
//        /// ��s���u ViewModel
//        /// </summary>
//        public void UpdateEmployeeViewModel(int employeeId, EmployeeDto dto)
//        {
//            lock (_lock)
//            {
//                if (_employeeViewModels.ContainsKey(employeeId))
//                {
//                    _employeeViewModels[employeeId].LoadFromDto(dto);
//                }
//            }
//        }

//        /// <summary>
//        /// �������u ViewModel
//        /// </summary>
//        public void RemoveEmployeeViewModel(int employeeId)
//        {
//            lock (_lock)
//            {
//                _employeeViewModels.Remove(employeeId);
//            }
//        }

//        /// <summary>
//        /// �ˬd���u ViewModel �O�_�s�b
//        /// </summary>
//        public bool HasEmployeeViewModel(int employeeId)
//        {
//            lock (_lock)
//            {
//                return _employeeViewModels.ContainsKey(employeeId);
//            }
//        }

//        #endregion

//        #region Machine ViewModel

//        /// <summary>
//        /// ���o�Ϋإ߾��x ViewModel
//        /// </summary>
//        public SharedMachineViewModel GetOrCreateMachineViewModel(int machineId, MachineDto dto = null)
//        {
//            lock (_lock)
//            {
//                if (!_machineViewModels.ContainsKey(machineId))
//                {
//                    var viewModel = dto != null
//                        ? new SharedMachineViewModel(dto)
//                        : new SharedMachineViewModel();
//                    _machineViewModels[machineId] = viewModel;
//                }
//                else if (dto != null)
//                {
//                    _machineViewModels[machineId].LoadFromDto(dto);
//                }

//                return _machineViewModels[machineId];
//            }
//        }

//        /// <summary>
//        /// ��s���x ViewModel
//        /// </summary>
//        public void UpdateMachineViewModel(int machineId, MachineDto dto)
//        {
//            lock (_lock)
//            {
//                if (_machineViewModels.ContainsKey(machineId))
//                {
//                    _machineViewModels[machineId].LoadFromDto(dto);
//                }
//            }
//        }

//        /// <summary>
//        /// �������x ViewModel
//        /// </summary>
//        public void RemoveMachineViewModel(int machineId)
//        {
//            lock (_lock)
//            {
//                _machineViewModels.Remove(machineId);
//            }
//        }

//        /// <summary>
//        /// �ˬd���x ViewModel �O�_�s�b
//        /// </summary>
//        public bool HasMachineViewModel(int machineId)
//        {
//            lock (_lock)
//            {
//                return _machineViewModels.ContainsKey(machineId);
//            }
//        }

//        #endregion

//        #region WorkOrder ViewModel

//        /// <summary>
//        /// ���o�Ϋإߺ��@�u�� ViewModel
//        /// </summary>
//        public SharedTaskOrderViewModel GetOrCreateWorkOrderViewModel(int workOrderId, WorkOrderDto dto = null)
//        {
//            lock (_lock)
//            {
//                if (!_workOrderViewModels.ContainsKey(workOrderId))
//                {
//                    var viewModel = dto != null
//                        ? new SharedTaskOrderViewModel(dto)
//                        : new SharedTaskOrderViewModel();
//                    _workOrderViewModels[workOrderId] = viewModel;
//                }
//                else if (dto != null)
//                {
//                    _workOrderViewModels[workOrderId].LoadFromDto(dto);
//                }

//                return _workOrderViewModels[workOrderId];
//            }
//        }

//        /// <summary>
//        /// ��s���@�u�� ViewModel
//        /// </summary>
//        public void UpdateWorkOrderViewModel(int workOrderId, WorkOrderDto dto)
//        {
//            lock (_lock)
//            {
//                if (_workOrderViewModels.ContainsKey(workOrderId))
//                {
//                    _workOrderViewModels[workOrderId].LoadFromDto(dto);
//                }
//            }
//        }

//        /// <summary>
//        /// �������@�u�� ViewModel
//        /// </summary>
//        public void RemoveWorkOrderViewModel(int workOrderId)
//        {
//            lock (_lock)
//            {
//                _workOrderViewModels.Remove(workOrderId);
//            }
//        }

//        /// <summary>
//        /// �ˬd���@�u�� ViewModel �O�_�s�b
//        /// </summary>
//        public bool HasWorkOrderViewModel(int workOrderId)
//        {
//            lock (_lock)
//            {
//                return _workOrderViewModels.ContainsKey(workOrderId);
//            }
//        }

//        #endregion

//        #region �M�z��k

//        /// <summary>
//        /// �M���Ҧ����u ViewModel
//        /// </summary>
//        public void ClearAllEmployeeViewModels()
//        {
//            lock (_lock)
//            {
//                _employeeViewModels.Clear();
//            }
//        }

//        /// <summary>
//        /// �M���Ҧ����x ViewModel
//        /// </summary>
//        public void ClearAllMachineViewModels()
//        {
//            lock (_lock)
//            {
//                _machineViewModels.Clear();
//            }
//        }

//        /// <summary>
//        /// �M���Ҧ����@�u�� ViewModel
//        /// </summary>
//        public void ClearAllWorkOrderViewModels()
//        {
//            lock (_lock)
//            {
//                _workOrderViewModels.Clear();
//            }
//        }

//        /// <summary>
//        /// �M���Ҧ� ViewModel
//        /// </summary>
//        public void ClearAll()
//        {
//            lock (_lock)
//            {
//                _employeeViewModels.Clear();
//                _machineViewModels.Clear();
//                _workOrderViewModels.Clear();
//            }
//        }

//        #endregion

//        #region �έp��T

//        /// <summary>
//        /// ���o�ثe���u ViewModel �ƶq
//        /// </summary>
//        public int EmployeeViewModelCount
//        {
//            get
//            {
//                lock (_lock)
//                {
//                    return _employeeViewModels.Count;
//                }
//            }
//        }

//        /// <summary>
//        /// ���o�ثe���x ViewModel �ƶq
//        /// </summary>
//        public int MachineViewModelCount
//        {
//            get
//            {
//                lock (_lock)
//                {
//                    return _machineViewModels.Count;
//                }
//            }
//        }

//        /// <summary>
//        /// ���o�ثe���@�u�� ViewModel �ƶq
//        /// </summary>
//        public int WorkOrderViewModelCount
//        {
//            get
//            {
//                lock (_lock)
//                {
//                    return _workOrderViewModels.Count;
//                }
//            }
//        }

//        #endregion
//    }
//}
