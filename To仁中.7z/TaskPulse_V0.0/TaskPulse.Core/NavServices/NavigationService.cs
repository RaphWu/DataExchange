﻿namespace Calin.TaskPulse.Core.NavServices
{
    public class NavigationService : INavigationService
    {
        private readonly IRegionManager _regionManager;
        private readonly IViewManager _viewManager;

        public NavigationService(IRegionManager regionManager, IViewManager viewManager)
        {
            _regionManager = regionManager;
            _viewManager = viewManager;
        }

        /// <inheritdoc/>
        public void Navigate<TView>(string regionName, bool alive = true) where TView : class
        {
            var region = _regionManager.GetRegion(regionName);

            // 獲取當前顯示的視圖
            var currentView = region.GetCurrentView() as INavigationAware;
            currentView?.OnNavigatedFrom();

            // 導航到新視圖
            var view = _viewManager.Resolve(typeof(TView), alive);
            region.ShowView(view);

            // 如果新視圖實現了 INavigationAware，調用 OnNavigatedTo
            if (view is INavigationAware navigationAwareView)
            {
                navigationAwareView.OnNavigatedTo();
            }
        }
    }
}
