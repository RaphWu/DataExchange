﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Permission : UserControl, IDisposable
    {
        #region fields

        private const int SYMBOL_CHECK = 61510;
        private const int SYMBOL_UNCHECK = 559445;

        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly ICurrentUserService _currentUser;
        private readonly IPermissionService _permission;
        private string _prefix;

        private PermissionSource _permissionSource;
        private HashSet<PermissionData> _permTable;

        private int _idDepartment;

        private int _idUserGroup;

        private string _idEmployee;
        //private Department _department = null;
        //private Employee _employee = null;

        private int _rSymbolToolQuest = SYMBOL_UNCHECK;
        private int _rSymbolMechaTrack = SYMBOL_UNCHECK;
        private int _rSymbolMaintiFlow = SYMBOL_UNCHECK;
        private int _rSymbolSetup = SYMBOL_UNCHECK;

        #endregion fields

        public Setup_Permission(
            CoreContext coreContext,
            CurrentUserContext currentUserContext,
            ICurrentUserService currentUserService,
            IPermissionService permissionService)
        {
            InitializeComponent();
            _context = coreContext;
            _user = currentUserContext;
            _currentUser = currentUserService;
            _permission = permissionService;

        }
    }
}
