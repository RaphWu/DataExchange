﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Models
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.Workstation_Up = new Sunny.UI.UISymbolButton();
            this.Workstation_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.Workstation_Create = new Sunny.UI.UISymbolButton();
            this.Workstation_Edit = new Sunny.UI.UISymbolButton();
            this.Workstation_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Model_Create = new Sunny.UI.UISymbolButton();
            this.Model_Edit = new Sunny.UI.UISymbolButton();
            this.Model_Modify = new Sunny.UI.UISymbolButton();
            this.Model_Delete = new Sunny.UI.UISymbolButton();
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.ModelStatus_Up = new Sunny.UI.UISymbolButton();
            this.ModelStatus_Down = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.ModelStatus_Create = new Sunny.UI.UISymbolButton();
            this.ModelStatus_Edit = new Sunny.UI.UISymbolButton();
            this.ModelStatus_Delete = new Sunny.UI.UISymbolButton();
            this.List_ModelStatus = new Sunny.UI.UIListBox();
            this.uiListBox1 = new Sunny.UI.UIListBox();
            this.List_Workstations = new Sunny.UI.UIListBox();
            this.Label_Workstation = new System.Windows.Forms.Label();
            this.List_Models = new Sunny.UI.UIListBox();
            this.Label_Model = new System.Windows.Forms.Label();
            this.Label_ModelStatus = new System.Windows.Forms.Label();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel3.AutoSize = true;
            this.flowLayoutPanel3.Controls.Add(this.Workstation_Up);
            this.flowLayoutPanel3.Controls.Add(this.Workstation_Down);
            this.flowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(276, 157);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel3.TabIndex = 6;
            // 
            // Workstation_Up
            // 
            this.Workstation_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Up.Location = new System.Drawing.Point(0, 9);
            this.Workstation_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Workstation_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Up.Name = "Workstation_Up";
            this.Workstation_Up.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Up.Symbol = 361702;
            this.Workstation_Up.SymbolSize = 32;
            this.Workstation_Up.TabIndex = 2;
            this.Workstation_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Up.Click += new System.EventHandler(this.WorkStation_Up_Click);
            // 
            // Workstation_Down
            // 
            this.Workstation_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Down.Location = new System.Drawing.Point(0, 57);
            this.Workstation_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.Workstation_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Down.Name = "Workstation_Down";
            this.Workstation_Down.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Down.Symbol = 361703;
            this.Workstation_Down.SymbolSize = 32;
            this.Workstation_Down.TabIndex = 4;
            this.Workstation_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Down.Click += new System.EventHandler(this.WorkStation_Down_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.Controls.Add(this.Workstation_Create);
            this.flowLayoutPanel4.Controls.Add(this.Workstation_Edit);
            this.flowLayoutPanel4.Controls.Add(this.Workstation_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(347, 632);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 5;
            // 
            // Workstation_Create
            // 
            this.Workstation_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Create.Location = new System.Drawing.Point(9, 0);
            this.Workstation_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Workstation_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Create.Name = "Workstation_Create";
            this.Workstation_Create.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Create.Symbol = 557669;
            this.Workstation_Create.SymbolSize = 32;
            this.Workstation_Create.TabIndex = 2;
            this.Workstation_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Create.Click += new System.EventHandler(this.WorkStation_Create_Click);
            // 
            // Workstation_Edit
            // 
            this.Workstation_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Edit.Location = new System.Drawing.Point(57, 0);
            this.Workstation_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Workstation_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Edit.Name = "Workstation_Edit";
            this.Workstation_Edit.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Edit.Symbol = 559205;
            this.Workstation_Edit.SymbolSize = 32;
            this.Workstation_Edit.TabIndex = 3;
            this.Workstation_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Edit.Click += new System.EventHandler(this.WorkStation_Edit_Click);
            // 
            // Workstation_Delete
            // 
            this.Workstation_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Workstation_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstation_Delete.Location = new System.Drawing.Point(105, 0);
            this.Workstation_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Workstation_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Workstation_Delete.Name = "Workstation_Delete";
            this.Workstation_Delete.Size = new System.Drawing.Size(30, 30);
            this.Workstation_Delete.Symbol = 559506;
            this.Workstation_Delete.SymbolSize = 26;
            this.Workstation_Delete.TabIndex = 4;
            this.Workstation_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Workstation_Delete.Click += new System.EventHandler(this.WorkStation_Delete_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.Model_Create);
            this.flowLayoutPanel1.Controls.Add(this.Model_Edit);
            this.flowLayoutPanel1.Controls.Add(this.Model_Modify);
            this.flowLayoutPanel1.Controls.Add(this.Model_Delete);
            this.flowLayoutPanel1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(39, 632);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(160, 30);
            this.flowLayoutPanel1.TabIndex = 3;
            // 
            // Model_Create
            // 
            this.Model_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Create.Location = new System.Drawing.Point(5, 0);
            this.Model_Create.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Create.Name = "Model_Create";
            this.Model_Create.Size = new System.Drawing.Size(30, 30);
            this.Model_Create.Symbol = 557669;
            this.Model_Create.SymbolSize = 32;
            this.Model_Create.TabIndex = 2;
            this.Model_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Create.Click += new System.EventHandler(this.Model_Create_Click);
            // 
            // Model_Edit
            // 
            this.Model_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Edit.Location = new System.Drawing.Point(45, 0);
            this.Model_Edit.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Edit.Name = "Model_Edit";
            this.Model_Edit.Size = new System.Drawing.Size(30, 30);
            this.Model_Edit.Symbol = 559205;
            this.Model_Edit.SymbolSize = 32;
            this.Model_Edit.TabIndex = 3;
            this.Model_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Edit.Click += new System.EventHandler(this.Model_Edit_Click);
            // 
            // Model_Modify
            // 
            this.Model_Modify.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Modify.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Modify.Location = new System.Drawing.Point(85, 0);
            this.Model_Modify.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Modify.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Modify.Name = "Model_Modify";
            this.Model_Modify.Size = new System.Drawing.Size(30, 30);
            this.Model_Modify.Symbol = 61473;
            this.Model_Modify.SymbolOffset = new System.Drawing.Point(0, 1);
            this.Model_Modify.SymbolSize = 26;
            this.Model_Modify.TabIndex = 4;
            this.Model_Modify.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Modify.Click += new System.EventHandler(this.Model_Modify_Click);
            // 
            // Model_Delete
            // 
            this.Model_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Model_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Model_Delete.Location = new System.Drawing.Point(125, 0);
            this.Model_Delete.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Model_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Model_Delete.Name = "Model_Delete";
            this.Model_Delete.Size = new System.Drawing.Size(30, 30);
            this.Model_Delete.Symbol = 559506;
            this.Model_Delete.SymbolSize = 26;
            this.Model_Delete.TabIndex = 5;
            this.Model_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Model_Delete.Click += new System.EventHandler(this.Model_Delete_Click);
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 7;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 220F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 220F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 220F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel5, 4, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel2, 5, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.List_ModelStatus, 5, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.uiListBox1, 0, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Workstations, 3, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.Label_Workstation, 3, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel3, 2, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel4, 3, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.flowLayoutPanel1, 1, 2);
            this.tableLayoutPanel_Page.Controls.Add(this.List_Models, 1, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.Label_Model, 1, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.Label_ModelStatus, 5, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 3;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(872, 682);
            this.tableLayoutPanel_Page.TabIndex = 1;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.flowLayoutPanel5.AutoSize = true;
            this.flowLayoutPanel5.Controls.Add(this.ModelStatus_Up);
            this.flowLayoutPanel5.Controls.Add(this.ModelStatus_Down);
            this.flowLayoutPanel5.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(576, 157);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 250);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel5.TabIndex = 23;
            // 
            // ModelStatus_Up
            // 
            this.ModelStatus_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ModelStatus_Up.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelStatus_Up.Location = new System.Drawing.Point(0, 9);
            this.ModelStatus_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.ModelStatus_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.ModelStatus_Up.Name = "ModelStatus_Up";
            this.ModelStatus_Up.Size = new System.Drawing.Size(30, 30);
            this.ModelStatus_Up.Symbol = 361702;
            this.ModelStatus_Up.SymbolSize = 32;
            this.ModelStatus_Up.TabIndex = 2;
            this.ModelStatus_Up.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ModelStatus_Up.Click += new System.EventHandler(this.ModelStatus_Up_Click);
            // 
            // ModelStatus_Down
            // 
            this.ModelStatus_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ModelStatus_Down.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelStatus_Down.Location = new System.Drawing.Point(0, 57);
            this.ModelStatus_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.ModelStatus_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.ModelStatus_Down.Name = "ModelStatus_Down";
            this.ModelStatus_Down.Size = new System.Drawing.Size(30, 30);
            this.ModelStatus_Down.Symbol = 361703;
            this.ModelStatus_Down.SymbolSize = 32;
            this.ModelStatus_Down.TabIndex = 4;
            this.ModelStatus_Down.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ModelStatus_Down.Click += new System.EventHandler(this.ModelStatus_Down_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel2.AutoSize = true;
            this.flowLayoutPanel2.Controls.Add(this.ModelStatus_Create);
            this.flowLayoutPanel2.Controls.Add(this.ModelStatus_Edit);
            this.flowLayoutPanel2.Controls.Add(this.ModelStatus_Delete);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(647, 632);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel2.TabIndex = 22;
            // 
            // ModelStatus_Create
            // 
            this.ModelStatus_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ModelStatus_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelStatus_Create.Location = new System.Drawing.Point(9, 0);
            this.ModelStatus_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.ModelStatus_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.ModelStatus_Create.Name = "ModelStatus_Create";
            this.ModelStatus_Create.Size = new System.Drawing.Size(30, 30);
            this.ModelStatus_Create.Symbol = 557669;
            this.ModelStatus_Create.SymbolSize = 32;
            this.ModelStatus_Create.TabIndex = 2;
            this.ModelStatus_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ModelStatus_Create.Click += new System.EventHandler(this.ModelStatus_Create_Click);
            // 
            // ModelStatus_Edit
            // 
            this.ModelStatus_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ModelStatus_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelStatus_Edit.Location = new System.Drawing.Point(57, 0);
            this.ModelStatus_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.ModelStatus_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.ModelStatus_Edit.Name = "ModelStatus_Edit";
            this.ModelStatus_Edit.Size = new System.Drawing.Size(30, 30);
            this.ModelStatus_Edit.Symbol = 559205;
            this.ModelStatus_Edit.SymbolSize = 32;
            this.ModelStatus_Edit.TabIndex = 3;
            this.ModelStatus_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ModelStatus_Edit.Click += new System.EventHandler(this.ModelStatus_Edit_Click);
            // 
            // ModelStatus_Delete
            // 
            this.ModelStatus_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ModelStatus_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelStatus_Delete.Location = new System.Drawing.Point(105, 0);
            this.ModelStatus_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.ModelStatus_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.ModelStatus_Delete.Name = "ModelStatus_Delete";
            this.ModelStatus_Delete.Size = new System.Drawing.Size(30, 30);
            this.ModelStatus_Delete.Symbol = 559506;
            this.ModelStatus_Delete.SymbolSize = 26;
            this.ModelStatus_Delete.TabIndex = 4;
            this.ModelStatus_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ModelStatus_Delete.Click += new System.EventHandler(this.ModelStatus_Delete_Click);
            // 
            // List_ModelStatus
            // 
            this.List_ModelStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_ModelStatus.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_ModelStatus.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_ModelStatus.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_ModelStatus.Location = new System.Drawing.Point(613, 30);
            this.List_ModelStatus.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_ModelStatus.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_ModelStatus.Name = "List_ModelStatus";
            this.List_ModelStatus.Padding = new System.Windows.Forms.Padding(2);
            this.List_ModelStatus.Radius = 1;
            this.List_ModelStatus.ShowText = false;
            this.List_ModelStatus.Size = new System.Drawing.Size(212, 597);
            this.List_ModelStatus.TabIndex = 21;
            this.List_ModelStatus.Text = "uiListBox1";
            this.List_ModelStatus.SelectedIndexChanged += new System.EventHandler(this.List_ModelStatus_SelectedIndexChanged);
            // 
            // uiListBox1
            // 
            this.uiListBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.uiListBox1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiListBox1.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.uiListBox1.ItemSelectForeColor = System.Drawing.Color.White;
            this.uiListBox1.Location = new System.Drawing.Point(4, 5);
            this.uiListBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiListBox1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiListBox1.Name = "uiListBox1";
            this.uiListBox1.Padding = new System.Windows.Forms.Padding(2);
            this.uiListBox1.Radius = 1;
            this.uiListBox1.ShowText = false;
            this.uiListBox1.Size = new System.Drawing.Size(1, 15);
            this.uiListBox1.TabIndex = 20;
            this.uiListBox1.Text = "uiListBox1";
            // 
            // List_Workstations
            // 
            this.List_Workstations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Workstations.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Workstations.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Workstations.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Workstations.Location = new System.Drawing.Point(313, 30);
            this.List_Workstations.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Workstations.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Workstations.Name = "List_Workstations";
            this.List_Workstations.Padding = new System.Windows.Forms.Padding(2);
            this.List_Workstations.Radius = 1;
            this.List_Workstations.ShowText = false;
            this.List_Workstations.Size = new System.Drawing.Size(212, 597);
            this.List_Workstations.TabIndex = 18;
            this.List_Workstations.Text = "uiListBox1";
            this.List_Workstations.SelectedIndexChanged += new System.EventHandler(this.List_Workstations_SelectedIndexChanged);
            // 
            // Label_Workstation
            // 
            this.Label_Workstation.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Label_Workstation.AutoSize = true;
            this.Label_Workstation.Font = new System.Drawing.Font("標楷體", 14F);
            this.Label_Workstation.Location = new System.Drawing.Point(394, 6);
            this.Label_Workstation.Name = "Label_Workstation";
            this.Label_Workstation.Size = new System.Drawing.Size(49, 19);
            this.Label_Workstation.TabIndex = 17;
            this.Label_Workstation.Text = "工站";
            this.Label_Workstation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // List_Models
            // 
            this.List_Models.Dock = System.Windows.Forms.DockStyle.Fill;
            this.List_Models.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.List_Models.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.List_Models.ItemSelectForeColor = System.Drawing.Color.White;
            this.List_Models.Location = new System.Drawing.Point(13, 30);
            this.List_Models.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.List_Models.MinimumSize = new System.Drawing.Size(1, 1);
            this.List_Models.Name = "List_Models";
            this.List_Models.Padding = new System.Windows.Forms.Padding(2);
            this.List_Models.ShowText = false;
            this.List_Models.Size = new System.Drawing.Size(212, 597);
            this.List_Models.TabIndex = 14;
            this.List_Models.Text = "uiListBox1";
            this.List_Models.SelectedIndexChanged += new System.EventHandler(this.List_Models_SelectedIndexChanged);
            // 
            // Label_Model
            // 
            this.Label_Model.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Label_Model.AutoSize = true;
            this.Label_Model.Font = new System.Drawing.Font("標楷體", 14F);
            this.Label_Model.Location = new System.Drawing.Point(94, 6);
            this.Label_Model.Name = "Label_Model";
            this.Label_Model.Size = new System.Drawing.Size(49, 19);
            this.Label_Model.TabIndex = 16;
            this.Label_Model.Text = "機種";
            this.Label_Model.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_ModelStatus
            // 
            this.Label_ModelStatus.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Label_ModelStatus.AutoSize = true;
            this.Label_ModelStatus.Font = new System.Drawing.Font("標楷體", 14F);
            this.Label_ModelStatus.Location = new System.Drawing.Point(694, 6);
            this.Label_ModelStatus.Name = "Label_ModelStatus";
            this.Label_ModelStatus.Size = new System.Drawing.Size(49, 19);
            this.Label_ModelStatus.TabIndex = 19;
            this.Label_ModelStatus.Text = "狀態";
            this.Label_ModelStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Setup_Models
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_Models";
            this.Size = new System.Drawing.Size(872, 682);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.tableLayoutPanel_Page.PerformLayout();
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Sunny.UI.UISymbolButton Model_Create;
        private Sunny.UI.UISymbolButton Model_Edit;
        private Sunny.UI.UISymbolButton Model_Modify;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton Workstation_Create;
        private Sunny.UI.UISymbolButton Workstation_Edit;
        private Sunny.UI.UISymbolButton Workstation_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private Sunny.UI.UISymbolButton Workstation_Up;
        private Sunny.UI.UISymbolButton Workstation_Down;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private Sunny.UI.UIListBox List_Models;
        private System.Windows.Forms.Label Label_Workstation;
        private System.Windows.Forms.Label Label_Model;
        private Sunny.UI.UIListBox List_Workstations;
        private Sunny.UI.UIListBox List_ModelStatus;
        private Sunny.UI.UIListBox uiListBox1;
        private System.Windows.Forms.Label Label_ModelStatus;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private Sunny.UI.UISymbolButton ModelStatus_Up;
        private Sunny.UI.UISymbolButton ModelStatus_Down;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private Sunny.UI.UISymbolButton ModelStatus_Create;
        private Sunny.UI.UISymbolButton ModelStatus_Edit;
        private Sunny.UI.UISymbolButton ModelStatus_Delete;
        private Sunny.UI.UISymbolButton Model_Delete;
    }
}
