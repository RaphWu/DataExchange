﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class MF_MaintiWork
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCompleted = new Sunny.UI.UISymbolButton();
            this.btnSave = new Sunny.UI.UISymbolButton();
            this.btnCancel = new Sunny.UI.UISymbolButton();
            this.Details = new Sunny.UI.UIRichTextBox();
            this.IssueDescription = new Sunny.UI.UIRichTextBox();
            this.IssueCategory = new Sunny.UI.UIComboBox();
            this.MaintenanceUnit = new Sunny.UI.UIComboBox();
            this.Label_RequestingUnit = new Sunny.UI.UILabel();
            this.RequestingUnit = new Sunny.UI.UITextBox();
            this.RepairStarted = new Sunny.UI.UIDatetimePicker();
            this.OutageEnded = new Sunny.UI.UIDatetimePicker();
            this.RepairCompleted = new Sunny.UI.UIDatetimePicker();
            this.OutageDuration = new Sunny.UI.UITextBox();
            this.RepairDuration = new Sunny.UI.UITextBox();
            this.Label_OutageDuration = new Sunny.UI.UILabel();
            this.Label_RepairDuration = new Sunny.UI.UILabel();
            this.Label_OutageEnded = new Sunny.UI.UILabel();
            this.Label_RepairCompleted = new Sunny.UI.UILabel();
            this.Label_RepairStarted = new Sunny.UI.UILabel();
            this.Label_IssueDescription = new Sunny.UI.UILabel();
            this.AcceptedTime = new Sunny.UI.UITextBox();
            this.Label_AcceptedTime = new Sunny.UI.UILabel();
            this.Label_IssueCategory = new Sunny.UI.UILabel();
            this.Label_Engineers = new Sunny.UI.UILabel();
            this.Label_MaintenanceUnit = new Sunny.UI.UILabel();
            this.Label_OutageStarted = new Sunny.UI.UILabel();
            this.ModelWorkstation = new Sunny.UI.UITextBox();
            this.Label_ModelWorkstation = new Sunny.UI.UILabel();
            this.MachineList = new Sunny.UI.UITextBox();
            this.Label_MachineList = new Sunny.UI.UILabel();
            this.CreationDate = new Sunny.UI.UITextBox();
            this.Label_CreationDate = new Sunny.UI.UILabel();
            this.Label_Creator = new Sunny.UI.UILabel();
            this.Creator = new Sunny.UI.UITextBox();
            this.Label_WorkOrderNo = new Sunny.UI.UILabel();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.Label_Details = new Sunny.UI.UILabel();
            this.splitContainer_Orders = new System.Windows.Forms.SplitContainer();
            this.label_ListBox = new System.Windows.Forms.Label();
            this.ListBoxOrders = new Sunny.UI.UIListBox();
            this.panelList = new System.Windows.Forms.Panel();
            this.btnTransfer = new Sunny.UI.UISymbolButton();
            this.Engineers = new Sunny.UI.UITextBox();
            this.btnQuickCreate = new Sunny.UI.UISymbolButton();
            this.OutageStarted = new Sunny.UI.UIDatetimePicker();
            this.Notification = new Sunny.UI.UITextBox();
            this.uiLabel1 = new Sunny.UI.UILabel();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_Orders)).BeginInit();
            this.splitContainer_Orders.Panel1.SuspendLayout();
            this.splitContainer_Orders.Panel2.SuspendLayout();
            this.splitContainer_Orders.SuspendLayout();
            this.panelList.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCompleted
            // 
            this.btnCompleted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCompleted.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCompleted.Location = new System.Drawing.Point(855, 587);
            this.btnCompleted.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCompleted.Name = "btnCompleted";
            this.btnCompleted.Radius = 10;
            this.btnCompleted.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnCompleted.Size = new System.Drawing.Size(110, 35);
            this.btnCompleted.Symbol = 61452;
            this.btnCompleted.TabIndex = 8;
            this.btnCompleted.Text = "維護完成";
            this.btnCompleted.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCompleted.Click += new System.EventHandler(this.button_Completed_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnSave.Location = new System.Drawing.Point(725, 587);
            this.btnSave.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Radius = 10;
            this.btnSave.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnSave.Size = new System.Drawing.Size(110, 35);
            this.btnSave.Symbol = 61639;
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "儲存";
            this.btnSave.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSave.Click += new System.EventHandler(this.Button_Save_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCancel.Location = new System.Drawing.Point(725, 628);
            this.btnCancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Radius = 10;
            this.btnCancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnCancel.Size = new System.Drawing.Size(110, 35);
            this.btnCancel.Style = Sunny.UI.UIStyle.Custom;
            this.btnCancel.Symbol = 361453;
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "取消";
            this.btnCancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Click += new System.EventHandler(this.Button_Cancel_Click);
            // 
            // Details
            // 
            this.Details.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Details.FillColor = System.Drawing.Color.White;
            this.Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Details.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Details.Location = new System.Drawing.Point(710, 382);
            this.Details.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Details.MinimumSize = new System.Drawing.Size(1, 1);
            this.Details.Name = "Details";
            this.Details.Padding = new System.Windows.Forms.Padding(2);
            this.Details.ShowText = false;
            this.Details.Size = new System.Drawing.Size(255, 183);
            this.Details.TabIndex = 89;
            this.Details.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // IssueDescription
            // 
            this.IssueDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IssueDescription.FillColor = System.Drawing.Color.White;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.IssueDescription.Location = new System.Drawing.Point(710, 247);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(2);
            this.IssueDescription.ReadOnly = true;
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(255, 125);
            this.IssueDescription.TabIndex = 88;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // IssueCategory
            // 
            this.IssueCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.IssueCategory.DataSource = null;
            this.IssueCategory.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.IssueCategory.FillColor = System.Drawing.Color.White;
            this.IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.IssueCategory.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.IssueCategory.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.IssueCategory.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.IssueCategory.Location = new System.Drawing.Point(349, 266);
            this.IssueCategory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueCategory.MinimumSize = new System.Drawing.Size(63, 0);
            this.IssueCategory.Name = "IssueCategory";
            this.IssueCategory.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.IssueCategory.Size = new System.Drawing.Size(255, 29);
            this.IssueCategory.SymbolSize = 24;
            this.IssueCategory.TabIndex = 87;
            this.IssueCategory.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.IssueCategory.Watermark = "";
            // 
            // MaintenanceUnit
            // 
            this.MaintenanceUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MaintenanceUnit.DataSource = null;
            this.MaintenanceUnit.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.MaintenanceUnit.FillColor = System.Drawing.Color.White;
            this.MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaintenanceUnit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MaintenanceUnit.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.Location = new System.Drawing.Point(349, 188);
            this.MaintenanceUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaintenanceUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.MaintenanceUnit.Name = "MaintenanceUnit";
            this.MaintenanceUnit.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.MaintenanceUnit.Size = new System.Drawing.Size(255, 29);
            this.MaintenanceUnit.SymbolSize = 24;
            this.MaintenanceUnit.TabIndex = 86;
            this.MaintenanceUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceUnit.Watermark = "";
            this.MaintenanceUnit.SelectedIndexChanged += new System.EventHandler(this.MaintenanceUnit_SelectedIndexChanged);
            // 
            // Label_RequestingUnit
            // 
            this.Label_RequestingUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RequestingUnit.BackColor = System.Drawing.Color.Transparent;
            this.Label_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RequestingUnit.Location = new System.Drawing.Point(611, 52);
            this.Label_RequestingUnit.Name = "Label_RequestingUnit";
            this.Label_RequestingUnit.Size = new System.Drawing.Size(92, 29);
            this.Label_RequestingUnit.TabIndex = 85;
            this.Label_RequestingUnit.Text = "需求單位";
            this.Label_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RequestingUnit
            // 
            this.RequestingUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RequestingUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RequestingUnit.FillDisableColor = System.Drawing.Color.White;
            this.RequestingUnit.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.Black;
            this.RequestingUnit.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.RequestingUnit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.RequestingUnit.Location = new System.Drawing.Point(710, 52);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(1, 16);
            this.RequestingUnit.Name = "RequestingUnit";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(5);
            this.RequestingUnit.ShowText = false;
            this.RequestingUnit.Size = new System.Drawing.Size(200, 29);
            this.RequestingUnit.TabIndex = 84;
            this.RequestingUnit.TabStop = false;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // RepairStarted
            // 
            this.RepairStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RepairStarted.CanEmpty = true;
            this.RepairStarted.DateFormat = "yyyy/MM/dd HH:mm";
            this.RepairStarted.FillColor = System.Drawing.Color.White;
            this.RepairStarted.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairStarted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairStarted.Location = new System.Drawing.Point(349, 326);
            this.RepairStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairStarted.MaxLength = 16;
            this.RepairStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.RepairStarted.Name = "RepairStarted";
            this.RepairStarted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.RepairStarted.ShowToday = true;
            this.RepairStarted.Size = new System.Drawing.Size(255, 29);
            this.RepairStarted.SymbolDropDown = 61555;
            this.RepairStarted.SymbolNormal = 61555;
            this.RepairStarted.SymbolSize = 24;
            this.RepairStarted.TabIndex = 83;
            this.RepairStarted.Text = "1900/01/01 00:00";
            this.RepairStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairStarted.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.RepairStarted.Watermark = "";
            this.RepairStarted.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.RepairStarted_ValueChanged);
            // 
            // OutageEnded
            // 
            this.OutageEnded.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OutageEnded.CanEmpty = true;
            this.OutageEnded.DateFormat = "yyyy/MM/dd HH:mm";
            this.OutageEnded.FillColor = System.Drawing.Color.White;
            this.OutageEnded.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageEnded.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageEnded.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageEnded.Location = new System.Drawing.Point(349, 497);
            this.OutageEnded.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageEnded.MaxLength = 16;
            this.OutageEnded.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageEnded.Name = "OutageEnded";
            this.OutageEnded.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.OutageEnded.ShowToday = true;
            this.OutageEnded.Size = new System.Drawing.Size(255, 29);
            this.OutageEnded.SymbolDropDown = 61555;
            this.OutageEnded.SymbolNormal = 61555;
            this.OutageEnded.SymbolSize = 24;
            this.OutageEnded.TabIndex = 83;
            this.OutageEnded.Text = "1900/01/01 00:00";
            this.OutageEnded.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageEnded.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.OutageEnded.Watermark = "";
            this.OutageEnded.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.OutageEnded_ValueChanged);
            // 
            // RepairCompleted
            // 
            this.RepairCompleted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RepairCompleted.CanEmpty = true;
            this.RepairCompleted.DateFormat = "yyyy/MM/dd HH:mm";
            this.RepairCompleted.FillColor = System.Drawing.Color.White;
            this.RepairCompleted.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairCompleted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairCompleted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairCompleted.Location = new System.Drawing.Point(349, 365);
            this.RepairCompleted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairCompleted.MaxLength = 16;
            this.RepairCompleted.MinimumSize = new System.Drawing.Size(63, 0);
            this.RepairCompleted.Name = "RepairCompleted";
            this.RepairCompleted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.RepairCompleted.ShowToday = true;
            this.RepairCompleted.Size = new System.Drawing.Size(255, 29);
            this.RepairCompleted.SymbolDropDown = 61555;
            this.RepairCompleted.SymbolNormal = 61555;
            this.RepairCompleted.SymbolSize = 24;
            this.RepairCompleted.TabIndex = 82;
            this.RepairCompleted.Text = "1900/01/01 00:00";
            this.RepairCompleted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairCompleted.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.RepairCompleted.Watermark = "";
            this.RepairCompleted.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.RepairCompleted_ValueChanged);
            // 
            // OutageDuration
            // 
            this.OutageDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OutageDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageDuration.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageDuration.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.OutageDuration.Location = new System.Drawing.Point(349, 536);
            this.OutageDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageDuration.Name = "OutageDuration";
            this.OutageDuration.Padding = new System.Windows.Forms.Padding(5);
            this.OutageDuration.ShowText = false;
            this.OutageDuration.Size = new System.Drawing.Size(255, 29);
            this.OutageDuration.TabIndex = 79;
            this.OutageDuration.TabStop = false;
            this.OutageDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageDuration.Watermark = "";
            // 
            // RepairDuration
            // 
            this.RepairDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RepairDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairDuration.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairDuration.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.RepairDuration.Location = new System.Drawing.Point(349, 404);
            this.RepairDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairDuration.Name = "RepairDuration";
            this.RepairDuration.Padding = new System.Windows.Forms.Padding(5);
            this.RepairDuration.ShowText = false;
            this.RepairDuration.Size = new System.Drawing.Size(255, 29);
            this.RepairDuration.TabIndex = 71;
            this.RepairDuration.TabStop = false;
            this.RepairDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairDuration.Watermark = "";
            // 
            // Label_OutageDuration
            // 
            this.Label_OutageDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_OutageDuration.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageDuration.Location = new System.Drawing.Point(233, 536);
            this.Label_OutageDuration.Name = "Label_OutageDuration";
            this.Label_OutageDuration.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageDuration.TabIndex = 81;
            this.Label_OutageDuration.Text = "停動工時";
            this.Label_OutageDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairDuration
            // 
            this.Label_RepairDuration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RepairDuration.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairDuration.Location = new System.Drawing.Point(233, 404);
            this.Label_RepairDuration.Name = "Label_RepairDuration";
            this.Label_RepairDuration.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairDuration.TabIndex = 73;
            this.Label_RepairDuration.Text = "維護工時";
            this.Label_RepairDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageEnded
            // 
            this.Label_OutageEnded.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_OutageEnded.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageEnded.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageEnded.Location = new System.Drawing.Point(233, 497);
            this.Label_OutageEnded.Name = "Label_OutageEnded";
            this.Label_OutageEnded.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageEnded.TabIndex = 76;
            this.Label_OutageEnded.Text = "停動結束時間";
            this.Label_OutageEnded.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairCompleted
            // 
            this.Label_RepairCompleted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RepairCompleted.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairCompleted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairCompleted.Location = new System.Drawing.Point(233, 365);
            this.Label_RepairCompleted.Name = "Label_RepairCompleted";
            this.Label_RepairCompleted.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairCompleted.TabIndex = 70;
            this.Label_RepairCompleted.Text = "維護完成時間";
            this.Label_RepairCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairStarted
            // 
            this.Label_RepairStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_RepairStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairStarted.Location = new System.Drawing.Point(233, 326);
            this.Label_RepairStarted.Name = "Label_RepairStarted";
            this.Label_RepairStarted.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairStarted.TabIndex = 67;
            this.Label_RepairStarted.Text = "維護開始時間";
            this.Label_RepairStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_IssueDescription
            // 
            this.Label_IssueDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueDescription.Location = new System.Drawing.Point(613, 247);
            this.Label_IssueDescription.Name = "Label_IssueDescription";
            this.Label_IssueDescription.Size = new System.Drawing.Size(90, 29);
            this.Label_IssueDescription.TabIndex = 74;
            this.Label_IssueDescription.Text = "問題描述";
            this.Label_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // AcceptedTime
            // 
            this.AcceptedTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AcceptedTime.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AcceptedTime.FillDisableColor = System.Drawing.Color.White;
            this.AcceptedTime.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.AcceptedTime.ForeDisableColor = System.Drawing.Color.Black;
            this.AcceptedTime.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.AcceptedTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AcceptedTime.Location = new System.Drawing.Point(710, 208);
            this.AcceptedTime.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AcceptedTime.MinimumSize = new System.Drawing.Size(1, 16);
            this.AcceptedTime.Name = "AcceptedTime";
            this.AcceptedTime.Padding = new System.Windows.Forms.Padding(5);
            this.AcceptedTime.ShowText = false;
            this.AcceptedTime.Size = new System.Drawing.Size(200, 29);
            this.AcceptedTime.TabIndex = 47;
            this.AcceptedTime.TabStop = false;
            this.AcceptedTime.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.AcceptedTime.Watermark = "";
            // 
            // Label_AcceptedTime
            // 
            this.Label_AcceptedTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_AcceptedTime.BackColor = System.Drawing.Color.Transparent;
            this.Label_AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_AcceptedTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_AcceptedTime.Location = new System.Drawing.Point(611, 208);
            this.Label_AcceptedTime.Name = "Label_AcceptedTime";
            this.Label_AcceptedTime.Size = new System.Drawing.Size(92, 29);
            this.Label_AcceptedTime.TabIndex = 49;
            this.Label_AcceptedTime.Text = "接單時間";
            this.Label_AcceptedTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_IssueCategory
            // 
            this.Label_IssueCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_IssueCategory.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueCategory.Location = new System.Drawing.Point(233, 266);
            this.Label_IssueCategory.Name = "Label_IssueCategory";
            this.Label_IssueCategory.Size = new System.Drawing.Size(109, 29);
            this.Label_IssueCategory.TabIndex = 64;
            this.Label_IssueCategory.Text = "維護類型";
            this.Label_IssueCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Engineers
            // 
            this.Label_Engineers.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Engineers.BackColor = System.Drawing.Color.Transparent;
            this.Label_Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Engineers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Engineers.Location = new System.Drawing.Point(233, 227);
            this.Label_Engineers.Name = "Label_Engineers";
            this.Label_Engineers.Size = new System.Drawing.Size(109, 29);
            this.Label_Engineers.TabIndex = 57;
            this.Label_Engineers.Text = "維護工程師";
            this.Label_Engineers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_MaintenanceUnit
            // 
            this.Label_MaintenanceUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_MaintenanceUnit.BackColor = System.Drawing.Color.Transparent;
            this.Label_MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MaintenanceUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MaintenanceUnit.Location = new System.Drawing.Point(233, 188);
            this.Label_MaintenanceUnit.Name = "Label_MaintenanceUnit";
            this.Label_MaintenanceUnit.Size = new System.Drawing.Size(109, 29);
            this.Label_MaintenanceUnit.TabIndex = 53;
            this.Label_MaintenanceUnit.Text = "維護單位";
            this.Label_MaintenanceUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageStarted
            // 
            this.Label_OutageStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageStarted.Location = new System.Drawing.Point(233, 458);
            this.Label_OutageStarted.Name = "Label_OutageStarted";
            this.Label_OutageStarted.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageStarted.TabIndex = 63;
            this.Label_OutageStarted.Text = "停動開始時間";
            this.Label_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ModelWorkstation
            // 
            this.ModelWorkstation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ModelWorkstation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ModelWorkstation.FillDisableColor = System.Drawing.Color.White;
            this.ModelWorkstation.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.ModelWorkstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelWorkstation.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.ModelWorkstation.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ModelWorkstation.Location = new System.Drawing.Point(349, 130);
            this.ModelWorkstation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ModelWorkstation.MinimumSize = new System.Drawing.Size(1, 16);
            this.ModelWorkstation.Name = "ModelWorkstation";
            this.ModelWorkstation.Padding = new System.Windows.Forms.Padding(5);
            this.ModelWorkstation.ShowButton = true;
            this.ModelWorkstation.ShowText = false;
            this.ModelWorkstation.Size = new System.Drawing.Size(255, 29);
            this.ModelWorkstation.TabIndex = 52;
            this.ModelWorkstation.TabStop = false;
            this.ModelWorkstation.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ModelWorkstation.Watermark = "";
            this.ModelWorkstation.ButtonClick += new System.EventHandler(this.ModelWorkstation_ButtonClick);
            this.ModelWorkstation.Validated += new System.EventHandler(this.ModelWorkstation_Validated);
            // 
            // Label_ModelWorkstation
            // 
            this.Label_ModelWorkstation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_ModelWorkstation.BackColor = System.Drawing.Color.Transparent;
            this.Label_ModelWorkstation.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_ModelWorkstation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_ModelWorkstation.Location = new System.Drawing.Point(233, 130);
            this.Label_ModelWorkstation.Name = "Label_ModelWorkstation";
            this.Label_ModelWorkstation.Size = new System.Drawing.Size(109, 29);
            this.Label_ModelWorkstation.TabIndex = 54;
            this.Label_ModelWorkstation.Text = "機種";
            this.Label_ModelWorkstation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineList
            // 
            this.MachineList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MachineList.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineList.FillDisableColor = System.Drawing.Color.White;
            this.MachineList.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineList.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MachineList.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MachineList.Location = new System.Drawing.Point(349, 91);
            this.MachineList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineList.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineList.Name = "MachineList";
            this.MachineList.Padding = new System.Windows.Forms.Padding(5);
            this.MachineList.ShowText = false;
            this.MachineList.Size = new System.Drawing.Size(255, 29);
            this.MachineList.TabIndex = 46;
            this.MachineList.TabStop = false;
            this.MachineList.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineList.Watermark = "";
            // 
            // Label_MachineList
            // 
            this.Label_MachineList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.Label_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MachineList.Location = new System.Drawing.Point(233, 91);
            this.Label_MachineList.Name = "Label_MachineList";
            this.Label_MachineList.Size = new System.Drawing.Size(109, 29);
            this.Label_MachineList.TabIndex = 48;
            this.Label_MachineList.Text = "機台編號";
            this.Label_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CreationDate
            // 
            this.CreationDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CreationDate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CreationDate.FillDisableColor = System.Drawing.Color.White;
            this.CreationDate.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.CreationDate.ForeDisableColor = System.Drawing.Color.Black;
            this.CreationDate.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.CreationDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.CreationDate.Location = new System.Drawing.Point(710, 169);
            this.CreationDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CreationDate.MinimumSize = new System.Drawing.Size(1, 16);
            this.CreationDate.Name = "CreationDate";
            this.CreationDate.Padding = new System.Windows.Forms.Padding(5);
            this.CreationDate.ShowText = false;
            this.CreationDate.Size = new System.Drawing.Size(200, 29);
            this.CreationDate.TabIndex = 42;
            this.CreationDate.TabStop = false;
            this.CreationDate.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.CreationDate.Watermark = "";
            // 
            // Label_CreationDate
            // 
            this.Label_CreationDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_CreationDate.BackColor = System.Drawing.Color.Transparent;
            this.Label_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_CreationDate.Location = new System.Drawing.Point(611, 169);
            this.Label_CreationDate.Name = "Label_CreationDate";
            this.Label_CreationDate.Size = new System.Drawing.Size(92, 29);
            this.Label_CreationDate.TabIndex = 44;
            this.Label_CreationDate.Text = "建檔日期";
            this.Label_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_Creator
            // 
            this.Label_Creator.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Creator.BackColor = System.Drawing.Color.Transparent;
            this.Label_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Creator.Location = new System.Drawing.Point(611, 91);
            this.Label_Creator.Name = "Label_Creator";
            this.Label_Creator.Size = new System.Drawing.Size(92, 29);
            this.Label_Creator.TabIndex = 43;
            this.Label_Creator.Text = "建檔人員";
            this.Label_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Creator
            // 
            this.Creator.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.FillDisableColor = System.Drawing.Color.White;
            this.Creator.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.Black;
            this.Creator.ForeReadOnlyColor = System.Drawing.Color.Black;
            this.Creator.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Creator.Location = new System.Drawing.Point(710, 91);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(200, 29);
            this.Creator.TabIndex = 40;
            this.Creator.TabStop = false;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            // 
            // Label_WorkOrderNo
            // 
            this.Label_WorkOrderNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_WorkOrderNo.BackColor = System.Drawing.Color.Transparent;
            this.Label_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_WorkOrderNo.Location = new System.Drawing.Point(233, 52);
            this.Label_WorkOrderNo.Name = "Label_WorkOrderNo";
            this.Label_WorkOrderNo.Size = new System.Drawing.Size(109, 29);
            this.Label_WorkOrderNo.TabIndex = 38;
            this.Label_WorkOrderNo.Text = "維護工單編號";
            this.Label_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.FillDisableColor = System.Drawing.Color.White;
            this.WorkOrderNo.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.WorkOrderNo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.WorkOrderNo.Location = new System.Drawing.Point(349, 52);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(255, 29);
            this.WorkOrderNo.TabIndex = 37;
            this.WorkOrderNo.TabStop = false;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // Label_Details
            // 
            this.Label_Details.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Details.BackColor = System.Drawing.Color.Transparent;
            this.Label_Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Details.Location = new System.Drawing.Point(613, 382);
            this.Label_Details.Name = "Label_Details";
            this.Label_Details.Size = new System.Drawing.Size(90, 29);
            this.Label_Details.TabIndex = 78;
            this.Label_Details.Text = "維護內容";
            this.Label_Details.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // splitContainer_Orders
            // 
            this.splitContainer_Orders.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer_Orders.Location = new System.Drawing.Point(0, 0);
            this.splitContainer_Orders.Name = "splitContainer_Orders";
            this.splitContainer_Orders.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer_Orders.Panel1
            // 
            this.splitContainer_Orders.Panel1.Controls.Add(this.label_ListBox);
            // 
            // splitContainer_Orders.Panel2
            // 
            this.splitContainer_Orders.Panel2.Controls.Add(this.ListBoxOrders);
            this.splitContainer_Orders.Size = new System.Drawing.Size(220, 633);
            this.splitContainer_Orders.SplitterDistance = 25;
            this.splitContainer_Orders.TabIndex = 2;
            // 
            // label_ListBox
            // 
            this.label_ListBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label_ListBox.AutoSize = true;
            this.label_ListBox.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_ListBox.Location = new System.Drawing.Point(68, 4);
            this.label_ListBox.Name = "label_ListBox";
            this.label_ListBox.Size = new System.Drawing.Size(73, 20);
            this.label_ListBox.TabIndex = 0;
            this.label_ListBox.Text = "已接工單";
            this.label_ListBox.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // ListBoxOrders
            // 
            this.ListBoxOrders.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ListBoxOrders.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ListBoxOrders.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.ListBoxOrders.ItemSelectForeColor = System.Drawing.Color.White;
            this.ListBoxOrders.Location = new System.Drawing.Point(0, 0);
            this.ListBoxOrders.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ListBoxOrders.MinimumSize = new System.Drawing.Size(1, 1);
            this.ListBoxOrders.Name = "ListBoxOrders";
            this.ListBoxOrders.Padding = new System.Windows.Forms.Padding(2);
            this.ListBoxOrders.ShowText = false;
            this.ListBoxOrders.Size = new System.Drawing.Size(220, 604);
            this.ListBoxOrders.TabIndex = 0;
            this.ListBoxOrders.Text = "uiListBox1";
            this.ListBoxOrders.SelectedIndexChanged += new System.EventHandler(this.ListBoxOrders_SelectedIndexChanged);
            // 
            // panelList
            // 
            this.panelList.Controls.Add(this.splitContainer_Orders);
            this.panelList.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelList.Location = new System.Drawing.Point(3, 38);
            this.panelList.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.panelList.Name = "panelList";
            this.panelList.Size = new System.Drawing.Size(220, 633);
            this.panelList.TabIndex = 94;
            // 
            // btnTransfer
            // 
            this.btnTransfer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTransfer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransfer.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnTransfer.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnTransfer.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnTransfer.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTransfer.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTransfer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnTransfer.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnTransfer.Location = new System.Drawing.Point(855, 628);
            this.btnTransfer.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Radius = 10;
            this.btnTransfer.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnTransfer.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnTransfer.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTransfer.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTransfer.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnTransfer.Size = new System.Drawing.Size(110, 35);
            this.btnTransfer.Style = Sunny.UI.UIStyle.Custom;
            this.btnTransfer.Symbol = 61473;
            this.btnTransfer.TabIndex = 95;
            this.btnTransfer.Text = "轉移工單";
            this.btnTransfer.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnTransfer.Click += new System.EventHandler(this.btnTransfer_Click);
            // 
            // Engineers
            // 
            this.Engineers.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Engineers.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Engineers.FillDisableColor = System.Drawing.Color.White;
            this.Engineers.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Engineers.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Engineers.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Engineers.Location = new System.Drawing.Point(349, 227);
            this.Engineers.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Engineers.MinimumSize = new System.Drawing.Size(1, 16);
            this.Engineers.Name = "Engineers";
            this.Engineers.Padding = new System.Windows.Forms.Padding(5);
            this.Engineers.ShowButton = true;
            this.Engineers.ShowText = false;
            this.Engineers.Size = new System.Drawing.Size(255, 29);
            this.Engineers.TabIndex = 53;
            this.Engineers.TabStop = false;
            this.Engineers.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Engineers.Watermark = "";
            this.Engineers.ButtonClick += new System.EventHandler(this.Engineers_ButtonClick);
            this.Engineers.Validated += new System.EventHandler(this.Engineers_Validated);
            // 
            // btnQuickCreate
            // 
            this.btnQuickCreate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuickCreate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuickCreate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnQuickCreate.Location = new System.Drawing.Point(593, 587);
            this.btnQuickCreate.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnQuickCreate.Name = "btnQuickCreate";
            this.btnQuickCreate.Radius = 10;
            this.btnQuickCreate.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnQuickCreate.Size = new System.Drawing.Size(110, 76);
            this.btnQuickCreate.Symbol = 362042;
            this.btnQuickCreate.TabIndex = 96;
            this.btnQuickCreate.Text = "一鍵補單";
            this.btnQuickCreate.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnQuickCreate.Click += new System.EventHandler(this.btnQuickCreate_Click);
            // 
            // OutageStarted
            // 
            this.OutageStarted.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OutageStarted.CanEmpty = true;
            this.OutageStarted.DateFormat = "yyyy/MM/dd HH:mm";
            this.OutageStarted.FillColor = System.Drawing.Color.White;
            this.OutageStarted.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageStarted.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageStarted.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageStarted.Location = new System.Drawing.Point(349, 458);
            this.OutageStarted.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageStarted.MaxLength = 16;
            this.OutageStarted.MinimumSize = new System.Drawing.Size(63, 0);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.OutageStarted.ShowToday = true;
            this.OutageStarted.Size = new System.Drawing.Size(255, 29);
            this.OutageStarted.SymbolDropDown = 61555;
            this.OutageStarted.SymbolNormal = 61555;
            this.OutageStarted.SymbolSize = 24;
            this.OutageStarted.TabIndex = 84;
            this.OutageStarted.Text = "1900/01/01 00:00";
            this.OutageStarted.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageStarted.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.OutageStarted.Watermark = "";
            this.OutageStarted.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.OutageStarted_ValueChanged);
            // 
            // Notification
            // 
            this.Notification.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Notification.FillDisableColor = System.Drawing.Color.White;
            this.Notification.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.Notification.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Notification.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Notification.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Notification.Location = new System.Drawing.Point(710, 130);
            this.Notification.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Notification.MinimumSize = new System.Drawing.Size(1, 16);
            this.Notification.Name = "Notification";
            this.Notification.Padding = new System.Windows.Forms.Padding(5);
            this.Notification.ShowButton = true;
            this.Notification.ShowText = false;
            this.Notification.Size = new System.Drawing.Size(200, 29);
            this.Notification.TabIndex = 111;
            this.Notification.TabStop = false;
            this.Notification.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Notification.Watermark = "";
            this.Notification.ButtonClick += new System.EventHandler(this.Notification_ButtonClick);
            this.Notification.Validated += new System.EventHandler(this.Notification_Validated);
            // 
            // uiLabel1
            // 
            this.uiLabel1.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel1.Location = new System.Drawing.Point(623, 130);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(80, 29);
            this.uiLabel1.TabIndex = 110;
            this.uiLabel1.Text = "通知人員";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MF_MaintiWork
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(987, 674);
            this.Controls.Add(this.Notification);
            this.Controls.Add(this.uiLabel1);
            this.Controls.Add(this.OutageStarted);
            this.Controls.Add(this.btnQuickCreate);
            this.Controls.Add(this.Engineers);
            this.Controls.Add(this.btnTransfer);
            this.Controls.Add(this.btnCompleted);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.panelList);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.RequestingUnit);
            this.Controls.Add(this.Label_Details);
            this.Controls.Add(this.Details);
            this.Controls.Add(this.WorkOrderNo);
            this.Controls.Add(this.IssueDescription);
            this.Controls.Add(this.Label_WorkOrderNo);
            this.Controls.Add(this.Creator);
            this.Controls.Add(this.IssueCategory);
            this.Controls.Add(this.Label_Creator);
            this.Controls.Add(this.Label_CreationDate);
            this.Controls.Add(this.MaintenanceUnit);
            this.Controls.Add(this.CreationDate);
            this.Controls.Add(this.Label_RequestingUnit);
            this.Controls.Add(this.Label_MachineList);
            this.Controls.Add(this.MachineList);
            this.Controls.Add(this.RepairStarted);
            this.Controls.Add(this.Label_ModelWorkstation);
            this.Controls.Add(this.OutageEnded);
            this.Controls.Add(this.ModelWorkstation);
            this.Controls.Add(this.RepairCompleted);
            this.Controls.Add(this.Label_OutageStarted);
            this.Controls.Add(this.OutageDuration);
            this.Controls.Add(this.Label_MaintenanceUnit);
            this.Controls.Add(this.RepairDuration);
            this.Controls.Add(this.Label_Engineers);
            this.Controls.Add(this.Label_OutageDuration);
            this.Controls.Add(this.Label_IssueCategory);
            this.Controls.Add(this.Label_RepairDuration);
            this.Controls.Add(this.Label_AcceptedTime);
            this.Controls.Add(this.Label_OutageEnded);
            this.Controls.Add(this.AcceptedTime);
            this.Controls.Add(this.Label_RepairCompleted);
            this.Controls.Add(this.Label_IssueDescription);
            this.Controls.Add(this.Label_RepairStarted);
            this.EscClose = true;
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MF_MaintiWork";
            this.Padding = new System.Windows.Forms.Padding(3, 38, 3, 3);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "維護作業";
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 987, 674);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MF_MaintiWork_FormClosing);
            this.Load += new System.EventHandler(this.FT_MaintiWork_Load);
            this.Shown += new System.EventHandler(this.FT_MaintiWork_Shown);
            this.splitContainer_Orders.Panel1.ResumeLayout(false);
            this.splitContainer_Orders.Panel1.PerformLayout();
            this.splitContainer_Orders.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer_Orders)).EndInit();
            this.splitContainer_Orders.ResumeLayout(false);
            this.panelList.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UISymbolButton btnSave;
        private Sunny.UI.UISymbolButton btnCancel;
        private Sunny.UI.UITextBox OutageDuration;
        private Sunny.UI.UITextBox RepairDuration;
        private Sunny.UI.UILabel Label_OutageDuration;
        private Sunny.UI.UILabel Label_RepairDuration;
        private Sunny.UI.UILabel Label_OutageEnded;
        private Sunny.UI.UILabel Label_RepairCompleted;
        private Sunny.UI.UILabel Label_RepairStarted;
        private Sunny.UI.UILabel Label_IssueDescription;
        private Sunny.UI.UITextBox AcceptedTime;
        private Sunny.UI.UILabel Label_AcceptedTime;
        private Sunny.UI.UILabel Label_IssueCategory;
        private Sunny.UI.UILabel Label_Engineers;
        private Sunny.UI.UILabel Label_MaintenanceUnit;
        private Sunny.UI.UILabel Label_OutageStarted;
        private Sunny.UI.UITextBox ModelWorkstation;
        private Sunny.UI.UILabel Label_ModelWorkstation;
        private Sunny.UI.UITextBox MachineList;
        private Sunny.UI.UILabel Label_MachineList;
        private Sunny.UI.UITextBox CreationDate;
        private Sunny.UI.UILabel Label_CreationDate;
        private Sunny.UI.UILabel Label_Creator;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UILabel Label_WorkOrderNo;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UILabel Label_Details;
        private Sunny.UI.UIDatetimePicker RepairCompleted;
        private Sunny.UI.UIDatetimePicker OutageEnded;
        private Sunny.UI.UIDatetimePicker RepairStarted;
        private Sunny.UI.UILabel Label_RequestingUnit;
        private Sunny.UI.UITextBox RequestingUnit;
        private Sunny.UI.UIComboBox MaintenanceUnit;
        private Sunny.UI.UIComboBox IssueCategory;
        private System.Windows.Forms.SplitContainer splitContainer_Orders;
        private System.Windows.Forms.Label label_ListBox;
        private Sunny.UI.UIListBox ListBoxOrders;
        private Sunny.UI.UISymbolButton btnCompleted;
        private Sunny.UI.UIRichTextBox Details;
        private Sunny.UI.UIRichTextBox IssueDescription;
        private System.Windows.Forms.Panel panelList;
        private Sunny.UI.UISymbolButton btnTransfer;
        private Sunny.UI.UITextBox Engineers;
        private Sunny.UI.UISymbolButton btnQuickCreate;
        private Sunny.UI.UIDatetimePicker OutageStarted;
        private Sunny.UI.UITextBox Notification;
        private Sunny.UI.UILabel uiLabel1;
    }
}
