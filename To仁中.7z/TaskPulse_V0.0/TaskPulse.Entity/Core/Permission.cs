﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 系統權限。
    /// </summary>
    /// <remarks>格式：<code><![CDATA[
    /// [模組 Module]_[View/功能分類]_[操作動作 Action]
    /// 
    ///     模組 Module： 系統中的主要功能區塊，如「維護管理 (MaintiFlow)」、「報表中心 (ReportCenter)」等。
    ///  View/功能分類]： 指定模組中的特定視圖或功能分類，如「設備清單 (EquipmentList)」、「維護計劃 (MaintenancePlan)」等。
    /// 操作動作 Action： 定義使用者在該視圖或功能分類中可執行的操作，如「檢視 (View)」、「新增 (Add)」、「編輯 (Edit)」、「刪除 (Delete)」等。
    /// ]]></code></remarks>
    public class Permission : IEquatable<Permission>
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 權限代碼。
        /// </summary>
        [Description("代碼")]
        [MaxLength(30)]
        public string Module { get; set; }  // e.g., "ToolQuest"

        [MaxLength(30)]
        public string Page { get; set; }    // e.g., "RequestEdit"

        [MaxLength(30)]
        public string Control { get; set; } // e.g., "btnSave"

        [MaxLength(30)]
        public string Action { get; set; }  // e.g., "Click"

        /// <summary>
        /// 權限類型：1=允許(Allow)、2=禁止(Deny)。預設為允許。
        /// </summary>
        [Description("權限類型")]
        [Required]
        public int PermissionType { get; set; } = 1; // 1=Allow, 2=Deny

        public virtual ICollection<Department> Departments { get; set; } = new HashSet<Department>();
        public virtual ICollection<UserGroup> UserGroups { get; set; } = new HashSet<UserGroup>();
        public virtual ICollection<Employee> Employees { get; set; } = new HashSet<Employee>();

        public bool Equals(Permission other)
        {
            if (ReferenceEquals(this, other)) return true;
            if (ReferenceEquals(other, null)) return false;

            return string.Equals(Module, other.Module, StringComparison.Ordinal) &&
                   string.Equals(Page, other.Page, StringComparison.Ordinal) &&
                   string.Equals(Control, other.Control, StringComparison.Ordinal) &&
                   string.Equals(Action, other.Action, StringComparison.Ordinal) &&
                   PermissionType == other.PermissionType;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as Permission);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 23 + (Module != null ? StringComparer.Ordinal.GetHashCode(Module) : 0);
                hash = hash * 23 + (Page != null ? StringComparer.Ordinal.GetHashCode(Page) : 0);
                hash = hash * 23 + (Control != null ? StringComparer.Ordinal.GetHashCode(Control) : 0);
                hash = hash * 23 + (Action != null ? StringComparer.Ordinal.GetHashCode(Action) : 0);
                hash = hash * 23 + PermissionType.GetHashCode();
                return hash;
            }
        }
    }
}
