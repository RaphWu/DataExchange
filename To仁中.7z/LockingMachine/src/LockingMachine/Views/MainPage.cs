﻿using System.Diagnostics.Eventing.Reader;
using Calin.LockingMachine.Ext;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.Services;
using Calin.Navigation;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class MainPage : UserControl
    {
        private readonly ILockingMachine _lockingMachine;
        private readonly RawData _rawData;
        private readonly BindingData _bindingData;
        private readonly LmData _lmData;

        private readonly Color _belowColor = Color.Transparent;
        private readonly Color _betweenColor = Color.LightGreen;
        private readonly Color _aboveColor = Color.Red;

        private System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();

        public MainPage(ILockingMachine lockingMachine, RawData rawData, BindingData bindingData, LmData lmData)
        {
            _lockingMachine = lockingMachine;
            _rawData = rawData;
            _bindingData = bindingData;
            _lmData = lmData;

            InitializeComponent();

            lbTorqueLimitH.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueLimitH), true);
            lbTorqueLimitL.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueLimitL), true);
            lbTorqueValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueValue), true);
            lbTorqueFinalValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueFinalValue), true);
            lbTorqueMaxValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueMaxValue), true);

            lbTorqueValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.TorqueValue),
                nameof(BindingData.TorqueLimitL),
                nameof(BindingData.TorqueLimitH),
                _betweenColor, _aboveColor, _belowColor);
            lbTorqueFinalValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.TorqueFinalValue),
                nameof(BindingData.TorqueLimitL),
                nameof(BindingData.TorqueLimitH),
                _betweenColor, _aboveColor, _belowColor);
            lbTorqueMaxValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.TorqueMaxValue),
                nameof(BindingData.TorqueLimitL),
                nameof(BindingData.TorqueLimitH),
                _betweenColor, _aboveColor, _belowColor);

            lbHeightDisplacementLimitH.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementLimitH), true);
            lbHeightDisplacementLimitL.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementLimitL), true);
            lbHeightDisplacementValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementValue), true);
            lbHeightDisplacementFinalValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementFinalValue), true);
            lbHeightDisplacementMaxValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementMaxValue), true);

            lbHeightDisplacementValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.HeightDisplacementValue),
                nameof(BindingData.HeightDisplacementLimitL),
                nameof(BindingData.HeightDisplacementLimitH),
                _betweenColor, _aboveColor, _belowColor);
            lbHeightDisplacementFinalValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.HeightDisplacementFinalValue),
                nameof(BindingData.HeightDisplacementLimitL),
                nameof(BindingData.HeightDisplacementLimitH),
                _betweenColor, _aboveColor, _belowColor);
            lbHeightDisplacementMaxValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.HeightDisplacementMaxValue),
                nameof(BindingData.HeightDisplacementLimitL),
                nameof(BindingData.HeightDisplacementLimitH),
                _betweenColor, _aboveColor, _belowColor);

#if DEBUG
            var lbHeightDisplacementStopwatch = new Label();
            lbHeightDisplacementStopwatch.Font = new Font("Consolas", 9F);
            lbHeightDisplacementStopwatch.Location = new Point(7, 112);
            lbHeightDisplacementStopwatch.BackColor = Color.Transparent;
            lbHeightDisplacementStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementStopwatch), true);
            gbHeightDisplacement.Controls.Add(lbHeightDisplacementStopwatch);

            var lbTorqueStopwatch = new Label();
            lbTorqueStopwatch.Font = new Font("Consolas", 9F);
            lbTorqueStopwatch.Location = new Point(7, 112);
            lbTorqueStopwatch.BackColor = Color.Transparent;
            lbTorqueStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueStopwatch), true);
            gbTorqueMeter.Controls.Add(lbTorqueStopwatch);
#endif

            _timer.Interval = _lmData.uiScanTimeInterval;
            _timer.Tick += (async (s, e) =>
            {
                #region 作業狀態

                _bindingData.IsMeasuring = _rawData.IsMeasuring;

                #endregion 作業狀態

                #region 軸卡

                _bindingData.ZAxisCoor = _rawData.ZAxisCoor;
                _bindingData.RPM = _rawData.RPM;
                _bindingData.Angle = _rawData.Angle;

                #endregion 軸卡

                #region 扭力計

                _bindingData.TorqueValue = _rawData.TorqueValue;
                _bindingData.TorqueFinalValue = _rawData.TorqueFinalValue;
                _bindingData.TorqueMaxValue = _rawData.TorqueMaxValue;
                _bindingData.TorqueLimitH = _rawData.TorqueLimitH;
                _bindingData.TorqueLimitL = _rawData.TorqueLimitL;

                #endregion 扭力計

                #region 高度計

                _bindingData.HeightDisplacementValue = _rawData.HeightDisplacementValue;
                _bindingData.HeightDisplacementFinalValue = _rawData.HeightDisplacementFinalValue;
                _bindingData.HeightDisplacementMaxValue = _rawData.HeightDisplacementMaxValue;
                _bindingData.HeightDisplacementLimitH = _rawData.HeightDisplacementLimitH;
                _bindingData.HeightDisplacementLimitL = _rawData.HeightDisplacementLimitL;

                #endregion 高度計

                #region USB4704

                _bindingData.DI0 = _rawData.DI0;
                _bindingData.DI1 = _rawData.DI1;
                _bindingData.DI2 = _rawData.DI2;
                _bindingData.DI3 = _rawData.DI3;
                _bindingData.DI4 = _rawData.DI4;
                _bindingData.DI5 = _rawData.DI5;
                _bindingData.DI6 = _rawData.DI6;
                _bindingData.DI7 = _rawData.DI7;

                #endregion USB4704

#if DEBUG
                _bindingData.HeightDisplacementStopwatch = _rawData.HeightDisplacementStopwatch;
                _bindingData.TorqueStopwatch = _rawData.TorqueStopwatch;
#endif

                //                // HeightDisplacement
                //                if (_bindingData._HeightDisplacementLimitH != _bindingData.HeightDisplacementLimitH)
                //                {
                //                    _bindingData._HeightDisplacementLimitH = _bindingData.HeightDisplacementLimitH;
                //                    lbHeightDisplacementLimitH.Text = _bindingData.HeightDisplacementLimitH.ToString("F3");
                //                }
                //                if (_bindingData._HeightDisplacementLimitL != _bindingData.HeightDisplacementLimitL)
                //                {
                //                    _bindingData._HeightDisplacementLimitL = _bindingData.HeightDisplacementLimitL;
                //                    lbHeightDisplacementLimitL.Text = _bindingData.HeightDisplacementLimitL.ToString("F3");
                //                }
                //                if (_bindingData._HeightDisplacementValue != _bindingData.HeightDisplacementValue)
                //                {
                //                    _bindingData._HeightDisplacementValue = _bindingData.HeightDisplacementValue;
                //                    lbHeightDisplacementValue.Text = _bindingData.HeightDisplacementValue.ToString("F3");

                //                    if (_bindingData.HeightDisplacementValue > _bindingData.HeightDisplacementMaxValue)
                //                        _bindingData.HeightDisplacementMaxValue = _bindingData.HeightDisplacementValue;
                //                    if (_bindingData.IsMeasuring && (_bindingData.HeightDisplacementValue > _bindingData.HeightDisplacementFinalValue))
                //                        _bindingData.HeightDisplacementFinalValue = _bindingData.HeightDisplacementValue;

                //                    if (_bindingData.HeightDisplacementValue >= _bindingData.HeightDisplacementLimitH)
                //                        lbHeightDisplacementValue.BackColor = _aboveColor;
                //                    else if (_bindingData.HeightDisplacementValue <= _bindingData.HeightDisplacementLimitL)
                //                        lbHeightDisplacementValue.BackColor = _belowColor;
                //                    else if (lbHeightDisplacementValue.BackColor != _betweenColor)
                //                        lbHeightDisplacementValue.BackColor = _betweenColor;
                //                }
                //                if (_bindingData._HeightDisplacementMaxValue != _bindingData.HeightDisplacementMaxValue)
                //                {
                //                    _bindingData._HeightDisplacementMaxValue = _bindingData.HeightDisplacementMaxValue;
                //                    lbHeightDisplacementMaxValue.Text = _bindingData.HeightDisplacementMaxValue.ToString("F3");

                //                    if (_bindingData.HeightDisplacementMaxValue >= _bindingData.HeightDisplacementLimitH)
                //                        lbHeightDisplacementMaxValue.BackColor = _aboveColor;
                //                    else if (_bindingData.HeightDisplacementMaxValue <= _bindingData.HeightDisplacementLimitL)
                //                        lbHeightDisplacementMaxValue.BackColor = _belowColor;
                //                    else if (lbHeightDisplacementMaxValue.BackColor != _betweenColor)
                //                        lbHeightDisplacementMaxValue.BackColor = _betweenColor;
                //                }
                //                if (_bindingData._HeightDisplacementFinalValue != _bindingData.HeightDisplacementFinalValue)
                //                {
                //                    _bindingData._HeightDisplacementFinalValue = _bindingData.HeightDisplacementFinalValue;
                //                    lbHeightDisplacementFinalValue.Text = _bindingData.HeightDisplacementFinalValue.ToString("F3");

                //                    if (_bindingData.HeightDisplacementFinalValue >= _bindingData.HeightDisplacementLimitH)
                //                        lbHeightDisplacementFinalValue.BackColor = _aboveColor;
                //                    else if (_bindingData.HeightDisplacementFinalValue <= _bindingData.HeightDisplacementLimitL)
                //                        lbHeightDisplacementFinalValue.BackColor = _belowColor;
                //                    else if (lbHeightDisplacementFinalValue.BackColor != _betweenColor)
                //                        lbHeightDisplacementFinalValue.BackColor = _betweenColor;
                //                }

                //                // Torque
                //                if (_bindingData._TorqueLimitH != _bindingData.TorqueLimitH)
                //                {
                //                    _bindingData._TorqueLimitH = _bindingData.TorqueLimitH;
                //                    lbTorqueLimitH.Text = _bindingData.TorqueLimitH.ToString("F3");
                //                }
                //                if (_bindingData._TorqueLimitL != _bindingData.TorqueLimitL)
                //                {
                //                    _bindingData._TorqueLimitL = _bindingData.TorqueLimitL;
                //                    lbTorqueLimitL.Text = _bindingData.TorqueLimitL.ToString("F3");
                //                }
                //                if (_bindingData._TorqueValue != _bindingData.TorqueValue)
                //                {
                //                    _bindingData._TorqueValue = _bindingData.TorqueValue;
                //                    lbTorqueValue.Text = _bindingData.TorqueValue.ToString("F3");

                //                    if (_bindingData.TorqueValue > _bindingData.TorqueMaxValue)
                //                        _bindingData.TorqueMaxValue = _bindingData.TorqueValue;
                //                    if (_bindingData.IsMeasuring && (_bindingData.TorqueValue > _bindingData.TorqueFinalValue))
                //                        _bindingData.TorqueFinalValue = _bindingData.TorqueValue;

                //                    if (_bindingData.TorqueValue >= _bindingData.TorqueLimitH)
                //                        lbTorqueValue.BackColor = _aboveColor;
                //                    else if (_bindingData.TorqueValue <= _bindingData.TorqueLimitL)
                //                        lbTorqueValue.BackColor = _belowColor;
                //                    else if (lbTorqueValue.BackColor != _betweenColor)
                //                        lbTorqueValue.BackColor = _betweenColor;
                //                }
                //                if (_bindingData._TorqueMaxValue != _bindingData.TorqueMaxValue)
                //                {
                //                    _bindingData._TorqueMaxValue = _bindingData.TorqueMaxValue;
                //                    lbTorqueMaxValue.Text = _bindingData.TorqueMaxValue.ToString("F3");

                //                    if (_bindingData.TorqueMaxValue >= _bindingData.TorqueLimitH)
                //                        lbTorqueMaxValue.BackColor = _aboveColor;
                //                    else if (_bindingData.TorqueMaxValue <= _bindingData.TorqueLimitL)
                //                        lbTorqueMaxValue.BackColor = _belowColor;
                //                    else if (lbTorqueMaxValue.BackColor != _betweenColor)
                //                        lbTorqueMaxValue.BackColor = _betweenColor;
                //                }
                //                if (_bindingData._TorqueFinalValue != _bindingData.TorqueFinalValue)
                //                {
                //                    _bindingData._TorqueFinalValue = _bindingData.TorqueFinalValue;
                //                    lbTorqueFinalValue.Text = _bindingData.TorqueFinalValue.ToString("F3");

                //                    if (_bindingData.TorqueFinalValue >= _bindingData.TorqueLimitH)
                //                        lbTorqueFinalValue.BackColor = _aboveColor;
                //                    else if (_bindingData.TorqueFinalValue <= _bindingData.TorqueLimitL)
                //                        lbTorqueFinalValue.BackColor = _belowColor;
                //                    else if (lbTorqueFinalValue.BackColor != _betweenColor)
                //                        lbTorqueFinalValue.BackColor = _betweenColor;
                //                }

                //#if DEBUG 
                //                lbHeightDisplacementStopwatch.Text = _bindingData.HeightDisplacementStopwatch.ToString("F3");
                //                lbTorqueStopwatch.Text = _bindingData.TorqueStopwatch.ToString("F3");

                //                //var lbTorqueStopwatch = new Label();
                //                //lbTorqueStopwatch.Font = new Font("Consolas", 9F);
                //                //lbTorqueStopwatch.Location = new Point(7, 121);
                //                //lbTorqueStopwatch.BackColor = Color.Transparent;
                //                //lbTorqueStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                //                //    nameof(BindingData.TorqueStopwatch), true);
                //                //gbTorqueMeter.Controls.Add(lbTorqueStopwatch);
                //#endif

                await Task.CompletedTask;
            });
            _timer.Start();
        }

        private void cbIsMeasuring_Click(object sender, EventArgs e)
        {
            //var check = !cbIsMeasuring.Checked;
            //cbIsMeasuring.Checked = check;
            _rawData.IsMeasuring = cbIsMeasuring.Checked;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            _lockingMachine.ClearMeasureData();
        }

        private void btnTest1_Click(object sender, EventArgs e)
        {
            _lockingMachine.DaqStartAcquisition();
        }

        private void btnTest2_Click(object sender, EventArgs e)
        {
            _lockingMachine.DaqStopAcquisition();
        }
    }
}
