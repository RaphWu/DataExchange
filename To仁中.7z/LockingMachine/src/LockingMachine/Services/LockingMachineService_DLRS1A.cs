﻿using System.Diagnostics;
using Autofac;
using Calin.Comm.DL_RS1A;
using Calin.Helpers;
using Calin.LockingMachine.Models;
using Calin.SerialPort;

namespace Calin.LockingMachine.Services
{
    // 高度計
    public partial class LockingMachineService : ILockingMachine_Dlrs1a
    {
        #region Fields

        private readonly string _heightDisplacementFile = "HeightDisplacement.json";

#if DEBUG
        private readonly Stopwatch _dispStopwatch = new Stopwatch();
#endif

        #endregion Fields

        /// <inheritdoc/>
        public void Dlrs1aInit()
        {
            if (_lmData.dlrs1a != null)
            {
                _lmData.dlrs1a.ResponseReceived -= Dlrs1a_Received;
                _lmData.dlrs1a.ErrorOccurred -= Dlrs1a_ErrorOccurred;
            }

            _rawData.HeightDisplacementValue = 0.0;
            _rawData.HeightDisplacementFinalValue = 0.0;
            _rawData.HeightDisplacementMaxValue = 0.0;

            Dlrs1aLoadConfig();

            var fac = _scope.Resolve<IDL_RS1A_ServiceFactory>();
            {
                _lmData.dlrs1a = fac.CreateAndOpen(_dispData.Dlrs1aConfig);
                if (_lmData.dlrs1a != null && _lmData.dlrs1a.IsTransmissionVerified)
                {
                    _lmData.dlrs1a.ResponseReceived += Dlrs1a_Received;
                    _lmData.dlrs1a.ErrorOccurred += Dlrs1a_ErrorOccurred;
                    _bindingData.HeightDisplacementActive = true;
                }
            }
        }

        /// <inheritdoc/>
        public void Dlrs1aClose()
        {
            if (_lmData.dlrs1a != null)
            {
                _lmData.dlrs1a.ResponseReceived -= Dlrs1a_Received;
                _lmData.dlrs1a.ErrorOccurred -= Dlrs1a_ErrorOccurred;
                _lmData.dlrs1a.Close();
                _lmData.dlrs1a.Dispose();
                _lmData.dlrs1a = null;
            }
            _bindingData.HeightDisplacementActive = false;
        }

        /// <inheritdoc/>
        public void Dlrs1aSaveConfig(Dlrs1aData config)
        {
            string path = GetConfigFilePath();
            try
            {
                // 確保目錄存在
                var dir = Path.GetDirectoryName(path);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                JsonFileHelper.Save(path, config);
            }
            catch (Exception ex)
            {
                // 若有 logging 機制可改用專案 logger，先用 Console 做簡易回報
                Console.WriteLine($"Dlrs1aSaveConfig failed: {ex}");
            }
        }

        /// <inheritdoc/>
        public void Dlrs1aLoadConfig()
        {
            Dlrs1aData config = null;

            string path = GetConfigFilePath();
            if (File.Exists(path))
            {
                try
                {
                    config = JsonFileHelper.Read<Dlrs1aData>(path);
                    config.Dlrs1aConfig.SensorType = KeyenceSensorType.GT2;
                    config.Dlrs1aConfig.IdNumber = 1;
                }
                catch (Exception ex)
                {
                    // 讀取失敗：不要立刻覆寫檔案（避免讀取中出錯就覆蓋原始檔）
                    Console.WriteLine($"Dlrs1aLoadConfig: failed to read config file '{path}': {ex}");
                    config = null;
                }
            }

            if (config == null)
            {
                // 若檔案不存在或讀取失敗，就使用預設值。
                config = new Dlrs1aData
                {
                    Dlrs1aConfig = new DL_RS1A_Config()
                    {
                        SensorType = KeyenceSensorType.GT2,
                        IdNumber = 1,
                        PortName = _lmData.comPortList.Count > 0 ? _lmData.comPortList.First() : "",
                        BaudRate = 38400,
                        DataBits = 8,
                        Parity = Parity.None,
                        StopBits = StopBits.One,
                    },
                    HeightDispLimitH = 20.0,
                    HeightDispLimitL = 15.0,
                };

                // 只有當檔案原本不存在時才儲存預設檔，若原本有檔但讀取失敗則不立刻覆蓋
                if (!File.Exists(path))
                {
                    Dlrs1aSaveConfig(config);
                }
            }

            _dispData.Dlrs1aConfig = config.Dlrs1aConfig;
            _dispData.HeightDispLimitH = config.HeightDispLimitH;
            _dispData.HeightDispLimitL = config.HeightDispLimitL;

            _rawData.HeightDisplacementLimitH = config.HeightDispLimitH;
            _rawData.HeightDisplacementLimitL = config.HeightDispLimitL;
        }

        /// <summary>
        /// 取得要儲存設定檔的實際路徑（改放在使用者 AppData 目錄，避免 output 覆蓋與權限問題）
        /// </summary>
        private string GetConfigFilePath()
        {
            //string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            //string dir = Path.Combine(appData, "Calin", "LockingMachine");
            string dir = AppDomain.CurrentDomain.BaseDirectory; // 與執行檔同目錄
            return Path.Combine(dir, _heightDisplacementFile);
        }

        /// <summary>
        /// 高度計回應接收事件處理程式。
        /// </summary>
        private void Dlrs1a_Received(object sender, DL_RS1A_ResponseEventArgs e)
        {
            if (e.Response.IsSuccess && e.Response.Values.Length > 0) // 有錯誤時會沒有資料
            {
                _rawData.HeightDisplacementValue = e.Response.Values[0];

                if (_rawData.HeightDisplacementMaxValue < _rawData.HeightDisplacementValue)
                    _rawData.HeightDisplacementMaxValue = _rawData.HeightDisplacementValue;

                if (_rawData.IsMeasuring && _rawData.HeightDisplacementFinalValue < _rawData.HeightDisplacementValue)
                    _rawData.HeightDisplacementFinalValue = _rawData.HeightDisplacementValue;
#if DEBUG
                _dispStopwatch.Stop();
                _rawData.HeightDisplacementStopwatch = _dispStopwatch.Elapsed.TotalMilliseconds;
                _dispStopwatch.Restart();
#endif
                _rawData.WaitForReceiveHeightDisplacement = 0;
            }
        }

        private void Dlrs1a_ErrorOccurred(object sender, DL_RS1A_ErrorEventArgs e)
        {
            _rawData.WaitForReceiveHeightDisplacement = 0;
        }
    }
}
