﻿using Calin.LockingMachine.ProcessFlow.Core;

namespace Calin.LockingMachine.ProcessFlow.Engine
{
    /// <summary>
    /// 流程執行事件參數。
    /// </summary>
    public class ProcessStepExecutingEventArgs : EventArgs
    {
        public ProcessStepEntity Step { get; }
        public int TotalSteps { get; }
        public int CurrentIndex { get; }

        public ProcessStepExecutingEventArgs(ProcessStepEntity step, int totalSteps, int currentIndex)
        {
            Step = step;
            TotalSteps = totalSteps;
            CurrentIndex = currentIndex;
        }
    }

    /// <summary>
    /// 流程步驟完成事件參數。
    /// </summary>
    public class ProcessStepCompletedEventArgs : EventArgs
    {
        public ProcessStepEntity Step { get; }
        public ProcessExecutionResult Result { get; }
        public int TotalSteps { get; }
        public int CurrentIndex { get; }

        public ProcessStepCompletedEventArgs(ProcessStepEntity step, ProcessExecutionResult result, int totalSteps, int currentIndex)
        {
            Step = step;
            Result = result;
            TotalSteps = totalSteps;
            CurrentIndex = currentIndex;
        }
    }
}
