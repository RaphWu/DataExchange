﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Calin.LockingMachine.ProcessFlow.Engine;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Handlers
{
    /// <summary>
    /// 尋邊氣缸操作工序處理器。
    /// </summary>
    public class GateMarkCylinderHandler : IProcessHandler
    {
        public async Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken cancellationToken)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<GateMarkCylinderParam>(paramJson);
                if (param == null)
                    return ProcessExecutionResult.Failed("參數解析失敗");

                //await Task.Delay(param.DelayMilliseconds, cancellationToken);

                return ProcessExecutionResult.Succeeded();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                return ProcessExecutionResult.Failed(ex);
            }
        }

        public string ValidateParam(string paramJson)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<DelayParam>(paramJson);
                if (param == null)
                    return "參數不可為空";

                if (param.DelayMilliseconds < 0)
                    return "延遲時間不可為負數";

                return null;
            }
            catch (Exception ex)
            {
                return $"參數格式錯誤: {ex.Message}";
            }
        }
    }
}
