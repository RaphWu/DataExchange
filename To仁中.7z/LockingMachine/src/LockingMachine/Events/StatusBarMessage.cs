﻿namespace Calin.LockingMachine.Events
{
    public class StatusBarMessage
    {
        public string Message { get; set; }
        public int Duration { get; set; } = 5000;
    }
}
