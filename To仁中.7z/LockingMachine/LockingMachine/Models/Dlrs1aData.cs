﻿using Calin.Comm.DL_RS1A;

namespace Calin.LockingMachine.Models
{
    public class Dlrs1aData
    {
        internal IDL_RS1A dlrs1a = default;
        internal DL_RS1A_Config dlrs1aConfig = new DL_RS1A_Config();

        // 高度計上下限設定
        internal double HighLimitH = 20.0;
        internal double HighLimitL = 10.0;
    }
}
