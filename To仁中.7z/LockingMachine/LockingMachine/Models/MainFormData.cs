﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.LockingMachine.Models
{
    public class MainFormData : ObservableObject
    {

        /// <summary>
        /// Z軸是否啟用。
        /// </summary>
        public bool ZAxisActive
        {
            get { return _zAxisActive; }
            set { SetProperty(ref _zAxisActive, value); }
        }
        private bool _zAxisActive;

        /// <summary>
        /// Z軸目前座標。
        /// </summary>
        public double ZAxisCoor
        {
            get { return _zAxisCoor; }
            set { SetProperty(ref _zAxisCoor, value); }
        }
        private double _zAxisCoor;

        /// <summary>
        /// R軸是否啟用。
        /// </summary>
        public bool RAxisActive
        {
            get { return _rAxisActive; }
            set { SetProperty(ref _rAxisActive, value); }
        }
        private bool _rAxisActive;

        /// <summary>
        /// R軸目前轉速(RPM)。
        /// </summary>
        public double RPM
        {
            get { return _rpm; }
            set { SetProperty(ref _rpm, value); }
        }
        private double _rpm;

        /// <summary>
        /// R軸目前角度。
        /// </summary>
        public double Angle
        {
            get { return _angle; }
            set { SetProperty(ref _angle, value); }
        }
        private double _angle;

        /// <summary>
        /// 扭力計是否啟用。
        /// </summary>
        public bool TorqueMeterActive
        {
            get { return _torqueMeterActive; }
            set { SetProperty(ref _torqueMeterActive, value); }
        }
        private bool _torqueMeterActive;

        /// <summary>
        /// 扭力計讀數。
        /// </summary>
        public double TorqueMeterValue
        {
            get { return _torqueMeterValue; }
            set { SetProperty(ref _torqueMeterValue, value); }
        }
        private double _torqueMeterValue;

        /// <summary>
        /// 高度計是否啟用。
        /// </summary>
        public bool HeightDisplacementActive
        {
            get { return _heightDisplacementActive; }
            set { SetProperty(ref _heightDisplacementActive, value); }
        }
        private bool _heightDisplacementActive;

        /// <summary>
        /// 高度計讀數。
        /// </summary>
        public double HeightDisplacementValue
        {
            get { return _heightDisplacementValue; }
            set { SetProperty(ref _heightDisplacementValue, value); }
        }
        private double _heightDisplacementValue;
    }
}
