﻿using System.ComponentModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Calin.LockingMachine.Models
{
    public class MainFormData : ObservableObject
    {

        /// <summary>
        /// Z軸是否啟用。
        /// </summary>
        public bool ZAxisActive
        {
            get { return _zAxisActive; }
            set { SetProperty(ref _zAxisActive, value); }
        }
        private bool _zAxisActive;

        /// <summary>
        /// Z軸目前座標。
        /// </summary>
        public double ZAxisCoor
        {
            get { return _zAxisCoor; }
            set { SetProperty(ref _zAxisCoor, value); }
        }
        private double _zAxisCoor;

        /// <summary>
        /// R軸是否啟用。
        /// </summary>
        public bool RAxisActive
        {
            get { return _rAxisActive; }
            set { SetProperty(ref _rAxisActive, value); }
        }
        private bool _rAxisActive;

        /// <summary>
        /// R軸目前轉速(RPM)。
        /// </summary>
        public double RPM
        {
            get { return _rpm; }
            set { SetProperty(ref _rpm, value); }
        }
        private double _rpm;

        /// <summary>
        /// R軸目前角度。
        /// </summary>
        public double Angle
        {
            get { return _angle; }
            set { SetProperty(ref _angle, value); }
        }
        private double _angle;

        /// <summary>
        /// 扭力計是否啟用。
        /// </summary>
        public bool TorqueActive
        {
            get { return _torqueActive; }
            set { SetProperty(ref _torqueActive, value); }
        }
        private bool _torqueActive;

        /// <summary>
        /// 扭力計讀數。
        /// </summary>
        public double Torque
        {
            get { return _torque; }
            set { SetProperty(ref _torque, value); }
        }
        private double _torque;

        /// <summary>
        /// 高度計是否啟用。
        /// </summary>
        public bool LD_RS1A_Active
        {
            get { return _lD_RS1A_Active; }
            set { SetProperty(ref _lD_RS1A_Active, value); }
        }
        private bool _lD_RS1A_Active;

        /// <summary>
        /// 高度計讀數。
        /// </summary>
        public double Height
        {
            get { return _height; }
            set { SetProperty(ref _height, value); }
        }
        private double _height;
    }
}
