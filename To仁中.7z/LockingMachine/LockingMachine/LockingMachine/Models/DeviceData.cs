﻿using Calin.Comm.DL_RS1A;

namespace Calin.LockingMachine.Models
{
    public class DeviceData
    {
        /********************
         * 作業參數
         ********************/
        // 高度計
        internal double HighLimitH = 20.0;
        internal double HighLimitL = 10.0;

        /********************
         * 硬體設備
         ********************/
        // Serial Port
        internal List<string> comPortList = new List<string>();

        // DL_RS1A
        internal IDL_RS1A dl_RS1A = default;
        internal DL_RS1A_Config dl_RS1A_Config = new DL_RS1A_Config();
    }
}
