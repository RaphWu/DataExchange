﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.LockingMachine.Constants
{
    public enum PageCode
    {
        None,

        MainPage,
        WorkSetup,
        Monitor,
        Setup,
    }
}
