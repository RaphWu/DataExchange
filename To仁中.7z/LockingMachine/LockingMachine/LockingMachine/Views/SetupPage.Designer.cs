﻿namespace Calin.LockingMachine.Views
{
    partial class SetupPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.VelSetupPanel = new System.Windows.Forms.GroupBox();
            this.NumVelL = new System.Windows.Forms.NumericUpDown();
            this.NumVelH = new System.Windows.Forms.NumericUpDown();
            this.NumAcc = new System.Windows.Forms.NumericUpDown();
            this.NumDec = new System.Windows.Forms.NumericUpDown();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.RbTCurver = new System.Windows.Forms.RadioButton();
            this.RbSCurver = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.VelSetupPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // VelSetupPanel
            // 
            this.VelSetupPanel.Controls.Add(this.NumVelL);
            this.VelSetupPanel.Controls.Add(this.NumVelH);
            this.VelSetupPanel.Controls.Add(this.NumAcc);
            this.VelSetupPanel.Controls.Add(this.NumDec);
            this.VelSetupPanel.Controls.Add(this.groupBox11);
            this.VelSetupPanel.Controls.Add(this.label16);
            this.VelSetupPanel.Controls.Add(this.label17);
            this.VelSetupPanel.Controls.Add(this.label18);
            this.VelSetupPanel.Controls.Add(this.label19);
            this.VelSetupPanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.VelSetupPanel.Location = new System.Drawing.Point(17, 16);
            this.VelSetupPanel.Margin = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Name = "VelSetupPanel";
            this.VelSetupPanel.Padding = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Size = new System.Drawing.Size(181, 216);
            this.VelSetupPanel.TabIndex = 48;
            this.VelSetupPanel.TabStop = false;
            this.VelSetupPanel.Text = "旋入軸速率設定 (PPU/sec)";
            // 
            // NumVelL
            // 
            this.NumVelL.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelL.Location = new System.Drawing.Point(72, 26);
            this.NumVelL.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelL.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelL.Name = "NumVelL";
            this.NumVelL.Size = new System.Drawing.Size(100, 23);
            this.NumVelL.TabIndex = 43;
            this.NumVelL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelL.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // NumVelH
            // 
            this.NumVelH.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelH.Location = new System.Drawing.Point(72, 57);
            this.NumVelH.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelH.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelH.Name = "NumVelH";
            this.NumVelH.Size = new System.Drawing.Size(100, 23);
            this.NumVelH.TabIndex = 42;
            this.NumVelH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelH.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // NumAcc
            // 
            this.NumAcc.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumAcc.Location = new System.Drawing.Point(72, 88);
            this.NumAcc.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumAcc.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumAcc.Name = "NumAcc";
            this.NumAcc.Size = new System.Drawing.Size(100, 23);
            this.NumAcc.TabIndex = 41;
            this.NumAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumAcc.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // NumDec
            // 
            this.NumDec.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumDec.Location = new System.Drawing.Point(72, 117);
            this.NumDec.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumDec.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumDec.Name = "NumDec";
            this.NumDec.Size = new System.Drawing.Size(100, 23);
            this.NumDec.TabIndex = 40;
            this.NumDec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumDec.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.RbTCurver);
            this.groupBox11.Controls.Add(this.RbSCurver);
            this.groupBox11.Location = new System.Drawing.Point(8, 150);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(164, 53);
            this.groupBox11.TabIndex = 37;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "速度曲線類型";
            // 
            // RbTCurver
            // 
            this.RbTCurver.AutoSize = true;
            this.RbTCurver.Checked = true;
            this.RbTCurver.Location = new System.Drawing.Point(10, 23);
            this.RbTCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbTCurver.Name = "RbTCurver";
            this.RbTCurver.Size = new System.Drawing.Size(68, 20);
            this.RbTCurver.TabIndex = 35;
            this.RbTCurver.TabStop = true;
            this.RbTCurver.Text = "T型曲線";
            this.RbTCurver.UseVisualStyleBackColor = true;
            // 
            // RbSCurver
            // 
            this.RbSCurver.AutoSize = true;
            this.RbSCurver.Location = new System.Drawing.Point(88, 23);
            this.RbSCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbSCurver.Name = "RbSCurver";
            this.RbSCurver.Size = new System.Drawing.Size(68, 20);
            this.RbSCurver.TabIndex = 36;
            this.RbSCurver.Text = "S型曲線";
            this.RbSCurver.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(20, 121);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 32;
            this.label16.Text = "減速度";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 90);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 16);
            this.label17.TabIndex = 30;
            this.label17.Text = "加速度";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 59);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 16);
            this.label18.TabIndex = 28;
            this.label18.Text = "運轉速度";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 28);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 16);
            this.label19.TabIndex = 26;
            this.label19.Text = "起始速度";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.numericUpDown2);
            this.groupBox1.Controls.Add(this.numericUpDown3);
            this.groupBox1.Controls.Add(this.numericUpDown4);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(206, 16);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(181, 216);
            this.groupBox1.TabIndex = 49;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "轉動軸速率設定 (PPU/sec)";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(72, 26);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown1.TabIndex = 43;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(72, 57);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown2.TabIndex = 42;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown2.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(72, 88);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown3.TabIndex = 41;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown3.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown4.Location = new System.Drawing.Point(72, 117);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown4.TabIndex = 40;
            this.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown4.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Location = new System.Drawing.Point(8, 150);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(164, 53);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "速度曲線類型";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(10, 23);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(68, 20);
            this.radioButton1.TabIndex = 35;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "T型曲線";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(88, 23);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(68, 20);
            this.radioButton2.TabIndex = 36;
            this.radioButton2.Text = "S型曲線";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 121);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "減速度";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 90);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 30;
            this.label2.Text = "加速度";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 59);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "運轉速度";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 28);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 26;
            this.label4.Text = "起始速度";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SetupPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.VelSetupPanel);
            this.Name = "SetupPage";
            this.Size = new System.Drawing.Size(526, 619);
            this.VelSetupPanel.ResumeLayout(false);
            this.VelSetupPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox VelSetupPanel;
        private NumericUpDown NumVelL;
        private NumericUpDown NumVelH;
        private NumericUpDown NumAcc;
        private NumericUpDown NumDec;
        private GroupBox groupBox11;
        public RadioButton RbTCurver;
        public RadioButton RbSCurver;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private GroupBox groupBox1;
        private NumericUpDown numericUpDown1;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown4;
        private GroupBox groupBox2;
        public RadioButton radioButton1;
        public RadioButton radioButton2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}
