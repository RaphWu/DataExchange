﻿namespace Calin.LockingMachine
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.SstripMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.SstripClock = new System.Windows.Forms.ToolStripStatusLabel();
            this.ClockTimer = new System.Windows.Forms.Timer(this.components);
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.ContentPanel = new System.Windows.Forms.Panel();
            this.MenuPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.MenuMain = new System.Windows.Forms.RadioButton();
            this.MenuWorkSetup = new System.Windows.Forms.RadioButton();
            this.MenuMonitor = new System.Windows.Forms.RadioButton();
            this.MenuSetup = new System.Windows.Forms.RadioButton();
            this.statusStrip.SuspendLayout();
            this.TLP.SuspendLayout();
            this.MenuPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SstripMessage,
            this.SstripClock});
            this.statusStrip.Location = new System.Drawing.Point(0, 573);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(634, 22);
            this.statusStrip.TabIndex = 1;
            this.statusStrip.Text = "statusStrip1";
            // 
            // SstripMessage
            // 
            this.SstripMessage.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Top;
            this.SstripMessage.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust;
            this.SstripMessage.Name = "SstripMessage";
            this.SstripMessage.Size = new System.Drawing.Size(469, 17);
            this.SstripMessage.Spring = true;
            this.SstripMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // SstripClock
            // 
            this.SstripClock.AutoSize = false;
            this.SstripClock.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.SstripClock.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SstripClock.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SstripClock.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SstripClock.Name = "SstripClock";
            this.SstripClock.Size = new System.Drawing.Size(150, 17);
            this.SstripClock.Text = "8888/88/88 88:88:88";
            // 
            // ClockTimer
            // 
            this.ClockTimer.Enabled = true;
            this.ClockTimer.Interval = 250;
            this.ClockTimer.Tick += new System.EventHandler(this.ClockTimer_Tick);
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 1;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.ContentPanel, 0, 1);
            this.TLP.Controls.Add(this.MenuPanel, 0, 0);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 2;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Size = new System.Drawing.Size(634, 573);
            this.TLP.TabIndex = 2;
            // 
            // ContentPanel
            // 
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(3, 30);
            this.ContentPanel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.Size = new System.Drawing.Size(628, 543);
            this.ContentPanel.TabIndex = 0;
            // 
            // MenuPanel
            // 
            this.MenuPanel.Controls.Add(this.MenuMain);
            this.MenuPanel.Controls.Add(this.MenuWorkSetup);
            this.MenuPanel.Controls.Add(this.MenuMonitor);
            this.MenuPanel.Controls.Add(this.MenuSetup);
            this.MenuPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MenuPanel.Location = new System.Drawing.Point(3, 0);
            this.MenuPanel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.MenuPanel.Name = "MenuPanel";
            this.MenuPanel.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.MenuPanel.Size = new System.Drawing.Size(628, 30);
            this.MenuPanel.TabIndex = 1;
            // 
            // MenuMain
            // 
            this.MenuMain.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuMain.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuMain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.MenuMain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuMain.Location = new System.Drawing.Point(15, 0);
            this.MenuMain.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.MenuMain.Name = "MenuMain";
            this.MenuMain.Size = new System.Drawing.Size(80, 26);
            this.MenuMain.TabIndex = 2;
            this.MenuMain.TabStop = true;
            this.MenuMain.Text = "主控頁";
            this.MenuMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuMain.UseVisualStyleBackColor = true;
            this.MenuMain.Click += new System.EventHandler(this.MenuMain_Click);
            // 
            // MenuWorkSetup
            // 
            this.MenuWorkSetup.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuWorkSetup.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuWorkSetup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.MenuWorkSetup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuWorkSetup.Location = new System.Drawing.Point(104, 0);
            this.MenuWorkSetup.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.MenuWorkSetup.Name = "MenuWorkSetup";
            this.MenuWorkSetup.Size = new System.Drawing.Size(80, 26);
            this.MenuWorkSetup.TabIndex = 3;
            this.MenuWorkSetup.TabStop = true;
            this.MenuWorkSetup.Text = "作業設定";
            this.MenuWorkSetup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuWorkSetup.UseVisualStyleBackColor = true;
            this.MenuWorkSetup.Click += new System.EventHandler(this.MenuWorkSetup_Click);
            // 
            // MenuMonitor
            // 
            this.MenuMonitor.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuMonitor.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuMonitor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.MenuMonitor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuMonitor.Location = new System.Drawing.Point(193, 0);
            this.MenuMonitor.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.MenuMonitor.Name = "MenuMonitor";
            this.MenuMonitor.Size = new System.Drawing.Size(80, 26);
            this.MenuMonitor.TabIndex = 4;
            this.MenuMonitor.TabStop = true;
            this.MenuMonitor.Text = "即時監控";
            this.MenuMonitor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuMonitor.UseVisualStyleBackColor = true;
            this.MenuMonitor.Click += new System.EventHandler(this.MenuMonitor_Click);
            // 
            // MenuSetup
            // 
            this.MenuSetup.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuSetup.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuSetup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.MenuSetup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuSetup.Location = new System.Drawing.Point(282, 0);
            this.MenuSetup.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.MenuSetup.Name = "MenuSetup";
            this.MenuSetup.Size = new System.Drawing.Size(80, 26);
            this.MenuSetup.TabIndex = 5;
            this.MenuSetup.TabStop = true;
            this.MenuSetup.Text = "設定";
            this.MenuSetup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuSetup.UseVisualStyleBackColor = true;
            this.MenuSetup.Click += new System.EventHandler(this.MenuSetup_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 595);
            this.Controls.Add(this.TLP);
            this.Controls.Add(this.statusStrip);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Locking Machine";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.TLP.ResumeLayout(false);
            this.MenuPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StatusStrip statusStrip;
        private ToolStripStatusLabel SstripMessage;
        private ToolStripStatusLabel SstripClock;
        private System.Windows.Forms.Timer ClockTimer;
        private TableLayoutPanel TLP;
        private Panel ContentPanel;
        private FlowLayoutPanel MenuPanel;
        private RadioButton MenuMain;
        private RadioButton MenuWorkSetup;
        private RadioButton MenuMonitor;
        private RadioButton MenuSetup;
    }
}
