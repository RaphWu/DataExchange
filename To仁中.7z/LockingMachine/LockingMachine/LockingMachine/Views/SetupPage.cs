﻿using Calin.WinForm.Framework.Navigation;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class SetupPage : UserControl
    {
        public SetupPage()
        {
            InitializeComponent();
        }
    }
}
