﻿using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// 雙軸同動參數編輯器。
    /// </summary>
    public class DualAxisMoveEditor : ProcessEditorBase
    {
        private ComboBox _cmbAxis1Id;
        private NumericUpDown _numAxis1TargetPosition;
        private NumericUpDown _numAxis1Speed;
        private NumericUpDown _numAxis1Acceleration;
        private ComboBox _cmbAxis2Id;
        private NumericUpDown _numAxis2TargetPosition;
        private NumericUpDown _numAxis2Speed;
        private NumericUpDown _numAxis2Acceleration;

        public override string ProcessId => ProcessIds.DUAL_AXIS_MOVE;

        public DualAxisMoveEditor()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            SuspendLayout();

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                ColumnCount = 2,
                RowCount = 8,
                Padding = new Padding(10),
                AutoSize = true
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            var axisOptions = new[] { "Z", "R" };

            // 第一軸代號
            layout.Controls.Add(new Label { Text = $"Z軸：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);

            // 第一軸代號
            //layout.Controls.Add(new Label { Text = "第一軸代號：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);
            //_cmbAxis1Id = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            //_cmbAxis1Id.Items.AddRange(axisOptions);
            //_cmbAxis1Id.SelectedIndexChanged += (s, e) => OnParamChanged();
            //layout.Controls.Add(_cmbAxis1Id, 1, 0);

            // 第一軸目標座標
            layout.Controls.Add(new Label { Text = "座標：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 1);
            _numAxis1TargetPosition = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = -999999,
                Maximum = 999999,
                DecimalPlaces = 3,
                Increment = 1
            };
            _numAxis1TargetPosition.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAxis1TargetPosition, 1, 1);

            // 速度
            layout.Controls.Add(new Label { Text = "速度 (mm/s)：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 2);
            _numAxis1Speed = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 1,
                Maximum = 10000,
                DecimalPlaces = 1,
                Value = 100
            };
            _numAxis1Speed.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAxis1Speed, 1, 2);

            // 加速度
            layout.Controls.Add(new Label { Text = "加速度 (mm/s²)：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 3);
            _numAxis1Acceleration = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 1,
                Maximum = 50000,
                DecimalPlaces = 1,
                Value = 500
            };
            _numAxis1Acceleration.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAxis1Acceleration, 1, 3);

            // 第一軸代號
            layout.Controls.Add(new Label { Text = $"R軸：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 4);

            // 第二軸代號
            //layout.Controls.Add(new Label { Text = "第二軸代號：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 4);
            //_cmbAxis2Id = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            //_cmbAxis2Id.Items.AddRange(axisOptions);
            //_cmbAxis2Id.SelectedIndexChanged += (s, e) => OnParamChanged();
            //layout.Controls.Add(_cmbAxis2Id, 1, 4);

            // 第二軸目標座標
            layout.Controls.Add(new Label { Text = "第二軸座標：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 5);
            _numAxis2TargetPosition = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = -999999,
                Maximum = 999999,
                DecimalPlaces = 3,
                Increment = 1
            };
            _numAxis2TargetPosition.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAxis2TargetPosition, 1, 5);

            // 速度
            layout.Controls.Add(new Label { Text = "速度 (mm/s)：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 6);
            _numAxis2Speed = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 1,
                Maximum = 10000,
                DecimalPlaces = 1,
                Value = 100
            };
            _numAxis2Speed.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAxis2Speed, 1, 6);

            // 加速度
            layout.Controls.Add(new Label { Text = "加速度 (mm/s²)：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 7);
            _numAxis2Acceleration = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 1,
                Maximum = 50000,
                DecimalPlaces = 1,
                Value = 500
            };
            _numAxis2Acceleration.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAxis2Acceleration, 1, 7);

            Controls.Add(layout);

            ResumeLayout(false);
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new DualAxisMoveParam()
                : JsonConvert.DeserializeObject<DualAxisMoveParam>(paramJson) ?? new DualAxisMoveParam();

            //_cmbAxis1Id.SelectedItem = param.Axis1Id ?? "Z";
            _numAxis1TargetPosition.Value = (decimal)param.Axis1TargetPosition;
            _numAxis1Speed.Value = (decimal)param.Axis1Speed;
            _numAxis1Acceleration.Value = (decimal)param.Axis1Acceleration;
            //_cmbAxis2Id.SelectedItem = param.Axis2Id ?? "R";
            _numAxis2TargetPosition.Value = (decimal)param.Axis2TargetPosition;
            _numAxis2Speed.Value = (decimal)param.Axis2Speed;
            _numAxis2Acceleration.Value = (decimal)param.Axis2Acceleration;
        }

        public override string Save()
        {
            var param = new DualAxisMoveParam
            {
                //Axis1Id = _cmbAxis1Id.SelectedItem?.ToString() ?? "Z",
                Axis1TargetPosition = (double)_numAxis1TargetPosition.Value,
                Axis1Speed = (double)_numAxis1Speed.Value,
                Axis1Acceleration = (double)_numAxis1Acceleration.Value,
                //Axis2Id = _cmbAxis2Id.SelectedItem?.ToString() ?? "R",
                Axis2TargetPosition = (double)_numAxis2TargetPosition.Value,
                Axis2Speed = (double)_numAxis2Speed.Value,
                Axis2Acceleration = (double)_numAxis2Acceleration.Value
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            //if (_cmbAxis1Id.SelectedItem?.ToString() == _cmbAxis2Id.SelectedItem?.ToString())
            //    return "兩軸代號不可相同";

            if (_numAxis2Speed.Value <= 0)
                return "速度必須大於 0";

            if (_numAxis2Acceleration.Value <= 0)
                return "加速度必須大於 0";

            return null;
        }
    }
}
