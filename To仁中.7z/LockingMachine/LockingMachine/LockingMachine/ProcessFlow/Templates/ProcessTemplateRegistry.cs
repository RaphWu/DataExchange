using Calin.LockingMachine.ProcessFlow.Core;
using Calin.LockingMachine.ProcessFlow.Templates.Editors;
using Calin.LockingMachine.ProcessFlow.Templates.Handlers;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates
{
    /// <summary>
    /// �u�ǼҪO���U���A�t�d���ѩҦ��u�Ǵy�z�C
    /// </summary>
    public static class ProcessTemplateRegistry
    {
        /// <summary>
        /// ���o�Ҧ��u�Ǵy�z�C
        /// </summary>
        public static IEnumerable<ProcessDescriptor> GetAllDescriptors()
        {
            yield return CreateSingleAxisMoveDescriptor();
            yield return CreateDualAxisMoveDescriptor();
            yield return CreateSensorCheckDescriptor();
            yield return CreateDelayDescriptor();
        }

        private static ProcessDescriptor CreateSingleAxisMoveDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.SINGLE_AXIS_MOVE,
                DisplayName = "��b����",
                Description = "��b�̫��w�t�ײ��ʨ���w�y��",
                HandlerType = typeof(SingleAxisMoveHandler),
                EditorType = typeof(SingleAxisMoveEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new SingleAxisMoveParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<SingleAxisMoveParam>(paramJson);
                        return $"�b:{p.AxisId}, �ؼ�:{p.TargetPosition}, �t��:{p.Speed}";
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateDualAxisMoveDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.DUAL_AXIS_MOVE,
                DisplayName = "���b�P��",
                Description = "��b�P�ʨ̫��w�t�ײ��ʨ���w�y��",
                HandlerType = typeof(DualAxisMoveHandler),
                EditorType = typeof(DualAxisMoveEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new DualAxisMoveParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<DualAxisMoveParam>(paramJson);
                        return $"�bZ:\n�y��:{p.Axis1TargetPosition}, �t��:{p.Axis1Speed}, �[�t��:{p.Axis1Acceleration}\n�bR:\n�y��:{p.Axis2TargetPosition}, �t��:{p.Axis2Speed}, �[�t��:{p.Axis2Acceleration}";
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateSensorCheckDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.HEIGHT_DISPLACEMENT,
                DisplayName = "���׭p�P�_",
                Description = "Ū�����׭p�A�P�_�O�_���b���w�d��",
                HandlerType = typeof(SensorCheckHandler),
                EditorType = typeof(SensorCheckEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new SensorCheckParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<SensorCheckParam>(paramJson);
                        return $"�d��:{p.MinValue}~{p.MaxValue}";
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateDelayDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.DELAY,
                DisplayName = "���𵥫�",
                Description = "������w�ɶ����~�����",
                HandlerType = typeof(DelayHandler),
                EditorType = typeof(DelayEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new DelayParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<DelayParam>(paramJson);
                        var desc = string.IsNullOrEmpty(p.Description) ? "" : $" ({p.Description})";
                        return $"���� {p.DelayMilliseconds} ms{desc}";
                    }
                    catch { return null; }
                }
            };
        }
    }
}
