﻿# 機台工序流程編輯與執行

## 定位與目標

提供 ENGINEER 使用，用來：

- 從既有工序模板中選擇工序
- 組合成一條可排序的流程
- 調整各工序參數
- 儲存後由機台依序執行

這是一套 **工程工具型 UI**，不是展示型 UI。

## 執行環境與限制

- 作業系統：Windows 7
- Framework：.NET Framework 4.8
- 使用 WinForm
- 使用 Autofac 作為 DI Container

## 已實作的檔案結構

```
ProcessFlow/
├── Core/
│   ├── ProcessStepEntity.cs       # 工序步驟實體
│   └── ProcessDescriptor.cs       # 工序描述器
├── Engine/
│   ├── IProcessHandler.cs         # 工序處理器介面
│   ├── ProcessExecutionResult.cs  # 執行結果
│   └── ProcessRunner.cs           # 流程執行器
├── Editor/
│   ├── IProcessEditor.cs          # 參數編輯器介面
│   └── ProcessEditorBase.cs       # 編輯器基底類別
├── Registry/
│   ├── IProcessRegistry.cs        # 工序註冊表介面
│   └── ProcessRegistry.cs         # 工序註冊表實作
├── Templates/
│   ├── ProcessIds.cs              # 工序識別碼常數
│   ├── ProcessTemplateRegistry.cs # 工序模板註冊器
│   ├── Parameters/
│   │   ├── SingleAxisMoveParam.cs # 單軸移動參數
│   │   ├── DualAxisMoveParam.cs   # 雙軸同動參數
│   │   ├── SensorCheckParam.cs    # 感測器判斷參數
│   │   └── DelayParam.cs          # 延遲等待參數
│   ├── Handlers/
│   │   ├── SingleAxisMoveHandler.cs
│   │   ├── DualAxisMoveHandler.cs
│   │   ├── SensorCheckHandler.cs
│   │   └── DelayHandler.cs
│   └── Editors/
│       ├── SingleAxisMoveEditor.cs
│       ├── DualAxisMoveEditor.cs
│       ├── SensorCheckEditor.cs
│       └── DelayEditor.cs
├── UI/
│   ├── ProcessFlowEditorView.cs   # 三區編輯視圖
│   ├── ProcessFlowMainForm.cs     # 主表單（含執行功能）
│   └── EmptyEditor.cs             # 空白編輯器
└── ProcessFlowModule.cs           # Autofac 模組
```

## 核心資料模型

### ProcessStepEntity

```csharp
public class ProcessStepEntity
{
    public int OrderNo { get; set; }        // 流程中的順序
    public string ProcessId { get; set; }   // 工序識別字串
    public string ParamJson { get; set; }   // 參數 JSON
    public bool Enabled { get; set; }       // 是否啟用
}
```

### ProcessDescriptor

```csharp
public class ProcessDescriptor
{
    public string ProcessId { get; set; }                   // 工序識別字串
    public string DisplayName { get; set; }                 // 顯示名稱
    public Type HandlerType { get; set; }                   // Handler 類型
    public Type EditorType { get; set; }                    // Editor 類型
    public string DefaultParamJson { get; set; }            // 預設參數 JSON
    public string Description { get; set; }                 // 工序說明
    public Func<string, string> SummaryFormatter { get; set; } // 摘要格式化器
}
```

## Engine 層設計

### IProcessHandler

```csharp
public interface IProcessHandler
{
    Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken cancellationToken);
    string ValidateParam(string paramJson);
}
```

### ProcessRunner

- 依 OrderNo 依序執行
- Enabled = false 的工序會跳過
- 支援 CancellationToken
- 提供 StepExecuting / StepCompleted 事件
- 不依賴任何 UI 類別

## UI Editor 層設計

### IProcessEditor

```csharp
public interface IProcessEditor
{
    string ProcessId { get; }
    void Load(string paramJson);
    string Save();
    string Validate();
    event EventHandler ParamChanged;
}
```

### ProcessEditorBase

繼承自 UserControl，實作 IProcessEditor 的基底類別。

## UI 架構（三區設計）

| 區域                | 功能                               |
| ----------------- | -------------------------------- |
| 左側：Process Source | 顯示所有可用工序模板（來自 ProcessDescriptor） |
| 中間：Process List   | 顯示實際流程，支援新增、刪除、上移、下移             |
| 右側：Process Editor | 顯示對應工序的參數編輯畫面                    |

### Summary 顯示

流程清單中的「摘要」欄位支援自訂格式化：

- 若 `ProcessDescriptor.SummaryFormatter` 有設定，使用自訂格式
- 若未設定，使用預設的截斷演算法（取前 50 字元）

## Templates 層設計

### ProcessTemplateRegistry

集中管理所有工序的 `ProcessDescriptor`，負責：

- 提供所有工序描述
- 設定各工序的 `SummaryFormatter`

```csharp
public static class ProcessTemplateRegistry
{
    public static IEnumerable<ProcessDescriptor> GetAllDescriptors()
    {
        yield return CreateSingleAxisMoveDescriptor();
        yield return CreateDualAxisMoveDescriptor();
        // ...
    }
}
```

## Autofac 註冊規則

使用 Keyed Registration，Key = ProcessId（字串）：

```csharp
// Handler 註冊
builder.RegisterType<SingleAxisMoveHandler>()
    .Keyed<IProcessHandler>(ProcessIds.SINGLE_AXIS_MOVE)
    .InstancePerDependency();

// Editor 註冊
builder.RegisterType<SingleAxisMoveEditor>()
    .Keyed<IProcessEditor>(ProcessIds.SINGLE_AXIS_MOVE)
    .InstancePerDependency();
```

**嚴禁使用 switch / if 判斷 ProcessId**

## 工序範例

| ProcessId        | 名稱    | 說明                | 摘要格式範例                          |
| ---------------- | ----- | ----------------- | ------------------------------- |
| SINGLE_AXIS_MOVE | 單軸移動  | 單軸依指定速度移動到指定座標    | `軸:X, 目標:100, 速度:50`            |
| DUAL_AXIS_MOVE   | 雙軸同動  | 兩軸同動依指定速度移動到指定座標  | `X:100, Y:200, 速度:50`           |
| SENSOR_CHECK     | 感測器判斷 | 讀取感測器值，判斷是否落在指定範圍 | `感測器:SENSOR_01, 範圍:0~100`       |
| DELAY            | 延遲等待  | 延遲指定時間後繼續執行       | `等待 1000 ms (說明)`               |

## 使用方式

### 1. 註冊模組

在 Program.cs 中註冊 ProcessFlowModule：

```csharp
builder.RegisterModule<ProcessFlowModule>();
builder.RegisterType<ProcessFlowMainForm>().AsSelf().InstancePerDependency();
```

### 2. 啟動表單

```csharp
Application.Run(container.Resolve<ProcessFlowMainForm>());
```

### 3. 新增自訂工序

1. 建立參數類別（繼承自 POCO）
2. 建立 Handler（實作 IProcessHandler）
3. 建立 Editor（繼承 ProcessEditorBase）
4. 在 ProcessTemplateRegistry 中新增 Descriptor
5. 在 ProcessFlowModule 中使用 Keyed 註冊

## 流程檔案格式

流程以 JSON 陣列格式儲存：

```json
[
  {
    "OrderNo": 1,
    "ProcessId": "SINGLE_AXIS_MOVE",
    "ParamJson": "{\"AxisId\":\"X\",\"TargetPosition\":100,\"Speed\":50,\"Acceleration\":500}",
    "Enabled": true
  },
  {
    "OrderNo": 2,
    "ProcessId": "DELAY",
    "ParamJson": "{\"DelayMilliseconds\":1000,\"Description\":\"等待穩定\"}",
    "Enabled": true
  }
]
```

## 擴充指南

### 新增工序的標準步驟

1. **定義 ProcessId 常數**（在 `Templates/ProcessIds.cs`）

   ```csharp
   public const string MY_PROCESS = "MY_PROCESS";
   ```

2. **建立參數類別**（在 `Templates/Parameters/`）

   ```csharp
   public class MyProcessParam
   {
       public string SomeValue { get; set; }
   }
   ```

3. **實作 Handler**（在 `Templates/Handlers/`）

   ```csharp
   public class MyProcessHandler : IProcessHandler
   {
       public async Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken ct)
       {
           var param = JsonConvert.DeserializeObject<MyProcessParam>(paramJson);
           // 執行邏輯
           return ProcessExecutionResult.Succeeded();
       }

       public string ValidateParam(string paramJson)
       {
           // 驗證邏輯
           return null; // null 表示驗證通過
       }
   }
   ```

4. **實作 Editor**（在 `Templates/Editors/`）

   ```csharp
   public class MyProcessEditor : ProcessEditorBase
   {
       public override string ProcessId => ProcessIds.MY_PROCESS;
       // 實作 Load, Save, Validate
   }
   ```

5. **在 ProcessTemplateRegistry 中新增 Descriptor**

   ```csharp
   private static ProcessDescriptor CreateMyProcessDescriptor()
   {
       return new ProcessDescriptor
       {
           ProcessId = ProcessIds.MY_PROCESS,
           DisplayName = "我的工序",
           Description = "工序說明",
           HandlerType = typeof(MyProcessHandler),
           EditorType = typeof(MyProcessEditor),
           DefaultParamJson = JsonConvert.SerializeObject(new MyProcessParam()),
           SummaryFormatter = paramJson =>
           {
               try
               {
                   var p = JsonConvert.DeserializeObject<MyProcessParam>(paramJson);
                   return $"值:{p.SomeValue}";
               }
               catch { return null; }
           }
       };
   }
   ```

6. **在 ProcessFlowModule 中註冊 Handler & Editor**

   ```csharp
   builder.RegisterType<MyProcessHandler>()
       .Keyed<IProcessHandler>(ProcessIds.MY_PROCESS)
       .InstancePerDependency();

   builder.RegisterType<MyProcessEditor>()
       .Keyed<IProcessEditor>(ProcessIds.MY_PROCESS)
       .InstancePerDependency();
   ```

## 設計原則

- UI 與 Engine 完全解耦
- 使用 Autofac Keyed Registration
- 不使用 switch / if 判斷 ProcessId
- 參數使用強型別 + JSON 序列化
- 支援 CancellationToken
- 工序描述集中於 ProcessTemplateRegistry 管理
- 符合 SOLID 原則
