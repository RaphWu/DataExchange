﻿using Autofac;
using Calin.Comm.DL_RS1A;
using Newtonsoft.Json;

namespace Calin.LockingMachine.Services
{
    public partial class DeviceService : IDeviceService_Displacement
    {
        #region DL_RS1A

        /// <inheritdoc/>
        public void DL_RS1A_SaveConfig(DL_RS1A_Config config)
        {
            string json = JsonConvert.SerializeObject(_deviceData.dl_RS1A_Config, Formatting.Indented);
            File.WriteAllText("Displacement.json", json);
        }

        /// <inheritdoc/>
        public DL_RS1A_Config DL_RS1A_LoadConfig()
        {
            DL_RS1A_Config config = null;

            if (File.Exists("Displacement.json"))
            {
                string json = File.ReadAllText("Displacement.json");
                config = JsonConvert.DeserializeObject<DL_RS1A_Config>(json);
                //config.SensorType = KeyenceSensorType.GT2;
                //config.IdNumber = 1;
            }

            if (config == null && _deviceData.comPortList.Count > 0)
            {
                config = new DL_RS1A_Config
                {
                    SensorType = KeyenceSensorType.GT2,
                    IdNumber = 1,
                    PortName = _deviceData.comPortList.First(),
                    BaudRate = 38400,
                    DataBits = 8,
                    Parity = RJCP.IO.Ports.Parity.None,
                    StopBits = RJCP.IO.Ports.StopBits.One,
                };
                DL_RS1A_SaveConfig(config);
            }

            return config;
        }

        /// <inheritdoc/>
        public void DL_RS1A_Init(DL_RS1A_Config config)
        {
            if (_deviceData.dl_RS1A != null)
                _deviceData.dl_RS1A.ResponseReceived -= Dl_RS1A_ResponseReceived;
            _mainFormData.Height = 0.0;

            if (config == null)
                config = _deviceData.dl_RS1A_Config;

            var fac = _scope.Resolve<IDL_RS1A_ServiceFactory>();
            {
                _deviceData.dl_RS1A = fac.Create(config);
                _deviceData.dl_RS1A.Open();
                if (_deviceData.dl_RS1A != null && _deviceData.dl_RS1A.IsTransmissionVerified)
                {
                    _deviceData.dl_RS1A.ResponseReceived += Dl_RS1A_ResponseReceived;
                    _mainFormData.LD_RS1A_Active = true;
                }
            }
        }

        private void Dl_RS1A_ResponseReceived(object sender, DL_RS1A_ResponseEventArgs e)
        {
            if (e.Response.IsSuccess)
            {
                _mainFormData.Height = e.Response.Values[0];
                if (!_mainFormData.LD_RS1A_Active)
                    _mainFormData.LD_RS1A_Active = true;
            }
        }

        public void DL_RS1A_Close()
        {
            if (_deviceData.dl_RS1A != null)
            {
                _deviceData.dl_RS1A.Close();
                _deviceData.dl_RS1A = null;
            }
            _mainFormData.LD_RS1A_Active = false;
        }

        #endregion DL_RS1A
    }
}
