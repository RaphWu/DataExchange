﻿namespace Calin.LockingMachine.Constants
{
    public static class CommonStyle
    {
        public const string AppFontFamily = "Microsoft JhengHei";

        public static Color BgDeviceInOperation = Color.Maroon;
        public static Color FgDeviceInOperation = Color.Yellow;
    }
}
