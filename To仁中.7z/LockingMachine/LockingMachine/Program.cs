using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Calin.LockingMachine
{
    internal static class Program
    {
        // P/Invoke ���w�s�b�{������e��
        private static class NativeMethods
        {
            [DllImport("user32.dll")]
            public static extern bool SetForegroundWindow(IntPtr hWnd);

            [DllImport("user32.dll")]
            public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        }

        // �Ω�T�O��@��Ұ��檺 Mutex
        private static Mutex _mutex;

        /// <summary>
        /// ���ε{�����D�n�i�J�I�C
        /// </summary>
        [STAThread]
        static void Main()
        {
            // �T�O��@��Ұ���
            _mutex = new Mutex(true, "Calin.LockingMachine.UniqueAppMutex", out bool createdNew);
            if (!createdNew)
            {
                // ���{���{���ABringToFront
                var current = Process.GetCurrentProcess();
                var existing = Process.GetProcessesByName(current.ProcessName)
                                      .FirstOrDefault(p => p.Id != current.Id);
                if (existing != null)
                {
                    MessageBox.Show("LockingMachine �w�b���椤�A�N������w�}�Ҫ������C", "����", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    NativeMethods.ShowWindow(existing.MainWindowHandle, 5); // SW_SHOW
                    NativeMethods.SetForegroundWindow(existing.MainWindowHandle);
                }
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new AppStartupContext());

            _mutex.Dispose();
        }
    }
}