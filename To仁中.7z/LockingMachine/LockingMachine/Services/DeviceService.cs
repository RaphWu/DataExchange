﻿using System.Timers;
using Autofac;
using Calin.Comm.DL_RS1A;
using Calin.LockingMachine.Models;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Services;

namespace Calin.LockingMachine.Services
{
    public partial class DeviceService : IDevice
    {
        #region Fields

        private readonly ILifetimeScope _scope;
        private readonly IAcm _acm;
        private readonly MainFormData _mainFormData;
        private readonly DeviceData _deviceData;

        private readonly System.Timers.Timer _deviceTimer;

        #endregion Fields

        #region ctor

        public DeviceService(
            ILifetimeScope lifetimeScope,
            IAcm acm,
            MainFormData mainFormData,
            DeviceData deviceData
            )
        {
            _scope = lifetimeScope;
            _mainFormData = mainFormData;
            _acm = acm;
            _deviceData = deviceData;

            // 更新可用的 COM 埠列表
            UpdateComPortList();

            // 初始化高度計
            DL_RS1A_LoadConfig();
            DL_RS1A_Init();

            // 初始化設備計時器
            _deviceTimer = new System.Timers.Timer();
            _deviceTimer.Interval = 25;
            _deviceTimer.Elapsed += DeviceTimer_Tick;
            _deviceTimer.Start();

            // 訂閱 Advantech ACM 狀態更新事件
            _acm.AcmStatusUpdated += AcmStatusUpdated;
        }

        #endregion ctor

        #region 

        /// <inheritdoc/>
        public void UpdateComPortList()
        {
            using (var serialPortStream = new RJCP.IO.Ports.SerialPortStream())
            {
                _deviceData.comPortList = serialPortStream.GetPortNames().ToList();
            }
        }

        #endregion 

        #region Events

        private void DeviceTimer_Tick(object sender, EventArgs e)
        {
            _deviceData.dl_RS1A?.ReadAll();
        }

        private void AcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs e)
        {
        }

        #endregion Events
    }
}
