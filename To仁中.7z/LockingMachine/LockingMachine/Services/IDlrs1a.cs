﻿using Calin.Comm.DL_RS1A;

namespace Calin.LockingMachine.Services
{
    /// <summary>
    /// 設備服務 - 位移計介面
    /// </summary>
    public interface IDlrs1a
    {
        /// <summary>
        /// 關閉 DL_RS1A 位移計。
        /// </summary>
        void Dlrs1aClose();

        /// <summary>
        /// 初始化高度計。
        /// </summary>
        void Dlrs1aInit(DL_RS1A_Config config);

        /// <summary>
        /// 儲存 DL_RS1A 配置。
        /// </summary>
        void Dlrs1aSaveConfig(DL_RS1A_Config config);

        /// <summary>
        /// 載入 DL_RS1A 配置。
        /// </summary>
        /// <returns></returns>
        DL_RS1A_Config Dlrs1aLoadConfig();
    }
}
