﻿namespace Calin.LockingMachine.Services
{
    public class DaqService : IDaq
    {
    }
}
