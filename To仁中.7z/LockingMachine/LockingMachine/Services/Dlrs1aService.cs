﻿using Autofac;
using Calin.Comm.DL_RS1A;
using Calin.LockingMachine.Models;
using Newtonsoft.Json;

namespace Calin.LockingMachine.Services
{
    public class Dlrs1aService : IDlrs1a
    {
        #region Fields

        private readonly ILifetimeScope _scope;
        private readonly MainFormData _mainFormData;
        private readonly DeviceData _deviceData;
        private readonly Dlrs1aData _dispData;
        private readonly IDeviceService _deviceService;

        // 高度計
        private readonly string _heightDisplacementFile = "HeightDisplacement.json";

        #endregion Fields

        public Dlrs1aService(
            ILifetimeScope scope,
            MainFormData mainFormData,
            DeviceData deviceData,
            Dlrs1aData dispData,
            IDeviceService deviceService)
        {
            _scope = scope;
            _mainFormData = mainFormData;
            _deviceData = deviceData;
            _dispData = dispData;
            _deviceService = deviceService;

            // 初始化高度計
            _dispData.dlrs1aConfig = Dlrs1aLoadConfig();
            Dlrs1aInit(_dispData.dlrs1aConfig);
        }

        private void DeviceService_LockingMachineTimerEvent(object sender, LockingMachineTimerEventArgs e)
        {
            if (_dispData.dlrs1a != null)
                _dispData.dlrs1a.ReadAll();
        }

        /// <inheritdoc/>
        public void Dlrs1aClose()
        {
            _deviceService.LockingMachineTimerEvent -= DeviceService_LockingMachineTimerEvent;
            _dispData.dlrs1a.ResponseReceived -= Dlrs1aReceived;

            if (_dispData.dlrs1a != null)
            {
                _dispData.dlrs1a.Close();
                _dispData.dlrs1a = null;
            }
            _mainFormData.HeightDisplacementActive = false;
        }

        /// <inheritdoc/>
        public void Dlrs1aInit(DL_RS1A_Config config)
        {
            if (_dispData.dlrs1a != null)
                _dispData.dlrs1a.ResponseReceived -= Dlrs1aReceived;
            _mainFormData.HeightDisplacementValue = 0.0;

            if (config == null)
                config = _dispData.dlrs1aConfig;

            var fac = _scope.Resolve<IDL_RS1A_ServiceFactory>();
            {
                _dispData.dlrs1a = fac.CreateAndOpen(config);
                if (_dispData.dlrs1a != null && _dispData.dlrs1a.IsTransmissionVerified)
                {
                    _dispData.dlrs1a.ResponseReceived += Dlrs1aReceived;
                    _mainFormData.HeightDisplacementActive = true;
                    _deviceService.LockingMachineTimerEvent += DeviceService_LockingMachineTimerEvent;
                }
            }
        }

        /// <summary>
        /// 高度計回應接收事件處理程式。
        /// </summary>
        private void Dlrs1aReceived(object sender, DL_RS1A_ResponseEventArgs e)
        {
            if (e.Response.IsSuccess)
            {
                _mainFormData.HeightDisplacementValue = e.Response.Values[0];
                if (!_mainFormData.HeightDisplacementActive)
                    _mainFormData.HeightDisplacementActive = true;
            }
        }

        /// <inheritdoc/>
        public void Dlrs1aSaveConfig(DL_RS1A_Config config)
        {
            string json = JsonConvert.SerializeObject(_dispData.dlrs1aConfig, Formatting.Indented);
            File.WriteAllText(_heightDisplacementFile, json);
        }

        /// <inheritdoc/>
        public DL_RS1A_Config Dlrs1aLoadConfig()
        {
            DL_RS1A_Config config = null;

            if (File.Exists(_heightDisplacementFile))
            {
                string json = File.ReadAllText(_heightDisplacementFile);
                config = JsonConvert.DeserializeObject<DL_RS1A_Config>(json);
                config.SensorType = KeyenceSensorType.GT2;
                config.IdNumber = 1;
            }

            if (config == null && _deviceData.comPortList.Count > 0)
            {
                config = new DL_RS1A_Config
                {
                    SensorType = KeyenceSensorType.GT2,
                    IdNumber = 1,
                    PortName = _deviceData.comPortList.First(),
                    BaudRate = 38400,
                    DataBits = 8,
                    Parity = RJCP.IO.Ports.Parity.None,
                    StopBits = RJCP.IO.Ports.StopBits.One,
                };
                Dlrs1aSaveConfig(config);
            }

            return config;
        }
    }
}
