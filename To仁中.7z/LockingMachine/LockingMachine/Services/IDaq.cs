﻿namespace Calin.LockingMachine.Services
{
    public interface IDaq
    {
    }
}
