﻿namespace Calin.LockingMachine.Services
{
    public class LockingMachineTimerEventArgs : EventArgs
    {
        public LockingMachineTimerEventArgs(EventArgs e)
        {
        }
    }
}