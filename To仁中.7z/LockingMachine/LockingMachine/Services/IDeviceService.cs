﻿namespace Calin.LockingMachine.Services
{
    public interface IDeviceService
    {
        /// <summary>
        /// 鎖付機計時器事件。
        /// </summary>
        public event EventHandler<LockingMachineTimerEventArgs> LockingMachineTimerEvent;

        /// <summary>
        /// 取得系統可用的 COM 埠清單。
        /// </summary>
        void UpdateComPortList();
    }
}
