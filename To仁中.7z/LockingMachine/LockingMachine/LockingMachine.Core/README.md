﻿# Calin.LockingMachine.Core

Calin.LockingMachine 是一個鎖付機的控制程式。

# 目標框架

- WinForm
- .NET Framework 4.8

# NuGet 依賴

- AutoFac
- Calin.CSharp v0.0.3
- Calin.WinForm v0.0.3

# 主要功能

