﻿namespace Calin.LockingMachine.Views
{
    partial class SplashScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.appName = new System.Windows.Forms.Label();
            this.msgList = new System.Windows.Forms.Label();
            this.AbortLoading = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // appName
            // 
            this.appName.AutoSize = true;
            this.appName.BackColor = System.Drawing.Color.Transparent;
            this.appName.Font = new System.Drawing.Font("Baskerville Old Face", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appName.Location = new System.Drawing.Point(37, 16);
            this.appName.Name = "appName";
            this.appName.Size = new System.Drawing.Size(193, 27);
            this.appName.TabIndex = 1;
            this.appName.Text = "Locking Machine";
            // 
            // msgList
            // 
            this.msgList.BackColor = System.Drawing.Color.Transparent;
            this.msgList.Font = new System.Drawing.Font("微軟正黑體", 10F);
            this.msgList.Location = new System.Drawing.Point(39, 68);
            this.msgList.Name = "msgList";
            this.msgList.Size = new System.Drawing.Size(324, 162);
            this.msgList.TabIndex = 3;
            // 
            // AbortLoading
            // 
            this.AbortLoading.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AbortLoading.BackColor = System.Drawing.Color.Transparent;
            this.AbortLoading.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AbortLoading.FlatAppearance.BorderSize = 0;
            this.AbortLoading.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.AbortLoading.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AbortLoading.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold);
            this.AbortLoading.Location = new System.Drawing.Point(366, 12);
            this.AbortLoading.MinimumSize = new System.Drawing.Size(1, 1);
            this.AbortLoading.Name = "AbortLoading";
            this.AbortLoading.Size = new System.Drawing.Size(22, 22);
            this.AbortLoading.TabIndex = 4;
            this.AbortLoading.Text = "X";
            this.AbortLoading.UseVisualStyleBackColor = false;
            this.AbortLoading.Click += new System.EventHandler(this.AbortLoading_Click);
            // 
            // SplashScreen
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImage = global::Calin.LockingMachine.Core.Properties.Resources.SplashScreen;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(400, 250);
            this.ControlBox = false;
            this.Controls.Add(this.AbortLoading);
            this.Controls.Add(this.msgList);
            this.Controls.Add(this.appName);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SplashScreen";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SplashScreen";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SplashScreen_FormClosing);
            this.Load += new System.EventHandler(this.SplashScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label appName;
        private System.Windows.Forms.Label msgList;
        private System.Windows.Forms.Button AbortLoading;
    }
}