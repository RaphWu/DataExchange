﻿using Autofac;

namespace Calin.LockingMachine.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {

        }
    }
}
