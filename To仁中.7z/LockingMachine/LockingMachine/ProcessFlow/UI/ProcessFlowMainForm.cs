using Autofac;
using Calin.LockingMachine.ProcessFlow.Core;
using Calin.LockingMachine.ProcessFlow.Engine;
using Calin.LockingMachine.ProcessFlow.Registry;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.UI
{
    /// <summary>
    /// �u�Ǭy�{�s��D����A�]�t�s��P����\��C
    /// </summary>
    public class ProcessFlowMainForm : Form
    {
        private readonly ILifetimeScope _scope;
        private readonly IProcessRegistry _registry;

        private ProcessFlowEditorView _editorView;
        private ToolStrip _toolStrip;
        private StatusStrip _statusStrip;
        private ToolStripStatusLabel _lblStatus;
        private ToolStripProgressBar _progressBar;

        private CancellationTokenSource _runCts;
        private bool _isRunning;

        public ProcessFlowMainForm(ILifetimeScope scope, IProcessRegistry registry)
        {
            _scope = scope ?? throw new ArgumentNullException(nameof(scope));
            _registry = registry ?? throw new ArgumentNullException(nameof(registry));

            InitializeForm();
            InitializeComponents();
        }

        private void InitializeForm()
        {
            this.Text = "�u�Ǭy�{�s��t��";
            this.Size = new Size(1000, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void InitializeComponents()
        {
            this.SuspendLayout();

            // ToolStrip
            _toolStrip = new ToolStrip();

            var btnNew = new ToolStripButton("�s��", null, BtnNew_Click) { DisplayStyle = ToolStripItemDisplayStyle.Text };
            var btnOpen = new ToolStripButton("�}��", null, BtnOpen_Click) { DisplayStyle = ToolStripItemDisplayStyle.Text };
            var btnSave = new ToolStripButton("�x�s", null, BtnSave_Click) { DisplayStyle = ToolStripItemDisplayStyle.Text };
            var separator1 = new ToolStripSeparator();
            var btnRun = new ToolStripButton("����", null, BtnRun_Click) { DisplayStyle = ToolStripItemDisplayStyle.Text, Name = "btnRun" };
            var btnStop = new ToolStripButton("����", null, BtnStop_Click) { DisplayStyle = ToolStripItemDisplayStyle.Text, Name = "btnStop", Enabled = false };
            var separator2 = new ToolStripSeparator();
            var btnValidate = new ToolStripButton("����", null, BtnValidate_Click) { DisplayStyle = ToolStripItemDisplayStyle.Text };

            _toolStrip.Items.AddRange(new ToolStripItem[]
            {
                btnNew, btnOpen, btnSave, separator1, btnRun, btnStop, separator2, btnValidate
            });

            // StatusStrip
            _statusStrip = new StatusStrip();
            _lblStatus = new ToolStripStatusLabel("�N��") { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
            _progressBar = new ToolStripProgressBar { Visible = false, Width = 200 };
            _statusStrip.Items.AddRange(new ToolStripItem[] { _lblStatus, _progressBar });

            // Editor View
            _editorView = new ProcessFlowEditorView(_scope, _registry)
            {
                Dock = DockStyle.Fill
            };
            _editorView.FlowChanged += EditorView_FlowChanged;

            this.Controls.Add(_editorView);
            this.Controls.Add(_toolStrip);
            this.Controls.Add(_statusStrip);

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private void EditorView_FlowChanged(object sender, EventArgs e)
        {
            UpdateStatus("�y�{�w�ק�");
        }

        private void BtnNew_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("�T�w�n�M���ثe���y�{�ܡH", "�T�{", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _editorView.ClearSteps();
                UpdateStatus("�w�إ߷s�y�{");
            }
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            using (var dialog = new OpenFileDialog
            {
                Filter = "�y�{�ɮ� (*.json)|*.json|�Ҧ��ɮ� (*.*)|*.*",
                Title = "�}�Ҭy�{�ɮ�"
            })
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var json = File.ReadAllText(dialog.FileName);
                        var steps = JsonConvert.DeserializeObject<List<ProcessStepEntity>>(json);
                        _editorView.LoadSteps(steps);
                        UpdateStatus($"�w���J�y�{: {Path.GetFileName(dialog.FileName)}");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"���J����: {ex.Message}", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            using (var dialog = new SaveFileDialog
            {
                Filter = "�y�{�ɮ� (*.json)|*.json|�Ҧ��ɮ� (*.*)|*.*",
                Title = "�x�s�y�{�ɮ�",
                DefaultExt = "json"
            })
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var steps = _editorView.GetSteps();
                        var json = JsonConvert.SerializeObject(steps, new JsonSerializerSettings { Formatting = Formatting.Indented });
                        File.WriteAllText(dialog.FileName, json);
                        UpdateStatus($"�w�x�s�y�{: {Path.GetFileName(dialog.FileName)}");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"�x�s����: {ex.Message}", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void BtnRun_Click(object sender, EventArgs e)
        {
            var steps = _editorView.GetSteps();
            if (!steps.Any())
            {
                MessageBox.Show("�y�{���S������u��", "����", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            SetRunningState(true);
            _runCts = new CancellationTokenSource();

            try
            {
                var runner = _scope.Resolve<ProcessRunner>();
                runner.StepExecuting += Runner_StepExecuting;
                runner.StepCompleted += Runner_StepCompleted;

                _progressBar.Value = 0;
                _progressBar.Maximum = steps.Count(s => s.Enabled);

                var result = await runner.RunAsync(steps, _runCts.Token);

                if (result.Success)
                {
                    UpdateStatus($"�y�{���槹���A�@ {result.ExecutedSteps} �Ӥu��");
                    MessageBox.Show($"�y�{���槹���I\n����u�Ǽ�: {result.ExecutedSteps}", "����", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    UpdateStatus($"�y�{���楢��: {result.ErrorMessage}");
                    MessageBox.Show($"�y�{���楢�ѡI\n{result.ErrorMessage}", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (OperationCanceledException)
            {
                UpdateStatus("�y�{�w����");
            }
            catch (Exception ex)
            {
                UpdateStatus($"������~: {ex.Message}");
                MessageBox.Show($"������~: {ex.Message}", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetRunningState(false);
                _runCts?.Dispose();
                _runCts = null;
            }
        }

        private void Runner_StepExecuting(object sender, ProcessStepExecutingEventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => Runner_StepExecuting(sender, e)));
                return;
            }

            var desc = _registry.GetById(e.Step.ProcessId);
            UpdateStatus($"���b����: {desc?.DisplayName ?? e.Step.ProcessId} ({e.CurrentIndex + 1}/{e.TotalSteps})");
        }

        private void Runner_StepCompleted(object sender, ProcessStepCompletedEventArgs e)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => Runner_StepCompleted(sender, e)));
                return;
            }

            if (e.Result.Success)
            {
                _progressBar.Value = Math.Min(_progressBar.Value + 1, _progressBar.Maximum);
            }
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            _runCts?.Cancel();
            UpdateStatus("���b����...");
        }

        private void BtnValidate_Click(object sender, EventArgs e)
        {
            var steps = _editorView.GetSteps();
            if (!steps.Any())
            {
                MessageBox.Show("�y�{���S������u��", "����", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var errors = new List<string>();
            foreach (var step in steps)
            {
                try
                {
                    var handler = _scope.ResolveKeyed<IProcessHandler>(step.ProcessId);
                    var error = handler.ValidateParam(step.ParamJson);
                    if (!string.IsNullOrEmpty(error))
                    {
                        var desc = _registry.GetById(step.ProcessId);
                        errors.Add($"#{step.OrderNo} {desc?.DisplayName ?? step.ProcessId}: {error}");
                    }
                }
                catch (Exception ex)
                {
                    errors.Add($"#{step.OrderNo} {step.ProcessId}: ���Үɵo�Ϳ��~ - {ex.Message}");
                }
            }

            if (errors.Any())
            {
                MessageBox.Show($"���ҵo�{�H�U���D:\n\n{string.Join("\n", errors)}", "���ҵ��G", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("�Ҧ��u�ǰѼ����ҳq�L�I", "���ҵ��G", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void SetRunningState(bool running)
        {
            _isRunning = running;
            _toolStrip.Items["btnRun"].Enabled = !running;
            _toolStrip.Items["btnStop"].Enabled = running;
            _progressBar.Visible = running;

            if (!running)
            {
                _progressBar.Value = 0;
            }
        }

        private void UpdateStatus(string message)
        {
            _lblStatus.Text = message;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_isRunning)
            {
                var result = MessageBox.Show("�y�{���b���椤�A�T�w�n�����ܡH", "�T�{", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }

                _runCts?.Cancel();
            }

            base.OnFormClosing(e);
        }
    }
}
