﻿using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Samples.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Samples.Editors
{
    /// <summary>
    /// 雙軸同動參數編輯器。
    /// </summary>
    public class DualAxisMoveEditor : ProcessEditorBase
    {
        private ComboBox _cmbAxis1Id;
        private NumericUpDown _numAxis1TargetPosition;
        private ComboBox _cmbAxis2Id;
        private NumericUpDown _numAxis2TargetPosition;
        private NumericUpDown _numSpeed;
        private NumericUpDown _numAcceleration;

        public override string ProcessId => ProcessIds.DUAL_AXIS_MOVE;

        public DualAxisMoveEditor()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.SuspendLayout();

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 7,
                Padding = new Padding(10)
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            var axisOptions = new[] { "X", "Y", "Z", "A", "B", "C" };

            // 第一軸代號
            layout.Controls.Add(new Label { Text = "第一軸代號：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);
            _cmbAxis1Id = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbAxis1Id.Items.AddRange(axisOptions);
            _cmbAxis1Id.SelectedIndexChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_cmbAxis1Id, 1, 0);

            // 第一軸目標座標
            layout.Controls.Add(new Label { Text = "第一軸座標：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 1);
            _numAxis1TargetPosition = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = -999999,
                Maximum = 999999,
                DecimalPlaces = 3,
                Increment = 1
            };
            _numAxis1TargetPosition.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAxis1TargetPosition, 1, 1);

            // 第二軸代號
            layout.Controls.Add(new Label { Text = "第二軸代號：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 2);
            _cmbAxis2Id = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbAxis2Id.Items.AddRange(axisOptions);
            _cmbAxis2Id.SelectedIndexChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_cmbAxis2Id, 1, 2);

            // 第二軸目標座標
            layout.Controls.Add(new Label { Text = "第二軸座標：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 3);
            _numAxis2TargetPosition = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = -999999,
                Maximum = 999999,
                DecimalPlaces = 3,
                Increment = 1
            };
            _numAxis2TargetPosition.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAxis2TargetPosition, 1, 3);

            // 速度
            layout.Controls.Add(new Label { Text = "速度 (mm/s)：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 4);
            _numSpeed = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 1,
                Maximum = 10000,
                DecimalPlaces = 1,
                Value = 100
            };
            _numSpeed.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numSpeed, 1, 4);

            // 加速度
            layout.Controls.Add(new Label { Text = "加速度 (mm/s²)：", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 5);
            _numAcceleration = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 1,
                Maximum = 50000,
                DecimalPlaces = 1,
                Value = 500
            };
            _numAcceleration.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numAcceleration, 1, 5);

            this.Controls.Add(layout);

            this.ResumeLayout(false);
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new DualAxisMoveParam()
                : JsonConvert.DeserializeObject<DualAxisMoveParam>(paramJson) ?? new DualAxisMoveParam();

            _cmbAxis1Id.SelectedItem = param.Axis1Id ?? "X";
            _numAxis1TargetPosition.Value = (decimal)param.Axis1TargetPosition;
            _cmbAxis2Id.SelectedItem = param.Axis2Id ?? "Y";
            _numAxis2TargetPosition.Value = (decimal)param.Axis2TargetPosition;
            _numSpeed.Value = (decimal)param.Speed;
            _numAcceleration.Value = (decimal)param.Acceleration;
        }

        public override string Save()
        {
            var param = new DualAxisMoveParam
            {
                Axis1Id = _cmbAxis1Id.SelectedItem?.ToString() ?? "X",
                Axis1TargetPosition = (double)_numAxis1TargetPosition.Value,
                Axis2Id = _cmbAxis2Id.SelectedItem?.ToString() ?? "Y",
                Axis2TargetPosition = (double)_numAxis2TargetPosition.Value,
                Speed = (double)_numSpeed.Value,
                Acceleration = (double)_numAcceleration.Value
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (_cmbAxis1Id.SelectedItem?.ToString() == _cmbAxis2Id.SelectedItem?.ToString())
                return "兩軸代號不可相同";

            if (_numSpeed.Value <= 0)
                return "速度必須大於 0";

            if (_numAcceleration.Value <= 0)
                return "加速度必須大於 0";

            return null;
        }
    }
}
