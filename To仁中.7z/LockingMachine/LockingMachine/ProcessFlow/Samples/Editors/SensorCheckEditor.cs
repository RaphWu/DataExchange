using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Samples.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Samples.Editors
{
    /// <summary>
    /// �P����Ū���P�d��P�_�Ѽƽs�边�C
    /// </summary>
    public class SensorCheckEditor : ProcessEditorBase
    {
        private TextBox _txtSensorId;
        private NumericUpDown _numMinValue;
        private NumericUpDown _numMaxValue;
        private ComboBox _cmbInRangeAction;
        private ComboBox _cmbOutOfRangeAction;

        public override string ProcessId => ProcessIds.SENSOR_CHECK;

        public SensorCheckEditor()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.SuspendLayout();

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 6,
                Padding = new Padding(10)
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            // �P�����ѧO�X
            layout.Controls.Add(new Label { Text = "�P���� ID�G", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);
            _txtSensorId = new TextBox { Dock = DockStyle.Fill };
            _txtSensorId.TextChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_txtSensorId, 1, 0);

            // �̤p��
            layout.Controls.Add(new Label { Text = "�̤p�ȡG", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 1);
            _numMinValue = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = -999999,
                Maximum = 999999,
                DecimalPlaces = 3,
                Increment = 1
            };
            _numMinValue.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numMinValue, 1, 1);

            // �̤j��
            layout.Controls.Add(new Label { Text = "�̤j�ȡG", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 2);
            _numMaxValue = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = -999999,
                Maximum = 999999,
                DecimalPlaces = 3,
                Increment = 1,
                Value = 100
            };
            _numMaxValue.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numMaxValue, 1, 2);

            // �b�d�򤺪��ʧ@
            layout.Controls.Add(new Label { Text = "�d�򤺰ʧ@�G", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 3);
            _cmbInRangeAction = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbInRangeAction.Items.AddRange(new object[]
            {
                new ActionItem(SensorCheckAction.None, "�L�ʧ@"),
                new ActionItem(SensorCheckAction.Continue, "�~�����"),
                new ActionItem(SensorCheckAction.StopFlow, "����y�{"),
                new ActionItem(SensorCheckAction.TriggerAlarm, "Ĳ�oĵ��")
            });
            _cmbInRangeAction.DisplayMember = "DisplayName";
            _cmbInRangeAction.SelectedIndexChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_cmbInRangeAction, 1, 3);

            // �b�d��~���ʧ@
            layout.Controls.Add(new Label { Text = "�d��~�ʧ@�G", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 4);
            _cmbOutOfRangeAction = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbOutOfRangeAction.Items.AddRange(new object[]
            {
                new ActionItem(SensorCheckAction.None, "�L�ʧ@"),
                new ActionItem(SensorCheckAction.Continue, "�~�����"),
                new ActionItem(SensorCheckAction.StopFlow, "����y�{"),
                new ActionItem(SensorCheckAction.TriggerAlarm, "Ĳ�oĵ��")
            });
            _cmbOutOfRangeAction.DisplayMember = "DisplayName";
            _cmbOutOfRangeAction.SelectedIndexChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_cmbOutOfRangeAction, 1, 4);

            this.Controls.Add(layout);

            this.ResumeLayout(false);
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new SensorCheckParam()
                : JsonConvert.DeserializeObject<SensorCheckParam>(paramJson) ?? new SensorCheckParam();

            _txtSensorId.Text = param.SensorId ?? "SENSOR_01";
            _numMinValue.Value = (decimal)param.MinValue;
            _numMaxValue.Value = (decimal)param.MaxValue;

            SelectActionItem(_cmbInRangeAction, param.InRangeAction);
            SelectActionItem(_cmbOutOfRangeAction, param.OutOfRangeAction);
        }

        public override string Save()
        {
            var param = new SensorCheckParam
            {
                SensorId = _txtSensorId.Text,
                MinValue = (double)_numMinValue.Value,
                MaxValue = (double)_numMaxValue.Value,
                InRangeAction = GetSelectedAction(_cmbInRangeAction),
                OutOfRangeAction = GetSelectedAction(_cmbOutOfRangeAction)
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (string.IsNullOrWhiteSpace(_txtSensorId.Text))
                return "�P�����ѧO�X���i����";

            if (_numMinValue.Value > _numMaxValue.Value)
                return "�̤p�Ȥ��i�j��̤j��";

            return null;
        }

        private void SelectActionItem(ComboBox comboBox, SensorCheckAction action)
        {
            for (int i = 0; i < comboBox.Items.Count; i++)
            {
                if (comboBox.Items[i] is ActionItem item && item.Action == action)
                {
                    comboBox.SelectedIndex = i;
                    return;
                }
            }
            comboBox.SelectedIndex = 0;
        }

        private SensorCheckAction GetSelectedAction(ComboBox comboBox)
        {
            return (comboBox.SelectedItem as ActionItem)?.Action ?? SensorCheckAction.None;
        }

        private class ActionItem
        {
            public SensorCheckAction Action { get; }
            public string DisplayName { get; }

            public ActionItem(SensorCheckAction action, string displayName)
            {
                Action = action;
                DisplayName = displayName;
            }

            public override string ToString() => DisplayName;
        }
    }
}
