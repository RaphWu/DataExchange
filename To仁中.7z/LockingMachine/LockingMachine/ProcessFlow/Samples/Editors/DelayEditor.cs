using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Samples.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Samples.Editors
{
    /// <summary>
    /// ���𵥫ݰѼƽs�边�C
    /// </summary>
    public class DelayEditor : ProcessEditorBase
    {
        private NumericUpDown _numDelayMs;
        private TextBox _txtDescription;

        public override string ProcessId => ProcessIds.DELAY;

        public DelayEditor()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.SuspendLayout();

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 3,
                Padding = new Padding(10)
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            // ����ɶ�
            layout.Controls.Add(new Label { Text = "���� (ms)�G", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);
            _numDelayMs = new NumericUpDown
            {
                Dock = DockStyle.Fill,
                Minimum = 0,
                Maximum = 600000, // �̦h 10 ����
                Increment = 100,
                Value = 1000
            };
            _numDelayMs.ValueChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_numDelayMs, 1, 0);

            // ����
            layout.Controls.Add(new Label { Text = "�����G", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 1);
            _txtDescription = new TextBox { Dock = DockStyle.Fill };
            _txtDescription.TextChanged += (s, e) => OnParamChanged();
            layout.Controls.Add(_txtDescription, 1, 1);

            this.Controls.Add(layout);

            this.ResumeLayout(false);
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new DelayParam()
                : JsonConvert.DeserializeObject<DelayParam>(paramJson) ?? new DelayParam();

            _numDelayMs.Value = param.DelayMilliseconds;
            _txtDescription.Text = param.Description ?? "";
        }

        public override string Save()
        {
            var param = new DelayParam
            {
                DelayMilliseconds = (int)_numDelayMs.Value,
                Description = _txtDescription.Text
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (_numDelayMs.Value < 0)
                return "����ɶ����i���t��";

            return null;
        }
    }
}
