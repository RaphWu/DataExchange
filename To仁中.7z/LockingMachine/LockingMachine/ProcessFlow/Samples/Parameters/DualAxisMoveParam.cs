namespace Calin.LockingMachine.ProcessFlow.Samples.Parameters
{
    /// <summary>
    /// ���b�P�ʰѼơC
    /// </summary>
    public class DualAxisMoveParam
    {
        /// <summary>
        /// �Ĥ@�b�N���C
        /// </summary>
        public string Axis1Id { get; set; } = "X";

        /// <summary>
        /// �Ĥ@�b�ؼЮy�СC
        /// </summary>
        public double Axis1TargetPosition { get; set; }

        /// <summary>
        /// �ĤG�b�N���C
        /// </summary>
        public string Axis2Id { get; set; } = "Y";

        /// <summary>
        /// �ĤG�b�ؼЮy�СC
        /// </summary>
        public double Axis2TargetPosition { get; set; }

        /// <summary>
        /// ���ʳt�ס]���Gmm/s�^�C
        /// </summary>
        public double Speed { get; set; } = 100;

        /// <summary>
        /// �[�t�ס]���Gmm/s?�^�C
        /// </summary>
        public double Acceleration { get; set; } = 500;
    }
}
