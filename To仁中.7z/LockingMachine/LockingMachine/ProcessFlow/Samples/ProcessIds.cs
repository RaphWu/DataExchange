namespace Calin.LockingMachine.ProcessFlow.Samples
{
    /// <summary>
    /// �u���ѧO�X�`�ơC
    /// </summary>
    public static class ProcessIds
    {
        /// <summary>
        /// ��b���ʡC
        /// </summary>
        public const string SINGLE_AXIS_MOVE = "SINGLE_AXIS_MOVE";

        /// <summary>
        /// ���b�P�ʡC
        /// </summary>
        public const string DUAL_AXIS_MOVE = "DUAL_AXIS_MOVE";

        /// <summary>
        /// �P����Ū���P�d��P�_�C
        /// </summary>
        public const string SENSOR_CHECK = "SENSOR_CHECK";

        /// <summary>
        /// ���𵥫ݡC
        /// </summary>
        public const string DELAY = "DELAY";
    }
}
