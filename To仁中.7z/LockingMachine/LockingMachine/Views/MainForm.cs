using System.ComponentModel;
using Calin.Framework.Navigation;
using Calin.LockingMachine.Constants;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.Views;
using Calin.MC.Advantech.Contracts;

namespace Calin.LockingMachine
{
    public partial class MainForm : Form
    {
        #region Fields

        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly IAcm _acm;
        private readonly MainFormData _mainFormData = new MainFormData();

        // ���A�C�T���p�ɾ��A�w�ɲM���T��
        private System.Windows.Forms.Timer _messageTimer = new System.Windows.Forms.Timer();

        private PageCode _currentPageCode = PageCode.None;

        #endregion Fields

        #region ctor

        public MainForm(
            IRegionManager regionManager,
            INavigationService navigationService,
            IAcm acm,
            MainFormData mainFormData
            )
        {
            _region = regionManager;
            _nav = navigationService;
            _acm = acm;
            _mainFormData = mainFormData;

            InitializeComponent();

            // Region ���U
            _region.RegisterRegion(nameof(ContentPanel), view =>
            {
                ContentPanel.SuspendLayout();
                ContentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    ContentPanel.Controls.Add(control);
                }
                ContentPanel.ResumeLayout();
            });

            // Status Bar
            _mainFormData.PropertyChanged += MainFormData_PropertyChanged;
        }

        private void InitBinding()
        {
        }

        #endregion ctor

        #region Form Events

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_acm.IsBoardInit)
            {
                _acm.PollingStop();
                _acm.BoardClose();
            }

            // ����Ҧ� Timer
            _messageTimer?.Stop();
            _messageTimer?.Dispose();

            ClockTimer?.Stop();
            ClockTimer?.Dispose();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ResizeScreen();
            UpdateStatusBar(""); // ��l�ƪ��A�C��ܤ��e

            _acm.BoardOpen();
            if (_acm.IsBoardInit)
            {
                _acm.PollingStart();
                _mainFormData.ZAxisActive = true;
                _mainFormData.RAxisActive = true;
            }
            else
            {
                _mainFormData.ZAxisActive = false;
                _mainFormData.RAxisActive = false;
            }
        }

        /// <summary>
        /// �� MainFormData �ݩ��ܧ��Ĳ�o�C
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainFormData_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            UpdateStatusBar(e.PropertyName);
        }

        /// <summary>
        /// ��s���A�C��ܤ��e�C
        /// </summary>
        /// <param name="propertyName"></param>
        private void UpdateStatusBar(string propertyName)
        {
            bool isEmpty = string.IsNullOrEmpty(propertyName);

            // Z�b
            if (propertyName == nameof(MainFormData.ZAxisActive) || isEmpty)
            {
                if (_mainFormData.ZAxisActive)
                {
                    SbZTitle.BackColor = SystemColors.Control;
                    SbZTitle.ForeColor = SystemColors.ControlText;
                    SbZ.BackColor = SystemColors.Control;
                    SbZ.ForeColor = SystemColors.ControlText;
                }
                else
                {
                    SbZTitle.BackColor = CommonStyle.BgDeviceInOperation;
                    SbZTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                    SbZ.BackColor = CommonStyle.BgDeviceInOperation;
                    SbZ.ForeColor = CommonStyle.FgDeviceInOperation;
                }
            }

            if (propertyName == nameof(MainFormData.ZAxisCoor) || isEmpty)
                SbZ.Text = _mainFormData.ZAxisCoor.ToString("F3");

            // R�b
            if (propertyName == nameof(MainFormData.RAxisActive) || isEmpty)
            {
                if (_mainFormData.RAxisActive)
                {
                    SbRTitle.BackColor = SystemColors.Control;
                    SbRTitle.ForeColor = SystemColors.ControlText;
                    SbR.BackColor = SystemColors.Control;
                    SbR.ForeColor = SystemColors.ControlText;
                }
                else
                {
                    SbRTitle.BackColor = CommonStyle.BgDeviceInOperation;
                    SbRTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                    SbR.BackColor = CommonStyle.BgDeviceInOperation;
                    SbR.ForeColor = CommonStyle.FgDeviceInOperation;
                }
            }

            if (propertyName == nameof(MainFormData.Angle) || isEmpty)
                SbR.Text = _mainFormData.Angle.ToString("F1");

            // ��O�p
            if (propertyName == nameof(MainFormData.TorqueActive) || isEmpty)
            {
                if (_mainFormData.TorqueActive)
                {
                    SbTorqueTitle.BackColor = SystemColors.Control;
                    SbTorqueTitle.ForeColor = SystemColors.ControlText;
                    SbTorque.BackColor = SystemColors.Control;
                    SbTorque.ForeColor = SystemColors.ControlText;
                }
                else
                {
                    SbTorqueTitle.BackColor = CommonStyle.BgDeviceInOperation;
                    SbTorqueTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                    SbTorque.BackColor = CommonStyle.BgDeviceInOperation;
                    SbTorque.ForeColor = CommonStyle.FgDeviceInOperation;
                }
            }

            if (propertyName == nameof(MainFormData.Torque) || isEmpty)
                SbTorque.Text = _mainFormData.Torque.ToString("F3");

            // LD_RS1A
            if (propertyName == nameof(MainFormData.LD_RS1A_Active) || isEmpty)
            {
                if (_mainFormData.LD_RS1A_Active)
                {
                    SbHeightTitle.BackColor = SystemColors.Control;
                    SbHeightTitle.ForeColor = SystemColors.ControlText;
                    SbHeight.BackColor = SystemColors.Control;
                    SbHeight.ForeColor = SystemColors.ControlText;
                }
                else
                {
                    SbHeightTitle.BackColor = CommonStyle.BgDeviceInOperation;
                    SbHeightTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                    SbHeight.BackColor = CommonStyle.BgDeviceInOperation;
                    SbHeight.ForeColor = CommonStyle.FgDeviceInOperation;
                }
            }

            if (propertyName == nameof(MainFormData.Height) || isEmpty)
                SbHeight.Text = _mainFormData.Height.ToString("F3");
        }

        #endregion Form Events

        #region Form Methods

        /// <summary>
        /// �վ�����j�p�C
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1024;
            const int TARGET_HEIGHT = 768;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        #endregion Form Methods

        #region Timer

        private void ClockTimer_Tick(object sender, EventArgs e)
        {
            SbClock.Text = DateTime.Now.ToString();
        }

        #endregion Timer

        #region Navigation

        /// <summary>
        /// �����ާ@�����C
        /// </summary>
        /// <param name="pageCode">�������ޡC</param>
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentPageCode == pageCode) return;

            switch (pageCode)
            {
                case PageCode.MainPage:
                    _nav.NavigateTo<MainPage>(nameof(ContentPanel), (int)PageCode.MainPage);
                    break;
                //case PageCode.WorkSetup:
                //    _nav.NavigateTo<WorkSetupPage>(nameof(ContainerPanel), (int)PageCode.WorkSetup);
                //    break;
                //case PageCode.Monitor:
                //    _nav.NavigateTo<MonitorPage>(nameof(ContainerPanel), (int)PageCode.Monitor);
                //    break;
                case PageCode.Setup:
                    _nav.NavigateTo<SetupPage>(nameof(ContentPanel), (int)PageCode.Setup);
                    break;
                default:
                    return;
            }
            _currentPageCode = pageCode;
        }

        private void MenuMain_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.MainPage);
        }

        private void MenuWorkSetup_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.WorkSetup);
        }

        private void MenuMonitor_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Monitor);
        }

        private void MenuSetup_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Setup);
        }

        #endregion Navigation
    }
}
