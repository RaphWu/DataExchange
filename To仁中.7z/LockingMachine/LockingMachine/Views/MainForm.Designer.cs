﻿namespace Calin.LockingMachine
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SbZTitle = new System.Windows.Forms.ToolStripStatusLabel();
            this.SbRTitle = new System.Windows.Forms.ToolStripStatusLabel();
            this.SbTorqueTitle = new System.Windows.Forms.ToolStripStatusLabel();
            this.SbHeightTitle = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.SbMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.SbZ = new System.Windows.Forms.ToolStripStatusLabel();
            this.SbR = new System.Windows.Forms.ToolStripStatusLabel();
            this.SbTorque = new System.Windows.Forms.ToolStripStatusLabel();
            this.SbHeight = new System.Windows.Forms.ToolStripStatusLabel();
            this.SbClock = new System.Windows.Forms.ToolStripStatusLabel();
            this.ClockTimer = new System.Windows.Forms.Timer(this.components);
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.ContentPanel = new System.Windows.Forms.Panel();
            this.MenuPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.MenuMain = new System.Windows.Forms.RadioButton();
            this.MenuProcessFlow = new System.Windows.Forms.RadioButton();
            this.MenuMonitor = new System.Windows.Forms.RadioButton();
            this.MenuSetup = new System.Windows.Forms.RadioButton();
            this.statusStrip.SuspendLayout();
            this.TLP.SuspendLayout();
            this.MenuPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // SbZTitle
            // 
            this.SbZTitle.AutoSize = false;
            this.SbZTitle.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbZTitle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbZTitle.Font = new System.Drawing.Font("Verdana", 9F);
            this.SbZTitle.Name = "SbZTitle";
            this.SbZTitle.Size = new System.Drawing.Size(25, 19);
            this.SbZTitle.Text = "Z:";
            this.SbZTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SbRTitle
            // 
            this.SbRTitle.AutoSize = false;
            this.SbRTitle.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbRTitle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbRTitle.Font = new System.Drawing.Font("Verdana", 9F);
            this.SbRTitle.Name = "SbRTitle";
            this.SbRTitle.Size = new System.Drawing.Size(25, 19);
            this.SbRTitle.Text = "R:";
            this.SbRTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SbTorqueTitle
            // 
            this.SbTorqueTitle.AutoSize = false;
            this.SbTorqueTitle.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbTorqueTitle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbTorqueTitle.Name = "SbTorqueTitle";
            this.SbTorqueTitle.Size = new System.Drawing.Size(40, 19);
            this.SbTorqueTitle.Text = "扭力:";
            // 
            // SbHeightTitle
            // 
            this.SbHeightTitle.AutoSize = false;
            this.SbHeightTitle.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbHeightTitle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbHeightTitle.Name = "SbHeightTitle";
            this.SbHeightTitle.Size = new System.Drawing.Size(40, 19);
            this.SbHeightTitle.Text = "高度:";
            this.SbHeightTitle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SbMessage,
            this.SbZTitle,
            this.SbZ,
            this.SbRTitle,
            this.SbR,
            this.SbTorqueTitle,
            this.SbTorque,
            this.SbHeightTitle,
            this.SbHeight,
            this.SbClock});
            this.statusStrip.Location = new System.Drawing.Point(0, 537);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1008, 24);
            this.statusStrip.TabIndex = 1;
            this.statusStrip.Text = "statusStrip1";
            // 
            // SbMessage
            // 
            this.SbMessage.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.SbMessage.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbMessage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbMessage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SbMessage.Name = "SbMessage";
            this.SbMessage.Size = new System.Drawing.Size(481, 19);
            this.SbMessage.Spring = true;
            // 
            // SbZ
            // 
            this.SbZ.AutoSize = false;
            this.SbZ.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.SbZ.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbZ.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbZ.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SbZ.Name = "SbZ";
            this.SbZ.Size = new System.Drawing.Size(68, 19);
            this.SbZ.Text = "888.888";
            // 
            // SbR
            // 
            this.SbR.AutoSize = false;
            this.SbR.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.SbR.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbR.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbR.Font = new System.Drawing.Font("Verdana", 9F);
            this.SbR.Name = "SbR";
            this.SbR.Size = new System.Drawing.Size(52, 19);
            this.SbR.Text = "888.8";
            // 
            // SbTorque
            // 
            this.SbTorque.AutoSize = false;
            this.SbTorque.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.SbTorque.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbTorque.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbTorque.Font = new System.Drawing.Font("Verdana", 9F);
            this.SbTorque.Name = "SbTorque";
            this.SbTorque.Size = new System.Drawing.Size(62, 19);
            this.SbTorque.Text = "888.88";
            // 
            // SbHeight
            // 
            this.SbHeight.AutoSize = false;
            this.SbHeight.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right;
            this.SbHeight.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbHeight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbHeight.Font = new System.Drawing.Font("Verdana", 9F);
            this.SbHeight.Name = "SbHeight";
            this.SbHeight.Size = new System.Drawing.Size(60, 19);
            this.SbHeight.Text = "88.888";
            // 
            // SbClock
            // 
            this.SbClock.AutoSize = false;
            this.SbClock.BorderStyle = System.Windows.Forms.Border3DStyle.Etched;
            this.SbClock.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.SbClock.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SbClock.Name = "SbClock";
            this.SbClock.Size = new System.Drawing.Size(140, 19);
            this.SbClock.Text = "8888/88/88 88:88:88";
            // 
            // ClockTimer
            // 
            this.ClockTimer.Enabled = true;
            this.ClockTimer.Interval = 250;
            this.ClockTimer.Tick += new System.EventHandler(this.ClockTimer_Tick);
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 1;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.ContentPanel, 0, 1);
            this.TLP.Controls.Add(this.MenuPanel, 0, 0);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 2;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Size = new System.Drawing.Size(1008, 537);
            this.TLP.TabIndex = 2;
            // 
            // ContentPanel
            // 
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(3, 32);
            this.ContentPanel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.Size = new System.Drawing.Size(1002, 505);
            this.ContentPanel.TabIndex = 0;
            // 
            // MenuPanel
            // 
            this.MenuPanel.Controls.Add(this.MenuMain);
            this.MenuPanel.Controls.Add(this.MenuProcessFlow);
            this.MenuPanel.Controls.Add(this.MenuMonitor);
            this.MenuPanel.Controls.Add(this.MenuSetup);
            this.MenuPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MenuPanel.Location = new System.Drawing.Point(3, 0);
            this.MenuPanel.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.MenuPanel.Name = "MenuPanel";
            this.MenuPanel.Padding = new System.Windows.Forms.Padding(15, 3, 0, 0);
            this.MenuPanel.Size = new System.Drawing.Size(1002, 32);
            this.MenuPanel.TabIndex = 1;
            // 
            // MenuMain
            // 
            this.MenuMain.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuMain.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuMain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.MenuMain.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuMain.Location = new System.Drawing.Point(15, 3);
            this.MenuMain.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.MenuMain.Name = "MenuMain";
            this.MenuMain.Size = new System.Drawing.Size(80, 26);
            this.MenuMain.TabIndex = 2;
            this.MenuMain.TabStop = true;
            this.MenuMain.Text = "主控頁";
            this.MenuMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuMain.UseVisualStyleBackColor = true;
            this.MenuMain.Click += new System.EventHandler(this.MenuMain_Click);
            // 
            // MenuProcessFlow
            // 
            this.MenuProcessFlow.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuProcessFlow.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuProcessFlow.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.MenuProcessFlow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuProcessFlow.Location = new System.Drawing.Point(104, 3);
            this.MenuProcessFlow.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.MenuProcessFlow.Name = "MenuProcessFlow";
            this.MenuProcessFlow.Size = new System.Drawing.Size(80, 26);
            this.MenuProcessFlow.TabIndex = 3;
            this.MenuProcessFlow.TabStop = true;
            this.MenuProcessFlow.Text = "工序編輯";
            this.MenuProcessFlow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuProcessFlow.UseVisualStyleBackColor = true;
            this.MenuProcessFlow.Click += new System.EventHandler(this.MenuWorkSetup_Click);
            // 
            // MenuMonitor
            // 
            this.MenuMonitor.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuMonitor.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuMonitor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.MenuMonitor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuMonitor.Location = new System.Drawing.Point(193, 3);
            this.MenuMonitor.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.MenuMonitor.Name = "MenuMonitor";
            this.MenuMonitor.Size = new System.Drawing.Size(80, 26);
            this.MenuMonitor.TabIndex = 4;
            this.MenuMonitor.TabStop = true;
            this.MenuMonitor.Text = "即時監控";
            this.MenuMonitor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuMonitor.UseVisualStyleBackColor = true;
            this.MenuMonitor.Click += new System.EventHandler(this.MenuMonitor_Click);
            // 
            // MenuSetup
            // 
            this.MenuSetup.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuSetup.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuSetup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Moccasin;
            this.MenuSetup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuSetup.Location = new System.Drawing.Point(282, 3);
            this.MenuSetup.Margin = new System.Windows.Forms.Padding(0, 0, 9, 0);
            this.MenuSetup.Name = "MenuSetup";
            this.MenuSetup.Size = new System.Drawing.Size(80, 26);
            this.MenuSetup.TabIndex = 5;
            this.MenuSetup.TabStop = true;
            this.MenuSetup.Text = "設定";
            this.MenuSetup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuSetup.UseVisualStyleBackColor = true;
            this.MenuSetup.Click += new System.EventHandler(this.MenuSetup_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 561);
            this.Controls.Add(this.TLP);
            this.Controls.Add(this.statusStrip);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Locking Machine";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.TLP.ResumeLayout(false);
            this.MenuPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StatusStrip statusStrip;
        private ToolStripStatusLabel SbZ;
        private ToolStripStatusLabel SbClock;
        private System.Windows.Forms.Timer ClockTimer;
        private TableLayoutPanel TLP;
        private Panel ContentPanel;
        private FlowLayoutPanel MenuPanel;
        private RadioButton MenuMain;
        private RadioButton MenuProcessFlow;
        private RadioButton MenuMonitor;
        private RadioButton MenuSetup;
        private ToolStripStatusLabel SbR;
        private ToolStripStatusLabel SbTorque;
        private ToolStripStatusLabel SbHeight;
        private ToolStripStatusLabel SbMessage;
        private ToolStripStatusLabel SbZTitle;
        private ToolStripStatusLabel SbRTitle;
        private ToolStripStatusLabel SbTorqueTitle;
        private ToolStripStatusLabel SbHeightTitle;
    }
}
