﻿namespace Calin.LockingMachine.Views
{
    partial class SetupPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.TcSetup = new System.Windows.Forms.TabControl();
            this.Tp1220U = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.VelSetupPanel = new System.Windows.Forms.GroupBox();
            this.NumVelL = new System.Windows.Forms.NumericUpDown();
            this.NumVelH = new System.Windows.Forms.NumericUpDown();
            this.NumAcc = new System.Windows.Forms.NumericUpDown();
            this.NumDec = new System.Windows.Forms.NumericUpDown();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.RbTCurver = new System.Windows.Forms.RadioButton();
            this.RbSCurver = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.TpIo = new System.Windows.Forms.TabPage();
            this.Gb_Dlrs1a = new System.Windows.Forms.GroupBox();
            this.CbDlrs1aDataBits = new System.Windows.Forms.ComboBox();
            this.BtnUpdatePortNames = new System.Windows.Forms.Button();
            this.label_StopBits = new System.Windows.Forms.Label();
            this.CbDlrs1aStopBits = new System.Windows.Forms.ComboBox();
            this.label_DataBits = new System.Windows.Forms.Label();
            this.label_Parity = new System.Windows.Forms.Label();
            this.CbDlrs1aParity = new System.Windows.Forms.ComboBox();
            this.label_BaudRate = new System.Windows.Forms.Label();
            this.CbDlrs1aBaudRate = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.CbDlrs1aCom = new System.Windows.Forms.ComboBox();
            this.BtnDlrs1aReconnect = new System.Windows.Forms.Button();
            this.TcSetup.SuspendLayout();
            this.Tp1220U.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.VelSetupPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.TpIo.SuspendLayout();
            this.Gb_Dlrs1a.SuspendLayout();
            this.SuspendLayout();
            // 
            // TcSetup
            // 
            this.TcSetup.Controls.Add(this.Tp1220U);
            this.TcSetup.Controls.Add(this.TpIo);
            this.TcSetup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TcSetup.Location = new System.Drawing.Point(0, 0);
            this.TcSetup.Margin = new System.Windows.Forms.Padding(4);
            this.TcSetup.Name = "TcSetup";
            this.TcSetup.SelectedIndex = 0;
            this.TcSetup.Size = new System.Drawing.Size(1000, 650);
            this.TcSetup.TabIndex = 50;
            // 
            // Tp1220U
            // 
            this.Tp1220U.Controls.Add(this.groupBox1);
            this.Tp1220U.Controls.Add(this.VelSetupPanel);
            this.Tp1220U.Location = new System.Drawing.Point(4, 25);
            this.Tp1220U.Margin = new System.Windows.Forms.Padding(4);
            this.Tp1220U.Name = "Tp1220U";
            this.Tp1220U.Padding = new System.Windows.Forms.Padding(4);
            this.Tp1220U.Size = new System.Drawing.Size(992, 621);
            this.Tp1220U.TabIndex = 0;
            this.Tp1220U.Text = "運動軸卡";
            this.Tp1220U.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.numericUpDown2);
            this.groupBox1.Controls.Add(this.numericUpDown3);
            this.groupBox1.Controls.Add(this.numericUpDown4);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(252, 109);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(181, 216);
            this.groupBox1.TabIndex = 54;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "轉動軸速率設定 (PPU/sec)";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(72, 26);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown1.TabIndex = 43;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(72, 57);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown2.TabIndex = 42;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown2.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(72, 88);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown3.TabIndex = 41;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown3.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown4.Location = new System.Drawing.Point(72, 117);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(100, 23);
            this.numericUpDown4.TabIndex = 40;
            this.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown4.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Location = new System.Drawing.Point(8, 150);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(164, 53);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "速度曲線類型";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(10, 23);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(68, 20);
            this.radioButton1.TabIndex = 35;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "T型曲線";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(88, 23);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(4);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(68, 20);
            this.radioButton2.TabIndex = 36;
            this.radioButton2.Text = "S型曲線";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 121);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "減速度";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 90);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 30;
            this.label2.Text = "加速度";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 59);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "運轉速度";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 28);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 26;
            this.label4.Text = "起始速度";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // VelSetupPanel
            // 
            this.VelSetupPanel.Controls.Add(this.NumVelL);
            this.VelSetupPanel.Controls.Add(this.NumVelH);
            this.VelSetupPanel.Controls.Add(this.NumAcc);
            this.VelSetupPanel.Controls.Add(this.NumDec);
            this.VelSetupPanel.Controls.Add(this.groupBox11);
            this.VelSetupPanel.Controls.Add(this.label16);
            this.VelSetupPanel.Controls.Add(this.label17);
            this.VelSetupPanel.Controls.Add(this.label18);
            this.VelSetupPanel.Controls.Add(this.label19);
            this.VelSetupPanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.VelSetupPanel.Location = new System.Drawing.Point(63, 109);
            this.VelSetupPanel.Margin = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Name = "VelSetupPanel";
            this.VelSetupPanel.Padding = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Size = new System.Drawing.Size(181, 216);
            this.VelSetupPanel.TabIndex = 53;
            this.VelSetupPanel.TabStop = false;
            this.VelSetupPanel.Text = "旋入軸速率設定 (PPU/sec)";
            // 
            // NumVelL
            // 
            this.NumVelL.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelL.Location = new System.Drawing.Point(72, 26);
            this.NumVelL.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelL.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelL.Name = "NumVelL";
            this.NumVelL.Size = new System.Drawing.Size(100, 23);
            this.NumVelL.TabIndex = 43;
            this.NumVelL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelL.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // NumVelH
            // 
            this.NumVelH.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelH.Location = new System.Drawing.Point(72, 57);
            this.NumVelH.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelH.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelH.Name = "NumVelH";
            this.NumVelH.Size = new System.Drawing.Size(100, 23);
            this.NumVelH.TabIndex = 42;
            this.NumVelH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelH.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // NumAcc
            // 
            this.NumAcc.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumAcc.Location = new System.Drawing.Point(72, 88);
            this.NumAcc.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumAcc.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumAcc.Name = "NumAcc";
            this.NumAcc.Size = new System.Drawing.Size(100, 23);
            this.NumAcc.TabIndex = 41;
            this.NumAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumAcc.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // NumDec
            // 
            this.NumDec.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumDec.Location = new System.Drawing.Point(72, 117);
            this.NumDec.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumDec.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumDec.Name = "NumDec";
            this.NumDec.Size = new System.Drawing.Size(100, 23);
            this.NumDec.TabIndex = 40;
            this.NumDec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumDec.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.RbTCurver);
            this.groupBox11.Controls.Add(this.RbSCurver);
            this.groupBox11.Location = new System.Drawing.Point(8, 150);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(164, 53);
            this.groupBox11.TabIndex = 37;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "速度曲線類型";
            // 
            // RbTCurver
            // 
            this.RbTCurver.AutoSize = true;
            this.RbTCurver.Checked = true;
            this.RbTCurver.Location = new System.Drawing.Point(10, 23);
            this.RbTCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbTCurver.Name = "RbTCurver";
            this.RbTCurver.Size = new System.Drawing.Size(68, 20);
            this.RbTCurver.TabIndex = 35;
            this.RbTCurver.TabStop = true;
            this.RbTCurver.Text = "T型曲線";
            this.RbTCurver.UseVisualStyleBackColor = true;
            // 
            // RbSCurver
            // 
            this.RbSCurver.AutoSize = true;
            this.RbSCurver.Location = new System.Drawing.Point(88, 23);
            this.RbSCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbSCurver.Name = "RbSCurver";
            this.RbSCurver.Size = new System.Drawing.Size(68, 20);
            this.RbSCurver.TabIndex = 36;
            this.RbSCurver.Text = "S型曲線";
            this.RbSCurver.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(20, 121);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 32;
            this.label16.Text = "減速度";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 90);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 16);
            this.label17.TabIndex = 30;
            this.label17.Text = "加速度";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 59);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 16);
            this.label18.TabIndex = 28;
            this.label18.Text = "運轉速度";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 28);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 16);
            this.label19.TabIndex = 26;
            this.label19.Text = "起始速度";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TpIo
            // 
            this.TpIo.Controls.Add(this.Gb_Dlrs1a);
            this.TpIo.Location = new System.Drawing.Point(4, 25);
            this.TpIo.Margin = new System.Windows.Forms.Padding(4);
            this.TpIo.Name = "TpIo";
            this.TpIo.Padding = new System.Windows.Forms.Padding(4);
            this.TpIo.Size = new System.Drawing.Size(992, 621);
            this.TpIo.TabIndex = 1;
            this.TpIo.Text = "IO";
            this.TpIo.UseVisualStyleBackColor = true;
            // 
            // Gb_Dlrs1a
            // 
            this.Gb_Dlrs1a.Controls.Add(this.BtnDlrs1aReconnect);
            this.Gb_Dlrs1a.Controls.Add(this.CbDlrs1aDataBits);
            this.Gb_Dlrs1a.Controls.Add(this.BtnUpdatePortNames);
            this.Gb_Dlrs1a.Controls.Add(this.label_StopBits);
            this.Gb_Dlrs1a.Controls.Add(this.CbDlrs1aStopBits);
            this.Gb_Dlrs1a.Controls.Add(this.label_DataBits);
            this.Gb_Dlrs1a.Controls.Add(this.label_Parity);
            this.Gb_Dlrs1a.Controls.Add(this.CbDlrs1aParity);
            this.Gb_Dlrs1a.Controls.Add(this.label_BaudRate);
            this.Gb_Dlrs1a.Controls.Add(this.CbDlrs1aBaudRate);
            this.Gb_Dlrs1a.Controls.Add(this.label9);
            this.Gb_Dlrs1a.Controls.Add(this.CbDlrs1aCom);
            this.Gb_Dlrs1a.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Gb_Dlrs1a.Location = new System.Drawing.Point(21, 17);
            this.Gb_Dlrs1a.Name = "Gb_Dlrs1a";
            this.Gb_Dlrs1a.Size = new System.Drawing.Size(173, 281);
            this.Gb_Dlrs1a.TabIndex = 77;
            this.Gb_Dlrs1a.TabStop = false;
            this.Gb_Dlrs1a.Text = "高度計參數設定";
            // 
            // CbDlrs1aDataBits
            // 
            this.CbDlrs1aDataBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbDlrs1aDataBits.FormattingEnabled = true;
            this.CbDlrs1aDataBits.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbDlrs1aDataBits.Location = new System.Drawing.Point(76, 116);
            this.CbDlrs1aDataBits.Name = "CbDlrs1aDataBits";
            this.CbDlrs1aDataBits.Size = new System.Drawing.Size(82, 25);
            this.CbDlrs1aDataBits.TabIndex = 158;
            this.CbDlrs1aDataBits.SelectedIndexChanged += new System.EventHandler(this.CbDlrs1aDataBits_SelectedIndexChanged);
            // 
            // BtnUpdatePortNames
            // 
            this.BtnUpdatePortNames.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnUpdatePortNames.Location = new System.Drawing.Point(13, 230);
            this.BtnUpdatePortNames.Name = "BtnUpdatePortNames";
            this.BtnUpdatePortNames.Size = new System.Drawing.Size(145, 31);
            this.BtnUpdatePortNames.TabIndex = 157;
            this.BtnUpdatePortNames.Text = "更新埠列表";
            this.BtnUpdatePortNames.UseVisualStyleBackColor = true;
            this.BtnUpdatePortNames.Click += new System.EventHandler(this.BtnUpdatePortNames_Click);
            // 
            // label_StopBits
            // 
            this.label_StopBits.AutoSize = true;
            this.label_StopBits.Location = new System.Drawing.Point(10, 150);
            this.label_StopBits.Name = "label_StopBits";
            this.label_StopBits.Size = new System.Drawing.Size(63, 17);
            this.label_StopBits.TabIndex = 156;
            this.label_StopBits.Text = "停止位元:";
            this.label_StopBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CbDlrs1aStopBits
            // 
            this.CbDlrs1aStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbDlrs1aStopBits.FormattingEnabled = true;
            this.CbDlrs1aStopBits.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbDlrs1aStopBits.Location = new System.Drawing.Point(76, 147);
            this.CbDlrs1aStopBits.Name = "CbDlrs1aStopBits";
            this.CbDlrs1aStopBits.Size = new System.Drawing.Size(82, 25);
            this.CbDlrs1aStopBits.TabIndex = 155;
            this.CbDlrs1aStopBits.SelectedIndexChanged += new System.EventHandler(this.CbDlrs1aStopBits_SelectedIndexChanged);
            // 
            // label_DataBits
            // 
            this.label_DataBits.AutoSize = true;
            this.label_DataBits.Location = new System.Drawing.Point(10, 119);
            this.label_DataBits.Name = "label_DataBits";
            this.label_DataBits.Size = new System.Drawing.Size(63, 17);
            this.label_DataBits.TabIndex = 154;
            this.label_DataBits.Text = "資料位元:";
            this.label_DataBits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Parity
            // 
            this.label_Parity.AutoSize = true;
            this.label_Parity.Location = new System.Drawing.Point(10, 88);
            this.label_Parity.Name = "label_Parity";
            this.label_Parity.Size = new System.Drawing.Size(63, 17);
            this.label_Parity.TabIndex = 152;
            this.label_Parity.Text = "同位位元:";
            this.label_Parity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CbDlrs1aParity
            // 
            this.CbDlrs1aParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbDlrs1aParity.FormattingEnabled = true;
            this.CbDlrs1aParity.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbDlrs1aParity.Location = new System.Drawing.Point(76, 85);
            this.CbDlrs1aParity.Name = "CbDlrs1aParity";
            this.CbDlrs1aParity.Size = new System.Drawing.Size(82, 25);
            this.CbDlrs1aParity.TabIndex = 151;
            this.CbDlrs1aParity.SelectedIndexChanged += new System.EventHandler(this.CbDlrs1aParity_SelectedIndexChanged);
            // 
            // label_BaudRate
            // 
            this.label_BaudRate.AutoSize = true;
            this.label_BaudRate.Location = new System.Drawing.Point(35, 57);
            this.label_BaudRate.Name = "label_BaudRate";
            this.label_BaudRate.Size = new System.Drawing.Size(37, 17);
            this.label_BaudRate.TabIndex = 150;
            this.label_BaudRate.Text = "鮑率:";
            this.label_BaudRate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CbDlrs1aBaudRate
            // 
            this.CbDlrs1aBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbDlrs1aBaudRate.FormattingEnabled = true;
            this.CbDlrs1aBaudRate.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbDlrs1aBaudRate.Location = new System.Drawing.Point(76, 54);
            this.CbDlrs1aBaudRate.Name = "CbDlrs1aBaudRate";
            this.CbDlrs1aBaudRate.Size = new System.Drawing.Size(82, 25);
            this.CbDlrs1aBaudRate.TabIndex = 149;
            this.CbDlrs1aBaudRate.SelectedIndexChanged += new System.EventHandler(this.CbDlrs1aBaudRate_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(35, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 17);
            this.label9.TabIndex = 148;
            this.label9.Text = "Port:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CbDlrs1aCom
            // 
            this.CbDlrs1aCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbDlrs1aCom.FormattingEnabled = true;
            this.CbDlrs1aCom.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.CbDlrs1aCom.Location = new System.Drawing.Point(76, 23);
            this.CbDlrs1aCom.Name = "CbDlrs1aCom";
            this.CbDlrs1aCom.Size = new System.Drawing.Size(82, 25);
            this.CbDlrs1aCom.TabIndex = 145;
            this.CbDlrs1aCom.SelectedIndexChanged += new System.EventHandler(this.CbDlrs1aCom_SelectedIndexChanged);
            // 
            // BtnDlrs1aReconnect
            // 
            this.BtnDlrs1aReconnect.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BtnDlrs1aReconnect.Location = new System.Drawing.Point(13, 181);
            this.BtnDlrs1aReconnect.Name = "BtnDlrs1aReconnect";
            this.BtnDlrs1aReconnect.Size = new System.Drawing.Size(145, 31);
            this.BtnDlrs1aReconnect.TabIndex = 159;
            this.BtnDlrs1aReconnect.Text = "重新連接";
            this.BtnDlrs1aReconnect.UseVisualStyleBackColor = true;
            this.BtnDlrs1aReconnect.Click += new System.EventHandler(this.BtnDlrs1aReconnect_Click);
            // 
            // SetupPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.TcSetup);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "SetupPage";
            this.Size = new System.Drawing.Size(1000, 650);
            this.TcSetup.ResumeLayout(false);
            this.Tp1220U.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.VelSetupPanel.ResumeLayout(false);
            this.VelSetupPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.TpIo.ResumeLayout(false);
            this.Gb_Dlrs1a.ResumeLayout(false);
            this.Gb_Dlrs1a.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl TcSetup;
        private TabPage Tp1220U;
        private GroupBox groupBox1;
        private NumericUpDown numericUpDown1;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown4;
        private GroupBox groupBox2;
        public RadioButton radioButton1;
        public RadioButton radioButton2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private GroupBox VelSetupPanel;
        private NumericUpDown NumVelL;
        private NumericUpDown NumVelH;
        private NumericUpDown NumAcc;
        private NumericUpDown NumDec;
        private GroupBox groupBox11;
        public RadioButton RbTCurver;
        public RadioButton RbSCurver;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private TabPage TpIo;
        private GroupBox Gb_Dlrs1a;
        private ComboBox CbDlrs1aDataBits;
        private Button BtnUpdatePortNames;
        private Label label_StopBits;
        private ComboBox CbDlrs1aStopBits;
        private Label label_DataBits;
        private Label label_Parity;
        private ComboBox CbDlrs1aParity;
        private Label label_BaudRate;
        private ComboBox CbDlrs1aBaudRate;
        private Label label9;
        private ComboBox CbDlrs1aCom;
        private Button BtnDlrs1aReconnect;
    }
}
