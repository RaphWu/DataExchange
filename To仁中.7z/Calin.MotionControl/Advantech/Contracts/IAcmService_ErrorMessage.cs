﻿using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Contracts
{
	/// <summary>
	/// Acm 錯誤訊息服務介面。
	/// </summary>
	public interface IAcmService_ErrorMessage
	{
		/// <summary>
		/// 清除錯誤訊息。
		/// </summary>
		void ClearErrMessage();

		/// <summary>
		/// 取得目前的錯誤訊息。
		/// </summary>
		ErrMessage ErrMessage { get; }


		/// <summary>
		/// 取得錯誤訊息表。
		/// </summary>
		/// <param name="code">錯誤代碼。</param>
		/// <returns>錯誤訊息表。</returns>
		ErrMessage GetErrMessage(int code);
	}
}
