﻿
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// 設備操作服務介面。
    /// </summary>
    public interface IAcmService_Device
    {
        /********************
         * 通用
         ********************/
        /// <summary>
        /// 取得已成功載入驅動裝置的裝置編號和名稱列表。
        /// </summary>
        /// <returns>錯誤代碼。</returns>
        int GetAvailableDevs();

        /// <summary>
        /// 取得闆卡設備號。
        /// </summary>
        /// <returns>錯誤代碼。</returns>
        int GetDevNum();

        /// <summary>
        /// 根據 API 傳回的錯誤代碼，取得錯誤訊息。
        /// </summary>
        /// <returns>錯誤代碼。</returns>
        int GetErrorMessage();

        /********************
         * 設備
         ********************/
        /// <summary>
        /// 關閉設備。
        /// </summary>
        /// <param name="DeviceHandle"></param>
        /// <returns>錯誤代碼。</returns>
        int DevClose(PHAND DeviceHandle);

        /// <summary>
        /// 開啟一個指定裝置以取得裝置句柄。
        /// </summary>
        /// <param name="DeviceNumber"></param>
        /// <param name="DeviceHandle"></param>
        /// <returns>錯誤代碼。</returns>
        int DeviceOpen(int DeviceNumber, PHAND DeviceHandle);

        /// <summary>
        /// 重新開啟裝置。
        /// </summary>
        /// <param name="DeviceHandle"></param>
        /// <returns>錯誤代碼。</returns>
        int DevReOpen(HAND DeviceHandle);

        /// <summary>
        /// 開啟一個指定裝置以取得裝置句柄。
        /// </summary>
        /// <returns>錯誤代碼。</returns>
        int DevReOpen(HAND DeviceHandle);

        /// <summary>
        /// 取得所需資料型別為無符號 32 位元整數的屬性值。
        /// </summary>
        /// <param name="Handle"></param>
        /// <param name="ProperyID"></param>
        /// <param name="Value"></param>
        /// <returns>錯誤代碼。</returns>
        int GetU32Property(HAND Handle, int ProperyID, PU32 Value);

        /// <summary>
        /// 取得所需資料型別為有符號 32 位元整數的屬性值。
        /// </summary>
        /// <param name="Handle"></param>
        /// <param name="ProperyID"></param>
        /// <param name="Value"></param>
        /// <returns>錯誤代碼。</returns>
        int GetI32Property(HAND Handle, int ProperyID, PI32 Value);

        /// <summary>
        /// 取得所需資料型態為浮點型的屬性值。
        /// </summary>
        /// <param name="Handle"></param>
        /// <param name="ProperyID"></param>
        /// <param name="Value"></param>
        /// <returns>錯誤代碼。</returns>
        int GetF64Property(HAND Handle, int ProperyID, PF64 Value);

        /// <summary>
        /// 透過指派的PropertyID 設定屬性（特性屬性、配置屬性或參數屬性）。
        /// </summary>
        /// <param name="Handle"></param>
        /// <param name="PropertyID"></param>
        /// <param name="Buffer"></param>
        /// <param name="BufferLength"></param>
        /// <returns>錯誤代碼。</returns>
        int SetProperty(HAND Handle, int PropertyID, PVOID Buffer, int BufferLength);

        /// <summary>
        /// 設定屬性值為無符號 32 位元整數的屬性。
        /// </summary>
        /// <param name="Handle"></param>
        /// <param name="ProperyID"></param>
        /// <param name="Value"></param>
        /// <returns>錯誤代碼。</returns>
        int SeU32tProperty(HAND Handle, int ProperyID, int Value);

        /// <summary>
        /// 設定屬性值為有符號 32 位元整數的屬性。
        /// </summary>
        /// <param name="Handle"></param>
        /// <param name="ProperyID"></param>
        /// <param name="Value"></param>
        /// <returns>錯誤代碼。</returns>
        int SeI32tProperty(HAND Handle, int ProperyID, I32 Value);

        /// <summary>
        /// 設定屬性值為浮點型的屬性。
        /// </summary>
        /// <param name="Handle"></param>
        /// <param name="ProperyID"></param>
        /// <param name="Value"></param>
        /// <returns>錯誤代碼。</returns>
        int SeF64tProperty(HAND Handle, int ProperyID, F64 Value);
    }
}
