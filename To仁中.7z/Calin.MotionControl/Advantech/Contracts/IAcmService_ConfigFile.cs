﻿namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// Acm 設定檔服務介面。
    /// </summary>
    public interface IAcmService_ConfigFile
    {
    }
}
