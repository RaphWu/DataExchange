﻿namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// Acm 服務介面。
    /// </summary>
    public interface IAcm :
        IAcmService_Device, IAcmService_Axis, IAcmService_Group,
        IAcmService_ErrManager
    {
    }
}
