﻿namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// 軸操作服務介面。
    /// </summary>
    public interface IAcmService_Axis
    {
    }
}
