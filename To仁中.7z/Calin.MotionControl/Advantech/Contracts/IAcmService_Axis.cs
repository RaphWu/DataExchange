﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.MC.Advantech.Contracts
{
    /// <summary>
    /// 軸操作服務介面。
    /// </summary>
    public interface IAcmService_Axis
    {
    }
}
