﻿using System.Threading;
using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    // 循環操作
    public partial class AcmService : IAcmService_Polling
    {
        private Thread _pollingThread;
        private CancellationTokenSource _pollingCts;

        public void PollingStart()
        {
            _pollingCts = new CancellationTokenSource();

            _pollingThread = new Thread(() => ListenerProc(_pollingCts.Token));
            _pollingThread.IsBackground = true;
            _pollingThread.Priority = ThreadPriority.Highest;
            _pollingThread.Start();
        }

        public void PollingStop()
        {
            _pollingCts?.Cancel();
        }

        private void ListenerProc(CancellationToken token)
        {
            //var sw = Stopwatch.StartNew();
            //long ticksPerMs = Stopwatch.Frequency / 1000;
            //long nextTick = sw.ElapsedTicks;

            //while (!token.IsCancellationRequested)
            //{
            //    long now = sw.ElapsedTicks;

            //    if (now >= nextTick)
            //    {
            //        nextTick += ticksPerMs;

            //        double torque = ReadTorqueFromDevice();

            //        _snapshot.CurrentTorque = torque;
            //        _snapshot.TimestampTicks = now;

            //        if (torque >= TorqueLimit)
            //        {
            //            _snapshot.IsOverLimit = true;
            //            EmergencyStop();
            //        }
            //    }
            //    else
            //    {
            //        Thread.SpinWait(20);
            //    }
            //}
        }

        private void EmergencyStop()
        {
            // 只做停機，不寫 log，不更新 UI
        }
    }
}
