﻿using System;
using System.Diagnostics;
using System.Threading;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    /// <summary>
    /// 當軸狀態有更新時，供事件傳遞狀態使用。
    /// </summary>
    public sealed class AcmStatusUpdatedEventArgs : EventArgs
    {
        /// <summary>
        /// 軸編號。
        /// </summary>
        public int AxisNo { get; }

        /// <summary>
        /// 軸狀態。
        /// </summary>
        public ParsedAxisState AxisState { get; }

        public AcmStatusUpdatedEventArgs(int axisNo, ParsedAxisState axisState)
        {
            AxisNo = axisNo;
            AxisState = axisState;
        }
    }

    // 控制卡狀態讀取/更新服務。
    public partial class AcmService : IAcmService_Polling
    {
        #region Fields

        private Thread _monitoringThread;
        private Thread _parseThread;
        private CancellationTokenSource _pollingCts;

        #endregion Fields

        #region Properties

        public event EventHandler<AcmStatusUpdatedEventArgs>? AcmStatusUpdated;

        #endregion Properties

        #region Methods

        /// <inheritdoc/>
        public void PollingStop()
        {
            _pollingCts?.Cancel();
        }

        /// <inheritdoc/>
        public void PollingStart()
        {
            _pollingCts = new CancellationTokenSource();

            _monitoringThread = new Thread(() => MonitoringProc(_pollingCts.Token));
            _monitoringThread.IsBackground = true;
            _monitoringThread.Priority = ThreadPriority.Highest;
            _monitoringThread.Start();

            _parseThread = new Thread(() => ParseProc(_pollingCts.Token));
            _parseThread.IsBackground = true;
            _parseThread.Priority = ThreadPriority.Normal;
            _parseThread.Start();
        }

        #endregion Methods

        #region Polling Procedures

        private void MonitoringProc(CancellationToken token)
        {
            var sw = Stopwatch.StartNew();
            long ticksPerMs = Stopwatch.Frequency / 1000;
            long nextTick = sw.ElapsedTicks;
            var spin = new SpinWait();

            while (!token.IsCancellationRequested)
            {
                long now = sw.ElapsedTicks;
                if (now >= nextTick)
                {
                    nextTick += ticksPerMs;
                    spin.Reset();

                    for (int axisNo = 0; axisNo < m_AxisCount; axisNo++)
                    {
                        double cmdPos = default;
                        ErrCode = Motion.mAcm_AxGetCmdPosition(m_AxisHandles[axisNo], ref cmdPos);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MonitoringProc)}", $"無法取得軸 {axisNo + 1} 的命令位置！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }

                        double actPos = default;
                        ErrCode = Motion.mAcm_AxGetActualPosition(m_AxisHandles[axisNo], ref actPos);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MonitoringProc)}", $"無法取得軸 {axisNo + 1} 的實際位置！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }

                        // 軸IO狀態
                        ushort acmAxisState = default;
                        ErrCode = Motion.mAcm_AxGetState(m_AxisHandles[axisNo], ref acmAxisState);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MonitoringProc)}", $"無法取得軸 {axisNo + 1} 的狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }

                        // 軸運動狀態
                        uint acmMotionStatus = default;
                        ErrCode = Motion.mAcm_AxGetMotionStatus(m_AxisHandles[axisNo], ref acmMotionStatus);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MonitoringProc)}", $"無法取得軸 {axisNo + 1} 的運動狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }

                        // 軸IO狀態
                        uint acmIoStatus = default;
                        ErrCode = Motion.mAcm_AxGetMotionIO(m_AxisHandles[axisNo], ref acmIoStatus);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MonitoringProc)}", $"無法取得軸 {axisNo + 1} 的 I/O 狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }

                        var axisState = _rawAxisStates[axisNo];
                        axisState.CmdPosition = cmdPos;
                        axisState.ActPosition = actPos;
                        axisState.AxisState = (AxisState)acmAxisState;
                        axisState.MotionStatus = acmMotionStatus;
                        axisState.IoStatus = acmIoStatus;
                        _rawAxisStates[axisNo] = axisState;
                    }

                    // 用於須快速反應的停止條件
                    //if (torque >= TorqueLimit)
                    //{
                    //    EmergencyStop();
                    //}
                }
                else
                {
                    spin.SpinOnce();
                }
            }
        }

        /// <summary>
        /// 解析程序。
        /// </summary>
        private void ParseProc(CancellationToken token)
        {
            int axisNo = 0;
            while (!token.IsCancellationRequested)
            {
                var parsedState = _parsedAxisStates[axisNo];

                parsedState.CmdPosition = _rawAxisStates[axisNo].CmdPosition;
                parsedState.ActPosition = _rawAxisStates[axisNo].ActPosition;

                // 軸狀態
                parsedState.StateFlags = (StateFlags)(int)_rawAxisStates[axisNo].AxisState;

                // 軸運動狀態
                parsedState.MotionFlags = (MotionFlags)(_rawAxisStates[axisNo].MotionStatus & (uint)(
                    MotionFlags.Stop |
                    MotionFlags.WaitERC |
                    MotionFlags.CorrectBksh |
                    MotionFlags.InFA |
                    MotionFlags.InFL |
                    MotionFlags.InACC |
                    MotionFlags.InFH |
                    MotionFlags.InDEC |
                    MotionFlags.WaitINP));

                // 軸IO
                parsedState.IoFlags = (IoFlags)(_rawAxisStates[axisNo].IoStatus & (uint)(
                    IoFlags.RDY |
                    IoFlags.ALM |
                    IoFlags.LMT_Positive |
                    IoFlags.LMT_Negative |
                    IoFlags.ORG |
                    IoFlags.DIR |
                    IoFlags.EMG |
                    IoFlags.PCS |
                    IoFlags.ERC |
                    IoFlags.EZ |
                    IoFlags.CLR |
                    IoFlags.LTC |
                    IoFlags.SD |
                    IoFlags.INP |
                    IoFlags.SVON |
                    IoFlags.ALRM |
                    IoFlags.SLMT_Positive |
                    IoFlags.SLMT_Negative |
                    IoFlags.CMP |
                    IoFlags.CAMDO));

                if (_parsedAxisStates[axisNo] != parsedState)
                {
                    _parsedAxisStates[axisNo] = parsedState;
                    AcmStatusUpdated?.Invoke(this, new AcmStatusUpdatedEventArgs(axisNo, parsedState));
                }

                if (++axisNo >= m_AxisCount)
                    axisNo = 0;

                // 用於一般的停止條件
                //if (torque >= TorqueLimit)
                //{
                //    StopWhenConditions();
                //}

                Thread.Sleep(20);
            }
        }

        #endregion Polling Procedures

        /// <summary>
        /// 緊急停止。
        /// </summary>
        /// <remarks></remarks>
        private void EmergencyStop()
        {
            // 只做停機，不寫 log，不更新 UI
        }

        /// <summary>
        /// 
        /// </summary>
        private void StopWhenConditions()
        {

        }
    }
}
