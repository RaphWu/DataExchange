﻿using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    /// <summary>
    /// Advantech ACM 服務。
    /// </summary>
    public partial class AcmService : IAcm
    {
        #region fields

        private DEV_LIST[] _availableDevices = new DEV_LIST[Motion.MAX_DEVICES]; // 有效設備列表
        private uint _deviceCount = 0; // 有效設備數量

        #endregion fields

        public AcmService(AcmConfig acmConfig)
        {
            ConfigErrorMessages();
        }


        public void StopMotion()
        {

        }
    }
}
