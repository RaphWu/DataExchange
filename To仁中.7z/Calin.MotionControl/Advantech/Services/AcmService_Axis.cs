﻿using Advantech.Motion;
using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    // 軸操作
    public partial class AcmService : IAcmService_Axis
    {

        public void GetAxisCount()
        {
            ErrCode = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref m_AxisCount);
            if (NoError)
            {
                for (ushort phyAxis = 0; phyAxis < m_AxisCount; phyAxis++)
                {
                    ErrCode = Motion.mAcm_AxOpen(m_DeviceHandle, phyAxis, ref m_AxisHandles[phyAxis]);
                    if (NoError)
                    {
                        // 設定命令位置及實際位置為 0
                        _ = Motion.mAcm_AxSetCmdPosition(m_AxisHandles[phyAxis], 0.0);
                        _ = Motion.mAcm_AxSetActualPosition(m_AxisHandles[phyAxis], 0.0);
                    }
                    else
                        break;
                }
            }

        }
    }
}
