﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    // 群組操作
    public partial class AcmService : IAcmService_Group
    {
    }
}
