﻿using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    // 群組操作
    public partial class AcmService : IAcmService_Group
    {
    }
}
