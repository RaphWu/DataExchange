﻿using System.Collections.Generic;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
	public partial class AcmService : IAcmService_ErrorMessage
	{
		#region fields

		private ErrMessage _errMessage = new ErrMessage();

		#endregion fields
		public ErrMessage ErrMessage => _errMessage;

		/// <inheritdoc/>
		public void ClearErrMessage() => _errMessage = new ErrMessage();


		private void SetErrMessage(int errCode)
		{
			_errMessage = new ErrMessage()
			{
				ErrorCode = errCode,
				Message = Motion.geterr
				Description = GetErrMessage(errCode).Description,
			};
		}












		/// <summary>
		/// 錯誤訊息表。
		/// </summary>
		internal Dictionary<int, ErrMessage> errorMessages = new Dictionary<int, ErrMessage>();

		/// <inheritdoc/>
		public ErrMessage GetErrMessage(int code)
		{
			return errorMessages.TryGetValue(code, out var errMessage)
				? errMessage
				: new ErrMessage("查無代碼", $"錯誤訊息表沒有錯誤代碼 0x{code:8X} 的資訊，請查閱手冊。");
		}

		/// <summary>
		/// 設定錯誤訊息表。
		/// </summary>
		internal void ConfigErrorMessages()
		{
			errorMessages.Add(0x00000000, new ErrMessage("SUCCESS"));
		}
	}
}
