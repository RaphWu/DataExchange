﻿using System;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    // 設備操作
    public partial class AcmService : IAcmService_Device
    {
        public int GetAvailableDevs()
        {
            int ret = Motion.mAcm_GetAvailableDevs(_availableDevices, Motion.MAX_DEVICES, ref _deviceCount);
            if (ret != (int)ErrorCode.SUCCESS)
            {
                _errMessage= Motion.macm_get
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(ret, 16) + "]";
                ShowMessages(strTemp, (uint)ret);
            }
            return ret;
        }

        public int DeviceOpen()
        {
            int ret = Acm_DevOpen();
            return ret;
        }

    }
}
