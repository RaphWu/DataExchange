﻿using Calin.MC.Advantech.Contracts;

namespace Calin.MC.Advantech.Services
{
    // Acm 設定檔
    public partial class AcmService : IAcmService_ConfigFile
    {
        /********************
         * 配置文件
         ********************/
        public void DevConfigLoad()
        {
            Acm_DevLoadConfig();
        }
    }
}
