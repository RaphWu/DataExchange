﻿using System.Text;
using Advantech.Motion;
using Calin.MC.Advantech.Contracts;
using Calin.MC.Advantech.Models;

namespace Calin.MC.Advantech.Services
{
    // 錯誤管理
    public partial class AcmService : IAcmService_ErrManager
    {
        #region fields

        private const int MaxError = 100;
        private bool _success;
        private ErrMessage _errMessage;

        #endregion fields

        #region Properties

        public bool Success => _success;

        public ErrMessage ErrMessage => _errMessage;

        /// <summary>
        /// 設定錯誤碼，然後設定是否成功、訊息、詳細資訊。
        /// </summary>
        internal uint ErrCode
        {
            get => _errMessage.ErrorCode;
            set
            {
                _success = value == (int)ErrorCode.SUCCESS;

                if (_success)
                {
                    _errMessage = new ErrMessage();
                }
                else
                {
                    StringBuilder errMsg = new StringBuilder("", MaxError);
                    if (!Motion.mAcm_GetErrorMessage(value, errMsg, MaxError))
                        errMsg.Append($"無法取得錯誤代碼 0x{value:8X} 的訊息，請查閱手冊或詢問原廠。");
                    _errMessage = new ErrMessage()
                    {
                        ErrorCode = value,
                        Message = errMsg.ToString(),
                        Description = "",
                    };
                }
            }
        }

        #endregion Properties

        #region Methods

        /// <inheritdoc/>
        public bool ResetAxisState(int axisNo)
        {
            ErrCode = Motion.mAcm_AxResetError(m_AxisHandles[axisNo]);
            return (!CheckErr($"{nameof(IAcmService_ErrManager)}.{nameof(ResetAxisState)}", $"軸 {axisNo + 1} 狀態重置失敗！"));
        }

        #endregion

        #region Internal Methods

        /// <summary>
        /// 檢查是否有錯誤發生，並設定詳細資訊。
        /// </summary>
        /// <remarks>注意：只有在有錯誤發生時才會設定呼叫者名稱及錯誤詳細資訊，以避免過多的變數設定動作。</remarks>
        /// <param name="callerName">呼叫者名稱。</param>
        /// <param name="detailMsg">錯誤詳細資訊。</param>
        /// <returns>是否有錯誤發生。</returns>
        internal bool CheckErr(string callerName, string detailMsg = "")
        {
            if (!Success)
            {
                _errMessage.Description = detailMsg;
                _errMessage.CallerName = callerName;
                return true;
            }
            return false;
        }

        /// <summary>
        /// 檢查是否有錯誤發生，並設定詳細資訊。
        /// </summary>
        /// <param name="detailMsg">錯誤詳細資訊。</param>
        /// <returns>是否有錯誤發生。</returns>
        internal bool CheckErr(string detailMsg = "")
        {
            return CheckErr("", detailMsg);
        }

        /// <summary>
        /// 設定錯誤訊息。
        /// </summary>
        /// <remarks>有時控制回報沒有問題，但程式仍無法運作，
        /// 比如使用 PropertyID.FT_DevAxesCount 取得軸數為零時，不會報錯，但沒有軸可以動作。</remarks>
        /// <param name="callerName">呼叫者名稱。</param>
        /// <param name="errMsg">錯誤訊息。</param>
        /// <param name="detailMsg">錯誤詳細資訊。</param>
        internal void SetErr(string callerName, string errMsg, string detailMsg = "")
        {
            _errMessage.ErrorCode = 0;
            _errMessage.Message = errMsg;
            _errMessage.Description = detailMsg;
            _errMessage.CallerName = callerName;
        }

        #endregion Internal Methods









        ///// <summary>
        ///// 錯誤訊息表。
        ///// </summary>
        //internal Dictionary<int, ErrManager> errorMessages = new Dictionary<int, ErrManager>();

        ///// <inheritdoc/>
        //public ErrManager GetErrMessage(int code)
        //{
        //    return errorMessages.TryGetValue(code, out var errMessage)
        //        ? errMessage
        //        : new ErrMessage("查無代碼", $"錯誤訊息表沒有錯誤代碼 0x{code:8X} 的資訊，請查閱手冊。");
        //}

        ///// <summary>
        ///// 設定錯誤訊息表。
        ///// </summary>
        //internal void ConfigErrorMessages()
        //{
        //    errorMessages.Add(0x00000000, new ErrMessage("SUCCESS"));
        //}
    }
}
