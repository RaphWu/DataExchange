﻿# Calin.MotionControl.Advantech (研華通用運動 ACM) 使用說明

## 簡介

`Calin.MotionControl.Advantech` 提供與 Advantech ACM (AdvMotAPI) 控制卡互動的封裝服務，包含裝置開啟/關閉、軸操作、群組操作、狀態輪詢與錯誤管理等功能。此套件透過介面分層，方便在應用程式中以 DI 容器（例如 `Autofac`）註冊與解析。

## 目標框架

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8

## 相依套件

- `Autofac`（用於註冊與解析服務）
- 原廠 C# 庫 `AdvMotAPI.dll`（請安裝 Advantech Common Motion Driver，並將 `AdvMotAPI.dll` 加入專案）

## 安裝與設定

1. 先安裝 Advantech Common Motion Driver（參考官方文件）。
2. 在專案中加入 `AdvMotAPI.dll`（建議放在 `nuget` 或專案資料夾，並將檔案屬性 `複製到輸出目錄` 設為 `一律複製`）。
3. 確認專案已加入 `Autofac` 套件（`Calin.MotionControl.Advantech` 的 csproj 已包含此參考）。

## 重要檔案

- `AdvantechModule`：提供一個 `Autofac` 模組，可直接註冊 `IAcm` 實作。
- `IAcm`：根介面，包含裝置、軸、群組、輪詢與錯誤管理等子介面：
  - `IAcmService_Device`（裝置/控制卡）
  - `IAcmService_Axis`（軸操作）
  - `IAcmService_Group`（群組操作）
  - `IAcmService_Polling`（狀態輪詢）
  - `IAcmService_ErrManager`（錯誤管理）

## 註冊方式（Autofac）

- 直接註冊 `AdvantechModule` 便可以呼叫使用：

```csharp
var builder = new ContainerBuilder();
builder.RegisterModule<Calin.MotionControl.Advantech.AdvantechModule>();
var container = builder.Build();
```

## 介面繼承結構

`IAcm` 作為所有功能介面的根介面而成為一個統一的入口，其他功能介面（如 `IAcmService_Device`、`IAcmService_Axis` 等）都繼承自 `IAcm`，開發者只需依賴 `IAcm`，即可存取所有功能。

```csharp
public class SomeClass
{
    private readonly IAcm _acm;
    public ToolPanel(IAcm acm)
    {
        _acm = acm;
    }

    private void SomeMethod()
    {
        if (!_acm.IsBoardInit) return;

        // ...
    }
}
```

## 介面與主要功能概覽

### 裝置與控制卡管理 `IAcmService_Device`

| 成員 | 類型 | 說明 |
| --- | --- | --- |
| `DeviceCount` | 屬性 | 裝置數量 |
| `AvailableDevices` | 屬性 | 可用裝置列表 |
| `DeviceNumber` | 屬性 | 目前操作的裝置編號 |
| `DeviceHandle` | 屬性 | 裝置控制代碼 |
| `IsBoardInit` | 屬性 | 控制卡是否已初始化 |
| `IsServoOn` | 屬性 | 伺服是否已開啟 |
| `GetAvailableDevs()` | 方法 | 取得可用裝置並更新列表 |
| `BoardOpen()` | 方法 | 開啟控制卡及所含的全部軸 |
| `BoardClose()` | 方法 | 關閉控制卡及所含的全部軸 |
| `ServoOn()` | 方法 | 開啟所有軸伺服 |
| `ServoOff()` | 方法 | 關閉所有軸伺服 |
| `LoadCfg(string)` | 方法 | 載入裝置設定檔 (.cfg) |

### 軸操作 `IAcmService_Axis`

| 成員 | 類型 | 說明 |
| --- | --- | --- |
| `AxisCount` | 屬性 | 軸數量 |
| `RawAxisStates` | 屬性 | 原始軸狀態 (IO 讀值) |
| `ParsedAxisStates` | 屬性 | 解析後的軸狀態 (包含限位、原點、錯誤等旗標) |
| `AxisStop(int)` | 方法 | 軸減速停止 |
| `AxisStopEmg(int)` | 方法 | 軸緊急停止 |
| `AxisHome(...)` | 方法 | 軸原點復歸 |
| `SetCmdPosition(...)` | 方法 | 設定軸命令位置 |
| `SetActPosition(...)` | 方法 | 設定軸實際位置 |
| `GetAxisVelLow` / `SetAxisVelLow` | 方法 | 讀取 / 設定軸初速度 (VelLow) |
| `GetAxisVelHigh` / `SetAxisVelHigh` | 方法 | 讀取 / 設定軸運行速度 (VelHigh) |
| `GetAxisAcc` / `SetAxisAcc` | 方法 | 讀取 / 設定軸加速度 |
| `GetAxisDec` / `SetAxisDec` | 方法 | 讀取 / 設定軸減速度 |
| `GetAxisJerk` / `SetAxisJerk` | 方法 | 讀取 / 設定速度曲線型態 (0: T 型, 1: S 型) |
| `GetHomeModeName(...)` | 方法 | 取得原點復歸模式名稱 |
| `GetHomeModeDescription(...)` | 方法 | 取得原點復歸模式詳細描述 |

### 手動操作 `IAcmService_Manual`

| 成員 | 類型 | 說明 |
| --- | --- | --- |
| `SetExtDrive(int, ushort)` | 方法 | 設定外部驅動模式 (0:Disable, 1:Jog, 2:MPG) |

### 狀態輪詢 `IAcmService_Polling` (內部使用)

| 成員 | 類型 | 說明 |
| --- | --- | --- |
| `AcmStatusUpdated` | 事件 | 軸狀態更新事件，於輪詢週期觸發 |
| `PollingStart()` | 方法 | 啟動狀態輪詢 |
| `PollingStop()` | 方法 | 停止狀態輪詢 |

### 錯誤管理 `IAcmService_ErrManager`

| 成員 | 類型 | 說明 |
| --- | --- | --- |
| `Success` | 屬性 | 最近一次操作是否成功 |
| `ErrMessage` | 屬性 | 錯誤訊息結構 |
| `ResetAxisState(int)` | 方法 | 重置指定軸的錯誤狀態 |

## 使用範例

### 基本使用流程

以下為完整的使用流程範例，涵蓋從容器建置到控制卡操作的所有步驟：

```csharp
using Autofac;
using Calin.MotionControl.Advantech;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Services;

// 1. 建置容器並註冊模組
var builder = new ContainerBuilder();
builder.RegisterModule<AdvantechModule>();
var container = builder.Build();

// 2. 解析 IAcm 服務
var acm = container.Resolve<IAcm>();

// 3. 掃描可用裝置
uint devCount = acm.GetAvailableDevs();
if (!acm.Success)
{
    Console.WriteLine($"裝置掃描失敗: {acm.ErrMessage.Message}");
    return;
}

Console.WriteLine($"找到 {devCount} 個裝置");
foreach (var dev in acm.AvailableDevices)
{
    Console.WriteLine($"裝置 {dev.DeviceNum}: {dev.DeviceName}");
}

// 4. 載入設定檔（選用）
string cfgPath = @"C:\Config\MyBoard.cfg";
if (!acm.LoadCfg(cfgPath))
{
    Console.WriteLine($"設定檔載入失敗: {acm.ErrMessage.Message}");
    return;
}

// 5. 開啟控制卡
if (!acm.BoardOpen())
{
    Console.WriteLine($"控制卡開啟失敗: {acm.ErrMessage.Message}");
    return;
}

Console.WriteLine($"控制卡已開啟，共有 {acm.AxisCount} 個軸");

// 6. 訂閱軸狀態更新事件
acm.AcmStatusUpdated += (sender, e) =>
{
    var state = e.State;
    Console.WriteLine($"軸 {e.AxisNo}: 命令位置={state.CmdPosition:F3}, 實際位置={state.ActPosition:F3}");
    
    // 檢查錯誤狀態
    if (state.StateFlags.HasFlag(StateFlags.STA_AX_ERROR_STOP))
    {
        Console.WriteLine($"軸 {e.AxisNo} 發生錯誤停止！");
    }
    
    // 檢查限位開關
    if (state.IoFlags.HasFlag(AxisIoFlags.LMT_Positive))
        Console.WriteLine($"軸 {e.AxisNo} 觸發正向限位");
    if (state.IoFlags.HasFlag(AxisIoFlags.LMT_Negative))
        Console.WriteLine($"軸 {e.AxisNo} 觸發負向限位");
}

// 7. 開啟伺服
if (!acm.ServoOn())
{
    Console.WriteLine($"伺服開啟失敗: {acm.ErrMessage.Message}");
}

// 8. 設定軸參數
int axisNo = 0;
if (!acm.SetAxisVelLow(axisNo, 1000.0))
    Console.WriteLine($"設定初速度失敗: {acm.ErrMessage.Message}");
if (!acm.SetAxisVelHigh(axisNo, 10000.0))
    Console.WriteLine($"設定運行速度失敗: {acm.ErrMessage.Message}");
if (!acm.SetAxisAcc(axisNo, 50000.0))
    Console.WriteLine($"設定加速度失敗: {acm.ErrMessage.Message}");
if (!acm.SetAxisDec(axisNo, 50000.0))
    Console.WriteLine($"設定減速度失敗: {acm.ErrMessage.Message}");
if (!acm.SetAxisJerk(axisNo, 1.0))  // 0: T型曲線, 1: S型曲線
    Console.WriteLine($"設定速度曲線失敗: {acm.ErrMessage.Message}");

// 9. 讀取軸參數（驗證設定）
var velLow = acm.GetAxisVelLow(axisNo);
if (velLow.IsSuccess)
    Console.WriteLine($"軸 {axisNo} 初速度: {velLow.Value}");

var velHigh = acm.GetAxisVelHigh(axisNo);
if (velHigh.IsSuccess)
    Console.WriteLine($"軸 {axisNo} 運行速度: {velHigh.Value}");

// 10. 執行原點復歸
// homeMode: 0~15 (參考研華手冊)
// direction: 0=正向, 1=負向
// switchMode: 0=Level On, 1=Level Off, 2=Rising Edge, 3=Falling Edge
// crossDistance: 跨越距離
uint homeMode = 1;  // MODE1
uint direction = 1; // 負向
uint switchMode = 0; // Level On
double crossDistance = 10000.0;

Console.WriteLine($"開始原點復歸 - {acm.GetHomeModeDescription(homeMode)}");
if (!acm.AxisHome(axisNo, homeMode, direction, switchMode, crossDistance))
{
    Console.WriteLine($"原點復歸失敗: {acm.ErrMessage.Message}");
}

// 等待原點復歸完成
while (acm.ParsedAxisStates[axisNo].StateFlags.HasFlag(StateFlags.STA_AX_HOMING))
{
    Thread.Sleep(100);
}
Console.WriteLine("原點復歸完成");

// 11. 位置重置
if (!acm.SetCmdPosition(axisNo, 0.0))
    Console.WriteLine($"命令位置重置失敗: {acm.ErrMessage.Message}");
if (!acm.SetActPosition(axisNo, 0.0))
    Console.WriteLine($"實際位置重置失敗: {acm.ErrMessage.Message}");

// 12. 軸停止操作
Thread.Sleep(5000);
if (!acm.AxisStop(axisNo))  // 減速停止
    Console.WriteLine($"減速停止失敗: {acm.ErrMessage.Message}");

// 或使用緊急停止
// if (!acm.AxisStopEmg(axisNo))
//     Console.WriteLine($"緊急停止失敗: {acm.ErrMessage.Message}");

// 13. 錯誤處理與重置
if (acm.ParsedAxisStates[axisNo].StateFlags.HasFlag(StateFlags.STA_AX_ERROR_STOP))
{
    Console.WriteLine("偵測到軸錯誤，嘗試重置...");
    if (!acm.ResetAxisState(axisNo))
        Console.WriteLine($"軸狀態重置失敗: {acm.ErrMessage.Message}");
    else
        Console.WriteLine("軸狀態重置成功");
}

// 14. 關閉並釋放資源
acm.ServoOff();
acm.BoardClose();

Console.WriteLine("程式結束");
```

### 在依賴注入環境中使用

在實際應用程式中（如 WinForms），通常會透過建構函式注入 `IAcm`：

```csharp
public class MyForm : Form
{
    private readonly IAcm _acm;
    
    public MyForm(IAcm acm)
    {
        _acm = acm;
        InitializeComponent();
    }
    
    private void BtnOpenBoard_Click(object sender, EventArgs e)
    {
        if (!_acm.BoardOpen())
        {
            ShowError($"控制卡開啟失敗");
            return;
        }
        
        // 訂閱狀態更新
        _acm.AcmStatusUpdated += OnAcmStatusUpdated;
    }
    
    private void OnAcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs e)
    {
        // 更新 UI
        BeginInvoke(new Action(() =>
        {
            txtPosition.Text = e.State.CmdPosition.ToString("F3");
            // ... 更新其他狀態顯示
        }));
    }
    
    private void ShowError(string message)
    {
        var err = _acm.ErrMessage;
        MessageBox.Show(
            $"{message}\n\n" +
            $"錯誤碼: 0x{err.ErrorCode:X8}\n" +
            $"錯誤訊息: {err.Message}\n" +
            $"詳細資訊: {err.Description}\n" +
            $"呼叫程序: {err.CallerName}()",
            "錯誤",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
    
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        // 確保資源正確釋放
        if (_acm.IsBoardInit)
        {
            _acm.PollingStop();
            _acm.BoardClose();
        }
        base.OnFormClosing(e);
    }
}
```

### 錯誤處理最佳實踐

建議在呼叫任何 ACM 方法後，都檢查返回值或 `Success` 屬性：

```csharp
// 方法1: 檢查返回值
if (!acm.BoardOpen())
{
    Console.WriteLine($"失敗: {acm.ErrMessage.Message}");
}

// 方法2: 檢查 Success 屬性
acm.GetAvailableDevs();
if (!acm.Success)
{
    Console.WriteLine($"失敗: {acm.ErrMessage.Message}");
}

// 方法3: 使用返回的 Tuple (適用於 Get 類方法)
var result = acm.GetAxisVelLow(0);
if (result.IsSuccess)
{
    Console.WriteLine($"VelLow = {result.Value}");
}
else
{
    Console.WriteLine($"讀取失敗: {acm.ErrMessage.Message}");
}
```

## 注意事項

- `AdvMotAPI.dll` 為原廠非託管 DLL，使用前請確保驅動與對應版本已安裝並可存取。
- 輪詢會建立背景執行緒，請在應用程式結束或切換控制卡時呼叫 `PollingStop()` 與 `BoardClose()` 以確保資源釋放與執行緒結束。
- `BoardOpen()` 會自動啟動輪詢 (`PollingStart()`)，無需手動呼叫。
- 原點復歸模式 (homeMode) 共有 0~15 種，詳細說明請參考研華 ACM API 手冊或使用 `GetHomeModeDescription()` 方法查詢。
- 錯誤訊息透過 `ErrMessage` 屬性取得，包含錯誤碼、訊息、詳細描述與呼叫者資訊。
- 狀態輪詢事件 `AcmStatusUpdated` 在 UI 執行緒外觸發，更新 UI 時請使用 `BeginInvoke` 或 `Dispatcher.Invoke`。

## 授權與版本

套件版本請參見專案檔 `Advantech.csproj` 中的 `<Version>`。

# Calin.Comm.DL_RS1A

## 簡介

`Calin.Comm.DL_RS1A` 是用於 Keyence DL-RS1A 的 .NET RS-232 通訊函式庫，基於 `Calin.SerialPort` 進行串列埠通訊。目前支援 Keyence GT2/GT 系列感測器。

## 功能說明

- **SerialPort 通訊** - 使用 `Calin.SerialPort` 進行底層通訊
- **Factory 模式** - 透過工廠建立 DL-RS1A 實例，支援多設備同時存在
- **支援 Autofac 依賴注入** - 方便應用層整合
- **GT2/GT 系列指令** - 支援 Keyence GT2/GT 系列感測器通訊指令

## 目標框架

- .NET Framework 4.6.2
- .NET Framework 4.8
- .NET 8.0

## 相依套件

- **Calin.SerialPort** - 串列埠通訊模組
- **Autofac** - 依賴注入框架

## 架構設計

```mermaid
graph TB
    subgraph Application Layer
        App[應用程式]
    end
    
    subgraph DI Container
        Module[DL_RS1A_Module]
        DLFactory[IDL_RS1A_ServiceFactory]
        SPFactory[ISerialPortServiceFactory]
    end
    
    subgraph Instance Layer
        DL1[DL_RS1A COM1]
        DL2[DL_RS1A COM2]
    end
    
    subgraph Hardware
        COM1[Keyence DL-RS1A #1]
        COM2[Keyence DL-RS1A #2]
    end
    
    App --> Module
    Module --> DLFactory
    Module --> SPFactory
    DLFactory --> DL1
    DLFactory --> DL2
    DL1 --> COM1
    DL2 --> COM2
```

### 設計原則

| 類別 | 生命週期 | 說明 |
|------|----------|------|
| `DL_RS1A_Module` | - | Autofac 模組，僅負責型別註冊 |
| `IDL_RS1A_ServiceFactory` | SingleInstance | 工廠，負責建立 DL_RS1A |
| `DL_RS1A` | InstancePerDependency | 代表單一設備，由 Factory 建立 |

## 檔案結構

```markdown
Calin.Comm.DL_RS1A/
├── IDL_RS1A.cs                  // DL-RS1A 介面
├── DL_RS1A.cs                   // DL-RS1A 實作
├── DL_RS1A_Config.cs            // DL-RS1A 設定
├── IDL_RS1A_ServiceFactory.cs   // 工廠介面
├── DL_RS1A_ServiceFactory.cs    // 工廠實作
├── DL_RS1A_Module.cs            // Autofac 模組
├── KeyenceSensorType.cs         // 感測器類型列舉
├── IDL_RS1A_GT2_Commands.cs     // GT2 指令介面
├── DL_RS1A_GT2_Commands.cs      // GT2 指令實作
└── README.md                    // 說明文件
```

## 快速開始

### 1. 使用 Autofac 依賴注入

```csharp
using Autofac;
using Calin.Comm.DL_RS1A;

// 建立 Autofac 容器
var builder = new ContainerBuilder();
builder.RegisterModule<DL_RS1A_Module>();
var container = builder.Build();

// 取得 Factory
var factory = container.Resolve<IDL_RS1A_ServiceFactory>();

// 使用 DL_RS1A_Config 建立
var config = new DL_RS1A_Config
{
    SensorType = KeyenceSensorType.GT2,
    IdNumber = 1,
    SensorName = "GT2 Sensor",
    PortName = "COM1",
    BaudRate = 9600,
    DataBits = 8,
    Parity = RJCP.IO.Ports.Parity.None,
    StopBits = RJCP.IO.Ports.StopBits.One
};

using (var device = factory.Create(config))
{
    // 開啟連線
    if (device.Open())
    {
        Console.WriteLine("DL-RS1A 連線成功");
        
        // 呼叫 IDL_RS1A 的方法來操作設備
        // 例如: device.SomeCommand();
        
        Console.ReadKey();
    }
}
```

### 2. 使用 CreateAndOpen 快速建立

```csharp
var factory = container.Resolve<IDL_RS1A_ServiceFactory>();

var config = new DL_RS1A_Config
{
    SensorType = KeyenceSensorType.GT2,
    PortName = "COM1",
    BaudRate = 9600
};

try
{
    using (var device = factory.CreateAndOpen(config))
    {
        // 呼叫 IDL_RS1A 的方法來操作設備
        Console.ReadKey();
    }
}
catch (InvalidOperationException ex)
{
    Console.WriteLine($"無法開啟連線: {ex.Message}");
}
```

### 3. 多設備同時使用

```csharp
var factory = container.Resolve<IDL_RS1A_ServiceFactory>();

var config1 = new DL_RS1A_Config 
{ 
    SensorType = KeyenceSensorType.GT2,
    IdNumber = 1,
    PortName = "COM1", 
    BaudRate = 9600 
};

var config2 = new DL_RS1A_Config 
{ 
    SensorType = KeyenceSensorType.GT2,
    IdNumber = 2,
    PortName = "COM2", 
    BaudRate = 9600 
};

// 建立多個 DL-RS1A 實例
var device1 = factory.Create(config1);
var device2 = factory.Create(config2);

device1.Open();
device2.Open();

// 呼叫 IDL_RS1A 的方法來操作設備

// 使用完畢後釋放
device1.Dispose();
device2.Dispose();
```

## DL_RS1A_Config 設定

| 參數 | 型別 | 預設值 | 說明 |
|------|------|--------|------|
| SensorType | KeyenceSensorType | None | 感測器類型（目前支援 GT2/GT） |
| IdNumber | int | 1 | 設備 ID 編號 |
| SensorName | string | "" | 感測器名稱 |
| PortName | string | "COM1" | COM Port 名稱 |
| BaudRate | int | 9600 | 鮑率 |
| DataBits | int | 8 | 資料位元數 |
| Parity | Parity | None | 同位位元 |
| StopBits | StopBits | One | 停止位元 |
| ReadTimeout | int | 1000 | 讀取逾時（毫秒） |
| WriteTimeout | int | 1000 | 寫入逾時（毫秒） |

## 支援的感測器類型

| 類型 | 說明 |
|------|------|
| `KeyenceSensorType.GT2` | Keyence GT2 系列感測器 |
| `KeyenceSensorType.GT` | Keyence GT 系列感測器 |

## 注意事項

- 使用完畢後請記得呼叫 `Dispose()` 或使用 `using` 語句釋放資源
- Factory 建立的實例需由呼叫者負責 Dispose
- APP 透過 `IDL_RS1A` 介面的方法來操作設備
- 目前僅支援 GT2/GT 系列感測器，其他類型會拋出 `ArgumentException`

## 版本歷史

### v0.0.2

2026.01.20

- 新增 `IsTransmissionVerified` 屬性至 `IDL_RS1A`
- `SerialPortTransport` 現在會檢查底層 SerialPort 的傳輸驗證狀態

### v0.0.1

- 初始版本
- 支援 SerialPort 通訊
- 實作 Factory 模式
- 支援 Autofac 依賴注入
- 支援 GT2/GT 系列感測器

---

Copyright © 2026 佳凌科技股份有限公司 Calin Technology Co.,Ltd.
