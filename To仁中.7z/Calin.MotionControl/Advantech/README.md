﻿# 研華通用運動 (ACM) 架構

# 目標框架

- .NET Framework 4.8
- .NET 8

---

# NuGet 套件依賴

- AutoFac
- 

---

# 檔案架構

---
