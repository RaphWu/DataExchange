﻿namespace Calin.MC.Advantech.Models
{
    /// <summary>
    /// 運動狀態資料模型 (Snapshot Buffer)。
    /// </summary>
    public sealed class AcmStatus
    {
        #region 軸當前狀態

        /// <summary>
        /// 軸被停用，使用者可開啟並激活。
        /// </summary>
        public bool STA_AX_DISABLE { get; set; }

        /// <summary>
        /// 軸已準備就緒，等待新的指令。
        /// </summary>
        public bool STA_AX_READY { get; set; }

        /// <summary>
        /// 軸停止。
        /// </summary>
        public bool STA_AX_STOPPING { get; set; }

        /// <summary>
        /// 出現錯誤，軸停止。
        /// </summary>
        public bool STA_AX_ERROR_STOP { get; set; }

        /// <summary>
        /// 軸正在執行返回原點運動。
        /// </summary>
        public bool STA_AX_HOMING { get; set; }

        /// <summary>
        /// 軸正在執行 PTP 運動。
        /// </summary>
        public bool STA_AX_PTP_MOT { get; set; }

        /// <summary>
        /// 軸正在執行連續運動。
        /// </summary>
        public bool STA_AX_CONTI_MOT { get; set; }

        /// <summary>
        /// 軸在一個群組中，群組正在執行插補運動；或軸是一個從軸，正在執行 E-cam/E-gear/Gantry 運動。
        /// </summary>
        public bool STA_AX_SYNC_MOT { get; set; }

        /// <summary>
        /// 軸由外部訊號控制執行 JOG 模式運動中。
        /// </summary>
        public bool STA_AX_EXT_JOG { get; set; }

        /// <summary>
        /// 軸由外部訊號控制。當外部訊號啟動時，軸將執行 MPG 模式運動。
        /// </summary>
        public bool STA_AX_EXT_MPG { get; set; }

        /// <summary>
        /// 軸暫停。
        /// </summary>
        public bool STA_AX_PAUSE { get; set; }

        /// <summary>
        /// 軸忙碌中，前一個指令尚未處理完成。
        /// </summary>
        public bool STA_AX_BUSY { get; set; }

        /// <summary>
        /// 軸在等待指定的DI訊號。
        /// </summary>
        public bool STA_AX_WAIT_DI { get; set; }

        /// <summary>
        /// 軸在等待其他軸點對點運動完成。
        /// </summary>
        public bool STA_AX_WAIT_PTP { get; set; }

        /// <summary>
        /// 軸在等待其他軸連續運動完成。
        /// </summary>
        public bool STA_AX_WAIT_VEL { get; set; }

        /// <summary>
        /// 軸由外部訊號控制。當外部訊號啟動時，軸將執行 JOG 模式運動。
        /// </summary>
        public bool STA_AX_EXT_JOG_READY { get; set; }

        #endregion 軸當前狀態

        #region 軸當前運動狀態

        /// <summary>
        /// 停止。
        /// </summary>
        public string Stop { get; set; }

        /// <summary>
        /// 保留。
        /// </summary>
        public string Res1 { get; set; }

        /// <summary>
        /// 等待ERC 完成。
        /// </summary>
        public string WaitERC { get; set; }

        /// <summary>
        /// 保留。
        /// </summary>
        public string Res2 { get; set; }

        /// <summary>
        /// 背隙補償。
        /// </summary>
        public string CorrectBksh { get; set; }

        /// <summary>
        /// 保留。
        /// </summary>
        public string Res3 { get; set; }

        /// <summary>
        /// 處於特定速度中 = FA。
        /// </summary>
        public string InFA { get; set; }

        /// <summary>
        /// 處於低速中 = FL。
        /// </summary>
        public string InFL { get; set; }

        /// <summary>
        /// 加速中。
        /// </summary>
        public string InACC { get; set; }

        /// <summary>
        /// 處於最大速度 = FH。
        /// </summary>
        public string InFH { get; set; }

        /// <summary>
        /// 減速中。
        /// </summary>
        public string InDEC { get; set; }

        /// <summary>
        /// 到位等待。
        /// </summary>
        public string WaitINP { get; set; }

        #endregion 軸當前運動狀態

        #region 軸速度

        /// <summary>
        /// 取得軸支援的最大速度。
        /// </summary>
        public string FT_AxMaxVel { get; set; }

        /// <summary>
        /// 取得軸支援的最大加速度。
        /// </summary>
        public string FT_AxMaxAcc { get; set; }

        /// <summary>
        /// 取得軸支援的最大減速度。
        /// </summary>
        public string FT_AxMaxDec { get; set; }

        /// <summary>
        /// 取得軸支援的最大減速度。
        /// </summary>
        public string FT_AxMaxJerk { get; set; }

        /// <summary>
        /// 配置運動軸的最大速度。
        /// </summary>
        public string CFG_AxMaxVel { get; set; }

        /// <summary>
        /// 配置運動軸的最大加速度。
        /// </summary>
        public string CFG_AxMaxAcc { get; set; }

        /// <summary>
        /// 配置運動軸的最大減速。
        /// </summary>
        public string CFG_AxMaxDec { get; set; }

        /// <summary>
        /// 取得運動軸的最大加加速度配置。
        /// </summary>
        public string CFG_AxMaxJerk { get; set; }

        /// <summary>
        /// 設定 / 取得該軸的起始速度。
        /// </summary>
        public string PAR_AxVelLow { get; set; }

        /// <summary>
        /// 設定 / 取得該軸的運轉速度。
        /// </summary>
        public string PAR_AxVelHigh { get; set; }

        /// <summary>
        /// 設定 / 取得該軸的加速度。
        /// </summary>
        public string PAR_AxAcc { get; set; }

        /// <summary>
        /// 設定 / 取得該軸的減速度。
        /// </summary>
        public string PAR_AxDec { get; set; }

        /// <summary>
        /// 設定速度曲線的類型：T 形曲線或 S 形曲線。
        /// </summary>
        public string PAR_AxJerk { get; set; }

        #endregion 軸速度

        #region 軸的運動 I/O 狀態

        /// <summary>
        /// 針腳輸入。
        /// </summary>
        public string RDY { get; set; }

        /// <summary>
        /// 警報訊號輸入。
        /// </summary>
        public string ALM { get; set; }

        /// <summary>
        /// 限位開關+。
        /// </summary>
        public string LMT_Positive { get; set; }

        /// <summary>
        /// 限位開關-。
        /// </summary>
        public string LMT_Negative { get; set; }

        /// <summary>
        /// 原始開關。
        /// </summary>
        public string ORG { get; set; }

        /// <summary>
        /// DIR輸出。
        /// </summary>
        public string DIR { get; set; }

        /// <summary>
        /// 緊急訊號輸入。
        /// </summary>
        public string EMG { get; set; }

        /// <summary>
        /// PCS訊號輸入。
        /// </summary>
        public string PCS { get; set; }

        /// <summary>
        /// 輸出偏誤計數器清除訊號至伺服馬達驅動。
        /// </summary>
        public string ERC { get; set; }

        /// <summary>
        /// 編碼器Z訊號。
        /// </summary>
        public string EZ { get; set; }

        /// <summary>
        /// 外部輸入至清除位置計數器。
        /// </summary>
        public string CLR { get; set; }

        /// <summary>
        /// 鎖存訊號輸入。
        /// </summary>
        public string LTC { get; set; }

        /// <summary>
        /// 減速訊號輸入。
        /// </summary>
        public string SD { get; set; }

        /// <summary>
        /// 到位訊號輸入。
        /// </summary>
        public string INP { get; set; }

        /// <summary>
        /// 伺服開啟（OUT6）。
        /// </summary>
        public string SVON { get; set; }

        /// <summary>
        /// 警報重設輸出狀態。
        /// </summary>
        public string ALRM { get; set; }

        /// <summary>
        /// 軟體限位+。
        /// </summary>
        public string SLMT_Positive { get; set; }

        /// <summary>
        /// 軟體限位-。
        /// </summary>
        public string SLMT_Negative { get; set; }

        /// <summary>
        /// 比較訊號。
        /// </summary>
        public string CMP { get; set; }

        /// <summary>
        /// 凸輪區間DO。
        /// </summary>
        public string CAMDO { get; set; }

        #endregion 軸的運動 I/O 狀態

        #region 群組狀態

        /// <summary>
        /// 群組狀態為Disable，無法執行群組運動。
        /// </summary>
        public string STA_GP_DISABLE { get; set; }

        /// <summary>
        /// 群組已準備好，等待新的指令。
        /// </summary>
        public string STA_GP_READY { get; set; }

        /// <summary>
        /// 群組停止。
        /// </summary>
        public string STA_GP_STOPPING { get; set; }

        /// <summary>
        /// 出現錯誤，群組停止。
        /// </summary>
        public string STA_GP_ERROR_STOP { get; set; }

        /// <summary>
        /// 群組正在運行。
        /// </summary>
        public string STA_GP_MOTION { get; set; }

        /// <summary>
        /// 不支援。
        /// </summary>
        public string STA_GP_AX_MOTION { get; set; }

        /// <summary>
        /// 群組正在執行Path運動。
        /// </summary>
        public string STA_GP_MOTION_PATH { get; set; }

        /// <summary>
        /// 群組暫停。
        /// </summary>
        public string STA_GP_PAUSE { get; set; }

        /// <summary>
        /// 群組忙碌中，前一個指令尚未處理完成。
        /// </summary>
        public string STA_GP_BUSY { get; set; }

        #endregion 群組狀態

        #region 群組速度

        /// <summary>
        /// 設定 / 取得此軸的初始速度 ( 起始速度)。
        /// </summary>
        public string PAR_GpVelLow { get; set; }

        /// <summary>
        /// 設定 / 取得該軸的運轉速度。
        /// </summary>
        public string PAR_GpVelHigh { get; set; }

        /// <summary>
        /// 設定 / 取得該軸的加速度。
        /// </summary>
        public string PAR_GpAcc { get; set; }

        /// <summary>
        /// 設定 / 取得該軸的減速度。
        /// </summary>
        public string PAR_GpDec { get; set; }

        /// <summary>
        /// 設定 / 取得速度曲線的類型：T/S 型曲線。
        /// </summary>
        public string PAR_GpJerk { get; set; }

        #endregion 群組速度
    }
}
