﻿using System;

namespace Calin.MC.Advantech.Models
{
    /// <summary>
    /// 解析後的軸狀態。
    /// </summary>
    public struct ParsedAxisState : IEquatable<ParsedAxisState>
    {
        /// <summary>
        /// 軸命令位置。
        /// </summary>
        public double CmdPosition;

        /// <summary>
        /// 軸實際位置。
        /// </summary>
        public double ActPosition;

        /// <summary>
        /// 軸當前狀態。
        /// </summary>
        public StateFlags StateFlags;

        /// <summary>
        /// 軸當前運動狀態。
        /// </summary>
        public MotionFlags MotionFlags;

        /// <summary>
        /// 軸的運動 I/O 狀態。
        /// </summary>
        public IoFlags IoFlags;

        public bool Equals(ParsedAxisState other)
            => StateFlags == other.StateFlags
            && MotionFlags == other.MotionFlags
            && IoFlags == other.IoFlags;

        public override bool Equals(object? obj)
            => obj is ParsedAxisState other && Equals(other);

        public override int GetHashCode()
            => ((int)StateFlags * 397) ^ ((int)MotionFlags * 17) ^ (int)IoFlags;

        public static bool operator ==(ParsedAxisState left, ParsedAxisState right) => left.Equals(right);

        public static bool operator !=(ParsedAxisState left, ParsedAxisState right) => !(left == right);
    }
}
