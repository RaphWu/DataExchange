﻿using System;

namespace Calin.MC.Advantech.Models
{
    [Flags]
    public enum MotionFlags : uint
    {
        Stop = 1 << 0,
        WaitERC = 1 << 2,
        CorrectBksh = 1 << 4,
        InFA = 1 << 6,
        InFL = 1 << 7,
        InACC = 1 << 8,
        InFH = 1 << 9,
        InDEC = 1 << 10,
        WaitINP = 1 << 11,
    }
}
