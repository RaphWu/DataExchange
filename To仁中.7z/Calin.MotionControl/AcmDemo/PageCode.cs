﻿namespace AcmDemo
{
    public enum PageCode
    {
        MainPanel,
        Manual,
        Home,
        P2P,
    }
}
