﻿using AcmDemo.Constants;

namespace AcmDemo.Models
{
    /// <summary>
    /// 軸配置。
    /// </summary>
    /// <remarks>這裡的是要儲存在磁碟的配置參數。</remarks>
    public sealed class AxisConfig
    {
        #region 共用(主控面板)

        public double VelLow = 2000.0;
        public double VelHigh = 8000.0;
        public double Acceleration = 100000.0;
        public double Deceleration = 100000.0;
        public double Jerk = 0.0;
        public AxisMovementMode AbsOrRel = AxisMovementMode.Absolute;

        #endregion 共用(主控面板)

        #region 復歸

        public uint HomeMode = 0;
        public uint Direction = 0;
        public uint SwitchMode = 0;
        public double CrossDistance = 10000.0;
        public int EzLevel = 0;
        public int OrgLevel = 0;
        public int HelLevel = 0;

        #endregion 復歸
    }
}
