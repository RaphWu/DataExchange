﻿using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace AcmDemo.Models
{
    /// <summary>
    /// UI 狀態模型。
    /// </summary>
    public class AcmParams : ObservableObject
    {
        #region 控制卡參數

        /// <summary>
        /// 目前指定的軸編號。
        /// </summary>
        public int AxisNo
        {
            get { return _axisNo; }
            set { SetProperty(ref _axisNo, value); }
        }
        private int _axisNo;

        /// <summary>
        /// 各軸配置。
        /// </summary>
        public ObservableCollection<AxisConfig> AxisConfigs
        {
            get { return _axisConfigs; }
            set { SetProperty(ref _axisConfigs, value); }
        }
        private ObservableCollection<AxisConfig> _axisConfigs = new ObservableCollection<AxisConfig>();

        /// <summary>
        /// 各軸狀態。
        /// </summary>
        public ObservableCollection<AxisStatus> AxisStatuses
        {
            get { return _axisStatuses; }
            set { SetProperty(ref _axisStatuses, value); }
        }
        private ObservableCollection<AxisStatus> _axisStatuses = new ObservableCollection<AxisStatus>();

        #endregion 控制卡參數

        #region 控制項啟用/停用

        /// <summary>
        /// 裝置是否啟用。
        /// </summary>
        public bool DeviceEnable
        {
            get { return _deviceEnable; }
            set { SetProperty(ref _deviceEnable, value); }
        }
        private bool _deviceEnable = false;

        #endregion 控制項啟用/停用
    }
}
