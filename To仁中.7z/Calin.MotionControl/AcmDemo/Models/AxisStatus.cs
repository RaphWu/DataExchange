﻿using AcmDemo.Constants;

namespace AcmDemo.Models
{
    /// <summary>
    /// 軸狀態。
    /// </summary>
    /// <remarks>這裡的是運行時期的各種狀態。</remarks>
    public class AxisStatus
    {
        #region 參數

        ///// <summary>
        ///// 軸名稱。
        ///// </summary>
        //public string Name { get; set; }

        /// <summary>
        /// 軸命令位置。
        /// </summary>
        public double CmdPosition;

        /// <summary>
        /// 軸實際位置。
        /// </summary>
        public double ActPosition;

        #endregion 參數

        #region 軸狀態

        public bool STA_AX_DISABLE { get; set; }        // 軸被停用，使用者可開啟並激活
        public bool STA_AX_READY { get; set; }          // 軸已準備就緒，等待新的指令
        public bool STA_AX_STOPPING { get; set; }       // 軸停止
        public bool STA_AX_ERROR_STOP { get; set; }     // 出現錯誤，軸停止
        public bool STA_AX_HOMING { get; set; }         // 軸正在執行返回原點運動
        public bool STA_AX_PTP_MOT { get; set; }        // 軸正在執行PTP運動
        public bool STA_AX_CONTI_MOT { get; set; }      // 軸正在執行連續運動
        public bool STA_AX_SYNC_MOT { get; set; }       // 軸在一個群組中，群組正在執行插補運動；或軸是一個從軸，正在執行E-cam/E-gear/Gantry運動
        public bool STA_AX_EXT_JOG { get; set; }        // 軸由外部訊號控制執行JOG模式運動中
        public bool STA_AX_EXT_MPG { get; set; }        // 軸由外部訊號控制。當外部訊號啟動時，軸將執行MPG模式運動
        public bool STA_AX_PAUSE { get; set; }          // 軸暫停
        public bool STA_AX_BUSY { get; set; }           // 軸忙碌中，前一個指令尚未處理完成
        public bool STA_AX_WAIT_DI { get; set; }        // 軸在等待指定的DI訊號
        public bool STA_AX_WAIT_PTP { get; set; }       // 軸在等待其他軸點對點運動完成
        public bool STA_AX_WAIT_VEL { get; set; }       // 軸在等待其他軸連續運動完成
        public bool STA_AX_EXT_JOG_READY { get; set; }  // 軸由外部訊號控制。當外部訊號啟動時，軸將執行JOG模式運動

        #endregion 軸狀態

        #region 軸運動狀態

        public bool Stop { get; set; }          // 停止
        public bool WaitERC { get; set; }       // 等待ERC完成
        public bool CorrectBksh { get; set; }   // 背隙補償
        public bool InFA { get; set; }          // 處於特定速度中=FA
        public bool InFL { get; set; }          // 處於低速中=FL
        public bool InACC { get; set; }         // 加速中
        public bool InFH { get; set; }          // 處於最大速度=FH
        public bool InDEC { get; set; }         // 減速中
        public bool WaitINP { get; set; }       // 到位等待

        #endregion 軸運動狀態

        #region 軸IO

        public bool RDY { get; set; }           // 針腳輸入
        public bool ALM { get; set; }           // 警報訊號輸入
        public bool LMT_Positive { get; set; }  // 限位開關+
        public bool LMT_Negative { get; set; }  // 限位開關-
        public bool ORG { get; set; }           // 原始開關
        public bool DIR { get; set; }           // DIR輸出
        public bool EMG { get; set; }           // 緊急訊號輸入
        public bool PCS { get; set; }           // PCS訊號輸入
        public bool ERC { get; set; }           // 輸出偏差計數器清除訊號至伺服馬達驅動
        public bool EZ { get; set; }            // 編碼器Z訊號
        public bool CLR { get; set; }           // 外部輸入至清除位置計數器
        public bool LTC { get; set; }           // 鎖存訊號輸入
        public bool SD { get; set; }            // 減速訊號輸入
        public bool INP { get; set; }           // 到位訊號輸入
        public bool SVON { get; set; }          // 伺服開啟（OUT6）
        public bool ALRM { get; set; }          // 警報重設輸出狀態
        public bool SLMT_Positive { get; set; } // 軟體限位+
        public bool SLMT_Negative { get; set; } // 軟體限位-
        public bool CMP { get; set; }           // 比較訊號
        public bool CAMDO { get; set; }         // 凸輪區間DO

        #endregion 軸IO
    }
}
