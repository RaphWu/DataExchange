﻿namespace AcmDemo
{
    /// <summary>
    /// ACM Demo 服務介面。
    /// </summary>
    public interface IDemoService
    {
        /// <summary>
        /// 顯示錯誤訊息。
        /// </summary>
        /// <param name="msg">附加訊息。</param>
        void ShowErrMsg(string msg);
    }
}
