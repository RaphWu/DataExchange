﻿using AcmDemo.Views;

namespace AcmDemo.Exts
{
    public static class ResourceExt
    {
        public static Image GetLocalResource(string key)
        {
            var rm = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            return (Image)rm.GetObject(key);
        }
    }
}
