﻿namespace AcmDemo.Views
{
    partial class P2PPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnMove = new System.Windows.Forms.Button();
            this.NumPosAbs = new System.Windows.Forms.NumericUpDown();
            this.NumPosRel = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosAbs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosRel)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.NumPosRel);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.NumPosAbs);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.BtnStop);
            this.groupBox1.Controls.Add(this.BtnMove);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(18, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(233, 133);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PTP 運動";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "絕對位置";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(128, 92);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(79, 25);
            this.BtnStop.TabIndex = 25;
            this.BtnStop.Text = "停止";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(27, 92);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(79, 25);
            this.BtnMove.TabIndex = 20;
            this.BtnMove.Text = "移動至目標";
            this.BtnMove.UseVisualStyleBackColor = true;
            this.BtnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // NumPosAbs
            // 
            this.NumPosAbs.DecimalPlaces = 3;
            this.NumPosAbs.Location = new System.Drawing.Point(82, 25);
            this.NumPosAbs.Name = "NumPosAbs";
            this.NumPosAbs.Size = new System.Drawing.Size(125, 23);
            this.NumPosAbs.TabIndex = 27;
            this.NumPosAbs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumPosAbs.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // NumPosRel
            // 
            this.NumPosRel.DecimalPlaces = 3;
            this.NumPosRel.Location = new System.Drawing.Point(82, 54);
            this.NumPosRel.Name = "NumPosRel";
            this.NumPosRel.Size = new System.Drawing.Size(125, 23);
            this.NumPosRel.TabIndex = 29;
            this.NumPosRel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 28;
            this.label1.Text = "相對位置";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // P2PPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "P2PPage";
            this.Size = new System.Drawing.Size(720, 475);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosAbs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumPosRel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private NumericUpDown NumPosAbs;
        private Label label10;
        private Button BtnStop;
        private Button BtnMove;
        private NumericUpDown NumPosRel;
        private Label label1;
    }
}
