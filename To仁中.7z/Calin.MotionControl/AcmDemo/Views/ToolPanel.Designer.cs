﻿namespace AcmDemo.Views
{
    partial class ToolPanel
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.DevicePanel = new System.Windows.Forms.GroupBox();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnServoOn = new System.Windows.Forms.Button();
            this.VelSetupPanel = new System.Windows.Forms.GroupBox();
            this.NumVelL = new System.Windows.Forms.NumericUpDown();
            this.NumVelH = new System.Windows.Forms.NumericUpDown();
            this.NumAcc = new System.Windows.Forms.NumericUpDown();
            this.NumDec = new System.Windows.Forms.NumericUpDown();
            this.BtnSetParam = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.RbTCurver = new System.Windows.Forms.RadioButton();
            this.RbSCurver = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.LbAxisList = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.StatePanel = new System.Windows.Forms.GroupBox();
            this.BtnResetPos = new System.Windows.Forms.Button();
            this.TbActPos = new System.Windows.Forms.TextBox();
            this.TbCmdPos = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.PbBusy = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.PbErrStop = new System.Windows.Forms.PictureBox();
            this.PbStop = new System.Windows.Forms.PictureBox();
            this.PbReady = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PBoxEz = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.PBoxHELNegative = new System.Windows.Forms.PictureBox();
            this.PBoxHELPositive = new System.Windows.Forms.PictureBox();
            this.PBoxOrg = new System.Windows.Forms.PictureBox();
            this.PBoxAlm = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.TboxCurrentState = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.ButtonPanel = new System.Windows.Forms.Panel();
            this.BtnStopEmg = new System.Windows.Forms.Button();
            this.BtnStopDec = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.RbRel = new System.Windows.Forms.RadioButton();
            this.RbAbs = new System.Windows.Forms.RadioButton();
            this.DevicePanel.SuspendLayout();
            this.VelSetupPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.StatePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbBusy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbErrStop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbStop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbReady)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxEz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxHELNegative)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxHELPositive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxOrg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxAlm)).BeginInit();
            this.ButtonPanel.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // DevicePanel
            // 
            this.DevicePanel.Controls.Add(this.BtnLoadCfg);
            this.DevicePanel.Controls.Add(this.label1);
            this.DevicePanel.Controls.Add(this.CbAvailableDevice);
            this.DevicePanel.Controls.Add(this.BtnOpenBoard);
            this.DevicePanel.Controls.Add(this.BtnCloseBoard);
            this.DevicePanel.Controls.Add(this.BtnServoOn);
            this.DevicePanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.DevicePanel.Location = new System.Drawing.Point(12, 6);
            this.DevicePanel.Margin = new System.Windows.Forms.Padding(4);
            this.DevicePanel.Name = "DevicePanel";
            this.DevicePanel.Padding = new System.Windows.Forms.Padding(4);
            this.DevicePanel.Size = new System.Drawing.Size(285, 131);
            this.DevicePanel.TabIndex = 46;
            this.DevicePanel.TabStop = false;
            this.DevicePanel.Text = "操作裝置";
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(162, 58);
            this.BtnLoadCfg.Margin = new System.Windows.Forms.Padding(4);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(100, 25);
            this.BtnLoadCfg.TabIndex = 32;
            this.BtnLoadCfg.Text = "載入CFG檔";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 13;
            this.label1.Text = "可用裝置";
            // 
            // CbAvailableDevice
            // 
            this.CbAvailableDevice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbAvailableDevice.FormattingEnabled = true;
            this.CbAvailableDevice.Location = new System.Drawing.Point(79, 22);
            this.CbAvailableDevice.Margin = new System.Windows.Forms.Padding(4);
            this.CbAvailableDevice.Name = "CbAvailableDevice";
            this.CbAvailableDevice.Size = new System.Drawing.Size(183, 24);
            this.CbAvailableDevice.TabIndex = 14;
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(22, 58);
            this.BtnOpenBoard.Margin = new System.Windows.Forms.Padding(4);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "控制卡開啟";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Enabled = false;
            this.BtnCloseBoard.Location = new System.Drawing.Point(22, 91);
            this.BtnCloseBoard.Margin = new System.Windows.Forms.Padding(4);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "控制卡關閉";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnServoOn
            // 
            this.BtnServoOn.Location = new System.Drawing.Point(162, 91);
            this.BtnServoOn.Margin = new System.Windows.Forms.Padding(4);
            this.BtnServoOn.Name = "BtnServoOn";
            this.BtnServoOn.Size = new System.Drawing.Size(100, 25);
            this.BtnServoOn.TabIndex = 17;
            this.BtnServoOn.Text = "Servo On";
            this.BtnServoOn.UseVisualStyleBackColor = true;
            this.BtnServoOn.Click += new System.EventHandler(this.BtnServoOn_Click);
            // 
            // VelSetupPanel
            // 
            this.VelSetupPanel.Controls.Add(this.NumVelL);
            this.VelSetupPanel.Controls.Add(this.NumVelH);
            this.VelSetupPanel.Controls.Add(this.NumAcc);
            this.VelSetupPanel.Controls.Add(this.NumDec);
            this.VelSetupPanel.Controls.Add(this.BtnSetParam);
            this.VelSetupPanel.Controls.Add(this.groupBox11);
            this.VelSetupPanel.Controls.Add(this.label16);
            this.VelSetupPanel.Controls.Add(this.label17);
            this.VelSetupPanel.Controls.Add(this.label18);
            this.VelSetupPanel.Controls.Add(this.label19);
            this.VelSetupPanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.VelSetupPanel.Location = new System.Drawing.Point(116, 145);
            this.VelSetupPanel.Margin = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Name = "VelSetupPanel";
            this.VelSetupPanel.Padding = new System.Windows.Forms.Padding(4);
            this.VelSetupPanel.Size = new System.Drawing.Size(181, 246);
            this.VelSetupPanel.TabIndex = 47;
            this.VelSetupPanel.TabStop = false;
            this.VelSetupPanel.Text = "速率設定 (PPU/sec)";
            // 
            // NumVelL
            // 
            this.NumVelL.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelL.Location = new System.Drawing.Point(72, 26);
            this.NumVelL.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelL.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelL.Name = "NumVelL";
            this.NumVelL.Size = new System.Drawing.Size(100, 23);
            this.NumVelL.TabIndex = 43;
            this.NumVelL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelL.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // NumVelH
            // 
            this.NumVelH.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumVelH.Location = new System.Drawing.Point(72, 57);
            this.NumVelH.Maximum = new decimal(new int[] {
            20000000,
            0,
            0,
            0});
            this.NumVelH.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumVelH.Name = "NumVelH";
            this.NumVelH.Size = new System.Drawing.Size(100, 23);
            this.NumVelH.TabIndex = 42;
            this.NumVelH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumVelH.Value = new decimal(new int[] {
            8000,
            0,
            0,
            0});
            // 
            // NumAcc
            // 
            this.NumAcc.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumAcc.Location = new System.Drawing.Point(72, 88);
            this.NumAcc.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumAcc.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumAcc.Name = "NumAcc";
            this.NumAcc.Size = new System.Drawing.Size(100, 23);
            this.NumAcc.TabIndex = 41;
            this.NumAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumAcc.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // NumDec
            // 
            this.NumDec.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumDec.Location = new System.Drawing.Point(72, 117);
            this.NumDec.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.NumDec.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumDec.Name = "NumDec";
            this.NumDec.Size = new System.Drawing.Size(100, 23);
            this.NumDec.TabIndex = 40;
            this.NumDec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumDec.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // BtnSetParam
            // 
            this.BtnSetParam.Location = new System.Drawing.Point(39, 210);
            this.BtnSetParam.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSetParam.Name = "BtnSetParam";
            this.BtnSetParam.Size = new System.Drawing.Size(100, 25);
            this.BtnSetParam.TabIndex = 39;
            this.BtnSetParam.Text = "設定/取得參數";
            this.BtnSetParam.UseVisualStyleBackColor = true;
            this.BtnSetParam.Click += new System.EventHandler(this.BtnSetParam_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.RbTCurver);
            this.groupBox11.Controls.Add(this.RbSCurver);
            this.groupBox11.Location = new System.Drawing.Point(8, 150);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(164, 53);
            this.groupBox11.TabIndex = 37;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "速度曲線類型";
            // 
            // RbTCurver
            // 
            this.RbTCurver.AutoSize = true;
            this.RbTCurver.Checked = true;
            this.RbTCurver.Location = new System.Drawing.Point(10, 23);
            this.RbTCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbTCurver.Name = "RbTCurver";
            this.RbTCurver.Size = new System.Drawing.Size(68, 20);
            this.RbTCurver.TabIndex = 35;
            this.RbTCurver.TabStop = true;
            this.RbTCurver.Text = "T型曲線";
            this.RbTCurver.UseVisualStyleBackColor = true;
            // 
            // RbSCurver
            // 
            this.RbSCurver.AutoSize = true;
            this.RbSCurver.Location = new System.Drawing.Point(88, 23);
            this.RbSCurver.Margin = new System.Windows.Forms.Padding(4);
            this.RbSCurver.Name = "RbSCurver";
            this.RbSCurver.Size = new System.Drawing.Size(68, 20);
            this.RbSCurver.TabIndex = 36;
            this.RbSCurver.Text = "S型曲線";
            this.RbSCurver.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(20, 121);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 16);
            this.label16.TabIndex = 32;
            this.label16.Text = "減速度";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 90);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 16);
            this.label17.TabIndex = 30;
            this.label17.Text = "加速度";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 59);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 16);
            this.label18.TabIndex = 28;
            this.label18.Text = "運轉速度";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 28);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 16);
            this.label19.TabIndex = 26;
            this.label19.Text = "起始速度";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LbAxisList
            // 
            this.LbAxisList.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LbAxisList.FormattingEnabled = true;
            this.LbAxisList.ItemHeight = 16;
            this.LbAxisList.Location = new System.Drawing.Point(12, 165);
            this.LbAxisList.Margin = new System.Windows.Forms.Padding(4);
            this.LbAxisList.Name = "LbAxisList";
            this.LbAxisList.Size = new System.Drawing.Size(96, 164);
            this.LbAxisList.TabIndex = 57;
            this.LbAxisList.SelectedIndexChanged += new System.EventHandler(this.LbAxisList_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 146);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 58;
            this.label2.Text = "軸選擇";
            // 
            // StatePanel
            // 
            this.StatePanel.Controls.Add(this.BtnResetPos);
            this.StatePanel.Controls.Add(this.TbActPos);
            this.StatePanel.Controls.Add(this.TbCmdPos);
            this.StatePanel.Controls.Add(this.label10);
            this.StatePanel.Controls.Add(this.label9);
            this.StatePanel.Controls.Add(this.label4);
            this.StatePanel.Controls.Add(this.PbBusy);
            this.StatePanel.Controls.Add(this.label5);
            this.StatePanel.Controls.Add(this.label6);
            this.StatePanel.Controls.Add(this.label7);
            this.StatePanel.Controls.Add(this.label8);
            this.StatePanel.Controls.Add(this.pictureBox2);
            this.StatePanel.Controls.Add(this.PbErrStop);
            this.StatePanel.Controls.Add(this.PbStop);
            this.StatePanel.Controls.Add(this.PbReady);
            this.StatePanel.Controls.Add(this.label3);
            this.StatePanel.Controls.Add(this.PBoxEz);
            this.StatePanel.Controls.Add(this.label15);
            this.StatePanel.Controls.Add(this.label14);
            this.StatePanel.Controls.Add(this.label13);
            this.StatePanel.Controls.Add(this.label12);
            this.StatePanel.Controls.Add(this.PBoxHELNegative);
            this.StatePanel.Controls.Add(this.PBoxHELPositive);
            this.StatePanel.Controls.Add(this.PBoxOrg);
            this.StatePanel.Controls.Add(this.PBoxAlm);
            this.StatePanel.Controls.Add(this.label20);
            this.StatePanel.Controls.Add(this.BtnResetErr);
            this.StatePanel.Controls.Add(this.TboxCurrentState);
            this.StatePanel.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.StatePanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.StatePanel.Location = new System.Drawing.Point(305, 6);
            this.StatePanel.Margin = new System.Windows.Forms.Padding(4);
            this.StatePanel.Name = "StatePanel";
            this.StatePanel.Padding = new System.Windows.Forms.Padding(4);
            this.StatePanel.Size = new System.Drawing.Size(201, 342);
            this.StatePanel.TabIndex = 59;
            this.StatePanel.TabStop = false;
            this.StatePanel.Text = "目前狀態";
            // 
            // BtnResetPos
            // 
            this.BtnResetPos.Location = new System.Drawing.Point(111, 302);
            this.BtnResetPos.Margin = new System.Windows.Forms.Padding(4);
            this.BtnResetPos.Name = "BtnResetPos";
            this.BtnResetPos.Size = new System.Drawing.Size(74, 25);
            this.BtnResetPos.TabIndex = 80;
            this.BtnResetPos.Text = "位置歸零";
            this.BtnResetPos.UseVisualStyleBackColor = true;
            this.BtnResetPos.Click += new System.EventHandler(this.BtnResetPos_Click);
            // 
            // TbActPos
            // 
            this.TbActPos.Location = new System.Drawing.Point(75, 218);
            this.TbActPos.Name = "TbActPos";
            this.TbActPos.ReadOnly = true;
            this.TbActPos.Size = new System.Drawing.Size(110, 23);
            this.TbActPos.TabIndex = 79;
            this.TbActPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TbCmdPos
            // 
            this.TbCmdPos.Location = new System.Drawing.Point(75, 189);
            this.TbCmdPos.Name = "TbCmdPos";
            this.TbCmdPos.ReadOnly = true;
            this.TbCmdPos.Size = new System.Drawing.Size(110, 23);
            this.TbCmdPos.TabIndex = 78;
            this.TbCmdPos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 222);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 16);
            this.label10.TabIndex = 77;
            this.label10.Text = "實際位置";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 193);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 16);
            this.label9.TabIndex = 76;
            this.label9.Text = "命令位置";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(133, 62);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 16);
            this.label4.TabIndex = 75;
            this.label4.Text = "Busy";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PbBusy
            // 
            this.PbBusy.BackColor = System.Drawing.Color.Gray;
            this.PbBusy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbBusy.Location = new System.Drawing.Point(111, 61);
            this.PbBusy.Margin = new System.Windows.Forms.Padding(4);
            this.PbBusy.Name = "PbBusy";
            this.PbBusy.Size = new System.Drawing.Size(18, 18);
            this.PbBusy.TabIndex = 74;
            this.PbBusy.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(133, 155);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 16);
            this.label5.TabIndex = 73;
            this.label5.Text = "X";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(133, 124);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 16);
            this.label6.TabIndex = 72;
            this.label6.Text = "ErrStop";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(133, 93);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 16);
            this.label7.TabIndex = 71;
            this.label7.Text = "Stop";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(133, 31);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 16);
            this.label8.TabIndex = 70;
            this.label8.Text = "Ready";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Gray;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(111, 154);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(18, 18);
            this.pictureBox2.TabIndex = 69;
            this.pictureBox2.TabStop = false;
            // 
            // PbErrStop
            // 
            this.PbErrStop.BackColor = System.Drawing.Color.Gray;
            this.PbErrStop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbErrStop.Location = new System.Drawing.Point(111, 123);
            this.PbErrStop.Margin = new System.Windows.Forms.Padding(4);
            this.PbErrStop.Name = "PbErrStop";
            this.PbErrStop.Size = new System.Drawing.Size(18, 18);
            this.PbErrStop.TabIndex = 68;
            this.PbErrStop.TabStop = false;
            // 
            // PbStop
            // 
            this.PbStop.BackColor = System.Drawing.Color.Gray;
            this.PbStop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbStop.Location = new System.Drawing.Point(111, 92);
            this.PbStop.Margin = new System.Windows.Forms.Padding(4);
            this.PbStop.Name = "PbStop";
            this.PbStop.Size = new System.Drawing.Size(18, 18);
            this.PbStop.TabIndex = 67;
            this.PbStop.TabStop = false;
            // 
            // PbReady
            // 
            this.PbReady.BackColor = System.Drawing.Color.Gray;
            this.PbReady.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PbReady.Location = new System.Drawing.Point(111, 30);
            this.PbReady.Margin = new System.Windows.Forms.Padding(4);
            this.PbReady.Name = "PbReady";
            this.PbReady.Size = new System.Drawing.Size(18, 18);
            this.PbReady.TabIndex = 66;
            this.PbReady.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 61);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 16);
            this.label3.TabIndex = 65;
            this.label3.Text = "Z相";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PBoxEz
            // 
            this.PBoxEz.BackColor = System.Drawing.Color.Gray;
            this.PBoxEz.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxEz.Location = new System.Drawing.Point(29, 60);
            this.PBoxEz.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxEz.Name = "PBoxEz";
            this.PBoxEz.Size = new System.Drawing.Size(18, 18);
            this.PBoxEz.TabIndex = 64;
            this.PBoxEz.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(51, 154);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 16);
            this.label15.TabIndex = 63;
            this.label15.Text = "負極限";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(51, 123);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 16);
            this.label14.TabIndex = 62;
            this.label14.Text = "正極限";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(51, 92);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 16);
            this.label13.TabIndex = 61;
            this.label13.Text = "原點";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(51, 30);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 16);
            this.label12.TabIndex = 60;
            this.label12.Text = "警報";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PBoxHELNegative
            // 
            this.PBoxHELNegative.BackColor = System.Drawing.Color.Gray;
            this.PBoxHELNegative.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxHELNegative.Location = new System.Drawing.Point(29, 153);
            this.PBoxHELNegative.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxHELNegative.Name = "PBoxHELNegative";
            this.PBoxHELNegative.Size = new System.Drawing.Size(18, 18);
            this.PBoxHELNegative.TabIndex = 59;
            this.PBoxHELNegative.TabStop = false;
            // 
            // PBoxHELPositive
            // 
            this.PBoxHELPositive.BackColor = System.Drawing.Color.Gray;
            this.PBoxHELPositive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxHELPositive.Location = new System.Drawing.Point(29, 122);
            this.PBoxHELPositive.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxHELPositive.Name = "PBoxHELPositive";
            this.PBoxHELPositive.Size = new System.Drawing.Size(18, 18);
            this.PBoxHELPositive.TabIndex = 58;
            this.PBoxHELPositive.TabStop = false;
            // 
            // PBoxOrg
            // 
            this.PBoxOrg.BackColor = System.Drawing.Color.Gray;
            this.PBoxOrg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxOrg.Location = new System.Drawing.Point(29, 91);
            this.PBoxOrg.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxOrg.Name = "PBoxOrg";
            this.PBoxOrg.Size = new System.Drawing.Size(18, 18);
            this.PBoxOrg.TabIndex = 57;
            this.PBoxOrg.TabStop = false;
            // 
            // PBoxAlm
            // 
            this.PBoxAlm.BackColor = System.Drawing.Color.Gray;
            this.PBoxAlm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PBoxAlm.Location = new System.Drawing.Point(29, 29);
            this.PBoxAlm.Margin = new System.Windows.Forms.Padding(4);
            this.PBoxAlm.Name = "PBoxAlm";
            this.PBoxAlm.Size = new System.Drawing.Size(18, 18);
            this.PBoxAlm.TabIndex = 56;
            this.PBoxAlm.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(25, 252);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 16);
            this.label20.TabIndex = 33;
            this.label20.Text = "狀態";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(20, 302);
            this.BtnResetErr.Margin = new System.Windows.Forms.Padding(4);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(74, 25);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "異常重置";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // TboxCurrentState
            // 
            this.TboxCurrentState.Location = new System.Drawing.Point(20, 271);
            this.TboxCurrentState.Margin = new System.Windows.Forms.Padding(4);
            this.TboxCurrentState.Name = "TboxCurrentState";
            this.TboxCurrentState.ReadOnly = true;
            this.TboxCurrentState.Size = new System.Drawing.Size(165, 23);
            this.TboxCurrentState.TabIndex = 30;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(18, 362);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(86, 20);
            this.checkBox1.TabIndex = 60;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(18, 388);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(86, 20);
            this.checkBox2.TabIndex = 61;
            this.checkBox2.Text = "checkBox2";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // ButtonPanel
            // 
            this.ButtonPanel.Controls.Add(this.BtnStopEmg);
            this.ButtonPanel.Controls.Add(this.BtnStopDec);
            this.ButtonPanel.Location = new System.Drawing.Point(305, 355);
            this.ButtonPanel.Name = "ButtonPanel";
            this.ButtonPanel.Size = new System.Drawing.Size(200, 97);
            this.ButtonPanel.TabIndex = 68;
            // 
            // BtnStopEmg
            // 
            this.BtnStopEmg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnStopEmg.BackColor = System.Drawing.Color.LightSalmon;
            this.BtnStopEmg.Location = new System.Drawing.Point(47, 56);
            this.BtnStopEmg.Margin = new System.Windows.Forms.Padding(4);
            this.BtnStopEmg.Name = "BtnStopEmg";
            this.BtnStopEmg.Size = new System.Drawing.Size(110, 30);
            this.BtnStopEmg.TabIndex = 69;
            this.BtnStopEmg.Text = "緊急停止";
            this.BtnStopEmg.UseVisualStyleBackColor = false;
            this.BtnStopEmg.Click += new System.EventHandler(this.BtnStopEmg_Click);
            // 
            // BtnStopDec
            // 
            this.BtnStopDec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnStopDec.Location = new System.Drawing.Point(47, 12);
            this.BtnStopDec.Margin = new System.Windows.Forms.Padding(4);
            this.BtnStopDec.Name = "BtnStopDec";
            this.BtnStopDec.Size = new System.Drawing.Size(110, 30);
            this.BtnStopDec.TabIndex = 68;
            this.BtnStopDec.Text = "減速停止";
            this.BtnStopDec.UseVisualStyleBackColor = true;
            this.BtnStopDec.Click += new System.EventHandler(this.BtnStopDec_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.RbRel);
            this.groupBox10.Controls.Add(this.RbAbs);
            this.groupBox10.Location = new System.Drawing.Point(116, 399);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(181, 53);
            this.groupBox10.TabIndex = 69;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "移動模式";
            // 
            // RbRel
            // 
            this.RbRel.AutoSize = true;
            this.RbRel.Location = new System.Drawing.Point(88, 23);
            this.RbRel.Margin = new System.Windows.Forms.Padding(4);
            this.RbRel.Name = "RbRel";
            this.RbRel.Size = new System.Drawing.Size(73, 20);
            this.RbRel.TabIndex = 35;
            this.RbRel.Text = "相對位置";
            this.RbRel.UseVisualStyleBackColor = true;
            // 
            // RbAbs
            // 
            this.RbAbs.AutoSize = true;
            this.RbAbs.Checked = true;
            this.RbAbs.Location = new System.Drawing.Point(10, 23);
            this.RbAbs.Margin = new System.Windows.Forms.Padding(4);
            this.RbAbs.Name = "RbAbs";
            this.RbAbs.Size = new System.Drawing.Size(73, 20);
            this.RbAbs.TabIndex = 36;
            this.RbAbs.TabStop = true;
            this.RbAbs.Text = "絕對位置";
            this.RbAbs.UseVisualStyleBackColor = true;
            // 
            // ToolPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 462);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.ButtonPanel);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.StatePanel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LbAxisList);
            this.Controls.Add(this.VelSetupPanel);
            this.Controls.Add(this.DevicePanel);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ToolPanel";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "主控面板";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainPanel_FormClosing);
            this.DevicePanel.ResumeLayout(false);
            this.DevicePanel.PerformLayout();
            this.VelSetupPanel.ResumeLayout(false);
            this.VelSetupPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumVelH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumAcc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDec)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.StatePanel.ResumeLayout(false);
            this.StatePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbBusy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbErrStop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbStop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbReady)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxEz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxHELNegative)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxHELPositive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxOrg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBoxAlm)).EndInit();
            this.ButtonPanel.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox DevicePanel;
        private Button BtnLoadCfg;
        private Label label1;
        private ComboBox CbAvailableDevice;
        private Button BtnOpenBoard;
        private Button BtnCloseBoard;
        private Button BtnServoOn;
        private GroupBox VelSetupPanel;
        private Button BtnSetParam;
        private GroupBox groupBox11;
        public RadioButton RbTCurver;
        public RadioButton RbSCurver;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private ListBox LbAxisList;
        private Label label2;
        private GroupBox StatePanel;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private PictureBox PBoxHELNegative;
        private PictureBox PBoxHELPositive;
        private PictureBox PBoxOrg;
        private PictureBox PBoxAlm;
        private Label label20;
        private Button BtnResetErr;
        private TextBox TboxCurrentState;
        private Label label3;
        private PictureBox PBoxEz;
        private NumericUpDown NumVelL;
        private NumericUpDown NumVelH;
        private NumericUpDown NumAcc;
        private NumericUpDown NumDec;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private Label label4;
        private PictureBox PbBusy;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private PictureBox pictureBox2;
        private PictureBox PbErrStop;
        private PictureBox PbStop;
        private PictureBox PbReady;
        private Panel ButtonPanel;
        private Button BtnStopEmg;
        private Button BtnStopDec;
        private TextBox TbActPos;
        private TextBox TbCmdPos;
        private Label label10;
        private Label label9;
        private Button BtnResetPos;
        private GroupBox groupBox10;
        public RadioButton RbRel;
        public RadioButton RbAbs;
    }
}
