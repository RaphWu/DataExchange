﻿namespace AcmDemo.Views
{
    partial class HomePage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonStop = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.buttonGo = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxSwitchMode = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButtonHELHigh = new System.Windows.Forms.RadioButton();
            this.radioButtonHELLow = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButtonORGHigh = new System.Windows.Forms.RadioButton();
            this.radioButtonORGLow = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButtonEZLow = new System.Windows.Forms.RadioButton();
            this.radioButtonEZHigh = new System.Windows.Forms.RadioButton();
            this.comboBoxMode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxDir = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.buttonStop);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.buttonGo);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.comboBoxSwitchMode);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.comboBoxMode);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.CmbAxes);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBoxDir);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(15, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(286, 400);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "原點復歸";
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(153, 355);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(82, 25);
            this.buttonStop.TabIndex = 39;
            this.buttonStop.Text = "停止";
            this.buttonStop.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(216, 325);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 16);
            this.label10.TabIndex = 41;
            this.label10.Text = "PPU";
            // 
            // buttonGo
            // 
            this.buttonGo.Location = new System.Drawing.Point(35, 355);
            this.buttonGo.Name = "buttonGo";
            this.buttonGo.Size = new System.Drawing.Size(82, 25);
            this.buttonGo.TabIndex = 38;
            this.buttonGo.Text = "復歸";
            this.buttonGo.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(33, 324);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 16);
            this.label9.TabIndex = 40;
            this.label9.Text = "跨越距離";
            // 
            // comboBoxSwitchMode
            // 
            this.comboBoxSwitchMode.FormattingEnabled = true;
            this.comboBoxSwitchMode.Items.AddRange(new object[] {
            "Level On",
            "Level Off",
            "Edge On",
            "Edge Off"});
            this.comboBoxSwitchMode.Location = new System.Drawing.Point(91, 294);
            this.comboBoxSwitchMode.Name = "comboBoxSwitchMode";
            this.comboBoxSwitchMode.Size = new System.Drawing.Size(162, 24);
            this.comboBoxSwitchMode.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 298);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 16);
            this.label5.TabIndex = 38;
            this.label5.Text = "停止模式";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(13, 102);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(255, 186);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "屬性設定";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButtonHELHigh);
            this.groupBox6.Controls.Add(this.radioButtonHELLow);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox6.Location = new System.Drawing.Point(6, 121);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(230, 45);
            this.groupBox6.TabIndex = 39;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "極限信號邏輯";
            // 
            // radioButtonHELHigh
            // 
            this.radioButtonHELHigh.AutoSize = true;
            this.radioButtonHELHigh.Location = new System.Drawing.Point(122, 10);
            this.radioButtonHELHigh.Name = "radioButtonHELHigh";
            this.radioButtonHELHigh.Size = new System.Drawing.Size(85, 20);
            this.radioButtonHELHigh.TabIndex = 40;
            this.radioButtonHELHigh.Text = "高電位觸發";
            this.radioButtonHELHigh.UseVisualStyleBackColor = true;
            // 
            // radioButtonHELLow
            // 
            this.radioButtonHELLow.AutoSize = true;
            this.radioButtonHELLow.Checked = true;
            this.radioButtonHELLow.Location = new System.Drawing.Point(19, 10);
            this.radioButtonHELLow.Name = "radioButtonHELLow";
            this.radioButtonHELLow.Size = new System.Drawing.Size(85, 20);
            this.radioButtonHELLow.TabIndex = 41;
            this.radioButtonHELLow.TabStop = true;
            this.radioButtonHELLow.Text = "低電位觸發";
            this.radioButtonHELLow.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButtonORGHigh);
            this.groupBox4.Controls.Add(this.radioButtonORGLow);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(6, 70);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(230, 45);
            this.groupBox4.TabIndex = 39;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "原點信號邏輯";
            // 
            // radioButtonORGHigh
            // 
            this.radioButtonORGHigh.AutoSize = true;
            this.radioButtonORGHigh.Location = new System.Drawing.Point(122, 10);
            this.radioButtonORGHigh.Name = "radioButtonORGHigh";
            this.radioButtonORGHigh.Size = new System.Drawing.Size(85, 20);
            this.radioButtonORGHigh.TabIndex = 42;
            this.radioButtonORGHigh.Text = "高電位觸發";
            this.radioButtonORGHigh.UseVisualStyleBackColor = true;
            // 
            // radioButtonORGLow
            // 
            this.radioButtonORGLow.AutoSize = true;
            this.radioButtonORGLow.Checked = true;
            this.radioButtonORGLow.Location = new System.Drawing.Point(19, 10);
            this.radioButtonORGLow.Name = "radioButtonORGLow";
            this.radioButtonORGLow.Size = new System.Drawing.Size(85, 20);
            this.radioButtonORGLow.TabIndex = 43;
            this.radioButtonORGLow.TabStop = true;
            this.radioButtonORGLow.Text = "低電位觸發";
            this.radioButtonORGLow.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButtonEZLow);
            this.groupBox3.Controls.Add(this.radioButtonEZHigh);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(6, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(230, 45);
            this.groupBox3.TabIndex = 38;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Z信號邏輯";
            // 
            // radioButtonEZLow
            // 
            this.radioButtonEZLow.AutoSize = true;
            this.radioButtonEZLow.Checked = true;
            this.radioButtonEZLow.Location = new System.Drawing.Point(19, 12);
            this.radioButtonEZLow.Name = "radioButtonEZLow";
            this.radioButtonEZLow.Size = new System.Drawing.Size(85, 20);
            this.radioButtonEZLow.TabIndex = 39;
            this.radioButtonEZLow.TabStop = true;
            this.radioButtonEZLow.Text = "低電位觸發";
            this.radioButtonEZLow.UseVisualStyleBackColor = true;
            // 
            // radioButtonEZHigh
            // 
            this.radioButtonEZHigh.AutoSize = true;
            this.radioButtonEZHigh.Location = new System.Drawing.Point(122, 12);
            this.radioButtonEZHigh.Name = "radioButtonEZHigh";
            this.radioButtonEZHigh.Size = new System.Drawing.Size(85, 20);
            this.radioButtonEZHigh.TabIndex = 38;
            this.radioButtonEZHigh.Text = "高電位觸發";
            this.radioButtonEZHigh.UseVisualStyleBackColor = true;
            // 
            // comboBoxMode
            // 
            this.comboBoxMode.FormattingEnabled = true;
            this.comboBoxMode.Items.AddRange(new object[] {
            "MODE1_Abs",
            "MODE2_Lmt",
            "MODE3_Ref",
            "MODE4_Abs_Ref",
            "MODE5_Abs_NegRef",
            "MODE6_Lmt_Ref",
            "MODE7_AbsSearch",
            "MODE8_LmtSearch",
            "MODE9_AbsSearch_Ref",
            "MODE10_AbsSearch_NegRef",
            "MODE11_LmtSearch_Ref",
            "MODE12_AbsSearchReFind",
            "MODE13_LmtSearchReFind",
            "MODE14_AbsSearchReFind_Ref",
            "MODE15_AbsSearchReFind_NegRef",
            "MODE16_LmtSearchReFind_Ref"});
            this.comboBoxMode.Location = new System.Drawing.Point(61, 60);
            this.comboBoxMode.Name = "comboBoxMode";
            this.comboBoxMode.Size = new System.Drawing.Size(207, 24);
            this.comboBoxMode.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 16);
            this.label4.TabIndex = 22;
            this.label4.Text = "模式";
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(120, 10);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(148, 24);
            this.CmbAxes.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(98, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "軸";
            // 
            // comboBoxDir
            // 
            this.comboBoxDir.FormattingEnabled = true;
            this.comboBoxDir.Items.AddRange(new object[] {
            "Positive Direction",
            "Negative Direction"});
            this.comboBoxDir.Location = new System.Drawing.Point(120, 35);
            this.comboBoxDir.Name = "comboBoxDir";
            this.comboBoxDir.Size = new System.Drawing.Size(148, 24);
            this.comboBoxDir.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "方向";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(91, 322);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 23);
            this.numericUpDown1.TabIndex = 42;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "HomePage";
            this.Size = new System.Drawing.Size(528, 475);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private Button buttonStop;
        private Label label10;
        private Button buttonGo;
        private Label label9;
        private ComboBox comboBoxSwitchMode;
        private Label label5;
        private GroupBox groupBox2;
        private GroupBox groupBox6;
        private RadioButton radioButtonHELHigh;
        private RadioButton radioButtonHELLow;
        private GroupBox groupBox4;
        private RadioButton radioButtonORGHigh;
        private RadioButton radioButtonORGLow;
        private GroupBox groupBox3;
        private RadioButton radioButtonEZLow;
        private RadioButton radioButtonEZHigh;
        private ComboBox comboBoxMode;
        private Label label4;
        private ComboBox CmbAxes;
        private Label label2;
        private ComboBox comboBoxDir;
        private Label label3;
        private NumericUpDown numericUpDown1;
    }
}
