using AcmDemo.Views;
using Autofac;
using Calin.MC.Advantech.Contracts;
using Calin.WinForm.Navigation;

namespace AcmDemo
{
    public partial class MainForm : Form
    {
        #region Fields

        private readonly ILifetimeScope _rootScope;
        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        private ToolPanel _toolPanel = null;
        private readonly string _btnToolPanelOpenCaption = "�}�ұ���O";
        private readonly string _btnToolPanelCloseCaption = "��������O";

        #endregion Fields

        public MainForm(
            ILifetimeScope lifetimeScope,
            IRegionManager regionManager,
            INavigationService navigationService,
            IDemoService demoService,
            IAcm acm)
        {
            InitializeComponent();

            _rootScope = lifetimeScope;
            _region = regionManager;
            _nav = navigationService;
            _demoService = demoService;
            _acm = acm;

            CommonStyle.SetMenuRadioButton(MenuManual);
            CommonStyle.SetMenuRadioButton(MenuP2P);
            CommonStyle.SetMenuRadioButton(MenuHome);
        }

        #region Form Events

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_toolPanel != null && !_toolPanel.IsDisposed)
                _toolPanel.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            _region.RegisterRegion(nameof(ContentPanel), view =>
            {
                ContentPanel.SuspendLayout();
                ContentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    ContentPanel.Controls.Add(control);
                }
                ContentPanel.ResumeLayout();
            });
        }

        #endregion Form Events

        #region Navigation

        private void SwitchPage(PageCode pageCode)
        {
            string regionName = nameof(ContentPanel);
            switch (pageCode)
            {
                case PageCode.Manual:
                    _nav.NavigateTo<ManualPage>(regionName, (int)PageCode.Manual);
                    break;
                case PageCode.Home:
                    _nav.NavigateTo<HomePage>(regionName, (int)PageCode.Home);
                    break;
                case PageCode.P2P:
                    _nav.NavigateTo<P2PPage>(regionName, (int)PageCode.P2P);
                    break;
                default:
                    throw new NotImplementedException($"�|����@�����N�X {pageCode} �������޿�C");
            }
        }

        #endregion Navigation

        #region Menu Control Events

        private void MenuManual_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Manual);
        }

        private void MenuHome_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Home);
        }

        private void MenuP2P_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.P2P);
        }

        #endregion Menu Control Events

        #region Control Events


        #endregion Control Events

        private void BtnToolPanel_Click(object sender, EventArgs e)
        {
            if (_toolPanel == null)
            {
                _toolPanel = _rootScope.Resolve<ToolPanel>();
                _toolPanel.Owner = this;

                int left = this.Left - _toolPanel.Width;
                _toolPanel.Show();
                _toolPanel.Top = this.Top;
                _toolPanel.Left = left;

                _toolPanel.ToolPanelHidden += ToolPanel_ToolPanelHidden;
                BtnToolPanel.Text = _btnToolPanelCloseCaption;
                return;
            }

            if (_toolPanel.Visible)
            {
                _toolPanel.Hide();
                BtnToolPanel.Text = _btnToolPanelOpenCaption;
            }
            else
            {
                _toolPanel.Show();
                BtnToolPanel.Text = _btnToolPanelCloseCaption;
            }
        }

        private void ToolPanel_ToolPanelHidden(object sender, EventArgs e)
        {
            BtnToolPanel.Text = _btnToolPanelOpenCaption;
        }
    }
}
