﻿using AcmDemo.Constants;
using AcmDemo.Models;
using AcmDemo.Services;
using Calin.MC.Advantech.Contracts;
using Calin.WinForm.Navigation;

namespace AcmDemo.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class ManualPage : UserControl, INavigationAware
    {
        #region Fields

        private readonly IDemoService _demoService;
        private readonly IAcm _acm;

        private readonly AcmParams _acmParams;

        #endregion Fields

        #region Properties



        #endregion Properties

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            _acm.SetExtDrive(_acmParams.AxisNo, RbJog.Checked
                ? (ushort)ExtDriveMode.Jog
                : (ushort)ExtDriveMode.MPG);
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            _acm.SetExtDrive(_acmParams.AxisNo, (ushort)ExtDriveMode.Disable);
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            return true;
        }

        #endregion INavigationAware

        #region Constructor

        public ManualPage(IDemoService demoService, IAcm acm, AcmParams acmParams)
        {
            _demoService = demoService;
            _acm = acm;
            _acmParams = acmParams;

            InitializeComponent();
        }

        #endregion Constructor

        #region Form Event




        #endregion Form Event
    }
}
