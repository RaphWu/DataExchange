﻿namespace AcmDemo
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Tlp = new System.Windows.Forms.TableLayoutPanel();
            this.FlpLeftMenu = new System.Windows.Forms.FlowLayoutPanel();
            this.MenuHome = new System.Windows.Forms.RadioButton();
            this.MenuManual = new System.Windows.Forms.RadioButton();
            this.MenuP2P = new System.Windows.Forms.RadioButton();
            this.MenuIO = new System.Windows.Forms.RadioButton();
            this.ContentPanel = new System.Windows.Forms.Panel();
            this.BtnToolPanel = new System.Windows.Forms.Button();
            this.Tlp.SuspendLayout();
            this.FlpLeftMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tlp
            // 
            this.Tlp.ColumnCount = 2;
            this.Tlp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Tlp.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 131F));
            this.Tlp.Controls.Add(this.FlpLeftMenu, 0, 1);
            this.Tlp.Controls.Add(this.ContentPanel, 0, 0);
            this.Tlp.Controls.Add(this.BtnToolPanel, 1, 1);
            this.Tlp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tlp.Location = new System.Drawing.Point(0, 0);
            this.Tlp.Name = "Tlp";
            this.Tlp.RowCount = 2;
            this.Tlp.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.Tlp.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.Tlp.Size = new System.Drawing.Size(715, 541);
            this.Tlp.TabIndex = 48;
            // 
            // FlpLeftMenu
            // 
            this.FlpLeftMenu.Controls.Add(this.MenuHome);
            this.FlpLeftMenu.Controls.Add(this.MenuManual);
            this.FlpLeftMenu.Controls.Add(this.MenuP2P);
            this.FlpLeftMenu.Controls.Add(this.MenuIO);
            this.FlpLeftMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FlpLeftMenu.Location = new System.Drawing.Point(3, 504);
            this.FlpLeftMenu.Name = "FlpLeftMenu";
            this.FlpLeftMenu.Padding = new System.Windows.Forms.Padding(10, 3, 0, 3);
            this.FlpLeftMenu.Size = new System.Drawing.Size(578, 34);
            this.FlpLeftMenu.TabIndex = 49;
            // 
            // MenuHome
            // 
            this.MenuHome.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuHome.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuHome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.MenuHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuHome.Location = new System.Drawing.Point(19, 3);
            this.MenuHome.Margin = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.MenuHome.Name = "MenuHome";
            this.MenuHome.Size = new System.Drawing.Size(90, 30);
            this.MenuHome.TabIndex = 2;
            this.MenuHome.Text = "原點復歸";
            this.MenuHome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuHome.UseVisualStyleBackColor = true;
            this.MenuHome.Click += new System.EventHandler(this.MenuHome_Click);
            // 
            // MenuManual
            // 
            this.MenuManual.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuManual.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuManual.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.MenuManual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuManual.Location = new System.Drawing.Point(118, 3);
            this.MenuManual.Margin = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.MenuManual.Name = "MenuManual";
            this.MenuManual.Size = new System.Drawing.Size(90, 30);
            this.MenuManual.TabIndex = 1;
            this.MenuManual.Text = "手動";
            this.MenuManual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuManual.UseVisualStyleBackColor = true;
            this.MenuManual.Click += new System.EventHandler(this.MenuManual_Click);
            // 
            // MenuP2P
            // 
            this.MenuP2P.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuP2P.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuP2P.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.MenuP2P.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuP2P.Location = new System.Drawing.Point(217, 3);
            this.MenuP2P.Margin = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.MenuP2P.Name = "MenuP2P";
            this.MenuP2P.Size = new System.Drawing.Size(90, 30);
            this.MenuP2P.TabIndex = 3;
            this.MenuP2P.Text = "點對點";
            this.MenuP2P.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuP2P.UseVisualStyleBackColor = true;
            this.MenuP2P.Click += new System.EventHandler(this.MenuP2P_Click);
            // 
            // MenuIO
            // 
            this.MenuIO.Appearance = System.Windows.Forms.Appearance.Button;
            this.MenuIO.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.MenuIO.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.MenuIO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuIO.Location = new System.Drawing.Point(316, 3);
            this.MenuIO.Margin = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.MenuIO.Name = "MenuIO";
            this.MenuIO.Size = new System.Drawing.Size(90, 30);
            this.MenuIO.TabIndex = 4;
            this.MenuIO.Text = "I/O監控";
            this.MenuIO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MenuIO.UseVisualStyleBackColor = true;
            // 
            // ContentPanel
            // 
            this.ContentPanel.AutoSize = true;
            this.Tlp.SetColumnSpan(this.ContentPanel, 2);
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(3, 3);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.Size = new System.Drawing.Size(709, 495);
            this.ContentPanel.TabIndex = 50;
            // 
            // BtnToolPanel
            // 
            this.BtnToolPanel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.BtnToolPanel.Location = new System.Drawing.Point(600, 507);
            this.BtnToolPanel.Margin = new System.Windows.Forms.Padding(3, 3, 15, 0);
            this.BtnToolPanel.Name = "BtnToolPanel";
            this.BtnToolPanel.Size = new System.Drawing.Size(100, 30);
            this.BtnToolPanel.TabIndex = 51;
            this.BtnToolPanel.Text = "開啟控制面板";
            this.BtnToolPanel.UseVisualStyleBackColor = true;
            this.BtnToolPanel.Click += new System.EventHandler(this.BtnToolPanel_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(715, 541);
            this.Controls.Add(this.Tlp);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ACM Demo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Tlp.ResumeLayout(false);
            this.Tlp.PerformLayout();
            this.FlpLeftMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private TableLayoutPanel Tlp;
        private FlowLayoutPanel FlpLeftMenu;
        private RadioButton MenuManual;
        private Panel ContentPanel;
        private RadioButton MenuP2P;
        private RadioButton MenuHome;
        private RadioButton MenuIO;
        private Button BtnToolPanel;
    }
}
