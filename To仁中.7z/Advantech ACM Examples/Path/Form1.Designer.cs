﻿using System.Collections.Generic;
using System;
using Advantech.Motion;//Common Motion API
namespace Path
{
    public struct PATH_INFO { 
        public IntPtr PathHandle;
		public uint PathCnt;
		public int   Index;
        public string PathFileName; 
    } 
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnServo = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnAddAxes = new System.Windows.Forms.Button();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonMovePath1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButtonRel = new System.Windows.Forms.RadioButton();
            this.radioButtonAbs = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonAddArc = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxCen2 = new System.Windows.Forms.TextBox();
            this.textBoxEnd2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxEnd1 = new System.Windows.Forms.TextBox();
            this.textBoxCen1 = new System.Windows.Forms.TextBox();
            this.radioButtonCCW = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.radioButtonCW = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buttonAddLine = new System.Windows.Forms.Button();
            this.listBoxEndPoints = new System.Windows.Forms.ListBox();
            this.BtnClearEnd = new System.Windows.Forms.Button();
            this.BtnSetEnd = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxEnd = new System.Windows.Forms.TextBox();
            this.textBoxMasterID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.buttonMovePath2 = new System.Windows.Forms.Button();
            this.buttonUnloadPath = new System.Windows.Forms.Button();
            this.textBoxPathCnt = new System.Windows.Forms.TextBox();
            this.buttonLoadPath = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxPathFiles = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBoxGpState = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.textBoxAxState = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.BtnResetCounter = new System.Windows.Forms.Button();
            this.textBoxAxCmd = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxFreeCnt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxCurCmd = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxRemain = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxCurIndex = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.LoadPathopenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.buttonClearPath = new System.Windows.Forms.Button();
            this.buttonStopPath = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(197, 45);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(83, 23);
            this.BtnServo.TabIndex = 37;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(105, 45);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(81, 23);
            this.BtnCloseBoard.TabIndex = 36;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(14, 45);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(75, 23);
            this.BtnOpenBoard.TabIndex = 35;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(125, 15);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(136, 20);
            this.CmbAvailableDevice.TabIndex = 34;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 33;
            this.label1.Text = "Available device:";
            // 
            // BtnAddAxes
            // 
            this.BtnAddAxes.Location = new System.Drawing.Point(197, 75);
            this.BtnAddAxes.Name = "BtnAddAxes";
            this.BtnAddAxes.Size = new System.Drawing.Size(83, 23);
            this.BtnAddAxes.TabIndex = 39;
            this.BtnAddAxes.Text = "Add Axis";
            this.BtnAddAxes.UseVisualStyleBackColor = true;
            this.BtnAddAxes.Click += new System.EventHandler(this.BtnAddAxes_Click);
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(108, 78);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(86, 20);
            this.CmbAxes.TabIndex = 38;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonMovePath1);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(12, 135);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(268, 279);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Set ContiPath Data with Mode 1";
            // 
            // buttonMovePath1
            // 
            this.buttonMovePath1.Location = new System.Drawing.Point(185, 247);
            this.buttonMovePath1.Name = "buttonMovePath1";
            this.buttonMovePath1.Size = new System.Drawing.Size(75, 23);
            this.buttonMovePath1.TabIndex = 48;
            this.buttonMovePath1.Text = "Move Path";
            this.buttonMovePath1.UseVisualStyleBackColor = true;
            this.buttonMovePath1.Click += new System.EventHandler(this.buttonMovePath1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtonRel);
            this.groupBox2.Controls.Add(this.radioButtonAbs);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(6, 227);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(176, 43);
            this.groupBox2.TabIndex = 49;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Movement Mode";
            // 
            // radioButtonRel
            // 
            this.radioButtonRel.AutoSize = true;
            this.radioButtonRel.Checked = true;
            this.radioButtonRel.Location = new System.Drawing.Point(8, 20);
            this.radioButtonRel.Name = "radioButtonRel";
            this.radioButtonRel.Size = new System.Drawing.Size(71, 16);
            this.radioButtonRel.TabIndex = 7;
            this.radioButtonRel.TabStop = true;
            this.radioButtonRel.Text = "Relative";
            this.radioButtonRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonAbs
            // 
            this.radioButtonAbs.AutoSize = true;
            this.radioButtonAbs.Location = new System.Drawing.Point(99, 20);
            this.radioButtonAbs.Name = "radioButtonAbs";
            this.radioButtonAbs.Size = new System.Drawing.Size(71, 16);
            this.radioButtonAbs.TabIndex = 6;
            this.radioButtonAbs.Text = "Absolute";
            this.radioButtonAbs.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.buttonAddArc);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.textBoxCen2);
            this.groupBox5.Controls.Add(this.textBoxEnd2);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.textBoxEnd1);
            this.groupBox5.Controls.Add(this.textBoxCen1);
            this.groupBox5.Controls.Add(this.radioButtonCCW);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.radioButtonCW);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox5.Location = new System.Drawing.Point(6, 122);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(252, 99);
            this.groupBox5.TabIndex = 48;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Arc Path";
            // 
            // buttonAddArc
            // 
            this.buttonAddArc.Location = new System.Drawing.Point(178, 69);
            this.buttonAddArc.Name = "buttonAddArc";
            this.buttonAddArc.Size = new System.Drawing.Size(67, 26);
            this.buttonAddArc.TabIndex = 32;
            this.buttonAddArc.Text = "Add Arc";
            this.buttonAddArc.UseVisualStyleBackColor = true;
            this.buttonAddArc.Click += new System.EventHandler(this.buttonAddArc_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(132, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 12);
            this.label12.TabIndex = 15;
            this.label12.Text = "End2:";
            // 
            // textBoxCen2
            // 
            this.textBoxCen2.Location = new System.Drawing.Point(48, 42);
            this.textBoxCen2.Name = "textBoxCen2";
            this.textBoxCen2.Size = new System.Drawing.Size(58, 21);
            this.textBoxCen2.TabIndex = 14;
            this.textBoxCen2.Text = "0";
            // 
            // textBoxEnd2
            // 
            this.textBoxEnd2.Location = new System.Drawing.Point(168, 42);
            this.textBoxEnd2.Name = "textBoxEnd2";
            this.textBoxEnd2.Size = new System.Drawing.Size(58, 21);
            this.textBoxEnd2.TabIndex = 16;
            this.textBoxEnd2.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 12);
            this.label9.TabIndex = 50;
            this.label9.Text = "Arc Direction:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(131, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 12);
            this.label13.TabIndex = 13;
            this.label13.Text = "End1:";
            // 
            // textBoxEnd1
            // 
            this.textBoxEnd1.Location = new System.Drawing.Point(168, 15);
            this.textBoxEnd1.Name = "textBoxEnd1";
            this.textBoxEnd1.Size = new System.Drawing.Size(58, 21);
            this.textBoxEnd1.TabIndex = 14;
            this.textBoxEnd1.Text = "16000";
            // 
            // textBoxCen1
            // 
            this.textBoxCen1.Location = new System.Drawing.Point(48, 15);
            this.textBoxCen1.Name = "textBoxCen1";
            this.textBoxCen1.Size = new System.Drawing.Size(58, 21);
            this.textBoxCen1.TabIndex = 11;
            this.textBoxCen1.Text = "8000";
            // 
            // radioButtonCCW
            // 
            this.radioButtonCCW.AutoSize = true;
            this.radioButtonCCW.Location = new System.Drawing.Point(138, 76);
            this.radioButtonCCW.Name = "radioButtonCCW";
            this.radioButtonCCW.Size = new System.Drawing.Size(41, 16);
            this.radioButtonCCW.TabIndex = 9;
            this.radioButtonCCW.Text = "CCW";
            this.radioButtonCCW.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 12);
            this.label10.TabIndex = 13;
            this.label10.Text = "Cen2:";
            // 
            // radioButtonCW
            // 
            this.radioButtonCW.AutoSize = true;
            this.radioButtonCW.Checked = true;
            this.radioButtonCW.Location = new System.Drawing.Point(101, 76);
            this.radioButtonCW.Name = "radioButtonCW";
            this.radioButtonCW.Size = new System.Drawing.Size(35, 16);
            this.radioButtonCW.TabIndex = 8;
            this.radioButtonCW.TabStop = true;
            this.radioButtonCW.Text = "CW";
            this.radioButtonCW.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 21);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 12;
            this.label11.Text = "Cen1:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buttonAddLine);
            this.groupBox3.Controls.Add(this.listBoxEndPoints);
            this.groupBox3.Controls.Add(this.BtnClearEnd);
            this.groupBox3.Controls.Add(this.BtnSetEnd);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBoxEnd);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(6, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(252, 96);
            this.groupBox3.TabIndex = 44;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Line Path";
            // 
            // buttonAddLine
            // 
            this.buttonAddLine.Location = new System.Drawing.Point(170, 59);
            this.buttonAddLine.Name = "buttonAddLine";
            this.buttonAddLine.Size = new System.Drawing.Size(75, 26);
            this.buttonAddLine.TabIndex = 31;
            this.buttonAddLine.Text = "Add Line";
            this.buttonAddLine.UseVisualStyleBackColor = true;
            this.buttonAddLine.Click += new System.EventHandler(this.buttonAddLine_Click);
            // 
            // listBoxEndPoints
            // 
            this.listBoxEndPoints.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxEndPoints.FormattingEnabled = true;
            this.listBoxEndPoints.ItemHeight = 12;
            this.listBoxEndPoints.Location = new System.Drawing.Point(11, 45);
            this.listBoxEndPoints.Name = "listBoxEndPoints";
            this.listBoxEndPoints.Size = new System.Drawing.Size(115, 40);
            this.listBoxEndPoints.TabIndex = 30;
            // 
            // BtnClearEnd
            // 
            this.BtnClearEnd.Location = new System.Drawing.Point(192, 16);
            this.BtnClearEnd.Name = "BtnClearEnd";
            this.BtnClearEnd.Size = new System.Drawing.Size(54, 23);
            this.BtnClearEnd.TabIndex = 12;
            this.BtnClearEnd.Text = "Clear";
            this.BtnClearEnd.UseVisualStyleBackColor = true;
            this.BtnClearEnd.Click += new System.EventHandler(this.BtnClearEnd_Click);
            // 
            // BtnSetEnd
            // 
            this.BtnSetEnd.Location = new System.Drawing.Point(132, 16);
            this.BtnSetEnd.Name = "BtnSetEnd";
            this.BtnSetEnd.Size = new System.Drawing.Size(57, 23);
            this.BtnSetEnd.TabIndex = 9;
            this.BtnSetEnd.Text = "Add End";
            this.BtnSetEnd.UseVisualStyleBackColor = true;
            this.BtnSetEnd.Click += new System.EventHandler(this.BtnSetEnd_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "EndPoint:";
            // 
            // textBoxEnd
            // 
            this.textBoxEnd.Location = new System.Drawing.Point(68, 16);
            this.textBoxEnd.Name = "textBoxEnd";
            this.textBoxEnd.Size = new System.Drawing.Size(58, 21);
            this.textBoxEnd.TabIndex = 11;
            this.textBoxEnd.Text = "10000";
            // 
            // textBoxMasterID
            // 
            this.textBoxMasterID.Location = new System.Drawing.Point(108, 106);
            this.textBoxMasterID.Name = "textBoxMasterID";
            this.textBoxMasterID.ReadOnly = true;
            this.textBoxMasterID.Size = new System.Drawing.Size(86, 21);
            this.textBoxMasterID.TabIndex = 42;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 12);
            this.label2.TabIndex = 41;
            this.label2.Text = "Master Axis ID:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 12);
            this.label3.TabIndex = 43;
            this.label3.Text = "Available Axes:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.buttonMovePath2);
            this.groupBox4.Controls.Add(this.buttonUnloadPath);
            this.groupBox4.Controls.Add(this.textBoxPathCnt);
            this.groupBox4.Controls.Add(this.buttonLoadPath);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.comboBoxPathFiles);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(14, 420);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(266, 76);
            this.groupBox4.TabIndex = 50;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Set ContiPath Data with Mode 2";
            // 
            // buttonMovePath2
            // 
            this.buttonMovePath2.Location = new System.Drawing.Point(185, 51);
            this.buttonMovePath2.Name = "buttonMovePath2";
            this.buttonMovePath2.Size = new System.Drawing.Size(75, 23);
            this.buttonMovePath2.TabIndex = 50;
            this.buttonMovePath2.Text = "Move Path";
            this.buttonMovePath2.UseVisualStyleBackColor = true;
            this.buttonMovePath2.Click += new System.EventHandler(this.buttonMovePath2_Click);
            // 
            // buttonUnloadPath
            // 
            this.buttonUnloadPath.Location = new System.Drawing.Point(183, 24);
            this.buttonUnloadPath.Name = "buttonUnloadPath";
            this.buttonUnloadPath.Size = new System.Drawing.Size(77, 23);
            this.buttonUnloadPath.TabIndex = 53;
            this.buttonUnloadPath.Text = "Unload";
            this.buttonUnloadPath.UseVisualStyleBackColor = true;
            this.buttonUnloadPath.Click += new System.EventHandler(this.buttonUnloadPath_Click);
            // 
            // textBoxPathCnt
            // 
            this.textBoxPathCnt.Location = new System.Drawing.Point(68, 51);
            this.textBoxPathCnt.Name = "textBoxPathCnt";
            this.textBoxPathCnt.ReadOnly = true;
            this.textBoxPathCnt.Size = new System.Drawing.Size(46, 21);
            this.textBoxPathCnt.TabIndex = 52;
            // 
            // buttonLoadPath
            // 
            this.buttonLoadPath.Location = new System.Drawing.Point(6, 21);
            this.buttonLoadPath.Name = "buttonLoadPath";
            this.buttonLoadPath.Size = new System.Drawing.Size(77, 23);
            this.buttonLoadPath.TabIndex = 52;
            this.buttonLoadPath.Text = "Load Path";
            this.buttonLoadPath.UseVisualStyleBackColor = true;
            this.buttonLoadPath.Click += new System.EventHandler(this.buttonLoadPath_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 51;
            this.label4.Text = "Path Cnt:";
            // 
            // comboBoxPathFiles
            // 
            this.comboBoxPathFiles.FormattingEnabled = true;
            this.comboBoxPathFiles.Location = new System.Drawing.Point(91, 24);
            this.comboBoxPathFiles.Name = "comboBoxPathFiles";
            this.comboBoxPathFiles.Size = new System.Drawing.Size(86, 20);
            this.comboBoxPathFiles.TabIndex = 51;
            this.comboBoxPathFiles.SelectedIndexChanged += new System.EventHandler(this.comboBoxPathFiles_SelectedIndexChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBoxGpState);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.BtnResetErr);
            this.groupBox8.Controls.Add(this.textBoxAxState);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox8.Location = new System.Drawing.Point(298, 290);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(199, 129);
            this.groupBox8.TabIndex = 52;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Current State";
            // 
            // textBoxGpState
            // 
            this.textBoxGpState.Location = new System.Drawing.Point(53, 56);
            this.textBoxGpState.Name = "textBoxGpState";
            this.textBoxGpState.ReadOnly = true;
            this.textBoxGpState.Size = new System.Drawing.Size(140, 21);
            this.textBoxGpState.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 16;
            this.label5.Text = "Group:";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(56, 100);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(105, 23);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // textBoxAxState
            // 
            this.textBoxAxState.Location = new System.Drawing.Point(53, 26);
            this.textBoxAxState.Name = "textBoxAxState";
            this.textBoxAxState.ReadOnly = true;
            this.textBoxAxState.Size = new System.Drawing.Size(140, 21);
            this.textBoxAxState.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "Axis:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label8);
            this.groupBox7.Controls.Add(this.BtnResetCounter);
            this.groupBox7.Controls.Add(this.textBoxAxCmd);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox7.Location = new System.Drawing.Point(298, 177);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(199, 99);
            this.groupBox7.TabIndex = 51;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Command Counter";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 12);
            this.label8.TabIndex = 18;
            this.label8.Text = "Selected Axis:";
            // 
            // BtnResetCounter
            // 
            this.BtnResetCounter.Location = new System.Drawing.Point(56, 66);
            this.BtnResetCounter.Name = "BtnResetCounter";
            this.BtnResetCounter.Size = new System.Drawing.Size(105, 23);
            this.BtnResetCounter.TabIndex = 15;
            this.BtnResetCounter.Text = "Reset Counter";
            this.BtnResetCounter.UseVisualStyleBackColor = true;
            this.BtnResetCounter.Click += new System.EventHandler(this.BtnResetCounter_Click);
            // 
            // textBoxAxCmd
            // 
            this.textBoxAxCmd.Location = new System.Drawing.Point(106, 24);
            this.textBoxAxCmd.Name = "textBoxAxCmd";
            this.textBoxAxCmd.ReadOnly = true;
            this.textBoxAxCmd.Size = new System.Drawing.Size(83, 21);
            this.textBoxAxCmd.TabIndex = 10;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.textBoxFreeCnt);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.textBoxCurCmd);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.textBoxRemain);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.textBoxCurIndex);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox6.Location = new System.Drawing.Point(298, 20);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(199, 143);
            this.groupBox6.TabIndex = 52;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Path Status";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 119);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 24;
            this.label17.Text = "FreeCnt:";
            // 
            // textBoxFreeCnt
            // 
            this.textBoxFreeCnt.Location = new System.Drawing.Point(71, 116);
            this.textBoxFreeCnt.Name = "textBoxFreeCnt";
            this.textBoxFreeCnt.ReadOnly = true;
            this.textBoxFreeCnt.Size = new System.Drawing.Size(83, 21);
            this.textBoxFreeCnt.TabIndex = 23;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 86);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 12);
            this.label16.TabIndex = 22;
            this.label16.Text = "CurCmd:";
            // 
            // textBoxCurCmd
            // 
            this.textBoxCurCmd.Location = new System.Drawing.Point(71, 83);
            this.textBoxCurCmd.Name = "textBoxCurCmd";
            this.textBoxCurCmd.ReadOnly = true;
            this.textBoxCurCmd.Size = new System.Drawing.Size(83, 21);
            this.textBoxCurCmd.TabIndex = 21;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 55);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 20;
            this.label15.Text = "Remain:";
            // 
            // textBoxRemain
            // 
            this.textBoxRemain.Location = new System.Drawing.Point(71, 52);
            this.textBoxRemain.Name = "textBoxRemain";
            this.textBoxRemain.ReadOnly = true;
            this.textBoxRemain.Size = new System.Drawing.Size(83, 21);
            this.textBoxRemain.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 12);
            this.label14.TabIndex = 18;
            this.label14.Text = "CurIndex:";
            // 
            // textBoxCurIndex
            // 
            this.textBoxCurIndex.Location = new System.Drawing.Point(71, 20);
            this.textBoxCurIndex.Name = "textBoxCurIndex";
            this.textBoxCurIndex.ReadOnly = true;
            this.textBoxCurIndex.Size = new System.Drawing.Size(83, 21);
            this.textBoxCurIndex.TabIndex = 10;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // LoadPathopenFileDialog
            // 
            this.LoadPathopenFileDialog.FileName = "openFileDialogLoadPath";
            // 
            // buttonClearPath
            // 
            this.buttonClearPath.Location = new System.Drawing.Point(404, 444);
            this.buttonClearPath.Name = "buttonClearPath";
            this.buttonClearPath.Size = new System.Drawing.Size(81, 23);
            this.buttonClearPath.TabIndex = 54;
            this.buttonClearPath.Text = "Clear Path";
            this.buttonClearPath.UseVisualStyleBackColor = true;
            this.buttonClearPath.Click += new System.EventHandler(this.buttonClearPath_Click);
            // 
            // buttonStopPath
            // 
            this.buttonStopPath.Location = new System.Drawing.Point(313, 444);
            this.buttonStopPath.Name = "buttonStopPath";
            this.buttonStopPath.Size = new System.Drawing.Size(75, 23);
            this.buttonStopPath.TabIndex = 53;
            this.buttonStopPath.Text = "Stop Path";
            this.buttonStopPath.UseVisualStyleBackColor = true;
            this.buttonStopPath.Click += new System.EventHandler(this.buttonStopPath_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 508);
            this.Controls.Add(this.buttonClearPath);
            this.Controls.Add(this.buttonStopPath);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxMasterID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BtnAddAxes);
            this.Controls.Add(this.CmbAxes);
            this.Controls.Add(this.BtnServo);
            this.Controls.Add(this.BtnCloseBoard);
            this.Controls.Add(this.BtnOpenBoard);
            this.Controls.Add(this.CmbAvailableDevice);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Path";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnAddAxes;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxMasterID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button BtnClearEnd;
        private System.Windows.Forms.Button BtnSetEnd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxEnd;
        private System.Windows.Forms.Button buttonAddLine;
        private System.Windows.Forms.ListBox listBoxEndPoints;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton radioButtonCCW;
        private System.Windows.Forms.RadioButton radioButtonCW;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButtonRel;
        private System.Windows.Forms.RadioButton radioButtonAbs;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button buttonAddArc;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxCen2;
        private System.Windows.Forms.TextBox textBoxEnd2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxEnd1;
        private System.Windows.Forms.TextBox textBoxCen1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonMovePath1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button buttonLoadPath;
        private System.Windows.Forms.ComboBox comboBoxPathFiles;
        private System.Windows.Forms.Button buttonMovePath2;
        private System.Windows.Forms.Button buttonUnloadPath;
        private System.Windows.Forms.TextBox textBoxPathCnt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBoxGpState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.TextBox textBoxAxState;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button BtnResetCounter;
        private System.Windows.Forms.TextBox textBoxAxCmd;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxCurIndex;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxFreeCnt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxCurCmd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxRemain;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[32];
        IntPtr m_GpHand = new IntPtr();
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        uint AxCountInGp = 0;
        double[] EndArray = new double[32];
        uint EndPointNum = new uint();
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog LoadPathopenFileDialog;
        List<PATH_INFO> PathInfoList = new List<PATH_INFO>();
        private System.Windows.Forms.Button buttonClearPath;
        private System.Windows.Forms.Button buttonStopPath;       
    }
}

