﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API

namespace Path
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Can Not Get Available Device", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
            m_GpHand = IntPtr.Zero;
            EndPointNum = 0;
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            uint i = 0;
            uint[] slaveDevs = new uint[16];
            uint AxesPerDev = new uint();
            uint AxisNumber;
            uint buffLen = 0;
            Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Can Not Open Device", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            buffLen = 4;
            Result = Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref buffLen);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Get Property Error", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            AxisNumber = AxesPerDev;
            buffLen = 64;
            Result = Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.CFG_DevSlaveDevs, slaveDevs, ref buffLen);
            if (Result == (uint)ErrorCode.SUCCESS)
            {
                i = 0;
                while (slaveDevs[i] != 0)
                {
                    AxisNumber += AxesPerDev;
                    i++;
                }
            }
            m_ulAxisCount = AxisNumber;
            CmbAxes.Items.Clear();
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                //Open Axis 
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Open Axis Failed", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                CmbAxes.Items.Add(String.Format("{0:d}-Axis", i));
                //Reset Command Counter
                double cmdPosition = new double();
                cmdPosition = 0;
                Motion.mAcm_AxSetCmdPosition(m_Axishand[i], cmdPosition);
            }
            CmbAxes.SelectedIndex = 0;
            m_bInit = true;
            timer1.Enabled = true;
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            UInt16[] usAxisState = new UInt16[32];
            uint AxisNum;
            //Stop Every Axes
            if (m_bInit == true)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                Motion.mAcm_GpClose(ref m_GpHand);
                m_GpHand = IntPtr.Zero;
                //Close Axes
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);
                }
                m_ulAxisCount = 0;
                AxCountInGp = 0;
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                timer1.Enabled = false;
                m_bInit = false;
                CmbAxes.Items.Clear();
                textBoxAxState.Clear();
                textBoxGpState.Clear();
                CmbAxes.Text = "";
                listBoxEndPoints.Items.Clear();
                textBoxMasterID.Text = "";
            }
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {

            UInt32 AxisNum;
            UInt32 Result;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        MessageBox.Show("Servo On Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        MessageBox.Show("Servo Off Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void BtnAddAxes_Click(object sender, EventArgs e)
        {
            uint Result, buffLen;
            uint AxesInfoInGp = new uint();
            if (m_bInit != true)
            {
                return;
            }
            Result = Motion.mAcm_GpAddAxis(ref m_GpHand, m_Axishand[CmbAxes.SelectedIndex]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Add Axis To Group Failed", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else//add axis success
            {
                AxCountInGp++;
                buffLen = 4;
                Result = Motion.mAcm_GetProperty(m_GpHand, (uint)PropertyID.CFG_GpAxesInGroup, ref AxesInfoInGp, ref buffLen);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    for (int i = 0; i < 32; i++)
                    {
                        if ((AxesInfoInGp & (0x1 << i)) > 0)
                        {
                            textBoxMasterID.Text = String.Format("{0:d}", i);
                            break;
                        }
                    }
                } 
            }
        }

        private void BtnSetEnd_Click(object sender, EventArgs e)
        {
            if (EndPointNum < 32)
            {
                EndArray[EndPointNum] = Convert.ToDouble(textBoxEnd.Text);
                listBoxEndPoints.Items.Add(textBoxEnd.Text);
                EndPointNum++;
            }
        }

        private void BtnClearEnd_Click(object sender, EventArgs e)
        {
            for (uint i = 0; i < 32; i++)
            {
                EndArray[i] = 0;
            }
            listBoxEndPoints.Items.Clear();
            EndPointNum = 0;
        }

        private void buttonAddLine_Click(object sender, EventArgs e)
        {
            UInt32 Result;
	        UInt16 MoveCmd;
            if (m_bInit != true)
            {
                return;
            }
            if (AxCountInGp == 2)
            {
                 if (radioButtonRel.Checked)//Rel
                {
                    MoveCmd = (UInt16)PathCmd.Rel2DLine;
                }
                else
                {
                    MoveCmd = (UInt16)PathCmd.Abs2DLine;
                }
            }
            else if (AxCountInGp == 3)
            {
                if (radioButtonRel.Checked)//Rel
                {
                    MoveCmd = (UInt16)PathCmd.Rel3DLine;
                }
                else
                {
                    MoveCmd = (UInt16)PathCmd.Abs3DLine;
                }
            }
            else if ((AxCountInGp > 3) & (AxCountInGp < 32))
            {
                if (radioButtonRel.Checked)//Rel
                {
                    MoveCmd = (UInt16)PathCmd.RelMultiLine;
                }
                else
                {
                    MoveCmd = (UInt16)PathCmd.AbsMultiLine; ;
                }
            }
            else
            {
                MessageBox.Show("Axis Count In Group Error", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Result = Motion.mAcm_GpAddPath(m_GpHand, MoveCmd, 0, 6000, 2000, EndArray, null, ref EndPointNum);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Add Path Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void buttonAddArc_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            UInt16 MoveCmd;
            double[] EndPoint_DataArray = new double[2];
            double[] CenPoint_DataArray = new double[2];
            if (m_bInit != true)
            {
                return;
            }
            if (AxCountInGp == 2)
            {
                if (radioButtonRel.Checked)//Rel
                {
                    if (radioButtonCW.Checked)//CW
                    {
                        MoveCmd = (UInt16)PathCmd.Rel2DArcCW;
                    }
                    else
                        MoveCmd = (UInt16)PathCmd.Rel2DArcCCW;
                }
                else//Abs
                {
                    if (radioButtonCW.Checked)//CW
                    {
                        MoveCmd = (UInt16)PathCmd.Abs2DArcCW;
                    }
                    else
                        MoveCmd = (UInt16)PathCmd.Abs2DArcCCW;
                }
            }
            else
            {
                MessageBox.Show("Axis Count In Group Error", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            EndPoint_DataArray[0] = Convert.ToDouble(textBoxEnd1.Text);
            EndPoint_DataArray[1] = Convert.ToDouble(textBoxEnd2.Text); ;
            CenPoint_DataArray[0] = Convert.ToDouble(textBoxCen1.Text); ;
            CenPoint_DataArray[1] = Convert.ToDouble(textBoxCen2.Text); ;
            Result = Motion.mAcm_GpAddPath(m_GpHand, MoveCmd, 0, 6000, 2000, EndPoint_DataArray, CenPoint_DataArray, ref  AxCountInGp);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Add Path Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void buttonMovePath1_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            if (m_bInit != true)
            {
                return;
            }
            Result = Motion.mAcm_GpMovePath(m_GpHand, IntPtr.Zero);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Path Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }            
        }

        private void buttonLoadPath_Click(object sender, EventArgs e)
        {
            UInt32 Result;
	        IntPtr PathHand = new IntPtr();
	        UInt32 PathCnt = new UInt32();
            if (m_bInit != true)
            {
                return;
            }
            if (LoadPathopenFileDialog.ShowDialog() != DialogResult.OK)
				return;
			string strFilePath=LoadPathopenFileDialog.FileName;

            Result = Motion.mAcm_GpLoadPath(m_GpHand, strFilePath, ref PathHand, ref PathCnt);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Load Path Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else//success
            {                
                PATH_INFO pathInfo = new PATH_INFO();
                pathInfo.PathCnt = PathCnt;
                pathInfo.PathHandle = PathHand;
                pathInfo.PathFileName = strFilePath;
                PathInfoList.Add(pathInfo);                
                comboBoxPathFiles.SelectedIndex = comboBoxPathFiles.Items.Add(strFilePath);
                textBoxPathCnt.Text = Convert.ToString(PathCnt, 10);
            }
        }
        private void buttonUnloadPath_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            int index=0;
            bool isFind = false;
            IntPtr PathHandle = new IntPtr();
            if (m_bInit != true)
            {
                return;
            }
            foreach (PATH_INFO pathInf in PathInfoList)
            {
                if (pathInf.PathFileName == comboBoxPathFiles.Text)
                {
                    PathHandle = pathInf.PathHandle;
                    Result = Motion.mAcm_GpUnloadPath(m_GpHand, ref PathHandle);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        MessageBox.Show("Unload Path Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        comboBoxPathFiles.Items.Remove(pathInf.PathFileName);
                        comboBoxPathFiles.SelectedIndex = comboBoxPathFiles.Items.Count - 1;
                        if (comboBoxPathFiles.SelectedIndex==-1)
                        {
                            comboBoxPathFiles.Text = "";
                            textBoxPathCnt.Text = "";
                        }                        
                        index = PathInfoList.IndexOf(pathInf);
                        isFind = true;
                        break;                      
                    }
                }
            }
            if (isFind)
            {
                PathInfoList.RemoveAt(index);
            }
            foreach (PATH_INFO pathInf in PathInfoList)
            {
                if (pathInf.PathFileName == comboBoxPathFiles.Text)
                { textBoxPathCnt.Text = Convert.ToString(pathInf.PathCnt); }
            }
        }

        private void buttonMovePath2_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            PATH_INFO pathInfo;
            IntPtr PathHandle;
            if (m_bInit != true)
            {
                return;
            }
            pathInfo = PathInfoList.Find(delegate(PATH_INFO p){ return p.PathFileName == comboBoxPathFiles.Text; });
            PathHandle = pathInfo.PathHandle;
            if (PathHandle == IntPtr.Zero)
            {
                MessageBox.Show("Please Load Path File First", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Result = Motion.mAcm_GpMovePath(m_GpHand, PathHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Path Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UInt32 Result;
            double CurPos = new double();
            UInt16 AxState = new UInt16();
            UInt16 GpState = new UInt16();
            uint Index = new uint();
            uint Remain = new uint();
            uint FreeCnt = new uint();
            uint CurCmd = new uint(); //[dan.yang 2011.06.14]
            string strTemp = "";
            if (m_bInit)
            {
                Result = Motion.mAcm_GpGetPathStatus(m_GpHand, ref Index, ref CurCmd, ref Remain, ref FreeCnt);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    textBoxCurIndex.Text = Convert.ToString(Index,10);
                    textBoxFreeCnt.Text = Convert.ToString(FreeCnt,10);
                    textBoxRemain.Text = Convert.ToString(Remain,10);
                    textBoxCurCmd.Text = Convert.ToString(CurCmd, 10);
                }
                Motion.mAcm_AxGetCmdPosition(m_Axishand[CmbAxes.SelectedIndex], ref CurPos);
                textBoxAxCmd.Text = Convert.ToString(CurPos);
                Motion.mAcm_AxGetState(m_Axishand[CmbAxes.SelectedIndex], ref AxState);
                switch (AxState)
                {
                    case 0:
                        strTemp = "STA_AX_DISABLE";
                        break;
                    case 1:
                        strTemp = "STA_AX_READY";
                        break;
                    case 2:
                        strTemp = "STA_AX_STOPPING";
                        break;
                    case 3:
                        strTemp = "STA_AX_ERROR_STOP";
                        break;
                    case 4:
                        strTemp = "STA_AX_HOMING";
                        break;
                    case 5:
                        strTemp = "STA_AX_PTP_MOT";
                        break;
                    case 6:
                        strTemp = "STA_AX_CONTI_MOT";
                        break;
                    case 7:
                        strTemp = "STA_AX_SYNC_MOT";
                        break;
                    default:
                        break;
                }
                textBoxAxState.Text = strTemp;
                if (m_GpHand != IntPtr.Zero)
                {
                    Motion.mAcm_GpGetState(m_GpHand, ref GpState);
                    switch (GpState)
                    {
                        case 0:
                            strTemp = "STA_GP_DISABLE";
                            break;
                        case 1:
                            strTemp = "STA_GP_READY";
                            break;
                        case 2:
                            strTemp = "STA_GP_STOPPING";
                            break;
                        case 3:
                            strTemp = "STA_GP_ERROR_STOP";
                            break;
                        case 4:
                            strTemp = "STA_GP_MOTION";
                            break;
                        case 5:
                            strTemp = "STA_GP_AX_MOTION";
                            break;
                        case 6:
                            strTemp = "STA_GP_MOTION_PATH";
                            break;
                        default:
                            break;
                    }
                    textBoxGpState.Text = strTemp;
                }
            }
        }

        private void buttonStopPath_Click(object sender, EventArgs e)
        {
            UInt16 State = new UInt16();
            if (m_bInit != true)
            {
                return;
            }
            Motion.mAcm_GpGetState(m_GpHand, ref State);
            if (State == (UInt16)GroupState.STA_Gp_ErrorStop)
            { Motion.mAcm_GpResetError(m_GpHand); }
            Motion.mAcm_GpStopEmg(m_GpHand);
            return;
        }

        private void buttonClearPath_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            if (m_bInit != true)
            {
                return;
            }
            Result = Motion.mAcm_GpResetPath(ref m_GpHand);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Reset Path Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void BtnResetCounter_Click(object sender, EventArgs e)
        {
            double cmdPosition = new double();
            cmdPosition = 0;
            if (m_bInit == true)
            {
                for (uint AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Motion.mAcm_AxSetCmdPosition(m_Axishand[AxisNum], cmdPosition);
                }
            }            
        }

        private void BtnResetErr_Click(object sender, EventArgs e)
        {
            UInt16 State = new UInt16();
            if (m_bInit == true)
            {
                for (uint AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                }
                Motion.mAcm_GpGetState(m_GpHand, ref State);
                if (State == (UInt16)GroupState.STA_Gp_ErrorStop)
                { Motion.mAcm_GpResetError(m_GpHand); }
            }           
        }

        private void comboBoxPathFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            PATH_INFO pathInfo;
            pathInfo = PathInfoList.Find(delegate(PATH_INFO p) { return p.PathFileName == comboBoxPathFiles.Text; });
            if (pathInfo.PathHandle != IntPtr.Zero)
            {
                textBoxPathCnt.Text = Convert.ToString(pathInfo.PathCnt);
            }
        }
    }
}