﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;

namespace GMSystem
{
    public partial class FormPpoint : Form
    {
        public FormPpoint()
        {
            InitializeComponent();
        }

        private IntPtr m_GMShand;
        private uint m_AxisCount;
        public FormPpoint(IntPtr GmsHandle,uint AxisCount)
        {
            InitializeComponent();

            m_GMShand = GmsHandle;
            m_AxisCount = AxisCount;
        }

        private void btn_LoadPoint_Click(object sender, EventArgs e)
        {
            this.OpenConfigFile.FileName = ".csv";
            this.OpenConfigFile.Filter = "Text file(.csv)|*.csv";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;

            uint Result =Motion.mAcm_GmLoadPoint(m_GMShand,OpenConfigFile.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Load Point Failed with ErrorCode:0x" + Result.ToString("X"), "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            RefreshPpointValues();
            dgv_Point_CellClick(null,null);
        }

        private void btn_SavePoint_Click(object sender, EventArgs e)
        {
            this.SaveFileDialog.FileName = ".csv";
            this.SaveFileDialog.Filter = "Text file(.csv)|*.csv";
            if (SaveFileDialog.ShowDialog() != DialogResult.OK)
                return;

            uint Result = Motion.mAcm_GmSavePoint(m_GMShand,SaveFileDialog.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Save Point Failed with ErrorCode:0x" + Result.ToString("X"), "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_ResetPoint_Click(object sender, EventArgs e)
        {
            uint Result = Motion.mAcm_GmResetPoint(m_GMShand);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Reset Point Failed with ErrorCode:0x" + Result.ToString("X"), "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            RefreshPpointValues();
            dgv_Point_CellClick(null, null);
        }

        private void btn_SetPoint_Click(object sender, EventArgs e)
        {
            uint PointID = Convert.ToUInt32(txb_PointID.Text);
            double[] PointArray = new double[m_AxisCount];

            PointArray[0] = Convert.ToDouble(txb_sPoint_X.Text);
            PointArray[1] = Convert.ToDouble(txb_sPoint_Y.Text);
            PointArray[2] = Convert.ToDouble(txb_sPoint_Z.Text);
            PointArray[3] = Convert.ToDouble(txb_sPoint_R.Text);

            uint Result = Motion.mAcm_GmSetPoint(m_GMShand,PointID, PointArray);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Set Point Failed with ErrorCode:0x" + Result.ToString("X"), "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            RefreshPpointValues();
        }

        private void RefreshPpointValues()
        {
            uint Result = 0;
            double[] PointArray=new double[m_AxisCount];
            string strPointIndex = "";
            string strPointValue = "";
            int RowIndex=0;

            dgv_Point.Rows.Clear();

            for(uint PointID=0;PointID<10000;PointID++)
            {
                Result = Motion.mAcm_GmGetPoint(m_GMShand, PointID, PointArray);
                if(Result==(uint)ErrorCode.SUCCESS)
                {
                    strPointIndex = "P" + PointID.ToString();
                    strPointValue = "";
                    for(uint i=0;i<m_AxisCount;i++)
                    {
                        strPointValue += PointArray[i].ToString() + "  ";
                    }
                    RowIndex = dgv_Point.Rows.Count;
                    dgv_Point.Rows.Add();
                    dgv_Point.Rows[RowIndex].Cells[0].Value = strPointIndex;
                    dgv_Point.Rows[RowIndex].Cells[1].Value = strPointValue;
                }
            }
        }

        private void dgv_Point_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            uint Result = 0;
            double[] PointArray=new double[m_AxisCount];

            if(dgv_Point.CurrentRow!=null)
            {
                string strPNo = dgv_Point.CurrentRow.Cells[0].Value.ToString();
                strPNo = strPNo.Substring(1);
                uint PNo = Convert.ToUInt32(strPNo);

                Result = Motion.mAcm_GmGetPoint(m_GMShand, PNo, PointArray);
                if(Result==(uint)ErrorCode.SUCCESS)
                {
                    txb_PointID.Text = strPNo;
                    txb_sPoint_X.Text = PointArray[0].ToString();
                    txb_sPoint_Y.Text = PointArray[1].ToString();
                    txb_sPoint_Z.Text = PointArray[2].ToString();
                    txb_sPoint_R.Text = PointArray[3].ToString();
                }
            }
            else
            {
                txb_PointID.Text = "0";
                txb_sPoint_X.Text = "0";
                txb_sPoint_Y.Text = "0";
                txb_sPoint_Z.Text = "0";
                txb_sPoint_R.Text = "0";
            }
        }

    }
}