﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;


namespace GMSystem
{
    public partial class Form1 : Form
    {

        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle;

        uint m_ulAxisCount = 0;
        bool m_bInit = false;


        IntPtr m_GMShand = IntPtr.Zero;
        bool m_bGMSOpened = false;
        private uint m_uGmSystemState = 0;

        string strGCodeFileName = string.Empty ;
        ///private System.Windows.Forms.Timer timer1;

        public Form1()
        {
            InitializeComponent();
           
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
   
            if (m_bInit == false)
            {


                Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Can not Open Device with Error Code[0x" + Convert.ToString(Result, 16) + "]", "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                BtnOpenBoard.Text = "Close Board";              

                Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref m_ulAxisCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Get AxesCount failed with Error Code[0x" + Convert.ToString(Result, 16) + "]", "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                m_bInit = true;
            }
            else
            {
                if (m_bGMSOpened)
                {
                    this.timer1.Enabled = false;
                    Result = Motion.mAcm_GmClose(m_GMShand);
                    m_GMShand = IntPtr.Zero;
                    btnOpenGMS.Text = "Open GMSystem";
                    m_bGMSOpened = false;
                }
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                BtnOpenBoard.Text = "Open Board";
                m_bInit = false;
            }
        }
        private void BtnLoadCfg_Click(object sender, EventArgs e)
        {
            UInt32 Result;

            if (m_bInit != true)
            {
                return;
            }
            this.OpenConfigFile.FileName = ".cfg";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;

            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, OpenConfigFile.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Load File failed with Error Code[0x" + Convert.ToString(Result, 16) + "]", "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }


        private void btnOpenGMS_Click(object sender, EventArgs e)
        {
            uint Result = 0;
            string strString;
            if (m_bGMSOpened == false)
            {

                Result = Motion.mAcm_GmOpen(m_DeviceHandle, ref m_GMShand);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Open G Code System failed with Error Code[0x" + Convert.ToString(Result, 16) + "]", "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                m_bGMSOpened = true;
                btnOpenGMS.Text = "Close GMSystem";

                //Now only PCI-1245S supports P point function
                if (((DeviceNum >> 24) & 0xff) == (uint)DevTypeID.PCI1245S || ((DeviceNum >> 24) & 0xff) == (uint)DevTypeID.V_PCI1245S)
                {
                    btn_Ppoint.Enabled = true;
                }
                else
                {
                    btn_Ppoint.Enabled = false;
                }

                timer1.Enabled = true;
                //Enable timer to check command counter and so on
            }
            else
            {
                timer1.Enabled = false;
                Result = Motion.mAcm_GmClose(m_GMShand);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Close G Code System failed with Error Code[0x" + Convert.ToString(Result, 16) + "]", "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                m_GMShand = IntPtr.Zero;
                btnOpenGMS.Text = "Open GMSystem";
                m_bGMSOpened = false;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Can not Get Available Device", "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //             if (deviceCount > Motion.MAX_DEVICES)
//             {
            //                 MessageBox.Show("Too Much Device", "G Code System", MessageBoxButtons.OK, MessageBoxIcon.Error);
//                 return;
//             }
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }
   

        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            string strFileName;
            OpenFileDialog.Filter = "CNC files(*.ncd/*.nc)|*.ncd;*.nc";
            if (OpenFileDialog.ShowDialog() != DialogResult.OK)
                return;

            strFileName = OpenFileDialog.FileName;

            FileStream fs = new FileStream(strFileName, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs, Encoding.Default);
            tbGCodeContent.Text = sr.ReadToEnd();
            sr.Close();

            strGCodeFileName = strFileName;
        }

        private void btnOpenDxf_Click(object sender, EventArgs e)
        {
            string strFileName;
            OpenFileDialog.Filter = "dxf files(*.dxf)|*.dxf";
            if (OpenFileDialog.ShowDialog() != DialogResult.OK)
                return;

            strFileName = OpenFileDialog.FileName;

            LoadDXF(strFileName);
            //adtoDXFMotionReader.AtCloseDXF();
            strGCodeFileName = "";

        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            uint Result;
            uint ErrorRow = 0;
            if (strGCodeFileName == "")
            {
                using (SaveFileDialog dialog = new SaveFileDialog())
                {
                    dialog.Filter = "CNC files (*.ncd;*.nc)|*.ncd;*.nc";
                    if (dialog.ShowDialog() == DialogResult.OK)
                    {
                        strGCodeFileName = dialog.FileName;
                    }
                    else
                    {
                        return;
                    }
                }
            }
            tbGCodeContent.SaveFile(strGCodeFileName, RichTextBoxStreamType.TextTextOleObjs) ;
            if(strGCodeFileName.Length ==0)
	        {
                if (SaveFileDialog.ShowDialog() != DialogResult.OK)
                    return;

                strGCodeFileName = SaveFileDialog.FileName;

	        }

            if (strGCodeFileName.Length == 0)
	        {
		        MessageBox.Show("Download G Code fail.filename is empty", "G Code System");
		        return;
	        }
            //save the file
            //FileStream fs = new FileStream(strGCodeFileName, FileMode.Create);
            //byte[] data = new UTF8Encoding().GetBytes(tbGCodeContent.Text);
           // fs.Write(data, 0, data.Length);
           // fs.Flush();
           // fs.Close();

          //  if (m_uGmSystemState != 1)
          //  {
           //     MessageBox.Show("Can not download the job file when the system is not ready;", "G Code System");
          //      return;
         //   }

           
            Result = Motion.mAcm_GmLoadJob(m_GMShand, strGCodeFileName, ref ErrorRow);

            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Download ncd file failed with ErrorCode:[" + Convert.ToString(Result, 16) + "]", "G Code System");
                return;
            }	
            

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            uint Result;
            uint JobLen = 0;
            StringBuilder uploadstr = new StringBuilder();


            Result = Motion.mAcm_GmUploadJob(m_GMShand, uploadstr, ref JobLen);//First,Get the Job Length
            if (Result != (uint)Advantech.Motion.ErrorCode.SUCCESS)
            {
                if (Result == (uint)Advantech.Motion.ErrorCode.Gm_NotEnoughMemory)
                {
                    uploadstr.Capacity = (int)JobLen + 1;
                    uploadstr.EnsureCapacity(uploadstr.Capacity);
                }
                else
                {
                    MessageBox.Show("Upload G Code failed with ErrorCode:[" + Convert.ToString(Result, 16) + "]", "G Code System");
                    return;
                }
            }

            Result = Motion.mAcm_GmUploadJob(m_GMShand, uploadstr, ref JobLen);//Then, Get the upload string
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Upload G Code failed with ErrorCode:[" + Convert.ToString(Result, 16) + "]", "G Code System");
                return;
            }
            tbGCodeContent.Text = uploadstr.ToString();


        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            uint Result;
            if (m_bGMSOpened == true)
            {
                Result = Motion.mAcm_GmCommand(m_GMShand, "XQ");
                if (Result != 0)
                {
                    MessageBox.Show("Execute G Code failed with ErrorCode:[" + Convert.ToString(Result, 16) + "]", "G Code System");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Open G Code System first.", "G Code System");
                return;
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            uint Result;
            if (m_bGMSOpened == true)
            {
                Result = Motion.mAcm_GmCommand(m_GMShand, "ST");
                if (Result != 0)
                {
                    MessageBox.Show("Stop G Code failed with ErrorCode:[" + Convert.ToString(Result, 16) + "]", "G Code System");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Open G Code System fisrt.", "G Code System");
                return;
            }
        }

        private void LoadDXF(String FilePath)
        {
            string GCode;
            StringBuilder GCodeText = new StringBuilder("", 9999 * 256);
            uint Length = 0;
            uint Result = 0;
            double DXFProportion = 0.2;

            Length = 9999 * 256;
            //Result = Motion.mAcm_GmLoadDXF(m_GMShand, FilePath, DXFProportion, GCodeText, ref Length);
            Result = Motion.mAcm_GmDxfToGCodeText(FilePath, DXFProportion, GCodeText, ref Length);
            if (Result != 0)
            {
                MessageBox.Show("Load DXF failed with ErrorCode:[" + Convert.ToString(Result, 16) + "]", "G Code System");
                return;
            }
            tbGCodeContent.Text = "";
            GCode = "HF 1200\r\n";          //1200mm/Min 1200/60=20mm/s
            GCode = GCode + "LF 120\r\n";   //120 mm/Min 120/60=2mm/s
            GCode = GCode + "F 600\r\n";    //600 mm/Min  10mm/s
            GCode = GCode + "AC 180000\r\n";//180000mm/Min 180000/60/60=50mm/s 
            GCode = GCode + "DC 180000\r\n";//180000mm/Min 180000/60/60=50mm/s 
            GCode = GCode + "G0 X0 Y0\r\n"; //Move to (0,0)
            GCode = GCode + "G90\r\n";      //Absolute coordinate mode
            GCode = GCode + "G62\r\n";      //Correct positioning mode

            tbGCodeContent.AppendText(GCode);
            tbGCodeContent.ScrollToCaret();
            tbGCodeContent.AppendText(GCodeText.ToString());
            tbGCodeContent.ScrollToCaret();            
            GCode = "M30";
            tbGCodeContent.AppendText(GCode);
            tbGCodeContent.ScrollToCaret();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            uint Result;
            if (m_bGMSOpened == true)
            {
                Result = Motion.mAcm_GmCommand(m_GMShand, tbCmd.Text);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Send Cmd failed with ErrorCode:[" + Convert.ToString(Result, 16) + "]", "G Code System");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Open G Code System fisrt.", "G Code System");
                return;
            }

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            uint uCurrentRow = 0;
            uint uCurrentStatus = 0;
            string strCurrentStatus;
            StringBuilder sbCurrentCmd = new StringBuilder();
            uint Length = 0;

            sbCurrentCmd.Capacity = 256;
            sbCurrentCmd.EnsureCapacity(sbCurrentCmd.Capacity);
            Length = 256;

            if (m_bInit && m_bGMSOpened)
            {
                Result = Motion.mAcm_GmGetCurrentRow(m_GMShand, ref uCurrentRow);

                if (Result != (uint)ErrorCode.SUCCESS)
		        {
                    tbCurrentStatus.Text = "Get current row failed with error code:["+Convert.ToString(Result,16)+"]";
		        }
		        //else
		        //{
    		    //    tbCurrentRow.Text = Convert.ToString(uCurrentRow,10);
		       // }
                if ((int)uCurrentRow < 0)
                {
                    return;
                }
		        Result = Motion.mAcm_GmGetState(m_GMShand, ref uCurrentStatus);

                if (Result != (uint)ErrorCode.SUCCESS)
		        {
                    tbCurrentStatus.Text = "Get Current status failed with error code:["+Convert.ToString(Result,16)+"]";
		        }
		        else
		        {
                    m_uGmSystemState = uCurrentStatus;
			        switch(uCurrentStatus)
			        {
			        case 0:
                        tbCurrentStatus.Text = "Stopping...";
                        CurrentRow = -1;
				        break;
                    case 1:
                        tbCurrentStatus.Text = "UnReady...";
                        CurrentRow = -1;
                        break;  
			        case 2:
                        if (tbCurrentStatus.Text != "Ready")
                        {
                            tbCurrentStatus.Text = "Ready";
                            CurrentRow = -1;
                        }
				        break;
			        case 3:
                        tbCurrentStatus.Text = "Executing...";
                        if ((CurrentRow != uCurrentRow))
                        {
                            CurrentRow = (int)uCurrentRow;
                        }
				        break;
			        case 4:
                        tbCurrentStatus.Text = "SinglePause";
                        CurrentRow =(int) uCurrentRow;
				        break;
			        case 5:
                        tbCurrentStatus.Text = "Pause";
                        if ((int)CurrentRow != uCurrentRow)
                        {
                            CurrentRow = (int)uCurrentRow;
                        }
				        break;
                    case 6:
                        tbCurrentStatus.Text = "Error";
                        if ((int)CurrentRow != uCurrentRow)
                        {
                            CurrentRow = (int)uCurrentRow;
                        }
                        break;
			        default:
                        tbCurrentStatus.Text = "Ready";
				        break;
			        }
			        
		        }
                if (CurrentRow == -1)
                {
                    this.tbCurrentRow.Text = Convert.ToString(0);
                }
                else
                {
                    this.tbCurrentRow.Text = Convert.ToString(CurrentRow +1);
                }
                if (m_uGmSystemState == 3)
                {

                    Result = Motion.mAcm_GmGetCurrentCommand(m_GMShand, sbCurrentCmd, ref Length);


                    if (Result != (uint)ErrorCode.SUCCESS)
		            {
                        tbCurrentCmd.Text = "Get Current Cmd failed with error code:["+Convert.ToString(Result,16)+"]";

		            }
		            else
		            {
                        tbCurrentCmd.Text = sbCurrentCmd.ToString().Trim();
		            }
                }
                else
                {
                    tbCurrentCmd.Text = "";
                }

            }

        }

        private void btn_Ppoint_Click(object sender, EventArgs e)
        {
            FormPpoint frmPpoint = new FormPpoint(m_GMShand, m_ulAxisCount);
            frmPpoint.Show();
        }
    }
}