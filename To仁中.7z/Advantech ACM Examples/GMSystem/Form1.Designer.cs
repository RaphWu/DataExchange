﻿namespace GMSystem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnOpenGMS = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tbCurrentRow = new System.Windows.Forms.TextBox();
            this.tbCurrentStatus = new System.Windows.Forms.TextBox();
            this.tbCurrentCmd = new System.Windows.Forms.TextBox();
            this.tbCmd = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnExecute = new System.Windows.Forms.Button();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnDownload = new System.Windows.Forms.Button();
            this.btnOpenDxf = new System.Windows.Forms.Button();
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.tbGCodeContent = new System.Windows.Forms.RichTextBox();
            this.btn_Ppoint = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnOpenGMS);
            this.groupBox1.Controls.Add(this.BtnLoadCfg);
            this.groupBox1.Controls.Add(this.BtnOpenBoard);
            this.groupBox1.Controls.Add(this.CmbAvailableDevice);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(563, 52);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Device";
            // 
            // btnOpenGMS
            // 
            this.btnOpenGMS.Location = new System.Drawing.Point(455, 18);
            this.btnOpenGMS.Name = "btnOpenGMS";
            this.btnOpenGMS.Size = new System.Drawing.Size(101, 23);
            this.btnOpenGMS.TabIndex = 13;
            this.btnOpenGMS.Text = "Open GMSystem";
            this.btnOpenGMS.UseVisualStyleBackColor = true;
            this.btnOpenGMS.Click += new System.EventHandler(this.btnOpenGMS_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(354, 18);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(101, 23);
            this.BtnLoadCfg.TabIndex = 10;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(253, 18);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(101, 23);
            this.BtnOpenBoard.TabIndex = 9;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(123, 20);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(121, 20);
            this.CmbAvailableDevice.TabIndex = 8;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Available device:";
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tbCurrentRow
            // 
            this.tbCurrentRow.Location = new System.Drawing.Point(111, 450);
            this.tbCurrentRow.Name = "tbCurrentRow";
            this.tbCurrentRow.ReadOnly = true;
            this.tbCurrentRow.Size = new System.Drawing.Size(100, 21);
            this.tbCurrentRow.TabIndex = 2;
            // 
            // tbCurrentStatus
            // 
            this.tbCurrentStatus.Location = new System.Drawing.Point(111, 477);
            this.tbCurrentStatus.Name = "tbCurrentStatus";
            this.tbCurrentStatus.ReadOnly = true;
            this.tbCurrentStatus.Size = new System.Drawing.Size(100, 21);
            this.tbCurrentStatus.TabIndex = 3;
            // 
            // tbCurrentCmd
            // 
            this.tbCurrentCmd.Location = new System.Drawing.Point(111, 504);
            this.tbCurrentCmd.Name = "tbCurrentCmd";
            this.tbCurrentCmd.ReadOnly = true;
            this.tbCurrentCmd.Size = new System.Drawing.Size(188, 21);
            this.tbCurrentCmd.TabIndex = 4;
            // 
            // tbCmd
            // 
            this.tbCmd.Location = new System.Drawing.Point(411, 450);
            this.tbCmd.Name = "tbCmd";
            this.tbCmd.Size = new System.Drawing.Size(83, 21);
            this.tbCmd.TabIndex = 5;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(500, 449);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 6;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 455);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "Current Row:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 481);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "Current Status:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 507);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "Current Cmd:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(376, 455);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "Cmd:";
            // 
            // btnOpenFile
            // 
            this.btnOpenFile.Location = new System.Drawing.Point(11, 70);
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.Size = new System.Drawing.Size(94, 23);
            this.btnOpenFile.TabIndex = 11;
            this.btnOpenFile.Text = "Open File";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(481, 70);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(94, 23);
            this.btnStop.TabIndex = 14;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnExecute
            // 
            this.btnExecute.Location = new System.Drawing.Point(387, 70);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(94, 23);
            this.btnExecute.TabIndex = 15;
            this.btnExecute.Text = "Execute";
            this.btnExecute.UseVisualStyleBackColor = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // btnUpload
            // 
            this.btnUpload.Location = new System.Drawing.Point(293, 70);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(94, 23);
            this.btnUpload.TabIndex = 16;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnDownload
            // 
            this.btnDownload.Location = new System.Drawing.Point(199, 70);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(94, 23);
            this.btnDownload.TabIndex = 17;
            this.btnDownload.Text = "Download";
            this.btnDownload.UseVisualStyleBackColor = true;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // btnOpenDxf
            // 
            this.btnOpenDxf.Location = new System.Drawing.Point(105, 70);
            this.btnOpenDxf.Name = "btnOpenDxf";
            this.btnOpenDxf.Size = new System.Drawing.Size(94, 23);
            this.btnOpenDxf.TabIndex = 18;
            this.btnOpenDxf.Text = "OpenDxf";
            this.btnOpenDxf.UseVisualStyleBackColor = true;
            this.btnOpenDxf.Click += new System.EventHandler(this.btnOpenDxf_Click);
            // 
            // SaveFileDialog
            // 
            this.SaveFileDialog.DefaultExt = "ncd";
            this.SaveFileDialog.Filter = "CNC files(*.ncd)|*.ncd";
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.DefaultExt = "ncd";
            this.OpenFileDialog.Filter = "CNC files(*.ncd)|*.ncd";
            // 
            // tbGCodeContent
            // 
            this.tbGCodeContent.Location = new System.Drawing.Point(11, 110);
            this.tbGCodeContent.Name = "tbGCodeContent";
            this.tbGCodeContent.Size = new System.Drawing.Size(563, 330);
            this.tbGCodeContent.TabIndex = 19;
            this.tbGCodeContent.Text = "";
            // 
            // btn_Ppoint
            // 
            this.btn_Ppoint.Enabled = false;
            this.btn_Ppoint.Location = new System.Drawing.Point(411, 476);
            this.btn_Ppoint.Name = "btn_Ppoint";
            this.btn_Ppoint.Size = new System.Drawing.Size(164, 23);
            this.btn_Ppoint.TabIndex = 20;
            this.btn_Ppoint.Text = "P Point Operation";
            this.btn_Ppoint.UseVisualStyleBackColor = true;
            this.btn_Ppoint.Click += new System.EventHandler(this.btn_Ppoint_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 541);
            this.Controls.Add(this.btn_Ppoint);
            this.Controls.Add(this.tbGCodeContent);
            this.Controls.Add(this.btnOpenDxf);
            this.Controls.Add(this.btnDownload);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.btnExecute);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnOpenFile);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.tbCmd);
            this.Controls.Add(this.tbCurrentCmd);
            this.Controls.Add(this.tbCurrentStatus);
            this.Controls.Add(this.tbCurrentRow);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnOpenGMS;
        private System.Windows.Forms.TextBox tbCurrentRow;
        private System.Windows.Forms.TextBox tbCurrentStatus;
        private System.Windows.Forms.TextBox tbCurrentCmd;
        private System.Windows.Forms.TextBox tbCmd;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnExecute;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.Button btnOpenDxf;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.RichTextBox tbGCodeContent;
        private int CurrentRow;
        private System.Windows.Forms.Button btn_Ppoint;
    }
}

