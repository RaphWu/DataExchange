﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Runtime.InteropServices; //For Marshal

namespace SetCardRelation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;

            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Can not Get Available Device", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
//             if (deviceCount > 0)
//             {
//                 CmbAvailableDevice.SelectedIndex = 0;
//                 DeviceNum = CurAvailableDevs[0].DeviceNum;
//                 TreeNode tmp ;
//                 tmp = new TreeNode(CurAvailableDevs[0].DeviceName);
//                 treeView2.Nodes.Add(tmp);
//                 treeView2.ExpandAll();
// 
//             }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;    
            deviceName = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceName;
            if ((DeviceNum & 0xff000000) == 0x25000000)
            {
                UpdateList();
            }
        }
        private void UpdateList()
        {
            uint Result;
            uint i = 0;
            uint[] slaveDevs = new uint[16];
            uint AxesPerDev = new uint();
            uint AxisNumber;
            uint buffLen = 0;

            Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Can not Open Device", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            treeView1.Nodes.Clear();
            treeView2.Nodes.Clear();
            TreeNode tmp;
           // tmp = new TreeNode(CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceName);
            tmp = new TreeNode(deviceName);
            treeView2.Nodes.Add(tmp);
            treeView2.SelectedNode = tmp;

            TreeNode tmp1, tmp2;
            tmp1 = new TreeNode("0-Axis");
            tmp2 = new TreeNode("1-Axis");
            //在TreeView组件中加入子节点
            treeView2.SelectedNode.Nodes.Add(tmp1);
            treeView2.SelectedNode.Nodes.Add(tmp2);

            buffLen = 4;
            Result = Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref buffLen);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Get Property Error", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            AxisNumber = AxesPerDev;


            buffLen = 64;
            Result = Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.CFG_DevSlaveDevs, slaveDevs, ref buffLen);
            if (Result == (uint)ErrorCode.SUCCESS)
            {
                i = 0;
                while (i<3)
                {
                    
                    TreeNode tmpx, tmpy, tmpdev;
                    tmpdev = new TreeNode(String.Format("PCI-1220(S{0:d})", (slaveDevs[i] >> 12) & 0xfff));
                    treeView2.SelectedNode.Nodes.Add(tmpdev);
                    treeView2.SelectedNode = tmpdev;
                    tmpx = new TreeNode(String.Format("{0:d}-Axis", AxisNumber));
                    tmpy = new TreeNode(String.Format("{0:d}-Axis", AxisNumber + 1));
                    treeView2.SelectedNode.Nodes.Add(tmpx);
                    treeView2.SelectedNode.Nodes.Add(tmpy);
                    AxisNumber += AxesPerDev;
                    i++;
                    treeView2.SelectedNode = tmp;
                }
            }
            treeView2.ExpandAll();

            // treeView1
            TreeNode mastroot;
            mastroot = new TreeNode("Motion Devices");
            treeView1.Nodes.Add(mastroot);
            treeView1.SelectedNode = treeView1.Nodes[0];
            for (i = 0; i < deviceCount; i++)
            {
                if ((CurAvailableDevs[i].DeviceNum & 0xff000000) == 0x25000000)
                {
                    if (CurAvailableDevs[i].DeviceNum == DeviceNum)
                    {
                        continue;
                    }
                    else
                    {
                        TreeNode mastdev;
                        mastdev = new TreeNode(CurAvailableDevs[i].DeviceName);
                        treeView1.SelectedNode.Nodes.Add(mastdev);

                    }
                }
            }
            treeView1.ExpandAll();
            m_bInit = true;
        }

        private void buttonSetSlave_Click(object sender, EventArgs e)
        {           
            uint processDevNum = 0;
            string SelectedDev;
            int refIndex;
            int bIDLen ;

            if (!m_bInit)
            {
                return;
            }
            SelectedDev = treeView1.SelectedNode.Text;
            
            if (SelectedDev.IndexOf("PCI-1220") >= 0)
            {
                refIndex = SelectedDev.IndexOf("(");
                bIDLen = SelectedDev.IndexOf(")") - refIndex - 2;
                string bID = SelectedDev.Substring(refIndex + 2, bIDLen);//Get the Device Name: ex.3240 3202 5240 and so on.
                uint boardID = Convert.ToUInt32(bID);

                processDevNum = ((uint)DevTypeID.PCI1220 << 24) + (boardID << 12);
                IntPtr hDevcie = new IntPtr();
                uint Result = Motion.mAcm_DevOpen(processDevNum, ref hDevcie);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Open device error", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Result = Motion.mAcm_SetProperty(hDevcie, (uint)PropertyID.CFG_DevBelongsTo, ref DeviceNum, 4);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Set device property error", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                Form1_Load(sender,e);
                UpdateList();

            }
            else
            {
                MessageBox.Show("Please select a master device", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }            
        }

        private void buttonDeleteSlave_Click(object sender, EventArgs e)
        {
            uint processDevNum = 0;
            string SelectedDev;
            int refIndex;
            int bIDLen;
            uint mastDevNum = new uint();

            if (!m_bInit)
            {
                return;
            }
            SelectedDev = treeView2.SelectedNode.Text;
            if (SelectedDev.IndexOf("PCI-1220(S") >= 0)
            {
                refIndex = SelectedDev.IndexOf("(");
                bIDLen = SelectedDev.IndexOf(")") - refIndex - 2;
                string bID = SelectedDev.Substring(refIndex + 2, bIDLen);//Get the Device Name: ex.3240 3202 5240 and so on.
                uint boardID = Convert.ToUInt32(bID);

                processDevNum = ((uint)DevTypeID.PCI1220 << 24) + (boardID << 12);
                IntPtr hDevcie = new IntPtr();
                uint Result = Motion.mAcm_DevOpen(processDevNum, ref hDevcie);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Open device error", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                mastDevNum = 0;
                Result = Motion.mAcm_SetProperty(hDevcie, (uint)PropertyID.CFG_DevBelongsTo, ref mastDevNum, 4);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    MessageBox.Show("Set device property error", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                Form1_Load(sender, e);
                UpdateList();
            }
            else
            {
                MessageBox.Show("Please select a slave device", "SetCardRelation", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }   
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
    }
}