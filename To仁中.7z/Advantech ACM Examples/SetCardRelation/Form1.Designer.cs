﻿using Advantech.Motion;//Common Motion API
using System;
namespace SetCardRelation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Motion Devices");
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.treeView2 = new System.Windows.Forms.TreeView();
            this.buttonSetSlave = new System.Windows.Forms.Button();
            this.buttonDeleteSlave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(140, 16);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(171, 20);
            this.CmbAvailableDevice.TabIndex = 25;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 24;
            this.label1.Text = "Available device:";
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(13, 73);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "Node0";
            treeNode1.Text = "Motion Devices";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.treeView1.Size = new System.Drawing.Size(190, 208);
            this.treeView1.TabIndex = 27;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // treeView2
            // 
            this.treeView2.Location = new System.Drawing.Point(353, 73);
            this.treeView2.Name = "treeView2";
            this.treeView2.Size = new System.Drawing.Size(181, 209);
            this.treeView2.TabIndex = 28;
            // 
            // buttonSetSlave
            // 
            this.buttonSetSlave.Location = new System.Drawing.Point(215, 104);
            this.buttonSetSlave.Name = "buttonSetSlave";
            this.buttonSetSlave.Size = new System.Drawing.Size(132, 23);
            this.buttonSetSlave.TabIndex = 29;
            this.buttonSetSlave.Text = "Set Slave Device";
            this.buttonSetSlave.UseVisualStyleBackColor = true;
            this.buttonSetSlave.Click += new System.EventHandler(this.buttonSetSlave_Click);
            // 
            // buttonDeleteSlave
            // 
            this.buttonDeleteSlave.Location = new System.Drawing.Point(215, 212);
            this.buttonDeleteSlave.Name = "buttonDeleteSlave";
            this.buttonDeleteSlave.Size = new System.Drawing.Size(130, 23);
            this.buttonDeleteSlave.TabIndex = 30;
            this.buttonDeleteSlave.Text = "Delete Slave Device";
            this.buttonDeleteSlave.UseVisualStyleBackColor = true;
            this.buttonDeleteSlave.Click += new System.EventHandler(this.buttonDeleteSlave_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 289);
            this.Controls.Add(this.buttonDeleteSlave);
            this.Controls.Add(this.buttonSetSlave);
            this.Controls.Add(this.treeView2);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.CmbAvailableDevice);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "SetCardRelation";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TreeView treeView2;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        string deviceName;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        Boolean m_bInit = false;
        private System.Windows.Forms.Button buttonSetSlave;
        private System.Windows.Forms.Button buttonDeleteSlave;
    }
}

