﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Threading;

namespace Master_AMONet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboMasterType.SelectedIndex=0;
            cboMasterBID.SelectedIndex = 0;
            cboRingNo.SelectedIndex = 0;
            IsMasOpen = false;
            IsRingOpen[0] = false;
            IsRingOpen[1] = false;
            buttonOpenSlaves.Enabled = false;
            buttonCloseSlaves.Enabled = false;
            buttonStartRing.Enabled = false;
            buttonStopRing.Enabled = false;


            // set master device number:SlaveBoardID = 0;MasterRingNo = 0xF;MasterBoardID = 0;MasterDevType = Adv_PCI1202;
            //             typedef union _ACM_DEV_NUM
            // {
            //     ULONG  data;
            //     struct {
            // 		ULONG    SlaveBoardID  : 8;
            // 		ULONG    MasterRingNo  : 4;
            // 		ULONG    MasterBoardID : 12;
            // 		ULONG    MasterDevType : 8;	
            //     } u;
            // }ACM_DEV_NUM, *PACM_DEV_NUM;
            MasDevNum = (uint)(DevTypeID.PCI1202);
            MasDevNum = (MasDevNum << 24) +  (15<< 8); 

        }

        private void buttonOpenMaster_Click(object sender, EventArgs e)
        {
            uint		ret;
            Byte[] szDllVersion = new Byte[32];
            Byte[] szDrvVersion = new Byte[32];
            uint data_size=32;
            uint rate;
            ret = Motion.mAcm_DevOpen(MasDevNum, ref hDevMaster);
            if (ret != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Master device doesn't  exist!", "Master_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ret = Motion.mAcm_GetProperty(hDevMaster, (uint)PropertyID.CFG_DevDllVersion, ref szDllVersion[0], ref data_size);
            ret = Motion.mAcm_GetProperty(hDevMaster, (uint)PropertyID.CFG_DevDriverVersion, ref szDrvVersion[0], ref data_size);

            rate = (uint)Baudrate.BR_AMONET_20M;
            ret = Motion.mAcm_SetProperty(hDevMaster, (uint)PropertyID.CFG_MasBaudRate_R0, ref rate, data_size);

            IsMasOpen = true;
            textBoxDllVersion.Text = Convert.ToString(szDllVersion);
            textBoxDriverVersion.Text = Convert.ToString(szDrvVersion);
            timer1.Enabled = true;
	
        }

        private void buttonCloseMaster_Click(object sender, EventArgs e)
        {
            uint ret;


            timer1.Enabled = false;
            ret = Motion.mAcm_DevClose(ref hDevMaster);
            if (ret != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Acm_DevClose master error!", "Master_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            IsMasOpen = false;
            buttonStartRing.Enabled = false;
            buttonStopRing.Enabled = false;
            buttonOpenSlaves.Enabled = false;
            buttonCloseSlaves.Enabled = false;
            textBoxRingState.Text = "Ring Disconnected";
                   
        }

        private void buttonStartRing_Click(object sender, EventArgs e)
        {
            uint ret;
            ushort MasStatus = new ushort();
            int max_wait_count = 1000;

            ret = Motion.mAcm_MasStartRing(hDevMaster, RingNo);
            if (ret != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Start Ring error!", "Master_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // check master status
            do
            {
                Thread.Sleep(1);
                ret = Motion.mAcm_MasGetComStatus(hDevMaster, RingNo, ref MasStatus);
                if (ret != (int)ErrorCode.SUCCESS || MasStatus == (ushort)ComStatus.COM_ST_CONNECTED || MasStatus == (ushort)ComStatus.COM_ST_ERROR)
                    break;
            } while ((max_wait_count--)>0);

            if (MasStatus != (ushort)ComStatus.COM_ST_CONNECTED)
            {
                MessageBox.Show("Start Ring failed!", "Master_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            IsRingOpen[RingNo] = true;
        }

        private void buttonStopRing_Click(object sender, EventArgs e)
        {
            uint ret;

            ret = Motion.mAcm_MasStopRing(hDevMaster, RingNo);
            if (ret != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Acm_MasStopRing error!", "Master_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            IsRingOpen[RingNo] = false;
        }

        private void buttonOpenSlaves_Click(object sender, EventArgs e)
        {
            UInt16		SlaveIP;
            bool	Active;
            UInt32[] ActTable=new UInt32[2];	
            UInt32 array_count=2;
            UInt32 ret;
            UInt32 SlvDevNum;

            ActTable[0] = 0;
            ActTable[1] = 0;
            Motion.mAcm_MasGetActiveTable(hDevMaster, RingNo, ActTable, ref array_count);
            for (SlaveIP = 0; SlaveIP < 64; SlaveIP++)
            {
                Active = false;
                if (SlaveIP < 32)
                {
                    if ((ActTable[0] & (0x01 << SlaveIP)) > 0)
                        Active = true;
                }
                else
                {
                    if ((ActTable[1] & (0x01 << (SlaveIP - 32))) > 0)
                        Active = true;
                }

                if (Active)
                {
                    // make slave device number and open it
                    //{
                    //     ULONG  data;
                    //     struct {
                    // 		ULONG    SlaveBoardID  : 8;
                    // 		ULONG    MasterRingNo  : 4;
                    // 		ULONG    MasterBoardID : 12;
                    // 		ULONG    MasterDevType : 8;	
                    //     } u;
                    // }ACM_DEV_NUM, *PACM_DEV_NUM;
                    SlvDevNum = (UInt32)(MasDevNum & 0xfffff000 + (RingNo << 8) + SlaveIP);
                    ret = Motion.mAcm_DevOpen(SlvDevNum, ref hDevSlave[RingNo][SlaveIP]);
                    if (ret != (int)ErrorCode.SUCCESS)
                    {
                        MessageBox.Show("Slave device [" + Convert.ToString(SlaveIP, 10) + "] doesn't exist!(Err=" + Convert.ToString(ret, 16) + "h)!", "Master_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }

            }
	


	

        }

        private void buttonCloseSlaves_Click(object sender, EventArgs e)
        {
            UInt16		SlaveIP;
	        bool	Active;
            UInt32[] ActTable=new UInt32[2];	
            UInt32 array_count=2;
	        UInt32		ret;
            ActTable[0] = 0;
            ActTable[1] = 0;

            Motion.mAcm_MasGetActiveTable(hDevMaster, RingNo, ActTable, ref array_count);
            for (SlaveIP = 0; SlaveIP < 64; SlaveIP++)
            {
                Active = false;
                if (SlaveIP < 32)
                {
                    if ((ActTable[0] & (0x01 << SlaveIP)) > 0)
                        Active = true;
                }
                else
                {
                    if ((ActTable[1] & (0x01 << (SlaveIP - 32))) > 0)
                        Active = true;
                }

                if (Active)
                {
                    ret = Motion.mAcm_DevClose(ref hDevSlave[RingNo][SlaveIP]);
                    if (ret != (int)ErrorCode.SUCCESS)
                    {
                        MessageBox.Show("Close slave device [" + Convert.ToString(SlaveIP, 10) + "] failed(Err=" + Convert.ToString(ret, 16) + "h)!", "Master_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
		
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ushort	RingStatus = new ushort();
            UInt32[] ActTableArray = new UInt32[2];
            UInt32[] ErrTableArray=new UInt32[2];
            UInt32 array_count=2;
	        UInt32		ret;
            string strInfo = "";
            double IoTime = new double();
            double DataTime= new double();


            // master 
            ret = Motion.mAcm_MasGetComStatus(hDevMaster, RingNo, ref RingStatus);
            ret = Motion.mAcm_MasGetActiveTable(hDevMaster, RingNo, ActTableArray, ref array_count);
            ret = Motion.mAcm_MasGetErrorTable(hDevMaster, RingNo, ErrTableArray, ref array_count);
            ret = Motion.mAcm_MasGetComCyclicTime(hDevMaster, RingNo, ref IoTime);
            ret = Motion.mAcm_MasGetDataCyclicTime(hDevMaster, RingNo, ref DataTime);
            switch (RingStatus)
            {
                case (ushort)COM_STATE.COM_ST_DISCONNECTED: strInfo = "Ring Disconnected"; break;
                case (ushort)COM_STATE.COM_ST_CONNECTED: strInfo = "Ring Connected"; break;
                case (ushort)COM_STATE.COM_ST_SLAVE_ERROR: strInfo = "Slave error"; break;
                case (ushort)COM_STATE.COM_ST_BUSY: strInfo = "Ring busy"; break;
                case (ushort)COM_STATE.COM_ST_ERROR: strInfo = "Ring error"; break;
            }


            textBoxRingState.Text = strInfo;

            textBoxActTabHI.Text = Convert.ToString(ActTableArray[1]);
            textBoxActTabLO.Text = Convert.ToString(ActTableArray[0]);
            textBoxErrTabHI.Text = Convert.ToString(ErrTableArray[1]);
            textBoxErrTabLO.Text = Convert.ToString(ErrTableArray[0]);

            textBoxIOTime.Text = Convert.ToString(IoTime);
            textBoxDataTime.Text = Convert.ToString(DataTime);

            // Enable/Disable control
            buttonStartRing.Enabled = IsMasOpen;
            buttonStopRing.Enabled = IsMasOpen;
            buttonOpenSlaves.Enabled = IsRingOpen[RingNo];
            buttonCloseSlaves.Enabled = IsRingOpen[RingNo];
	
        }

        private void cboRingNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            RingNo = (UInt16)(cboRingNo.SelectedIndex);
        }

        private void cboMasterType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // set master device number:SlaveBoardID = 0;MasterRingNo = 0xF;MasterBoardID = 0;MasterDevType = Adv_PCI1202;
            //             typedef union _ACM_DEV_NUM
            // {
            //     ULONG  data;
            //     struct {
            // 		ULONG    SlaveBoardID  : 8;
            // 		ULONG    MasterRingNo  : 4;
            // 		ULONG    MasterBoardID : 12;
            // 		ULONG    MasterDevType : 8;	
            //     } u;
            // }ACM_DEV_NUM, *PACM_DEV_NUM;
            if (cboMasterType.SelectedText == "PCI-1202")
            {
                MasDevNum = MasDevNum & 0xff000000 + (uint)(DevTypeID.PCI1202)<<24;
            }
            else if (cboMasterType.SelectedText == "APAX5202")
            {
                MasDevNum = MasDevNum & 0xff000000 + (uint)(DevTypeID.ADAM5202)<<24;
            }
            else
            {
                MasDevNum = MasDevNum & 0xff000000 + (uint)(DevTypeID.PCM3202)<<24 ;
            }
        }

        private void cboMasterBID_SelectedIndexChanged(object sender, EventArgs e)
        {
            // set master device number:SlaveBoardID = 0;MasterRingNo = 0xF;MasterBoardID = 0;MasterDevType = Adv_PCI1202;
            //             typedef union _ACM_DEV_NUM
            // {
            //     ULONG  data;
            //     struct {
            // 		ULONG    SlaveBoardID  : 8;
            // 		ULONG    MasterRingNo  : 4;
            // 		ULONG    MasterBoardID : 12;
            // 		ULONG    MasterDevType : 8;	
            //     } u;
            // }ACM_DEV_NUM, *PACM_DEV_NUM;
            UInt16 BID;
            BID = (UInt16)cboMasterBID.SelectedIndex;
            MasDevNum = (uint)((MasDevNum & 0xff000fff) + (BID << 12));
        }

        
    }
}