﻿using System;
namespace Master_AMONet
{    

    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonOpenMaster = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxDriverVersion = new System.Windows.Forms.TextBox();
            this.textBoxDllVersion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cboMasterType = new System.Windows.Forms.ComboBox();
            this.cboMasterBID = new System.Windows.Forms.ComboBox();
            this.cboRingNo = new System.Windows.Forms.ComboBox();
            this.textBoxActTabHI = new System.Windows.Forms.TextBox();
            this.textBoxActTabLO = new System.Windows.Forms.TextBox();
            this.textBoxErrTabLO = new System.Windows.Forms.TextBox();
            this.textBoxErrTabHI = new System.Windows.Forms.TextBox();
            this.textBoxIOTime = new System.Windows.Forms.TextBox();
            this.textBoxDataTime = new System.Windows.Forms.TextBox();
            this.textBoxRingState = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonCloseSlaves = new System.Windows.Forms.Button();
            this.buttonOpenSlaves = new System.Windows.Forms.Button();
            this.buttonStopRing = new System.Windows.Forms.Button();
            this.buttonStartRing = new System.Windows.Forms.Button();
            this.buttonCloseMaster = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonOpenMaster
            // 
            this.buttonOpenMaster.Location = new System.Drawing.Point(304, 16);
            this.buttonOpenMaster.Name = "buttonOpenMaster";
            this.buttonOpenMaster.Size = new System.Drawing.Size(129, 23);
            this.buttonOpenMaster.TabIndex = 0;
            this.buttonOpenMaster.Text = "Open Master";
            this.buttonOpenMaster.UseVisualStyleBackColor = true;
            this.buttonOpenMaster.Click += new System.EventHandler(this.buttonOpenMaster_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBoxDriverVersion);
            this.groupBox1.Controls.Add(this.textBoxDllVersion);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox1.Location = new System.Drawing.Point(8, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(439, 57);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Driver Version";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "Dll version";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(235, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "Driver version";
            // 
            // textBoxDriverVersion
            // 
            this.textBoxDriverVersion.Location = new System.Drawing.Point(330, 23);
            this.textBoxDriverVersion.Name = "textBoxDriverVersion";
            this.textBoxDriverVersion.ReadOnly = true;
            this.textBoxDriverVersion.Size = new System.Drawing.Size(92, 21);
            this.textBoxDriverVersion.TabIndex = 3;
            this.textBoxDriverVersion.TabStop = false;
            // 
            // textBoxDllVersion
            // 
            this.textBoxDllVersion.Location = new System.Drawing.Point(83, 23);
            this.textBoxDllVersion.Name = "textBoxDllVersion";
            this.textBoxDllVersion.ReadOnly = true;
            this.textBoxDllVersion.Size = new System.Drawing.Size(101, 21);
            this.textBoxDllVersion.TabIndex = 2;
            this.textBoxDllVersion.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "Master Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "Master BoardID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 91);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "Ring No";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "Active Table(63-0)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 152);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "Error Table(63-0)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 178);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "IO Cyclic Time";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 206);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "Data Cyclic Time";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 234);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "Ring State";
            // 
            // cboMasterType
            // 
            this.cboMasterType.FormattingEnabled = true;
            this.cboMasterType.Items.AddRange(new object[] {
            "PCI-1202",
            "APAX5202",
            "PCM3202P"});
            this.cboMasterType.Location = new System.Drawing.Point(136, 20);
            this.cboMasterType.Name = "cboMasterType";
            this.cboMasterType.Size = new System.Drawing.Size(121, 20);
            this.cboMasterType.TabIndex = 10;
            this.cboMasterType.SelectedIndexChanged += new System.EventHandler(this.cboMasterType_SelectedIndexChanged);
            // 
            // cboMasterBID
            // 
            this.cboMasterBID.FormattingEnabled = true;
            this.cboMasterBID.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cboMasterBID.Location = new System.Drawing.Point(136, 48);
            this.cboMasterBID.Name = "cboMasterBID";
            this.cboMasterBID.Size = new System.Drawing.Size(121, 20);
            this.cboMasterBID.TabIndex = 11;
            this.cboMasterBID.SelectedIndexChanged += new System.EventHandler(this.cboMasterBID_SelectedIndexChanged);
            // 
            // cboRingNo
            // 
            this.cboRingNo.FormattingEnabled = true;
            this.cboRingNo.Items.AddRange(new object[] {
            "0",
            "1"});
            this.cboRingNo.Location = new System.Drawing.Point(136, 86);
            this.cboRingNo.Name = "cboRingNo";
            this.cboRingNo.Size = new System.Drawing.Size(121, 20);
            this.cboRingNo.TabIndex = 12;
            this.cboRingNo.SelectedIndexChanged += new System.EventHandler(this.cboRingNo_SelectedIndexChanged);
            // 
            // textBoxActTabHI
            // 
            this.textBoxActTabHI.Location = new System.Drawing.Point(136, 122);
            this.textBoxActTabHI.Name = "textBoxActTabHI";
            this.textBoxActTabHI.ReadOnly = true;
            this.textBoxActTabHI.Size = new System.Drawing.Size(63, 21);
            this.textBoxActTabHI.TabIndex = 13;
            // 
            // textBoxActTabLO
            // 
            this.textBoxActTabLO.Location = new System.Drawing.Point(195, 122);
            this.textBoxActTabLO.Name = "textBoxActTabLO";
            this.textBoxActTabLO.ReadOnly = true;
            this.textBoxActTabLO.Size = new System.Drawing.Size(62, 21);
            this.textBoxActTabLO.TabIndex = 14;
            // 
            // textBoxErrTabLO
            // 
            this.textBoxErrTabLO.Location = new System.Drawing.Point(195, 149);
            this.textBoxErrTabLO.Name = "textBoxErrTabLO";
            this.textBoxErrTabLO.ReadOnly = true;
            this.textBoxErrTabLO.Size = new System.Drawing.Size(62, 21);
            this.textBoxErrTabLO.TabIndex = 16;
            // 
            // textBoxErrTabHI
            // 
            this.textBoxErrTabHI.Location = new System.Drawing.Point(136, 149);
            this.textBoxErrTabHI.Name = "textBoxErrTabHI";
            this.textBoxErrTabHI.ReadOnly = true;
            this.textBoxErrTabHI.Size = new System.Drawing.Size(63, 21);
            this.textBoxErrTabHI.TabIndex = 15;
            // 
            // textBoxIOTime
            // 
            this.textBoxIOTime.Location = new System.Drawing.Point(136, 175);
            this.textBoxIOTime.Name = "textBoxIOTime";
            this.textBoxIOTime.ReadOnly = true;
            this.textBoxIOTime.Size = new System.Drawing.Size(121, 21);
            this.textBoxIOTime.TabIndex = 17;
            // 
            // textBoxDataTime
            // 
            this.textBoxDataTime.Location = new System.Drawing.Point(136, 202);
            this.textBoxDataTime.Name = "textBoxDataTime";
            this.textBoxDataTime.ReadOnly = true;
            this.textBoxDataTime.Size = new System.Drawing.Size(121, 21);
            this.textBoxDataTime.TabIndex = 18;
            // 
            // textBoxRingState
            // 
            this.textBoxRingState.Location = new System.Drawing.Point(136, 229);
            this.textBoxRingState.Name = "textBoxRingState";
            this.textBoxRingState.ReadOnly = true;
            this.textBoxRingState.Size = new System.Drawing.Size(121, 21);
            this.textBoxRingState.TabIndex = 19;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonCloseSlaves);
            this.groupBox2.Controls.Add(this.buttonOpenSlaves);
            this.groupBox2.Controls.Add(this.buttonStopRing);
            this.groupBox2.Controls.Add(this.buttonStartRing);
            this.groupBox2.Controls.Add(this.buttonCloseMaster);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.cboMasterBID);
            this.groupBox2.Controls.Add(this.textBoxRingState);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textBoxDataTime);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textBoxIOTime);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.textBoxErrTabLO);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.textBoxErrTabHI);
            this.groupBox2.Controls.Add(this.cboMasterType);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.textBoxActTabLO);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cboRingNo);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.textBoxActTabHI);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.buttonOpenMaster);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(8, 77);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(439, 256);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Master";
            // 
            // buttonCloseSlaves
            // 
            this.buttonCloseSlaves.Location = new System.Drawing.Point(304, 167);
            this.buttonCloseSlaves.Name = "buttonCloseSlaves";
            this.buttonCloseSlaves.Size = new System.Drawing.Size(129, 23);
            this.buttonCloseSlaves.TabIndex = 28;
            this.buttonCloseSlaves.Text = "Close Ring\'s Slaves";
            this.buttonCloseSlaves.UseVisualStyleBackColor = true;
            this.buttonCloseSlaves.Click += new System.EventHandler(this.buttonCloseSlaves_Click);
            // 
            // buttonOpenSlaves
            // 
            this.buttonOpenSlaves.Location = new System.Drawing.Point(304, 140);
            this.buttonOpenSlaves.Name = "buttonOpenSlaves";
            this.buttonOpenSlaves.Size = new System.Drawing.Size(129, 23);
            this.buttonOpenSlaves.TabIndex = 27;
            this.buttonOpenSlaves.Text = "Open Ring\'s Slaves";
            this.buttonOpenSlaves.UseVisualStyleBackColor = true;
            this.buttonOpenSlaves.Click += new System.EventHandler(this.buttonOpenSlaves_Click);
            // 
            // buttonStopRing
            // 
            this.buttonStopRing.Location = new System.Drawing.Point(304, 102);
            this.buttonStopRing.Name = "buttonStopRing";
            this.buttonStopRing.Size = new System.Drawing.Size(129, 23);
            this.buttonStopRing.TabIndex = 26;
            this.buttonStopRing.Text = "Stop Ring";
            this.buttonStopRing.UseVisualStyleBackColor = true;
            this.buttonStopRing.Click += new System.EventHandler(this.buttonStopRing_Click);
            // 
            // buttonStartRing
            // 
            this.buttonStartRing.Location = new System.Drawing.Point(304, 75);
            this.buttonStartRing.Name = "buttonStartRing";
            this.buttonStartRing.Size = new System.Drawing.Size(129, 23);
            this.buttonStartRing.TabIndex = 25;
            this.buttonStartRing.Text = "Start Ring";
            this.buttonStartRing.UseVisualStyleBackColor = true;
            this.buttonStartRing.Click += new System.EventHandler(this.buttonStartRing_Click);
            // 
            // buttonCloseMaster
            // 
            this.buttonCloseMaster.Location = new System.Drawing.Point(304, 42);
            this.buttonCloseMaster.Name = "buttonCloseMaster";
            this.buttonCloseMaster.Size = new System.Drawing.Size(129, 23);
            this.buttonCloseMaster.TabIndex = 24;
            this.buttonCloseMaster.Text = "Close Master";
            this.buttonCloseMaster.UseVisualStyleBackColor = true;
            this.buttonCloseMaster.Click += new System.EventHandler(this.buttonCloseMaster_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(263, 205);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 12);
            this.label14.TabIndex = 23;
            this.label14.Text = "ms";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(263, 178);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 12);
            this.label13.TabIndex = 22;
            this.label13.Text = "ms";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(259, 152);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 12);
            this.label12.TabIndex = 21;
            this.label12.Text = "(hex)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(259, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 20;
            this.label11.Text = "(hex)";
            // 
            // timer1
            // 
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 343);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Master_AMONet";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonOpenMaster;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxDllVersion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxDriverVersion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cboMasterType;
        private System.Windows.Forms.ComboBox cboMasterBID;
        private System.Windows.Forms.ComboBox cboRingNo;
        private System.Windows.Forms.TextBox textBoxActTabHI;
        private System.Windows.Forms.TextBox textBoxActTabLO;
        private System.Windows.Forms.TextBox textBoxErrTabLO;
        private System.Windows.Forms.TextBox textBoxErrTabHI;
        private System.Windows.Forms.TextBox textBoxIOTime;
        private System.Windows.Forms.TextBox textBoxDataTime;
        private System.Windows.Forms.TextBox textBoxRingState;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonCloseSlaves;
        private System.Windows.Forms.Button buttonOpenSlaves;
        private System.Windows.Forms.Button buttonStopRing;
        private System.Windows.Forms.Button buttonStartRing;
        private System.Windows.Forms.Button buttonCloseMaster;


        IntPtr hDevMaster = IntPtr.Zero;
        ushort RingNo=0;
        IntPtr[][] hDevSlave = new IntPtr[2][];
	    uint	MasDevNum;
        //uint SlvDevNum;
	    bool		IsMasOpen;
	    bool[]		IsRingOpen=new bool[2];
        private System.Windows.Forms.Timer timer1;
    }
}

