﻿using Advantech.Motion;//Common Motion API
using System;
namespace EGear
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmb_SlaveAxis = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rdo_SlaveAbsolute = new System.Windows.Forms.RadioButton();
            this.rdo_SlaveRelative = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdo_FeedbackPos = new System.Windows.Forms.RadioButton();
            this.rdo_CommandPos = new System.Windows.Forms.RadioButton();
            this.txb_Denominator = new System.Windows.Forms.TextBox();
            this.btn_GearStop = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txb_Numerator = new System.Windows.Forms.TextBox();
            this.btn_GearIn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rdo_MasterAbsolute = new System.Windows.Forms.RadioButton();
            this.rdo_MasterRelative = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txb_Distance = new System.Windows.Forms.TextBox();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.rdo_ContinueMove = new System.Windows.Forms.RadioButton();
            this.rdo_PtoPMove = new System.Windows.Forms.RadioButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.rdo_SCurve = new System.Windows.Forms.RadioButton();
            this.rdo_TCurve = new System.Windows.Forms.RadioButton();
            this.btn_GoPositive = new System.Windows.Forms.Button();
            this.btn_GoNegative = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_MasterAxis = new System.Windows.Forms.ComboBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txb_SlaveCommand = new System.Windows.Forms.TextBox();
            this.txb_SlaveFeedback = new System.Windows.Forms.TextBox();
            this.btn_ResetCounter = new System.Windows.Forms.Button();
            this.Lable = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txb_MasterCommand = new System.Windows.Forms.TextBox();
            this.txb_MasterFeedback = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_ResetError = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_MasterAxisState = new System.Windows.Forms.TextBox();
            this.txb_SlaveAxisState = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.group = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.group.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.SuspendLayout();
            // 
            // cmb_SlaveAxis
            // 
            this.cmb_SlaveAxis.FormattingEnabled = true;
            this.cmb_SlaveAxis.Location = new System.Drawing.Point(129, 20);
            this.cmb_SlaveAxis.Name = "cmb_SlaveAxis";
            this.cmb_SlaveAxis.Size = new System.Drawing.Size(175, 20);
            this.cmb_SlaveAxis.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 20;
            this.label2.Text = "Slave Axis:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.txb_Denominator);
            this.groupBox1.Controls.Add(this.btn_GearStop);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txb_Numerator);
            this.groupBox1.Controls.Add(this.btn_GearIn);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cmb_SlaveAxis);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(17, 129);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(357, 204);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Slave Axis Operation";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rdo_SlaveAbsolute);
            this.groupBox7.Controls.Add(this.rdo_SlaveRelative);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox7.Location = new System.Drawing.Point(180, 114);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(169, 45);
            this.groupBox7.TabIndex = 37;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Movement Mode";
            // 
            // rdo_SlaveAbsolute
            // 
            this.rdo_SlaveAbsolute.AutoSize = true;
            this.rdo_SlaveAbsolute.Location = new System.Drawing.Point(13, 20);
            this.rdo_SlaveAbsolute.Name = "rdo_SlaveAbsolute";
            this.rdo_SlaveAbsolute.Size = new System.Drawing.Size(71, 16);
            this.rdo_SlaveAbsolute.TabIndex = 1;
            this.rdo_SlaveAbsolute.Text = "Absolute";
            this.rdo_SlaveAbsolute.UseVisualStyleBackColor = true;
            // 
            // rdo_SlaveRelative
            // 
            this.rdo_SlaveRelative.AutoSize = true;
            this.rdo_SlaveRelative.Checked = true;
            this.rdo_SlaveRelative.Location = new System.Drawing.Point(92, 21);
            this.rdo_SlaveRelative.Name = "rdo_SlaveRelative";
            this.rdo_SlaveRelative.Size = new System.Drawing.Size(71, 16);
            this.rdo_SlaveRelative.TabIndex = 0;
            this.rdo_SlaveRelative.TabStop = true;
            this.rdo_SlaveRelative.Text = "Relative";
            this.rdo_SlaveRelative.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdo_FeedbackPos);
            this.groupBox2.Controls.Add(this.rdo_CommandPos);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(10, 114);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(160, 45);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reference Source";
            // 
            // rdo_FeedbackPos
            // 
            this.rdo_FeedbackPos.AutoSize = true;
            this.rdo_FeedbackPos.Location = new System.Drawing.Point(88, 20);
            this.rdo_FeedbackPos.Name = "rdo_FeedbackPos";
            this.rdo_FeedbackPos.Size = new System.Drawing.Size(65, 16);
            this.rdo_FeedbackPos.TabIndex = 1;
            this.rdo_FeedbackPos.Text = "Fdb Pos";
            this.rdo_FeedbackPos.UseVisualStyleBackColor = true;
            // 
            // rdo_CommandPos
            // 
            this.rdo_CommandPos.AutoSize = true;
            this.rdo_CommandPos.Checked = true;
            this.rdo_CommandPos.Location = new System.Drawing.Point(12, 20);
            this.rdo_CommandPos.Name = "rdo_CommandPos";
            this.rdo_CommandPos.Size = new System.Drawing.Size(65, 16);
            this.rdo_CommandPos.TabIndex = 0;
            this.rdo_CommandPos.TabStop = true;
            this.rdo_CommandPos.Text = "Cmd Pos";
            this.rdo_CommandPos.UseVisualStyleBackColor = true;
            // 
            // txb_Denominator
            // 
            this.txb_Denominator.Location = new System.Drawing.Point(130, 78);
            this.txb_Denominator.Name = "txb_Denominator";
            this.txb_Denominator.Size = new System.Drawing.Size(139, 21);
            this.txb_Denominator.TabIndex = 35;
            this.txb_Denominator.Text = "1";
            // 
            // btn_GearStop
            // 
            this.btn_GearStop.Location = new System.Drawing.Point(208, 168);
            this.btn_GearStop.Name = "btn_GearStop";
            this.btn_GearStop.Size = new System.Drawing.Size(88, 26);
            this.btn_GearStop.TabIndex = 39;
            this.btn_GearStop.Text = "Stop";
            this.btn_GearStop.UseVisualStyleBackColor = true;
            this.btn_GearStop.Click += new System.EventHandler(this.btn_GearStop_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(48, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 34;
            this.label9.Text = "Denominator:";
            // 
            // txb_Numerator
            // 
            this.txb_Numerator.Location = new System.Drawing.Point(130, 49);
            this.txb_Numerator.Name = "txb_Numerator";
            this.txb_Numerator.Size = new System.Drawing.Size(139, 21);
            this.txb_Numerator.TabIndex = 33;
            this.txb_Numerator.Text = "1";
            // 
            // btn_GearIn
            // 
            this.btn_GearIn.Location = new System.Drawing.Point(67, 168);
            this.btn_GearIn.Name = "btn_GearIn";
            this.btn_GearIn.Size = new System.Drawing.Size(88, 26);
            this.btn_GearIn.TabIndex = 38;
            this.btn_GearIn.Text = "Gear In";
            this.btn_GearIn.UseVisualStyleBackColor = true;
            this.btn_GearIn.Click += new System.EventHandler(this.btn_GearIn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(63, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 32;
            this.label8.Text = "Numerator:";
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openFileDialog1";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.txb_Distance);
            this.groupBox3.Controls.Add(this.btn_Stop);
            this.groupBox3.Controls.Add(this.groupBox9);
            this.groupBox3.Controls.Add(this.groupBox10);
            this.groupBox3.Controls.Add(this.btn_GoPositive);
            this.groupBox3.Controls.Add(this.btn_GoNegative);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.cmb_MasterAxis);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(390, 11);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(334, 255);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Master Axis Operation";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rdo_MasterAbsolute);
            this.groupBox5.Controls.Add(this.rdo_MasterRelative);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox5.Location = new System.Drawing.Point(15, 91);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(303, 45);
            this.groupBox5.TabIndex = 48;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Movement Mode";
            // 
            // rdo_MasterAbsolute
            // 
            this.rdo_MasterAbsolute.AutoSize = true;
            this.rdo_MasterAbsolute.Location = new System.Drawing.Point(188, 19);
            this.rdo_MasterAbsolute.Name = "rdo_MasterAbsolute";
            this.rdo_MasterAbsolute.Size = new System.Drawing.Size(71, 16);
            this.rdo_MasterAbsolute.TabIndex = 1;
            this.rdo_MasterAbsolute.Text = "Absolute";
            this.rdo_MasterAbsolute.UseVisualStyleBackColor = true;
            // 
            // rdo_MasterRelative
            // 
            this.rdo_MasterRelative.AutoSize = true;
            this.rdo_MasterRelative.Checked = true;
            this.rdo_MasterRelative.Location = new System.Drawing.Point(22, 20);
            this.rdo_MasterRelative.Name = "rdo_MasterRelative";
            this.rdo_MasterRelative.Size = new System.Drawing.Size(71, 16);
            this.rdo_MasterRelative.TabIndex = 0;
            this.rdo_MasterRelative.TabStop = true;
            this.rdo_MasterRelative.Text = "Relative";
            this.rdo_MasterRelative.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(226, 197);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 12);
            this.label16.TabIndex = 47;
            this.label16.Text = "PPU";
            // 
            // label21
            // 
            this.label21.Location = new System.Drawing.Point(17, 195);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 12);
            this.label21.TabIndex = 45;
            this.label21.Text = "Distance:";
            // 
            // txb_Distance
            // 
            this.txb_Distance.Location = new System.Drawing.Point(78, 191);
            this.txb_Distance.Name = "txb_Distance";
            this.txb_Distance.Size = new System.Drawing.Size(142, 21);
            this.txb_Distance.TabIndex = 46;
            this.txb_Distance.Text = "10000";
            // 
            // btn_Stop
            // 
            this.btn_Stop.Location = new System.Drawing.Point(240, 222);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(75, 24);
            this.btn_Stop.TabIndex = 43;
            this.btn_Stop.Text = "Stop";
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.rdo_ContinueMove);
            this.groupBox9.Controls.Add(this.rdo_PtoPMove);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox9.Location = new System.Drawing.Point(16, 140);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(303, 44);
            this.groupBox9.TabIndex = 41;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Motion Mode";
            // 
            // rdo_ContinueMove
            // 
            this.rdo_ContinueMove.Location = new System.Drawing.Point(187, 18);
            this.rdo_ContinueMove.Name = "rdo_ContinueMove";
            this.rdo_ContinueMove.Size = new System.Drawing.Size(71, 24);
            this.rdo_ContinueMove.TabIndex = 4;
            this.rdo_ContinueMove.Text = "Continue";
            // 
            // rdo_PtoPMove
            // 
            this.rdo_PtoPMove.Checked = true;
            this.rdo_PtoPMove.Location = new System.Drawing.Point(21, 17);
            this.rdo_PtoPMove.Name = "rdo_PtoPMove";
            this.rdo_PtoPMove.Size = new System.Drawing.Size(104, 24);
            this.rdo_PtoPMove.TabIndex = 5;
            this.rdo_PtoPMove.TabStop = true;
            this.rdo_PtoPMove.Text = "P to P";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.rdo_SCurve);
            this.groupBox10.Controls.Add(this.rdo_TCurve);
            this.groupBox10.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox10.Location = new System.Drawing.Point(16, 45);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(303, 42);
            this.groupBox10.TabIndex = 38;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Speed Pattern";
            // 
            // rdo_SCurve
            // 
            this.rdo_SCurve.Location = new System.Drawing.Point(188, 15);
            this.rdo_SCurve.Name = "rdo_SCurve";
            this.rdo_SCurve.Size = new System.Drawing.Size(63, 21);
            this.rdo_SCurve.TabIndex = 3;
            this.rdo_SCurve.Text = "S-curve";
            // 
            // rdo_TCurve
            // 
            this.rdo_TCurve.Checked = true;
            this.rdo_TCurve.Location = new System.Drawing.Point(22, 17);
            this.rdo_TCurve.Name = "rdo_TCurve";
            this.rdo_TCurve.Size = new System.Drawing.Size(66, 24);
            this.rdo_TCurve.TabIndex = 4;
            this.rdo_TCurve.TabStop = true;
            this.rdo_TCurve.Text = "Trapezia";
            // 
            // btn_GoPositive
            // 
            this.btn_GoPositive.Location = new System.Drawing.Point(133, 222);
            this.btn_GoPositive.Name = "btn_GoPositive";
            this.btn_GoPositive.Size = new System.Drawing.Size(75, 24);
            this.btn_GoPositive.TabIndex = 42;
            this.btn_GoPositive.Text = "-->";
            this.btn_GoPositive.Click += new System.EventHandler(this.btn_GoPositive_Click);
            // 
            // btn_GoNegative
            // 
            this.btn_GoNegative.Location = new System.Drawing.Point(26, 222);
            this.btn_GoNegative.Name = "btn_GoNegative";
            this.btn_GoNegative.Size = new System.Drawing.Size(75, 24);
            this.btn_GoNegative.TabIndex = 44;
            this.btn_GoNegative.Text = "<--";
            this.btn_GoNegative.Click += new System.EventHandler(this.btn_GoNegative_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 22;
            this.label6.Text = "Master Axis:";
            // 
            // cmb_MasterAxis
            // 
            this.cmb_MasterAxis.FormattingEnabled = true;
            this.cmb_MasterAxis.Location = new System.Drawing.Point(107, 20);
            this.cmb_MasterAxis.Name = "cmb_MasterAxis";
            this.cmb_MasterAxis.Size = new System.Drawing.Size(176, 20);
            this.cmb_MasterAxis.TabIndex = 23;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label24);
            this.groupBox11.Controls.Add(this.txb_SlaveCommand);
            this.groupBox11.Controls.Add(this.txb_SlaveFeedback);
            this.groupBox11.Controls.Add(this.btn_ResetCounter);
            this.groupBox11.Controls.Add(this.Lable);
            this.groupBox11.Controls.Add(this.label22);
            this.groupBox11.Controls.Add(this.txb_MasterCommand);
            this.groupBox11.Controls.Add(this.txb_MasterFeedback);
            this.groupBox11.Controls.Add(this.label23);
            this.groupBox11.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox11.Location = new System.Drawing.Point(390, 272);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(334, 128);
            this.groupBox11.TabIndex = 41;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Position";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(197, 18);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 14;
            this.label24.Text = "Slave Axis";
            // 
            // txb_SlaveCommand
            // 
            this.txb_SlaveCommand.Location = new System.Drawing.Point(199, 36);
            this.txb_SlaveCommand.Name = "txb_SlaveCommand";
            this.txb_SlaveCommand.ReadOnly = true;
            this.txb_SlaveCommand.Size = new System.Drawing.Size(94, 21);
            this.txb_SlaveCommand.TabIndex = 12;
            this.txb_SlaveCommand.Text = "0";
            // 
            // txb_SlaveFeedback
            // 
            this.txb_SlaveFeedback.Location = new System.Drawing.Point(199, 62);
            this.txb_SlaveFeedback.Name = "txb_SlaveFeedback";
            this.txb_SlaveFeedback.ReadOnly = true;
            this.txb_SlaveFeedback.Size = new System.Drawing.Size(94, 21);
            this.txb_SlaveFeedback.TabIndex = 13;
            this.txb_SlaveFeedback.Text = "0";
            // 
            // btn_ResetCounter
            // 
            this.btn_ResetCounter.Location = new System.Drawing.Point(143, 92);
            this.btn_ResetCounter.Name = "btn_ResetCounter";
            this.btn_ResetCounter.Size = new System.Drawing.Size(96, 26);
            this.btn_ResetCounter.TabIndex = 40;
            this.btn_ResetCounter.Text = "Reset Counter";
            this.btn_ResetCounter.Click += new System.EventHandler(this.btn_ResetCounter_Click);
            // 
            // Lable
            // 
            this.Lable.AutoSize = true;
            this.Lable.Location = new System.Drawing.Point(92, 18);
            this.Lable.Name = "Lable";
            this.Lable.Size = new System.Drawing.Size(71, 12);
            this.Lable.TabIndex = 11;
            this.Lable.Text = "Master Axis";
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(33, 41);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 6;
            this.label22.Text = "Command:";
            // 
            // txb_MasterCommand
            // 
            this.txb_MasterCommand.Location = new System.Drawing.Point(90, 36);
            this.txb_MasterCommand.Name = "txb_MasterCommand";
            this.txb_MasterCommand.ReadOnly = true;
            this.txb_MasterCommand.Size = new System.Drawing.Size(100, 21);
            this.txb_MasterCommand.TabIndex = 7;
            this.txb_MasterCommand.Text = "0";
            // 
            // txb_MasterFeedback
            // 
            this.txb_MasterFeedback.Location = new System.Drawing.Point(90, 63);
            this.txb_MasterFeedback.Name = "txb_MasterFeedback";
            this.txb_MasterFeedback.ReadOnly = true;
            this.txb_MasterFeedback.Size = new System.Drawing.Size(100, 21);
            this.txb_MasterFeedback.TabIndex = 8;
            this.txb_MasterFeedback.Text = "0";
            // 
            // label23
            // 
            this.label23.Location = new System.Drawing.Point(26, 68);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 12);
            this.label23.TabIndex = 9;
            this.label23.Text = "Feedback:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_ResetError);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.txb_MasterAxisState);
            this.groupBox4.Controls.Add(this.txb_SlaveAxisState);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(17, 342);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(357, 121);
            this.groupBox4.TabIndex = 42;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Current Axis State";
            // 
            // btn_ResetError
            // 
            this.btn_ResetError.Location = new System.Drawing.Point(164, 86);
            this.btn_ResetError.Name = "btn_ResetError";
            this.btn_ResetError.Size = new System.Drawing.Size(88, 26);
            this.btn_ResetError.TabIndex = 44;
            this.btn_ResetError.Text = "Reset Error";
            this.btn_ResetError.UseVisualStyleBackColor = true;
            this.btn_ResetError.Click += new System.EventHandler(this.btn_ResetError_Click);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(89, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 18);
            this.label4.TabIndex = 26;
            this.label4.Text = "Slave Axis:";
            // 
            // txb_MasterAxisState
            // 
            this.txb_MasterAxisState.Location = new System.Drawing.Point(163, 24);
            this.txb_MasterAxisState.Name = "txb_MasterAxisState";
            this.txb_MasterAxisState.ReadOnly = true;
            this.txb_MasterAxisState.Size = new System.Drawing.Size(159, 21);
            this.txb_MasterAxisState.TabIndex = 24;
            this.txb_MasterAxisState.Text = "0";
            // 
            // txb_SlaveAxisState
            // 
            this.txb_SlaveAxisState.Location = new System.Drawing.Point(162, 53);
            this.txb_SlaveAxisState.Name = "txb_SlaveAxisState";
            this.txb_SlaveAxisState.ReadOnly = true;
            this.txb_SlaveAxisState.Size = new System.Drawing.Size(160, 21);
            this.txb_SlaveAxisState.TabIndex = 25;
            this.txb_SlaveAxisState.Text = "0";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(82, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 12);
            this.label5.TabIndex = 27;
            this.label5.Text = "Master Axis:";
            // 
            // group
            // 
            this.group.Controls.Add(this.label1);
            this.group.Controls.Add(this.CmbAvailableDevice);
            this.group.Controls.Add(this.BtnOpenBoard);
            this.group.Controls.Add(this.BtnCloseBoard);
            this.group.Controls.Add(this.BtnLoadCfg);
            this.group.Controls.Add(this.BtnServo);
            this.group.Location = new System.Drawing.Point(17, 10);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(357, 110);
            this.group.TabIndex = 48;
            this.group.TabStop = false;
            this.group.Text = "Device Operate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Available device:";
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(146, 19);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(157, 20);
            this.CmbAvailableDevice.TabIndex = 2;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(67, 44);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(92, 26);
            this.BtnOpenBoard.TabIndex = 3;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(220, 45);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(92, 26);
            this.BtnCloseBoard.TabIndex = 5;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(66, 76);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(92, 26);
            this.BtnLoadCfg.TabIndex = 4;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(220, 77);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(92, 26);
            this.BtnServo.TabIndex = 6;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox6.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox6.Controls.Add(this.pictureBoxORG);
            this.groupBox6.Controls.Add(this.pictureBoxALM);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox6.Location = new System.Drawing.Point(390, 406);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(334, 57);
            this.groupBox6.TabIndex = 59;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Master Axis Signal Status";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(263, 30);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 12);
            this.label14.TabIndex = 28;
            this.label14.Text = "-HEL:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(179, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 12);
            this.label15.TabIndex = 27;
            this.label15.Text = "+HEL:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(101, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 26;
            this.label19.Text = "ORG:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(17, 30);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 25;
            this.label20.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(298, 26);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(214, 26);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(130, 26);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(46, 26);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 483);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.group);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "E-Gear";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_SlaveAxis;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[32];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rdo_SlaveAbsolute;
        private System.Windows.Forms.RadioButton rdo_SlaveRelative;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdo_FeedbackPos;
        private System.Windows.Forms.RadioButton rdo_CommandPos;
        private System.Windows.Forms.TextBox txb_Denominator;
        private System.Windows.Forms.Button btn_GearStop;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txb_Numerator;
        private System.Windows.Forms.Button btn_GearIn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdo_MasterAbsolute;
        private System.Windows.Forms.RadioButton rdo_MasterRelative;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txb_Distance;
        private System.Windows.Forms.Button btn_Stop;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton rdo_ContinueMove;
        private System.Windows.Forms.RadioButton rdo_PtoPMove;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton rdo_SCurve;
        private System.Windows.Forms.RadioButton rdo_TCurve;
        private System.Windows.Forms.Button btn_GoPositive;
        private System.Windows.Forms.Button btn_GoNegative;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_MasterAxis;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txb_SlaveCommand;
        private System.Windows.Forms.TextBox txb_SlaveFeedback;
        private System.Windows.Forms.Label Lable;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txb_MasterCommand;
        private System.Windows.Forms.TextBox txb_MasterFeedback;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btn_ResetCounter;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txb_MasterAxisState;
        private System.Windows.Forms.TextBox txb_SlaveAxisState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_ResetError;
        private System.Windows.Forms.GroupBox group;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
    }
}

