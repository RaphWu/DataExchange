﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Runtime.InteropServices; //For Marshal
using System.Diagnostics;
namespace EGear
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            VersionIsOk = GetDevCfgDllDrvVer(); //Get Driver Version Number, this step is not necessary
        }
        Boolean VersionIsOk = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            if (VersionIsOk == false)
            {
                return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite 
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            double Pos = new double();
            UInt16 AxState = new UInt16();
            UInt32 IOStatus = new UInt32();
            uint Result;
            if (m_bInit)
            {
                //Get the motion I/O status of the axis.
                Result = Motion.mAcm_AxGetMotionIO(m_Axishand[cmb_MasterAxis.SelectedIndex], ref IOStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    GetMotionIOStatus(IOStatus);
                }
                //Get current command position of the specified axis
                Motion.mAcm_AxGetCmdPosition(m_Axishand[cmb_SlaveAxis.SelectedIndex], ref Pos);
                txb_SlaveCommand.Text = Convert.ToString(Pos);
                Motion.mAcm_AxGetCmdPosition(m_Axishand[cmb_MasterAxis.SelectedIndex],ref Pos);
                txb_MasterCommand.Text = Convert.ToString(Pos);
                //Get actual position for the specified axis
                Motion.mAcm_AxGetActualPosition(m_Axishand[cmb_SlaveAxis.SelectedIndex],ref Pos);
                txb_SlaveFeedback.Text = Convert.ToString(Pos);
                Motion.mAcm_AxGetActualPosition(m_Axishand[cmb_MasterAxis.SelectedIndex], ref Pos);
                txb_MasterFeedback.Text = Convert.ToString(Pos);
                //Get the axis's current state.
                Motion.mAcm_AxGetState(m_Axishand[cmb_SlaveAxis.SelectedIndex], ref AxState);
                txb_SlaveAxisState.Text = ((AxisState)AxState).ToString();
                Motion.mAcm_AxGetState(m_Axishand[cmb_MasterAxis.SelectedIndex], ref AxState);
                txb_MasterAxisState.Text = ((AxisState)AxState).ToString();
            }
        }     

        private void btn_GearIn_Click(object sender, EventArgs e)
        {
            int Numerator, Denominator;
            uint RefSrc = 0;  //Command Position
            uint Mode = 0;    //Relative
            string strTemp;
            Numerator = Convert.ToInt32(txb_Numerator.Text);
            Denominator = Convert.ToInt32(txb_Denominator.Text);
            if (rdo_FeedbackPos.Checked)
            {
                RefSrc = 1;
            }
            if (rdo_SlaveAbsolute.Checked)
            {
                Mode = 1;
            }
            if(m_bInit)
            {
                if (cmb_MasterAxis.SelectedIndex == cmb_SlaveAxis.SelectedIndex)
                {
                    MessageBox.Show("Slave Axis Can't Be The Same Axis With Master Axis!", "E-Gear", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                    return;
                }
                //This function starts gear synchronization with a ratio between a
                //slave (following) axis and master (leading) axis
                uint result = Motion.mAcm_AxGearInAx(m_Axishand[cmb_SlaveAxis.SelectedIndex], m_Axishand[cmb_MasterAxis.SelectedIndex], Numerator, Denominator, RefSrc, Mode);
                if (result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Gear Motion Failed With Error Code [0x" + Convert.ToString(result, 16) + "]";
                    ShowMessages(strTemp, result);
                    return;
                }
                cmb_MasterAxis.Enabled = false;
            }
        }

        private void btn_GearStop_Click(object sender, EventArgs e)
        {
            string strTemp;
            uint Result;
           //To command axis to decelerate to stop
            Result = Motion.mAcm_AxStopDec(m_Axishand[cmb_SlaveAxis.SelectedIndex]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Axis To Decelerate To Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            cmb_MasterAxis.Enabled = true;
        }

        private void btn_GoNegative_Click(object sender, EventArgs e)
        {
            double m_Jerk;
            uint Result;
            string strTemp;
            if(m_bInit)
            {               
                if (rdo_TCurve.Checked)
                {
                    m_Jerk = 0;                    
                    
                }
                else
                {
                    m_Jerk = 1;
                }
                Result = Motion.mAcm_SetF64Property(m_Axishand[cmb_MasterAxis.SelectedIndex], (uint)PropertyID.PAR_AxJerk, m_Jerk);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set Property - PAR_AxJerk Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (rdo_PtoPMove.Checked)
                {
                    if (rdo_MasterRelative.Checked)
                        //Start single axis's relative position motion.
                        Result = Motion.mAcm_AxMoveRel(m_Axishand[cmb_MasterAxis.SelectedIndex], Convert.ToDouble(txb_Distance.Text) * (-1));

                    else
                        //Start single axis's absolute position motion
                        Result = Motion.mAcm_AxMoveAbs(m_Axishand[cmb_MasterAxis.SelectedIndex], Convert.ToDouble(txb_Distance.Text) * (-1));
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "PTP Move Failed  With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
                else if (rdo_ContinueMove.Checked)
                {
                    //To command axis to make a never ending movement with a specified velocity
                    Result = Motion.mAcm_AxMoveVel(m_Axishand[cmb_MasterAxis.SelectedIndex], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Continue Move Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void btn_GoPositive_Click(object sender, EventArgs e)
        {
            double m_Jerk;
            uint Result;
            string strTemp;
            if(m_bInit)
            {
                if (rdo_TCurve.Checked)
                {
                    m_Jerk = 0;
                    //Set the type of velocity profile: t-curve or s-curve
                    //You can also use the old API:Motion.mAcm_SetF64Property(m_Axishand[cmb_MasterAxis.SelectedIndex], (uint)PropertyID.PAR_AxJerk, ref  m_Jerk,BufferLength)
                    //uint  BufferLength;
                    // BufferLength =8; buffer size for the property
                    Result = Motion.mAcm_SetF64Property(m_Axishand[cmb_MasterAxis.SelectedIndex], (uint)PropertyID.PAR_AxJerk, m_Jerk);
                }
                else
                {
                    m_Jerk = 1;
                    Result = Motion.mAcm_SetF64Property(m_Axishand[cmb_MasterAxis.SelectedIndex], (uint)PropertyID.PAR_AxJerk, m_Jerk);
                }
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set Property - PAR_AxJerk Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (rdo_PtoPMove.Checked)
                {
                    if (rdo_MasterRelative.Checked)
                        //Start single axis's relative position motion.
                        Result = Motion.mAcm_AxMoveRel(m_Axishand[cmb_MasterAxis.SelectedIndex], Convert.ToDouble(txb_Distance.Text));
                    else
                        //Start single axis's absolute position motion
                        Result = Motion.mAcm_AxMoveAbs(m_Axishand[cmb_MasterAxis.SelectedIndex], Convert.ToDouble(txb_Distance.Text));
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "PTP Move Failed  With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
                else if (rdo_ContinueMove.Checked)
                {
                    //To command axis to make a never ending movement with a specified velocity
                    Result = Motion.mAcm_AxMoveVel(m_Axishand[cmb_MasterAxis.SelectedIndex], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Continue Move Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void btn_Stop_Click(object sender, EventArgs e)
        {
            string strTemp;
            uint Result;
            //To command axis to decelerate to stop
            Result = Motion.mAcm_AxStopDec(m_Axishand[cmb_MasterAxis.SelectedIndex]);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Axis To Decelerate To Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void btn_ResetCounter_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            if (m_bInit)
            {
                //Set command position for the specified axis
                Result = Motion.mAcm_AxSetCmdPosition(m_Axishand[cmb_SlaveAxis.SelectedIndex], 0);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set axis's command position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                //Set actual position for the specified axis
                Result = Motion.mAcm_AxSetActualPosition(m_Axishand[cmb_SlaveAxis.SelectedIndex], 0);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set axis's command position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                Result = Motion.mAcm_AxSetCmdPosition(m_Axishand[cmb_MasterAxis.SelectedIndex], 0);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set axis's actual position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                Result = Motion.mAcm_AxSetActualPosition(m_Axishand[cmb_MasterAxis.SelectedIndex], 0);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set axis's actual position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                }
            }
        }

        private void btn_ResetError_Click(object sender, EventArgs e)
        {
            ushort axisState = 0;
            uint Result;
            string strTemp;
            if (m_bInit)
            {
                //Get axis's current state
                Motion.mAcm_AxGetState(m_Axishand[cmb_SlaveAxis.SelectedIndex], ref axisState);
                if (axisState == (uint)AxisState.STA_AX_ERROR_STOP)
                {
                    ////Reset the axis' state. If the axis is in ErrorStop state, the state will
                    //be changed to Ready after calling this function.
                    Result = Motion.mAcm_AxResetError(m_Axishand[cmb_SlaveAxis.SelectedIndex]);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Reset axis's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
                //Get axis's current state
                Motion.mAcm_AxGetState(m_Axishand[cmb_MasterAxis.SelectedIndex], ref axisState);
                if (axisState == (uint)AxisState.STA_AX_ERROR_STOP)
                {
                    ////Reset the axis' state. If the axis is in ErrorStop state, the state will
                    //be changed to Ready after calling this function.
                    Result = Motion.mAcm_AxResetError(m_Axishand[cmb_MasterAxis.SelectedIndex]);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Reset axis's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
        }

        private void BtnLoadCfg_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            this.OpenConfigFile.FileName = ".cfg";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, OpenConfigFile.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load Config Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }		 
        }
          //User-defined API to show error message
      private void ShowMessages(string DetailMessage, uint errorCode)
      {
          StringBuilder ErrorMsg = new StringBuilder("", 100);
          //Get the error message according to error code returned from API
          Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
          string ErrorMessage = "";
          if (res)
              ErrorMessage = ErrorMsg.ToString();
          MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "EGear", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      //User-defined API to close board
        private void CloseBoardOrForm()
        {
            UInt16[] usAxisState = new UInt16[32];
            uint AxisNum;
            //Stop Every Axes
            if (m_bInit == true)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Get the axis's current state.
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will
                        //be changed to Ready after calling this function.
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    // To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                //Close Axes
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);
                }
                m_ulAxisCount = 0;
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                timer1.Enabled = false;
                m_bInit = false;
                cmb_SlaveAxis.Items.Clear();
                cmb_MasterAxis.Text = "";
                cmb_SlaveAxis.Text = "";
                cmb_MasterAxis.Items.Clear();
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            uint i = 0;
            uint[] slaveDevs = new uint[16];
            uint AxesPerDev = new uint();
            string strTemp;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Open Device Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            //FT_DevAxesCount:Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Axis Number Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_ulAxisCount = AxesPerDev;
            cmb_SlaveAxis.Items.Clear();
            cmb_MasterAxis.Items.Clear();
            //if you device is fixed,for example: PCI-1245 m_ulAxisCount =4
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                //Open Axis 
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                cmb_SlaveAxis.Items.Add(String.Format("{0:d}-Axis", i));
                cmb_MasterAxis.Items.Add(String.Format("{0:d}-Axis", i));
                
                double cmdPosition = new double();
                cmdPosition = 0;
                //Reset Command Counter
                Motion.mAcm_AxSetCmdPosition(m_Axishand[i], cmdPosition);
                //Set actual position for the specified axis
                Motion.mAcm_AxSetActualPosition(m_Axishand[i], cmdPosition);
            }
            cmb_SlaveAxis.SelectedIndex = 0;
            cmb_MasterAxis.SelectedIndex = 1;
            m_bInit = true;
            timer1.Enabled = true;
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {
            UInt32 AxisNum;
            UInt32 Result;
            string strTemp;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver ON,1: On
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo On Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver OFF,0: Off
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo Off Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
        private void GetMotionIOStatus(uint IOStatus)
        {
            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ALM) > 0)//ALM
            {
                pictureBoxALM.BackColor = Color.Red;
            }
            else
            {
                pictureBoxALM.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ORG) > 0)//ORG
            {
                pictureBoxORG.BackColor = Color.Red;
            }
            else
            {
                pictureBoxORG.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTP) > 0)//+EL
            {
                pictureBoxPosHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxPosHEL.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTN) > 0)//-EL
            {
                pictureBoxNegHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxNegHEL.BackColor = Color.Gray;
            }
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {

                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "EGear", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;

            }
            return true;
        }
    }
}