﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Diagnostics;
namespace AIO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            VersionIsOk = GetDevCfgDllDrvVer();
        }
        Boolean VersionIsOk = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            //Get Driver Version Number, this step is not necessary
            
            if (VersionIsOk == false)
            {
                return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ushort rawData = 0;
            float voltData = 0.0f;
            //Get the binary value of an analog input value
            Motion.mAcm_DaqAiGetRawData(m_DeviceHandle, (ushort)cb_AiChan.SelectedIndex, ref rawData);
            //Get the actual analog input value.
            Motion.mAcm_DaqAiGetVoltData(m_DeviceHandle, (ushort)cb_AiChan.SelectedIndex, ref voltData);
            tb_RawData.Text = rawData.ToString();
            tb_VoltData.Text = voltData.ToString("f4");
        }

        private void btn_OpenBrd_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            uint buffer = 0;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Open Device Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            //Get CFG_DaqAiChanType Property value,show AI Channel Type: Single ended(value:0),Differential(value:1)
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.CFG_DaqAiChanType, ref buffer, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DaqAiChanType, ref buffer);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get AI Channel Type Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            cb_ChanType.SelectedIndex = (Int32)buffer;
            //Get the supported AI range. 1: support, 0: not support.
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.CFG_DaqAiRanges, ref buffer, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DaqAiRanges, ref buffer);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get AI Range Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            cb_Range.SelectedIndex = (Int32)buffer;
            cb_AiChan.SelectedIndex = 0;
            m_bInit = true;
            timer1.Enabled = true;
        }

        private void btn_CloseBrd_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();//Close Board
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();//Close Board And Form
        }

        private void btn_Set_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            uint buffer = 0;
            buffer = (uint)cb_ChanType.SelectedIndex;
            //Set CFG_DaqAiChanType Property value,Show AI Channel Type: Single ended(value:0),Differential(value:1)
            //You can also use the old API: Motion.mAcm_SetProperty(m_DeviceHandle, (uint)PropertyID.CFG_DaqAiChanType, ref buffer, BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DaqAiChanType, buffer);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set AI Channel Type Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            buffer = (uint)cb_Range.SelectedIndex;
            //Set CFG_DaqAiRanges property value,show the supported AI range. 1: support, 0: not support.
            //You can also use the old API: Motion.mAcm_SetProperty(m_DeviceHandle, (uint)PropertyID.CFG_DaqAiRanges, ref buffer, BufferLength);
           // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_DeviceHandle, (uint)PropertyID.CFG_DaqAiRanges, buffer);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set AI Range Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }
        //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "AIO", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            if (m_bInit)
            {
                //Close a device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                timer1.Enabled = false;
                m_bInit = false;
                tb_RawData.Text = "";
                tb_VoltData.Text = "";
            }
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "AIO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
    }
}