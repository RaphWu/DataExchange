﻿using Advantech.Motion;//Common Motion API
using System;
namespace DIO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnDO7 = new System.Windows.Forms.Button();
            this.BtnDO6 = new System.Windows.Forms.Button();
            this.BtnDO5 = new System.Windows.Forms.Button();
            this.BtnDO4 = new System.Windows.Forms.Button();
            this.BtnDO3 = new System.Windows.Forms.Button();
            this.BtnDO2 = new System.Windows.Forms.Button();
            this.BtnDO1 = new System.Windows.Forms.Button();
            this.BtnDO0 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox0 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBoxDI3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI0 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_SetParam = new System.Windows.Forms.Button();
            this.textBoxDec = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.textBoxAcc = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.textBoxVelH = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxVelL = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(140, 19);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(163, 20);
            this.CmbAvailableDevice.TabIndex = 18;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 17;
            this.label1.Text = "Available device:";
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(140, 47);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(163, 20);
            this.CmbAxes.TabIndex = 20;
            this.CmbAxes.SelectedIndexChanged += new System.EventHandler(this.CmbAxes_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 12);
            this.label2.TabIndex = 19;
            this.label2.Text = "Operation Axis:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnDO7);
            this.groupBox1.Controls.Add(this.BtnDO6);
            this.groupBox1.Controls.Add(this.BtnDO5);
            this.groupBox1.Controls.Add(this.BtnDO4);
            this.groupBox1.Controls.Add(this.BtnDO3);
            this.groupBox1.Controls.Add(this.BtnDO2);
            this.groupBox1.Controls.Add(this.BtnDO1);
            this.groupBox1.Controls.Add(this.BtnDO0);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.pictureBox0);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(16, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(298, 162);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DO";
            // 
            // BtnDO7
            // 
            this.BtnDO7.Location = new System.Drawing.Point(247, 129);
            this.BtnDO7.Name = "BtnDO7";
            this.BtnDO7.Size = new System.Drawing.Size(33, 23);
            this.BtnDO7.TabIndex = 29;
            this.BtnDO7.Text = "DO7";
            this.BtnDO7.UseVisualStyleBackColor = true;
            this.BtnDO7.Click += new System.EventHandler(this.BtnDO7_Click);
            // 
            // BtnDO6
            // 
            this.BtnDO6.Location = new System.Drawing.Point(171, 129);
            this.BtnDO6.Name = "BtnDO6";
            this.BtnDO6.Size = new System.Drawing.Size(33, 23);
            this.BtnDO6.TabIndex = 28;
            this.BtnDO6.Text = "DO6";
            this.BtnDO6.UseVisualStyleBackColor = true;
            this.BtnDO6.Click += new System.EventHandler(this.BtnDO6_Click);
            // 
            // BtnDO5
            // 
            this.BtnDO5.Location = new System.Drawing.Point(95, 129);
            this.BtnDO5.Name = "BtnDO5";
            this.BtnDO5.Size = new System.Drawing.Size(33, 23);
            this.BtnDO5.TabIndex = 27;
            this.BtnDO5.Text = "DO5";
            this.BtnDO5.UseVisualStyleBackColor = true;
            this.BtnDO5.Click += new System.EventHandler(this.BtnDO5_Click);
            // 
            // BtnDO4
            // 
            this.BtnDO4.Location = new System.Drawing.Point(19, 129);
            this.BtnDO4.Name = "BtnDO4";
            this.BtnDO4.Size = new System.Drawing.Size(33, 23);
            this.BtnDO4.TabIndex = 26;
            this.BtnDO4.Text = "DO4";
            this.BtnDO4.UseVisualStyleBackColor = true;
            this.BtnDO4.Click += new System.EventHandler(this.BtnDO4_Click);
            // 
            // BtnDO3
            // 
            this.BtnDO3.Location = new System.Drawing.Point(247, 64);
            this.BtnDO3.Name = "BtnDO3";
            this.BtnDO3.Size = new System.Drawing.Size(33, 23);
            this.BtnDO3.TabIndex = 25;
            this.BtnDO3.Text = "DO3";
            this.BtnDO3.UseVisualStyleBackColor = true;
            this.BtnDO3.Click += new System.EventHandler(this.BtnDO3_Click);
            // 
            // BtnDO2
            // 
            this.BtnDO2.Location = new System.Drawing.Point(171, 64);
            this.BtnDO2.Name = "BtnDO2";
            this.BtnDO2.Size = new System.Drawing.Size(33, 23);
            this.BtnDO2.TabIndex = 24;
            this.BtnDO2.Text = "DO2";
            this.BtnDO2.UseVisualStyleBackColor = true;
            this.BtnDO2.Click += new System.EventHandler(this.BtnDO2_Click);
            // 
            // BtnDO1
            // 
            this.BtnDO1.Location = new System.Drawing.Point(95, 64);
            this.BtnDO1.Name = "BtnDO1";
            this.BtnDO1.Size = new System.Drawing.Size(33, 23);
            this.BtnDO1.TabIndex = 23;
            this.BtnDO1.Text = "DO1";
            this.BtnDO1.UseVisualStyleBackColor = true;
            this.BtnDO1.Click += new System.EventHandler(this.BtnDO1_Click);
            // 
            // BtnDO0
            // 
            this.BtnDO0.Location = new System.Drawing.Point(19, 64);
            this.BtnDO0.Name = "BtnDO0";
            this.BtnDO0.Size = new System.Drawing.Size(33, 23);
            this.BtnDO0.TabIndex = 22;
            this.BtnDO0.Text = "DO0";
            this.BtnDO0.UseVisualStyleBackColor = true;
            this.BtnDO0.Click += new System.EventHandler(this.BtnDO0_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Gray;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(99, 97);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(25, 24);
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Gray;
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Location = new System.Drawing.Point(175, 97);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 24);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Gray;
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(251, 97);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 24);
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Gray;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(23, 97);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(25, 24);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Gray;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(252, 32);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(25, 24);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Gray;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(176, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(25, 24);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gray;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(100, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(25, 24);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox0
            // 
            this.pictureBox0.BackColor = System.Drawing.Color.Gray;
            this.pictureBox0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox0.Location = new System.Drawing.Point(24, 32);
            this.pictureBox0.Name = "pictureBox0";
            this.pictureBox0.Size = new System.Drawing.Size(25, 24);
            this.pictureBox0.TabIndex = 0;
            this.pictureBox0.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBoxDI3);
            this.groupBox2.Controls.Add(this.pictureBoxDI2);
            this.groupBox2.Controls.Add(this.pictureBoxDI0);
            this.groupBox2.Controls.Add(this.pictureBoxDI1);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(333, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(264, 56);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DI";
            // 
            // pictureBoxDI3
            // 
            this.pictureBoxDI3.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI3.Location = new System.Drawing.Point(215, 20);
            this.pictureBoxDI3.Name = "pictureBoxDI3";
            this.pictureBoxDI3.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI3.TabIndex = 33;
            this.pictureBoxDI3.TabStop = false;
            // 
            // pictureBoxDI2
            // 
            this.pictureBoxDI2.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI2.Location = new System.Drawing.Point(154, 20);
            this.pictureBoxDI2.Name = "pictureBoxDI2";
            this.pictureBoxDI2.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI2.TabIndex = 32;
            this.pictureBoxDI2.TabStop = false;
            // 
            // pictureBoxDI0
            // 
            this.pictureBoxDI0.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI0.Location = new System.Drawing.Point(32, 20);
            this.pictureBoxDI0.Name = "pictureBoxDI0";
            this.pictureBoxDI0.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI0.TabIndex = 30;
            this.pictureBoxDI0.TabStop = false;
            // 
            // pictureBoxDI1
            // 
            this.pictureBoxDI1.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI1.Location = new System.Drawing.Point(93, 20);
            this.pictureBoxDI1.Name = "pictureBoxDI1";
            this.pictureBoxDI1.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI1.TabIndex = 31;
            this.pictureBoxDI1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbl_Note);
            this.groupBox3.Location = new System.Drawing.Point(333, 88);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(264, 136);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Note";
            // 
            // lbl_Note
            // 
            this.lbl_Note.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_Note.Location = new System.Drawing.Point(3, 17);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(258, 116);
            this.lbl_Note.TabIndex = 0;
            this.lbl_Note.Text = "label3";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label13);
            this.groupBox13.Controls.Add(this.label11);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(334, 242);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(264, 116);
            this.groupBox13.TabIndex = 56;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Axis Signal Status";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(150, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 12);
            this.label13.TabIndex = 28;
            this.label13.Text = "-HEL:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(29, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 27;
            this.label11.Text = "+HEL:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(155, 34);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 26;
            this.label19.Text = "ORG:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(34, 34);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 25;
            this.label20.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(187, 72);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(66, 72);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(187, 30);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(66, 30);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_SetParam);
            this.groupBox4.Controls.Add(this.textBoxDec);
            this.groupBox4.Controls.Add(this.Label6);
            this.groupBox4.Controls.Add(this.textBoxAcc);
            this.groupBox4.Controls.Add(this.Label8);
            this.groupBox4.Controls.Add(this.textBoxVelH);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.textBoxVelL);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(16, 243);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(298, 116);
            this.groupBox4.TabIndex = 57;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vel Set";
            // 
            // btn_SetParam
            // 
            this.btn_SetParam.Location = new System.Drawing.Point(103, 82);
            this.btn_SetParam.Name = "btn_SetParam";
            this.btn_SetParam.Size = new System.Drawing.Size(100, 26);
            this.btn_SetParam.TabIndex = 42;
            this.btn_SetParam.Text = "Set/Get Param";
            this.btn_SetParam.UseVisualStyleBackColor = true;
            this.btn_SetParam.Click += new System.EventHandler(this.btn_SetParam_Click);
            // 
            // textBoxDec
            // 
            this.textBoxDec.Location = new System.Drawing.Point(190, 50);
            this.textBoxDec.Name = "textBoxDec";
            this.textBoxDec.Size = new System.Drawing.Size(87, 21);
            this.textBoxDec.TabIndex = 26;
            this.textBoxDec.Text = "10000";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(155, 54);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(29, 12);
            this.Label6.TabIndex = 25;
            this.Label6.Text = "DEC:";
            // 
            // textBoxAcc
            // 
            this.textBoxAcc.Location = new System.Drawing.Point(57, 50);
            this.textBoxAcc.Name = "textBoxAcc";
            this.textBoxAcc.Size = new System.Drawing.Size(86, 21);
            this.textBoxAcc.TabIndex = 24;
            this.textBoxAcc.Text = "10000";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(26, 53);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(29, 12);
            this.Label8.TabIndex = 23;
            this.Label8.Text = "ACC:";
            // 
            // textBoxVelH
            // 
            this.textBoxVelH.Location = new System.Drawing.Point(190, 22);
            this.textBoxVelH.Name = "textBoxVelH";
            this.textBoxVelH.Size = new System.Drawing.Size(87, 21);
            this.textBoxVelH.TabIndex = 22;
            this.textBoxVelH.Text = "8000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(149, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 21;
            this.label5.Text = "VelH:";
            // 
            // textBoxVelL
            // 
            this.textBoxVelL.Location = new System.Drawing.Point(57, 21);
            this.textBoxVelL.Name = "textBoxVelL";
            this.textBoxVelL.Size = new System.Drawing.Size(86, 21);
            this.textBoxVelL.TabIndex = 20;
            this.textBoxVelL.TabStop = false;
            this.textBoxVelL.Text = "2000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = "VelL:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 381);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CmbAxes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CmbAvailableDevice);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DIO";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox0;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BtnDO0;
        private System.Windows.Forms.Button BtnDO7;
        private System.Windows.Forms.Button BtnDO6;
        private System.Windows.Forms.Button BtnDO5;
        private System.Windows.Forms.Button BtnDO4;
        private System.Windows.Forms.Button BtnDO3;
        private System.Windows.Forms.Button BtnDO2;
        private System.Windows.Forms.Button BtnDO1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBoxDI3;
        private System.Windows.Forms.PictureBox pictureBoxDI2;
        private System.Windows.Forms.PictureBox pictureBoxDI0;
        private System.Windows.Forms.PictureBox pictureBoxDI1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[32];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_SetParam;
        private System.Windows.Forms.TextBox textBoxDec;
        private System.Windows.Forms.Label Label6;
        private System.Windows.Forms.TextBox textBoxAcc;
        private System.Windows.Forms.Label Label8;
        private System.Windows.Forms.TextBox textBoxVelH;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxVelL;
        private System.Windows.Forms.Label label4;
    }
}

