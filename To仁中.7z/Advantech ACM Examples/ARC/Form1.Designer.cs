﻿using Advantech.Motion;//Common Motion API
using System;
namespace ARC
{
    partial class Form1
    {         
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioButtonCCW = new System.Windows.Forms.RadioButton();
            this.radioButtonCW = new System.Windows.Forms.RadioButton();
            this.BtnStop = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButtonRel = new System.Windows.Forms.RadioButton();
            this.radioButtonAbs = new System.Windows.Forms.RadioButton();
            this.BtnMove = new System.Windows.Forms.Button();
            this.BtnAddAxes = new System.Windows.Forms.Button();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxThirdAxID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxSecAxID = new System.Windows.Forms.TextBox();
            this.textBoxFirstAxID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBoxThirdAxCmd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnResetCounter = new System.Windows.Forms.Button();
            this.textBoxSecAxCmd = new System.Windows.Forms.TextBox();
            this.textBoxFirAxCmd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBoxThirdAxState = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxGpState = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.textBoxSecAxState = new System.Windows.Forms.TextBox();
            this.textBoxFirAxState = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.group = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_SetParam = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.btn_2DARC = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn3DMove = new System.Windows.Forms.Button();
            this.btn3DARC = new System.Windows.Forms.Button();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.group.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Available device:";
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(125, 15);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(176, 20);
            this.CmbAvailableDevice.TabIndex = 2;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(37, 42);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(98, 25);
            this.BtnOpenBoard.TabIndex = 3;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(36, 73);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(99, 25);
            this.BtnLoadCfg.TabIndex = 4;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(193, 42);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(95, 25);
            this.BtnCloseBoard.TabIndex = 5;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(193, 73);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(95, 25);
            this.BtnServo.TabIndex = 6;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioButtonCCW);
            this.groupBox5.Controls.Add(this.radioButtonCW);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox5.Location = new System.Drawing.Point(20, 106);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(285, 46);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Arc Direction";
            // 
            // radioButtonCCW
            // 
            this.radioButtonCCW.AutoSize = true;
            this.radioButtonCCW.Location = new System.Drawing.Point(190, 22);
            this.radioButtonCCW.Name = "radioButtonCCW";
            this.radioButtonCCW.Size = new System.Drawing.Size(41, 16);
            this.radioButtonCCW.TabIndex = 9;
            this.radioButtonCCW.Text = "CCW";
            this.radioButtonCCW.UseVisualStyleBackColor = true;
            // 
            // radioButtonCW
            // 
            this.radioButtonCW.AutoSize = true;
            this.radioButtonCW.Checked = true;
            this.radioButtonCW.Location = new System.Drawing.Point(18, 22);
            this.radioButtonCW.Name = "radioButtonCW";
            this.radioButtonCW.Size = new System.Drawing.Size(35, 16);
            this.radioButtonCW.TabIndex = 8;
            this.radioButtonCW.TabStop = true;
            this.radioButtonCW.Text = "CW";
            this.radioButtonCW.UseVisualStyleBackColor = true;
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(227, 20);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(79, 24);
            this.BtnStop.TabIndex = 9;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButtonRel);
            this.groupBox4.Controls.Add(this.radioButtonAbs);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(20, 51);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(285, 46);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Movement Mode";
            // 
            // radioButtonRel
            // 
            this.radioButtonRel.AutoSize = true;
            this.radioButtonRel.Checked = true;
            this.radioButtonRel.Location = new System.Drawing.Point(10, 22);
            this.radioButtonRel.Name = "radioButtonRel";
            this.radioButtonRel.Size = new System.Drawing.Size(71, 16);
            this.radioButtonRel.TabIndex = 7;
            this.radioButtonRel.TabStop = true;
            this.radioButtonRel.Text = "Relative";
            this.radioButtonRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonAbs
            // 
            this.radioButtonAbs.AutoSize = true;
            this.radioButtonAbs.Location = new System.Drawing.Point(190, 22);
            this.radioButtonAbs.Name = "radioButtonAbs";
            this.radioButtonAbs.Size = new System.Drawing.Size(71, 16);
            this.radioButtonAbs.TabIndex = 6;
            this.radioButtonAbs.Text = "Absolute";
            this.radioButtonAbs.UseVisualStyleBackColor = true;
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(126, 20);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(79, 24);
            this.BtnMove.TabIndex = 8;
            this.BtnMove.Text = "2D Move";
            this.BtnMove.UseVisualStyleBackColor = true;
            this.BtnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // BtnAddAxes
            // 
            this.BtnAddAxes.Location = new System.Drawing.Point(194, 21);
            this.BtnAddAxes.Name = "BtnAddAxes";
            this.BtnAddAxes.Size = new System.Drawing.Size(95, 25);
            this.BtnAddAxes.TabIndex = 1;
            this.BtnAddAxes.Text = "Add Axis";
            this.BtnAddAxes.UseVisualStyleBackColor = true;
            this.BtnAddAxes.Click += new System.EventHandler(this.BtnAddAxes_Click);
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(37, 23);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(149, 20);
            this.CmbAxes.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBoxThirdAxID);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.textBoxSecAxID);
            this.groupBox6.Controls.Add(this.textBoxFirstAxID);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox6.Location = new System.Drawing.Point(356, 154);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(272, 101);
            this.groupBox6.TabIndex = 13;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Selected Axes";
            // 
            // textBoxThirdAxID
            // 
            this.textBoxThirdAxID.Location = new System.Drawing.Point(110, 72);
            this.textBoxThirdAxID.Name = "textBoxThirdAxID";
            this.textBoxThirdAxID.ReadOnly = true;
            this.textBoxThirdAxID.Size = new System.Drawing.Size(130, 21);
            this.textBoxThirdAxID.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "Third AxisID:";
            // 
            // textBoxSecAxID
            // 
            this.textBoxSecAxID.Location = new System.Drawing.Point(110, 45);
            this.textBoxSecAxID.Name = "textBoxSecAxID";
            this.textBoxSecAxID.ReadOnly = true;
            this.textBoxSecAxID.Size = new System.Drawing.Size(130, 21);
            this.textBoxSecAxID.TabIndex = 10;
            // 
            // textBoxFirstAxID
            // 
            this.textBoxFirstAxID.Location = new System.Drawing.Point(110, 18);
            this.textBoxFirstAxID.Name = "textBoxFirstAxID";
            this.textBoxFirstAxID.ReadOnly = true;
            this.textBoxFirstAxID.Size = new System.Drawing.Size(130, 21);
            this.textBoxFirstAxID.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "Second AxisID:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 12);
            this.label8.TabIndex = 8;
            this.label8.Text = "First AxisID:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBoxThirdAxCmd);
            this.groupBox7.Controls.Add(this.label3);
            this.groupBox7.Controls.Add(this.BtnResetCounter);
            this.groupBox7.Controls.Add(this.textBoxSecAxCmd);
            this.groupBox7.Controls.Add(this.textBoxFirAxCmd);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Controls.Add(this.label10);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox7.Location = new System.Drawing.Point(356, 10);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(272, 139);
            this.groupBox7.TabIndex = 14;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Command Counter";
            // 
            // textBoxThirdAxCmd
            // 
            this.textBoxThirdAxCmd.Location = new System.Drawing.Point(110, 77);
            this.textBoxThirdAxCmd.Name = "textBoxThirdAxCmd";
            this.textBoxThirdAxCmd.ReadOnly = true;
            this.textBoxThirdAxCmd.Size = new System.Drawing.Size(130, 21);
            this.textBoxThirdAxCmd.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 16;
            this.label3.Text = "Third Axis:";
            // 
            // BtnResetCounter
            // 
            this.BtnResetCounter.Location = new System.Drawing.Point(104, 105);
            this.BtnResetCounter.Name = "BtnResetCounter";
            this.BtnResetCounter.Size = new System.Drawing.Size(93, 26);
            this.BtnResetCounter.TabIndex = 15;
            this.BtnResetCounter.Text = "Reset Counter";
            this.BtnResetCounter.UseVisualStyleBackColor = true;
            this.BtnResetCounter.Click += new System.EventHandler(this.BtnResetCounter_Click);
            // 
            // textBoxSecAxCmd
            // 
            this.textBoxSecAxCmd.Location = new System.Drawing.Point(110, 49);
            this.textBoxSecAxCmd.Name = "textBoxSecAxCmd";
            this.textBoxSecAxCmd.ReadOnly = true;
            this.textBoxSecAxCmd.Size = new System.Drawing.Size(130, 21);
            this.textBoxSecAxCmd.TabIndex = 10;
            // 
            // textBoxFirAxCmd
            // 
            this.textBoxFirAxCmd.Location = new System.Drawing.Point(110, 21);
            this.textBoxFirAxCmd.Name = "textBoxFirAxCmd";
            this.textBoxFirAxCmd.ReadOnly = true;
            this.textBoxFirAxCmd.Size = new System.Drawing.Size(130, 21);
            this.textBoxFirAxCmd.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 52);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "Second Axis:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(35, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 12);
            this.label10.TabIndex = 8;
            this.label10.Text = "First Axis:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBoxThirdAxState);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.textBoxGpState);
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.BtnResetErr);
            this.groupBox8.Controls.Add(this.textBoxSecAxState);
            this.groupBox8.Controls.Add(this.textBoxFirAxState);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox8.Location = new System.Drawing.Point(356, 325);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(272, 162);
            this.groupBox8.TabIndex = 16;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Current State";
            // 
            // textBoxThirdAxState
            // 
            this.textBoxThirdAxState.Location = new System.Drawing.Point(125, 74);
            this.textBoxThirdAxState.Name = "textBoxThirdAxState";
            this.textBoxThirdAxState.ReadOnly = true;
            this.textBoxThirdAxState.Size = new System.Drawing.Size(114, 21);
            this.textBoxThirdAxState.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 12);
            this.label5.TabIndex = 18;
            this.label5.Text = "Third AxisID:";
            // 
            // textBoxGpState
            // 
            this.textBoxGpState.Location = new System.Drawing.Point(124, 101);
            this.textBoxGpState.Name = "textBoxGpState";
            this.textBoxGpState.ReadOnly = true;
            this.textBoxGpState.Size = new System.Drawing.Size(115, 21);
            this.textBoxGpState.TabIndex = 17;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(77, 105);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 16;
            this.label13.Text = "Group:";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(104, 129);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(93, 26);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // textBoxSecAxState
            // 
            this.textBoxSecAxState.Location = new System.Drawing.Point(125, 47);
            this.textBoxSecAxState.Name = "textBoxSecAxState";
            this.textBoxSecAxState.ReadOnly = true;
            this.textBoxSecAxState.Size = new System.Drawing.Size(114, 21);
            this.textBoxSecAxState.TabIndex = 10;
            // 
            // textBoxFirAxState
            // 
            this.textBoxFirAxState.Location = new System.Drawing.Point(125, 19);
            this.textBoxFirAxState.Name = "textBoxFirAxState";
            this.textBoxFirAxState.ReadOnly = true;
            this.textBoxFirAxState.Size = new System.Drawing.Size(114, 21);
            this.textBoxFirAxState.TabIndex = 6;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(31, 54);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 12);
            this.label11.TabIndex = 9;
            this.label11.Text = "Second AxisID:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(38, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 12);
            this.label12.TabIndex = 8;
            this.label12.Text = "First AxisID:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // group
            // 
            this.group.Controls.Add(this.label1);
            this.group.Controls.Add(this.CmbAvailableDevice);
            this.group.Controls.Add(this.BtnOpenBoard);
            this.group.Controls.Add(this.BtnCloseBoard);
            this.group.Controls.Add(this.BtnLoadCfg);
            this.group.Controls.Add(this.BtnServo);
            this.group.Location = new System.Drawing.Point(16, 10);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(323, 104);
            this.group.TabIndex = 17;
            this.group.TabStop = false;
            this.group.Text = "Device Operate";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.CmbAxes);
            this.groupBox11.Controls.Add(this.BtnAddAxes);
            this.groupBox11.Location = new System.Drawing.Point(16, 122);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(323, 58);
            this.groupBox11.TabIndex = 18;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Add Axis Operate";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_SetParam);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Location = new System.Drawing.Point(16, 188);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(323, 168);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Group Param Set";
            // 
            // btn_SetParam
            // 
            this.btn_SetParam.Location = new System.Drawing.Point(168, 19);
            this.btn_SetParam.Name = "btn_SetParam";
            this.btn_SetParam.Size = new System.Drawing.Size(118, 23);
            this.btn_SetParam.TabIndex = 1;
            this.btn_SetParam.Text = "Set/Get Param";
            this.btn_SetParam.UseVisualStyleBackColor = true;
            this.btn_SetParam.Click += new System.EventHandler(this.btn_SetParam_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(28, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 12);
            this.label14.TabIndex = 0;
            this.label14.Text = "Group Velocity Param:";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.btn_2DARC);
            this.groupBox12.Controls.Add(this.BtnMove);
            this.groupBox12.Controls.Add(this.BtnStop);
            this.groupBox12.Location = new System.Drawing.Point(16, 364);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(323, 53);
            this.groupBox12.TabIndex = 20;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "ARC 2D Mode:";
            // 
            // btn_2DARC
            // 
            this.btn_2DARC.Location = new System.Drawing.Point(21, 20);
            this.btn_2DARC.Name = "btn_2DARC";
            this.btn_2DARC.Size = new System.Drawing.Size(79, 24);
            this.btn_2DARC.TabIndex = 41;
            this.btn_2DARC.Text = "2D Param";
            this.btn_2DARC.UseVisualStyleBackColor = true;
            this.btn_2DARC.Click += new System.EventHandler(this.btn_2DARC_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label16);
            this.groupBox13.Controls.Add(this.label17);
            this.groupBox13.Controls.Add(this.label18);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(356, 260);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(272, 60);
            this.groupBox13.TabIndex = 40;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Selected Axis Signal Status";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(203, 33);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 12);
            this.label16.TabIndex = 28;
            this.label16.Text = "-HEL:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(137, 34);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 27;
            this.label17.Text = "+HEL:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(72, 34);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 26;
            this.label18.Text = "ORG:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(7, 34);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(239, 29);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(173, 28);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(104, 29);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(38, 30);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.btn3DMove);
            this.groupBox2.Controls.Add(this.btn3DARC);
            this.groupBox2.Location = new System.Drawing.Point(16, 425);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(323, 61);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ARC 3D Mode:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(227, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 24);
            this.button1.TabIndex = 10;
            this.button1.Text = "Stop";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn3DMove
            // 
            this.btn3DMove.Location = new System.Drawing.Point(126, 29);
            this.btn3DMove.Name = "btn3DMove";
            this.btn3DMove.Size = new System.Drawing.Size(79, 24);
            this.btn3DMove.TabIndex = 1;
            this.btn3DMove.Text = "3D Move";
            this.btn3DMove.UseVisualStyleBackColor = true;
            this.btn3DMove.Click += new System.EventHandler(this.btn3DMove_Click);
            // 
            // btn3DARC
            // 
            this.btn3DARC.Location = new System.Drawing.Point(22, 29);
            this.btn3DARC.Name = "btn3DARC";
            this.btn3DARC.Size = new System.Drawing.Size(79, 24);
            this.btn3DARC.TabIndex = 0;
            this.btn3DARC.Text = "3D Param";
            this.btn3DARC.UseVisualStyleBackColor = true;
            this.btn3DARC.Click += new System.EventHandler(this.btn3DARC_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 507);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.group);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ARC";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnAddAxes;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButtonRel;
        private System.Windows.Forms.RadioButton radioButtonAbs;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton radioButtonCCW;
        private System.Windows.Forms.RadioButton radioButtonCW;
        private System.Windows.Forms.Button BtnMove;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBoxSecAxID;
        private System.Windows.Forms.TextBox textBoxFirstAxID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBoxSecAxCmd;
        private System.Windows.Forms.TextBox textBoxFirAxCmd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button BtnResetCounter;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBoxGpState;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.TextBox textBoxSecAxState;
        private System.Windows.Forms.TextBox textBoxFirAxState;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;

        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum=0;
        IntPtr m_DeviceHandle;
        IntPtr[] m_Axishand = new IntPtr[32];
        IntPtr m_GpHand = IntPtr.Zero;
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        uint AxCountInGp = 0;
        ushort[] AxisArray = new ushort[32];
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.GroupBox group;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_SetParam;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.Button btn_2DARC;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn3DMove;
        private System.Windows.Forms.Button btn3DARC;
        private System.Windows.Forms.TextBox textBoxThirdAxCmd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxThirdAxID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxThirdAxState;
        private System.Windows.Forms.Label label5;
    }
}

