using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ARC
{
    public partial class Form2DARC : Form
    {
        public Form2DARC()
        {
            InitializeComponent();
        }

        private void Form2DARC_Load(object sender, EventArgs e)
        {

        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox19_Enter(object sender, EventArgs e)
        {

        }
    }
}