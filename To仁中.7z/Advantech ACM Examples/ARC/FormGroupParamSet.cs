using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ARC
{
    public partial class FormGroupParamSet : Form
    {
        public FormGroupParamSet()
        {
            InitializeComponent();
        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormGroupParamSet_Load(object sender, EventArgs e)
        {

        }
    }
}