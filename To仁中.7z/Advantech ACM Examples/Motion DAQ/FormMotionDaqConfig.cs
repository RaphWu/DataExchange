﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Motion_DAQ
{
    public partial class FormMotionDaqConfig : Form
    {
        public uint m_Period = 10;
        public uint m_AxisNo = 0;
        public uint m_Method = 0;
        public uint m_ChanType = 0;
        public uint m_Count = 2000;

        public FormMotionDaqConfig()
        {
            InitializeComponent();
        }

        public FormMotionDaqConfig(DAQConfig DaqConfig,uint AxesNum)
        {
            InitializeComponent();
            cmb_Method.Items.Add("MQ_TRIG_DISABLE");
            cmb_Method.Items.Add("MQ_TRIG_SW");
            for (int i = 0; i < AxesNum; i++)
            {
                cmb_AxisNo.Items.Add("AXIS_" + Convert.ToString(i, 10));
                cmb_Method.Items.Add("MQ_TRIG_AX" +Convert.ToString(i,10) +"_START");
            }
            txb_Period.Text = DaqConfig.Period.ToString();
            m_Period = DaqConfig.Period;
            cmb_AxisNo.SelectedIndex = (int)DaqConfig.AxisNo;
            if (DaqConfig.Method <= 1) //For MQ_TRIG_DI
                cmb_Method.SelectedIndex = (int)DaqConfig.Method;
            else
                cmb_Method.SelectedIndex = 0;
            cmb_ChanType.SelectedIndex = (int)DaqConfig.ChanType;
            txb_Count.Text = DaqConfig.Count.ToString();
            m_Count = DaqConfig.Count;
        }

        private void FormMotionDaqConfig_Load(object sender, EventArgs e)
        {
            this.AcceptButton = this.btnOK;
            this.CancelButton = this.btnCancel;
            this.btnOK.DialogResult = DialogResult.OK;
            this.btnCancel.DialogResult = DialogResult.Cancel;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.ShowInTaskbar = false; 
        }

        private void btnOK_Click(object sender, EventArgs e)
        {

             m_Period = Convert.ToUInt32(txb_Period.Text);
             m_AxisNo = (uint)cmb_AxisNo.SelectedIndex;
             m_Method = (uint)cmb_Method.SelectedIndex;
             if (m_Method > 1)    //For MQ_TRIG_DI
                 m_Method = m_Method + 1;
             m_ChanType = (uint)cmb_ChanType.SelectedIndex;
             m_Count = Convert.ToUInt32(txb_Count.Text);
          
        }

        private void txb_Period_Leave(object sender, EventArgs e)
        {
            uint Period = 10;
            try
            {
                Period = Convert.ToUInt32(txb_Period.Text);
            }
            catch (System.Exception)
            {
                MessageBox.Show("Invalid Parameters,Period must be 1-255 integer.", "Motion DAQ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txb_Period.Text = m_Period.ToString();
                return;
            }
            if ((Period > 255) || (Period == 0))//Period Range:1-255ms
            {
                MessageBox.Show("Invalid Parameters,the range of Period:1-255ms.", "Motion DAQ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txb_Period.Text = m_Period.ToString();
                return;
            }
        }

        private void txb_Count_Leave(object sender, EventArgs e)
        {
            uint Count= 10;
            try
            {
                Count = Convert.ToUInt32(txb_Count.Text);
            }
            catch (System.Exception)
            {
                MessageBox.Show("Invalid Parameters,Count must be 0-2000 integer.", "Motion DAQ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txb_Count.Text = m_Count.ToString();
                return;
            }
            if (Count > 2000)//Count Range:0-2000
            {
                MessageBox.Show("Invalid Parameters,the range of Count:0-2000.", "Motion DAQ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txb_Count.Text = m_Count.ToString();
                return;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }
    }
}