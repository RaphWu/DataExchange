﻿using Advantech.Motion;
using System;
namespace Motion_DAQ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.BtnServo = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnChan3Config = new System.Windows.Forms.Button();
            this.btnChan1Config = new System.Windows.Forms.Button();
            this.btnChan2Config = new System.Windows.Forms.Button();
            this.btnChan0Config = new System.Windows.Forms.Button();
            this.dgv_MotionDAQConfig = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AxisNo = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Method = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ChanType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_GetDAQData = new System.Windows.Forms.Button();
            this.txb_StartIndex = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.buttonStop = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.lv_MDAQData = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.buttonReset = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lbl_Status3 = new System.Windows.Forms.Label();
            this.txb_CurrentCnt3 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbl_Status2 = new System.Windows.Forms.Label();
            this.txb_CurrentCnt2 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_Status1 = new System.Windows.Forms.Label();
            this.txb_CurrentCnt1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_Status0 = new System.Windows.Forms.Label();
            this.txb_CurrentCnt0 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnRightMove = new System.Windows.Forms.Button();
            this.BtnLeftMove = new System.Windows.Forms.Button();
            this.BtnStop = new System.Windows.Forms.Button();
            this.btn_ResetCounter = new System.Windows.Forms.Button();
            this.cmb_ChannelNo = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txb_Cmd = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txb_Act = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.buttonLoadCfg = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_MotionDAQConfig)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(167, 76);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(90, 26);
            this.BtnServo.TabIndex = 32;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(167, 44);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(90, 26);
            this.BtnCloseBoard.TabIndex = 31;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(46, 43);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(90, 26);
            this.BtnOpenBoard.TabIndex = 30;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(131, 17);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(136, 20);
            this.CmbAvailableDevice.TabIndex = 29;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 28;
            this.label1.Text = "Available device:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnChan3Config);
            this.groupBox3.Controls.Add(this.btnChan1Config);
            this.groupBox3.Controls.Add(this.btnChan2Config);
            this.groupBox3.Controls.Add(this.btnChan0Config);
            this.groupBox3.Location = new System.Drawing.Point(10, 115);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(303, 79);
            this.groupBox3.TabIndex = 43;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "MDAQ Config";
            // 
            // btnChan3Config
            // 
            this.btnChan3Config.Location = new System.Drawing.Point(182, 49);
            this.btnChan3Config.Name = "btnChan3Config";
            this.btnChan3Config.Size = new System.Drawing.Size(75, 23);
            this.btnChan3Config.TabIndex = 55;
            this.btnChan3Config.Text = "Channel 3";
            this.btnChan3Config.UseVisualStyleBackColor = true;
            this.btnChan3Config.Click += new System.EventHandler(this.btnChan3Config_Click);
            // 
            // btnChan1Config
            // 
            this.btnChan1Config.Location = new System.Drawing.Point(182, 20);
            this.btnChan1Config.Name = "btnChan1Config";
            this.btnChan1Config.Size = new System.Drawing.Size(75, 23);
            this.btnChan1Config.TabIndex = 53;
            this.btnChan1Config.Text = "Channel 1";
            this.btnChan1Config.UseVisualStyleBackColor = true;
            this.btnChan1Config.Click += new System.EventHandler(this.btnChan1Config_Click);
            // 
            // btnChan2Config
            // 
            this.btnChan2Config.Location = new System.Drawing.Point(56, 49);
            this.btnChan2Config.Name = "btnChan2Config";
            this.btnChan2Config.Size = new System.Drawing.Size(75, 23);
            this.btnChan2Config.TabIndex = 54;
            this.btnChan2Config.Text = "Channel 2";
            this.btnChan2Config.UseVisualStyleBackColor = true;
            this.btnChan2Config.Click += new System.EventHandler(this.btnChan2Config_Click);
            // 
            // btnChan0Config
            // 
            this.btnChan0Config.Location = new System.Drawing.Point(56, 20);
            this.btnChan0Config.Name = "btnChan0Config";
            this.btnChan0Config.Size = new System.Drawing.Size(75, 23);
            this.btnChan0Config.TabIndex = 52;
            this.btnChan0Config.Text = "Channel 0";
            this.btnChan0Config.UseVisualStyleBackColor = true;
            this.btnChan0Config.Click += new System.EventHandler(this.btnChan0Config_Click);
            // 
            // dgv_MotionDAQConfig
            // 
            this.dgv_MotionDAQConfig.AllowUserToAddRows = false;
            this.dgv_MotionDAQConfig.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_MotionDAQConfig.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_MotionDAQConfig.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_MotionDAQConfig.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.AxisNo,
            this.Method,
            this.ChanType,
            this.Count});
            this.dgv_MotionDAQConfig.Location = new System.Drawing.Point(334, 23);
            this.dgv_MotionDAQConfig.Name = "dgv_MotionDAQConfig";
            this.dgv_MotionDAQConfig.RowHeadersWidth = 5;
            this.dgv_MotionDAQConfig.RowTemplate.Height = 23;
            this.dgv_MotionDAQConfig.Size = new System.Drawing.Size(501, 114);
            this.dgv_MotionDAQConfig.TabIndex = 60;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ChannelID";
            this.Column1.Name = "Column1";
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column1.Width = 80;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Period";
            this.Column2.Name = "Column2";
            this.Column2.Width = 45;
            // 
            // AxisNo
            // 
            this.AxisNo.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.AxisNo.HeaderText = "AxisNo";
            this.AxisNo.Name = "AxisNo";
            this.AxisNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.AxisNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.AxisNo.Width = 75;
            // 
            // Method
            // 
            this.Method.HeaderText = "Method";
            this.Method.Name = "Method";
            this.Method.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Method.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Method.Width = 135;
            // 
            // ChanType
            // 
            this.ChanType.HeaderText = "ChanType";
            this.ChanType.Name = "ChanType";
            this.ChanType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ChanType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ChanType.Width = 106;
            // 
            // Count
            // 
            this.Count.HeaderText = "Count";
            this.Count.Name = "Count";
            this.Count.Width = 50;
            // 
            // btn_GetDAQData
            // 
            this.btn_GetDAQData.Location = new System.Drawing.Point(202, 146);
            this.btn_GetDAQData.Name = "btn_GetDAQData";
            this.btn_GetDAQData.Size = new System.Drawing.Size(93, 23);
            this.btn_GetDAQData.TabIndex = 65;
            this.btn_GetDAQData.Text = "Get DAQ Data";
            this.btn_GetDAQData.UseVisualStyleBackColor = true;
            this.btn_GetDAQData.Click += new System.EventHandler(this.btn_GetDAQData_Click);
            // 
            // txb_StartIndex
            // 
            this.txb_StartIndex.Location = new System.Drawing.Point(119, 48);
            this.txb_StartIndex.Name = "txb_StartIndex";
            this.txb_StartIndex.Size = new System.Drawing.Size(104, 21);
            this.txb_StartIndex.TabIndex = 64;
            this.txb_StartIndex.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(35, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 63;
            this.label10.Text = "Start Index:";
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(160, 20);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(81, 23);
            this.buttonStop.TabIndex = 62;
            this.buttonStop.Text = "MDAQ Stop ";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(57, 20);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(81, 23);
            this.buttonStart.TabIndex = 61;
            this.buttonStart.Text = "MDAQ Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // lv_MDAQData
            // 
            this.lv_MDAQData.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lv_MDAQData.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lv_MDAQData.Location = new System.Drawing.Point(8, 119);
            this.lv_MDAQData.Name = "lv_MDAQData";
            this.lv_MDAQData.Size = new System.Drawing.Size(189, 109);
            this.lv_MDAQData.TabIndex = 66;
            this.lv_MDAQData.UseCompatibleStateImageBehavior = false;
            this.lv_MDAQData.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "DataIndex";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "DataValue";
            this.columnHeader2.Width = 100;
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(202, 189);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(93, 23);
            this.buttonReset.TabIndex = 67;
            this.buttonReset.Text = "Reset DAQ";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.lbl_Status3);
            this.groupBox1.Controls.Add(this.txb_CurrentCnt3);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.lbl_Status2);
            this.groupBox1.Controls.Add(this.txb_CurrentCnt2);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.lbl_Status1);
            this.groupBox1.Controls.Add(this.txb_CurrentCnt1);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.lbl_Status0);
            this.groupBox1.Controls.Add(this.txb_CurrentCnt0);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(334, 245);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(365, 156);
            this.groupBox1.TabIndex = 68;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Motion DAQ Status";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label24.Location = new System.Drawing.Point(3, 119);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 15;
            this.label24.Text = "Channel 3:";
            // 
            // lbl_Status3
            // 
            this.lbl_Status3.AutoSize = true;
            this.lbl_Status3.Location = new System.Drawing.Point(224, 119);
            this.lbl_Status3.Name = "lbl_Status3";
            this.lbl_Status3.Size = new System.Drawing.Size(47, 12);
            this.lbl_Status3.TabIndex = 14;
            this.lbl_Status3.Text = "Status:";
            // 
            // txb_CurrentCnt3
            // 
            this.txb_CurrentCnt3.Location = new System.Drawing.Point(143, 115);
            this.txb_CurrentCnt3.Name = "txb_CurrentCnt3";
            this.txb_CurrentCnt3.ReadOnly = true;
            this.txb_CurrentCnt3.Size = new System.Drawing.Size(64, 21);
            this.txb_CurrentCnt3.TabIndex = 13;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(74, 119);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 12);
            this.label26.TabIndex = 12;
            this.label26.Text = "CurCount:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label21.Location = new System.Drawing.Point(3, 88);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 12);
            this.label21.TabIndex = 11;
            this.label21.Text = "Channel 2:";
            // 
            // lbl_Status2
            // 
            this.lbl_Status2.AutoSize = true;
            this.lbl_Status2.Location = new System.Drawing.Point(222, 88);
            this.lbl_Status2.Name = "lbl_Status2";
            this.lbl_Status2.Size = new System.Drawing.Size(47, 12);
            this.lbl_Status2.TabIndex = 10;
            this.lbl_Status2.Text = "Status:";
            // 
            // txb_CurrentCnt2
            // 
            this.txb_CurrentCnt2.Location = new System.Drawing.Point(143, 84);
            this.txb_CurrentCnt2.Name = "txb_CurrentCnt2";
            this.txb_CurrentCnt2.ReadOnly = true;
            this.txb_CurrentCnt2.Size = new System.Drawing.Size(64, 21);
            this.txb_CurrentCnt2.TabIndex = 9;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(74, 88);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 12);
            this.label23.TabIndex = 8;
            this.label23.Text = "CurCount:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label18.Location = new System.Drawing.Point(4, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 12);
            this.label18.TabIndex = 7;
            this.label18.Text = "Channel 1:";
            // 
            // lbl_Status1
            // 
            this.lbl_Status1.AutoSize = true;
            this.lbl_Status1.Location = new System.Drawing.Point(223, 57);
            this.lbl_Status1.Name = "lbl_Status1";
            this.lbl_Status1.Size = new System.Drawing.Size(47, 12);
            this.lbl_Status1.TabIndex = 6;
            this.lbl_Status1.Text = "Status:";
            // 
            // txb_CurrentCnt1
            // 
            this.txb_CurrentCnt1.Location = new System.Drawing.Point(144, 53);
            this.txb_CurrentCnt1.Name = "txb_CurrentCnt1";
            this.txb_CurrentCnt1.ReadOnly = true;
            this.txb_CurrentCnt1.Size = new System.Drawing.Size(64, 21);
            this.txb_CurrentCnt1.TabIndex = 5;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(75, 57);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 12);
            this.label20.TabIndex = 4;
            this.label20.Text = "CurCount:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label16.Location = new System.Drawing.Point(4, 26);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 12);
            this.label16.TabIndex = 3;
            this.label16.Text = "Channel 0:";
            // 
            // lbl_Status0
            // 
            this.lbl_Status0.AutoSize = true;
            this.lbl_Status0.Location = new System.Drawing.Point(225, 26);
            this.lbl_Status0.Name = "lbl_Status0";
            this.lbl_Status0.Size = new System.Drawing.Size(47, 12);
            this.lbl_Status0.TabIndex = 2;
            this.lbl_Status0.Text = "Status:";
            // 
            // txb_CurrentCnt0
            // 
            this.txb_CurrentCnt0.Location = new System.Drawing.Point(144, 22);
            this.txb_CurrentCnt0.Name = "txb_CurrentCnt0";
            this.txb_CurrentCnt0.ReadOnly = true;
            this.txb_CurrentCnt0.Size = new System.Drawing.Size(64, 21);
            this.txb_CurrentCnt0.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "CurCount:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(336, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 12);
            this.label3.TabIndex = 69;
            this.label3.Text = "Motion DAQ Configuration";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 12);
            this.label4.TabIndex = 70;
            this.label4.Text = "Motion DAQ Data";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(95, 18);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(137, 20);
            this.CmbAxes.TabIndex = 72;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 71;
            this.label5.Text = "Axis:";
            // 
            // BtnRightMove
            // 
            this.BtnRightMove.Location = new System.Drawing.Point(118, 45);
            this.BtnRightMove.Name = "BtnRightMove";
            this.BtnRightMove.Size = new System.Drawing.Size(71, 23);
            this.BtnRightMove.TabIndex = 75;
            this.BtnRightMove.Text = "-->";
            this.BtnRightMove.UseVisualStyleBackColor = true;
            this.BtnRightMove.Click += new System.EventHandler(this.BtnRightMove_Click);
            // 
            // BtnLeftMove
            // 
            this.BtnLeftMove.Location = new System.Drawing.Point(24, 45);
            this.BtnLeftMove.Name = "BtnLeftMove";
            this.BtnLeftMove.Size = new System.Drawing.Size(71, 23);
            this.BtnLeftMove.TabIndex = 74;
            this.BtnLeftMove.Text = "<--";
            this.BtnLeftMove.UseVisualStyleBackColor = true;
            this.BtnLeftMove.Click += new System.EventHandler(this.BtnLeftMove_Click);
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(212, 46);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(71, 23);
            this.BtnStop.TabIndex = 73;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // btn_ResetCounter
            // 
            this.btn_ResetCounter.Location = new System.Drawing.Point(189, 50);
            this.btn_ResetCounter.Name = "btn_ResetCounter";
            this.btn_ResetCounter.Size = new System.Drawing.Size(94, 23);
            this.btn_ResetCounter.TabIndex = 76;
            this.btn_ResetCounter.Text = "Reset Counter";
            this.btn_ResetCounter.UseVisualStyleBackColor = true;
            this.btn_ResetCounter.Click += new System.EventHandler(this.btn_ResetCounter_Click);
            // 
            // cmb_ChannelNo
            // 
            this.cmb_ChannelNo.FormattingEnabled = true;
            this.cmb_ChannelNo.Items.AddRange(new object[] {
            "Channel_0",
            "Channel_1",
            "Channel_2",
            "Channel_3"});
            this.cmb_ChannelNo.Location = new System.Drawing.Point(119, 76);
            this.cmb_ChannelNo.Name = "cmb_ChannelNo";
            this.cmb_ChannelNo.Size = new System.Drawing.Size(143, 20);
            this.cmb_ChannelNo.TabIndex = 78;
            this.cmb_ChannelNo.SelectedIndexChanged += new System.EventHandler(this.cmb_ChannelNo_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(41, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 12);
            this.label6.TabIndex = 77;
            this.label6.Text = "Channel No:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 21);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 12);
            this.label14.TabIndex = 31;
            this.label14.Text = "Cmd Position:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(187, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 12);
            this.label13.TabIndex = 29;
            this.label13.Text = "PPU";
            // 
            // txb_Cmd
            // 
            this.txb_Cmd.Location = new System.Drawing.Point(95, 20);
            this.txb_Cmd.Name = "txb_Cmd";
            this.txb_Cmd.ReadOnly = true;
            this.txb_Cmd.Size = new System.Drawing.Size(87, 21);
            this.txb_Cmd.TabIndex = 30;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(220, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 12);
            this.label7.TabIndex = 81;
            this.label7.Text = "Act Position:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(402, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 12);
            this.label8.TabIndex = 79;
            this.label8.Text = "PPU";
            // 
            // txb_Act
            // 
            this.txb_Act.Location = new System.Drawing.Point(309, 20);
            this.txb_Act.Name = "txb_Act";
            this.txb_Act.ReadOnly = true;
            this.txb_Act.Size = new System.Drawing.Size(87, 21);
            this.txb_Act.TabIndex = 80;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txb_Cmd);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.btn_ResetCounter);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txb_Act);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Location = new System.Drawing.Point(334, 149);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(453, 79);
            this.groupBox2.TabIndex = 82;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Position";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.buttonLoadCfg);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.CmbAvailableDevice);
            this.groupBox4.Controls.Add(this.BtnOpenBoard);
            this.groupBox4.Controls.Add(this.BtnCloseBoard);
            this.groupBox4.Controls.Add(this.BtnServo);
            this.groupBox4.Location = new System.Drawing.Point(11, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(303, 107);
            this.groupBox4.TabIndex = 83;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Operate Device:";
            // 
            // buttonLoadCfg
            // 
            this.buttonLoadCfg.Location = new System.Drawing.Point(46, 74);
            this.buttonLoadCfg.Name = "buttonLoadCfg";
            this.buttonLoadCfg.Size = new System.Drawing.Size(90, 26);
            this.buttonLoadCfg.TabIndex = 33;
            this.buttonLoadCfg.Text = "Load Config";
            this.buttonLoadCfg.UseVisualStyleBackColor = true;
            this.buttonLoadCfg.Click += new System.EventHandler(this.buttonLoadCfg_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.CmbAxes);
            this.groupBox5.Controls.Add(this.BtnLeftMove);
            this.groupBox5.Controls.Add(this.BtnRightMove);
            this.groupBox5.Controls.Add(this.BtnStop);
            this.groupBox5.Location = new System.Drawing.Point(11, 197);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(303, 79);
            this.groupBox5.TabIndex = 84;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "CMove";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.txb_StartIndex);
            this.groupBox6.Controls.Add(this.buttonStart);
            this.groupBox6.Controls.Add(this.buttonStop);
            this.groupBox6.Controls.Add(this.label4);
            this.groupBox6.Controls.Add(this.cmb_ChannelNo);
            this.groupBox6.Controls.Add(this.buttonReset);
            this.groupBox6.Controls.Add(this.label6);
            this.groupBox6.Controls.Add(this.btn_GetDAQData);
            this.groupBox6.Controls.Add(this.lv_MDAQData);
            this.groupBox6.Location = new System.Drawing.Point(10, 279);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(303, 235);
            this.groupBox6.TabIndex = 85;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Motion DAQ";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label9);
            this.groupBox13.Controls.Add(this.label17);
            this.groupBox13.Controls.Add(this.label11);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(335, 421);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(364, 89);
            this.groupBox13.TabIndex = 86;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Selected Axis Signal Status";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(158, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 12);
            this.label9.TabIndex = 28;
            this.label9.Text = "-HEL:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(30, 59);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 27;
            this.label17.Text = "+HEL:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(164, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "ORG:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(37, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(195, 56);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(66, 56);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(195, 25);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(66, 25);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 522);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.dgv_MotionDAQConfig);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Motion DAQ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_MotionDAQConfig)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgv_MotionDAQConfig;
        private System.Windows.Forms.Button btnChan3Config;
        private System.Windows.Forms.Button btnChan1Config;
        private System.Windows.Forms.Button btnChan2Config;
        private System.Windows.Forms.Button btnChan0Config;
        private System.Windows.Forms.Button btn_GetDAQData;
        private System.Windows.Forms.TextBox txb_StartIndex;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.ListView lv_MDAQData;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button buttonReset;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lbl_Status3;
        private System.Windows.Forms.TextBox txb_CurrentCnt3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbl_Status2;
        private System.Windows.Forms.TextBox txb_CurrentCnt2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbl_Status1;
        private System.Windows.Forms.TextBox txb_CurrentCnt1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_Status0;
        private System.Windows.Forms.TextBox txb_CurrentCnt0;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;

        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[32];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BtnRightMove;
        private System.Windows.Forms.Button BtnLeftMove;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button btn_ResetCounter;
        private System.Windows.Forms.ComboBox cmb_ChannelNo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txb_Cmd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txb_Act;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewComboBoxColumn AxisNo;
        private System.Windows.Forms.DataGridViewComboBoxColumn Method;
        private System.Windows.Forms.DataGridViewComboBoxColumn ChanType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Count;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button buttonLoadCfg;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
    }
}

