﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Diagnostics;
namespace Motion_DAQ
{
    public struct DAQConfig
    {
        public uint Period;
        public uint AxisNo;
        public uint Method;
        public uint ChanType;
        public uint Count;
    }

    public struct DAQChannelInfo
    {
        public DAQConfig Config;
        public ushort CurrentCnt;
        public Byte Status;
        public int[] DataBuffer;
    };

    public enum ChannelID
    {
        Channel_0 = 0,
        Channel_1 = 1,
        Channel_2 = 2,
        Channel_3 = 3
    }

    public enum AxisNo
    {
        Axis_0 = 0,
        Axis_1 = 1,
        Axis_2 = 2,
        Axis_3 = 3,
        Axis_4 = 4,
        Axis_5 = 5,
        Axis_6 = 6,
        Axis_7 = 7
    }

    public enum MDAQTrigMethod
    {
        MQ_TRIG_DISABLE = 0,
        MQ_TRIG_SW = 1,
        MQ_TRIG_DI = 2,
        MQ_TRIG_AX0_START = 3,
        MQ_TRIG_AX1_START = 4,
        MQ_TRIG_AX2_START = 5,
        MQ_TRIG_AX3_START = 6,
        MQ_TRIG_AX4_START = 7,
        MQ_TRIG_AX5_START = 8,
        MQ_TRIG_AX6_START = 9,
        MQ_TRIG_AX7_START = 10,
        MQ_TRIG_AX8_START = 11,
        MQ_TRIG_AX9_START = 12,
        MQ_TRIG_AX10_START = 13,
        MQ_TRIG_AX11_START = 14
    }

    public enum ChanType
    {
        Cmd_Position = 0,
        Act_Position = 1,
        Lag_Position = 2,
        Cmd_Velocity = 3
    }

    public enum MDAQStatus
    {
        MDAQST_Ready = 0,
        MDAQST_WaitTrig = 1,
        MDAQST_Started = 2
    }

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            VersionIsOk = GetDevCfgDllDrvVer(); //Get Driver Version Number, this step is not necessary
        }
        ushort StartIndex = 0;
        uint ChanPeriod = 10;
        DAQChannelInfo[] DaqChannelInfo = new DAQChannelInfo[4];
        private void InitDAQConfig()
        {
            uint Period = 0;
            uint AxisNo = 0;
            uint Method = 0;
            uint ChanType = 0;
            uint Count = 0;
            String strTemp;
            for (int i = 0; i < 4; i++)
            {
                //Get MotionDAQ related values of a specified ChannelID
                uint Result = Motion.mAcm_DevMDaqGetConfig(m_DeviceHandle,(ushort)i, ref Period, ref AxisNo, ref Method, ref ChanType, ref Count);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Get Motion DAQ Config Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                DaqChannelInfo[i].Config.Period = Period;
                DaqChannelInfo[i].Config.AxisNo = AxisNo;
                DaqChannelInfo[i].Config.Method = Method;
                DaqChannelInfo[i].Config.ChanType = ChanType;
                DaqChannelInfo[i].Config.Count = Count;
                DaqChannelInfo[i].CurrentCnt = 0;
                DaqChannelInfo[i].Status = 0;
                dgv_MotionDAQConfig.Rows.Add();
                dgv_MotionDAQConfig.Rows[i].Cells[0].Value = (ChannelID)(uint)i;
                dgv_MotionDAQConfig.Rows[i].Cells[1].Value = DaqChannelInfo[i].Config.Period;
                dgv_MotionDAQConfig.Rows[i].Cells[2].Value = ((AxisNo)(DaqChannelInfo[i].Config.AxisNo)).ToString();
                dgv_MotionDAQConfig.Rows[i].Cells[3].Value = ((MDAQTrigMethod)(DaqChannelInfo[i].Config.Method)).ToString();
                dgv_MotionDAQConfig.Rows[i].Cells[4].Value = ((ChanType)(DaqChannelInfo[i].Config.ChanType)).ToString();
                dgv_MotionDAQConfig.Rows[i].Cells[5].Value = DaqChannelInfo[i].Config.Count;
            }
            dgv_MotionDAQConfig.Columns[0].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_MotionDAQConfig.Columns[1].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_MotionDAQConfig.Columns[2].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_MotionDAQConfig.Columns[3].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_MotionDAQConfig.Columns[4].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_MotionDAQConfig.Columns[5].DefaultCellStyle.BackColor = Color.LightGray;
            ChanPeriod = Period;
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            uint i = 0;
            uint AxesPerDev = new uint();
            string strTemp;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Open Device Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            //FT_DevAxesCount:Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Axis Number Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_ulAxisCount = AxesPerDev;
            dgv_MotionDAQConfig.Rows.Clear();
            CmbAxes.Items.Clear();
            CmbAxes.Text = "";
            //if you device is fixed,for example: PCI-1245 m_ulAxisCount =4
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle	
                //Open Axis 
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                CmbAxes.Items.Add(String.Format("{0:d}-Axis", i));
                double Position = 0;
                //Set command position for the specified axis
                Motion.mAcm_AxSetCmdPosition(m_Axishand[i], Position);
                //Set actual position for the specified axis
                Motion.mAcm_AxSetActualPosition(m_Axishand[i], Position);
            }
            CmbAxes.SelectedIndex = 0;
            cmb_ChannelNo.SelectedIndex = 0;
            m_bInit = true;
            InitDAQConfig();
            InitDataGridView();
            timer1.Enabled = true;    
        }
        public void InitDataGridView()
        {
            AxisNo.Items.Clear();
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                AxisNo.Items.Add("Axis_" + i.ToString());
            }
            Method.Items.Clear();
            for (int i = 0; i < m_ulAxisCount; i++)
            {
                uint MethodMap = 0;
                //The methods to trigger MotionDAQ function
                //You  can also use the old API:Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevMDAQTrigMap, ref MethodMap, ref BufferLength)
                //uint BufferLength;
                //BufferLength =4; buffer size for the property
                Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevMDAQTrigMap, ref MethodMap);
                if (((MethodMap >> i) & 0x01) == 1)
                {
                    if (i != 3)
                    {
                        Method.Items.Add(((MDAQTrigMethod)i).ToString());
                    }
                    else
                    {
                        for (int j = 0; j < m_ulAxisCount; j++)
                        {
                            Method.Items.Add(((MDAQTrigMethod)(i+j)).ToString());
                        }
                    }
                }
            }
            ChanType.Items.Clear();
            for (int i = 0; i < 4; i++)
            {
                uint ChanTypeMap = 0;
                //Data types that MotionDAQ supports
                //You  can also use the old API:Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevMDAQTypeMap, ref ChanTypeMap, ref BufferLength)
                //uint BufferLength;
                //BufferLength =4; buffer size for the property
                Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevMDAQTypeMap, ref ChanTypeMap);
                if (((ChanTypeMap >> i) & 0x01) == 1)
                {
                    ChanType.Items.Add(((ChanType)i).ToString());
                }
            }
        }
        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {
            UInt32 AxisNum;
            UInt32 Result;
            string strTemp;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver ON,1: On
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo On Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver OFF,0: Off
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo Off Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }
        }

        private void btnChan0Config_Click(object sender, EventArgs e)
        {
            if (m_bInit != true)
            {
                return;
            }
            FormMotionDaqConfig frmDaqConfig = new FormMotionDaqConfig(DaqChannelInfo[0].Config,m_ulAxisCount);
            string strTemp;
            frmDaqConfig.ShowDialog();
            if (frmDaqConfig.ShowDialog()==DialogResult.OK)
            {
                uint Period = frmDaqConfig.m_Period;
                uint AxisNo = frmDaqConfig.m_AxisNo;
                uint Method = frmDaqConfig.m_Method ;
                uint ChanType = frmDaqConfig.m_ChanType;
                uint MaxCount = frmDaqConfig.m_Count;
                //Set MotionDAQ related configurations
                uint Result = Motion.mAcm_DevMDaqConfig(m_DeviceHandle,0, Period, AxisNo, Method, ChanType, MaxCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set Configuration Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                else
                {
                    DaqChannelInfo[0].Config.Period = Period;
                    DaqChannelInfo[0].Config.AxisNo = AxisNo;
                    DaqChannelInfo[0].Config.Method = Method;
                    DaqChannelInfo[0].Config.ChanType = ChanType;
                    DaqChannelInfo[0].Config.Count = MaxCount;
                    dgv_MotionDAQConfig.Rows[0].Cells[1].Value = Period;
                    dgv_MotionDAQConfig.Rows[0].Cells[2].Value = ((AxisNo)DaqChannelInfo[0].Config.AxisNo).ToString();
                    dgv_MotionDAQConfig.Rows[0].Cells[3].Value = ((MDAQTrigMethod)DaqChannelInfo[0].Config.Method).ToString();
                    dgv_MotionDAQConfig.Rows[0].Cells[4].Value = ((ChanType)DaqChannelInfo[0].Config.ChanType).ToString();
                    dgv_MotionDAQConfig.Rows[0].Cells[5].Value = MaxCount;
                   
                }
            }
        }

        private void btnChan1Config_Click(object sender, EventArgs e)
        {
            if (m_bInit != true)
            {
                return;
            }
            FormMotionDaqConfig frmDaqConfig = new FormMotionDaqConfig(DaqChannelInfo[1].Config, m_ulAxisCount);
            string strTemp;
            frmDaqConfig.ShowDialog();
            if (frmDaqConfig.ShowDialog() == DialogResult.OK)
            {
                uint Period = frmDaqConfig.m_Period;
                uint AxisNo = frmDaqConfig.m_AxisNo;
                uint Method = frmDaqConfig.m_Method;
                uint ChanType = frmDaqConfig.m_ChanType;
                uint MaxCount = frmDaqConfig.m_Count;
                //Set MotionDAQ related configurations
                uint Result = Motion.mAcm_DevMDaqConfig(m_DeviceHandle, 1, Period, AxisNo, Method, ChanType, MaxCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set Configuration Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                else
                {
                    DaqChannelInfo[1].Config.Period = Period;
                    DaqChannelInfo[1].Config.AxisNo = AxisNo;
                    DaqChannelInfo[1].Config.Method = Method;
                    DaqChannelInfo[1].Config.ChanType = ChanType;
                    DaqChannelInfo[1].Config.Count = MaxCount;
                    dgv_MotionDAQConfig.Rows[1].Cells[1].Value = Period;
                    dgv_MotionDAQConfig.Rows[1].Cells[2].Value = ((AxisNo)AxisNo).ToString();
                    dgv_MotionDAQConfig.Rows[1].Cells[3].Value = ((MDAQTrigMethod)Method).ToString();
                    dgv_MotionDAQConfig.Rows[1].Cells[4].Value = ((ChanType)ChanType).ToString();
                    dgv_MotionDAQConfig.Rows[1].Cells[5].Value = MaxCount;
                }
            }
        }

        private void btnChan2Config_Click(object sender, EventArgs e)
        {
            if (m_bInit != true)
            {
                return;
            }
            FormMotionDaqConfig frmDaqConfig = new FormMotionDaqConfig(DaqChannelInfo[2].Config, m_ulAxisCount);
            string strTemp;
            frmDaqConfig.ShowDialog();
            if (frmDaqConfig.ShowDialog() == DialogResult.OK)
            {
                uint Period = frmDaqConfig.m_Period;
                uint AxisNo = frmDaqConfig.m_AxisNo;
                uint Method = frmDaqConfig.m_Method;
                uint ChanType = frmDaqConfig.m_ChanType;
                uint MaxCount = frmDaqConfig.m_Count;
                //Set MotionDAQ related configurations
                uint Result = Motion.mAcm_DevMDaqConfig(m_DeviceHandle, 2, Period, AxisNo, Method, ChanType, MaxCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set Configuration Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                else
                {
                    DaqChannelInfo[2].Config.Period = Period;
                    DaqChannelInfo[2].Config.AxisNo = AxisNo;
                    DaqChannelInfo[2].Config.Method = Method;
                    DaqChannelInfo[2].Config.ChanType = ChanType;
                    DaqChannelInfo[2].Config.Count = MaxCount;
                    dgv_MotionDAQConfig.Rows[2].Cells[1].Value = Period;
                    dgv_MotionDAQConfig.Rows[2].Cells[2].Value = ((AxisNo)AxisNo).ToString();
                    dgv_MotionDAQConfig.Rows[2].Cells[3].Value = ((MDAQTrigMethod)Method).ToString();
                    dgv_MotionDAQConfig.Rows[2].Cells[4].Value = ((ChanType)ChanType).ToString();
                    dgv_MotionDAQConfig.Rows[2].Cells[5].Value = MaxCount;
                }
            }
        }

        private void btnChan3Config_Click(object sender, EventArgs e)
        {
            if (m_bInit != true)
            {
                return;
            }
            FormMotionDaqConfig frmDaqConfig = new FormMotionDaqConfig(DaqChannelInfo[3].Config, m_ulAxisCount);
            string strTemp;
            frmDaqConfig.ShowDialog();
            if (frmDaqConfig.ShowDialog() == DialogResult.OK)
            {
                uint Period = frmDaqConfig.m_Period;
                uint AxisNo = frmDaqConfig.m_AxisNo;
                uint Method = frmDaqConfig.m_Method;
                uint ChanType = frmDaqConfig.m_ChanType;
                uint MaxCount = frmDaqConfig.m_Count;
                //Set MotionDAQ related configurations
                uint Result = Motion.mAcm_DevMDaqConfig(m_DeviceHandle, 3, Period, AxisNo, Method, ChanType, MaxCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set Configuration Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                else
                {
                    DaqChannelInfo[3].Config.Period = Period;
                    DaqChannelInfo[3].Config.AxisNo = AxisNo;
                    DaqChannelInfo[3].Config.Method = Method;
                    DaqChannelInfo[3].Config.ChanType = ChanType;
                    DaqChannelInfo[3].Config.Count = MaxCount;
                    dgv_MotionDAQConfig.Rows[3].Cells[1].Value = Period;
                    dgv_MotionDAQConfig.Rows[3].Cells[2].Value = ((AxisNo)AxisNo).ToString();
                    dgv_MotionDAQConfig.Rows[3].Cells[3].Value = ((MDAQTrigMethod)Method).ToString();
                    dgv_MotionDAQConfig.Rows[3].Cells[4].Value = ((ChanType)ChanType).ToString();
                    dgv_MotionDAQConfig.Rows[3].Cells[5].Value = MaxCount;
                }
            }
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            UInt32 Result = 0;
            string strTemp;
            //Enable MotionDAQ function to record related data
            Result = Motion.mAcm_DevMDaqStart(m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Start Motion DAQ Failed  With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            UInt32 Result = 0;
            string strTemp;
            //Stop recording MotionDAQ related data
            Result = Motion.mAcm_DevMDaqStop(m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Stop Motion DAQ Failed  With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
        }

        private void btn_GetDAQData_Click(object sender, EventArgs e)
        {
            UInt32 Result = 0;
            string strTemp;
            for (int i = 0; i < 4; i++)
            {
                if (DaqChannelInfo[i].Config.Method != 0)//Not Disable(Configuration is effective)
                {
                    if (DaqChannelInfo[i].DataBuffer == null)
                    {
                        DaqChannelInfo[i].DataBuffer = new int[2000];
                    }
                    else
                    {
                        for (int j = 0; j < 2000; j++)
                        {
                            DaqChannelInfo[i].DataBuffer[j] = 0;
                        }
                    }   
                    StartIndex = Convert.ToUInt16(txb_StartIndex.Text);
                    //Get all data in the range specified by MotionDAQ that has been
                    //recorded by corresponding channel
                    Result = Motion.mAcm_DevMDaqGetData(m_DeviceHandle, (ushort)i, StartIndex, (ushort)(DaqChannelInfo[i].Config.Count-StartIndex), DaqChannelInfo[i].DataBuffer);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Get Motion DAQ Data Failed  With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }
            lv_MDAQData.Items.Clear();
            string[] subItems = new string[2];
            if (DaqChannelInfo[cmb_ChannelNo.SelectedIndex].DataBuffer != null)
            {
                for (int i = 0; i < DaqChannelInfo[cmb_ChannelNo.SelectedIndex].Config.Count; i++)
                {
                    subItems[0] = i.ToString();
                    ListViewItem lvi = new ListViewItem(subItems);
                    lv_MDAQData.Items.Add(lvi);
                    lv_MDAQData.Items[i].SubItems[1].Text = DaqChannelInfo[cmb_ChannelNo.SelectedIndex].DataBuffer[i].ToString();
                }
            }
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            UInt32 Result = 0;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            for (int i = 0; i < 4; i++)
            {
                //Clear MotionDAQ related data of corresponding ChannelID.
                Result = Motion.mAcm_DevMDaqReset(m_DeviceHandle, (ushort)i);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Reset Motion DAQ Failed  With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
            lv_MDAQData.Items.Clear();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UInt32 Result = 0;
            ushort CurrentCnt = 0;
            byte Status = 0;
            String DaqStatus = "";
            double CurCmd = new double();
            double CurAct= new double();
            UInt32 IOStatus = new UInt32();
            if (m_bInit != true)
            {
                return;
            }
            for (int i = 0; i < 4; i++)
            {
                //Get MotionDAQ status of corresponding ChannelID.
                Result = Motion.mAcm_DevMDaqGetStatus(m_DeviceHandle,(ushort)i, ref CurrentCnt, ref Status);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    switch ((MDAQStatus)Status)
                    {
                        case MDAQStatus.MDAQST_Ready:
                            DaqStatus = "Status:Ready.";
                            break;
                        case MDAQStatus.MDAQST_WaitTrig:
                            DaqStatus = "Status:Wait Trigger.";
                            break;
                        case MDAQStatus.MDAQST_Started:
                            DaqStatus = "Status:Started";
                            break;
                        default:
                            break;
                    }
                    switch (i)
                    {
                        case 0:
                            txb_CurrentCnt0.Text = CurrentCnt.ToString();
                            DaqChannelInfo[i].CurrentCnt = CurrentCnt;
                            lbl_Status0.Text = DaqStatus;
                            break;
                        case 1:
                            txb_CurrentCnt1.Text = CurrentCnt.ToString();
                            DaqChannelInfo[i].CurrentCnt = CurrentCnt;
                            lbl_Status1.Text = DaqStatus;
                            break;
                        case 2:
                            txb_CurrentCnt2.Text = CurrentCnt.ToString();
                            DaqChannelInfo[i].CurrentCnt = CurrentCnt;
                            lbl_Status2.Text = DaqStatus;
                            break;
                        case 3:
                            txb_CurrentCnt3.Text = CurrentCnt.ToString();
                            DaqChannelInfo[i].CurrentCnt = CurrentCnt;
                            lbl_Status3.Text = DaqStatus;
                            break;
                    }

                }
            }
            //Get current command position of the specified axis
            Motion.mAcm_AxGetCmdPosition(m_Axishand[CmbAxes.SelectedIndex], ref CurCmd);
            txb_Cmd.Text = Convert.ToString(CurCmd);
            //Get current actual position of the specified axis
            Motion.mAcm_AxGetActualPosition(m_Axishand[CmbAxes.SelectedIndex], ref CurAct);
            txb_Act.Text = Convert.ToString(CurAct);
            //Get the motion I/O status of the axis.
            Result = Motion.mAcm_AxGetMotionIO(m_Axishand[CmbAxes.SelectedIndex], ref IOStatus);
            if (Result == (uint)ErrorCode.SUCCESS)
            {
                GetMotionIOStatus(IOStatus);
            }

        }
        private void GetMotionIOStatus(uint IOStatus)
        {
            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ALM) > 0)//ALM
            {
                pictureBoxALM.BackColor = Color.Red;
            }
            else
            {
                pictureBoxALM.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ORG) > 0)//ORG
            {
                pictureBoxORG.BackColor = Color.Red;
            }
            else
            {
                pictureBoxORG.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTP) > 0)//+EL
            {
                pictureBoxPosHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxPosHEL.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTN) > 0)//-EL
            {
                pictureBoxNegHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxNegHEL.BackColor = Color.Gray;
            }
        }
        Boolean VersionIsOk = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            if (VersionIsOk == false)
            {
               return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite 
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void BtnLeftMove_Click(object sender, EventArgs e)
        {
            string strTemp;
            UInt32 Result;
            if (m_bInit)
            {
                //To command axis to make a never ending movement with a specified velocity.1: Negative direction.
                Result = Motion.mAcm_AxMoveVel(m_Axishand[CmbAxes.SelectedIndex], 1);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }

        private void BtnRightMove_Click(object sender, EventArgs e)
        {
            string strTemp;
            UInt32 Result;
            if (m_bInit)
            {
                //To command axis to make a never ending movement with a specified velocity.1: Negative direction.
                Result = Motion.mAcm_AxMoveVel(m_Axishand[CmbAxes.SelectedIndex], 0);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Move Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            if (m_bInit)
            {
                //To command axis to decelerate to stop.
                Result = Motion.mAcm_AxStopDec(m_Axishand[CmbAxes.SelectedIndex]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Axis To decelerate Stop Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
            return;
        }

        private void btn_ResetCounter_Click(object sender, EventArgs e)
        {
            double cmdPosition = new double();
            uint Result;
            string strTemp;
            cmdPosition = 0;
            if (m_bInit == true)
            {
                //Set command position for the specified axis
                Result = Motion.mAcm_AxSetCmdPosition(m_Axishand[CmbAxes.SelectedIndex], cmdPosition);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set axis's command position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                Result = Motion.mAcm_AxSetActualPosition(m_Axishand[CmbAxes.SelectedIndex], cmdPosition);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set axis's actual position failed with error code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }

        private void cmb_ChannelNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            lv_MDAQData.Items.Clear();
            string[] subItems = new string[2];
            if (DaqChannelInfo[cmb_ChannelNo.SelectedIndex].DataBuffer != null)
            {
                for (int i = 0; i < DaqChannelInfo[cmb_ChannelNo.SelectedIndex].Config.Count; i++)
                {
                    subItems[0] = i.ToString();
                    ListViewItem lvi = new ListViewItem(subItems);
                    lv_MDAQData.Items.Add(lvi);
                    lv_MDAQData.Items[i].SubItems[1].Text = DaqChannelInfo[cmb_ChannelNo.SelectedIndex].DataBuffer[i].ToString();
                }
            }
        }
        //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "Motion DAQ", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            UInt16[] usAxisState = new UInt16[32];
            uint AxisNum;
            //Stop Every Axes
            if (m_bInit == true)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Get the axis's current state
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will be changed to Ready after calling this function
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    //To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                //Close Axes
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);
                }
                m_ulAxisCount = 0;
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                timer1.Enabled = false;
                m_bInit = false;
                txb_Cmd.Clear();
                txb_Act.Clear();
                dgv_MotionDAQConfig.Rows.Clear();
                lv_MDAQData.Items.Clear();
                CmbAxes.Items.Clear();
                CmbAxes.Text = "";
            }
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }

        private void buttonLoadCfg_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            this.OpenConfigFile.FileName = ".cfg";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, OpenConfigFile.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load Config Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }		 
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {
               
                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "Motion DAQ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
              
            }
            return true;
        }
    }
}