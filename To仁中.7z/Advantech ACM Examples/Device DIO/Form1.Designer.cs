﻿using Advantech.Motion;
using System;
namespace Device_DIO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gb_DO = new System.Windows.Forms.GroupBox();
            this.BtnDO7 = new System.Windows.Forms.Button();
            this.BtnDO6 = new System.Windows.Forms.Button();
            this.BtnDO5 = new System.Windows.Forms.Button();
            this.BtnDO4 = new System.Windows.Forms.Button();
            this.BtnDO3 = new System.Windows.Forms.Button();
            this.BtnDO2 = new System.Windows.Forms.Button();
            this.BtnDO1 = new System.Windows.Forms.Button();
            this.BtnDO0 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox0 = new System.Windows.Forms.PictureBox();
            this.gb_DI = new System.Windows.Forms.GroupBox();
            this.pictureBoxDI7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI0 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDI1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gb_DO.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0)).BeginInit();
            this.gb_DI.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI1)).BeginInit();
            this.SuspendLayout();
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(130, 18);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(160, 20);
            this.CmbAvailableDevice.TabIndex = 20;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 19;
            this.label1.Text = "Available device:";
            // 
            // gb_DO
            // 
            this.gb_DO.Controls.Add(this.BtnDO7);
            this.gb_DO.Controls.Add(this.BtnDO6);
            this.gb_DO.Controls.Add(this.BtnDO5);
            this.gb_DO.Controls.Add(this.BtnDO4);
            this.gb_DO.Controls.Add(this.BtnDO3);
            this.gb_DO.Controls.Add(this.BtnDO2);
            this.gb_DO.Controls.Add(this.BtnDO1);
            this.gb_DO.Controls.Add(this.BtnDO0);
            this.gb_DO.Controls.Add(this.pictureBox5);
            this.gb_DO.Controls.Add(this.pictureBox6);
            this.gb_DO.Controls.Add(this.pictureBox7);
            this.gb_DO.Controls.Add(this.pictureBox4);
            this.gb_DO.Controls.Add(this.pictureBox3);
            this.gb_DO.Controls.Add(this.pictureBox2);
            this.gb_DO.Controls.Add(this.pictureBox1);
            this.gb_DO.Controls.Add(this.pictureBox0);
            this.gb_DO.Enabled = false;
            this.gb_DO.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gb_DO.Location = new System.Drawing.Point(20, 52);
            this.gb_DO.Name = "gb_DO";
            this.gb_DO.Size = new System.Drawing.Size(281, 162);
            this.gb_DO.TabIndex = 22;
            this.gb_DO.TabStop = false;
            this.gb_DO.Text = "DO";
            // 
            // BtnDO7
            // 
            this.BtnDO7.Location = new System.Drawing.Point(229, 128);
            this.BtnDO7.Name = "BtnDO7";
            this.BtnDO7.Size = new System.Drawing.Size(33, 23);
            this.BtnDO7.TabIndex = 29;
            this.BtnDO7.Text = "DO7";
            this.BtnDO7.UseVisualStyleBackColor = true;
            this.BtnDO7.Click += new System.EventHandler(this.BtnDO7_Click);
            // 
            // BtnDO6
            // 
            this.BtnDO6.Location = new System.Drawing.Point(160, 128);
            this.BtnDO6.Name = "BtnDO6";
            this.BtnDO6.Size = new System.Drawing.Size(33, 23);
            this.BtnDO6.TabIndex = 28;
            this.BtnDO6.Text = "DO6";
            this.BtnDO6.UseVisualStyleBackColor = true;
            this.BtnDO6.Click += new System.EventHandler(this.BtnDO6_Click);
            // 
            // BtnDO5
            // 
            this.BtnDO5.Location = new System.Drawing.Point(91, 128);
            this.BtnDO5.Name = "BtnDO5";
            this.BtnDO5.Size = new System.Drawing.Size(33, 23);
            this.BtnDO5.TabIndex = 27;
            this.BtnDO5.Text = "DO5";
            this.BtnDO5.UseVisualStyleBackColor = true;
            this.BtnDO5.Click += new System.EventHandler(this.BtnDO5_Click);
            // 
            // BtnDO4
            // 
            this.BtnDO4.Location = new System.Drawing.Point(22, 128);
            this.BtnDO4.Name = "BtnDO4";
            this.BtnDO4.Size = new System.Drawing.Size(33, 23);
            this.BtnDO4.TabIndex = 26;
            this.BtnDO4.Text = "DO4";
            this.BtnDO4.UseVisualStyleBackColor = true;
            this.BtnDO4.Click += new System.EventHandler(this.BtnDO4_Click);
            // 
            // BtnDO3
            // 
            this.BtnDO3.Location = new System.Drawing.Point(229, 59);
            this.BtnDO3.Name = "BtnDO3";
            this.BtnDO3.Size = new System.Drawing.Size(33, 23);
            this.BtnDO3.TabIndex = 25;
            this.BtnDO3.Text = "DO3";
            this.BtnDO3.UseVisualStyleBackColor = true;
            this.BtnDO3.Click += new System.EventHandler(this.BtnDO3_Click);
            // 
            // BtnDO2
            // 
            this.BtnDO2.Location = new System.Drawing.Point(159, 59);
            this.BtnDO2.Name = "BtnDO2";
            this.BtnDO2.Size = new System.Drawing.Size(33, 23);
            this.BtnDO2.TabIndex = 24;
            this.BtnDO2.Text = "DO2";
            this.BtnDO2.UseVisualStyleBackColor = true;
            this.BtnDO2.Click += new System.EventHandler(this.BtnDO2_Click);
            // 
            // BtnDO1
            // 
            this.BtnDO1.Location = new System.Drawing.Point(91, 59);
            this.BtnDO1.Name = "BtnDO1";
            this.BtnDO1.Size = new System.Drawing.Size(33, 23);
            this.BtnDO1.TabIndex = 23;
            this.BtnDO1.Text = "DO1";
            this.BtnDO1.UseVisualStyleBackColor = true;
            this.BtnDO1.Click += new System.EventHandler(this.BtnDO1_Click);
            // 
            // BtnDO0
            // 
            this.BtnDO0.Location = new System.Drawing.Point(21, 59);
            this.BtnDO0.Name = "BtnDO0";
            this.BtnDO0.Size = new System.Drawing.Size(33, 23);
            this.BtnDO0.TabIndex = 22;
            this.BtnDO0.Text = "DO0";
            this.BtnDO0.UseVisualStyleBackColor = true;
            this.BtnDO0.Click += new System.EventHandler(this.BtnDO0_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Gray;
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Location = new System.Drawing.Point(93, 95);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(25, 24);
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Gray;
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Location = new System.Drawing.Point(163, 95);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(25, 24);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Gray;
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Location = new System.Drawing.Point(234, 95);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(25, 24);
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Gray;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(25, 95);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(25, 24);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Gray;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(234, 24);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(25, 24);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Gray;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(164, 24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(25, 24);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gray;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(95, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(25, 24);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox0
            // 
            this.pictureBox0.BackColor = System.Drawing.Color.Gray;
            this.pictureBox0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox0.Location = new System.Drawing.Point(26, 24);
            this.pictureBox0.Name = "pictureBox0";
            this.pictureBox0.Size = new System.Drawing.Size(25, 24);
            this.pictureBox0.TabIndex = 0;
            this.pictureBox0.TabStop = false;
            // 
            // gb_DI
            // 
            this.gb_DI.Controls.Add(this.pictureBoxDI7);
            this.gb_DI.Controls.Add(this.pictureBoxDI6);
            this.gb_DI.Controls.Add(this.pictureBoxDI4);
            this.gb_DI.Controls.Add(this.pictureBoxDI5);
            this.gb_DI.Controls.Add(this.pictureBoxDI3);
            this.gb_DI.Controls.Add(this.pictureBoxDI2);
            this.gb_DI.Controls.Add(this.pictureBoxDI0);
            this.gb_DI.Controls.Add(this.pictureBoxDI1);
            this.gb_DI.Enabled = false;
            this.gb_DI.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gb_DI.Location = new System.Drawing.Point(20, 225);
            this.gb_DI.Name = "gb_DI";
            this.gb_DI.Size = new System.Drawing.Size(281, 107);
            this.gb_DI.TabIndex = 23;
            this.gb_DI.TabStop = false;
            this.gb_DI.Text = "DI";
            // 
            // pictureBoxDI7
            // 
            this.pictureBoxDI7.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI7.Location = new System.Drawing.Point(233, 70);
            this.pictureBoxDI7.Name = "pictureBoxDI7";
            this.pictureBoxDI7.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI7.TabIndex = 37;
            this.pictureBoxDI7.TabStop = false;
            // 
            // pictureBoxDI6
            // 
            this.pictureBoxDI6.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI6.Location = new System.Drawing.Point(163, 70);
            this.pictureBoxDI6.Name = "pictureBoxDI6";
            this.pictureBoxDI6.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI6.TabIndex = 36;
            this.pictureBoxDI6.TabStop = false;
            // 
            // pictureBoxDI4
            // 
            this.pictureBoxDI4.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI4.Location = new System.Drawing.Point(23, 70);
            this.pictureBoxDI4.Name = "pictureBoxDI4";
            this.pictureBoxDI4.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI4.TabIndex = 34;
            this.pictureBoxDI4.TabStop = false;
            // 
            // pictureBoxDI5
            // 
            this.pictureBoxDI5.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI5.Location = new System.Drawing.Point(93, 70);
            this.pictureBoxDI5.Name = "pictureBoxDI5";
            this.pictureBoxDI5.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI5.TabIndex = 35;
            this.pictureBoxDI5.TabStop = false;
            // 
            // pictureBoxDI3
            // 
            this.pictureBoxDI3.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI3.Location = new System.Drawing.Point(233, 29);
            this.pictureBoxDI3.Name = "pictureBoxDI3";
            this.pictureBoxDI3.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI3.TabIndex = 33;
            this.pictureBoxDI3.TabStop = false;
            // 
            // pictureBoxDI2
            // 
            this.pictureBoxDI2.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI2.Location = new System.Drawing.Point(163, 29);
            this.pictureBoxDI2.Name = "pictureBoxDI2";
            this.pictureBoxDI2.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI2.TabIndex = 32;
            this.pictureBoxDI2.TabStop = false;
            // 
            // pictureBoxDI0
            // 
            this.pictureBoxDI0.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI0.Location = new System.Drawing.Point(23, 29);
            this.pictureBoxDI0.Name = "pictureBoxDI0";
            this.pictureBoxDI0.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI0.TabIndex = 30;
            this.pictureBoxDI0.TabStop = false;
            // 
            // pictureBoxDI1
            // 
            this.pictureBoxDI1.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxDI1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDI1.Location = new System.Drawing.Point(93, 29);
            this.pictureBoxDI1.Name = "pictureBoxDI1";
            this.pictureBoxDI1.Size = new System.Drawing.Size(25, 24);
            this.pictureBoxDI1.TabIndex = 31;
            this.pictureBoxDI1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 355);
            this.Controls.Add(this.gb_DI);
            this.Controls.Add(this.gb_DO);
            this.Controls.Add(this.CmbAvailableDevice);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Device DIO";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.gb_DO.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox0)).EndInit();
            this.gb_DI.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDI1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gb_DO;
        private System.Windows.Forms.Button BtnDO7;
        private System.Windows.Forms.Button BtnDO6;
        private System.Windows.Forms.Button BtnDO5;
        private System.Windows.Forms.Button BtnDO4;
        private System.Windows.Forms.Button BtnDO3;
        private System.Windows.Forms.Button BtnDO2;
        private System.Windows.Forms.Button BtnDO1;
        private System.Windows.Forms.Button BtnDO0;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox0;
        private System.Windows.Forms.GroupBox gb_DI;
        private System.Windows.Forms.PictureBox pictureBoxDI7;
        private System.Windows.Forms.PictureBox pictureBoxDI6;
        private System.Windows.Forms.PictureBox pictureBoxDI4;
        private System.Windows.Forms.PictureBox pictureBoxDI5;
        private System.Windows.Forms.PictureBox pictureBoxDI3;
        private System.Windows.Forms.PictureBox pictureBoxDI2;
        private System.Windows.Forms.PictureBox pictureBoxDI0;
        private System.Windows.Forms.PictureBox pictureBoxDI1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[32];
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        private System.Windows.Forms.Timer timer1;
    }
}

