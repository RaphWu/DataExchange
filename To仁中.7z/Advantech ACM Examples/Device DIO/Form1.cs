﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Diagnostics;
namespace Device_DIO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite 
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            uint Result;
            uint deviceFunctionMap = 0;
            string strTemp;
            CloseBoardOrForm();
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Open Device Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_bInit = true;
            //Get device supported functions.1: support, 0: Not support
            //You can also use the old API:  Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevFunctionMap, ref deviceFunctionMap,ref BufferLength);
            //uint BufferLength;
            //	BufferLength =4; buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevFunctionMap, ref deviceFunctionMap);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            if ((deviceFunctionMap >> 7 & 0x01) == 1)
            {
                gb_DI.Enabled = true;
                timer1.Enabled = true;
            }
            if ((deviceFunctionMap >> 8 & 0x01) == 1)
            {
                gb_DO.Enabled = true;
                InitDO();
            }
        }

        private void ReInitBackCoolor()
        {
            pictureBox0.BackColor = Color.Gray;
            pictureBox1.BackColor = Color.Gray;
            pictureBox2.BackColor = Color.Gray;
            pictureBox3.BackColor = Color.Gray;
            pictureBox4.BackColor = Color.Gray;
            pictureBox5.BackColor = Color.Gray;
            pictureBox6.BackColor = Color.Gray;
            pictureBox7.BackColor = Color.Gray;
            pictureBoxDI0.BackColor = Color.Gray;
            pictureBoxDI1.BackColor = Color.Gray;
            pictureBoxDI2.BackColor = Color.Gray;
            pictureBoxDI3.BackColor = Color.Gray;
            pictureBoxDI4.BackColor = Color.Gray;
            pictureBoxDI5.BackColor = Color.Gray;
            pictureBoxDI6.BackColor = Color.Gray;
            pictureBoxDI7.BackColor = Color.Gray;
        }

        private void InitDO()
        {
            UInt32 Result;
            ushort i = 0;
            byte bitDo = 0;
            PictureBox pictureBox;
            Button BtnDO;
          
            if (m_bInit)
            {
                for (i = 0; i < 8; i++)
                {
                    switch (i)
                    {
                        case 0:
                            pictureBox = pictureBox0;
                            BtnDO = BtnDO0;
                            break;
                        case 1:
                            pictureBox = pictureBox1;
                            BtnDO = BtnDO1;
                            break;
                        case 2:
                            pictureBox = pictureBox2;
                            BtnDO = BtnDO2;
                            break;
                        case 3:
                            pictureBox = pictureBox3;
                            BtnDO = BtnDO3;
                            break;
                        case 4:
                            pictureBox = pictureBox4;
                            BtnDO = BtnDO4;
                            break;
                        case 5:
                            pictureBox = pictureBox5;
                            BtnDO = BtnDO5;
                            break;
                        case 6:
                            pictureBox = pictureBox6;
                            BtnDO = BtnDO6;
                            break;
                        case 7:
                            pictureBox = pictureBox7;
                            BtnDO = BtnDO7;
                            break;
                        default:
                            return;
                    }
                    //Get the bit value of specified DO channel
                    Result = Motion.mAcm_DaqDoGetBit(m_DeviceHandle, i, ref bitDo);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        pictureBox.Enabled = false;
                        BtnDO.Enabled = false;
                    }
                    else
                    {
                        pictureBox.Enabled = true;
                        BtnDO.Enabled = true;
                        if (bitDo == 1)
                        {
                            pictureBox.BackColor = System.Drawing.Color.Red;
                        }
                        else
                        {
                            pictureBox.BackColor = System.Drawing.Color.Green;
                        }
                    }
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UInt32 Result;
            ushort i = 0;
            byte BitIn = 0;
            PictureBox pictureBox;
            if (m_bInit)
            {
                for (i = 0; i < 8; i++)
                {
                    //Get the bit data of specified DI channel
                    Result = Motion.mAcm_DaqDiGetBit(m_DeviceHandle, i, ref BitIn);
                    switch (i)
                    {
                        case 0:
                            pictureBox = pictureBoxDI0;
                            break;
                        case 1:
                            pictureBox = pictureBoxDI1;
                            break;
                        case 2:
                            pictureBox = pictureBoxDI2;
                            break;
                        case 3:
                            pictureBox = pictureBoxDI3;
                            break;
                        case 4:
                            pictureBox = pictureBoxDI4;
                            break;
                        case 5:
                            pictureBox = pictureBoxDI5;
                            break;
                        case 6:
                            pictureBox = pictureBoxDI6;
                            break;
                        case 7:
                            pictureBox = pictureBoxDI7;
                            break;
                        default:
                            return;
                    }
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        pictureBox.Enabled = false;
                    }
                    else
                    {
                        pictureBox.Enabled = true;
                        if (BitIn == 1)
                        {
                            pictureBox.BackColor = System.Drawing.Color.Red;
                        }
                        else
                        {
                            pictureBox.BackColor = System.Drawing.Color.Green;
                        }
                    }
                }
            }
        }

        private void BtnDO_Click(PictureBox pictureBoxDO, ushort DOChannel)
        {
            UInt32 Result;
            byte DoValue;
            string strTemp;
            if (pictureBoxDO.BackColor == System.Drawing.Color.Red)
            {
                DoValue = 0;
            }
            else
                DoValue = 1;
            //Set the value to specified DO channel
            Result = Motion.mAcm_DaqDoSetBit(m_DeviceHandle, DOChannel, DoValue);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set DaqDoSetBit Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            else
            {
                if (pictureBoxDO.BackColor == System.Drawing.Color.Red)
                    pictureBoxDO.BackColor = System.Drawing.Color.Green;
                else
                    pictureBoxDO.BackColor = System.Drawing.Color.Red;
            }
        }

        private void BtnDO0_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pictureBox0, 0);
        }

        private void BtnDO1_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pictureBox1, 1);
        }

        private void BtnDO2_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pictureBox2, 2);
        }

        private void BtnDO3_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pictureBox3, 3);
        }

        private void BtnDO4_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pictureBox4, 4);
        }

        private void BtnDO5_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pictureBox5, 5);
        }

        private void BtnDO6_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pictureBox6, 6);
        }

        private void BtnDO7_Click(object sender, EventArgs e)
        {
            BtnDO_Click(pictureBox7, 7);
        }
        //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "Device DIO", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();
        }
        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            //Stop Every Axes
            if (m_bInit == true)
            {
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                gb_DI.Enabled = false;
                gb_DO.Enabled = false;
                ReInitBackCoolor();
                timer1.Enabled = false;
                m_bInit = false;
            }
        }
    } 
}