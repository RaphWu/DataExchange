using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using  Advantech.Motion;
using System.Diagnostics;
namespace DataProtect
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Open Device Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_bInit = true;
            cmb_PropertyID.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot��Perhaps the opposite 
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment��you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
           CmbAvailableDevice.Items.Clear();
           for (int i = 0; i < deviceCount; i++)
           {
              CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
           }
           if (deviceCount > 0)
           {
              CmbAvailableDevice.SelectedIndex = 0;
              DeviceNum = CurAvailableDevs[0].DeviceNum;
           }
        }

        private void btn_Set_Click(object sender, EventArgs e)
        {
            string strTemp;
            UInt32[] Passwrd = new UInt32[2];
            UInt32[] wData = new UInt32[2];
            UInt32 Result;
            ushort m_PrivateID;
            if (txb_PassWord1.Text == "" && txb_PassWord2.Text == "" && txb_PassData1.Text == "" && txb_PassData2.Text == "")
            {
                MessageBox.Show("Please Input PassWord And PassData", "Data Protect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (txb_PassWord1.Text == "")
                Passwrd[0] = 0;
            else
            {
                strTemp = "0x" + txb_PassWord1.Text;
                Passwrd[0] = Convert.ToUInt32(strTemp, 16);
            }
            if (txb_PassWord2.Text == "")
                Passwrd[1] = 0;
            else
            {
                strTemp = "0x" + txb_PassWord2.Text;
                Passwrd[1] = Convert.ToUInt32(strTemp, 16);
            }
            if (txb_PassData1.Text == "")
                wData[0] = 0;
            else
            {
                strTemp = "0x" + txb_PassData1.Text;
                wData[0] = Convert.ToUInt32(strTemp, 16);
            }
            if (txb_PassData2.Text == "")
            {
                wData[1] = 0;
            }
            else
            {
                strTemp = "0x" + txb_PassData2.Text;
                wData[1] = Convert.ToUInt32(strTemp, 16);
            }
            m_PrivateID = (ushort)cmb_PropertyID.SelectedIndex;
            //write protect data to ROM
            Result = Motion.mAcm_DevWriteEEPROM_Ex(m_DeviceHandle, m_PrivateID, Passwrd, 2, wData, 2);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Set Private Data Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void btn_Get_Click(object sender, EventArgs e)
        {
            UInt32[] Passwrd = new UInt32[2];
            UInt32[] rData = new UInt32[2];
            string strTemp;
            ushort m_PrivateID;
            UInt32 Result;
            if (txb_ReadPassWord1.Text == "")
                Passwrd[0] = 0;
            else
            {
                strTemp = "0x" + txb_ReadPassWord1.Text;
                Passwrd[0] = Convert.ToUInt32(strTemp, 16);
            }
            if (txb_ReadPassWord2.Text == "")
                Passwrd[1] = 0;
            else
            {
                strTemp = "0x" + txb_ReadPassWord2.Text;
                Passwrd[1] = Convert.ToUInt32(strTemp, 16);
            }      
            m_PrivateID = (ushort)cmb_PropertyID.SelectedIndex;
            //Read data form EEPROM
            Result = Motion.mAcm_DevReadEEPROM_Ex(m_DeviceHandle, m_PrivateID, Passwrd, 2, rData, 2);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Private Data Failed With Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            txb_ReadPassData1.Text = Convert.ToString(rData[0],16);
            txb_ReadPassData2.Text = Convert.ToString(rData[1], 16);
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
           CloseBoardOrForm();
        }
         //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "DataProtect", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
          //User-defined API to close board
        private void CloseBoardOrForm()
        {
            //Close Device
             Motion.mAcm_DevClose(ref m_DeviceHandle);
            m_DeviceHandle = IntPtr.Zero;
            m_bInit = false;
            txb_ReadPassWord1.Text = "";
            txb_ReadPassWord2.Text = "";
            txb_ReadPassData1.Text = "";
            txb_ReadPassData2.Text ="";
            txb_PassWord1.Text ="";
            txb_PassWord2.Text = "";
            txb_PassData1.Text = "";
            txb_PassData2.Text = "";
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();
        }
        //get the device number of fixed equipment
        private UInt32 GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID)
        {
            return (UInt32)(DevType << 24 | BoardID << 12 | MasterRingNo << 8 | SlaveBoardID);
        }
    }
}