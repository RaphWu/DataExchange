﻿using Advantech.Motion;
using System;
namespace DataProtect
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_PropertyID = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Get = new System.Windows.Forms.Button();
            this.txb_ReadPassData2 = new System.Windows.Forms.TextBox();
            this.txb_ReadPassData1 = new System.Windows.Forms.TextBox();
            this.txb_ReadPassWord2 = new System.Windows.Forms.TextBox();
            this.txb_ReadPassWord1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_Set = new System.Windows.Forms.Button();
            this.txb_PassData2 = new System.Windows.Forms.TextBox();
            this.txb_PassData1 = new System.Windows.Forms.TextBox();
            this.txb_PassWord2 = new System.Windows.Forms.TextBox();
            this.txb_PassWord1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(213, 45);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(98, 25);
            this.BtnCloseBoard.TabIndex = 15;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(77, 45);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(98, 25);
            this.BtnOpenBoard.TabIndex = 14;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(155, 14);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(157, 20);
            this.CmbAvailableDevice.TabIndex = 13;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 12;
            this.label1.Text = "Available device:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 16;
            this.label2.Text = "PrivateID:";
            // 
            // cmb_PropertyID
            // 
            this.cmb_PropertyID.FormattingEnabled = true;
            this.cmb_PropertyID.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.cmb_PropertyID.Location = new System.Drawing.Point(144, 85);
            this.cmb_PropertyID.Name = "cmb_PropertyID";
            this.cmb_PropertyID.Size = new System.Drawing.Size(167, 20);
            this.cmb_PropertyID.TabIndex = 17;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_Get);
            this.groupBox1.Controls.Add(this.txb_ReadPassData2);
            this.groupBox1.Controls.Add(this.txb_ReadPassData1);
            this.groupBox1.Controls.Add(this.txb_ReadPassWord2);
            this.groupBox1.Controls.Add(this.txb_ReadPassWord1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(23, 231);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(332, 113);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "GetData";
            // 
            // btn_Get
            // 
            this.btn_Get.Location = new System.Drawing.Point(132, 81);
            this.btn_Get.Name = "btn_Get";
            this.btn_Get.Size = new System.Drawing.Size(86, 26);
            this.btn_Get.TabIndex = 6;
            this.btn_Get.Text = "Get Data ";
            this.btn_Get.UseVisualStyleBackColor = true;
            this.btn_Get.Click += new System.EventHandler(this.btn_Get_Click);
            // 
            // txb_ReadPassData2
            // 
            this.txb_ReadPassData2.Location = new System.Drawing.Point(201, 51);
            this.txb_ReadPassData2.Name = "txb_ReadPassData2";
            this.txb_ReadPassData2.ReadOnly = true;
            this.txb_ReadPassData2.Size = new System.Drawing.Size(111, 21);
            this.txb_ReadPassData2.TabIndex = 5;
            // 
            // txb_ReadPassData1
            // 
            this.txb_ReadPassData1.Location = new System.Drawing.Point(79, 51);
            this.txb_ReadPassData1.Name = "txb_ReadPassData1";
            this.txb_ReadPassData1.ReadOnly = true;
            this.txb_ReadPassData1.Size = new System.Drawing.Size(111, 21);
            this.txb_ReadPassData1.TabIndex = 4;
            // 
            // txb_ReadPassWord2
            // 
            this.txb_ReadPassWord2.Location = new System.Drawing.Point(201, 21);
            this.txb_ReadPassWord2.Name = "txb_ReadPassWord2";
            this.txb_ReadPassWord2.Size = new System.Drawing.Size(111, 21);
            this.txb_ReadPassWord2.TabIndex = 3;
            // 
            // txb_ReadPassWord1
            // 
            this.txb_ReadPassWord1.Location = new System.Drawing.Point(79, 21);
            this.txb_ReadPassWord1.Name = "txb_ReadPassWord1";
            this.txb_ReadPassWord1.Size = new System.Drawing.Size(111, 21);
            this.txb_ReadPassWord1.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "Data:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "PassWord:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_Set);
            this.groupBox2.Controls.Add(this.txb_PassData2);
            this.groupBox2.Controls.Add(this.txb_PassData1);
            this.groupBox2.Controls.Add(this.txb_PassWord2);
            this.groupBox2.Controls.Add(this.txb_PassWord1);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(23, 109);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(332, 112);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "SetData";
            // 
            // btn_Set
            // 
            this.btn_Set.Location = new System.Drawing.Point(132, 77);
            this.btn_Set.Name = "btn_Set";
            this.btn_Set.Size = new System.Drawing.Size(86, 26);
            this.btn_Set.TabIndex = 6;
            this.btn_Set.Text = "Set Data";
            this.btn_Set.UseVisualStyleBackColor = true;
            this.btn_Set.Click += new System.EventHandler(this.btn_Set_Click);
            // 
            // txb_PassData2
            // 
            this.txb_PassData2.Location = new System.Drawing.Point(201, 50);
            this.txb_PassData2.Name = "txb_PassData2";
            this.txb_PassData2.Size = new System.Drawing.Size(111, 21);
            this.txb_PassData2.TabIndex = 5;
            // 
            // txb_PassData1
            // 
            this.txb_PassData1.Location = new System.Drawing.Point(79, 50);
            this.txb_PassData1.Name = "txb_PassData1";
            this.txb_PassData1.Size = new System.Drawing.Size(111, 21);
            this.txb_PassData1.TabIndex = 4;
            // 
            // txb_PassWord2
            // 
            this.txb_PassWord2.Location = new System.Drawing.Point(201, 21);
            this.txb_PassWord2.Name = "txb_PassWord2";
            this.txb_PassWord2.Size = new System.Drawing.Size(111, 21);
            this.txb_PassWord2.TabIndex = 3;
            // 
            // txb_PassWord1
            // 
            this.txb_PassWord1.Location = new System.Drawing.Point(79, 21);
            this.txb_PassWord1.Name = "txb_PassWord1";
            this.txb_PassWord1.Size = new System.Drawing.Size(111, 21);
            this.txb_PassWord1.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(41, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "Data:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "PassWord:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 364);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmb_PropertyID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnCloseBoard);
            this.Controls.Add(this.BtnOpenBoard);
            this.Controls.Add(this.CmbAvailableDevice);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DataProtect";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        bool m_bInit = false;
        uint deviceCount = 0;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_PropertyID;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Get;
        private System.Windows.Forms.TextBox txb_ReadPassData2;
        private System.Windows.Forms.TextBox txb_ReadPassData1;
        private System.Windows.Forms.TextBox txb_ReadPassWord2;
        private System.Windows.Forms.TextBox txb_ReadPassWord1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_Set;
        private System.Windows.Forms.TextBox txb_PassData2;
        private System.Windows.Forms.TextBox txb_PassData1;
        private System.Windows.Forms.TextBox txb_PassWord2;
        private System.Windows.Forms.TextBox txb_PassWord1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

