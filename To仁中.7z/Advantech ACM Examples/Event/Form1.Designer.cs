﻿using Advantech.Motion;//Common Motion API
using System;
namespace Event
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBoxVHEnd = new System.Windows.Forms.CheckBox();
            this.checkBoxVHStart = new System.Windows.Forms.CheckBox();
            this.CheckBoxAxisMotionDone = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBoxGpVHEnd = new System.Windows.Forms.CheckBox();
            this.checkBoxGpVHStart = new System.Windows.Forms.CheckBox();
            this.checkBoxGpMotionDone = new System.Windows.Forms.CheckBox();
            this.BtnAddAxis = new System.Windows.Forms.Button();
            this.comboBoxAddAxis = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.radioButtonRel = new System.Windows.Forms.RadioButton();
            this.radioButtonAbs = new System.Windows.Forms.RadioButton();
            this.buttonSet = new System.Windows.Forms.Button();
            this.buttonLine = new System.Windows.Forms.Button();
            this.buttonPTP = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btn_ResetError = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxVHEndCnt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxVHStartCnt = new System.Windows.Forms.TextBox();
            this.BtnAxReset = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxAxState = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxCmdPos = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxAxDoneCnt = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_GpResetError = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxGpVHEndCnt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxGpVHStartCnt = new System.Windows.Forms.TextBox();
            this.BtnGpReset = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxGpState = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxAxesInGp = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxGpDoneCnt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxGpID = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.group = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btn_GpStop = new System.Windows.Forms.Button();
            this.btn_AxStop = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.group.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(100, 19);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(152, 20);
            this.CmbAxes.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 12);
            this.label2.TabIndex = 29;
            this.label2.Text = "Selected Axis:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.CmbAxes);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(11, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(265, 129);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Axis Setting";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBoxVHEnd);
            this.groupBox3.Controls.Add(this.checkBoxVHStart);
            this.groupBox3.Controls.Add(this.CheckBoxAxisMotionDone);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(8, 46);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(240, 64);
            this.groupBox3.TabIndex = 32;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Event Type";
            // 
            // checkBoxVHEnd
            // 
            this.checkBoxVHEnd.AutoSize = true;
            this.checkBoxVHEnd.Location = new System.Drawing.Point(119, 45);
            this.checkBoxVHEnd.Name = "checkBoxVHEnd";
            this.checkBoxVHEnd.Size = new System.Drawing.Size(60, 16);
            this.checkBoxVHEnd.TabIndex = 37;
            this.checkBoxVHEnd.Text = "VH End";
            this.checkBoxVHEnd.UseVisualStyleBackColor = true;
            // 
            // checkBoxVHStart
            // 
            this.checkBoxVHStart.AutoSize = true;
            this.checkBoxVHStart.Location = new System.Drawing.Point(11, 46);
            this.checkBoxVHStart.Name = "checkBoxVHStart";
            this.checkBoxVHStart.Size = new System.Drawing.Size(72, 16);
            this.checkBoxVHStart.TabIndex = 36;
            this.checkBoxVHStart.Text = "VH Start";
            this.checkBoxVHStart.UseVisualStyleBackColor = true;
            // 
            // CheckBoxAxisMotionDone
            // 
            this.CheckBoxAxisMotionDone.AutoSize = true;
            this.CheckBoxAxisMotionDone.Location = new System.Drawing.Point(12, 20);
            this.CheckBoxAxisMotionDone.Name = "CheckBoxAxisMotionDone";
            this.CheckBoxAxisMotionDone.Size = new System.Drawing.Size(126, 16);
            this.CheckBoxAxisMotionDone.TabIndex = 32;
            this.CheckBoxAxisMotionDone.Text = "Motion Done Event";
            this.CheckBoxAxisMotionDone.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBoxGpVHEnd);
            this.groupBox2.Controls.Add(this.checkBoxGpVHStart);
            this.groupBox2.Controls.Add(this.checkBoxGpMotionDone);
            this.groupBox2.Controls.Add(this.BtnAddAxis);
            this.groupBox2.Controls.Add(this.comboBoxAddAxis);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(10, 154);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(265, 101);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Group Setting";
            // 
            // checkBoxGpVHEnd
            // 
            this.checkBoxGpVHEnd.AutoSize = true;
            this.checkBoxGpVHEnd.Location = new System.Drawing.Point(156, 74);
            this.checkBoxGpVHEnd.Name = "checkBoxGpVHEnd";
            this.checkBoxGpVHEnd.Size = new System.Drawing.Size(60, 16);
            this.checkBoxGpVHEnd.TabIndex = 39;
            this.checkBoxGpVHEnd.Text = "VH End";
            this.checkBoxGpVHEnd.UseVisualStyleBackColor = true;
            // 
            // checkBoxGpVHStart
            // 
            this.checkBoxGpVHStart.AutoSize = true;
            this.checkBoxGpVHStart.Location = new System.Drawing.Point(19, 77);
            this.checkBoxGpVHStart.Name = "checkBoxGpVHStart";
            this.checkBoxGpVHStart.Size = new System.Drawing.Size(72, 16);
            this.checkBoxGpVHStart.TabIndex = 38;
            this.checkBoxGpVHStart.Text = "VH Start";
            this.checkBoxGpVHStart.UseVisualStyleBackColor = true;
            // 
            // checkBoxGpMotionDone
            // 
            this.checkBoxGpMotionDone.AutoSize = true;
            this.checkBoxGpMotionDone.Location = new System.Drawing.Point(19, 52);
            this.checkBoxGpMotionDone.Name = "checkBoxGpMotionDone";
            this.checkBoxGpMotionDone.Size = new System.Drawing.Size(126, 16);
            this.checkBoxGpMotionDone.TabIndex = 36;
            this.checkBoxGpMotionDone.Text = "Motion Done Event";
            this.checkBoxGpMotionDone.UseVisualStyleBackColor = true;
            // 
            // BtnAddAxis
            // 
            this.BtnAddAxis.Location = new System.Drawing.Point(156, 16);
            this.BtnAddAxis.Name = "BtnAddAxis";
            this.BtnAddAxis.Size = new System.Drawing.Size(92, 28);
            this.BtnAddAxis.TabIndex = 32;
            this.BtnAddAxis.Text = "Add Axis";
            this.BtnAddAxis.UseVisualStyleBackColor = true;
            this.BtnAddAxis.Click += new System.EventHandler(this.BtnAddAxis_Click);
            // 
            // comboBoxAddAxis
            // 
            this.comboBoxAddAxis.FormattingEnabled = true;
            this.comboBoxAddAxis.Location = new System.Drawing.Point(8, 20);
            this.comboBoxAddAxis.Name = "comboBoxAddAxis";
            this.comboBoxAddAxis.Size = new System.Drawing.Size(138, 20);
            this.comboBoxAddAxis.TabIndex = 33;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox7);
            this.groupBox4.Controls.Add(this.buttonSet);
            this.groupBox4.Controls.Add(this.groupBox1);
            this.groupBox4.Controls.Add(this.groupBox2);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox4.Location = new System.Drawing.Point(16, 120);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(326, 326);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Setting";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.radioButtonRel);
            this.groupBox7.Controls.Add(this.radioButtonAbs);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox7.Location = new System.Drawing.Point(9, 263);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(264, 46);
            this.groupBox7.TabIndex = 34;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Movement Mode";
            // 
            // radioButtonRel
            // 
            this.radioButtonRel.AutoSize = true;
            this.radioButtonRel.Checked = true;
            this.radioButtonRel.Location = new System.Drawing.Point(10, 22);
            this.radioButtonRel.Name = "radioButtonRel";
            this.radioButtonRel.Size = new System.Drawing.Size(71, 16);
            this.radioButtonRel.TabIndex = 7;
            this.radioButtonRel.TabStop = true;
            this.radioButtonRel.Text = "Relative";
            this.radioButtonRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonAbs
            // 
            this.radioButtonAbs.AutoSize = true;
            this.radioButtonAbs.Location = new System.Drawing.Point(155, 22);
            this.radioButtonAbs.Name = "radioButtonAbs";
            this.radioButtonAbs.Size = new System.Drawing.Size(71, 16);
            this.radioButtonAbs.TabIndex = 6;
            this.radioButtonAbs.Text = "Absolute";
            this.radioButtonAbs.UseVisualStyleBackColor = true;
            // 
            // buttonSet
            // 
            this.buttonSet.Location = new System.Drawing.Point(283, 44);
            this.buttonSet.Name = "buttonSet";
            this.buttonSet.Size = new System.Drawing.Size(33, 270);
            this.buttonSet.TabIndex = 33;
            this.buttonSet.Text = "Set";
            this.buttonSet.UseVisualStyleBackColor = true;
            this.buttonSet.Click += new System.EventHandler(this.buttonSet_Click);
            // 
            // buttonLine
            // 
            this.buttonLine.Location = new System.Drawing.Point(20, 54);
            this.buttonLine.Name = "buttonLine";
            this.buttonLine.Size = new System.Drawing.Size(120, 28);
            this.buttonLine.TabIndex = 34;
            this.buttonLine.Text = "Line(10000,10000)";
            this.buttonLine.UseVisualStyleBackColor = true;
            this.buttonLine.Click += new System.EventHandler(this.buttonLine_Click);
            // 
            // buttonPTP
            // 
            this.buttonPTP.Location = new System.Drawing.Point(19, 20);
            this.buttonPTP.Name = "buttonPTP";
            this.buttonPTP.Size = new System.Drawing.Size(120, 28);
            this.buttonPTP.TabIndex = 33;
            this.buttonPTP.Text = "->10000";
            this.buttonPTP.UseVisualStyleBackColor = true;
            this.buttonPTP.Click += new System.EventHandler(this.buttonPTP_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btn_ResetError);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.textBoxVHEndCnt);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.textBoxVHStartCnt);
            this.groupBox5.Controls.Add(this.BtnAxReset);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.textBoxAxState);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.textBoxCmdPos);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.textBoxAxDoneCnt);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox5.Location = new System.Drawing.Point(360, 14);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(265, 200);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Axis Info";
            // 
            // btn_ResetError
            // 
            this.btn_ResetError.Location = new System.Drawing.Point(156, 159);
            this.btn_ResetError.Name = "btn_ResetError";
            this.btn_ResetError.Size = new System.Drawing.Size(85, 26);
            this.btn_ResetError.TabIndex = 55;
            this.btn_ResetError.Text = "Reset Error";
            this.btn_ResetError.UseVisualStyleBackColor = true;
            this.btn_ResetError.Click += new System.EventHandler(this.btn_ResetError_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(30, 108);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 12);
            this.label14.TabIndex = 54;
            this.label14.Text = "VHEndCnt:";
            // 
            // textBoxVHEndCnt
            // 
            this.textBoxVHEndCnt.Location = new System.Drawing.Point(90, 102);
            this.textBoxVHEndCnt.Name = "textBoxVHEndCnt";
            this.textBoxVHEndCnt.ReadOnly = true;
            this.textBoxVHEndCnt.Size = new System.Drawing.Size(159, 21);
            this.textBoxVHEndCnt.TabIndex = 53;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(18, 80);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 12);
            this.label15.TabIndex = 52;
            this.label15.Text = "VHStartCnt:";
            // 
            // textBoxVHStartCnt
            // 
            this.textBoxVHStartCnt.Location = new System.Drawing.Point(90, 75);
            this.textBoxVHStartCnt.Name = "textBoxVHStartCnt";
            this.textBoxVHStartCnt.ReadOnly = true;
            this.textBoxVHStartCnt.Size = new System.Drawing.Size(159, 21);
            this.textBoxVHStartCnt.TabIndex = 51;
            // 
            // BtnAxReset
            // 
            this.BtnAxReset.Location = new System.Drawing.Point(33, 159);
            this.BtnAxReset.Name = "BtnAxReset";
            this.BtnAxReset.Size = new System.Drawing.Size(85, 26);
            this.BtnAxReset.TabIndex = 37;
            this.BtnAxReset.Text = "Reset Count";
            this.BtnAxReset.UseVisualStyleBackColor = true;
            this.BtnAxReset.Click += new System.EventHandler(this.BtnAxReset_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 26;
            this.label7.Text = "CurSate:";
            // 
            // textBoxAxState
            // 
            this.textBoxAxState.Location = new System.Drawing.Point(90, 129);
            this.textBoxAxState.Name = "textBoxAxState";
            this.textBoxAxState.ReadOnly = true;
            this.textBoxAxState.Size = new System.Drawing.Size(159, 21);
            this.textBoxAxState.TabIndex = 25;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 12);
            this.label4.TabIndex = 22;
            this.label4.Text = "CmdPos:";
            // 
            // textBoxCmdPos
            // 
            this.textBoxCmdPos.Location = new System.Drawing.Point(90, 48);
            this.textBoxCmdPos.Name = "textBoxCmdPos";
            this.textBoxCmdPos.ReadOnly = true;
            this.textBoxCmdPos.Size = new System.Drawing.Size(159, 21);
            this.textBoxCmdPos.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 20;
            this.label3.Text = "DoneCnt:";
            // 
            // textBoxAxDoneCnt
            // 
            this.textBoxAxDoneCnt.Location = new System.Drawing.Point(90, 21);
            this.textBoxAxDoneCnt.Name = "textBoxAxDoneCnt";
            this.textBoxAxDoneCnt.ReadOnly = true;
            this.textBoxAxDoneCnt.Size = new System.Drawing.Size(159, 21);
            this.textBoxAxDoneCnt.TabIndex = 19;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btn_GpResetError);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.textBoxGpVHEndCnt);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.textBoxGpVHStartCnt);
            this.groupBox6.Controls.Add(this.BtnGpReset);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.textBoxGpState);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.textBoxAxesInGp);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.textBoxGpDoneCnt);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.textBoxGpID);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox6.Location = new System.Drawing.Point(360, 224);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(265, 210);
            this.groupBox6.TabIndex = 36;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Group Info";
            // 
            // btn_GpResetError
            // 
            this.btn_GpResetError.Location = new System.Drawing.Point(156, 178);
            this.btn_GpResetError.Name = "btn_GpResetError";
            this.btn_GpResetError.Size = new System.Drawing.Size(85, 26);
            this.btn_GpResetError.TabIndex = 51;
            this.btn_GpResetError.Text = "Reset Error";
            this.btn_GpResetError.UseVisualStyleBackColor = true;
            this.btn_GpResetError.Click += new System.EventHandler(this.btn_GpResetError_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 103);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 12);
            this.label13.TabIndex = 50;
            this.label13.Text = "VHEndCnt:";
            // 
            // textBoxGpVHEndCnt
            // 
            this.textBoxGpVHEndCnt.Location = new System.Drawing.Point(87, 97);
            this.textBoxGpVHEndCnt.Name = "textBoxGpVHEndCnt";
            this.textBoxGpVHEndCnt.ReadOnly = true;
            this.textBoxGpVHEndCnt.Size = new System.Drawing.Size(162, 21);
            this.textBoxGpVHEndCnt.TabIndex = 49;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 77);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 12);
            this.label12.TabIndex = 48;
            this.label12.Text = "VHStartCnt:";
            // 
            // textBoxGpVHStartCnt
            // 
            this.textBoxGpVHStartCnt.Location = new System.Drawing.Point(87, 70);
            this.textBoxGpVHStartCnt.Name = "textBoxGpVHStartCnt";
            this.textBoxGpVHStartCnt.ReadOnly = true;
            this.textBoxGpVHStartCnt.Size = new System.Drawing.Size(162, 21);
            this.textBoxGpVHStartCnt.TabIndex = 47;
            // 
            // BtnGpReset
            // 
            this.BtnGpReset.Location = new System.Drawing.Point(33, 177);
            this.BtnGpReset.Name = "BtnGpReset";
            this.BtnGpReset.Size = new System.Drawing.Size(85, 26);
            this.BtnGpReset.TabIndex = 46;
            this.BtnGpReset.Text = "Reset Count";
            this.BtnGpReset.UseVisualStyleBackColor = true;
            this.BtnGpReset.Click += new System.EventHandler(this.BtnGpReset_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 45;
            this.label8.Text = "CurSate:";
            // 
            // textBoxGpState
            // 
            this.textBoxGpState.Location = new System.Drawing.Point(87, 151);
            this.textBoxGpState.Name = "textBoxGpState";
            this.textBoxGpState.ReadOnly = true;
            this.textBoxGpState.Size = new System.Drawing.Size(162, 21);
            this.textBoxGpState.TabIndex = 44;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 130);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 12);
            this.label9.TabIndex = 43;
            this.label9.Text = "AxesInGp:";
            // 
            // textBoxAxesInGp
            // 
            this.textBoxAxesInGp.Location = new System.Drawing.Point(87, 124);
            this.textBoxAxesInGp.Name = "textBoxAxesInGp";
            this.textBoxAxesInGp.ReadOnly = true;
            this.textBoxAxesInGp.Size = new System.Drawing.Size(162, 21);
            this.textBoxAxesInGp.TabIndex = 42;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(28, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 41;
            this.label10.Text = "DoneCnt:";
            // 
            // textBoxGpDoneCnt
            // 
            this.textBoxGpDoneCnt.Location = new System.Drawing.Point(87, 43);
            this.textBoxGpDoneCnt.Name = "textBoxGpDoneCnt";
            this.textBoxGpDoneCnt.ReadOnly = true;
            this.textBoxGpDoneCnt.Size = new System.Drawing.Size(162, 21);
            this.textBoxGpDoneCnt.TabIndex = 40;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(28, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 39;
            this.label11.Text = "GroupID:";
            // 
            // textBoxGpID
            // 
            this.textBoxGpID.Location = new System.Drawing.Point(87, 16);
            this.textBoxGpID.Name = "textBoxGpID";
            this.textBoxGpID.ReadOnly = true;
            this.textBoxGpID.Size = new System.Drawing.Size(162, 21);
            this.textBoxGpID.TabIndex = 38;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // group
            // 
            this.group.Controls.Add(this.label1);
            this.group.Controls.Add(this.CmbAvailableDevice);
            this.group.Controls.Add(this.BtnOpenBoard);
            this.group.Controls.Add(this.BtnCloseBoard);
            this.group.Controls.Add(this.BtnLoadCfg);
            this.group.Controls.Add(this.BtnServo);
            this.group.Location = new System.Drawing.Point(17, 12);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(327, 104);
            this.group.TabIndex = 48;
            this.group.TabStop = false;
            this.group.Text = "Device Operate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Available device:";
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(125, 15);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(176, 20);
            this.CmbAvailableDevice.TabIndex = 2;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged_1);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(40, 42);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(98, 25);
            this.BtnOpenBoard.TabIndex = 3;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(191, 42);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(95, 25);
            this.BtnCloseBoard.TabIndex = 5;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(40, 73);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(99, 25);
            this.BtnLoadCfg.TabIndex = 4;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(191, 73);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(95, 25);
            this.BtnServo.TabIndex = 6;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label17);
            this.groupBox13.Controls.Add(this.label18);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(357, 445);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(267, 92);
            this.groupBox13.TabIndex = 56;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Axis Signal Status";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(133, 63);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 28;
            this.label17.Text = "-HEL:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(35, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 12);
            this.label18.TabIndex = 27;
            this.label18.Text = "+HEL:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(138, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 26;
            this.label19.Text = "ORG:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(42, 33);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 25;
            this.label20.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(169, 60);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(71, 62);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(169, 24);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(72, 28);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btn_GpStop);
            this.groupBox8.Controls.Add(this.btn_AxStop);
            this.groupBox8.Controls.Add(this.buttonLine);
            this.groupBox8.Controls.Add(this.buttonPTP);
            this.groupBox8.Location = new System.Drawing.Point(16, 450);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(326, 89);
            this.groupBox8.TabIndex = 35;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "groupBox8";
            // 
            // btn_GpStop
            // 
            this.btn_GpStop.Location = new System.Drawing.Point(183, 55);
            this.btn_GpStop.Name = "btn_GpStop";
            this.btn_GpStop.Size = new System.Drawing.Size(104, 27);
            this.btn_GpStop.TabIndex = 57;
            this.btn_GpStop.Text = "Group Stop";
            this.btn_GpStop.UseVisualStyleBackColor = true;
            this.btn_GpStop.Click += new System.EventHandler(this.btn_GpStop_Click);
            // 
            // btn_AxStop
            // 
            this.btn_AxStop.Location = new System.Drawing.Point(183, 19);
            this.btn_AxStop.Name = "btn_AxStop";
            this.btn_AxStop.Size = new System.Drawing.Size(104, 30);
            this.btn_AxStop.TabIndex = 35;
            this.btn_AxStop.Text = "Axis Stop";
            this.btn_AxStop.UseVisualStyleBackColor = true;
            this.btn_AxStop.Click += new System.EventHandler(this.btn_AxStop_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 559);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.group);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Event";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox CheckBoxAxisMotionDone;
        private System.Windows.Forms.ComboBox comboBoxAddAxis;
        private System.Windows.Forms.CheckBox checkBoxGpMotionDone;
        private System.Windows.Forms.Button BtnAddAxis;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button buttonSet;
        private System.Windows.Forms.Button buttonLine;
        private System.Windows.Forms.Button buttonPTP;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxAxState;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxCmdPos;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxAxDoneCnt;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button BtnAxReset;
        private System.Windows.Forms.Button BtnGpReset;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxGpState;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxAxesInGp;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxGpDoneCnt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxGpID;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[32];
        IntPtr m_GpHand = IntPtr.Zero;
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        uint AxCountInGp = 0;

        uint[]  AxEnableEvtArray = new uint[32];
        uint[] GpEnableEvt = new uint[32];

        uint[] m_AxCmpEvtCnt = new uint[32];
	    uint[]  m_AxDoneEvtCnt = new uint[32];
        uint[] m_AxVHStartCnt = new uint[32];
        uint[] m_AxVHEndCnt = new uint[32];
        uint[] m_AxLatchBufCnt = new uint[32];
	    uint m_GpDoneEvtCnt;
        uint m_GpVHStartCnt;
        uint m_GpVHEndCnt;

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox checkBoxVHEnd;
        private System.Windows.Forms.CheckBox checkBoxVHStart;
        private System.Windows.Forms.CheckBox checkBoxGpVHEnd;
        private System.Windows.Forms.CheckBox checkBoxGpVHStart;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxGpVHStartCnt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxGpVHEndCnt;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxVHEndCnt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxVHStartCnt;
        private System.Windows.Forms.GroupBox group;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton radioButtonRel;
        private System.Windows.Forms.RadioButton radioButtonAbs;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.Button btn_ResetError;
        private System.Windows.Forms.Button btn_GpResetError;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btn_GpStop;
        private System.Windows.Forms.Button btn_AxStop;
    }
}

