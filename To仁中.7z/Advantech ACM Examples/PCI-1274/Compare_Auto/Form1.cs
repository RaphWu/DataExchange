﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion; // Common Motion API
using System.Diagnostics;

namespace Compare_Auto
{
    public partial class Form1 : Form
    {
        #region Fields
        
        private DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        private UInt32 deviceNum = 0;
        private UInt32 deviceCount = new UInt32();
        private IntPtr m_DeviceHandle = IntPtr.Zero;
        private IntPtr[] m_Axishand = new IntPtr[32];
        private UInt32 m_ulAxisCount = new UInt32();
        private Boolean m_bInit = false;
        private Boolean m_bServoOn = false;
        
        #endregion

        public Form1()
        {
            InitializeComponent();
            VersionIsOk = getDevCfgDllDrvVer(); //Get Driver Version Number, this step is not necessary
        }

        Boolean VersionIsOk = false;

        private void Form1_Load(object sender, EventArgs e)
        {
            Int32 result;
            if (VersionIsOk == false)
            {
                return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite 
            result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (result != (int)ErrorCode.SUCCESS)
            {
                printError("GetAvailableDevs", (UInt32)result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (Byte i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                deviceNum = CurAvailableDevs[0].DeviceNum;
            }

            comboBoxLtcCh.SelectedIndex = 0; // Latch Channel 0
            comboBoxCmpCh.SelectedIndex = 0; // Compare Channel 0
            comboBoxLtcEnMode.SelectedIndex = 2; // Repeat
            comboBoxDOmode.SelectedIndex = 0; // Pulse
            comboBoxCmpEnMode.SelectedIndex = 3; // Auto
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Double curCmd = new Double();
            Double curPos = new Double();
            UInt16 axState = new UInt16();
            UInt32 result = new UInt32();
            if (m_bInit)
            {
                //Get current command position of the specified axis
                Motion.mAcm_AxGetCmdPosition(m_Axishand[comboBoxAx.SelectedIndex], ref curCmd);
                //Get current actual position of the specified axis
                Motion.mAcm_AxGetActualPosition(m_Axishand[comboBoxAx.SelectedIndex], ref curPos);
                textBoxAct.Text = Convert.ToString(curPos);
                textBoxCmd.Text = Convert.ToString(curCmd);
                //Get the Axis's current state
                result = Motion.mAcm_AxGetState(m_Axishand[comboBoxAx.SelectedIndex], ref axState);
                if (result == (uint)ErrorCode.SUCCESS)
                {
                    textBoxCurState.Text = ((AxisState)axState).ToString();
                }

                getCmpInfo();
                getLtcInfo();
                getLinkInfo();
            }
        }

        private void buttonResetCnt_Click(object sender, EventArgs e)
        {
            resetCnt();
        }

        private void resetCnt()
        {
            UInt32 result = new UInt32();
            if (m_bInit == true)
            {
                //Set command position for the specified axis
                result = Motion.mAcm_AxSetCmdPosition(m_Axishand[comboBoxAx.SelectedIndex], 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("AxSetCmdPosition", result);
                    return;
                }
                result = Motion.mAcm_AxSetActualPosition(m_Axishand[comboBoxAx.SelectedIndex], 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("AxSetActualPosition", result);
                    return;
                }
            }
        }

        private void BtnResetErr_Click(object sender, EventArgs e)
        {
            resetErr();
        }

        private void resetErr()
        {
            ////Reset the axis' state. If the axis is in ErrorStop state, the state will
            //be changed to Ready after calling this function.
            UInt32 result = Motion.mAcm_AxResetError(m_Axishand[comboBoxAx.SelectedIndex]);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                printError("AxResetError", result);
                return;
            }
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            UInt32 result = new UInt32();
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            result = Motion.mAcm_DevOpen(deviceNum, ref m_DeviceHandle);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                printError("DevOpen", result);
                return;
            }
            //FT_DevAxesCount:Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref m_ulAxisCount);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                printError("GetU32Property", result);
                return;
            }
            comboBoxAx.Items.Clear();
            for (Byte ithAx = 0; ithAx < m_ulAxisCount; ithAx++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                //Open Axis 
                result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)ithAx, ref m_Axishand[ithAx]);
                if (result != (uint)ErrorCode.SUCCESS)
                {
                    printError("AxOpen", result);
                    return;
                }
                comboBoxAx.Items.Add(String.Format("{0:d}-Axis", ithAx));
                //Set command position for the specified axis
                Motion.mAcm_AxSetCmdPosition(m_Axishand[ithAx], 0);
                //Set actual position for the specified axis
                Motion.mAcm_AxSetActualPosition(m_Axishand[ithAx], 0);
            }
            comboBoxAx.SelectedIndex = 0;

            m_bInit = true;
            timer1.Enabled = true;
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {
            UInt32 result = new UInt32();
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (Byte ithAx = 0; ithAx < m_ulAxisCount; ithAx++)
                {
                    // Set servo Driver ON,1: On
                    result = Motion.mAcm_AxSetSvOn(m_Axishand[ithAx], 1);
                    if (result != (uint)ErrorCode.SUCCESS)
                    {
                        printError("AxSetSvOn", result);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (Byte ithAx = 0; ithAx < m_ulAxisCount; ithAx++)
                {
                    // Set servo Driver OFF,0: Off
                    result = Motion.mAcm_AxSetSvOn(m_Axishand[ithAx], 0);
                    if (result != (uint)ErrorCode.SUCCESS)
                    {
                        printError("AxSetSvOn", result);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }
        }

        //User-defined API to show error message
        private void printError(String APIname, UInt32 result)
        {
            StringBuilder errorMsg = new StringBuilder(null, 100);
            Boolean result2 = Motion.mAcm_GetErrorMessage(result, errorMsg, 100);
            if (result2)
            {
                MessageBox.Show("API " + APIname + " failed with error code:" + Environment.NewLine 
                    + "0x" + Convert.ToString(result, 16) + " (" + errorMsg.ToString(0, errorMsg.Length - 1) + ")."
                    , "Latch Links Compare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //User-defined API to close board
        private void CloseBoardOrForm()
        {
            UInt16[] usAxisState = new UInt16[32];
            //Stop Every Axes
            if (m_bInit == true)
            {
                for (Byte ithAx = 0; ithAx < m_ulAxisCount; ithAx++)
                {
                    //Get the axis's current state
                    Motion.mAcm_AxGetState(m_Axishand[ithAx], ref usAxisState[ithAx]);
                    if (usAxisState[ithAx] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will be changed to Ready after calling this function
                        Motion.mAcm_AxResetError(m_Axishand[ithAx]);
                    }
                    //To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[ithAx]);
                }

                // Reset
                resetAll();

                for (Byte ithAx = 0; ithAx < m_ulAxisCount; ithAx++)
                {
                    //Close Axes
                    Motion.mAcm_AxClose(ref m_Axishand[ithAx]);
                }
                m_ulAxisCount = 0;

                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                timer1.Enabled = false;
                m_bInit = false;
                comboBoxAx.Items.Clear();
                comboBoxAx.Text = null;
                textBoxCurState.Clear();
                textBoxCmd.Clear();
                textBoxAct.Clear();
                textBoxLtcCmdPos.Clear();
                textBoxLtcActualPos.Clear();
                textBoxFIFOcount.Clear();
                textBoxLinkStatus.Clear();
                
                pictureBoxLtcFlag.BackColor = Color.Gray;
                pictureBoxCmpFlag.BackColor = Color.Gray;
            }
        }

        private void buttonLoadCfg_Click(object sender, EventArgs e)
        {
            this.OpenConfigFile.FileName = ".cfg";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            UInt32 result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, OpenConfigFile.FileName);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                printError("DevLoadConfig", result);
                return;
            }
        }

        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            deviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseBoardOrForm();
        }

        private Boolean getDevCfgDllDrvVer()
        {
            String fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            FileVersionInfo myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            String FileVersion = myFileVersionInfo.FileVersion;
            String DetailMessage = String.Empty;
            String[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {

                DetailMessage = "The Driver Version Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "Compare", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void buttonSetLtc_Click(object sender, EventArgs e)
        {
            UInt16 ltcID = (UInt16)comboBoxLtcCh.SelectedIndex;
            UInt32 result = new UInt32();
            UInt16 tmp = new UInt16();

            result = Motion.mAcm_DevLTCSaftyDist(m_DeviceHandle, ltcID, Convert.ToDouble(textBoxSaftyDis.Text));
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevLTCSaftyDist", result);
                return;
            }

            tmp = Convert.ToUInt16(radioButtonLtcLogicHigh.Checked);
            result = Motion.mAcm_DevSetLTCInPol(m_DeviceHandle, ltcID, tmp);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevSetLTCInPol", result);
                return;
            }

            tmp = Convert.ToUInt16(radioButtonLtcEdgeOnToOff.Checked);
            result = Motion.mAcm_DevSetLTCInEdge(m_DeviceHandle, ltcID,tmp);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevSetLTCInEdge", result);
                return;
            }

            result = Motion.mAcm_DevEnableLTC(m_DeviceHandle, ltcID, (UInt16)comboBoxLtcEnMode.SelectedIndex);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevEnableLTC", result);
                return;
            }
        }


        private void getLtcInfo()
        {
            UInt16 ltcID = (UInt16)comboBoxLtcCh.SelectedIndex;
            Double commandPos = new Double();
            Double actualPos = new Double();
            Byte ltcFlag = new Byte();
            UInt32 result = new UInt32();

            result = Motion.mAcm_DevGetLTCData(m_DeviceHandle, ltcID, ref commandPos, ref actualPos);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevGetLTCData", result);
                return;
            }
            textBoxLtcCmdPos.Text = commandPos.ToString();
            textBoxLtcActualPos.Text = actualPos.ToString();

            result = Motion.mAcm_DevGetLTCFlag(m_DeviceHandle, ltcID, ref ltcFlag);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevGetLTCFlag", result);
                return;
            }

            if (Convert.ToBoolean(ltcFlag))
                pictureBoxLtcFlag.BackColor = Color.Red;
            else
                pictureBoxLtcFlag.BackColor = Color.Gray;
        }

        private void buttonResetSingleLtc_Click(object sender, EventArgs e)
        {
            UInt16 ltcID = (UInt16)comboBoxLtcCh.SelectedIndex;

            UInt32 result = Motion.mAcm_DevResetLTC(m_DeviceHandle, ltcID);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevResetLTC", result);
                return;
            };
        }

        private void buttonSetCmp_Click(object sender, EventArgs e)
        {
            UInt16 cmpID = (UInt16)comboBoxCmpCh.SelectedIndex;
            UInt32 result = new UInt32();

            // Enable/Disable Cmp.
            result = Motion.mAcm_DevEnableCmp(m_DeviceHandle, cmpID,
                (UInt16)comboBoxCmpEnMode.SelectedIndex);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevEnableCmp", result);
                return;
            }

            // Enable FIFO.
            result = Motion.mAcm_DevEnableCmpFIFO(m_DeviceHandle, cmpID
                , Convert.ToUInt16(radioButtonFIFOen.Checked));
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevEnableCmpFIFO", result);
                return;
            }

            // Enable/Disable DO.
            result = Motion.mAcm_DevSetCmpDO(m_DeviceHandle, cmpID, Convert.ToUInt16(radioButtonDOen.Checked));
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevSetCmpDO", result);
                return;
            }

            // Set CmpLogic, CmpSrc, CmpMethod, DOmode, and DOwidth.
            result = Motion.mAcm_DevSetCmp(m_DeviceHandle, cmpID,
                Convert.ToUInt32(radioButtonCmpLogic.Checked),
                Convert.ToUInt32(!radioButtonCmpSrc.Checked),
                Convert.ToUInt32(radioButtonCmpMethod.Checked),
                (UInt32)comboBoxDOmode.SelectedIndex,
                Convert.ToUInt32(textBoxDOwidth.Text));
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevSetCmp", result);
                return;
            }
        }

        private void buttonGetCompare_Click(object sender, EventArgs e)
        {
            getCmpInfo();
        }

        private void getCmpInfo()
        {
            UInt16 cmpID = (UInt16)comboBoxCmpCh.SelectedIndex;
            UInt16 FIFOcount = new UInt16();
            Byte cmpFlag = new Byte();
            Double cmpData = new Double();
            UInt32 result = new UInt32();

            // Get FIFO DataCount
            result = Motion.mAcm_DevGetCmpFIFOCount(m_DeviceHandle, cmpID, ref FIFOcount);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevGetCmpFIFOCount", result);
                return;
            }
            textBoxFIFOcount.Text = FIFOcount.ToString();

            // Get compare flag
            result = Motion.mAcm_DevGetCmpFlag(m_DeviceHandle, cmpID, ref cmpFlag);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevGetCmpFlag", result);
                return;
            }

            if (Convert.ToBoolean(cmpFlag))
                pictureBoxCmpFlag.BackColor = Color.Red;
            else
                pictureBoxCmpFlag.BackColor = Color.Gray;


            // Get current compare data
            result = Motion.mAcm_DevGetCmpData(m_DeviceHandle, cmpID, ref cmpData);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevGetCmpData", result);
                return;
            }
            textBoxCurrentCmpData.Text = cmpData.ToString();
        }

        private void buttonResetSingleCmp_Click(object sender, EventArgs e)
        {
            UInt16 cmpID = (UInt16)comboBoxCmpCh.SelectedIndex;
            resetSingleCmp(cmpID);
        }

        private void resetSingleCmp(UInt16 cmpID)
        {
            UInt32 result = new UInt32();
            
            // Reset FIFO data
            result = Motion.mAcm_DevResetCmpFIFO(m_DeviceHandle, cmpID);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevResetCmpFIFO", result);
                return;
            }

            // Reset current compare data
            result = Motion.mAcm_DevResetCmpData(m_DeviceHandle, cmpID);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevResetCmpData", result);
                return;
            }

            result = Motion.mAcm_DevResetCmpFlag(m_DeviceHandle, cmpID);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevResetCmpFlag", result);
                return;
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            if (m_bInit)
            {
                //To command axis to decelerate to stop.
                UInt32 result = Motion.mAcm_AxStopDec(m_Axishand[comboBoxAx.SelectedIndex]);
                if (result != (uint)ErrorCode.SUCCESS)
                {
                    printError("AxStopDec", result);
                    return;
                }
            }
        }

        private void buttonCMoveForward_Click(object sender, EventArgs e)
        {
            UInt32 result = Motion.mAcm_AxMoveVel(m_Axishand[comboBoxAx.SelectedIndex], 0);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                printError("AxMoveVel", result);
                return;
            }
        }

        private void buttonCMoveBackward_Click(object sender, EventArgs e)
        {
            UInt32 result = Motion.mAcm_AxMoveVel(m_Axishand[comboBoxAx.SelectedIndex], 1);
            if (result != (uint)ErrorCode.SUCCESS)
            {
                printError("AxMoveVel", result);
                return;
            }
        }

        private void buttonLtcLinkCmp_Click(object sender, EventArgs e)
        {
            UInt16 ltcID = (UInt16)comboBoxLtcCh.SelectedIndex;
            UInt16 cmpID = (UInt16)comboBoxCmpCh.SelectedIndex;
            UInt32 result = Motion.mAcm_DevLtcLinkCmp(m_DeviceHandle, m_Axishand[0]
                , Convert.ToUInt16(radioButtonLinkEn.Checked), ltcID, cmpID, 0);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevLtcLinkCmp", result);
                return;
            }
        }

        private void getLinkInfo()
        {
            UInt16 ltcID = (UInt16)comboBoxLtcCh.SelectedIndex;
            UInt16 linkStatus = new UInt16();
            UInt32 result = Motion.mAcm_DevGetLtcLinkCmpStatus(m_DeviceHandle, ltcID, ref linkStatus);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevGetLtcLinkCmpStatus", result);
                return;
            }

            textBoxLinkStatus.Text = Convert.ToString(linkStatus, 2);
        }

        private void resetAll()
        {
            UInt32 result = new UInt32();

            // Latch and link
            for (Byte ithLtc = 0; ithLtc < 12; ithLtc++)
            {
                result = Motion.mAcm_DevResetLTC(m_DeviceHandle, ithLtc);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevResetLTC", result);
                    return;
                }

                result = Motion.mAcm_DevLTCSaftyDist(m_DeviceHandle, ithLtc, 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevLTCSaftyDist", result);
                    return;
                }

                result = Motion.mAcm_DevSetLTCInPol(m_DeviceHandle, ithLtc, 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevSetLTCInPol", result);
                    return;
                }

                result = Motion.mAcm_DevSetLTCInEdge(m_DeviceHandle, ithLtc, 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevSetLTCInEdge", result);
                    return;
                }

                result = Motion.mAcm_DevEnableLTC(m_DeviceHandle, ithLtc, 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevEnableLTC", result);
                    return;
                }

                for (Byte ithCmp = 0; ithCmp < 12; ithCmp++)
                {
                    result = Motion.mAcm_DevLtcLinkCmp(m_DeviceHandle, m_Axishand[0], 0, ithLtc, ithCmp, 0);
                    if (result != (UInt32)ErrorCode.SUCCESS)
                    {
                        printError("DevLtcLinkCmp", result);
                        return;
                    }
                }
            }

            // Compare
            for (Byte ithCmp = 0; ithCmp < 12; ithCmp++)
            {
                resetSingleCmp(ithCmp);

                result = Motion.mAcm_DevEnableCmp(m_DeviceHandle, ithCmp, 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevEnableCmp", result);
                    return;
                }

                // Disable FIFO.
                result = Motion.mAcm_DevEnableCmpFIFO(m_DeviceHandle, ithCmp, 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevEnableCmpFIFO", result);
                    return;
                }

                // Disable DO.
                result = Motion.mAcm_DevSetCmpDO(m_DeviceHandle, ithCmp, 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevSetCmpDO", result);
                    return;
                }

                // Set CmpLogic, CmpSrc, CmpMethod, DOmode, and DOwidth.
                result = Motion.mAcm_DevSetCmp(m_DeviceHandle, ithCmp, 0, 0, 0, 0, 0);
                if (result != (UInt32)ErrorCode.SUCCESS)
                {
                    printError("DevSetCmp", result);
                    return;
                }
            }

            resetCnt();
            resetErr();
        }

        private void buttonResetAll_Click(object sender, EventArgs e)
        {
            if (m_bInit)
                resetAll();
        }

        private void buttonResetLink_Click_1(object sender, EventArgs e)
        {
            UInt16 ltcID = (UInt16)comboBoxLtcCh.SelectedIndex;
            UInt16 cmpID = (UInt16)comboBoxCmpCh.SelectedIndex;
            UInt32 result = Motion.mAcm_DevLtcLinkCmp(m_DeviceHandle, m_Axishand[0], 0, ltcID, cmpID, 0);
            if (result != (UInt32)ErrorCode.SUCCESS)
            {
                printError("DevLtcLinkCmp", result);
                return;
            }
        }

        private void buttonAutoSetCmpData_Click(object sender, EventArgs e)
        {
            UInt16 cmpID = (UInt16)comboBoxCmpCh.SelectedIndex;

            UInt32 result = Motion.mAcm_DevSetCmpAuto(m_DeviceHandle, cmpID,
                Convert.ToDouble(textBoxStart.Text),
                Convert.ToDouble(textBoxEnd.Text),
                Convert.ToDouble(textBoxInterval.Text));
            if (result != (uint)ErrorCode.SUCCESS)
            {
                printError("Compare_Auto", result);
                return;
            }
        }
    }
}
