﻿using Advantech.Motion;

namespace Latch_Link_Compare
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButtonFIFOen = new System.Windows.Forms.RadioButton();
            this.label33 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radioButtonCmpLogic = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButtonDOen = new System.Windows.Forms.RadioButton();
            this.label38 = new System.Windows.Forms.Label();
            this.comboBoxCmpEnMode = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButtonCmpMethod = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.comboBoxDOmode = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButtonCmpSrc = new System.Windows.Forms.RadioButton();
            this.label32 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.textBoxDOwidth = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.buttonSetCmp = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButtonLtcEdgeOffToOn = new System.Windows.Forms.RadioButton();
            this.radioButtonLtcEdgeOnToOff = new System.Windows.Forms.RadioButton();
            this.buttonSetLtc = new System.Windows.Forms.Button();
            this.radioButtonLtcLogicHigh = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxLinkStatus = new System.Windows.Forms.TextBox();
            this.comboBoxLtcCh = new System.Windows.Forms.ComboBox();
            this.radioButtonLtcLogicLow = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.buttonSetCnt = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxAct = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxCmd = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.textBoxCurState = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.comboBoxAx = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBoxLtcEnMode = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBoxSaftyDis = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.comboBoxCmpCh = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxCurrentCmpData = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBoxCmpFlag = new System.Windows.Forms.PictureBox();
            this.buttonResetCmp = new System.Windows.Forms.Button();
            this.textBoxFIFOcount = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonCMoveBackward = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.buttonCMoveForward = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.buttonLtcLinkCmp = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxOffset = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButtonLinkEn = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonResetAllLinks = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.buttonResetLink = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBoxLtcCmdPos = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBoxLtcActualPos = new System.Windows.Forms.TextBox();
            this.buttonResetLtc = new System.Windows.Forms.Button();
            this.pictureBoxLtcFlag = new System.Windows.Forms.PictureBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.radioButtonLtcSourceCmd = new System.Windows.Forms.RadioButton();
            this.radioButtonLtcSourceAct = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCmpFlag)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLtcFlag)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.panel5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label39, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label38, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.comboBoxCmpEnMode, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label37, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label29, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label34, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.comboBoxDOmode, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label32, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label36, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxDOwidth, 1, 6);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(18, 29);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(259, 240);
            this.tableLayoutPanel1.TabIndex = 47;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel5.AutoSize = true;
            this.panel5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel5.Controls.Add(this.radioButton4);
            this.panel5.Controls.Add(this.radioButtonFIFOen);
            this.panel5.Location = new System.Drawing.Point(86, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(148, 22);
            this.panel5.TabIndex = 66;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(88, 3);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(57, 16);
            this.radioButton4.TabIndex = 38;
            this.radioButton4.Text = "Disable";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButtonFIFOen
            // 
            this.radioButtonFIFOen.AutoSize = true;
            this.radioButtonFIFOen.Checked = true;
            this.radioButtonFIFOen.Location = new System.Drawing.Point(3, 3);
            this.radioButtonFIFOen.Name = "radioButtonFIFOen";
            this.radioButtonFIFOen.Size = new System.Drawing.Size(55, 16);
            this.radioButtonFIFOen.TabIndex = 37;
            this.radioButtonFIFOen.TabStop = true;
            this.radioButtonFIFOen.Text = "Enable";
            this.radioButtonFIFOen.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(13, 9);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(67, 12);
            this.label33.TabIndex = 65;
            this.label33.Text = "FIFO Enable:";
            // 
            // label39
            // 
            this.label39.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(19, 39);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(61, 12);
            this.label39.TabIndex = 61;
            this.label39.Text = "Cmp Logic:";
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel8.AutoSize = true;
            this.panel8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel8.Controls.Add(this.radioButtonCmpLogic);
            this.panel8.Controls.Add(this.radioButton2);
            this.panel8.Location = new System.Drawing.Point(86, 34);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(170, 22);
            this.panel8.TabIndex = 42;
            // 
            // radioButtonCmpLogic
            // 
            this.radioButtonCmpLogic.AutoSize = true;
            this.radioButtonCmpLogic.Location = new System.Drawing.Point(88, 3);
            this.radioButtonCmpLogic.Name = "radioButtonCmpLogic";
            this.radioButtonCmpLogic.Size = new System.Drawing.Size(79, 16);
            this.radioButtonCmpLogic.TabIndex = 38;
            this.radioButtonCmpLogic.Text = "Active High";
            this.radioButtonCmpLogic.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(3, 3);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(77, 16);
            this.radioButton2.TabIndex = 37;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Active Low";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel7.AutoSize = true;
            this.panel7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel7.Controls.Add(this.radioButton8);
            this.panel7.Controls.Add(this.radioButtonDOen);
            this.panel7.Location = new System.Drawing.Point(86, 214);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(95, 22);
            this.panel7.TabIndex = 46;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(53, 3);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(39, 16);
            this.radioButton8.TabIndex = 38;
            this.radioButton8.Text = "Off";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButtonDOen
            // 
            this.radioButtonDOen.AutoSize = true;
            this.radioButtonDOen.Checked = true;
            this.radioButtonDOen.Location = new System.Drawing.Point(3, 3);
            this.radioButtonDOen.Name = "radioButtonDOen";
            this.radioButtonDOen.Size = new System.Drawing.Size(37, 16);
            this.radioButtonDOen.TabIndex = 37;
            this.radioButtonDOen.TabStop = true;
            this.radioButtonDOen.Text = "On";
            this.radioButtonDOen.UseVisualStyleBackColor = true;
            // 
            // label38
            // 
            this.label38.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(40, 219);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(40, 12);
            this.label38.TabIndex = 45;
            this.label38.Text = "DO En:";
            // 
            // comboBoxCmpEnMode
            // 
            this.comboBoxCmpEnMode.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.comboBoxCmpEnMode.FormattingEnabled = true;
            this.comboBoxCmpEnMode.Items.AddRange(new object[] {
            "Disable",
            "Single Mode",
            "Repeat Mode"});
            this.comboBoxCmpEnMode.Location = new System.Drawing.Point(86, 125);
            this.comboBoxCmpEnMode.Name = "comboBoxCmpEnMode";
            this.comboBoxCmpEnMode.Size = new System.Drawing.Size(121, 20);
            this.comboBoxCmpEnMode.TabIndex = 42;
            // 
            // label37
            // 
            this.label37.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(3, 129);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 12);
            this.label37.TabIndex = 41;
            this.label37.Text = "Cmp En Mode:";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(24, 189);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(56, 12);
            this.label29.TabIndex = 43;
            this.label29.Text = "DO Width:";
            // 
            // label34
            // 
            this.label34.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(14, 69);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(66, 12);
            this.label34.TabIndex = 1;
            this.label34.Text = "Cmp Source:";
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel6.AutoSize = true;
            this.panel6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel6.Controls.Add(this.radioButtonCmpMethod);
            this.panel6.Controls.Add(this.radioButton7);
            this.panel6.Location = new System.Drawing.Point(86, 94);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(149, 22);
            this.panel6.TabIndex = 42;
            // 
            // radioButtonCmpMethod
            // 
            this.radioButtonCmpMethod.AutoSize = true;
            this.radioButtonCmpMethod.Location = new System.Drawing.Point(88, 3);
            this.radioButtonCmpMethod.Name = "radioButtonCmpMethod";
            this.radioButtonCmpMethod.Size = new System.Drawing.Size(58, 16);
            this.radioButtonCmpMethod.TabIndex = 38;
            this.radioButtonCmpMethod.Text = "Smaller";
            this.radioButtonCmpMethod.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Checked = true;
            this.radioButton7.Location = new System.Drawing.Point(3, 3);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(57, 16);
            this.radioButton7.TabIndex = 37;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Greater";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // comboBoxDOmode
            // 
            this.comboBoxDOmode.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.comboBoxDOmode.FormattingEnabled = true;
            this.comboBoxDOmode.Items.AddRange(new object[] {
            "Pulse",
            "Toggle",
            "Level"});
            this.comboBoxDOmode.Location = new System.Drawing.Point(86, 155);
            this.comboBoxDOmode.Name = "comboBoxDOmode";
            this.comboBoxDOmode.Size = new System.Drawing.Size(121, 20);
            this.comboBoxDOmode.TabIndex = 6;
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel4.AutoSize = true;
            this.panel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel4.Controls.Add(this.radioButton1);
            this.panel4.Controls.Add(this.radioButtonCmpSrc);
            this.panel4.Location = new System.Drawing.Point(86, 64);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(144, 22);
            this.panel4.TabIndex = 40;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(88, 3);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(53, 16);
            this.radioButton1.TabIndex = 38;
            this.radioButton1.Text = "Actual";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButtonCmpSrc
            // 
            this.radioButtonCmpSrc.AutoSize = true;
            this.radioButtonCmpSrc.Checked = true;
            this.radioButtonCmpSrc.Location = new System.Drawing.Point(3, 3);
            this.radioButtonCmpSrc.Name = "radioButtonCmpSrc";
            this.radioButtonCmpSrc.Size = new System.Drawing.Size(72, 16);
            this.radioButtonCmpSrc.TabIndex = 37;
            this.radioButtonCmpSrc.TabStop = true;
            this.radioButtonCmpSrc.Text = "Command";
            this.radioButtonCmpSrc.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(26, 159);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(54, 12);
            this.label32.TabIndex = 3;
            this.label32.Text = "DO Mode:";
            // 
            // label36
            // 
            this.label36.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(10, 99);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(70, 12);
            this.label36.TabIndex = 41;
            this.label36.Text = "Cmp Method:";
            // 
            // textBoxDOwidth
            // 
            this.textBoxDOwidth.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBoxDOwidth.Location = new System.Drawing.Point(86, 184);
            this.textBoxDOwidth.Name = "textBoxDOwidth";
            this.textBoxDOwidth.ReadOnly = true;
            this.textBoxDOwidth.Size = new System.Drawing.Size(100, 22);
            this.textBoxDOwidth.TabIndex = 64;
            this.textBoxDOwidth.Text = "5";
            // 
            // groupBox16
            // 
            this.groupBox16.AutoSize = true;
            this.groupBox16.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox16.Controls.Add(this.tableLayoutPanel1);
            this.groupBox16.Controls.Add(this.buttonSetCmp);
            this.groupBox16.Location = new System.Drawing.Point(22, 34);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Padding = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.groupBox16.Size = new System.Drawing.Size(283, 322);
            this.groupBox16.TabIndex = 51;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Set Compare";
            // 
            // buttonSetCmp
            // 
            this.buttonSetCmp.Location = new System.Drawing.Point(101, 284);
            this.buttonSetCmp.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.buttonSetCmp.Name = "buttonSetCmp";
            this.buttonSetCmp.Size = new System.Drawing.Size(93, 23);
            this.buttonSetCmp.TabIndex = 9;
            this.buttonSetCmp.Text = "Set Cmp";
            this.buttonSetCmp.UseVisualStyleBackColor = true;
            this.buttonSetCmp.Click += new System.EventHandler(this.buttonSetCmp_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(696, 32);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(93, 12);
            this.label28.TabIndex = 52;
            this.label28.Text = "Compare Channel:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(358, 31);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(76, 12);
            this.label26.TabIndex = 48;
            this.label26.Text = "Latch Channel:";
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel2.Controls.Add(this.radioButtonLtcEdgeOffToOn);
            this.panel2.Controls.Add(this.radioButtonLtcEdgeOnToOff);
            this.panel2.Location = new System.Drawing.Point(101, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(160, 22);
            this.panel2.TabIndex = 40;
            // 
            // radioButtonLtcEdgeOffToOn
            // 
            this.radioButtonLtcEdgeOffToOn.AutoSize = true;
            this.radioButtonLtcEdgeOffToOn.Checked = true;
            this.radioButtonLtcEdgeOffToOn.Location = new System.Drawing.Point(3, 3);
            this.radioButtonLtcEdgeOffToOn.Name = "radioButtonLtcEdgeOffToOn";
            this.radioButtonLtcEdgeOffToOn.Size = new System.Drawing.Size(69, 16);
            this.radioButtonLtcEdgeOffToOn.TabIndex = 38;
            this.radioButtonLtcEdgeOffToOn.TabStop = true;
            this.radioButtonLtcEdgeOffToOn.Text = "Off -> On";
            this.radioButtonLtcEdgeOffToOn.UseVisualStyleBackColor = true;
            // 
            // radioButtonLtcEdgeOnToOff
            // 
            this.radioButtonLtcEdgeOnToOff.AutoSize = true;
            this.radioButtonLtcEdgeOnToOff.Location = new System.Drawing.Point(88, 2);
            this.radioButtonLtcEdgeOnToOff.Name = "radioButtonLtcEdgeOnToOff";
            this.radioButtonLtcEdgeOnToOff.Size = new System.Drawing.Size(69, 16);
            this.radioButtonLtcEdgeOnToOff.TabIndex = 37;
            this.radioButtonLtcEdgeOnToOff.Text = "On -> Off";
            this.radioButtonLtcEdgeOnToOff.UseVisualStyleBackColor = true;
            // 
            // buttonSetLtc
            // 
            this.buttonSetLtc.Location = new System.Drawing.Point(100, 174);
            this.buttonSetLtc.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.buttonSetLtc.Name = "buttonSetLtc";
            this.buttonSetLtc.Size = new System.Drawing.Size(90, 23);
            this.buttonSetLtc.TabIndex = 9;
            this.buttonSetLtc.Text = "Set Ltc";
            this.buttonSetLtc.UseVisualStyleBackColor = true;
            this.buttonSetLtc.Click += new System.EventHandler(this.buttonSetLtc_Click);
            // 
            // radioButtonLtcLogicHigh
            // 
            this.radioButtonLtcLogicHigh.AutoSize = true;
            this.radioButtonLtcLogicHigh.Location = new System.Drawing.Point(88, 3);
            this.radioButtonLtcLogicHigh.Name = "radioButtonLtcLogicHigh";
            this.radioButtonLtcLogicHigh.Size = new System.Drawing.Size(79, 16);
            this.radioButtonLtcLogicHigh.TabIndex = 37;
            this.radioButtonLtcLogicHigh.Text = "Active High";
            this.radioButtonLtcLogicHigh.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 12);
            this.label6.TabIndex = 55;
            this.label6.Text = "Linked Cmp:";
            // 
            // textBoxLinkStatus
            // 
            this.textBoxLinkStatus.Location = new System.Drawing.Point(94, 28);
            this.textBoxLinkStatus.Name = "textBoxLinkStatus";
            this.textBoxLinkStatus.ReadOnly = true;
            this.textBoxLinkStatus.Size = new System.Drawing.Size(110, 22);
            this.textBoxLinkStatus.TabIndex = 50;
            // 
            // comboBoxLtcCh
            // 
            this.comboBoxLtcCh.FormattingEnabled = true;
            this.comboBoxLtcCh.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11"});
            this.comboBoxLtcCh.Location = new System.Drawing.Point(441, 27);
            this.comboBoxLtcCh.Name = "comboBoxLtcCh";
            this.comboBoxLtcCh.Size = new System.Drawing.Size(71, 20);
            this.comboBoxLtcCh.TabIndex = 50;
            // 
            // radioButtonLtcLogicLow
            // 
            this.radioButtonLtcLogicLow.AutoSize = true;
            this.radioButtonLtcLogicLow.Checked = true;
            this.radioButtonLtcLogicLow.Location = new System.Drawing.Point(3, 3);
            this.radioButtonLtcLogicLow.Name = "radioButtonLtcLogicLow";
            this.radioButtonLtcLogicLow.Size = new System.Drawing.Size(77, 16);
            this.radioButtonLtcLogicLow.TabIndex = 38;
            this.radioButtonLtcLogicLow.TabStop = true;
            this.radioButtonLtcLogicLow.Text = "Active Low";
            this.radioButtonLtcLogicLow.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.AutoSize = true;
            this.groupBox6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox6.Controls.Add(this.buttonSetCnt);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.textBoxAct);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.textBoxCmd);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox6.Location = new System.Drawing.Point(10, 25);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 3, 10, 0);
            this.groupBox6.Size = new System.Drawing.Size(228, 129);
            this.groupBox6.TabIndex = 32;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Position";
            // 
            // buttonSetCnt
            // 
            this.buttonSetCnt.Location = new System.Drawing.Point(76, 88);
            this.buttonSetCnt.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.buttonSetCnt.Name = "buttonSetCnt";
            this.buttonSetCnt.Size = new System.Drawing.Size(105, 26);
            this.buttonSetCnt.TabIndex = 31;
            this.buttonSetCnt.Text = "Reset Counter";
            this.buttonSetCnt.UseVisualStyleBackColor = true;
            this.buttonSetCnt.Click += new System.EventHandler(this.buttonResetCnt_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(42, 60);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(24, 12);
            this.label17.TabIndex = 34;
            this.label17.Text = "Act:";
            // 
            // textBoxAct
            // 
            this.textBoxAct.Location = new System.Drawing.Point(74, 56);
            this.textBoxAct.Name = "textBoxAct";
            this.textBoxAct.ReadOnly = true;
            this.textBoxAct.Size = new System.Drawing.Size(141, 22);
            this.textBoxAct.TabIndex = 33;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(42, 31);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 12);
            this.label14.TabIndex = 31;
            this.label14.Text = "Cmd:";
            // 
            // textBoxCmd
            // 
            this.textBoxCmd.Location = new System.Drawing.Point(74, 25);
            this.textBoxCmd.Name = "textBoxCmd";
            this.textBoxCmd.ReadOnly = true;
            this.textBoxCmd.Size = new System.Drawing.Size(141, 22);
            this.textBoxCmd.TabIndex = 30;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 12);
            this.label8.TabIndex = 33;
            this.label8.Text = "Status:";
            // 
            // groupBox5
            // 
            this.groupBox5.AutoSize = true;
            this.groupBox5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.BtnResetErr);
            this.groupBox5.Controls.Add(this.textBoxCurState);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox5.Location = new System.Drawing.Point(10, 169);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 3, 10, 0);
            this.groupBox5.Size = new System.Drawing.Size(228, 98);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Current State";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(76, 57);
            this.BtnResetErr.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(105, 26);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // textBoxCurState
            // 
            this.textBoxCurState.Location = new System.Drawing.Point(74, 25);
            this.textBoxCurState.Name = "textBoxCurState";
            this.textBoxCurState.ReadOnly = true;
            this.textBoxCurState.Size = new System.Drawing.Size(141, 22);
            this.textBoxCurState.TabIndex = 30;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // comboBoxAx
            // 
            this.comboBoxAx.FormattingEnabled = true;
            this.comboBoxAx.Location = new System.Drawing.Point(60, 34);
            this.comboBoxAx.Name = "comboBoxAx";
            this.comboBoxAx.Size = new System.Drawing.Size(135, 20);
            this.comboBoxAx.TabIndex = 15;
            // 
            // groupBox3
            // 
            this.groupBox3.AutoSize = true;
            this.groupBox3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox3.Location = new System.Drawing.Point(32, 318);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(10, 10, 10, 0);
            this.groupBox3.Size = new System.Drawing.Size(251, 285);
            this.groupBox3.TabIndex = 45;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Move Info";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(22, 37);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 30;
            this.label18.Text = "Axis:";
            // 
            // comboBoxLtcEnMode
            // 
            this.comboBoxLtcEnMode.FormattingEnabled = true;
            this.comboBoxLtcEnMode.Items.AddRange(new object[] {
            "Disable",
            "Single Mode",
            "Repeat Mode"});
            this.comboBoxLtcEnMode.Location = new System.Drawing.Point(100, 145);
            this.comboBoxLtcEnMode.Name = "comboBoxLtcEnMode";
            this.comboBoxLtcEnMode.Size = new System.Drawing.Size(121, 20);
            this.comboBoxLtcEnMode.TabIndex = 6;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(209, 34);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(25, 12);
            this.label25.TabIndex = 5;
            this.label25.Text = "PPU";
            // 
            // textBoxSaftyDis
            // 
            this.textBoxSaftyDis.Location = new System.Drawing.Point(101, 30);
            this.textBoxSaftyDis.Name = "textBoxSaftyDis";
            this.textBoxSaftyDis.Size = new System.Drawing.Size(100, 22);
            this.textBoxSaftyDis.TabIndex = 4;
            this.textBoxSaftyDis.Text = "100";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(23, 149);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(69, 12);
            this.label24.TabIndex = 3;
            this.label24.Text = "Ltc En Mode:";
            // 
            // groupBox14
            // 
            this.groupBox14.AutoSize = true;
            this.groupBox14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox14.Controls.Add(this.panel3);
            this.groupBox14.Controls.Add(this.label7);
            this.groupBox14.Controls.Add(this.panel2);
            this.groupBox14.Controls.Add(this.panel1);
            this.groupBox14.Controls.Add(this.buttonSetLtc);
            this.groupBox14.Controls.Add(this.comboBoxLtcEnMode);
            this.groupBox14.Controls.Add(this.label25);
            this.groupBox14.Controls.Add(this.textBoxSaftyDis);
            this.groupBox14.Controls.Add(this.label24);
            this.groupBox14.Controls.Add(this.label23);
            this.groupBox14.Controls.Add(this.label22);
            this.groupBox14.Controls.Add(this.label2);
            this.groupBox14.Location = new System.Drawing.Point(19, 28);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.groupBox14.Size = new System.Drawing.Size(277, 212);
            this.groupBox14.TabIndex = 47;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Set Latch";
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.Controls.Add(this.radioButtonLtcLogicLow);
            this.panel1.Controls.Add(this.radioButtonLtcLogicHigh);
            this.panel1.Location = new System.Drawing.Point(101, 58);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(170, 22);
            this.panel1.TabIndex = 39;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(40, 63);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 2;
            this.label23.Text = "Ltc Logic:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(40, 94);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(50, 12);
            this.label22.TabIndex = 1;
            this.label22.Text = "Ltc Edge:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "Safety Dis:";
            // 
            // buttonLoadCfg
            // 
            this.buttonLoadCfg.Location = new System.Drawing.Point(46, 99);
            this.buttonLoadCfg.Name = "buttonLoadCfg";
            this.buttonLoadCfg.Size = new System.Drawing.Size(92, 25);
            this.buttonLoadCfg.TabIndex = 31;
            this.buttonLoadCfg.Text = "Load Config";
            this.buttonLoadCfg.UseVisualStyleBackColor = true;
            this.buttonLoadCfg.Click += new System.EventHandler(this.buttonLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(163, 99);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(92, 25);
            this.BtnServo.TabIndex = 17;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.AutoSize = true;
            this.groupBox10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox10.Controls.Add(this.buttonLoadCfg);
            this.groupBox10.Controls.Add(this.BtnServo);
            this.groupBox10.Controls.Add(this.BtnCloseBoard);
            this.groupBox10.Controls.Add(this.BtnOpenBoard);
            this.groupBox10.Controls.Add(this.CmbAvailableDevice);
            this.groupBox10.Controls.Add(this.label1);
            this.groupBox10.Location = new System.Drawing.Point(29, 25);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(279, 145);
            this.groupBox10.TabIndex = 46;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Device Operation";
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(164, 66);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(92, 25);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(46, 65);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(92, 25);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(125, 29);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(148, 20);
            this.CmbAvailableDevice.TabIndex = 14;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "Available device:";
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openFileDialog1";
            // 
            // comboBoxCmpCh
            // 
            this.comboBoxCmpCh.FormattingEnabled = true;
            this.comboBoxCmpCh.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11"});
            this.comboBoxCmpCh.Location = new System.Drawing.Point(799, 29);
            this.comboBoxCmpCh.Name = "comboBoxCmpCh";
            this.comboBoxCmpCh.Size = new System.Drawing.Size(71, 20);
            this.comboBoxCmpCh.TabIndex = 53;
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.Controls.Add(this.textBoxCurrentCmpData);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.pictureBoxCmpFlag);
            this.groupBox1.Controls.Add(this.buttonResetCmp);
            this.groupBox1.Controls.Add(this.textBoxFIFOcount);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(22, 375);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(224, 166);
            this.groupBox1.TabIndex = 50;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Compare Info";
            // 
            // textBoxCurrentCmpData
            // 
            this.textBoxCurrentCmpData.Location = new System.Drawing.Point(117, 31);
            this.textBoxCurrentCmpData.Name = "textBoxCurrentCmpData";
            this.textBoxCurrentCmpData.ReadOnly = true;
            this.textBoxCurrentCmpData.Size = new System.Drawing.Size(100, 22);
            this.textBoxCurrentCmpData.TabIndex = 57;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 12);
            this.label3.TabIndex = 56;
            this.label3.Text = "Current Cmp Data:";
            // 
            // pictureBoxCmpFlag
            // 
            this.pictureBoxCmpFlag.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxCmpFlag.Location = new System.Drawing.Point(118, 91);
            this.pictureBoxCmpFlag.Name = "pictureBoxCmpFlag";
            this.pictureBoxCmpFlag.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxCmpFlag.TabIndex = 55;
            this.pictureBoxCmpFlag.TabStop = false;
            // 
            // buttonResetCmp
            // 
            this.buttonResetCmp.Location = new System.Drawing.Point(117, 122);
            this.buttonResetCmp.Name = "buttonResetCmp";
            this.buttonResetCmp.Size = new System.Drawing.Size(100, 23);
            this.buttonResetCmp.TabIndex = 43;
            this.buttonResetCmp.Text = "Reset Cmp";
            this.buttonResetCmp.UseVisualStyleBackColor = true;
            this.buttonResetCmp.Click += new System.EventHandler(this.buttonResetFIFO_Click);
            // 
            // textBoxFIFOcount
            // 
            this.textBoxFIFOcount.Location = new System.Drawing.Point(118, 60);
            this.textBoxFIFOcount.Name = "textBoxFIFOcount";
            this.textBoxFIFOcount.ReadOnly = true;
            this.textBoxFIFOcount.Size = new System.Drawing.Size(100, 22);
            this.textBoxFIFOcount.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "Cmp Flag:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(47, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "FIFO Count:";
            // 
            // groupBox2
            // 
            this.groupBox2.AutoSize = true;
            this.groupBox2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.buttonCMoveBackward);
            this.groupBox2.Controls.Add(this.comboBoxAx);
            this.groupBox2.Controls.Add(this.buttonStop);
            this.groupBox2.Controls.Add(this.buttonCMoveForward);
            this.groupBox2.Location = new System.Drawing.Point(32, 187);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(275, 112);
            this.groupBox2.TabIndex = 45;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Continuous Moverment";
            // 
            // buttonCMoveBackward
            // 
            this.buttonCMoveBackward.Location = new System.Drawing.Point(9, 66);
            this.buttonCMoveBackward.Name = "buttonCMoveBackward";
            this.buttonCMoveBackward.Size = new System.Drawing.Size(79, 25);
            this.buttonCMoveBackward.TabIndex = 31;
            this.buttonCMoveBackward.Text = "<--";
            this.buttonCMoveBackward.UseVisualStyleBackColor = true;
            this.buttonCMoveBackward.Click += new System.EventHandler(this.buttonCMoveBackward_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(100, 66);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(79, 25);
            this.buttonStop.TabIndex = 14;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // buttonCMoveForward
            // 
            this.buttonCMoveForward.Location = new System.Drawing.Point(190, 66);
            this.buttonCMoveForward.Name = "buttonCMoveForward";
            this.buttonCMoveForward.Size = new System.Drawing.Size(79, 25);
            this.buttonCMoveForward.TabIndex = 28;
            this.buttonCMoveForward.Text = "-->";
            this.buttonCMoveForward.UseVisualStyleBackColor = true;
            this.buttonCMoveForward.Click += new System.EventHandler(this.buttonCMoveForward_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.AutoSize = true;
            this.groupBox4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox4.Controls.Add(this.groupBox15);
            this.groupBox4.Controls.Add(this.groupBox14);
            this.groupBox4.Location = new System.Drawing.Point(360, 85);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(10, 10, 10, 0);
            this.groupBox4.Size = new System.Drawing.Size(311, 428);
            this.groupBox4.TabIndex = 60;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Latch";
            // 
            // groupBox8
            // 
            this.groupBox8.AutoSize = true;
            this.groupBox8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox8.Controls.Add(this.groupBox1);
            this.groupBox8.Controls.Add(this.groupBox16);
            this.groupBox8.Location = new System.Drawing.Point(698, 85);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(10, 10, 10, 0);
            this.groupBox8.Size = new System.Drawing.Size(318, 561);
            this.groupBox8.TabIndex = 62;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Compare";
            // 
            // groupBox9
            // 
            this.groupBox9.AutoSize = true;
            this.groupBox9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox9.Controls.Add(this.buttonLtcLinkCmp);
            this.groupBox9.Controls.Add(this.tableLayoutPanel2);
            this.groupBox9.Location = new System.Drawing.Point(23, 31);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 3, 10, 0);
            this.groupBox9.Size = new System.Drawing.Size(234, 136);
            this.groupBox9.TabIndex = 63;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Set Link";
            // 
            // buttonLtcLinkCmp
            // 
            this.buttonLtcLinkCmp.Location = new System.Drawing.Point(93, 98);
            this.buttonLtcLinkCmp.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.buttonLtcLinkCmp.Name = "buttonLtcLinkCmp";
            this.buttonLtcLinkCmp.Size = new System.Drawing.Size(93, 23);
            this.buttonLtcLinkCmp.TabIndex = 65;
            this.buttonLtcLinkCmp.Text = "Set Link";
            this.buttonLtcLinkCmp.UseVisualStyleBackColor = true;
            this.buttonLtcLinkCmp.Click += new System.EventHandler(this.buttonLtcLinkCmp_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.textBoxOffset, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel10, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(20, 28);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(201, 60);
            this.tableLayoutPanel2.TabIndex = 64;
            // 
            // textBoxOffset
            // 
            this.textBoxOffset.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBoxOffset.Location = new System.Drawing.Point(74, 34);
            this.textBoxOffset.Name = "textBoxOffset";
            this.textBoxOffset.Size = new System.Drawing.Size(110, 22);
            this.textBoxOffset.TabIndex = 68;
            this.textBoxOffset.Text = "10000";
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel10.AutoSize = true;
            this.panel10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel10.Controls.Add(this.radioButton10);
            this.panel10.Controls.Add(this.radioButtonLinkEn);
            this.panel10.Location = new System.Drawing.Point(74, 4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(124, 22);
            this.panel10.TabIndex = 39;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(64, 3);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(57, 16);
            this.radioButton10.TabIndex = 38;
            this.radioButton10.Text = "Disable";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButtonLinkEn
            // 
            this.radioButtonLinkEn.AutoSize = true;
            this.radioButtonLinkEn.Checked = true;
            this.radioButtonLinkEn.Location = new System.Drawing.Point(3, 3);
            this.radioButtonLinkEn.Name = "radioButtonLinkEn";
            this.radioButtonLinkEn.Size = new System.Drawing.Size(55, 16);
            this.radioButtonLinkEn.TabIndex = 37;
            this.radioButtonLinkEn.TabStop = true;
            this.radioButtonLinkEn.Text = "Enable";
            this.radioButtonLinkEn.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 12);
            this.label12.TabIndex = 2;
            this.label12.Text = "Link Enable:";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 39);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(36, 12);
            this.label13.TabIndex = 43;
            this.label13.Text = "Offset:";
            // 
            // buttonResetAllLinks
            // 
            this.buttonResetAllLinks.Location = new System.Drawing.Point(117, 305);
            this.buttonResetAllLinks.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.buttonResetAllLinks.Name = "buttonResetAllLinks";
            this.buttonResetAllLinks.Size = new System.Drawing.Size(110, 23);
            this.buttonResetAllLinks.TabIndex = 67;
            this.buttonResetAllLinks.Text = "Reset All Links";
            this.buttonResetAllLinks.UseVisualStyleBackColor = true;
            this.buttonResetAllLinks.Click += new System.EventHandler(this.buttonResetLink_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.AutoSize = true;
            this.groupBox7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox7.Controls.Add(this.buttonResetLink);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.textBoxLinkStatus);
            this.groupBox7.Location = new System.Drawing.Point(23, 188);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 3, 10, 0);
            this.groupBox7.Size = new System.Drawing.Size(217, 99);
            this.groupBox7.TabIndex = 64;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Link Info";
            // 
            // buttonResetLink
            // 
            this.buttonResetLink.Location = new System.Drawing.Point(94, 61);
            this.buttonResetLink.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.buttonResetLink.Name = "buttonResetLink";
            this.buttonResetLink.Size = new System.Drawing.Size(110, 23);
            this.buttonResetLink.TabIndex = 68;
            this.buttonResetLink.Text = "Reset Link";
            this.buttonResetLink.UseVisualStyleBackColor = true;
            this.buttonResetLink.Click += new System.EventHandler(this.buttonResetLink_Click_1);
            // 
            // groupBox11
            // 
            this.groupBox11.AutoSize = true;
            this.groupBox11.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox11.Controls.Add(this.buttonResetAllLinks);
            this.groupBox11.Controls.Add(this.groupBox7);
            this.groupBox11.Controls.Add(this.groupBox9);
            this.groupBox11.Location = new System.Drawing.Point(1044, 85);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(3, 3, 10, 0);
            this.groupBox11.Size = new System.Drawing.Size(270, 343);
            this.groupBox11.TabIndex = 65;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Link";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(37, 32);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(50, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "Cmd Pos:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(41, 90);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(46, 12);
            this.label30.TabIndex = 1;
            this.label30.Text = "Ltc Flag:";
            // 
            // textBoxLtcCmdPos
            // 
            this.textBoxLtcCmdPos.Location = new System.Drawing.Point(93, 28);
            this.textBoxLtcCmdPos.Name = "textBoxLtcCmdPos";
            this.textBoxLtcCmdPos.ReadOnly = true;
            this.textBoxLtcCmdPos.Size = new System.Drawing.Size(110, 22);
            this.textBoxLtcCmdPos.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(30, 62);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(57, 12);
            this.label27.TabIndex = 41;
            this.label27.Text = "Actual Pos:";
            // 
            // textBoxLtcActualPos
            // 
            this.textBoxLtcActualPos.Location = new System.Drawing.Point(93, 57);
            this.textBoxLtcActualPos.Name = "textBoxLtcActualPos";
            this.textBoxLtcActualPos.ReadOnly = true;
            this.textBoxLtcActualPos.Size = new System.Drawing.Size(110, 22);
            this.textBoxLtcActualPos.TabIndex = 42;
            // 
            // buttonResetLtc
            // 
            this.buttonResetLtc.Location = new System.Drawing.Point(91, 119);
            this.buttonResetLtc.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.buttonResetLtc.Name = "buttonResetLtc";
            this.buttonResetLtc.Size = new System.Drawing.Size(107, 23);
            this.buttonResetLtc.TabIndex = 43;
            this.buttonResetLtc.Text = "Reset Ltc";
            this.buttonResetLtc.UseVisualStyleBackColor = true;
            this.buttonResetLtc.Click += new System.EventHandler(this.buttonResetLtc_Click);
            // 
            // pictureBoxLtcFlag
            // 
            this.pictureBoxLtcFlag.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxLtcFlag.Location = new System.Drawing.Point(94, 87);
            this.pictureBoxLtcFlag.Name = "pictureBoxLtcFlag";
            this.pictureBoxLtcFlag.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxLtcFlag.TabIndex = 54;
            this.pictureBoxLtcFlag.TabStop = false;
            // 
            // groupBox15
            // 
            this.groupBox15.AutoSize = true;
            this.groupBox15.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox15.Controls.Add(this.pictureBoxLtcFlag);
            this.groupBox15.Controls.Add(this.buttonResetLtc);
            this.groupBox15.Controls.Add(this.textBoxLtcActualPos);
            this.groupBox15.Controls.Add(this.label27);
            this.groupBox15.Controls.Add(this.textBoxLtcCmdPos);
            this.groupBox15.Controls.Add(this.label30);
            this.groupBox15.Controls.Add(this.label31);
            this.groupBox15.Location = new System.Drawing.Point(19, 251);
            this.groupBox15.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Padding = new System.Windows.Forms.Padding(3, 3, 10, 0);
            this.groupBox15.Size = new System.Drawing.Size(216, 157);
            this.groupBox15.TabIndex = 49;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Latch Info";
            // 
            // panel3
            // 
            this.panel3.AutoSize = true;
            this.panel3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel3.Controls.Add(this.radioButtonLtcSourceCmd);
            this.panel3.Controls.Add(this.radioButtonLtcSourceAct);
            this.panel3.Location = new System.Drawing.Point(102, 116);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(144, 22);
            this.panel3.TabIndex = 42;
            // 
            // radioButtonLtcSourceCmd
            // 
            this.radioButtonLtcSourceCmd.AutoSize = true;
            this.radioButtonLtcSourceCmd.Checked = true;
            this.radioButtonLtcSourceCmd.Location = new System.Drawing.Point(3, 3);
            this.radioButtonLtcSourceCmd.Name = "radioButtonLtcSourceCmd";
            this.radioButtonLtcSourceCmd.Size = new System.Drawing.Size(72, 16);
            this.radioButtonLtcSourceCmd.TabIndex = 38;
            this.radioButtonLtcSourceCmd.TabStop = true;
            this.radioButtonLtcSourceCmd.Text = "Command";
            this.radioButtonLtcSourceCmd.UseVisualStyleBackColor = true;
            // 
            // radioButtonLtcSourceAct
            // 
            this.radioButtonLtcSourceAct.AutoSize = true;
            this.radioButtonLtcSourceAct.Location = new System.Drawing.Point(88, 2);
            this.radioButtonLtcSourceAct.Name = "radioButtonLtcSourceAct";
            this.radioButtonLtcSourceAct.Size = new System.Drawing.Size(53, 16);
            this.radioButtonLtcSourceAct.TabIndex = 37;
            this.radioButtonLtcSourceAct.Text = "Actual";
            this.radioButtonLtcSourceAct.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 122);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 12);
            this.label7.TabIndex = 41;
            this.label7.Text = "Ltc Source:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1447, 720);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.comboBoxCmpCh);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.comboBoxLtcCh);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox8);
            this.Name = "Form1";
            this.Text = "Latch_Link_Compare";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCmpFlag)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLtcFlag)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.RadioButton radioButtonCmpLogic;
        public System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.RadioButton radioButton8;
        public System.Windows.Forms.RadioButton radioButtonDOen;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox comboBoxCmpEnMode;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.RadioButton radioButtonCmpMethod;
        public System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.ComboBox comboBoxDOmode;
        private System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.RadioButton radioButton1;
        public System.Windows.Forms.RadioButton radioButtonCmpSrc;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button buttonSetCmp;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.RadioButton radioButtonLtcEdgeOffToOn;
        public System.Windows.Forms.RadioButton radioButtonLtcEdgeOnToOff;
        private System.Windows.Forms.Button buttonSetLtc;
        public System.Windows.Forms.RadioButton radioButtonLtcLogicHigh;
        private System.Windows.Forms.ComboBox comboBoxLtcCh;
        public System.Windows.Forms.RadioButton radioButtonLtcLogicLow;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button buttonSetCnt;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxAct;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxCmd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.TextBox textBoxCurState;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ComboBox comboBoxAx;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBoxLtcEnMode;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBoxSaftyDis;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.ComboBox comboBoxCmpCh;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonResetCmp;
        private System.Windows.Forms.TextBox textBoxFIFOcount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonCMoveBackward;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Button buttonCMoveForward;
        private System.Windows.Forms.PictureBox pictureBoxCmpFlag;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBoxCurrentCmpData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button buttonLtcLinkCmp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel10;
        public System.Windows.Forms.RadioButton radioButton10;
        public System.Windows.Forms.RadioButton radioButtonLinkEn;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonResetAllLinks;
        private System.Windows.Forms.TextBox textBoxDOwidth;
        private System.Windows.Forms.TextBox textBoxLinkStatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.RadioButton radioButton4;
        public System.Windows.Forms.RadioButton radioButtonFIFOen;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button buttonResetLink;
        private System.Windows.Forms.TextBox textBoxOffset;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.RadioButton radioButtonLtcSourceCmd;
        public System.Windows.Forms.RadioButton radioButtonLtcSourceAct;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.PictureBox pictureBoxLtcFlag;
        private System.Windows.Forms.Button buttonResetLtc;
        private System.Windows.Forms.TextBox textBoxLtcActualPos;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBoxLtcCmdPos;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;



    }
}

