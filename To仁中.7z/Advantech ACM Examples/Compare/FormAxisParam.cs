using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Compare
{
    public partial class FormAxisParam : Form
    {
        public FormAxisParam()
        {
            InitializeComponent();
        }

        private void FormAxisParam_Load(object sender, EventArgs e)
        {

        }
    }
}