﻿using Advantech.Motion;//Common Motion API
using System;
namespace Helix
{
    partial class Form1
    {         
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.rdo_Agl = new System.Windows.Forms.RadioButton();
            this.rdo_Cen = new System.Windows.Forms.RadioButton();
            this.rdo_Ref = new System.Windows.Forms.RadioButton();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.rdo_XZPlane = new System.Windows.Forms.RadioButton();
            this.rdo_YZPlane = new System.Windows.Forms.RadioButton();
            this.rdo_XYPlane = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rdo_CCW = new System.Windows.Forms.RadioButton();
            this.rdo_CW = new System.Windows.Forms.RadioButton();
            this.cbx_Axes = new System.Windows.Forms.CheckedListBox();
            this.label74 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rdo_Rel = new System.Windows.Forms.RadioButton();
            this.rdo_Abs = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txb_Agl1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txb_End8 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txb_End7 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txb_End6 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txb_End5 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txb_End4 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txb_End3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txb_End2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txb_End1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txb_Cen3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txb_Cen2 = new System.Windows.Forms.TextBox();
            this.txb_Cen1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.BtnMove = new System.Windows.Forms.Button();
            this.BtnStop = new System.Windows.Forms.Button();
            this.BtnResetCounter = new System.Windows.Forms.Button();
            this.textBoxGpState = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.label7 = new System.Windows.Forms.Label();
            this.dgv_Position = new System.Windows.Forms.DataGridView();
            this.Axis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CommandPosition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgv_AxisState = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label8 = new System.Windows.Forms.Label();
            this.group = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Position)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AxisState)).BeginInit();
            this.group.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox19);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.cbx_Axes);
            this.groupBox1.Controls.Add(this.label74);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.BtnMove);
            this.groupBox1.Controls.Add(this.BtnStop);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox1.Location = new System.Drawing.Point(13, 126);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(404, 410);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Helix Interpolation Operation";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.rdo_Agl);
            this.groupBox6.Controls.Add(this.rdo_Cen);
            this.groupBox6.Controls.Add(this.rdo_Ref);
            this.groupBox6.Location = new System.Drawing.Point(295, 21);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(88, 107);
            this.groupBox6.TabIndex = 67;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Helix Mode";
            // 
            // rdo_Agl
            // 
            this.rdo_Agl.AutoSize = true;
            this.rdo_Agl.Location = new System.Drawing.Point(11, 74);
            this.rdo_Agl.Name = "rdo_Agl";
            this.rdo_Agl.Size = new System.Drawing.Size(41, 16);
            this.rdo_Agl.TabIndex = 15;
            this.rdo_Agl.Text = "Agl";
            this.rdo_Agl.UseVisualStyleBackColor = true;
            // 
            // rdo_Cen
            // 
            this.rdo_Cen.AutoSize = true;
            this.rdo_Cen.Checked = true;
            this.rdo_Cen.Location = new System.Drawing.Point(11, 21);
            this.rdo_Cen.Name = "rdo_Cen";
            this.rdo_Cen.Size = new System.Drawing.Size(41, 16);
            this.rdo_Cen.TabIndex = 11;
            this.rdo_Cen.TabStop = true;
            this.rdo_Cen.Text = "Cen";
            this.rdo_Cen.UseVisualStyleBackColor = true;
            // 
            // rdo_Ref
            // 
            this.rdo_Ref.AutoSize = true;
            this.rdo_Ref.Location = new System.Drawing.Point(11, 48);
            this.rdo_Ref.Name = "rdo_Ref";
            this.rdo_Ref.Size = new System.Drawing.Size(41, 16);
            this.rdo_Ref.TabIndex = 12;
            this.rdo_Ref.Text = "Ref";
            this.rdo_Ref.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.rdo_XZPlane);
            this.groupBox19.Controls.Add(this.rdo_YZPlane);
            this.groupBox19.Controls.Add(this.rdo_XYPlane);
            this.groupBox19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox19.Location = new System.Drawing.Point(154, 23);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(119, 106);
            this.groupBox19.TabIndex = 66;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Reference Plane";
            // 
            // rdo_XZPlane
            // 
            this.rdo_XZPlane.AutoSize = true;
            this.rdo_XZPlane.Location = new System.Drawing.Point(11, 46);
            this.rdo_XZPlane.Name = "rdo_XZPlane";
            this.rdo_XZPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_XZPlane.TabIndex = 2;
            this.rdo_XZPlane.Text = "X_Z Plane";
            this.rdo_XZPlane.UseVisualStyleBackColor = true;
            // 
            // rdo_YZPlane
            // 
            this.rdo_YZPlane.AutoSize = true;
            this.rdo_YZPlane.Location = new System.Drawing.Point(11, 71);
            this.rdo_YZPlane.Name = "rdo_YZPlane";
            this.rdo_YZPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_YZPlane.TabIndex = 1;
            this.rdo_YZPlane.Text = "Y_Z Plane";
            this.rdo_YZPlane.UseVisualStyleBackColor = true;
            // 
            // rdo_XYPlane
            // 
            this.rdo_XYPlane.AutoSize = true;
            this.rdo_XYPlane.Checked = true;
            this.rdo_XYPlane.Location = new System.Drawing.Point(10, 20);
            this.rdo_XYPlane.Name = "rdo_XYPlane";
            this.rdo_XYPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_XYPlane.TabIndex = 0;
            this.rdo_XYPlane.TabStop = true;
            this.rdo_XYPlane.Text = "X_Y Plane";
            this.rdo_XYPlane.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rdo_CCW);
            this.groupBox5.Controls.Add(this.rdo_CW);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox5.Location = new System.Drawing.Point(10, 322);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(157, 44);
            this.groupBox5.TabIndex = 62;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Arc Direction";
            // 
            // rdo_CCW
            // 
            this.rdo_CCW.AutoSize = true;
            this.rdo_CCW.Location = new System.Drawing.Point(97, 22);
            this.rdo_CCW.Name = "rdo_CCW";
            this.rdo_CCW.Size = new System.Drawing.Size(41, 16);
            this.rdo_CCW.TabIndex = 9;
            this.rdo_CCW.Text = "CCW";
            this.rdo_CCW.UseVisualStyleBackColor = true;
            // 
            // rdo_CW
            // 
            this.rdo_CW.AutoSize = true;
            this.rdo_CW.Checked = true;
            this.rdo_CW.Location = new System.Drawing.Point(10, 18);
            this.rdo_CW.Name = "rdo_CW";
            this.rdo_CW.Size = new System.Drawing.Size(35, 16);
            this.rdo_CW.TabIndex = 8;
            this.rdo_CW.TabStop = true;
            this.rdo_CW.Text = "CW";
            this.rdo_CW.UseVisualStyleBackColor = true;
            // 
            // cbx_Axes
            // 
            this.cbx_Axes.CheckOnClick = true;
            this.cbx_Axes.FormattingEnabled = true;
            this.cbx_Axes.Location = new System.Drawing.Point(15, 31);
            this.cbx_Axes.Name = "cbx_Axes";
            this.cbx_Axes.Size = new System.Drawing.Size(123, 100);
            this.cbx_Axes.TabIndex = 65;
            this.cbx_Axes.SelectedIndexChanged += new System.EventHandler(this.cbx_Axes_SelectedIndexChanged);
            // 
            // label74
            // 
            this.label74.Location = new System.Drawing.Point(14, 16);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(147, 23);
            this.label74.TabIndex = 64;
            this.label74.Text = "Operation Axes:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.rdo_Rel);
            this.groupBox4.Controls.Add(this.rdo_Abs);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(189, 322);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(205, 44);
            this.groupBox4.TabIndex = 63;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Movement Mode";
            // 
            // rdo_Rel
            // 
            this.rdo_Rel.AutoSize = true;
            this.rdo_Rel.Checked = true;
            this.rdo_Rel.Location = new System.Drawing.Point(123, 21);
            this.rdo_Rel.Name = "rdo_Rel";
            this.rdo_Rel.Size = new System.Drawing.Size(71, 16);
            this.rdo_Rel.TabIndex = 7;
            this.rdo_Rel.TabStop = true;
            this.rdo_Rel.Text = "Relative";
            this.rdo_Rel.UseVisualStyleBackColor = true;
            // 
            // rdo_Abs
            // 
            this.rdo_Abs.AutoSize = true;
            this.rdo_Abs.Location = new System.Drawing.Point(11, 21);
            this.rdo_Abs.Name = "rdo_Abs";
            this.rdo_Abs.Size = new System.Drawing.Size(71, 16);
            this.rdo_Abs.TabIndex = 6;
            this.rdo_Abs.Text = "Absolute";
            this.rdo_Abs.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txb_Agl1);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.txb_End8);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txb_End7);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.txb_End6);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txb_End5);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txb_End4);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txb_End3);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txb_End2);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txb_End1);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(9, 188);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(386, 129);
            this.groupBox3.TabIndex = 61;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "End";
            // 
            // txb_Agl1
            // 
            this.txb_Agl1.Location = new System.Drawing.Point(48, 100);
            this.txb_Agl1.Name = "txb_Agl1";
            this.txb_Agl1.Size = new System.Drawing.Size(81, 21);
            this.txb_Agl1.TabIndex = 27;
            this.txb_Agl1.Text = "90";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 103);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 12);
            this.label16.TabIndex = 25;
            this.label16.Text = "Agl1:";
            // 
            // txb_End8
            // 
            this.txb_End8.Location = new System.Drawing.Point(175, 71);
            this.txb_End8.Name = "txb_End8";
            this.txb_End8.Size = new System.Drawing.Size(82, 21);
            this.txb_End8.TabIndex = 24;
            this.txb_End8.Text = "1000";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(151, 76);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(23, 12);
            this.label15.TabIndex = 23;
            this.label15.Text = "E8:";
            // 
            // txb_End7
            // 
            this.txb_End7.Location = new System.Drawing.Point(49, 73);
            this.txb_End7.Name = "txb_End7";
            this.txb_End7.Size = new System.Drawing.Size(80, 21);
            this.txb_End7.TabIndex = 22;
            this.txb_End7.Text = "1000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 78);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(23, 12);
            this.label12.TabIndex = 21;
            this.label12.Text = "E7:";
            // 
            // txb_End6
            // 
            this.txb_End6.Location = new System.Drawing.Point(298, 44);
            this.txb_End6.Name = "txb_End6";
            this.txb_End6.Size = new System.Drawing.Size(81, 21);
            this.txb_End6.TabIndex = 20;
            this.txb_End6.Text = "1000";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(275, 49);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 12);
            this.label11.TabIndex = 19;
            this.label11.Text = "E6:";
            // 
            // txb_End5
            // 
            this.txb_End5.Location = new System.Drawing.Point(176, 44);
            this.txb_End5.Name = "txb_End5";
            this.txb_End5.Size = new System.Drawing.Size(81, 21);
            this.txb_End5.TabIndex = 18;
            this.txb_End5.Text = "1000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(150, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 12);
            this.label10.TabIndex = 17;
            this.label10.Text = "E5:";
            // 
            // txb_End4
            // 
            this.txb_End4.Location = new System.Drawing.Point(48, 46);
            this.txb_End4.Name = "txb_End4";
            this.txb_End4.Size = new System.Drawing.Size(81, 21);
            this.txb_End4.TabIndex = 16;
            this.txb_End4.Text = "1000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 51);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 12);
            this.label9.TabIndex = 15;
            this.label9.Text = "E4:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(275, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "E3:";
            // 
            // txb_End3
            // 
            this.txb_End3.Location = new System.Drawing.Point(299, 17);
            this.txb_End3.Name = "txb_End3";
            this.txb_End3.Size = new System.Drawing.Size(80, 21);
            this.txb_End3.TabIndex = 13;
            this.txb_End3.Text = "1000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(151, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "E2:";
            // 
            // txb_End2
            // 
            this.txb_End2.Location = new System.Drawing.Point(175, 17);
            this.txb_End2.Name = "txb_End2";
            this.txb_End2.Size = new System.Drawing.Size(82, 21);
            this.txb_End2.TabIndex = 12;
            this.txb_End2.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "E1:";
            // 
            // txb_End1
            // 
            this.txb_End1.Location = new System.Drawing.Point(48, 19);
            this.txb_End1.Name = "txb_End1";
            this.txb_End1.Size = new System.Drawing.Size(81, 21);
            this.txb_End1.TabIndex = 11;
            this.txb_End1.Text = "16000";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txb_Cen3);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txb_Cen2);
            this.groupBox2.Controls.Add(this.txb_Cen1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(10, 134);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(385, 52);
            this.groupBox2.TabIndex = 60;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Center";
            // 
            // txb_Cen3
            // 
            this.txb_Cen3.Location = new System.Drawing.Point(299, 21);
            this.txb_Cen3.Name = "txb_Cen3";
            this.txb_Cen3.Size = new System.Drawing.Size(80, 21);
            this.txb_Cen3.TabIndex = 14;
            this.txb_Cen3.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(261, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 13;
            this.label3.Text = "C3/R3:";
            // 
            // txb_Cen2
            // 
            this.txb_Cen2.Location = new System.Drawing.Point(175, 20);
            this.txb_Cen2.Name = "txb_Cen2";
            this.txb_Cen2.Size = new System.Drawing.Size(80, 21);
            this.txb_Cen2.TabIndex = 10;
            this.txb_Cen2.Text = "0";
            // 
            // txb_Cen1
            // 
            this.txb_Cen1.Location = new System.Drawing.Point(48, 21);
            this.txb_Cen1.Name = "txb_Cen1";
            this.txb_Cen1.Size = new System.Drawing.Size(80, 21);
            this.txb_Cen1.TabIndex = 6;
            this.txb_Cen1.Text = "8000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(135, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "C2/R2:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 12);
            this.label14.TabIndex = 8;
            this.label14.Text = "C1/R1:";
            // 
            // BtnMove
            // 
            this.BtnMove.Location = new System.Drawing.Point(92, 376);
            this.BtnMove.Name = "BtnMove";
            this.BtnMove.Size = new System.Drawing.Size(88, 25);
            this.BtnMove.TabIndex = 8;
            this.BtnMove.Text = "Move";
            this.BtnMove.UseVisualStyleBackColor = true;
            this.BtnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // BtnStop
            // 
            this.BtnStop.Location = new System.Drawing.Point(237, 376);
            this.BtnStop.Name = "BtnStop";
            this.BtnStop.Size = new System.Drawing.Size(88, 25);
            this.BtnStop.TabIndex = 9;
            this.BtnStop.Text = "Stop";
            this.BtnStop.UseVisualStyleBackColor = true;
            this.BtnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // BtnResetCounter
            // 
            this.BtnResetCounter.Location = new System.Drawing.Point(555, 191);
            this.BtnResetCounter.Name = "BtnResetCounter";
            this.BtnResetCounter.Size = new System.Drawing.Size(105, 24);
            this.BtnResetCounter.TabIndex = 15;
            this.BtnResetCounter.Text = "Reset Counter";
            this.BtnResetCounter.UseVisualStyleBackColor = true;
            this.BtnResetCounter.Click += new System.EventHandler(this.BtnResetCounter_Click);
            // 
            // textBoxGpState
            // 
            this.textBoxGpState.Location = new System.Drawing.Point(525, 402);
            this.textBoxGpState.Name = "textBoxGpState";
            this.textBoxGpState.ReadOnly = true;
            this.textBoxGpState.Size = new System.Drawing.Size(143, 21);
            this.textBoxGpState.TabIndex = 17;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(441, 406);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 12);
            this.label13.TabIndex = 16;
            this.label13.Text = "Group State:";
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(555, 428);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(105, 24);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openConfigFileDialog";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(449, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 12);
            this.label7.TabIndex = 17;
            this.label7.Text = "Position:";
            // 
            // dgv_Position
            // 
            this.dgv_Position.AllowUserToAddRows = false;
            this.dgv_Position.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Position.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Position.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Position.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Axis,
            this.CommandPosition});
            this.dgv_Position.Location = new System.Drawing.Point(513, 15);
            this.dgv_Position.Name = "dgv_Position";
            this.dgv_Position.ReadOnly = true;
            this.dgv_Position.RowHeadersVisible = false;
            this.dgv_Position.RowHeadersWidth = 10;
            this.dgv_Position.RowTemplate.Height = 23;
            this.dgv_Position.Size = new System.Drawing.Size(186, 169);
            this.dgv_Position.TabIndex = 18;
            // 
            // Axis
            // 
            this.Axis.HeaderText = "Axis";
            this.Axis.Name = "Axis";
            this.Axis.ReadOnly = true;
            this.Axis.Width = 80;
            // 
            // CommandPosition
            // 
            this.CommandPosition.HeaderText = "Cmd Position";
            this.CommandPosition.Name = "CommandPosition";
            this.CommandPosition.ReadOnly = true;
            // 
            // dgv_AxisState
            // 
            this.dgv_AxisState.AllowUserToAddRows = false;
            this.dgv_AxisState.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_AxisState.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_AxisState.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_AxisState.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgv_AxisState.Location = new System.Drawing.Point(514, 223);
            this.dgv_AxisState.Name = "dgv_AxisState";
            this.dgv_AxisState.ReadOnly = true;
            this.dgv_AxisState.RowHeadersVisible = false;
            this.dgv_AxisState.RowHeadersWidth = 10;
            this.dgv_AxisState.RowTemplate.Height = 23;
            this.dgv_AxisState.Size = new System.Drawing.Size(185, 172);
            this.dgv_AxisState.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Axis";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "State";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(443, 228);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 12);
            this.label8.TabIndex = 20;
            this.label8.Text = "Axis State:";
            // 
            // group
            // 
            this.group.Controls.Add(this.label1);
            this.group.Controls.Add(this.CmbAvailableDevice);
            this.group.Controls.Add(this.BtnOpenBoard);
            this.group.Controls.Add(this.BtnCloseBoard);
            this.group.Controls.Add(this.BtnLoadCfg);
            this.group.Controls.Add(this.BtnServo);
            this.group.Location = new System.Drawing.Point(14, 13);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(403, 104);
            this.group.TabIndex = 48;
            this.group.TabStop = false;
            this.group.Text = "Device Operate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Available device:";
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(161, 18);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(157, 20);
            this.CmbAvailableDevice.TabIndex = 2;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged_1);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(76, 43);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnOpenBoard.TabIndex = 3;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(231, 43);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnCloseBoard.TabIndex = 5;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnLoadCfg
            // 
            this.BtnLoadCfg.Location = new System.Drawing.Point(76, 73);
            this.BtnLoadCfg.Name = "BtnLoadCfg";
            this.BtnLoadCfg.Size = new System.Drawing.Size(100, 25);
            this.BtnLoadCfg.TabIndex = 4;
            this.BtnLoadCfg.Text = "Load Config";
            this.BtnLoadCfg.UseVisualStyleBackColor = true;
            this.BtnLoadCfg.Click += new System.EventHandler(this.BtnLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(231, 74);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(100, 25);
            this.BtnServo.TabIndex = 6;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.CmbAxes);
            this.groupBox13.Controls.Add(this.label18);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.label20);
            this.groupBox13.Controls.Add(this.label21);
            this.groupBox13.Controls.Add(this.label22);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(432, 458);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(329, 80);
            this.groupBox13.TabIndex = 123;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Axis Signal Status";
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(127, 18);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(167, 20);
            this.CmbAxes.TabIndex = 32;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(29, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(95, 12);
            this.label18.TabIndex = 31;
            this.label18.Text = "Operation Axis:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(259, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 12);
            this.label19.TabIndex = 28;
            this.label19.Text = "-HEL:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(177, 56);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 12);
            this.label20.TabIndex = 27;
            this.label20.Text = "+HEL:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(93, 54);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 12);
            this.label21.TabIndex = 26;
            this.label21.Text = "ORG:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(16, 54);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 25;
            this.label22.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(300, 50);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(218, 50);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(128, 50);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(49, 50);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 558);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.group);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dgv_AxisState);
            this.Controls.Add(this.textBoxGpState);
            this.Controls.Add(this.dgv_Position);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.BtnResetErr);
            this.Controls.Add(this.BtnResetCounter);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Helix";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Position)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AxisState)).EndInit();
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnMove;
        private System.Windows.Forms.Button BtnStop;
        private System.Windows.Forms.Button BtnResetCounter;
        private System.Windows.Forms.TextBox textBoxGpState;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button BtnResetErr;

        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum=0;
        IntPtr m_DeviceHandle;
        IntPtr[] m_Axishand = new IntPtr[32];
        IntPtr m_GpHand = IntPtr.Zero;
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        uint AxCountInGp = 0;
        uint motionAxisCount = 0;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RadioButton rdo_XZPlane;
        private System.Windows.Forms.RadioButton rdo_YZPlane;
        private System.Windows.Forms.RadioButton rdo_XYPlane;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdo_CCW;
        private System.Windows.Forms.RadioButton rdo_CW;
        private System.Windows.Forms.CheckedListBox cbx_Axes;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdo_Rel;
        private System.Windows.Forms.RadioButton rdo_Abs;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txb_End3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txb_End2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txb_End1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txb_Cen3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rdo_Ref;
        private System.Windows.Forms.RadioButton rdo_Cen;
        private System.Windows.Forms.TextBox txb_Cen2;
        private System.Windows.Forms.TextBox txb_Cen1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgv_Position;
        private System.Windows.Forms.DataGridViewTextBoxColumn Axis;
        private System.Windows.Forms.DataGridViewTextBoxColumn CommandPosition;
        private System.Windows.Forms.DataGridView dgv_AxisState;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txb_End8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txb_End7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txb_End6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txb_End5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txb_End4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton rdo_Agl;
        private System.Windows.Forms.TextBox txb_Agl1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox group;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
    }
}

