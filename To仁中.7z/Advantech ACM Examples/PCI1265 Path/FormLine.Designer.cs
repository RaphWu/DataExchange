﻿namespace Path
{
    partial class FormLine
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.listBoxEndPoints = new System.Windows.Forms.ListBox();
            this.BtnClearEnd = new System.Windows.Forms.Button();
            this.BtnSetEnd = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxEnd = new System.Windows.Forms.TextBox();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listBoxEndPoints);
            this.groupBox3.Controls.Add(this.BtnClearEnd);
            this.groupBox3.Controls.Add(this.BtnSetEnd);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBoxEnd);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(18, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(351, 120);
            this.groupBox3.TabIndex = 45;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Line Path";
            // 
            // listBoxEndPoints
            // 
            this.listBoxEndPoints.BackColor = System.Drawing.SystemColors.Control;
            this.listBoxEndPoints.FormattingEnabled = true;
            this.listBoxEndPoints.ItemHeight = 12;
            this.listBoxEndPoints.Location = new System.Drawing.Point(199, 20);
            this.listBoxEndPoints.Name = "listBoxEndPoints";
            this.listBoxEndPoints.Size = new System.Drawing.Size(118, 88);
            this.listBoxEndPoints.TabIndex = 30;
            // 
            // BtnClearEnd
            // 
            this.BtnClearEnd.Location = new System.Drawing.Point(112, 64);
            this.BtnClearEnd.Name = "BtnClearEnd";
            this.BtnClearEnd.Size = new System.Drawing.Size(77, 24);
            this.BtnClearEnd.TabIndex = 12;
            this.BtnClearEnd.Text = "Clear";
            this.BtnClearEnd.UseVisualStyleBackColor = true;
            this.BtnClearEnd.Click += new System.EventHandler(this.BtnClearEnd_Click);
            // 
            // BtnSetEnd
            // 
            this.BtnSetEnd.Location = new System.Drawing.Point(26, 64);
            this.BtnSetEnd.Name = "BtnSetEnd";
            this.BtnSetEnd.Size = new System.Drawing.Size(71, 23);
            this.BtnSetEnd.TabIndex = 9;
            this.BtnSetEnd.Text = "Add End";
            this.BtnSetEnd.UseVisualStyleBackColor = true;
            this.BtnSetEnd.Click += new System.EventHandler(this.BtnSetEnd_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "EndPoint:";
            // 
            // textBoxEnd
            // 
            this.textBoxEnd.Location = new System.Drawing.Point(83, 24);
            this.textBoxEnd.Name = "textBoxEnd";
            this.textBoxEnd.Size = new System.Drawing.Size(106, 21);
            this.textBoxEnd.TabIndex = 11;
            this.textBoxEnd.Text = "10000";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(218, 151);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 60;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            // 
            // btn_OK
            // 
            this.btn_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_OK.Location = new System.Drawing.Point(76, 151);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 59;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // FormLine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(388, 203);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.groupBox3);
            this.Name = "FormLine";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormLine";
            this.Load += new System.EventHandler(this.FormLine_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox listBoxEndPoints;
        private System.Windows.Forms.Button BtnClearEnd;
        private System.Windows.Forms.Button BtnSetEnd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxEnd;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_OK;
        Form1 form1 = new Form1();
        public uint EndPointNum = new uint();
        public double[] EndArray = new double[32];
    }
}