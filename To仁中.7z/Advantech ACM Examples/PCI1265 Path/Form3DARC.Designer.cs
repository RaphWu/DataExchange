﻿namespace Path
{
    partial class Form3DARC
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxAgl = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxCen3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxCen2 = new System.Windows.Forms.TextBox();
            this.textBoxCen1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxEnd3 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxEnd2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxEnd1 = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.radioButtonCen = new System.Windows.Forms.RadioButton();
            this.radioButtonRef = new System.Windows.Forms.RadioButton();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.radioButtonCCW = new System.Windows.Forms.RadioButton();
            this.radioButtonCW = new System.Windows.Forms.RadioButton();
            this.groupBox10.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.textBoxAgl);
            this.groupBox10.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox10.Location = new System.Drawing.Point(232, 141);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(194, 55);
            this.groupBox10.TabIndex = 18;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Arc Agl";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(27, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 11;
            this.label15.Text = "Agl:";
            // 
            // textBoxAgl
            // 
            this.textBoxAgl.Location = new System.Drawing.Point(62, 23);
            this.textBoxAgl.Name = "textBoxAgl";
            this.textBoxAgl.Size = new System.Drawing.Size(100, 21);
            this.textBoxAgl.TabIndex = 11;
            this.textBoxAgl.Text = "90";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxCen3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.textBoxCen2);
            this.groupBox2.Controls.Add(this.textBoxCen1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(12, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(417, 56);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Center";
            // 
            // textBoxCen3
            // 
            this.textBoxCen3.Location = new System.Drawing.Point(325, 24);
            this.textBoxCen3.Name = "textBoxCen3";
            this.textBoxCen3.Size = new System.Drawing.Size(78, 21);
            this.textBoxCen3.TabIndex = 12;
            this.textBoxCen3.Text = "8000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(280, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 11;
            this.label1.Text = "C3/R3:";
            // 
            // textBoxCen2
            // 
            this.textBoxCen2.Location = new System.Drawing.Point(188, 23);
            this.textBoxCen2.Name = "textBoxCen2";
            this.textBoxCen2.Size = new System.Drawing.Size(78, 21);
            this.textBoxCen2.TabIndex = 10;
            this.textBoxCen2.Text = "8000";
            // 
            // textBoxCen1
            // 
            this.textBoxCen1.Location = new System.Drawing.Point(50, 24);
            this.textBoxCen1.Name = "textBoxCen1";
            this.textBoxCen1.Size = new System.Drawing.Size(78, 21);
            this.textBoxCen1.TabIndex = 6;
            this.textBoxCen1.Text = "8000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(143, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "C2/R2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "C1/R1:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxEnd3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textBoxEnd2);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBoxEnd1);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(11, 71);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(418, 62);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "End";
            // 
            // textBoxEnd3
            // 
            this.textBoxEnd3.Location = new System.Drawing.Point(326, 26);
            this.textBoxEnd3.Name = "textBoxEnd3";
            this.textBoxEnd3.Size = new System.Drawing.Size(78, 21);
            this.textBoxEnd3.TabIndex = 19;
            this.textBoxEnd3.Text = "-3890";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(282, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "E3/V3:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(144, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "E2/V2:";
            // 
            // textBoxEnd2
            // 
            this.textBoxEnd2.Location = new System.Drawing.Point(189, 24);
            this.textBoxEnd2.Name = "textBoxEnd2";
            this.textBoxEnd2.Size = new System.Drawing.Size(78, 21);
            this.textBoxEnd2.TabIndex = 12;
            this.textBoxEnd2.Text = "5353";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "E1/V1:";
            // 
            // textBoxEnd1
            // 
            this.textBoxEnd1.Location = new System.Drawing.Point(49, 25);
            this.textBoxEnd1.Name = "textBoxEnd1";
            this.textBoxEnd1.Size = new System.Drawing.Size(80, 21);
            this.textBoxEnd1.TabIndex = 11;
            this.textBoxEnd1.Text = "14600";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.radioButtonCen);
            this.groupBox9.Controls.Add(this.radioButtonRef);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox9.Location = new System.Drawing.Point(11, 139);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(204, 57);
            this.groupBox9.TabIndex = 17;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Arc Mode";
            // 
            // radioButtonCen
            // 
            this.radioButtonCen.AutoSize = true;
            this.radioButtonCen.Checked = true;
            this.radioButtonCen.Location = new System.Drawing.Point(12, 28);
            this.radioButtonCen.Name = "radioButtonCen";
            this.radioButtonCen.Size = new System.Drawing.Size(41, 16);
            this.radioButtonCen.TabIndex = 11;
            this.radioButtonCen.TabStop = true;
            this.radioButtonCen.Text = "End";
            this.radioButtonCen.UseVisualStyleBackColor = true;
            // 
            // radioButtonRef
            // 
            this.radioButtonRef.AutoSize = true;
            this.radioButtonRef.Location = new System.Drawing.Point(131, 30);
            this.radioButtonRef.Name = "radioButtonRef";
            this.radioButtonRef.Size = new System.Drawing.Size(41, 16);
            this.radioButtonRef.TabIndex = 12;
            this.radioButtonRef.Text = "Vec";
            this.radioButtonRef.UseVisualStyleBackColor = true;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cancel.Location = new System.Drawing.Point(270, 256);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 26);
            this.btn_Cancel.TabIndex = 20;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            // 
            // btn_OK
            // 
            this.btn_OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btn_OK.Location = new System.Drawing.Point(96, 255);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 26);
            this.btn_OK.TabIndex = 19;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 12);
            this.label9.TabIndex = 53;
            this.label9.Text = "Arc Direction:";
            // 
            // radioButtonCCW
            // 
            this.radioButtonCCW.AutoSize = true;
            this.radioButtonCCW.Location = new System.Drawing.Point(197, 218);
            this.radioButtonCCW.Name = "radioButtonCCW";
            this.radioButtonCCW.Size = new System.Drawing.Size(41, 16);
            this.radioButtonCCW.TabIndex = 52;
            this.radioButtonCCW.Text = "CCW";
            this.radioButtonCCW.UseVisualStyleBackColor = true;
            // 
            // radioButtonCW
            // 
            this.radioButtonCW.AutoSize = true;
            this.radioButtonCW.Checked = true;
            this.radioButtonCW.Location = new System.Drawing.Point(116, 216);
            this.radioButtonCW.Name = "radioButtonCW";
            this.radioButtonCW.Size = new System.Drawing.Size(35, 16);
            this.radioButtonCW.TabIndex = 51;
            this.radioButtonCW.TabStop = true;
            this.radioButtonCW.Text = "CW";
            this.radioButtonCW.UseVisualStyleBackColor = true;
            // 
            // Form3DARC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 299);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.radioButtonCCW);
            this.Controls.Add(this.radioButtonCW);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox9);
            this.Name = "Form3DARC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3DARC";
            this.Load += new System.EventHandler(this.Form3DARC_Load);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.TextBox textBoxAgl;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.TextBox textBoxCen3;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox textBoxCen2;
        public System.Windows.Forms.TextBox textBoxCen1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.TextBox textBoxEnd3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox textBoxEnd2;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox textBoxEnd1;
        private System.Windows.Forms.GroupBox groupBox9;
        public System.Windows.Forms.RadioButton radioButtonCen;
        private System.Windows.Forms.RadioButton radioButtonRef;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButtonCCW;
        public System.Windows.Forms.RadioButton radioButtonCW;
    }
}