﻿using System.Collections.Generic;
using System;
using Advantech.Motion;//Common Motion API
namespace Path
{
    public struct PATH_INFO { 
        public IntPtr PathHandle;
		public uint PathCnt;
		public int   Index;
        public string PathFileName; 
    } 
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_AddAglHelix = new System.Windows.Forms.Button();
            this.button3Darc = new System.Windows.Forms.Button();
            this.btn_AddSpiral = new System.Windows.Forms.Button();
            this.btn_AddAglArc = new System.Windows.Forms.Button();
            this.buttonAddLine = new System.Windows.Forms.Button();
            this.buttonAddArc = new System.Windows.Forms.Button();
            this.lbl_ms = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txb_DelayTime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_AddDelay = new System.Windows.Forms.Button();
            this.txb_blendTime = new System.Windows.Forms.TextBox();
            this.lblBlend = new System.Windows.Forms.Label();
            this.cbx_SpeedForward = new System.Windows.Forms.CheckBox();
            this.buttonMovePath1 = new System.Windows.Forms.Button();
            this.buttonStopPath = new System.Windows.Forms.Button();
            this.buttonClearPath = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButtonRel = new System.Windows.Forms.RadioButton();
            this.radioButtonAbs = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.buttonUnloadPath = new System.Windows.Forms.Button();
            this.textBoxPathCnt = new System.Windows.Forms.TextBox();
            this.buttonLoadPath = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxPathFiles = new System.Windows.Forms.ComboBox();
            this.buttonMovePath2 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxFreeCnt = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxCurCmd = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxRemain = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxCurIndex = new System.Windows.Forms.TextBox();
            this.BtnResetErr = new System.Windows.Forms.Button();
            this.BtnResetCounter = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.LoadPathopenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.dgv_Position = new System.Windows.Forms.DataGridView();
            this.Axis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CommandPosition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label18 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dgv_AxisState = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxGpState = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbx_Axes = new System.Windows.Forms.CheckedListBox();
            this.label74 = new System.Windows.Forms.Label();
            this.gb_MoveSelectPath = new System.Windows.Forms.GroupBox();
            this.txb_Repeat = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.txb_EndIndex = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.btn_MoveSelectPath = new System.Windows.Forms.Button();
            this.txb_StartIndex = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.buttonLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.CmbAxes = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.btn_SetParam = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Position)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AxisState)).BeginInit();
            this.gb_MoveSelectPath.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_AddAglHelix);
            this.groupBox1.Controls.Add(this.button3Darc);
            this.groupBox1.Controls.Add(this.btn_AddSpiral);
            this.groupBox1.Controls.Add(this.btn_AddAglArc);
            this.groupBox1.Controls.Add(this.buttonAddLine);
            this.groupBox1.Controls.Add(this.buttonAddArc);
            this.groupBox1.Controls.Add(this.lbl_ms);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.txb_blendTime);
            this.groupBox1.Controls.Add(this.lblBlend);
            this.groupBox1.Controls.Add(this.cbx_SpeedForward);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(15, 224);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(336, 210);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Set ContiPath Data with Mode 1";
            // 
            // btn_AddAglHelix
            // 
            this.btn_AddAglHelix.Location = new System.Drawing.Point(180, 84);
            this.btn_AddAglHelix.Name = "btn_AddAglHelix";
            this.btn_AddAglHelix.Size = new System.Drawing.Size(92, 24);
            this.btn_AddAglHelix.TabIndex = 32;
            this.btn_AddAglHelix.Text = "Add Agl Helix";
            this.btn_AddAglHelix.UseVisualStyleBackColor = true;
            this.btn_AddAglHelix.Click += new System.EventHandler(this.btn_AddAglHelix_Click);
            // 
            // button3Darc
            // 
            this.button3Darc.Location = new System.Drawing.Point(180, 54);
            this.button3Darc.Name = "button3Darc";
            this.button3Darc.Size = new System.Drawing.Size(92, 24);
            this.button3Darc.TabIndex = 33;
            this.button3Darc.Text = "Add 3D Arc";
            this.button3Darc.UseVisualStyleBackColor = true;
            this.button3Darc.Click += new System.EventHandler(this.button3Darc_Click);
            // 
            // btn_AddSpiral
            // 
            this.btn_AddSpiral.Location = new System.Drawing.Point(49, 84);
            this.btn_AddSpiral.Name = "btn_AddSpiral";
            this.btn_AddSpiral.Size = new System.Drawing.Size(92, 24);
            this.btn_AddSpiral.TabIndex = 31;
            this.btn_AddSpiral.Text = "Add Helix";
            this.btn_AddSpiral.UseVisualStyleBackColor = true;
            this.btn_AddSpiral.Click += new System.EventHandler(this.btn_AddSpiral_Click);
            // 
            // btn_AddAglArc
            // 
            this.btn_AddAglArc.Location = new System.Drawing.Point(49, 54);
            this.btn_AddAglArc.Name = "btn_AddAglArc";
            this.btn_AddAglArc.Size = new System.Drawing.Size(92, 24);
            this.btn_AddAglArc.TabIndex = 33;
            this.btn_AddAglArc.Text = "Add Agl Arc";
            this.btn_AddAglArc.UseVisualStyleBackColor = true;
            this.btn_AddAglArc.Click += new System.EventHandler(this.btn_AddAglArc_Click);
            // 
            // buttonAddLine
            // 
            this.buttonAddLine.Location = new System.Drawing.Point(49, 25);
            this.buttonAddLine.Name = "buttonAddLine";
            this.buttonAddLine.Size = new System.Drawing.Size(92, 24);
            this.buttonAddLine.TabIndex = 31;
            this.buttonAddLine.Text = "Add Line";
            this.buttonAddLine.UseVisualStyleBackColor = true;
            this.buttonAddLine.Click += new System.EventHandler(this.buttonAddLine_Click);
            // 
            // buttonAddArc
            // 
            this.buttonAddArc.Location = new System.Drawing.Point(180, 25);
            this.buttonAddArc.Name = "buttonAddArc";
            this.buttonAddArc.Size = new System.Drawing.Size(92, 24);
            this.buttonAddArc.TabIndex = 32;
            this.buttonAddArc.Text = "Add Arc";
            this.buttonAddArc.UseVisualStyleBackColor = true;
            this.buttonAddArc.Click += new System.EventHandler(this.buttonAddArc_Click);
            // 
            // lbl_ms
            // 
            this.lbl_ms.AutoSize = true;
            this.lbl_ms.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lbl_ms.Location = new System.Drawing.Point(302, 178);
            this.lbl_ms.Name = "lbl_ms";
            this.lbl_ms.Size = new System.Drawing.Size(17, 12);
            this.lbl_ms.TabIndex = 73;
            this.lbl_ms.Text = "ms";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txb_DelayTime);
            this.groupBox7.Controls.Add(this.label3);
            this.groupBox7.Controls.Add(this.btn_AddDelay);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox7.Location = new System.Drawing.Point(15, 114);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(309, 52);
            this.groupBox7.TabIndex = 56;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Delay Path";
            // 
            // txb_DelayTime
            // 
            this.txb_DelayTime.Location = new System.Drawing.Point(88, 21);
            this.txb_DelayTime.Name = "txb_DelayTime";
            this.txb_DelayTime.Size = new System.Drawing.Size(99, 21);
            this.txb_DelayTime.TabIndex = 55;
            this.txb_DelayTime.Text = "1000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 12);
            this.label3.TabIndex = 54;
            this.label3.Text = "Delay Time:";
            // 
            // btn_AddDelay
            // 
            this.btn_AddDelay.Location = new System.Drawing.Point(194, 18);
            this.btn_AddDelay.Name = "btn_AddDelay";
            this.btn_AddDelay.Size = new System.Drawing.Size(87, 25);
            this.btn_AddDelay.TabIndex = 53;
            this.btn_AddDelay.Text = "Add Delay";
            this.btn_AddDelay.UseVisualStyleBackColor = true;
            this.btn_AddDelay.Click += new System.EventHandler(this.btn_AddDelay_Click);
            // 
            // txb_blendTime
            // 
            this.txb_blendTime.Location = new System.Drawing.Point(222, 176);
            this.txb_blendTime.Name = "txb_blendTime";
            this.txb_blendTime.Size = new System.Drawing.Size(74, 21);
            this.txb_blendTime.TabIndex = 72;
            this.txb_blendTime.Text = "0";
            // 
            // lblBlend
            // 
            this.lblBlend.AutoSize = true;
            this.lblBlend.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblBlend.Location = new System.Drawing.Point(132, 180);
            this.lblBlend.Name = "lblBlend";
            this.lblBlend.Size = new System.Drawing.Size(89, 12);
            this.lblBlend.TabIndex = 71;
            this.lblBlend.Text = "Blending Time:";
            // 
            // cbx_SpeedForward
            // 
            this.cbx_SpeedForward.AutoSize = true;
            this.cbx_SpeedForward.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cbx_SpeedForward.Location = new System.Drawing.Point(17, 178);
            this.cbx_SpeedForward.Name = "cbx_SpeedForward";
            this.cbx_SpeedForward.Size = new System.Drawing.Size(102, 16);
            this.cbx_SpeedForward.TabIndex = 70;
            this.cbx_SpeedForward.Text = "Speed Forward";
            this.cbx_SpeedForward.UseVisualStyleBackColor = true;
            this.cbx_SpeedForward.CheckedChanged += new System.EventHandler(this.cbx_SpeedForward_CheckedChanged);
            // 
            // buttonMovePath1
            // 
            this.buttonMovePath1.Location = new System.Drawing.Point(15, 527);
            this.buttonMovePath1.Name = "buttonMovePath1";
            this.buttonMovePath1.Size = new System.Drawing.Size(112, 25);
            this.buttonMovePath1.TabIndex = 48;
            this.buttonMovePath1.Text = "Move Path Mode1";
            this.buttonMovePath1.UseVisualStyleBackColor = true;
            this.buttonMovePath1.Click += new System.EventHandler(this.buttonMovePath1_Click);
            // 
            // buttonStopPath
            // 
            this.buttonStopPath.Location = new System.Drawing.Point(263, 526);
            this.buttonStopPath.Name = "buttonStopPath";
            this.buttonStopPath.Size = new System.Drawing.Size(88, 25);
            this.buttonStopPath.TabIndex = 53;
            this.buttonStopPath.Text = "Stop Path";
            this.buttonStopPath.UseVisualStyleBackColor = true;
            this.buttonStopPath.Click += new System.EventHandler(this.buttonStopPath_Click);
            // 
            // buttonClearPath
            // 
            this.buttonClearPath.Location = new System.Drawing.Point(147, 83);
            this.buttonClearPath.Name = "buttonClearPath";
            this.buttonClearPath.Size = new System.Drawing.Size(101, 25);
            this.buttonClearPath.TabIndex = 54;
            this.buttonClearPath.Text = "Reset Path";
            this.buttonClearPath.UseVisualStyleBackColor = true;
            this.buttonClearPath.Click += new System.EventHandler(this.buttonClearPath_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButtonRel);
            this.groupBox2.Controls.Add(this.radioButtonAbs);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(155, 159);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(195, 54);
            this.groupBox2.TabIndex = 49;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Movement Mode";
            // 
            // radioButtonRel
            // 
            this.radioButtonRel.AutoSize = true;
            this.radioButtonRel.Checked = true;
            this.radioButtonRel.Location = new System.Drawing.Point(8, 28);
            this.radioButtonRel.Name = "radioButtonRel";
            this.radioButtonRel.Size = new System.Drawing.Size(71, 16);
            this.radioButtonRel.TabIndex = 7;
            this.radioButtonRel.TabStop = true;
            this.radioButtonRel.Text = "Relative";
            this.radioButtonRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonAbs
            // 
            this.radioButtonAbs.AutoSize = true;
            this.radioButtonAbs.Location = new System.Drawing.Point(118, 28);
            this.radioButtonAbs.Name = "radioButtonAbs";
            this.radioButtonAbs.Size = new System.Drawing.Size(71, 16);
            this.radioButtonAbs.TabIndex = 6;
            this.radioButtonAbs.Text = "Absolute";
            this.radioButtonAbs.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.buttonUnloadPath);
            this.groupBox4.Controls.Add(this.textBoxPathCnt);
            this.groupBox4.Controls.Add(this.buttonLoadPath);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.comboBoxPathFiles);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox4.Location = new System.Drawing.Point(13, 443);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(340, 75);
            this.groupBox4.TabIndex = 50;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Set ContiPath Data with Mode 2";
            // 
            // buttonUnloadPath
            // 
            this.buttonUnloadPath.Location = new System.Drawing.Point(254, 19);
            this.buttonUnloadPath.Name = "buttonUnloadPath";
            this.buttonUnloadPath.Size = new System.Drawing.Size(75, 24);
            this.buttonUnloadPath.TabIndex = 53;
            this.buttonUnloadPath.Text = "Unload";
            this.buttonUnloadPath.UseVisualStyleBackColor = true;
            this.buttonUnloadPath.Click += new System.EventHandler(this.buttonUnloadPath_Click);
            // 
            // textBoxPathCnt
            // 
            this.textBoxPathCnt.Location = new System.Drawing.Point(91, 47);
            this.textBoxPathCnt.Name = "textBoxPathCnt";
            this.textBoxPathCnt.ReadOnly = true;
            this.textBoxPathCnt.Size = new System.Drawing.Size(145, 21);
            this.textBoxPathCnt.TabIndex = 52;
            // 
            // buttonLoadPath
            // 
            this.buttonLoadPath.Location = new System.Drawing.Point(6, 21);
            this.buttonLoadPath.Name = "buttonLoadPath";
            this.buttonLoadPath.Size = new System.Drawing.Size(77, 23);
            this.buttonLoadPath.TabIndex = 52;
            this.buttonLoadPath.Text = "Load Path";
            this.buttonLoadPath.UseVisualStyleBackColor = true;
            this.buttonLoadPath.Click += new System.EventHandler(this.buttonLoadPath_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 51;
            this.label4.Text = "Path Cnt:";
            // 
            // comboBoxPathFiles
            // 
            this.comboBoxPathFiles.FormattingEnabled = true;
            this.comboBoxPathFiles.Location = new System.Drawing.Point(91, 22);
            this.comboBoxPathFiles.Name = "comboBoxPathFiles";
            this.comboBoxPathFiles.Size = new System.Drawing.Size(160, 20);
            this.comboBoxPathFiles.TabIndex = 51;
            this.comboBoxPathFiles.SelectedIndexChanged += new System.EventHandler(this.comboBoxPathFiles_SelectedIndexChanged);
            // 
            // buttonMovePath2
            // 
            this.buttonMovePath2.Location = new System.Drawing.Point(140, 528);
            this.buttonMovePath2.Name = "buttonMovePath2";
            this.buttonMovePath2.Size = new System.Drawing.Size(109, 24);
            this.buttonMovePath2.TabIndex = 50;
            this.buttonMovePath2.Text = "Move Path Mode2";
            this.buttonMovePath2.UseVisualStyleBackColor = true;
            this.buttonMovePath2.Click += new System.EventHandler(this.buttonMovePath2_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.textBoxFreeCnt);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.textBoxCurCmd);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.textBoxRemain);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.textBoxCurIndex);
            this.groupBox6.Controls.Add(this.buttonClearPath);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox6.Location = new System.Drawing.Point(376, 95);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(383, 120);
            this.groupBox6.TabIndex = 52;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Path Status";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(200, 57);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 24;
            this.label17.Text = "FreeCnt:";
            // 
            // textBoxFreeCnt
            // 
            this.textBoxFreeCnt.Location = new System.Drawing.Point(256, 52);
            this.textBoxFreeCnt.Name = "textBoxFreeCnt";
            this.textBoxFreeCnt.ReadOnly = true;
            this.textBoxFreeCnt.Size = new System.Drawing.Size(105, 21);
            this.textBoxFreeCnt.TabIndex = 23;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(203, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 12);
            this.label16.TabIndex = 22;
            this.label16.Text = "CurCmd:";
            // 
            // textBoxCurCmd
            // 
            this.textBoxCurCmd.Location = new System.Drawing.Point(256, 22);
            this.textBoxCurCmd.Name = "textBoxCurCmd";
            this.textBoxCurCmd.ReadOnly = true;
            this.textBoxCurCmd.Size = new System.Drawing.Size(105, 21);
            this.textBoxCurCmd.TabIndex = 21;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(18, 55);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 20;
            this.label15.Text = "Remain:";
            // 
            // textBoxRemain
            // 
            this.textBoxRemain.Location = new System.Drawing.Point(71, 50);
            this.textBoxRemain.Name = "textBoxRemain";
            this.textBoxRemain.ReadOnly = true;
            this.textBoxRemain.Size = new System.Drawing.Size(115, 21);
            this.textBoxRemain.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 12);
            this.label14.TabIndex = 18;
            this.label14.Text = "CurIndex:";
            // 
            // textBoxCurIndex
            // 
            this.textBoxCurIndex.Location = new System.Drawing.Point(72, 21);
            this.textBoxCurIndex.Name = "textBoxCurIndex";
            this.textBoxCurIndex.ReadOnly = true;
            this.textBoxCurIndex.Size = new System.Drawing.Size(115, 21);
            this.textBoxCurIndex.TabIndex = 10;
            // 
            // BtnResetErr
            // 
            this.BtnResetErr.Location = new System.Drawing.Point(616, 474);
            this.BtnResetErr.Name = "BtnResetErr";
            this.BtnResetErr.Size = new System.Drawing.Size(84, 23);
            this.BtnResetErr.TabIndex = 15;
            this.BtnResetErr.Text = "Reset Error";
            this.BtnResetErr.UseVisualStyleBackColor = true;
            this.BtnResetErr.Click += new System.EventHandler(this.BtnResetErr_Click);
            // 
            // BtnResetCounter
            // 
            this.BtnResetCounter.Location = new System.Drawing.Point(428, 474);
            this.BtnResetCounter.Name = "BtnResetCounter";
            this.BtnResetCounter.Size = new System.Drawing.Size(91, 23);
            this.BtnResetCounter.TabIndex = 15;
            this.BtnResetCounter.Text = "Reset Counter";
            this.BtnResetCounter.UseVisualStyleBackColor = true;
            this.BtnResetCounter.Click += new System.EventHandler(this.BtnResetCounter_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // LoadPathopenFileDialog
            // 
            this.LoadPathopenFileDialog.FileName = "openFileDialogLoadPath";
            // 
            // dgv_Position
            // 
            this.dgv_Position.AllowUserToAddRows = false;
            this.dgv_Position.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Position.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Position.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Position.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Axis,
            this.CommandPosition});
            this.dgv_Position.Location = new System.Drawing.Point(376, 335);
            this.dgv_Position.Name = "dgv_Position";
            this.dgv_Position.ReadOnly = true;
            this.dgv_Position.RowHeadersVisible = false;
            this.dgv_Position.RowHeadersWidth = 10;
            this.dgv_Position.RowTemplate.Height = 23;
            this.dgv_Position.Size = new System.Drawing.Size(187, 130);
            this.dgv_Position.TabIndex = 56;
            // 
            // Axis
            // 
            this.Axis.HeaderText = "Axis";
            this.Axis.Name = "Axis";
            this.Axis.ReadOnly = true;
            this.Axis.Width = 80;
            // 
            // CommandPosition
            // 
            this.CommandPosition.HeaderText = "Cmd Position";
            this.CommandPosition.Name = "CommandPosition";
            this.CommandPosition.ReadOnly = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(379, 316);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 12);
            this.label18.TabIndex = 55;
            this.label18.Text = "Position:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(576, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 12);
            this.label8.TabIndex = 60;
            this.label8.Text = "Axis State:";
            // 
            // dgv_AxisState
            // 
            this.dgv_AxisState.AllowUserToAddRows = false;
            this.dgv_AxisState.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_AxisState.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_AxisState.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_AxisState.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgv_AxisState.Location = new System.Drawing.Point(576, 335);
            this.dgv_AxisState.Name = "dgv_AxisState";
            this.dgv_AxisState.ReadOnly = true;
            this.dgv_AxisState.RowHeadersVisible = false;
            this.dgv_AxisState.RowHeadersWidth = 10;
            this.dgv_AxisState.RowTemplate.Height = 23;
            this.dgv_AxisState.Size = new System.Drawing.Size(184, 130);
            this.dgv_AxisState.TabIndex = 59;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Axis";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "State";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // textBoxGpState
            // 
            this.textBoxGpState.Location = new System.Drawing.Point(484, 519);
            this.textBoxGpState.Name = "textBoxGpState";
            this.textBoxGpState.ReadOnly = true;
            this.textBoxGpState.Size = new System.Drawing.Size(145, 21);
            this.textBoxGpState.TabIndex = 58;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(398, 522);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 57;
            this.label5.Text = "Group State:";
            // 
            // cbx_Axes
            // 
            this.cbx_Axes.CheckOnClick = true;
            this.cbx_Axes.FormattingEnabled = true;
            this.cbx_Axes.Location = new System.Drawing.Point(17, 135);
            this.cbx_Axes.Name = "cbx_Axes";
            this.cbx_Axes.Size = new System.Drawing.Size(127, 84);
            this.cbx_Axes.TabIndex = 66;
            this.cbx_Axes.SelectedIndexChanged += new System.EventHandler(this.cbx_Axes_SelectedIndexChanged);
            // 
            // label74
            // 
            this.label74.Location = new System.Drawing.Point(19, 113);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(102, 23);
            this.label74.TabIndex = 65;
            this.label74.Text = "Operation Axes:";
            // 
            // gb_MoveSelectPath
            // 
            this.gb_MoveSelectPath.Controls.Add(this.txb_Repeat);
            this.gb_MoveSelectPath.Controls.Add(this.label87);
            this.gb_MoveSelectPath.Controls.Add(this.txb_EndIndex);
            this.gb_MoveSelectPath.Controls.Add(this.label83);
            this.gb_MoveSelectPath.Controls.Add(this.btn_MoveSelectPath);
            this.gb_MoveSelectPath.Controls.Add(this.txb_StartIndex);
            this.gb_MoveSelectPath.Controls.Add(this.label82);
            this.gb_MoveSelectPath.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gb_MoveSelectPath.Location = new System.Drawing.Point(376, 13);
            this.gb_MoveSelectPath.Name = "gb_MoveSelectPath";
            this.gb_MoveSelectPath.Size = new System.Drawing.Size(385, 73);
            this.gb_MoveSelectPath.TabIndex = 67;
            this.gb_MoveSelectPath.TabStop = false;
            this.gb_MoveSelectPath.Text = "Move Select Path";
            // 
            // txb_Repeat
            // 
            this.txb_Repeat.Location = new System.Drawing.Point(82, 45);
            this.txb_Repeat.Name = "txb_Repeat";
            this.txb_Repeat.Size = new System.Drawing.Size(105, 21);
            this.txb_Repeat.TabIndex = 58;
            this.txb_Repeat.Text = "1";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(36, 47);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(41, 12);
            this.label87.TabIndex = 57;
            this.label87.Text = "Times:";
            // 
            // txb_EndIndex
            // 
            this.txb_EndIndex.Location = new System.Drawing.Point(260, 16);
            this.txb_EndIndex.Name = "txb_EndIndex";
            this.txb_EndIndex.Size = new System.Drawing.Size(105, 21);
            this.txb_EndIndex.TabIndex = 53;
            this.txb_EndIndex.Text = "-1";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(197, 19);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(65, 12);
            this.label83.TabIndex = 52;
            this.label83.Text = "End Index:";
            // 
            // btn_MoveSelectPath
            // 
            this.btn_MoveSelectPath.Location = new System.Drawing.Point(240, 42);
            this.btn_MoveSelectPath.Name = "btn_MoveSelectPath";
            this.btn_MoveSelectPath.Size = new System.Drawing.Size(119, 26);
            this.btn_MoveSelectPath.TabIndex = 56;
            this.btn_MoveSelectPath.Text = "Move Select Path";
            this.btn_MoveSelectPath.UseVisualStyleBackColor = true;
            this.btn_MoveSelectPath.Click += new System.EventHandler(this.btn_MoveSelectPath_Click);
            // 
            // txb_StartIndex
            // 
            this.txb_StartIndex.Location = new System.Drawing.Point(82, 16);
            this.txb_StartIndex.Name = "txb_StartIndex";
            this.txb_StartIndex.Size = new System.Drawing.Size(104, 21);
            this.txb_StartIndex.TabIndex = 51;
            this.txb_StartIndex.Text = "-1";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(3, 22);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(77, 12);
            this.label82.TabIndex = 50;
            this.label82.Text = "Start Index:";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.buttonLoadCfg);
            this.groupBox9.Controls.Add(this.BtnServo);
            this.groupBox9.Controls.Add(this.BtnCloseBoard);
            this.groupBox9.Controls.Add(this.BtnOpenBoard);
            this.groupBox9.Controls.Add(this.CmbAvailableDevice);
            this.groupBox9.Controls.Add(this.label1);
            this.groupBox9.Location = new System.Drawing.Point(17, 9);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(336, 101);
            this.groupBox9.TabIndex = 69;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Device Operate";
            // 
            // buttonLoadCfg
            // 
            this.buttonLoadCfg.Location = new System.Drawing.Point(48, 70);
            this.buttonLoadCfg.Name = "buttonLoadCfg";
            this.buttonLoadCfg.Size = new System.Drawing.Size(90, 24);
            this.buttonLoadCfg.TabIndex = 31;
            this.buttonLoadCfg.Text = "Load Config";
            this.buttonLoadCfg.UseVisualStyleBackColor = true;
            this.buttonLoadCfg.Click += new System.EventHandler(this.buttonLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(203, 70);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(90, 24);
            this.BtnServo.TabIndex = 17;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(203, 41);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(90, 24);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(48, 41);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(90, 24);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(133, 15);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(174, 20);
            this.CmbAvailableDevice.TabIndex = 14;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "Available device:";
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openFileDialog1";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.CmbAxes);
            this.groupBox13.Controls.Add(this.label6);
            this.groupBox13.Controls.Add(this.label11);
            this.groupBox13.Controls.Add(this.label2);
            this.groupBox13.Controls.Add(this.label12);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(376, 223);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(384, 76);
            this.groupBox13.TabIndex = 114;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Selected Axis Signal Status";
            // 
            // CmbAxes
            // 
            this.CmbAxes.FormattingEnabled = true;
            this.CmbAxes.Location = new System.Drawing.Point(10, 44);
            this.CmbAxes.Name = "CmbAxes";
            this.CmbAxes.Size = new System.Drawing.Size(163, 20);
            this.CmbAxes.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 12);
            this.label6.TabIndex = 36;
            this.label6.Text = "Selected Axis:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(285, 53);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 28;
            this.label11.Text = "-HEL:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(187, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 27;
            this.label2.Text = "+HEL:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(285, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 26;
            this.label12.Text = "ORG:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(192, 26);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(326, 48);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(228, 48);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(326, 20);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(228, 20);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // btn_SetParam
            // 
            this.btn_SetParam.Location = new System.Drawing.Point(241, 124);
            this.btn_SetParam.Name = "btn_SetParam";
            this.btn_SetParam.Size = new System.Drawing.Size(100, 23);
            this.btn_SetParam.TabIndex = 115;
            this.btn_SetParam.Text = "Set/Get Param";
            this.btn_SetParam.UseVisualStyleBackColor = true;
            this.btn_SetParam.Click += new System.EventHandler(this.btn_SetParam_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(160, 130);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 12);
            this.label7.TabIndex = 116;
            this.label7.Text = "Group Param:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 564);
            this.Controls.Add(this.buttonMovePath2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_SetParam);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.gb_MoveSelectPath);
            this.Controls.Add(this.cbx_Axes);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dgv_AxisState);
            this.Controls.Add(this.buttonMovePath1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.textBoxGpState);
            this.Controls.Add(this.buttonStopPath);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.dgv_Position);
            this.Controls.Add(this.BtnResetCounter);
            this.Controls.Add(this.BtnResetErr);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Path";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Position)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AxisState)).EndInit();
            this.gb_MoveSelectPath.ResumeLayout(false);
            this.gb_MoveSelectPath.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonAddLine;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButtonRel;
        private System.Windows.Forms.RadioButton radioButtonAbs;
        private System.Windows.Forms.Button buttonMovePath1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button buttonLoadPath;
        private System.Windows.Forms.ComboBox comboBoxPathFiles;
        private System.Windows.Forms.Button buttonMovePath2;
        private System.Windows.Forms.Button buttonUnloadPath;
        private System.Windows.Forms.TextBox textBoxPathCnt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BtnResetErr;
        private System.Windows.Forms.Button BtnResetCounter;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxCurIndex;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxFreeCnt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxCurCmd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBoxRemain;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[32];
        IntPtr m_GpHand = new IntPtr();
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        uint AxCountInGp = 0;
        public  double[] EndArray = new double[32];
        public uint EndPointNum = new uint();
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog LoadPathopenFileDialog;
        List<PATH_INFO> PathInfoList = new List<PATH_INFO>();
        private System.Windows.Forms.Button buttonClearPath;
        private System.Windows.Forms.Button buttonStopPath;
        private System.Windows.Forms.DataGridView dgv_Position;
        private System.Windows.Forms.DataGridViewTextBoxColumn Axis;
        private System.Windows.Forms.DataGridViewTextBoxColumn CommandPosition;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dgv_AxisState;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TextBox textBoxGpState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckedListBox cbx_Axes;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.GroupBox gb_MoveSelectPath;
        private System.Windows.Forms.TextBox txb_Repeat;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox txb_EndIndex;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Button btn_MoveSelectPath;
        private System.Windows.Forms.TextBox txb_StartIndex;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txb_DelayTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_AddDelay;
        private System.Windows.Forms.Label lbl_ms;
        private System.Windows.Forms.TextBox txb_blendTime;
        private System.Windows.Forms.Label lblBlend;
        private System.Windows.Forms.CheckBox cbx_SpeedForward;
        private System.Windows.Forms.Button btn_AddSpiral;
        private System.Windows.Forms.Button btn_AddAglHelix;
        private System.Windows.Forms.Button btn_AddAglArc;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button buttonLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
        private System.Windows.Forms.ComboBox CmbAxes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3Darc;
        private System.Windows.Forms.Button btn_SetParam;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonAddArc;       
    }
}

