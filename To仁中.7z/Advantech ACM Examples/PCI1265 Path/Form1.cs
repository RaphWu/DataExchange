﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Runtime.InteropServices; //For Marshal
using System.Diagnostics;
namespace Path
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }
        FormAddLine LineDlg = new FormAddLine();
     //   FormLine LineDlg = new FormLine();
        uint motionAxisCount = 0;
        uint CurPathCount = 0;
        IntPtr PathHand = IntPtr.Zero;
        
        private void Form1_Load(object sender, EventArgs e)
        {
            int Result;
            string strTemp;
            Boolean VersionIsOk = false;
            VersionIsOk = GetDevCfgDllDrvVer(); //Get Driver Version Number, this step is not necessary
            if (VersionIsOk == false)
            {
              return;
            }
            // Get the list of available device numbers and names of devices, of which driver has been loaded successfully 
            //If you have two/more board,the device list(m_avaDevs) may be changed when the slot of the boards changed,for example:m_avaDevs[0].szDeviceName to PCI-1245
            //m_avaDevs[1].szDeviceName to PCI-1245L,changing the slot，Perhaps the opposite
            Result = Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount);
            if (Result != (int)ErrorCode.SUCCESS)
            {
                strTemp = "Get Device Numbers Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, (uint)Result);
                return;
            }
            //If you want to get the device number of fixed equipment，you also can achieve it By adding the API:GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID),
            //The API is defined and illustrates the way of using in this example,but it is not called,you can copy it to your program and
            //don't need to call Motion.mAcm_GetAvailableDevs(CurAvailableDevs, Motion.MAX_DEVICES, ref deviceCount)
            //GetDevNum(UInt32 DevType, UInt32 BoardID, UInt32 MasterRingNo, UInt32 SlaveBoardID) API Variables are stated below:
            //UInt32 DevType : Set Device Type ID of your motion card plug in PC. (Definition is in ..\Public\AdvMotDev.h)
            //UInt32 BoardID : Set Hardware Board-ID of your motion card plug in PC,you can get it from Utility
            //UInt32 MasterRingNo: PCI-Motion card, Always set to 0
            //UInt32 SlaveBoardID : PCI-Motion card,Always set to 0
            CmbAvailableDevice.Items.Clear();
            for (int i = 0; i < deviceCount; i++)
            {
                CmbAvailableDevice.Items.Add(CurAvailableDevs[i].DeviceName);
            }
            if (deviceCount > 0)
            {
                CmbAvailableDevice.SelectedIndex = 0;
                DeviceNum = CurAvailableDevs[0].DeviceNum;
            }
            m_GpHand = IntPtr.Zero;
            EndPointNum = 0;

        }
       
        private void buttonAddLine_Click(object sender, EventArgs e)
        {
            UInt32 Result;
	        UInt16 MoveCmd=0;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            if (LineDlg.ShowDialog() == DialogResult.OK)
            {
                if (motionAxisCount == 2)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        MoveCmd = (UInt16)InterpolationTypeMap.DEV_IPO_LINE_REL_2AX;
                    }
                    else
                    {
                        MoveCmd = (UInt16)InterpolationTypeMap.DEV_IPO_LINE_ABS_2AX;
                    }
                }
                else if (motionAxisCount >= 3)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        MoveCmd = (UInt16)InterpolationTypeMap.DEV_IPO_LINE_REL_3AX;
                    }
                    else
                    {
                        MoveCmd = (UInt16)InterpolationTypeMap.DEV_IPO_LINE_ABS_3AX;
                    }
                }
                EndArray = LineDlg.EndArray;
                //Add an interpolation path to system path buffer
                Result = Motion.mAcm_GpAddPath(m_GpHand, MoveCmd, 0, GpVelHigh, GpVelLow, EndArray, null, ref motionAxisCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Add path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (textBoxRemain.Text != "0")
                {
                    CurPathCount = Convert.ToUInt32(textBoxRemain.Text);
                    if (CurPathCount > 0)
                    {
                        txb_StartIndex.Text = "0";
                        txb_EndIndex.Text = Convert.ToString(CurPathCount);
                    }
                }
                else
                {
                    txb_StartIndex.Text = "0";
                    txb_EndIndex.Text = "0";
                }
            }
        }
        Arc dlg = new Arc();
        private void buttonAddArc_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            UInt16 MoveCmd;
            string strTemp;
            double[] EndPoint_DataArray = new double[3];
            double[] CenPoint_DataArray = new double[3];
          
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                if (motionAxisCount >= 2)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (dlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)InterpolationTypeMap.DEV_IPO_ARC_REL_CW_2AX;
                        }
                        else
                            MoveCmd = (UInt16)InterpolationTypeMap.DEV_IPO_ARC_REL_CCW_2AX; ;
                    }
                    else//Abs
                    {
                        if (dlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)InterpolationTypeMap.DEV_IPO_ARC_ABS_CW_2AX; ;
                        }
                        else
                            MoveCmd = (UInt16)InterpolationTypeMap.DEV_IPO_ARC_ABS_CCW_2AX; ; ;
                    }

                }
                else
                {
                    MessageBox.Show("Axis count in group error", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                EndPoint_DataArray[0] = Convert.ToDouble(dlg.textBoxEnd1.Text);
                EndPoint_DataArray[1] = Convert.ToDouble(dlg.textBoxEnd2.Text);
                EndPoint_DataArray[2] = 0; 
                CenPoint_DataArray[0] = Convert.ToDouble(dlg.textBoxCen1.Text); 
                CenPoint_DataArray[1] = Convert.ToDouble(dlg.textBoxCen2.Text);
                CenPoint_DataArray[2] =0;
                //Add an interpolation path to system path buffer
                //Add an interpolation path to system path buffer
                Result = Motion.mAcm_GpAddPath(m_GpHand, MoveCmd, 0, GpVelHigh, GpVelLow, EndPoint_DataArray, CenPoint_DataArray, ref  motionAxisCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Add path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (textBoxRemain.Text != "0")
                {
                    CurPathCount = Convert.ToUInt32(textBoxRemain.Text);
                    if (CurPathCount > 0)
                    {
                        txb_StartIndex.Text = "0";
                        txb_EndIndex.Text = Convert.ToString(CurPathCount);
                    }
                }
                else
                {
                    txb_StartIndex.Text = "0";
                    txb_EndIndex.Text = "0";
                }
            }
        }

        private void buttonMovePath1_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            //Start continuous interpolation motion (Path).
            Result = Motion.mAcm_GpMovePath(m_GpHand, IntPtr.Zero);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Path move failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }            
        }

        private void buttonLoadPath_Click(object sender, EventArgs e)
        {
            UInt32 Result;
	        //IntPtr PathHand = new IntPtr();
	        UInt32 PathCnt = new UInt32();
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            if (LoadPathopenFileDialog.ShowDialog() != DialogResult.OK)
				return;
			string strFilePath=LoadPathopenFileDialog.FileName;
            //Load path data from path file. It can load up to 600 path data one  time.
            Result = Motion.mAcm_GpLoadPath(m_GpHand, strFilePath, ref PathHand, ref PathCnt);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
            else//success
            {                
                PATH_INFO pathInfo = new PATH_INFO();
                pathInfo.PathCnt = PathCnt;
                pathInfo.PathHandle = PathHand;
                pathInfo.PathFileName = strFilePath;
                PathInfoList.Add(pathInfo);                
                comboBoxPathFiles.SelectedIndex = comboBoxPathFiles.Items.Add(strFilePath);
                textBoxPathCnt.Text = Convert.ToString(PathCnt, 10);

            }
        }
        private void buttonUnloadPath_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            int index=0;
            bool isFind = false;
            string strTemp;
            //IntPtr PathHandle = new IntPtr();

            if (m_bInit != true)
            {
                return;
            }
            foreach (PATH_INFO pathInf in PathInfoList)
            {
                if (pathInf.PathFileName == comboBoxPathFiles.Text)
                {
                    PathHand = pathInf.PathHandle;
                    //Unload path data.
                    Result = Motion.mAcm_GpUnloadPath(m_GpHand, ref PathHand);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Unload path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    else
                    {
                        comboBoxPathFiles.Items.Remove(pathInf.PathFileName);
                        comboBoxPathFiles.SelectedIndex = comboBoxPathFiles.Items.Count - 1;
                        if (comboBoxPathFiles.SelectedIndex==-1)
                        {
                            comboBoxPathFiles.Text = "";
                            textBoxPathCnt.Text = "";
                        }                        
                        index = PathInfoList.IndexOf(pathInf);
                        isFind = true;
                        break;
                        
                    }
                }
            }
            if (isFind)
            {
                PathInfoList.RemoveAt(index);
            }
            foreach (PATH_INFO pathInf in PathInfoList)
            {
                if (pathInf.PathFileName == comboBoxPathFiles.Text)
                { textBoxPathCnt.Text = Convert.ToString(pathInf.PathCnt); }
            }

        }

        private void buttonMovePath2_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            PATH_INFO pathInfo;
            IntPtr PathHandle;
            string strTemp = "";
            if (m_bInit != true)
            {
                return;
            }
            pathInfo = PathInfoList.Find(delegate(PATH_INFO p){ return p.PathFileName == comboBoxPathFiles.Text; });
            PathHandle = pathInfo.PathHandle;
            if (PathHandle == IntPtr.Zero)
            {
                MessageBox.Show("Please Load Path File First", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Convert.ToUInt32(txb_blendTime.Text) % 2 != 0)
            {
                MessageBox.Show("Blending Time must be divisible by 2.", "Path", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                return;
            }
            uint BldTime = Convert.ToUInt32(txb_blendTime.Text);
            //Set blending time when add a path into system path buffer.
            //You can also use the old API:Motion.mAcm_SetProperty(m_GpHand, (uint)PropertyID.CFG_GpBldTime, ref BldTime, BufferLength);
            // uint BufferLength;
            // BufferLength = 4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_GpHand, (uint)PropertyID.CFG_GpBldTime, BldTime);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_GpBldTime Property failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            //Start continuous interpolation motion (Path).
            Result = Motion.mAcm_GpMovePath(m_GpHand, PathHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Path move failed with error code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            UInt32 Result;
            double[] CurPos = new double[m_ulAxisCount];
            UInt16[] State = new UInt16[m_ulAxisCount];
            UInt16 GpState = new UInt16();
            uint Index = new uint();
            uint Remain = new uint();
            uint FreeCnt = new uint();
            UInt32 IOStatus = new UInt32();
            uint CurCmd = new uint(); //[dan.yang 2011.06.14]
            if (m_bInit)
            {
                //Get current status of path buffer
                Result = Motion.mAcm_GpGetPathStatus(m_GpHand, ref Index, ref CurCmd, ref Remain, ref FreeCnt);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    textBoxCurIndex.Text = Convert.ToString(Index,10);
                    textBoxFreeCnt.Text = Convert.ToString(FreeCnt,10);
                    textBoxRemain.Text = Convert.ToString(Remain,10);
                    textBoxCurCmd.Text = Convert.ToString(CurCmd, 10);
                }
                for (int i = 0; i < m_ulAxisCount; i++)
                {
                    //Get current command position of the specified axis.
                    Motion.mAcm_AxGetCmdPosition(m_Axishand[i], ref CurPos[i]);
                    dgv_Position.Rows[i].Cells[1].Value = CurPos[i];
                    //Get the axis's current state
                    Motion.mAcm_AxGetState(m_Axishand[i], ref State[i]);
                    dgv_AxisState.Rows[i].Cells[1].Value = ((AxisState)State[i]).ToString();
                }
                if (m_GpHand != IntPtr.Zero)
                {
                    //Get the group's current state
                    Motion.mAcm_GpGetState(m_GpHand, ref GpState);
                    textBoxGpState.Text = ((GroupState)GpState).ToString();

                }
                //Get the motion I/O status of the axis.
                Result = Motion.mAcm_AxGetMotionIO(m_Axishand[CmbAxes.SelectedIndex], ref IOStatus);
                if (Result == (uint)ErrorCode.SUCCESS)
                {
                    GetMotionIOStatus(IOStatus);
                }
            }
        }
        private void GetMotionIOStatus(uint IOStatus)
        {
            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ALM) > 0)//ALM
            {
                pictureBoxALM.BackColor = Color.Red;
            }
            else
            {
                pictureBoxALM.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_ORG) > 0)//ORG
            {
                pictureBoxORG.BackColor = Color.Red;
            }
            else
            {
                pictureBoxORG.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTP) > 0)//+EL
            {
                pictureBoxPosHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxPosHEL.BackColor = Color.Gray;
            }

            if ((IOStatus & (uint)Ax_Motion_IO.AX_MOTION_IO_LMTN) > 0)//-EL
            {
                pictureBoxNegHEL.BackColor = Color.Red;
            }
            else
            {
                pictureBoxNegHEL.BackColor = Color.Gray;
            }
        }
        private void buttonStopPath_Click(object sender, EventArgs e)
        {
            uint Result;
            string strTemp;
            //Command axis in this group to stop immediately without deceleration
            Result = Motion.mAcm_GpStopEmg(m_GpHand);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "The group to stop immediately failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
            return;
        }

        private void buttonClearPath_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            //Clear system path buffer. If there is group executing path, the path
            //motion will be stopped.
            Result = Motion.mAcm_GpResetPath(ref m_GpHand);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Reset Path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void BtnResetCounter_Click(object sender, EventArgs e)
        {
            double cmdPosition = new double();
            cmdPosition = 0;
            if (m_bInit != true)
            {
                return;
            }
            if (m_bInit == true)
            {
                for (uint AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Set command position for the specified axis
                    Motion.mAcm_AxSetCmdPosition(m_Axishand[AxisNum], cmdPosition);
                }
            }            

        }

        private void BtnResetErr_Click(object sender, EventArgs e)
        {
            uint Result;
            UInt16 State = new UInt16();
            string strTemp;
            if (m_bInit == true)
            {
                for (uint AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    ////Reset the axis' state. If the axis is in ErrorStop state, the state will
                    //be changed to Ready after calling this function.
                    Result = Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Reset axis's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
                //Get the group's current state
                Motion.mAcm_GpGetState(m_GpHand, ref State);
                if (State == (UInt16)GroupState.STA_Gp_ErrorStop)
                {
                    //Reset group states
                    Result = Motion.mAcm_GpResetError(m_GpHand);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Reset group's error failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                }
            }  
        }

        private void comboBoxPathFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            PATH_INFO pathInfo;

            pathInfo = PathInfoList.Find(delegate(PATH_INFO p) { return p.PathFileName == comboBoxPathFiles.Text; });

            if (pathInfo.PathHandle != IntPtr.Zero)
            {
                textBoxPathCnt.Text = Convert.ToString(pathInfo.PathCnt);
            }
        }

        private void cbx_Axes_SelectedIndexChanged(object sender, EventArgs e)
        {
            ushort state = 0;
            string strTemp;
            uint Result;
            if (cbx_Axes.GetItemCheckState(cbx_Axes.SelectedIndex) == CheckState.Checked)
            {
            
                //Add an axis to the specified group
                 Result = Motion.mAcm_GpAddAxis(ref m_GpHand, m_Axishand[cbx_Axes.SelectedIndex]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Add Axis To Group Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    cbx_Axes.SetItemCheckState(cbx_Axes.SelectedIndex, CheckState.Unchecked);
                    return;
                }
                motionAxisCount++;
            }
            else
            {
                
                //Remove an axis from the specified group.
                Result = Motion.mAcm_GpRemAxis(m_GpHand, m_Axishand[cbx_Axes.SelectedIndex]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Remove Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    cbx_Axes.SetItemCheckState(cbx_Axes.SelectedIndex, CheckState.Checked);
                    return;
                }
                motionAxisCount--;
            }
        }
        Helix Helixdlg = new Helix();
        private void btn_AddSpiral_Click(object sender, EventArgs e)
        {
            uint Result;
            uint AxisNum = new uint();
            UInt16 MoveCmd;
            double[] CenterArray = new double[3];
            double[] EndArray = new double[8];          
            string strTemp;
            if (Helixdlg.ShowDialog() == DialogResult.OK)
            {
                if (m_bInit != true)
                {
                    return;
                }
                if (motionAxisCount == 3)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel3DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel3DHelixCCW;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs3DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs3DHelixCCW;
                    }

                }
                else if (motionAxisCount == 4)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel4DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel4DHelixCCW;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs4DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs4DHelixCCW;
                    }
                }
                else if (motionAxisCount == 5)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel5DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel5DHelixCCW;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs5DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs5DHelixCCW;
                    }
                }
                else if (motionAxisCount == 6)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel6DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel6DHelixCCW;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs6DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs6DHelixCCW;
                    }
                }
                else if (motionAxisCount == 7)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel7DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel7DHelixCCW;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs7DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs7DHelixCCW;
                    }
                }
                else if (motionAxisCount == 8)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel8DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel8DHelixCCW;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs8DHelixCW;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs8DHelixCCW;
                    }
                }
                else
                {
                    MessageBox.Show("Axis count in group error", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                AxisNum = motionAxisCount;
                CenterArray[0] = Convert.ToDouble(Helixdlg.txb_Cen1.Text);
                CenterArray[1] = Convert.ToDouble(Helixdlg.txb_Cen2.Text);
                CenterArray[2] = Convert.ToDouble(Helixdlg.txb_Cen3.Text);
                EndArray[0] = Convert.ToDouble(Helixdlg.txb_End1.Text);
                EndArray[1] = Convert.ToDouble(Helixdlg.txb_End2.Text);
                EndArray[2] = Convert.ToDouble(Helixdlg.txb_End3.Text);
                EndArray[3] = Convert.ToDouble(Helixdlg.txb_End4.Text);
                EndArray[4] = Convert.ToDouble(Helixdlg.txb_End5.Text);
                EndArray[5] = Convert.ToDouble(Helixdlg.txb_End6.Text);
                EndArray[6] = Convert.ToDouble(Helixdlg.txb_End7.Text);
                EndArray[7] = Convert.ToDouble(Helixdlg.txb_End8.Text);
                //Add an interpolation path to system path buffer,
                Result = Motion.mAcm_GpAddPath(m_GpHand, MoveCmd, 0, GpVelHigh, GpVelLow, EndArray, CenterArray, ref AxisNum);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Add path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (textBoxRemain.Text != "0")
                {
                    CurPathCount = Convert.ToUInt32(textBoxRemain.Text);
                    if (CurPathCount > 0)
                    {
                        txb_StartIndex.Text = "0";
                        txb_EndIndex.Text = Convert.ToString(CurPathCount);
                    }
                }
                else
                {
                    txb_StartIndex.Text = "0";
                    txb_EndIndex.Text = "0";
                }
            }
        }

        private void btn_AddDelay_Click(object sender, EventArgs e)
        {
            uint Result;
            uint AxisNum = new uint();
            string strTemp;
            UInt16 MoveCmd;
            if (m_bInit != true)
            {
                return;
            }
            AxisNum = motionAxisCount;
            MoveCmd = (UInt16)PathCmd.GPDELAY;
            double delayTime = Convert.ToDouble(txb_DelayTime.Text);
            //Add an interpolation path to system path buffer,
            Result = Motion.mAcm_GpAddPath(m_GpHand,MoveCmd, 0, delayTime, 2000, null, null, ref AxisNum);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Add path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            if (textBoxRemain.Text != "0")
            {
                CurPathCount = Convert.ToUInt32(textBoxRemain.Text);
                if (CurPathCount > 0)
                {
                    txb_StartIndex.Text = "0";
                    txb_EndIndex.Text = Convert.ToString(CurPathCount);
                }
            }
            else
            {
                txb_StartIndex.Text = "0";
                txb_EndIndex.Text = "0";
            }
        }

        private void btn_MoveSelectPath_Click(object sender, EventArgs e)
        {

            if (m_bInit != true)
            {
                return;
            }
            uint StartIndex = Convert.ToUInt32(txb_StartIndex.Text);
            uint EndIndex = Convert.ToUInt32(txb_EndIndex.Text);
            byte Repeat = 0;
            uint Result = 0;
            string strTemp;
            if (Convert.ToUInt32(txb_blendTime.Text) % 2 != 0)
            {
                MessageBox.Show("Blending Time must be divisible by 2.", "Path", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                return;
            }
            uint BldTime = Convert.ToUInt32(txb_blendTime.Text);

            //Set blending time when add a path into system path buffer
            //You can also use the old API:Motion.mAcm_SetProperty(m_GpHand, (uint)PropertyID.CFG_GpBldTime, ref PropertyVal, BufferLength);
            // uint BufferLength;
            // BufferLength = 4; buffer size for the property
            Result = Motion.mAcm_SetU32Property(m_GpHand, (uint)PropertyID.CFG_GpBldTime,BldTime);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Set CFG_GpBldTime Property failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            Repeat = Convert.ToByte(txb_Repeat.Text);
            //Move path segment in system path buffer from start index and end index.
            Result = Motion.mAcm_GpMoveSelPath(m_GpHand,PathHand,StartIndex, EndIndex, Repeat);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Move selected path(s) failed with Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
            }
        }

        private void cbx_SpeedForward_CheckedChanged(object sender, EventArgs e)
        {
            uint sfEnable=0;
            uint Result = 0;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            if (cbx_SpeedForward.Checked)
            {
                sfEnable = (uint)SFEnable.SF_EN;
                //Enable  speed forward function
                //You can also use the old API:Motion.mAcm_SetProperty(m_GpHand, (uint)PropertyID.CFG_GpSFEnable, ref sfEnable, BufferLength);
                // uint BufferLength;
                // BufferLength = 4; buffer size for the property
                Result = Motion.mAcm_SetU32Property(m_GpHand, (uint)PropertyID.CFG_GpSFEnable,  sfEnable);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set CFG_GpSFEnable Property failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
            else
            {
                sfEnable = (uint)SFEnable.SF_DIS;
                //DisEnable  speed forward function
                //You can also use the old API:Motion.mAcm_SetProperty(m_GpHand, (uint)PropertyID.CFG_GpSFEnable, ref sfEnable, BufferLength);
                // uint BufferLength;
                // BufferLength = 4; buffer size for the property
                Result = Motion.mAcm_SetU32Property(m_GpHand, (uint)PropertyID.CFG_GpSFEnable,sfEnable);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set CFG_GpSFEnable Property failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                }
            }
        }

        private void btn_AddAglHelix_Click(object sender, EventArgs e)
        {
            uint Result;
            uint AxisNum = new uint();
            UInt16 MoveCmd;
            double[] CenterArray = new double[3];
            double[] EndArray = new double[8];
            string strTemp;
            if (Helixdlg.ShowDialog() == DialogResult.OK)
            {
                if (m_bInit != true)
                {
                    return;
                }
                if (motionAxisCount == 3)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel3DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel3DHelixCCWAngle;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs3DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs3DHelixCCWAngle;
                    }

                }
                else if (motionAxisCount == 4)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel4DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel4DHelixCCWAngle;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs4DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs4DHelixCCWAngle;
                    }
                }
                else if (motionAxisCount == 5)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel5DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel5DHelixCCWAngle;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs5DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs5DHelixCCWAngle;
                    }
                }
                else if (motionAxisCount == 6)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel6DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel6DHelixCCWAngle;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs6DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs6DHelixCCWAngle;
                    }
                }
                else if (motionAxisCount == 7)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel7DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel7DHelixCCWAngle;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs7DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs7DHelixCCWAngle;
                    }
                }
                else if (motionAxisCount == 8)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel8DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel8DHelixCCWAngle;
                    }
                    else//Abs
                    {
                        if (Helixdlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs8DHelixCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs8DHelixCCWAngle;
                    }
                }
                else
                {
                    MessageBox.Show("Axis count in group error", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                AxisNum = motionAxisCount;
                CenterArray[0] = Convert.ToDouble(Helixdlg.txb_Cen1.Text);
                CenterArray[1] = Convert.ToDouble(Helixdlg.txb_Cen2.Text);
                CenterArray[2] = Convert.ToDouble(Helixdlg.txb_Cen3.Text);
                EndArray[0] = Convert.ToDouble(Helixdlg.txb_Agl1.Text);
                EndArray[1] = Convert.ToDouble(Helixdlg.txb_Agl2.Text);
                EndArray[2] = Convert.ToDouble(Helixdlg.txb_End3.Text);
                EndArray[3] = Convert.ToDouble(Helixdlg.txb_End4.Text);
                EndArray[4] = Convert.ToDouble(Helixdlg.txb_End5.Text);
                EndArray[5] = Convert.ToDouble(Helixdlg.txb_End6.Text);
                EndArray[6] = Convert.ToDouble(Helixdlg.txb_End7.Text);
                EndArray[7] = Convert.ToDouble(Helixdlg.txb_End8.Text);
                //Add an interpolation path to system path buffer
                Result = Motion.mAcm_GpAddPath(m_GpHand, MoveCmd, 0, GpVelHigh, GpVelLow, EndArray, CenterArray, ref AxisNum);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Add path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (textBoxRemain.Text != "0")
                {
                    CurPathCount = Convert.ToUInt32(textBoxRemain.Text);
                    if (CurPathCount > 0)
                    {
                        txb_StartIndex.Text = "0";
                        txb_EndIndex.Text = Convert.ToString(CurPathCount);
                    }
                }
                else
                {
                    txb_StartIndex.Text = "0";
                    txb_EndIndex.Text = "0";
                }
            }
        }
        
        private void btn_AddAglArc_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            UInt16 MoveCmd;
            double[] EndPoint_DataArray = new double[3];
            double[] CenPoint_DataArray = new double[3];
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                if (motionAxisCount >= 2)
                {
                    if (radioButtonRel.Checked)//Rel
                    {
                        if (dlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Rel2DArcCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Rel2DArcCCWAngle;
                    }
                    else//Abs
                    {
                        if (dlg.radioButtonCW.Checked)//CW
                        {
                            MoveCmd = (UInt16)PathCmd.Abs2DArcCWAngle;
                        }
                        else
                            MoveCmd = (UInt16)PathCmd.Abs2DArcCCWAngle;
                    }

                }
                else
                {
                    MessageBox.Show("Axis count in group error", "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                EndPoint_DataArray[0] = Convert.ToDouble(dlg.txb_Agl.Text);
                EndPoint_DataArray[1] = Convert.ToDouble(dlg.txb_Agl.Text);
                EndPoint_DataArray[2] = 0; 
                CenPoint_DataArray[0] = Convert.ToDouble(dlg.textBoxCen1.Text); 
                CenPoint_DataArray[1] = Convert.ToDouble(dlg.textBoxCen2.Text);
                CenPoint_DataArray[2] =0;
                //Add an interpolation path to system path buffer
                Result = Motion.mAcm_GpAddPath(m_GpHand, MoveCmd, 0, GpVelHigh, GpVelLow, EndPoint_DataArray, CenPoint_DataArray, ref  motionAxisCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Add path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (textBoxRemain.Text != "0")
                {
                    CurPathCount = Convert.ToUInt32(textBoxRemain.Text);
                    if (CurPathCount > 0)
                    {
                        txb_StartIndex.Text = "0";
                        txb_EndIndex.Text = Convert.ToString(CurPathCount);
                    }
                }
                else
                {
                    txb_StartIndex.Text = "0";
                    txb_EndIndex.Text = "0";
                }
            }
        }

        private void BtnOpenBoard_Click(object sender, EventArgs e)
        {
            uint Result;
            int i = 0;
            uint[] slaveDevs = new uint[16];
            uint AxesPerDev = new uint();
            string strTemp;
            //Open a specified device to get device handle
            //you can call GetDevNum() API to get the devcie number of fixed equipment in this,as follow
            //DeviceNum = GetDevNum((uint)DevTypeID.PCI1285, 15, 0, 0);
            Result = Motion.mAcm_DevOpen(DeviceNum, ref m_DeviceHandle);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Open Device Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            //FT_DevAxesCount:Get axis number of this device.
            //if you device is fixed(for example: PCI-1245),You can not get FT_DevAxesCount property value
            //This step is not necessary
            //You can also use the old API: Motion.mAcm_GetProperty(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev, ref BufferLength);
            // UInt32 BufferLength;
            //BufferLength =4;  buffer size for the property
            Result = Motion.mAcm_GetU32Property(m_DeviceHandle, (uint)PropertyID.FT_DevAxesCount, ref AxesPerDev);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get Axis Number Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            m_ulAxisCount = AxesPerDev;
            cbx_Axes.Items.Clear();
            dgv_Position.Rows.Clear();
            dgv_AxisState.Rows.Clear();
            dgv_Position.Height = dgv_Position.ColumnHeadersHeight;
            dgv_AxisState.Height = dgv_AxisState.ColumnHeadersHeight;
            //if you device is fixed,for example: PCI-1245 m_ulAxisCount =4
            for (i = 0; i < m_ulAxisCount; i++)
            {
                //Open every Axis and get the each Axis Handle
                //And Initial property for each Axis 		
                //Open Axis 
                Result = Motion.mAcm_AxOpen(m_DeviceHandle, (UInt16)i, ref m_Axishand[i]);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Open Axis Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                cbx_Axes.Items.Add(String.Format("{0:d}-Axis", i));
                CmbAxes.Items.Add(String.Format("Axis {0:d}", i));
                double cmdPosition = new double();
                cmdPosition = 0;
                //Set command position for the specified axis
                Motion.mAcm_AxSetCmdPosition(m_Axishand[i], cmdPosition);
                dgv_Position.Rows.Add();
                dgv_Position.Height = dgv_Position.Height + dgv_Position.Rows[i].Height;
                dgv_Position.Rows[i].Cells[0].Value = String.Format("{0:d}-Axis", i);
                dgv_Position.Rows[i].Cells[1].Value = 0;
                dgv_Position.Rows[i].DefaultCellStyle.BackColor = Color.LightGray;

                dgv_AxisState.Rows.Add();
                dgv_AxisState.Height = dgv_AxisState.Height + dgv_AxisState.Rows[i].Height;
                dgv_AxisState.Rows[i].Cells[0].Value = String.Format("{0:d}-Axis", i);
                dgv_AxisState.Rows[i].DefaultCellStyle.BackColor = Color.LightGray;
            }
            CmbAxes.SelectedIndex = 0;
            if (dgv_Position.Height >= 130)
                dgv_Position.Height = 130;
            else
                dgv_Position.Height = dgv_Position.Height + 3;
            if (dgv_AxisState.Height >= 130)
                dgv_AxisState.Height = 130;
            else
                dgv_AxisState.Height = dgv_AxisState.Height + 3;
            m_bInit = true;
            timer1.Enabled = true;
            motionAxisCount = 0;
        }

        private void BtnServo_Click(object sender, EventArgs e)
        {
            UInt32 AxisNum;
            UInt32 Result;
            string strTemp;
            //Check the servoOno flag to decide if turn on or turn off the ServoOn output.
            if (m_bInit != true)
            {
                return;
            }
            if (m_bServoOn == false)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver ON,1: On
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 1);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo On Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = true;
                    BtnServo.Text = "Servo Off";
                }
            }
            else
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    // Set servo Driver OFF,0: Off
                    Result = Motion.mAcm_AxSetSvOn(m_Axishand[AxisNum], 0);
                    if (Result != (uint)ErrorCode.SUCCESS)
                    {
                        strTemp = "Servo Off Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                        ShowMessages(strTemp, Result);
                        return;
                    }
                    m_bServoOn = false;
                    BtnServo.Text = "Servo On";
                }
            }
        }

        private void BtnCloseBoard_Click(object sender, EventArgs e)
        {
            CloseBoardOrForm();
        }
        //User-defined API to show error message
        private void ShowMessages(string DetailMessage, uint errorCode)
        {
            StringBuilder ErrorMsg = new StringBuilder("", 100);
            //Get the error message according to error code returned from API
            Boolean res = Motion.mAcm_GetErrorMessage(errorCode, ErrorMsg, 100);
            string ErrorMessage = "";
            if (res)
                ErrorMessage = ErrorMsg.ToString();
            MessageBox.Show(DetailMessage + "\r\nError Message:" + ErrorMessage, "AIO", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
       //User-defined API to close board
        private void CloseBoardOrForm()
        {
            UInt16[] usAxisState = new UInt16[32];
            uint AxisNum;
            //Stop Every Axes
            if (m_bInit == true)
            {
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Get the axis's current state
                    Motion.mAcm_AxGetState(m_Axishand[AxisNum], ref usAxisState[AxisNum]);
                    if (usAxisState[AxisNum] == (uint)AxisState.STA_AX_ERROR_STOP)
                    {
                        // Reset the axis' state. If the axis is in ErrorStop state, the state will be changed to Ready after calling this function
                        Motion.mAcm_AxResetError(m_Axishand[AxisNum]);
                    }
                    //To command axis to decelerate to stop.
                    Motion.mAcm_AxStopDec(m_Axishand[AxisNum]);
                }
                //Remove all axis in the group and close the group handle
                Motion.mAcm_GpClose(ref m_GpHand);
                m_GpHand = IntPtr.Zero;               
                for (AxisNum = 0; AxisNum < m_ulAxisCount; AxisNum++)
                {
                    //Close Axes
                    Motion.mAcm_AxClose(ref m_Axishand[AxisNum]);
                }
                m_ulAxisCount = 0;
                AxCountInGp = 0;
                //Close Device
                Motion.mAcm_DevClose(ref m_DeviceHandle);
                m_DeviceHandle = IntPtr.Zero;
                timer1.Enabled = false;
                m_bInit = false;
                cbx_Axes.Items.Clear();
                CmbAxes.Items.Clear();
                 motionAxisCount = 0;
                dgv_Position.Rows.Clear();
                dgv_AxisState.Rows.Clear();
                textBoxGpState.Clear();
                //  listBoxEndPoints.Items.Clear();
                EndPointNum = 0;
            }
        }

        private void buttonLoadCfg_Click(object sender, EventArgs e)
        {
            UInt32 Result;
            string strTemp;
            if (m_bInit != true)
            {
                return;
            }
            this.OpenConfigFile.FileName = ".cfg";
            if (OpenConfigFile.ShowDialog() != DialogResult.OK)
                return;
            //Set all configurations for the device according to the loaded file
            Result = Motion.mAcm_DevLoadConfig(m_DeviceHandle, OpenConfigFile.FileName);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Load Config Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }		 
        }
        FormGroupParamSet formgroupparamset = new FormGroupParamSet();
        
        private void GetGroupVelocityParam()
        {
            UInt32 Result;
            string strTemp;
            // FormGroupParamSet formgroupparamset = new FormGroupParamSet();
            // Get low velocity (start velocity) of this group (Unit: PPU/s). 
            //You can also use the old API:  Motion.mAcm_GetProperty(m_GpHand,(uint)PropertyID.PAR_GpVelLow, ref GpVelLow,ref BufferLen);
            //uint BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_GpHand, (uint)PropertyID.PAR_GpVelLow, ref GpVelLow);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get PAR_GpVelLow Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formgroupparamset.txt_VelLow.Text = Convert.ToString(GpVelLow);
            // Get high velocity (driving velocity) of this group (Unit: PPU/s).
            //You can also use the old API:  Motion.mAcm_GetProperty(m_GpHand,(uint)PropertyID.PAR_GpVelHigh, ref GpVelHigh,ref BufferLen);
            //uint BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_GpHand, (uint)PropertyID.PAR_GpVelHigh, ref GpVelHigh);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get PAR_GpVelHigh Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formgroupparamset.txt_VelHigh.Text = Convert.ToString(GpVelHigh);
            //Get acceleration of this group (Unit: PPU/s2).
            //You can also use the old API:  Motion.mAcm_GetProperty(m_GpHand,(uint)PropertyID.PAR_GpAcc, ref GpAcc,ref BufferLen);
            //uint BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_GpHand, (uint)PropertyID.PAR_GpAcc, ref GpAcc);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get PAR_GpAcc Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formgroupparamset.txt_Acc.Text = Convert.ToString(GpAcc);
            //Get deceleration of this group (Unit: PPU/s2).
            //You can also use the old API:  Motion.mAcm_GetProperty(m_GpHand,(uint)PropertyID.PAR_GpAcc, ref GpDec,ref BufferLen);
            //uint BufferLength;
            //BufferLength =8; buffer size for the property
            Result = Motion.mAcm_GetF64Property(m_GpHand, (uint)PropertyID.PAR_GpAcc, ref GpDec);
            if (Result != (uint)ErrorCode.SUCCESS)
            {
                strTemp = "Get PAR_GpAcc Property Failed With Error Code: [0x" + Convert.ToString(Result, 16) + "]";
                ShowMessages(strTemp, Result);
                return;
            }
            formgroupparamset.txt_Dec.Text = Convert.ToString(GpDec);
        }
        private void CmbAvailableDevice_SelectedIndexChanged(object sender, EventArgs e)
        {
            DeviceNum = CurAvailableDevs[CmbAvailableDevice.SelectedIndex].DeviceNum;
        }

        
        Form3DARC arc3Darc = new Form3DARC();
        private void Btn3dParam_Click(object sender, EventArgs e)
        {
            arc3Darc.ShowDialog(null);
        }
        private Boolean GetDevCfgDllDrvVer()
        {
            string fileName = "";
            FileVersionInfo myFileVersionInfo;
            string FileVersion = "";
            fileName = Environment.SystemDirectory + "\\ADVMOT.dll";//SystemDirectory指System32 
            myFileVersionInfo = FileVersionInfo.GetVersionInfo(fileName);
            FileVersion = myFileVersionInfo.FileVersion;
            string DetailMessage;
            string[] strSplit = FileVersion.Split(',');
            if (Convert.ToUInt16(strSplit[0]) < 2)
            {

                DetailMessage = "The Driver Version  Is Too Low" + "\r\nYou can update the driver through the driver installation package ";
                DetailMessage = DetailMessage + "\r\nThe Current Driver Version Number is " + FileVersion;
                DetailMessage = DetailMessage + "\r\nYou need to update the driver to 2.0.0.0 version and above";
                MessageBox.Show(DetailMessage, "Path", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private void button3Darc_Click(object sender, EventArgs e)
        {
            uint Result;
            ushort MoveCmd;
            double[] EndArray = new double[4];
            double[] CenterArray = new double[3];
            uint AxisNum = AxCountInGp;
            String strTemp;                 
            if (arc3Darc.ShowDialog() == DialogResult.OK)
            {
                CenterArray[0] = Convert.ToDouble(arc3Darc.textBoxCen1.Text);
                CenterArray[1] = Convert.ToDouble(arc3Darc.textBoxCen2.Text);
                CenterArray[2] = Convert.ToDouble(arc3Darc.textBoxCen3.Text);
                EndArray[0] = Convert.ToDouble(arc3Darc.textBoxEnd1.Text);
                EndArray[1] = Convert.ToDouble(arc3Darc.textBoxEnd2.Text);
                EndArray[2] = Convert.ToDouble(arc3Darc.textBoxEnd3.Text);
                EndArray[3] = Convert.ToDouble(arc3Darc.textBoxAgl.Text);
                if (arc3Darc.radioButtonCen.Checked)
                {
                    if (radioButtonRel.Checked)
                    {
                        if (arc3Darc.radioButtonCW.Checked)
                        {
                            MoveCmd = (UInt16)PathCmd.Rel3DArcCW;
                        }
                        else
                        {
                            MoveCmd = (UInt16)PathCmd.Rel3DArcCCW;
                        }
                    }
                    else
                    {
                        if (arc3Darc.radioButtonCW.Checked)
                        {
                            MoveCmd = (UInt16)PathCmd.Abs3DArcCW;
                        }
                        else
                        {
                            MoveCmd = (UInt16)PathCmd.Abs3DArcCCW;
                        }
                    }
                }
                else
                {
                    if (radioButtonRel.Checked)
                    {
                        if (arc3Darc.radioButtonCW.Checked)
                        {
                            MoveCmd = (UInt16)PathCmd.Rel3DArcCWAngle;
                        }
                        else
                        {
                            MoveCmd = (UInt16)PathCmd.Rel3DArcCCWAngle;
                        }
                    }
                    else
                    {
                        if (arc3Darc.radioButtonCW.Checked)
                        {
                            MoveCmd = (UInt16)PathCmd.Abs3DArcCWAngle;
                        }
                        else
                        {
                            MoveCmd = (UInt16)PathCmd.Abs3DArcCCWAngle;
                        }
                    }
                }
                //Add an interpolation path to system path buffer
                Result = Motion.mAcm_GpAddPath(m_GpHand, MoveCmd, 0, GpVelHigh, GpVelLow, EndArray, CenterArray, ref motionAxisCount);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Add path failed with Error Code[0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }
        double GpVelLow = 2000;
        double GpVelHigh = 8000;
        double GpAcc = 10000;
        double GpDec = 10000;
        private void btn_SetParam_Click(object sender, EventArgs e)
        {
            UInt32 Result;
           
            double GpJerk;
            string strTemp;
            GetGroupVelocityParam();
            if (formgroupparamset.ShowDialog() == DialogResult.OK)
            {
                GpVelLow = Convert.ToDouble(formgroupparamset.txt_VelLow.Text);
                // Set low velocity (start velocity) of this group (Unit: PPU/s). 
                // This property value must be smaller than or equal to Par_GpVelHigh .
                // The default value is the first added axis' PAR_AxVelLow
                //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpVelLow,ref GpVelLow,BufferLength)
                //uint BufferLength;
                //BufferLength =8; buffer size for the property
                Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpVelLow, GpVelLow);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set PAR_GpVelLow Property Failed: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                GpVelHigh = Convert.ToDouble(formgroupparamset.txt_VelHigh.Text);
                //Set high velocity (driving velocity) of this group (Unit: PPU/s).
                //This property value must be smaller than first added axis'
                //CFG_AxMaxVel and greater than Par_GpVelLow. The default value is the first added axis' PAR_AxVelHigh
                //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpVelHigh,ref  GpVelHigh,BufferLength)
                //uint BufferLength;
                //BufferLength =8; buffer size for the property
                Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpVelHigh, GpVelHigh);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set PAR_GpVelHigh Property Failed: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                GpAcc = Convert.ToDouble(formgroupparamset.txt_Acc.Text);
                //Set acceleration of this group (Unit: PPU/s2). This property value
                //must be smaller than or equal to first added axis' CFG_AxMaxAcc.
                //The default value is the first added axis' PAR_AxAcc.    
                //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpAcc,ref GpAcc,BufferLength)
                //uint BufferLength;
                //BufferLength =8; buffer size for the property
                Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpAcc, GpAcc);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set PAR_GpAcc Property Failed: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                GpDec = Convert.ToDouble(formgroupparamset.txt_Dec.Text);
                //Set deceleration of this group (Unit: PPU/s2). This property value
                //must be smaller than or equal to first added axis' CFG_AxMaxDec.
                //The default value is the first added axis' PAR_AxDec
                //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpDec,ref GpDec,BufferLength)
                //uint BufferLength;
                //BufferLength =8; buffer size for the property
                Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpDec, GpDec);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set PAR_GpDec Property Failed: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
                if (formgroupparamset.rdb_T.Checked)
                {
                    GpJerk = 0;
                }
                else
                {
                    GpJerk = 1;
                }
                //Set the type of velocity profile: t-curve or s-curve
                //You  can also use the old API:Motion.mAcm_SetProperty(m_GpHand,(uint)PropertyID.PAR_GpJerk,ref GpJerk,BufferLength)
                //uint BufferLength;
                //BufferLength =8; buffer size for the property
                Result = Motion.mAcm_SetF64Property(m_GpHand, (uint)PropertyID.PAR_GpJerk, GpJerk);
                if (Result != (uint)ErrorCode.SUCCESS)
                {
                    strTemp = "Set PAR_GpJerk Property Failed: [0x" + Convert.ToString(Result, 16) + "]";
                    ShowMessages(strTemp, Result);
                    return;
                }
            }
        }

    }
}