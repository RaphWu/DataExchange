using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Path
{
    public partial class Helix : Form
    {
        public Helix()
        {
            InitializeComponent();
        }

        private void Helix_Load(object sender, EventArgs e)
        {
            this.AcceptButton = this.btn_OK;
            this.CancelButton = this.btn_Cancel;
            this.btn_OK.DialogResult = DialogResult.OK;
            this.btn_Cancel.DialogResult = DialogResult.Cancel;
        }
    }
}