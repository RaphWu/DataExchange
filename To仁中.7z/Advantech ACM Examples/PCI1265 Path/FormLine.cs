using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Path
{
    public partial class FormLine : Form
    {
        public FormLine()
        {
            InitializeComponent();
        }
       

        private void BtnSetEnd_Click(object sender, EventArgs e)
        {
            
            if (EndPointNum < 32)
            {
               EndArray[EndPointNum] = Convert.ToDouble(textBoxEnd.Text);
                listBoxEndPoints.Items.Add(textBoxEnd.Text);
                EndPointNum++;
            }
        }

        private void BtnClearEnd_Click(object sender, EventArgs e)
        {
            
            for (uint i = 0; i < 32; i++)
            {
                EndArray[i] = 0;
            }
            listBoxEndPoints.Items.Clear();
           EndPointNum = 0;
        
        }

        private void FormLine_Load(object sender, EventArgs e)
        {
            EndPointNum = 0;
        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}