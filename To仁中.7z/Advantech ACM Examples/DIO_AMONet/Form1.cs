﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Advantech.Motion;//Common Motion API
using System.Threading;

namespace DIO_AMONet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboMasterType.SelectedIndex = 0;
            cboMasterBID.SelectedIndex = 0;
            cboRingNo.SelectedIndex = 0;
            IsMasOpen = false;
            IsRingOpen[0] = false;
            IsRingOpen[1] = false;
            
            // set master device number:SlaveBoardID = 0;MasterRingNo = 0xF;MasterBoardID = 0;MasterDevType = Adv_PCI1202;
            //             typedef union _ACM_DEV_NUM
            // {
            //     ULONG  data;
            //     struct {
            // 		ULONG    SlaveBoardID  : 8;
            // 		ULONG    MasterRingNo  : 4;
            // 		ULONG    MasterBoardID : 12;
            // 		ULONG    MasterDevType : 8;	
            //     } u;
            // }ACM_DEV_NUM, *PACM_DEV_NUM;
            MasDevNum = (uint)(DevTypeID.PCI1202);
            MasDevNum = (MasDevNum << 24) + (15 << 8);



        }

        private void buttonMasterInit_Click(object sender, EventArgs e)
        {
            UInt32 ret;
            UInt32 data_size = 32;
            UInt32 rate = new UInt32();

            ret = Motion.mAcm_DevOpen(MasDevNum, ref hDevMaster);
            if (ret != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Master device doesn't  exist!", "DIO_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            rate = (uint)Baudrate.BR_AMONET_20M; 
            ret = Motion.mAcm_SetProperty(hDevMaster, (uint)PropertyID.CFG_MasBaudRate_R0, ref rate, data_size);

            IsMasOpen = true;
            cboMasterType.Enabled =false;
            cboMasterBID.Enabled = false;
            
            timer1.Enabled = true;
            

        }

        private void buttonStartRing_Click(object sender, EventArgs e)
        {
            uint ret;
            ushort MasStatus = new ushort();
            UInt16		SlaveIP;
	        bool	Active;
            UInt32[] ActTableArray = new UInt32[2];	
            UInt32 array_count=2;
            UInt32 SlvDevNum;
            UInt32 Info=new UInt32();
            int max_wait_count = 1000;
            ActTableArray[0] = 0;
            ActTableArray[1] = 0;

            //////////////////////////////////////////////////////////////////////////
            // start ring communication
            //////////////////////////////////////////////////////////////////////////
            ret = Motion.mAcm_MasStartRing(hDevMaster, RingNo);
            if (ret != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Start Ring error!", "DIO_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // check master status
            do
            {
                Thread.Sleep(1);
                ret = Motion.mAcm_MasGetComStatus(hDevMaster, RingNo, ref MasStatus);
                if (ret != (int)ErrorCode.SUCCESS || MasStatus == (ushort)ComStatus.COM_ST_CONNECTED || MasStatus == (ushort)ComStatus.COM_ST_ERROR)
                    break;
            } while ((max_wait_count--)>0);

            if (MasStatus != (ushort)ComStatus.COM_ST_CONNECTED)
            {
                MessageBox.Show("Start Ring failed!", "DIO_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            IsRingOpen[RingNo] = true;
            cboRingNo.Enabled = false;

	      // show active device	           
            ret = Motion.mAcm_MasGetActiveTable(hDevMaster, RingNo, ActTableArray, ref array_count);
           
            textBoxActTabHI.Text = Convert.ToString(ActTableArray[1]);
            textBoxActTabLO.Text = Convert.ToString(ActTableArray[0]);
            //////////////////////////////////////////////////////////////////////////
            // Open all slave DIO device
            //////////////////////////////////////////////////////////////////////////
//            memset(hDevSlave, NULL, sizeof(uint) * 64);		// reset all slave handle
            for (SlaveIP = 0; SlaveIP < 64; SlaveIP++)
            {
                // Check slave device exists or not
                Active = false;
                if (SlaveIP < 32)
                {
                    if ((ActTableArray[0] & (0x01 << SlaveIP)) > 0)
                        Active = true;
                }
                else
                {
                    if ((ActTableArray[1] & (0x01 << (SlaveIP - 32))) > 0)
                        Active = true;
                }

                // If device exists, open it
                if (Active)
                {
                    ret = Motion.mAcm_MasGetSlaveInfo(hDevMaster, RingNo, SlaveIP, ref Info);
                    if (ret != (int)ErrorCode.SUCCESS)
                    {
                        MessageBox.Show("GetSlaveInfo failed!", "DIO_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    // Only open IO device
                    if (Info != (UInt32)DevTypeID.AMAX2752 && Info != (UInt32)DevTypeID.AMAX2754 && Info != (UInt32)DevTypeID.AMAX2756)
                        continue;

                    // make slave device number and open it
                    SlvDevNum = (UInt32)(MasDevNum & 0xfffff000 + (RingNo << 8) + SlaveIP);
                    ret = Motion.mAcm_DevOpen(SlvDevNum, ref hDevSlave[RingNo][SlaveIP]);
                    if (ret != (int)ErrorCode.SUCCESS)
                    {
                        MessageBox.Show("Slave device [" + Convert.ToString(SlaveIP, 10) + "] doesn't exist!(Err=" + Convert.ToString(ret, 16) + "h)!", "DIO_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }	

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ushort RingStatus = new ushort();
            UInt32[] ActTableArray = new UInt32[2];
            UInt32 array_count = 2;
            UInt32 ret;
            string strInfo = "";


            // master 
            ret = Motion.mAcm_MasGetComStatus(hDevMaster, RingNo, ref RingStatus);
            ret = Motion.mAcm_MasGetActiveTable(hDevMaster, RingNo, ActTableArray, ref array_count);
            switch (RingStatus)
            {
                case (ushort)COM_STATE.COM_ST_DISCONNECTED: strInfo = "Ring Disconnected"; break;
                case (ushort)COM_STATE.COM_ST_CONNECTED: strInfo = "Ring Connected"; break;
                case (ushort)COM_STATE.COM_ST_SLAVE_ERROR: strInfo = "Slave error"; break;
                case (ushort)COM_STATE.COM_ST_BUSY: strInfo = "Ring busy"; break;
                case (ushort)COM_STATE.COM_ST_ERROR: strInfo = "Ring error"; break;
            }


            textBoxRingState.Text = strInfo;

            textBoxActTabHI.Text = Convert.ToString(ActTableArray[1]);
            textBoxActTabLO.Text = Convert.ToString(ActTableArray[0]);
        }

        private void buttonWrite_Click(object sender, EventArgs e)
        {
            UInt32 ret;
            UInt16 SlaveIP, PortNo;
            Byte value = new byte();

            SlaveIP = Convert.ToUInt16(textBoxDeviceIP.Text);
            PortNo = Convert.ToUInt16(textBoxPort.Text);
            value = (byte)Convert.ToUInt16(textBoxWriteByte.Text);
            ret = Motion.mAcm_DaqDoSetByte(hDevSlave[RingNo][SlaveIP], PortNo, value);

            if (ret != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Write DO failed! ErrCode =" + Convert.ToString(ret, 16) + "h)!", "DIO_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonRead_Click(object sender, EventArgs e)
        {
            
            
            UInt32 ret;
            UInt16 SlaveIP, PortNo;
            Byte value = new byte();

            SlaveIP = Convert.ToUInt16(textBoxDeviceIP.Text);
            PortNo = Convert.ToUInt16(textBoxPort.Text);
            ret = Motion.mAcm_DaqDiGetByte(hDevSlave[RingNo][SlaveIP], PortNo, ref value);

            if (ret != (int)ErrorCode.SUCCESS)
            {
                MessageBox.Show("Read DI failed! ErrCode =" + Convert.ToString(ret, 16) + "h)!", "DIO_AMONet", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            textBoxReadByte.Text = Convert.ToString(value);
        }

        private void cboRingNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            RingNo = (UInt16)(cboRingNo.SelectedIndex);
        }

        private void cboMasterType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // set master device number:SlaveBoardID = 0;MasterRingNo = 0xF;MasterBoardID = 0;MasterDevType = Adv_PCI1202;
            //             typedef union _ACM_DEV_NUM
            // {
            //     ULONG  data;
            //     struct {
            // 		ULONG    SlaveBoardID  : 8;
            // 		ULONG    MasterRingNo  : 4;
            // 		ULONG    MasterBoardID : 12;
            // 		ULONG    MasterDevType : 8;	
            //     } u;
            // }ACM_DEV_NUM, *PACM_DEV_NUM;
            if (cboMasterType.SelectedText == "PCI-1202")
            {
                MasDevNum = MasDevNum & 0xff000000 + (uint)(DevTypeID.PCI1202) << 24;
            }
            else if (cboMasterType.SelectedText == "APAX5202")
            {
                MasDevNum = MasDevNum & 0xff000000 + (uint)(DevTypeID.ADAM5202) << 24;
            }
            else
            {
                MasDevNum = MasDevNum & 0xff000000 + (uint)(DevTypeID.PCM3202) << 24;
            }
        }

        private void cboMasterBID_SelectedIndexChanged(object sender, EventArgs e)
        {
            // set master device number:SlaveBoardID = 0;MasterRingNo = 0xF;MasterBoardID = 0;MasterDevType = Adv_PCI1202;
            //             typedef union _ACM_DEV_NUM
            // {
            //     ULONG  data;
            //     struct {
            // 		ULONG    SlaveBoardID  : 8;
            // 		ULONG    MasterRingNo  : 4;
            // 		ULONG    MasterBoardID : 12;
            // 		ULONG    MasterDevType : 8;	
            //     } u;
            // }ACM_DEV_NUM, *PACM_DEV_NUM;
            UInt16 BID;
            BID = (UInt16)cboMasterBID.SelectedIndex;
            MasDevNum = (uint)((MasDevNum & 0xff000fff) + (BID << 12));
        }

       
    }
}