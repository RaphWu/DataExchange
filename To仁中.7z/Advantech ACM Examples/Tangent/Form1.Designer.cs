﻿using Advantech.Motion;//Common Motion API
using System;
namespace Tangent
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cmb_Axis = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txb_ModuleRange = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.rdo_Opposite = new System.Windows.Forms.RadioButton();
            this.rdo_Same = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.txb_ZPos = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.txb_YPos = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.txb_XPos = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.btn_TangentIn = new System.Windows.Forms.Button();
            this.btn_TangentStop = new System.Windows.Forms.Button();
            this.OpenConfigFile = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_ResetCounter = new System.Windows.Forms.Button();
            this.btn_ResetError = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rdo_Spiral = new System.Windows.Forms.RadioButton();
            this.rdo_Arc = new System.Windows.Forms.RadioButton();
            this.rdo_Line = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButtonRel = new System.Windows.Forms.RadioButton();
            this.radioButtonAbs = new System.Windows.Forms.RadioButton();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.rdo_CCW = new System.Windows.Forms.RadioButton();
            this.rdo_CW = new System.Windows.Forms.RadioButton();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.rdo_XZPlane = new System.Windows.Forms.RadioButton();
            this.rdo_YZPlane = new System.Windows.Forms.RadioButton();
            this.rdo_XYPlane = new System.Windows.Forms.RadioButton();
            this.btn_Move = new System.Windows.Forms.Button();
            this.btn_GroupStop = new System.Windows.Forms.Button();
            this.dgv_Ends = new System.Windows.Forms.DataGridView();
            this.Axes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LineEndValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ArcCenterValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ArcEndValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label74 = new System.Windows.Forms.Label();
            this.cbx_Axes = new System.Windows.Forms.CheckedListBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.dgv_Position = new System.Windows.Forms.DataGridView();
            this.Position = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_MasterAxisState = new System.Windows.Forms.TextBox();
            this.txb_GroupState = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.buttonLoadCfg = new System.Windows.Forms.Button();
            this.BtnServo = new System.Windows.Forms.Button();
            this.BtnCloseBoard = new System.Windows.Forms.Button();
            this.BtnOpenBoard = new System.Windows.Forms.Button();
            this.CmbAvailableDevice = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxNegHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxPosHEL = new System.Windows.Forms.PictureBox();
            this.pictureBoxORG = new System.Windows.Forms.PictureBox();
            this.pictureBoxALM = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Ends)).BeginInit();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Position)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).BeginInit();
            this.SuspendLayout();
            // 
            // cmb_Axis
            // 
            this.cmb_Axis.FormattingEnabled = true;
            this.cmb_Axis.Location = new System.Drawing.Point(126, 18);
            this.cmb_Axis.Name = "cmb_Axis";
            this.cmb_Axis.Size = new System.Drawing.Size(174, 20);
            this.cmb_Axis.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(88, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 20;
            this.label2.Text = "Axis:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txb_ModuleRange);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.groupBox18);
            this.groupBox1.Controls.Add(this.groupBox17);
            this.groupBox1.Controls.Add(this.btn_TangentIn);
            this.groupBox1.Controls.Add(this.btn_TangentStop);
            this.groupBox1.Controls.Add(this.cmb_Axis);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(7, 119);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(321, 193);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Axis Operation";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(241, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 52;
            this.label3.Text = "Pulse";
            // 
            // txb_ModuleRange
            // 
            this.txb_ModuleRange.Location = new System.Drawing.Point(111, 95);
            this.txb_ModuleRange.Name = "txb_ModuleRange";
            this.txb_ModuleRange.Size = new System.Drawing.Size(126, 21);
            this.txb_ModuleRange.TabIndex = 51;
            this.txb_ModuleRange.Text = "3600";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 12);
            this.label6.TabIndex = 50;
            this.label6.Text = "Module Range:";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.rdo_Opposite);
            this.groupBox18.Controls.Add(this.rdo_Same);
            this.groupBox18.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox18.Location = new System.Drawing.Point(16, 117);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(289, 40);
            this.groupBox18.TabIndex = 49;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Direction";
            // 
            // rdo_Opposite
            // 
            this.rdo_Opposite.AutoSize = true;
            this.rdo_Opposite.Location = new System.Drawing.Point(185, 18);
            this.rdo_Opposite.Name = "rdo_Opposite";
            this.rdo_Opposite.Size = new System.Drawing.Size(71, 16);
            this.rdo_Opposite.TabIndex = 1;
            this.rdo_Opposite.Text = "Opposite";
            this.rdo_Opposite.UseVisualStyleBackColor = true;
            // 
            // rdo_Same
            // 
            this.rdo_Same.AutoSize = true;
            this.rdo_Same.Checked = true;
            this.rdo_Same.Location = new System.Drawing.Point(24, 18);
            this.rdo_Same.Name = "rdo_Same";
            this.rdo_Same.Size = new System.Drawing.Size(47, 16);
            this.rdo_Same.TabIndex = 0;
            this.rdo_Same.TabStop = true;
            this.rdo_Same.Text = "Same";
            this.rdo_Same.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.txb_ZPos);
            this.groupBox17.Controls.Add(this.label86);
            this.groupBox17.Controls.Add(this.txb_YPos);
            this.groupBox17.Controls.Add(this.label85);
            this.groupBox17.Controls.Add(this.txb_XPos);
            this.groupBox17.Controls.Add(this.label84);
            this.groupBox17.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox17.Location = new System.Drawing.Point(14, 42);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(295, 45);
            this.groupBox17.TabIndex = 48;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Start Vector";
            // 
            // txb_ZPos
            // 
            this.txb_ZPos.Location = new System.Drawing.Point(211, 18);
            this.txb_ZPos.Name = "txb_ZPos";
            this.txb_ZPos.Size = new System.Drawing.Size(60, 21);
            this.txb_ZPos.TabIndex = 5;
            this.txb_ZPos.Text = "0";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(190, 23);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(17, 12);
            this.label86.TabIndex = 4;
            this.label86.Text = "Z:";
            // 
            // txb_YPos
            // 
            this.txb_YPos.Location = new System.Drawing.Point(113, 19);
            this.txb_YPos.Name = "txb_YPos";
            this.txb_YPos.Size = new System.Drawing.Size(60, 21);
            this.txb_YPos.TabIndex = 3;
            this.txb_YPos.Text = "10";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(95, 24);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(17, 12);
            this.label85.TabIndex = 2;
            this.label85.Text = "Y:";
            // 
            // txb_XPos
            // 
            this.txb_XPos.Location = new System.Drawing.Point(22, 18);
            this.txb_XPos.Name = "txb_XPos";
            this.txb_XPos.Size = new System.Drawing.Size(60, 21);
            this.txb_XPos.TabIndex = 1;
            this.txb_XPos.Text = "0";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(5, 25);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(17, 12);
            this.label84.TabIndex = 0;
            this.label84.Text = "X:";
            // 
            // btn_TangentIn
            // 
            this.btn_TangentIn.Location = new System.Drawing.Point(37, 162);
            this.btn_TangentIn.Name = "btn_TangentIn";
            this.btn_TangentIn.Size = new System.Drawing.Size(80, 24);
            this.btn_TangentIn.TabIndex = 47;
            this.btn_TangentIn.Text = "Tangent In";
            this.btn_TangentIn.UseVisualStyleBackColor = true;
            this.btn_TangentIn.Click += new System.EventHandler(this.btn_TangentIn_Click);
            // 
            // btn_TangentStop
            // 
            this.btn_TangentStop.Location = new System.Drawing.Point(191, 163);
            this.btn_TangentStop.Name = "btn_TangentStop";
            this.btn_TangentStop.Size = new System.Drawing.Size(80, 24);
            this.btn_TangentStop.TabIndex = 39;
            this.btn_TangentStop.Text = "Stop";
            this.btn_TangentStop.UseVisualStyleBackColor = true;
            this.btn_TangentStop.Click += new System.EventHandler(this.btn_TangentStop_Click);
            // 
            // OpenConfigFile
            // 
            this.OpenConfigFile.FileName = "openFileDialog1";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_ResetCounter
            // 
            this.btn_ResetCounter.Location = new System.Drawing.Point(648, 404);
            this.btn_ResetCounter.Name = "btn_ResetCounter";
            this.btn_ResetCounter.Size = new System.Drawing.Size(96, 26);
            this.btn_ResetCounter.TabIndex = 40;
            this.btn_ResetCounter.Text = "Reset Counter";
            this.btn_ResetCounter.Click += new System.EventHandler(this.btn_ResetCounter_Click);
            // 
            // btn_ResetError
            // 
            this.btn_ResetError.Location = new System.Drawing.Point(648, 490);
            this.btn_ResetError.Name = "btn_ResetError";
            this.btn_ResetError.Size = new System.Drawing.Size(96, 26);
            this.btn_ResetError.TabIndex = 44;
            this.btn_ResetError.Text = "Reset Error";
            this.btn_ResetError.UseVisualStyleBackColor = true;
            this.btn_ResetError.Click += new System.EventHandler(this.btn_ResetError_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox5);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox15);
            this.groupBox2.Controls.Add(this.groupBox19);
            this.groupBox2.Controls.Add(this.btn_Move);
            this.groupBox2.Controls.Add(this.btn_GroupStop);
            this.groupBox2.Controls.Add(this.dgv_Ends);
            this.groupBox2.Controls.Add(this.label74);
            this.groupBox2.Controls.Add(this.cbx_Axes);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox2.Location = new System.Drawing.Point(336, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(414, 361);
            this.groupBox2.TabIndex = 45;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Group Operation";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rdo_Spiral);
            this.groupBox5.Controls.Add(this.rdo_Arc);
            this.groupBox5.Controls.Add(this.rdo_Line);
            this.groupBox5.Location = new System.Drawing.Point(124, 134);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(284, 46);
            this.groupBox5.TabIndex = 39;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Interpolation Mode";
            // 
            // rdo_Spiral
            // 
            this.rdo_Spiral.Location = new System.Drawing.Point(203, 20);
            this.rdo_Spiral.Name = "rdo_Spiral";
            this.rdo_Spiral.Size = new System.Drawing.Size(59, 20);
            this.rdo_Spiral.TabIndex = 4;
            this.rdo_Spiral.Text = "Spiral";
            // 
            // rdo_Arc
            // 
            this.rdo_Arc.Location = new System.Drawing.Point(106, 20);
            this.rdo_Arc.Name = "rdo_Arc";
            this.rdo_Arc.Size = new System.Drawing.Size(56, 20);
            this.rdo_Arc.TabIndex = 2;
            this.rdo_Arc.Text = "Arc";
            // 
            // rdo_Line
            // 
            this.rdo_Line.Checked = true;
            this.rdo_Line.Location = new System.Drawing.Point(9, 20);
            this.rdo_Line.Name = "rdo_Line";
            this.rdo_Line.Size = new System.Drawing.Size(57, 20);
            this.rdo_Line.TabIndex = 3;
            this.rdo_Line.TabStop = true;
            this.rdo_Line.Text = "Line";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButtonRel);
            this.groupBox4.Controls.Add(this.radioButtonAbs);
            this.groupBox4.Location = new System.Drawing.Point(121, 17);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(157, 54);
            this.groupBox4.TabIndex = 49;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Movement Mode";
            // 
            // radioButtonRel
            // 
            this.radioButtonRel.AutoSize = true;
            this.radioButtonRel.Checked = true;
            this.radioButtonRel.Location = new System.Drawing.Point(7, 23);
            this.radioButtonRel.Name = "radioButtonRel";
            this.radioButtonRel.Size = new System.Drawing.Size(71, 16);
            this.radioButtonRel.TabIndex = 7;
            this.radioButtonRel.TabStop = true;
            this.radioButtonRel.Text = "Relative";
            this.radioButtonRel.UseVisualStyleBackColor = true;
            // 
            // radioButtonAbs
            // 
            this.radioButtonAbs.Location = new System.Drawing.Point(81, 26);
            this.radioButtonAbs.Name = "radioButtonAbs";
            this.radioButtonAbs.Size = new System.Drawing.Size(75, 16);
            this.radioButtonAbs.TabIndex = 6;
            this.radioButtonAbs.Text = "Absolute";
            this.radioButtonAbs.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.rdo_CCW);
            this.groupBox15.Controls.Add(this.rdo_CW);
            this.groupBox15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox15.Location = new System.Drawing.Point(287, 18);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(118, 54);
            this.groupBox15.TabIndex = 44;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Arc Direction";
            // 
            // rdo_CCW
            // 
            this.rdo_CCW.Location = new System.Drawing.Point(59, 24);
            this.rdo_CCW.Name = "rdo_CCW";
            this.rdo_CCW.Size = new System.Drawing.Size(47, 20);
            this.rdo_CCW.TabIndex = 2;
            this.rdo_CCW.Text = "CCW";
            // 
            // rdo_CW
            // 
            this.rdo_CW.Checked = true;
            this.rdo_CW.Location = new System.Drawing.Point(9, 23);
            this.rdo_CW.Name = "rdo_CW";
            this.rdo_CW.Size = new System.Drawing.Size(56, 20);
            this.rdo_CW.TabIndex = 3;
            this.rdo_CW.TabStop = true;
            this.rdo_CW.Text = "CW";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.rdo_XZPlane);
            this.groupBox19.Controls.Add(this.rdo_YZPlane);
            this.groupBox19.Controls.Add(this.rdo_XYPlane);
            this.groupBox19.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox19.Location = new System.Drawing.Point(123, 80);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(285, 45);
            this.groupBox19.TabIndex = 32;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Reference Plane";
            // 
            // rdo_XZPlane
            // 
            this.rdo_XZPlane.AutoSize = true;
            this.rdo_XZPlane.Location = new System.Drawing.Point(202, 20);
            this.rdo_XZPlane.Name = "rdo_XZPlane";
            this.rdo_XZPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_XZPlane.TabIndex = 2;
            this.rdo_XZPlane.Text = "X_Z Plane";
            this.rdo_XZPlane.UseVisualStyleBackColor = true;
            // 
            // rdo_YZPlane
            // 
            this.rdo_YZPlane.AutoSize = true;
            this.rdo_YZPlane.Location = new System.Drawing.Point(107, 20);
            this.rdo_YZPlane.Name = "rdo_YZPlane";
            this.rdo_YZPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_YZPlane.TabIndex = 1;
            this.rdo_YZPlane.Text = "Y_Z Plane";
            this.rdo_YZPlane.UseVisualStyleBackColor = true;
            // 
            // rdo_XYPlane
            // 
            this.rdo_XYPlane.AutoSize = true;
            this.rdo_XYPlane.Checked = true;
            this.rdo_XYPlane.Location = new System.Drawing.Point(10, 20);
            this.rdo_XYPlane.Name = "rdo_XYPlane";
            this.rdo_XYPlane.Size = new System.Drawing.Size(77, 16);
            this.rdo_XYPlane.TabIndex = 0;
            this.rdo_XYPlane.TabStop = true;
            this.rdo_XYPlane.Text = "X_Y Plane";
            this.rdo_XYPlane.UseVisualStyleBackColor = true;
            // 
            // btn_Move
            // 
            this.btn_Move.Location = new System.Drawing.Point(64, 329);
            this.btn_Move.Name = "btn_Move";
            this.btn_Move.Size = new System.Drawing.Size(88, 26);
            this.btn_Move.TabIndex = 43;
            this.btn_Move.Text = "Move";
            this.btn_Move.Click += new System.EventHandler(this.btn_Move_Click);
            // 
            // btn_GroupStop
            // 
            this.btn_GroupStop.Location = new System.Drawing.Point(210, 329);
            this.btn_GroupStop.Name = "btn_GroupStop";
            this.btn_GroupStop.Size = new System.Drawing.Size(88, 26);
            this.btn_GroupStop.TabIndex = 42;
            this.btn_GroupStop.Text = "Stop";
            this.btn_GroupStop.Click += new System.EventHandler(this.btn_GroupStop_Click);
            // 
            // dgv_Ends
            // 
            this.dgv_Ends.AllowUserToAddRows = false;
            this.dgv_Ends.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Ends.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Ends.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Ends.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Axes,
            this.LineEndValue,
            this.ArcCenterValue,
            this.ArcEndValue});
            this.dgv_Ends.Location = new System.Drawing.Point(13, 199);
            this.dgv_Ends.Name = "dgv_Ends";
            this.dgv_Ends.RowHeadersVisible = false;
            this.dgv_Ends.RowHeadersWidth = 10;
            this.dgv_Ends.RowTemplate.Height = 23;
            this.dgv_Ends.Size = new System.Drawing.Size(353, 120);
            this.dgv_Ends.TabIndex = 40;
            // 
            // Axes
            // 
            this.Axes.HeaderText = "Axes";
            this.Axes.Name = "Axes";
            this.Axes.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Axes.Width = 50;
            // 
            // LineEndValue
            // 
            this.LineEndValue.HeaderText = "Line End";
            this.LineEndValue.Name = "LineEndValue";
            this.LineEndValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ArcCenterValue
            // 
            this.ArcCenterValue.HeaderText = "Arc Center";
            this.ArcCenterValue.Name = "ArcCenterValue";
            this.ArcCenterValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ArcEndValue
            // 
            this.ArcEndValue.HeaderText = "Arc End";
            this.ArcEndValue.Name = "ArcEndValue";
            this.ArcEndValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // label74
            // 
            this.label74.Location = new System.Drawing.Point(11, 19);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(102, 14);
            this.label74.TabIndex = 38;
            this.label74.Text = "Operation Axes:";
            // 
            // cbx_Axes
            // 
            this.cbx_Axes.CheckOnClick = true;
            this.cbx_Axes.FormattingEnabled = true;
            this.cbx_Axes.Location = new System.Drawing.Point(10, 35);
            this.cbx_Axes.Name = "cbx_Axes";
            this.cbx_Axes.Size = new System.Drawing.Size(103, 148);
            this.cbx_Axes.TabIndex = 37;
            this.cbx_Axes.SelectedIndexChanged += new System.EventHandler(this.cbx_Axes_SelectedIndexChanged);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.dgv_Position);
            this.groupBox16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox16.Location = new System.Drawing.Point(9, 369);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(627, 110);
            this.groupBox16.TabIndex = 47;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Position";
            // 
            // dgv_Position
            // 
            this.dgv_Position.AllowUserToAddRows = false;
            this.dgv_Position.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.GrayText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Position.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Position.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Position.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Position});
            this.dgv_Position.Location = new System.Drawing.Point(10, 14);
            this.dgv_Position.Name = "dgv_Position";
            this.dgv_Position.RowHeadersWidth = 10;
            this.dgv_Position.RowTemplate.Height = 23;
            this.dgv_Position.Size = new System.Drawing.Size(604, 90);
            this.dgv_Position.TabIndex = 25;
            // 
            // Position
            // 
            this.Position.HeaderText = "Position";
            this.Position.Name = "Position";
            this.Position.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Position.Width = 60;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txb_MasterAxisState);
            this.groupBox3.Controls.Add(this.txb_GroupState);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.groupBox3.Location = new System.Drawing.Point(13, 482);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(623, 49);
            this.groupBox3.TabIndex = 46;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Current Axis Status";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(400, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 12);
            this.label4.TabIndex = 26;
            this.label4.Text = "Group State:";
            // 
            // txb_MasterAxisState
            // 
            this.txb_MasterAxisState.Location = new System.Drawing.Point(101, 19);
            this.txb_MasterAxisState.Name = "txb_MasterAxisState";
            this.txb_MasterAxisState.ReadOnly = true;
            this.txb_MasterAxisState.Size = new System.Drawing.Size(122, 21);
            this.txb_MasterAxisState.TabIndex = 24;
            this.txb_MasterAxisState.Text = "0";
            // 
            // txb_GroupState
            // 
            this.txb_GroupState.Location = new System.Drawing.Point(486, 22);
            this.txb_GroupState.Name = "txb_GroupState";
            this.txb_GroupState.ReadOnly = true;
            this.txb_GroupState.Size = new System.Drawing.Size(122, 21);
            this.txb_GroupState.TabIndex = 25;
            this.txb_GroupState.Text = "0";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(13, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 12);
            this.label5.TabIndex = 27;
            this.label5.Text = "Axis State:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.buttonLoadCfg);
            this.groupBox6.Controls.Add(this.BtnServo);
            this.groupBox6.Controls.Add(this.BtnCloseBoard);
            this.groupBox6.Controls.Add(this.BtnOpenBoard);
            this.groupBox6.Controls.Add(this.CmbAvailableDevice);
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Location = new System.Drawing.Point(9, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(319, 112);
            this.groupBox6.TabIndex = 48;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Device Operate";
            // 
            // buttonLoadCfg
            // 
            this.buttonLoadCfg.Location = new System.Drawing.Point(37, 80);
            this.buttonLoadCfg.Name = "buttonLoadCfg";
            this.buttonLoadCfg.Size = new System.Drawing.Size(100, 25);
            this.buttonLoadCfg.TabIndex = 31;
            this.buttonLoadCfg.Text = "Load Config";
            this.buttonLoadCfg.UseVisualStyleBackColor = true;
            this.buttonLoadCfg.Click += new System.EventHandler(this.buttonLoadCfg_Click);
            // 
            // BtnServo
            // 
            this.BtnServo.Location = new System.Drawing.Point(186, 80);
            this.BtnServo.Name = "BtnServo";
            this.BtnServo.Size = new System.Drawing.Size(100, 25);
            this.BtnServo.TabIndex = 17;
            this.BtnServo.Text = "Servo On";
            this.BtnServo.UseVisualStyleBackColor = true;
            this.BtnServo.Click += new System.EventHandler(this.BtnServo_Click);
            // 
            // BtnCloseBoard
            // 
            this.BtnCloseBoard.Location = new System.Drawing.Point(186, 48);
            this.BtnCloseBoard.Name = "BtnCloseBoard";
            this.BtnCloseBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnCloseBoard.TabIndex = 16;
            this.BtnCloseBoard.Text = "Close Board";
            this.BtnCloseBoard.UseVisualStyleBackColor = true;
            this.BtnCloseBoard.Click += new System.EventHandler(this.BtnCloseBoard_Click);
            // 
            // BtnOpenBoard
            // 
            this.BtnOpenBoard.Location = new System.Drawing.Point(36, 48);
            this.BtnOpenBoard.Name = "BtnOpenBoard";
            this.BtnOpenBoard.Size = new System.Drawing.Size(100, 25);
            this.BtnOpenBoard.TabIndex = 15;
            this.BtnOpenBoard.Text = "Open Board";
            this.BtnOpenBoard.UseVisualStyleBackColor = true;
            this.BtnOpenBoard.Click += new System.EventHandler(this.BtnOpenBoard_Click);
            // 
            // CmbAvailableDevice
            // 
            this.CmbAvailableDevice.FormattingEnabled = true;
            this.CmbAvailableDevice.Location = new System.Drawing.Point(122, 20);
            this.CmbAvailableDevice.Name = "CmbAvailableDevice";
            this.CmbAvailableDevice.Size = new System.Drawing.Size(174, 20);
            this.CmbAvailableDevice.TabIndex = 14;
            this.CmbAvailableDevice.SelectedIndexChanged += new System.EventHandler(this.CmbAvailableDevice_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "Available device:";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label11);
            this.groupBox13.Controls.Add(this.label17);
            this.groupBox13.Controls.Add(this.label12);
            this.groupBox13.Controls.Add(this.label19);
            this.groupBox13.Controls.Add(this.pictureBoxNegHEL);
            this.groupBox13.Controls.Add(this.pictureBoxPosHEL);
            this.groupBox13.Controls.Add(this.pictureBoxORG);
            this.groupBox13.Controls.Add(this.pictureBoxALM);
            this.groupBox13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox13.Location = new System.Drawing.Point(7, 316);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(321, 50);
            this.groupBox13.TabIndex = 113;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Selected Axis Signal Status";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(240, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 28;
            this.label11.Text = "-HEL:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(162, 28);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 27;
            this.label17.Text = "+HEL:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(82, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 26;
            this.label12.Text = "ORG:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(10, 26);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "ALM:";
            // 
            // pictureBoxNegHEL
            // 
            this.pictureBoxNegHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxNegHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxNegHEL.Location = new System.Drawing.Point(281, 23);
            this.pictureBoxNegHEL.Name = "pictureBoxNegHEL";
            this.pictureBoxNegHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxNegHEL.TabIndex = 7;
            this.pictureBoxNegHEL.TabStop = false;
            // 
            // pictureBoxPosHEL
            // 
            this.pictureBoxPosHEL.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxPosHEL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPosHEL.Location = new System.Drawing.Point(201, 23);
            this.pictureBoxPosHEL.Name = "pictureBoxPosHEL";
            this.pictureBoxPosHEL.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxPosHEL.TabIndex = 6;
            this.pictureBoxPosHEL.TabStop = false;
            // 
            // pictureBoxORG
            // 
            this.pictureBoxORG.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxORG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxORG.Location = new System.Drawing.Point(115, 23);
            this.pictureBoxORG.Name = "pictureBoxORG";
            this.pictureBoxORG.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxORG.TabIndex = 5;
            this.pictureBoxORG.TabStop = false;
            // 
            // pictureBoxALM
            // 
            this.pictureBoxALM.BackColor = System.Drawing.Color.Gray;
            this.pictureBoxALM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxALM.Location = new System.Drawing.Point(43, 23);
            this.pictureBoxALM.Name = "pictureBoxALM";
            this.pictureBoxALM.Size = new System.Drawing.Size(20, 20);
            this.pictureBoxALM.TabIndex = 4;
            this.pictureBoxALM.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 538);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_ResetError);
            this.Controls.Add(this.btn_ResetCounter);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tangent";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Ends)).EndInit();
            this.groupBox16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Position)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNegHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPosHEL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxORG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxALM)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_Axis;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        DEV_LIST[] CurAvailableDevs = new DEV_LIST[Motion.MAX_DEVICES];
        uint deviceCount = 0;
        uint DeviceNum = 0;
        IntPtr m_DeviceHandle = IntPtr.Zero;
        IntPtr[] m_Axishand = new IntPtr[32];
        IntPtr m_GpHand = IntPtr.Zero;
        uint m_ulAxisCount = 0;
        bool m_bInit = false;
        bool m_bServoOn = false;
        private System.Windows.Forms.OpenFileDialog OpenConfigFile;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_TangentStop;
        private System.Windows.Forms.Button btn_ResetCounter;
        private System.Windows.Forms.Button btn_ResetError;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.RadioButton rdo_Opposite;
        private System.Windows.Forms.RadioButton rdo_Same;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox txb_ZPos;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox txb_YPos;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox txb_XPos;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Button btn_TangentIn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.RadioButton rdo_CCW;
        private System.Windows.Forms.RadioButton rdo_CW;
        private System.Windows.Forms.Button btn_Move;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RadioButton rdo_XZPlane;
        private System.Windows.Forms.RadioButton rdo_YZPlane;
        private System.Windows.Forms.RadioButton rdo_XYPlane;
        private System.Windows.Forms.Button btn_GroupStop;
        private System.Windows.Forms.DataGridView dgv_Ends;
        private System.Windows.Forms.DataGridViewTextBoxColumn Axes;
        private System.Windows.Forms.DataGridViewTextBoxColumn LineEndValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn ArcCenterValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn ArcEndValue;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdo_Spiral;
        private System.Windows.Forms.RadioButton rdo_Arc;
        private System.Windows.Forms.RadioButton rdo_Line;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.CheckedListBox cbx_Axes;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.DataGridView dgv_Position;
        private System.Windows.Forms.DataGridViewTextBoxColumn Position;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txb_MasterAxisState;
        private System.Windows.Forms.TextBox txb_GroupState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txb_ModuleRange;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button buttonLoadCfg;
        private System.Windows.Forms.Button BtnServo;
        private System.Windows.Forms.Button BtnCloseBoard;
        private System.Windows.Forms.Button BtnOpenBoard;
        private System.Windows.Forms.ComboBox CmbAvailableDevice;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButtonRel;
        private System.Windows.Forms.RadioButton radioButtonAbs;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxNegHEL;
        private System.Windows.Forms.PictureBox pictureBoxPosHEL;
        private System.Windows.Forms.PictureBox pictureBoxORG;
        private System.Windows.Forms.PictureBox pictureBoxALM;
    }
}

