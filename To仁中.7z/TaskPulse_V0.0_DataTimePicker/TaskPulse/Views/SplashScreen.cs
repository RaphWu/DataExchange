﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Services;

namespace Calin.TaskPulse.Views
{
    public partial class SplashScreen : Form
    {
        private List<string> _msg = new List<string>();

        public SplashScreen()
        {
            InitializeComponent();
        }

        private void SplashScreen_Load(object sender, EventArgs e)
        {
            SplashMessenger.Initialize(SynchronizationContext.Current, msg => AddMessage(msg));
        }

        public void AddMessage(string msg)
        {
            _msg.Insert(0, msg);
            string displayMsg = string.Join(Environment.NewLine, _msg.Take(9).Reverse());

            if (msgList.InvokeRequired)
                msgList.Invoke(new Action(() => msgList.Text = displayMsg));
            else
                msgList.Text = displayMsg;
        }
    }
}
