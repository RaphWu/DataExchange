﻿namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 權限所屬分類。
    /// </summary>
    public enum PermissionSource
    {
        None,
        Employee,
        Department,
        UserGroup,
    }
}
