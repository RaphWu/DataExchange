﻿using System.Drawing;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.SharedUI
{
    public static class MyFormEx
    {
        public static DialogResult ShowDialogWithMask(this Form form)
        {
#if !DEBUG
            Point pt = Sunny.UI.SystemEx.GetCursorPos();
            Rectangle screen = Screen.GetBounds(pt);
            using (MaskLayer mask = new MaskLayer())
            {
                mask.Bounds = screen;
                mask.Show();

#endif
                form.ShowInTaskbar = false;
                form.TopMost = true;
                return form.ShowDialog();
#if !DEBUG
            }
#endif
        }

        public class MaskLayer : Form
        {
            public MaskLayer()
            {
                this.SuspendLayout();
                this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
                this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
                base.BackColor = Color.Black;
                this.ClientSize = new System.Drawing.Size(800, 450);
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                this.Name = "MaskLayer";
                this.Opacity = 0.5D;
                this.ShowInTaskbar = false;
                this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
                this.Text = "MaskLayer";
                this.TopMost = true;
                this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MaskLayer_MouseClick);
                this.ResumeLayout(false);
            }

            protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
            {
                int num = 256;
                int num2 = 260;
                if (msg.Msg == num | msg.Msg == num2)
                {
                    if (keyData == Keys.Escape)
                    {
                        Close();
                    }
                }

                return base.ProcessCmdKey(ref msg, keyData);
            }

            private void MaskLayer_MouseClick(object sender, MouseEventArgs e)
            {
                Close();
            }

            //private System.ComponentModel.IContainer components = null;

            //protected override void Dispose(bool disposing)
            //{
            //    if (disposing && (components != null))
            //    {
            //        components.Dispose();
            //    }

            //    base.Dispose(disposing);
            //}
        }
    }
}
