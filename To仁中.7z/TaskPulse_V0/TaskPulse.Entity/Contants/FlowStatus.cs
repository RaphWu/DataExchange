﻿using System.ComponentModel;

namespace Calin.TaskPulse.Entity.Contants
{
    // 請依流程順序倒序排列

    /// <summary>
    /// 維護工單流程狀態。
    /// </summary>
    public enum FlowStatus
    {
        /// <summary>
        /// 未知狀態。
        /// </summary>
        [Description("未知狀態")]
        Unknow = 0,

        /// <summary>
        /// 維護結束。
        /// </summary>
        [Description("維護結束")]
        Completed = 1,

        /// <summary>
        /// 待確認。
        /// </summary>
        [Description("待確認")]
        Pending = 2,

        /// <summary>
        /// 維護中。
        /// </summary>
        [Description("維護中")]
        InProgress = 4,

        /// <summary>
        /// 新工單。
        /// </summary>
        [Description("新工單")]
        NewTaskOrder = 8,
    }
}
