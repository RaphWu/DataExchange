﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.WinForms
{
    public partial class FuzzyComboBox : ComboBox
    {
        [Browsable(false)]
        public new AutoCompleteMode AutoCompleteMode { get; } = AutoCompleteMode.None;

        public new object DataSource
        {
            get => OutSideDataSource;
            set
            {
                OutSideDataSource = value;
                base.DataSource = value;
                _OriginalItems = Items.Cast<object>().ToList();
            }
        }
        object OutSideDataSource { get; set; }
        IList<object> _OriginalItems { get; set; }

        public FuzzyComboBox()
        {
            InitializeComponent();

            base.AutoCompleteMode = this.AutoCompleteMode;
        }
        protected override void OnTextUpdate(EventArgs e)
        {
            string inputString = Text;
            SelectionLength = 0;
            IList<object> searchResult = GetDataSource(Text);
            if (searchResult.Any())
            {
                base.DataSource = searchResult;
                DroppedDown = true;
                SelectedIndex = 0;
            }
            else
            {
                string oldDisplayMember = DisplayMember;
                base.DataSource = null;
                DisplayMember = oldDisplayMember;
                Items.Add("");
                DroppedDown = false;
                Items.Clear();
                SelectedIndex = -1;
            }
            Text = inputString;
            SelectionStart = inputString.Length;
            base.OnTextUpdate(e);
        }

        protected override void OnLeave(EventArgs e)
        {
            Text = GetSuggestText();
            base.OnLeave(e);
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                Text = GetSuggestText();
            }
            base.OnKeyPress(e);
        }

        string GetSuggestText()
        {
            if (SelectedItem != null)
            {
                return GetItemText(SelectedItem);
            }
            else if (Items.Count > 0)
            {
                SelectedItem = Items[0];
                return GetItemText(Items[0]);
            }
            else
            {
                return Text;
            }
        }
        IList<object> GetDataSource(string compareText)
        {
            if (string.IsNullOrEmpty(Text) || _OriginalItems.Count < 1)
            {
                return _OriginalItems;
            }
            return _OriginalItems
                .Cast<object>()
                .Where(item =>
                {
                    string text = GetItemText(item);
                    return text.Contains(compareText);
                })
                .ToList();
        }
    }
}
