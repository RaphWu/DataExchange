﻿namespace Calin.TaskPulse.Core.Views
{
    partial class SetupPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.tvSetupMenu = new Sunny.UI.UITreeView();
            this.SetupRegion = new System.Windows.Forms.Panel();
            this.uiLine1 = new Sunny.UI.UILine();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 3;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Page.Controls.Add(this.tvSetupMenu, 0, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.SetupRegion, 2, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.uiLine1, 1, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 1;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1117, 676);
            this.tableLayoutPanel_Page.TabIndex = 0;
            // 
            // tvSetupMenu
            // 
            this.tvSetupMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvSetupMenu.FillColor = System.Drawing.Color.White;
            this.tvSetupMenu.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tvSetupMenu.Location = new System.Drawing.Point(3, 6);
            this.tvSetupMenu.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.tvSetupMenu.MinimumSize = new System.Drawing.Size(1, 1);
            this.tvSetupMenu.Name = "tvSetupMenu";
            this.tvSetupMenu.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.tvSetupMenu.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.tvSetupMenu.ScrollBarStyleInherited = false;
            this.tvSetupMenu.ShowText = false;
            this.tvSetupMenu.Size = new System.Drawing.Size(184, 664);
            this.tvSetupMenu.TabIndex = 0;
            this.tvSetupMenu.Text = null;
            this.tvSetupMenu.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.tvSetupMenu.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvSetupMenu_AfterSelect);
            this.tvSetupMenu.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvSetupMenu_NodeMouseClick);
            // 
            // SetupRegion
            // 
            this.SetupRegion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SetupRegion.Location = new System.Drawing.Point(202, 3);
            this.SetupRegion.Name = "SetupRegion";
            this.SetupRegion.Size = new System.Drawing.Size(912, 670);
            this.SetupRegion.TabIndex = 1;
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiLine1.Dock = System.Windows.Forms.DockStyle.Left;
            this.uiLine1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.LineSize = 3;
            this.uiLine1.Location = new System.Drawing.Point(193, 3);
            this.uiLine1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(3, 670);
            this.uiLine1.TabIndex = 2;
            // 
            // SetupPage
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "SetupPage";
            this.Size = new System.Drawing.Size(1117, 676);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private Sunny.UI.UITreeView tvSetupMenu;
        private System.Windows.Forms.Panel SetupRegion;
        private Sunny.UI.UILine uiLine1;
    }
}