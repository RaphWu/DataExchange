﻿using System;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Entity;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class SetupPage : UserControl, INavigationAware
    {
        private readonly Serilog.ILogger _logger;
        private readonly ICacheManager _cacheManager;
        private readonly ILifetimeScope _scope;
        private readonly IRegionManager _region;
        private readonly INavigationService _navigation;
        private readonly IPermissionService _permission;

        private PageCode _currentPageCode = PageCode.None;

        #region INavigationAware

        public void OnNavigatedTo()
        {
        }

        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();
        }

        #endregion INavigationAware

        public SetupPage(
            Serilog.ILogger logger,
            ICacheManager cacheManager,
            IRegionManager regionManager,
            INavigationService navigationService,
            ILifetimeScope rootScope,
            IPermissionService permissionService)
        {
            InitializeComponent();

            _logger = logger;
            _cacheManager = cacheManager;
            _region = regionManager;
            _navigation = navigationService;
            _scope = rootScope;
            _permission = permissionService;

            _region.RegisterRegion(nameof(SetupRegion), SetupRegion);
            tvSetupMenu.SelectedColor = CommonStyles.BackColor;

            //WeakReferenceMessenger.Default.Register<CurrentUserChangedMessage>(this, (sender, e) =>
            //{
            bool permMachine = _permission.HasControlAccess(PermissionWords.MODULE_SETUP, PermissionWords.PAGE_MACHINE_MANAGER);
            bool permEmployee = _permission.HasControlAccess(PermissionWords.MODULE_SETUP, PermissionWords.PAGE_EMPLOYEE_MANAGER);
            //bool permToolQuest = _permission.HasControlAccess(PermissionWords.MODULE_SETUP, PermissionWords.PAGE_TOOL_QUEST_MANAGER);
            //bool permMechaTrack = _permission.HasControlAccess(PermissionWords.MODULE_SETUP, PermissionWords.PAGE_MECHA_TRACK_MANAGER);
            bool permMaintiFlow = _permission.HasControlAccess(PermissionWords.MODULE_SETUP, PermissionWords.PAGE_MAINTI_FLOW_MANAGER);

            TreeNode parent;
            TreeNode child1;
            TreeNode child2;

            tvSetupMenu.Nodes.Clear();

            /***** 基本資料管理 *****/
            if (permMachine)
            {
                parent = new TreeNode(PageCode.Machines.GetDescription());
                parent.Tag = (int)PageCode.Machines;
                tvSetupMenu.Nodes.Add(parent);

                child1 = new TreeNode(PageCode.MachinesSummary.GetDescription());
                child1.Tag = (int)PageCode.MachinesSummary;
                parent.Nodes.Add(child1);

                child1 = new TreeNode(PageCode.MachineBrend.GetDescription());
                child1.Tag = (int)PageCode.MachineBrend;
                parent.Nodes.Add(child1);

                child1 = new TreeNode(PageCode.MachineCategory.GetDescription());
                child1.Tag = (int)PageCode.MachineCategory;
                parent.Nodes.Add(child1);

                child1 = new TreeNode(PageCode.Models.GetDescription());
                child1.Tag = (int)PageCode.Models;
                parent.Nodes.Add(child1);
            }

            if (permEmployee)
            {
                parent = new TreeNode(PageCode.EmployeesManagement.GetDescription());
                parent.Tag = (int)PageCode.EmployeesManagement;
                tvSetupMenu.Nodes.Add(parent);

                child1 = new TreeNode(PageCode.Employees.GetDescription());
                child1.Tag = (int)PageCode.Employees;
                parent.Nodes.Add(child1);

                child1 = new TreeNode(PageCode.Department.GetDescription());
                child1.Tag = (int)PageCode.Department;
                parent.Nodes.Add(child1);

                child1 = new TreeNode(PageCode.UserGroup.GetDescription());
                child1.Tag = (int)PageCode.UserGroup;
                parent.Nodes.Add(child1);

                child1 = new TreeNode(PageCode.Permission.GetDescription());
                child1.Tag = (int)PageCode.Permission;
                parent.Nodes.Add(child1);
            }

            /***** 維護工單 *****/

            if (permMaintiFlow)
            {
                parent = new TreeNode(PageCode.MaintiFlowManagement.GetDescription());
                parent.Tag = (int)PageCode.MaintiFlowManagement;
                tvSetupMenu.Nodes.Add(parent);

                child1 = new TreeNode(PageCode.MaintiFlowClassify.GetDescription());
                child1.Tag = (int)PageCode.MaintiFlowClassify;
                parent.Nodes.Add(child1);
            }

            /***** 工具委託 *****/

            /***** 專案管理 *****/

            tvSetupMenu.ExpandAll();
            tvSetupMenu.ContextMenuStrip = new TreeViewContextMenu();
        }

        private void SetupPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        private void tvSetupMenu_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                ((UITreeView)sender).SelectedNode = e.Node;
        }

        private void tvSetupMenu_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (Enum.TryParse(e.Node.Tag.ToString(), out PageCode pageCode))
            {
                if (_currentPageCode == pageCode)
                    return;

                switch (pageCode)
                {
                    case PageCode.MachinesSummary:
                        _navigation.Navigate<Setup_MachinesSummary>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.MachineBrend:
                        _navigation.Navigate<Setup_MachineBrend>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.MachineCategory:
                        _navigation.Navigate<Setup_MachineCategory>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.Models:
                        _navigation.Navigate<Setup_Models>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.Employees:
                        _navigation.Navigate<Setup_Employees>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.Department:
                        _navigation.Navigate<Setup_Department>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.UserGroup:
                        _navigation.Navigate<Setup_UserGroup>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.Permission:
                        _navigation.Navigate<Setup_Permission>(nameof(SetupRegion), alive: true);
                        break;

                    case PageCode.MaintiFlowClassify:
                        _navigation.Navigate<Setup_MaintiFlowClassify>(nameof(SetupRegion), alive: true);
                        break;

                    default:
                        return;
                }

                _currentPageCode = pageCode;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                if (!DesignMode)
                    _scope?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
