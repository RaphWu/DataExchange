using System;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache ��s���G�C
    /// </summary>
    public class CacheRefreshResult
    {
        /// <summary>
        /// ������ Cache �����C
        /// </summary>
        public CacheKey CacheKey { get; }

        /// <summary>
        /// �O�_���\��s�C
        /// </summary>
        public bool Success { get; }

        /// <summary>
        /// ��s�����ɶ��C
        /// </summary>
        public DateTime CompletedAt { get; }

        /// <summary>
        /// ��s�ӮɡC
        /// </summary>
        public TimeSpan Duration { get; }

        /// <summary>
        /// ���~�T���]�p�G���ѡ^�C
        /// </summary>
        public string ErrorMessage { get; }

        /// <summary>
        /// ���~�ҥ~�]�p�G���ѡ^�C
        /// </summary>
        public Exception Exception { get; }

        private CacheRefreshResult(CacheKey cacheKey, bool success, TimeSpan duration, string errorMessage = null, Exception exception = null)
        {
            CacheKey = cacheKey;
            Success = success;
            CompletedAt = DateTime.Now;
            Duration = duration;
            ErrorMessage = errorMessage;
            Exception = exception;
        }

        /// <summary>
        /// �إߦ��\���G�C
        /// </summary>
        public static CacheRefreshResult Succeeded(CacheKey cacheKey, TimeSpan duration)
            => new CacheRefreshResult(cacheKey, true, duration);

        /// <summary>
        /// �إߥ��ѵ��G�C
        /// </summary>
        public static CacheRefreshResult Failed(CacheKey cacheKey, TimeSpan duration, string errorMessage, Exception exception = null)
            => new CacheRefreshResult(cacheKey, false, duration, errorMessage, exception);

        public override string ToString()
            => Success
                ? $"[{CacheKey.Name}] ���\ ({Duration.TotalMilliseconds:F0}ms)"
                : $"[{CacheKey.Name}] ����: {ErrorMessage}";
    }
}
