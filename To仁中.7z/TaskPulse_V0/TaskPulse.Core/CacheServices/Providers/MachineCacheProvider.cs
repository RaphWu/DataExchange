using System;
using System.Data.Entity;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.CacheServices.Providers
{
    /// <summary>
    /// ���x��� Cache Provider�C
    /// </summary>
    public class MachineCacheProvider : CacheProviderBase
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        public override CacheKey CacheKey => CacheKeys.Machine;

        public MachineCacheProvider(CoreContext context, CoreData coreData)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _coreData = coreData ?? throw new ArgumentNullException(nameof(coreData));
        }

        protected override async Task RefreshCoreAsync(CacheRefreshContext context)
        {
            var qMachines = await _context.Machines
                .Include(m => m.MachineName.MachineType.Category)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Condition)
                .Include(m => m.UserGroups)
                .AsNoTracking()
                .ToListAsync();

            _coreData.Machines = qMachines
                .Select(m => new { Original = m, Key = GetMachineSortKey(m.MachineCode) })
                .OrderBy(x => x.Key.Text)
                .ThenBy(x => x.Key.Number)
                .Select(x => x.Original)
                .ToList();

            _coreData.ClassifyMachines = _coreData.Machines
                .Where(m => m.Disposal == false
                    && m.MachineName != null
                    && m.MachineName.MachineType != null
                    && m.MachineName.MachineType.Category != null)
                .GroupBy(m => m.MachineName.MachineType.Category.CategoryName)
                .OrderBy(g => g.First().MachineName.MachineType.Category.OrderNo)
                .ToDictionary(
                    categoryGroup => categoryGroup.Key,
                    categoryGroup => categoryGroup
                        .GroupBy(m => m.MachineName.MachineType.TypeName)
                        .OrderBy(typeGroup => typeGroup.First().MachineName.MachineType.OrderNo)
                        .ToDictionary(
                            typeGroup => typeGroup.Key,
                            typeGroup => typeGroup
                                .Select(m => new ClassifyInfo
                                {
                                    Id = m.Id,
                                    Name = m.MachineCode
                                })
                                .ToList()
                        )
                );

            _coreData.MachineCategories = await _context.MachineCategories
                .OrderBy(b => b.OrderNo)
                .AsNoTracking()
                .ToListAsync();

            _coreData.MachineTypes = await _context.MachineTypes
                .OrderBy(b => b.OrderNo)
                .AsNoTracking()
                .ToListAsync();
        }

        private (string Text, int Number) GetMachineSortKey(string machineCode)
        {
            if (string.IsNullOrWhiteSpace(machineCode))
                return ("", 0);

            var match = Regex.Match(machineCode, @"^([^\d]+?)-?(\d+)?$", RegexOptions.IgnoreCase);
            if (match.Success)
            {
                string text = match.Groups[1].Value.Trim();
                int number = 0;
                if (match.Groups[2].Success && !string.IsNullOrEmpty(match.Groups[2].Value))
                    int.TryParse(match.Groups[2].Value, out number);
                return (text, number);
            }

            return (machineCode.Trim(), 0);
        }
    }
}
