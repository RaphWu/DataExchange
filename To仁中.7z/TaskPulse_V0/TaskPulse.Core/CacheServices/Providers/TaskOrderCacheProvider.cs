using System;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.CacheServices.Providers
{
    /// <summary>
    /// �u���� Cache Provider�C
    /// </summary>
    public class TaskOrderCacheProvider : CacheProviderBase
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        public override CacheKey CacheKey => CacheKeys.TaskOrder;

        public TaskOrderCacheProvider(CoreContext context, CoreData coreData)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _coreData = coreData ?? throw new ArgumentNullException(nameof(coreData));
        }

        protected override async Task RefreshCoreAsync(CacheRefreshContext context)
        {
            // �u�� Cache ����ڤ��e�� TaskOrderService �޲z
            // �o�̥u�O�ܽd�A��ڹ�@�i�̻ݨD�վ�
            await Task.CompletedTask;
        }
    }
}
