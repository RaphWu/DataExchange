using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.CacheServices.Providers
{
    /// <summary>
    /// ���u��� Cache Provider�C
    /// </summary>
    public class EmployeeCacheProvider : CacheProviderBase
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        public override CacheKey CacheKey => CacheKeys.Employee;

        public EmployeeCacheProvider(CoreContext context, CoreData coreData)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _coreData = coreData ?? throw new ArgumentNullException(nameof(coreData));
        }

        protected override async Task RefreshCoreAsync(CacheRefreshContext context)
        {
            var query = await _context.Employees
                .Where(x => x.StatusId == _coreData.IsActiveEmployee)
                .AsNoTracking()
                .ToListAsync();

            _coreData.Employees = query
                .OrderBy(e => e.Department?.OrderNo ?? int.MaxValue)
                .ThenBy(e => e.JobTitle?.OrderNo ?? int.MaxValue)
                .ThenBy(e => e.EmployeeId)
                .ToList();

            _coreData.ClassifyEmployee = _coreData.Employees
                .GroupBy(e => e.DepartmentName)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(e => new ClassifyInfo()
                    {
                        Id = e.Id,
                        IdString = e.EmployeeId,
                        Category1 = e.DepartmentName,
                        Category2 = e.JobTitleName,
                        Name = e.EmployeeName,
                    })
                    .ToList());

            _coreData.Engineers = _coreData.Employees
                .Where(e => e.IsEngineer)
                .ToList();
        }
    }
}
