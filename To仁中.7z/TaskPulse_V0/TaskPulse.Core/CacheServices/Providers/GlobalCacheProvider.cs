using System;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.CacheServices.Providers
{
    /// <summary>
    /// ����]�w Cache Provider�C
    /// </summary>
    public class GlobalCacheProvider : CacheProviderBase
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        public override CacheKey CacheKey => CacheKeys.Global;

        public GlobalCacheProvider(CoreContext context, CoreData coreData)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _coreData = coreData ?? throw new ArgumentNullException(nameof(coreData));
        }

        protected override async Task RefreshCoreAsync(CacheRefreshContext context)
        {
            // ����]�w Cache ����ڤ��e
            // Permission �� Group �� Cache �ѥL�̦ۤv�޲z
            await Task.CompletedTask;
        }
    }
}
