using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.CacheServices.Providers
{
    /// <summary>
    /// ���ظ�� Cache Provider�C
    /// </summary>
    public class ModelCacheProvider : CacheProviderBase
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        public override CacheKey CacheKey => CacheKeys.Model;

        public ModelCacheProvider(CoreContext context, CoreData coreData)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _coreData = coreData ?? throw new ArgumentNullException(nameof(coreData));
        }

        protected override async Task RefreshCoreAsync(CacheRefreshContext context)
        {
            var tModels = await _context.Models
                .AsNoTracking()
                .ToListAsync();

            _coreData.Models = tModels
                .Select(m => new { Original = m, Key = GetModelSortKey(m.ModelName) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();

            var sortedModels = SortModelNames(_coreData.Models.Select(m => m.ModelName).Distinct())
                .SelectMany(name => _coreData.Models.Where(m => m.ModelName == name))
                .ToList();

            _coreData.ClassifyModels = ClassifyItems(
                sortedModels,
                m => m.ModelName,
                "Model",
                m => m.Id,
                m => m.ModelName
            );
        }

        private (bool IsThreeDigits, int SortKey) GetModelSortKey(string modelName)
        {
            var prefix = modelName.Split('-')[0];
            bool isThreeDigits = Regex.IsMatch(prefix, @"^\d{3}$");
            int sortKey = int.TryParse(prefix, out var n) ? n : int.MaxValue;
            return (isThreeDigits, sortKey);
        }

        private List<string> SortModelNames(IEnumerable<string> modelNames)
        {
            return modelNames
                .Select(name => new { Original = name, Key = GetModelSortKey(name) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();
        }

        private static Dictionary<string, Dictionary<string, List<ClassifyInfo>>> ClassifyItems<T>(
            IEnumerable<T> items,
            Func<T, string> categorySelector,
            string typeName,
            Func<T, int> idSelector,
            Func<T, string> nameSelector)
        {
            return items
                .GroupBy(categorySelector)
                .ToDictionary(
                    g => g.Key,
                    g => new Dictionary<string, List<ClassifyInfo>>
                    {
                        {
                            typeName,
                            g.Select(x => new ClassifyInfo
                            {
                                Id = idSelector(x),
                                Category1 = typeName,
                                Name = nameSelector(x)
                            }).ToList()
                        }
                    }
                );
        }
    }
}
