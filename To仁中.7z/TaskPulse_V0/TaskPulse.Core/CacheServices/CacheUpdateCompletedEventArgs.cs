using System;
using System.Collections.Generic;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache ��s�����ƥ��ơC
    /// </summary>
    public class CacheUpdateCompletedEventArgs : EventArgs
    {
        /// <summary>
        /// ������ Session�C
        /// </summary>
        public CacheUpdateSession Session { get; }

        /// <summary>
        /// �w��s�� Cache �M��C
        /// </summary>
        public IReadOnlyCollection<CacheKey> UpdatedCaches { get; }

        /// <summary>
        /// �O�_�������\�C
        /// </summary>
        public bool IsFullySucceeded => Session.IsFullySucceeded;

        public CacheUpdateCompletedEventArgs(CacheUpdateSession session, IReadOnlyCollection<CacheKey> updatedCaches)
        {
            Session = session ?? throw new ArgumentNullException(nameof(session));
            UpdatedCaches = updatedCaches ?? new List<CacheKey>().AsReadOnly();
        }
    }
}
