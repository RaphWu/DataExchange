using System;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache �������ߤ@�ѧO��C
    /// �C�� Cache Provider �������Ѱߤ@�� CacheKey�C
    /// </summary>
    public sealed class CacheKey : IEquatable<CacheKey>
    {
        /// <summary>
        /// Cache ���ߤ@�ѧO�W�١C
        /// </summary>
        public string Name { get; }

        /// <summary>
        /// Cache ����ܦW�١]�Ω� Log �P Debug�^�C
        /// </summary>
        public string DisplayName { get; }

        /// <summary>
        /// Cache ���u�����ǡ]�Ʀr�V�p�u����s�^�C
        /// </summary>
        public int Priority { get; }

        public CacheKey(string name, string displayName = null, int priority = 100)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentNullException(nameof(name));

            Name = name;
            DisplayName = displayName ?? name;
            Priority = priority;
        }

        public bool Equals(CacheKey other)
        {
            if (other is null) return false;
            return string.Equals(Name, other.Name, StringComparison.OrdinalIgnoreCase);
        }

        public override bool Equals(object obj) => Equals(obj as CacheKey);

        public override int GetHashCode() => StringComparer.OrdinalIgnoreCase.GetHashCode(Name);

        public override string ToString() => $"[{Name}] {DisplayName}";

        public static bool operator ==(CacheKey left, CacheKey right)
        {
            if (left is null) return right is null;
            return left.Equals(right);
        }

        public static bool operator !=(CacheKey left, CacheKey right) => !(left == right);
    }
}
