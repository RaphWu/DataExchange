using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache Provider �����O�C
    /// ���Ѧ@�Ϊ����A�޲z�P���~�B�z�޿�C
    /// </summary>
    public abstract class CacheProviderBase : ICacheProvider
    {
        private readonly object _lock = new object();
        private bool _isAvailable;
        private DateTime? _lastUpdatedAt;

        /// <inheritdoc/>
        public abstract CacheKey CacheKey { get; }

        /// <inheritdoc/>
        public bool IsAvailable
        {
            get { lock (_lock) { return _isAvailable; } }
            protected set { lock (_lock) { _isAvailable = value; } }
        }

        /// <summary>
        /// �̫��s�ɶ��C
        /// </summary>
        public DateTime? LastUpdatedAt
        {
            get { lock (_lock) { return _lastUpdatedAt; } }
            protected set { lock (_lock) { _lastUpdatedAt = value; } }
        }

        /// <inheritdoc/>
        public void Invalidate()
        {
            IsAvailable = false;
        }

        /// <inheritdoc/>
        public async Task<CacheRefreshResult> RefreshAsync(CacheRefreshContext context)
        {
            var stopwatch = Stopwatch.StartNew();

            try
            {
                // �����ڪ���s�޿�
                await RefreshCoreAsync(context);

                stopwatch.Stop();
                IsAvailable = true;
                LastUpdatedAt = DateTime.Now;

                return CacheRefreshResult.Succeeded(CacheKey, stopwatch.Elapsed);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                IsAvailable = false;

                return CacheRefreshResult.Failed(CacheKey, stopwatch.Elapsed, ex.Message, ex);
            }
        }

        /// <summary>
        /// ��ڪ���s�޿�A�Ѥl���O��@�C
        /// </summary>
        /// <param name="context">��s�W�U��C</param>
        protected abstract Task RefreshCoreAsync(CacheRefreshContext context);
    }
}
