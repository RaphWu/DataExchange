﻿#region License
// Advanced DataGridView
//
// Copyright (c), 2014 Davide Gironi <davide.gironi@gmail.com>
// Original work Copyright (c), 2013 Zuby <zuby@me.com>
//
// Please refer to LICENSE file for licensing information.
#endregion

using System;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.ADGV
{
    [System.ComponentModel.DesignerCategory("")]
    internal class TreeNodeItemSelector : TreeNode
    {

        #region 公開 列舉

        public enum CustomNodeType : byte
        {
            Default,
            SelectAll,
            SelectEmpty,
            DateTimeNode,
            Master_Slave,
        }

        #endregion


        #region 類別 欄位

        private CheckState _checkState = CheckState.Unchecked;
        private TreeNodeItemSelector _parent;

        #endregion


        #region 建構子

        /// <summary>
        /// TreeNodeItemSelector 建構子
        /// </summary>
        /// <param name="text"></param>
        /// <param name="value"></param>
        /// <param name="state"></param>
        /// <param name="nodeType"></param>
        private TreeNodeItemSelector(String text, object value, CheckState state, CustomNodeType nodeType)
            : base(text)
        {
            CheckState = state;
            NodeType = nodeType;
            Value = value;
        }

        #endregion


        #region 複製 方法

        /// <summary>
        /// 複製節點
        /// </summary>
        /// <returns></returns>
        public new TreeNodeItemSelector Clone()
        {
            TreeNodeItemSelector n = new TreeNodeItemSelector(Text, Value, _checkState, NodeType)
            {
                NodeFont = NodeFont
            };

            if (GetNodeCount(false) > 0)
            {
                foreach (TreeNodeItemSelector child in Nodes)
                    n.AddChild(child.Clone());
            }

            return n;
        }

        #endregion


        #region 公開 屬性

        /// <summary>
        /// 取得節點類型
        /// </summary>
        public CustomNodeType NodeType { get; private set; }

        /// <summary>
        /// 取得節點值
        /// </summary>
        public object Value { get; private set; }

        /// <summary>
        /// 取得節點的父節點（若不是 TreeNodeItemSelector 則回傳 null）
        /// </summary>
        new public TreeNodeItemSelector Parent
        {
            get
            {
                if (_parent is TreeNodeItemSelector)
                    return _parent;
                else
                    return null;
            }
            set
            {
                _parent = value;
            }
        }

        /// <summary>
        /// 節點是否被勾選
        /// </summary>
        new public bool Checked
        {
            get
            {
                return _checkState == CheckState.Checked;
            }
            set
            {
                CheckState = (value == true ? CheckState.Checked : CheckState.Unchecked);
            }
        }

        /// <summary>
        /// 取得或設定節點的 CheckState
        /// </summary>
        public CheckState CheckState
        {
            get
            {
                return _checkState;
            }
            set
            {
                _checkState = value;
                switch (_checkState)
                {
                    case CheckState.Checked:
                        StateImageIndex = 1;
                        break;

                    case CheckState.Indeterminate:
                        StateImageIndex = 2;
                        break;

                    default:
                        StateImageIndex = 0;
                        break;
                }
            }
        }

        #endregion


        #region 建立 節點 方法

        /// <summary>
        /// 建立節點
        /// </summary>
        /// <param name="text"></param>
        /// <param name="value"></param>
        /// <param name="state"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static TreeNodeItemSelector CreateNode(string text, object value, CheckState state, CustomNodeType type)
        {
            return new TreeNodeItemSelector(text, value, state, type);
        }

        /// <summary>
        /// 建立子節點（指定狀態）
        /// </summary>
        /// <param name="text"></param>
        /// <param name="value"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public TreeNodeItemSelector CreateChildNode(string text, object value, CheckState state)
        {
            TreeNodeItemSelector n = null;

            // 僅支援 DateTimeNode 類型的特定建立方式
            if (NodeType == CustomNodeType.DateTimeNode || NodeType == CustomNodeType.Master_Slave)
            {
                n = new TreeNodeItemSelector(text, value, state, CustomNodeType.DateTimeNode);
            }

            if (n != null)
                AddChild(n);

            return n;
        }
        public TreeNodeItemSelector CreateChildNode(string text, object value)
        {
            return CreateChildNode(text, value, _checkState);
        }

        /// <summary>
        /// 新增子節點
        /// </summary>
        /// <param name="child"></param>
        protected void AddChild(TreeNodeItemSelector child)
        {
            child.Parent = this;
            Nodes.Add(child);
        }

        #endregion

    }
}