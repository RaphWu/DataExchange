﻿using System;
using System.Runtime.Caching;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// 記憶體快取服務。
    /// </summary>
    public class MemoryCacheService
    {
        private readonly ObjectCache _cache = MemoryCache.Default;

        /// <summary>
        /// 取得或建立快取項目。
        /// </summary>
        /// <typeparam name="T">項目的型別。</typeparam>
        /// <param name="key">快取鍵。</param>
        /// <param name="factory">建立項目的函式。</param>
        /// <param name="expiration">過期時間，預設為 30 分鐘。</param>
        /// <returns>快取的項目。</returns>
        public T GetOrCreate<T>(string key, Func<CacheItemPolicy, T> factory, TimeSpan? expiration = null)
        {
            if (_cache.Contains(key))
                return (T)_cache[key];

            var policy = new CacheItemPolicy
            {
                AbsoluteExpiration = DateTimeOffset.Now.Add(expiration ?? TimeSpan.FromMinutes(30))
            };
            var value = factory(policy);
            _cache.Set(key, value, policy);
            return value;
        }

        /// <summary>
        /// 移除快取項目。
        /// </summary>
        /// <param name="key">快取鍵。</param>
        public void Remove(string key)
        {
            if (_cache.Contains(key))
                _cache.Remove(key);
        }

        /// <summary>
        /// 根據前綴移除快取項目。
        /// </summary>
        /// <param name="prefix">前綴字串。</param>
        public void RemoveByPrefix(string prefix)
        {
            foreach (var item in _cache)
            {
                if (item.Key.StartsWith(prefix))
                    _cache.Remove(item.Key);
            }
        }
    }
}
