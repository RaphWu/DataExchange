﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 維護資料庫更新訊息。
    /// </summary>
    public class RequestTaskOrderDataUpdate
    {
        public static readonly RequestTaskOrderDataUpdate Instance = new RequestTaskOrderDataUpdate();
        private RequestTaskOrderDataUpdate() { }
    }
}
