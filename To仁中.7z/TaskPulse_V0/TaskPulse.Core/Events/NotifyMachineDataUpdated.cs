﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 機台快取已更新通知。
    /// </summary>
    public class NotifyMachineDataUpdated
    {
        public static readonly NotifyMachineDataUpdated Instance = new NotifyMachineDataUpdated();
        private NotifyMachineDataUpdated() { }
    }
}
