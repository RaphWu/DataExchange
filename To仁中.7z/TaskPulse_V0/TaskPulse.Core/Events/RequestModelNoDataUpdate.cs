﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 要求更新機種快取。
    /// </summary>
    public class RequestModelNoDataUpdate
    {
        public static readonly RequestModelNoDataUpdate Instance = new RequestModelNoDataUpdate();
        private RequestModelNoDataUpdate() { }
    }
}
