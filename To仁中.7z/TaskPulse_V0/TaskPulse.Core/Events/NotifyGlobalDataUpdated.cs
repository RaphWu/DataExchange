﻿namespace Calin.TaskPulse.Core.Events
{
    public class NotifyGlobalDataUpdated
    {
        public static readonly NotifyGlobalDataUpdated Instance = new NotifyGlobalDataUpdated();
        private NotifyGlobalDataUpdated() { }
    }
}
