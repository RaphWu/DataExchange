﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Extensions;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Models;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MF_QuickCreate : UIForm
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly IMail _mail;
        private readonly IUserGroupService _userGroup;
        private readonly IEntityCacheManager _cacheManager;
        private readonly MultiSelector _mSel;
        private readonly CurrentUserContext _user;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;

        // ResultList buffers
        private List<ClassifyInfo> _defaultMachineCode = new List<ClassifyInfo>();
        private ClassifyInfo _defaultModelWs = new ClassifyInfo();
        private List<ClassifyInfo> _defaultEngineers = new List<ClassifyInfo>();
        private ClassifyInfo _defaultCreator = new ClassifyInfo();
        private List<ClassifyInfo> _defaultNotification = new List<ClassifyInfo>();

        #endregion fields

        public MF_QuickCreate(
            Serilog.ILogger logger,
            CoreContext coreContext,
            ICore core,
            IMail mail,
            IUserGroupService userGroupService,
            IEntityCacheManager entityCacheManager,
            CurrentUserContext currentUserContext,
            MaintiFlowData maintiFlowData,
            CoreData coreData,
            MultiSelector multiSelector)
        {
            InitializeComponent();
            _logger = logger;
            _context = coreContext;
            _core = core;
            _mail = mail;
            _userGroup = userGroupService;
            _cacheManager = entityCacheManager;
            _user = currentUserContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _mSel = multiSelector;

            CommonStyles.SetButton(btnCreate);
            CommonStyles.SetButton(btnCancel, isCancel: true);
        }

        private async void QuickCreate_Load(object sender, EventArgs e)
        {
            /********************
             * 
             ********************/
            var mu = await _context.MaintenanceUnits
                .OrderBy(m => m.OrderNo)
                .Select(m => new ListViewModel
                {
                    Id = m.Id,
                    Name = m.UnitName,
                })
                .ToListAsync();
            mu.Insert(0, new ListViewModel { Id = 0, Name = "" });
            MaintenanceUnit.DataSource = mu;
            MaintenanceUnit.DisplayMember = "Name";
            MaintenanceUnit.ValueMember = "Id";

            var ic = await _context.IssueCategories
                .OrderBy(i => i.OrderNo)
                .Select(i => new ListViewModel
                {
                    Id = i.Id,
                    Name = i.CategoryName,
                })
                .ToListAsync();
            ic.Insert(0, new ListViewModel { Id = 0, Name = "" });
            IssueCategory.DataSource = ic;
            IssueCategory.DisplayMember = "Name";
            IssueCategory.ValueMember = "Id";

            var ru = await _context.Departments
                .OrderBy(d => d.OrderNo)
                .Select(d => new ListViewModel
                {
                    Id = d.Id,
                    Name = d.DepartmentName,
                })
                .ToListAsync();
            ru.Insert(0, new ListViewModel { Id = 0, Name = "" });
            RequestingUnit.DataSource = ru;
            RequestingUnit.DisplayMember = "Name";
            RequestingUnit.ValueMember = "Id";

            /********************
             * 預設值
             ********************/
            //_tovm = new TaskOrderViewModel();

            if (_user.CurrentUser?.DepartmentId.HasValue ?? false)
                MaintenanceUnit.SelectedValue = (int)_user.CurrentUser.DepartmentId;
            Creator.Text = _user.IsAdmin ? "" : _user.UserName;
            Engineers.Text = _user.IsAdmin ? "" : _user.UserName;

            var now = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
            CreationDateTime.Text = now;
            AcceptedTime.Text = now;
            RepairStarted.Text = now;
            RepairCompleted.Text = now;
            RepairDuration.Text = "00:00";
            OutageStarted.Text = "";
            OutageEnded.Text = "";
            OutageDuration.Text = "00:00";

            //_bs.DataSource = _tovm;
            //_bs.MoveFirst();

            /********************
             * 
             ********************/
            int tabIdx = 0;
            Label_MachineList.Text = PropertyText.Title.Machine;
            MachineCode.DataBindings.Clear();
            //MachineCode.DataBindings.Add("Text", _tovm, PropertyText.Name.MachineCode, true, DataSourceUpdateMode.OnPropertyChanged);
            MachineCode.TabIndex = ++tabIdx;

            Label_ModelWs.Text = PropertyText.Title.ModelWsName;
            ModelWs.DataBindings.Clear();
            //ModelWs.DataBindings.Add("Text", _tovm, PropertyText.Name.ModelWsName, true, DataSourceUpdateMode.OnPropertyChanged);
            ModelWs.TabIndex = ++tabIdx;

            Label_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
            MaintenanceUnit.DataBindings.Clear();
            //MaintenanceUnit.DataBindings.Add("SelectedValue", _tovm, PropertyText.Name.MaintenanceUnitId, true, DataSourceUpdateMode.OnPropertyChanged);
            MaintenanceUnit.TabIndex = ++tabIdx;

            Label_Engineers.Text = PropertyText.Title.Engineer;
            Engineers.DataBindings.Clear();
            //Engineers.DataBindings.Add("Text", _tovm, PropertyText.Name.EngineerString, true, DataSourceUpdateMode.OnPropertyChanged);
            Engineers.TabIndex = ++tabIdx;

            Label_IssueCategory.Text = PropertyText.Title.MaintiFlowIssueCategory;
            IssueCategory.DataBindings.Clear();
            //IssueCategory.DataBindings.Add("SelectedValue", _tovm, PropertyText.Name.IssueCategoryId, true, DataSourceUpdateMode.OnPropertyChanged);
            IssueCategory.TabIndex = ++tabIdx;

            Label_RepairStarted.Text = PropertyText.Title.RepairStarted;
            RepairStarted.DataBindings.Clear();
            //RepairStarted.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairStartedString, true, DataSourceUpdateMode.OnPropertyChanged);
            RepairStarted.TabIndex = ++tabIdx;

            Label_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
            RepairCompleted.DataBindings.Clear();
            //RepairCompleted.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairCompletedString, true, DataSourceUpdateMode.OnPropertyChanged);
            RepairCompleted.TabIndex = ++tabIdx;

            Label_RepairDuration.Text = PropertyText.Title.RepairDuration;
            RepairDuration.DataBindings.Clear();
            //RepairDuration.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairDurationString, true, DataSourceUpdateMode.OnPropertyChanged);
            RepairDuration.TabIndex = ++tabIdx;

            Label_OutageStarted.Text = PropertyText.Title.OutageStarted;
            OutageStarted.DataBindings.Clear();
            //OutageStarted.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageStartedString, true, DataSourceUpdateMode.OnPropertyChanged);
            OutageStarted.TabIndex = ++tabIdx;

            Label_OutageEnded.Text = PropertyText.Title.OutageEnded;
            OutageEnded.DataBindings.Clear();
            //OutageEnded.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageEndedString, true, DataSourceUpdateMode.OnPropertyChanged);
            OutageEnded.TabIndex = ++tabIdx;

            Label_OutageDuration.Text = PropertyText.Title.OutageDuration;
            OutageDuration.DataBindings.Clear();
            //OutageDuration.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageDurationString, true, DataSourceUpdateMode.OnPropertyChanged);
            OutageDuration.TabIndex = ++tabIdx;

            Label_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
            RequestingUnit.DataBindings.Clear();
            //RequestingUnit.DataBindings.Add("SelectedValue", _tovm, PropertyText.Name.RequestingUnitId, true, DataSourceUpdateMode.OnPropertyChanged);
            RequestingUnit.TabIndex = ++tabIdx;

            Label_Creator.Text = PropertyText.Title.Creator;
            Creator.DataBindings.Clear();
            //Creator.DataBindings.Add("Text", _tovm, PropertyText.Name.CreatorName, true, DataSourceUpdateMode.OnPropertyChanged);
            Creator.TabIndex = ++tabIdx;

            Label_CreationDate.Text = PropertyText.Title.CreationDateTime;
            CreationDateTime.DataBindings.Clear();
            //CreationDateTime.DataBindings.Add("Text", _tovm, PropertyText.Name.CreationDateTimeString, true, DataSourceUpdateMode.OnPropertyChanged);
            CreationDateTime.TabIndex = ++tabIdx;

            Label_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
            AcceptedTime.DataBindings.Clear();
            //AcceptedTime.DataBindings.Add("Text", _tovm, PropertyText.Name.AcceptedTimeString, true, DataSourceUpdateMode.OnPropertyChanged);
            AcceptedTime.TabIndex = ++tabIdx;

            Label_IssueDescription.Text = PropertyText.Title.MaintiFlowIssueDescription;
            IssueDescription.DataBindings.Clear();
            //IssueDescription.DataBindings.Add("Text", _tovm, PropertyText.Name.IssueDescription, true, DataSourceUpdateMode.OnPropertyChanged);
            IssueDescription.TabIndex = ++tabIdx;

            Label_Details.Text = PropertyText.Title.Details;
            Details.DataBindings.Clear();
            //Details.DataBindings.Add("Text", _tovm, PropertyText.Name.Details, true, DataSourceUpdateMode.OnPropertyChanged);
            Details.TabIndex = ++tabIdx;

            //Label_FeedbackEmployee.Text = PropertyText.Title.FeedbackEmployee;
            //FeedbackEmployee.DataBindings.Clear();
            //FeedbackEmployee.DataBindings.Add("Text", _tovm, PropertyText.Name.FeedbackEmployeeString, true, DataSourceUpdateMode.OnPropertyChanged);

            //Label_RequestingUnitResponse.Text = PropertyText.Title.Feedback;
            //RequestingUnitFeedback.DataBindings.Clear();
            //RequestingUnitFeedback.DataBindings.Add("Text", _tovm, PropertyText.Name.Feedback, true, DataSourceUpdateMode.OnPropertyChanged);

            //Label_FillingTime.Text = PropertyText.Title.FillingTime;
            //FillingTime.DataBindings.Clear();
            //FillingTime.DataBindings.Add("Value", _tovm, PropertyText.Name.FillingTime, true, DataSourceUpdateMode.OnPropertyChanged);

            //Label_Responsible.Text = PropertyText.Title.Responsible;
            //Responsible.DataBindings.Clear();
            //Responsible.DataBindings.Add("Text", _tovm, PropertyText.Name.Responsible, true, DataSourceUpdateMode.OnPropertyChanged);

        }

        //private async Task LoadData()
        //{
        //    var mu = await _context.MaintenanceUnits
        //        .OrderBy(m => m.OrderNo)
        //        .Select(m => new ListViewModel
        //        {
        //            Id = m.Id,
        //            Name = m.UnitName,
        //        })
        //        .ToListAsync();
        //    MaintenanceUnit.DataSource = mu;
        //    MaintenanceUnit.DisplayMember = "Name";
        //    MaintenanceUnit.ValueMember = "Id";

        //    var ic = await _context.IssueCategories
        //        .OrderBy(i => i.OrderNo)
        //        .Select(i => new ListViewModel
        //        {
        //            Id = i.Id,
        //            Name = i.CategoryName,
        //        })
        //        .ToListAsync();
        //    ic.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
        //    IssueCategory.DataSource = ic;
        //    IssueCategory.DisplayMember = "Name";
        //    IssueCategory.ValueMember = "Id";

        //    var ru = await _context.Departments
        //        .OrderBy(d => d.OrderNo)
        //        .Select(d => new ListViewModel
        //        {
        //            Id = d.Id,
        //            Name = d.DepartmentName,
        //        })
        //        .ToListAsync();
        //    ru.Insert(0, new ListViewModel { Id = 0, Name = "-- 請選擇 --" });
        //    RequestingUnit.DataSource = ru;
        //    RequestingUnit.DisplayMember = "Name";
        //    RequestingUnit.ValueMember = "Id";
        //}

        private void btnCancel_Click(object sender, EventArgs ea)
        {
            this.Close();
        }

        private async void btnSave_Click(object sender, EventArgs ea)
        {
            // 拆解機台編號
            var machineCodeList = MachineCode.Text
                .Split(new char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
            int machineCounter = machineCodeList.Count;
            var creator = _coreData.Employees.FirstOrDefault(c => c.EmployeeName == (string)Creator.Text);

            try
            {
                var deviceList = new List<Machine>();

                // 計算新工單號
                var tos = _context.TaskOrders;
                var _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                var _lastWorkOrderNo = tos
                    .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                    .Select(w => w.WorkOrderNo)
                    .AsEnumerable()
                    .Select(o => int.TryParse(o.Substring(8, 3), out int val) ? val : 0)
                    .DefaultIfEmpty(0)
                    .Max();

                // 加入資料庫
                int rUnitId = (int)RequestingUnit.SelectedValue;

                DateTime startRepair = DateTime.TryParse(RepairStarted.Text, out DateTime dtR) ? dtR : DateTime.Now;
                DateTime endRepair = DateTime.TryParse(RepairCompleted.Text, out DateTime dtRC) ? dtRC : DateTime.Now;
                TimeSpan totalDuration = endRepair - startRepair;
                TimeSpan interval = TimeSpan.FromTicks(totalDuration.Ticks / machineCounter);
                DateTime currentStartRepair = startRepair;
                DateTime currentEndRepair = startRepair;

                var newTaskOrders = new List<TaskOrder>();
                var newTaskOrder = new TaskOrder();
                for (int no = 1; no <= machineCounter; no++)
                {
                    string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                    string machineCode = machineCodeList[no - 1];

                    currentStartRepair = currentEndRepair;
                    currentEndRepair = no == machineCounter ? endRepair : currentStartRepair + interval;

                    newTaskOrder = new TaskOrder()
                    {
                        WorkOrderNo = newWorkOrderNo,
                        CreatorId = creator?.Id ?? 0,
                        RequestingUnitId = rUnitId,
                        Status = FlowStatus.InProgress,
                        MachineId = _context.Machines.FirstOrDefault(x => x.MachineCode == machineCode)?.Id,

                        CreationDateString = CreationDateTime.Text,
                        AcceptedTimeString = AcceptedTime.Text,
                        FillingTime = DateTime.Now,

                        RepairStarted = currentStartRepair,
                        RepairCompleted = currentEndRepair,
                        RepairDuration = TimeSpan.TryParse(interval.ToString(), out TimeSpan rt) ? rt : TimeSpan.Zero,
                        //RepairStartedString = currentStartRepair.ToString("yyyy-MM-dd HH:mm:ss"),
                        //RepairCompletedString = currentEndRepair.ToString("yyyy-MM-dd HH:mm:ss"),
                        //RepairDurationString = (currentEndRepair - currentStartRepair).ToString(@"d\.hh\:mm\:ss"),
                        OutageStarted = OutageStarted.Value,
                        OutageEnded = OutageEnded.Value,
                        OutageDuration = TimeSpan.TryParse(OutageDuration.Text, out TimeSpan ts) ? ts : TimeSpan.Zero,

                        MaintenanceUnitId = (int?)MaintenanceUnit.SelectedValue,
                        IssueCategoryId = (int?)IssueCategory.SelectedValue,
                        IssueDescription = IssueDescription.Text,
                        Details = Details.Text,
                    };

                    newTaskOrder.Engineers = newTaskOrder.GetEngineers(StringExtensions.SplitCleanFast(Engineers.Text, '»', ';', ','), _context);
                    newTaskOrder.WorkstationId = newTaskOrder.GetWorkstationId(ModelWs.Text, _context);

                    _context.TaskOrders.Add(newTaskOrder);
                    newTaskOrders.Add(newTaskOrder);
                }

                await _context.SaveChangesAsync();
                _cacheManager.RequestTaskOrderUpdate();

                // send email
                StringBuilder mail = new StringBuilder();
                mail.Append("<table><caption>新建工單 (補單)</caption>");

                mail.Append("<tr>");
                mail.Append("<td>機種 » 工站</td>");
                mail.Append($"<td>{newTaskOrders[0].ModelWsName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>工單建立者</td>");
                mail.Append($"<td>{creator.EmployeeName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>維護工程師</td>");
                mail.Append($"<td>{string.Join("<br/>", newTaskOrders[0].Engineers.Select(emp => emp.EmployeeId + ", " + emp.EmployeeName))}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動開始時間</td>");
                mail.Append($"<td>{newTaskOrders[0].OutageStartedString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動結束時間</td>");
                mail.Append($"<td>{newTaskOrders[0].OutageEndedString} ({newTaskOrders[0].OutageDurationString})</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>問題描述</td>");
                mail.Append($"<td>{newTaskOrders[0].IssueDescription}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>維護內容</td>");
                mail.Append($"<td>{newTaskOrders[0].Details}</td>");
                mail.Append("</tr>");
                mail.Append("</table>");

                mail.Append("<p><table><caption>工單列表</caption>");
                mail.Append("<tr><th>工單</th><th>機台</th><th>維護開始時間</th><th>維護完成時間</th></tr>");
                List<string> oms = new List<string>();
                foreach (var wo in newTaskOrders)
                {
                    oms.Add($"{wo.WorkOrderNo}: {wo.FullMachineName}");

                    mail.Append("<tr>");
                    mail.Append($"<td>{wo.WorkOrderNo}</td>");
                    mail.Append($"<td>{wo.FullMachineName}</td>");
                    mail.Append($"<td>{wo.RepairStartedString}</td>");
                    mail.Append($"<td>{wo.RepairCompletedString} ({wo.RepairDurationString})</td>");
                    mail.Append("</tr>");
                }
                mail.Append("</table></p>");

                var mailList = new HashSet<int>() { _user.UserId };
                if (creator != null)
                    mailList.Add(creator.Id);

                foreach (var notiEmp in Notification.Text.SplitClean(';', ','))
                {
                    var emp = _coreData.Employees.FirstOrDefault(em => em.EmployeeName == notiEmp);
                    if (emp != null)
                        mailList.Add(emp.Id);
                }

                foreach (var emp in newTaskOrders)
                    mailList.UnionWith(emp.Engineers.Select(e => e.Id).ToList());

                _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                    $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][新建工單] {creator.EmployeeName} 新建 {newTaskOrders.Count} 張維護工單。",
                    mail.ToString());

                MessageBox.Show($"下列工單已建立：\n{string.Join("\n", oms)}",
                                "工單建立成功！",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                string errMsg = "補單：工單建立失敗";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg);
            }
        }

        private async void btnCreate_Click(object sender, EventArgs ea)
        {
            // 拆解機台編號
            var machineCodeList = MachineCode.Text
                .Split(new char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
            int machineCounter = machineCodeList.Count;
            var creator = _coreData.Employees.FirstOrDefault(c => c.EmployeeName == (string)Creator.Text);

            // 錯誤檢查
            StringBuilder err = new StringBuilder();

            if (string.IsNullOrWhiteSpace(Notification.Text))
            {
                if (MessageBox.Show("沒有設定通知人員，是否繼續？",
                                    "確定",
                                    MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Warning) == DialogResult.No)
                    return;

                foreach (var notiEmp in Notification.Text.SplitClean(';', ','))
                {
                    var emp = _coreData.Employees.FirstOrDefault(e => e.EmployeeName == notiEmp);
                    if (emp == null)
                        err.AppendLine($"查無此人：{notiEmp}！");
                }
            }

            if (string.IsNullOrWhiteSpace(ModelWs.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.ModelWsName}！");

            if (string.IsNullOrWhiteSpace(MaintenanceUnit.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.MaintenanceUnit}！");

            if (string.IsNullOrWhiteSpace(Engineers.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.Engineer}！");

            if (string.IsNullOrWhiteSpace(IssueCategory.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.MaintiFlowIssueCategory}！");

            if (string.IsNullOrWhiteSpace(RepairStarted.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.RepairStarted}！");

            if (string.IsNullOrWhiteSpace(RequestingUnit.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.RequestingUnit}！");

            if (string.IsNullOrWhiteSpace(Creator.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.Creator}！");
            else if (creator == null)
                err.AppendLine($"查無此人：{Creator.Tag}！");

            if (string.IsNullOrWhiteSpace(MachineCode.Text))
            {
                err.AppendLine($"沒有輸入 {PropertyText.Title.Machine}！");
            }
            else
            {
                foreach (var mCode in machineCodeList)
                    if (_coreData.Machines.FindIndex(x => x.MachineCode == mCode) == -1)
                        err.AppendLine($"{PropertyText.Title.Machine}不存在: {mCode}");
            }

            if (RepairCompleted.Value < RepairStarted.Value)
                err.AppendLine($"{PropertyText.Title.RepairCompleted} 必須大於等於 {PropertyText.Title.RepairStarted}！");

            if (!string.IsNullOrEmpty(OutageStarted.Text) && string.IsNullOrEmpty(OutageEnded.Text))
                err.AppendLine($"有 {PropertyText.Title.OutageStarted} 但沒有 {PropertyText.Title.OutageEnded}！");

            if (string.IsNullOrEmpty(OutageStarted.Text) && !string.IsNullOrEmpty(OutageEnded.Text))
                err.AppendLine($"有 {PropertyText.Title.OutageEnded} 但沒有 {PropertyText.Title.OutageStarted}！");

            if (!string.IsNullOrEmpty(OutageStarted.Text) && !string.IsNullOrEmpty(OutageEnded.Text)
                && (OutageStarted.Value > OutageEnded.Value))
                err.AppendLine($"{PropertyText.Title.OutageEnded} 必須大於等於 {PropertyText.Title.OutageStarted}！");

            if (!string.IsNullOrEmpty(RepairCompleted.Text) && !string.IsNullOrEmpty(OutageEnded.Text) &&
                (RepairCompleted.Value < OutageEnded.Value))
                err.AppendLine($"{PropertyText.Title.RepairCompleted} 必須大於等於 {PropertyText.Title.OutageEnded}！");

            if (err.Length > 0)
            {
                err.Append("\n注意：資料尚未儲存！");
                MessageBox.Show(err.ToString(),
                    "輸入資料不正確",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            try
            {
                var deviceList = new List<Machine>();

                // 計算新工單號
                var tos = _context.TaskOrders;
                var _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                var _lastWorkOrderNo = tos
                    .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                    .Select(w => w.WorkOrderNo)
                    .AsEnumerable()
                    .Select(o => int.TryParse(o.Substring(8, 3), out int val) ? val : 0)
                    .DefaultIfEmpty(0)
                    .Max();

                // 加入資料庫
                int rUnitId = (int)RequestingUnit.SelectedValue;

                DateTime startRepair = DateTime.TryParse(RepairStarted.Text, out DateTime dtR) ? dtR : DateTime.Now;
                DateTime endRepair = DateTime.TryParse(RepairCompleted.Text, out DateTime dtRC) ? dtRC : DateTime.Now;
                TimeSpan totalDuration = endRepair - startRepair;
                TimeSpan interval = TimeSpan.FromTicks(totalDuration.Ticks / machineCounter);
                DateTime currentStartRepair = startRepair;
                DateTime currentEndRepair = startRepair;

                var newTaskOrders = new List<TaskOrder>();
                var newTaskOrder = new TaskOrder();
                for (int no = 1; no <= machineCounter; no++)
                {
                    string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                    string machineCode = machineCodeList[no - 1];

                    currentStartRepair = currentEndRepair;
                    currentEndRepair = no == machineCounter ? endRepair : currentStartRepair + interval;

                    newTaskOrder = new TaskOrder()
                    {
                        WorkOrderNo = newWorkOrderNo,
                        CreatorId = creator?.Id ?? 0,
                        RequestingUnitId = rUnitId,
                        Status = FlowStatus.Pending,
                        MachineId = _context.Machines.FirstOrDefault(x => x.MachineCode == machineCode)?.Id,

                        CreationDateString = CreationDateTime.Text,
                        AcceptedTimeString = AcceptedTime.Text,
                        FillingTime = DateTime.Now,

                        RepairStarted = currentStartRepair,
                        RepairCompleted = currentEndRepair,
                        RepairDuration = TimeSpan.TryParse(interval.ToString(), out TimeSpan rt) ? rt : TimeSpan.Zero,
                        //RepairStartedString = currentStartRepair.ToString("yyyy-MM-dd HH:mm:ss"),
                        //RepairCompletedString = currentEndRepair.ToString("yyyy-MM-dd HH:mm:ss"),
                        //RepairDurationString = (currentEndRepair - currentStartRepair).ToString(@"d\.hh\:mm\:ss"),
                        OutageStarted = OutageStarted.Value,
                        OutageEnded = OutageEnded.Value,
                        OutageDuration = TimeSpan.TryParse(OutageDuration.Text, out TimeSpan ts) ? ts : TimeSpan.Zero,

                        MaintenanceUnitId = (int?)MaintenanceUnit.SelectedValue,
                        IssueCategoryId = (int?)IssueCategory.SelectedValue,
                        IssueDescription = IssueDescription.Text,
                        Details = Details.Text,
                    };

                    newTaskOrder.Engineers = newTaskOrder.GetEngineers(StringExtensions.SplitCleanFast(Engineers.Text, '»', ';', ','), _context);
                    newTaskOrder.WorkstationId = newTaskOrder.GetWorkstationId(ModelWs.Text, _context);

                    _context.TaskOrders.Add(newTaskOrder);
                    newTaskOrders.Add(newTaskOrder);
                }

                await _context.SaveChangesAsync();
                _cacheManager.RequestTaskOrderUpdate();

                // send email
                StringBuilder mail = new StringBuilder();

                mail.Append("<table><caption>維護完成</caption>");

                mail.Append("<tr>");
                mail.Append("<td>機種 » 工站</td>");
                mail.Append($"<td>{newTaskOrders[0].ModelWsName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>工單建立者</td>");
                mail.Append($"<td>{creator.EmployeeName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>維護工程師</td>");
                mail.Append($"<td>{string.Join("<br/>", newTaskOrders[0].Engineers.Select(emp => emp.EmployeeId + ", " + emp.EmployeeName))}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動開始時間</td>");
                mail.Append($"<td>{newTaskOrders[0].OutageStartedString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動結束時間</td>");
                mail.Append($"<td>{newTaskOrders[0].OutageEndedString} ({newTaskOrders[0].OutageDurationString})</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>問題描述</td>");
                mail.Append($"<td>{newTaskOrders[0].IssueDescription}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>維護內容</td>");
                mail.Append($"<td>{newTaskOrders[0].Details}</td>");
                mail.Append("</tr>");
                mail.Append("</table>");

                mail.Append("<p><table><caption>工單列表</caption>");
                mail.Append("<tr><th>工單</th><th>機台</th><th>維護開始時間</th><th>維護完成時間</th></tr>");
                List<string> oms = new List<string>();
                foreach (var wo in newTaskOrders)
                {
                    oms.Add($"{wo.WorkOrderNo}: {wo.FullMachineName}");

                    mail.Append("<tr>");
                    mail.Append($"<td>{wo.WorkOrderNo}</td>");
                    mail.Append($"<td>{wo.FullMachineName}</td>");
                    mail.Append($"<td>{wo.RepairStartedString}</td>");
                    mail.Append($"<td>{wo.RepairCompletedString} ({wo.RepairDurationString})</td>");
                    mail.Append("</tr>");
                }
                mail.Append("</table></p>");

                mail.AppendLine(@"<p>請生產單位確認，點擊 <a href='\\172.16.254.45\共用區\量產移行用\生技--\TaskPulse\TaskPulse.exe'>此處</a> 開啟維護工單程式。</p>");

                var mailList = new HashSet<int>() { _user.UserId };
                if (creator != null)
                    mailList.Add(creator.Id);

                foreach (var notiEmp in Notification.Text.SplitClean(';', ','))
                {
                    var emp = _coreData.Employees.FirstOrDefault(em => em.EmployeeName == notiEmp);
                    if (emp != null)
                        mailList.Add(emp.Id);
                }

                foreach (var emp in newTaskOrders)
                    mailList.UnionWith(emp.Engineers.Select(e => e.Id).ToList());

                foreach (var to in newTaskOrders)
                {
                    var machine = _coreData.Machines
                    .FirstOrDefault(m => m.MachineCode == to.MachineCode);
                    if (machine != null)
                    {
                        var members = _userGroup.GetEmployeesFromMachineUserGroups(machine);
                        foreach (var emp in members)
                        {
                            if (!mailList.Contains(emp.Id))
                                mailList.Add(emp.Id);
                        }
                    }
                }

                _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                    $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][新建工單] {creator.EmployeeName} 新建 {newTaskOrders.Count} 張維護工單。",
                    mail.ToString());

                MessageBox.Show($"下列工單已建立：\n{string.Join("\n", oms)}",
                                "工單建立成功！",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                string errMsg = "補單：工單建立失敗";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg);
            }
        }

        private void MachineList_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.Machine}";
            _mSel.TreeViewCaption = "機台";
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.MachinesMultiTabPageCache;
            _mSel.DefaultSelect = _defaultMachineCode;
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                _defaultMachineCode = _mSel.ResultList;
                MachineCode.Text = _defaultMachineCode.Count > 0
                    ? string.Join("; ", _defaultMachineCode.Select(r => r.Name).ToArray())
                    : "";
            }
        }

        private void ModelWs_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.ModelName}";
            _mSel.TreeViewCaption = "機種";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultModelWs };
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultModelWs = _mSel.ResultList[0];
                    var ws = _core.GetWorkstation(_defaultModelWs.Id);
                    var model = _core.GetModel(ws.ModelId.HasValue ? (int)ws.ModelId : 0);
                    ModelWs.Text = $"{model.ModelName} » {ws.WorkstationName}";
                }
                else
                {
                    ModelWs.Text = "";
                }
            }
        }

        private void Engineers_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = false;
            _mSel.Title = $"請選擇{PropertyText.Title.Engineer}";
            _mSel.DialogWidth = 600;
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EngineerMultiTabPageCache;
            _mSel.DefaultSelect = _defaultEngineers;
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                _defaultEngineers = _mSel.ResultList;
                List<string> emps = new List<string>();
                foreach (var emp in _defaultEngineers)
                    emps.Add(emp.Name);
                Engineers.Text = string.Join("; ", emps);
            }
        }

        private void Creator_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultCreator };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultCreator = _mSel.ResultList[0];
                    var emp = _defaultCreator;
                    Creator.Text = emp.Name;
                }
                else
                {
                    Creator.Text = "";
                }
            }
        }

        //private bool _isRepairStartedTyping = false; // 是否使用鍵盤輸入

        //private void RepairStarted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isRepairStartedTyping = true;
        //}

        //private void RepairStarted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isRepairStartedTyping = false;
        //    ValidateAndUpdateRepairStarted();
        //}

        //private void RepairStarted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isRepairStartedTyping) return;
        //    ValidateAndUpdateRepairStarted();
        //}
        //private void ValidateAndUpdateRepairStarted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.RepairStarted = DateTime.TryParse(RepairStarted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateRepairDuration();
        //}

        //private bool _isRepairCompletedTyping = false; // 是否使用鍵盤輸入

        //private void RepairCompleted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isRepairCompletedTyping = true;
        //}

        //private void RepairCompleted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isRepairCompletedTyping = false;
        //    ValidateAndUpdateRepairCompleted();
        //}

        //private void RepairCompleted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isRepairCompletedTyping) return;
        //    ValidateAndUpdateRepairCompleted();
        //}
        //private void ValidateAndUpdateRepairCompleted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.RepairCompleted = DateTime.TryParse(RepairCompleted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateRepairDuration();
        //}

        //private void UpdateRepairDuration()
        //{
        //    if (_tovm.RepairStarted != null)
        //    {
        //        _tovm.RepairDuration = _tovm.RepairCompleted != null
        //            ? (TimeSpan)(_tovm.RepairCompleted - _tovm.RepairStarted)
        //            : (TimeSpan)(DateTime.Now - _tovm.RepairStarted);
        //    }
        //    else
        //    {
        //        _tovm.RepairDuration = TimeSpan.Zero;
        //    }
        //    string days = _tovm.RepairDuration.Days > 0 ? $"{_tovm.RepairDuration.Days}天 " : "";
        //    RepairDuration.Text = $"{days}{_tovm.RepairDuration.Hours:D2}:{_tovm.RepairDuration.Minutes:D2}";
        //}

        //private bool _isOutageStartedTyping = false; // 是否使用鍵盤輸入

        //private void OutageStarted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isOutageStartedTyping = true;
        //}

        //private void OutageStarted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isOutageStartedTyping = false;
        //    ValidateAndUpdateOutageStarted();
        //}

        //private void OutageStarted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isOutageStartedTyping) return;
        //    ValidateAndUpdateOutageStarted();
        //}
        //private void ValidateAndUpdateOutageStarted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.OutageStarted = DateTime.TryParse(OutageStarted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateOutageDuration();
        //}

        //private bool _isOutageEndedTyping = false; // 是否使用鍵盤輸入

        //private void OutageEnded_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isOutageEndedTyping = true;
        //}

        //private void OutageEnded_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isOutageEndedTyping = false;
        //    ValidateAndUpdateOutageEnded();
        //}

        //private void OutageEnded_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isOutageEndedTyping) return;
        //    ValidateAndUpdateOutageEnded();
        //}

        //private void ValidateAndUpdateOutageEnded()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.OutageEnded = DateTime.TryParse(OutageEnded.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateOutageDuration();
        //}

        //private void UpdateOutageDuration()
        //{
        //    if (_tovm.OutageStarted != null)
        //    {
        //        _tovm.OutageDuration = _tovm.OutageEnded != null
        //            ? (TimeSpan)(_tovm.OutageEnded - _tovm.OutageStarted)
        //            : (TimeSpan)(DateTime.Now - _tovm.OutageStarted);
        //    }
        //    else
        //    {
        //        _tovm.OutageDuration = TimeSpan.Zero;
        //    }
        //    string days = _tovm.OutageDuration.Days > 0 ? $"{_tovm.OutageDuration.Days}天 " : "";
        //    OutageDuration.Text = $"{days}{_tovm.OutageDuration.Hours:D2}:{_tovm.OutageDuration.Minutes:D2}";
        //}

        private void Notification_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EmployeeMultiTabPageCache;
            _mSel.DefaultSelect = _defaultNotification;
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultNotification = _mSel.ResultList;
                    List<string> emps = new List<string>();
                    foreach (var emp in _defaultNotification)
                        emps.Add(emp.Name);
                    Notification.Text = string.Join("; ", emps);
                }
                else
                {
                    Notification.Text = "";
                }
            }
        }
    }
}