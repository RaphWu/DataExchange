﻿using System;
using System.IO;
using FluentMigrator.Runner;
using Microsoft.Extensions.DependencyInjection;

namespace TaskPulse.Migrations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var serviceProvider = CreateServices();

            using (var scope = serviceProvider.CreateScope())
            {
                UpdateDatabase(scope.ServiceProvider);
            }
        }

        private static IServiceProvider CreateServices()
        {
            return new ServiceCollection()
                .AddFluentMigratorCore()
                .ConfigureRunner(rb => rb
                    .AddSQLite() // 使用 SQLite Runner
                    .WithGlobalConnectionString("Data Source=../../../TaskPulse/bin/Debug/TaskPulse.sqlite;Version=3;") // 指向主專案的資料庫
                    .ScanIn(typeof(Program).Assembly).For.Migrations()) // 掃描遷移檔案
                .AddLogging(lb => lb.AddFluentMigratorConsole()) // 添加日誌
                .BuildServiceProvider(false);
        }

        private static void UpdateDatabase(IServiceProvider serviceProvider)
        {
            var runner = serviceProvider.GetRequiredService<IMigrationRunner>();
            runner.MigrateUp(); // 執行所有尚未執行的遷移
        }
    }
}
