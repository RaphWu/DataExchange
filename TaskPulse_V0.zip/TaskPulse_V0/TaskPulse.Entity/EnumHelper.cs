﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace Calin.TaskPulse.Entity
{
    public static class EnumHelper
    {
        /// <summary>
        /// 取得與列舉值相關聯的描述。
        /// </summary>
        /// <remarks>此方法會檢查指定的列舉值上是否存在 <see cref="DescriptionAttribute"/>。若找到該屬性，則會回傳其描述；否則方法會回傳該列舉值的字串表示。</remarks>
        /// <param name="enumValue">要取得描述的列舉值。</param>
        /// <returns>套用於該列舉值之 <see cref="DescriptionAttribute"/> 所指定的描述；若沒有描述屬性，則回傳該列舉值的名稱。</returns>
        public static string GetDescription(this Enum enumValue)
        {
            DescriptionAttribute[] array = (DescriptionAttribute[])enumValue.GetType().GetField(enumValue.ToString()).GetCustomAttributes(typeof(DescriptionAttribute), inherit: false);
            if (array != null && array.Length != 0)
            {
                return array[0].Description;
            }

            return enumValue.ToString();
        }

        /// <summary>
        /// 取得屬性的 Description。
        /// </summary>
        /// <param name="T">資料物件。</param>
        /// <param name="propertyName">屬性名稱。</param>
        public static string GetDescription<T>(string propertyName)
        {
            PropertyInfo property = typeof(T).GetProperty(propertyName);
            if (property == null)
            {
                return null;
            }

            return property.GetCustomAttribute<DescriptionAttribute>()?.Description;
        }

        public static T GetEnumByDescription<T>(this string description)
        {
            foreach (FieldInfo fi in typeof(T).GetFields())
            {
                DescriptionAttribute[] attributes =
                    (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attributes.Length > 0 && attributes[0].Description == description)
                    return (T)fi.GetValue(null);

                if (fi.Name == description)
                    return (T)fi.GetValue(null);
            }
            //throw new ArgumentException($"找不到描述：{description}");
            return default;
        }
    }
}
