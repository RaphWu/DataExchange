﻿//namespace Calin.TaskPulse.Core.Events
//{
//    public class RequestGlobalDataUpdate
//    {
//        public static readonly RequestGlobalDataUpdate Instance = new RequestGlobalDataUpdate();
//        private RequestGlobalDataUpdate() { }
//    }
//}
