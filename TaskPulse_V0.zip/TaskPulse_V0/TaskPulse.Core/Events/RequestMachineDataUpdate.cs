﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 要求更新機台快取。
    /// </summary>
    public class RequestMachineDataUpdate
    {
        public static readonly RequestMachineDataUpdate Instance = new RequestMachineDataUpdate();
        private RequestMachineDataUpdate() { }
    }
}
