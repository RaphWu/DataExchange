﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 要求更新工站快取。
    /// </summary>
    public class RequestWorkstationDataUpdate
    {
        public static readonly RequestWorkstationDataUpdate Instance = new RequestWorkstationDataUpdate();
        private RequestWorkstationDataUpdate() { }
    }
}
