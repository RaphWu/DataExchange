﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 要求更新員工快取。
    /// </summary>
    public class RequestEmployeeDataUpdate
    {
        public static readonly RequestEmployeeDataUpdate Instance = new RequestEmployeeDataUpdate();
        private RequestEmployeeDataUpdate() { }
    }
}
