﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 工站快取已更新通知。
    /// </summary>
    public class NotifyWorkstationDataUpdated
    {
        public static readonly NotifyWorkstationDataUpdated Instance = new NotifyWorkstationDataUpdated();
        private NotifyWorkstationDataUpdated() { }
    }
}
