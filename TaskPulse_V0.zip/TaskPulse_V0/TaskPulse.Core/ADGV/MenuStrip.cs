﻿#region License
// Advanced DataGridView
//
// Copyright (c), 2014 Davide Gironi <davide.gironi@gmail.com>
// Original work Copyright (c), 2013 Zuby <zuby@me.com>
//
// Please refer to LICENSE file for licensing information.
#endregion

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Calin.TaskPulse.Core.Extensions;
using Sunny.UI;
using static Calin.TaskPulse.Core.ADGV.TreeNodeItemSelector;

namespace Calin.TaskPulse.Core.ADGV
{

    [System.ComponentModel.DesignerCategory("")]
    internal partial class MenuStrip : ContextMenuStrip
    {

        #region 公開 列舉

        /// <summary>
        /// MenuStrip 篩選類型
        /// </summary>
        public enum FilterType : byte
        {
            None = 0,
            Custom = 1,
            CheckList = 2,
            Loaded = 3
        }


        /// <summary>
        /// MenuStrip 排序類型
        /// </summary>
        public enum SortType : byte
        {
            None = 0,
            ASC = 1,
            DESC = 2
        }

        #endregion


        #region 公開 常數

        /// <summary>
        /// 預設 checklist 篩選在搜尋時是否移除節點的行為
        /// </summary>
        public const bool DefaultCheckTextFilterRemoveNodesOnSearch = true;

        /// <summary>
        /// 預設 checklist 篩選最大節點數量
        /// </summary>
        public const int DefaultMaxChecklistNodes = 10000;

        /// <summary>
        /// 啟用文字篩選 TextChanged 延遲的預設節點數量門檻
        /// </summary>
        public const int DefaultTextFilterTextChangedDelayNodes = 1000;

        /// <summary>
        /// 用於停用文字篩選 TextChanged 延遲的節點數量標記
        /// </summary>
        public const int TextFilterTextChangedDelayNodesDisabled = -1;

        /// <summary>
        /// 文字篩選 TextChanged 延遲的預設毫秒數
        /// </summary>
        public const int DefaultTextFilterTextChangedDelayMs = 300;

        #endregion


        #region 類別 欄位

        private FilterType _activeFilterType = FilterType.None;
        private SortType _activeSortType = SortType.None;
        private TreeNodeItemSelector[] _loadedNodes = new TreeNodeItemSelector[] { };
        private TreeNodeItemSelector[] _startingNodes = new TreeNodeItemSelector[] { };
        private TreeNodeItemSelector[] _removedNodes = new TreeNodeItemSelector[] { };
        private TreeNodeItemSelector[] _removedsessionNodes = new TreeNodeItemSelector[] { };
        private string _sortString = null;
        private string _filterString = null;
        private static Point _resizeStartPoint = new Point(1, 1);
        private Point _resizeEndPoint = new Point(-1, -1);
        private bool _checkTextFilterChangedEnabled = true;
        private bool _checkTextFilterRemoveNodesOnSearch = DefaultCheckTextFilterRemoveNodesOnSearch;
        private int _maxChecklistNodes = DefaultMaxChecklistNodes;
        private bool _filterclick = false;
        private Timer _textFilterTextChangedTimer;
        private int _textFilterTextChangedDelayNodes = DefaultTextFilterTextChangedDelayNodes;
        private int _textFilterTextChangedDelayMs = DefaultTextFilterTextChangedDelayMs;

        #endregion


        #region 建構子

        /// <summary>
        /// MenuStrip 建構子
        /// </summary>
        /// <param name="dataType"></param>
        public MenuStrip(Type dataType)
            : base()
        {
            // 初始化元件
            InitializeComponent();

            // 設定資料類型
            SetDataType(dataType);

            // 設定元件的翻譯文字
            cancelSortMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVClearSort.ToString()];
            cancelFilterMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVClearFilter.ToString()];
            customFilterMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVAddCustomFilter.ToString()];
            button_filter.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVButtonFilter.ToString()];
            button_undofilter.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVButtonUndofilter.ToString()];

            // 設定預設 NOT IN 邏輯
            IsFilterNOTINLogicEnabled = false;

            // 設定各項功能預設為啟用
            IsSortEnabled = true;
            IsFilterEnabled = true;
            IsFilterChecklistEnabled = true;
            IsFilterDateAndTimeEnabled = true;
            FilterTextFocusOnShow = false;

            // 在到達 ResizeBox 前先依縮放比例調整，確保右下角縮放控制顯示正常
            float scalingfactor = GetScalingFactor();
            MinimumSize = new Size(Scale(PreferredSize.Width, scalingfactor), Scale(PreferredSize.Height, scalingfactor));
            // 設定不會改變的控制項尺寸
            resizeBoxControlHost.Height = Scale(resizeBoxControlHost.Height, scalingfactor);
            resizeBoxControlHost.Width = Scale(resizeBoxControlHost.Width, scalingfactor);
            toolStripSeparator1MenuItem.Height = Scale(toolStripSeparator1MenuItem.Height, scalingfactor);
            toolStripSeparator2MenuItem.Height = Scale(toolStripSeparator2MenuItem.Height, scalingfactor);
            toolStripSeparator3MenuItem.Height = Scale(toolStripSeparator3MenuItem.Height, scalingfactor);
            sortASCMenuItem.Height = Scale(sortASCMenuItem.Height, scalingfactor);
            sortDESCMenuItem.Height = Scale(sortDESCMenuItem.Height, scalingfactor);
            cancelSortMenuItem.Height = Scale(cancelSortMenuItem.Height, scalingfactor);
            cancelFilterMenuItem.Height = Scale(cancelFilterMenuItem.Height, scalingfactor);
            customFilterMenuItem.Height = Scale(customFilterMenuItem.Height, scalingfactor);
            customFilterLastFiltersListMenuItem.Height = Scale(customFilterLastFiltersListMenuItem.Height, scalingfactor);
            checkTextFilterControlHost.Height = Scale(checkTextFilterControlHost.Height, scalingfactor);
            button_filter.Width = Scale(button_filter.Width, scalingfactor);
            button_filter.Height = Scale(button_filter.Height, scalingfactor);
            button_undofilter.Width = Scale(button_undofilter.Width, scalingfactor);
            button_undofilter.Height = Scale(button_undofilter.Height, scalingfactor);
            // 依最小尺寸重新配置
            ResizeBox(MinimumSize.Width, MinimumSize.Height);

            _textFilterTextChangedTimer = new Timer();
            _textFilterTextChangedTimer.Interval = _textFilterTextChangedDelayMs;
            _textFilterTextChangedTimer.Tick += new EventHandler(this.CheckTextFilterTextChangedTimer_Tick);

            //checkList.Font = checkList.Parent.Font;

            CommonStyles.SetButton(button_filter);
            CommonStyles.SetButton(button_undofilter, isCancel: true);
        }

        /// <summary>
        /// Closed 事件處理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuStrip_Closed(Object sender, EventArgs e)
        {
            ResizeClean();

            if (_checkTextFilterRemoveNodesOnSearch && !_filterclick)
            {
                _loadedNodes = DuplicateNodes(_startingNodes);
            }

            _startingNodes = new TreeNodeItemSelector[] { };

            _checkTextFilterChangedEnabled = false;
            checkTextFilter.Text = "";
            _checkTextFilterChangedEnabled = true;
        }

        /// <summary>
        /// LostFocus 事件，若不含焦點則關閉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuStrip_LostFocus(Object sender, EventArgs e)
        {
            if (!ContainsFocus)
                Close();
        }

        /// <summary>
        /// 控制項移除事件處理
        /// </summary>
        /// <param name="e"></param>
        protected override void OnControlRemoved(ControlEventArgs e)
        {
            _loadedNodes = new TreeNodeItemSelector[] { };
            _startingNodes = new TreeNodeItemSelector[] { };
            _removedNodes = new TreeNodeItemSelector[] { };
            _removedsessionNodes = new TreeNodeItemSelector[] { };
            if (_textFilterTextChangedTimer != null)
                _textFilterTextChangedTimer.Stop();

            base.OnControlRemoved(e);
        }

        /// <summary>
        /// 取得 checklist 所使用的狀態影像列表
        /// </summary>
        /// <returns></returns>
        private static ImageList GetCheckListStateImages()
        {
            ImageList images = new ImageList();
            Bitmap unCheckImg = new Bitmap(16, 16);
            Bitmap checkImg = new Bitmap(16, 16);
            Bitmap mixedImg = new Bitmap(16, 16);

            using (Bitmap img = new Bitmap(16, 16))
            {
                using (Graphics g = Graphics.FromImage(img))
                {
                    CheckBoxRenderer.DrawCheckBox(g, new Point(0, 1), CheckBoxState.UncheckedNormal);
                    unCheckImg = (Bitmap)img.Clone();
                    CheckBoxRenderer.DrawCheckBox(g, new Point(0, 1), CheckBoxState.CheckedNormal);
                    checkImg = (Bitmap)img.Clone();
                    CheckBoxRenderer.DrawCheckBox(g, new Point(0, 1), CheckBoxState.MixedNormal);
                    mixedImg = (Bitmap)img.Clone();
                }
            }

            images.Images.Add("uncheck", unCheckImg);
            images.Images.Add("check", checkImg);
            images.Images.Add("mixed", mixedImg);

            return images;
        }

        #endregion


        #region 公開 事件

        /// <summary>
        /// 當排序改變時觸發
        /// </summary>
        public event EventHandler SortChanged;

        /// <summary>
        /// 當篩選改變時觸發
        /// </summary>
        public event EventHandler FilterChanged;

        #endregion


        #region 公開 屬性

        /// <summary>
        /// 設定 checklist 最大節點數
        /// </summary>
        public int MaxChecklistNodes
        {
            get
            {
                return _maxChecklistNodes;
            }
            set
            {
                _maxChecklistNodes = value;
            }
        }

        /// <summary>
        /// 取得目前排序類型
        /// </summary>
        public SortType ActiveSortType
        {
            get
            {
                return _activeSortType;
            }
        }

        /// <summary>
        /// 取得目前篩選類型
        /// </summary>
        public FilterType ActiveFilterType
        {
            get
            {
                return _activeFilterType;
            }
        }

        /// <summary>
        /// 取得用於篩選的資料類型
        /// </summary>
        public Type DataType { get; private set; }

        /// <summary>
        /// 取得或設定排序功能是否啟用
        /// </summary>
        public bool IsSortEnabled { get; set; }

        /// <summary>
        /// 取得或設定篩選功能是否啟用
        /// </summary>
        public bool IsFilterEnabled { get; set; }

        /// <summary>
        /// 取得或設定 checklist 篩選是否啟用
        /// </summary>
        public bool IsFilterChecklistEnabled { get; set; }

        /// <summary>
        /// 取得或設定自訂篩選是否啟用
        /// </summary>
        public bool IsFilterCustomEnabled { get; set; }

        /// <summary>
        /// 取得或設定日期/時間篩選是否啟用
        /// </summary>
        public bool IsFilterDateAndTimeEnabled { get; set; }

        /// <summary>
        /// 取得或設定是否啟用 NOT IN 邏輯
        /// </summary>
        public bool IsFilterNOTINLogicEnabled { get; set; }

        /// <summary>
        /// 設定文字篩選在搜尋時是否移除節點
        /// </summary>
        public bool DoesTextFilterRemoveNodesOnSearch
        {
            get
            {
                return _checkTextFilterRemoveNodesOnSearch;
            }
            set
            {
                _checkTextFilterRemoveNodesOnSearch = value;
            }
        }

        /// <summary>
        /// 啟用文字篩選 TextChanged 延遲所需的節點數量門檻
        /// </summary>
        public int TextFilterTextChangedDelayNodes
        {
            get
            {
                return _textFilterTextChangedDelayNodes;
            }
            set
            {
                _textFilterTextChangedDelayNodes = value;
            }
        }

        /// <summary>
        /// 文字篩選 TextChanged 延遲毫秒數
        /// </summary>
        public int TextFilterTextChangedDelayMs
        {
            get
            {
                return _textFilterTextChangedDelayMs;
            }
            set
            {
                _textFilterTextChangedDelayMs = value;
            }
        }

        /// <summary>
        /// 顯示時是否將文字篩選 textbox 設為焦點
        /// </summary>
        public bool FilterTextFocusOnShow { get; set; }

        #endregion


        #region 公開 啟關功能

        /// <summary>
        /// 啟用或停用排序功能
        /// </summary>
        /// <param name="enabled"></param>
        public void SetSortEnabled(bool enabled)
        {
            IsSortEnabled = enabled;

            sortASCMenuItem.Enabled = enabled;
            sortDESCMenuItem.Enabled = enabled;
            cancelSortMenuItem.Enabled = enabled;
        }

        /// <summary>
        /// 啟用或停用篩選功能
        /// </summary>
        /// <param name="enabled"></param>
        public void SetFilterEnabled(bool enabled)
        {
            IsFilterEnabled = enabled;

            cancelFilterMenuItem.Enabled = enabled;
            customFilterLastFiltersListMenuItem.Enabled = (enabled && DataType != typeof(bool));
            button_filter.Enabled = enabled;
            button_undofilter.Enabled = enabled;
            checkList.Enabled = enabled;
            checkTextFilter.Enabled = enabled;
        }

        /// <summary>
        /// 啟用或停用 checklist 篩選功能
        /// </summary>
        /// <param name="enabled"></param>
        public void SetFilterChecklistEnabled(bool enabled)
        {
            if (!IsFilterEnabled)
                enabled = false;

            IsFilterChecklistEnabled = enabled;
            checkList.Enabled = enabled;
            checkTextFilter.ReadOnly = !enabled;

            if (!IsFilterChecklistEnabled)
            {
                ChecklistClearNodes();
                TreeNodeItemSelector disablednode = TreeNodeItemSelector.CreateNode(AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVFilterChecklistDisable.ToString()] + "            ", null, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.SelectAll);
                disablednode.NodeFont = new Font(checkList.Font, FontStyle.Bold);
                ChecklistAddNode(disablednode);
                ChecklistReloadNodes();
            }
        }

        /// <summary>
        /// 啟用或停用自訂篩選功能
        /// </summary>
        /// <param name="enabled"></param>
        public void SetFilterCustomEnabled(bool enabled)
        {
            if (!IsFilterEnabled)
                enabled = false;

            IsFilterCustomEnabled = enabled;
            customFilterMenuItem.Enabled = enabled;
            customFilterLastFiltersListMenuItem.Enabled = enabled;

            if (!IsFilterCustomEnabled)
            {
                UnCheckCustomFilters();
            }
        }

        /// <summary>
        /// 停用文字篩選 TextChanged 延遲（將門檻設定為停用值）
        /// </summary>
        public void SetTextFilterTextChangedDelayNodesDisabled()
        {
            _textFilterTextChangedDelayNodes = TextFilterTextChangedDelayNodesDisabled;
        }

        #endregion


        #region 載入模式

        public void SetLoadedMode(bool enabled)
        {
            customFilterMenuItem.Enabled = !enabled;
            cancelFilterMenuItem.Enabled = enabled;
            if (enabled)
            {
                _activeFilterType = FilterType.Loaded;
                _sortString = null;
                _filterString = null;
                customFilterLastFiltersListMenuItem.Checked = false;
                for (int i = 2; i < customFilterLastFiltersListMenuItem.DropDownItems.Count - 1; i++)
                {
                    (customFilterLastFiltersListMenuItem.DropDownItems[i] as ToolStripMenuItem).Checked = false;
                }

                ChecklistClearNodes();
                TreeNodeItemSelector allnode = TreeNodeItemSelector.CreateNode(AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVNodeSelectAll.ToString()] + "            ", null, CheckState.Indeterminate, TreeNodeItemSelector.CustomNodeType.SelectAll);
                allnode.NodeFont = new Font(checkList.Font, FontStyle.Bold);
                ChecklistAddNode(allnode);
                ChecklistReloadNodes();

                SetSortEnabled(false);
                SetFilterEnabled(false);
            }
            else
            {
                _activeFilterType = FilterType.None;

                SetSortEnabled(true);
                SetFilterEnabled(true);
            }
        }

        #endregion


        #region 顯示 方法

        /// <summary>
        /// 顯示 MenuStrip
        /// </summary>
        /// <param name="control"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="columnName"></param>
        public void Show(Control control, int x, int y, string columnName)
        {
            _removedNodes = new TreeNodeItemSelector[] { };
            _removedsessionNodes = new TreeNodeItemSelector[] { };

            // 建立節點
            DataGridView dataGridView = control as DataGridView;
            IEnumerable<DataGridViewCell> vals = dataGridView != null ? GetValuesForFilter(dataGridView, columnName) : Enumerable.Empty<DataGridViewCell>();
            BuildNodes(vals, dataGridView, columnName);
            // 設定起始節點快照
            _startingNodes = DuplicateNodes(_loadedNodes);

            if (_activeFilterType == FilterType.Custom)
                SetNodesCheckState(_loadedNodes, false);
            base.Show(control, x, y);

            // 強制 checklist 重繪
            checkList.BeginUpdate();
            checkList.EndUpdate();

            _filterclick = false;

            _checkTextFilterChangedEnabled = false;
            checkTextFilter.Text = "";
            _checkTextFilterChangedEnabled = true;

            if (FilterTextFocusOnShow)
                checkTextFilter.Focus();
        }

        /// <summary>
        /// 顯示 MenuStrip（可還原篩選狀態）
        /// </summary>
        /// <param name="control"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="_restoreFilter"></param>
        public void Show(Control control, int x, int y, bool _restoreFilter)
        {
            _checkTextFilterChangedEnabled = false;
            checkTextFilter.Text = "";
            _checkTextFilterChangedEnabled = true;
            if (_restoreFilter || _checkTextFilterRemoveNodesOnSearch)
            {
                // 重設起始節點快照
                _startingNodes = DuplicateNodes(_loadedNodes);
            }
            // 重設已移除節點
            if (_checkTextFilterRemoveNodesOnSearch)
            {
                _removedNodes = _loadedNodes.Where(n => n.CheckState == CheckState.Unchecked && n.NodeType == TreeNodeItemSelector.CustomNodeType.Default).ToArray();
                _removedsessionNodes = _removedNodes;
            }

            ChecklistReloadNodes();

            base.Show(control, x, y);

            _filterclick = false;

            if (FilterTextFocusOnShow)
                checkTextFilter.Focus();
        }

        /// <summary>
        /// 取得用於 Show 的欄位儲存格集合
        /// </summary>
        /// <param name="grid"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public static IEnumerable<DataGridViewCell> GetValuesForFilter(DataGridView grid, string columnName)
        {
            var vals =
                from DataGridViewRow nulls in grid.Rows
                select nulls.Cells[columnName];

            return vals;
        }

        #endregion


        #region 排序 方法

        /// <summary>
        /// 排序 ASC
        /// </summary>
        public void SortASC()
        {
            SortASCMenuItem_Click(this, null);
        }

        /// <summary>
        /// 排序 DESC
        /// </summary>
        public void SortDESC()
        {
            SortDESCMenuItem_Click(this, null);
        }

        /// <summary>
        /// 取得排序字串
        /// </summary>
        public string SortString
        {
            get
            {
                return (!String.IsNullOrEmpty(_sortString) ? _sortString : "");
            }
            private set
            {
                cancelSortMenuItem.Enabled = (value != null && value.Length > 0);
                _sortString = value;
            }
        }

        /// <summary>
        /// 清除排序
        /// </summary>
        public void CleanSort()
        {
            sortASCMenuItem.Checked = false;
            sortDESCMenuItem.Checked = false;
            _activeSortType = SortType.None;
            SortString = null;
        }

        #endregion


        #region 篩選 方法

        /// <summary>
        /// 取得篩選字串
        /// </summary>
        public string FilterString
        {
            get
            {
                return (!String.IsNullOrEmpty(_filterString) ? _filterString : "");
            }
            private set
            {
                cancelFilterMenuItem.Enabled = (value != null && value.Length > 0);
                _filterString = value;
            }
        }

        /// <summary>
        /// 清除篩選
        /// </summary>
        public void CleanFilter()
        {
            if (_checkTextFilterRemoveNodesOnSearch)
            {
                _removedNodes = new TreeNodeItemSelector[] { };
                _removedsessionNodes = new TreeNodeItemSelector[] { };
            }

            for (int i = 2; i < customFilterLastFiltersListMenuItem.DropDownItems.Count - 1; i++)
            {
                (customFilterLastFiltersListMenuItem.DropDownItems[i] as ToolStripMenuItem).Checked = false;
            }
            _activeFilterType = FilterType.None;
            SetNodesCheckState(_loadedNodes, true);
            FilterString = null;
            customFilterLastFiltersListMenuItem.Checked = false;
            button_filter.Enabled = true;
        }

        /// <summary>
        /// 設定 checklist 文字篩選在搜尋時是否移除節點的模式
        /// </summary>
        /// <param name="enabled"></param>
        public void SetChecklistTextFilterRemoveNodesOnSearchMode(bool enabled)
        {
            if (_checkTextFilterRemoveNodesOnSearch != enabled)
            {
                _checkTextFilterRemoveNodesOnSearch = enabled;
                CleanFilter();
            }
        }

        #endregion


        #region checklist 篩選 方法

        /// <summary>
        /// 清除已載入的 checklist 節點
        /// </summary>
        private void ChecklistClearNodes()
        {
            _loadedNodes = new TreeNodeItemSelector[] { };
        }

        /// <summary>
        /// 新增節點到 checklist
        /// </summary>
        /// <param name="node"></param>
        private void ChecklistAddNode(TreeNodeItemSelector node)
        {
            _loadedNodes = _loadedNodes.Concat(new TreeNodeItemSelector[] { node }).ToArray();
        }

        /// <summary>
        /// 重新載入 checklist 節點至畫面
        /// </summary>
        private void ChecklistReloadNodes()
        {
            checkList.BeginUpdate();
            checkList.Nodes.Clear();
            int nodecount = 0;
            foreach (TreeNodeItemSelector node in _loadedNodes)
            {
                if (node.NodeType == TreeNodeItemSelector.CustomNodeType.Default)
                {
                    if (_maxChecklistNodes == 0)
                    {
                        if (!_removedNodes.Contains(node))
                            checkList.Nodes.Add(node);
                    }
                    else
                    {
                        if (nodecount < _maxChecklistNodes && !_removedNodes.Contains(node))
                            checkList.Nodes.Add(node);
                        else if (nodecount == _maxChecklistNodes)
                            checkList.Nodes.Add("...");
                        if (!_removedNodes.Contains(node) || nodecount == _maxChecklistNodes)
                            nodecount++;

                    }
                }
                else
                {
                    checkList.Nodes.Add(node);
                }

            }
            checkList.EndUpdate();
        }

        /// <summary>
        /// 取得 checklist 的節點集合
        /// </summary>
        /// <returns></returns>
        private TreeNodeCollection ChecklistNodes()
        {
            return checkList.Nodes;
        }

        /// <summary>
        /// 從 checklist 已選節點建立篩選字串
        /// </summary>
        private void SetCheckListFilter()
        {
            UnCheckCustomFilters();

            TreeNodeItemSelector selectAllNode = GetSelectAllNode();
            customFilterLastFiltersListMenuItem.Checked = false;

            if (selectAllNode != null && selectAllNode.Checked && String.IsNullOrEmpty(checkTextFilter.Text))
                CancelFilterMenuItem_Click(null, new EventArgs());
            else
            {
                string oldfilter = FilterString;
                FilterString = "";
                _activeFilterType = FilterType.CheckList;

                if (_loadedNodes.Length > 1)
                {
                    selectAllNode = GetSelectEmptyNode();
                    if (selectAllNode != null && selectAllNode.Checked)
                        FilterString = "[{0}] IS NULL";

                    if (_loadedNodes.Length > 2 || selectAllNode == null)
                    {
                        string filter = BuildNodesFilterString(
                            (IsFilterNOTINLogicEnabled && (DataType != typeof(DateTime) && DataType != typeof(TimeSpan) && DataType != typeof(bool)) ?
                                _loadedNodes.AsParallel().Cast<TreeNodeItemSelector>().Where(
                                    n => n.NodeType != TreeNodeItemSelector.CustomNodeType.SelectAll
                                        && n.NodeType != TreeNodeItemSelector.CustomNodeType.SelectEmpty
                                        && n.CheckState == CheckState.Unchecked
                                ) :
                                _loadedNodes.AsParallel().Cast<TreeNodeItemSelector>().Where(
                                    n => n.NodeType != TreeNodeItemSelector.CustomNodeType.SelectAll
                                        && n.NodeType != TreeNodeItemSelector.CustomNodeType.SelectEmpty
                                        && n.CheckState != CheckState.Unchecked
                                ))
                        );
                        filter = filter.Replace("{", "{{").Replace("}", "}}");

                        if (filter.Length > 0)
                        {
                            if (FilterString.Length > 0)
                                FilterString += " OR ";

                            if (DataType == typeof(bool))
                                FilterString += "[{0}] =" + filter;
                            else if (DataType == typeof(int) || DataType == typeof(long) || DataType == typeof(short) ||
                                     DataType == typeof(uint) || DataType == typeof(ulong) || DataType == typeof(ushort) ||
                                     DataType == typeof(decimal) ||
                                     DataType == typeof(byte) || DataType == typeof(sbyte))
                            {
                                if (IsFilterNOTINLogicEnabled)
                                    FilterString += "[{0}] NOT IN (" + filter + ")";
                                else
                                    FilterString += "[{0}] IN (" + filter + ")";
                            }
                            else if (DataType == typeof(string))
                            {
                                if (filter.Contains('»'))
                                {
                                    if (IsFilterNOTINLogicEnabled)
                                        FilterString += "[{0}] NOT IN (" + filter + ")";
                                    else
                                        FilterString += "[{0}] IN (" + filter + ")";
                                    //fs[i] = IsFilterNOTINLogicEnabled
                                    //    ? "[{0}] NOT IN '%" + fs[i] + "%'"
                                    //    : "[{0}] IN '%" + fs[i] + "%'";
                                }
                                else
                                {
                                    var fs = filter.SplitClean(',');
                                    for (int i = 0; i < fs.Count; i++)
                                        fs[i] = IsFilterNOTINLogicEnabled
                                            ? "[{0}] NOT LIKE '%" + fs[i] + "%'"
                                            : "[{0}] LIKE '%" + fs[i] + "%'";
                                    FilterString += string.Join(" OR ", fs);
                                }
                            }
                            else if (DataType == typeof(Bitmap))
                            { }
                            else
                            {
                                if (IsFilterNOTINLogicEnabled)
                                    FilterString += "Convert([{0}],System.String) NOT IN (" + filter + ")";
                                else
                                    FilterString += "Convert([{0}],System.String) IN (" + filter + ")";
                            }
                        }
                    }
                }

                if (oldfilter != FilterString && FilterChanged != null)
                    FilterChanged(this, new EventArgs());
            }
        }

        /// <summary>
        /// 根據所選節點集合建構用於篩選或 IN/NOT IN 子句的字串清單（以逗號與空格分隔）。
        /// </summary>
        /// <param name="nodes">
        /// 要用來建構篩選字串的節點集合。節點通常為 <see cref="TreeNodeItemSelector"/>，方法會檢查節點的
        /// <see cref="TreeNodeItemSelector.CheckState"/>, <see cref="TreeNodeItemSelector.Checked"/> 與 <see cref="TreeNodeItemSelector.Value"/> 屬性。
        /// 傳入 null 或空集合時會回傳空字串。
        /// </param>
        /// <returns>
        /// 回傳經格式化的篩選子項集合（以 ", " 分隔）。各類型格式化規則：
        /// DateTime：以目前文化 (CultureInfo.CurrentCulture) 將日期或日期時間轉為字串並以單引號包覆。
        /// TimeSpan：以自定的 'P...T...' 期間格式（字串）並以單引號包覆。
        /// bool：回傳第一個符合條件的布林值字串（不會加入分隔符號）。
        /// 整數型別：直接以數值字串輸出（不加引號）。
        /// 浮點/十進位：將區域小數分隔符 ',' 轉為 '.'，以符合查詢語法，並以逗號分隔。
        /// Bitmap：忽略，不回傳任何項目。
        /// 其餘（例如字串）：以單引號包覆並替換內部單引號為兩個單引號以防注入/語法錯誤。
        /// 對於有子節點的節點，若父節點未被取消選取且含子節點，會遞迴建構子節點的篩選字串並合併回傳。
        /// </returns>
        /// <remarks>
        /// - 方法保留既有遞迴邏輯：當節點具有子節點時會對子節點呼叫自己以建構篩選字串。
        /// - 回傳字串尾端在非 bool 類型時不會包含多餘的分隔符號。
        /// </remarks>
        private string BuildNodesFilterString(IEnumerable<TreeNodeItemSelector> nodes)
        {
            StringBuilder sb = new StringBuilder("");

            string appx = ", ";

            if (nodes != null && nodes.Any())
            {
                if (DataType == typeof(DateTime))
                {
                    foreach (TreeNodeItemSelector n in nodes)
                    {
                        if (n.Checked && (n.Nodes.AsParallel().Cast<TreeNodeItemSelector>().Where(sn => sn.CheckState != CheckState.Unchecked).Count() == 0))
                        {
                            DateTime dt = (DateTime)n.Value;
                            sb.Append("'" + Convert.ToString((IsFilterDateAndTimeEnabled ? dt : dt.Date), CultureInfo.CurrentCulture) + "'" + appx);
                        }
                        else if (n.CheckState != CheckState.Unchecked && n.Nodes.Count > 0)
                        {
                            string subnode = BuildNodesFilterString(n.Nodes.AsParallel().Cast<TreeNodeItemSelector>().Where(sn => sn.CheckState != CheckState.Unchecked));
                            if (subnode.Length > 0)
                                sb.Append(subnode + appx);
                        }
                    }
                }
                else if (DataType == typeof(TimeSpan))
                {
                    foreach (TreeNodeItemSelector n in nodes)
                    {
                        if (n.Checked && (n.Nodes.AsParallel().Cast<TreeNodeItemSelector>().Where(sn => sn.CheckState != CheckState.Unchecked).Count() == 0))
                        {
                            TimeSpan ts = (TimeSpan)n.Value;
                            sb.Append("'P" +
                                (ts.Days > 0 ? ts.Days + "D" : "") +
                                (ts.TotalHours > 0 ? "T" : "") + (ts.Hours > 0 ? ts.Hours + "H" : "") +
                                (ts.Minutes > 0 ? ts.Minutes + "M" : "") +
                                (ts.Seconds > 0 ? ts.Seconds + "S" : "") + "'" +
                                appx);
                        }
                        else if (n.CheckState != CheckState.Unchecked && n.Nodes.Count > 0)
                        {
                            string subnode = BuildNodesFilterString(n.Nodes.AsParallel().Cast<TreeNodeItemSelector>().Where(sn => sn.CheckState != CheckState.Unchecked));
                            if (subnode.Length > 0)
                                sb.Append(subnode + appx);
                        }
                    }
                }
                else if (DataType == typeof(bool))
                {
                    foreach (TreeNodeItemSelector n in nodes)
                    {
                        sb.Append(n.Value.ToString());
                        break;
                    }
                }
                else if (DataType == typeof(int) || DataType == typeof(long) || DataType == typeof(short) ||
                         DataType == typeof(uint) || DataType == typeof(ulong) || DataType == typeof(ushort) ||
                         DataType == typeof(byte) || DataType == typeof(sbyte))
                {
                    foreach (TreeNodeItemSelector n in nodes)
                        sb.Append(n.Value.ToString() + appx);
                }
                else if (DataType == typeof(float) || DataType == typeof(double) || DataType == typeof(decimal))
                {
                    foreach (TreeNodeItemSelector n in nodes)
                        sb.Append(n.Value.ToString().Replace(",", ".") + appx);
                }
                else if (DataType == typeof(string))
                {
                    foreach (TreeNodeItemSelector n in nodes)
                    {
                        if (n.NodeType == CustomNodeType.Default)
                        {
                            sb.Append(FormatFilterString(n.Value.ToString()) + appx);
                        }
                        else if (n.Checked && (n.Nodes.AsParallel().Cast<TreeNodeItemSelector>().Where(sn => sn.CheckState != CheckState.Unchecked).Count() == 0))
                        {
                            sb.Append("'" + FormatFilterString($"{n.Parent.Text} » {n.Value}") + "'" + appx);
                        }
                        else if (n.CheckState != CheckState.Unchecked && n.Nodes.Count > 0)
                        {
                            string subnode = BuildNodesFilterString(n.Nodes.AsParallel().Cast<TreeNodeItemSelector>().Where(sn => sn.CheckState != CheckState.Unchecked));
                            if (subnode.Length > 0)
                                sb.Append(subnode + appx);
                        }
                    }
                }
                else if (DataType == typeof(Bitmap))
                { }
                else
                {
                    foreach (TreeNodeItemSelector n in nodes)
                        sb.Append("'" + FormatFilterString(n.Value.ToString()) + "'" + appx);
                }
            }

            if (sb.Length > appx.Length && DataType != typeof(bool))
                sb.Remove(sb.Length - appx.Length, appx.Length);

            return sb.ToString();
        }

        /// <summary>
        /// 格式化文字篩選字串（替換單引號以避免語法錯誤）
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        private static string FormatFilterString(string text)
        {
            return text.Replace("'", "''");
        }

        /// <summary>
        /// 依據傳入的儲存格集合建立 checklist 節點
        /// </summary>
        /// <param name="vals"></param>
        /// <param name="dataGridView"></param>
        /// <param name="columnName"></param>
        private void BuildNodes(IEnumerable<DataGridViewCell> vals, DataGridView dataGridView, string columnName)
        {
            if (!IsFilterChecklistEnabled)
                return;

            ChecklistClearNodes();

            if (vals != null)
            {
                // 新增全選節點
                TreeNodeItemSelector allnode = TreeNodeItemSelector.CreateNode(AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVNodeSelectAll.ToString()] + "            ", null, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.SelectAll);
                allnode.NodeFont = new Font(checkList.Font, FontStyle.Bold);
                ChecklistAddNode(allnode);

                if (vals.Any())
                {
                    var nonulls = vals.Where<DataGridViewCell>(c => c.Value != null && c.Value != DBNull.Value);

                    // 新增空值節點
                    if (vals.Count() != nonulls.Count())
                    {
                        TreeNodeItemSelector nullnode = TreeNodeItemSelector.CreateNode(AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVNodeSelectEmpty.ToString()] + "               ", null, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.SelectEmpty);
                        nullnode.NodeFont = new Font(checkList.Font, FontStyle.Bold);
                        ChecklistAddNode(nullnode);
                    }

                    // 若為 DateTime，建立年/月/日 層級節點
                    if (DataType == typeof(DateTime))
                    {
                        var years =
                            from year in nonulls
                            group year by ((DateTime)year.Value).Year into cy
                            orderby cy.Key ascending
                            select cy;

                        foreach (var year in years)
                        {
                            TreeNodeItemSelector yearnode = TreeNodeItemSelector.CreateNode(year.Key.ToString(), year.Key, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.DateTimeNode);
                            ChecklistAddNode(yearnode);

                            var months =
                                from month in year
                                group month by ((DateTime)month.Value).Month into cm
                                orderby cm.Key ascending
                                select cm;

                            foreach (var month in months)
                            {
                                TreeNodeItemSelector monthnode = yearnode.CreateChildNode(CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(month.Key), month.Key);

                                var days =
                                    from day in month
                                    group day by ((DateTime)day.Value).Day into cd
                                    orderby cd.Key ascending
                                    select cd;

                                foreach (var day in days)
                                {
                                    TreeNodeItemSelector daysnode;

                                    if (!IsFilterDateAndTimeEnabled)
                                        daysnode = monthnode.CreateChildNode(day.Key.ToString("D2"), day.First().Value);
                                    else
                                    {
                                        daysnode = monthnode.CreateChildNode(day.Key.ToString("D2"), day.Key);

                                        var hours =
                                            from hour in day
                                            group hour by ((DateTime)hour.Value).Hour into ch
                                            orderby ch.Key ascending
                                            select ch;

                                        foreach (var hour in hours)
                                        {
                                            TreeNodeItemSelector hoursnode = daysnode.CreateChildNode(hour.Key.ToString("D2") + " " + "h", hour.Key);

                                            var mins =
                                                from min in hour
                                                group min by ((DateTime)min.Value).Minute into cmin
                                                orderby cmin.Key ascending
                                                select cmin;

                                            foreach (var min in mins)
                                            {
                                                TreeNodeItemSelector minsnode = hoursnode.CreateChildNode(min.Key.ToString("D2") + " " + "m", min.Key);

                                                var secs =
                                                    from sec in min
                                                    group sec by ((DateTime)sec.Value).Second into cs
                                                    orderby cs.Key ascending
                                                    select cs;

                                                foreach (var sec in secs)
                                                {
                                                    TreeNodeItemSelector secsnode = minsnode.CreateChildNode(sec.Key.ToString("D2") + " " + "s", sec.First().Value);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 若為 TimeSpan，建立 day/hour/min/sec 層級節點
                    else if (DataType == typeof(TimeSpan))
                    {
                        var days =
                            from day in nonulls
                            group day by ((TimeSpan)day.Value).Days into cd
                            orderby cd.Key ascending
                            select cd;

                        foreach (var day in days)
                        {
                            TreeNodeItemSelector daysnode = TreeNodeItemSelector.CreateNode(day.Key.ToString("D2"), day.Key, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.DateTimeNode);
                            ChecklistAddNode(daysnode);

                            var hours =
                                from hour in day
                                group hour by ((TimeSpan)hour.Value).Hours into ch
                                orderby ch.Key ascending
                                select ch;

                            foreach (var hour in hours)
                            {
                                TreeNodeItemSelector hoursnode = daysnode.CreateChildNode(hour.Key.ToString("D2") + " " + "h", hour.Key);

                                var mins =
                                    from min in hour
                                    group min by ((TimeSpan)min.Value).Minutes into cmin
                                    orderby cmin.Key ascending
                                    select cmin;

                                foreach (var min in mins)
                                {
                                    TreeNodeItemSelector minsnode = hoursnode.CreateChildNode(min.Key.ToString("D2") + " " + "m", min.Key);

                                    var secs =
                                        from sec in min
                                        group sec by ((TimeSpan)sec.Value).Seconds into cs
                                        orderby cs.Key ascending
                                        select cs;

                                    foreach (var sec in secs)
                                    {
                                        TreeNodeItemSelector secsnode = minsnode.CreateChildNode(sec.Key.ToString("D2") + " " + "s", sec.First().Value);
                                    }
                                }
                            }
                        }
                    }

                    // 若為布林值，建立 True/False 節點
                    else if (DataType == typeof(bool))
                    {
                        var values = nonulls.Where<DataGridViewCell>(c => (bool)c.Value == true);

                        if (values.Count() != nonulls.Count())
                        {
                            TreeNodeItemSelector node = TreeNodeItemSelector.CreateNode(AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVNodeSelectFalse.ToString()], false, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.Default);
                            ChecklistAddNode(node);
                        }

                        if (values.Any())
                        {
                            TreeNodeItemSelector node = TreeNodeItemSelector.CreateNode(AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVNodeSelectTrue.ToString()], true, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.Default);
                            ChecklistAddNode(node);
                        }
                    }

                    // 忽略影像類型
                    else if (DataType == typeof(Bitmap))
                    { }

                    // 其他（字串等），建立一般節點
                    else
                    {
                        // 若欄位有自訂字型則套用
                        Font nodeFont = null;
                        if (dataGridView != null && !String.IsNullOrEmpty(columnName))
                            nodeFont = dataGridView.Columns[columnName].DefaultCellStyle.Font;

                        if (nonulls.First().Value.ToString().Contains('»'))
                        {
                            foreach (var v in nonulls
                                .Select(c => c.Value.ToString().SplitClean('»'))
                                .GroupBy(x => x[0])
                                .OrderBy(g => g.Key))
                            {
                                TreeNodeItemSelector node = TreeNodeItemSelector.CreateNode(
                                    v.Key,
                                    v.Key,
                                    CheckState.Checked,
                                    TreeNodeItemSelector.CustomNodeType.Master_Slave);

                                if (nodeFont != null)
                                    node.NodeFont = nodeFont;

                                ChecklistAddNode(node);

                                foreach (var subv in v
                                    .GroupBy(x => x[1])
                                    .OrderBy(g => g.Key))
                                {
                                    TreeNodeItemSelector subnode = node.CreateChildNode(subv.Key, subv.Key);
                                }
                            }
                        }
                        else
                        {
                            foreach (var v in nonulls
                                .SelectMany(c => c.Value.ToString().SplitClean(';', ','), (cell, splitValue) => new { cell, splitValue })
                                .GroupBy(x => x.splitValue)
                                .OrderBy(g => g.Key))
                            {
                                TreeNodeItemSelector node = TreeNodeItemSelector.CreateNode(
                                    v.First().splitValue,
                                    v.Key,
                                    CheckState.Checked,
                                    TreeNodeItemSelector.CustomNodeType.Default);
                                if (nodeFont != null)
                                    node.NodeFont = nodeFont;
                                ChecklistAddNode(node);
                            }
                        }
                    }
                }
            }

            ChecklistReloadNodes();
        }

        /// <summary>
        /// 檢查是否需要啟用篩選按鈕
        /// </summary>
        private void CheckFilterButtonEnabled()
        {
            button_filter.Enabled = HasNodesChecked(_loadedNodes);
        }

        /// <summary>
        /// 檢查是否有選取的節點存在（含遞迴子節點）
        /// </summary>
        /// <param name="nodes"></param>
        /// <returns></returns>
        private bool HasNodesChecked(TreeNodeItemSelector[] nodes)
        {
            bool state = false;
            if (!String.IsNullOrEmpty(checkTextFilter.Text))
            {
                state = nodes.Any(n => n.CheckState == CheckState.Checked && n.Text.ToLower().Contains(checkTextFilter.Text.ToLower()));
            }
            else
            {
                state = nodes.Any(n => n.CheckState == CheckState.Checked);
            }

            if (state)
                return state;

            foreach (TreeNodeItemSelector node in nodes)
            {
                foreach (TreeNodeItemSelector nodesel in node.Nodes)
                {
                    state = HasNodesChecked(new TreeNodeItemSelector[] { nodesel });
                    if (state)
                        break;
                }
                if (state)
                    break;
            }

            return state;
        }

        /// <summary>
        /// 節點勾選狀態切換（用於點擊狀態影像或按空白鍵）
        /// </summary>
        /// <param name="node"></param>
        private void NodeCheckChange(TreeNodeItemSelector node)
        {
            if (node.CheckState == CheckState.Checked)
                node.CheckState = CheckState.Unchecked;
            else
                node.CheckState = CheckState.Checked;

            if (node.NodeType == TreeNodeItemSelector.CustomNodeType.SelectAll)
            {
                SetNodesCheckState(_loadedNodes, node.Checked);
            }
            else
            {
                if (node.Nodes.Count > 0)
                {
                    foreach (TreeNodeItemSelector subnode in node.Nodes)
                    {
                        SetNodesCheckState(new TreeNodeItemSelector[] { subnode }, node.Checked);
                    }
                }

                // 重新計算父節點的狀態
                CheckState state = UpdateNodesCheckState(ChecklistNodes());
                GetSelectAllNode().CheckState = state;
            }
        }

        /// <summary>
        /// 設定一組節點的勾選狀態
        /// </summary>
        /// <param name="nodes"></param>
        /// <param name="isChecked"></param>
        private void SetNodesCheckState(TreeNodeItemSelector[] nodes, bool isChecked)
        {
            foreach (TreeNodeItemSelector node in nodes)
            {
                node.Checked = isChecked;
                if (node.Nodes != null && node.Nodes.Count > 0)
                {
                    foreach (TreeNodeItemSelector subnode in node.Nodes)
                    {
                        SetNodesCheckState(new TreeNodeItemSelector[] { subnode }, isChecked);
                    }
                }

            }
        }

        /// <summary>
        /// 遞迴更新節點的 CheckState，回傳集合的整體狀態
        /// </summary>
        /// <param name="nodes"></param>
        /// <returns></returns>
        private CheckState UpdateNodesCheckState(TreeNodeCollection nodes)
        {
            CheckState result = CheckState.Unchecked;
            bool isFirstNode = true;
            bool isAllNodesSomeCheckState = true;

            foreach (TreeNodeItemSelector n in nodes.OfType<TreeNodeItemSelector>())
            {
                if (n.NodeType == TreeNodeItemSelector.CustomNodeType.SelectAll)
                    continue;

                if (n.Nodes.Count > 0)
                {
                    n.CheckState = UpdateNodesCheckState(n.Nodes);
                }

                if (isFirstNode)
                {
                    result = n.CheckState;
                    isFirstNode = false;
                }
                else
                {
                    if (result != n.CheckState)
                        isAllNodesSomeCheckState = false;
                }
            }

            if (isAllNodesSomeCheckState)
                return result;
            else
                return CheckState.Indeterminate;
        }

        /// <summary>
        /// 取得 SelectAll 節點
        /// </summary>
        /// <returns></returns>
        private TreeNodeItemSelector GetSelectAllNode()
        {
            TreeNodeItemSelector result = null;
            int i = 0;
            foreach (TreeNodeItemSelector n in ChecklistNodes().OfType<TreeNodeItemSelector>())
            {
                if (n.NodeType == TreeNodeItemSelector.CustomNodeType.SelectAll)
                {
                    result = n;
                    break;
                }
                else if (i > 2)
                    break;
                else
                    i++;
            }

            return result;
        }

        /// <summary>
        /// 取得 SelectEmpty 節點
        /// </summary>
        /// <returns></returns>
        private TreeNodeItemSelector GetSelectEmptyNode()
        {
            TreeNodeItemSelector result = null;
            int i = 0;
            foreach (TreeNodeItemSelector n in ChecklistNodes().OfType<TreeNodeItemSelector>())
            {
                if (n.NodeType == TreeNodeItemSelector.CustomNodeType.SelectEmpty)
                {
                    result = n;
                    break;
                }
                else if (i > 2)
                    break;
                else
                    i++;
            }

            return result;
        }

        /// <summary>
        /// 複製節點（Clone）陣列
        /// </summary>
        private static TreeNodeItemSelector[] DuplicateNodes(TreeNodeItemSelector[] nodes)
        {
            TreeNodeItemSelector[] ret = new TreeNodeItemSelector[nodes.Length];
            int i = 0;
            foreach (TreeNodeItemSelector n in nodes)
            {
                ret[i] = n.Clone();
                i++;
            }
            return ret;
        }

        #endregion


        #region checklist 事件

        /// <summary>
        /// checkList 狀態影像點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckList_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            TreeViewHitTestInfo HitTestInfo = checkList.HitTest(e.X, e.Y);
            if (HitTestInfo != null && HitTestInfo.Location == TreeViewHitTestLocations.StateImage)
            {
                // 切換節點勾選狀態
                NodeCheckChange(e.Node as TreeNodeItemSelector);
                // 更新篩選按鈕啟用狀態
                CheckFilterButtonEnabled();
            }
        }

        /// <summary>
        /// checkList 按鍵事件（支援空白鍵切換）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                // 切換目前選取節點勾選狀態
                NodeCheckChange(checkList.SelectedNode as TreeNodeItemSelector);
                // 更新篩選按鈕啟用狀態
                CheckFilterButtonEnabled();
            }
        }

        /// <summary>
        /// checkList 雙擊節點事件（在此會立即套用該節點的篩選）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckList_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            TreeNodeItemSelector n = e.Node as TreeNodeItemSelector;
            if (n != null)
            {
                // 設定新的節點勾選狀態
                SetNodesCheckState(_loadedNodes, false);
                n.CheckState = CheckState.Unchecked;
                NodeCheckChange(n);
                // 更新按鈕啟用狀態
                CheckFilterButtonEnabled();
                // 直接套用 checklist 篩選
                Button_ok_Click(this, new EventArgs());
            }
        }

        /// <summary>
        /// mouse 進入 checkList 時將焦點移至 checkList
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckList_MouseEnter(object sender, EventArgs e)
        {
            checkList.Focus();
        }

        /// <summary>
        /// mouse 離開 checkList 時將焦點移回 MenuStrip
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckList_MouseLeave(object sender, EventArgs e)
        {
            Focus();
        }

        /// <summary>
        /// 套用 checklist 篩選（確定按鈕）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_ok_Click(object sender, EventArgs e)
        {
            _filterclick = true;

            SetCheckListFilter();
            Close();
        }

        /// <summary>
        /// 取消 checklist 變更（還原到起始節點）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_cancel_Click(object sender, EventArgs e)
        {
            _loadedNodes = DuplicateNodes(_startingNodes);
            Close();
        }

        #endregion


        #region 篩選 方法（自訂篩選相關）

        /// <summary>
        /// 取消所有自訂篩選的勾選
        /// </summary>
        private void UnCheckCustomFilters()
        {
            for (int i = 2; i < customFilterLastFiltersListMenuItem.DropDownItems.Count; i++)
            {
                (customFilterLastFiltersListMenuItem.DropDownItems[i] as ToolStripMenuItem).Checked = false;
            }
        }

        /// <summary>
        /// 設定自訂篩選（使用最近的預設項目）
        /// </summary>
        /// <param name="filtersMenuItemIndex"></param>
        private void SetCustomFilter(int filtersMenuItemIndex)
        {
            if (_activeFilterType == FilterType.CheckList)
                SetNodesCheckState(_loadedNodes, false);

            string filterstring = customFilterLastFiltersListMenuItem.DropDownItems[filtersMenuItemIndex].Tag.ToString();
            string viewfilterstring = customFilterLastFiltersListMenuItem.DropDownItems[filtersMenuItemIndex].Text;

            // 處理預設清單順序
            if (filtersMenuItemIndex != 2)
            {
                for (int i = filtersMenuItemIndex; i > 2; i--)
                {
                    customFilterLastFiltersListMenuItem.DropDownItems[i].Text = customFilterLastFiltersListMenuItem.DropDownItems[i - 1].Text;
                    customFilterLastFiltersListMenuItem.DropDownItems[i].Tag = customFilterLastFiltersListMenuItem.DropDownItems[i - 1].Tag;
                }

                customFilterLastFiltersListMenuItem.DropDownItems[2].Text = viewfilterstring;
                customFilterLastFiltersListMenuItem.DropDownItems[2].Tag = filterstring;
            }

            // 取消其他預設項目的勾選
            for (int i = 3; i < customFilterLastFiltersListMenuItem.DropDownItems.Count; i++)
            {
                (customFilterLastFiltersListMenuItem.DropDownItems[i] as ToolStripMenuItem).Checked = false;
            }

            (customFilterLastFiltersListMenuItem.DropDownItems[2] as ToolStripMenuItem).Checked = true;
            _activeFilterType = FilterType.Custom;

            // 設定篩選字串
            string oldfilter = FilterString;
            FilterString = filterstring;

            // 將 checklist 節點清空選取
            SetNodesCheckState(_loadedNodes, false);

            customFilterLastFiltersListMenuItem.Checked = true;
            button_filter.Enabled = false;

            // 觸發篩選變更事件
            if (oldfilter != FilterString && FilterChanged != null)
                FilterChanged(this, new EventArgs());
        }

        #endregion


        #region 篩選 事件

        /// <summary>
        /// 取消篩選選單項目點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelFilterMenuItem_Click(object sender, EventArgs e)
        {
            string oldfilter = FilterString;

            // 清除篩選
            CleanFilter();

            // 觸發篩選變更事件
            if (oldfilter != FilterString && FilterChanged != null)
                FilterChanged(this, new EventArgs());
        }

        /// <summary>
        /// 取消篩選選單項目的滑鼠進入事件（如果可用則選取）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelFilterMenuItem_MouseEnter(object sender, EventArgs e)
        {
            if ((sender as ToolStripMenuItem).Enabled)
                (sender as ToolStripMenuItem).Select();
        }

        /// <summary>
        /// 自訂篩選選單項目點擊事件（開啟自訂篩選視窗）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomFilterMenuItem_Click(object sender, EventArgs e)
        {
            // 忽略影像類型
            if (DataType == typeof(Bitmap))
                return;

            // 開啟自訂篩選視窗
            FormCustomFilter flt = new FormCustomFilter(DataType, IsFilterDateAndTimeEnabled);

            if (flt.ShowDialog() == DialogResult.OK)
            {
                // 新增或更新自訂篩選預設

                string filterString = flt.FilterString;
                string viewFilterString = flt.FilterStringDescription;

                int index = -1;

                for (int i = 2; i < customFilterLastFiltersListMenuItem.DropDownItems.Count; i++)
                {
                    if (customFilterLastFiltersListMenuItem.DropDown.Items[i].Available)
                    {
                        if (customFilterLastFiltersListMenuItem.DropDownItems[i].Text == viewFilterString && customFilterLastFiltersListMenuItem.DropDownItems[i].Tag.ToString() == filterString)
                        {
                            index = i;
                            break;
                        }
                    }
                    else
                        break;
                }

                if (index < 2)
                {
                    for (int i = customFilterLastFiltersListMenuItem.DropDownItems.Count - 2; i > 1; i--)
                    {
                        if (customFilterLastFiltersListMenuItem.DropDownItems[i].Available)
                        {
                            customFilterLastFiltersListMenuItem.DropDownItems[i + 1].Text = customFilterLastFiltersListMenuItem.DropDownItems[i].Text;
                            customFilterLastFiltersListMenuItem.DropDownItems[i + 1].Tag = customFilterLastFiltersListMenuItem.DropDownItems[i].Tag;
                        }
                    }
                    index = 2;

                    customFilterLastFiltersListMenuItem.DropDownItems[2].Text = viewFilterString;
                    customFilterLastFiltersListMenuItem.DropDownItems[2].Tag = filterString;
                }

                // 設定自訂篩選
                SetCustomFilter(index);
            }
        }

        /// <summary>
        /// 自訂篩選預設選單滑鼠進入事件（如果可用則選取）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomFilterLastFiltersListMenuItem_MouseEnter(object sender, EventArgs e)
        {
            if ((sender as ToolStripMenuItem).Enabled)
                (sender as ToolStripMenuItem).Select();
        }

        /// <summary>
        /// 自訂篩選預設項目的繪製（繪製箭頭圖示）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomFilterLastFiltersListMenuItem_Paint(Object sender, PaintEventArgs e)
        {
            Rectangle rect = new Rectangle(customFilterLastFiltersListMenuItem.Width - 12, 7, 10, 10);
            ControlPaint.DrawMenuGlyph(e.Graphics, rect, MenuGlyph.Arrow, Color.Black, Color.Transparent);
        }

        /// <summary>
        /// 自訂篩選預設項目可見性改變（首次變更時更新分隔線）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomFilterLastFilter1MenuItem_VisibleChanged(object sender, EventArgs e)
        {
            toolStripSeparator2MenuItem.Visible = !customFilterLastFilter1MenuItem.Visible;
            (sender as ToolStripMenuItem).VisibleChanged -= CustomFilterLastFilter1MenuItem_VisibleChanged;
        }

        /// <summary>
        /// 自訂篩選預設項目點擊事件，套用相應的預設篩選
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomFilterLastFilterMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem menuitem = sender as ToolStripMenuItem;

            for (int i = 2; i < customFilterLastFiltersListMenuItem.DropDownItems.Count; i++)
            {
                if (customFilterLastFiltersListMenuItem.DropDownItems[i].Text == menuitem.Text && customFilterLastFiltersListMenuItem.DropDownItems[i].Tag.ToString() == menuitem.Tag.ToString())
                {
                    // 設定目前的預設為啟用
                    SetCustomFilter(i);
                    break;
                }
            }
        }

        /// <summary>
        /// 自訂篩選預設項目文字變更事件，標記該項目為可用
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomFilterLastFilterMenuItem_TextChanged(object sender, EventArgs e)
        {
            (sender as ToolStripMenuItem).Available = true;
            (sender as ToolStripMenuItem).TextChanged -= CustomFilterLastFilterMenuItem_TextChanged;
        }

        /// <summary>
        /// 文字變更計時器 Tick 事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckTextFilterTextChangedTimer_Tick(object sender, EventArgs e)
        {
            Timer timer = sender as Timer;
            if (timer == null)
                return;

            CheckTextFilterHandleTextChanged(timer.Tag.ToString());

            timer.Stop();
        }

        /// <summary>
        /// checkTextFilter 的 TextChanged 事件處理（包含延遲機制）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckTextFilter_TextChanged(object sender, EventArgs e)
        {
            if (!_checkTextFilterChangedEnabled)
                return;

            if (_textFilterTextChangedDelayNodes != TextFilterTextChangedDelayNodesDisabled && _loadedNodes.Length > _textFilterTextChangedDelayNodes)
            {
                if (_textFilterTextChangedTimer == null)
                {
                    _textFilterTextChangedTimer = new Timer();
                    _textFilterTextChangedTimer.Tick += new EventHandler(this.CheckTextFilterTextChangedTimer_Tick);
                }
                _textFilterTextChangedTimer.Stop();
                _textFilterTextChangedTimer.Interval = _textFilterTextChangedDelayMs;
                _textFilterTextChangedTimer.Tag = checkTextFilter.Text.ToLower();
                _textFilterTextChangedTimer.Start();
            }
            else
            {
                CheckTextFilterHandleTextChanged(checkTextFilter.Text.ToLower());
            }
        }

        /// <summary>
        /// 處理 checkTextFilter 的文字變更邏輯（包含在搜尋模式下移除節點的行為）
        /// </summary>
        /// <param name="text"></param>
        private void CheckTextFilterHandleTextChanged(string text)
        {
            TreeNodeItemSelector allnode = TreeNodeItemSelector.CreateNode(AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVNodeSelectAll.ToString()] + "            ", null, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.SelectAll);
            TreeNodeItemSelector nullnode = TreeNodeItemSelector.CreateNode(AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVNodeSelectEmpty.ToString()] + "               ", null, CheckState.Checked, TreeNodeItemSelector.CustomNodeType.SelectEmpty);
            string[] removednodesText = new string[] { };
            if (_checkTextFilterRemoveNodesOnSearch)
            {
                removednodesText = _removedsessionNodes.Where(r => !String.IsNullOrEmpty(r.Text)).Select(r => r.Text.ToLower()).Distinct().ToArray();
            }
            for (int i = _loadedNodes.Length - 1; i >= 0; i--)
            {
                TreeNodeItemSelector node = _loadedNodes[i];
                if (node.Text == allnode.Text)
                {
                    node.CheckState = CheckState.Indeterminate;
                }
                else if (node.Text == nullnode.Text)
                {
                    node.CheckState = CheckState.Unchecked;
                }
                else
                {
                    if (node.Text.ToLower().Contains(text))
                        node.CheckState = CheckState.Unchecked;
                    else
                        node.CheckState = CheckState.Checked;
                    if (removednodesText.Contains(node.Text.ToLower()))
                        node.CheckState = CheckState.Checked;
                    NodeCheckChange(node);
                }
            }
            // 更新篩選按鈕啟用狀態
            CheckFilterButtonEnabled();
            _removedNodes = _removedsessionNodes;
            if (_checkTextFilterRemoveNodesOnSearch)
            {
                for (int i = _loadedNodes.Length - 1; i >= 0; i--)
                {
                    TreeNodeItemSelector node = _loadedNodes[i];
                    if (!(node.Text == allnode.Text || node.Text == nullnode.Text))
                    {
                        if (!node.Text.ToLower().Contains(text))
                        {
                            _removedNodes = _removedNodes.Concat(new TreeNodeItemSelector[] { node }).ToArray();
                        }
                    }
                }
                ChecklistReloadNodes();
            }
        }

        #endregion


        #region 排序 事件

        /// <summary>
        /// Sort ASC 點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SortASCMenuItem_Click(object sender, EventArgs e)
        {
            // 忽略影像類型
            if (DataType == typeof(Bitmap))
                return;

            sortASCMenuItem.Checked = true;
            sortDESCMenuItem.Checked = false;
            _activeSortType = SortType.ASC;

            // 取得排序字串
            string oldsort = SortString;
            SortString = "[{0}] ASC";

            // 觸發排序變更事件
            if (oldsort != SortString && SortChanged != null)
                SortChanged(this, new EventArgs());
        }

        /// <summary>
        /// Sort ASC 滑鼠進入事件（若可用則選取）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SortASCMenuItem_MouseEnter(object sender, EventArgs e)
        {
            if ((sender as ToolStripMenuItem).Enabled)
                (sender as ToolStripMenuItem).Select();
        }

        /// <summary>
        /// Sort DESC 點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SortDESCMenuItem_Click(object sender, EventArgs e)
        {
            // 忽略影像類型
            if (DataType == typeof(Bitmap))
                return;

            sortASCMenuItem.Checked = false;
            sortDESCMenuItem.Checked = true;
            _activeSortType = SortType.DESC;

            // 取得排序字串
            string oldsort = SortString;
            SortString = "[{0}] DESC";

            // 觸發排序變更事件
            if (oldsort != SortString && SortChanged != null)
                SortChanged(this, new EventArgs());
        }

        /// <summary>
        /// Sort DESC 滑鼠進入事件（若可用則選取）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SortDESCMenuItem_MouseEnter(object sender, EventArgs e)
        {
            if ((sender as ToolStripMenuItem).Enabled)
                (sender as ToolStripMenuItem).Select();
        }

        /// <summary>
        /// 取消排序點擊事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelSortMenuItem_Click(object sender, EventArgs e)
        {
            string oldsort = SortString;
            // 清除排序
            CleanSort();
            // 觸發排序變更事件
            if (oldsort != SortString && SortChanged != null)
                SortChanged(this, new EventArgs());
        }

        /// <summary>
        /// 取消排序滑鼠進入事件（若可用則選取）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelSortMenuItem_MouseEnter(object sender, EventArgs e)
        {
            if ((sender as ToolStripMenuItem).Enabled)
                (sender as ToolStripMenuItem).Select();
        }

        #endregion


        #region 資料類型 函數

        /// <summary>
        /// 更新資料類型設置
        /// </summary>
        /// <param name="dataType"></param>
        internal void SetDataType(Type dataType)
        {
            // 設定目前資料類型
            DataType = dataType;

            // 根據類型設定元件文字與圖示
            if (dataType == typeof(DateTime) || dataType == typeof(TimeSpan))
            {
                customFilterLastFiltersListMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVCustomFilter.ToString()];
                sortASCMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVSortDateTimeASC.ToString()];
                sortDESCMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVSortDateTimeDESC.ToString()];
                sortASCMenuItem.Image = Calin.TaskPulse.Core.Properties.Resources.MenuStrip_OrderASCnum;
                sortDESCMenuItem.Image = Calin.TaskPulse.Core.Properties.Resources.MenuStrip_OrderDESCnum;
            }
            else if (dataType == typeof(bool))
            {
                customFilterLastFiltersListMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVCustomFilter.ToString()];
                sortASCMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVSortBoolASC.ToString()];
                sortDESCMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVSortBoolDESC.ToString()];
                sortASCMenuItem.Image = Calin.TaskPulse.Core.Properties.Resources.MenuStrip_OrderASCbool;
                sortDESCMenuItem.Image = Calin.TaskPulse.Core.Properties.Resources.MenuStrip_OrderDESCbool;
            }
            else if (dataType == typeof(Int32) || dataType == typeof(Int64) || dataType == typeof(Int16) ||
                dataType == typeof(UInt32) || dataType == typeof(UInt64) || dataType == typeof(UInt16) ||
                dataType == typeof(Byte) || dataType == typeof(SByte) || dataType == typeof(Decimal) ||
                dataType == typeof(Single) || dataType == typeof(Double))
            {
                customFilterLastFiltersListMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVCustomFilter.ToString()];
                sortASCMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVSortNumASC.ToString()];
                sortDESCMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVSortNumDESC.ToString()];
                sortASCMenuItem.Image = Calin.TaskPulse.Core.Properties.Resources.MenuStrip_OrderASCnum;
                sortDESCMenuItem.Image = Calin.TaskPulse.Core.Properties.Resources.MenuStrip_OrderDESCnum;
            }
            else
            {
                customFilterLastFiltersListMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVCustomFilter.ToString()];
                sortASCMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVSortTextASC.ToString()];
                sortDESCMenuItem.Text = AdvancedDataGridView.Translations[AdvancedDataGridView.TranslationKey.ADGVSortTextDESC.ToString()];
                sortASCMenuItem.Image = Calin.TaskPulse.Core.Properties.Resources.MenuStrip_OrderASCtxt;
                sortDESCMenuItem.Image = Calin.TaskPulse.Core.Properties.Resources.MenuStrip_OrderDESCtxt;
            }

            // 若為 DateTime/TimeSpan/bool，停用文字篩選輸入框
            if (dataType == typeof(DateTime) || dataType == typeof(TimeSpan) || dataType == typeof(bool))
                checkTextFilter.Enabled = false;

            // 設定自訂篩選預設狀態
            customFilterLastFiltersListMenuItem.Enabled = dataType != typeof(bool);
            customFilterLastFiltersListMenuItem.Checked = ActiveFilterType == FilterType.Custom;
        }

        #endregion


        #region 縮放 方法

        /// <summary>
        /// 取得縮放因子（依 DPI 計算）
        /// </summary>
        /// <returns></returns>
        private float GetScalingFactor()
        {
            float ret = 1;
            using (Graphics Gscale = this.CreateGraphics())
            {
                try
                {
                    ret = Gscale.DpiX / 96.0F;
                }
                catch { }
                ;
            }
            return ret;
        }

        /// <summary>
        /// 依縮放因子計算尺寸
        /// </summary>
        /// <param name="dimesion"></param>
        /// <param name="factor"></param>
        /// <returns></returns>
        private static int Scale(int dimesion, float factor)
        {
            return (int)Math.Floor(dimesion * factor);
        }

        /// <summary>
        /// 調整 MenuStrip 大小並重新配置內部控制項
        /// </summary>
        /// <param name="w"></param>
        /// <param name="h"></param>
        private void ResizeBox(int w, int h)
        {
            sortASCMenuItem.Width = w - 1;
            sortDESCMenuItem.Width = w - 1;
            cancelSortMenuItem.Width = w - 1; ;
            cancelFilterMenuItem.Width = w - 1;
            customFilterMenuItem.Width = w - 1;
            customFilterLastFiltersListMenuItem.Width = w - 1;
            checkTextFilterControlHost.Width = w - 35;

            // 使用原始寬高進行縮放
            float scalingfactor = GetScalingFactor();
            int w2 = (int)Math.Round(w / scalingfactor, 0);
            int h2 = (int)Math.Round(h / scalingfactor, 0);
            checkFilterListControlHost.Size = new Size(Scale(w2 - 35, scalingfactor), Scale(h2 - 160 - 15, scalingfactor));
            checkFilterListPanel.Size = checkFilterListControlHost.Size;
            checkList.Bounds = new Rectangle(Scale(4, scalingfactor), Scale(4, scalingfactor), Scale(w2 - 35 - 8, scalingfactor), Scale(h2 - 160 - 15 - 8, scalingfactor));
            checkFilterListButtonsControlHost.Size = new Size(Scale(w2 - 35, scalingfactor), Scale(32, scalingfactor));
            button_filter.Location = new Point(Scale(w2 - 40 - 164, scalingfactor), 0);
            button_undofilter.Location = new Point(Scale(w2 - 40 - 79, scalingfactor), 0);
            resizeBoxControlHost.Margin = new Padding(Scale(w2 - 46, scalingfactor), 0, 0, 0);

            // 計算所有物件高度以確保右下角縮放握把可顯示
            int finalHeight =
                sortASCMenuItem.Height +
                sortDESCMenuItem.Height +
                cancelSortMenuItem.Height +
                cancelFilterMenuItem.Height +
                toolStripSeparator1MenuItem.Height +
                toolStripSeparator2MenuItem.Height +
                customFilterLastFiltersListMenuItem.Height +
                toolStripSeparator3MenuItem.Height +
                checkFilterListControlHost.Height +
                checkTextFilterControlHost.Height +
                checkFilterListButtonsControlHost.Height +
                resizeBoxControlHost.Height;

            // 若為非 1 的縮放需調整高度以容納內容
            //if (scalingfactor == 1)
            //    Size = new Size(w, h);
            //else
            Size = new Size(w, h + (finalHeight - h < 0 ? 0 : finalHeight - h));
        }

        /// <summary>
        /// 清除縮放時繪製的虛線框
        /// </summary>
        private void ResizeClean()
        {
            if (_resizeEndPoint.X != -1)
            {
                Point startPoint = PointToScreen(MenuStrip._resizeStartPoint);

                Rectangle rc = new Rectangle(startPoint.X, startPoint.Y, _resizeEndPoint.X, _resizeEndPoint.Y)
                {
                    X = Math.Min(startPoint.X, _resizeEndPoint.X),
                    Width = Math.Abs(startPoint.X - _resizeEndPoint.X),

                    Y = Math.Min(startPoint.Y, _resizeEndPoint.Y),
                    Height = Math.Abs(startPoint.Y - _resizeEndPoint.Y)
                };

                ControlPaint.DrawReversibleFrame(rc, Color.Black, FrameStyle.Dashed);

                _resizeEndPoint.X = -1;
            }
        }

        #endregion


        #region 縮放 事件

        /// <summary>
        /// 縮放滑鼠按下事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResizeBoxControlHost_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ResizeClean();
            }
        }

        /// <summary>
        /// 縮放滑鼠移動事件（繪製虛線預覽框）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResizeBoxControlHost_MouseMove(object sender, MouseEventArgs e)
        {
            if (Visible)
            {
                if (e.Button == MouseButtons.Left)
                {
                    int x = e.X;
                    int y = e.Y;

                    ResizeClean();

                    x += Width - resizeBoxControlHost.Width;
                    y += Height - resizeBoxControlHost.Height;

                    x = Math.Max(x, MinimumSize.Width - 1);
                    y = Math.Max(y, MinimumSize.Height - 1);

                    Point StartPoint = PointToScreen(MenuStrip._resizeStartPoint);
                    Point EndPoint = PointToScreen(new Point(x, y));

                    Rectangle rc = new Rectangle
                    {
                        X = Math.Min(StartPoint.X, EndPoint.X),
                        Width = Math.Abs(StartPoint.X - EndPoint.X),

                        Y = Math.Min(StartPoint.Y, EndPoint.Y),
                        Height = Math.Abs(StartPoint.Y - EndPoint.Y)
                    };

                    ControlPaint.DrawReversibleFrame(rc, Color.Black, FrameStyle.Dashed);

                    _resizeEndPoint.X = EndPoint.X;
                    _resizeEndPoint.Y = EndPoint.Y;
                }
            }
        }

        /// <summary>
        /// 縮放滑鼠放開事件（套用最終尺寸）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResizeBoxControlHost_MouseUp(object sender, MouseEventArgs e)
        {
            if (_resizeEndPoint.X != -1)
            {
                ResizeClean();

                if (Visible)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        int newWidth = e.X + Width - resizeBoxControlHost.Width;
                        int newHeight = e.Y + Height - resizeBoxControlHost.Height;

                        newWidth = Math.Max(newWidth, MinimumSize.Width);
                        newHeight = Math.Max(newHeight, MinimumSize.Height);

                        ResizeBox(newWidth, newHeight);
                    }
                }
            }
        }

        /// <summary>
        /// 繪製縮放握把的事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResizeBoxControlHost_Paint(Object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(Calin.TaskPulse.Core.Properties.Resources.MenuStrip_ResizeGrip, 0, 0);
        }

        #endregion

    }
}