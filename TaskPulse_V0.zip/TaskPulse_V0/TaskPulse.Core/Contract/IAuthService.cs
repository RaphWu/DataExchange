﻿using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Contract
{
    public interface IAuthService
    {
        /********************
         * AD認證服務
         ********************/
        /// <summary>
        /// LDAP伺服器AD認證服務。
        /// </summary>
        /// <param name="userName">使用者名稱。</param>
        /// <param name="password">密碼。</param>
        /// <returns>認證是否通過。</returns>
        Task<bool> ActiveDirectoryAsync(string userName, string password);
    }
}
