﻿using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 分類資料。
    /// </summary>
    public class ClassifyInfo
    {
        public int Id { get; set; }
        public string IdString { get; set; }
        public string Category1 { get; set; }
        public string Category2 { get; set; }
        public string Name { get; set; }

        public ClassifyInfo()
        {
            Clear();
        }

        public ClassifyInfo(ClassifyInfo ci)
        {
            if (ci == null)
            {
                Clear();
            }
            else
            {
                Id = ci.Id;
                IdString = ci.IdString;
                Category1 = ci.Category1;
                Category2 = ci.Category2;
                Name = ci.Name;
            }
        }

        public void Clear()
        {
            Id = -1;
            IdString = string.Empty;
            Category1 = string.Empty;
            Category2 = string.Empty;
            Name = string.Empty;
        }

        /********************
         * Employee
         ********************/
        public ClassifyInfo(Employee employee)
        {
            SetEmployee(employee);
        }

        public void SetEmployee(Employee employee)
        {
            if (employee == null)
            {
                Clear();
            }
            else
            {
                Id = employee.Id;
                IdString = employee.EmployeeId;
                Category1 = employee.DepartmentName;
                Category2 = employee.JobTitleName;
                Name = employee.EmployeeName;
            }
        }

        public string JobTitle_Id_Name()
        {
            if (Id < 0) return string.Empty;

            string displayText = string.IsNullOrWhiteSpace(Category2) ? "" : $"{Category2} » ";
            displayText += $"{IdString} {Name}";
            return displayText;
        }

        /********************
         * Machine
         ********************/
        public ClassifyInfo(Machine machine)
        {
            SetMachine(machine);
        }

        public void SetMachine(Machine machine)
        {
            if (machine == null)
            {
                Clear();
            }
            else
            {
                Id = machine.Id;
                IdString = string.Empty;
                Category1 = machine.CategoryName;
                Category2 = machine.TypeName;
                Name = machine.MachineCode;
            }
        }

        /********************
         * Workstation
         ********************/
        public ClassifyInfo(Workstation ws)
        {
            SetWorkstation(ws);
        }

        public void SetWorkstation(Workstation ws)
        {
            if (ws == null)
            {
                Clear();
            }
            else
            {
                Id = ws.Id;
                IdString = string.Empty;
                Category1 = ws.ModelName;
                Category2 = string.Empty;
                Name = ws.WorkstationName;
            }
        }

        /********************
         * Collection helpers
         ********************/

        public static void SyncEmployees(ICollection<ClassifyInfo> target, ICollection<Employee> source)
        {
            Sync(target, source, e => new ClassifyInfo(e), (ci, e) => ci.SetEmployee(e));
        }

        public static void SyncMachines(ICollection<ClassifyInfo> target, ICollection<Machine> source)
        {
            Sync(target, source, m => new ClassifyInfo(m), (ci, m) => ci.SetMachine(m));
        }

        public static void SyncWorkstations(ICollection<ClassifyInfo> target, ICollection<Workstation> source)
        {
            Sync(target, source, w => new ClassifyInfo(w), (ci, w) => ci.SetWorkstation(w));
        }

        private static void Sync<T>(
            ICollection<ClassifyInfo> target,
            ICollection<T> source,
            System.Func<T, ClassifyInfo> factory,
            System.Action<ClassifyInfo, T> updater)
        {
            if (target == null) return;

            if (source == null || source.Count == 0)
            {
                target.Clear();
                return;
            }

            var srcList = source as IList<T> ?? source.ToList();

            // Ensure we can index target by snapshotting.
            var tgtList = target as IList<ClassifyInfo>;
            if (tgtList == null)
            {
                // Fallback: rebuild when target isn't indexable (still keeps reference).
                target.Clear();
                foreach (var s in srcList)
                    target.Add(factory(s));
                return;
            }

            // Update existing items
            int common = System.Math.Min(tgtList.Count, srcList.Count);
            for (int i = 0; i < common; i++)
            {
                updater(tgtList[i], srcList[i]);
            }

            // Remove extra
            for (int i = tgtList.Count - 1; i >= srcList.Count; i--)
            {
                tgtList.RemoveAt(i);
            }

            // Add missing
            for (int i = common; i < srcList.Count; i++)
            {
                tgtList.Add(factory(srcList[i]));
            }
        }
    }
}
