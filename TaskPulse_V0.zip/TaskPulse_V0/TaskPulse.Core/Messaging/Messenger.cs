//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace Calin.TaskPulse.Core.Messaging
//{
//    /// <summary>
//    /// ���q�ŰT������ - �ϥήz�ޥ��קK�O���鬪�|�C
//    /// ���N CommunityToolkit.Mvvm.Messaging.WeakReferenceMessenger
//    /// </summary>
//    public sealed class Messenger
//    {
//        // �x�s�T���q�\�̡]�ϥήz�ޥΡ^
//        private readonly Dictionary<Type, List<WeakReference>> _recipients;

//        /// <summary>
//        /// �w�]��ҡ]�ϥ� Lazy<T> �T�O������w���^
//        /// </summary>
//        public static Messenger Default => _lazyInstance.Value;

//        private static readonly Lazy<Messenger> _lazyInstance =
//            new Lazy<Messenger>(() => new Messenger(), isThreadSafe: true);

//        private Messenger()
//        {
//            _recipients = new Dictionary<Type, List<WeakReference>>();
//        }

//        /// <summary>
//        /// ���U�T��������
//        /// </summary>
//        /// <typeparam name="TMessage">�T������</typeparam>
//        /// <param name="recipient">�����̪���</param>
//        /// <param name="handler">�B�z�T������k</param>
//        public void Register<TMessage>(object recipient, Action<TMessage> handler)
//            where TMessage : class
//        {
//            if (recipient == null) throw new ArgumentNullException(nameof(recipient));
//            if (handler == null) throw new ArgumentNullException(nameof(handler));

//            var messageType = typeof(TMessage);

//            lock (_recipients)
//            {
//                if (!_recipients.ContainsKey(messageType))
//                {
//                    _recipients[messageType] = new List<WeakReference>();
//                }

//                // �إߥ]�˪���]�]�t�����̩M�B�z��k�^
//                var wrapper = new MessageHandler<TMessage>(recipient, handler);
//                _recipients[messageType].Add(new WeakReference(wrapper));
//            }
//        }

//        /// <summary>
//        /// �o�e�T�����Ҧ����U��������
//        /// </summary>
//        /// <typeparam name="TMessage">�T������</typeparam>
//        /// <param name="message">�T������</param>
//        public void Send<TMessage>(TMessage message)
//            where TMessage : class
//        {
//            if (message == null) throw new ArgumentNullException(nameof(message));

//            var messageType = typeof(TMessage);
//            List<WeakReference> handlers = null;

//            lock (_recipients)
//            {
//                if (_recipients.ContainsKey(messageType))
//                {
//                    handlers = _recipients[messageType].ToList();
//                }
//            }

//            if (handlers == null || handlers.Count == 0)
//                return;

//            // �M�z�w���Ī��z�ޥΨð��榳�Ī��B�z��
//            var deadReferences = new List<WeakReference>();

//            foreach (var weakRef in handlers)
//            {
//                if (weakRef.IsAlive)
//                {
//                    var handler = weakRef.Target as MessageHandler<TMessage>;
//                    if (handler != null && handler.IsAlive)
//                    {
//                        try
//                        {
//                            handler.Handle(message);
//                        }
//                        catch (Exception ex)
//                        {
//                            // TODO �i��G�O�����~
//                            System.Diagnostics.Debug.WriteLine($"�T���B�z���~: {ex.Message}");
//                        }
//                    }
//                    else
//                    {
//                        deadReferences.Add(weakRef);
//                    }
//                }
//                else
//                {
//                    deadReferences.Add(weakRef);
//                }
//            }

//            // �M�z���Ī��ޥ�
//            if (deadReferences.Count > 0)
//            {
//                lock (_recipients)
//                {
//                    if (_recipients.ContainsKey(messageType))
//                    {
//                        foreach (var deadRef in deadReferences)
//                        {
//                            _recipients[messageType].Remove(deadRef);
//                        }
//                    }
//                }
//            }
//        }

//        /// <summary>
//        /// �������U�S�w�����̪��Ҧ��T��
//        /// </summary>
//        /// <param name="recipient">�����̪���</param>
//        public void UnregisterAll(object recipient)
//        {
//            if (recipient == null) return;

//            lock (_recipients)
//            {
//                foreach (var kvp in _recipients.ToList())
//                {
//                    var toRemove = kvp.Value
//                        .Where(wr =>
//                        {
//                            if (!wr.IsAlive) return true;
//                            var handler = wr.Target as IMessageHandler;
//                            return handler != null && handler.RecipientEquals(recipient);
//                        })
//                        .ToList();

//                    foreach (var wr in toRemove)
//                    {
//                        kvp.Value.Remove(wr);
//                    }

//                    // �p�G�������S���q�\�̤F�A����������
//                    if (kvp.Value.Count == 0)
//                    {
//                        _recipients.Remove(kvp.Key);
//                    }
//                }
//            }
//        }

//        /// <summary>
//        /// �������U�S�w�������T��
//        /// </summary>
//        /// <typeparam name="TMessage">�T������</typeparam>
//        /// <param name="recipient">�����̪���</param>
//        public void Unregister<TMessage>(object recipient)
//            where TMessage : class
//        {
//            if (recipient == null) return;

//            var messageType = typeof(TMessage);

//            lock (_recipients)
//            {
//                if (_recipients.ContainsKey(messageType))
//                {
//                    var toRemove = _recipients[messageType]
//                        .Where(wr =>
//                        {
//                            if (!wr.IsAlive) return true;
//                            var handler = wr.Target as IMessageHandler;
//                            return handler != null && handler.RecipientEquals(recipient);
//                        })
//                        .ToList();

//                    foreach (var wr in toRemove)
//                    {
//                        _recipients[messageType].Remove(wr);
//                    }

//                    if (_recipients[messageType].Count == 0)
//                    {
//                        _recipients.Remove(messageType);
//                    }
//                }
//            }
//        }

//        /// <summary>
//        /// �M���Ҧ��T���q�\
//        /// </summary>
//        public void Reset()
//        {
//            lock (_recipients)
//            {
//                _recipients.Clear();
//            }
//        }

//        #region �������O

//        /// <summary>
//        /// �T���B�z������
//        /// </summary>
//        private interface IMessageHandler
//        {
//            bool IsAlive { get; }
//            bool RecipientEquals(object other);
//        }

//        /// <summary>
//        /// �T���B�z���]�����O
//        /// </summary>
//        private class MessageHandler<TMessage> : IMessageHandler
//            where TMessage : class
//        {
//            private readonly WeakReference _recipient;
//            private readonly Action<TMessage> _handler;

//            public MessageHandler(object recipient, Action<TMessage> handler)
//            {
//                _recipient = new WeakReference(recipient);
//                _handler = handler;
//            }

//            public bool IsAlive => _recipient.IsAlive;

//            public bool RecipientEquals(object other)
//            {
//                return _recipient.IsAlive && _recipient.Target == other;
//            }

//            public void Handle(TMessage message)
//            {
//                if (_recipient.IsAlive)
//                {
//                    _handler?.Invoke(message);
//                }
//            }
//        }

//        #endregion
//    }
//}