﻿using Autofac;
using Calin.Infrastructure.Coordination;
using Calin.Infrastructure.Coordination.Policies;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.Services.Coordination;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.Views;

namespace Calin.TaskPulse.Core
{
    public class CoreModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            SplashMessenger.Post("核心協調者模組...");

            // 註冊 Handlers
            builder.RegisterTaskHandler<EmployeeCacheUpdateHandler>();
            builder.RegisterTaskHandler<MachineCacheUpdateHandler>();
            builder.RegisterTaskHandler<ModelCacheUpdateHandler>();
            builder.RegisterTaskHandler<WorkstationCacheUpdateHandler>();

            // 註冊 Mapping Strategy
            builder.RegisterTaskMappingStrategy<CacheUpdateMappingStrategy>();

            // 註冊結果發布者
            builder.RegisterResultPublisher<CacheUpdatePublisher>();

            // 註冊平行執行策略
            builder.RegisterType<ParallelExecutionPolicy>()
               .As<IExecutionPolicy>()
               .WithParameter("maxDegreeOfParallelism", 5)
               .SingleInstance();

            builder.RegisterModule<CoordinationModule>();

            SplashMessenger.Post("載入核心模組...");

            // dialog
            builder.RegisterType<LoginControl>().ExternallyOwned();
            builder.RegisterType<CRUD>().ExternallyOwned();
            builder.RegisterType<MultiSelector>().ExternallyOwned();
            builder.RegisterType<MachineEdit>().ExternallyOwned();
            builder.RegisterType<LoadingDialog>().ExternallyOwned();

            // views
            builder.RegisterType<SetupPage>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_Models>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_MachinesSummary>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_MachineBrend>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_MachineCategory>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_Employees>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_Department>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_UserGroup>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_Permission>().InstancePerLifetimeScope();
            builder.RegisterType<Setup_MaintiFlowClassify>().InstancePerLifetimeScope();

            builder.RegisterType<Setup_Permission_Small>().InstancePerLifetimeScope();

            // service
            builder.RegisterType<CoreService>().As<ICore>().SingleInstance();
            builder.RegisterType<MemoryCacheService>().SingleInstance();
            builder.RegisterType<AuthService>().As<IAuthService>().SingleInstance();
            //builder.RegisterType<LogService>().As<ILogService>().SingleInstance();
            //builder.RegisterType<EmployeeService>().As<IEmployeeService>().SingleInstance();
            builder.RegisterType<CurrentUserService>().As<ICurrentUserService>().SingleInstance();
            builder.RegisterType<PermissionService>().As<IPermissionService>().SingleInstance();
            builder.RegisterType<UserGroupService>().As<IUserGroupService>().SingleInstance();

            builder.RegisterType<MailService>().As<IMail>().SingleInstance();

            // public data
            builder.RegisterType<CoreData>().SingleInstance();
            builder.RegisterType<CurrentUserContext>().SingleInstance();

            // DbContext
            builder.RegisterType<CoreContext>().InstancePerDependency();
            builder.RegisterType<CoreInitializer>().As<IStartable>().SingleInstance();

            builder.RegisterBuildCallback(async c =>
            {
                var core = c.Resolve<ICore>();
                core.Initialize();
            });
        }
    }
}
