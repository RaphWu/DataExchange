﻿using System;
using System.Data.Entity;
using System.DirectoryServices.Protocols;
using System.Net;
using System.Security;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using Serilog;
using Serilog.Context;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// 登入驗證。
    /// </summary>
    public class AuthService : IAuthService
    {
        private readonly Serilog.ILogger _logger;
        private readonly ICurrentUserService _currentUser;
        private readonly CoreContext _context;

        public AuthService(
            ILogger logger,
            CoreContext coreContext,
            ICurrentUserService currentUserService)
        {
            _logger = logger;
            _currentUser = currentUserService;
            _context = coreContext;
        }

        /********************
         * AD認證服務
         ********************/
        /// <inheritdoc/>
        public async Task<bool> ActiveDirectoryAsync(string employeeId, string password)
        {
#if TEST
            return true;
#endif
            var user = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == employeeId);
            try
            {
                SecureString securePwd = new SecureString();
                foreach (var c in password)
                    securePwd.AppendChar(c);

                var identifier = new LdapDirectoryIdentifier("172.16.254.200");
                using (var connection = new LdapConnection(identifier))
                {
                    connection.SessionOptions.ProtocolVersion = 3;
                    connection.AuthType = AuthType.Negotiate;
                    var credential = new NetworkCredential(employeeId, securePwd);
                    connection.Bind(credential);
                    return user != null;
                }
            }
            catch (LdapException ex)
            {
                using (LogContext.PushProperty("Category", "UserActivity"))
                {
                    _logger.Error(ex, "LDAP伺服器異常或帳號密碼未通過認證: {0}", user.FullName);
                }
                //_currentUser.SwitchCurrentUserToGuest();
            }
            catch (Exception ex)
            {
                using (LogContext.PushProperty("Category", "UserActivity"))
                {
                    _logger.Error(ex, "LDAP驗證失敗 User: {0}", employeeId);
                }
                _currentUser.SwitchCurrentUserToGuest();
            }
            return false;
        }
    }
}


//public User Login(string username, string password)
//{
//    var emp = _context.Employees.FirstOrDefault(e => e.UserName == username);
//    if (emp != null && PasswordHelper.VerifyPassword(password, emp.PasswordHash))
//        return emp;
//    return null;
//}

//public async Task LoginAsync(User user)
//{
//    await _log.LoginAsync(user.Id, "Login", new { user.UserName });
//}

//public async Task LogoutAsync(User user)
//{
//    await _log.LoginAsync(user.Id, "Logout", new { user.UserName });
//}
