﻿using System.Threading.Tasks;
using Calin.Infrastructure.Coordination;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class WorkstationUpdateHandler : TaskHandlerBase<CacheUpdateRequest>
    {
        public override TaskKey TaskKey => CoreTaskKeys.WorkstationUpdate;

        protected override async Task ExecuteAsync(ITaskExecutionContext context, CacheUpdateRequest request)
        {
            // 模擬載入組態
            await Task.Delay(100);
            // 實際邏輯：從檔案或服務載入組態
        }
    }
}
