﻿using System.Threading.Tasks;
using Calin.Infrastructure.Coordination;
using Calin.TaskPulse.Core.Coordination;
using Calin.TaskPulse.Core.Events;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class EmployeeCacheUpdatePublisher : ISelectiveResultPublisher
    {
        public string TargetName => nameof(EmployeeCacheUpdatePublisher);

        public async Task PublishAsync(TaskKey taskKey, ICoordinationResult result)
        {
            _ = WeakReferenceMessenger.Default.Send(NotifyEmployeeDataUpdated.Instance);
            await Task.CompletedTask;
        }
    }
}
