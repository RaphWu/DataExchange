﻿using System.Threading.Tasks;
using Calin.Infrastructure.Coordination;
using Calin.TaskPulse.Core.Contracts;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class EmployeeCacheUpdateHandler : TaskHandlerBase<CacheUpdateRequest>
    {
        private readonly ICore _core;

        public override TaskKey TaskKey => CoreTaskKeys.EmployeeUpdate;

        public EmployeeCacheUpdateHandler(ICore core)
        {
            _core = core;
        }

        protected override async Task ExecuteAsync(ITaskExecutionContext context, CacheUpdateRequest request)
        {
            await _core.UpdateEmployeesCache();
        }
    }
}
