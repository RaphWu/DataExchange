﻿using Calin.Infrastructure.Coordination;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class CacheUpdateRequest : CoordinationRequest
    {
        /// <summary>
        /// 取得是否強制重新載入。
        /// </summary>
        public bool ForceReload { get; }

        public CacheUpdateRequest(bool forceReload = false)
            : base("CacheUpdate")
        {
            ForceReload = forceReload;
        }
    }
}
