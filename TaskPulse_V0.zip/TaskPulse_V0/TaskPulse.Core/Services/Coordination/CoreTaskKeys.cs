﻿using Calin.Infrastructure.Coordination;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public static class CoreTaskKeys
    {
        public static readonly TaskKey EmployeeUpdate = new TaskKey("TaskPulse.Core.EmployeeUpdate");
        public static readonly TaskKey ModelUpdate = new TaskKey("TaskPulse.Core.ModelUpdate");
        public static readonly TaskKey MachineUpdate = new TaskKey("TaskPulse.Core.MachineUpdate");
        public static readonly TaskKey WorkstationUpdate = new TaskKey("TaskPulse.Core.WorkstationUpdate");
    }
}
