﻿using System.Threading.Tasks;
using Calin.Infrastructure.Coordination;
using Calin.TaskPulse.Core.Coordination;
using Calin.TaskPulse.Core.Events;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class WorkstationCacheUpdatePublisher : ISelectiveResultPublisher
    {
        public string TargetName => nameof(WorkstationCacheUpdatePublisher);

        public async Task PublishAsync(TaskKey taskKey, ICoordinationResult result)
        {
            _ = WeakReferenceMessenger.Default.Send(NotifyWorkstationDataUpdated.Instance);
            await Task.CompletedTask;
        }
    }
}
