﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Services
{
    public class CoreService : ICore
    {
        #region fields

        private readonly ICacheManager _cacheManager;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        private bool _isInitialized = false;

        #endregion fields

        public CoreService(
            ICacheManager entityCacheManager,
            CoreContext coreContext,
            CoreData coreData)
        {
            _cacheManager = entityCacheManager;
            _context = coreContext;
            _coreData = coreData;

            WeakReferenceMessenger.Default.Register<RequestEmployeeDataUpdate>(this, async (recipient, message) =>
            {
                await UpdateEmployeesCache();
            });
            WeakReferenceMessenger.Default.Register<RequestMachineDataUpdate>(this, async (recipient, message) =>
            {
                await UpdateMachinesCache();
            });
            WeakReferenceMessenger.Default.Register<RequestModelNoDataUpdate>(this, async (recipient, message) =>
            {
                await UpdateModelsCache();
            });
            WeakReferenceMessenger.Default.Register<RequestWorkstationDataUpdate>(this, async (recipient, message) =>
            {
                await UpdateWorkstationsCache();
            });
            WeakReferenceMessenger.Default.Register<RequestGlobalDataUpdate>(this, async (recipient, message) =>
            {
                await UpdateGlobalsCache();
            });
        }

        /// <inheritdoc/>
        public async Task Initialize()
        {
            if (_isInitialized)
                return;

            SplashMessenger.Post("核心模組: 初始化內部訊息");
            PropertyText.Name.EmployeeId = nameof(Employee.EmployeeId);
            PropertyText.Name.EmployeeName = nameof(Employee.EmployeeName);
            PropertyText.Name.DepartmentId = nameof(Employee.DepartmentId);
            PropertyText.Name.Department = nameof(Employee.Department);
            PropertyText.Name.JobTitleId = nameof(Employee.JobTitleId);
            PropertyText.Name.JobTitle = nameof(Employee.JobTitle);
            PropertyText.Name.JobTitleName = nameof(Employee.JobTitleName);
            PropertyText.Name.Email = nameof(Employee.Email);
            PropertyText.Name.CarbonCopies = nameof(Employee.CarbonCopies);
            PropertyText.Name.CarbonCopyString = nameof(Employee.CarbonCopyString);
            PropertyText.Name.CarbonCopyList = nameof(Employee.CarbonCopyList);
            PropertyText.Name.IsEngineer = nameof(Employee.IsEngineer);
            PropertyText.Name.IsEngineerString = nameof(Employee.IsEngineerString);
            PropertyText.Name.EmployeeStatus = nameof(Employee.Status);
            PropertyText.Name.EmployeeStatusId = nameof(Employee.StatusId);
            PropertyText.Name.EmployeeStatusName = nameof(Employee.StatusName);
            PropertyText.Name.EmployeeStatusBoolean = nameof(Employee.StatusBoolean);
            PropertyText.Name.StatusChangeAt = nameof(Employee.StatusChangeAt);
            PropertyText.Name.StatusChangeAtString = nameof(Employee.StatusChangeAtString);

            PropertyText.Name.MachineCode = nameof(Machine.MachineCode);
            PropertyText.Name.MachineCategory = nameof(MachineCategory.CategoryName);
            PropertyText.Name.MachineType = nameof(MachineType.TypeName);
            PropertyText.Name.MachineName = nameof(Machine.MachineName);
            PropertyText.Name.MachineModel = nameof(Machine.MachineName.ModelName);
            PropertyText.Name.Condition = nameof(Machine.Condition);
            PropertyText.Name.ConditionName = nameof(Machine.ConditionName);
            PropertyText.Name.Brand = nameof(Machine.Brand);
            PropertyText.Name.BrandName = nameof(Machine.BrandName);
            PropertyText.Name.Location = nameof(Machine.Location);
            PropertyText.Name.LocationName = nameof(Machine.LocationName);
            PropertyText.Name.Assets = nameof(Machine.Assets);
            PropertyText.Name.AssetString = nameof(Machine.AssetString);
            PropertyText.Name.AssetList = nameof(Machine.AssetList);
            PropertyText.Name.SerialNumber = nameof(Machine.SerialNumber);
            PropertyText.Name.Barcode = nameof(Machine.Barcode);
            PropertyText.Name.Connected = nameof(Machine.Connected);
            PropertyText.Name.ConnectedString = nameof(Machine.ConnectedString);
            PropertyText.Name.Disposal = nameof(Machine.Disposal);
            PropertyText.Name.DisposalString = nameof(Machine.DisposalString);
            PropertyText.Name.Remark = nameof(Machine.Remark);
            PropertyText.Name.Workstations = nameof(Machine.Workstations);
            PropertyText.Name.ModelStatus = nameof(ModelStatus.Status);
            PropertyText.Name.UserGroupNames = nameof(UserGroup.Name);

            PropertyText.Title.Performer = "執行人員";
            PropertyText.Title.List = "列表";
            PropertyText.Title.CheckList = "清單";

            PropertyText.Title.Setup = EnumHelper.GetDescription<PageCode>(nameof(PageCode.Setup));
            PropertyText.Title.ToolQuest = EnumHelper.GetDescription<PageCode>(nameof(PageCode.ToolQuest));
            PropertyText.Title.MechaTrack = EnumHelper.GetDescription<PageCode>(nameof(PageCode.MechaTrack));
            PropertyText.Title.MaintiFlow = EnumHelper.GetDescription<PageCode>(nameof(PageCode.MaintiFlow));

            PropertyText.Title.Employee = "員工";
            PropertyText.Title.EmployeeId = EnumHelper.GetDescription<Employee>(PropertyText.Name.EmployeeId);
            PropertyText.Title.EmployeeName = EnumHelper.GetDescription<Employee>(PropertyText.Name.EmployeeName);
            PropertyText.Title.Department = EnumHelper.GetDescription<Employee>(PropertyText.Name.Department);
            PropertyText.Title.JobTitle = EnumHelper.GetDescription<Employee>(PropertyText.Name.JobTitle);
            PropertyText.Title.Email = EnumHelper.GetDescription<Employee>(PropertyText.Name.Email);
            PropertyText.Title.CarbonCopies = EnumHelper.GetDescription<Employee>(PropertyText.Name.CarbonCopies);
            PropertyText.Title.IsEngineer = EnumHelper.GetDescription<Employee>(PropertyText.Name.IsEngineer);
            PropertyText.Title.EmployeeStatus = EnumHelper.GetDescription<Employee>(PropertyText.Name.EmployeeStatus);
            PropertyText.Title.StatusChangeAt = EnumHelper.GetDescription<Employee>(PropertyText.Name.StatusChangeAt);

            PropertyText.Title.MachineCategory = EnumHelper.GetDescription<MachineCategory>(PropertyText.Name.MachineCategory);
            PropertyText.Title.MachineType = EnumHelper.GetDescription<MachineType>(PropertyText.Name.MachineType);
            PropertyText.Title.MachineName = EnumHelper.GetDescription<Machine>(PropertyText.Name.MachineName);
            PropertyText.Title.MachineModel = EnumHelper.GetDescription<MachineName>(PropertyText.Name.MachineModel);
            PropertyText.Title.Condition = EnumHelper.GetDescription<Machine>(PropertyText.Name.Condition);
            PropertyText.Title.Brand = EnumHelper.GetDescription<Machine>(PropertyText.Name.Brand);
            PropertyText.Title.Location = EnumHelper.GetDescription<Machine>(PropertyText.Name.Location);
            PropertyText.Title.Assets = EnumHelper.GetDescription<Machine>(PropertyText.Name.Assets);
            PropertyText.Title.SerialNumber = EnumHelper.GetDescription<Machine>(PropertyText.Name.SerialNumber);
            PropertyText.Title.Barcode = EnumHelper.GetDescription<Machine>(PropertyText.Name.Barcode);
            PropertyText.Title.Connected = EnumHelper.GetDescription<Machine>(PropertyText.Name.Connected);
            PropertyText.Title.Disposal = EnumHelper.GetDescription<Machine>(PropertyText.Name.Disposal);
            PropertyText.Title.Remark = EnumHelper.GetDescription<Machine>(PropertyText.Name.Remark);
            PropertyText.Title.Workstations = EnumHelper.GetDescription<Machine>(PropertyText.Name.Workstations);
            PropertyText.Title.ModelStatus = EnumHelper.GetDescription<ModelStatus>(PropertyText.Name.ModelStatus);
            PropertyText.Title.UserGroups = EnumHelper.GetDescription<UserGroup>(PropertyText.Name.UserGroupNames);

            SplashMessenger.Post("核心模組: 建立快取");
            _coreData.IsActiveEmployee = _context.EmployeeStatuses.FirstOrDefault(s => s.StatusName == "在職")?.Id ?? 1;
            await UpdateCoreDataCache();

            _isInitialized = true;
        }

        /********************
         * Control
         ********************/
        /// <inheritdoc/>
        public void CleanUpControls(Control.ControlCollection controls)
        {
            if (controls.Count == 0)
                return;

            foreach (Control c in controls)
                c.Dispose();
            controls.Clear();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        /********************
         * 取得 Core Data
         ********************/

        /***** Machine *****/
        /// <inheritdoc/>
        public int? GetMachineId(string machineString)
        {
            Machine ma = GetMachine(machineString);
            return ma?.Id ?? null;
        }

        /// <inheritdoc/>
        public Machine GetMachine(int id)
            => _coreData.Machines.FirstOrDefault(e => e.Id == id);

        /// <inheritdoc/>
        public Machine GetMachine(string MachineCode)
            => _coreData.Machines.FirstOrDefault(e => e.MachineCode == MachineCode);

        /***** User *****/

        /// <inheritdoc/>
        public Employee GetEmployee(int id)
            => _coreData.Employees.FirstOrDefault(e => e.Id == id);

        /// <inheritdoc/>
        public Employee GetEmployee(string employee)
            => _coreData.Employees.FirstOrDefault(e => employee.Contains(e.EmployeeId) || employee.Contains(e.EmployeeName));

        /***** Engineer *****/

        /// <inheritdoc/>
        public Employee GetEngineer(int id)
            => _coreData.Engineers.FirstOrDefault(e => e.Id == id);

        /// <inheritdoc/>
        public Employee GetEngineer(string employee)
            => _coreData.Engineers.FirstOrDefault(e => employee.Contains(e.EmployeeId) || employee.Contains(e.EmployeeName));

        /// <inheritdoc/>
        public List<Employee> GetEngineers(List<int> engineerIdList)
        {
            if (engineerIdList.Count == 0)
                return new List<Employee>();

            return _coreData.Employees
                .Where(e => e.IsEngineer && engineerIdList.Contains(e.Id))
                .ToList();
        }

        /// <inheritdoc/>
        public List<Employee> GetEngineers(string engineerNameList)
        {
            if (string.IsNullOrWhiteSpace(engineerNameList))
                return new List<Employee>();

            var emps = engineerNameList
                .Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
            return _coreData.Employees
                .Where(e => e.IsEngineer && emps.Contains(e.EmployeeName))
                .ToList();
        }

        /***** Model *****/

        /// <inheritdoc/>
        public Model GetModel(int modelId)
        {
            return _coreData.Models.FirstOrDefault(w => w.Id == modelId);
        }

        /// <inheritdoc/>
        public Model GetModel(string modelName)
        {
            return _coreData.Models.FirstOrDefault(w => w.ModelName == modelName);
        }

        /***** Workstation *****/

        /// <inheritdoc/>
        public Workstation GetWorkstation(int id)
        {
            return _coreData.Workstations.FirstOrDefault(w => w.Id == id);
        }

        /// <inheritdoc/>
        public Workstation GetWorkstation(string workstationName)
        {
            if (string.IsNullOrWhiteSpace(workstationName))
                return null;

            var wsName = workstationName
                .Split(new[] { '»', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Last();
            return _coreData.Workstations.FirstOrDefault(w => w.WorkstationName == wsName);

            //return _coreData.Workstations.FirstOrDefault(w => w.workstationName == workstationName);
        }

        /***** Model » Workstation *****/

        /// <inheritdoc/>
        public (Model, Workstation) GetModelWorkstation(string modelWorkstation)
        {
            if (string.IsNullOrWhiteSpace(modelWorkstation))
                return (null, null);

            var objs = modelWorkstation
                .Split(new[] { '»', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();

            Model model;
            Workstation ws;
            switch (objs.Count)
            {
                case 1:
                    model = null;
                    ws = GetWorkstation(objs[0]);
                    break;
                case 2:
                    model = GetModel(objs[0]);
                    ws = GetWorkstation(objs[1]);
                    break;
                default:
                    model = null;
                    ws = null;
                    break;
            }
            return (model, ws);
        }

        /********************
         * Core Data
         ********************/
        /// <inheritdoc/>
        public async Task UpdateCoreDataCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            await UpdateEmployeesCache(false);
            if (RecreateTabPage)
            {
                _ = CreateEmployeeTabPage();
                _ = CreateEngineerTabPage();
            }
            if (SendUpdateNotification)
                _cacheManager.NotifyEmployeeUpdated();

            await UpdateMachinesCache(false, false);
            if (RecreateTabPage)
                _ = CreateMachineTabPage();
            if (SendUpdateNotification)
                _cacheManager.NotifyMachineUpdated();

            await UpdateModelsCache(false, false);
            if (RecreateTabPage)
                _ = CreateModelTabPage();
            if (SendUpdateNotification)
                _cacheManager.NotifyModelNoUpdated();

            await UpdateWorkstationsCache(false, false);
            if (RecreateTabPage)
                _ = CreateModelWsTabPage();
            if (SendUpdateNotification)
                _cacheManager.NotifyWorkstationUpdated();

            await UpdateGlobalsCache(false, false);
            if (RecreateTabPage)
                _ = CreateGlobalTabPage();
            if (SendUpdateNotification)
                _cacheManager.NotifyGlobalUpdated();
        }

        /// <inheritdoc/>
        public async Task UpdateEmployeesCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var query = await _context.Employees
                .Where(x => x.StatusId == _coreData.IsActiveEmployee)
                .AsNoTracking()
                .ToListAsync();

            _coreData.Employees = query
                .OrderBy(e => e.Department?.OrderNo ?? int.MaxValue)
                .ThenBy(e => e.JobTitle?.OrderNo ?? int.MaxValue)
                .ThenBy(e => e.EmployeeId)
                .ToList();

            _coreData.ClassifyEmployee = _coreData.Employees
                .GroupBy(e => e.DepartmentName)
                .ToDictionary(
                    g => g.Key,
                    g => g.Select(e => new ClassifyInfo()
                    {
                        Id = e.Id,
                        IdString = e.EmployeeId,
                        Category1 = e.DepartmentName,
                        Category2 = e.JobTitleName,
                        Name = e.EmployeeName,
                    })
                    .ToList());

            _coreData.Engineers = _coreData.Employees
                .Where(e => e.IsEngineer)
                .ToList();

            if (RecreateTabPage)
                _ = CreateEmployeeTabPage();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                _cacheManager.NotifyEmployeeUpdated();
            //_ = WeakReferenceMessenger.Default.Send(NotifyEmployeeDataUpdated.Instance);
        }

        /********************
         * Cache Update
         ********************/
        /// <inheritdoc/>
        public async Task UpdateMachinesCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var qMachines = await _context.Machines
                .Include(m => m.MachineName.MachineType.Category)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Condition)
                .Include(m => m.UserGroups)
                //.Where(m => m.Disposal == false)
                .AsNoTracking()
                .ToListAsync();
            _coreData.Machines = qMachines
                .Select(m => new { Original = m, Key = GetMachineSortKey(m.MachineCode) })
                .OrderBy(x => x.Key.Text)
                .ThenBy(x => x.Key.Number)
                .Select(x => x.Original)
                .ToList();

            _coreData.ClassifyMachines = _coreData.Machines
                .Where(m => m.Disposal == false
                    && m.MachineName != null
                    && m.MachineName.MachineType != null
                    && m.MachineName.MachineType.Category != null)
                .GroupBy(m => m.MachineName.MachineType.Category.CategoryName) // 外層 Category
                .OrderBy(g => g.First().MachineName.MachineType.Category.OrderNo)
                .ToDictionary(
                    categoryGroup => categoryGroup.Key, // CategoryName
                    categoryGroup => categoryGroup
                        .GroupBy(m => m.MachineName.MachineType.TypeName) // 內層 TypeName
                        .OrderBy(typeGroup => typeGroup.First().MachineName.MachineType.OrderNo)
                        .ToDictionary(
                            typeGroup => typeGroup.Key, // TypeName
                            typeGroup => typeGroup
                                .Select(m => new ClassifyInfo
                                {
                                    Id = m.Id,
                                    Name = m.MachineCode // 或 MachineName.MachineName
                                })
                                .ToList()
                        )
                );

            // MachineCategories
            _coreData.MachineCategories = await _context.MachineCategories
                    .OrderBy(b => b.OrderNo)
                    .AsNoTracking()
                    .ToListAsync();

            // MachineTypes
            _coreData.MachineTypes = await _context.MachineTypes
                    .OrderBy(b => b.OrderNo)
                    .AsNoTracking()
                    .ToListAsync();

            if (RecreateTabPage)
                _ = CreateMachineTabPage();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                _cacheManager.NotifyMachineUpdated();
            //_ = WeakReferenceMessenger.Default.Send(NotifyMachineDataUpdated.Instance);
        }

        /// <inheritdoc/>
        public async Task UpdateModelsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var tModels = await _context.Models
                .AsNoTracking()
                .ToListAsync();
            _coreData.Models = tModels
                .ToList()
                .Select(m => new { Original = m, Key = GetModelSortKey(m.ModelName) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();

            var sortedModels = SortModelNames(_coreData.Models.Select(m => m.ModelName).Distinct())
                .SelectMany(name => _coreData.Models.Where(m => m.ModelName == name))
                .ToList();
            _coreData.ClassifyModels = ClassifyItems(
                sortedModels,
                m => m.ModelName,
                "Model",
                m => m.Id,
                m => m.ModelName
            );

            if (RecreateTabPage)
            {
                _ = CreateModelTabPage();
                _ = CreateModelWsTabPage();
            }

            // 發佈資料更新通知
            if (SendUpdateNotification)
                _cacheManager.NotifyModelNoUpdated();
            //_ = WeakReferenceMessenger.Default.Send(NotifyModelNoDataUpdated.Instance);
        }

        /// <inheritdoc/>
        public async Task UpdateWorkstationsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            var tWorkstations = await _context.Workstations
                .Include(w => w.Model)
                .AsNoTracking()
                .ToListAsync();
            _coreData.Workstations = tWorkstations
                .Select(w => new { Original = w, Key = GetWorkstationSortKey(w) })
                .OrderBy(w => w.Key.ModelPriority)
                .ThenBy(w => w.Key.ModelNumber)
                .ThenBy(w => w.Key.OrderNo)
                .Select(w => w.Original)
                .ToList();

            var sortedWorkstations = SortWorkstations(_coreData.Workstations);
            _coreData.ClassifyWorkstations = ClassifyItems(
                sortedWorkstations,
                w => w.Model.ModelName,
                "Workstation",
                w => w.Id,
                w => w.WorkstationName
            );

            if (RecreateTabPage)
                _ = CreateModelWsTabPage();
            //    CreateModelTabPage();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                _cacheManager.NotifyWorkstationUpdated();
            //_ = WeakReferenceMessenger.Default.Send(NotifyWorkstationDataUpdated.Instance);
        }

        /// <inheritdoc/>
        public async Task UpdateGlobalsCache(bool SendUpdateNotification = true, bool RecreateTabPage = true)
        {
            // Permission 及 Group 的 Cache 由他們自己管理

            if (RecreateTabPage)
                _ = CreateGlobalTabPage();

            // 發佈資料更新通知
            if (SendUpdateNotification)
                _cacheManager.NotifyGlobalUpdated();

            await Task.CompletedTask;
        }

        /********************
         * Utility
         ********************/
        /// <inheritdoc/>
        public IEnumerable<Machine> SortMachines(IEnumerable<Machine> machines)
        {
            return machines
                .Select(m => new { Machine = m, Key = GetMachineSortKey(m.MachineCode) })
                .OrderBy(x => x.Key.Text)
                .ThenBy(x => x.Key.Number)
                .Select(x => x.Machine);
        }

        /// <inheritdoc/>
        public List<string> SortModelNames(IEnumerable<string> modelNames)
        {
            return modelNames
                .Select(name => new { Original = name, Key = GetModelSortKey(name) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .ToList();
        }

        /// <inheritdoc/>
        public List<Workstation> SortWorkstations(IEnumerable<Workstation> workstations)
        {
            return workstations
                .OrderBy(w => GetWorkstationSortKey(w))
                .ToList();
        }

        /// <summary>
        /// 將資料列表轉換成 Classify 結構
        /// </summary>
        /// <typeparam name="T">資料類型，例如 Model 或 Workstation</typeparam>
        /// <param name="items">資料列表</param>
        /// <param name="categorySelector">第一層分類 key，例如 ModelName</param>
        /// <param name="typeName">第二層 Type 名稱，例如 "Model" 或 "Workstation"</param>
        /// <param name="idSelector">取得 Id 的函式</param>
        /// <param name="nameSelector">取得 Name 的函式</param>
        /// <returns>分類後的 Dictionary 結構</returns>
        private static Dictionary<string, Dictionary<string, List<ClassifyInfo>>> ClassifyItems<T>(
            IEnumerable<T> items,
            Func<T, string> categorySelector,
            string typeName,
            Func<T, int> idSelector,
            Func<T, string> nameSelector)
        {
            return items
                .GroupBy(categorySelector)
                .ToDictionary(
                    g => g.Key,
                    g => new Dictionary<string, List<ClassifyInfo>>
                    {
                        {
                            typeName,
                            g.Select(x => new ClassifyInfo
                            {
                                Id = idSelector(x),
                                Category1 = typeName,
                                Name = nameSelector(x)
                            }).ToList()
                        }
                    }
                );
        }

        /********************
         * TabPage Cache
         ********************/
        //public async Task CreateMachineTabPage()
        //{
        //    await DebouncedSmartSyncAsync(
        //        _coreData.MachinesMultiTabPageCache,
        //        _coreData.ClassifyMachines,
        //        isMultiMode: true);

        //    await DebouncedSmartSyncAsync(
        //        _coreData.MachinesSingleTabPageCache,
        //        _coreData.ClassifyMachines,
        //        isMultiMode: false);
        //}

        ///// <inheritdoc/>
        //public async Task CreateModelTabPage()
        //{
        //    await DebouncedSmartSyncAsync(
        //        _coreData.ModelTabPageCache,
        //        _coreData.ClassifyModels,
        //        isMultiMode: false);
        //}

        ///// <inheritdoc/>
        //public async Task CreateModelWsTabPage()
        //{
        //    await DebouncedSmartSyncAsync(
        //        _coreData.ModelWsTabPageCache,
        //        _coreData.ClassifyWorkstations,
        //        isMultiMode: false);
        //}

        /********************
         * Common TabPage Cache Update Functions
         ********************/
        /// <summary>
        /// 比對兩個TabPage是否相同。
        /// </summary>
        private bool AreTabPageListsEqual(List<TabPage> oldList, List<TabPage> newList)
        {
            if (oldList.Count != newList.Count)
                return false;

            for (int i = 0; i < oldList.Count; i++)
            {
                if (oldList[i].Name != newList[i].Name)
                    return false;
            }
            return true;
        }

        /// <inheritdoc/>
        public async Task CreateEmployeeTabPage()
        {
            _coreData.EmployeeMultiTabPageCache = new Dictionary<string, List<TabPage>>();
            _coreData.EmployeeSingleTabPageCache = new Dictionary<string, List<TabPage>>();

            foreach (var mDepName in _coreData.ClassifyEmployee.Keys)
            {
                var emps = _coreData.ClassifyEmployee[mDepName]
                    .OrderBy(e => e.IdString)
                    .ToList();
                List<TabPage> emTabPages = new List<TabPage>();
                List<TabPage> esTabPages = new List<TabPage>();

                int colCount = 3;
                int typeCount = emps.Count();
                int rowCount = (int)Math.Ceiling((double)typeCount / (double)colCount);

                var emFlow = new UITableLayoutPanel
                {
                    ColumnCount = colCount,
                    RowCount = rowCount,
                    Dock = DockStyle.Fill,
                    AutoScroll = true,
                };
                var emTabPage = new TabPage(mDepName)
                {
                    Name = mDepName,
                    Font = CommonStyles.Font,
                };

                var esFlow = new UITableLayoutPanel
                {
                    ColumnCount = colCount,
                    RowCount = rowCount,
                    Dock = DockStyle.Fill,
                    AutoScroll = true,
                };
                var esTabPage = new TabPage(mDepName)
                {
                    Name = mDepName,
                    Font = CommonStyles.Font,
                };

                int nCol = 0;
                int nRow = 0;
                var margins = new Padding(9, 5, 15, 5);
                foreach (var emp in emps)
                {
                    //string displayText = string.IsNullOrWhiteSpace(emp.Category2 ?? "") ? "" : $"{emp.Category2} » ";
                    string displayText = $"{emp.IdString} {emp.Name}";

                    var cb = new UICheckBox
                    {
                        Text = displayText,
                        Name = emp.IdString,
                        Checked = false,
                        AutoSize = true,
                        //Width = 130,
                        Margin = margins,
                        Font = CommonStyles.Font,
                        Style = UIStyle.Inherited,
                        CheckBoxColor = CommonStyles.BackColor,
                        Tag = emp
                    };
                    emFlow.Controls.Add(cb, nCol, nRow);

                    var rb = new UIRadioButton
                    {
                        GroupIndex = 1,
                        Text = displayText,
                        Name = emp.IdString,
                        Checked = false,
                        AutoSize = true,
                        //Width = 130,
                        Margin = margins,
                        Font = CommonStyles.Font,
                        Style = UIStyle.Inherited,
                        RadioButtonColor = CommonStyles.BackColor,
                        Tag = emp
                    };
                    esFlow.Controls.Add(rb, nCol, nRow);

                    if (++nCol >= colCount)
                    {
                        nCol = 0;
                        ++nRow;
                    }
                }
                emTabPage.Controls.Add(emFlow);
                emTabPages.Add(emTabPage);
                _coreData.EmployeeMultiTabPageCache.Add(mDepName, emTabPages);

                esTabPage.Controls.Add(esFlow);
                esTabPages.Add(esTabPage);
                _coreData.EmployeeSingleTabPageCache.Add(mDepName, esTabPages);
            }
            await Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task CreateEngineerTabPage()
        {
            _coreData.EngineerMultiTabPageCache = new Dictionary<string, List<TabPage>>();
            _coreData.EngineerSingleTabPageCache = new Dictionary<string, List<TabPage>>();

            int colCount = 3;
            int rowCount = _coreData.Engineers.Count();

            var emFlow = new UITableLayoutPanel
            {
                ColumnCount = colCount,
                RowCount = rowCount,
                Dock = DockStyle.Fill,
                AutoScroll = true,
            };

            var esFlow = new UITableLayoutPanel
            {
                ColumnCount = colCount,
                RowCount = rowCount,
                Dock = DockStyle.Fill,
                AutoScroll = true,
            };

            List<TabPage> emTabPages = new List<TabPage>();
            List<TabPage> esTabPages = new List<TabPage>();
            int nCol = 0;
            int nRow = 0;
            var margins = new Padding(9, 5, 15, 5);
            var dbSource = _coreData.Engineers
                .OrderBy(e => e.EmployeeId)
                .ToList();
            foreach (var emp in dbSource)
            {
                //string displayText = string.IsNullOrWhiteSpace(emp.JobTitle?.JobTitleName ?? "")
                //    ? ""
                //    : $"{emp.JobTitle.JobTitleName} » ";
                string displayText = $"{emp.EmployeeId} {emp.EmployeeName}";

                var cb = new UICheckBox
                {
                    Text = displayText,
                    Name = emp.EmployeeId,
                    Checked = false,
                    AutoSize = true,
                    //Width = 130,
                    Margin = margins,
                    Font = CommonStyles.Font,
                    Style = UIStyle.Inherited,
                    CheckBoxColor = CommonStyles.BackColor,
                    Tag = new ClassifyInfo()
                    {
                        Id = emp.Id,
                        IdString = emp.EmployeeId,
                        Category1 = emp.Department?.DepartmentName ?? "",
                        Category2 = emp.JobTitle?.JobTitleName ?? "",
                        Name = emp.EmployeeName,
                    }
                };
                emFlow.Controls.Add(cb, nCol, nRow);

                var rb = new UIRadioButton
                {
                    GroupIndex = 1,
                    Text = displayText,
                    Name = emp.EmployeeId,
                    Checked = false,
                    AutoSize = true,
                    //Width = 130,
                    Margin = margins,
                    Font = CommonStyles.Font,
                    Style = UIStyle.Inherited,
                    RadioButtonColor = CommonStyles.BackColor,
                    Tag = new ClassifyInfo()
                    {
                        Id = emp.Id,
                        IdString = emp.EmployeeId,
                        Category1 = emp.Department?.DepartmentName ?? "",
                        Category2 = emp.JobTitle?.JobTitleName ?? "",
                        Name = emp.EmployeeName,
                    }
                };
                esFlow.Controls.Add(rb, nCol, nRow);

                if (++nCol >= colCount)
                {
                    nCol = 0;
                    ++nRow;
                }
            }
            TabPage emTabPage = new TabPage();
            emTabPage.Controls.Add(emFlow);
            emTabPages.Add(emTabPage);
            _coreData.EngineerMultiTabPageCache.Add(string.Empty, emTabPages);

            TabPage esTabPage = new TabPage();
            esTabPage.Controls.Add(esFlow);
            esTabPages.Add(esTabPage);
            _coreData.EngineerSingleTabPageCache.Add(string.Empty, esTabPages);

            await Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task CreateMachineTabPage()
        {
            _coreData.MachinesMultiTabPageCache = new Dictionary<string, List<TabPage>>();
            _coreData.MachinesSingleTabPageCache = new Dictionary<string, List<TabPage>>();

            foreach (var mCategoryName in _coreData.ClassifyMachines.Keys)
            {
                List<TabPage> mmTabPages = new List<TabPage>();
                List<TabPage> msTabPages = new List<TabPage>();
                var mTypesDicts = _coreData.ClassifyMachines[mCategoryName];

                int colCount = 5;
                int typeCount = mTypesDicts.Count();
                int rowCount = (int)Math.Ceiling((double)typeCount / (double)colCount);

                foreach (var mTypeName in mTypesDicts.Keys)
                {
                    var mmFlow = new UITableLayoutPanel
                    {
                        ColumnCount = colCount,
                        RowCount = rowCount,
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    var mmTabPage = new TabPage(mTypeName)
                    {
                        Name = mTypeName,
                        Font = CommonStyles.Font,
                    };
                    mmTabPage.Controls.Add(mmFlow);

                    var msFlow = new UITableLayoutPanel
                    {
                        ColumnCount = colCount,
                        RowCount = rowCount,
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    var msTabPage = new TabPage(mTypeName)
                    {
                        Name = mTypeName,
                        Font = CommonStyles.Font,
                    };
                    msTabPage.Controls.Add(msFlow);

                    int nCol = 0;
                    int nRow = 0;
                    var machineList = mTypesDicts[mTypeName];
                    foreach (var machine in machineList)
                    {
                        var cb = new UICheckBox
                        {
                            Text = machine.Name,
                            Name = machine.Name,
                            Checked = false,
                            AutoSize = false,
                            Width = 130,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            CheckBoxColor = CommonStyles.BackColor,
                            Tag = new ClassifyInfo()
                            {
                                Id = machine.Id,
                                Category1 = mCategoryName,
                                Category2 = mTypeName,
                                Name = machine.Name,
                            }
                        };
                        mmFlow.Controls.Add(cb, nCol, nRow);

                        var rb = new UIRadioButton
                        {
                            GroupIndex = 1,
                            Text = machine.Name,
                            Name = machine.Name,
                            Checked = false,
                            AutoSize = false,
                            Width = 130,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            RadioButtonColor = CommonStyles.BackColor,
                            Tag = new ClassifyInfo()
                            {
                                Id = machine.Id,
                                Category1 = mCategoryName,
                                Category2 = mTypeName,
                                Name = machine.Name,
                            }
                        };
                        msFlow.Controls.Add(rb, nCol, nRow);

                        if (++nCol >= colCount)
                        {
                            nCol = 0;
                            ++nRow;
                        }
                    }
                    mmTabPages.Add(mmTabPage);
                    msTabPages.Add(msTabPage);
                }

                _coreData.MachinesMultiTabPageCache.Add(mCategoryName, mmTabPages);
                _coreData.MachinesSingleTabPageCache.Add(mCategoryName, msTabPages);
            }
            await Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task CreateModelTabPage()
        {
            _coreData.ModelTabPageCache = new Dictionary<string, List<TabPage>>();
            List<TabPage> moTabPages = new List<TabPage>();
            string moCategoryName = default;
            foreach (var model in _coreData.Models)
            {
                moCategoryName = model.ModelName;
                string moTypeName = PropertyText.Title.ModelName;
                int colCount = 4;
                int rowCount = (int)Math.Ceiling((double)_coreData.Models.Count() / (double)colCount);

                var moFlow = new UITableLayoutPanel()
                {
                    ColumnCount = colCount,
                    RowCount = rowCount,
                    Dock = DockStyle.Fill,
                    AutoScroll = true,
                };
                var moTabPage = new TabPage(moTypeName)
                {
                    Name = moTypeName,
                    Font = CommonStyles.Font,
                };
                moTabPage.Controls.Add(moFlow);

                int nCol = 0;
                int nRow = 0;
                foreach (var ml in _coreData.Models)
                {
                    var rb = new UIRadioButton
                    {
                        GroupIndex = 1,
                        Text = ml.ModelName,
                        Name = ml.ModelName,
                        Checked = false,
                        AutoSize = false,
                        Width = 150,
                        Font = CommonStyles.Font,
                        Style = UIStyle.Inherited,
                        RadioButtonColor = CommonStyles.BackColor,
                        Tag = new ClassifyInfo()
                        {
                            Id = ml.Id,
                            Category1 = moCategoryName,
                            Category2 = moTypeName,
                            Name = ml.ModelName,
                        }
                    };
                    moFlow.Controls.Add(rb, nCol, nRow);

                    if (++nCol >= colCount)
                    {
                        nCol = 0;
                        ++nRow;
                    }
                }
                moTabPages.Add(moTabPage);
            }
            _coreData.ModelTabPageCache.Add(moCategoryName, moTabPages);
            await Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task CreateModelWsTabPage()
        {
            _coreData.ModelWsMultiTabPageCache = new Dictionary<string, List<TabPage>>();
            _coreData.ModelWsSingleTabPageCache = new Dictionary<string, List<TabPage>>();

            foreach (var model in _coreData.Models)
            {
                var wss = _coreData.Workstations
                    .Where(w => w.ModelId == model.Id)
                    .ToList();

                int colCount = 3;
                int typeCount = wss.Count();
                int rowCount = (int)Math.Ceiling((double)typeCount / (double)colCount);

                if (wss.Count > 0)
                {
                    string moCategoryName = model.ModelName;
                    string moTypeName = PropertyText.Title.Workstation;
                    List<TabPage> mmTabPages = new List<TabPage>();
                    List<TabPage> msTabPages = new List<TabPage>();
                    var mmTabPage = new TabPage(moTypeName)
                    {
                        Name = moTypeName,
                        Font = CommonStyles.Font,
                    };
                    var mmFlow = new UITableLayoutPanel
                    {
                        ColumnCount = colCount,
                        RowCount = rowCount,
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    mmTabPage.Controls.Add(mmFlow);

                    var msTabPage = new TabPage(moTypeName)
                    {
                        Name = moTypeName,
                        Font = CommonStyles.Font,
                    };
                    var msFlow = new UITableLayoutPanel
                    {
                        ColumnCount = colCount,
                        RowCount = rowCount,
                        Dock = DockStyle.Fill,
                        AutoScroll = true,
                    };
                    msTabPage.Controls.Add(msFlow);

                    int nCol = 0;
                    int nRow = 0;
                    foreach (var ws in wss)
                    {
                        var cb = new UICheckBox
                        {
                            Text = ws.WorkstationName,
                            Name = ws.WorkstationName,
                            Checked = false,
                            //AutoSize = true,
                            Width = 200,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            CheckBoxColor = CommonStyles.BackColor,
                            Tag = new ClassifyInfo()
                            {
                                Id = ws.Id,
                                Category1 = moCategoryName,
                                Category2 = moTypeName,
                                Name = ws.WorkstationName,
                            }
                        };
                        mmFlow.Controls.Add(cb, nCol, nRow);

                        var rb = new UIRadioButton
                        {
                            GroupIndex = 1,
                            Text = ws.WorkstationName,
                            Name = ws.WorkstationName,
                            Checked = false,
                            //AutoSize = true,
                            Width = 200,
                            Font = CommonStyles.Font,
                            Style = UIStyle.Inherited,
                            RadioButtonColor = CommonStyles.BackColor,
                            Tag = new ClassifyInfo()
                            {
                                Id = ws.Id,
                                Category1 = moCategoryName,
                                Category2 = moTypeName,
                                Name = ws.WorkstationName,
                            }
                        };
                        msFlow.Controls.Add(rb, nCol, nRow);

                        if (++nCol >= colCount)
                        {
                            nCol = 0;
                            ++nRow;
                        }
                    }
                    mmTabPages.Add(mmTabPage);
                    msTabPages.Add(msTabPage);
                    _coreData.ModelWsMultiTabPageCache.Add(moCategoryName, mmTabPages);
                    _coreData.ModelWsSingleTabPageCache.Add(moCategoryName, msTabPages);
                }
            }
            await Task.CompletedTask;
        }

        /// <inheritdoc/>
        public async Task CreateGlobalTabPage()
        {
            _coreData.GroupMultiTabPageCache = new Dictionary<string, List<TabPage>>();
            List<TabPage> moTabPages = new List<TabPage>();

            var globals = await _context.UserGroups
                .AsNoTracking()
                .ToListAsync();

            string mgTitle = "群組";
            int colCount = 4;
            int rowCount = (int)Math.Ceiling((double)globals.Count() / colCount);

            var mgFlow = new UITableLayoutPanel()
            {
                ColumnCount = colCount,
                RowCount = rowCount,
                Dock = DockStyle.Fill,
                AutoScroll = true,
            };
            var mgTabPage = new TabPage(mgTitle)
            {
                Name = mgTitle,
                Font = CommonStyles.Font,
            };
            mgTabPage.Controls.Add(mgFlow);

            int nCol = 0;
            int nRow = 0;
            foreach (var gl in globals)
            {
                var cb = new UICheckBox
                {
                    Name = gl.Name,
                    Text = gl.Name,
                    Checked = false,
                    AutoSize = false,
                    Width = 150,
                    Font = CommonStyles.Font,
                    Style = UIStyle.Inherited,
                    CheckBoxColor = CommonStyles.BackColor,
                    Tag = new ClassifyInfo()
                    {
                        Id = gl.Id,
                        Category1 = mgTitle,
                        Category2 = null,
                        Name = gl.Name,
                    }
                };
                mgFlow.Controls.Add(cb, nCol, nRow);

                if (++nCol >= colCount)
                {
                    nCol = 0;
                    ++nRow;
                }
            }
            moTabPages.Add(mgTabPage);
            _coreData.GroupMultiTabPageCache.Add(mgTitle, moTabPages);
        }

        ///// <summary>
        ///// 智慧快取防抖，300ms內多次呼叫只跑最後一次
        ///// </summary>
        ///// <param name="cache">原 Cache。</param>
        ///// <param name="source">待更新資料來源。</param>
        ///// <param name="isMultiMode">true: 多選模式，使用 CheckBox。<br/>false: 單選模式，使用 RadioButtom。</param>
        ///// <param name="rebuildThreshold">變動比例。原 Cache 與資料來源差異比例超過此值，則執行完整重建，否則使用差異更新。</param>
        //public async Task DebouncedSmartSyncAsync(
        //    ConcurrentDictionary<string, List<TabPage>> cache,
        //    Dictionary<string, Dictionary<string, List<TabPageInfo>>> source,
        //    bool isMultiMode,
        //    double rebuildThreshold = 0.7)
        //{
        //    _syncCts?.Cancel();
        //    _syncCts = new CancellationTokenSource();

        //    try
        //    {
        //        await Task.Delay(300, _syncCts.Token);
        //        await SmartSyncCacheAsync(cache, source, isMultiMode, rebuildThreshold);
        //    }
        //    catch (TaskCanceledException) { }
        //}

        ///// <summary>
        ///// 智慧快取。根據變動比例選擇差異更新或完整重建，並在背景執行。
        ///// </summary>
        //public async Task SmartSyncCacheAsync(
        //    ConcurrentDictionary<string, List<TabPage>> cache,
        //    Dictionary<string, Dictionary<string, List<TabPageInfo>>> source,
        //    bool isMultiMode,
        //    double rebuildThreshold = 0.7)
        //{
        //    // 分析差異比例
        //    var currentKeys = cache.Keys.ToList();
        //    var newKeys = source.Keys.ToList();

        //    double changeRatio;
        //    int totalKeys = newKeys.Count;
        //    if (totalKeys == 0)
        //    {
        //        changeRatio = 1.0;
        //    }
        //    else
        //    {
        //        int changedOrMissingCount = newKeys.Count(k => !cache.ContainsKey(k));
        //        int removedCount = currentKeys.Count(k => !newKeys.Contains(k));
        //        int totalChanges = changedOrMissingCount + removedCount;
        //        changeRatio = (double)totalChanges / totalKeys;
        //    }

        //    // 背景處理資料差異
        //    var diffResult = await Task.Run(() =>
        //    {
        //        var toRemove = cache.Keys.Except(source.Keys).ToList();
        //        var updatedItems = new List<(string key, List<TabPageInfo> pageInfos)>();

        //        if (changeRatio >= rebuildThreshold)
        //        {
        //            // 大幅變動：重建整個 cache
        //            foreach (var category in source.Keys)
        //            {
        //                var newPageInfos = source[category].SelectMany(kv => kv.Value).ToList();
        //                updatedItems.Add((category, newPageInfos));
        //            }
        //        }
        //        else
        //        {
        //            // 小幅變動：只更新差異
        //            foreach (var category in source.Keys)
        //            {
        //                var newPageInfos = source[category].SelectMany(kv => kv.Value).ToList();
        //                if (!cache.TryGetValue(category, out var oldPages) ||
        //                    !AreTabPageInfosEqual(oldPages, newPageInfos))
        //                {
        //                    updatedItems.Add((category, newPageInfos));
        //                }
        //            }
        //        }

        //        return (toRemove, updatedItems);
        //    });

        //    // UI 執行緒生成 TabPage 控件
        //    WinFormExtension.RunOnUIThread(() =>
        //    {
        //        // 移除多餘
        //        foreach (var key in diffResult.toRemove)
        //            cache.TryRemove(key, out _);

        //        // 更新或新增
        //        foreach (var (key, pageInfos) in diffResult.updatedItems)
        //        {
        //            var tabPages = pageInfos.Select(pi =>
        //            {
        //                var tab = new TabPage(pi.Name);
        //                foreach (var ctrlData in pi.ControlsData)
        //                {
        //                    // 這裡根據 DTO 生成 Control
        //                    var c = CreateControlFromData(ctrlData);
        //                    tab.Controls.Add(c);
        //                }
        //                return tab;
        //            }).ToList();

        //            cache.AddOrUpdate(key, tabPages, (k, oldVal) => tabPages);
        //        }
        //    });

        //    // 背景執行實際同步
        //    await Task.Run(() =>
        //    {
        //        if (changeRatio >= rebuildThreshold)
        //        {
        //            // 大幅變動，執行完整重建
        //            var newCache = new ConcurrentDictionary<string, List<TabPage>>();
        //            foreach (var category in source.Keys)
        //            {
        //                var newTabs = CreateTabPages(category, isMultiMode);
        //                newCache.TryAdd(category, newTabs);
        //            }
        //            WinFormExtension.RunOnUIThread(() =>
        //            {
        //                cache.Clear();
        //                foreach (var kvp in newCache)
        //                    cache.TryAdd(kvp.Key, kvp.Value);
        //            });
        //        }
        //        else
        //        {
        //            // 小幅變動，執行差異更新
        //            var toRemove = cache.Keys.Except(source.Keys).ToList();
        //            var updatedItems = new List<(string key, List<TabPage> value)>();
        //            foreach (var category in source.Keys)
        //            {
        //                var newTabs = CreateTabPages(category, isMultiMode);
        //                if (!cache.TryGetValue(category, out var oldTabs) ||
        //                    !AreTabPageListsEqual(oldTabs, newTabs))
        //                {
        //                    updatedItems.Add((category, newTabs));
        //                }
        //            }
        //            WinFormExtension.RunOnUIThread(() =>
        //            {
        //                foreach (var (key, value) in updatedItems)
        //                    cache.AddOrUpdate(key, value, (k, oldVal) => value);

        //                foreach (var key in toRemove)
        //                    cache.TryRemove(key, out _);
        //            });
        //        }
        //    });
        //}

        //// 判斷 TabPage 是否一致（可依實際需求調整）
        //private bool AreTabPageInfosEqual(List<TabPage> tabs, List<TabPageInfo> infos)
        //{
        //    if (tabs.Count != infos.Count) return false;
        //    for (int i = 0; i < tabs.Count; i++)
        //    {
        //        if (tabs[i].Text != infos[i].Name) return false;
        //    }
        //    return true;
        //}

        ///// <summary>
        ///// 建立 TabPage 列表。
        ///// </summary>
        ///// <param name="categoryName">第一層分類。</param>
        ///// <param name="isMultiMode">true: 多選模式，使用 CheckBox。<br/>false: 單選模式，使用 RadioButtom。</param>
        ///// <returns>TabPage 列表。</returns>
        //private List<TabPage> CreateTabPages(string categoryName, bool isMultiMode)
        //{
        //    var tabPages = new List<TabPage>();
        //    if (!_coreData.ClassifyMachines.TryGetValue(categoryName, out var typeDicts))
        //        return tabPages;

        //    foreach (var mTypeName in typeDicts.Keys)
        //    {
        //        var tabPage = new TabPage(mTypeName)
        //        {
        //            Name = mTypeName,
        //            Font = CommonStyles.Font,
        //        };

        //        var flow = new UITableLayoutPanel
        //        {
        //            Dock = DockStyle.Fill,
        //            AutoScroll = true,
        //        };
        //        tabPage.Controls.Add(flow);

        //        var items = typeDicts[mTypeName];
        //        foreach (var item in items)
        //        {
        //            Control ctrl;
        //            if (isMultiMode)
        //                ctrl = CreateCheckBox(item, categoryName, mTypeName);
        //            else
        //                ctrl = CreateRadioButton(item, categoryName, mTypeName);

        //            flow.Controls.Add(ctrl);
        //        }

        //        tabPages.Add(tabPage);
        //    }
        //    return tabPages;
        //}

        ///// <summary>
        ///// 建立 CheckBox Control。
        ///// </summary>
        ///// <param name="item">要建立的 Control 資訊。</param>
        ///// <param name="categoryName">所屬第一層分類名稱。</param>
        ///// <param name="mTypeName">所屬第二層分類名稱。</param>
        ///// <returns>CheckBox。</returns>
        //private UICheckBox CreateCheckBox(TabPageInfo item, string categoryName, string mTypeName)
        //{
        //    return new UICheckBox
        //    {
        //        Text = item.Name,
        //        Name = item.Name,
        //        Checked = false,
        //        AutoSize = false,
        //        Width = 130,
        //        Font = CommonStyles.Font,
        //        Style = UIStyle.Inherited,
        //        CheckBoxColor = CommonStyles.BackColor,
        //        Tag = new SelectorInfo()
        //        {
        //            Id = item.Id,
        //            Category = categoryName,
        //            Type = mTypeName,
        //            Name = item.Name,
        //        }
        //    };
        //}

        ///// <summary>
        ///// 建立 RadioButton Control。
        ///// </summary>
        ///// <param name="item">要建立的 Control 資訊。</param>
        ///// <param name="categoryName">所屬第一層分類名稱。</param>
        ///// <param name="mTypeName">所屬第二層分類名稱。</param>
        ///// <returns>RadioButton。</returns>
        //private UIRadioButton CreateRadioButton(TabPageInfo item, string categoryName, string mTypeName)
        //{
        //    return new UIRadioButton
        //    {
        //        GroupIndex = 1,
        //        Text = item.Name,
        //        Name = item.Name,
        //        Checked = false,
        //        AutoSize = false,
        //        Width = 130,
        //        Font = CommonStyles.Font,
        //        Style = UIStyle.Inherited,
        //        RadioButtonColor = CommonStyles.BackColor,
        //        Tag = new SelectorInfo()
        //        {
        //            Id = item.Id,
        //            Category = categoryName,
        //            Type = mTypeName,
        //            Name = item.Name,
        //        }
        //    };
        //}

        /********************
         * Sorting Functions
         ********************/
        /*****
         * 英文開頭	                  ^([A-Za-z]+)-?(\d+)?$
         * 英文 + 中文 + 任意文字開頭   ^([^\d\-]+)-?(\d+)?$
         * 前綴可包含任意非數字字元     ^([^\d]+?)-?(\d+)?$
        *****/
        /// <summary>
        /// MachineCode 的共用排序規則。支援 A-1, A1, SS12, B-05, 等格式。
        /// </summary>
        public (string Text, int Number) GetMachineSortKey(string MachineCode)
        {
            if (string.IsNullOrWhiteSpace(MachineCode))
                return ("", 0);

            var match = Regex.Match(MachineCode, @"^([^\d]+?)-?(\d+)?$", RegexOptions.IgnoreCase);
            if (match.Success)
            {
                string text = match.Groups[1].Value.Trim();
                int number = 0;
                if (match.Groups[2].Success && !string.IsNullOrEmpty(match.Groups[2].Value))
                    int.TryParse(match.Groups[2].Value, out number);
                return (text, number);
            }

            return (MachineCode.Trim(), 0);
        }

        /// <summary>
        /// Model 的共用排序規則。
        /// </summary>
        public (bool IsThreeDigits, int SortKey) GetModelSortKey(string modelName)
        {
            var prefix = modelName.Split('-')[0];
            bool isThreeDigits = Regex.IsMatch(prefix, @"^\d{3}$");
            int sortKey = int.TryParse(prefix, out var n) ? n : int.MaxValue;
            return (isThreeDigits, sortKey);
        }

        /// <summary>
        /// workstationName 的共用排序規則。
        /// </summary>
        public (int ModelPriority, int ModelNumber, int OrderNo) GetWorkstationSortKey(Workstation w)
        {
            var modelName = w.Model?.ModelName ?? "";
            var key = GetModelSortKey(modelName);

            int modelPriority = key.IsThreeDigits ? 0 : 1;
            int modelNumber = key.SortKey;
            int orderNo = w.OrderNo;

            return (modelPriority, modelNumber, orderNo);
        }
    }
}


///// <inheritdoc/>
//public void CreateMachineTabPage()
//{
//    _coreData.MachinesMultiTabPageCache = new ConcurrentDictionary<string, List<TabPage>>();
//    _coreData.MachinesSingleTabPageCache = new ConcurrentDictionary<string, List<TabPage>>();
//    foreach (var mCategoryName in _coreData.ClassifyMachines.Keys)
//    {
//        List<TabPage> mmTabPages = new List<TabPage>();
//        List<TabPage> msTabPages = new List<TabPage>();
//        var mTypesDicts = _coreData.ClassifyMachines[mCategoryName];
//        foreach (var mTypeName in mTypesDicts.Keys)
//        {
//            var mmTabPage = new TabPage(mTypeName)
//            {
//                Name = mTypeName,
//                Font = CommonStyles.Font,
//            };
//            var mmFlow = new UIFlowLayoutPanel
//            {
//                Dock = DockStyle.Fill,
//                AutoScroll = true,
//            };
//            mmTabPage.Controls.Add(mmFlow);

//            var msTabPage = new TabPage(mTypeName)
//            {
//                Name = mTypeName,
//                Font = CommonStyles.Font,
//            };
//            var msFlow = new UIFlowLayoutPanel
//            {
//                Dock = DockStyle.Fill,
//                AutoScroll = true,
//            };
//            msTabPage.Controls.Add(msFlow);

//            var machineList = mTypesDicts[mTypeName];
//            List<UICheckBox> cbs = new List<UICheckBox>();
//            List<UIRadioButton> rbs = new List<UIRadioButton>();
//            foreach (var machine in machineList)
//            {
//                var cb = new UICheckBox
//                {
//                    Text = machine.Name,
//                    Name = machine.Name,
//                    Checked = false,
//                    AutoSize = false,
//                    Width = 130,
//                    Font = CommonStyles.Font,
//                    Style = UIStyle.Inherited,
//                    CheckBoxColor = CommonStyles.BackColor,
//                    Tag = new SelectorInfo()
//                    {
//                        Id = machine.Id,
//                        Category = mCategoryName,
//                        Type = mTypeName,
//                        Name = machine.Name,
//                    }
//                };
//                cbs.Add(cb);

//                var rb = new UIRadioButton
//                {
//                    GroupIndex = 1,
//                    Text = machine.Name,
//                    Name = machine.Name,
//                    Checked = false,
//                    AutoSize = false,
//                    Width = 130,
//                    Font = CommonStyles.Font,
//                    Style = UIStyle.Inherited,
//                    RadioButtonColor = CommonStyles.BackColor,
//                    Tag = new SelectorInfo()
//                    {
//                        Id = machine.Id,
//                        Category = mCategoryName,
//                        Type = mTypeName,
//                        Name = machine.Name,
//                    }
//                };
//                rbs.Add(rb);
//            }
//            mmFlow.Controls.AddRange(cbs.ToArray());
//            mmTabPages.Add(mmTabPage);
//            msFlow.Controls.AddRange(rbs.ToArray());
//            msTabPages.Add(msTabPage);
//        }
//        _coreData.MachinesMultiTabPageCache[mCategoryName] = mmTabPages;
//        _coreData.MachinesSingleTabPageCache.AddOrUpdate(mCategoryName, msTabPages);
//    }
//}



///// <inheritdoc/>
//public async Task CreateModelTabPage()
//{
//    _coreData.ModelTabPageCache = new ConcurrentDictionary<string, List<TabPage>>();
//    foreach (var model in _coreData.Models)
//    {
//        //var wss = _coreData.Models
//        //    .Where(w => w.Id == model.Id)
//        //    .ToList();
//        if (_coreData.Models.Count > 0)
//        {
//            string moCategoryName = model.ModelName;
//            string moTypeName = PropertyString.Title.Model;
//            List<TabPage> moTabPages = new List<TabPage>();
//            var moTabPage = new TabPage(moTypeName)
//            {
//                Name = moTypeName,
//                Font = CommonStyles.Font,
//            };
//            var moFlow = new UIFlowLayoutPanel()
//            {
//                Dock = DockStyle.Fill,
//                AutoScroll = true,
//            };
//            moTabPage.Controls.Add(moFlow);

//            List<UIRadioButton> rbs = new List<UIRadioButton>();
//            foreach (var ml in _coreData.Models)
//            {
//                var rb = new UIRadioButton
//                {
//                    GroupIndex = 1,
//                    Text = ml.ModelName,
//                    Name = ml.ModelName,
//                    Checked = false,
//                    AutoSize = false,
//                    Width = 150,
//                    Font = CommonStyles.Font,
//                    Style = UIStyle.Inherited,
//                    RadioButtonColor = CommonStyles.BackColor,
//                    Tag = new SelectorInfo()
//                    {
//                        Id = ml.Id,
//                        Category = moCategoryName,
//                        Type = moTypeName,
//                        Name = ml.ModelName,
//                    }
//                };
//                rbs.Add(rb);
//            }
//            moFlow.Controls.AddRange(rbs.ToArray());
//            moTabPages.Add(moTabPage);
//            _coreData.ModelTabPageCache.Add(moCategoryName, moTabPages);
//        }
//    }
//}



///// <inheritdoc/>
//public void CreateModelWsTabPage()
//{
//    _coreData.ModelWsTabPageCache = new Dictionary<string, List<TabPage>>();
//    foreach (var model in _coreData.Models)
//    {
//        var wss = _coreData.Workstations
//            .Where(w => w.ModelId == model.Id)
//            .ToList();
//        if (wss.Count > 0)
//        {
//            string moCategoryName = model.ModelName;
//            string moTypeName = PropertyString.Title.Workstation;
//            List<TabPage> moTabPages = new List<TabPage>();
//            var moTabPage = new TabPage(moTypeName)
//            {
//                Name = moTypeName,
//                Font = CommonStyles.Font,
//            };
//            var moFlow = new UIFlowLayoutPanel
//            {
//                Dock = DockStyle.Fill,
//                AutoScroll = true,
//            };
//            moTabPage.Controls.Add(moFlow);

//            List<UIRadioButton> rbs = new List<UIRadioButton>();
//            foreach (var ws in wss)
//            {
//                var rb = new UIRadioButton
//                {
//                    Text = ws.WorkstationName,
//                    Name = ws.WorkstationName,
//                    Checked = false,
//                    AutoSize = false,
//                    Width = 150,
//                    Font = CommonStyles.Font,
//                    Style = UIStyle.Inherited,
//                    RadioButtonColor = CommonStyles.BackColor,
//                    Tag = new SelectorInfo()
//                    {
//                        Id = ws.Id,
//                        Category = moCategoryName,
//                        Type = moTypeName,
//                        Name = ws.WorkstationName,
//                    }
//                };
//                rbs.Add(rb);
//            }
//            moFlow.Controls.AddRange(rbs.ToArray());
//            moTabPages.Add(moTabPage);
//            _coreData.ModelWsTabPageCache.Add(moCategoryName, moTabPages);
//        }
//    }
//}