using System.Collections.Generic;
using System.Linq;

namespace Calin.Infrastructure.Coordination
{
    /// <summary>
    /// Task Handler �ѪR������@�C
    /// �ϥΤw���U�� Handler ���X�ӸѪR TaskKey�C
    /// </summary>
    public class TaskHandlerResolver : ITaskHandlerResolver
    {
        private readonly Dictionary<TaskKey, ITaskHandler> _handlers;

        /// <summary>
        /// ��l�� Task Handler �ѪR���C
        /// </summary>
        /// <param name="handlers">�w���U�� Handler ���X�C</param>
        public TaskHandlerResolver(IEnumerable<ITaskHandler> handlers)
        {
            _handlers = new Dictionary<TaskKey, ITaskHandler>();

            if (handlers != null)
            {
                foreach (var handler in handlers)
                {
                    if (handler != null && !_handlers.ContainsKey(handler.TaskKey))
                    {
                        _handlers[handler.TaskKey] = handler;
                    }
                }
            }
        }

        /// <inheritdoc/>
        public ITaskHandler Resolve(TaskKey taskKey)
        {
            _handlers.TryGetValue(taskKey, out var handler);
            return handler;
        }

        /// <inheritdoc/>
        public IEnumerable<TaskKey> GetRegisteredTaskKeys()
        {
            return _handlers.Keys.ToList();
        }
    }
}
