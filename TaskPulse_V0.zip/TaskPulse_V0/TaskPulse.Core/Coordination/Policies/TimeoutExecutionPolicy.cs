using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Calin.Infrastructure.Coordination.Policies
{
    /// <summary>
    /// �a�O�ɪ����浦���C
    /// ���C�� Task �]�w����O�ɭ���C
    /// </summary>
    public class TimeoutExecutionPolicy : ExecutionPolicyBase
    {
        private readonly TimeSpan _timeout;

        /// <inheritdoc/>
        public override string PolicyName => "Timeout";

        /// <summary>
        /// ��l�ƹO�ɰ��浦���C
        /// </summary>
        /// <param name="timeout">�C�� Task ������O�ɮɶ��C</param>
        public TimeoutExecutionPolicy(TimeSpan timeout)
        {
            _timeout = timeout;
        }

        /// <inheritdoc/>
        public override async Task ExecuteAsync(
            CoordinationSession session,
            IEnumerable<TaskKey> taskKeys,
            Func<TaskKey, ITaskHandler> handlerResolver,
            CancellationToken cancellationToken = default)
        {
            foreach (var taskKey in taskKeys)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var handler = handlerResolver(taskKey);
                if (handler == null)
                {
                    session.MarkTaskFailed(taskKey,
                        new InvalidOperationException($"No handler registered for task '{taskKey}'."));
                    continue;
                }

                await ExecuteWithTimeoutAsync(session, taskKey, handler, cancellationToken);
            }
        }

        private async Task ExecuteWithTimeoutAsync(
            CoordinationSession session,
            TaskKey taskKey,
            ITaskHandler handler,
            CancellationToken cancellationToken)
        {
            using (var timeoutCts = new CancellationTokenSource())
            using (var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, timeoutCts.Token))
            {
                var context = new TaskExecutionContext(taskKey, session, linkedCts.Token);

                try
                {
                    var executionTask = handler.ExecuteAsync(context);
                    var timeoutTask = Task.Delay(_timeout, linkedCts.Token);

                    var completedTask = await Task.WhenAny(executionTask, timeoutTask);

                    if (completedTask == timeoutTask)
                    {
                        timeoutCts.Cancel();
                        session.MarkTaskFailed(taskKey,
                            new TimeoutException($"Task '{taskKey}' execution timed out after {_timeout}."));
                        return;
                    }

                    // ���ݰ�����ȧ����]�i��ߥX�ҥ~�^
                    await executionTask;
                    session.MarkTaskCompleted(taskKey);
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    throw;
                }
                catch (OperationCanceledException)
                {
                    // �O�ɨ���
                    session.MarkTaskFailed(taskKey,
                        new TimeoutException($"Task '{taskKey}' execution timed out after {_timeout}."));
                }
                catch (Exception ex)
                {
                    session.MarkTaskFailed(taskKey, ex);
                }
            }
        }
    }
}
