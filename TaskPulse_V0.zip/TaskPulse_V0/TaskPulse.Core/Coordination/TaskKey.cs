using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Calin.Infrastructure.Coordination
{
    /// <summary>
    /// �w�q��դu�@�椸���ߤ@���ѡC
    /// TaskKey �Ω��ѧO�ج[�����̤p������C
    /// </summary>
    public readonly struct TaskKey : IEquatable<TaskKey>
    {
        /// <summary>
        /// ���o���Ȫ��ߤ@���ѭȡC
        /// </summary>
        public string Value { get; }

        /// <summary>
        /// ��l�� TaskKey�C
        /// </summary>
        /// <param name="value">���Ȫ��ߤ@���ѭȡC</param>
        public TaskKey(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentNullException(nameof(value));

            Value = value;
        }

        /// <inheritdoc/>
        public bool Equals(TaskKey other) => string.Equals(Value, other.Value, StringComparison.Ordinal);

        /// <inheritdoc/>
        public override bool Equals(object obj) => obj is TaskKey other && Equals(other);

        /// <inheritdoc/>
        public override int GetHashCode() => Value?.GetHashCode() ?? 0;

        /// <inheritdoc/>
        public override string ToString() => Value ?? string.Empty;

        /// <summary>
        /// �P�_��� TaskKey �O�_�۵��C
        /// </summary>
        public static bool operator ==(TaskKey left, TaskKey right) => left.Equals(right);

        /// <summary>
        /// �P�_��� TaskKey �O�_���۵��C
        /// </summary>
        public static bool operator !=(TaskKey left, TaskKey right) => !left.Equals(right);

        /// <summary>
        /// �q�r�������ഫ�� TaskKey�C
        /// </summary>
        public static implicit operator TaskKey(string value) => new TaskKey(value);

        /// <summary>
        /// �q TaskKey �����ഫ���r��C
        /// </summary>
        public static implicit operator string(TaskKey key) => key.Value;
    }
}
