﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Contracts
{
    public interface IUserGroupService
    {
        Task<UserGroup> CreateAsync(UserGroup group, string currentUserId);
        Task<UserGroup> UpdateAsync(UserGroup group, string currentUserId);
        Task DeleteAsync(int groupId, string currentUserId);
        Task<UserGroup> GetByIdAsync(int groupId);
        Task<List<UserGroup>> GetAllAsync();
        Task AssignUsersAsync(int groupId, List<int> userIds, string currentUserId);
        Task AssignPermissionsAsync(int groupId, List<int> permissionIds, string currentUserId);
        IEnumerable<Employee> GetEmployeesFromMachineUserGroups(Machine machine);
    }
}
