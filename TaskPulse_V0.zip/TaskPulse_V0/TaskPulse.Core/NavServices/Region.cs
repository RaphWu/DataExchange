﻿using System;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavServices
{
    public class Region : IRegion
    {
        private object _currentView;

        /// <inheritdoc/>
        public string Name { get; }

        /// <inheritdoc/>
        public Control HostControl { get; }

        public Region(string name, Control host)
        {
            Name = name;
            HostControl = host;
        }

        /// <inheritdoc/>
        public void ShowView(object view)
        {
            if (view is Control ctrl)
            {
                HostControl.Controls.Clear();
                ctrl.Dock = DockStyle.Fill;
                HostControl.Controls.Add(ctrl);
            }
            else
            {
                throw new ArgumentException("View must be a Control");
            }

            _currentView = view;
        }

        /// <inheritdoc/>
        public object GetCurrentView()
        {
            // 優先以實際承載在 HostControl 上的 Control 為準，避免狀態不同步。
            // 有些情境(例如外部手動 Clear/替換 Controls、handle 重建等)可能讓 _currentView 與 UI 不一致。
            if (HostControl != null && HostControl.Controls.Count > 0)
                return HostControl.Controls[0];

            return _currentView;
        }

        /// <inheritdoc/>
        public void Clear()
        {
            HostControl.Controls.Clear();
            _currentView = null;
        }
    }
}
