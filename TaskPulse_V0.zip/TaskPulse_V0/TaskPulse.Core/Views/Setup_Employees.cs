﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.ADGV;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Employees : UserControl, INavigationAware
    {
        #region fields

        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly IEntityCacheManager _cacheManager;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        private List<EmployeeViewModel> _vmEmps = null;
        private DataTable _dt;
        private DataGridViewComboBoxColumn dgvComboBox;
        private BindingSource _bs = new BindingSource();

        private EmployeeViewModel _thisEmployee = null;
        private string _thisEmployeeId = "";

        #endregion fields

        #region INavigationAware

        public async void OnNavigatedTo()
        {
            await UpdateDataAsync();

            WeakReferenceMessenger.Default.Register<NotifyEmployeeDataUpdated>(this, async (recipient, message) =>
            {
                await UpdateDataAsync();
            });
        }

        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();

            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        #endregion INavigationAware

        public Setup_Employees(
            IRegionManager regionManager,
            INavigationService navigationService,
            IEntityCacheManager cacheManager,
            CoreContext coreContext,
            CoreData coreData,
            MultiSelector multiSelector)
        {
            InitializeComponent();

            _region = regionManager;
            _nav = navigationService;
            _cacheManager = cacheManager;
            _context = coreContext;
            _coreData = coreData;
            _mSel = multiSelector;

            //_region.RegisterRegion(nameof(TP_Employees), TP_Employees);
            _region.RegisterRegion(nameof(panelPermission), panelPermission);

            // adgv
            _dt = new DataTable();
            _dt.Columns.Add(PropertyText.Name.EmployeeId, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Department, typeof(string));
            _dt.Columns.Add(PropertyText.Name.JobTitle, typeof(string));
            _dt.Columns.Add(PropertyText.Name.EmployeeName, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Email, typeof(string));
            _dt.Columns.Add(PropertyText.Name.IsEngineer, typeof(bool));
            _dt.Columns.Add(PropertyText.Name.EmployeeStatus, typeof(bool));
            _dt.Columns.Add(PropertyText.Name.StatusChangeAt, typeof(DateTime));

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.EmployeeId,
                DataPropertyName = nameof(EmployeeViewModel.EmployeeId),
                HeaderText = PropertyText.Title.EmployeeId,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyText.Name.EmployeeId], true);

            dgvComboBox = new DataGridViewComboBoxColumn()
            {
                DataPropertyName = nameof(EmployeeViewModel.DepartmentId),
                HeaderText = PropertyText.Title.Department,
                ValueType = typeof(string),
            };
            //dgvComboBox.Items.Add("");
            //dgvComboBox.Items.AddRange(_context.Departments.Select(d => d.DepartmentName).ToList());
            dgvComboBox.DataSource = _context.Departments
                .OrderBy(d => d.OrderNo)
                .Select(d => new ListViewModel() { Id = d.Id, Name = d.DepartmentName })
                .ToList();
            dgvComboBox.DisplayMember = "Name";
            dgvComboBox.ValueMember = "Id";
            dgvComboBox.DisplayStyle = DataGridViewComboBoxDisplayStyle.Nothing;
            dgvComboBox.DisplayStyleForCurrentCellOnly = true;
            adgv.Columns.Add(dgvComboBox);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.JobTitleName,
                DataPropertyName = PropertyText.Name.JobTitleName,
                HeaderText = PropertyText.Title.JobTitle,
                ValueType = typeof(string),
            });
            adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyText.Name.JobTitleName], true);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.EmployeeName,
                DataPropertyName = PropertyText.Name.EmployeeName,
                HeaderText = PropertyText.Title.EmployeeName,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });
            adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyText.Name.EmployeeName], true);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.Email,
                DataPropertyName = PropertyText.Name.Email,
                HeaderText = PropertyText.Title.Email,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });
            adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyText.Name.Email], true);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.CarbonCopyString,
                DataPropertyName = PropertyText.Name.CarbonCopyString,
                HeaderText = PropertyText.Title.CarbonCopies,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
            });
            adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyText.Name.CarbonCopyString], false);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.IsEngineerString,
                DataPropertyName = PropertyText.Name.IsEngineerString,
                HeaderText = PropertyText.Title.IsEngineer,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyText.Name.IsEngineerString], true);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.EmployeeStatusName,
                DataPropertyName = PropertyText.Name.EmployeeStatusName,
                HeaderText = PropertyText.Title.EmployeeStatus,
                ValueType = typeof(string),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyText.Name.EmployeeStatusName], true);

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = PropertyText.Name.StatusChangeAtString,
                DataPropertyName = PropertyText.Name.StatusChangeAtString,
                HeaderText = PropertyText.Title.StatusChangeAt,
                ValueType = typeof(DateTime),
                //AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    Alignment = DataGridViewContentAlignment.MiddleCenter,
                },
            });
            adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyText.Name.StatusChangeAtString], true);

            adgvSearchToolBar.SetColumns(adgv.Columns);
            CommonStyles.SetAdvancedDataGridView(adgv, true);

            CommonStyles.SetButton(btnSave);
            CommonStyles.SetListBox(Status);
            CommonStyles.SetCheckBox(IsEngineer);
            CommonStyles.SetButton(CarbonCopies);
        }

        private async void Setup_Employees_Load(object sender, EventArgs e)
        {
            await UpdateDataAsync();

            // Detail
            label_EmployeeId.Text = PropertyText.Title.EmployeeId;
            EmployeeId.DataBindings.Clear();
            EmployeeId.DataBindings.Add("Text", _bs, PropertyText.Name.EmployeeId);

            label_Department.Text = PropertyText.Title.Department;
            var dm = _context.Departments
                .OrderBy(d => d.OrderNo)
                .Select(d => new ListViewModel()
                {
                    Id = d.Id,
                    Name = d.DepartmentName,
                }).ToList();
            dm.Insert(0, new ListViewModel() { Id = 0, Name = "-- 請選擇 --" });
            Department.DataSource = dm;
            Department.DisplayMember = "Name";
            Department.ValueMember = "Id";
            Department.DataBindings.Clear();
            Department.DataBindings.Add("SelectedValue", _bs, PropertyText.Name.DepartmentId);

            label_JobTitle.Text = PropertyText.Title.JobTitle;
            var jt = _context.JobTitles
                .OrderBy(j => j.OrderNo)
                .Select(j => new ListViewModel()
                {
                    Id = j.Id,
                    Name = j.JobTitleName,
                }).ToList();
            jt.Insert(0, new ListViewModel() { Id = 0, Name = "-- 請選擇 --" });
            JobTitle.DataSource = jt;
            JobTitle.DisplayMember = "Name";
            JobTitle.ValueMember = "Id";
            JobTitle.DataBindings.Clear();
            JobTitle.DataBindings.Add("SelectedValue", _bs, PropertyText.Name.JobTitleId);

            label_EmployeeName.Text = PropertyText.Title.EmployeeName;
            EmployeeName.DataBindings.Clear();
            EmployeeName.DataBindings.Add("Text", _bs, PropertyText.Name.EmployeeName);

            label_Email.Text = PropertyText.Title.Email;
            Email.DataBindings.Clear();
            Email.DataBindings.Add("Text", _bs, PropertyText.Name.Email);

            label_CarbonCopies.Text = PropertyText.Title.CarbonCopies;
            CarbonCopies.DataBindings.Clear();
            CarbonCopies.DataBindings.Add("Text", _bs, PropertyText.Name.CarbonCopyString);

            IsEngineer.Text = PropertyText.Title.IsEngineer;
            IsEngineer.DataBindings.Clear();
            IsEngineer.DataBindings.Add("Checked", _bs, PropertyText.Name.IsEngineer);

            label_Status.Text = PropertyText.Title.EmployeeStatus;
            var es = _context.EmployeeStatuses
                .OrderBy(em => em.OrderNo)
                .Select(j => new ListViewModel()
                {
                    Id = j.Id,
                    Name = j.StatusName,
                }).ToList();
            es.Insert(0, new ListViewModel() { Id = 0, Name = "-- 請選擇 --" });
            Status.DataSource = es;
            Status.DisplayMember = "Name";
            Status.ValueMember = "Id";
            Status.DataBindings.Clear();
            Status.DataBindings.Add("SelectedValue", _bs, PropertyText.Name.EmployeeStatusId);

            //label_StatusChangeAt.Text = PropertyText.Title.StatusChangeAt;
            StatusChangeAt.DataBindings.Clear();
            StatusChangeAt.DataBindings.Add("Text", _bs, PropertyText.Name.StatusChangeAtString);

            _nav.Navigate<Setup_Permission_Small>(nameof(panelPermission), alive: false);

            //_core.CleanUpControls(TP_Permission.Controls);
            //TP_Permission.Controls.Add(_permission);
            //_ = WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
            //new PermissionSettingInfo()
            //    {
            //        PermissionSource = PermissionSource.Employee,
            //        EmployeeId = "",
            //    }));
        }

        private async Task UpdateDataAsync()
        {
            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "正在更新資料...";
                loadingDialog.Show();

                var query = await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.JobTitle)
                .Include(e => e.Status)
                .AsNoTracking()
                .ToListAsync();
                _vmEmps = query
                    .OrderBy(e => e.Department?.OrderNo ?? int.MaxValue)
                    .ThenBy(e => e.JobTitle?.OrderNo ?? int.MaxValue)
                    .ThenBy(e => e.EmployeeId)
                    .Select(e => new EmployeeViewModel
                    {
                        EmployeeId = e.EmployeeId,
                        EmployeeName = e.EmployeeName,
                        DepartmentId = e.DepartmentId ?? 0,
                        DepartmentName = e.Department?.DepartmentName ?? string.Empty,
                        JobTitleId = e.JobTitleId ?? 0,
                        JobTitleName = e.JobTitle?.JobTitleName ?? string.Empty,
                        Email = e.Email,
                        CarbonCopies = e.CarbonCopies,
                        CarbonCopyString = e.CarbonCopyString,
                        CarbonCopyList = e.CarbonCopyList,
                        IsEngineer = e.IsEngineer,
                        IsEngineerString = e.IsEngineerString,
                        Status = e.Status,
                        StatusId = e.StatusId,
                        StatusName = e.StatusName,
                        StatusBoolean = e.StatusBoolean,
                        StatusChangeAt = e.StatusChangeAt ?? DateTime.Now,
                        StatusChangeAtString = e.StatusChangeAtString,
                    }).ToList();

                adgv.AutoGenerateColumns = false;
                _dt = _vmEmps.ToDataTable();
                adgv.DataSource = _dt;
                _bs.DataSource = _dt;
                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_vmEmps.Count()} 筆資料"));

                loadingDialog.Close();
            }
        }

        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewRow row = adgv.CurrentRow;
            if (row != null)
            {
                _thisEmployeeId = row.Cells[PropertyText.Name.EmployeeId].Value.ToString();
                int index = _vmEmps.FindIndex(x => x.EmployeeId == _thisEmployeeId);
                _thisEmployee = _vmEmps[index];
                if (index >= 0)
                    _bs.Position = index;

                _ = WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                    new PermissionSettingInfo()
                    {
                        PermissionSource = PermissionSource.Employee,
                        EmployeeId = _thisEmployeeId,
                    }));
            }
            else
            {
                _thisEmployeeId = "";
                _thisEmployee = null;
            }

            bool canEdit = _thisEmployee?.Status != null && _thisEmployee.Status.StatusName == "在職";
            EmployeeId.Enabled = canEdit;
            Department.Enabled = canEdit;
            JobTitle.Enabled = canEdit;
            EmployeeName.Enabled = canEdit;
            Email.Enabled = canEdit;
            CarbonCopies.Enabled = canEdit;
            IsEngineer.Enabled = canEdit;
            Status.Enabled = canEdit;
            StatusChangeAt.Enabled = canEdit;
            btnSave.Enabled = canEdit;
        }

        private async void btnSave_Click(object sender, EventArgs eventArgs)
        {
            var emp = await _context.Employees.FirstOrDefaultAsync(e => e.EmployeeId == _thisEmployeeId);
            if (emp != null)
            {
                emp.EmployeeId = _thisEmployeeId;
                emp.EmployeeName = EmployeeName.Text;
                emp.DepartmentId = (int)Department.SelectedValue;
                emp.JobTitleId = (int)JobTitle.SelectedValue;
                emp.Email = Email.Text;
                emp.IsEngineer = IsEngineer.Checked;
                emp.StatusId = (int)Status.SelectedValue;
                emp.StatusChangeAtString = string.IsNullOrEmpty(StatusChangeAt.Text) ? null : StatusChangeAt.Text;

                var ccs = CarbonCopies.Text
                    .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim())
                    .ToList();
                emp.CarbonCopies.Clear();
                foreach (var cc in ccs)
                {
                    var e = await _context.Employees.FirstOrDefaultAsync(x => x.EmployeeName == cc);
                    if (e != null)
                        emp.CarbonCopies.Add(e);
                }

                await _context.SaveChangesAsync();
                _cacheManager.RequestEmployeeUpdateDelay();
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已儲存 {emp.EmployeeName} 權限設定。"));
            }
        }

        private void CarbonCopies_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.CarbonCopies}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EmployeeMultiTabPageCache;
            //_mSel.DefaultChecked = CarbonCopies.Text
            //    .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
            //    .Select(s => s.Trim())
            //    .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                List<string> emps = new List<string>();
                foreach (var emp in _mSel.ResultList)
                    emps.Add(emp.Name);
                CarbonCopies.Text = string.Join("; ", emps);
            }
        }

        private void adgvSearchToolBar_Search(object sender, AdvancedDataGridViewSearchToolBarSearchEventArgs e)
        {
            bool restartsearch = true;
            int startColumn = 0;
            int startRow = 0;
            if (!e.FromBegin)
            {
                bool endcol = adgv.CurrentCell.ColumnIndex + 1 >= adgv.ColumnCount;
                bool endrow = adgv.CurrentCell.RowIndex + 1 >= adgv.RowCount;

                if (endcol && endrow)
                {
                    startColumn = adgv.CurrentCell.ColumnIndex;
                    startRow = adgv.CurrentCell.RowIndex;
                }
                else
                {
                    startColumn = endcol ? 0 : adgv.CurrentCell.ColumnIndex + 1;
                    startRow = adgv.CurrentCell.RowIndex + (endcol ? 1 : 0);
                }
            }
            DataGridViewCell c = adgv.FindCell(
                e.ValueToSearch,
                e.ColumnToSearch != null ? e.ColumnToSearch.Name : null,
                startRow,
                startColumn,
                e.WholeWord,
                e.CaseSensitive);
            if (c == null && restartsearch)
                c = adgv.FindCell(
                e.ValueToSearch,
                e.ColumnToSearch != null ? e.ColumnToSearch.Name : null,
                0,
                0,
                e.WholeWord,
                e.CaseSensitive);
            if (c != null)
                adgv.CurrentCell = c;
        }
    }
}
