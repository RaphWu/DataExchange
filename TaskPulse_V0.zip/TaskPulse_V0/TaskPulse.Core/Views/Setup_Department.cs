﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.Framework.Navigation;
using Calin.Infrastructure.Coordination;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.Services.Coordination;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Department : UserControl, INavigationAware
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ILifetimeScope _scope;
        private readonly IRegionManager _region;
        private readonly INavigationService _navigation;
        private readonly CoreContext _context;

        private readonly DbSet<Department> _departments;
        private readonly DbSet<JobTitle> _jobTitles;
        private readonly DbSet<EmployeeStatus> _statuses;

        private List<ListViewModel> _vmDepartments = null;
        private ListViewModel _vmDep = null;
        private List<ListViewModel> _vmJobTitles = null;
        private ListViewModel _vmJobTitle = null;
        private List<ListViewModel> _vmStatuses = null;
        private ListViewModel _vmStatus = null;

        private bool _dataHasChanged = false;

        #endregion fields

        #region INavigationAware

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            _dataHasChanged = false;
            _ = UpdateDataAsync();

            WeakReferenceMessenger.Default.Register<NotifyEmployeeDataUpdated>(this, async (recipient, message) =>
            {
                await UpdateDataAsync();
            });
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        public bool OnNavigatingFrom(INavigationParameters parameters)
        {
            if (_dataHasChanged)
            {
                Task.Run(async () =>
                {
                    using (var scope = _scope.BeginLifetimeScope())
                    {
                        var coordinator = scope.Resolve<ICoordinator>();
                        var request = new CacheUpdateRequest(CoreTaskKeys.EmployeeUpdate);
                        var result = await coordinator.CoordinateAsync(request);
                        //if (result.IsSuccess) { }
                    }
                }).Wait();
            }

            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            WeakReferenceMessenger.Default.UnregisterAll(this);
            return true;
        }

        #endregion INavigationAware

        public Setup_Department(
            Serilog.ILogger logger,
            ILifetimeScope lifetimeScope,
            IRegionManager regionManager,
            INavigationService navigationService,
            CoreContext coreContext)
        {
            InitializeComponent();

            _logger = logger;
            _scope = lifetimeScope;
            _region = regionManager;
            _navigation = navigationService;
            _context = coreContext;

            _region.RegisterRegion(nameof(Panel_Permission),
                view =>
                {
                    Panel_Permission.Controls.Clear();
                    if (view is Control control)
                    {
                        control.Dock = DockStyle.Fill;
                        Panel_Permission.Controls.Add(control);
                    }
                }, view =>
                {
                    if (view is Control control)
                    {
                        Panel_Permission.Controls.Remove(control);
                    }
                });
            _navigation.NavigateTo<Setup_Permission_Small>(nameof(Panel_Permission), 0);

            _departments = _context.Departments;
            _jobTitles = _context.JobTitles;
            _statuses = _context.EmployeeStatuses;

            string itemName = PropertyText.Title.Department;
            Label_Department.Text = itemName;
            CommonStyles.SetListBox(lboxDepartments);
            CommonStyles.SetCrudButton(Department_Create, "C", itemName);
            CommonStyles.SetCrudButton(Department_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Department_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Department_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Department_Down, "DOWN", itemName);

            itemName = PropertyText.Title.JobTitle;
            Label_Title.Text = itemName;
            CommonStyles.SetListBox(lboxJobTitles);
            CommonStyles.SetCrudButton(JobTitle_Create, "C", itemName);
            CommonStyles.SetCrudButton(JobTitle_Edit, "E", itemName);
            CommonStyles.SetCrudButton(JobTitle_Delete, "D", itemName);
            CommonStyles.SetCrudButton(JobTitle_Up, "UP", itemName);
            CommonStyles.SetCrudButton(JobTitle_Down, "DOWN", itemName);

            itemName = PropertyText.Title.EmployeeStatus;
            labelStatus.Text = itemName;
            CommonStyles.SetListBox(lboxStatus);
            CommonStyles.SetCrudButton(Status_Create, "C", itemName);
            CommonStyles.SetCrudButton(Status_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Status_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Status_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Status_Down, "DOWN", itemName);
        }

        private async void Setup_Department_Load(object sender, EventArgs e)
        {
            await UpdateDataAsync();
        }

        private async Task UpdateDataAsync()
        {
            await UpdateDepartmentViewAsync();
            await UpdateJobTitleViewAsync();
            await UpdateStatusViewAsync();
        }

        /********************
         * Department
         ********************/
        private async Task UpdateDepartmentViewAsync()
        {
            _vmDepartments = await _departments
                .Select(d => new ListViewModel()
                {
                    Id = d.Id,
                    Name = d.DepartmentName,
                    OrderNo = d.OrderNo,
                })
                .ToListAsync();

            lboxDepartments.DisplayMember = nameof(ListViewModel.Name);
            lboxDepartments.ValueMember = nameof(ListViewModel.Id);
            lboxDepartments.DataSource = _vmDepartments;
        }

        private void lboxDepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmDep = lboxDepartments.SelectedItem as ListViewModel;
            if (_vmDep != null)
            {
                Department_Edit.Enabled = true;
                Department_Delete.Enabled = true;

                if (lboxDepartments.DataSource is List<ListViewModel> vmDeps)
                {
                    var vmOrderNo = vmDeps.FirstOrDefault(w => w.Id == _vmDep.Id).OrderNo;
                    Department_Up.Enabled = vmOrderNo != vmDeps.Min(w => w.OrderNo);
                    Department_Down.Enabled = vmOrderNo != vmDeps.Max(w => w.OrderNo);
                }
                else
                {
                    Department_Up.Enabled = false;
                    Department_Down.Enabled = false;
                }
            }
            else
            {
                Department_Edit.Enabled = false;
                Department_Delete.Enabled = false;
                Department_Up.Enabled = false;
                Department_Down.Enabled = false;
            }

            if (lboxDepartments.SelectedItem is ListViewModel select)
            {
                _ = WeakReferenceMessenger.Default.Send(new PermissionSettingPageMessage(
                    new PermissionSettingInfo()
                    {
                        PermissionSource = PermissionSource.Department,
                        DepartmentId = select.Id,
                    }));
            }
        }

        private async void Department_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.Department}名稱";
            string caption = $"新{PropertyText.Title.Department}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Department}名稱不可為空白！"),
                input => input.Length <= 50 ? (true, "") : (false, $"{PropertyText.Title.Department}名稱必須小於等於 50 個字元！"),
                input => _departments.Any(m => m.DepartmentName == input) ? (false, $"{PropertyText.Title.Department}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newDepName = crud.Result.StringValue;
                        int maxOrderNo = _departments.Max(w => w.OrderNo);

                        _context.Departments.Add(new Department() { DepartmentName = newDepName, OrderNo = maxOrderNo + 1 });
                        await _context.SaveChangesAsync();
                        await UpdateDepartmentViewAsync();
                        _dataHasChanged = true;
                        lboxDepartments.SelectedIndex = _vmDepartments.FindIndex(m => m.Name == newDepName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.Department}: {newDepName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.Department}失敗: {nameof(Setup_Department)} -> {nameof(Department_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Department_Edit_Click(object sender, EventArgs e)
        {
            if (_vmDep != null)
            {
                var thisDep = _vmDep;
                string title = $"請輸入新{PropertyText.Title.Department}名稱";
                string oldCaption = $"原{PropertyText.Title.Department}名稱";
                string newCaption = $"新{PropertyText.Title.Department}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Department}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.Department}名稱必須小於等於 30 個字元！"),
                    input => _departments.Any(m => m.DepartmentName == input) ? (false, $"{PropertyText.Title.Department}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisDep.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newDepName = crud.Result.StringValue;

                            var newDep = _departments.FirstOrDefault(m => m.Id == thisDep.Id);
                            if (newDep != null)
                            {
                                newDep.DepartmentName = newDepName;
                                await _context.SaveChangesAsync();
                                await UpdateDepartmentViewAsync();
                                _dataHasChanged = true;
                                lboxDepartments.SelectedIndex = _vmDepartments.FindIndex(m => m.Id == newDep.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.Condition}: {thisDep.Name}，名稱已變更為: {newDepName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.Department}重新命名失敗: {nameof(Setup_Department)} -> {nameof(Department_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void Department_Delete_Click(object sender, EventArgs e)
        {
            if (_vmDep != null)
            {
                var thisDep = _vmDep;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.Department} {thisDep.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetDep = _departments.FirstOrDefault(m => m.Id == thisDep.Id);
                        if (targetDep != null)
                        {
                            _departments.Remove(targetDep);
                            await _context.SaveChangesAsync();
                            await UpdateDepartmentViewAsync();
                            _dataHasChanged = true;

                            MessageBox.Show($"{PropertyText.Title.Department} {thisDep.Name} 刪除成功",
                                            $"刪除成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.Department}刪除失敗: {nameof(Setup_Department)} -> {nameof(Department_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Department_Up_Click(object sender, EventArgs e)
        {
            if (_vmDep != null)
            {
                var thisDep = _vmDep;
                var smallerVmWs = _vmDepartments.LastOrDefault(w => w.OrderNo < thisDep.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapDepartmentOrderNo(thisDep.Id, smallerVmWs.Id);
                    lboxDepartments.SelectedIndex = _vmDepartments.FindIndex(m => m.Id == thisDep.Id);
                }
            }
        }

        private async void Department_Down_Click(object sender, EventArgs e)
        {
            if (_vmDep != null)
            {
                var thisVm = _vmDep;
                var biggerVm = _vmDepartments.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapDepartmentOrderNo(thisVm.Id, biggerVm.Id);
                    lboxDepartments.SelectedIndex = _vmDepartments.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapDepartmentOrderNo(int id1, int id2)
        {
            try
            {
                var entity1 = _departments.FirstOrDefault(w => w.Id == id1);
                var entity2 = _departments.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateDepartmentViewAsync();
                _dataHasChanged = true;
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_Department)} -> {nameof(SwapDepartmentOrderNo)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /********************
         * JobTitle
         ********************/
        private async Task UpdateJobTitleViewAsync()
        {
            _vmJobTitles = await _jobTitles
                .Select(d => new ListViewModel()
                {
                    Id = d.Id,
                    Name = d.JobTitleName,
                    OrderNo = d.OrderNo,
                })
                .ToListAsync();

            lboxJobTitles.DisplayMember = nameof(ListViewModel.Name);
            lboxJobTitles.ValueMember = nameof(ListViewModel.Id);
            lboxJobTitles.DataSource = _vmJobTitles;
        }

        private void lboxJobTitles_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmJobTitle = lboxJobTitles.SelectedItem as ListViewModel;
            if (_vmJobTitle != null)
            {
                JobTitle_Edit.Enabled = true;
                JobTitle_Delete.Enabled = true;

                if (lboxJobTitles.DataSource is List<ListViewModel> vmJobTitle)
                {
                    var vmOrderNo = vmJobTitle.FirstOrDefault(w => w.Id == _vmJobTitle.Id).OrderNo;
                    JobTitle_Up.Enabled = vmOrderNo != vmJobTitle.Min(w => w.OrderNo);
                    JobTitle_Down.Enabled = vmOrderNo != vmJobTitle.Max(w => w.OrderNo);
                }
                else
                {
                    JobTitle_Up.Enabled = false;
                    JobTitle_Down.Enabled = false;
                }
            }
            else
            {
                JobTitle_Edit.Enabled = false;
                JobTitle_Delete.Enabled = false;
                JobTitle_Up.Enabled = false;
                JobTitle_Down.Enabled = false;
            }
        }

        private async void JobTitle_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.JobTitle}名稱";
            string caption = $"新{PropertyText.Title.JobTitle}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.JobTitle}名稱不可為空白！"),
                input => input.Length <= 12 ? (true, "") : (false, $"{PropertyText.Title.JobTitle}名稱必須小於等於 12 個字元！"),
                input => _jobTitles.Any(m => m.JobTitleName == input) ? (false, $"{PropertyText.Title.JobTitle}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newJobTitleName = crud.Result.StringValue;
                        int maxOrderNo = _jobTitles.Max(w => w.OrderNo);

                        _context.JobTitles.Add(new JobTitle() { JobTitleName = newJobTitleName, OrderNo = maxOrderNo + 1 });
                        await _context.SaveChangesAsync();
                        await UpdateJobTitleViewAsync();
                        _dataHasChanged = true;
                        lboxJobTitles.SelectedIndex = _vmJobTitles.FindIndex(m => m.Name == newJobTitleName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.JobTitle}: {newJobTitleName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.JobTitle}失敗: {nameof(Setup_Department)} -> {nameof(JobTitle_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void JobTitle_Edit_Click(object sender, EventArgs e)
        {
            if (_vmJobTitle != null)
            {
                var thisJobTitle = _vmJobTitle;
                string title = $"請輸入新{PropertyText.Title.JobTitle}名稱";
                string oldCaption = $"原{PropertyText.Title.JobTitle}名稱";
                string newCaption = $"新{PropertyText.Title.JobTitle}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.JobTitle}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.JobTitle}名稱必須小於等於 30 個字元！"),
                    input => _jobTitles.Any(m => m.JobTitleName == input) ? (false, $"{PropertyText.Title.JobTitle}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisJobTitle.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newJobTitleName = crud.Result.StringValue;

                            var newJobTitle = _jobTitles.FirstOrDefault(m => m.Id == thisJobTitle.Id);
                            if (newJobTitle != null)
                            {
                                newJobTitle.JobTitleName = newJobTitleName;
                                await _context.SaveChangesAsync();
                                await UpdateJobTitleViewAsync();
                                _dataHasChanged = true;
                                lboxJobTitles.SelectedIndex = _vmJobTitles.FindIndex(m => m.Id == newJobTitle.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.JobTitle}: {thisJobTitle.Name}，名稱已變更為: {newJobTitleName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.JobTitle}重新命名失敗: {nameof(Setup_Department)} -> {nameof(JobTitle_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void JobTitle_Delete_Click(object sender, EventArgs e)
        {
            if (_vmJobTitle != null)
            {
                var thisJobTitle = _vmJobTitle;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.JobTitle} {thisJobTitle.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetJobTitle = _jobTitles.FirstOrDefault(m => m.Id == thisJobTitle.Id);
                        if (targetJobTitle != null)
                        {
                            _jobTitles.Remove(targetJobTitle);
                            await _context.SaveChangesAsync();
                            await UpdateJobTitleViewAsync();
                            _dataHasChanged = true;

                            MessageBox.Show($"{PropertyText.Title.JobTitle} {thisJobTitle.Name} 刪除成功",
                                            $"刪除成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.JobTitle}刪除失敗: {nameof(Setup_Department)} -> {nameof(JobTitle_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void JobTitle_Up_Click(object sender, EventArgs e)
        {
            if (_vmJobTitle != null)
            {
                var thisDep = _vmJobTitle;
                var smallerVmWs = _vmJobTitles.LastOrDefault(w => w.OrderNo < thisDep.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapJobTitleOrderNo(thisDep.Id, smallerVmWs.Id);
                    lboxJobTitles.SelectedIndex = _vmJobTitles.FindIndex(m => m.Id == thisDep.Id);
                }
            }
        }

        private async void JobTitle_Down_Click(object sender, EventArgs e)
        {
            if (_vmJobTitle != null)
            {
                var thisVm = _vmJobTitle;
                var biggerVm = _vmJobTitles.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapJobTitleOrderNo(thisVm.Id, biggerVm.Id);
                    lboxJobTitles.SelectedIndex = _vmJobTitles.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapJobTitleOrderNo(int id1, int id2)
        {
            try
            {
                var entity1 = _jobTitles.FirstOrDefault(w => w.Id == id1);
                var entity2 = _jobTitles.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateJobTitleViewAsync();
                _dataHasChanged = true;
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_Department)} -> {nameof(SwapJobTitleOrderNo)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /********************
         * Status
         ********************/
        private async Task UpdateStatusViewAsync()
        {
            _vmStatuses = await _statuses
                .Select(d => new ListViewModel()
                {
                    Id = d.Id,
                    Name = d.StatusName,
                    OrderNo = d.OrderNo,
                })
                .ToListAsync();

            lboxStatus.DisplayMember = nameof(ListViewModel.Name);
            lboxStatus.ValueMember = nameof(ListViewModel.Id);
            lboxStatus.DataSource = _vmStatuses;
        }

        private void lboxStatuss_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmStatus = lboxStatus.SelectedItem as ListViewModel;
            // 在職=1, 已離職=2 預設不可變，固定在前兩筆
            if (_vmStatus == null || _vmStatus.Name == "在職" || _vmStatus.Name == "已離職")
            {
                Status_Edit.Enabled = false;
                Status_Delete.Enabled = false;
                Status_Up.Enabled = false;
                Status_Down.Enabled = false;
            }
            else
            {
                Status_Edit.Enabled = true;
                Status_Delete.Enabled = true;

                if (lboxStatus.DataSource is List<ListViewModel> vmStatus)
                {
                    var vmOrderNo = vmStatus.FirstOrDefault(w => w.Id == _vmStatus.Id).OrderNo;
                    Status_Up.Enabled = vmOrderNo > 3;
                    Status_Down.Enabled = vmOrderNo >= 3 && vmOrderNo < vmStatus.Max(w => w.OrderNo);
                }
                else
                {
                    Status_Up.Enabled = false;
                    Status_Down.Enabled = false;
                }
            }
        }

        private async void Status_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.Status}名稱";
            string caption = $"新{PropertyText.Title.Status}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Status}名稱不可為空白！"),
                input => input.Length <= 12 ? (true, "") : (false, $"{PropertyText.Title.Status}名稱必須小於等於 12 個字元！"),
                input => _statuses.Any(m => m.StatusName == input) ? (false, $"{PropertyText.Title.Status}名稱已存在！") : (true, "")
                );

            using (var crud = _scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);
                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newStatusName = crud.Result.StringValue;
                        int maxOrderNo = _statuses.Max(w => w.OrderNo);

                        _context.EmployeeStatuses.Add(new EmployeeStatus() { StatusName = newStatusName, OrderNo = maxOrderNo + 1 });
                        await _context.SaveChangesAsync();
                        await UpdateStatusViewAsync();
                        _dataHasChanged = true;
                        lboxStatus.SelectedIndex = _vmStatuses.FindIndex(m => m.Name == newStatusName);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.Status}: {newStatusName}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增{PropertyText.Title.Status}失敗: {nameof(Setup_Department)} -> {nameof(Status_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Status_Edit_Click(object sender, EventArgs e)
        {
            if (_vmStatus != null)
            {
                var thisStatus = _vmStatus;
                string title = $"請輸入新{PropertyText.Title.Status}名稱";
                string oldCaption = $"原{PropertyText.Title.Status}名稱";
                string newCaption = $"新{PropertyText.Title.Status}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Status}名稱不可為空白！"),
                    input => input.Length <= 30 ? (true, "") : (false, $"{PropertyText.Title.Status}名稱必須小於等於 30 個字元！"),
                    input => _statuses.Any(m => m.StatusName == input) ? (false, $"{PropertyText.Title.Status}名稱已存在！") : (true, "")
                    );

                using (var crud = _scope.Resolve<CRUD>())
                {
                    crud.Edit_1TextBox(new TextBoxInfo()
                    {
                        Value = "",
                        Caption = oldCaption,
                        WaterMark = oldCaption
                    }, new TextBoxInfo()
                    {
                        Value = thisStatus.Name,
                        Caption = newCaption,
                        WaterMark = newCaption
                    }, title, validor);
                    if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                    {
                        try
                        {
                            string newStatusName = crud.Result.StringValue;

                            var newStatus = _statuses.FirstOrDefault(m => m.Id == thisStatus.Id);
                            if (newStatus != null)
                            {
                                newStatus.StatusName = newStatusName;
                                await _context.SaveChangesAsync();
                                await UpdateStatusViewAsync();
                                _dataHasChanged = true;
                                lboxStatus.SelectedIndex = _vmStatuses.FindIndex(m => m.Id == newStatus.Id);

                                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.Status}: {thisStatus.Name}，名稱已變更為: {newStatusName}"));
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"{PropertyText.Title.Status}重新命名失敗: {nameof(Setup_Department)} -> {nameof(Status_Edit_Click)}()";
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Fatal(ex, errMsg);
                            }
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private async void Status_Delete_Click(object sender, EventArgs e)
        {
            if (_vmStatus != null)
            {
                var thisStatus = _vmStatus;
                if (UIMessageBox.ShowAsk2($"確定要刪除 {PropertyText.Title.Status} {thisStatus.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetStatus = _statuses.FirstOrDefault(m => m.Id == thisStatus.Id);
                        if (targetStatus != null)
                        {
                            _statuses.Remove(targetStatus);
                            await _context.SaveChangesAsync();
                            await UpdateStatusViewAsync();
                            _dataHasChanged = true;

                            MessageBox.Show($"{PropertyText.Title.Status} {thisStatus.Name} 刪除成功",
                                            $"刪除成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.Status}刪除失敗: {nameof(Setup_Department)} -> {nameof(Status_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Status_Up_Click(object sender, EventArgs e)
        {
            if (_vmStatus != null)
            {
                var thisDep = _vmStatus;
                var smallerVmWs = _vmStatuses.LastOrDefault(w => w.OrderNo < thisDep.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapStatusOrderNo(thisDep.Id, smallerVmWs.Id);
                    lboxStatus.SelectedIndex = _vmStatuses.FindIndex(m => m.Id == thisDep.Id);
                }
            }
        }

        private async void Status_Down_Click(object sender, EventArgs e)
        {
            if (_vmStatus != null)
            {
                var thisVm = _vmStatus;
                var biggerVm = _vmStatuses.FirstOrDefault(w => w.OrderNo > thisVm.OrderNo);
                if (biggerVm != null)
                {
                    await SwapStatusOrderNo(thisVm.Id, biggerVm.Id);
                    lboxStatus.SelectedIndex = _vmStatuses.FindIndex(m => m.Id == thisVm.Id);
                }
            }
        }

        private async Task SwapStatusOrderNo(int id1, int id2)
        {
            try
            {
                var entity1 = _statuses.FirstOrDefault(w => w.Id == id1);
                var entity2 = _statuses.FirstOrDefault(w => w.Id == id2);

                (entity2.OrderNo, entity1.OrderNo) = (entity1.OrderNo, entity2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateStatusViewAsync();
                _dataHasChanged = true;
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_Department)} -> {nameof(SwapStatusOrderNo)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
