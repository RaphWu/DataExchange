﻿using System.Collections.Generic;
using Calin.Infrastructure.Coordination;

namespace Calin.TaskPulse.MaintiFlow.Service.Coordination
{
    public class CacheUpdateMappingStrategy : TaskMappingStrategyBase<CacheUpdateRequest>
    {
        protected override IEnumerable<TaskKey> GetRequiredTasks(CacheUpdateRequest request)
        {
            return request.RequiredTaskKeys;
        }
    }
}
