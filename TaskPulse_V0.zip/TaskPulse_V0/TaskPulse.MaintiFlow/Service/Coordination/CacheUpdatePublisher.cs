﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.Infrastructure.Coordination;
using Calin.TaskPulse.Core.Coordination;

namespace Calin.TaskPulse.MaintiFlow.Service.Coordination
{
    public class CacheUpdatePublisher : IResultPublisher
    {
        private readonly Dictionary<TaskKey, ISelectiveResultPublisher> _publisherMap;

        public CacheUpdatePublisher(WorkOrderCacheUpdatePublisher workOrderCacheUpdatePublisher)
        {
            _publisherMap = new Dictionary<TaskKey, ISelectiveResultPublisher>
            {
                { MaintiFlowTaskKeys.WorkOrderUpdate, workOrderCacheUpdatePublisher }
            };
        }

        public async Task PublishAsync(ICoordinationResult result)
        {
            var session = result.Session;

            // 只對成功完成的任務進行發布
            foreach (var completedTask in session.CompletedTasks)
            {
                if (_publisherMap.TryGetValue(completedTask, out var publisher))
                {
                    await publisher.PublishAsync(completedTask, result);
                }
            }

            // 可選：對失敗的任務進行錯誤日誌記錄
            foreach (var failedTask in session.FailedTasks)
            {
                // 記錄失敗資訊
                // Console.WriteLine($"Task {failedTask.Key} failed: {failedTask.Value.Message}");
            }
        }
    }
}
