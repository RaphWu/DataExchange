﻿using System;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.MaintiFlow.Contract;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class ManitiFlowMain : UserControl, INavigationAware
    {
        private readonly Serilog.ILogger _logger;
        private readonly IEntityCacheManager _cacheManager;
        private readonly IPermissionService _permission;
        private readonly CurrentUserContext _user;
        private readonly IMaintiFlow _maintiFlow;

        #region INavigationAware

        public void OnNavigatedTo()
        {
        }

        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        #endregion INavigationAware

        public ManitiFlowMain(
            Serilog.ILogger logger,
            IEntityCacheManager cacheManager,
            IPermissionService permissionService,
            CurrentUserContext currentUserContext,
            IMaintiFlow maintiFlow)
        {
            InitializeComponent();

            _logger = logger;
            _cacheManager = cacheManager;
            _permission = permissionService;
            _user = currentUserContext;
            _maintiFlow = maintiFlow;

            Button_CreateFlow.Text = PageCode.CreateFlow.GetDescription();
            Button_AcceptFlow.Text = PageCode.AcceptFlow.GetDescription();
            Button_MaintiWork.Text = PageCode.MaintiWork.GetDescription();
            Button_FlowConfirmed.Text = PageCode.FlowConfirmed.GetDescription();
            Button_CancelFlow.Text = PageCode.CancelFlow.GetDescription();

            UserChanged();

            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (recipient, message) =>
            {
                UserChanged();
            });
        }

        private void UserChanged()
        {
            Button_CreateFlow.Enabled = _permission.HasControlAccess(
                  PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_CREATE_FLOW);
            Button_AcceptFlow.Enabled = _permission.HasControlAccess(
                PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_ACCEPT_FLOW) || _user.IsEngineer;
            Button_MaintiWork.Enabled = _permission.HasControlAccess(
                PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_MAINTI_FLOW) || _user.IsEngineer;
            Button_FlowConfirmed.Enabled = _permission.HasControlAccess(
                PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_FLOW_CONFIRM);
            Button_CancelFlow.Enabled = _permission.HasControlAccess(
                PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_CANCEL_FLOW);
        }

        private void Button_CreateFlow_Click(object sender, EventArgs e)
        {
            _maintiFlow.CreateNewFlow();
        }

        private async void Button_CancelFlow_Click(object sender, EventArgs e)
        {
            await _maintiFlow.CancelFlow();
        }

        private async void Button_AcceptFlow_Click(object sender, EventArgs e)
        {
            await _maintiFlow.AcceptFlow();
        }

        private void Button_MaintiWork_Click(object sender, EventArgs e)
        {
            _maintiFlow.MaintiWork();
        }

        private async void Button_FlowConfirmed_Click(object sender, EventArgs e)
        {
            await _maintiFlow.FlowConfirmed();
        }
    }
}
