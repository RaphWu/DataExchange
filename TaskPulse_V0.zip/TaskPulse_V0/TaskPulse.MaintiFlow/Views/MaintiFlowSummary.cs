﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.ADGV;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Extensions;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.WinForms;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using MiniExcelLibs;
using Newtonsoft.Json.Linq;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UserControl, INavigationAware
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly IEntityCacheManager _cacheManager;
        private readonly ICore _core;
        private readonly IPermissionService _permission;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;
        private readonly MultiSelector _mSel;

        private int _thisTaskOrderId;
        private int _toIndex = -1;
        private TaskOrderViewModel _tovm;
        private List<TaskOrderViewModel> _tovms = new List<TaskOrderViewModel>();
        private DataTable _dt;
        private BindingSource _bs = new BindingSource();
        private bool _suppressCurrentItemChanged = false;

        // ResultList Buffers
        private ClassifyInfo _defaultCreator = new ClassifyInfo();
        private ClassifyInfo _defaultMachineCode = new ClassifyInfo();
        private ClassifyInfo _defaultModelWs = new ClassifyInfo();
        private List<ClassifyInfo> _defaultEngineers = new List<ClassifyInfo>();
        private ClassifyInfo _defaultFeedbackEmployee = new ClassifyInfo();

        #endregion fields

        #region INavigationAware

        public void OnNavigatedTo()
        {
            EditModeSwitch.Active = false;
            SwitchEditMode(false);
        }

        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();

            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
        }

        #endregion INavigationAware

        public bool IsEnabled
        {
            get { return _isEnabled; }
            set { _isEnabled = value; }
        }
        private bool _isEnabled;

        public MaintiFlowSummary(
            Serilog.ILogger logger,
            IEntityCacheManager cacheManager,
            ICore core,
            IPermissionService permissionService,
            CoreContext coreContext,
            CoreData coreData,
            MaintiFlowData maintiFlowData,
            MultiSelector multiSelector)
        {
            InitializeComponent();

            _logger = logger;
            _cacheManager = cacheManager;
            _core = core;
            _permission = permissionService;
            _context = coreContext;
            _coreData = coreData;
            _flowData = maintiFlowData;
            _mSel = multiSelector;

            _dt = new DataTable();
            _dt.Columns.Add(PropertyText.Name.WorkOrderNo, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Creator, typeof(string));
            _dt.Columns.Add(PropertyText.Name.CreationDateTime, typeof(DateTime));
            _dt.Columns.Add(PropertyText.Name.ModelStatus, typeof(string));
            _dt.Columns.Add(PropertyText.Name.MaintenanceUnit, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Engineers, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Machine, typeof(string));
            _dt.Columns.Add(PropertyText.Name.ModelName, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Workstation, typeof(string));
            _dt.Columns.Add(PropertyText.Name.RepairDuration, typeof(TimeSpan));
            _dt.Columns.Add(PropertyText.Name.OutageDuration, typeof(TimeSpan));

            SwitchEditMode(false);
            CommonStyles.SetButton(btnSave);
            CommonStyles.SetButton(btnRefresh);
            CommonStyles.SetButton(btnExportingExcel);
            EditModeSwitch.ActiveColor = CommonStyles.BackColor;
            EditModeSwitch.InActiveColor = Color.DarkRed;
            Creator.ButtonFillColor = CommonStyles.BackColor;
            Engineers.ButtonFillColor = CommonStyles.BackColor;
            MachineCode.ButtonFillColor = CommonStyles.BackColor;
            ModelWs.ButtonFillColor = CommonStyles.BackColor;
            FeedbackEmployee.ButtonFillColor = CommonStyles.BackColor;

            _defaultCreator = new ClassifyInfo();
            _defaultMachineCode = new ClassifyInfo();
            _defaultModelWs = new ClassifyInfo();
            _defaultFeedbackEmployee = new ClassifyInfo();
            _defaultEngineers = new List<ClassifyInfo>();

            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (recipient, message) =>
            {
                UserChanged();
            });

            WeakReferenceMessenger.Default.Register<NotifyTaskOrderDataUpdated>(this, (recipient, message) =>
            {
                LoadData();
            });

            //_bs.CurrentItemChanged += BindingSource_CurrentItemChanged;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                _tovms = null;
                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        private void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            UserChanged();
            LoadData();
            //UpdateDataToUI(result.List, result.Table);

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "資料載入中，請稍候...";
                loadingDialog.Show();

                //adgv.Columns.Add(new DataGridViewCheckBoxColumn
                //{
                //    DataPropertyName = "Edited",
                //    HeaderText = "修改",
                //    ValueType = typeof(bool),
                //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                //    DefaultCellStyle = new DataGridViewCellStyle()
                //    {
                //        Alignment = DataGridViewContentAlignment.MiddleCenter,
                //    },
                //});

                //adgv.Columns.Add(new DataGridViewTextBoxColumn
                //{
                //    DataPropertyName = PropertyString.Name.TaskOrderId,
                //    HeaderText = PropertyString.Title.TaskOrderId,
                //    ValueType = typeof(int),
                //    AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                //    DefaultCellStyle = new DataGridViewCellStyle()
                //    {
                //        Alignment = DataGridViewContentAlignment.MiddleCenter,
                //    },
                //});
                //adgv.SetFilterChecklistEnabled(adgv.Columns[PropertyString.Name.TaskOrderId], false);

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.WorkOrderNo,
                    HeaderText = PropertyText.Title.WorkOrderNo,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.CreatorName,
                    HeaderText = PropertyText.Title.Creator,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.CreationDateString,
                    HeaderText = PropertyText.Title.CreationDateTime,
                    ValueType = typeof(DateTime),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.OrderStatusString,
                    HeaderText = PropertyText.Title.Status,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.MaintenanceUnit,
                    HeaderText = PropertyText.Title.MaintenanceUnit,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.EngineerString,
                    HeaderText = PropertyText.Title.Engineer,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.MachineCode,
                    HeaderText = PropertyText.Title.Machine,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.ModelName,
                    HeaderText = PropertyText.Title.ModelName,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.WorkstationName,
                    HeaderText = PropertyText.Title.Workstation,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.RepairDurationString,
                    HeaderText = PropertyText.Title.RepairDuration,
                    ValueType = typeof(TimeSpan),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                adgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.OutageDurationString,
                    HeaderText = PropertyText.Title.OutageDuration,
                    ValueType = typeof(TimeSpan),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                // TimeSpan的Format須另外設定
                adgv.CellFormatting += (s, e) =>
                {
                    if (adgv.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                        && e.Value is TimeSpan ts)
                    {
                        string days = ts.Days > 0 ? $"{ts.Days}d " : "";
                        e.Value = $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
                        e.FormattingApplied = true;
                    }
                };

                //adgvSearchToolBar.SetColumns(adgv.Columns);
                CommonStyles.SetAdvancedDataGridView(adgv, filterAndSort: true);
                AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
                AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

                // 下方
                int tabIndex = 0;

                uiLabel_OrderNo.Text = PropertyText.Title.TaskOrderId;
                OrderNo.DataBindings.Clear();
                //OrderNo.DataBindings.Add("Text", _tovm, PropertyText.Name.TaskOrderId, true, DataSourceUpdateMode.OnPropertyChanged);
                OrderNo.TabIndex = ++tabIndex;

                uiLabel_WorkOrderNo.Text = PropertyText.Title.WorkOrderNo;
                WorkOrderNo.DataBindings.Clear();
                //WorkOrderNo.DataBindings.Add("Text", _tovm, PropertyText.Name.WorkOrderNo, true, DataSourceUpdateMode.OnPropertyChanged);
                WorkOrderNo.TabIndex = ++tabIndex;

                uiLabel_Creator.Text = PropertyText.Title.Creator;
                Creator.DataBindings.Clear();
                //Creator.DataBindings.Add("Text", _tovm, PropertyText.Name.CreatorName, true, DataSourceUpdateMode.OnPropertyChanged);
                Creator.TabIndex = ++tabIndex;

                uiLabel_CreationDate.Text = PropertyText.Title.CreationDateTime;
                CreationDateTime.DataBindings.Clear();
                //CreationDateTime.DataBindings.Add("Text", _tovm, PropertyText.Name.CreationDateTimeString, true, DataSourceUpdateMode.OnPropertyChanged);
                CreationDateTime.TabIndex = ++tabIndex;

                uiLabel_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
                AcceptedTime.DataBindings.Clear();
                //AcceptedTime.DataBindings.Add("Text", _tovm, PropertyText.Name.AcceptedTimeString, true, DataSourceUpdateMode.OnPropertyChanged);
                AcceptedTime.TabIndex = ++tabIndex;

                uiLabel_Status.Text = PropertyText.Title.Status;
                var statusList = Enum.GetValues(typeof(FlowStatus))
                    .Cast<FlowStatus>()
                    .OrderByDescending(s => (int)s)
                    .Select(s => new { Value = (int)s, Text = s.GetDescription() })
                    .ToList();
                Status.DisplayMember = "Text";
                Status.ValueMember = "Value";
                Status.DataSource = statusList;
                Status.DataBindings.Clear();
                //Status.DataBindings.Add("SelectedValue", _tovm, PropertyText.Name.OrderStatusId, true, DataSourceUpdateMode.OnPropertyChanged);
                Status.TabIndex = ++tabIndex;

                uiLabel_MachineList.Text = PropertyText.Title.Machine;
                MachineCode.DataBindings.Clear();
                //MachineCode.DataBindings.Add("Text", _tovm, PropertyText.Name.FullMachineName, true, DataSourceUpdateMode.OnPropertyChanged);
                MachineCode.TabIndex = ++tabIndex;

                uiLabel_ModelWs.Text = PropertyText.Title.ModelWsName;
                ModelWs.DataBindings.Clear();
                //ModelWs.DataBindings.Add("Text", _tovm, PropertyText.Name.ModelWsName, true, DataSourceUpdateMode.OnPropertyChanged);
                ModelWs.TabIndex = ++tabIndex;

                uiLabel_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
                var lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
                lvm.AddRange(_context.MaintenanceUnits
                    .Select(m => new ListViewModel()
                    {
                        NullableId = m.Id,
                        Name = m.UnitName,
                    })
                    .ToList());
                MaintenanceUnit.DataSource = lvm;
                MaintenanceUnit.DisplayMember = "Name";
                MaintenanceUnit.ValueMember = "NullableId";
                MaintenanceUnit.DataBindings.Clear();
                //MaintenanceUnit.DataBindings.Add("Text", _tovm, PropertyText.Name.MaintenanceUnit, true, DataSourceUpdateMode.OnPropertyChanged);
                MaintenanceUnit.TabIndex = ++tabIndex;

                uiLabel_MaintenanceEngineer.Text = PropertyText.Title.Engineer;
                Engineers.DataBindings.Clear();
                //Engineers.DataBindings.Add("Text", _tovm, PropertyText.Name.EngineerString, true, DataSourceUpdateMode.OnPropertyChanged);
                Engineers.TabIndex = ++tabIndex;

                uiLabel_RepairStarted.Text = PropertyText.Title.RepairStarted;
                RepairStarted.DataBindings.Clear();
                //RepairStarted.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairStartedString, true, DataSourceUpdateMode.OnPropertyChanged);
                RepairStarted.TabIndex = ++tabIndex;

                uiLabel_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
                RepairCompleted.DataBindings.Clear();
                //RepairCompleted.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairCompletedString, true, DataSourceUpdateMode.OnPropertyChanged);
                RepairCompleted.TabIndex = ++tabIndex;

                uiLabel_RepairDuration.Text = PropertyText.Title.RepairDuration;
                RepairDuration.DataBindings.Clear();
                //RepairDuration.DataBindings.Add("Text", _tovm, PropertyText.Name.RepairDurationString, true, DataSourceUpdateMode.OnPropertyChanged);
                RepairDuration.TabIndex = ++tabIndex;

                uiLabel_OutageStarted.Text = PropertyText.Title.OutageStarted;
                OutageStarted.DataBindings.Clear();
                //OutageStarted.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageStartedString, true, DataSourceUpdateMode.OnPropertyChanged);
                OutageStarted.TabIndex = ++tabIndex;

                uiLabel_OutageEnded.Text = PropertyText.Title.OutageEnded;
                OutageEnded.DataBindings.Clear();
                //OutageEnded.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageEndedString, true, DataSourceUpdateMode.OnPropertyChanged);
                OutageEnded.TabIndex = ++tabIndex;

                uiLabel_OutageDuration.Text = PropertyText.Title.OutageDuration;
                OutageDuration.DataBindings.Clear();
                //OutageDuration.DataBindings.Add("Text", _tovm, PropertyText.Name.OutageDurationString, true, DataSourceUpdateMode.OnPropertyChanged);
                OutageDuration.TabIndex = ++tabIndex;

                uiLabel_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
                var rUnitList = _context.Departments
                    .OrderBy(r => r.OrderNo)
                    .Select(r => new ListViewModel { Id = r.Id, Name = r.DepartmentName, })
                    .ToList();
                RequestingUnit.DataSource = rUnitList;
                RequestingUnit.DisplayMember = "Name";
                RequestingUnit.ValueMember = "Id";
                RequestingUnit.DataBindings.Clear();
                //RequestingUnit.DataBindings.Add("Text", _tovm, PropertyText.Name.RequestingUnitString, true, DataSourceUpdateMode.OnPropertyChanged);
                RequestingUnit.TabIndex = ++tabIndex;

                uiLabel_FeedbackEmployee.Text = PropertyText.Title.FeedbackEmployee;
                FeedbackEmployee.DataBindings.Clear();
                //FeedbackEmployee.DataBindings.Add("Text", _tovm, PropertyText.Name.FeedbackEmployeeString, true, DataSourceUpdateMode.OnPropertyChanged);
                FeedbackEmployee.TabIndex = ++tabIndex;

                uiLabel_RequestingUnitResponse.Text = PropertyText.Title.Feedback;
                RequestingUnitFeedback.DataBindings.Clear();
                //RequestingUnitFeedback.DataBindings.Add("Text", _tovm, PropertyText.Name.Feedback, true, DataSourceUpdateMode.OnPropertyChanged);
                RequestingUnitFeedback.TabIndex = ++tabIndex;

                uiLabel_IssueCategory.Text = PropertyText.Title.MaintiFlowIssueCategory;
                lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
                lvm.AddRange(_context.IssueCategories
                    .Select(m => new ListViewModel()
                    {
                        NullableId = m.Id,
                        Name = m.CategoryName,
                    })
                    .ToList());
                IssueCategory.DataSource = lvm;
                IssueCategory.DisplayMember = "Name";
                IssueCategory.ValueMember = "NullableId";
                IssueCategory.DataBindings.Clear();
                //IssueCategory.DataBindings.Add("Text", _tovm, PropertyText.Name.IssueCategoryString, true, DataSourceUpdateMode.OnPropertyChanged);
                IssueCategory.TabIndex = ++tabIndex;

                uiLabel_IssueDescription.Text = PropertyText.Title.MaintiFlowIssueDescription;
                IssueDescription.DataBindings.Clear();
                //IssueDescription.DataBindings.Add("Text", _tovm, PropertyText.Name.IssueDescription, true, DataSourceUpdateMode.OnPropertyChanged);
                IssueDescription.TabIndex = ++tabIndex;

                uiLabel_Details.Text = PropertyText.Title.Details;
                Details.DataBindings.Clear();
                //Details.DataBindings.Add("Text", _tovm, PropertyText.Name.Details, true, DataSourceUpdateMode.OnPropertyChanged);
                Details.TabIndex = ++tabIndex;

                Label_FillingTime.Text = PropertyText.Title.FillingTime;
                FillingTime.DataBindings.Clear();
                //FillingTime.DataBindings.Add("Text", _tovm, PropertyText.Name.FillingTimeString, true, DataSourceUpdateMode.OnPropertyChanged);
                FillingTime.TabIndex = ++tabIndex;

                uiLabel_Responsible.Text = PropertyText.Title.Responsible;
                Responsible.DataBindings.Clear();
                //Responsible.DataBindings.Add("Text", _tovm, PropertyText.Name.Responsible, true, DataSourceUpdateMode.OnPropertyChanged);
                Responsible.TabIndex = ++tabIndex;

                loadingDialog.Close();
            }
        }

        private void UserChanged()
        {
            bool allowEdit = _permission.HasControlAccess(PermissionWords.MODULE_MAINTI_FLOW,
                                                          PermissionWords.PAGE_FLOW_SUMMARY,
                                                          "*",
                                                          PermissionWords.ACTION_EDIT);
            IsEnabled = !allowEdit;
            EditModeSwitch.Visible = allowEdit;
            btnSave.Visible = allowEdit;
            btnExportingExcel.Visible = allowEdit;

            adgv.ContextMenuStrip = allowEdit
                ? adgvContextMenu
                : null;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            _suppressCurrentItemChanged = true;

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "資料顯示中，請稍候...";
                loadingDialog.Show();

                var source = (_flowData?.TaskOrders) ?? Enumerable.Empty<TaskOrder>();
                _tovms = source.Select(u => new TaskOrderViewModel
                {
                    Edited = false,
                    Id = u.Id,
                    WorkOrderNo = u.WorkOrderNo,
                    StatusString = u.StatusString,
                    CreatorId = u.CreatorId,
                    CreatorName = u.CreatorName,
                    CreatorNameWithDepartment = u.CreatorNameWithDepartment,
                    CreationDateTime = u.CreationDateTime,
                    CreationDateString = u.CreationDateString,
                    CreationDateTimeString = u.CreationDateTimeString,
                    MachineCode = u.MachineCode,
                    FullMachineName = u.FullMachineName,
                    ModelName = u.ModelName,
                    WorkstationId = u.WorkstationId,
                    WorkstationName = u.WorkstationName,
                    ModelWsName = u.ModelWsName,
                    MaintenanceUnit = u.MaintenanceUnitString,
                    Engineers = u.Engineers,
                    EngineerString = u.EngineerString,
                    AcceptedTime = u.AcceptedTime,
                    AcceptedTimeString = u.AcceptedTimeString,
                    StatusId = u.StatusId,
                    IssueCategoryString = u.IssueCategoryString,
                    IssueDescription = u.IssueDescription,
                    Details = u.Details,
                    RepairStarted = u.RepairStarted,
                    RepairStartedString = u.RepairStartedString,
                    RepairCompleted = u.RepairCompleted,
                    RepairCompletedString = u.RepairCompletedString,
                    RepairDuration = u.RepairDuration,
                    RepairDurationString = u.RepairDurationString,
                    FillingTime = u.FillingTime,
                    FillingTimeString = u.FillingTimeString,
                    RequestingUnitString = u.RequestingUnitString,
                    FeedbackEmployeeId = u.FeedbackEmployeeId,
                    FeedbackEmployeeString = u.FeedbackEmployeeString,
                    Feedback = u.Feedback,
                    OutageStarted = u.OutageStarted,
                    OutageStartedString = u.OutageStartedString,
                    OutageEnded = u.OutageEnded,
                    OutageEndedString = u.OutageEndedString,
                    OutageDuration = u.OutageDuration,
                    OutageDurationString = u.OutageDurationString,
                    Responsible = u.Responsible
                }).ToList();

                var dt = _tovms.ToDataTable();
                _bs.DataSource = _tovms;
                adgv.AutoGenerateColumns = false;
                adgv.DataSource = dt;

                loadingDialog.Close();
                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_tovms.Count()} 筆資料"));
            }

            _suppressCurrentItemChanged = false;
        }

        /********************
         * 編輯模式
         ********************/
        private void SwitchEditMode(bool editMode)
        {
            IsEnabled = editMode;

            WorkOrderNo.Enabled = IsEnabled;
            Creator.Enabled = IsEnabled;
            CreationDateTime.Enabled = IsEnabled;
            AcceptedTime.Enabled = IsEnabled;
            Status.Enabled = IsEnabled;
            MaintenanceUnit.Enabled = IsEnabled;
            Engineers.Enabled = IsEnabled;
            MachineCode.Enabled = IsEnabled;
            ModelWs.Enabled = IsEnabled;
            IssueCategory.Enabled = IsEnabled;
            IssueDescription.Enabled = IsEnabled;
            Details.Enabled = IsEnabled;
            RequestingUnit.Enabled = IsEnabled;
            FeedbackEmployee.Enabled = IsEnabled;
            RequestingUnitFeedback.Enabled = IsEnabled;
            RepairStarted.Enabled = IsEnabled;
            RepairCompleted.Enabled = IsEnabled;
            OutageStarted.Enabled = IsEnabled;
            OutageEnded.Enabled = IsEnabled;
            Responsible.Enabled = IsEnabled;
            FillingTime.Enabled = IsEnabled;

            btnSave.Enabled = IsEnabled;
            //btnExportingExcel.Enabled = IsEnabled;

            adgv.ContextMenuStrip = IsEnabled ? adgvContextMenu : (ContextMenuStrip)null;
        }

        private void EditModeSwitch_ValueChanged(object sender, bool value)
        {
            SwitchEditMode(value);
        }

        //private void BindingSource_CurrentItemChanged(object sender, EventArgs e)
        //{
        //    if (_suppressCurrentItemChanged || _tovm == null) return;

        //    if (_bs.Current is TaskOrderViewModel currentItem)
        //    {
        //        currentItem.Edited = true;
        //    }
        //}

        //private void ChangePositionSafely(int newPosition)
        //{
        //    _suppressCurrentItemChanged = true;
        //    _bs.Position = newPosition;
        //    _suppressCurrentItemChanged = false;
        //}

        /********************
         * 
         ********************/
        private void ApplyVmToUi()
        {
            if (_tovm != null)
            {
                OrderNo.Text = _tovm.Id.ToString();
                WorkOrderNo.Text = _tovm.WorkOrderNo;
                Creator.Text = _tovm.CreatorName;
                CreationDateTime.Text = _tovm.CreationDateTimeString;
                AcceptedTime.Text = _tovm.AcceptedTimeString;
                Status.SelectedValue = _tovm.StatusId;
                MachineCode.Text = _tovm.FullMachineName;
                ModelWs.Text = _tovm.ModelWsName;
                MaintenanceUnit.Text = _tovm.MaintenanceUnit;
                Engineers.Text = _tovm.EngineerString;
                RepairStarted.Text = _tovm.RepairStartedString;
                RepairCompleted.Text = _tovm.RepairCompletedString;
                RepairDuration.Text = _tovm.RepairDurationString;
                OutageStarted.Text = _tovm.OutageStartedString;
                OutageEnded.Text = _tovm.OutageEndedString;
                OutageDuration.Text = _tovm.OutageDurationString;
                RequestingUnit.Text = _tovm.RequestingUnitString;
                FeedbackEmployee.Text = _tovm.FeedbackEmployeeString;
                RequestingUnitFeedback.Text = _tovm.Feedback;
                IssueCategory.Text = _tovm.IssueCategoryString;
                IssueDescription.Text = _tovm.IssueDescription;
                Details.Text = _tovm.Details;
                FillingTime.Text = _tovm.FillingTimeString;
                Responsible.Text = _tovm.Responsible;
            }
            else
            {
                OrderNo.Text = "";
                WorkOrderNo.Text = "";
                Creator.Text = "";
                CreationDateTime.Text = "";
                AcceptedTime.Text = "";
                Status.SelectedValue = "";
                MachineCode.Text = "";
                ModelWs.Text = "";
                MaintenanceUnit.Text = "";
                Engineers.Text = "";
                RepairStarted.Text = "";
                RepairCompleted.Text = "";
                RepairDuration.Text = "";
                OutageStarted.Text = "";
                OutageEnded.Text = "";
                OutageDuration.Text = "";
                RequestingUnit.Text = "";
                FeedbackEmployee.Text = "";
                RequestingUnitFeedback.Text = "";
                IssueCategory.Text = "";
                IssueDescription.Text = "";
                Details.Text = "";
                FillingTime.Text = "";
                Responsible.Text = "";
            }
        }

        /********************
         * adgv
         ********************/
        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            if (adgv.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                if (_toIndex >= 0)
                    _tovms[_toIndex] = _tovm;

                _thisTaskOrderId = Convert.ToInt32(drv[PropertyText.Name.TaskOrderId]);
                _tovm = _tovms.FirstOrDefault(to => to.Id == _thisTaskOrderId);

                ApplyVmToUi();

                if (_tovm != null)
                {
                    _defaultCreator.SetEmployee(_coreData.Employees.FirstOrDefault(c => c.Id == _tovm.CreatorId));
                    _defaultMachineCode.SetMachine(_coreData.Machines.FirstOrDefault(c => c.MachineCode == _tovm.MachineCode));
                    _defaultModelWs.SetWorkstation(_coreData.Workstations.FirstOrDefault(c => c.Id == _tovm.WorkstationId));
                    _defaultFeedbackEmployee.SetEmployee(_coreData.Employees.FirstOrDefault(c => c.Id == _tovm.FeedbackEmployeeId));
                    ClassifyInfo.SyncEmployees(_defaultEngineers, _tovm.Engineers);
                }
                else
                {
                    _defaultCreator.Clear();
                    _defaultMachineCode.Clear();
                    _defaultModelWs.Clear();
                    _defaultFeedbackEmployee.Clear();
                    _defaultEngineers.Clear();
                }
            }
        }

        private async void Button_Delete_Click(object sender, EventArgs e)
        {
            if (adgv.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                string selectedKey = drv[PropertyText.Name.WorkOrderNo].ToString();
                var item = _tovms.FirstOrDefault(x => x.WorkOrderNo == selectedKey);
                if (item != null)
                {
                    string msg = $"確定刪除這筆資料嗎？\n\n{PropertyText.Title.WorkOrderNo}: {item.WorkOrderNo}\n{PropertyText.Title.Creator}: {item.CreatorName}\n{PropertyText.Title.ModelName}: {item.ModelName}";
                    if (MessageBox.Show(msg, "刪除確認",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        var entity = _context.TaskOrders.FirstOrDefault(x => x.WorkOrderNo == item.WorkOrderNo);
                        if (entity != null)
                        {
                            try
                            {
                                // 重新從資料庫載入實體狀態（若已被其他來源刪除或修改，Reload 會拋例外）
                                try
                                {
                                    _context.Entry(entity).Reload();
                                }
                                catch (InvalidOperationException)
                                {
                                    // 重新查一次（可能已被刪除）
                                    entity = _context.TaskOrders.Find(entity.Id);
                                    if (entity == null)
                                    {
                                        string errMsg = "該筆資料已不存在（可能已被其他使用者刪除）。";
                                        MessageBox.Show(errMsg, "刪除中止", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        _logger.Error($"維護總表：刪除中止\n\n{errMsg}\n{PropertyText.Title.WorkOrderNo}: {item.WorkOrderNo}\n{PropertyText.Title.Creator}: {item.CreatorName}\n{PropertyText.Title.ModelName}: {item.ModelName}");
                                        return;
                                    }
                                }

                                // 明確處理子集合（範例：清除 many-to-many 的關聯）
                                _context.Entry(entity).Collection(x => x.TaskOrderEngineers).Load();
                                if (entity.TaskOrderEngineers != null && entity.TaskOrderEngineers.Any())
                                {
                                    entity.TaskOrderEngineers.Clear(); // 移除 join table 的關聯列
                                }

                                // 如有其它子集合或依賴表，應在此處先行刪除或清除 FK

                                _context.TaskOrders.Remove(entity);
                                await _context.SaveChangesAsync();

                                _tovms.Remove(item);

                                foreach (DataRow row in _dt.Rows)
                                {
                                    if (row[PropertyText.Name.WorkOrderNo].ToString() == selectedKey)
                                    {
                                        _dt.Rows.Remove(row);
                                        break;
                                    }
                                }

                                _bs.ResetBindings(false);

                                MessageBox.Show($"{PropertyText.Title.WorkOrderNo}: {item.WorkOrderNo} 已刪除！");
                            }
                            catch (System.Data.Entity.Infrastructure.DbUpdateConcurrencyException)
                            {
                                MessageBox.Show("刪除失敗：資料已被其他使用者修改或刪除，請重新整理後再試。", "並發錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            catch (System.Data.Entity.Infrastructure.DbUpdateException due)
                            {
                                MessageBox.Show($"資料庫更新失敗：{due.InnerException?.Message ?? due.Message}", "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "資料庫變更失敗");
                            }
                        }
                    }
                }
            }
        }

        #region 建檔日期處理

        //private bool _isCreationDateTimeTyping = false; // 是否使用鍵盤輸入
        //private bool _isCreationDateTimePickerOpen = false; // 是否開啟日曆

        //private void CreationDateTime_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isCreationDateTimeTyping = true;
        //}

        //private void CreationDateTime_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isCreationDateTimeTyping = false;
        //    ValidateAndUpdateCreationDateTime();
        //}

        //private void CreationDateTime_DropDown(object sender, EventArgs e)
        //{
        //    _isCreationDateTimePickerOpen = true;
        //}

        //private void CreationDateTime_DropDownClosed(object sender, EventArgs e)
        //{
        //    _isCreationDateTimePickerOpen = false;
        //    ValidateAndUpdateCreationDateTime();
        //}

        //private void CreationDateTime_ButtonClick(object sender, EventArgs e)
        //{
        //    if (_tovm.CreationDateTime == null)
        //    {
        //        CreationDateTime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        //    }
        //}

        //private void CreationDateTime_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isCreationDateTimePickerOpen || _isCreationDateTimeTyping)
        //        return;
        //    ValidateAndUpdateCreationDateTime();
        //}

        //private void CreationDateTime_TextChanged(object sender, EventArgs e)
        //{
        //    if (_isCreationDateTimePickerOpen)
        //        return;

        //    if (string.IsNullOrWhiteSpace(CreationDateTime.Text))
        //        _tovm.CreationDateTime = null;
        //}

        //private void ValidateAndUpdateCreationDateTime()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.CreationDateTime = DateTime.TryParse(CreationDateTime.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //}

        #endregion 建檔日期處理

        #region 維護時間處理

        //private bool _isRepairStartedTyping = false; // 是否使用鍵盤輸入
        //private bool _isRepairStartedPickerOpen = false; // 是否開啟日曆

        //private void RepairStarted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isRepairStartedTyping = true;
        //}

        //private void RepairStarted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isRepairStartedTyping = false;
        //    ValidateAndUpdateRepairStarted();
        //}

        //private void RepairStarted_DropDown(object sender, EventArgs e)
        //{
        //    _isRepairStartedPickerOpen = true;
        //}

        //private void RepairStarted_DropDownClosed(object sender, EventArgs e)
        //{
        //    _isRepairStartedPickerOpen = false;
        //    ValidateAndUpdateRepairStarted();
        //}

        //private void RepairStarted_ButtonClick(object sender, EventArgs e)
        //{
        //    if (_tovm.RepairStarted == null)
        //    {
        //        RepairStarted.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        //    }
        //}

        //private void RepairStarted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isRepairStartedPickerOpen || _isRepairStartedTyping)
        //        return;
        //    ValidateAndUpdateRepairStarted();
        //}

        //private void RepairStarted_TextChanged(object sender, EventArgs e)
        //{
        //    if (_isRepairStartedPickerOpen)
        //        return;

        //    if (string.IsNullOrWhiteSpace(RepairStarted.Text))
        //        _tovm.RepairStarted = null;
        //}

        //private void ValidateAndUpdateRepairStarted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.RepairStarted = DateTime.TryParse(RepairStarted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateRepairDuration();
        //}

        //private bool _isRepairCompletedTyping = false; // 是否使用鍵盤輸入
        //private bool _isRepairCompletedPickerOpen = false; // 是否開啟日曆

        //private void RepairCompleted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isRepairCompletedTyping = true;
        //}

        //private void RepairCompleted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isRepairCompletedTyping = false;
        //    ValidateAndUpdateRepairCompleted();
        //}

        //private void RepairCompleted_DropDown(object sender, EventArgs e)
        //{
        //    _isRepairCompletedPickerOpen = true;
        //}

        //private void RepairCompleted_DropDownClosed(object sender, EventArgs e)
        //{
        //    _isRepairCompletedPickerOpen = false;
        //    ValidateAndUpdateRepairCompleted();
        //}

        //private void RepairCompleted_ButtonClick(object sender, EventArgs e)
        //{
        //    if (_tovm.RepairCompleted == null)
        //    {
        //        RepairCompleted.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        //    }
        //}

        //private void RepairCompleted_TextChanged(object sender, EventArgs e)
        //{
        //    if (_isRepairCompletedPickerOpen)
        //        return;

        //    if (string.IsNullOrWhiteSpace(RepairCompleted.Text))
        //        _tovm.RepairCompleted = null;
        //}

        //private void RepairCompleted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isRepairCompletedTyping) return;
        //    ValidateAndUpdateRepairCompleted();
        //}

        //private void ValidateAndUpdateRepairCompleted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.RepairCompleted = DateTime.TryParse(RepairCompleted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateRepairDuration();
        //}

        //private void UpdateRepairDuration()
        //{
        //    if (_tovm.RepairStarted != null)
        //    {
        //        _tovm.RepairDuration = _tovm.RepairCompleted != null
        //            ? (TimeSpan)(_tovm.RepairCompleted - _tovm.RepairStarted)
        //            : (TimeSpan)(DateTime.Now - _tovm.RepairStarted);
        //    }
        //    else
        //    {
        //        _tovm.RepairDuration = TimeSpan.Zero;
        //    }
        //    string days = _tovm.RepairDuration.Days > 0 ? $"{_tovm.RepairDuration.Days}天 " : "";
        //    RepairDuration.Text = $"{days}{_tovm.RepairDuration.Hours:D2}:{_tovm.RepairDuration.Minutes:D2}";
        //}

        #endregion 維護時間處理

        #region 停動時間處理

        //private bool _isOutageStartedTyping = false; // 是否使用鍵盤輸入
        //private bool _isOutageStartedPickerOpen = false; // 是否開啟日曆

        //private void OutageStarted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isOutageStartedTyping = true;
        //}

        //private void OutageStarted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isOutageStartedTyping = false;
        //    ValidateAndUpdateOutageStarted();
        //}

        //private void OutageStarted_DropDown(object sender, EventArgs e)
        //{
        //    _isOutageStartedPickerOpen = true;
        //}

        //private void OutageStarted_DropDownClosed(object sender, EventArgs e)
        //{
        //    _isOutageStartedPickerOpen = false;
        //    ValidateAndUpdateOutageStarted();
        //}

        //private void OutageStarted_ButtonClick(object sender, EventArgs e)
        //{
        //    if (_tovm.OutageStarted == null)
        //    {
        //        OutageStarted.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        //    }
        //}

        //private void OutageStarted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isOutageStartedPickerOpen || _isOutageStartedTyping)
        //        return;
        //    ValidateAndUpdateOutageStarted();
        //}

        //private void OutageStarted_TextChanged(object sender, EventArgs e)
        //{
        //    if (_isOutageStartedPickerOpen)
        //        return;

        //    if (string.IsNullOrWhiteSpace(OutageStarted.Text))
        //        _tovm.OutageStarted = null;
        //}

        //private void ValidateAndUpdateOutageStarted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.OutageStarted = DateTime.TryParse(OutageStarted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateOutageDuration();
        //}

        //private bool _isOutageEndedTyping = false; // 是否使用鍵盤輸入
        //private bool _isOutageEndedPickerOpen = false; // 是否開啟日曆

        //private void OutageEnded_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isOutageEndedTyping = true;
        //}

        //private void OutageEnded_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isOutageEndedTyping = false;
        //    ValidateAndUpdateOutageEnded();
        //}

        //private void OutageEnded_DropDown(object sender, EventArgs e)
        //{
        //    _isOutageEndedPickerOpen = true;
        //}

        //private void OutageEnded_DropDownClosed(object sender, EventArgs e)
        //{
        //    _isOutageEndedPickerOpen = false;
        //    ValidateAndUpdateOutageEnded();
        //}

        //private void OutageEnded_ButtonClick(object sender, EventArgs e)
        //{
        //    if (_tovm.OutageEnded == null)
        //    {
        //        OutageEnded.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
        //    }
        //}

        //private void OutageEnded_TextChanged(object sender, EventArgs e)
        //{
        //    if (_isOutageEndedPickerOpen)
        //        return;

        //    if (string.IsNullOrWhiteSpace(OutageEnded.Text))
        //        _tovm.OutageEnded = null;
        //}

        //private void OutageEnded_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isOutageEndedTyping) return;
        //    ValidateAndUpdateOutageEnded();
        //}

        //private void ValidateAndUpdateOutageEnded()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.OutageEnded = DateTime.TryParse(OutageEnded.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateOutageDuration();
        //}

        //private void UpdateOutageDuration()
        //{
        //    if (_tovm.OutageStarted != null)
        //    {
        //        _tovm.OutageDuration = _tovm.OutageEnded != null
        //            ? (TimeSpan)(_tovm.OutageEnded - _tovm.OutageStarted)
        //            : (TimeSpan)(DateTime.Now - _tovm.OutageStarted);
        //    }
        //    else
        //    {
        //        _tovm.OutageDuration = TimeSpan.Zero;
        //    }
        //    string days = _tovm.OutageDuration.Days > 0 ? $"{_tovm.OutageDuration.Days}天 " : "";
        //    OutageDuration.Text = $"{days}{_tovm.OutageDuration.Hours:D2}:{_tovm.OutageDuration.Minutes:D2}";
        //}

        #endregion 停動時間處理

        #region 多選對話框

        private void Creator_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultCreator };
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultCreator = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(_defaultCreator.Category2) ? "" : $"{_defaultCreator.Category2} » ";
                    displayText += $"{_defaultCreator.IdString} {_defaultCreator.Name}";

                    Creator.Text = _defaultCreator.Name;
                }
                else
                {
                    Creator.Text = "";
                }
            }
        }

        private void MachineList_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.Machine}";
            _mSel.TreeViewCaption = "機台";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.MachinesSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultMachineCode };
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultMachineCode = _mSel.ResultList[0];
                    MachineCode.Text = string.Join(" » ", new[] { _defaultMachineCode.Name, _defaultMachineCode.Category2 }
                            .Where(s => !string.IsNullOrWhiteSpace(s)));
                }
            }
        }

        private void ModelWs_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇 {PropertyText.Title.ModelName} » {PropertyText.Title.Workstation}";
            _mSel.TreeViewCaption = "機種";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultModelWs };
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultModelWs = _mSel.ResultList[0];
                    var ws = _core.GetWorkstation(_defaultModelWs.Id);
                    var tovm = _tovms.FirstOrDefault(x => x.Id == _thisTaskOrderId);
                    tovm.WorkstationId = ws.Id;
                    tovm.Workstation = ws;
                    //tovm.Workstation.ModelId = ws != null && ws.ModelId != null
                    //? (int?)_core.GetModel((int)ws.ModelId).Id
                    //: null;
                    tovm.Workstation.Model = _coreData.Models.FirstOrDefault(m => m.Id == ws.ModelId);
                    ModelWs.Text = tovm.Workstation.FullWorkstationName;
                }
                else
                {
                    ModelWs.Text = "";
                }
            }
        }

        private void Engineers_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = false;
            _mSel.Title = $"請選擇{PropertyText.Title.Engineer}";
            _mSel.DialogWidth = 600;
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EmployeeMultiTabPageCache;
            _mSel.DefaultSelect = _defaultEngineers;
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                _defaultEngineers = _mSel.ResultList;
                List<string> emps = new List<string>();
                foreach (var emp in _defaultEngineers)
                    emps.Add(emp.Name);
                Engineers.Text = string.Join("; ", emps);
            }
        }

        private void FeedbackEmployee_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultFeedbackEmployee };
            _mSel.DisplayFormat = categoryInfo => $"{categoryInfo.Category1} » {categoryInfo.Name}";
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultFeedbackEmployee = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(_defaultFeedbackEmployee.Category2)
                        ? ""
                        : $"{_defaultFeedbackEmployee.Category2} » ";
                    displayText += $"{_defaultFeedbackEmployee.IdString} {_defaultFeedbackEmployee.Name}";

                    FeedbackEmployee.Text = _defaultFeedbackEmployee.Name;
                }
                else
                {
                    FeedbackEmployee.Text = "";
                }
            }
        }

        #endregion 多選對話框

        private async void btnSave_Click(object sender, EventArgs e)
        {
            var to = _context.TaskOrders.FirstOrDefault(x => x.Id == _thisTaskOrderId);
            if (to != null)
            {
                to.WorkOrderNo = WorkOrderNo.Text;
                to.StatusId = (int)Status.SelectedValue;
                to.CreationDateTime = CreationDateTime.Value;
                to.AcceptedTime = AcceptedTime.Value;
                to.IssueCategoryId = (int?)IssueCategory.SelectedValue;
                to.IssueDescription = IssueDescription.Text;
                to.Details = Details.Text;

                to.RepairStartedString = RepairStarted.Text;
                to.RepairCompletedString = RepairCompleted.Text;
                to.RepairDurationString = RepairDuration.Text;
                to.OutageStartedString = OutageStarted.Text;
                to.OutageEndedString = OutageEnded.Text;
                to.OutageDurationString = OutageDuration.Text;

                to.FillingTime = FillingTime.Value;
                to.WorkstationId = to.GetWorkstationId(ModelWs.Text, _context);

                _context.Entry(to).Collection(x => x.TaskOrderEngineers).Load();
                to.TaskOrderEngineers.Clear();
                var engineerNames = Engineers.Text
                    .Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim())
                    .Where(s => !string.IsNullOrWhiteSpace(s))
                    .ToList();
                var newEngineers = _context.Employees
                    .Where(emp => emp.IsEngineer && engineerNames.Contains(emp.EmployeeName))
                    .ToList();
                foreach (var eng in newEngineers)
                    to.Engineers.Add(eng);

                string mCode = MachineCode.Text.SplitClean('»', ';', ',').First();
                var machine = _coreData.Machines.FirstOrDefault(m => m.MachineCode == mCode);
                to.MachineId = machine?.Id;

                var creator = await _context.Employees.FirstOrDefaultAsync(emp => emp.EmployeeName == Creator.Text);
                to.CreatorId = creator?.Id ?? 0;

                int selectedMunitId = MaintenanceUnit.SelectedValue is int i ? i : 0;
                var munit = await _context.MaintenanceUnits.FirstOrDefaultAsync(r => r.Id == selectedMunitId);
                to.MaintenanceUnitId = munit?.Id ?? 0;

                to.FeedbackEmployeeId = await _context.Employees
                    .Where(emp => emp.EmployeeName == FeedbackEmployee.Text)
                    .Select(emp => (int?)emp.Id)
                    .FirstOrDefaultAsync();

                to.Feedback = RequestingUnitFeedback.Text;
                to.Responsible = Responsible.Text;

                await _context.SaveChangesAsync();
                _cacheManager.RequestTaskOrderUpdate();
                adgv.SelectRowByMachineCode(mCode);

                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("維護工單已儲存！"));
            }
        }

        private void ADGV_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
                return;

            var hit = adgv.HitTest(e.X, e.Y);
            if (hit.Type == DataGridViewHitTestType.Cell)
            {
                adgv.ClearSelection();
                adgv.CurrentCell = adgv.Rows[hit.RowIndex].Cells[hit.ColumnIndex];
                adgv.CurrentCell.Selected = true;
            }
        }

        private void adgvSearchToolBar_Search(object sender, AdvancedDataGridViewSearchToolBarSearchEventArgs e)
        {
            bool restartsearch = true;
            int startColumn = 0;
            int startRow = 0;
            if (!e.FromBegin)
            {
                bool endcol = adgv.CurrentCell.ColumnIndex + 1 >= adgv.ColumnCount;
                bool endrow = adgv.CurrentCell.RowIndex + 1 >= adgv.RowCount;

                if (endcol && endrow)
                {
                    startColumn = adgv.CurrentCell.ColumnIndex;
                    startRow = adgv.CurrentCell.RowIndex;
                }
                else
                {
                    startColumn = endcol ? 0 : adgv.CurrentCell.ColumnIndex + 1;
                    startRow = adgv.CurrentCell.RowIndex + (endcol ? 1 : 0);
                }
            }
            DataGridViewCell c = adgv.FindCell(
                e.ValueToSearch,
                e.ColumnToSearch != null ? e.ColumnToSearch.Name : null,
                startRow,
                startColumn,
                e.WholeWord,
                e.CaseSensitive);
            if (c == null && restartsearch)
                c = adgv.FindCell(
                e.ValueToSearch,
                e.ColumnToSearch != null ? e.ColumnToSearch.Name : null,
                0,
                0,
                e.WholeWord,
                e.CaseSensitive);
            if (c != null)
                adgv.CurrentCell = c;
        }

        private async void delWorkOrder_Click(object sender, EventArgs e)
        {
            if (adgv.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                _thisTaskOrderId = Convert.ToInt32(drv[PropertyText.Name.TaskOrderId]);
                var emp = _context.TaskOrders.FirstOrDefault(m => m.Id == _thisTaskOrderId);
                if (emp != null)
                {
                    if (UIMessageBox.ShowAsk2($"確定要刪除{PropertyText.Title.TaskOrderId} {emp.WorkOrderNo} 嗎？", true, UIMessageDialogButtons.Cancel))
                    {
                        try
                        {
                            // Reload 確認目前 DB 狀態
                            try
                            {
                                _context.Entry(emp).Reload();
                            }
                            catch (InvalidOperationException)
                            {
                                emp = _context.TaskOrders.Find(_thisTaskOrderId);
                                if (emp == null)
                                {
                                    string errMsg = "該筆資料已不存在（可能已被其他使用者刪除）。";
                                    MessageBox.Show(errMsg, "刪除中止", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    using (LogContext.PushProperty("Category", "Database"))
                                    {
                                        _logger.Information(errMsg);
                                    }
                                    return;
                                }
                            }

                            // 清除 many-to-many 關聯（避免 join table FK 衝突）
                            _context.Entry(emp).Collection(x => x.TaskOrderEngineers).Load();
                            if (emp.TaskOrderEngineers != null && emp.TaskOrderEngineers.Any())
                            {
                                emp.TaskOrderEngineers.Clear();
                            }

                            var preEmp = _context.TaskOrders
                                .Where(t => t.Id < emp.Id)
                                .OrderByDescending(t => t.Id)
                                .FirstOrDefault();
                            _context.TaskOrders.Remove(emp);

                            await _context.SaveChangesAsync();
                            MessageBox.Show($"{PropertyText.Title.ModelName} {emp.WorkOrderNo} 已刪除",
                                            $"刪除成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);

                            _cacheManager.RequestTaskOrderUpdate();
                            if (preEmp != null)
                            {
                                adgv.SelectRowByMachineCode(preEmp.MachineCode);
                            }
                            else
                            {
                                adgv.ClearSelection();
                            }
                        }
                        catch (System.Data.Entity.Infrastructure.DbUpdateConcurrencyException)
                        {
                            string errMsg = "刪除失敗：資料已被其他使用者修改或刪除，請重新整理後再試。";
                            MessageBox.Show(errMsg, "並發錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Warning(errMsg);
                            }
                        }
                        catch (System.Data.Entity.Infrastructure.DbUpdateException due)
                        {
                            string errMsg = $"資料庫更新失敗：{due.InnerException?.Message ?? due.Message}";
                            MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Error(due, errMsg);
                            }
                        }
                        catch (Exception ex)
                        {
                            string errMsg = $"刪除失敗：{nameof(MaintiFlowSummary)} » {nameof(delWorkOrder_Click)}()\n";
                            MessageBox.Show(ex.Message, "刪除失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            using (LogContext.PushProperty("Category", "Database"))
                            {
                                _logger.Error(ex, errMsg);
                            }
                        }
                    }
                }
            }
        }

        #region EXCEL

        private void btnExportingExcel_Click(object sender, EventArgs e)
        {
            if (_flowData?.TaskOrders == null)
            {
                MessageBox.Show("目前沒有可匯出的資料。", "匯出中止", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string rootDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Excel");
            if (!Directory.Exists(rootDir))
                Directory.CreateDirectory(rootDir);

            var exportTime = DateTime.Now;
            SaveFileDialog sfd = new SaveFileDialog
            {
                Title = "匯出維護工單總表",
                Filter = "Excel 檔案 (*.xlsx)|*.xlsx",
                DefaultExt = "xlsx",
                InitialDirectory = rootDir,
                FileName = $"維護工單總表_{exportTime:yyyyMMdd_HHmmss}.xlsx"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string filePath = sfd.FileName;
                try
                {
                    var datalist = _flowData.TaskOrders
                        .OrderBy(t => t.WorkOrderNo)
                        .Select(to => new
                        {
                            to.Id,
                            to.WorkOrderNo,
                            to.CreatorName,
                            to.CreationDateTimeString,
                            to.AcceptedTimeString,
                            to.StatusString,

                            to.MachineCode,
                            to.MachineName,
                            to.ModelName,
                            to.WorkstationName,

                            to.MaintenanceUnitString,
                            to.EngineerMultiString,
                            to.RepairStartedString,
                            to.RepairCompletedString,
                            to.RepairDurationString,
                            to.OutageStartedString,
                            to.OutageEndedString,
                            to.OutageDurationString,

                            to.RequestingUnitString,
                            to.FeedbackEmployeeString,
                            FeedbackString = to.Feedback.WrapByCharCount(30),

                            to.IssueCategoryString,
                            IssueDescriptionString = to.IssueDescription.WrapByCharCount(30),
                            DetailsString = to.Details.WrapByCharCount(30),

                            to.Responsible,
                            to.FillingTimeString,
                        }).ToList();

                    var excelData = new
                    {
                        ExportTime = exportTime.ToString("yyyy/MM/dd HH:mm"),
                        TotalRec = _flowData.TaskOrders.Count(),
                        DataList = datalist,
                    };

                    MiniExcel.SaveAsByTemplate(filePath, "MaintiFlowTemplate.xlsx", excelData);
                    MessageBox.Show($"維護工單總表已匯出。\n{filePath}", "匯出完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    string errMsg = $"維護工單總表匯出失敗！\n{filePath}";
                    MessageBox.Show(errMsg, "匯出錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    _logger.Error(ex, errMsg);
                }
            }
        }

        #endregion EXCEL
    }
}
