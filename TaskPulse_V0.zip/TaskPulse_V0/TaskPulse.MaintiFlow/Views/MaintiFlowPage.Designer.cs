﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class MaintiFlowPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.NavMenu = new Sunny.UI.UINavMenu();
            this.label_Header = new System.Windows.Forms.Label();
            this.MaintiFlowRegion = new System.Windows.Forms.Panel();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 2;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 134F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.NavMenu, 0, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.label_Header, 0, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.MaintiFlowRegion, 1, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 1;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1123, 702);
            this.tableLayoutPanel_Page.TabIndex = 16;
            // 
            // NavMenu
            // 
            this.NavMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.NavMenu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NavMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NavMenu.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.NavMenu.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.NavMenu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.NavMenu.FullRowSelect = true;
            this.NavMenu.HotTracking = true;
            this.NavMenu.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(230)))));
            this.NavMenu.ItemHeight = 50;
            this.NavMenu.Location = new System.Drawing.Point(0, 50);
            this.NavMenu.Margin = new System.Windows.Forms.Padding(0);
            this.NavMenu.MenuStyle = Sunny.UI.UIMenuStyle.White;
            this.NavMenu.Name = "NavMenu";
            this.NavMenu.ScrollBarColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.NavMenu.ScrollBarHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.NavMenu.ScrollBarPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.NavMenu.ScrollFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.NavMenu.SecondBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235)))));
            this.NavMenu.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.NavMenu.SelectedColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.NavMenu.ShowLines = false;
            this.NavMenu.ShowPlusMinus = false;
            this.NavMenu.ShowRootLines = false;
            this.NavMenu.Size = new System.Drawing.Size(134, 652);
            this.NavMenu.TabIndex = 8;
            this.NavMenu.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NavMenu.MenuItemClick += new Sunny.UI.UINavMenu.OnMenuItemClick(this.NavMenu_MenuItemClick);
            // 
            // label_Header
            // 
            this.label_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.label_Header.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_Header.Font = new System.Drawing.Font("標楷體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Header.Location = new System.Drawing.Point(0, 0);
            this.label_Header.Margin = new System.Windows.Forms.Padding(0);
            this.label_Header.Name = "label_Header";
            this.label_Header.Size = new System.Drawing.Size(134, 50);
            this.label_Header.TabIndex = 7;
            this.label_Header.Text = "維護工單";
            this.label_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MaintiFlowRegion
            // 
            this.MaintiFlowRegion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MaintiFlowRegion.Location = new System.Drawing.Point(137, 3);
            this.MaintiFlowRegion.Name = "MaintiFlowRegion";
            this.tableLayoutPanel_Page.SetRowSpan(this.MaintiFlowRegion, 2);
            this.MaintiFlowRegion.Size = new System.Drawing.Size(983, 696);
            this.MaintiFlowRegion.TabIndex = 9;
            // 
            // MaintiFlowPage
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "MaintiFlowPage";
            this.Size = new System.Drawing.Size(1123, 702);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private Sunny.UI.UINavMenu NavMenu;
        private System.Windows.Forms.Label label_Header;
        private System.Windows.Forms.Panel MaintiFlowRegion;
    }
}