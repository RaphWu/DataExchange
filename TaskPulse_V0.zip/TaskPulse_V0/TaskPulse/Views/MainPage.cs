﻿using System.Windows.Forms;

using Calin.TaskPulse.Core.SharedUI;

namespace Calin.TaskPulse.Views
{
    public partial class MainPage : UserControl
    {
        public MainPage(IRegionManager region, INavigationService nav)
        {
            InitializeComponent();

            region.RegisterRegion(nameof(TLP), TLP);
            nav.NavigateTo<LoginControl>(nameof(TLP), alive: false);

            var ctl = region.GetRegion(nameof(TLP)).HostControl.Controls[0];
            ctl.Dock = DockStyle.None;
            ctl.Anchor = AnchorStyles.None;
        }
    }
}
