﻿using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.SharedUI;
using Sunny.UI;

namespace Calin.TaskPulse.Views
{
    public partial class LoginForm : UIForm
    {
        public LoginForm(LoginControl loginControl)
        {
            InitializeComponent();

            TitleColor = CommonStyles.BackColor;
            loginControl.Dock = DockStyle.None;
            TLP.Controls.Add(loginControl);
        }
    }
}
