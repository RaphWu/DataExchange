﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Automation.BDaq;
using Calin.Filter;
using ScottPlot;
using ScottPlot.PlotStyles;
using ScottPlot.Plottables;
using Timer = System.Windows.Forms.Timer;

namespace USB4704Test
{
    // https://www.cnblogs.com/EasonDongH/p/8818829.html

    public partial class Form1 : Form, INotifyPropertyChanged
    {
        #region fields

        Timer _timer = new Timer();

#if DEBUG
        Stopwatch _stopwatch = new Stopwatch();
        double curWatch;
        double maxWatch = double.MinValue;
        double minWatch = double.MaxValue;
#endif

        // USB-4704
        const string deviceCode = "USB-4704,BID#0";
        const int channel = 0;  // 通道編號：0~7
        ModeName _modeName;

        const double KALMAN_INIT_R = 0.2;
        const double KALMAN_INIT_Q = 1.0;

        FilterKalman _filterKalman;
        FilterLowPass _filterLowPass;

        #endregion

        #region ScottPlot

        const int MAX_DATA = 1_000_000;
        const string FONT_NAME = "微軟正黑體";
        const string PLOT_NAME_MEASURE = "量測數據";
        const string PLOT_NAME_KALMAN = "卡爾曼濾波";
        const string PLOT_NAME_LPF1_1 = "一階低通濾波";
        const string PLOT_NAME_LPF2_1 = "二階低通濾波2-1";
        const string PLOT_NAME_LPF2_2 = "二階低通濾波2-2";

        //Multiplot _multiplot = new Multiplot();
        bool _autoScale = false;
        double[] _xTimeRanges = new double[] { 10, 30, 60 };
        double _xTimeRange;

        #endregion

        #region Instant

        const int TIMER_TICK = 10; // ms
        InstantAiCtrl _instantAiCtrl;
        int _instantTotalData;
        double _instantTimeTick;

        List<double> _instantData_Time;
        List<double> _instantData_Measure;
        List<double> _instantData_Kalman;
        List<double> _instantData_Lpf1_1;
        List<double> _instantData_Lpf2_1;
        List<double> _instantData_Lpf2_2;

        double[] _instantDataScaled;
        double _instantKVal;
        double _instantLpf1_1Val;
        double _instantLpf2_1Val;
        double _instantLpf2_2Val;

        Plot _instantPlot;
        List<DataLogger> _instantPlotList = new List<DataLogger>();
        AxisManager _instantAxis;
        DataLogger _instantPlot_Measure;
        DataLogger _instantPlot_Kalman;
        DataLogger _instantPlot_Lpf1_1;
        DataLogger _instantPlot_Lpf2_1;
        DataLogger _instantPlot_Lpf2_2;

        #endregion

        #region Streaming

        WaveformAiCtrl _waveformAiCtrl;
        bool _isFirstOverRun = true;

        double[] _streamingDataScaled = new double[2048];
        double _streamingKVal;
        double _streamingLpf1_1Val;
        double _streamingLpf2_1Val;
        double _streamingLpf2_2Val;

        Plot _streamingPlot;
        AxisManager _streamingAxis;
        DataLogger _streamingPlot_Measure;
        DataLogger _streamingPlot_Kalman;
        DataLogger _streamingPlot_Lpf1_1;
        DataLogger _streamingPlot_Lpf2_1;
        DataLogger _streamingPlot_Lpf2_2;

        #endregion

        #region data binding

        public bool IsRunning
        {
            get { return _isRunning; }
            set
            {
                if (_isRunning != value)
                {
                    _isRunning = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _isRunning = false;

        public bool IsStopped
        {
            get { return _isStopped; }
            set
            {
                if (_isStopped != value)
                {
                    _isStopped = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _isStopped = true;

        #endregion

        #region Data Reset

        private void Reset()
        {
            _instantTotalData = 0;
            _instantTimeTick = 0.0;

            // Instant
            _instantDataScaled = new double[1];
            _instantKVal = 0.0;
            _instantLpf1_1Val = 0.0;
            _instantLpf2_1Val = 0.0;
            _instantLpf2_2Val = 0.0;

            _instantData_Time = new List<double>();
            _instantData_Measure = new List<double>();
            _instantData_Kalman = new List<double>();
            _instantData_Lpf1_1 = new List<double>();
            _instantData_Lpf2_1 = new List<double>();
            _instantData_Lpf2_2 = new List<double>();

            //_instantPlot_Measure.Clear();
            //_instantPlot_Kalman.Clear();
            //_instantPlot_Lpf1_1.Clear();
            //_instantPlot_Lpf2_1.Clear();
            //_instantPlot_Lpf2_2.Clear();

            _instantPlot.Clear();

            _instantPlot_Measure = _instantPlot.Add.DataLogger();
            //_instantPlot_Measure.ViewSlide();
            _instantPlot_Measure.LegendText = PLOT_NAME_MEASURE;
            _instantPlotList.Add(_instantPlot_Measure);

            _instantPlot_Kalman = _instantPlot.Add.DataLogger();
            //_instantPlot_Kalman.ViewSlide();
            _instantPlot_Kalman.LegendText = PLOT_NAME_KALMAN;
            checkBox_Kalman.Text = PLOT_NAME_KALMAN;
            _instantPlotList.Add(_instantPlot_Kalman);

            _instantPlot_Lpf1_1 = _instantPlot.Add.DataLogger();
            //_instantPlot_Lpf1_1.ViewSlide();
            _instantPlot_Lpf1_1.LegendText = PLOT_NAME_LPF1_1;
            checkBox_LPF1_1.Text = PLOT_NAME_LPF1_1;
            _instantPlotList.Add(_instantPlot_Lpf1_1);

            _instantPlot_Lpf2_1 = _instantPlot.Add.DataLogger();
            //_instantPlot_Lpf2_1.ViewSlide();
            _instantPlot_Lpf2_1.LegendText = PLOT_NAME_LPF2_1;
            checkBox_LPF2_1.Text = PLOT_NAME_LPF2_1;
            _instantPlotList.Add(_instantPlot_Lpf2_1);

            _instantPlot_Lpf2_2 = _instantPlot.Add.DataLogger();
            //_instantPlot_Lpf2_2.ViewSlide();
            _instantPlot_Lpf2_2.LegendText = PLOT_NAME_LPF2_2;
            checkBox_LPF2_2.Text = PLOT_NAME_LPF2_2;
            _instantPlotList.Add(_instantPlot_Lpf2_2);

            formsPlot1.Update();
            formsPlot1.Refresh();

#if DEBUG
            _stopwatch.Stop();
            curWatch = 0.0;
            maxWatch = double.MinValue;
            minWatch = double.MaxValue;
#endif
        }

        #endregion

        #region ctor

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button_Start.DataBindings.Add("Enabled", this, "IsStopped");
            button_Stop.DataBindings.Add("Enabled", this, "IsRunning");
            groupBox_Mode.DataBindings.Add("Enabled", this, "IsStopped");

            // Filter
            _filterKalman = new FilterKalman(KALMAN_INIT_R, KALMAN_INIT_Q, 1, 1, 1);
            _filterLowPass = new FilterLowPass();

            // ScootPlot
            _instantPlot = formsPlot1.Plot;
            _instantPlot.YLabel("電壓 ( V )");

            _instantAxis = _instantPlot.Axes;
            _instantPlot.Axes.Left.Label.FontName = FONT_NAME;
            _instantPlot.Axes.Bottom.Label.FontName = FONT_NAME;
            _instantPlot.Axes.ContinuousAutoscaleAction = (RenderPack rp) =>
            {
                if (!_autoScale)
                    return;

                AxisLimits limits = _instantPlot.Axes.GetLimits();

                double windowWidth = _xTimeRange / 2;

                // 最後一筆資料的 X 值
                double latestX = _instantData_Time[_instantData_Time.Count - 1];
                bool touchRightEdge = latestX >= limits.Right;

                double left;
                double right;
                int indexLeft = _instantData_Time.FindIndex(x => x >= limits.Left);
                int indexRight = _instantData_Time.FindLastIndex(x => x <= limits.Right);

                // 若沒找到合法區間
                bool outOfView = (indexLeft == -1 || indexRight == -1 || indexLeft >= indexRight);

                // === 更新視窗區間 ===
                //double left = touchRightEdge ? latestX - windowWidth : limits.Left;
                //double right = touchRightEdge ? latestX : limits.Right;
                //double left = touchRightEdge ? latestX - limits.HorizontalCenter : limits.Left;
                //double right = touchRightEdge ? latestX + limits.HorizontalCenter : limits.Right;
                if (touchRightEdge || outOfView)
                {
                    left = latestX - windowWidth;
                    right = latestX + windowWidth;
                    indexLeft = _instantData_Time.Count - 1;
                    indexRight = (int)(indexLeft - _xTimeRange / (TIMER_TICK / 1000));
                    if (indexRight < 0)
                        indexRight = 0;
                }
                else
                {
                    left = limits.Left;
                    right = limits.Right;
                }

                // 取該範圍內 Y 值的 min/max
                double min = _instantData_Measure[indexLeft];
                double max = min;
                for (int i = indexLeft + 1; i <= indexRight; i++)
                {
                    min = Math.Min(min, _instantData_Measure[i]);
                    max = Math.Max(max, _instantData_Measure[i]);
                }

                rp.Plot.Axes.SetLimits(left, right, min, max);

                //if (!_autoScale)
                //    return;

                //// determine the left and right data index in view
                //AxisLimits limits = _instantPlot.Axes.GetLimits();
                //int indexLeft = (int)(limits.Left * 1000);
                //int indexRight = (int)(limits.Right * 1000);

                //// insure indexes are valid
                //indexLeft = NumericConversion.Clamp(indexLeft, 0, _instantData_Measure.Count - 1);
                //indexRight = NumericConversion.Clamp(indexRight, 0, _instantData_Measure.Count - 1);
                //if (indexLeft == indexRight)
                //    return;

                //// determine the vertical range of values in the visible range of indexes
                //double min = _instantData_Measure[indexLeft];
                //double max = _instantData_Measure[indexLeft];
                //for (int i = indexLeft; i <= indexRight; i++)
                //{
                //    min = Math.Min(min, _instantData_Measure[i]);
                //    max = Math.Max(max, _instantData_Measure[i]);
                //}

                //bool touchRightEdge = _instantData_Time[_instantData_Time.Count - 1] > limits.Right;

                //double left = touchRightEdge ? limits.HorizontalCenter : limits.Left;
                //double right = touchRightEdge ? limits.Right + (limits.Right - limits.VerticalCenter) : limits.Right;

                //// set vertical axis limits to that range
                //rp.Plot.Axes.SetLimits(left, right, min, max);
                ////rp.Plot.Axes.SetLimitsY(min, max);
            };
             
            var leg = _instantPlot.ShowLegend();
            leg.Alignment = Alignment.LowerLeft;
            leg.FontName = FONT_NAME;

            // Control

            radioButton_TimeRange0.Text = String.Concat(_xTimeRanges[0].ToString("0"), " 秒");
            radioButton_TimeRange1.Text = String.Concat(_xTimeRanges[1].ToString("0"), " 秒");
            radioButton_TimeRange2.Text = String.Concat(_xTimeRanges[2].ToString("0"), " 秒");

            // Timer
            _timer.Interval = TIMER_TICK;
            _timer.Tick += TimerElapsed;

            // Mode
            //ModeChange(ModeName.Instant);
            radioButton_Instant.Checked = true;
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            numericUpDown_KalmanR.Value = decimal.Parse(KALMAN_INIT_R.ToString());
            numericUpDown_KalmanQ.Value = decimal.Parse(KALMAN_INIT_Q.ToString());

            SetLimitsX(_xTimeRanges[0]);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _timer.Stop();
            _timer.Tick -= TimerElapsed;
            _timer.Dispose();

            if (_instantAiCtrl != null)
            {
                _instantAiCtrl.Dispose();
                _instantAiCtrl = null;
            }

            if (_waveformAiCtrl != null)
            {
                _waveformAiCtrl.Stop();
                _waveformAiCtrl.Dispose();
                _waveformAiCtrl = null;
            }
        }

        #endregion

        #region 模式選擇

        private enum ModeName
        {
            Instant,
            Streaming,
        }

        private void ModeChange(ModeName modeName)
        {
            _modeName = modeName;

            switch (modeName)
            {
                case ModeName.Instant:
                    Reset();

                    if (_waveformAiCtrl != null)
                    {
                        _waveformAiCtrl.Stop();
                        _waveformAiCtrl.DataReady -= _waveformAiCtrl_DataReady;
                        _waveformAiCtrl.CacheOverflow -= _waveformAiCtrl_CacheOverflow;
                        _waveformAiCtrl.Overrun -= _waveformAiCtrl_Overrun;
                        _waveformAiCtrl.Dispose();
                        _waveformAiCtrl = null;
                    }

                    _instantAiCtrl = new InstantAiCtrl();
                    _instantAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
                    if (!_instantAiCtrl.Initialized)
                    {
                        MessageBox.Show("No device be selected or device open failed!", "InstantAI");
                        this.Close();
                        return;
                    }

                    _instantPlot.XLabel(String.Concat("時間：每筆量測值取值間隔 ", TIMER_TICK.ToString(), " ms"));
                    break;

                case ModeName.Streaming:
                    _timer.Stop();
                    Reset();

                    if (_instantAiCtrl != null)
                    {
                        _instantAiCtrl.Dispose();
                        _instantAiCtrl = null;
                    }

                    _waveformAiCtrl = new WaveformAiCtrl();
                    _waveformAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
                    if (!_waveformAiCtrl.Initialized)
                    {
                        MessageBox.Show("No device be selected or device open failed!", "StreamingAI");
                        this.Close();
                        return;
                    }
                    _waveformAiCtrl.DataReady += _waveformAiCtrl_DataReady;
                    _waveformAiCtrl.CacheOverflow += _waveformAiCtrl_CacheOverflow;
                    _waveformAiCtrl.Overrun += _waveformAiCtrl_Overrun;

                    _instantPlot.XLabel("時間：每次取2048筆量測值，間隔約2秒");
                    break;
            }
        }

        private void radioButton_Instant_CheckedChanged(object sender, EventArgs e)
        {
            ModeChange(ModeName.Instant);
        }

        private void radioButton_Streaming_CheckedChanged(object sender, EventArgs e)
        {
            ModeChange(ModeName.Streaming);
        }

        private void button_Start_Click(object sender, EventArgs e)
        {
            ErrorCode err = ErrorCode.ErrorUndefined;

            switch (_modeName)
            {
                case ModeName.Instant:
                    _timer.Start();
                    err = ErrorCode.Success;
                    break;

                case ModeName.Streaming:
                    err = _waveformAiCtrl.Prepare();
                    if (err == ErrorCode.Success)
                        err = _waveformAiCtrl.Start();

                    break;
            }

            if (err == ErrorCode.Success)
            {
                IsRunning = true;
                IsStopped = false;
                _autoScale = true;
                _instantAxis.ContinuouslyAutoscale = true;
            }
        }

        private void button_Stop_Click(object sender, EventArgs e)
        {
            ErrorCode err = ErrorCode.ErrorUndefined;

            switch (_modeName)
            {
                case ModeName.Instant:
                    _timer.Stop();
                    err = ErrorCode.Success;
                    break;

                case ModeName.Streaming:
                    err = _waveformAiCtrl.Stop();
                    break;
            }

            IsRunning = false;
            IsStopped = true;
            _autoScale = false;
            _instantAxis.ContinuouslyAutoscale = false;
        }

        private void button_Reset_Click(object sender, EventArgs e)
        {
            _autoScale = false;
            Reset();
            _autoScale = IsRunning;
        }

        #endregion

        #region Common

        private void HandleError(ErrorCode err)
        {
            if ((err >= ErrorCode.ErrorHandleNotValid) && (err != ErrorCode.Success))
                MessageBox.Show(String.Concat("USB-4704異常！錯誤碼：", err.ToString()));
        }

        #endregion

        #region Instant Mode

        private void TimerElapsed(object sender, EventArgs e)
        {
            //if (_instantAiCtrl != null && _instantAiCtrl.State == ControlState.Running)
            {
#if DEBUG
                _stopwatch.Reset();
                _stopwatch.Start();
#endif

                var err = _instantAiCtrl.Read(channel, 1, _instantDataScaled);
                if (err == ErrorCode.Success)
                {
                    //if (_axisTime.Count >= MAX_DATA)
                    //{
                    //    _axisTime.RemoveAt(0);
                    //    _axisMeasure.RemoveAt(0);
                    //    _axisKalman.RemoveAt(0);
                    //    _axisLowPass1_1.RemoveAt(0);
                    //}

                    double measure = _instantDataScaled[0];
                    _instantKVal = _filterKalman.Filter(measure, 0.0);
                    _instantLpf1_1Val = _filterLowPass.LPF1_1(measure);
                    _instantLpf2_1Val = FilterLowPass.LPF2_1(measure);
                    _instantLpf2_2Val = FilterLowPass.LPF2_2(measure);

                    // 繪圖
                    _instantData_Time.Add(_instantTimeTick);
                    _instantData_Measure.Add(Math.Round(measure, 3));
                    _instantData_Kalman.Add(Math.Round(_instantKVal, 3));
                    _instantData_Lpf1_1.Add(Math.Round(_instantLpf1_1Val, 3));
                    _instantData_Lpf2_1.Add(Math.Round(_instantLpf2_1Val, 3));
                    _instantData_Lpf2_2.Add(Math.Round(_instantLpf2_2Val, 3));

                    //_instantPlot_Measure.Add(Math.Round(measure, 3));
                    //_instantPlot_Kalman.Add(Math.Round(_instantKVal, 3));
                    //_instantPlot_Lpf1_1.Add(Math.Round(_instantLpf1_1Val, 3));
                    //_instantPlot_Lpf2_1.Add(Math.Round(_instantLpf2_1Val, 3));
                    //_instantPlot_Lpf2_2.Add(Math.Round(_instantLpf2_2Val, 3));

                    formsPlot1.Update();
                    formsPlot1.Refresh();

#if DEBUG
                    _stopwatch.Stop();
                    curWatch = _stopwatch.Elapsed.TotalMilliseconds;
                    if (maxWatch < curWatch)
                        maxWatch = curWatch;
                    if (minWatch > curWatch)
                        minWatch = curWatch;
#endif

                    _instantTotalData++;
                    _instantTimeTick = Math.Round(_instantTimeTick + (TIMER_TICK / 1000.0), 2);


                    // 文字
                    label_Measure.Text = String.Concat("取值: ", measure.ToString());

#if DEBUG
                    label_adjMeasure.Text = String.Concat("Stopwatch: ", curWatch.ToString("0.000"));
                    label_MaxMeasure.Text = String.Concat("最大: ", maxWatch.ToString("0.000"));
                    label_MinMeasure.Text = String.Concat("最小: ", minWatch.ToString("0.000"));
#endif
                }
                else
                {
                    HandleError(err);
                    _timer.Stop();
                }
            }
        }

        #endregion

        #region Streaming Mode

        /********************
         * USB-4704 Buffer事件
         * 注意：Overrun 和 CacheOverflow 事件表示資料收集過程中發生了資料遺失（可能存在資料錯位或不連續的情況）。
         * 強烈建議在應用程式中持續監控這些事件。遺失這些事件通知可能會導致您誤解採集狀態。
         ********************/
        /********************
         * 注意：        
         * 1. 不建議在此函數中處理或列印過多訊息，容易造成事件阻塞。        
         * 2. 理論上，DataReady 傳回的資料量 argsCount 應該等於 sectionLen * channelCount。
         * 然而，實際上，dataReady 回呼函數的執行時間也會受到系統負載的影響，
         * 因此無法保證每次 DataReady 傳回的資料量 argsCount 等於 sectionLen * channelCount。
         ********************/
        private void _waveformAiCtrl_DataReady(object sender, BfdAiEventArgs args)
        {
            try
            {
#if DEBUG
                _stopwatch.Reset();
                _stopwatch.Start();
#endif

                //The WaveformAiCtrl has been disposed.
                if (_waveformAiCtrl.State == ControlState.Idle)
                    return;

                if (_instantDataScaled.Length < args.Count)
                    _instantDataScaled = new double[args.Count];

                ErrorCode err = ErrorCode.Success;
                //int chanCount = _waveformAiCtrl.Conversion.ChannelCount;
                //int sectionLength = _waveformAiCtrl.Record.SectionLength;
                err = _waveformAiCtrl.GetData(args.Count, _instantDataScaled);
                if (err != ErrorCode.Success && err != ErrorCode.WarningRecordEnd)
                {
                    HandleError(err);
                    return;
                }

                _instantTimeTick = Math.Round(_instantTimeTick + 0.1, 1);
                _instantData_Time[_instantTotalData] = _instantTimeTick;
                //_axisTime.Add(_timeTick);

                Task.Run(() =>
                {
                    foreach (var data in _instantDataScaled)
                    {
                        double measure = data;
                        //if (measure > _maxMeasure) _maxMeasure = measure;
                        //if (measure < _minMeasure) _minMeasure = measure;
                        //_avgMeasure = measure * 0.7 + _avgMeasure * 0.3;
                        //_dataMeasure[_tickCounter] = measure;
                        //_axisMeasure.Add(measure);

                        // Kalman
                        _instantKVal = _filterKalman.Filter(data, 0.0);
                        //_avgKVal = _kVal * 0.7 + _avgKVal * 0.3;
                        //if (_kVal > _maxKVal) _maxKVal = _kVal;
                        //if (_kVal < _minKVal) _minKVal = _kVal;

                        // Low Pass 1
                        _instantLpf1_1Val = _filterLowPass.LPF1_1(data);
                        _instantLpf2_1Val = FilterLowPass.LPF2_1(data);
                        _instantLpf2_2Val = FilterLowPass.LPF2_2(data);

#if DEBUG
                        _stopwatch.Stop();
                        curWatch = _stopwatch.Elapsed.TotalMilliseconds;
                        if (maxWatch < curWatch)
                            maxWatch = curWatch;
                        if (minWatch > curWatch)
                            minWatch = curWatch;
#endif

                        // 繪圖
                        //formsPlot1.Plot.Add.Signal(_dataMeasure);

                        //_instantPlot_Measure.Add(Math.Round(measure, 3));
                        //_instantPlot_Kalman.Add(Math.Round(_instantKVal, 3));
                        //_instantPlot_Lpf1_1.Add(Math.Round(_instantLpf1_1Val, 3));
                        //_instantPlot_Lpf2_1.Add(Math.Round(_instantLpf2_1Val, 3));
                        //_instantPlot_Lpf2_2.Add(Math.Round(_instantLpf2_2Val, 3));
                    }

                    formsPlot1.InvokeIfRequired(() =>
                    {
                        formsPlot1.Refresh();

#if DEBUG
                        label_adjMeasure.Text = String.Concat("Stopwatch: ", curWatch.ToString("0.000"));
                        label_MaxMeasure.Text = String.Concat("最大: ", maxWatch.ToString("0.000"));
                        label_MinMeasure.Text = String.Concat("最小: ", minWatch.ToString("0.000"));
#endif
                    });
                });
            }
            catch (System.Exception) { }
        }

        private void _waveformAiCtrl_Overrun(object sender, BfdAiEventArgs e)
        {
            MessageBox.Show("WaveformAiCacheOverflow");
            // Please consider if it's necessary to stop the application in your application when this event is triggered.
            // waveformAiCtrl1->Stop();
        }

        private void _waveformAiCtrl_CacheOverflow(object sender, BfdAiEventArgs e)
        {
            if (_isFirstOverRun)
            {
                MessageBox.Show("WaveformAiOverrun");
                _isFirstOverRun = false;
            }
            // Please consider if it's necessary to stop the application in your application when this event is triggered.
            // waveformAiCtrl1->Stop();
        }

        #endregion

        #region other

        public event PropertyChangedEventHandler PropertyChanged;

        internal void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            if (Application.OpenForms.Count > 0)
            {
                var form = Application.OpenForms[0];
                if (form.InvokeRequired)
                {
                    form.Invoke(new Action(() =>
                    {
                        if (PropertyChanged != null)
                            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                    }));
                }
                else
                {
                    if (PropertyChanged != null)
                        PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                }
            }
        }

        #endregion

        private void numericUpDown_KalmanR_ValueChanged(object sender, EventArgs e)
        {
            if (_filterKalman != null)
                _filterKalman.SetProcessNoise((double)numericUpDown_KalmanR.Value);
        }

        private void numericUpDown_KalmanQ_ValueChanged(object sender, EventArgs e)
        {
            if (_filterKalman != null)
                _filterKalman.SetMeasurementNoise((double)numericUpDown_KalmanQ.Value);
        }

        private void checkBox_Kalman_CheckedChanged(object sender, EventArgs e)
        {
            _instantPlot_Kalman.IsVisible = checkBox_Kalman.Checked;
        }

        private void checkBox_LPF1_1_CheckedChanged(object sender, EventArgs e)
        {
            _instantPlot_Lpf1_1.IsVisible = checkBox_LPF1_1.Checked;
        }

        private void checkBox_LPF2_1_CheckedChanged(object sender, EventArgs e)
        {
            _instantPlot_Lpf2_1.IsVisible = checkBox_LPF2_1.Checked;
        }

        private void checkBox_LPF2_2_CheckedChanged(object sender, EventArgs e)
        {
            _instantPlot_Lpf2_2.IsVisible = checkBox_LPF2_2.Checked;
        }

        private void radioButton_TimeRange1_CheckedChanged(object sender, EventArgs e)
        {
            SetLimitsX(_xTimeRanges[0]);
        }

        private void radioButton_TimeRange2_CheckedChanged(object sender, EventArgs e)
        {
            SetLimitsX(_xTimeRanges[1]);
        }

        private void radioButton_TimeRange3_CheckedChanged(object sender, EventArgs e)
        {
            SetLimitsX(_xTimeRanges[2]);
        }
    }
}
