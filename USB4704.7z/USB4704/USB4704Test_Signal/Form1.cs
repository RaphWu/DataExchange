﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Automation.BDaq;
using ScottPlot;
using ScottPlot.Plottables;
using Timer = System.Windows.Forms.Timer;

namespace USB4704Test
{
    // https://www.cnblogs.com/EasonDongH/p/8818829.html

    public partial class Form1 : Form, INotifyPropertyChanged
    {
        #region fields

        Timer _timer = new Timer();

        // USB-4704
        const string deviceCode = "USB-4704,BID#0";
        const int channel = 0;  // 通道編號：0~7
        ModeName _modeName;

        // data save
        const int MAX_DATA = 1_000_000;
        int _totalData;
        double _timeTick;
        double[] _instantData_Time;
        double[] _instantData_Measure;
        double[] _instantData_Kalman;
        double[] _instantData_Lpf1_1;
        double[] _instantData_Lpf2_1;
        double[] _instantData_Lpf2_2;

        // Instant
        const int TIMER_TICK = 5;
        InstantAiCtrl _instantAiCtrl;

        // Streaming
        WaveformAiCtrl _waveformAiCtrl;
        bool _isFirstOverRun = true;

        // ScootPlot
        Plot plot;
        AxisManager plotAxis;
        DataLogger _instantPlot_Measure;
        DataLogger _plotKalman;
        DataLogger _plotLpf1_1;
        DataLogger _plotLpf2_1;
        DataLogger _plotLpf2_2;
        //Multiplot _multiplot = new Multiplot();

        // 量測值
        const string PLOT_NAME_MEASURE = "量測數據";
        double[] _dataScaled = new double[2048];
        double _maxMeasure = double.MinValue;
        double _minMeasure = double.MaxValue;
        double _avgMeasure = 0.0;

        // Kalman
        const string PLOT_NAME_KALMAN = "卡爾曼濾波";
        const double KALMAN_INIT_R = 0.2;
        const double KALMAN_INIT_Q = 1.0;
        FilterKalman _filterKalman;
        double _kVal;

        // 一階低通濾波
        const string PLOT_NAME_LPF1_1 = "一階低通濾波";
        FilterLowPass _filterLowPass;
        double _lpf1_1Val;

        // 二階低通濾波
        const string PLOT_NAME_LPF2_1 = "二階低通濾波2-1";
        double _lpf2_1Val;

        const string PLOT_NAME_LPF2_2 = "二階低通濾波2-2";
        double _lpf2_2Val;

#if DEBUG
        Stopwatch _stopwatch = new Stopwatch();
        double curWatch;
        double maxWatch = double.MinValue;
        double minWatch = double.MaxValue;
#endif
        #endregion

        #region data binding

        public bool IsRunning
        {
            get { return _isRunning; }
            set
            {
                if (_isRunning != value)
                {
                    _isRunning = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _isRunning = false;

        public bool IsStopped
        {
            get { return _isStopped; }
            set
            {
                if (_isStopped != value)
                {
                    _isStopped = value;
                    NotifyPropertyChanged();
                }
            }
        }
        private bool _isStopped = true;

        #endregion

        #region ctor

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button_Start.DataBindings.Add("Enabled", this, "IsStopped");
            button_Stop.DataBindings.Add("Enabled", this, "IsRunning");
            groupBox_Mode.DataBindings.Add("Enabled", this, "IsStopped");

            // Filter
            _filterKalman = new FilterKalman(KALMAN_INIT_R, KALMAN_INIT_Q, 1, 1, 1);
            _filterLowPass = new FilterLowPass();

            // ScootPlot
            const string FONT_NAME = "微軟正黑體";

            plot = formsPlot1.Plot;
            plot.YLabel("電壓 ( V )");

            plotAxis = plot.Axes;
            plot.Axes.Left.Label.FontName = FONT_NAME;
            plot.Axes.Bottom.Label.FontName = FONT_NAME;
            plot.Axes.ContinuousAutoscaleAction = (RenderPack rp) =>
            {
                // determine the left and right data index in view
                AxisLimits limits = plot.Axes.GetLimits();
                int indexLeft = (int)(limits.Left * 1000);
                int indexRight = (int)(limits.Right * 1000);

                // insure indexes are valid
                indexLeft = NumericConversion.Clamp(indexLeft, 0, _instantData_Measure.Length - 1);
                indexRight = NumericConversion.Clamp(indexRight, 0, _instantData_Measure.Length - 1);
                if (indexLeft == indexRight)
                    return;

                // determine the vertical range of values in the visible range of indexes
                double min = _instantData_Measure[indexLeft];
                double max = _instantData_Measure[indexLeft];
                for (int i = indexLeft; i <= indexRight; i++)
                {
                    min = Math.Min(min, _instantData_Measure[i]);
                    max = Math.Max(max, _instantData_Measure[i]);
                }

                // set vertical axis limits to that range
                rp.Plot.Axes.SetLimitsY(min, max);
            };

            var leg = plot.ShowLegend();
            leg.Alignment = Alignment.LowerLeft;
            leg.FontName = FONT_NAME;

            _instantPlot_Measure = plot.Add.SignalXY();
            _instantPlot_Measure.ViewSlide();
            _instantPlot_Measure.LegendText = PLOT_NAME_MEASURE;

            _plotKalman = plot.Add.DataLogger();
            _plotKalman.ViewSlide();
            _plotKalman.LegendText = PLOT_NAME_KALMAN;
            checkBox_Kalman.Text = PLOT_NAME_KALMAN;

            _plotLpf1_1 = plot.Add.DataLogger();
            _plotLpf1_1.ViewSlide();
            _plotLpf1_1.LegendText = PLOT_NAME_LPF1_1;
            checkBox_LPF1_1.Text = PLOT_NAME_LPF1_1;

            _plotLpf2_1 = plot.Add.DataLogger();
            _plotLpf2_1.ViewSlide();
            _plotLpf2_1.LegendText = PLOT_NAME_LPF2_1;
            checkBox_LPF2_1.Text = PLOT_NAME_LPF2_1;

            _plotLpf2_2 = plot.Add.DataLogger();
            _plotLpf2_2.ViewSlide();
            _plotLpf2_2.LegendText = PLOT_NAME_LPF2_2;
            checkBox_LPF2_2.Text = PLOT_NAME_LPF2_2;

            //plot.Font.Automatic(); // Automatic Font Detection

            // Timer
            _timer.Interval = TIMER_TICK;
            _timer.Tick += TimerElapsed;

            // Mode
            //ModeChange(ModeName.Instant);
            radioButton_Instant.Checked = true;
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            numericUpDown_KalmanR.Value = decimal.Parse(KALMAN_INIT_R.ToString());
            numericUpDown_KalmanQ.Value = decimal.Parse(KALMAN_INIT_Q.ToString());
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _timer.Stop();
            _timer.Tick -= TimerElapsed;
            _timer.Dispose();

            if (_instantAiCtrl != null)
            {
                _instantAiCtrl.Dispose();
                _instantAiCtrl = null;
            }

            if (_waveformAiCtrl != null)
            {
                _waveformAiCtrl.Stop();
                _waveformAiCtrl.Dispose();
                _waveformAiCtrl = null;
            }
        }

        #endregion

        #region 模式選擇

        private enum ModeName
        {
            Instant,
            Streaming,
        }

        private void ModeChange(ModeName modeName)
        {
            _modeName = modeName;

            switch (modeName)
            {
                case ModeName.Instant:
                    Reset();

                    if (_waveformAiCtrl != null)
                    {
                        _waveformAiCtrl.Stop();
                        _waveformAiCtrl.DataReady -= _waveformAiCtrl_DataReady;
                        _waveformAiCtrl.CacheOverflow -= _waveformAiCtrl_CacheOverflow;
                        _waveformAiCtrl.Overrun -= _waveformAiCtrl_Overrun;
                        _waveformAiCtrl.Dispose();
                        _waveformAiCtrl = null;
                    }

                    _instantAiCtrl = new InstantAiCtrl();
                    _instantAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
                    if (!_instantAiCtrl.Initialized)
                    {
                        MessageBox.Show("No device be selected or device open failed!", "InstantAI");
                        this.Close();
                        return;
                    }

                    plot.XLabel(String.Concat("時間：每筆量測值取值間隔 ", TIMER_TICK.ToString(), " ms"));
                    break;

                case ModeName.Streaming:
                    _timer.Stop();
                    Reset();

                    if (_instantAiCtrl != null)
                    {
                        _instantAiCtrl.Dispose();
                        _instantAiCtrl = null;
                    }

                    _waveformAiCtrl = new WaveformAiCtrl();
                    _waveformAiCtrl.SelectedDevice = new DeviceInformation(deviceCode);
                    if (!_waveformAiCtrl.Initialized)
                    {
                        MessageBox.Show("No device be selected or device open failed!", "StreamingAI");
                        this.Close();
                        return;
                    }
                    _waveformAiCtrl.DataReady += _waveformAiCtrl_DataReady;
                    _waveformAiCtrl.CacheOverflow += _waveformAiCtrl_CacheOverflow;
                    _waveformAiCtrl.Overrun += _waveformAiCtrl_Overrun;

                    plot.XLabel("時間：每次取2048筆量測值，間隔約2秒");
                    break;
            }
        }

        private void radioButton_Instant_CheckedChanged(object sender, EventArgs e)
        {
            ModeChange(ModeName.Instant);
        }

        private void radioButton_Streaming_CheckedChanged(object sender, EventArgs e)
        {
            ModeChange(ModeName.Streaming);
        }

        private void Reset()
        {
            _instantPlot_Measure.Clear();
            _plotKalman.Clear();
            _plotLpf1_1.Clear();
            _plotLpf2_1.Clear();
            _plotLpf2_2.Clear();
            formsPlot1.Refresh();

            _totalData = 0;
            _timeTick = 0.0;
            _instantData_Time = new double[MAX_DATA];
            _instantData_Measure = new double[MAX_DATA];
            _instantData_Kalman = new double[MAX_DATA];
            _instantData_Lpf1_1 = new double[MAX_DATA];
            _instantData_Lpf2_1 = new double[MAX_DATA];
            _instantData_Lpf2_2 = new double[MAX_DATA];

            // 量測值
            _dataScaled = new double[2048];
            _maxMeasure = double.MinValue;
            _minMeasure = double.MaxValue;
            _avgMeasure = 0.0;

            // Kalman
            _kVal = 0.0;
            _kValMax = double.MinValue;
            _kValMin = double.MaxValue;
            _kValAvg = 0.0;

            // 一階低通濾波
            _lpf1_1Val = 0.0;
            _lpf1_1ValMax = double.MinValue;
            _lpf1_1ValMin = double.MaxValue;
            _lpf1_1ValAvg = 0.0;

            // 二階低通濾波
            _lpf2_1Val = 0.0;
            _lpf2_1ValMax = double.MinValue;
            _lpf2_1ValMin = double.MaxValue;
            _lpf2_1ValAvg = 0.0;

            _lpf2_2Val = 0.0;
            _lpf2_2ValMax = double.MinValue;
            _lpf2_2ValMin = double.MaxValue;
            _lpf2_2ValAvg = 0.0;

#if DEBUG
            _stopwatch.Stop();
            curWatch = 0.0;
            maxWatch = double.MinValue;
            minWatch = double.MaxValue;
#endif
        }

        private void button_Start_Click(object sender, EventArgs e)
        {
            ErrorCode err = ErrorCode.ErrorUndefined;

            switch (_modeName)
            {
                case ModeName.Instant:
                    _timer.Start();
                    err = ErrorCode.Success;
                    break;

                case ModeName.Streaming:
                    err = _waveformAiCtrl.Prepare();
                    if (err == ErrorCode.Success)
                        err = _waveformAiCtrl.Start();

                    break;
            }

            if (err == ErrorCode.Success)
            {
                IsRunning = true;
                IsStopped = false;
                plotAxis.ContinuouslyAutoscale = true;
            }
        }

        private void button_Stop_Click(object sender, EventArgs e)
        {
            ErrorCode err = ErrorCode.ErrorUndefined;

            switch (_modeName)
            {
                case ModeName.Instant:
                    _timer.Stop();
                    err = ErrorCode.Success;
                    break;

                case ModeName.Streaming:
                    err = _waveformAiCtrl.Stop();
                    break;
            }

            IsRunning = false;
            IsStopped = true;
            plotAxis.ContinuouslyAutoscale = false;
        }

        private void button_Reset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        #endregion

        #region Common

        private void HandleError(ErrorCode err)
        {
            if ((err >= ErrorCode.ErrorHandleNotValid) && (err != ErrorCode.Success))
                MessageBox.Show(String.Concat("USB-4704異常！錯誤碼：", err.ToString()));
        }

        #endregion

        #region Instant Mode

        private void TimerElapsed(object sender, EventArgs e)
        {
            //if (_instantAiCtrl != null && _instantAiCtrl.State == ControlState.Running)
            {
#if DEBUG
                _stopwatch.Reset();
                _stopwatch.Start();
#endif

                var err = _instantAiCtrl.Read(channel, 1, _dataScaled);
                if (err == ErrorCode.Success)
                {
                    //if (_axisTime.Count >= MAX_DATA)
                    //{
                    //    _axisTime.RemoveAt(0);
                    //    _axisMeasure.RemoveAt(0);
                    //    _axisKalman.RemoveAt(0);
                    //    _axisLowPass1_1.RemoveAt(0);
                    //}

                    _timeTick = Math.Round(_timeTick + 0.1, 1);
                    _instantData_Time[_totalData] = _timeTick;
                    //_axisTime.Add(_timeTick);

                    double measure = _dataScaled[0];
                    if (measure > _maxMeasure) _maxMeasure = measure;
                    if (measure < _minMeasure) _minMeasure = measure;
                    _avgMeasure = measure * 0.7 + _avgMeasure * 0.3;
                    _instantData_Measure[_totalData] = measure;
                    //_axisMeasure.Add(measure);

                    // Kalman
                    _kVal = _filterKalman.Filter(measure, 0.0);
                    //_avgKVal = _kVal * 0.7 + _avgKVal * 0.3;
                    //if (_kVal > _maxKVal) _maxKVal = _kVal;
                    //if (_kVal < _minKVal) _minKVal = _kVal;
                    //_axisKalman.Add(_kVal);

                    // Low Pass 1
                    _lpf1_1Val = _filterLowPass.LPF1_1(measure);
                    _lpf2_1Val = FilterLowPass.LPF2_1(measure);
                    _lpf2_2Val = FilterLowPass.LPF2_2(measure);

                    // 繪圖
                    _instantPlot_Measure.Add(Math.Round(measure, 3));
                    _plotKalman.Add(Math.Round(_kVal, 3));
                    _plotLpf1_1.Add(Math.Round(_lpf1_1Val, 3));
                    _plotLpf2_1.Add(Math.Round(_lpf2_1Val, 3));
                    _plotLpf2_2.Add(Math.Round(_lpf2_2Val, 3));

                    formsPlot1.Refresh();

#if DEBUG
                    _stopwatch.Stop();
                    curWatch = _stopwatch.Elapsed.TotalMilliseconds;
                    if (maxWatch < curWatch)
                        maxWatch = curWatch;
                    if (minWatch > curWatch)
                        minWatch = curWatch;
#endif

                    _totalData++;
                    _timeTick += TIMER_TICK / 1000.0;

                    // 文字
                    label_Measure.Text = String.Concat("取值: ", measure.ToString());

#if DEBUG
                    label_adjMeasure.Text = String.Concat("Stopwatch: ", curWatch.ToString("0.000"));
                    label_MaxMeasure.Text = String.Concat("最大: ", maxWatch.ToString("0.000"));
                    label_MinMeasure.Text = String.Concat("最小: ", minWatch.ToString("0.000"));
#endif
                }
                else
                {
                    HandleError(err);
                    _timer.Stop();
                }
            }
        }

        #endregion

        #region Streaming Mode

        /********************
         * USB-4704 Buffer事件
         * 注意：Overrun 和 CacheOverflow 事件表示資料收集過程中發生了資料遺失（可能存在資料錯位或不連續的情況）。
         * 強烈建議在應用程式中持續監控這些事件。遺失這些事件通知可能會導致您誤解採集狀態。
         ********************/
        /********************
         * 注意：        
         * 1. 不建議在此函數中處理或列印過多訊息，容易造成事件阻塞。        
         * 2. 理論上，DataReady 傳回的資料量 argsCount 應該等於 sectionLen * channelCount。
         * 然而，實際上，dataReady 回呼函數的執行時間也會受到系統負載的影響，
         * 因此無法保證每次 DataReady 傳回的資料量 argsCount 等於 sectionLen * channelCount。
         ********************/
        private void _waveformAiCtrl_DataReady(object sender, BfdAiEventArgs args)
        {
            try
            {
#if DEBUG
                _stopwatch.Reset();
                _stopwatch.Start();
#endif

                //The WaveformAiCtrl has been disposed.
                if (_waveformAiCtrl.State == ControlState.Idle)
                    return;

                if (_dataScaled.Length < args.Count)
                    _dataScaled = new double[args.Count];

                ErrorCode err = ErrorCode.Success;
                //int chanCount = _waveformAiCtrl.Conversion.ChannelCount;
                //int sectionLength = _waveformAiCtrl.Record.SectionLength;
                err = _waveformAiCtrl.GetData(args.Count, _dataScaled);
                if (err != ErrorCode.Success && err != ErrorCode.WarningRecordEnd)
                {
                    HandleError(err);
                    return;
                }

                _timeTick = Math.Round(_timeTick + 0.1, 1);
                _instantData_Time[_totalData] = _timeTick;
                //_axisTime.Add(_timeTick);

                Task.Run(() =>
                {
                    foreach (var data in _dataScaled)
                    {
                        double measure = data;
                        if (measure > _maxMeasure) _maxMeasure = measure;
                        if (measure < _minMeasure) _minMeasure = measure;
                        _avgMeasure = measure * 0.7 + _avgMeasure * 0.3;
                        //_dataMeasure[_tickCounter] = measure;
                        //_axisMeasure.Add(measure);

                        // Kalman
                        _kVal = _filterKalman.Filter(data, 0.0);
                        //_avgKVal = _kVal * 0.7 + _avgKVal * 0.3;
                        //if (_kVal > _maxKVal) _maxKVal = _kVal;
                        //if (_kVal < _minKVal) _minKVal = _kVal;

                        // Low Pass 1
                        _lpf1_1Val = _filterLowPass.LPF1_1(data);
                        _lpf2_1Val = FilterLowPass.LPF2_1(data);
                        _lpf2_2Val = FilterLowPass.LPF2_2(data);

#if DEBUG
                        _stopwatch.Stop();
                        curWatch = _stopwatch.Elapsed.TotalMilliseconds;
                        if (maxWatch < curWatch)
                            maxWatch = curWatch;
                        if (minWatch > curWatch)
                            minWatch = curWatch;
#endif

                        // 繪圖
                        //formsPlot1.Plot.Add.Signal(_dataMeasure);

                        _instantPlot_Measure.Add(Math.Round(measure, 3));
                        _plotKalman.Add(Math.Round(_kVal, 3));
                        _plotLpf1_1.Add(Math.Round(_lpf1_1Val, 3));
                        _plotLpf2_1.Add(Math.Round(_lpf2_1Val, 3));
                        _plotLpf2_2.Add(Math.Round(_lpf2_2Val, 3));
                    }

                    formsPlot1.InvokeIfRequired(() =>
                    {
                        formsPlot1.Refresh();

#if DEBUG
                        label_adjMeasure.Text = String.Concat("Stopwatch: ", curWatch.ToString("0.000"));
                        label_MaxMeasure.Text = String.Concat("最大: ", maxWatch.ToString("0.000"));
                        label_MinMeasure.Text = String.Concat("最小: ", minWatch.ToString("0.000"));
#endif
                    });
                });
            }
            catch (System.Exception) { }
        }

        private void _waveformAiCtrl_Overrun(object sender, BfdAiEventArgs e)
        {
            MessageBox.Show("WaveformAiCacheOverflow");
            // Please consider if it's necessary to stop the application in your application when this event is triggered.
            // waveformAiCtrl1->Stop();
        }

        private void _waveformAiCtrl_CacheOverflow(object sender, BfdAiEventArgs e)
        {
            if (_isFirstOverRun)
            {
                MessageBox.Show("WaveformAiOverrun");
                _isFirstOverRun = false;
            }
            // Please consider if it's necessary to stop the application in your application when this event is triggered.
            // waveformAiCtrl1->Stop();
        }

        #endregion

        #region other

        public event PropertyChangedEventHandler PropertyChanged;

        internal void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            if (Application.OpenForms.Count > 0)
            {
                var form = Application.OpenForms[0];
                if (form.InvokeRequired)
                {
                    form.Invoke(new Action(() =>
                    {
                        if (PropertyChanged != null)
                            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                    }));
                }
                else
                {
                    if (PropertyChanged != null)
                        PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                }
            }
        }

        #endregion

        private void numericUpDown_KalmanR_ValueChanged(object sender, EventArgs e)
        {
            if (_filterKalman != null)
                _filterKalman.SetProcessNoise((double)numericUpDown_KalmanR.Value);
        }

        private void numericUpDown_KalmanQ_ValueChanged(object sender, EventArgs e)
        {
            if (_filterKalman != null)
                _filterKalman.SetMeasurementNoise((double)numericUpDown_KalmanQ.Value);
        }

        private void checkBox_Kalman_CheckedChanged(object sender, EventArgs e)
        {
            _plotKalman.IsVisible = checkBox_Kalman.Checked;
        }

        private void checkBox_LPF1_1_CheckedChanged(object sender, EventArgs e)
        {
            _plotLpf1_1.IsVisible = checkBox_LPF1_1.Checked;
        }

        private void checkBox_LPF2_1_CheckedChanged(object sender, EventArgs e)
        {
            _plotLpf2_1.IsVisible = checkBox_LPF2_1.Checked;
        }

        private void checkBox_LPF2_2_CheckedChanged(object sender, EventArgs e)
        {
            _plotLpf2_2.IsVisible = checkBox_LPF2_2.Checked;
        }
    }
}
