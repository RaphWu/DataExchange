﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Automation.BDaq;
using Calin.Filter;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {
        bool _isFirstOverRun = true;
        double _streamingPlotTimeMark;

        int _streamingTotalData;
        double[] _streamingPlotDataScaled;
        List<double> _streamingPlotData_Time;
        List<double> _streamingPlotData_Timestamp;
        List<double> _streamingPlotData_Measure;
        List<double> _streamingPlotData_Kalman;
        List<double> _streamingPlotData_Lpf1_1;
        List<double> _streamingPlotData_Lpf2_1;
        List<double> _streamingPlotData_Lpf2_2;

        int _stramingTriggerTimes;

        /********************
         * USB-4704 Buffer事件
         * 注意：Overrun 和 CacheOverflow 事件表示資料收集過程中發生了資料遺失（可能存在資料錯位或不連續的情況）。
         * 強烈建議在應用程式中持續監控這些事件。遺失這些事件通知可能會導致您誤解採集狀態。
         ********************/
        /********************
         * 注意：        
         * 1. 不建議在此函數中處理或列印過多訊息，容易造成事件阻塞。        
         * 2. 理論上，DataReady 傳回的資料量 argsCount 應該等於 sectionLen * channelCount。
         * 然而，實際上，dataReady 回呼函數的執行時間也會受到系統負載的影響，
         * 因此無法保證每次 DataReady 傳回的資料量 argsCount 等於 sectionLen * channelCount。
         ********************/

        Stopwatch _streamingStopwatch = new Stopwatch();

        private void _waveformAiCtrl_DataReady(object sender, BfdAiEventArgs args)
        {
            try
            {
                if (_modeName == ModeName.Buffer)
                    return;

                if (_waveformAiCtrl.State == ControlState.Idle)
                    return;

                if (_streamingPlotDataScaled.Length < args.Count)
                    _streamingPlotDataScaled = new double[args.Count];
                _streamingTotalData += args.Count;

                ErrorCode err = ErrorCode.Success;
                err = _waveformAiCtrl.GetData(args.Count, _streamingPlotDataScaled);
                if (err != ErrorCode.Success && err != ErrorCode.WarningRecordEnd)
                {
                    HandleError(err);
                    return;
                }

                _streamingPlotData_Timestamp.Add(_streamingStopwatch.Elapsed.TotalSeconds);
                foreach (var data in _streamingPlotDataScaled)
                {
                    _streamingPlotData_Measure.Add(Math.Round(data, 3));
                    _streamingPlotData_Kalman.Add(Math.Round(_filterKalman.Filter(data, 0.0), 3));
                    _streamingPlotData_Lpf1_1.Add(Math.Round(FilterLowPass.LPF1_1(data, CutoffFreq, ClockRate), 3));
                    _streamingPlotData_Lpf2_1.Add(Math.Round(FilterLowPass.LPF2_1(data, CutoffFreq, ClockRate), 3));
                    _streamingPlotData_Lpf2_2.Add(Math.Round(FilterLowPass.LPF2_2(data, CutoffFreq, ClockRate), 3));
                }

                if (++TotalTriggerTimes >= _stramingTriggerTimes)
                {
                    _streamingStopwatch.Stop();
                    _waveformAiCtrl.Stop();

                    _streamingPlotTimeMark = _streamingStopwatch.Elapsed.TotalMilliseconds;
                    double timeInterval = _streamingPlotTimeMark / _streamingTotalData;
                    double mark = 0.0;
                    for (int i = 0; i < _streamingTotalData; i++)
                    {
                        _streamingPlotData_Time.Add(Math.Round(mark / 1000.0, 3));
                        mark += timeInterval;
                    }

                    UpdateScreen();
                    return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
