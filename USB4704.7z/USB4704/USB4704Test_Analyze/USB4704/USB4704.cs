﻿using System;
using System.Windows.Forms;
using Automation.BDaq;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {

        private void numericUpDown_ClockRate_ValueChanged(object sender, EventArgs e)
        {
            var control = sender as NumericUpDown;
            ClockRate = (double)control.Value;
        }

        private void numericUpDown_ClockRate2_ValueChanged(object sender, EventArgs e)
        {
            var control = sender as NumericUpDown;
            ClockRate = (double)control.Value;
        }

        private void numericUpDown_TimerTick_ValueChanged(object sender, EventArgs e)
        {
            var control = sender as NumericUpDown;
            TimerTick = (int)control.Value;
            //ModeSelect(_modeName);
        }

        private void numericUpDown_TimerTick2_ValueChanged(object sender, EventArgs e)
        {
            var control = sender as NumericUpDown;
            TimerTick = (int)control.Value;
            //ModeSelect(_modeName);
        }

        private void numericUpDown_TimeToStop_ValueChanged(object sender, EventArgs e)
        {
            var control = sender as NumericUpDown;
            TimeToStop = (int)control.Value;
            //ModeSelect(_modeName);
        }

        private void numericUpDown_TotalTriggerTimes_ValueChanged(object sender, EventArgs e)
        {
            var control = sender as NumericUpDown;
            TotalTriggerTimes = (int)control.Value;
            ModeSelect(_modeName);
        }

        private void comboBox_SectionLength_SelectedIndexChanged(object sender, EventArgs e)
        {
            var control = sender as ComboBox;
            SectionLengthString = control.SelectedItem.ToString();
            ModeSelect(_modeName);
        }

        /**************************************/

        private void HandleError(ErrorCode err)
        {
            if ((err >= ErrorCode.ErrorHandleNotValid) && (err != ErrorCode.Success))
                MessageBox.Show(String.Concat("USB-4704異常！錯誤碼：", err.ToString("0.000")));
        }

        private void _waveformAiCtrl_Overrun(object sender, BfdAiEventArgs e)
        {
            MessageBox.Show("WaveformAiCacheOverflow");
            //_waveformAiCtrl.Stop();
        }

        private void _waveformAiCtrl_CacheOverflow(object sender, BfdAiEventArgs e)
        {
            if (_isFirstOverRun)
            {
                MessageBox.Show("WaveformAiOverrun");
                _isFirstOverRun = false;
            }
            //_waveformAiCtrl.Stop();
        }
    }
}
