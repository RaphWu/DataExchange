﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Automation.BDaq;
using Calin.Filter;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {
        double _instantPlotTimeMark;

        int _instantTotalData;
        double[] _instantPlotDataScaled;
        List<double> _instantPlotData_Time;
        List<double> _instantPlotData_Timestamp;
        List<double> _instantPlotData_Measure;
        List<double> _instantPlotData_Kalman;
        List<double> _instantPlotData_Lpf1_1;
        List<double> _instantPlotData_Lpf2_1;
        List<double> _instantPlotData_Lpf2_2;

        Stopwatch _instantStopwatch = new Stopwatch();

        private void InstantTimerElapsed(object sender, EventArgs e)
        {
            if (_instantStopwatch.Elapsed.TotalSeconds >= TimeToStop)
            {
                _instantStopwatch.Stop();
                _commonTimer.Stop();
                _commonTimer.Elapsed -= InstantTimerElapsed;

                _instantPlotTimeMark -= TimerTickSecond;
                double timeGap = Convert.ToDouble(TimeToStop) / Convert.ToDouble(_instantTotalData);
                double timeMark = 0.0;

                for (int i = 0; i < _instantTotalData; i++)
                {
                    _instantPlotData_Time.Add(Math.Round(timeMark, 3));
                    _instantPlotData_Kalman.Add(Math.Round(_filterKalman.Filter(_instantPlotData_Measure[i], 0.0), 3));
                    _instantPlotData_Lpf1_1.Add(Math.Round(FilterLowPass.LPF1_1(_instantPlotData_Measure[i], CutoffFreq, ClockRate), 3));
                    _instantPlotData_Lpf2_1.Add(Math.Round(FilterLowPass.LPF2_1(_instantPlotData_Measure[i], CutoffFreq, ClockRate), 3));
                    _instantPlotData_Lpf2_2.Add(Math.Round(FilterLowPass.LPF2_2(_instantPlotData_Measure[i], CutoffFreq, ClockRate), 3));
                    _instantPlotData_Measure[i] = Math.Round(_instantPlotData_Measure[i], 3);
                    timeMark += timeGap;
                }
                _instantPlotData_Time[_instantTotalData - 1] = TimeToStop;

                UpdateScreen();
                return;
            }

            if (_plotAiCtrl != null)
            {
                var err = _plotAiCtrl.Read(channel, 1, _instantPlotDataScaled);
                if (err == ErrorCode.Success)
                {
                    _instantPlotData_Timestamp.Add(_instantStopwatch.Elapsed.TotalSeconds);
                    _instantPlotData_Measure.Add(_instantPlotDataScaled[0]);
                    _instantTotalData++;
                    _instantPlotTimeMark += TimerTickSecond;
                }
                else
                {
                    _commonTimer.Stop();
                    HandleError(err);
                    UpdateScreen();
                }
            }
        }
    }
}
