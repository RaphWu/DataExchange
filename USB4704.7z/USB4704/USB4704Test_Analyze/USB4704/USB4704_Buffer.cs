﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Automation.BDaq;
using Calin.Filter;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {
        double _bufferPlotTimeMark;

        int _bufferTotalData;
        double[] _bufferPlotDataScaled;
        List<double> _bufferPlotData_Time;
        List<double> _bufferPlotData_Timestamp;
        List<double> _bufferPlotData_Measure;
        List<double> _bufferPlotData_Kalman;
        List<double> _bufferPlotData_Lpf1_1;
        List<double> _bufferPlotData_Lpf2_1;
        List<double> _bufferPlotData_Lpf2_2;

        int _bufferTriggerTimes;

        Stopwatch _bufferStopwatch = new Stopwatch();

        private void BufferTimerElapsed(object sender, EventArgs e)
        {
            try
            {
                if (_modeName == ModeName.Streaming)
                    return;

                if (_waveformAiCtrl.State == ControlState.Idle)
                    return;

                ErrorCode err = ErrorCode.Success;
                _waveformAiCtrl.Prepare();
                err = _waveformAiCtrl.Start();
                if (err == ErrorCode.Success)
                {
                    int returnValue = 0;
                    err = _waveformAiCtrl.GetData(SectionLength, _bufferPlotDataScaled, -1, out returnValue);
                }
                if (err != ErrorCode.Success && err != ErrorCode.WarningRecordEnd)
                {
                    HandleError(err);
                    return;
                }

                _waveformAiCtrl.Release();
                _bufferTotalData += _bufferPlotDataScaled.Length;

                _bufferPlotData_Timestamp.Add(_bufferStopwatch.Elapsed.TotalSeconds);
                foreach (var data in _bufferPlotDataScaled)
                {
                    _bufferPlotData_Measure.Add(Math.Round(data, 3));
                    _bufferPlotData_Kalman.Add(Math.Round(_filterKalman.Filter(data, 0.0), 3));
                    _bufferPlotData_Lpf1_1.Add(Math.Round(FilterLowPass.LPF1_1(data, CutoffFreq, ClockRate), 3));
                    _bufferPlotData_Lpf2_1.Add(Math.Round(FilterLowPass.LPF2_1(data, CutoffFreq, ClockRate), 3));
                    _bufferPlotData_Lpf2_2.Add(Math.Round(FilterLowPass.LPF2_2(data, CutoffFreq, ClockRate), 3));
                }

                if (++TotalTriggerTimes >= _bufferTriggerTimes)
                {
                    _bufferStopwatch.Stop();
                    _commonTimer.Stop();
                    _commonTimer.Elapsed -= BufferTimerElapsed;
                    _waveformAiCtrl.Stop();

                    _bufferPlotTimeMark = _bufferStopwatch.Elapsed.TotalMilliseconds;
                    double timeInterval = _bufferPlotTimeMark / _bufferTotalData;
                    double mark = 0.0;
                    for (int i = 0; i < _bufferTotalData; i++)
                    {
                        _bufferPlotData_Time.Add(Math.Round(mark / 1000.0, 3));
                        mark += timeInterval;
                    }

                    UpdateScreen();
                    return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
