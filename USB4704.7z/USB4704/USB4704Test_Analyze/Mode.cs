﻿using System;
using System.Collections.Generic;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {
        private enum ModeName
        {
            Instant,
            Streaming,
            Buffer,
        }

        private void Reset(bool resetAll = false)
        {
            if (_modeName == ModeName.Instant || resetAll)
            {
                _instantTotalData = 0;
                _instantPlotTimeMark = 0.0;

                _instantPlotDataScaled = new double[1];
                _instantPlotData_Time = new List<double>();
                _instantPlotData_Timestamp = new List<double>();
                _instantPlotData_Measure = new List<double>();
                _instantPlotData_Kalman = new List<double>();
                _instantPlotData_Lpf1_1 = new List<double>();
                _instantPlotData_Lpf2_1 = new List<double>();
                _instantPlotData_Lpf2_2 = new List<double>();
            }

            if (_modeName == ModeName.Streaming || resetAll)
            {
                _streamingTotalData = 0;

                _streamingPlotDataScaled = new double[2048];
                _streamingPlotData_Time = new List<double>();
                _streamingPlotData_Timestamp = new List<double>();
                _streamingPlotData_Measure = new List<double>();
                _streamingPlotData_Kalman = new List<double>();
                _streamingPlotData_Lpf1_1 = new List<double>();
                _streamingPlotData_Lpf2_1 = new List<double>();
                _streamingPlotData_Lpf2_2 = new List<double>();
            }

            if (_modeName == ModeName.Buffer || resetAll)
            {
                _bufferTotalData = 0;

                _bufferPlotDataScaled = new double[SectionLength];
                _bufferPlotData_Time = new List<double>();
                _bufferPlotData_Timestamp = new List<double>();
                _bufferPlotData_Measure = new List<double>();
                _bufferPlotData_Kalman = new List<double>();
                _bufferPlotData_Lpf1_1 = new List<double>();
                _bufferPlotData_Lpf2_1 = new List<double>();
                _bufferPlotData_Lpf2_2 = new List<double>();
            }

            formsPlot_Measure.Update();
            formsPlot_Measure.Refresh();
            UpdateScreen();
        }

        private void ModeSelect(ModeName modeName)
        {
            _modeName = modeName;
            switch (_modeName)
            {
                case ModeName.Instant:
                    if (_waveformAiCtrl != null)
                        _waveformAiCtrl.Stop();
                    groupBox_InstantParams.Visible = true;
                    groupBox_StreamingParams.Visible = false;
                    groupBox_Buffer.Visible = false;
                    break;

                case ModeName.Streaming:
                    //_waveformAiCtrl.LoadProfile("USB4704.xml");
                    //_waveformAiCtrl.Conversion.ClockRate = ClockRate;
                    groupBox_InstantParams.Visible = false;
                    groupBox_StreamingParams.Visible = true;
                    groupBox_Buffer.Visible = false;
                    break;

                case ModeName.Buffer:
                    //_waveformAiCtrl.Conversion.ClockRate = ClockRate;
                    _waveformAiCtrl.Prepare();

                    groupBox_InstantParams.Visible = false;
                    groupBox_StreamingParams.Visible = false;
                    groupBox_Buffer.Visible = true;
                    break;
            }

            UpdateScreen();
        }

        private void radioButton_Instant_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_Instant.Checked)
                ModeSelect(ModeName.Instant);
        }

        private void radioButton_Streaming_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_Streaming.Checked)
                ModeSelect(ModeName.Streaming);
        }

        private void radioButton_Buffer_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_Buffer.Checked)
                ModeSelect(ModeName.Buffer);
        }
    }
}
