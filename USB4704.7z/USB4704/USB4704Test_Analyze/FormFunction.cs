﻿using Automation.BDaq;
using Calin.WinForm;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {
        private void Start()
        {
            tabControl_View.SelectedTab = tabPage_MeasureData;

            Reset();
            IsRunning = true;
            IsStopped = false;

            switch (_modeName)
            {
                case ModeName.Instant:
                    _commonTimer.Elapsed += InstantTimerElapsed;
                    _commonTimer.Start();
                    _instantStopwatch.Reset();
                    _instantStopwatch.Start();
                    break;

                case ModeName.Streaming:
                    TotalTriggerTimes = 0;
                    _stramingTriggerTimes = (int)numericUpDown_StramingTriggerTimes.Value;
                    _streamingStopwatch.Restart();
                    _streamingStopwatch.Start();
                    _waveformAiCtrl.Start();
                    break;

                case ModeName.Buffer:
                    TotalTriggerTimes = 0;
                    _bufferTriggerTimes = (int)numericUpDown_BufferTriggerTimes.Value;
                    _commonTimer.Elapsed += BufferTimerElapsed;
                    _commonTimer.Start();
                    _bufferStopwatch.Start();
                    //_waveformAiCtrl.Start();
                    break;
            }
        }

        private void StopAllRunner()
        {
            if (_waveformAiCtrl.State == ControlState.Running)
                _waveformAiCtrl.Stop();

            if (_instantStopwatch.IsRunning)
                _instantStopwatch.Stop();

            if (_streamingStopwatch.IsRunning)
                _streamingStopwatch.Stop();

            if (_bufferStopwatch.IsRunning)
                _bufferStopwatch.Stop();

            if (_commonTimer.IsRunning)
                _commonTimer.Stop();
        }

        private void UpdateScreen()
        {
            formsPlot_Measure.InvokeIfRequired(() =>
            {
                switch (_modeName)
                {
                    case ModeName.Instant:
                        if (_instantPlotData_Time.Count == 0)
                            break;

                        double[] instantData_Time = new double[_instantTotalData];
                        double[] instantData_Measure = new double[_instantTotalData];
                        double[] instantData_Kalman = new double[_instantTotalData];
                        double[] instantData_Lpf1_1 = new double[_instantTotalData];
                        double[] instantData_Lpf2_1 = new double[_instantTotalData];
                        double[] instantData_Lpf2_2 = new double[_instantTotalData];

                        _instantPlotData_Time.CopyTo(0, instantData_Time, 0, _instantTotalData);
                        _instantPlotData_Measure.CopyTo(0, instantData_Measure, 0, _instantTotalData);
                        _instantPlotData_Kalman.CopyTo(0, instantData_Kalman, 0, _instantTotalData);
                        _instantPlotData_Lpf1_1.CopyTo(0, instantData_Lpf1_1, 0, _instantTotalData);
                        _instantPlotData_Lpf2_1.CopyTo(0, instantData_Lpf2_1, 0, _instantTotalData);
                        _instantPlotData_Lpf2_2.CopyTo(0, instantData_Lpf2_2, 0, _instantTotalData);

                        _plot.Clear();
                        _instantPlot_Measure = _plot.Add.SignalXY(instantData_Time, instantData_Measure);
                        _instantPlot_Kalman = _plot.Add.SignalXY(instantData_Time, instantData_Kalman);
                        _instantPlot_Lpf1_1 = _plot.Add.SignalXY(instantData_Time, instantData_Lpf1_1);
                        _instantPlot_Lpf2_1 = _plot.Add.SignalXY(instantData_Time, instantData_Lpf2_1);
                        _instantPlot_Lpf2_2 = _plot.Add.SignalXY(instantData_Time, instantData_Lpf2_2);

                        _instantPlot_Measure.LegendText = PLOT_NAME_MEASURE;
                        _instantPlotList.Add(_instantPlot_Measure);
                        _instantPlot_Kalman.LegendText = PLOT_NAME_KALMAN;
                        _instantPlotList.Add(_instantPlot_Kalman);
                        _instantPlot_Lpf1_1.LegendText = PLOT_NAME_LPF1_1;
                        _instantPlotList.Add(_instantPlot_Lpf1_1);
                        _instantPlot_Lpf2_1.LegendText = PLOT_NAME_LPF2_1;
                        _instantPlotList.Add(_instantPlot_Lpf2_1);
                        _instantPlot_Lpf2_2.LegendText = PLOT_NAME_LPF2_2;
                        _instantPlotList.Add(_instantPlot_Lpf2_2);

                        _plot.XLabel($"時間：每筆量測值取值間隔 {_timerTick} ms");
                        label_TotalTime.Text = $"總計耗時: {_instantStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_TotalData.Text = $"數據筆數: {_instantTotalData} 筆";
                        label_TimePerRecord.Text = $"每筆耗時: {_instantStopwatch.Elapsed.TotalMilliseconds / _instantTotalData:F3} ms";

                        label_ActualTime.Text = $"資料時間: {_instantPlotTimeMark:F3} 秒";

                        label_ActualTime.Visible = true;
                        label_TriggerTimes.Visible = false;
                        label_TimeConsumingMax.Visible = false;
                        label_TimeConsumingMin.Visible = false;
                        label_TimeConsumingAvg.Visible = false;

                        break;

                    case ModeName.Streaming:
                        if (_streamingPlotData_Time.Count == 0)
                            break;

                        double[] streamingData_Time = new double[_streamingTotalData];
                        double[] streamingData_Measure = new double[_streamingTotalData];
                        double[] streamingData_Kalman = new double[_streamingTotalData];
                        double[] streamingData_Lpf1_1 = new double[_streamingTotalData];
                        double[] streamingData_Lpf2_1 = new double[_streamingTotalData];
                        double[] streamingData_Lpf2_2 = new double[_streamingTotalData];

                        _streamingPlotData_Time.CopyTo(0, streamingData_Time, 0, _streamingTotalData);
                        _streamingPlotData_Measure.CopyTo(0, streamingData_Measure, 0, _streamingTotalData);
                        _streamingPlotData_Kalman.CopyTo(0, streamingData_Kalman, 0, _streamingTotalData);
                        _streamingPlotData_Lpf1_1.CopyTo(0, streamingData_Lpf1_1, 0, _streamingTotalData);
                        _streamingPlotData_Lpf2_1.CopyTo(0, streamingData_Lpf2_1, 0, _streamingTotalData);
                        _streamingPlotData_Lpf2_2.CopyTo(0, streamingData_Lpf2_2, 0, _streamingTotalData);

                        _plot.Clear();
                        _streamingPlot_Measure = _plot.Add.SignalXY(streamingData_Time, streamingData_Measure);
                        _streamingPlot_Kalman = _plot.Add.SignalXY(streamingData_Time, streamingData_Kalman);
                        _streamingPlot_Lpf1_1 = _plot.Add.SignalXY(streamingData_Time, streamingData_Lpf1_1);
                        _streamingPlot_Lpf2_1 = _plot.Add.SignalXY(streamingData_Time, streamingData_Lpf2_1);
                        _streamingPlot_Lpf2_2 = _plot.Add.SignalXY(streamingData_Time, streamingData_Lpf2_2);

                        _streamingPlot_Measure.LegendText = PLOT_NAME_MEASURE;
                        _streamingPlotList.Add(_streamingPlot_Measure);
                        _streamingPlot_Kalman.LegendText = PLOT_NAME_KALMAN;
                        _streamingPlotList.Add(_streamingPlot_Kalman);
                        _streamingPlot_Lpf1_1.LegendText = PLOT_NAME_LPF1_1;
                        _streamingPlotList.Add(_streamingPlot_Lpf1_1);
                        _streamingPlot_Lpf2_1.LegendText = PLOT_NAME_LPF2_1;
                        _streamingPlotList.Add(_streamingPlot_Lpf2_1);
                        _streamingPlot_Lpf2_2.LegendText = PLOT_NAME_LPF2_2;
                        _streamingPlotList.Add(_streamingPlot_Lpf2_2);

                        _plot.XLabel("時間：每次取2048筆量測值");
                        label_TotalTime.Text = $"總計耗時: {_streamingStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_ActualTime.Text = $"資料時間: {_streamingPlotTimeMark:F3} 秒";
                        label_TimeConsumingMax.Text = $"每段耗時: {_streamingStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_TotalData.Text = $"數據筆數: {_streamingTotalData} 筆";
                        label_TimePerRecord.Text = $"每筆耗時: {_streamingStopwatch.Elapsed.TotalMilliseconds / _streamingTotalData:F3} ms";

                        label_TriggerTimes.Text = $"觸發次數: {TotalTriggerTimes} 次";
                        label_TimeConsumingMax.Text = $"最大耗時: {_streamingStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_TimeConsumingMin.Text = $"最小耗時: {_streamingStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_TimeConsumingAvg.Text = $"平均耗時: {_streamingStopwatch.Elapsed.TotalSeconds:F3} 秒";

                        label_ActualTime.Visible = false;
                        label_TriggerTimes.Visible = true;
                        label_TimeConsumingMax.Visible = false;
                        label_TimeConsumingMin.Visible = false;
                        label_TimeConsumingAvg.Visible = false;

                        break;

                    case ModeName.Buffer:
                        if (_bufferPlotData_Time.Count == 0)
                            break;

                        double[] bufferData_Time = new double[_bufferTotalData];
                        double[] bufferData_Measure = new double[_bufferTotalData];
                        double[] bufferData_Kalman = new double[_bufferTotalData];
                        double[] bufferData_Lpf1_1 = new double[_bufferTotalData];
                        double[] bufferData_Lpf2_1 = new double[_bufferTotalData];
                        double[] bufferData_Lpf2_2 = new double[_bufferTotalData];

                        _bufferPlotData_Time.CopyTo(0, bufferData_Time, 0, _bufferTotalData);
                        _bufferPlotData_Measure.CopyTo(0, bufferData_Measure, 0, _bufferTotalData);
                        _bufferPlotData_Kalman.CopyTo(0, bufferData_Kalman, 0, _bufferTotalData);
                        _bufferPlotData_Lpf1_1.CopyTo(0, bufferData_Lpf1_1, 0, _bufferTotalData);
                        _bufferPlotData_Lpf2_1.CopyTo(0, bufferData_Lpf2_1, 0, _bufferTotalData);
                        _bufferPlotData_Lpf2_2.CopyTo(0, bufferData_Lpf2_2, 0, _bufferTotalData);

                        _plot.Clear();
                        _bufferPlot_Measure = _plot.Add.SignalXY(bufferData_Time, bufferData_Measure);
                        _bufferPlot_Kalman = _plot.Add.SignalXY(bufferData_Time, bufferData_Kalman);
                        _bufferPlot_Lpf1_1 = _plot.Add.SignalXY(bufferData_Time, bufferData_Lpf1_1);
                        _bufferPlot_Lpf2_1 = _plot.Add.SignalXY(bufferData_Time, bufferData_Lpf2_1);
                        _bufferPlot_Lpf2_2 = _plot.Add.SignalXY(bufferData_Time, bufferData_Lpf2_2);

                        _bufferPlot_Measure.LegendText = PLOT_NAME_MEASURE;
                        _bufferPlotList.Add(_bufferPlot_Measure);
                        _bufferPlot_Kalman.LegendText = PLOT_NAME_KALMAN;
                        _bufferPlotList.Add(_bufferPlot_Kalman);
                        _bufferPlot_Lpf1_1.LegendText = PLOT_NAME_LPF1_1;
                        _bufferPlotList.Add(_bufferPlot_Lpf1_1);
                        _bufferPlot_Lpf2_1.LegendText = PLOT_NAME_LPF2_1;
                        _bufferPlotList.Add(_bufferPlot_Lpf2_1);
                        _bufferPlot_Lpf2_2.LegendText = PLOT_NAME_LPF2_2;
                        _bufferPlotList.Add(_bufferPlot_Lpf2_2);

                        _plot.XLabel($"時間：每次取 {SectionLengthString} 組量測值");
                        label_TotalTime.Text = $"總計耗時: {_bufferStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_ActualTime.Text = $"資料時間: {_bufferPlotTimeMark:F3} 秒";
                        label_TimeConsumingMax.Text = $"每段耗時: {_bufferStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_TotalData.Text = $"數據筆數: {_bufferTotalData} 筆";
                        label_TimePerRecord.Text = $"每筆耗時: {_bufferStopwatch.Elapsed.TotalMilliseconds / _bufferTotalData:F3} ms";

                        label_TriggerTimes.Text = $"觸發次數: {TotalTriggerTimes} 次";
                        label_TimeConsumingMax.Text = $"最大耗時: {_bufferStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_TimeConsumingMin.Text = $"最小耗時: {_bufferStopwatch.Elapsed.TotalSeconds:F3} 秒";
                        label_TimeConsumingAvg.Text = $"平均耗時: {_bufferStopwatch.Elapsed.TotalSeconds:F3} 秒";

                        label_ActualTime.Visible = false;
                        label_TriggerTimes.Visible = true;
                        label_TimeConsumingMax.Visible = false;
                        label_TimeConsumingMin.Visible = false;
                        label_TimeConsumingAvg.Visible = false;

                        break;
                }

                formsPlot_Measure.Update();
                SetLegendVisible();
                _plotAxis.AutoScale();
                formsPlot_Measure.Refresh();
            });

            IsRunning = false;
            IsStopped = true;
        }
    }
}
