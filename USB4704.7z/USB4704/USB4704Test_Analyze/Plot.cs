﻿using System.Collections.Generic;
using ScottPlot;
using ScottPlot.Plottables;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {
        const int MAX_DATA = 1_024_000; // = 2048*500
        const string FONT_NAME = "微軟正黑體";
        const string PLOT_NAME_MEASURE = "量測數據";
        const string PLOT_NAME_KALMAN = "卡爾曼濾波";
        const string PLOT_NAME_LPF1_1 = "一階低通濾波";
        const string PLOT_NAME_LPF2_1 = "二階低通濾波2-1";
        const string PLOT_NAME_LPF2_2 = "二階低通濾波2-2";

        List<SignalXY> _instantPlotList = new List<SignalXY>();
        SignalXY _instantPlot_Measure;
        SignalXY _instantPlot_Kalman;
        SignalXY _instantPlot_Lpf1_1;
        SignalXY _instantPlot_Lpf2_1;
        SignalXY _instantPlot_Lpf2_2;

        List<SignalXY> _streamingPlotList = new List<SignalXY>();
        SignalXY _streamingPlot_Measure;
        SignalXY _streamingPlot_Kalman;
        SignalXY _streamingPlot_Lpf1_1;
        SignalXY _streamingPlot_Lpf2_1;
        SignalXY _streamingPlot_Lpf2_2;

        List<SignalXY> _bufferPlotList = new List<SignalXY>();
        SignalXY _bufferPlot_Measure;
        SignalXY _bufferPlot_Kalman;
        SignalXY _bufferPlot_Lpf1_1;
        SignalXY _bufferPlot_Lpf2_1;
        SignalXY _bufferPlot_Lpf2_2;

        Plot _plot;
        AxisManager _plotAxis;

        private void SetLegendVisible()
        {
            if (_instantPlot_Kalman != null)
                _instantPlot_Kalman.IsVisible = checkBox_Kalman.Checked;
            if (_streamingPlot_Kalman != null)
                _streamingPlot_Kalman.IsVisible = checkBox_Kalman.Checked;

            if (_instantPlot_Lpf1_1 != null)
                _instantPlot_Lpf1_1.IsVisible = checkBox_LPF1_1.Checked;
            if (_streamingPlot_Lpf1_1 != null)
                _streamingPlot_Lpf1_1.IsVisible = checkBox_LPF1_1.Checked;

            if (_instantPlot_Lpf2_1 != null)
                _instantPlot_Lpf2_1.IsVisible = checkBox_LPF2_1.Checked;
            if (_streamingPlot_Lpf2_1 != null)
                _streamingPlot_Lpf2_1.IsVisible = checkBox_LPF2_1.Checked;

            if (_instantPlot_Lpf2_2 != null)
                _instantPlot_Lpf2_2.IsVisible = checkBox_LPF2_2.Checked;
            if (_streamingPlot_Lpf2_2 != null)
                _streamingPlot_Lpf2_2.IsVisible = checkBox_LPF2_2.Checked;
        }
    }
}
