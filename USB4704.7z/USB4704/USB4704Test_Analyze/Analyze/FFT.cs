﻿using System;
using System.Collections.Generic;
using Calin.Calculate;
using ScottPlot;
using ScottPlot.Plottables;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {
        private void UpdateFFT()
        {
            List<double> fftArray = new List<double>();
            int requireNumbers;
            FilterType filterType;
            List<double> data = new List<double>();

            if (radioButton_FFT_Kalman.Checked)
                filterType = FilterType.Kalman;
            else if (radioButton_FFT_LPF1_1.Checked)
                filterType = FilterType.LPF1_1;
            else if (radioButton_FFT_LPF2_1.Checked)
                filterType = FilterType.LPF1_1;
            else if (radioButton_FFT_LPF2_2.Checked)
                filterType = FilterType.LPF2_2;
            else
                filterType = FilterType.None;

            switch (_modeName)
            {
                case ModeName.Instant:
                    switch (filterType)
                    {
                        case FilterType.None:
                            data = _instantPlotData_Measure;
                            break;
                        case FilterType.Kalman:
                            data = _instantPlotData_Kalman;
                            break;
                        case FilterType.LPF1_1:
                            data = _instantPlotData_Lpf1_1;
                            break;
                        case FilterType.LPF2_1:
                            data = _instantPlotData_Lpf2_1;
                            break;
                        case FilterType.LPF2_2:
                            data = _instantPlotData_Lpf2_2;
                            break;
                    }

                    if (data.Count == 0)
                        return;
                    requireNumbers = Round.RoundUpToPowerOf2(data.Count);
                    fftArray.AddRange(data);
                    fftArray.AddRange(new double[requireNumbers - data.Count]); // 補0
                    break;

                case ModeName.Streaming:
                    switch (filterType)
                    {
                        case FilterType.None:
                            data = _streamingPlotData_Measure;
                            break;
                        case FilterType.Kalman:
                            data = _streamingPlotData_Kalman;
                            break;
                        case FilterType.LPF1_1:
                            data = _streamingPlotData_Lpf1_1;
                            break;
                        case FilterType.LPF2_1:
                            data = _streamingPlotData_Lpf2_1;
                            break;
                        case FilterType.LPF2_2:
                            data = _streamingPlotData_Lpf2_2;
                            break;
                    }

                    if (data.Count == 0)
                        return;
                    requireNumbers = Round.RoundUpToPowerOf2(data.Count);
                    fftArray.AddRange(data);
                    fftArray.AddRange(new double[requireNumbers - data.Count]); // 補0
                    break;

                case ModeName.Buffer:
                    switch (filterType)
                    {
                        case FilterType.None:
                            data = _bufferPlotData_Measure;
                            break;
                        case FilterType.Kalman:
                            data = _bufferPlotData_Kalman;
                            break;
                        case FilterType.LPF1_1:
                            data = _bufferPlotData_Lpf1_1;
                            break;
                        case FilterType.LPF2_1:
                            data = _bufferPlotData_Lpf2_1;
                            break;
                        case FilterType.LPF2_2:
                            data = _bufferPlotData_Lpf2_2;
                            break;
                    }

                    if (data.Count == 0)
                        return;
                    requireNumbers = Round.RoundUpToPowerOf2(data.Count);
                    fftArray.AddRange(data);
                    fftArray.AddRange(new double[requireNumbers - data.Count]); // 補0
                    break;
            }

            tabControl_View.SelectedTab = tabPage_FFT;

            System.Numerics.Complex[] spectrum = FftSharp.FFT.Forward(fftArray.ToArray());
            double[] fft = FftSharp.FFT.Magnitude(spectrum);

            formsPlot_FFT.Plot.Clear();
            Scatter fftScatter = formsPlot_FFT.Plot.Add.Scatter(Generate.Consecutive(fft.Length), fft);
            fftScatter.LineWidth = 1;

            // Create a text label to place near the highlighted value
            Text MyHighlightText = formsPlot_FFT.Plot.Add.Text("", 0, 0);
            MyHighlightText.LabelAlignment = Alignment.LowerLeft;
            MyHighlightText.OffsetX = 7;
            MyHighlightText.OffsetY = -7;

            // Create a marker to highlight the point under the cursor
            Crosshair MyCrosshair = formsPlot_FFT.Plot.Add.Crosshair(0, 0);
            Marker MyHighlightMarker = formsPlot_FFT.Plot.Add.Marker(0, 0);
            MyHighlightMarker.Shape = MarkerShape.OpenCircle;
            MyHighlightMarker.Size = 17;
            MyHighlightMarker.LineWidth = 1;
            formsPlot_FFT.MouseMove += (s, fe) =>
            {
                // determine where the mouse is and get the nearest point
                Pixel mousePixel = new Pixel(fe.Location.X, fe.Location.Y);
                Coordinates mouseLocation = formsPlot_FFT.Plot.GetCoordinates(mousePixel);
                DataPoint nearest = fftScatter.Data.GetNearest(mouseLocation, formsPlot_FFT.Plot.LastRender);
                //DataPoint nearest = rbNearestXY.Checked
                //    ? fftScatter.Data.GetNearest(mouseLocation, formsPlot_FFT.Plot.LastRender)
                //    : fftScatter.Data.GetNearestX(mouseLocation, formsPlot_FFT.Plot.LastRender);


                // get the nearest point of each scatter
                Dictionary<int, DataPoint> nearestPoints = new Dictionary<int, DataPoint>();
                DataPoint nearestPoint = fftScatter.Data.GetNearest(mouseLocation, formsPlot_FFT.Plot.LastRender);
                nearestPoints.Add(0, nearestPoint);

                // determine which scatter's nearest point is nearest to the mouse
                bool pointSelected = false;
                int scatterIndex = -1;
                double smallestDistance = double.MaxValue;
                for (int i = 0; i < nearestPoints.Count; i++)
                {
                    if (nearestPoints[i].IsReal)
                    {
                        // calculate the distance of the point to the mouse
                        double distance = nearestPoints[i].Coordinates.Distance(mouseLocation);
                        if (distance < smallestDistance)
                        {
                            // store the index
                            scatterIndex = i;
                            pointSelected = true;
                            // update the smallest distance
                            smallestDistance = distance;
                        }
                    }
                }

                // place the crosshair, marker and text over the selected point
                if (pointSelected)
                {
                    DataPoint point = nearestPoints[scatterIndex];

                    MyCrosshair.IsVisible = true;
                    MyCrosshair.Position = point.Coordinates;
                    MyCrosshair.LineColor = fftScatter.MarkerStyle.FillColor;

                    MyHighlightMarker.IsVisible = true;
                    MyHighlightMarker.Location = point.Coordinates;
                    MyHighlightMarker.MarkerStyle.LineColor = fftScatter.MarkerStyle.FillColor;

                    MyHighlightText.IsVisible = true;
                    MyHighlightText.Location = point.Coordinates;
                    MyHighlightText.LabelText = $"{point.X:0.000}, {point.Y:0.000}";
                    MyHighlightText.LabelFontColor = fftScatter.MarkerStyle.FillColor;

                    base.Text = $"Index={point.Index}, X={point.X:0.000}, Y={point.Y:0.000}";
                }

                // hide the crosshair, marker and text when no point is selected
                if (!pointSelected && MyCrosshair.IsVisible)
                {
                    MyCrosshair.IsVisible = false;
                    MyHighlightMarker.IsVisible = false;
                    MyHighlightText.IsVisible = false;
                    base.Text = $"No point selected";
                }

                //// place the crosshair over the highlighted point
                //if (nearest.IsReal)
                //{
                //    MyCrosshair.IsVisible = true;
                //    MyCrosshair.Position = nearest.Coordinates;
                //    Text = $"Selected Index={nearest.Index}, X={nearest.X:0.##}, Y={nearest.Y:0.##}";
                //}

                //// hide the crosshair when no point is selected
                //if (!nearest.IsReal && MyCrosshair.IsVisible)
                //{
                //    MyCrosshair.IsVisible = false;
                //    Text = $"No point selected";
                //}
            };

            formsPlot_FFT.Refresh();
        }

        private void fFTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateFFT();
        }

        private void button_FFT_Click(object sender, EventArgs e)
        {
            UpdateFFT();
        }
    }
}
