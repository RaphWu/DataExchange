﻿using System;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {
        private enum FilterType
        {
            None,
            Kalman,
            LPF1_1,
            LPF2_1,
            LPF2_2,
        }

        private void numericUpDown_KalmanR_ValueChanged(object sender, EventArgs e)
        {
            if (_filterKalman != null)
                _filterKalman.SetProcessNoise((double)numericUpDown_KalmanR.Value);
        }

        private void numericUpDown_KalmanQ_ValueChanged(object sender, EventArgs e)
        {
            if (_filterKalman != null)
                _filterKalman.SetMeasurementNoise((double)numericUpDown_KalmanQ.Value);
        }

        private void numericUpDown_CutoffFreq_ValueChanged(object sender, EventArgs e)
        {
            CutoffFreq = (double)numericUpDown_CutoffFreq.Value;
        }

        private void checkBox_Kalman_CheckedChanged(object sender, EventArgs e)
        {
            SetLegendVisible();
            formsPlot_Measure.Refresh();
        }

        private void checkBox_LPF1_1_CheckedChanged(object sender, EventArgs e)
        {
            SetLegendVisible();
            formsPlot_Measure.Refresh();
        }

        private void checkBox_LPF2_1_CheckedChanged(object sender, EventArgs e)
        {
            SetLegendVisible();
            formsPlot_Measure.Refresh();
        }

        private void checkBox_LPF2_2_CheckedChanged(object sender, EventArgs e)
        {
            SetLegendVisible();
            formsPlot_Measure.Refresh();
        }
    }
}
