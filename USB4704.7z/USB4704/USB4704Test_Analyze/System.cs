﻿using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;

namespace USB4704Test_Analyze
{
    public partial class Form1
    {

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Title = "儲存檔案",
                Filter = "CSV 檔案 (*.csv)|*.csv|所有檔案 (*.*)|*.*",
                DefaultExt = "csv"
            };

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // 開啟檔案以寫入資料（覆蓋模式）
                    using (FileStream fs = File.Open(saveDialog.FileName, FileMode.Create, FileAccess.Write))
                    {
                        using (StreamWriter writer = new StreamWriter(fs, Encoding.UTF8))
                        {
                            writer.WriteLine("時間 (sec),Stopwatch (sec),Instant (V),Kalman,LPF1_1,LPF2_1,LPF2_2,Stopwatch (sec),Streaming (V),Kalman,LPF1_1,LPF2_1,LPF2_2");

                            StringBuilder sb = new StringBuilder();
                            int idxInstant = 0;
                            int idxStreaming = 0;
                            double instantTimestamp = 0.0;
                            double streamingTimestamp = 0.0;
                            bool instantHasData = _instantTotalData > 0;
                            bool streamingHasData = _streamingTotalData > 0;

                            int idxInstantStopwatch = 0;
                            int idxStreamingStopwatch = 0;
                            bool instantStopwatchHasData = _instantPlotData_Timestamp.Count > 0;
                            bool streamingStopwatchHasData = _streamingPlotData_Timestamp.Count > 0;

                            double tmp;

                            do
                            {
                                sb.Clear();
                                if (instantHasData)
                                    instantTimestamp = _instantPlotData_Time[idxInstant];
                                if (streamingHasData)
                                    streamingTimestamp = _streamingPlotData_Time[idxStreaming];

                                instantStopwatchHasData = idxInstantStopwatch < _instantPlotData_Timestamp.Count;
                                streamingStopwatchHasData = idxStreamingStopwatch < _streamingPlotData_Timestamp.Count;

                                if (instantHasData && streamingHasData && instantTimestamp == streamingTimestamp)
                                {
                                    sb.Append(instantTimestamp.ToString("0.000"));
                                    sb.Append(",");

                                    if (instantStopwatchHasData && _instantPlotData_Timestamp[idxInstantStopwatch] >= instantTimestamp)
                                    {
                                        tmp = _instantPlotData_Timestamp[idxInstantStopwatch];
                                        sb.Append(tmp.ToString("0.000"));
                                        if (idxInstantStopwatch > 0)
                                        {
                                            sb.Append(" / ");
                                            sb.Append((_instantPlotData_Timestamp[idxInstantStopwatch - 1] - tmp).ToString("0.000"));
                                        }
                                        idxInstantStopwatch++;
                                    }
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Measure[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Kalman[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Lpf1_1[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Lpf2_1[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Lpf2_2[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    if (streamingStopwatchHasData && _streamingPlotData_Timestamp[idxStreamingStopwatch] <= streamingTimestamp)
                                    {
                                        tmp = _streamingPlotData_Timestamp[idxStreamingStopwatch];
                                        sb.Append(tmp.ToString("0.000"));
                                        if (idxStreamingStopwatch > 0)
                                        {
                                            sb.Append(" / ");
                                            sb.Append((_streamingPlotData_Timestamp[idxStreamingStopwatch - 1] - tmp).ToString("0.000"));
                                        }
                                        idxStreamingStopwatch++;
                                    }
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Measure[idxStreaming].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Kalman[idxStreaming].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Lpf1_1[idxStreaming].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Lpf2_1[idxStreaming].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Lpf2_2[idxStreaming].ToString("0.000"));

                                    writer.WriteLine(sb);
                                    idxInstant++;
                                    idxStreaming++;
                                }

                                else if ((instantHasData && !streamingHasData)
                                        || (instantHasData && streamingHasData && instantTimestamp < streamingTimestamp))
                                {
                                    sb.Append(instantTimestamp.ToString("0.000"));
                                    sb.Append(",");

                                    if (instantStopwatchHasData && _instantPlotData_Timestamp[idxInstantStopwatch] <= instantTimestamp)
                                    {
                                        tmp = _instantPlotData_Timestamp[idxInstantStopwatch];
                                        sb.Append(tmp.ToString("0.000"));
                                        if (idxInstantStopwatch > 0)
                                        {
                                            sb.Append(" / ");
                                            sb.Append((_instantPlotData_Timestamp[idxInstantStopwatch - 1] - tmp).ToString("0.000"));
                                        }
                                        idxInstantStopwatch++;
                                    }
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Measure[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Kalman[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Lpf1_1[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Lpf2_1[idxInstant].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_instantPlotData_Lpf2_2[idxInstant].ToString("0.000"));

                                    writer.WriteLine(sb);
                                    idxInstant++;
                                }

                                else if ((!instantHasData && streamingHasData)
                                        || (instantHasData && streamingHasData && instantTimestamp > streamingTimestamp))
                                {
                                    sb.Append(streamingTimestamp.ToString("0.000"));
                                    sb.Append(",,,,,,,");

                                    if (streamingStopwatchHasData && _streamingPlotData_Timestamp[idxStreamingStopwatch] <= streamingTimestamp)
                                    {
                                        tmp = _streamingPlotData_Timestamp[idxStreamingStopwatch];
                                        sb.Append(tmp.ToString("0.000"));
                                        if (idxStreamingStopwatch > 0)
                                        {
                                            sb.Append(" / ");
                                            sb.Append((_streamingPlotData_Timestamp[idxStreamingStopwatch - 1] - tmp).ToString("0.000"));
                                        }
                                        idxStreamingStopwatch++;
                                    }
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Measure[idxStreaming].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Kalman[idxStreaming].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Lpf1_1[idxStreaming].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Lpf2_1[idxStreaming].ToString("0.000"));
                                    sb.Append(",");

                                    sb.Append(_streamingPlotData_Lpf2_2[idxStreaming].ToString("0.000"));

                                    writer.WriteLine(sb);
                                    idxStreaming++;
                                }

                                instantHasData = idxInstant < _instantTotalData;
                                streamingHasData = idxStreaming < _streamingTotalData;
                            } while (instantHasData || streamingHasData);
                        }
                    }

                    MessageBox.Show("檔案儲存成功！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("儲存失敗：" + ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        internal void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            if (Application.OpenForms.Count > 0)
            {
                var form = Application.OpenForms[0];
                if (form.InvokeRequired)
                {
                    form.Invoke(new Action(() =>
                    {
                        if (PropertyChanged != null)
                            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                    }));
                }
                else
                {
                    if (PropertyChanged != null)
                        PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
                }
            }
        }


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
