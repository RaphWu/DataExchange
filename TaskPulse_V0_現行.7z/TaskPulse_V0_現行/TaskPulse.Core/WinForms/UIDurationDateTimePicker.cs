﻿/*
功能特點：
1. 基本屬性
    - Value (DateTime?) - 可為 null 的日期時間值
    - Text (string) - 顯示的文字內容
    - Enabled (bool) - 是否啟用控制項
    - Font (Font) - 字型設定
    - FillColor (Color) - 填充顏色
2. 關聯屬性 (可在設計器中設定)
    - StartTimeControl (UIDurationDateTimePicker) - 開始時間控制項
    - EndTimeControl (UIDurationDateTimePicker) - 結束時間控制項
    - DurationControl (UITextBox) - 時間差顯示控制項
3. 事件
    - ValueChanged - 值變更時觸發
    - TextChanged - 文字變更時觸發
    - DropDown - 日曆開啟時觸發
    - DropDownClosed - 日曆關閉時觸發
    - ButtonClick - 按鈕點擊時觸發
    - KeyDown - 鍵盤按下時觸發
    - KeyUp - 鍵盤放開時觸發
4. 核心功能實現
    A. Null 值處理
        - Value 為 null 時，Text 顯示為空字串
        - 點擊按鈕開啟日曆時，自動以 DateTime.Now 取代 null
    B. 文字清除
        - 使用者清除 Text 時，Value 自動設為 null
    C. 輸入行為控制
        - 鍵盤輸入期間不觸發 ValueChanged，避免干擾使用者體驗
        - 使用 _isTyping 旗標控制
        - 開啟日曆時也不觸發 ValueChanged，使用 _isPickerOpen 旗標
    D. 時間差自動計算
        - 如果設定了 DurationControl 和 StartTimeControl：
        - 時間差 = 自己的 Value - StartTimeControl.Value
        - 如果設定了 DurationControl 和 EndTimeControl：
        - 時間差 = EndTimeControl.Value - 自己的 Value
        - 格式：0天 00:00 或 00:00
    E. DataBinding 支援
        - 使用 _isDataBinding 旗標防止 DataBinding 變更觸發不必要的事件
        - 支援雙向綁定到 Text 或 Value 屬性

技術實現細節：
1.	繼承自 UserControl - 因 UIDatetimePicker 為 sealed，無法直接繼承
2.	內部包裝 UIDatetimePicker - 作為內部控制項
3.	事件轉發機制 - 將內部控制項的事件轉發到外部
4.	智能更新機制 - 使用多個旗標防止遞迴更新和不必要的觸發
5.	適當的資源釋放 - 在 Dispose 中解除所有事件訂閱
*/

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Sunny.UI;

namespace Calin.TaskPulse.Core.WinForms
{
    /// <summary>
    /// 具有時間差計算功能的日期時間選擇器。
    /// </summary>
    [DefaultEvent("ValueChanged")]
    public partial class UIDurationDateTimePicker : UserControl
    {
        #region Fields

        private UIDatetimePicker _dateTimePicker;
        private DateTime? _value;
        private bool _isTyping = false;
        private bool _isPickerOpen = false;
        private bool _isDataBinding = false;

        #endregion

        #region Properties

        /// <summary>
        /// 開始時間控制項 (用於計算時間差)。
        /// </summary>
        [Category("SunnyUI")]
        [Description("開始時間控制項 (用於計算時間差)")]
        public UIDurationDateTimePicker StartTimeControl { get; set; }

        /// <summary>
        /// 結束時間控制項 (用於計算時間差)。
        /// </summary>
        [Category("SunnyUI")]
        [Description("結束時間控制項 (用於計算時間差)")]
        public UIDurationDateTimePicker EndTimeControl { get; set; }

        /// <summary>
        /// 時間差顯示控制項。
        /// </summary>
        [Category("SunnyUI")]
        [Description("時間差顯示控制項")]
        public UITextBox DurationControl { get; set; }

        /// <summary>
        /// 日期時間值 (可為 null)。
        /// </summary>
        [Browsable(true)]
        [Category("Data")]
        [Description("日期時間值 (可為 null)")]
        public DateTime? Value
        {
            get => _value;
            set
            {
                if (_value != value)
                {
                    _value = value;
                    UpdateDisplay();
                    OnValueChanged(EventArgs.Empty);
                }
            }
        }

        /// <summary>
        /// 顯示的文字。
        /// </summary>
        [Browsable(true)]
        [Category("Appearance")]
        [Description("顯示的文字")]
        public override string Text
        {
            get => _dateTimePicker?.Text ?? string.Empty;
            set
            {
                if (_dateTimePicker != null && _dateTimePicker.Text != value)
                {
                    _isDataBinding = true;
                    _dateTimePicker.Text = value;

                    if (string.IsNullOrWhiteSpace(value))
                    {
                        _value = null;
                    }
                    else if (DateTime.TryParse(value, out DateTime dt))
                    {
                        _value = dt;
                    }

                    _isDataBinding = false;
                    OnTextChanged(EventArgs.Empty);
                }
            }
        }

        /// <summary>
        /// 內部 UIDatetimePicker 的字型。
        /// </summary>
        [Browsable(true)]
        [Category("Appearance")]
        public override Font Font
        {
            get => base.Font;
            set
            {
                base.Font = value;
                if (_dateTimePicker != null)
                    _dateTimePicker.Font = value;
            }
        }

        /// <summary>
        /// 是否啟用。
        /// </summary>
        [Browsable(true)]
        [Category("Behavior")]
        public new bool Enabled
        {
            get => base.Enabled;
            set
            {
                base.Enabled = value;
                if (_dateTimePicker != null)
                    _dateTimePicker.Enabled = value;
            }
        }

        /// <summary>
        /// 填充顏色。
        /// </summary>
        [Category("SunnyUI")]
        [Description("填充顏色")]
        public Color FillColor
        {
            get => _dateTimePicker?.FillColor ?? Color.Empty;
            set
            {
                if (_dateTimePicker != null)
                    _dateTimePicker.FillColor = value;
            }
        }

        /// <summary>
        /// 浮水印文字。
        /// </summary>
        [Category("SunnyUI")]
        [Description("浮水印文字")]
        public string Watermark
        {
            get => _dateTimePicker?.Watermark ?? "";
            set
            {
                if (_dateTimePicker != null)
                    _dateTimePicker.Watermark = value;
            }
        }

        /// <summary>
        /// 日期格式化遮罩。
        /// </summary>
        [Category("SunnyUI")]
        [Description("日期格式化遮罩")]
        public string DateFormat
        {
            get => _dateTimePicker?.DateFormat ?? "";
            set
            {
                if (_dateTimePicker != null)
                    _dateTimePicker.DateFormat = value;
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// 值變更事件。
        /// </summary>
        [Category("Property Changed")]
        [Description("值變更時觸發")]
        public event EventHandler<DateTime> ValueChanged;

        /// <summary>
        /// 文字變更事件。
        /// </summary>
        [Category("Property Changed")]
        [Description("文字變更時觸發")]
        public new event EventHandler TextChanged;

        /// <summary>
        /// 日曆開啟事件。
        /// </summary>
        [Category("Action")]
        [Description("日曆開啟時觸發")]
        public event EventHandler DropDown;

        /// <summary>
        /// 日曆關閉事件。
        /// </summary>
        [Category("Action")]
        [Description("日曆關閉時觸發")]
        public event EventHandler DropDownClosed;

        /// <summary>
        /// 按鈕點擊事件。
        /// </summary>
        [Category("Action")]
        [Description("按鈕點擊時觸發")]
        public event EventHandler ButtonClick;

        /// <summary>
        /// 鍵盤按下事件。
        /// </summary>
        [Category("Key")]
        [Description("鍵盤按下時觸發")]
        public new event KeyEventHandler KeyDown;

        /// <summary>
        /// 鍵盤放開事件。
        /// </summary>
        [Category("Key")]
        [Description("鍵盤放開時觸發")]
        public new event KeyEventHandler KeyUp;

        #endregion

        #region Constructor

        public UIDurationDateTimePicker()
        {
            InitializeComponent();
            InitializeInternalControl();
        }

        private void InitializeInternalControl()
        {
            _dateTimePicker = new UIDatetimePicker
            {
                Dock = DockStyle.Fill,
                FillColor = Color.White,
                Font = new Font("微軟正黑體", 11F),
                DateFormat = "yyyy/MM/dd HH:mm",
                Location = new Point(0, 0),
                Name = "internalDateTimePicker",
                Size = this.Size,
                TabIndex = 0,

                Height = 29,
                ShowToday = false,
                CanEmpty = true,
                ImeMode = ImeMode.Disable,
                DropDownStyle = UIDropDownStyle.DropDown,
            };

            // 訂閱內部控制項事件
            _dateTimePicker.ValueChanged += InternalDateTimePicker_ValueChanged;
            _dateTimePicker.TextChanged += InternalDateTimePicker_TextChanged;
            _dateTimePicker.DropDown += InternalDateTimePicker_DropDown;
            _dateTimePicker.DropDownClosed += InternalDateTimePicker_DropDownClosed;
            _dateTimePicker.ButtonClick += InternalDateTimePicker_ButtonClick;
            _dateTimePicker.KeyDown += InternalDateTimePicker_KeyDown;
            _dateTimePicker.KeyUp += InternalDateTimePicker_KeyUp;

            this.Controls.Add(_dateTimePicker);
        }

        #endregion

        #region Internal Event Handlers

        private void InternalDateTimePicker_ValueChanged(object sender, DateTime value)
        {
            if (_isDataBinding || _isPickerOpen || _isTyping)
                return;

            ValidateAndUpdateValue();
        }

        private void InternalDateTimePicker_TextChanged(object sender, EventArgs e)
        {
            if (_isDataBinding)
                return;

            // 如果文字被清空，設定 Value 為 null
            if (string.IsNullOrWhiteSpace(_dateTimePicker.Text))
            {
                _value = null;
                UpdateDuration();
                OnTextChanged(e);
                return;
            }

            if (!_isTyping && !_isPickerOpen)
            {
                OnTextChanged(e);
            }
        }

        private void InternalDateTimePicker_DropDown(object sender, EventArgs e)
        {
            _isPickerOpen = true;
            OnDropDown(e);
        }

        private void InternalDateTimePicker_DropDownClosed(object sender, EventArgs e)
        {
            _isPickerOpen = false;
            ValidateAndUpdateValue();
            OnDropDownClosed(e);
        }

        private void InternalDateTimePicker_ButtonClick(object sender, EventArgs e)
        {
            // 如果 Value 為 null，點擊按鈕時設定為當前時間
            if (_value == null)
            {
                _dateTimePicker.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                _value = DateTime.Now;
                UpdateDuration();
            }

            OnButtonClick(e);
        }

        private void InternalDateTimePicker_KeyDown(object sender, KeyEventArgs e)
        {
            _isTyping = true;
            OnKeyDown(e);
        }

        private void InternalDateTimePicker_KeyUp(object sender, KeyEventArgs e)
        {
            _isTyping = false;
            ValidateAndUpdateValue();
            OnKeyUp(e);
        }

        #endregion

        #region Private Methods

        private void UpdateDisplay()
        {
            if (_isDataBinding)
                return;

            _isDataBinding = true;

            if (_value == null)
            {
                _dateTimePicker.Text = string.Empty;
            }
            else
            {
                _dateTimePicker.Text = _value.Value.ToString("yyyy/MM/dd HH:mm");
            }

            UpdateDuration();
            _isDataBinding = false;
        }

        private void ValidateAndUpdateValue()
        {
            if (_isDataBinding)
                return;

            if (string.IsNullOrWhiteSpace(_dateTimePicker.Text))
            {
                _value = null;
            }
            else if (DateTime.TryParse(_dateTimePicker.Text, out DateTime dt))
            {
                _value = dt;
            }

            UpdateDuration();
        }

        private void UpdateDuration()
        {
            if (DurationControl == null)
                return;

            TimeSpan duration = TimeSpan.Zero;

            // 如果有設定 StartTimeControl，計算自己 - 開始時間
            if (StartTimeControl != null && StartTimeControl.Value != null && _value != null)
            {
                duration = _value.Value - StartTimeControl.Value.Value;
            }
            // 如果有設定 EndTimeControl，計算結束時間 - 自己
            else if (EndTimeControl != null && EndTimeControl.Value != null && _value != null)
            {
                duration = EndTimeControl.Value.Value - _value.Value;
            }

            // 格式化時間差
            string days = duration.Days > 0 ? $"{duration.Days}天 " : "";
            DurationControl.Text = $"{days}{Math.Abs(duration.Hours):D2}:{Math.Abs(duration.Minutes):D2}";
        }

        #endregion

        #region Event Invokers

        protected virtual void OnValueChanged(EventArgs e)
        {
            if (!_isDataBinding)
            {
                ValueChanged?.Invoke(this, _value ?? DateTime.MinValue);
                UpdateDuration();
            }
        }

        protected override void OnTextChanged(EventArgs e)
        {
            if (!_isDataBinding)
            {
                base.OnTextChanged(e);
                TextChanged?.Invoke(this, e);
            }
        }

        protected virtual void OnDropDown(EventArgs e)
        {
            DropDown?.Invoke(this, e);
        }

        protected virtual void OnDropDownClosed(EventArgs e)
        {
            DropDownClosed?.Invoke(this, e);
        }

        protected virtual void OnButtonClick(EventArgs e)
        {
            ButtonClick?.Invoke(this, e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            KeyDown?.Invoke(this, e);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);
            KeyUp?.Invoke(this, e);
        }

        #endregion

        #region Cleanup

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_dateTimePicker != null)
                {
                    _dateTimePicker.ValueChanged -= InternalDateTimePicker_ValueChanged;
                    _dateTimePicker.TextChanged -= InternalDateTimePicker_TextChanged;
                    _dateTimePicker.DropDown -= InternalDateTimePicker_DropDown;
                    _dateTimePicker.DropDownClosed -= InternalDateTimePicker_DropDownClosed;
                    _dateTimePicker.ButtonClick -= InternalDateTimePicker_ButtonClick;
                    _dateTimePicker.KeyDown -= InternalDateTimePicker_KeyDown;
                    _dateTimePicker.KeyUp -= InternalDateTimePicker_KeyUp;
                    _dateTimePicker.Dispose();
                    _dateTimePicker = null;
                }
            }
            base.Dispose(disposing);
        }

        #endregion
    }
}
