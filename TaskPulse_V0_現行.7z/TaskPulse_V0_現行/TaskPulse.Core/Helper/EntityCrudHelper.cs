using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Helper
{
    /// <summary>
    /// �i�Ƨǹ��餶���C
    /// </summary>
    public interface IOrderable
    {
        int OrderNo { get; set; }
    }

    /// <summary>
    /// ���� CRUD �t�m�C
    /// </summary>
    /// <typeparam name="TEntity">���������C</typeparam>
    public class EntityCrudConfig<TEntity> where TEntity : class
    {
        public string EntityTypeName { get; set; }
        public Expression<Func<TEntity, string>> NameSelector { get; set; }
        public Expression<Func<TEntity, int>> OrderNoSelector { get; set; }
        public Func<TEntity, string> NameGetter { get; set; }
        public Action<TEntity, string> NameSetter { get; set; }
        public Func<TEntity, int> OrderNoGetter { get; set; }
        public Action<TEntity, int> OrderNoSetter { get; set; }
        public int MaxNameLength { get; set; } = 30;
        public Func<string, bool> ExistsChecker { get; set; }
        public Func<int, TEntity> EntityFinder { get; set; }
        public Func<TEntity> EntityFactory { get; set; }
    }

    /// <summary>
    /// ���ѹ��� CRUD �ާ@�����U��k���X�C
    /// </summary>
    public static class EntityCrudHelper
    {
        /// <summary>
        /// �D�P�B�إ߷s����C
        /// </summary>
        /// <typeparam name="TEntity">���������C</typeparam>
        /// <param name="scope">Autofac �ͩR�g���d��C</param>
        /// <param name="logger">��x�O�����C</param>
        /// <param name="context">��Ʈw�W�U��C</param>
        /// <param name="dbSet">���骺��Ʈw���X�C</param>
        /// <param name="config">���� CRUD �t�m�C</param>
        /// <param name="cacheManager">����֨��޲z���C</param>
        /// <param name="cacheUpdateAction">��s�֨����ʧ@�C</param>
        /// <param name="updateViewAction">��s�˵����D�P�B�ʧ@�C</param>
        /// <param name="selectCreatedItem">����w�إ߶��ت��ʧ@�C</param>
        /// <returns>�Y���\�إ߹���h�Ǧ^ true�A�_�h�Ǧ^ false�C</returns>
        public static async Task<bool> CreateEntityAsync<TEntity>(
            ILifetimeScope scope,
            Serilog.ILogger logger,
            DbContext context,
            DbSet<TEntity> dbSet,
            EntityCrudConfig<TEntity> config,
            ICacheManager cacheManager,
            Action cacheUpdateAction,
            Func<Task> updateViewAction,
            Action<int> selectCreatedItem) where TEntity : class
        {
            string title = $"�п�J�s{config.EntityTypeName}�W��";
            string caption = $"�s{config.EntityTypeName}�W��";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{config.EntityTypeName}�W�٤��i���ťաI"),
                input => input.Length <= config.MaxNameLength ? (true, "") : (false, $"{config.EntityTypeName}�W�٥����p�󵥩� {config.MaxNameLength} �Ӧr���I"),
                input => config.ExistsChecker(input) ? (false, $"{config.EntityTypeName}�W�٤w�s�b�I") : (true, "")
            );

            using (var crud = scope.Resolve<CRUD>())
            {
                crud.New_1TextBox(new TextBoxInfo()
                {
                    Value = "",
                    Caption = caption,
                    WaterMark = caption
                }, title, validator);

                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newName = crud.Result.StringValue;
                        int maxOrderNo = dbSet.Any() ? dbSet.Max(config.OrderNoSelector) : 0;

                        var newEntity = config.EntityFactory();
                        config.NameSetter(newEntity, newName);
                        config.OrderNoSetter(newEntity, maxOrderNo + 1);

                        dbSet.Add(newEntity);
                        await context.SaveChangesAsync();
                        await updateViewAction();
                        cacheUpdateAction();

                        //var createdEntity = dbSet.AsNoTracking().FirstOrDefault(e => config.NameGetter(e) == newName);
                        var nameGetter = config.NameGetter;
                        var createdEntity = dbSet.AsNoTracking().FirstOrDefault(e => nameGetter(e) == newName);
                        if (createdEntity != null)
                        {
                            var entityId = context.Entry(createdEntity).Property("Id").CurrentValue as int?;
                            if (entityId.HasValue)
                            {
                                selectCreatedItem(entityId.Value);
                            }
                        }

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"�w�W�[�s{config.EntityTypeName}: {newName}"));
                        return true;
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"�s�W{config.EntityTypeName}����";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "��Ʈw���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// �D�P�B�s��{������C
        /// </summary>
        /// <typeparam name="TEntity">���������C</typeparam>
        /// <param name="scope">Autofac �ͩR�g���d��C</param>
        /// <param name="logger">��x�O�����C</param>
        /// <param name="context">��Ʈw�W�U��C</param>
        /// <param name="dbSet">���骺��Ʈw���X�C</param>
        /// <param name="config">���� CRUD �t�m�C</param>
        /// <param name="cacheManager">����֨��޲z���C</param>
        /// <param name="cacheUpdateAction">��s�֨����ʧ@�C</param>
        /// <param name="updateViewAction">��s�˵����D�P�B�ʧ@�C</param>
        /// <param name="entityId">�n�s�誺���� ID�C</param>
        /// <param name="currentName">�ثe������W�١C</param>
        /// <param name="selectEditedItem">����w�s�趵�ت��ʧ@�C</param>
        /// <returns>�Y���\�s�����h�Ǧ^ true�A�_�h�Ǧ^ false�C</returns>
        public static async Task<bool> EditEntityAsync<TEntity>(
            ILifetimeScope scope,
            Serilog.ILogger logger,
            DbContext context,
            DbSet<TEntity> dbSet,
            EntityCrudConfig<TEntity> config,
            ICacheManager cacheManager,
            Action cacheUpdateAction,
            Func<Task> updateViewAction,
            int entityId,
            string currentName,
            Action<int> selectEditedItem) where TEntity : class
        {
            string title = $"�п�J�s{config.EntityTypeName}�W��";
            string oldCaption = $"��{config.EntityTypeName}�W��";
            string newCaption = $"�s{config.EntityTypeName}�W��";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{config.EntityTypeName}�W�٤��i���ťաI"),
                input => input.Length <= config.MaxNameLength ? (true, "") : (false, $"{config.EntityTypeName}�W�٥����p�󵥩� {config.MaxNameLength} �Ӧr���I"),
                input => config.ExistsChecker(input) ? (false, $"{config.EntityTypeName}�W�٤w�s�b�I") : (true, "")
            );

            using (var crud = scope.Resolve<CRUD>())
            {
                crud.Edit_1TextBox(new TextBoxInfo()
                {
                    Value = currentName,
                    Caption = oldCaption,
                    WaterMark = oldCaption
                }, new TextBoxInfo()
                {
                    Value = "",
                    Caption = newCaption,
                    WaterMark = newCaption
                }, title, validator);

                if (MyFormEx.ShowDialogWithMask(crud) == DialogResult.OK)
                {
                    try
                    {
                        string newName = crud.Result.StringValue;
                        var entity = config.EntityFinder(entityId);
                        if (entity != null)
                        {
                            config.NameSetter(entity, newName);
                            await context.SaveChangesAsync();
                            await updateViewAction();
                            cacheUpdateAction();
                            selectEditedItem(entityId);

                            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{config.EntityTypeName}: {currentName}�A�W�٤w�ܧ�: {newName}"));
                            return true;
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{config.EntityTypeName}���s�R�W����";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "��Ʈw���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// �D�P�B�R������C
        /// </summary>
        /// <typeparam name="TEntity">���������C</typeparam>
        /// <param name="logger">��x�O�����C</param>
        /// <param name="context">��Ʈw�W�U��C</param>
        /// <param name="dbSet">���骺��Ʈw���X�C</param>
        /// <param name="config">���� CRUD �t�m�C</param>
        /// <param name="cacheManager">����֨��޲z���C</param>
        /// <param name="cacheUpdateAction">��s�֨����ʧ@�C</param>
        /// <param name="updateViewAction">��s�˵����D�P�B�ʧ@�C</param>
        /// <param name="entityId">�n�R�������� ID�C</param>
        /// <param name="entityName">�n�R��������W�١C</param>
        /// <returns>�Y���\�R������h�Ǧ^ true�A�_�h�Ǧ^ false�C</returns>
        public static async Task<bool> DeleteEntityAsync<TEntity>(
            Serilog.ILogger logger,
            DbContext context,
            DbSet<TEntity> dbSet,
            EntityCrudConfig<TEntity> config,
            ICacheManager cacheManager,
            Action cacheUpdateAction,
            Func<Task> updateViewAction,
            int entityId,
            string entityName) where TEntity : class
        {
            if (UIMessageBox.ShowAsk2($"�T�w�n�R�� {config.EntityTypeName} {entityName} �ܡH", true, UIMessageDialogButtons.Cancel))
            {
                try
                {
                    var entity = config.EntityFinder(entityId);
                    if (entity != null)
                    {
                        dbSet.Remove(entity);
                        await context.SaveChangesAsync();
                        await updateViewAction();
                        cacheUpdateAction();

                        MessageBox.Show($"{config.EntityTypeName}: {entityName} �R�����\�I",
                            "�R�����\",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    string errMsg = $"{config.EntityTypeName}�R������";
                    using (LogContext.PushProperty("Category", "Database"))
                    {
                        logger.Fatal(ex, errMsg);
                    }
                    MessageBox.Show(errMsg, "��Ʈw���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// �B�z�V�W���ʶ��ت��I���ƥ�C
        /// </summary>
        /// <typeparam name="TViewModel">�˵��ҫ������C</typeparam>
        /// <typeparam name="TEntity">���������C</typeparam>
        /// <param name="logger">��x�O�����C</param>
        /// <param name="context">��Ʈw�W�U��C</param>
        /// <param name="config">���� CRUD �t�m�C</param>
        /// <param name="cacheManager">����֨��޲z���C</param>
        /// <param name="cacheUpdateAction">��s�֨����ʧ@�C</param>
        /// <param name="updateViewAction">��s�˵����D�P�B�ʧ@�C</param>
        /// <param name="viewModels">�Ҧ��˵��ҫ����M��C</param>
        /// <param name="currentViewModel">�ثe������˵��ҫ��C</param>
        /// <param name="orderNoGetter">���o�Ƨǽs�����禡�C</param>
        /// <param name="idGetter">���o ID ���禡�C</param>
        /// <param name="selectAction">������ت��ʧ@�C</param>
        public static async Task HandleUpClickAsync<TViewModel, TEntity>(
            Serilog.ILogger logger,
            DbContext context,
            EntityCrudConfig<TEntity> config,
            ICacheManager cacheManager,
            Action cacheUpdateAction,
            Func<Task> updateViewAction,
            List<TViewModel> viewModels,
            TViewModel currentViewModel,
            Func<TViewModel, int> orderNoGetter,
            Func<TViewModel, int> idGetter,
            Action<int> selectAction)
            where TViewModel : class
            where TEntity : class
        {
            if (currentViewModel == null) return;

            var currentOrderNo = orderNoGetter(currentViewModel);
            var smallerItem = viewModels.LastOrDefault(vm => orderNoGetter(vm) < currentOrderNo);

            if (smallerItem != null)
            {
                var currentId = idGetter(currentViewModel);
                var smallerId = idGetter(smallerItem);

                try
                {
                    var entity1 = config.EntityFinder(currentId);
                    var entity2 = config.EntityFinder(smallerId);

                    if (entity1 != null && entity2 != null)
                    {
                        var orderNo1 = config.OrderNoGetter(entity1);
                        var orderNo2 = config.OrderNoGetter(entity2);

                        config.OrderNoSetter(entity1, orderNo2);
                        config.OrderNoSetter(entity2, orderNo1);

                        await context.SaveChangesAsync();
                        await updateViewAction();
                        cacheUpdateAction();
                        selectAction(currentId);
                    }
                }
                catch (Exception ex)
                {
                    string errMsg = "���ǽվ㥢��";
                    using (LogContext.PushProperty("Category", "Database"))
                    {
                        logger.Fatal(ex, errMsg);
                    }
                    MessageBox.Show(errMsg, "��Ʈw���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// �B�z�V�U���ʶ��ت��I���ƥ�C
        /// </summary>
        /// <typeparam name="TViewModel">�˵��ҫ������C</typeparam>
        /// <typeparam name="TEntity">���������C</typeparam>
        /// <param name="logger">��x�O�����C</param>
        /// <param name="context">��Ʈw�W�U��C</param>
        /// <param name="config">���� CRUD �t�m�C</param>
        /// <param name="cacheManager">����֨��޲z���C</param>
        /// <param name="cacheUpdateAction">��s�֨����ʧ@�C</param>
        /// <param name="updateViewAction">��s�˵����D�P�B�ʧ@�C</param>
        /// <param name="viewModels">�Ҧ��˵��ҫ����M��C</param>
        /// <param name="currentViewModel">�ثe������˵��ҫ��C</param>
        /// <param name="orderNoGetter">���o�Ƨǽs�����禡�C</param>
        /// <param name="idGetter">���o ID ���禡�C</param>
        /// <param name="selectAction">������ت��ʧ@�C</param>
        public static async Task HandleDownClickAsync<TViewModel, TEntity>(
            Serilog.ILogger logger,
            DbContext context,
            EntityCrudConfig<TEntity> config,
            ICacheManager cacheManager,
            Action cacheUpdateAction,
            Func<Task> updateViewAction,
            List<TViewModel> viewModels,
            TViewModel currentViewModel,
            Func<TViewModel, int> orderNoGetter,
            Func<TViewModel, int> idGetter,
            Action<int> selectAction)
            where TViewModel : class
            where TEntity : class
        {
            if (currentViewModel == null) return;

            var currentOrderNo = orderNoGetter(currentViewModel);
            var biggerItem = viewModels.FirstOrDefault(vm => orderNoGetter(vm) > currentOrderNo);

            if (biggerItem != null)
            {
                var currentId = idGetter(currentViewModel);
                var biggerId = idGetter(biggerItem);

                try
                {
                    var entity1 = config.EntityFinder(currentId);
                    var entity2 = config.EntityFinder(biggerId);

                    if (entity1 != null && entity2 != null)
                    {
                        var orderNo1 = config.OrderNoGetter(entity1);
                        var orderNo2 = config.OrderNoGetter(entity2);

                        config.OrderNoSetter(entity1, orderNo2);
                        config.OrderNoSetter(entity2, orderNo1);

                        await context.SaveChangesAsync();
                        await updateViewAction();
                        cacheUpdateAction();
                        selectAction(currentId);
                    }
                }
                catch (Exception ex)
                {
                    string errMsg = "���ǽվ㥢��";
                    using (LogContext.PushProperty("Category", "Database"))
                    {
                        logger.Fatal(ex, errMsg);
                    }
                    MessageBox.Show(errMsg, "��Ʈw���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// �ھڥثe������ا�s���s���A�C
        /// </summary>
        /// <param name="currentItem">�ثe��������ءC</param>
        /// <param name="allItems">�Ҧ����ت��M��C</param>
        /// <param name="editButton">�s����s�C</param>
        /// <param name="deleteButton">�R�����r�C</param>
        /// <param name="upButton">�V�W���ʫ��s�C</param>
        /// <param name="downButton">�V�U���ʫ��s�C</param>
        public static void UpdateButtonStates(
            ListViewModel currentItem,
            List<ListViewModel> allItems,
            Button editButton,
            Button deleteButton,
            Button upButton,
            Button downButton)
        {
            if (currentItem != null && allItems != null && allItems.Any())
            {
                editButton.Enabled = true;
                deleteButton.Enabled = true;

                var currentOrderNo = currentItem.OrderNo;
                var minOrderNo = allItems.Min(w => w.OrderNo);
                var maxOrderNo = allItems.Max(w => w.OrderNo);

                upButton.Enabled = currentOrderNo != minOrderNo;
                downButton.Enabled = currentOrderNo != maxOrderNo;
            }
            else
            {
                editButton.Enabled = false;
                deleteButton.Enabled = false;
                upButton.Enabled = false;
                downButton.Enabled = false;
            }
        }
    }
}
