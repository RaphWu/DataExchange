﻿using System;

namespace Calin.TaskPulse.Core.NavServices
{
    public interface INavigationService
    {
        void Navigate(string regionName, Type viewType, bool alive = true);
        void Navigate<TView>(string regionName, bool alive = true) where TView : class;
    }
}
