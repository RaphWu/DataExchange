﻿//using System;
//using System.Threading.Tasks;
//using Calin.TaskPulse.Core.Contracts;
//using Serilog;
//using Serilog.Formatting.Compact;

//namespace Calin.TaskPulse.Core.Services
//{
//    public class LogService : ILogService
//    {
//        private readonly Serilog.ILogger _logger;

//        public LogService(Serilog.ILogger logger)
//        {
//            _logger = logger;

//            //_infoLogger = new LoggerConfiguration()
//            //    .MinimumLevel.Debug()
//            //    .WriteTo.File("logs/information.txt", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 30)
//            //    .CreateLogger();

//            //_userLogger = new LoggerConfiguration()
//            //    .MinimumLevel.Information()
//            //    .WriteTo.File(new CompactJsonFormatter(),
//            //        "logs/user_activity.json", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 90)
//            //    .CreateLogger();

//            //_errorLogger = new LoggerConfiguration()
//            //  .MinimumLevel.Error()
//            //  .WriteTo.File("logs/error_log_.txt", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 90)
//            //  .CreateLogger();

//            //_dbLogger = new LoggerConfiguration()
//            //    .MinimumLevel.Information()
//            //    .WriteTo.File(new CompactJsonFormatter(),
//            //        "logs/security_event.json", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 180)
//            //    .CreateLogger();
//        }

//        /********************
//         * System
//         ********************/
//        /// <inheritdoc/>
//        public void Fatal(string message, Exception ex = null)
//        {
//            var logEntry = new
//            {
//                Message = message,
//                Exception = ex?.ToString(),
//                Timestamp = DateTime.Now
//            };
//            _logger.Fatal(ex, "{@LogEntry}", logEntry);
//        }

//        /// <inheritdoc/>
//        public void Error(string message, Exception ex = null)
//        {
//            var logEntry = new
//            {
//                Message = message,
//                Exception = ex?.ToString(),
//                Timestamp = DateTime.Now
//            };
//            _logger.Error(ex, "{@LogEntry}", logEntry);
//        }

//        ///********************
//        // * User
//        // ********************/
//        ///// <inheritdoc/>
//        //public void LoginAsync(string userId, string action, string dataJson)
//        //{
//        //    var logEntry = new
//        //    {
//        //        UserId = userId,
//        //        Action = action,
//        //        Data = dataJson,
//        //        Timestamp = DateTime.Now
//        //    };
//        //    _userLogger.Information("{@LogEntry}", logEntry);
//        //    await Task.CompletedTask;
//        //}

//        ///// <inheritdoc/>
//        //public async Task UIActionAsync(int userId, string formName, string controlName, string action, object data = null)
//        //{
//        //    var logEntry = new
//        //    {
//        //        Timestamp = DateTime.Now,
//        //        UserId = userId,
//        //        Form = formName,
//        //        Control = controlName,
//        //        Action = action,
//        //        Data = data
//        //    };

//        //    _infoLogger.Information("{@LogEntry}", logEntry);
//        //    await Task.CompletedTask;
//        //}
//    }
//}
