﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using MailKit.Net.Smtp;
using MimeKit;

namespace Calin.TaskPulse.Core.Services
{
    /*
     * https://mimekit.net/
     */

    public class MailService : IMail
    {
        private readonly CoreData _coreData;
        private HashSet<Mail> _mailList;
        private HashSet<Mail> _ccList;

        public MailService(CoreData coreData)
        {
            _coreData = coreData;
        }

        /// <inheritdoc/>
        public void SendMail(string senderTitle, ICollection<int> recipient, string subject, string contents)
        {
            HashSet<string> nameList = new HashSet<string>();
            _mailList = new HashSet<Mail>();
            _ccList = new HashSet<Mail>();
            foreach (var empId in recipient)
            {
                var emp = _coreData.Employees.FirstOrDefault(e => e.Id == empId);
                if (emp != null)
                {
                    _mailList.Add(new Mail()
                    {
                        Name = emp.EmployeeName,
                        Email = emp.Email,
                    });

                    foreach (var cc in emp.CarbonCopies)
                    {
                        if (!recipient.Contains(cc.Id))
                            _ccList.Add(new Mail()
                            {
                                Name = cc.EmployeeName,
                                Email = cc.Email,
                            });
                    }
                }
            }
            _ccList.Add(new Mail() { Name = "系統管理員", Email = "raphael.wu@calinn.com.tw" }); // 追蹤用，可移除

            if (_mailList.Count == 0)
                return;

            contents = Regex.Replace(contents,
                @"<table[^>]*>",
                "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse:collapse; border:1px solid #8c8c8c;'>",
                RegexOptions.IgnoreCase);
            contents = Regex.Replace(contents,
                @"<caption[^>]*>",
                "<caption style='font-weight:bold;margin-bottom:10px;'>",
                RegexOptions.IgnoreCase);
            contents = Regex.Replace(contents,
                @"<td[^>]*>",
                "<td style='border:1px solid #8c8c8c;'>",
                RegexOptions.IgnoreCase);

            string header = $"<h2 style='color:#000099;'>{subject}</h2><hr/>";
            string footer = $"<span style='color:#990000;'><em><strong>此信件由{senderTitle}自動發送，請勿回覆此信件！</strong></em></span>";
            string body = $"<p>{contents}</p><p>{footer}</p>";

            /********************
             * 使用 MimeKit/MailKit 寄信
             ********************/
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(senderTitle, "sys.automate@calin.com.tw"));

            foreach (var mail in _mailList)
                message.To.Add(new MailboxAddress(mail.Name, mail.Email));

            foreach (var cc in _ccList)
            {
                bool alreadyInTo = message.To
                   .Cast<MailboxAddress>()
                   .Any(m => string.Equals(m.Address, cc.Email, StringComparison.OrdinalIgnoreCase));

                if (!alreadyInTo)
                    message.Cc.Add(new MailboxAddress(cc.Name, cc.Email));
            }

            message.Subject = subject;

            var builder = new BodyBuilder();
            builder.HtmlBody = body;
            message.Body = builder.ToMessageBody();

            _ = Task.Run(async () =>
            {
                try
                {
                    using (var client = new SmtpClient())
                    {
                        await client.ConnectAsync("calin-mails0.calin.com.tw", 25, false);
                        //await client.ConnectAsync("calin-mails0.calin.com.tw", 587, SecureSocketOptions.StartTls);
                        //await client.AuthenticateAsync("sys.automate@calin.com.tw", "#Calin@70848492");
                        await client.SendAsync(message);
                        await client.DisconnectAsync(true);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    MessageBox.Show($"郵件寄送失敗！\n錯誤訊息：{ex.Message}",
                                    "郵件寄送失敗",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                }
                finally
                {
                }
            });


            ///********************
            // * 修改自公司提供的示範程式碼
            // ********************/
            ////tsslMsg.Text = "";
            //System.Net.Mail.MailMessage messageOld = new System.Net.Mail.MailMessage();
            //messageOld.From = new System.Net.Mail.MailAddress("sys.automate@calin.com.tw");

            ////讀取收件者
            //foreach (var emp in _mailList)
            //    messageOld.To.Add(new System.Net.Mail.MailAddress(emp.Email, emp.Name));

            //foreach (var cc in _ccList)
            //{
            //    bool alreadyInTo = messageOld.To
            //       .Cast<System.Net.Mail.MailAddress>()
            //       .Any(m => string.Equals(m.Address, cc.Email, StringComparison.OrdinalIgnoreCase));

            //    if (!alreadyInTo)
            //        messageOld.CC.Add(cc.Email);
            //}

            //messageOld.Subject = subject;
            //messageOld.IsBodyHtml = true;
            //messageOld.Body = body;

            //_ = Task.Run(() =>
            //{
            //    try
            //    {
            //        //////////////設定郵箱smtp伺服器 埠//////////////
            //        System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
            //        smtp.Port = 25;
            //        smtp.Host = "calin-mails0.calin.com.tw";
            //        //   smtp.EnableSsl = true; //SSL安全連線
            //        smtp.UseDefaultCredentials = false;
            //        smtp.Credentials = new System.Net.NetworkCredential("sys.automate@calin.com.tw", "#Calin@70848492"); //自動寄信公用帳號

            //        //設定郵件傳送格式
            //        smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            //        smtp.Send(messageOld);
            //        smtp.Dispose();
            //        messageOld.Dispose();
            //    }
            //    catch (Exception ex)
            //    {
            //        Console.WriteLine(ex.ToString());
            //        MessageBox.Show($"郵件寄送失敗！\n錯誤訊息：{ex.Message}",
            //                        "郵件寄送失敗",
            //                        MessageBoxButtons.OK,
            //                        MessageBoxIcon.Error);
            //    }
            //    finally
            //    {
            //    }
            //});
        }
    }
}
