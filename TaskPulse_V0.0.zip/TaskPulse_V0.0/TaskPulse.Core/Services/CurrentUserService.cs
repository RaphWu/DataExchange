﻿using System.Linq;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// 使用者切換操作服務。
    /// </summary>
    public class CurrentUserService : ICurrentUserService
    {
        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly IPermissionService _permission;

        public CurrentUserService(CoreContext coreContext,
                                  CurrentUserContext currentUserContext,
                                  IPermissionService permissionService)
        {
            _context = coreContext;
            _user = currentUserContext;
            _permission = permissionService;
        }

        /********************
         * Switch User
         ********************/
        /// <summary>
        /// 切換目前使用者並發送通知。
        /// </summary>
        private void SwitchCurrentUser()
        {
            _user.Permissions = _permission.GetFullPermissions(_user.CurrentUser?.EmployeeId ?? "");
            _ = WeakReferenceMessenger.Default.Send(NotifyCurrentUserChanged.Instance);

            if (_user.CurrentUser != null)
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{_user.UserName} 已登入。"));
            else
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("目前沒有使用者登入。"));
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(Employee employee)
        {
            _user.CurrentUser = _context.Employees.FirstOrDefault(e => e.Id == employee.Id);
            SwitchCurrentUser();
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(int userId)
        {
            _user.CurrentUser = _context.Employees.FirstOrDefault(e => e.Id == userId);
            SwitchCurrentUser();
        }

        /// <inheritdoc/>
        public void SwitchCurrentUser(string employeeId)
        {
            _user.CurrentUser = _context.Employees.FirstOrDefault(e => e.EmployeeId == employeeId);
            SwitchCurrentUser();
        }

        /********************
         * 特定使用者
         ********************/
        /// <inheritdoc/>
        public void SwitchCurrentUserToGuest()
        {
            _user.SetGuest();
            _ = WeakReferenceMessenger.Default.Send(NotifyCurrentUserChanged.Instance);
            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("目前為訪客權限。"));
        }

        /// <inheritdoc/>
        public void AdminLogin()
        {
            _user.SetAdmin();
            _ = WeakReferenceMessenger.Default.Send(NotifyCurrentUserChanged.Instance);
            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("歡迎管理員。"));
        }
    }
}
