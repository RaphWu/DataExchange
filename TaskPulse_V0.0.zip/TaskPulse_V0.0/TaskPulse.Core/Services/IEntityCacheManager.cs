﻿using System;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// 定義實體快取管理器的介面，提供快取狀態檢查與更新的功能。
    /// </summary>
    public interface IEntityCacheManager
    {
        /********************
         * Public Properties
         ********************/

        /// <summary>
        /// 取得員工快取是否可用的狀態。
        /// </summary>
        bool EmployeeAvailable { get; }

        /// <summary>
        /// 取得員工快取的最後更新時間。
        /// </summary>
        DateTime EmployeeUpdatedTime { get; }

        /// <summary>
        /// 取得機器快取是否可用的狀態。
        /// </summary>
        bool MachineAvailable { get; }

        /// <summary>
        /// 取得機器快取的最後更新時間。
        /// </summary>
        DateTime MachineUpdatedTime { get; }

        /// <summary>
        /// 取得型號快取是否可用的狀態。
        /// </summary>
        bool ModelNoAvailable { get; }

        /// <summary>
        /// 取得型號快取的最後更新時間。
        /// </summary>
        DateTime ModelNoUpdatedTime { get; }

        /// <summary>
        /// 取得工作站快取是否可用的狀態。
        /// </summary>
        bool WorkstationAvailable { get; }

        /// <summary>
        /// 取得工作站快取的最後更新時間。
        /// </summary>
        DateTime WorkstationUpdatedTime { get; }

        /// <summary>
        /// 取得工單快取是否可用的狀態。
        /// </summary>
        bool TaskOrderAvailable { get; }

        /// <summary>
        /// 取得工單快取的最後更新時間。
        /// </summary>
        DateTime TaskOrderUpdatedTime { get; }

        /********************
         * Public Methods - 總體快取管理
         ********************/

        /// <summary>
        /// 取得或設定是否有任何快取不可用的狀態。
        /// </summary>
        bool HaveCacheNotAvailable { get; }

        /// <summary>
        /// 更新所有快取的狀態。
        /// </summary>
        void UpdateAllCaches();

        /********************
         * Public Methods - 個別快取管理
         * 字尾有 Delay 的方法表示請求延遲更新快取，有些頁面不須要立即更新快取時使用，但記得切換頁面時呼叫一次 UpdateAllCaches()。
         ********************/

        /// <summary>
        /// 請求延遲更新員工快取。
        /// </summary>
        void RequestEmployeeUpdateDelay();

        /// <summary>
        /// 請求立即更新員工快取。
        /// </summary>
        void RequestEmployeeUpdate();

        /// <summary>
        /// 通知員工快取已更新。
        /// </summary>
        void NotifyEmployeeUpdated();

        /// <summary>
        /// 等待員工快取可用的非同步方法。
        /// </summary>
        Task WaitForEmployeeAvailableAsync();

        /// <summary>
        /// 請求延遲更新機器快取。
        /// </summary>
        void RequestMachineUpdateDelay();

        /// <summary>
        /// 請求立即更新機器快取。
        /// </summary>
        void RequestMachineUpdate();

        /// <summary>
        /// 通知機器快取已更新。
        /// </summary>
        void NotifyMachineUpdated();

        /// <summary>
        /// 等待機器快取可用的非同步方法。
        /// </summary>
        Task WaitForMachineAvailableAsync();

        /// <summary>
        /// 請求延遲更新型號快取。
        /// </summary>
        void RequestModelNoUpdateDelay();

        /// <summary>
        /// 請求立即更新型號快取。
        /// </summary>
        void RequestModelNoUpdate();

        /// <summary>
        /// 通知型號快取已更新。
        /// </summary>
        void NotifyModelNoUpdated();

        /// <summary>
        /// 等待型號快取可用的非同步方法。
        /// </summary>
        Task WaitForModelNoAvailableAsync();

        /// <summary>
        /// 請求延遲更新工作站快取。
        /// </summary>
        void RequestWorkstationUpdateDelay();

        /// <summary>
        /// 請求立即更新工作站快取。
        /// </summary>
        void RequestWorkstationUpdate();

        /// <summary>
        /// 通知工作站快取已更新。
        /// </summary>
        void NotifyWorkstationUpdated();

        /// <summary>
        /// 等待工作站快取可用的非同步方法。
        /// </summary>
        Task WaitForWorkstationAvailableAsync();

        /// <summary>
        /// 請求延遲更新工單快取。
        /// </summary>
        void RequestTaskOrderUpdateDelay();

        /// <summary>
        /// 請求立即更新工單快取。
        /// </summary>
        void RequestTaskOrderUpdate();

        /// <summary>
        /// 通知工單快取已更新。
        /// </summary>
        void NotifyTaskOrderUpdated();

        /// <summary>
        /// 等待工單快取可用的非同步方法。
        /// </summary>
        Task WaitForTaskOrderAvailableAsync();
    }
}
