﻿using System.Collections.Generic;
using System.Configuration;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 目前的登入者。
    /// </summary>
    public class CurrentUserContext
    {
        /********************
         * Property
         ********************/
        /// <summary>
        /// 目前登入者的Id。
        /// </summary>
        public int UserId
        {
            get { return _userId; }
            set { _userId = value; }
        }
        private int _userId;

        /// <summary>
        /// 目前登入者的員工工號。
        /// </summary>
        public string EmployeeId
        {
            get { return _employeeId; }
            set { _employeeId = value; }
        }
        private string _employeeId;

        /// <summary>
        /// 目前登入者的姓名。
        /// </summary>
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }
        private string _userName;

        /// <summary>
        /// 登入者是否為管理員。
        /// </summary>
        public bool IsAdmin
        {
            get => _isAdmin;
            set => _isAdmin = value;
        }
        private bool _isAdmin;

        /// <summary>
        /// 登入者是否為維護工程師。
        /// </summary>
        public bool IsEngineer
        {
            get => _isEngineer;
            set => _isEngineer = value;
        }
        private bool _isEngineer;

        /// <summary>
        /// 沒有登入者，為訪客狀態。
        /// </summary>
        public bool IsGuest
        {
            get => _isGuest;
            set => _isGuest = value;
        }
        private bool _isGuest;

        /// <summary>
        /// 目前登入者的資料。
        /// </summary>
        public Employee CurrentUser
        {
            get => _currentUser;
            set
            {
                if (value != null)
                {
                    _currentUser = value;
                    _userId = value.Id;
                    _employeeId = value.EmployeeId;
                    _userName = value.EmployeeName;
                    _isAdmin = _userId == int.MaxValue;
                    _isEngineer = value.IsEngineer;
                    _isGuest = _userId == 0;
                }
                else
                {
                    SetGuest();
                }
            }
        }
        private Employee _currentUser = new Employee();

        /// <summary>
        /// 目前登入者的權限。
        /// </summary>
        public HashSet<PermissionData> Permissions // 此內容由 CurrentUserService 設定
        {
            get { return _permissions; }
            set { _permissions = value; }
        }
        private HashSet<PermissionData> _permissions = new HashSet<PermissionData>();

        /********************
         * Methods
         ********************/
        /// <summary>
        /// 設定為管理員狀態。
        /// </summary>
        public void SetAdmin()
        {
            _currentUser = null;
            _userId = int.MaxValue;
            _employeeId = ConfigurationManager.AppSettings["AdminUser"];
            _userName = "管理員";
            _isAdmin = true;
            _isEngineer = false;
            _isGuest = false;
        }

        /// <summary>
        /// 設定為訪客。
        /// </summary>
        public void SetGuest()
        {
            _currentUser = null;
            _userId = 0;
            _employeeId = "USER_Guest";
            _userName = "訪客";
            _permissions = new HashSet<PermissionData>();
            _isAdmin = false;
            _isEngineer = false;
            _isGuest = true;
        }
    }
}
