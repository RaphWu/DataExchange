using System.Collections.Generic;
using Calin.TaskPulse.Core.Contants;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// �v�����ص��ϼҫ��A�Ω���ܳ���v���Ψ�ӷ�
    /// </summary>
    public class PermissionItemViewModel
    {
        public string Module { get; set; }
        public string Page { get; set; }
        public string Control { get; set; }
        public string Action { get; set; }
        public string PermissionString { get; set; }
        public PermissionType Type { get; set; }
        public PermissionSource Source { get; set; }
        public string SourceName { get; set; }
        public bool IsInherited { get; set; }
        public bool HasConflict { get; set; }

        /// <summary>
        /// ��ܥΪ�������r
        /// </summary>
        public string TypeText => Type == PermissionType.Allow ? "���\" : "�T��";

        /// <summary>
        /// ��ܥΪ��ӷ���r
        /// </summary>
        public string SourceText
        {
            get
            {
                switch (Source)
                {
                    case PermissionSource.Department:
                        return $"����: {SourceName}";
                    case PermissionSource.UserGroup:
                        return $"�s��: {SourceName}";
                    case PermissionSource.Employee:
                        return $"�ӤH: {SourceName}";
                    default:
                        return "����";
                }
            }
        }
    }

    /// <summary>
    /// �v���X�ֵ��G�A�Ω���̲ܳץͮĪ��v��
    /// </summary>
    public class PermissionMergeResult
    {
        public string Module { get; set; }
        public string Page { get; set; }
        public string Control { get; set; }
        public string Action { get; set; }
        public string PermissionString { get; set; }

        /// <summary>
        /// �̲ץͮĪ��v������
        /// </summary>
        public PermissionType FinalType { get; set; }

        /// <summary>
        /// �M�w�̲��v�����ӷ�
        /// </summary>
        public PermissionSource DecidingSource { get; set; }

        /// <summary>
        /// �M�w�̲��v�����ӷ��W��
        /// </summary>
        public string DecidingSourceName { get; set; }

        /// <summary>
        /// �O�_���Ĭ�]�h�Өӷ��w�q�F���P���v�������^
        /// </summary>
        public bool HasConflict { get; set; }

        /// <summary>
        /// �Ҧ��������v���ӷ�
        /// </summary>
        public List<PermissionItemViewModel> AllSources { get; set; } = new List<PermissionItemViewModel>();
    }

    /// <summary>
    /// �v���Ĭ���ϼҫ�
    /// </summary>
    public class PermissionConflictViewModel
    {
        public string Module { get; set; }
        public string Page { get; set; }
        public string Control { get; set; }
        public string Action { get; set; }
        public string PermissionString { get; set; }

        /// <summary>
        /// �������]�w
        /// </summary>
        public PermissionType? DepartmentSetting { get; set; }
        public string DepartmentName { get; set; }

        /// <summary>
        /// �s�ժ��]�w�]�i�঳�h�ӡ^
        /// </summary>
        public List<(string GroupName, PermissionType Type)> UserGroupSettings { get; set; }
            = new List<(string GroupName, PermissionType Type)>();

        /// <summary>
        /// �ӤH���]�w
        /// </summary>
        public PermissionType? EmployeeSetting { get; set; }

        /// <summary>
        /// �̲ץͮĪ��v��
        /// </summary>
        public PermissionType FinalType { get; set; }

        /// <summary>
        /// �Ĭ𵥯šG0=�L�Ĭ�, 1=�s�ն��Ĭ�, 2=�h�Ŷ��Ĭ�
        /// </summary>
        public int ConflictLevel { get; set; }

        /// <summary>
        /// �Ĭ�y�z
        /// </summary>
        public string ConflictDescription { get; set; }
    }
}
