﻿namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 權限設定介面互相傳遞訊息用。
    /// </summary>
    public class PermissionSettingInfo
    {
        /// <summary>
        /// 權限來源。
        /// </summary>
        public PermissionSource PermissionSource { get; set; }

        /// <summary>
        /// 部門代號。
        /// </summary>
        public int DepartmentId { get; set; }

        /// <summary>
        /// 群組代號。
        /// </summary>
        public int UserGroupId { get; set; }

        /// <summary>
        /// 員工工號。
        /// </summary>
        public string EmployeeId { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ModuleName { get; set; }
    }
}
