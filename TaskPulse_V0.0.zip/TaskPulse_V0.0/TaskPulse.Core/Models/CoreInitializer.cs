﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using Calin.TaskPulse.Core.Models.Import;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using MiniExcelLibs;
using Newtonsoft.Json;
using SQLite.CodeFirst;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Models
{
    /********************
     * SqliteDropCreateDatabaseAlways // 每次執行都刪除並重建資料庫
     * SqliteCreateDatabaseIfNotExists // 如果資料庫不存在，則建立資料庫並初始化預設資料。
     * SqliteDropCreateDatabaseWhenModelChanges // 如果模型有變更，則刪除並重建資料庫。
     ********************/
    /// <summary>
    /// AssetCode First 初始化類別。
    /// </summary>
    /// <remarks>參見: <see href="https://github.com/msallin/SQLiteCodeFirst#initializer-sample">Initializer Sample</see>。</remarks>
    public class CoreInitializer : SqliteCreateDatabaseIfNotExists<CoreContext>
    {
        public CoreInitializer(DbModelBuilder modelBuilder) : base(modelBuilder)
        {
        }

        protected override void Seed(CoreContext context)
        {
            SplashMessenger.Post("資料庫檔案找不到，重建中...");
            SplashMessenger.Post("資料庫重建 (1/6) ...");

            int recCount;
            int orderNo1;
            int orderNo2;

            orderNo1 = 0;
            var dbDep = context.Set<Department>();
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "設備部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "組裝製造部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "第一製造部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "製品技術部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "機構設計課" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "機構設計課2" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "機構開發部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "機構開發部2" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "成形部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "模具部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "元件開發部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "光學開發部" });
            dbDep.Add(new Department() { OrderNo = ++orderNo1, DepartmentName = "光學開發部2" });

            orderNo1 = 0;
            var dbTitle = context.Set<JobTitle>();
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "經理" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "副理" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "課長" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "副課長" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "主任" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "副主任" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "高級工程師" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "工程師" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "副工程師" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "管理師" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "副管理師" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "領班" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "高級技術員" });
            dbTitle.Add(new JobTitle() { OrderNo = ++orderNo1, JobTitleName = "技術員" });

            orderNo1 = 0;
            var dbStatus = context.Set<EmployeeStatus>();
            dbStatus.Add(new EmployeeStatus() { OrderNo = ++orderNo1, StatusName = "在職" });
            dbStatus.Add(new EmployeeStatus() { OrderNo = ++orderNo1, StatusName = "已離職" });
            dbStatus.Add(new EmployeeStatus() { OrderNo = ++orderNo1, StatusName = "已轉調" });
            dbStatus.Add(new EmployeeStatus() { OrderNo = ++orderNo1, StatusName = "留職停薪" });
            dbStatus.Add(new EmployeeStatus() { OrderNo = ++orderNo1, StatusName = "退休" });

            orderNo1 = 0;
            var dCategory = context.Set<MachineCategory>();
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo1, CategoryName = "半自動生產設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo1, CategoryName = "全自動生產設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo1, CategoryName = "檢測設備" });
            dCategory.Add(new MachineCategory() { OrderNo = ++orderNo1, CategoryName = "其他" });

            orderNo1 = 0;
            var dType = context.Set<MachineType>();
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "打壓機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "插入機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "斜點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "中壓斜點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "桌上型點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "熔著機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo1, TypeName = "21039自動線" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "UV照射機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "氣動式出膠機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo1, TypeName = "氣密檢漏儀" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo1, TypeName = "氣密自動檢測設備" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "鎖附機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo1, TypeName = "PF機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo1, TypeName = "儀科MTF機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo1, TypeName = "鬼影機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "鉚合機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo1, TypeName = "切割機" });
            dType.Add(new MachineType() { CategoryId = 3, OrderNo = ++orderNo1, TypeName = "高度量測" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo1, TypeName = "自動組裝機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo1, TypeName = "自動整列機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo1, TypeName = "高速點膠機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo1, TypeName = "自動鎖附機" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo1, TypeName = "三合一點膠機" });
            dType.Add(new MachineType() { CategoryId = 1, OrderNo = ++orderNo1, TypeName = "貼膜設備" });
            dType.Add(new MachineType() { CategoryId = 2, OrderNo = ++orderNo1, TypeName = "調芯機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo1, TypeName = "拆解機" });
            dType.Add(new MachineType() { CategoryId = 4, OrderNo = ++orderNo1, TypeName = "成形扭斷" });

            orderNo1 = 0;
            var brand = context.Set<MachineBrand>();
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "自製" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "晟普" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "點膠科技" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "稼動科技" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "立璽(LIHSI)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "高興易" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "衫綺" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "勛凱" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "USHIO" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "KGN" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "MUSASHI" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "IEI(iwashita instrumemt)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "九驊" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "儀科" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "客戶製" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "元利盛(EVEST)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "翔元(SYAUTO)" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "瀚升" });
            brand.Add(new MachineBrand() { OrderNo = ++orderNo1, BrandName = "儀銳" });

            orderNo1 = 0;
            var cond = context.Set<MachineCondition>();
            cond.Add(new MachineCondition() { OrderNo = ++orderNo1, ConditionName = "停動中" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo1, ConditionName = "稼動中" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo1, ConditionName = "檢討室" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo1, ConditionName = "RD檢討室" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo1, ConditionName = "微小倉庫" });
            cond.Add(new MachineCondition() { OrderNo = ++orderNo1, ConditionName = "試作線上" });

            var mStatus = context.Set<ModelStatus>();
            mStatus.Add(new ModelStatus() { Status = "生產中", OrderNo = 1 });
            mStatus.Add(new ModelStatus() { Status = "停產中", OrderNo = 2 });
            mStatus.Add(new ModelStatus() { Status = "試產中", OrderNo = 3 });

            var model = context.Set<Model>();
            model.Add(new Model() { ModelStatusId = 1, ModelName = "其他" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "155" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "260" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "271" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "273" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "281" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "283" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "366" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "453" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "459" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "467" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "561" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "563" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "568" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "570" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "575" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "585" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "19008" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "20006" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "20007" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "20019" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "20056" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "21018" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "21028" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "21039" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "22001" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "23010" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "23021" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "23069" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "23070" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "23071" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "23073" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "24301" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "132-07" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "19003-04" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "19003-06" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "20007-AS2" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "20007-AS3" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "417-01" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "417-02" });
            model.Add(new Model() { ModelStatusId = 1, ModelName = "568-02" });

            //var fLoc = context.Set<Factory>();
            //fLoc.Add(new Factory() { FactoryName = "本廠" });
            //fLoc.Add(new Factory() { FactoryName = "區北廠" });
            //fLoc.Add(new Factory() { FactoryName = "嘉義廠" });

            orderNo1 = 0;
            var mu = context.Set<MaintenanceUnit>();
            mu.Add(new MaintenanceUnit() { OrderNo = ++orderNo1, UnitName = "工具/設計課" });
            mu.Add(new MaintenanceUnit() { OrderNo = ++orderNo1, UnitName = "自働化課" });

            orderNo1 = 0;
            var ic = context.Set<IssueCategory>();
            ic.Add(new IssueCategory() { OrderNo = ++orderNo1, CategoryName = "日常維護" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo1, CategoryName = "機台保養" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo1, CategoryName = "更換零件" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo1, CategoryName = "機台改線" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo1, CategoryName = "故障中待協助" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo1, CategoryName = "異常排除" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo1, CategoryName = "機台功能追加" });
            ic.Add(new IssueCategory() { OrderNo = ++orderNo1, CategoryName = "機台移動" });

            //orderNo1 = 0;
            //var ru = context.Set<RequestingUnit>();
            //ru.Add(new RequestingUnit() { OrderNo = ++orderNo1, UnitName = "組立" });
            //ru.Add(new RequestingUnit() { OrderNo = ++orderNo1, UnitName = "製技" });
            //ru.Add(new RequestingUnit() { OrderNo = ++orderNo1, UnitName = "RD" });
            //ru.Add(new RequestingUnit() { OrderNo = ++orderNo1, UnitName = "試作" });
            //ru.Add(new RequestingUnit() { OrderNo = ++orderNo1, UnitName = "試作開發" });
            //ru.Add(new RequestingUnit() { OrderNo = ++orderNo1, UnitName = "品管" });

            context.SaveChanges();

            /********************
             * User
             ********************/
            SplashMessenger.Post("資料庫重建 (2/6) ...");

            var dep = dbDep.ToList();
            var title = dbTitle.ToList();
            var employees = context.Set<Employee>();

            using (var stream = File.OpenRead("人員名冊Import.xlsx"))
            {
                var rows = stream.Query<ExcelEmployee>(sheetName: "Import",
                                                       excelType: ExcelType.XLSX,
                                                       hasHeader: true).ToList();
                foreach (var row in rows)
                {
                    employees.Add(new Employee()
                    {
                        EmployeeId = row.EmployeeId,
                        EmployeeName = row.Name,
                        DepartmentId = dbDep.FirstOrDefault(d => d.DepartmentName == row.Department)?.Id,
                        JobTitleId = dbTitle.FirstOrDefault(t => t.JobTitleName == row.Title)?.Id,
                        IsEngineer = (row.IsEngineer ?? "") == "V",
                        StatusId = (row.Status ?? "") == "V" ? 1 : 2,
                        Email = row.Email,
                    });
                }
            }

            context.SaveChanges();

            var machines = context.Set<Machine>();
            var wss = context.Set<Workstation>();
            //var assCode = context.Set<MachineAssetCode>();
            var ctLoc = context.Set<MachineLocation>();

            try
            {
                SplashMessenger.Post("資料庫重建 (3/6) ...");

                //var machineName = context.Set<MachineNames>();
                var machineName = new HashSet<(string Model, string TypeName)>(context.MachineNames
                    .Include(d => d.MachineType)
                    .Include(d => d.MachineType.Category)
                    .Select(d => new { d.ModelName, d.MachineType.TypeName })
                    .AsEnumerable()
                    .Select(x => (x.ModelName, x.TypeName))
                    );

                ////var factory = context.Set<MachineLocation>();
                //var factory = new HashSet<(string Factory, string Location)>(context.MachineLocations
                //    .Include(d => d.Factory)
                //    .Select(d => new { d.Factory.FactoryName, d.Location })
                //    .AsEnumerable()
                //    .Select(x => (x.FactoryName, x.Location))
                //    );

                /********************
                 * MachineName
                 ********************/
                recCount = 0;
                orderNo1 = 0;
                orderNo2 = 0;
                using (var stream = File.OpenRead("設備清單Import.xlsx"))
                {
                    var rows = stream.Query<ExcelMachine>(sheetName: "Import",
                                                          excelType: ExcelType.XLSX,
                                                          hasHeader: true).ToList();
                    foreach (var row in rows)
                    {
                        var type = (row.Type ?? "").Trim();
                        var mName = (row.Name ?? "").Trim();
                        var dKey = (mName, type);
                        if (!machineName.Contains(dKey))
                        {
                            var mn = new MachineName
                            {
                                MachineType = dType.FirstOrDefault(x => x.TypeName == type),
                                ModelName = mName,
                                OrderNo = ++orderNo2,
                            };

                            context.MachineNames.Add(mn);
                            machineName.Add(dKey);
                        }

                        var loc = (row.Location ?? "").Trim() + ", " + (row.Position ?? "").Trim();
                        var oLoc = ctLoc.FirstOrDefault(x => x.LocationName == loc);
                        if (oLoc == null && loc.Trim() != ",")
                        {
                            ctLoc.Add(new MachineLocation { LocationName = loc, OrderNo = ++orderNo1 });
                            context.SaveChanges();
                        }
                    }
                }
                context.SaveChanges();

                /********************
                 * Model-Workstation
                 ********************/
                SplashMessenger.Post("資料庫重建 (4/6) ...");

                using (var stream = File.OpenRead("設備維修履歷Import.xlsx"))
                {
                    var rows = stream.Query<ExcelFlow>(sheetName: "Import",
                                                          excelType: ExcelType.XLSX,
                                                          hasHeader: true).ToList();
                    foreach (var row in rows)
                    {
                        Model thisModel = null;
                        string moData = (row.Model ?? "").Trim();
                        if (!string.IsNullOrWhiteSpace(moData))
                        {
                            thisModel = model.FirstOrDefault(x => x.ModelName == moData);
                        }

                        var wsData = (row.Workstation ?? "").Trim();
                        if (!string.IsNullOrWhiteSpace(wsData))
                        {
                            var ws = wss.FirstOrDefault(x => x.WorkstationName == wsData && x.Model.ModelName == moData);
                            if (ws == null)
                            {
                                ws = new Workstation()
                                {
                                    WorkstationName = wsData,
                                    Model = thisModel,
                                    OrderNo = ++orderNo1,
                                };
                                wss.Add(ws);
                                context.SaveChanges();
                            }
                        }
                    }
                    context.SaveChanges();
                }

                /********************
                 * MachineLocations
                 ********************/
                SplashMessenger.Post("資料庫重建 (5/6) ...");

                recCount = 0;
                orderNo1 = 0;
                using (var stream = File.OpenRead("設備清單Import.xlsx"))
                {
                    var rows = stream.Query<ExcelMachine>(sheetName: "Import",
                                                          excelType: ExcelType.XLSX,
                                                          hasHeader: true).ToList();
                    foreach (var row in rows)
                    {
                        var machine = new Machine();

                        string MachineCode = (row.MachineCode ?? "").Trim();
                        machine.MachineCode = MachineCode;

                        var type = (row.Type ?? "").Trim();
                        var mName = (row.Name ?? "").Trim();
                        var mn = context.MachineNames.FirstOrDefault(x => x.ModelName == mName && x.MachineType.TypeName == type);
                        var oType = context.MachineTypes.FirstOrDefault(ty => ty.TypeName == type);
                        if (mn != null)
                        {
                            machine.MachineName = mn;
                            machine.MachineName.TypeId = oType?.Id;
                        }

                        var bName = (row.Brand ?? "").Trim();
                        machine.Brand = brand.FirstOrDefault(x => x.BrandName == bName);
                        machine.SerialNumber = (row.SerialNumber ?? "").Trim();

                        List<string> assets = new List<string>();
                        var ass = (row.Assets ?? "").Trim();
                        {
                            if (ass.StartsWith("\""))
                                ass = ass.Substring(1, ass.Length - 2);
                            assets = ass.Split(new[] { "\n" }, StringSplitOptions.RemoveEmptyEntries)
                                        .Select(x => x.Trim())
                                        .Where(x => x != "無" && !string.IsNullOrWhiteSpace(x))
                                        .Distinct()
                                        .ToList();
                        }
                        machine.Assets = JsonConvert.SerializeObject(assets);

                        machine.LocationId = 0;
                        var loc = $"{(row.Location ?? "").Trim()}, {(row.Position ?? "").Trim()}";
                        var mmLoc = context.MachineLocations.FirstOrDefault(x => x.LocationName == loc);
                        if (mmLoc != null && loc.Trim() != ",")
                            machine.LocationId = mmLoc.Id;

                        var cnd = (row.Condition ?? "").Trim();
                        machine.Condition = cond.FirstOrDefault(x => x.ConditionName == cnd);
                        machine.Barcode = row.Barcode?.Trim() ?? "" ?? "";
                        machine.Connected = (row.Connected ?? "").Trim() == "V";
                        machine.Disposal = MachineCode == "SAL-1";
                        machine.Remark = (row.Remark ?? "").Trim();

                        machines.Add(machine);
                    }
                    context.SaveChanges();
                }

                /********************
                 * TaskOrder
                 ********************/
                SplashMessenger.Post("資料庫重建 (6/6) ...");

                recCount = 0;
                orderNo1 = 0;
                using (var stream = File.OpenRead("設備維修履歷Import.xlsx"))
                {
                    var mod = context.Set<Model>().ToList();
                    var machine = context.Set<Machine>().Include(m => m.MachineName).ToList();
                    var engineers = context.Set<Employee>().Where(e => e.IsEngineer).ToList();

                    var tos = context.Set<TaskOrder>();
                    string data;
                    string[] sList;

                    var rows = stream.Query<ExcelFlow>(sheetName: "Import",
                                                       excelType: ExcelType.XLSX,
                                                       hasHeader: true).ToList();
                    foreach (var row in rows)
                    {
                        recCount++;
                        var to = new TaskOrder();
                        string workOrderNo = (row.WorkOrderNo ?? "").Trim();

                        to.WorkOrderNo = workOrderNo;

                        string empName = (row.Creator ?? "").Trim();
                        to.Creator = employees.FirstOrDefault(x => x.EmployeeName == empName);
                        //to.CreatorId = (to.CreatorName != null) ? to.CreatorName.Id : string.Empty;

                        to.CreationDateTime = DateTime.Parse(row.CreationDateTime ?? "");

                        string muName = (row.MaintenanceUnit ?? "").Trim();
                        if (muName == "工具設計")
                            to.MaintenanceUnit = mu.FirstOrDefault(x => x.Id == 1);
                        else
                            to.MaintenanceUnit = mu.FirstOrDefault(x => x.Id == 2);

                        sList = row.Engineers?.Split('/') ?? new string[0];
                        to.Engineers = new List<Employee>();
                        foreach (var d5 in sList)
                        {
                            var e = engineers.FirstOrDefault(x => x.EmployeeName == d5);
                            if (e != null)
                                to.Engineers.Add(e);
                        }

                        data = (row.MachineCode ?? "").Trim();
                        var mac = machine.FirstOrDefault(x => x.MachineCode == data);
                        to.MachineId = (mac != null) ? mac.Id : 0;
                        to.Machine = null;

                        //var d6 = datas[6].Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries)
                        //                .Select(x => x.Trim())
                        //                .Where(x => !string.IsNullOrWhiteSpace(x))
                        //                .Distinct()
                        //                .ToList();
                        //to.MachineId = new List<MachineId>();
                        //foreach (var d_6 in d6)
                        //{
                        //    var mch = deviceList.FirstOrDefault(x => x.MachineId == d_6);
                        //    if (mch != null)
                        //        to.MachineId.Add(new MachineId
                        //        {
                        //            WorkOrderNo = workOrderNo,
                        //            MachineId = mch.MachineId,
                        //        });
                        //}

                        DateTime cdt = to.CreationDateTime;
                        if (!string.IsNullOrEmpty(row.RepairStarted))
                            to.AcceptedTime = cdt + TimeSpan.Parse(row.RepairStarted);

                        //to.AcceptedTime = DateTime.Parse(string.Concat(row.CreationDateTime ?? "", " ", row.RepairStarted ?? "").Trim());

                        if (!string.IsNullOrEmpty(row.RepairStarted))
                            to.RepairStarted = cdt + TimeSpan.Parse(row.RepairStarted);
                        else
                            to.RepairStarted = null;

                        if (!string.IsNullOrEmpty(row.RepairCompleted))
                            to.RepairCompleted = cdt + TimeSpan.Parse(row.RepairCompleted);
                        else
                            to.RepairCompleted = null;

                        if (int.TryParse(row.RepairDuration ?? "", out int rd))
                            to.RepairDuration = TimeSpan.FromMinutes(rd);
                        else
                        {
                            if (to.RepairStarted == null || to.RepairCompleted == null)
                                to.RepairDuration = TimeSpan.Zero;
                            else
                                to.RepairDuration = (TimeSpan)(to.RepairCompleted - to.RepairStarted);
                        }

                        if (!string.IsNullOrEmpty(row.OutageStarted))
                            to.OutageStarted = cdt + TimeSpan.Parse(row.OutageStarted);
                        else
                            to.OutageStarted = null;

                        if (!string.IsNullOrEmpty(row.OutageEnded))
                            to.OutageEnded = cdt + TimeSpan.Parse(row.OutageEnded);
                        else
                            to.OutageEnded = null;

                        if (int.TryParse(row.OutageDuration ?? "", out int od))
                            to.OutageDuration = TimeSpan.FromMinutes(od);
                        else
                        {
                            if (to.OutageEnded == null || to.OutageStarted == null)
                                to.OutageDuration = TimeSpan.Zero;
                            else
                                to.OutageDuration = (TimeSpan)(to.OutageEnded - to.OutageStarted);
                        }

                        //if (!string.IsNullOrWhiteSpace(datas[15]))
                        //{
                        //    string name = datas[15].Trim();
                        //    to.Model = mod.FirstOrDefault(x => x.Value == name);
                        //    if (to.Model == null)
                        //    {
                        //        var newModel = new Model() { Value = name };
                        //        mod.Add(newModel);
                        //        context.SaveChanges();
                        //        //to.Value = newModel;
                        //        //to.Value = newModel.Value;
                        //    }
                        //}

                        data = (row.Workstation ?? "").Trim();
                        var ws = wss.FirstOrDefault(x => x.WorkstationName == data);
                        if (ws != null)
                        {
                            to.Workstation = ws;
                        }

                        if (!string.IsNullOrWhiteSpace(row.IssueCategory))
                        {
                            string name = (row.IssueCategory ?? "").Trim();
                            to.IssueCategory = ic.FirstOrDefault(x => x.CategoryName == name);
                        }
                        else
                        {
                            to.IssueCategory = null;
                        }

                        to.IssueDescription = (row.IssueDescription ?? "").Trim();
                        to.Details = (row.Details ?? "").Trim();

                        if (!string.IsNullOrWhiteSpace(row.RequestingUnit))
                        {
                            string name = (row.RequestingUnit ?? "").Trim();
                            to.RequestingUnit = dep.FirstOrDefault(x => x.DepartmentName == name);
                        }
                        else
                        {
                            to.RequestingUnit = null;
                        }

                        if (!string.IsNullOrWhiteSpace(row.FeedbackEmployee))
                        {
                            string name = (row.FeedbackEmployee ?? "").Trim();
                            to.FeedbackEmployee = employees.FirstOrDefault(x => x.EmployeeName == name);
                        }
                        else
                        {
                            to.FeedbackEmployee = null;
                        }

                        to.Status = FlowStatus.Completed;
                        //if (!string.IsNullOrWhiteSpace(datas[22]))
                        //{
                        //    string name = datas[22].Trim();
                        //    to.Condition = st.FirstOrDefault(x => x.Condition == name);
                        //}
                        //if (to.Condition == null)
                        //    to.Condition = st.FirstOrDefault(x => x.Condition == "待處理");

                        to.Feedback = (row.Feedback ?? "").Trim();
                        to.Responsible = string.Empty;

                        tos.Add(to);
                    }
                    context.SaveChanges();
                }




                //recCount = 0;
                //orderNo1 = 0;
                //orderNo2 = 0;
                //// 一對多
                //using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                //{
                //    while (sr.Peek() != -1)
                //    {
                //        recCount++;
                //        string[] data = sr.ReadLine().Split('\t');

                //        if (recCount > 1) // 去掉標題
                //        {
                //            var type = data[1].Trim();
                //            var mName = data[3].Trim();
                //            var dKey = (mName, type);
                //            if (!machineName.Contains(dKey))
                //            {
                //                var mn = new MachineName
                //                {
                //                    MachineType = dType.FirstOrDefault(x => x.TypeName == type),
                //                    ModelName = mName,
                //                    OrderNo = ++orderNo2,
                //                };

                //                context.MachineNames.Add(mn);
                //                machineName.Add(dKey);
                //            }

                //            //if (machineName.Local.FirstOrDefault(x => x.Value == mName && x.MachineType.TypeName == type) == null)
                //            //{
                //            //    machineName.Add(new MachineNames()
                //            //    {
                //            //        MachineType = dType.FirstOrDefault(x => x.TypeName == type),
                //            //        Value = mName,
                //            //    });
                //            //}

                //            var loc = $"{data[6].Trim()}, {data[7].Trim()}";
                //            var oLoc = ctLoc.FirstOrDefault(x => x.Location == loc);
                //            if (oLoc == null)
                //            {
                //                ctLoc.Add(new MachineLocation { Location = loc, OrderNo = ++orderNo1 });
                //                context.SaveChanges();
                //            }

                //            //if (!factory.Contains(fKey))
                //            //{
                //            //    var newLoc = new MachineLocation
                //            //    {
                //            //        Factory = fLoc.FirstOrDefault(x => x.FactoryName == fac),
                //            //        Location = loc,
                //            //    };

                //            //    context.MachineLocations.Add(newLoc);
                //            //    factory.Add(fKey);
                //            //}

                //            //if (factory.FirstOrDefault(x => x.Location == loc && x.Factory.FactoryName == fac) == null)
                //            //{
                //            //    factory.Add(new MachineLocation()
                //            //    {
                //            //        Factory = fLoc.FirstOrDefault(x => x.FactoryName == fac),
                //            //        Location = loc,
                //            //    });
                //            //}
                //        }
                //    }
                //    context.SaveChanges();
                //}

                ///********************
                // * WorkstationName
                // ********************/
                //recCount = 0;
                //orderNo1 = 0;
                //using (var sr = new StreamReader("設備維修履歷_Import.txt", Encoding.Default))
                //{
                //    while (sr.Peek() != -1)
                //    {
                //        recCount++;
                //        string[] data = sr.ReadLine().Split('\t');

                //        if (recCount > 1) // 去掉標題
                //        {
                //            Model thisModel = null;
                //            string moData = default;
                //            if (!string.IsNullOrWhiteSpace(data[15]))
                //            {
                //                moData = data[15].Trim();
                //                thisModel = model.FirstOrDefault(x => x.ModelName == moData);
                //            }

                //            if (!string.IsNullOrWhiteSpace(data[16]))
                //            {
                //                var wsData = data[16].Trim();
                //                var ws = wss.FirstOrDefault(x => x.WorkstationName == wsData && x.Model.ModelName == moData);
                //                if (ws == null)
                //                {
                //                    ws = new Workstation()
                //                    {
                //                        WorkstationName = wsData,
                //                        Model = thisModel,
                //                        OrderNo = ++orderNo1,
                //                    };
                //                    wss.Add(ws);
                //                    context.SaveChanges();
                //                }
                //            }
                //        }
                //    }
                //    context.SaveChanges();
                //}

                ///********************
                // * MachineLocations
                // ********************/
                //recCount = 0;
                //orderNo1 = 0;
                //using (var sr = new StreamReader("設備清單_Import.txt", Encoding.Default))
                //{
                //    while (sr.Peek() != -1)
                //    {
                //        recCount++;
                //        string[] data = sr.ReadLine().Split('\t');

                //        if (recCount > 1) // 去掉標題
                //        {
                //            var machine = new Machine();

                //            string machineId = data[0].Trim();
                //            machine.MachineId = machineId;

                //            var type = data[1].Trim();
                //            var mName = data[3].Trim();
                //            var mn = context.MachineNames.FirstOrDefault(x => x.ModelName == mName && x.MachineType.TypeName == type);
                //            if (mn != null)
                //            {
                //                machine.MachineName = mn;
                //            }

                //            var bName = data[2].Trim();
                //            machine.Brand = brand.FirstOrDefault(x => x.BrandName == bName);
                //            machine.SerialNumber = data[4].Trim();

                //            if (data[5].StartsWith("\""))
                //                data[5] = data[5].Substring(1, data[5].Length - 2);
                //            var assets = data[5].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                //                            .Select(x => x.Trim())
                //                            .Where(x => x != "無" && !string.IsNullOrWhiteSpace(x))
                //                            .Distinct()
                //                            .ToList();
                //            machine.Assets = new List<MachineAssetCode>();
                //            foreach (var a in assets)
                //                machine.Assets.Add(new MachineAssetCode() { AssetCode = a });

                //            var loc = $"{data[6].Trim()}, {data[7].Trim()}";
                //            var mmLoc = context.MachineLocations.FirstOrDefault(x => x.Location == loc);
                //            if (mmLoc != null)
                //                machine.Location = mmLoc;

                //            var cnd = data[8].Trim();
                //            machine.Condition = cond.FirstOrDefault(x => x.Condition == cnd);
                //            machine.Barcode = data[9].Trim();
                //            machine.Connected = !string.IsNullOrWhiteSpace(data[10].Trim());
                //            machine.Remark = data[11].Trim();

                //            machines.Add(machine);
                //        }
                //    }

                //    var t = machines.FirstOrDefault(x => x.MachineId == "SAL-1");
                //    if (t != null)
                //        t.Disposal = true;
                //    context.SaveChanges();
                //}

                ///********************
                // * 
                // ********************/

                ////var depList = context.Set<Department>();
                ////foreach (var dl in depList)
                ////{
                ////    dbDep.Add(new Department() { DepartmentName = dl.DepartmentName, });
                ////}

                ////var titleList = context.Set<Title>();
                ////var dbTitle = context.Set<Title>();
                ////foreach (var tl in titleList)
                ////{
                ////    dbTitle.Add(new Title() { TitleName = tl.TitleName, });
                ////}
                ////context.SaveChanges();

                ////var empList = context.Set<User>()
                ////    .OrderBy(e => e.Id)
                ////    .ToList();
                ////var employees = context.Set<User>();
                ////var buffs = empList.Select(e =>
                ////{
                ////    var dd = dbDep.FirstOrDefault(d => d.Key == e.Key);
                ////    var tt = (e.Key > 0) ? dbTitle.FirstOrDefault(d => d.Key == e.Key) : null;

                ////    return new User
                ////    {
                ////        Id = e.Id,
                ////        UnitName = e.UnitName,
                ////        Department = dd,
                ////        Title = tt,
                ////        IsEngineer = e.IsEngineer,
                ////    };
                ////}).ToList();
                ////employees.AddRange(buffs);

                ////var deviceList = context.Set<Core.Models.MachineLocations>()
                ////    .Include(d => d.MachineName.MachineType)
                ////    .ToList();
                ////var mn = context.Set<MachineLocations>();
                ////foreach (var w in deviceList)
                ////{
                ////    mn.Add(new MachineLocations()
                ////    {
                ////        MachineId = w.MachineId,
                ////        MachineName = w.MachineName,
                ////    });
                ////}

                ////var modelList = context.Set<Model>().ToList();
                ////foreach (var ml in modelList)
                ////{
                ////    model.Add(new Model()
                ////    {
                ////        Value = ml.Value,
                ////    });
                ////}
                ////context.SaveChanges();

                ////var workstationList = context.Set<WorkstationName>().ToList();
                ////foreach (var w in workstationList)
                ////{
                ////    var mb = model.FirstOrDefault(m => m.Key == w.Key);
                ////    wss.Add(new WorkstationName()
                ////    {
                ////        WorkstationName = w.WorkstationName,
                ////        Model = mb,
                ////    });
                ////}
                ////context.SaveChanges();

                ///********************
                // * TaskOrder
                // ********************/
                //recCount = 0;
                //orderNo1 = 0;
                //using (var sr = new StreamReader("設備維修履歷_Import.txt", Encoding.Default))
                //{
                //    string[] sList;

                //    var mod = context.Set<Model>().ToList();
                //    var machine = context.Set<Machine>().Include(m => m.MachineName).ToList();
                //    var engineers = context.Set<User>().Where(e => e.IsEngineer).ToList();

                //    var tos = context.Set<TaskOrder>();
                //    string data;

                //    while (sr.Peek() != -1)
                //    {
                //        recCount++;
                //        string[] datas = sr.ReadLine().Split('\t');

                //        if (recCount > 1) // 去掉標題
                //        {
                //            var to = new TaskOrder();
                //            string workOrderNo = datas[1].Trim();

                //            to.WorkOrderNo = workOrderNo;

                //            string empName = datas[2].Trim();
                //            to.Creator = employees.FirstOrDefault(x => x.Name == empName);
                //            //to.CreatorId = (to.CreatorName != null) ? to.CreatorName.Id : string.Empty;

                //            to.CreationDateTime = DateTime.Parse(datas[3]);

                //            string muName = datas[4].Trim();
                //            if (muName == "工具設計")
                //                to.MaintenanceUnit = mu.FirstOrDefault(x => x.Id == 1);
                //            else
                //                to.MaintenanceUnit = mu.FirstOrDefault(x => x.Id == 2);

                //            sList = datas[5].Split('/');
                //            to.Engineers = new List<User>();
                //            foreach (var d5 in sList)
                //            {
                //                var e = engineers.FirstOrDefault(x => x.Name == d5);
                //                if (e != null)
                //                    to.Engineers.Add(e);
                //            }

                //            data = datas[6].Trim();
                //            var mac = machine.FirstOrDefault(x => x.MachineId == data);
                //            to.MachineId = (mac != null) ? mac.Id : 0;
                //            to.Machine = null;

                //            //var d6 = datas[6].Split(new[] { '_' }, StringSplitOptions.RemoveEmptyEntries)
                //            //                .Select(x => x.Trim())
                //            //                .Where(x => !string.IsNullOrWhiteSpace(x))
                //            //                .Distinct()
                //            //                .ToList();
                //            //to.MachineId = new List<MachineId>();
                //            //foreach (var d_6 in d6)
                //            //{
                //            //    var mch = deviceList.FirstOrDefault(x => x.MachineId == d_6);
                //            //    if (mch != null)
                //            //        to.MachineId.Add(new MachineId
                //            //        {
                //            //            WorkOrderNo = workOrderNo,
                //            //            MachineId = mch.MachineId,
                //            //        });
                //            //}

                //            to.AcceptedTime = DateTime.Parse(string.Concat(datas[3], " ", datas[7]));

                //            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[8]), out DateTime rs))
                //                to.RepairStarted = rs;
                //            else
                //                to.RepairStarted = null;

                //            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[9]), out DateTime rc))
                //                to.RepairCompleted = rc;
                //            else
                //                to.RepairCompleted = null;

                //            if (int.TryParse(datas[10], out int rd))
                //                to.RepairDuration = TimeSpan.FromMinutes(rd);
                //            else
                //            {
                //                if (rs == null || rc == null)
                //                    to.RepairDuration = TimeSpan.Zero;
                //                else
                //                    to.RepairDuration = rc - rs;
                //            }

                //            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[11]), out DateTime os))
                //                to.OutageStarted = os;
                //            else
                //                to.OutageStarted = null;

                //            if (DateTime.TryParse(string.Concat(datas[3], " ", datas[12]), out DateTime oe))
                //                to.OutageEnded = oe;
                //            else
                //                to.OutageEnded = null;

                //            if (int.TryParse(datas[13], out int od))
                //            //    to.OutageDuration = TimeSpan.FromMinutes(od);
                //            //else
                //            {
                //                if (os == null || oe == null)
                //                    to.OutageDuration = TimeSpan.Zero;
                //                else
                //                    to.OutageDuration = oe - os;
                //            }

                //            //if (!string.IsNullOrWhiteSpace(datas[15]))
                //            //{
                //            //    string name = datas[15].Trim();
                //            //    to.Model = mod.FirstOrDefault(x => x.Value == name);
                //            //    if (to.Model == null)
                //            //    {
                //            //        var newModel = new Model() { Value = name };
                //            //        mod.Add(newModel);
                //            //        context.SaveChanges();
                //            //        //to.Value = newModel;
                //            //        //to.Value = newModel.Value;
                //            //    }
                //            //}

                //            data = datas[16].Trim();
                //            var ws = wss.FirstOrDefault(x => x.WorkstationName == data);
                //            if (ws != null)
                //            {
                //                to.Workstation = ws;
                //            }

                //            if (!string.IsNullOrWhiteSpace(datas[17]))
                //            {
                //                string name = datas[17].Trim();
                //                to.IssueCategory = ic.FirstOrDefault(x => x.CategoryName == name);
                //            }
                //            else
                //            {
                //                to.IssueCategory = null;
                //            }

                //            to.IssueDescription = datas[18].Trim();
                //            to.Details = datas[19].Trim();

                //            if (!string.IsNullOrWhiteSpace(datas[20]))
                //            {
                //                string name = datas[20].Trim();
                //                to.RequestingUnit = ru.FirstOrDefault(x => x.UnitName == name);
                //            }
                //            else
                //            {
                //                to.RequestingUnit = null;
                //            }

                //            if (!string.IsNullOrWhiteSpace(datas[21]))
                //            {
                //                string name = datas[21].Trim();
                //                to.FeedbackEmployee = employees.FirstOrDefault(x => x.Name == name);
                //            }
                //            else
                //            {
                //                to.FeedbackEmployee = null;
                //            }

                //            to.Status = FlowStatus.Completed;
                //            //if (!string.IsNullOrWhiteSpace(datas[22]))
                //            //{
                //            //    string name = datas[22].Trim();
                //            //    to.Condition = st.FirstOrDefault(x => x.Condition == name);
                //            //}
                //            //if (to.Condition == null)
                //            //    to.Condition = st.FirstOrDefault(x => x.Condition == "待處理");

                //            to.Feedback = datas[23].Trim();
                //            to.Responsible = string.Empty;

                //            tos.Add(to);
                //        }
                //    }
                //    context.SaveChanges();
                //}
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    Console.WriteLine($"Entity of type '{eve.Entry.Entity.GetType().Name}' in state '{eve.Entry.State}' has the following validation errors:");

                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine($"- Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                    }
                }

                throw;
            }
            catch (Exception ex)
            {
                // 檢查 inner exception 是否為 DbEntityValidationException
                var validationException = ex as DbEntityValidationException
                    ?? ex.InnerException as DbEntityValidationException;

                if (validationException != null)
                {
                    foreach (var validationErrors in validationException.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            Console.WriteLine("❌ Entity: " + validationErrors.Entry.Entity.GetType().Name);
                            Console.WriteLine("   Property: " + validationError.PropertyName);
                            Console.WriteLine("   Error: " + validationError.ErrorMessage);
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"其他例外：{ex.ToString()}");
                }

                throw;
            }

            base.Seed(context);
        }
    }
}
