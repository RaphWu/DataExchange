﻿namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 分類資料。
    /// </summary>
    public class ClassifyInfo
    {
        public int Id { get; set; }
        public string IdString { get; set; }
        public string Category1 { get; set; }
        public string Category2 { get; set; }
        public string Name { get; set; }
    }
}
