﻿namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 簡單的分類資料。
    /// </summary>
    public class CategoryInfo
    {
        public int Id { get; set; }
        public string IdString { get; set; }
        public string Category1 { get; set; }
        public string Category2 { get; set; }
        public string Name { get; set; }
    }
}
