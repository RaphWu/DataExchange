using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_Permission
    {
        /// <summary> 
        /// �]�p�u��һݪ��ܼơC
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// �M������ϥΤ����귽�C
        /// </summary>
        /// <param name="disposing">�p�G���ӳB�m�����귽�h�� true�A�_�h�� false�C</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region ����]�p�u�㲣�ͪ��{���X

        /// <summary> 
        /// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边�ק�
        /// �o�Ӥ�k�����e�C
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeSource = new UITreeView();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPermissions = new System.Windows.Forms.TabPage();
            this.panelPermissions = new System.Windows.Forms.Panel();
            this.btnSave = new UIButton();
            this.tabMerged = new System.Windows.Forms.TabPage();
            this.dgvMergedPermissions = new System.Windows.Forms.DataGridView();
            this.tabConflicts = new System.Windows.Forms.TabPage();
            this.dgvConflicts = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabPermissions.SuspendLayout();
            this.tabMerged.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMergedPermissions)).BeginInit();
            this.tabConflicts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConflicts)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeSource);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl);
            this.splitContainer1.Size = new System.Drawing.Size(1200, 700);
            this.splitContainer1.SplitterDistance = 300;
            this.splitContainer1.TabIndex = 0;
            // 
            // treeSource
            // 
            this.treeSource.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeSource.Font = new System.Drawing.Font("�L�n������", 11F);
            this.treeSource.Location = new System.Drawing.Point(0, 0);
            this.treeSource.Name = "treeSource";
            this.treeSource.Size = new System.Drawing.Size(300, 700);
            this.treeSource.TabIndex = 0;
            this.treeSource.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TreeSource_AfterSelect);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPermissions);
            this.tabControl.Controls.Add(this.tabMerged);
            this.tabControl.Controls.Add(this.tabConflicts);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Font = new System.Drawing.Font("�L�n������", 11F);
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(896, 700);
            this.tabControl.TabIndex = 0;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.TabControl_SelectedIndexChanged);
            // 
            // tabPermissions
            // 
            this.tabPermissions.Controls.Add(this.btnSave);
            this.tabPermissions.Controls.Add(this.panelPermissions);
            this.tabPermissions.Location = new System.Drawing.Point(4, 28);
            this.tabPermissions.Name = "tabPermissions";
            this.tabPermissions.Padding = new System.Windows.Forms.Padding(3);
            this.tabPermissions.Size = new System.Drawing.Size(888, 668);
            this.tabPermissions.TabIndex = 0;
            this.tabPermissions.Text = "�v���]�w";
            this.tabPermissions.UseVisualStyleBackColor = true;
            // 
            // panelPermissions
            // 
            this.panelPermissions.AutoScroll = true;
            this.panelPermissions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPermissions.Location = new System.Drawing.Point(3, 3);
            this.panelPermissions.Name = "panelPermissions";
            this.panelPermissions.Size = new System.Drawing.Size(882, 622);
            this.panelPermissions.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnSave.Font = new System.Drawing.Font("�L�n������", 11F);
            this.btnSave.Location = new System.Drawing.Point(3, 625);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(882, 40);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "�x�s�v���]�w";
            //this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // tabMerged
            // 
            this.tabMerged.Controls.Add(this.dgvMergedPermissions);
            this.tabMerged.Location = new System.Drawing.Point(4, 28);
            this.tabMerged.Name = "tabMerged";
            this.tabMerged.Padding = new System.Windows.Forms.Padding(3);
            this.tabMerged.Size = new System.Drawing.Size(888, 668);
            this.tabMerged.TabIndex = 1;
            this.tabMerged.Text = "�X���v��";
            this.tabMerged.UseVisualStyleBackColor = true;
            // 
            // dgvMergedPermissions
            // 
            this.dgvMergedPermissions.AllowUserToAddRows = false;
            this.dgvMergedPermissions.AllowUserToDeleteRows = false;
            this.dgvMergedPermissions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMergedPermissions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMergedPermissions.Location = new System.Drawing.Point(3, 3);
            this.dgvMergedPermissions.Name = "dgvMergedPermissions";
            this.dgvMergedPermissions.ReadOnly = true;
            this.dgvMergedPermissions.RowTemplate.Height = 24;
            this.dgvMergedPermissions.Size = new System.Drawing.Size(882, 662);
            this.dgvMergedPermissions.TabIndex = 0;
            // 
            // tabConflicts
            // 
            this.tabConflicts.Controls.Add(this.dgvConflicts);
            this.tabConflicts.Location = new System.Drawing.Point(4, 28);
            this.tabConflicts.Name = "tabConflicts";
            this.tabConflicts.Size = new System.Drawing.Size(888, 668);
            this.tabConflicts.TabIndex = 2;
            this.tabConflicts.Text = "�v���Ĭ�";
            this.tabConflicts.UseVisualStyleBackColor = true;
            // 
            // dgvConflicts
            // 
            this.dgvConflicts.AllowUserToAddRows = false;
            this.dgvConflicts.AllowUserToDeleteRows = false;
            this.dgvConflicts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConflicts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvConflicts.Location = new System.Drawing.Point(0, 0);
            this.dgvConflicts.Name = "dgvConflicts";
            this.dgvConflicts.ReadOnly = true;
            this.dgvConflicts.RowTemplate.Height = 24;
            this.dgvConflicts.Size = new System.Drawing.Size(888, 668);
            this.dgvConflicts.TabIndex = 0;
            // 
            // Setup_Permission
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.splitContainer1);
            this.Name = "Setup_Permission";
            this.Size = new System.Drawing.Size(1200, 700);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.tabPermissions.ResumeLayout(false);
            this.tabMerged.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMergedPermissions)).EndInit();
            this.tabConflicts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvConflicts)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private UITreeView treeSource;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPermissions;
        private System.Windows.Forms.Panel panelPermissions;
        private UIButton btnSave;
        private System.Windows.Forms.TabPage tabMerged;
        private System.Windows.Forms.DataGridView dgvMergedPermissions;
        private System.Windows.Forms.TabPage tabConflicts;
        private System.Windows.Forms.DataGridView dgvConflicts;
    }
}
