﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Extensions;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using static Calin.TaskPulse.Core.Models.PropertyText;

namespace Calin.TaskPulse.Core.Views
{
    public partial class MachineEdit : UIForm
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;
        private readonly CRUD _crud;

        // ResultList Buffers
        private List<ClassifyInfo> _defaultWS = new List<ClassifyInfo>();
        private List<OptionalList> _existPrefix = new List<OptionalList>(); // 已存在的前綴
        private List<OptionalList> _thisPrefix = new List<OptionalList>(); // 此分類下的前綴
        private bool _suppressSelectionChanged = false;
        private bool _suppressMachineCodeChanged = false;

        #endregion fields

        public string Title { get; set; }
        public CrudType CrudType { get; set; }
        public MachineViewModel MachineValue { get; set; } = new MachineViewModel();

        public MachineEdit(
            CoreContext coreContext,
            CoreData coreData,
            MultiSelector multiSelector,
            CRUD crud)
        {
            //_isLoading = true;

            InitializeComponent();

            _context = coreContext;
            _coreData = coreData;
            _mSel = multiSelector;
            _crud = crud;
        }

        private async void MachineEdit_Load(object sender, EventArgs e)
        {
            //this.cbCategory.SelectedIndexChanged -= new System.EventHandler(this.cbCategory_SelectedIndexChanged);
            //this.cbType.SelectedIndexChanged -= new System.EventHandler(this.cbType_SelectedIndexChanged);
            //this.tbMachineCode.Validated -= new System.EventHandler(this.tbMaincheId_Validated);

            //_isLoading = true;
            _suppressSelectionChanged = true;
            _suppressMachineCodeChanged = true;

            this.Text = Title;
            tbMachineCode.Text = MachineValue.MachineCode;

            var listCategories = await _context.MachineCategories
                .OrderBy(c => c.OrderNo)
                .Select(c => new ListViewModel()
                {
                    Id = c.Id,
                    Name = c.CategoryName,
                    OrderNo = c.OrderNo,
                })
                .ToListAsync();
            listCategories.Insert(0, new ListViewModel()
            {
                Id = -1,
                Name = "",
                OrderNo = 0,
            });
            cbCategory.DataSource = listCategories;
            cbCategory.DisplayMember = "Name";
            cbCategory.ValueMember = "Id";
            //cbCategory.Enabled = false;
            //cbCategory.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            //cbType.DisplayMember = "Name";
            //cbType.ValueMember = "Id";
            //cbType.DataSource = await _context.MachineTypes
            //    .Where(t => t.CategoryId == MachineValue.CategoryId)
            //    .Select(c => new ListViewModel() { Id = c.Id, Name = c.TypeName })
            //    .ToListAsync();
            //cbType.Enabled = false;
            //cbType.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            //cbModelName.DisplayMember = "Name";
            //cbModelName.ValueMember = "Id";
            //cbModelName.DataSource = await _context.MachineNames
            //    .Where(t => t.TypeId == MachineValue.TypeId)
            //    .Select(c => new ListViewModel() { Id = c.Id, Name = c.ModelName })
            //    .ToListAsync();
            //cbModelName.Enabled = false;
            //cbModelName.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            cbCondition.DisplayMember = "Name";
            cbCondition.ValueMember = "Id";
            cbCondition.DataSource = await _context.MachineConditions
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.ConditionName })
                .ToListAsync();

            cbBrand.DisplayMember = "Name";
            cbBrand.ValueMember = "Id";
            cbBrand.DataSource = await _context.MachineBrands
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.BrandName })
                .ToListAsync();

            cbLocation.DisplayMember = "Name";
            cbLocation.ValueMember = "Id";
            cbLocation.DataSource = await _context.MachineLocations
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.LocationName })
                .ToListAsync();

            //cbConnected.DisplayMember = "Name";
            //cbConnected.ValueMember = "BooleanId";
            //cbConnected.DataSource = new List<ListViewModel>()
            //{
            //    new ListViewModel() { BooleanId = false, Name = "未連網" },
            //    new ListViewModel() { BooleanId= true, Name = "可連網" },
            //};

            //cbDisposal.DisplayMember = "Name";
            //cbDisposal.ValueMember = "BooleanId";
            //cbDisposal.DataSource = new List<ListViewModel>()
            //{
            //    new ListViewModel() {BooleanId = false, Name = "正常作業" },
            //    new ListViewModel() {BooleanId = true, Name = "已處置" },
            //};

            await UpdateTypeListAsync(MachineValue.CategoryId);
            await UpdateModelNameListAsync(MachineValue.TypeId);

            cbCategory.SelectedValue = MachineValue.CategoryId;
            cbType.SelectedValue = MachineValue.TypeId;
            cbModelName.SelectedValue = MachineValue.MachineNameId;
            cbCondition.SelectedValue = MachineValue.ConditionId;
            cbBrand.SelectedValue = MachineValue.BrandId;
            cbLocation.SelectedValue = MachineValue.LocationId;
            cbConnected.Checked = MachineValue.Connected;
            cbDisposal.Checked = MachineValue.Disposal;
            tbAssets.Text = MachineValue.AssetString;
            tbSerialNumber.Text = MachineValue.SerialNumber;
            tbBarcode.Text = MachineValue.Barcode;
            tbRemark.Text = MachineValue.Remark;

            CommonStyles.SetCheckBox(cbConnected);
            CommonStyles.SetCheckBox(cbDisposal);

            _suppressMachineCodeChanged = false;
            _suppressSelectionChanged = false;
            //_isLoading = false;

            SetOptionalMachineCode();
            ShowRepeatPrefix();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            // 若不是此分類，必需前綴是沒被使用的
            string prefix = GetMachineCodePrefix(tbMachineCode.Text);
            if (!_thisPrefix.Any(tp => prefix == tp.Prefix) && _existPrefix.Any(ep => prefix == ep.Prefix))
            {
                MessageBox.Show($"機台編號前綴 '{prefix}' 已被使用，請重新選擇！",
                                "資料錯誤",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            // 檢查新的編號是否已存在
            if (_coreData.Machines.Any(m => m.MachineCode == tbMachineCode.Text))
            {
                if (CrudType == CrudType.Add)
                {
                    MessageBox.Show(
                        $"機台編號 {tbMachineCode.Text} 已存在，無法更新！",
                        "資料錯誤",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    if (MessageBox.Show(
                        $"機台編號 {tbMachineCode.Text} 已存在，確定要覆蓋嗎？",
                        "覆蓋資料確認",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2)
                            != DialogResult.Yes)
                        return;
                }
            }

            MachineValue.MachineCode = tbMachineCode.Text;
            MachineValue.CategoryId = (int)cbCategory.SelectedValue;
            MachineValue.CategoryName = cbCategory.Text;
            MachineValue.TypeId = (int)cbType.SelectedValue;
            MachineValue.TypeName = cbType.Text;
            MachineValue.MachineNameId = (int)cbModelName.SelectedValue;
            MachineValue.ModelName = cbModelName.Text;
            MachineValue.ConditionId = (int)cbCondition.SelectedValue;
            MachineValue.BrandId = (int)cbBrand.SelectedValue;
            MachineValue.LocationId = (int)cbLocation.SelectedValue;
            MachineValue.Connected = cbConnected.Checked;
            MachineValue.Disposal = cbDisposal.Checked;
            MachineValue.AssetString = tbAssets.Text;
            MachineValue.SerialNumber = tbSerialNumber.Text;
            MachineValue.Barcode = tbBarcode.Text;
            MachineValue.Remark = tbRemark.Text;

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private static string GetMachineCodePrefix(string machineCode)
        {
            return Regex.Replace(machineCode, @"\d+$", "");
        }

        private int _lastCategoryId = int.MinValue;
        private async Task UpdateTypeListAsync(int categoryId)
        {
            if (_lastCategoryId == categoryId)
                return;

            _lastCategoryId = categoryId;
            var listType = await _context.MachineTypes
                .Where(t => t.CategoryId == categoryId)
                .OrderBy(t => t.OrderNo)
                .Select(c => new ListViewModel()
                {
                    Id = c.Id,
                    Name = c.TypeName,
                    OrderNo = c.OrderNo,
                })
                .ToListAsync();
            if (!listType.Any(m => string.IsNullOrWhiteSpace(m.Name)))
                listType.Insert(0, new ListViewModel()
                {
                    Id = -1,
                    Name = "",
                    OrderNo = 0,
                });
            cbType.DataSource = listType;
            cbType.DisplayMember = "Name";
            cbType.ValueMember = "Id";
        }

        private int _lastTypeId = int.MinValue;
        private async Task UpdateModelNameListAsync(int typeId)
        {
            if (_lastTypeId == typeId)
                return;

            _lastTypeId = typeId;
            var listModelNames = await _context.MachineNames
                 .Where(t => t.TypeId == typeId)
                 .OrderBy(t => t.OrderNo)
                 .Select(c => new ListViewModel()
                 {
                     Id = c.Id,
                     Name = c.ModelName,
                     OrderNo = c.OrderNo,
                 })
                 .ToListAsync();
            if (!listModelNames.Any(m => string.IsNullOrWhiteSpace(m.Name)))
                listModelNames.Insert(0, new ListViewModel()
                {
                    Id = -1,
                    Name = "",
                    OrderNo = 0,
                });
            cbModelName.DataSource = listModelNames;
            cbModelName.DisplayMember = "Name";
            cbModelName.ValueMember = "Id";
        }

        private async void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (_suppressSelectionChanged) return;

            //int categoryId = -1;
            //if (cbCategory.SelectedValue != null && int.TryParse(cbCategory.SelectedValue.ToString(), out int val))
            //    categoryId = val;

            //await UpdateTypeListAsync(categoryId);
            //CheckMachineCode();
        }

        private async void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (_suppressSelectionChanged) return;

            //int typeId = -1;
            //if (cbType.SelectedValue != null && int.TryParse(cbType.SelectedValue.ToString(), out int val))
            //    typeId = val;

            //await UpdateModelNameListAsync(typeId);
            //CheckMachineCode();
        }

        //private void CheckMachineCode()
        //{
        //    if (_suppressMachineCodeChanged) return;

        //    if (cbCategory.SelectedIndex >= 0 && cbType.SelectedIndex >= 0)
        //    {
        //        _suppressMachineCodeChanged = true;

        //        int idCategory = (int)cbCategory.SelectedValue;
        //        int idType = (int)cbType.SelectedValue;
        //        var existMachnie = _coreData.Machines.FindAll(m => m.CategoryId == idCategory && m.TypeId == idType);
        //        if (existMachnie.Count() > 0)
        //        {
        //            var listSource = existMachnie
        //                .GroupBy(em => Regex.Replace(em.MachineCode, @"\d+$", ""))
        //                .Select(group => new ListViewModel
        //                {
        //                    Id = group.First().Id,
        //                    Name = $"{group.First().CategoryName} » {group.Key}"
        //                })
        //                .ToList();

        //            _crud.Edit_1ComboBox(new ComboBoxInfo()
        //            {
        //                ListSource = listSource,
        //                Id = existMachnie.First().Id,
        //                Caption = "選擇設備別\n或取消自選",
        //                WaterMark = ""
        //            }, $"'{cbCategory.Text} » {cbType.Text}' 已存在！");

        //            if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
        //            {
        //                _suppressSelectionChanged = true;

        //                var selectedId = _crud.Result.IntValue;
        //                var selectedMachine = _coreData.Machines.FirstOrDefault(m => m.Id == listSource[selectedId].Id);

        //                // 保留原始格式(包含'-'等分隔符)
        //                string codePrefix = Regex.Replace(selectedMachine.MachineCode, @"\d+$", "");
        //                var maxCode = _coreData.Machines
        //                    .Where(m => m.MachineCode.StartsWith(codePrefix))
        //                    .Select(m => Regex.Match(m.MachineCode, @"\d+$"))
        //                    .Where(match => match.Success)
        //                    .Select(match => int.Parse(match.Value))
        //                    .DefaultIfEmpty(0)
        //                    .Max();
        //                var nextCode = codePrefix + (maxCode + 1).ToString();

        //                tbMachineCode.Text = nextCode;
        //                cbCategory.SelectedValue = selectedMachine.CategoryId;
        //                cbType.SelectedValue = selectedMachine.TypeId;
        //                cbModelName.SelectedValue = selectedMachine.MachineNameId;

        //                cbCondition.SelectedValue = selectedMachine.ConditionId;
        //                cbBrand.SelectedValue = selectedMachine.BrandId;
        //                cbLocation.SelectedValue = selectedMachine.LocationId;
        //                cbConnected.Checked = selectedMachine.Connected;
        //                cbDisposal.Checked = false;

        //                _suppressSelectionChanged = false;
        //            }
        //        }
        //        _suppressMachineCodeChanged = false;
        //    }
        //}

        private void SetOptionalMachineCode()
        {
            //var idList = new Dictionary<int, string>();
            _thisPrefix = new List<OptionalList>();
            var idCategory = (int)(cbCategory?.SelectedValue ?? -1);
            var idType = (int)(cbType?.SelectedValue ?? -1);
            string mcode = tbMachineCode.Text;

            if (idCategory >= 0)
            {
                var machines = idType >= 0
                    ? _coreData.Machines
                        .FindAll(m => m.CategoryId == idCategory && m.TypeId == idType)
                        .GroupBy(em => GetMachineCodePrefix(em.MachineCode))
                        .Select(group => group.First())
                    : _coreData.Machines
                        .FindAll(m => m.CategoryId == idCategory)
                        .GroupBy(em => GetMachineCodePrefix(em.MachineCode))
                        .Select(group => group.First());

                foreach (var ma in machines)
                {
                    if (!_thisPrefix.Any(em => em.Id == ma.Id))
                    {
                        _thisPrefix.Add(new OptionalList
                        {
                            Id = ma.Id,
                            Prefix = GetMachineCodePrefix(ma.MachineCode)
                        });
                    }
                }
            }

            var listMachnie = new List<ListViewModel>();
            foreach (var ol in _thisPrefix)
            {
                var machine = _coreData.Machines.FirstOrDefault(m => m.Id == ol.Id);
                var maxCode = _coreData.Machines
                    .Where(m => m.MachineCode.StartsWith(ol.Prefix))
                    .Select(m => Regex.Match(m.MachineCode, @"\d+$"))
                    .Where(match => match.Success)
                    .Select(match => int.Parse(match.Value))
                    .DefaultIfEmpty(0)
                    .Max();
                var newCode = $"{ol.Prefix}{maxCode + 1}";

                listMachnie.Add(new ListViewModel
                {
                    Id = ol.Id,
                    IdString = newCode,
                    Name = $"{newCode}：{machine.CategoryName} » {machine.TypeName}"
                });
            }

            lbOptionalMachineCode.DataSource = listMachnie;
            lbOptionalMachineCode.DisplayMember = "Name";
            lbOptionalMachineCode.ValueMember = "IdString";
        }

        private void ShowRepeatPrefix()
        {
            string prefix = GetMachineCodePrefix(tbMachineCode.Text);
            if (!string.IsNullOrWhiteSpace(prefix))
            {
                _existPrefix = _coreData.Machines
                    .Where(m => m.MachineCode.StartsWith(prefix))
                    .GroupBy(m => Regex.Replace(m.MachineCode, @"\d+$", ""))
                    .Select(group => new OptionalList
                    {
                        Id = group.First().Id,
                        Prefix = GetMachineCodePrefix(group.First().MachineCode)
                    })
                    .ToList();

                var exist = new List<string>();
                foreach (var em in _existPrefix)
                {
                    if (_thisPrefix.Any(tp => tp.Prefix == em.Prefix))
                        continue;
                    var machine = _coreData.Machines.FirstOrDefault(m => m.Id == em.Id);
                    exist.Add($"{GetMachineCodePrefix(machine.MachineCode)}：{machine.CategoryName} » {machine.TypeName}");
                }

                lblMessage.Text = string.Join(Environment.NewLine, exist);
                lblMessageTitle.Visible = exist.Any();
            }

            //if (_coreData.Machines.Any(m => m.MachineCode == tbMachineCode.Text))
            //{
            //    btnOK.Enabled = false;
            //    var machine = _coreData.Machines.FirstOrDefault(m => m.MachineCode == tbMachineCode.Text);
            //    lblMessage.ForeColor = System.Drawing.Color.Maroon;
            //    lblMessage.Text = $"機台編號已存在 → {machine.MachineCode}：{machine.MachineName.FullName}";
            //}
            else
            {
                lblMessageTitle.Visible = false;
                lblMessage.Text = "";
            }
        }

        private void tbMaincheId_TextChanged(object sender, EventArgs e)
        {
            SetOptionalMachineCode();
            ShowRepeatPrefix();
        }

        private void lbOptionalMachineCode_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
                return;

            int index = lbOptionalMachineCode.IndexFromPoint(e.Location);
            if (index != ListBox.NoMatches)
                lbOptionalMachineCode.SelectedIndex = index;
            else
                lbOptionalMachineCode.ClearSelected();
        }

        private void selectOptionalMachineCode_Click(object sender, EventArgs e)
        {
            if (lbOptionalMachineCode.SelectedIndex >= 0)
                tbMachineCode.Text = lbOptionalMachineCode.SelectedValue.ToString();
        }

        private void tbMaincheId_Validated(object sender, EventArgs e)
        {
            ////if (_isLoading) return;

            //var startText = Regex.Replace(tbMachineCode.Text.SplitClean('-', '_')[0], @"\d+$", "");
            //var existMachnie = _coreData.Machines.FindAll(m => m.MachineCode.StartsWith(startText));
            //if (existMachnie.Count() > 0)
            //{
            //    var listMachnie = existMachnie
            //        .GroupBy(em => em.TypeName)
            //        .Select(group => new ListViewModel
            //        {
            //            Id = group.First().Id,
            //            Name = $"{group.First().CategoryName} » {group.Key}"
            //        })
            //        .ToList();

            //    _crud.Edit_1ComboBox(new ComboBoxInfo()
            //    {
            //        ListSource = listMachnie,
            //        Id = existMachnie.First().Id,
            //        Caption = "選擇設備別\n或取消自選",
            //        WaterMark = ""
            //    }, $"'{startText}' 開頭的機台編號已存在！");

            //    if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
            //    {
            //        _suppressSelectionChanged = true;

            //        var selectedId = _crud.Result.IntValue;
            //        var selectedMachine = _coreData.Machines.FirstOrDefault(m => m.Id == listMachnie[selectedId].Id);

            //        // 保留原始格式(包含'-'等分隔符)
            //        string codePrefix = Regex.Replace(selectedMachine.MachineCode, @"\d+$", "");
            //        var maxCode = _coreData.Machines
            //            .Where(m => m.MachineCode.StartsWith(codePrefix))
            //            .Select(m => Regex.Match(m.MachineCode, @"\d+$"))
            //            .Where(match => match.Success)
            //            .Select(match => int.Parse(match.Value))
            //            .DefaultIfEmpty(0)
            //            .Max();
            //        var nextCode = codePrefix + (maxCode + 1).ToString();

            //        tbMachineCode.Text = nextCode;
            //        cbCategory.SelectedValue = selectedMachine.CategoryId;
            //        cbType.SelectedValue = selectedMachine.TypeId;
            //        cbModelName.SelectedValue = selectedMachine.MachineNameId;

            //        cbCondition.SelectedValue = selectedMachine.ConditionId;
            //        cbBrand.SelectedValue = selectedMachine.BrandId;
            //        cbLocation.SelectedValue = selectedMachine.LocationId;
            //        cbConnected.Checked = selectedMachine.Connected;
            //        cbDisposal.Checked = false;

            //        _suppressSelectionChanged = false;
            //    }
            //}
        }
    }

    internal class OptionalList
    {
        internal int Id { get; set; }
        internal string Prefix { get; set; }
    }
}
