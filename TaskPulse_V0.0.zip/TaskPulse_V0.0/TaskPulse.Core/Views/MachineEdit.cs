﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Extensions;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using static Calin.TaskPulse.Core.Models.PropertyText;

namespace Calin.TaskPulse.Core.Views
{
    public partial class MachineEdit : UIForm
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;
        private readonly CRUD _crud;

        // ResultList Buffers
        private List<ClassifyInfo> _defaultWS = new List<ClassifyInfo>();
        //private bool _isLoading = false;
        private bool _suppressSelectionChanged = false;
        private bool _suppressMachineCodeChanged = false;

        #endregion fields

        public string Title { get; set; }
        public CrudType CrudType { get; set; }
        public MachineViewModel MachineValue { get; set; } = new MachineViewModel();

        public MachineEdit(
            CoreContext coreContext,
            CoreData coreData,
            MultiSelector multiSelector,
            CRUD crud)
        {
            //_isLoading = true;

            InitializeComponent();

            _context = coreContext;
            _coreData = coreData;
            _mSel = multiSelector;
            _crud = crud;
        }

        private async void MachineEdit_Load(object sender, EventArgs e)
        {
            //this.cbCategory.SelectedIndexChanged -= new System.EventHandler(this.cbCategory_SelectedIndexChanged);
            //this.cbType.SelectedIndexChanged -= new System.EventHandler(this.cbType_SelectedIndexChanged);
            //this.tbMachineCode.Validated -= new System.EventHandler(this.tbMaincheId_Validated);

            //_isLoading = true;
            _suppressSelectionChanged = true;
            _suppressMachineCodeChanged = true;

            this.Text = Title;
            tbMachineCode.Text = MachineValue.MachineCode;

            var listCategories = await _context.MachineCategories
                .OrderBy(c => c.OrderNo)
                .Select(c => new ListViewModel()
                {
                    Id = c.Id,
                    Name = c.CategoryName,
                    OrderNo = c.OrderNo,
                })
                .ToListAsync();
            listCategories.Insert(0, new ListViewModel()
            {
                Id = -1,
                Name = "",
                OrderNo = 0,
            });
            cbCategory.DataSource = listCategories;
            cbCategory.DisplayMember = "Name";
            cbCategory.ValueMember = "Id";
            //cbCategory.Enabled = false;
            //cbCategory.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            //cbType.DisplayMember = "Name";
            //cbType.ValueMember = "Id";
            //cbType.DataSource = await _context.MachineTypes
            //    .Where(t => t.CategoryId == MachineValue.CategoryId)
            //    .Select(c => new ListViewModel() { Id = c.Id, Name = c.TypeName })
            //    .ToListAsync();
            //cbType.Enabled = false;
            //cbType.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            //cbModelName.DisplayMember = "Name";
            //cbModelName.ValueMember = "Id";
            //cbModelName.DataSource = await _context.MachineNames
            //    .Where(t => t.TypeId == MachineValue.TypeId)
            //    .Select(c => new ListViewModel() { Id = c.Id, Name = c.ModelName })
            //    .ToListAsync();
            //cbModelName.Enabled = false;
            //cbModelName.Enabled = !(CrudType == CrudType.Add || CrudType == CrudType.Create);

            cbCondition.DisplayMember = "Name";
            cbCondition.ValueMember = "Id";
            cbCondition.DataSource = await _context.MachineConditions
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.ConditionName })
                .ToListAsync();

            cbBrand.DisplayMember = "Name";
            cbBrand.ValueMember = "Id";
            cbBrand.DataSource = await _context.MachineBrands
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.BrandName })
                .ToListAsync();

            cbLocation.DisplayMember = "Name";
            cbLocation.ValueMember = "Id";
            cbLocation.DataSource = await _context.MachineLocations
                .Select(c => new ListViewModel() { Id = c.Id, Name = c.LocationName })
                .ToListAsync();

            //cbConnected.DisplayMember = "Name";
            //cbConnected.ValueMember = "BooleanId";
            //cbConnected.DataSource = new List<ListViewModel>()
            //{
            //    new ListViewModel() { BooleanId = false, Name = "未連網" },
            //    new ListViewModel() { BooleanId= true, Name = "可連網" },
            //};

            //cbDisposal.DisplayMember = "Name";
            //cbDisposal.ValueMember = "BooleanId";
            //cbDisposal.DataSource = new List<ListViewModel>()
            //{
            //    new ListViewModel() {BooleanId = false, Name = "正常作業" },
            //    new ListViewModel() {BooleanId = true, Name = "已處置" },
            //};

            await UpdateTypeListAsync(MachineValue.CategoryId);
            await UpdateModelNameListAsync(MachineValue.TypeId);

            cbCategory.SelectedValue = MachineValue.CategoryId;
            cbType.SelectedValue = MachineValue.TypeId;
            cbModelName.SelectedValue = MachineValue.MachineNameId;
            cbCondition.SelectedValue = MachineValue.ConditionId;
            cbBrand.SelectedValue = MachineValue.BrandId;
            cbLocation.SelectedValue = MachineValue.LocationId;
            cbConnected.Checked = MachineValue.Connected;
            cbDisposal.Checked = MachineValue.Disposal;
            tbAssets.Text = MachineValue.AssetString;
            tbSerialNumber.Text = MachineValue.SerialNumber;
            tbBarcode.Text = MachineValue.Barcode;
            tbRemark.Text = MachineValue.Remark;

            CommonStyles.SetCheckBox(cbConnected);
            CommonStyles.SetCheckBox(cbDisposal);

            _suppressMachineCodeChanged = false;
            _suppressSelectionChanged = false;
            //_isLoading = false;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (MachineValue.MachineCode != tbMachineCode.Text)
            {
                // 檢查新的編號是否已存在
                if (_coreData.Machines.Any(m => m.MachineCode == tbMachineCode.Text))
                {
                    MessageBox.Show($"機台編號 {tbMachineCode.Text} 已存在，無法更新！",
                                    "更新失敗",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }
                MachineValue.MachineCode = tbMachineCode.Text;
            }

            MachineValue.MachineCode = tbMachineCode.Text;
            MachineValue.ModelName = cbModelName.Text;
            MachineValue.CategoryId = (int)cbCategory.SelectedValue;
            MachineValue.CategoryName = cbCategory.Text;
            MachineValue.TypeId = (int)cbType.SelectedValue;
            MachineValue.TypeName = cbType.Text;
            MachineValue.MachineNameId = (int)cbModelName.SelectedValue;
            MachineValue.ModelName = cbModelName.Text;
            MachineValue.ConditionId = (int)cbCondition.SelectedValue;
            MachineValue.BrandId = (int)cbBrand.SelectedValue;
            MachineValue.LocationId = (int)cbLocation.SelectedValue;
            MachineValue.Connected = cbConnected.Checked;
            MachineValue.Disposal = cbDisposal.Checked;
            MachineValue.AssetString = tbAssets.Text;
            MachineValue.SerialNumber = tbSerialNumber.Text;
            MachineValue.Barcode = tbBarcode.Text;
            MachineValue.Remark = tbRemark.Text;

            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private int _lastCategoryId = int.MinValue;
        private async Task UpdateTypeListAsync(int categoryId)
        {
            if (_lastCategoryId == categoryId)
                return;

            _lastCategoryId = categoryId;
            var listType = await _context.MachineTypes
                .Where(t => t.CategoryId == categoryId)
                .OrderBy(t => t.OrderNo)
                .Select(c => new ListViewModel()
                {
                    Id = c.Id,
                    Name = c.TypeName,
                    OrderNo = c.OrderNo,
                })
                .ToListAsync();
            if (!listType.Any(m => string.IsNullOrWhiteSpace(m.Name)))
                listType.Insert(0, new ListViewModel()
                {
                    Id = -1,
                    Name = "",
                    OrderNo = 0,
                });
            cbType.DataSource = listType;
            cbType.DisplayMember = "Name";
            cbType.ValueMember = "Id";
        }

        private int _lastTypeId = int.MinValue;
        private async Task UpdateModelNameListAsync(int typeId)
        {
            if (_lastTypeId == typeId)
                return;

            _lastTypeId = typeId;
            var listModelNames = await _context.MachineNames
                 .Where(t => t.TypeId == typeId)
                 .OrderBy(t => t.OrderNo)
                 .Select(c => new ListViewModel()
                 {
                     Id = c.Id,
                     Name = c.ModelName,
                     OrderNo = c.OrderNo,
                 })
                 .ToListAsync();
            if (!listModelNames.Any(m => string.IsNullOrWhiteSpace(m.Name)))
                listModelNames.Insert(0, new ListViewModel()
                {
                    Id = -1,
                    Name = "",
                    OrderNo = 0,
                });
            cbModelName.DataSource = listModelNames;
            cbModelName.DisplayMember = "Name";
            cbModelName.ValueMember = "Id";
        }

        private async void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (_suppressSelectionChanged) return;

            //int categoryId = -1;
            //if (cbCategory.SelectedValue != null && int.TryParse(cbCategory.SelectedValue.ToString(), out int val))
            //    categoryId = val;

            //await UpdateTypeListAsync(categoryId);
            //CheckMachineCode();
        }

        private async void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (_suppressSelectionChanged) return;

            //int typeId = -1;
            //if (cbType.SelectedValue != null && int.TryParse(cbType.SelectedValue.ToString(), out int val))
            //    typeId = val;

            //await UpdateModelNameListAsync(typeId);
            //CheckMachineCode();
        }

        //private void CheckMachineCode()
        //{
        //    if (_suppressMachineCodeChanged) return;

        //    if (cbCategory.SelectedIndex >= 0 && cbType.SelectedIndex >= 0)
        //    {
        //        _suppressMachineCodeChanged = true;

        //        int idCategory = (int)cbCategory.SelectedValue;
        //        int idType = (int)cbType.SelectedValue;
        //        var existMachnie = _coreData.Machines.FindAll(m => m.CategoryId == idCategory && m.TypeId == idType);
        //        if (existMachnie.Count() > 0)
        //        {
        //            var listSource = existMachnie
        //                .GroupBy(em => Regex.Replace(em.MachineCode, @"\d+$", ""))
        //                .Select(group => new ListViewModel
        //                {
        //                    Id = group.First().Id,
        //                    Name = $"{group.First().CategoryName} » {group.Key}"
        //                })
        //                .ToList();

        //            _crud.Edit_1ComboBox(new ComboBoxInfo()
        //            {
        //                ListSource = listSource,
        //                Id = existMachnie.First().Id,
        //                Caption = "選擇設備別\n或取消自選",
        //                WaterMark = ""
        //            }, $"'{cbCategory.Text} » {cbType.Text}' 已存在！");

        //            if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
        //            {
        //                _suppressSelectionChanged = true;

        //                var selectedId = _crud.Result.IntValue;
        //                var selectedMachine = _coreData.Machines.FirstOrDefault(m => m.Id == listSource[selectedId].Id);

        //                // 保留原始格式(包含'-'等分隔符)
        //                string codePrefix = Regex.Replace(selectedMachine.MachineCode, @"\d+$", "");
        //                var maxCode = _coreData.Machines
        //                    .Where(m => m.MachineCode.StartsWith(codePrefix))
        //                    .Select(m => Regex.Match(m.MachineCode, @"\d+$"))
        //                    .Where(match => match.Success)
        //                    .Select(match => int.Parse(match.Value))
        //                    .DefaultIfEmpty(0)
        //                    .Max();
        //                var nextCode = codePrefix + (maxCode + 1).ToString();

        //                tbMachineCode.Text = nextCode;
        //                cbCategory.SelectedValue = selectedMachine.CategoryId;
        //                cbType.SelectedValue = selectedMachine.TypeId;
        //                cbModelName.SelectedValue = selectedMachine.MachineNameId;

        //                cbCondition.SelectedValue = selectedMachine.ConditionId;
        //                cbBrand.SelectedValue = selectedMachine.BrandId;
        //                cbLocation.SelectedValue = selectedMachine.LocationId;
        //                cbConnected.Checked = selectedMachine.Connected;
        //                cbDisposal.Checked = false;

        //                _suppressSelectionChanged = false;
        //            }
        //        }
        //        _suppressMachineCodeChanged = false;
        //    }
        //}

        private List<ListViewModel> GetExistMachineCodePrefixList(string perfix)
        {
            if (!string.IsNullOrWhiteSpace(perfix))
            {
                var existMachnie = _coreData.Machines.FindAll(m => m.MachineCode.StartsWith(perfix));
                if (existMachnie.Count() > 0)
                {
                    var listMachnie = existMachnie
                        .GroupBy(em => Regex.Replace(em.MachineCode, @"\d+$", ""))
                        .Select(group => new ListViewModel
                        {
                            Id = group.First().Id,
                            IdString = Regex.Replace(group.First().MachineCode, @"\d+$", ""),
                            Name = $"{group.First().MachineName.FullName}"
                        })
                        .ToList();

                    var selectedId = _crud.Result.IntValue;
                    var selectedMachine = _coreData.Machines.FirstOrDefault(m => m.Id == listMachnie[selectedId].Id);

                    foreach (var item in listMachnie)
                    {
                        var maxCode = _coreData.Machines
                            .Where(m => m.MachineCode.StartsWith(item.IdString))
                            .Select(m => Regex.Match(m.MachineCode, @"\d+$"))
                            .Where(match => match.Success)
                            .Select(match => int.Parse(match.Value))
                            .DefaultIfEmpty(0)
                            .Max();
                        var extCode = (maxCode + 1).ToString();
                        item.IdString += extCode;
                        item.Name = $"{item.IdString}：{item.Name}";
                    }
                    return listMachnie;
                }
            }
            return new List<ListViewModel>();
        }

        private void tbMaincheId_TextChanged(object sender, EventArgs e)
        {
            lbOptionalMachineCode.DataSource = GetExistMachineCodePrefixList(tbMachineCode.Text);
            lbOptionalMachineCode.DisplayMember = "Name";
            lbOptionalMachineCode.ValueMember = "IdString";

            if (_coreData.Machines.Any(m => m.MachineCode == tbMachineCode.Text))
            {
                btnOK.Enabled = false;
                var machine = _coreData.Machines.FirstOrDefault(m => m.MachineCode == tbMachineCode.Text);
                lblMessage.ForeColor = System.Drawing.Color.Maroon;
                lblMessage.Text = $"機台編號已存在 → {machine.MachineCode}：{machine.MachineName.FullName}";
            }
            else
            {
                btnOK.Enabled = true;
                lblMessage.Text = "";
            }
        }

        private void lbOptionalMachineCode_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
                return;

            int index = lbOptionalMachineCode.IndexFromPoint(e.Location);
            if (index != ListBox.NoMatches)
                lbOptionalMachineCode.SelectedIndex = index;
            else
                lbOptionalMachineCode.ClearSelected();
        }

        private void selectOptionalMachineCode_Click(object sender, EventArgs e)
        {
            if (lbOptionalMachineCode.SelectedIndex >= 0)
                tbMachineCode.Text = lbOptionalMachineCode.SelectedValue.ToString();
        }

        private void tbMaincheId_Validated(object sender, EventArgs e)
        {
            ////if (_isLoading) return;

            //var startText = Regex.Replace(tbMachineCode.Text.SplitClean('-', '_')[0], @"\d+$", "");
            //var existMachnie = _coreData.Machines.FindAll(m => m.MachineCode.StartsWith(startText));
            //if (existMachnie.Count() > 0)
            //{
            //    var listMachnie = existMachnie
            //        .GroupBy(em => em.TypeName)
            //        .Select(group => new ListViewModel
            //        {
            //            Id = group.First().Id,
            //            Name = $"{group.First().CategoryName} » {group.Key}"
            //        })
            //        .ToList();

            //    _crud.Edit_1ComboBox(new ComboBoxInfo()
            //    {
            //        ListSource = listMachnie,
            //        Id = existMachnie.First().Id,
            //        Caption = "選擇設備別\n或取消自選",
            //        WaterMark = ""
            //    }, $"'{startText}' 開頭的機台編號已存在！");

            //    if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
            //    {
            //        _suppressSelectionChanged = true;

            //        var selectedId = _crud.Result.IntValue;
            //        var selectedMachine = _coreData.Machines.FirstOrDefault(m => m.Id == listMachnie[selectedId].Id);

            //        // 保留原始格式(包含'-'等分隔符)
            //        string codePrefix = Regex.Replace(selectedMachine.MachineCode, @"\d+$", "");
            //        var maxCode = _coreData.Machines
            //            .Where(m => m.MachineCode.StartsWith(codePrefix))
            //            .Select(m => Regex.Match(m.MachineCode, @"\d+$"))
            //            .Where(match => match.Success)
            //            .Select(match => int.Parse(match.Value))
            //            .DefaultIfEmpty(0)
            //            .Max();
            //        var nextCode = codePrefix + (maxCode + 1).ToString();

            //        tbMachineCode.Text = nextCode;
            //        cbCategory.SelectedValue = selectedMachine.CategoryId;
            //        cbType.SelectedValue = selectedMachine.TypeId;
            //        cbModelName.SelectedValue = selectedMachine.MachineNameId;

            //        cbCondition.SelectedValue = selectedMachine.ConditionId;
            //        cbBrand.SelectedValue = selectedMachine.BrandId;
            //        cbLocation.SelectedValue = selectedMachine.LocationId;
            //        cbConnected.Checked = selectedMachine.Connected;
            //        cbDisposal.Checked = false;

            //        _suppressSelectionChanged = false;
            //    }
            //}
        }
    }
}
