using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Autofac.Core.Lifetime;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    /// <summary>
    /// �v���޲z����
    /// �䴩�����B�s�աB�ӤH�T���v���]�w
    /// �䴩���\/�T�����v��
    /// </summary>
    public partial class Setup_Permission : UserControl, INavigationAware
    {
        #region Fields

        private readonly Serilog.ILogger _logger;
        private readonly IEntityCacheManager _cacheManager;
        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly ICurrentUserService _currentUser;
        private readonly IPermissionService _permission;
        private PermissionSource _currentSource;
        private int _selectedDepartmentId;
        private int _selectedUserGroupId;
        private string _selectedEmployeeId;
        private List<PermissionItemViewModel> _currentPermissions;
        private List<PermissionMergeResult> _mergedPermissions;
        private List<PermissionConflictViewModel> _conflicts;

        /// <summary>
        /// �v������r��GModule -> Page -> Control -> (AllowCheckBox, DenyCheckBox)
        /// </summary>
        private Dictionary<string, Dictionary<string, Dictionary<string, PermissionCheckBoxPair>>> _permissionControls;

        #endregion

        #region INavigationAware

        /// <summary>
        /// ���ɯ�즹�����ɰ��檺�ާ@
        /// </summary>
        public async void OnNavigatedTo()
        {
            //await UpdateDataAsync();
        }

        /// <summary>
        /// ���q�������ɯ����}�ɰ��檺�ާ@
        /// </summary>
        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();

            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        #endregion INavigationAware

        #region Constructor

        /// <summary>
        /// ��l�� <see cref="Setup_Permission"/> ���O���s�������
        /// </summary>
        /// <param name="logger">��x�O����</param>
        /// <param name="cacheManager">����֨��޲z��</param>
        /// <param name="coreContext">�֤߸�Ʈw�W�U��</param>
        /// <param name="currentUserContext">���e�ϥΪ̤W�U��</param>
        /// <param name="currentUserService">���e�ϥΪ̪A��</param>
        /// <param name="permissionService">�v���A��</param>
        public Setup_Permission(
            Serilog.ILogger logger,
            IEntityCacheManager cacheManager,
            CoreContext coreContext,
            CurrentUserContext currentUserContext,
            ICurrentUserService currentUserService,
            IPermissionService permissionService)
        {
            InitializeComponent();

            _logger = logger;
            _cacheManager = cacheManager;
            _context = coreContext;
            _user = currentUserContext;
            _currentUser = currentUserService;
            _permission = permissionService;

            InitializeUI();
        }

        #endregion

        #region Initialization

        /// <summary>
        /// ��l�ƨϥΪ̤����C
        /// </summary>
        private void InitializeUI()
        {
            // �]�w TreeView �˦�
            CommonStyles.SetTreeView(treeSource);

            // �]�w DataGridView �˦�
            SetupDataGridViewStyle(dgvMergedPermissions);
            SetupDataGridViewStyle(dgvConflicts);

            // ��l�� TreeView
            InitializeSourceTree();

            // �]�w DataGridView ���
            SetupMergedGridColumns();
            SetupConflictGridColumns();

            CommonStyles.SetButton(btnSave);

            // ��l���v������r��
            _permissionControls = new Dictionary<string, Dictionary<string, Dictionary<string, PermissionCheckBoxPair>>>();
        }

        /// <summary>
        /// �]�w DataGridView ���˦��C
        /// </summary>
        /// <param name="dgv">�ؼ� DataGridView�C</param>
        private void SetupDataGridViewStyle(DataGridView dgv)
        {
            dgv.AutoGenerateColumns = false;
            dgv.RowHeadersVisible = false;
            dgv.MultiSelect = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgv.DefaultCellStyle.SelectionBackColor = CommonStyles.SelectedColor;
            dgv.DefaultCellStyle.SelectionForeColor = Color.White;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.WhiteSmoke;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = CommonStyles.BackColor;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.GridColor = Color.LightGray;
            dgv.DefaultCellStyle.Font = CommonStyles.Font;
            dgv.ColumnHeadersDefaultCellStyle.Font = CommonStyles.Font;
            dgv.AllowUserToResizeColumns = true;
            dgv.AllowUserToResizeRows = false;
            dgv.AllowUserToAddRows = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.AllowUserToOrderColumns = false;
        }

        /// <summary>
        /// ��l���v���ӷ��� TreeView�C
        /// </summary>
        private void InitializeSourceTree()
        {
            treeSource.Nodes.Clear();

            // �����`�I
            var deptNode = new TreeNode("����")
            {
                Tag = "Department",
                ImageIndex = 0,
                SelectedImageIndex = 0
            };

            var departments = _context.Departments
                .OrderBy(d => d.OrderNo)
                .ToList();

            foreach (var dept in departments)
            {
                var node = new TreeNode(dept.DepartmentName)
                {
                    Tag = new SourceNodeData
                    {
                        Source = PermissionSource.Department,
                        Id = dept.Id,
                        Name = dept.DepartmentName
                    }
                };
                deptNode.Nodes.Add(node);
            }

            treeSource.Nodes.Add(deptNode);

            // �s�ո`�I
            var groupNode = new TreeNode("�ϥΪ̸s��")
            {
                Tag = "UserGroup",
                ImageIndex = 1,
                SelectedImageIndex = 1
            };

            var userGroups = _context.UserGroups
                .OrderBy(g => g.OrderNo)
                .ToList();

            foreach (var group in userGroups)
            {
                var node = new TreeNode(group.Name)
                {
                    Tag = new SourceNodeData
                    {
                        Source = PermissionSource.UserGroup,
                        Id = group.Id,
                        Name = group.Name
                    }
                };
                groupNode.Nodes.Add(node);
            }

            treeSource.Nodes.Add(groupNode);

            // ���u�`�I
            var empNode = new TreeNode("���u")
            {
                Tag = "Employee",
                ImageIndex = 2,
                SelectedImageIndex = 2
            };

            var employees = _context.Employees
                .Include(e => e.Department)
                .Include(e => e.Status)
                .Where(e => e.StatusId == 1) // �u��ܦb¾���u
                .OrderBy(e => e.Department.OrderNo)
                .ThenBy(e => e.EmployeeId)
                .ToList();

            // ����������
            var empByDept = employees.GroupBy(e => e.Department?.DepartmentName ?? "�����t����");

            foreach (var deptGroup in empByDept)
            {
                var deptSubNode = new TreeNode(deptGroup.Key);

                foreach (var emp in deptGroup)
                {
                    var node = new TreeNode($"{emp.EmployeeId} - {emp.EmployeeName}")
                    {
                        Tag = new SourceNodeData
                        {
                            Source = PermissionSource.Employee,
                            EmployeeId = emp.EmployeeId,
                            Name = emp.EmployeeName
                        }
                    };
                    deptSubNode.Nodes.Add(node);
                }

                empNode.Nodes.Add(deptSubNode);
            }

            treeSource.Nodes.Add(empNode);
            treeSource.CollapseAll();
        }

        /// <summary>
        /// �]�w�X���v���� DataGridView ���C
        /// </summary>
        private void SetupMergedGridColumns()
        {
            dgvMergedPermissions.Columns.Clear();
            dgvMergedPermissions.AutoGenerateColumns = false;

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Module",
                HeaderText = "�Ҳ�",
                Width = 120
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Page",
                HeaderText = "����",
                Width = 120
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Control",
                HeaderText = "���",
                Width = 120
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Action",
                HeaderText = "�ʧ@",
                Width = 100
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "FinalType",
                HeaderText = "�̲��v��",
                Width = 100
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DecidingSourceName",
                HeaderText = "�M�w�ӷ�",
                Width = 150
            });

            dgvMergedPermissions.Columns.Add(new DataGridViewCheckBoxColumn
            {
                DataPropertyName = "HasConflict",
                HeaderText = "���Ĭ�",
                Width = 80
            });
        }

        /// <summary>
        /// �]�w�v���Ĭ� DataGridView ���C
        /// </summary>
        private void SetupConflictGridColumns()
        {
            dgvConflicts.Columns.Clear();
            dgvConflicts.AutoGenerateColumns = false;

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "PermissionString",
                HeaderText = "�v��",
                Width = 200
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DepartmentSetting",
                HeaderText = "�����]�w",
                Width = 100
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "EmployeeSetting",
                HeaderText = "�ӤH�]�w",
                Width = 100
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "FinalType",
                HeaderText = "�̲ץͮ�",
                Width = 100
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "ConflictLevel",
                HeaderText = "�Ĭ𵥯�",
                Width = 80
            });

            dgvConflicts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "ConflictDescription",
                HeaderText = "����",
                Width = 250
            });
        }

        #endregion

        #region Event Handlers

        /// <summary>
        /// ����� TreeView �`�I����J�������v����ơC
        /// </summary>
        private void TreeSource_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node?.Tag is SourceNodeData data)
            {
                _currentSource = data.Source;

                switch (data.Source)
                {
                    case PermissionSource.Department:
                        _selectedDepartmentId = data.Id;
                        LoadDepartmentPermissions(data.Id);
                        break;

                    case PermissionSource.UserGroup:
                        _selectedUserGroupId = data.Id;
                        LoadUserGroupPermissions(data.Id);
                        break;

                    case PermissionSource.Employee:
                        _selectedEmployeeId = data.EmployeeId;
                        LoadEmployeePermissions(data.EmployeeId);
                        break;
                }
            }
        }

        /// <summary>
        /// ������ Tab ���Үɸ��J��������ơC
        /// </summary>
        private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedTab?.Name == "tabMerged" && !string.IsNullOrEmpty(_selectedEmployeeId))
            {
                LoadMergedPermissions();
            }
            else if (tabControl.SelectedTab?.Name == "tabConflicts" && !string.IsNullOrEmpty(_selectedEmployeeId))
            {
                LoadConflicts();
            }
        }

        /// <summary>
        /// �����U�x�s���s���x�s�v���]�w�C
        /// </summary>
        private void BtnSave_Click(object sender, EventArgs e)
        {
            SavePermissions();
        }

        #endregion

        #region Data Loading Methods

        /// <summary>
        /// ���J�������v���]�w�C
        /// </summary>
        /// <param name="departmentId">���� ID�C</param>
        private void LoadDepartmentPermissions(int departmentId)
        {
            var dept = _context.Departments
                .Include(d => d.Permissions)
                .FirstOrDefault(d => d.Id == departmentId);

            if (dept != null)
            {
                _currentPermissions = dept.Permissions.Select(p => new PermissionItemViewModel
                {
                    Module = p.Module,
                    Page = p.Page,
                    Control = p.Control,
                    Action = p.Action,
                    PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                    Type = (PermissionType)p.PermissionType,
                    Source = PermissionSource.Department,
                    SourceName = dept.DepartmentName,
                    IsInherited = false
                }).ToList();

                BuildPermissionTree();
            }
        }

        /// <summary>
        /// ���J�ϥΪ̸s�ժ��v���]�w�C
        /// </summary>
        /// <param name="userGroupId">�ϥΪ̸s�� ID�C</param>
        private void LoadUserGroupPermissions(int userGroupId)
        {
            var group = _context.UserGroups
                .Include(g => g.Permissions)
                .FirstOrDefault(g => g.Id == userGroupId);

            if (group != null)
            {
                _currentPermissions = group.Permissions.Select(p => new PermissionItemViewModel
                {
                    Module = p.Module,
                    Page = p.Page,
                    Control = p.Control,
                    Action = p.Action,
                    PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                    Type = (PermissionType)p.PermissionType,
                    Source = PermissionSource.UserGroup,
                    SourceName = group.Name,
                    IsInherited = false
                }).ToList();

                BuildPermissionTree();
            }
        }

        /// <summary>
        /// ���J���u���v���]�w�C
        /// </summary>
        /// <param name="employeeId">���u ID�C</param>
        private void LoadEmployeePermissions(string employeeId)
        {
            // �����u�A�u��ܪ������t���ӭ��u���v���A���]�t�~�Ӫ��v��
            var emp = _context.Employees
                .Include(e => e.Permissions)
                .FirstOrDefault(e => e.EmployeeId == employeeId);

            if (emp != null)
            {
                _currentPermissions = emp.Permissions.Select(p => new PermissionItemViewModel
                {
                    Module = p.Module,
                    Page = p.Page,
                    Control = p.Control,
                    Action = p.Action,
                    PermissionString = $"{p.Module}:{p.Page}:{p.Control}:{p.Action}",
                    Type = (PermissionType)p.PermissionType,
                    Source = PermissionSource.Employee,
                    SourceName = emp.EmployeeName,
                    IsInherited = false
                }).ToList();

                BuildPermissionTree();
            }
        }

        /// <summary>
        /// ���J�X���v����ƨ���ܩ� DataGridView ���C
        /// ����k�q�v���A��������u���X���v���A�ñN���Ĭ��v����H����I���ХܡC
        /// </summary>
        /// <remarks>
        /// �X���v���|�Ҽ{�����B�s�թM�ӤH�T�Ӽh�Ū��v���]�w�A
        /// �îھ��u�����ǳW�h�p��̲ץͮĪ��v���C
        /// �u���b��ܭ��u�ɤ~�|���J�X���v����ơC
        /// </remarks>
        private void LoadMergedPermissions()
        {
            if (!string.IsNullOrEmpty(_selectedEmployeeId))
            {
                _mergedPermissions = _permission.GetMergedPermissions(_selectedEmployeeId);
                dgvMergedPermissions.DataSource = _mergedPermissions;

                // ���G��ܦ��Ĭ𪺦�
                foreach (DataGridViewRow row in dgvMergedPermissions.Rows)
                {
                    var item = row.DataBoundItem as PermissionMergeResult;
                    if (item?.HasConflict == true)
                    {
                        row.DefaultCellStyle.BackColor = Color.LightYellow;
                    }
                }
            }
        }

        /// <summary>
        /// ���J�v���Ĭ��ƨ���ܩ� DataGridView ���C
        /// ����k�q�v���A��������u���v���Ĭ�M��A�îھڽĬ𵥯ų]�w���P���I���C��C
        /// </summary>
        /// <remarks>
        /// �Ĭ𵥯Ż����G
        /// - ���� 2 (���Ĭ�)�G��ܬ��L����I�� (LightCoral)
        /// - ���� 1 (�C�Ĭ�)�G��ܬ��L����I�� (LightYellow)
        /// �u���b��ܭ��u�ɤ~�|���J�Ĭ��ơC
        /// </remarks>
        private void LoadConflicts()
        {
            if (!string.IsNullOrEmpty(_selectedEmployeeId))
            {
                _conflicts = _permission.GetPermissionConflicts(_selectedEmployeeId);
                dgvConflicts.DataSource = _conflicts;

                // �̽Ĭ𵥯ų]�w�C��
                foreach (DataGridViewRow row in dgvConflicts.Rows)
                {
                    var conflict = row.DataBoundItem as PermissionConflictViewModel;
                    if (conflict != null)
                    {
                        switch (conflict.ConflictLevel)
                        {
                            case 2:
                                row.DefaultCellStyle.BackColor = Color.LightCoral; // ���Ĭ�
                                break;
                            case 1:
                                row.DefaultCellStyle.BackColor = Color.LightYellow; // �C�Ĭ�
                                break;
                        }
                    }
                }
            }
        }

        #endregion

        #region Permission Tree Building

        /// <summary>
        /// �ھڷ��e�v���]�w�ʺA�إ��v���𪬵��c�C
        /// </summary>
        private void BuildPermissionTree()
        {
            panelPermissions.Controls.Clear();
            _permissionControls.Clear();

            // ����Ҧ��i�Ϊ�����v���]�q���ε{�������y�^
            var allControls = GetAllAvailableControls();

            // ���Ҳդ���
            var moduleGroups = allControls.GroupBy(c => c.Module);

            int yOffset = 10;

            foreach (var moduleGroup in moduleGroups.OrderBy(g => g.Key))
            {
                // �ЫؼҲ� GroupBox
                var moduleGroupBox = new GroupBox
                {
                    Text = moduleGroup.Key,
                    Location = new Point(10, yOffset),
                    Width = panelPermissions.Width - 30,
                    AutoSize = true,
                    Font = new Font("�L�n������", 11F, FontStyle.Bold)
                };

                int moduleYOffset = 25;

                // ����������
                var pageGroups = moduleGroup.GroupBy(c => c.Page);

                foreach (var pageGroup in pageGroups.OrderBy(g => g.Key))
                {
                    // �Ыح�������
                    var pageLabel = new Label
                    {
                        Text = pageGroup.Key,
                        Location = new Point(20, moduleYOffset),
                        Width = 150,
                        Font = new Font("�L�n������", 10F, FontStyle.Bold),
                        AutoSize = true
                    };
                    moduleGroupBox.Controls.Add(pageLabel);

                    moduleYOffset += 25;

                    // ���������
                    foreach (var control in pageGroup.OrderBy(c => c.Control))
                    {
                        var controlPanel = CreateControlPermissionPanel(control);
                        controlPanel.Location = new Point(40, moduleYOffset);
                        moduleGroupBox.Controls.Add(controlPanel);

                        moduleYOffset += controlPanel.Height + 5;
                    }

                    moduleYOffset += 10;
                }

                moduleGroupBox.Height = moduleYOffset + 10;
                panelPermissions.Controls.Add(moduleGroupBox);

                yOffset += moduleGroupBox.Height + 10;
            }
        }

        /// <summary>
        /// �إ߳�@������v�����O�A�]�t���\�M�T� CheckBox�C
        /// </summary>
        /// <param name="control">�����T�C</param>
        /// <returns>�v�����O�C</returns>
        private Panel CreateControlPermissionPanel(ControlPermissionInfo control)
        {
            var panel = new Panel
            {
                Width = panelPermissions.Width - 100,
                Height = 30,
                BorderStyle = BorderStyle.None
            };

            // ����W��
            var lblControl = new Label
            {
                Text = $"{control.Control} ({control.Action})",
                Location = new Point(0, 5),
                Width = 250,
                Font = new Font("�L�n������", 10F)
            };
            panel.Controls.Add(lblControl);

            // ���\ CheckBox
            var chkAllow = new UICheckBox
            {
                Text = "���\",
                Location = new Point(260, 5),
                Width = 80,
                Tag = control
            };
            CommonStyles.SetCheckBox(chkAllow);
            chkAllow.CheckedChanged += CheckBox_CheckedChanged;

            // �T�� CheckBox
            var chkDeny = new UICheckBox
            {
                Text = "�T��",
                Location = new Point(350, 5),
                Width = 80,
                Tag = control
            };
            CommonStyles.SetCheckBox(chkDeny);
            chkDeny.CheckedChanged += CheckBox_CheckedChanged;

            panel.Controls.Add(chkAllow);
            panel.Controls.Add(chkDeny);

            // �O�s��r��
            if (!_permissionControls.ContainsKey(control.Module))
                _permissionControls[control.Module] = new Dictionary<string, Dictionary<string, PermissionCheckBoxPair>>();

            if (!_permissionControls[control.Module].ContainsKey(control.Page))
                _permissionControls[control.Module][control.Page] = new Dictionary<string, PermissionCheckBoxPair>();

            var key = $"{control.Control}:{control.Action}";
            _permissionControls[control.Module][control.Page][key] = new PermissionCheckBoxPair
            {
                AllowCheckBox = chkAllow,
                DenyCheckBox = chkDeny,
                ControlInfo = control
            };

            // �]�m���e���A
            var existing = _currentPermissions.FirstOrDefault(p =>
                p.Module == control.Module &&
                p.Page == control.Page &&
                p.Control == control.Control &&
                p.Action == control.Action);

            if (existing != null)
            {
                if (existing.Type == PermissionType.Allow)
                    chkAllow.Checked = true;
                else if (existing.Type == PermissionType.Deny)
                    chkDeny.Checked = true;
            }

            return panel;
        }

        /// <summary>
        /// �����\�θT� CheckBox ���A���ܮ�Ĳ�o�A��{�����޿�C
        /// </summary>
        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (!(sender is CheckBox checkBox) || checkBox.Tag == null)
                return;

            if (!(checkBox.Tag is ControlPermissionInfo control))
                return;

            // �����޿�G���\�M�T���P�ɿ襤
            if (checkBox.Checked)
            {
                var key = $"{control.Control}:{control.Action}";
                if (_permissionControls.ContainsKey(control.Module)
                    && _permissionControls[control.Module].ContainsKey(control.Page)
                    && _permissionControls[control.Module][control.Page].ContainsKey(key))
                {
                    var pair = _permissionControls[control.Module][control.Page][key];

                    if (checkBox.Text == "���\" && pair.DenyCheckBox.Checked)
                    {
                        pair.DenyCheckBox.CheckedChanged -= CheckBox_CheckedChanged;
                        pair.DenyCheckBox.Checked = false;
                        pair.DenyCheckBox.CheckedChanged += CheckBox_CheckedChanged;
                    }
                    else if (checkBox.Text == "�T��" && pair.AllowCheckBox.Checked)
                    {
                        pair.AllowCheckBox.CheckedChanged -= CheckBox_CheckedChanged;
                        pair.AllowCheckBox.Checked = false;
                        pair.AllowCheckBox.CheckedChanged += CheckBox_CheckedChanged;
                    }
                }
            }
        }

        /// <summary>
        /// ����Ҧ��i�Ϊ�����v���M��C
        /// </summary>
        /// <returns>�Ҧ��i�Ϊ�����v���M��C</returns>
        private List<ControlPermissionInfo> GetAllAvailableControls()
        {
            // �o�����ӱq��Ʈw�ΰt�m��Ū���Ҧ��i�Ϊ����
            // ���F�ܽd�A�o�̪�^�@�Ӱ򥻦C��
            var controls = new List<ControlPermissionInfo>();

            // �q�Ҧ��w�s�b���v��������ߤ@������զX
            var existingPermissions = _context.Permissions
                .Select(p => new ControlPermissionInfo
                {
                    Module = p.Module,
                    Page = p.Page,
                    Control = p.Control,
                    Action = p.Action
                })
                .Distinct()
                .ToList();

            return existingPermissions;
        }

        #endregion

        #region Save Permissions

        /// <summary>
        /// �x�s���e�襤���v���]�w���Ʈw�C
        /// </summary>
        private void SavePermissions()
        {
            try
            {
                var permissionsToSave = new List<Permission>();

                // �M���Ҧ�����A�����襤���v��
                foreach (var module in _permissionControls)
                {
                    foreach (var page in module.Value)
                    {
                        foreach (var control in page.Value)
                        {
                            var pair = control.Value;
                            var info = pair.ControlInfo;

                            PermissionType? type = null;
                            if (pair.AllowCheckBox.Checked)
                                type = PermissionType.Allow;
                            else if (pair.DenyCheckBox.Checked)
                                type = PermissionType.Deny;

                            if (type.HasValue)
                            {
                                // �d��γЫ��v��
                                var permission = _context.Permissions.FirstOrDefault(p =>
                                    p.Module == info.Module &&
                                    p.Page == info.Page &&
                                    p.Control == info.Control &&
                                    p.Action == info.Action &&
                                    p.PermissionType == (int)type.Value);

                                if (permission == null)
                                {
                                    permission = new Permission
                                    {
                                        Module = info.Module,
                                        Page = info.Page,
                                        Control = info.Control,
                                        Action = info.Action,
                                        PermissionType = (int)type.Value
                                    };
                                    _context.Permissions.Add(permission);
                                }

                                permissionsToSave.Add(permission);
                            }
                        }
                    }
                }

                // �O�s���Ʈw
                _context.SaveChanges();

                // �ھڨӷ���s���p
                switch (_currentSource)
                {
                    case PermissionSource.Department:
                        UpdateDepartmentPermissions(_selectedDepartmentId, permissionsToSave);
                        break;

                    case PermissionSource.UserGroup:
                        UpdateUserGroupPermissions(_selectedUserGroupId, permissionsToSave);
                        break;

                    case PermissionSource.Employee:
                        UpdateEmployeePermissions(_selectedEmployeeId, permissionsToSave);
                        break;
                }

                MessageBox.Show("�v���w���\�x�s", "���\", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"�x�s�v���ɵo�Ϳ��~: {ex.Message}", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// ��s�������v���]�w�C
        /// </summary>
        /// <param name="departmentId">���� ID�C</param>
        /// <param name="permissions">�v���M��C</param>
        private void UpdateDepartmentPermissions(int departmentId, List<Permission> permissions)
        {
            var dept = _context.Departments
                .Include(d => d.Permissions)
                .FirstOrDefault(d => d.Id == departmentId);

            if (dept != null)
            {
                dept.Permissions.Clear();
                foreach (var perm in permissions)
                {
                    dept.Permissions.Add(perm);
                }
                _context.SaveChanges();
                _permission.RefreshDepartmentPermissions(departmentId);
            }
        }

        /// <summary>
        /// ��s�ϥΪ̸s�ժ��v���]�w�C
        /// </summary>
        /// <param name="userGroupId">�ϥΪ̸s�� ID�C</param>
        /// <param name="permissions">�v���M��C</param>
        private void UpdateUserGroupPermissions(int userGroupId, List<Permission> permissions)
        {
            var group = _context.UserGroups
                .Include(g => g.Permissions)
                .FirstOrDefault(g => g.Id == userGroupId);

            if (group != null)
            {
                group.Permissions.Clear();
                foreach (var perm in permissions)
                {
                    group.Permissions.Add(perm);
                }
                _context.SaveChanges();
                _permission.RefreshUserGroupPermissions(userGroupId);
            }
        }

        /// <summary>
        /// ��s���u���v���]�w�C
        /// </summary>
        /// <param name="employeeId">���u ID�C</param>
        /// <param name="permissions">�v���M��C</param>
        private void UpdateEmployeePermissions(string employeeId, List<Permission> permissions)
        {
            var emp = _context.Employees
                .Include(e => e.Permissions)
                .FirstOrDefault(e => e.EmployeeId == employeeId);

            if (emp != null)
            {
                emp.Permissions.Clear();
                foreach (var perm in permissions)
                {
                    emp.Permissions.Add(perm);
                }
                _context.SaveChanges();
                _permission.RefreshUserPermissions(employeeId);
            }
        }

        #endregion

        #region Nested Classes

        /// <summary>
        /// �ӷ��`�I��Ƶ��c�C
        /// </summary>
        private class SourceNodeData
        {
            public PermissionSource Source { get; set; }
            public int Id { get; set; }
            public string EmployeeId { get; set; }
            public string Name { get; set; }
        }

        /// <summary>
        /// ����v����T���c�C
        /// </summary>
        private class ControlPermissionInfo
        {
            public string Module { get; set; }
            public string Page { get; set; }
            public string Control { get; set; }
            public string Action { get; set; }

            public override bool Equals(object obj)
            {
                if (obj is ControlPermissionInfo other)
                {
                    return Module == other.Module &&
                           Page == other.Page &&
                           Control == other.Control &&
                           Action == other.Action;
                }
                return false;
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    int hash = 17;
                    hash = hash * 23 + (Module?.GetHashCode() ?? 0);
                    hash = hash * 23 + (Page?.GetHashCode() ?? 0);
                    hash = hash * 23 + (Control?.GetHashCode() ?? 0);
                    hash = hash * 23 + (Action?.GetHashCode() ?? 0);
                    return hash;
                }
            }
        }

        /// <summary>
        /// ���\�P�T�� CheckBox �t�ﵲ�c�C
        /// </summary>
        private class PermissionCheckBoxPair
        {
            public UICheckBox AllowCheckBox { get; set; }
            public UICheckBox DenyCheckBox { get; set; }
            public ControlPermissionInfo ControlInfo { get; set; }
        }

        #endregion
    }
}
