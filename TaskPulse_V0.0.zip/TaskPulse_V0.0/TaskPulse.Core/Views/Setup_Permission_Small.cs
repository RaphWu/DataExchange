﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Permission_Small : UserControl, IDisposable
    {
        #region fields

        private const int SYMBOL_CHECK = 61510;
        private const int SYMBOL_UNCHECK = 559445;

        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly ICurrentUserService _currentUser;
        private readonly IPermissionService _permission;
        private string _prefix;

        private PermissionSource _permissionSource;
        private HashSet<PermissionData> _permTable;

        private int _idDepartment;

        private int _idUserGroup;

        private string _idEmployee;
        //private Department _department = null;
        //private Employee _employee = null;

        private int _rSymbolToolQuest = SYMBOL_UNCHECK;
        private int _rSymbolMechaTrack = SYMBOL_UNCHECK;
        private int _rSymbolMaintiFlow = SYMBOL_UNCHECK;
        private int _rSymbolSetup = SYMBOL_UNCHECK;

        #endregion fields

        public Setup_Permission_Small(
            CoreContext coreContext,
            CurrentUserContext currentUserContext,
            ICurrentUserService currentUserService,
            IPermissionService permissionService)
        {
            InitializeComponent();
            _context = coreContext;
            _user = currentUserContext;
            _currentUser = currentUserService;
            _permission = permissionService;

            UISetup(this.Controls);

            WeakReferenceMessenger.Default.Register<PermissionSettingPageMessage>(this, (r, m) =>
            {
                SourceTargetChange(m.Value);
            });

            NM_Permission.SelectedColor = CommonStyles.AccentColor;
            NM_Permission.SelectedNode = NM_Permission.Nodes[NM_Permission.Nodes.Count - 1];
            TC_Permission.SelectedTab = TP_Setup;

            foreach (var ctl in TP_MaintiFlow.Controls)
            {
                if (ctl is UICheckBox cb)
                {
                    cb.CheckedChanged += (s, e) =>
                    {
                        UICheckBox uICheckBox = s as UICheckBox;
                        if (uICheckBox.Checked)
                        {
                            _rSymbolMaintiFlow = SYMBOL_CHECK;
                            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[2]);
                            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[2], SYMBOL_CHECK);
                        }

                        bool hasChecked = CBr_MaintiFlowSummy.Checked ||
                                          CBe_MaintiFlowSummy.Checked ||
                                          CBe_Create.Checked ||
                                          CBe_Cancel.Checked ||
                                          CBe_Accept.Checked ||
                                          CBe_Maintant.Checked ||
                                          CBe_Confirm.Checked;
                        if (!hasChecked)
                        {
                            _rSymbolMaintiFlow = SYMBOL_UNCHECK;
                            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[3]);
                            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[3], SYMBOL_UNCHECK);
                        }
                    };
                }
            }

            foreach (var ctl in TP_Setup.Controls)
            {
                if (ctl is UICheckBox cb)
                {
                    cb.CheckedChanged += (s, e) =>
                    {
                        UICheckBox uICheckBox = s as UICheckBox;
                        if (uICheckBox.Checked)
                        {
                            _rSymbolSetup = SYMBOL_CHECK;
                            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[3]);
                            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[3], SYMBOL_CHECK);
                        }

                        bool hasChecked = CBr_MachineManager.Checked ||
                                          CBe_MachineManager.Checked ||
                                          CBr_EmployeeManager.Checked ||
                                          CBe_EmployeeManager.Checked;
                        if (!hasChecked)
                        {
                            _rSymbolMaintiFlow = SYMBOL_UNCHECK;
                            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[3]);
                            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[3], SYMBOL_UNCHECK);
                        }
                    };
                }
            }
        }

        private void UISetup(ControlCollection controls)
        {
            CommonStyles.SetButton(btn_Save);

            foreach (Control control in controls)
            {
                if (control is UITitlePanel tp)
                {
                    tp.TitleColor = CommonStyles.BackColor;
                }

                if (control is UICheckBox cb)
                {
                    CommonStyles.SetCheckBox(cb);
                }
                else if (control is UIButton btn)
                {
                    CommonStyles.SetButton(btn);
                }
                else if (control is UILine line)
                {
                    line.LineColor = CommonStyles.BackColor;
                }
                else if (control.HasChildren)
                {
                    UISetup(control.Controls);
                }
            }
        }

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        /********************
         * 權限表
         ********************/

        private void CLearAllCheckBox()
        {
            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[0]);
            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[0], SYMBOL_UNCHECK);
            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[1]);
            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[1], SYMBOL_UNCHECK);
            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[2]);
            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[2], SYMBOL_UNCHECK);
            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[3]);
            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[3], SYMBOL_UNCHECK);

            // 工具委託

            // 專案管理

            // 維護工單
            CBe_MaintiFlowSummy.Checked = false;
            CBr_MaintiFlowSummy.Checked = false;
            CBe_Create.Checked = false;
            CBe_Cancel.Checked = false;
            CBe_Accept.Checked = false;
            CBe_Maintant.Checked = false;
            CBe_Confirm.Checked = false;

            // 設定
            CBe_MachineManager.Checked = false;
            CBr_MachineManager.Checked = false;
            CBe_EmployeeManager.Checked = false;
            CBr_EmployeeManager.Checked = false;
        }

        private void SourceTargetChange(PermissionSettingInfo info)
        {
            if (_permissionSource != info.PermissionSource)
                _permissionSource = info.PermissionSource;

            switch (_permissionSource)
            {
                case PermissionSource.Department:
                    _idDepartment = info.DepartmentId;
                    _permTable = _permission.GetDepartmentPermissions(info.DepartmentId);
                    break;
                case PermissionSource.UserGroup:
                    _idUserGroup = info.UserGroupId;
                    _permTable = _permission.GetUserGroupPermissions(info.UserGroupId);
                    break;
                case PermissionSource.Employee:
                    _idEmployee = info.EmployeeId;
                    _permTable = _permission.GetUserPermissions(_idEmployee);
                    break;
                default:
                    _permTable = null;
                    return;
            }
            ApplyPermissions();
        }

        private void ApplyPermissions()
        {
            CLearAllCheckBox();
            foreach (var perm in _permTable)
            {
                switch (perm.Module)
                {
                    case PermissionWords.MODULE_TOOL_QUEST:

                        break;
                    case PermissionWords.MODULE_MECHA_TRACK:

                        break;
                    case PermissionWords.MODULE_MAINTI_FLOW:
                        if (perm.Page == PermissionWords.PAGE_SUMMARY)
                        {
                            if (perm.Control == "**")
                                CBe_MaintiFlowSummy.Checked = true;

                            if (perm.Control == "*" && perm.Action == PermissionWords.ACTION_VIEW)
                                CBr_MaintiFlowSummy.Checked = true;
                        }
                        if (perm.Page == PermissionWords.PAGE_CREATE_FLOW && perm.Control == "**")
                            CBe_Create.Checked = true;

                        if (perm.Page == PermissionWords.PAGE_CANCEL_FLOW && perm.Control == "**")
                            CBe_Cancel.Checked = true;

                        if (perm.Page == PermissionWords.PAGE_ACCEPT_FLOW && perm.Control == "**")
                            CBe_Accept.Checked = true;

                        if (perm.Page == PermissionWords.PAGE_MAINTANT_FLOW && perm.Control == "**")
                            CBe_Maintant.Checked = true;

                        if (perm.Page == PermissionWords.PAGE_FLOW_CONFIRM && perm.Control == "**")
                            CBe_Confirm.Checked = true;

                        break;
                    case PermissionWords.MODULE_SETUP:
                        if (perm.Page == PermissionWords.PAGE_MACHINE_MANAGER)
                        {
                            if (perm.Control == "**")
                                CBe_MachineManager.Checked = true;

                            if (perm.Control == "*" && perm.Action == PermissionWords.ACTION_VIEW)
                                CBr_MachineManager.Checked = true;
                        }
                        if (perm.Page == PermissionWords.PAGE_EMPLOYEE_MANAGER)
                        {
                            if (perm.Control == "**")
                                CBe_EmployeeManager.Checked = true;

                            if (perm.Control == "*" && perm.Action == PermissionWords.ACTION_VIEW)
                                CBr_EmployeeManager.Checked = true;
                        }

                        break;
                    case PermissionWords.MODULE_HOME:
                        break;
                }
            }
        }

        /********************
         * NavMenu
         ********************/
        private void NM_Permission_MenuItemClick(TreeNode node, NavMenuItem item, int pageIndex)
        {
            TC_Permission.SelectedIndex = node.Index;
        }

        private void NM_Permission_NodeRightSymbolClick(object sender, TreeNode node, int index, int symbol)
        {
            int newSymbol = symbol == SYMBOL_CHECK ? SYMBOL_UNCHECK : SYMBOL_CHECK;
            bool newChked = newSymbol == SYMBOL_CHECK;
            TC_Permission.SelectedIndex = node.Index;
            switch (node.Index)
            {
                case 0:
                    _rSymbolToolQuest = newSymbol;
                    break;
                case 1:
                    _rSymbolMechaTrack = newSymbol;
                    break;
                case 2:
                    _rSymbolMaintiFlow = newSymbol;
                    //CBr_MaintiFlowSummy.Checked = newChked;
                    //CBe_MaintiFlowSummy.Checked = newChked;
                    //CBe_Create.Checked = newChked;
                    //CBe_Cancel.Checked = newChked;
                    //CBe_Accept.Checked = newChked;
                    //CBe_Maintant.Checked = newChked;
                    //CBe_Confirm.Checked = newChked;
                    break;
                case 3:
                    _rSymbolSetup = newSymbol;
                    //CBr_MachineManager.Checked = newChked;
                    //CBe_MachineManager.Checked = newChked;
                    //CBr_EmployeeManager.Checked = newChked;
                    //CBe_EmployeeManager.Checked = newChked;
                    break;
            }
            NM_Permission.ClearNodeRightSymbol(node);
            NM_Permission.AddNodeRightSymbol(node, newSymbol);
        }

        private void NM_Permission_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private async void btn_Save_Click(object sender, EventArgs e)
        {
            var perms = new List<Permission>();

            if (_rSymbolToolQuest == SYMBOL_CHECK)
            {
                perms.Add(new Permission()
                {
                    Module = PermissionWords.MODULE_TOOL_QUEST,
                    Page = "*",
                    Control = "",
                    Action = "",
                });
            }

            if (_rSymbolMechaTrack == SYMBOL_CHECK)
            {
                perms.Add(new Permission()
                {
                    Module = PermissionWords.MODULE_MECHA_TRACK,
                    Page = "**",
                    Control = "",
                    Action = "",
                });
            }

            if (_rSymbolMaintiFlow == SYMBOL_CHECK)
            {
                if (CBr_MaintiFlowSummy.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_MAINTI_FLOW,
                        Page = PermissionWords.PAGE_SUMMARY,
                        Control = "*",
                        Action = PermissionWords.ACTION_VIEW,
                    });
                if (CBe_MaintiFlowSummy.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_MAINTI_FLOW,
                        Page = PermissionWords.PAGE_SUMMARY,
                        Control = "**",
                        Action = "",
                    });
                if (CBe_Create.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_MAINTI_FLOW,
                        Page = PermissionWords.PAGE_CREATE_FLOW,
                        Control = "**",
                        Action = "",
                    });
                if (CBe_Cancel.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_MAINTI_FLOW,
                        Page = PermissionWords.PAGE_CANCEL_FLOW,
                        Control = "**",
                        Action = "",
                    });
                if (CBe_Accept.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_MAINTI_FLOW,
                        Page = PermissionWords.PAGE_ACCEPT_FLOW,
                        Control = "**",
                        Action = "",
                    });
                if (CBe_Maintant.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_MAINTI_FLOW,
                        Page = PermissionWords.PAGE_MAINTANT_FLOW,
                        Control = "**",
                        Action = "",
                    });
                if (CBe_Confirm.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_MAINTI_FLOW,
                        Page = PermissionWords.PAGE_FLOW_CONFIRM,
                        Control = "**",
                        Action = "",
                    });
            }

            if (_rSymbolSetup == SYMBOL_CHECK)
            {
                if (CBe_MachineManager.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_SETUP,
                        Page = PermissionWords.PAGE_MACHINE_MANAGER,
                        Control = "**",
                        Action = "",
                    });
                if (CBr_MachineManager.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_SETUP,
                        Page = PermissionWords.PAGE_MACHINE_MANAGER,
                        Control = "*",
                        Action = PermissionWords.ACTION_VIEW,
                    });

                if (CBe_EmployeeManager.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_SETUP,
                        Page = PermissionWords.PAGE_EMPLOYEE_MANAGER,
                        Control = "**",
                        Action = "",
                    });
                if (CBr_EmployeeManager.Checked)
                    perms.Add(new Permission()
                    {
                        Module = PermissionWords.MODULE_SETUP,
                        Page = PermissionWords.PAGE_EMPLOYEE_MANAGER,
                        Control = "*",
                        Action = PermissionWords.ACTION_VIEW,
                    });
            }

            // 存入資料庫
            var newPermSet = new HashSet<Permission>(perms);
            List<Permission> existingPerms = default; // 取得現有權限
            Department department = default;
            Employee employee = default;

            switch (_permissionSource)
            {
                case PermissionSource.Department:
                    department = await _context.Departments
                        .Include(nameof(Department.Permissions))
                        .FirstOrDefaultAsync(u => u.Id == _idDepartment);
                    existingPerms = department.Permissions.ToList();

                    break;
                case PermissionSource.UserGroup:

                    break;
                case PermissionSource.Employee:
                    employee = await _context.Employees
                        .Include(nameof(Employee.Permissions))
                        .FirstOrDefaultAsync(u => u.EmployeeId == _idEmployee);
                    existingPerms = employee.Permissions.ToList();

                    break;
                default:
                    throw new ArgumentException($"PermissionSource參數異常: {_permissionSource}");
            }

            //// 找出要刪除的權限（舊的有、新的沒有）
            //var toRemove = existingPerms
            //    .Where(old => !newPermSet.Contains(new Permission
            //    {
            //        Module = old.Module,
            //        Page = old.Page,
            //        Control = old.Control,
            //        Action = old.Action
            //    }))
            //    .ToList();

            //// 找出要新增的權限（新的有、舊的沒有）
            //var existingPermSet = new HashSet<Permission>(
            //    existingPerms.Select(p => new Permission
            //    {
            //        Module = p.Module,
            //        Page = p.Page,
            //        Control = p.Control,
            //        Action = p.Action
            //    }));

            //var toAdd = newPermSet
            //    .Where(newp => !existingPermSet.Contains(newp))
            //    .ToList();

            //// 新增
            //foreach (var permData in toAdd)
            //{
            //    var perm = await _context.Permissions
            //        .FirstOrDefaultAsync(p =>
            //            p.Module == permData.Module &&
            //            p.Page == permData.Page &&
            //            p.Control == permData.Control &&
            //            p.Action == permData.Action);

            //    if (perm == null)
            //    {
            //        perm = new Permission
            //        {
            //            Module = permData.Module,
            //            Page = permData.Page,
            //            Control = permData.Control,
            //            Action = permData.Action,
            //        };
            //        _context.Permissions.Add(perm);
            //    }
            //}

            switch (_permissionSource)
            {
                case PermissionSource.Department:
                    //foreach (var perm in toRemove)
                    //{
                    //    //department = await _context.Departments.FindAsync(perm.Id);
                    //    department.Permissions.Remove(perm);
                    //}
                    //foreach (var perm in toAdd)
                    //    department.Permissions.Add(perm);
                    var dep = _context.Departments
                        .Include(nameof(Department.Permissions))
                        .FirstOrDefault(u => u.Id == _idDepartment);
                    if (dep != null)
                    {
                        dep.Permissions.Clear();
                        foreach (var perm in perms)
                        {
                            //perm.Owner = PermissionSource.Department;
                            dep.Permissions.Add(perm);
                        }
                        await _context.SaveChangesAsync();

                        _permission.RefreshDepartmentPermissions(_idDepartment);
                        await _permission.CleanOrphanPermissions();
                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{dep.DepartmentName} 權限已更新。"));
                    }
                    break;
                case PermissionSource.UserGroup:

                    break;
                case PermissionSource.Employee:
                    var emp = await _context.Employees
                            .Include(nameof(Employee.Permissions))
                            .FirstOrDefaultAsync(u => u.EmployeeId == _idEmployee);
                    if (emp != null)
                    {
                        emp.Permissions.Clear();

                        //foreach (var perm in toRemove)
                        //    emp.Permissions.Remove(perm);
                        //foreach (var perm in toAdd)
                        //    emp.Permissions.Add(perm);
                        foreach (var perm in perms)
                        {
                            //perm.Owner = PermissionSource.Employee;
                            emp.Permissions.Add(perm);
                        }

                        await _context.SaveChangesAsync();
                        _permission.RefreshUserPermissions(_idEmployee);
                        await _permission.CleanOrphanPermissions();
                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{emp.EmployeeName} 權限已更新。"));
                    }
                    break;
                default:
                    throw new ArgumentException($"PermissionSource 參數異常: {_permissionSource}");
            }
        }

        /********************
         * 維護工單
         ********************/
    }
}
