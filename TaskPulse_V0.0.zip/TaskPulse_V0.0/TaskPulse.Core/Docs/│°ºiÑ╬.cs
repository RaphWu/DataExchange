﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;
//using System.Windows.Forms;
//using Calin.TaskPulse.Core.Models;
//using Calin.TaskPulse.Core.Services;
//using Sunny.UI;

//namespace Calin.TaskPulse.Core.Docs
//{
//    internal class 報告用
//    {
//        #region fields

//        private readonly IEntityCacheManager _cacheManager;
//        private readonly CoreContext _context;
//        private readonly CoreData _coreData;

//        private bool _isInitialized = false;
//        private CancellationTokenSource _syncCts;

//        private readonly List<string> TreeView部門分類s;
//        private readonly Dictionary<string, List<TabPage>> 員工分類資料 = new Dictionary<string, List<TabPage>>();

//        #endregion fields

//        public 報告用(
//            IEntityCacheManager entityCacheManager,
//            CoreContext coreContext,
//            CoreData coreData)
//        {
//            _cacheManager = entityCacheManager;
//            _context = coreContext;
//            _coreData = coreData;
//        }

//        public async Task CreateEmployeeTabPage()
//        {
//            _coreData.EmployeeMultiTabPageCache = new Dictionary<string, List<TabPage>>();

//            foreach (string TreeView部門分類 in TreeView部門分類s)
//            {
//                var 部門名冊 = 員工分類資料[TreeView部門分類]
//                    .OrderBy(e => e.部門)
//                    .ToList();
//                List<TabPage> emTabPages = new List<TabPage>();

//                int colCount = 3;
//                int typeCount = 部門名冊.Count();
//                int rowCount = (int)Math.Ceiling((double)typeCount / (double)colCount);

//                var emFlow = new TableLayoutPanel
//                {
//                    // ...
//                };
//                var emTabPage = new TabPage(TreeView部門分類)
//                {
//                    // ...
//                };
//                emTabPage.Controls.Add(emFlow);

//                int nCol = 0;
//                int nRow = 0;
//                foreach (var 人員清單 in 部門名冊)
//                {
//                    var cb = new CheckBox
//                    {
//                        // ...
//                    };
//                    emFlow.Controls.Add(cb, nCol, nRow);

//                    // var rb = new RadioButton

//                    if (++nCol >= colCount)
//                    {
//                        nCol = 0;
//                        ++nRow;
//                    }
//                }
//                emTabPages.Add(emTabPage);
//                _coreData.EmployeeMultiTabPageCache.Add(TreeView部門分類, emTabPages);
//                // ...
//            }
//            await Task.CompletedTask;
//        }
//    }
//}
