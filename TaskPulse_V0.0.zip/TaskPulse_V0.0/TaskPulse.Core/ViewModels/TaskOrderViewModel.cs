﻿using System;
using System.Collections.Generic;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.ViewModels
{
    public class TaskOrderViewModel : BindableBase
    {
        public bool Edited
        {
            get { return _edited; }
            set { SetProperty(ref _edited, value); }
        }
        private bool _edited;

        public int Id
        {
            get { return _id; }
            set { SetProperty(ref _id, value); }
        }
        private int _id;

        public string WorkOrderNo
        {
            get { return _workOrderNo; }
            set { SetProperty(ref _workOrderNo, value); }
        }
        private string _workOrderNo;

        public FlowStatus Status
        {
            get { return _status; }
            set { SetProperty(ref _status, value); }
        }
        private FlowStatus _status;

        public int StatusId
        {
            get { return _statusId; }
            set { SetProperty(ref _statusId, value); }
        }
        private int _statusId;

        public string StatusString
        {
            get { return _statusString; }
            set { SetProperty(ref _statusString, value); }
        }
        private string _statusString;

        //public int MachineId
        //{
        //    get { return _machineId; }
        //    set { SetProperty(ref _machineId, value); }
        //}
        //private int _machineId;

        public string MachineCode
        {
            get { return _machineCode; }
            set { SetProperty(ref _machineCode, value); }
        }
        private string _machineCode;

        public string FullMachineName
        {
            get { return _fullMachineName; }
            set { SetProperty(ref _fullMachineName, value); }
        }
        private string _fullMachineName;

        public string ModelName
        {
            get { return _modelName; }
            set { SetProperty(ref _modelName, value); }
        }
        private string _modelName;

        public Workstation Workstation
        {
            get { return _workstation; }
            set { SetProperty(ref _workstation, value); }
        }
        private Workstation _workstation;

        public int? WorkstationId
        {
            get { return _workstationId; }
            set { SetProperty(ref _workstationId, value); }
        }
        private int? _workstationId;

        public string WorkstationName
        {
            get { return _workstationName; }
            set { SetProperty(ref _workstationName, value); }
        }
        private string _workstationName;

        public string ModelWsName
        {
            get { return _modelWsName; }
            set { SetProperty(ref _modelWsName, value); }
        }
        private string _modelWsName;

        public int CreatorId
        {
            get { return _creatorId; }
            set { SetProperty(ref _creatorId, value); }
        }
        private int _creatorId;

        public string CreatorName
        {
            get { return _creatorName; }
            set { SetProperty(ref _creatorName, value); }
        }
        private string _creatorName;

        public string CreatorNameWithDepartment
        {
            get { return _creatorHalfName; }
            set { SetProperty(ref _creatorHalfName, value); }
        }
        private string _creatorHalfName;

        public DateTime? CreationDateTime
        {
            get { return _creationDateTime; }
            set { SetProperty(ref _creationDateTime, value); }
        }
        private DateTime? _creationDateTime;

        public string CreationDateTimeString
        {
            get { return _creationDateTimeString; }
            set { SetProperty(ref _creationDateTimeString, value); }
        }
        private string _creationDateTimeString;

        public string CreationDateString
        {
            get { return _creationDateString; }
            set { SetProperty(ref _creationDateString, value); }
        }
        private string _creationDateString;

        /*****/

        public string MaintenanceUnit
        {
            get { return _maintenanceUnit; }
            set { SetProperty(ref _maintenanceUnit, value); }
        }
        private string _maintenanceUnit;

        public int? MaintenanceUnitId
        {
            get { return _maintenanceUnitId; }
            set { SetProperty(ref _maintenanceUnitId, value); }
        }
        private int? _maintenanceUnitId;

        public string MaintenanceUnitString
        {
            get { return _maintenanceUnitString; }
            set { SetProperty(ref _maintenanceUnitString, value); }
        }
        private string _maintenanceUnitString;

        public ICollection<Employee> Engineers
        {
            get { return _engineerId; }
            set { SetProperty(ref _engineerId, value); }
        }
        private ICollection<Employee> _engineerId;

        public string EngineerString
        {
            get { return _engineerString; }
            set { SetProperty(ref _engineerString, value); }
        }
        private string _engineerString;

        public Dictionary<int, string> EngineerList
        {
            get { return _engineerList; }
            set { SetProperty(ref _engineerList, value); }
        }
        private Dictionary<int, string> _engineerList;

        public DateTime? AcceptedTime
        {
            get { return _acceptedTime; }
            set { SetProperty(ref _acceptedTime, value); }
        }
        private DateTime? _acceptedTime;

        public string AcceptedTimeString
        {
            get { return _AcceptedTimeString; }
            set { SetProperty(ref _AcceptedTimeString, value); }
        }
        private string _AcceptedTimeString;

        public int? IssueCategoryId
        {
            get { return _IssueCategoryId; }
            set { SetProperty(ref _IssueCategoryId, value); }
        }
        private int? _IssueCategoryId;

        public string IssueCategoryString
        {
            get { return _issueCategoryString; }
            set { SetProperty(ref _issueCategoryString, value); }
        }
        private string _issueCategoryString;

        public string IssueDescription
        {
            get { return _issueDescription; }
            set { SetProperty(ref _issueDescription, value); }
        }
        private string _issueDescription;

        public string Details
        {
            get { return _details; }
            set { SetProperty(ref _details, value); }
        }
        private string _details;

        public DateTime? RepairStarted
        {
            get { return _repairStarted; }
            set { SetProperty(ref _repairStarted, value); }
        }
        private DateTime? _repairStarted;

        public string RepairStartedString
        {
            get { return _repairStartedString; }
            set { SetProperty(ref _repairStartedString, value); }
        }
        private string _repairStartedString;

        public DateTime? RepairCompleted
        {
            get { return _repairCompleted; }
            set { SetProperty(ref _repairCompleted, value); }
        }
        private DateTime? _repairCompleted;

        public string RepairCompletedString
        {
            get { return _repairCompletedString; }
            set { SetProperty(ref _repairCompletedString, value); }
        }
        private string _repairCompletedString;

        public TimeSpan RepairDuration
        {
            get { return _repairDuration; }
            set { SetProperty(ref _repairDuration, value); }
        }
        private TimeSpan _repairDuration;

        public string RepairDurationString
        {
            get { return _repairDurationString; }
            set { SetProperty(ref _repairDurationString, value); }
        }
        private string _repairDurationString;

        public DateTime? FillingTime
        {
            get { return _fillingTime; }
            set { SetProperty(ref _fillingTime, value); }
        }
        private DateTime? _fillingTime;

        public string FillingTimeString
        {
            get { return _fillingTimeString; }
            set { SetProperty(ref _fillingTimeString, value); }
        }
        private string _fillingTimeString;

        /*****/

        public int? RequestingUnitId
        {
            get { return _requestingUnitId; }
            set { SetProperty(ref _requestingUnitId, value); }
        }
        private int? _requestingUnitId;

        public string RequestingUnitString
        {
            get { return _requestingUnitString; }
            set { SetProperty(ref _requestingUnitString, value); }
        }
        private string _requestingUnitString;

        public int? FeedbackEmployeeId
        {
            get { return _requestingEmployeeId; }
            set { SetProperty(ref _requestingEmployeeId, value); }
        }
        private int? _requestingEmployeeId;

        public string FeedbackEmployeeString
        {
            get { return _requestingEmployeeString; }
            set { SetProperty(ref _requestingEmployeeString, value); }
        }
        private string _requestingEmployeeString;

        public string Feedback
        {
            get { return _feedback; }
            set { SetProperty(ref _feedback, value); }
        }
        private string _feedback;

        public DateTime? OutageStarted
        {
            get { return _outageStarted; }
            set
            {
                SetProperty(ref _outageStarted, value);

                if (OutageEnded != null && OutageStarted != null)
                    OutageDuration = (TimeSpan)(OutageEnded - OutageStarted);
                else
                    OutageDuration = TimeSpan.Zero;
            }
        }
        private DateTime? _outageStarted;

        public string OutageStartedString
        {
            get { return _OutageStartedString; }
            set { SetProperty(ref _OutageStartedString, value); }
        }
        private string _OutageStartedString;

        public DateTime? OutageEnded
        {
            get { return _outageEnded; }
            set
            {
                SetProperty(ref _outageEnded, value);

                if (OutageEnded != null && OutageStarted != null)
                    OutageDuration = (TimeSpan)(OutageEnded - OutageStarted);
                else
                    OutageDuration = TimeSpan.Zero;
            }
        }
        private DateTime? _outageEnded;

        public string OutageEndedString
        {
            get { return _outageEndedString; }
            set { SetProperty(ref _outageEndedString, value); }
        }
        private string _outageEndedString;

        public TimeSpan OutageDuration
        {
            get { return _outageDuration; }
            set { SetProperty(ref _outageDuration, value); }
        }
        private TimeSpan _outageDuration;

        public string OutageDurationString
        {
            get { return _outageDurationString; }
            set { SetProperty(ref _outageDurationString, value); }
        }
        private string _outageDurationString;

        /*****/

        public string Responsible
        {
            get { return _responsible; }
            set { SetProperty(ref _responsible, value); }
        }
        private string _responsible;
    }
}
