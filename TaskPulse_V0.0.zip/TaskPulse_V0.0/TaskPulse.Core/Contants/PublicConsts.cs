﻿namespace Calin.TaskPulse.Core.Contants
{
    public static class PublicConsts
    {
        //Prefix Suffix
        public const string SUFFIX_SYS = "系統";

        public const string APP_NAME = "TaskPulse";
        public const string MENU = "選單";
        public const string TOOL_QUEST = "工具委託";
        public const string MECHA_TRACK = "專案管理";
        public const string MAINTI_FLOW = "維護工單";
    }
}
