﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.Contants
{
    /// <summary>
    /// 頁面代號。
    /// </summary>
    public enum PageCode
    {
        None = 0,

        /********************
         * 右側選單
         ********************/
        [Description("權限管理")]
        AuthorityManager = 1,

        [Description("使用者")]
        User = 2,

        [Description("登入")]
        Login = 3,

        [Description("登出")]
        Logout = 4,

        [Description("切換使用者")]
        SwitchUser = 5,

        [Description("設定")]
        Setup = 10,

        [Description("設定")]
        SetupTrigger = 19,

        /***** 設定 - 共用資料 2 *****/

        [Description("人員管理")]
        EmployeesManagement = 20,

        [Description("人員名冊")]
        Employees = 24,

        [Description("人員基本資料")]
        EmployeeInfo = 25,

        [Description("權限系統")]
        Permission = 28,

        /***** 設定 - 工具委託 4 *****/

        /***** 設定 - 專案管理 5 *****/

        /***** 設定 - 工單維護 6 *****/

        [Description("機台管理")]
        Machines = 60,

        [Description("機台列表")]
        MachinesSummary = 61,

        [Description("基本資料")]
        MachineInfo1 = 65,

        [Description("分類管理")]
        MachineInfo2 = 68,

        [Description("機種&&工站")]
        Models = 64,

        [Description("維護資料")]
        Maintenance = 67,

        /********************
         * 主頁面
         ********************/
        [Description("主頁面")]
        MainPage = 100,

        /********************
         * 工具委託
         ********************/
        [Description(PublicConsts.TOOL_QUEST)]
        ToolQuest = 200,

        /********************
         * 專案管理
         ********************/
        [Description(PublicConsts.MECHA_TRACK)]
        MechaTrack = 300,

        /********************
         * 維護工單
         ********************/
        [Description(PublicConsts.MAINTI_FLOW)]
        MaintiFlow = 400,

        [Description("維護總表")]
        MaintiFlowSummary = 401,

        // 工單操作

        [Description("新建工單")]
        CreateFlow = 432,

        [Description("取消工單")]
        CancelFlow = 433,

        [Description("接單")]
        AcceptFlow = 434,

        [Description("維護作業")]
        MaintiWork = 435,

        [Description("確認作業")]
        FlowConfirmed = 436,
    }
}
