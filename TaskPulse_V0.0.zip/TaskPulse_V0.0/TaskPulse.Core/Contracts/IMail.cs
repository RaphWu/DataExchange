﻿using System.Collections.Generic;

namespace Calin.TaskPulse.Core.Contracts
{
    public interface IMail
    {
        /// <summary>
        /// 發送信件。
        /// </summary>
        /// <param name="senderTitle">寄信者名稱。</param>
        /// <param name="recipient">收件人清單。</param>
        /// <param name="subject">主旨。</param>
        /// <param name="contents">信件內容。</param>
        void SendMail(string senderTitle, ICollection<int> recipient, string subject, string contents);
    }
}
