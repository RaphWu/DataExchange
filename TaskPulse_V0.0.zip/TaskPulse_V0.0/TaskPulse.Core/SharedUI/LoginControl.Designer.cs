﻿namespace Calin.TaskPulse.Core.SharedUI
{
    partial class LoginControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new Sunny.UI.UIButton();
            this.btnLogin = new Sunny.UI.UIButton();
            this.tbPassword = new Sunny.UI.UITextBox();
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiAvatar1 = new Sunny.UI.UIAvatar();
            this.cbUserName = new Sunny.UI.UIComboBox();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCancel.Location = new System.Drawing.Point(137, 265);
            this.btnCancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Radius = 15;
            this.btnCancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Size = new System.Drawing.Size(95, 40);
            this.btnCancel.Style = Sunny.UI.UIStyle.Custom;
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "取消";
            this.btnCancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnLogin.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnLogin.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(30)))), ((int)(((byte)(63)))));
            this.btnLogin.Location = new System.Drawing.Point(22, 265);
            this.btnLogin.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Radius = 15;
            this.btnLogin.Size = new System.Drawing.Size(95, 40);
            this.btnLogin.Style = Sunny.UI.UIStyle.Custom;
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "登入";
            this.btnLogin.TipsFont = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // tbPassword
            // 
            this.tbPassword.ButtonSymbol = 61453;
            this.tbPassword.ButtonSymbolOffset = new System.Drawing.Point(1, 1);
            this.tbPassword.ButtonSymbolSize = 20;
            this.tbPassword.ButtonWidth = 22;
            this.tbPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbPassword.EnterAsTab = true;
            this.tbPassword.Font = new System.Drawing.Font("Tahoma", 11F);
            this.tbPassword.Location = new System.Drawing.Point(22, 212);
            this.tbPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbPassword.MinimumSize = new System.Drawing.Size(1, 16);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Padding = new System.Windows.Forms.Padding(5);
            this.tbPassword.PasswordChar = '●';
            this.tbPassword.ShowButton = true;
            this.tbPassword.ShowText = false;
            this.tbPassword.Size = new System.Drawing.Size(210, 30);
            this.tbPassword.Symbol = 361572;
            this.tbPassword.TabIndex = 1;
            this.tbPassword.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.tbPassword.Watermark = "請輸入密碼";
            this.tbPassword.ButtonClick += new System.EventHandler(this.tbPassword_ButtonClick);
            // 
            // uiLine1
            // 
            this.uiLine1.BackColor = System.Drawing.Color.Transparent;
            this.uiLine1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLine1.LineSize = 3;
            this.uiLine1.Location = new System.Drawing.Point(22, 120);
            this.uiLine1.Margin = new System.Windows.Forms.Padding(4);
            this.uiLine1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(210, 30);
            this.uiLine1.TabIndex = 7;
            this.uiLine1.TabStop = false;
            this.uiLine1.Text = "使用者登入";
            // 
            // uiAvatar1
            // 
            this.uiAvatar1.BackColor = System.Drawing.Color.Transparent;
            this.uiAvatar1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.uiAvatar1.Location = new System.Drawing.Point(80, 26);
            this.uiAvatar1.Margin = new System.Windows.Forms.Padding(4);
            this.uiAvatar1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiAvatar1.Name = "uiAvatar1";
            this.uiAvatar1.Size = new System.Drawing.Size(95, 102);
            this.uiAvatar1.TabIndex = 6;
            this.uiAvatar1.TabStop = false;
            this.uiAvatar1.Text = "uiAvatar1";
            // 
            // cbUserName
            // 
            this.cbUserName.DataSource = null;
            this.cbUserName.FillColor = System.Drawing.Color.White;
            this.cbUserName.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.cbUserName.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.cbUserName.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.cbUserName.Location = new System.Drawing.Point(22, 164);
            this.cbUserName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbUserName.MinimumSize = new System.Drawing.Size(63, 0);
            this.cbUserName.Name = "cbUserName";
            this.cbUserName.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.cbUserName.ShowClearButton = true;
            this.cbUserName.ShowFilter = true;
            this.cbUserName.Size = new System.Drawing.Size(210, 30);
            this.cbUserName.SymbolSize = 24;
            this.cbUserName.TabIndex = 0;
            this.cbUserName.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.cbUserName.Watermark = "使用者名稱";
            // 
            // LoginControl
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.cbUserName);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.tbPassword);
            this.Controls.Add(this.uiLine1);
            this.Controls.Add(this.uiAvatar1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "LoginControl";
            this.Size = new System.Drawing.Size(256, 341);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UIButton btnCancel;
        private Sunny.UI.UIButton btnLogin;
        private Sunny.UI.UITextBox tbPassword;
        private Sunny.UI.UILine uiLine1;
        private Sunny.UI.UIAvatar uiAvatar1;
        private Sunny.UI.UIComboBox cbUserName;
    }
}