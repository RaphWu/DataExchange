﻿using System;
using System.Configuration;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Helper;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.Core.SharedUI
{
    public partial class LoginControl : UserControl
    {
        private readonly ILifetimeScope _scope;
        private readonly Serilog.ILogger _logger;
        private readonly ICurrentUserService _currentUser;
        private readonly CoreData _coreData;

        //public string[] NameList = new string[0];

        public LoginControl(
            ILifetimeScope lifetimeScope,
            Serilog.ILogger logger,
            ICurrentUserService currentUserService,
            CoreData coreData)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _logger = logger;
            _currentUser = currentUserService;
            _coreData = coreData;

            var _nameList = coreData.Employees.Select(e => new ListViewModel()
            {
                IdString = e.EmployeeId,
                Name = e.FullName
            }).ToList();
            uiComboBox_UserName.DataSource = _nameList;
            uiComboBox_UserName.DisplayMember = "Name";
            uiComboBox_UserName.ValueMember = "IdString";

            CommonStyles.SetButton(Button_Login);
            CommonStyles.SetButton(Button_Cancel, isCancel: true);
        }

        private async void Button_Login_Click(object sender, EventArgs ea)
        {
            var adminUser = ConfigurationManager.AppSettings["AdminUser"];
            var appEncryptedPassword = ConfigurationManager.AppSettings["AdminPassword"];
            var appPassword = AESHelper.Decrypt(appEncryptedPassword);
            var password = uiTextBox_Password.Text.Trim();
            var employeeId = uiComboBox_UserName.SelectedValue != null
                ? uiComboBox_UserName.SelectedValue.ToString()
                : uiComboBox_UserName.Text.Trim();

            if (!string.IsNullOrEmpty(employeeId))
            {
                if (employeeId.ToLower() == adminUser.ToLower())
                {
                    if (password == appPassword)
                    {
                        _currentUser.AdminLogin();
                        using (LogContext.PushProperty("Category", "UserActivity"))
                        {
                            _logger.Information("管理員登入，登入時間：{0}", DateTime.Now);
                        }
                        return;
                    }
                    else
                    {
                        using (LogContext.PushProperty("Category", "UserActivity"))
                        {
                            _logger.Information("管理員登入錯誤，嘗試時間：{0}", DateTime.Now);
                        }
                    }
                }
                else
                {
                    var auth = _scope.Resolve<IAuthService>();
                    var user = _coreData.Employees.FirstOrDefault(e => e.EmployeeId == employeeId);
                    if (await auth.ActiveDirectoryAsync(employeeId, password))
                    {
                        _currentUser.SwitchCurrentUser(employeeId);
                        //Console.WriteLine("LDAP驗證成功");
                        //using (LogContext.PushProperty("Category", "UserActivity"))
                        //{
                        //    _logger.Information("登入人員：{0}，登入時間：{1}", user.FullName, DateTime.Now);
                        //}
                        return;
                    }
                    else
                    {
                        //Console.WriteLine("登入驗證未過");
                        //using (LogContext.PushProperty("Category", "UserActivity"))
                        //{
                        //    _logger.Information("登入驗證未過，登入人員：{0}，登入時間：{1}", user.FullName, DateTime.Now);
                        //}
                    }
                }
            }
            else
            {
                Console.WriteLine("User輸入空白。");
            }
            _currentUser.SwitchCurrentUserToGuest();
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            //DialogResult = DialogResult.Cancel;
            //this.Close();
        }

        private void uiTextBox_Password_ButtonClick(object sender, EventArgs e)
        {
            uiTextBox_Password.Text = "";
        }
    }
}
