﻿using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 狀態列 DB 資料區顯示訊息。
    /// </summary>
    public class DbInfoMessage : ValueChangedMessage<string>
    {
        public DbInfoMessage(string info) : base(info) { }
    }
}
