﻿using System;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.MaintiFlow.Contract;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class ManitiFlowMain : UserControl
    {
        private readonly IPermissionService _permission;
        private readonly CurrentUserContext _user;
        private readonly IMaintiFlow _maintiFlow;

        public ManitiFlowMain(IPermissionService permissionService,
                              CurrentUserContext currentUserContext,
                              IMaintiFlow maintiFlow)
        {
            InitializeComponent();
            _permission = permissionService;
            _user = currentUserContext;
            _maintiFlow = maintiFlow;

            Button_CreateFlow.Text = PageCode.CreateFlow.GetDescription();
            Button_AcceptFlow.Text = PageCode.AcceptFlow.GetDescription();
            Button_MaintiWork.Text = PageCode.MaintiWork.GetDescription();
            Button_FlowConfirmed.Text = PageCode.FlowConfirmed.GetDescription();
            Button_CancelFlow.Text = PageCode.CancelFlow.GetDescription();

            UserChanged();

            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (r, m) =>
            {
                UserChanged();
            });
        }

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        private void UserChanged()
        {
            Button_CreateFlow.Enabled = _permission.HasControlAccess(
                  PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_CREATE_FLOW);
            Button_AcceptFlow.Enabled = _permission.HasControlAccess(
                PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_ACCEPT_FLOW) || _user.IsEngineer;
            Button_MaintiWork.Enabled = _permission.HasControlAccess(
                PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_MAINTANT_FLOW) || _user.IsEngineer;
            Button_FlowConfirmed.Enabled = _permission.HasControlAccess(
                PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_FLOW_CONFIRM);
            Button_CancelFlow.Enabled = _permission.HasControlAccess(
                PermissionWords.MODULE_MAINTI_FLOW, PermissionWords.PAGE_CANCEL_FLOW);
        }

        private void Button_CreateFlow_Click(object sender, EventArgs e)
        {
            _maintiFlow.CreateNewFlow();
        }

        private async void Button_CancelFlow_Click(object sender, EventArgs e)
        {
            await _maintiFlow.CancelFlow();
        }

        private async void Button_AcceptFlow_Click(object sender, EventArgs e)
        {
            await _maintiFlow.AcceptFlow();
        }

        private async void Button_MaintiWork_Click(object sender, EventArgs e)
        {
            await _maintiFlow.MaintiWork();
        }

        private async void Button_FlowConfirmed_Click(object sender, EventArgs e)
        {
            await _maintiFlow.FlowConfirmed();
        }
    }
}
