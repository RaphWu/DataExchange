﻿/*
 * 資料查詢改為非同步。
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.Metadata.Edm;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.ADGV;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Extensions;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Events;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowSummary : UserControl
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MaintiFlowData _flowData;
        private readonly ICore _core;
        private readonly IPermissionService _permission;
        private readonly MultiSelector _mSel;

        private int _thisTaskOrderId;
        private TaskOrderViewModel _tovm;
        private List<TaskOrderViewModel> _tovms = new List<TaskOrderViewModel>();
        private DataTable _dt;
        private BindingSource _bs = new BindingSource();

        public bool IsEnabled
        {
            get { return _isEnabled; }
            set { _isEnabled = value; }
        }
        private bool _isEnabled;

        public MaintiFlowSummary(CoreContext coreContext,
                                 CoreData coreData,
                                 MaintiFlowData maintiFlowData,
                                 ICore core,
                                 IPermissionService permissionService,
                                 MultiSelector multiSelector)
        {
            InitializeComponent();
            _context = coreContext;
            _coreData = coreData;
            _flowData = maintiFlowData;
            _core = core;
            _permission = permissionService;
            _mSel = multiSelector;

            _dt = new DataTable();
            _dt.Columns.Add(PropertyText.Name.WorkOrderNo, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Creator, typeof(string));
            _dt.Columns.Add(PropertyText.Name.CreationDateTime, typeof(DateTime));
            _dt.Columns.Add(PropertyText.Name.ModelStatus, typeof(string));
            _dt.Columns.Add(PropertyText.Name.MaintenanceUnit, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Engineers, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Machine, typeof(string));
            _dt.Columns.Add(PropertyText.Name.ModelName, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Workstation, typeof(string));
            _dt.Columns.Add(PropertyText.Name.RepairDuration, typeof(TimeSpan));
            _dt.Columns.Add(PropertyText.Name.OutageDuration, typeof(TimeSpan));

            SwitchEditMode(false);
            CommonStyles.SetButton(btnSave);
            EditModeSwitch.ActiveColor = CommonStyles.BackColor;
            EditModeSwitch.InActiveColor = Color.DarkRed;
            Creator.ButtonFillColor = CommonStyles.BackColor;
            Engineers.ButtonFillColor = CommonStyles.BackColor;
            MachineCode.ButtonFillColor = CommonStyles.BackColor;
            ModelWs.ButtonFillColor = CommonStyles.BackColor;
            FeedbackEmployee.ButtonFillColor = CommonStyles.BackColor;

            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (r, m) =>
            {
                UserChanged();
            });

            WeakReferenceMessenger.Default.Register<NotifyMaintiFlowDataUpdated>(this, async (r, m) =>
            {
                var result = await UpdateDataAsync();
                UpdateDataToUI(result.List, result.Table);
            });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                _tovms = null;
                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
                WeakReferenceMessenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

        private async void MaintiFlowSummary_Load(object sender, EventArgs ea)
        {
            UserChanged();
            var result = await UpdateDataAsync();
            UpdateDataToUI(result.List, result.Table);

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "資料載入中，請稍候...";
                loadingDialog.Show();

                ADGV.AutoGenerateColumns = false;
                ADGV.DataSource = _bs;

                //ADGV.Columns.Add(new DataGridViewTextBoxColumn
                //{
                //    DataPropertyName = PropertyString.Name.TaskOrderId,
                //    HeaderText = PropertyString.Title.TaskOrderId,
                //    ValueType = typeof(int),
                //    AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                //    DefaultCellStyle = new DataGridViewCellStyle()
                //    {
                //        Alignment = DataGridViewContentAlignment.MiddleCenter,
                //    },
                //});
                //ADGV.SetFilterChecklistEnabled(ADGV.Columns[PropertyString.Name.TaskOrderId], false);

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.WorkOrderNo,
                    HeaderText = PropertyText.Title.WorkOrderNo,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.CreatorName,
                    HeaderText = PropertyText.Title.Creator,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.CreationDateString,
                    HeaderText = PropertyText.Title.CreationDateTime,
                    ValueType = typeof(DateTime),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.OrderStatusString,
                    HeaderText = PropertyText.Title.Status,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.MaintenanceUnit,
                    HeaderText = PropertyText.Title.MaintenanceUnit,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.EngineerString,
                    HeaderText = PropertyText.Title.Engineer,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.MachineCode,
                    HeaderText = PropertyText.Title.Machine,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.ModelName,
                    HeaderText = PropertyText.Title.ModelName,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.WorkstationName,
                    HeaderText = PropertyText.Title.Workstation,
                    ValueType = typeof(string),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.RepairDurationString,
                    HeaderText = PropertyText.Title.RepairDuration,
                    ValueType = typeof(TimeSpan),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                ADGV.Columns.Add(new DataGridViewTextBoxColumn
                {
                    DataPropertyName = PropertyText.Name.OutageDurationString,
                    HeaderText = PropertyText.Title.OutageDuration,
                    ValueType = typeof(TimeSpan),
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                    DefaultCellStyle = new DataGridViewCellStyle()
                    {
                        Alignment = DataGridViewContentAlignment.MiddleCenter,
                    },
                });

                // TimeSpan的Format須另外設定
                ADGV.CellFormatting += (s, e) =>
                {
                    if (ADGV.Columns[e.ColumnIndex].ValueType == typeof(TimeSpan)
                        && e.Value is TimeSpan ts)
                    {
                        string days = ts.Days > 0 ? $"{ts.Days}d " : "";
                        e.Value = $"{days}{ts.Hours:D2}:{ts.Minutes:D2}";
                        e.FormattingApplied = true;
                    }
                };

                //adgvSearchToolBar.SetColumns(ADGV.Columns);
                CommonStyles.SetAdvancedDataGridView(ADGV, filterAndSort: true);
                AdvancedDataGridView.SetTranslations(AdvancedDataGridView.LoadTranslationsFromFile("adgvLang_zh-TW.json"));
                AdvancedDataGridViewSearchToolBar.SetTranslations(AdvancedDataGridViewSearchToolBar.LoadTranslationsFromFile("adgvLang_zh-TW.json"));

                // 下方
                uiLabel_OrderNo.Text = PropertyText.Title.TaskOrderId;
                OrderNo.DataBindings.Clear();
                OrderNo.DataBindings.Add("Text", _bs, PropertyText.Name.TaskOrderId, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_WorkOrderNo.Text = PropertyText.Title.WorkOrderNo;
                WorkOrderNo.DataBindings.Clear();
                WorkOrderNo.DataBindings.Add("Text", _bs, PropertyText.Name.WorkOrderNo, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_Creator.Text = PropertyText.Title.Creator;
                Creator.DataBindings.Clear();
                Creator.DataBindings.Add("Text", _bs, PropertyText.Name.CreatorName, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_CreationDate.Text = PropertyText.Title.CreationDateTime;
                CreationDateTime.DataBindings.Clear();
                CreationDateTime.DataBindings.Add("Value", _bs, PropertyText.Name.CreationDateTime, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
                AcceptedTime.DataBindings.Clear();
                AcceptedTime.DataBindings.Add("Value", _bs, PropertyText.Name.AcceptedTime, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_Status.Text = PropertyText.Title.Status;
                var statusList = Enum.GetValues(typeof(FlowStatus))
                    .Cast<FlowStatus>()
                    .OrderByDescending(s => (int)s)
                    .Select(s => new { Value = (int)s, Text = s.GetDescription() })
                    .ToList();
                Status.DisplayMember = "Text";
                Status.ValueMember = "Value";
                Status.DataSource = statusList;
                Status.DataBindings.Clear();
                Status.DataBindings.Add("SelectedValue", _bs, PropertyText.Name.OrderStatusId, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
                var lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
                lvm.AddRange(_context.MaintenanceUnits
                    .Select(m => new ListViewModel()
                    {
                        NullableId = m.Id,
                        Name = m.UnitName,
                    })
                    .ToList());
                MaintenanceUnit.DataSource = lvm;
                MaintenanceUnit.DisplayMember = "Name";
                MaintenanceUnit.ValueMember = "NullableId";
                MaintenanceUnit.DataBindings.Clear();
                MaintenanceUnit.DataBindings.Add("Text", _bs, PropertyText.Name.MaintenanceUnit, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_MaintenanceEngineer.Text = PropertyText.Title.Engineer;
                Engineers.DataBindings.Clear();
                Engineers.DataBindings.Add("Text", _bs, PropertyText.Name.EngineerString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_MachineList.Text = PropertyText.Title.Machine;
                MachineCode.DataBindings.Clear();
                MachineCode.DataBindings.Add("Text", _bs, PropertyText.Name.FullMachineName, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_ModelWs.Text = PropertyText.Title.ModelWsName;
                ModelWs.DataBindings.Clear();
                ModelWs.DataBindings.Add("Text", _bs, PropertyText.Name.ModelWsName, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_IssueCategory.Text = PropertyText.Title.IssueCategory;
                lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
                lvm.AddRange(_context.IssueCategories
                    .Select(m => new ListViewModel()
                    {
                        NullableId = m.Id,
                        Name = m.CategoryName,
                    })
                    .ToList());
                IssueCategory.DataSource = lvm;
                IssueCategory.DisplayMember = "Name";
                IssueCategory.ValueMember = "NullableId";
                IssueCategory.DataBindings.Clear();
                IssueCategory.DataBindings.Add("Text", _bs, PropertyText.Name.IssueCategoryString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_IssueDescription.Text = PropertyText.Title.IssueDescription;
                IssueDescription.DataBindings.Clear();
                IssueDescription.DataBindings.Add("Text", _bs, PropertyText.Name.IssueDescription, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_Details.Text = PropertyText.Title.Details;
                Details.DataBindings.Clear();
                Details.DataBindings.Add("Text", _bs, PropertyText.Name.Details, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
                var rUnitList = _context.Departments
                    .OrderBy(r => r.OrderNo)
                    .Select(r => new ListViewModel { Id = r.Id, Name = r.DepartmentName, })
                    .ToList();
                RequestingUnit.DataSource = rUnitList;
                RequestingUnit.DisplayMember = "Name";
                RequestingUnit.ValueMember = "Id";
                RequestingUnit.DataBindings.Clear();
                RequestingUnit.DataBindings.Add("Text", _bs, PropertyText.Name.RequestingUnitString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_FeedbackEmployee.Text = PropertyText.Title.FeedbackEmployee;
                FeedbackEmployee.DataBindings.Clear();
                FeedbackEmployee.DataBindings.Add("Text", _bs, PropertyText.Name.FeedbackEmployeeString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_RequestingUnitResponse.Text = PropertyText.Title.Feedback;
                RequestingUnitFeedback.DataBindings.Clear();
                RequestingUnitFeedback.DataBindings.Add("Text", _bs, PropertyText.Name.Feedback, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_RepairStarted.Text = PropertyText.Title.RepairStarted;
                RepairStarted.DataBindings.Clear();
                RepairStarted.DataBindings.Add("Text", _bs, PropertyText.Name.RepairStartedString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
                RepairCompleted.DataBindings.Clear();
                RepairCompleted.DataBindings.Add("Text", _bs, PropertyText.Name.RepairCompletedString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_RepairDuration.Text = PropertyText.Title.RepairDuration;
                RepairDuration.DataBindings.Clear();
                RepairDuration.DataBindings.Add("Text", _bs, PropertyText.Name.RepairDurationString, true, DataSourceUpdateMode.OnPropertyChanged);

                Label_FillingTime.Text = PropertyText.Title.FillingTime;
                FillingTime.DataBindings.Clear();
                FillingTime.DataBindings.Add("Value", _bs, PropertyText.Name.FillingTime, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_OutageStarted.Text = PropertyText.Title.OutageStarted;
                OutageStarted.DataBindings.Clear();
                OutageStarted.DataBindings.Add("Text", _bs, PropertyText.Name.OutageStartedString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_OutageEnded.Text = PropertyText.Title.OutageEnded;
                OutageEnded.DataBindings.Clear();
                OutageEnded.DataBindings.Add("Text", _bs, PropertyText.Name.OutageEndedString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_OutageDuration.Text = PropertyText.Title.OutageDuration;
                OutageDuration.DataBindings.Clear();
                OutageDuration.DataBindings.Add("Text", _bs, PropertyText.Name.OutageDurationString, true, DataSourceUpdateMode.OnPropertyChanged);

                uiLabel_Responsible.Text = PropertyText.Title.Responsible;
                Responsible.DataBindings.Clear();
                Responsible.DataBindings.Add("Text", _bs, PropertyText.Name.Responsible, true, DataSourceUpdateMode.OnPropertyChanged);

                loadingDialog.Close();
            }
        }

        //private void UpdateDataAsync()
        //{
        //    //var taskOrders = await _context.TaskOrders
        //    //    .Include(t => t.CreatorName.Department)
        //    //    .Include(t => t.CreatorName.Title)
        //    //    .Include(t => t.EngineerString)
        //    //    .Include(t => t.Machine)
        //    //    .Include(t => t.WorkstationName.ModelWorkstation)
        //    //    .Include(t => t.MaintenanceUnit)
        //    //    .Include(t => t.IssueCategoryString)
        //    //    .Include(t => t.RequestingUnitString)
        //    //    .Include(t => t.FeedbackEmployeeString)
        //    //    .OrderByDescending(u => u.Id)
        //    //    .AsNoTracking()
        //    //    .ToListAsync();

        //    _tovms = _flowData.TaskOrders.Select(u => new TaskOrderViewModel
        //    {
        //        Id = u.Id,
        //        WorkOrderNo = u.WorkOrderNo,
        //        StatusString = u.StatusString,
        //        CreatorName = u.CreatorName,
        //        CreatorNameWithDepartment = u.CreatorNameWithDepartment,
        //        CreationDateTime = u.CreationDateTime,
        //        CreationDateTimeString = u.CreationDateTimeString,
        //        CreationDateString = u.CreationDateString,
        //        MachineCode = u.MachineCode,
        //        ModelName = u.ModelName,
        //        WorkstationId = u.WorkstationId,
        //        WorkstationName = u.WorkstationName,
        //        ModelWorkstationName = u.ModelWorkstationName,

        //        MaintenanceUnit = u.MaintenanceUnitString,
        //        EngineerString = u.EngineerString,
        //        AcceptedTime = u.AcceptedTime,
        //        AcceptedTimeString = u.AcceptedTimeString,
        //        StatusId = u.StatusId,
        //        IssueCategoryString = u.IssueCategoryString,
        //        IssueDescription = u.IssueDescription,
        //        Details = u.Details,
        //        RepairStarted = u.RepairStarted,
        //        RepairStartedString = u.RepairStartedString,
        //        RepairCompleted = u.RepairCompleted,
        //        RepairCompletedString = u.RepairCompletedString,
        //        RepairDuration = u.RepairDuration,
        //        RepairDurationString = u.RepairDurationString,
        //        FillingTimeString = u.FillingTimeString,

        //        RequestingUnitString = u.RequestingUnitString,
        //        FeedbackEmployeeString = u.FeedbackEmployeeString,
        //        Feedback = u.Feedback,
        //        OutageStarted = u.OutageStarted,
        //        OutageStartedString = u.OutageStartedString,
        //        OutageEnded = u.OutageEnded,
        //        OutageEndedString = u.OutageEndedString,
        //        OutageDuration = u.OutageDuration,
        //        OutageDurationString = u.OutageDurationString,

        //        Responsible = u.Responsible,
        //    }).ToList();
        //    //_tovms = new BindingList<TaskOrderViewModel>(svm);

        //    _dt = _tovms.ToDataTable();
        //    _bs.DataSource = _dt;

        //    //ADGV.AutoGenerateColumns = false;
        //    //ADGV.DataSource = null;
        //    //ADGV.DataSource = _bs;
        //    //ADGV.VirtualMode = true;
        //    //_bs.DataSource = _tovms;
        //    //_bs.DataSource = _context.TaskOrders.Local.ToBindingList();
        //    //_bs.ResetBindings(true);
        //    //ADGV.RowCount = _svm.Count;
        //    //ADGV.CellValueNeeded += new DataGridViewCellValueEventHandler(ADGV_CellValueNeeded);

        //    _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_tovms.Count()} 筆資料"));
        //}

        private void UserChanged()
        {
            bool allowEdit = _permission.HasControlAccess(PermissionWords.MODULE_MAINTI_FLOW,
                                                          PermissionWords.PAGE_SUMMARY,
                                                          "*",
                                                          PermissionWords.ACTION_EDIT);
            IsEnabled = !allowEdit;
            btnSave.Visible = allowEdit;
            EditModeSwitch.Visible = allowEdit;

            ADGV.ContextMenuStrip = allowEdit
                ? adgvContextMenu
                : null;
        }

        private async Task<(List<TaskOrderViewModel> List, DataTable Table)> UpdateDataAsync()
        {
            var result = await Task.Run(() =>
            {
                var source = (_flowData?.TaskOrders) ?? Enumerable.Empty<TaskOrder>();
                var list = source.Select(u => new TaskOrderViewModel
                {
                    Id = u.Id,
                    WorkOrderNo = u.WorkOrderNo,
                    StatusString = u.StatusString,
                    CreatorName = u.CreatorName,
                    CreatorNameWithDepartment = u.CreatorNameWithDepartment,
                    CreationDateTime = u.CreationDateTime,
                    CreationDateString = u.CreationDateString,
                    MachineCode = u.MachineCode,
                    FullMachineName = u.FullMachineName,
                    ModelName = u.ModelName,
                    WorkstationId = u.WorkstationId,
                    WorkstationName = u.WorkstationName,
                    ModelWsName = u.ModelWsName,
                    MaintenanceUnit = u.MaintenanceUnitString,
                    EngineerString = u.EngineerString,
                    AcceptedTime = u.AcceptedTime,
                    AcceptedTimeString = u.AcceptedTimeString,
                    StatusId = u.StatusId,
                    IssueCategoryString = u.IssueCategoryString,
                    IssueDescription = u.IssueDescription,
                    Details = u.Details,
                    RepairStarted = u.RepairStarted,
                    RepairStartedString = u.RepairStartedString,
                    RepairCompleted = u.RepairCompleted,
                    RepairCompletedString = u.RepairCompletedString,
                    RepairDuration = u.RepairDuration,
                    RepairDurationString = u.RepairDurationString,
                    FillingTimeString = u.FillingTimeString,
                    RequestingUnitString = u.RequestingUnitString,
                    FeedbackEmployeeString = u.FeedbackEmployeeString,
                    Feedback = u.Feedback,
                    OutageStarted = u.OutageStarted,
                    OutageStartedString = u.OutageStartedString,
                    OutageEnded = u.OutageEnded,
                    OutageEndedString = u.OutageEndedString,
                    OutageDuration = u.OutageDuration,
                    OutageDurationString = u.OutageDurationString,
                    Responsible = u.Responsible
                }).ToList();

                DataTable table = list.ToDataTable();
                return (list, table);
            });

            return result;
        }

        private void UpdateDataToUI(List<TaskOrderViewModel> list, DataTable table)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => UpdateDataToUI(list, table)));
                return;
            }

            _tovms = list;
            _dt = table;

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "資料顯示中，請稍候...";
                loadingDialog.Show();

                _bs.DataSource = _dt;
                loadingDialog.Close();
            }
        }

        private void ADGV_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e)
        {
        }

        /********************
         * 編輯模式
         ********************/
        private void SwitchEditMode(bool editMode)
        {
            IsEnabled = editMode;

            WorkOrderNo.Enabled = IsEnabled;
            Creator.Enabled = IsEnabled;
            CreationDateTime.Enabled = IsEnabled;
            AcceptedTime.Enabled = IsEnabled;
            Status.Enabled = IsEnabled;
            MaintenanceUnit.Enabled = IsEnabled;
            Engineers.Enabled = IsEnabled;
            MachineCode.Enabled = IsEnabled;
            ModelWs.Enabled = IsEnabled;
            IssueCategory.Enabled = IsEnabled;
            IssueDescription.Enabled = IsEnabled;
            Details.Enabled = IsEnabled;
            RequestingUnit.Enabled = IsEnabled;
            FeedbackEmployee.Enabled = IsEnabled;
            RequestingUnitFeedback.Enabled = IsEnabled;
            RepairStarted.Enabled = IsEnabled;
            RepairCompleted.Enabled = IsEnabled;
            OutageStarted.Enabled = IsEnabled;
            OutageEnded.Enabled = IsEnabled;
            Responsible.Enabled = IsEnabled;
            FillingTime.Enabled = IsEnabled;

            //cbRepairStarted.Enabled = IsEnabled;
            //cbRepairCompleted.Enabled = IsEnabled;
            //cbOutageEnded.Enabled = IsEnabled;
            //cbOutageStarted.Enabled = IsEnabled;

            btnSave.Enabled = IsEnabled;
        }

        private void EditModeSwitch_ValueChanged(object sender, bool value)
        {
            SwitchEditMode(value);
        }

        /********************
         * ADGV
         ********************/
        private void ADGV_SelectionChanged(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                _thisTaskOrderId = Convert.ToInt32(drv[PropertyText.Name.TaskOrderId]);
                _tovm = _tovms.FirstOrDefault(x => x.Id == _thisTaskOrderId);

                int index = _tovms.IndexOf(_tovm);
                if (index >= 0)
                    _bs.Position = index;

                if (_tovm.RepairStarted == null)
                    RepairStarted.Text = "";
                if (_tovm.RepairCompleted == null)
                    RepairCompleted.Text = "";
                if (_tovm.OutageStarted == null)
                    OutageStarted.Text = "";
                if (_tovm.OutageEnded == null)
                    OutageEnded.Text = "";
            }
        }

        private void Button_Edit_Click(object sender, EventArgs e)
        {
        }

        private async void Button_Delete_Click(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                string selectedKey = drv[PropertyText.Name.WorkOrderNo].ToString();
                var item = _tovms.FirstOrDefault(x => x.WorkOrderNo == selectedKey);
                if (item != null)
                {
                    string msg = $"確定刪除這筆資料嗎？\n\n{PropertyText.Title.WorkOrderNo}: {item.WorkOrderNo}\n{PropertyText.Title.Creator}: {item.CreatorName}\n{PropertyText.Title.ModelName}: {item.ModelName}";
                    if (MessageBox.Show(msg, "刪除確認",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        var entity = _context.TaskOrders.FirstOrDefault(x => x.WorkOrderNo == item.WorkOrderNo);
                        if (entity != null)
                        {
                            try
                            {
                                // 重新從資料庫載入實體狀態（若已被其他來源刪除或修改，Reload 會拋例外）
                                try
                                {
                                    _context.Entry(entity).Reload();
                                }
                                catch (InvalidOperationException)
                                {
                                    // 重新查一次（可能已被刪除）
                                    entity = _context.TaskOrders.Find(entity.Id);
                                    if (entity == null)
                                    {
                                        MessageBox.Show("該筆資料已不存在（可能已被其他使用者刪除）。", "刪除中止", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        return;
                                    }
                                }

                                // 明確處理子集合（範例：清除 many-to-many 的關聯）
                                _context.Entry(entity).Collection(x => x.TaskOrderEngineers).Load();
                                if (entity.TaskOrderEngineers != null && entity.TaskOrderEngineers.Any())
                                {
                                    entity.TaskOrderEngineers.Clear(); // 移除 join table 的關聯列
                                }

                                // 如有其它子集合或依賴表，應在此處先行刪除或清除 FK

                                _context.TaskOrders.Remove(entity);
                                await _context.SaveChangesAsync();

                                _tovms.Remove(item);

                                foreach (DataRow row in _dt.Rows)
                                {
                                    if (row[PropertyText.Name.WorkOrderNo].ToString() == selectedKey)
                                    {
                                        _dt.Rows.Remove(row);
                                        break;
                                    }
                                }

                                _bs.ResetBindings(false);

                                MessageBox.Show($"{PropertyText.Title.WorkOrderNo}: {item.WorkOrderNo} 已刪除！");
                            }
                            catch (System.Data.Entity.Infrastructure.DbUpdateConcurrencyException)
                            {
                                MessageBox.Show("刪除失敗：資料已被其他使用者修改或刪除，請重新整理後再試。", "並發錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            catch (System.Data.Entity.Infrastructure.DbUpdateException due)
                            {
                                MessageBox.Show($"資料庫更新失敗：{due.InnerException?.Message ?? due.Message}", "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "資料庫變更失敗");
                            }
                        }
                    }
                }
            }
        }

        private void RepairStarted_ValueChanged(object sender, DateTime value)
        {
            if (_tovm != null)
            {
                _tovm.RepairStarted = DateTime.TryParse(RepairStarted.Text, out DateTime dt)
                    ? dt
                    : (DateTime?)null;
                UpdateRepairDuration();
            }
        }

        private void RepairCompleted_ValueChanged(object sender, DateTime value)
        {
            if (_tovm != null)
            {
                _tovm.RepairCompleted = DateTime.TryParse(RepairCompleted.Text, out DateTime dt)
                    ? dt
                    : (DateTime?)null;
                UpdateRepairDuration();
            }
        }

        private void UpdateRepairDuration()
        {
            if (_tovm.RepairStarted != null)
            {
                _tovm.RepairDuration = _tovm.RepairCompleted != null
                    ? (TimeSpan)(_tovm.RepairCompleted - _tovm.RepairStarted)
                    : (TimeSpan)(DateTime.Now - _tovm.RepairStarted);
            }
            else
            {
                _tovm.RepairDuration = TimeSpan.Zero;
            }
            RepairDuration.Text = _tovm.RepairDurationString;
        }

        private void OutageStarted_ValueChanged(object sender, DateTime value)
        {
            if (_tovm != null)
            {
                _tovm.OutageStarted = DateTime.TryParse(OutageStarted.Text, out DateTime dt)
                    ? dt
                    : (DateTime?)null;
                UpdateOutageDuration();
            }
        }

        private void OutageEnded_ValueChanged(object sender, DateTime value)
        {
            if (_tovm != null)
            {
                _tovm.OutageEnded = DateTime.TryParse(OutageEnded.Text, out DateTime dt)
                    ? dt
                    : (DateTime?)null;
                UpdateOutageDuration();
            }
        }

        private void UpdateOutageDuration()
        {
            if (_tovm.OutageStarted != null)
            {
                _tovm.OutageDuration = _tovm.OutageEnded != null
                    ? (TimeSpan)(_tovm.OutageEnded - _tovm.OutageStarted)
                    : (TimeSpan)(DateTime.Now - _tovm.OutageStarted);
            }
            else
            {
                _tovm.OutageDuration = TimeSpan.Zero;
            }
            OutageDuration.Text = _tovm.OutageDurationString;
        }

        private void Creator_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>() { (string)Creator.Text };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    var emp = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(emp.Category2) ? "" : $"{emp.Category2} » ";
                    displayText += $"{emp.IdString} {emp.Name}";

                    Creator.Text = emp.Name;
                }
                else
                {
                    Creator.Text = "";
                }
            }
        }

        private void MachineList_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.Machine}";
            _mSel.TreeViewCaption = "機台";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.MachinesSingleTabPageCache;
            _mSel.DefaultChecked = MachineCode.Text
                .Split(new char[] { '»', ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                var machine = _mSel.ResultList.FirstOrDefault();
                MachineCode.Text = machine != null
                    ? string.Join(" » ", new[] { machine.Name, machine.Category2 }.Where(s => !string.IsNullOrWhiteSpace(s)))
                    : "";
            }
        }

        private void ModelWs_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇 {PropertyText.Title.ModelName} » {PropertyText.Title.Workstation}";
            _mSel.TreeViewCaption = "機種";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>()
            {
                ModelWs.Text
                    .Split(new char[] { '»', ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim())
                    .Where(s => !string.IsNullOrWhiteSpace(s))
                    .Last()
            };
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    CategoryInfo info = _mSel.ResultList[0];
                    var ws = _core.GetWorkstation(info.Id);
                    var tovm = _tovms.FirstOrDefault(x => x.Id == _thisTaskOrderId);
                    tovm.WorkstationId = ws.Id;
                    tovm.Workstation = ws;
                    //tovm.Workstation.ModelId = ws != null && ws.ModelId != null
                    //? (int?)_core.GetModel((int)ws.ModelId).Id
                    //: null;
                    tovm.Workstation.Model = _coreData.Models.FirstOrDefault(m => m.Id == ws.ModelId);
                    ModelWs.Text = tovm.Workstation.FullWorkstationName;
                }
                else
                {
                    ModelWs.Text = "";
                }
            }
        }

        private void Engineers_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = false;
            _mSel.Title = $"請選擇{PropertyText.Title.Engineer}";
            _mSel.DialogWidth = 600;
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EmployeeMultiTabPageCache;
            _mSel.DefaultChecked = Engineers.Text
                .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                List<string> emps = new List<string>();
                foreach (var emp in _mSel.ResultList)
                    emps.Add(emp.Name);
                Engineers.Text = string.Join("; ", emps);
            }
        }

        private void FeedbackEmployee_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>() { (string)FeedbackEmployee.Text };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    var emp = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(emp.Category2) ? "" : $"{emp.Category2} » ";
                    displayText += $"{emp.IdString} {emp.Name}";

                    FeedbackEmployee.Text = emp.Name;
                }
                else
                {
                    FeedbackEmployee.Text = "";
                }
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            var to = _context.TaskOrders.FirstOrDefault(x => x.Id == _thisTaskOrderId);
            if (to != null)
            {
                to.WorkOrderNo = WorkOrderNo.Text;
                to.StatusId = (int)Status.SelectedValue;
                to.CreationDateTime = CreationDateTime.Value;
                to.AcceptedTime = AcceptedTime.Value;
                to.IssueCategoryId = (int?)IssueCategory.SelectedValue;
                to.IssueDescription = IssueDescription.Text;
                to.Details = Details.Text;

                to.RepairStartedString = RepairStarted.Text;
                to.RepairCompletedString = RepairCompleted.Text;
                to.RepairDurationString = RepairDuration.Text;
                to.OutageStartedString = OutageStarted.Text;
                to.OutageEndedString = OutageEnded.Text;
                to.OutageDurationString = OutageDuration.Text;

                to.FillingTime = FillingTime.Value;
                to.WorkstationId = to.GetWorkstationId(ModelWs.Text, _context);

                _context.Entry(to).Collection(x => x.TaskOrderEngineers).Load();
                to.TaskOrderEngineers.Clear();
                var engineerNames = Engineers.Text
                    .Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim())
                    .Where(s => !string.IsNullOrWhiteSpace(s))
                    .ToList();
                var newEngineers = _context.Employees
                    .Where(emp => emp.IsEngineer && engineerNames.Contains(emp.EmployeeName))
                    .ToList();
                foreach (var eng in newEngineers)
                    to.Engineers.Add(eng);

                string mCode = MachineCode.Text.SplitClean('»', ';', ',').First();
                var machine = _coreData.Machines.FirstOrDefault(m => m.MachineCode == mCode);
                to.MachineId = machine?.Id;

                var creator = await _context.Employees.FirstOrDefaultAsync(emp => emp.EmployeeName == Creator.Text);
                to.CreatorId = creator?.Id ?? 0;

                int selectedMunitId = MaintenanceUnit.SelectedValue is int i ? i : 0;
                var munit = await _context.MaintenanceUnits.FirstOrDefaultAsync(r => r.Id == selectedMunitId);
                to.MaintenanceUnitId = munit?.Id ?? 0;

                to.FeedbackEmployeeId = await _context.Employees
                    .Where(emp => emp.EmployeeName == FeedbackEmployee.Text)
                    .Select(emp => (int?)emp.Id)
                    .FirstOrDefaultAsync();

                to.Feedback = RequestingUnitFeedback.Text;
                to.Responsible = Responsible.Text;

                await _context.SaveChangesAsync();
                await UpdateDataAsync();
                _ = WeakReferenceMessenger.Default.Send(RequestMaintiFlowDataUpdate.Instance);
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("維護工單已儲存！"));
            }
        }

        private void adgvSearchToolBar_Search(object sender, AdvancedDataGridViewSearchToolBarSearchEventArgs e)
        {
            bool restartsearch = true;
            int startColumn = 0;
            int startRow = 0;
            if (!e.FromBegin)
            {
                bool endcol = ADGV.CurrentCell.ColumnIndex + 1 >= ADGV.ColumnCount;
                bool endrow = ADGV.CurrentCell.RowIndex + 1 >= ADGV.RowCount;

                if (endcol && endrow)
                {
                    startColumn = ADGV.CurrentCell.ColumnIndex;
                    startRow = ADGV.CurrentCell.RowIndex;
                }
                else
                {
                    startColumn = endcol ? 0 : ADGV.CurrentCell.ColumnIndex + 1;
                    startRow = ADGV.CurrentCell.RowIndex + (endcol ? 1 : 0);
                }
            }
            DataGridViewCell c = ADGV.FindCell(
                e.ValueToSearch,
                e.ColumnToSearch != null ? e.ColumnToSearch.Name : null,
                startRow,
                startColumn,
                e.WholeWord,
                e.CaseSensitive);
            if (c == null && restartsearch)
                c = ADGV.FindCell(
                e.ValueToSearch,
                e.ColumnToSearch != null ? e.ColumnToSearch.Name : null,
                0,
                0,
                e.WholeWord,
                e.CaseSensitive);
            if (c != null)
                ADGV.CurrentCell = c;
        }

        private void ADGV_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                    ADGV.ClearSelection(); // 可選：如果你希望只選這個cell
                    ADGV.CurrentCell = ADGV[e.ColumnIndex, e.RowIndex];
                    ADGV[e.ColumnIndex, e.RowIndex].Selected = true;
                }
            }
        }

        private async void delWorkOrder_Click(object sender, EventArgs e)
        {
            if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                _thisTaskOrderId = Convert.ToInt32(drv[PropertyText.Name.TaskOrderId]);
                var emp = _context.TaskOrders.FirstOrDefault(m => m.Id == _thisTaskOrderId);
                if (emp != null)
                {
                    if (UIMessageBox.ShowAsk2($"確定要刪除{PropertyText.Title.TaskOrderId} {emp.WorkOrderNo} 嗎？", true, UIMessageDialogButtons.Cancel))
                    {
                        try
                        {
                            // Reload 確認目前 DB 狀態
                            try
                            {
                                _context.Entry(emp).Reload();
                            }
                            catch (InvalidOperationException)
                            {
                                emp = _context.TaskOrders.Find(_thisTaskOrderId);
                                if (emp == null)
                                {
                                    MessageBox.Show("該筆資料已不存在（可能已被其他使用者刪除）。", "刪除中止", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }
                            }

                            // 清除 many-to-many 關聯（避免 join table FK 衝突）
                            _context.Entry(emp).Collection(x => x.TaskOrderEngineers).Load();
                            if (emp.TaskOrderEngineers != null && emp.TaskOrderEngineers.Any())
                            {
                                emp.TaskOrderEngineers.Clear();
                            }

                            // 若有其他依賴資料（如附件等），在此先行處理或刪除

                            _context.TaskOrders.Remove(emp);
                            await _context.SaveChangesAsync();
                            await _core.UpdateModelsCache();

                            _ = WeakReferenceMessenger.Default.Send(RequestMaintiFlowDataUpdate.Instance);
                            MessageBox.Show($"{PropertyText.Title.ModelName} {emp.WorkOrderNo} 已刪除",
                                            $"刪除成功",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Information);
                        }
                        catch (System.Data.Entity.Infrastructure.DbUpdateConcurrencyException)
                        {
                            MessageBox.Show("刪除失敗：資料已被其他使用者修改或刪除，請重新整理後再試。", "並發錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        catch (System.Data.Entity.Infrastructure.DbUpdateException due)
                        {
                            MessageBox.Show($"資料庫更新失敗：{due.InnerException?.Message ?? due.Message}", "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "刪除失敗");
                        }
                    }
                }
            }
        }

        //private async void delWorkOrder_Click(object sender, EventArgs e)
        //{
        //    if (ADGV.CurrentRow?.DataBoundItem is DataRowView drv)
        //    {
        //        _thisTaskOrderId = Convert.ToInt32(drv[PropertyText.Name.TaskOrderId]);
        //        var emp = _context.TaskOrders.FirstOrDefault(m => m.Id == _thisTaskOrderId);
        //        if (emp != null)
        //        {
        //            if (UIMessageBox.ShowAsk2($"確定要刪除{PropertyText.Title.TaskOrderId} {emp.WorkOrderNo} 嗎？", true, UIMessageDialogButtons.Cancel))
        //            {
        //                try
        //                {
        //                    // Reload 確認目前 DB 狀態
        //                    try
        //                    {
        //                        _context.Entry(emp).Reload();
        //                    }
        //                    catch (InvalidOperationException)
        //                    {
        //                        emp = _context.TaskOrders.Find(_thisTaskOrderId);
        //                        if (emp == null)
        //                        {
        //                            MessageBox.Show("該筆資料已不存在（可能已被其他使用者刪除）。", "刪除中止", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                            return;
        //                        }
        //                    }

        //                    // 清除 many-to-many 關聯（避免 join table FK 衝突）
        //                    _context.Entry(emp).Collection(x => x.TaskOrderEngineers).Load();
        //                    if (emp.TaskOrderEngineers != null && emp.TaskOrderEngineers.Any())
        //                    {
        //                        emp.TaskOrderEngineers.Clear();
        //                    }

        //                    // 若有其他依賴資料（如附件等），在此先行處理或刪除

        //                    _context.TaskOrders.Remove(emp);
        //                    await _context.SaveChangesAsync();
        //                    await _core.UpdateModelsCache();

        //                    _ = WeakReferenceMessenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);
        //                    MessageBox.Show($"{PropertyText.Title.ModelName} {emp.WorkOrderNo} 已刪除",
        //                                    $"刪除成功",
        //                                    MessageBoxButtons.OK,
        //                                    MessageBoxIcon.Information);
        //                }
        //                catch (System.Data.Entity.Infrastructure.DbUpdateConcurrencyException)
        //                {
        //                    MessageBox.Show("刪除失敗：資料已被其他使用者修改或刪除，請重新整理後再試。", "並發錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //                }
        //                catch (System.Data.Entity.Infrastructure.DbUpdateException due)
        //                {
        //                    MessageBox.Show($"資料庫更新失敗：{due.InnerException?.Message ~~due.Message}", "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                }
        //                catch (Exception ex)
        //                {
        //                    MessageBox.Show(ex.Message, "刪除失敗");
        //                }
        //            }
        //        }
        //    }
        //}
    }
}
