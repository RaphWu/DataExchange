﻿/*
 * 工程師開單 vs 線上人員開單分開。
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.WinForms;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Events;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MF_CreateFlow : UIForm
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly IMail _mail;
        private readonly CurrentUserContext _user;
        private readonly MultiSelector _mSel;

        private string _todayPrefix;
        private int _lastWorkOrderNo;

        #endregion fields

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 新建工單的工單號。
        /// </summary>
        public List<TaskOrder> NewWorkOrderNos { get; set; } = new List<TaskOrder>();

        public MF_CreateFlow(CoreContext CoreContext,
                          CoreData coreData,
                          IMail mail,
                          CurrentUserContext currentUserContext,
                          MultiSelector multiSelector)
        {
            InitializeComponent();
            _context = CoreContext;
            _coreData = coreData;
            _mail = mail;
            _user = currentUserContext;
            _mSel = multiSelector;

            CommonStyles.SetButton(Button_OK);
            CommonStyles.SetButton(Button_Cancel, isCancel: true);

            this.AcceptButton = Button_OK;
            this.CancelButton = Button_Cancel;
        }

        private void CreateFlow_Load(object sender, EventArgs e)
        {
            string caption;

            caption = PropertyText.Title.RequestingUnit;
            Label_RequestingUnit.Text = caption;
            RequestingUnit.Watermark = caption;
            var rUnitList = _context.Departments
                .OrderBy(r => r.OrderNo)
                .Select(r => new ListViewModel { Id = r.Id, Name = r.DepartmentName, })
                .ToList();
            RequestingUnit.DataSource = rUnitList;
            RequestingUnit.DisplayMember = "Name";
            RequestingUnit.ValueMember = "Id";

            caption = PropertyText.Title.Creator;
            Label_Creator.Text = caption;
            Creator.Watermark = caption;
            Creator.ButtonFillColor = CommonStyles.BackColor;
            Creator.ButtonFillHoverColor = CommonStyles.HoverColor;

            caption = PropertyText.Title.Machine;
            Label_MachineList.Text = caption;
            MachineList.Watermark = caption;
            MachineList.ButtonFillColor = CommonStyles.BackColor;
            MachineList.ButtonFillHoverColor = CommonStyles.HoverColor;

            caption = PropertyText.Title.OutageStarted;
            Label_OutageStarted.Text = caption;
            OutageStarted.Watermark = caption;
            OutageStarted.Value = DateTime.Now;

            caption = PropertyText.Title.IssueDescription;
            Label_IssueDescription.Text = caption;
        }

        private void CreateFlow_Shown(object sender, EventArgs e)
        {
            SunnyUiHelper.AdjustFormLayout(this, TLP);
        }

        private void uiButton_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void uiButton_OK_Click(object sender, EventArgs e)
        {
            // 拆解機台編號
            var machineList = MachineList.Text
                .Split(new char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();

            var creator = _coreData.Employees.FirstOrDefault(c => c.EmployeeName == (string)Creator.Tag);

            // 錯誤檢查
            StringBuilder err = new StringBuilder();

            if (string.IsNullOrWhiteSpace(RequestingUnit.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.RequestingUnit}！");

            if (string.IsNullOrWhiteSpace(Creator.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.Creator}！");
            else if (creator == null)
                err.AppendLine($"查無此人：{Creator.Tag}！");

            if (string.IsNullOrWhiteSpace(MachineList.Text))
            {
                err.AppendLine($"沒有輸入 {PropertyText.Title.Machine}！");
            }
            else
            {
                foreach (var mId in machineList)
                    if (_coreData.Machines.FindIndex(x => x.MachineCode == mId) == -1)
                        err.AppendLine($"{PropertyText.Title.Machine}不存在: {mId}");
            }

            if (string.IsNullOrEmpty(OutageStarted.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.OutageStarted}！");

            if (err.Length > 0)
            {
                err.Append("\n注意：資料尚未儲存！");
                MessageBox.Show(err.ToString(),
                    "輸入資料不正確",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            try
            {
                var deviceList = new List<Machine>();

                // 計算新工單號
                _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                var tos = _context.TaskOrders;
                _lastWorkOrderNo = tos
                    .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                    .Select(w => w.WorkOrderNo)
                    .AsEnumerable()
                    .Select(o => int.TryParse(o.Substring(8, 3), out int val) ? val : 0)
                    .DefaultIfEmpty(0)
                    .Max();

                // 加入資料庫
                int rUnitId = (int)RequestingUnit.SelectedValue;

                NewWorkOrderNos.Clear();
                for (int no = 1; no <= machineList.Count; no++)
                {
                    string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                    string machineId = machineList[no - 1];
                    var to = new TaskOrder()
                    {
                        WorkOrderNo = newWorkOrderNo,
                        CreationDateTime = DateTime.Today,
                        Machine = _context.Machines.FirstOrDefault(x => x.MachineCode == machineId),
                        IssueDescription = IssueDescription.Text,

                        CreatorId = creator.Id,
                        Engineers = null,
                        Status = FlowStatus.NewTaskOrder,
                        AcceptedTime = DateTime.Now,
                        OutageStarted = OutageStarted.Value,
                        RequestingUnitId = rUnitId,
                        FeedbackEmployeeId = creator.Id,

                        WorkstationId = 0,
                        MaintenanceUnitId = 0,
                        IssueCategoryId = 0,
                        Details = "",
                        Feedback = "",
                        Responsible = "",
                    };
                    _context.TaskOrders.Add(to);
                    NewWorkOrderNos.Add(to);
                }
                _context.SaveChanges();
                _ = WeakReferenceMessenger.Default.Send(RequestMaintiFlowDataUpdate.Instance);
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("資料已儲存。"));

                // send email
                StringBuilder mail = new StringBuilder();
                mail.Append("<table><caption>新建工單</caption>");

                var ruId = NewWorkOrderNos[0].RequestingUnitId;
                mail.Append("<tr>");
                mail.Append("<td>需求單位</td>");
                mail.Append($"<td>{_context.Departments.FirstOrDefault(r => r.Id == ruId).DepartmentName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>工單建立者</td>");
                mail.Append($"<td>{creator.EmployeeName}</td>");
                mail.Append("</tr>");

                List<string> oms = new List<string>();
                foreach (var wo in NewWorkOrderNos)
                    oms.Add($"{wo.WorkOrderNo}: {wo.FullMachineName}");

                mail.Append("<tr>");
                mail.Append("<td>新增工單</td>");
                mail.Append($"<td>{string.Join("<br/>", oms)}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>建立時間</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].CreationDateString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動時間</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].OutageStartedString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>問題描述</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].IssueDescription}</td>");
                mail.Append("</tr>");
                mail.Append("</table>");

                //var mailList = new HashSet<int>() { 19 };
                var mailList = new HashSet<int>() { creator.Id };
                _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                               $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][新建工單] {creator.EmployeeName} 新建 {NewWorkOrderNos.Count} 張維護工單。",
                               mail.ToString());

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Creator_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultChecked = new List<string>() { (string)Creator.Tag };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    var emp = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(emp.Category2) ? "" : $"{emp.Category2} » ";
                    displayText += $"{emp.IdString} {emp.Name}";

                    Creator.Tag = emp.Name;
                    Creator.Text = string.Join(" » ", displayText);
                }
                else
                {
                    Creator.Tag = "";
                    Creator.Text = "";
                }
            }
        }

        private void MachineId_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.Machine}";
            _mSel.TreeViewCaption = "機台";
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.MachinesMultiTabPageCache;
            _mSel.DefaultChecked = MachineList.Text
                .Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                MachineList.Text = _mSel.ResultList.Count > 0
                    ? string.Join("; ", _mSel.ResultList.Select(r => r.Name).ToArray())
                    : "";
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            Creator.Text = "";
            MachineList.Text = "";
            OutageStarted.Value = DateTime.Now;
            IssueDescription.Text = "";
        }
    }
}
