﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Extensions;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MF_MaintiWork : UIForm
    {
        #region fields

        private readonly ILifetimeScope _scope;
        private readonly ICore _core;
        private readonly IMail _mail;
        private readonly IEntityCacheManager _cacheManager;
        private readonly Serilog.ILogger _logger;
        private readonly CoreContext _context;
        private readonly CurrentUserContext _user;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        private BindingSource _bs = new BindingSource();
        private List<ListViewModel> _listSources;
        private List<TaskOrder> _orders = new List<TaskOrder>();
        private List<TaskOrderViewModel> _tovms = new List<TaskOrderViewModel>();
        private TaskOrderViewModel _tovm = new TaskOrderViewModel();

        private List<int> _engineerList = new List<int>();

        // ResultList buffers
        private ClassifyInfo _defaultWS = new ClassifyInfo();
        private List<ClassifyInfo> _defaultEngineers = new List<ClassifyInfo>();
        private List<ClassifyInfo> _defaultNotification = new List<ClassifyInfo>();

        #endregion fields

        public MF_MaintiWork(
            ILifetimeScope lifetimeScope,
            ICore core,
            IMail mail,
            IEntityCacheManager entityCacheManager,
            Serilog.ILogger logger,
            CoreContext coreContext,
            CurrentUserContext currentUserContext,
            MaintiFlowData maintiFlowData,
            CoreData coreData,
            MultiSelector multiSelector)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _core = core;
            _mail = mail;
            _cacheManager = entityCacheManager;
            _logger = logger;
            _context = coreContext;
            _user = currentUserContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _mSel = multiSelector;

            CommonStyles.SetButton(btnSave);
            CommonStyles.SetButton(btnCompleted);
            CommonStyles.SetButton(btnCancel, isCancel: true);
            CommonStyles.SetButton(btnTransfer, isAccent: true);
            CommonStyles.SetButton(ModelWorkstation);
            CommonStyles.SetButton(Engineers);
            CommonStyles.SetButton(btnQuickCreate);
            CommonStyles.SetListBox(ListBoxOrders);

            btnQuickCreate.Visible = _user.IsAdmin || _user.IsEngineer;

            WeakReferenceMessenger.Default.Register<NotifyTaskOrderDataUpdated>(this, (recipient, message) =>
            {
                LoadData();
            });
        }

        private void MF_MaintiWork_FormClosing(object sender, FormClosingEventArgs e)
        {
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        private void FT_MaintiWork_Load(object sender, System.EventArgs e)
        {
            LoadData();
        }

        private void FT_MaintiWork_Shown(object sender, EventArgs e)
        {
            //SunnyUiHelper.AdjustFormLayout(this, TLP_Content);
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void Button_Save_Click(object sender, EventArgs ea)
        {
            await SaveToDb();
        }

        private bool DataVerify()
        {
            List<string> err = new List<string>();

            if (string.IsNullOrEmpty(ModelWorkstation.Text))
                err.Add($"沒有輸入 {PropertyText.Title.ModelWsName}！");

            if (string.IsNullOrEmpty(MaintenanceUnit.Text))
                err.Add($"沒有輸入 {PropertyText.Title.MaintenanceUnit}！");

            if (string.IsNullOrEmpty(Engineers.Text))
                err.Add($"沒有輸入 {PropertyText.Title.Engineer}！");

            if (string.IsNullOrEmpty(IssueCategory.Text))
                err.Add($"沒有輸入 {PropertyText.Title.MaintiFlowIssueCategory}！");

            if (string.IsNullOrEmpty(RepairStarted.Text))
                err.Add($"沒有輸入 {PropertyText.Title.RepairStarted}！");

            if (string.IsNullOrEmpty(RepairCompleted.Text))
                err.Add($"沒有輸入 {PropertyText.Title.RepairCompleted}！");

            if (RepairCompleted.Value < RepairStarted.Value)
                err.Add($"{PropertyText.Title.RepairCompleted} 必須大於等於 {PropertyText.Title.RepairStarted}！");

            //if (string.IsNullOrEmpty(OutageStarted.Text))
            //    err.Add($"沒有輸入 {PropertyText.Title.OutageStarted}！");

            //if (string.IsNullOrEmpty(OutageEnded.Text))
            //    err.Add($"沒有輸入 {PropertyText.Title.OutageEnded}！");

            //if (RepairCompleted.Value < OutageEnded.Value)
            //    err.Add($"{PropertyText.Title.OutageEnded} 必須大於等於 {PropertyText.Title.RepairCompleted}！");

            //if (OutageStarted.Value > OutageEnded.Value)
            //    err.Add($"{PropertyText.Title.OutageEnded} 必須大於等於 {PropertyText.Title.OutageStarted}！");

            if (err.Count > 0)
            {
                err.Add("\n注意：資料尚未儲存！");
                MessageBox.Show(string.Join(Environment.NewLine, err),
                    "輸入資料不正確",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            else
            {
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("資料已儲存。"));
                return true;
            }
        }

        /********************
         * 
         ********************/
        public void Initialize()
        {
            LoadData();

            if (!_orders.Any())
            {
                using (var qc = _scope.Resolve<MF_QuickCreate>())
                {
                    qc.ShowDialog();
                }
                return;
            }

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "資料載入中，請稍候...";
                loadingDialog.Show();

                //var tos2 = _orders
                //    .Select(o => new ListViewModel()
                //    {
                //        IdString = o.WorkOrderNo,
                //        Name = o.WorkOrderNo + " » " + o.MachineCode,
                //    })
                //    .ToList();
                //_listSources = new BindingList<ListViewModel>(tos2);

                var lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
                lvm.AddRange(_context.MaintenanceUnits
                    .Select(m => new ListViewModel()
                    {
                        NullableId = m.Id,
                        Name = m.UnitName,
                    })
                    .ToList());
                MaintenanceUnit.DataSource = lvm;
                MaintenanceUnit.DisplayMember = "Name";
                MaintenanceUnit.ValueMember = "NullableId";

                lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
                lvm.AddRange(_context.IssueCategories
                    .Select(m => new ListViewModel()
                    {
                        NullableId = m.Id,
                        Name = m.CategoryName,
                    })
                    .ToList());
                IssueCategory.DataSource = lvm;
                IssueCategory.DisplayMember = "Name";
                IssueCategory.ValueMember = "NullableId";


                int tabIndex = 0;
                Label_WorkOrderNo.Text = PropertyText.Title.WorkOrderNo;
                WorkOrderNo.DataBindings.Clear();
                //WorkOrderNo.DataBindings.Add("Text", _bs, PropertyText.Name.WorkOrderNo, true, DataSourceUpdateMode.OnPropertyChanged);
                WorkOrderNo.TabIndex = ++tabIndex;
                WorkOrderNo.ReadOnly = true;

                Label_MachineList.Text = PropertyText.Title.Machine;
                MachineList.DataBindings.Clear();
                //MachineList.DataBindings.Add("Text", _bs, PropertyText.Name.FullMachineName, true, DataSourceUpdateMode.OnPropertyChanged);
                MachineList.TabIndex = ++tabIndex;
                MachineList.ReadOnly = true;

                Label_ModelWorkstation.Text = PropertyText.Title.ModelWsName;
                ModelWorkstation.DataBindings.Clear();
                //ModelWorkstation.DataBindings.Add("Text", _bs, PropertyText.Name.ModelWsName, true, DataSourceUpdateMode.OnPropertyChanged);
                ModelWorkstation.TabIndex = ++tabIndex;

                Label_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
                MaintenanceUnit.DataBindings.Clear();
                //MaintenanceUnit.DataBindings.Add("Text", _bs, PropertyText.Name.MaintenanceUnitString, true, DataSourceUpdateMode.OnPropertyChanged);
                MaintenanceUnit.TabIndex = ++tabIndex;

                Label_Engineers.Text = PropertyText.Title.Engineer;
                Engineers.DataBindings.Clear();
                //Engineers.DataBindings.Add("Text", _bs, PropertyText.Name.EngineerString, true, DataSourceUpdateMode.OnPropertyChanged);
                Engineers.TabIndex = ++tabIndex;

                Label_IssueCategory.Text = PropertyText.Title.MaintiFlowIssueCategory;
                IssueCategory.DataBindings.Clear();
                //IssueCategory.DataBindings.Add("Text", _bs, PropertyText.Name.IssueCategoryString, true, DataSourceUpdateMode.OnPropertyChanged);
                IssueCategory.TabIndex = ++tabIndex;

                Label_RepairStarted.Text = PropertyText.Title.RepairStarted;
                RepairStarted.DataBindings.Clear();
                //RepairStarted.DataBindings.Add("Text", _bs, PropertyText.Name.RepairStartedString, true, DataSourceUpdateMode.OnPropertyChanged);
                RepairStarted.TabIndex = ++tabIndex;

                Label_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
                RepairCompleted.DataBindings.Clear();
                //RepairCompleted.DataBindings.Add("Text", _bs, PropertyText.Name.RepairCompletedString, true, DataSourceUpdateMode.OnPropertyChanged);
                RepairCompleted.TabIndex = ++tabIndex;

                Label_RepairDuration.Text = PropertyText.Title.RepairDuration;
                RepairDuration.DataBindings.Clear();
                //RepairDuration.DataBindings.Add("Text", _bs, PropertyText.Name.RepairDurationString, true, DataSourceUpdateMode.OnPropertyChanged);
                RepairDuration.TabIndex = ++tabIndex;
                RepairDuration.ReadOnly = true;

                Label_OutageStarted.Text = PropertyText.Title.OutageStarted;
                OutageStarted.DataBindings.Clear();
                //OutageStarted.DataBindings.Add("Text", _bs, PropertyText.Name.OutageStartedString, true, DataSourceUpdateMode.OnPropertyChanged);
                OutageStarted.TabIndex = ++tabIndex;

                Label_OutageEnded.Text = PropertyText.Title.OutageEnded;
                OutageEnded.DataBindings.Clear();
                //OutageEnded.DataBindings.Add("Text", _bs, PropertyText.Name.OutageEndedString, true, DataSourceUpdateMode.OnPropertyChanged);
                OutageEnded.TabIndex = ++tabIndex;

                Label_OutageDuration.Text = PropertyText.Title.OutageDuration;
                OutageDuration.DataBindings.Clear();
                //OutageDuration.DataBindings.Add("Text", _bs, PropertyText.Name.OutageDurationString, true, DataSourceUpdateMode.OnPropertyChanged);
                OutageDuration.TabIndex = ++tabIndex;
                OutageDuration.ReadOnly = true;

                Label_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
                RequestingUnit.DataBindings.Clear();
                //RequestingUnit.DataBindings.Add("Text", _bs, PropertyText.Name.RequestingUnitString, true, DataSourceUpdateMode.OnPropertyChanged);
                RequestingUnit.TabIndex = ++tabIndex;
                RequestingUnit.ReadOnly = true;

                Label_Creator.Text = PropertyText.Title.Creator;
                Creator.DataBindings.Clear();
                //Creator.DataBindings.Add("Text", _bs, PropertyText.Name.CreatorName, true, DataSourceUpdateMode.OnPropertyChanged);
                Creator.TabIndex = ++tabIndex;
                Creator.ReadOnly = true;

                Label_CreationDate.Text = PropertyText.Title.CreationDateTime;
                CreationDate.DataBindings.Clear();
                //CreationDate.DataBindings.Add("Text", _bs, PropertyText.Name.CreationDateTime, true, DataSourceUpdateMode.OnPropertyChanged);
                CreationDate.TabIndex = ++tabIndex;
                CreationDate.ReadOnly = true;

                Label_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
                AcceptedTime.DataBindings.Clear();
                //AcceptedTime.DataBindings.Add("Text", _bs, PropertyText.Name.AcceptedTimeString, true, DataSourceUpdateMode.OnPropertyChanged);
                AcceptedTime.TabIndex = ++tabIndex;
                AcceptedTime.ReadOnly = true;

                Label_IssueDescription.Text = PropertyText.Title.MaintiFlowIssueDescription;
                IssueDescription.DataBindings.Clear();
                //IssueDescription.DataBindings.Add("Text", _bs, PropertyText.Name.IssueDescription, true, DataSourceUpdateMode.OnPropertyChanged);
                IssueDescription.TabIndex = ++tabIndex;

                Label_Details.Text = PropertyText.Title.Details;
                Details.DataBindings.Clear();
                //Details.DataBindings.Add("Text", _bs, PropertyText.Name.Details, true, DataSourceUpdateMode.OnPropertyChanged);
                Details.TabIndex = ++tabIndex;

                loadingDialog.Close();
            }
        }

        private void LoadData()
        {
            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.Text = "資料載入中，請稍候...";
                loadingDialog.Show();

                _orders = _flowData.TaskOrders
                    .Where(t => t.Status == FlowStatus.InProgress && (
                        _user.IsAdmin
                        || (t.Creator != null && t.Creator.Id == _user.UserId)
                        || (t.Engineers != null && t.Engineers.Any(eg => eg.Id == _user.UserId))
                    ))
                   .ToList();
                _tovms = _orders
                    .Select(t => new TaskOrderViewModel()
                    {
                        Id = t.Id,
                        WorkOrderNo = t.WorkOrderNo,
                        Status = t.Status,
                        MachineCode = t.MachineCode,
                        FullMachineName = t.FullMachineName,
                        WorkstationId = t.WorkstationId,
                        Workstation = t.Workstation,
                        ModelWsName = t.ModelWsName,
                        CreatorName = t.CreatorName,
                        CreationDateTimeString = t.CreationDateTimeString,
                        MaintenanceUnitId = t.MaintenanceUnitId,
                        MaintenanceUnitString = t.MaintenanceUnitString,
                        Engineers = t.Engineers,
                        EngineerString = t.EngineerString,
                        AcceptedTime = t.AcceptedTime,
                        AcceptedTimeString = t.AcceptedTimeString,
                        IssueCategoryId = t.IssueCategoryId,
                        IssueCategoryString = t.IssueCategoryString,
                        IssueDescription = t.IssueDescription,
                        Details = t.Details,
                        RequestingUnitString = t.RequestingUnitString,
                        RepairStarted = t.RepairStarted,
                        RepairCompleted = t.RepairCompleted,
                        OutageStarted = t.OutageStarted,
                        OutageEnded = t.OutageEnded,
                        RepairDuration = t.RepairDuration,
                        OutageDuration = t.OutageDuration,
                        RepairStartedString = t.RepairStartedString,
                        RepairCompletedString = t.RepairCompletedString,
                        OutageStartedString = t.OutageStartedString,
                        OutageEndedString = t.OutageEndedString,
                        RepairDurationString = t.RepairDurationString,
                        OutageDurationString = t.OutageDurationString,
                        FeedbackEmployeeId = t.FeedbackEmployeeId,
                        Feedback = t.Feedback,
                    }).ToList();

                _listSources = _orders
                    .Select(t => new ListViewModel()
                    {
                        Id = t.Id,
                        Name = t.WorkOrderNo + " » " + t.MachineCode,
                    })
                    .ToList();

                ListBoxOrders.DataSource = new BindingList<ListViewModel>(_listSources);
                ListBoxOrders.DisplayMember = "Name";
                ListBoxOrders.ValueMember = "Id";
                _bs.DataSource = new BindingList<TaskOrderViewModel>(_tovms);
                _bs.ResetBindings(false);

                loadingDialog.Close();
            }
        }

        private async Task SaveToDb()
        {
            if (_tovm == null) return;

            try
            {
                var to = _context.TaskOrders.FirstOrDefault(t => t.Id == _tovm.Id);
                if (to != null)
                {
                    //to.WorkOrderNo = WorkOrderNo.Text;
                    to.CreationDateString = CreationDate.Text;
                    to.AcceptedTimeString = AcceptedTime.Text;
                    to.IssueCategoryId = (int?)IssueCategory.SelectedValue;
                    to.IssueDescription = IssueDescription.Text;
                    to.Details = Details.Text;

                    to.RepairStartedString = RepairStarted.Text;
                    to.RepairCompletedString = RepairCompleted.Text;
                    to.RepairDurationString = RepairDuration.Text;
                    to.OutageStartedString = OutageStarted.Text;
                    to.OutageEndedString = OutageEnded.Text;
                    to.OutageDurationString = OutageDuration.Text;

                    to.FillingTime = null;
                    to.WorkstationId = to.GetWorkstationId(ModelWorkstation.Text, _context);

                    _context.Entry(to).Collection(x => x.TaskOrderEngineers).Load();
                    to.TaskOrderEngineers.Clear();
                    var engineerNames = Engineers.Text.SplitClean(',', ';', '\n');
                    var newEngineers = _context.Employees
                        .Where(emp => emp.IsEngineer && engineerNames.Contains(emp.EmployeeName))
                        .ToList();
                    foreach (var eng in newEngineers)
                        to.Engineers.Add(eng);

                    string mCode = MachineList.Text.SplitClean('»', ';', ',').First();
                    var machine = _coreData.Machines.FirstOrDefault(m => m.MachineCode == mCode);
                    to.MachineId = machine?.Id;

                    var creator = await _context.Employees.FirstOrDefaultAsync(emp => emp.EmployeeName == Creator.Text);
                    to.CreatorId = creator?.Id ?? 0;

                    int selectedMunitId = MaintenanceUnit.SelectedValue is int i ? i : 0;
                    var munit = await _context.MaintenanceUnits.FirstOrDefaultAsync(r => r.Id == selectedMunitId);
                    to.MaintenanceUnitId = munit?.Id ?? 0;

                    await _context.SaveChangesAsync();
                    _cacheManager.RequestTaskOrderUpdate();
                    MessageBox.Show("維護工單已儲存！");
                    _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("維護工單已儲存！"));
                }
                else
                {
                    throw new ArgumentNullException(_tovm.WorkOrderNo);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                _logger.Error(ex, "儲存維護工單發生錯誤，WorkOrderNo={WorkOrderNo}", _tovm.WorkOrderNo);
            }
        }

        private void ListBoxOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBoxOrders.SelectedValue is int selId)
            {
                _tovm = _tovms.FirstOrDefault(o => o.Id == selId);
                ApplyVmToUi();

                //int bsIdx = _tovms.FindIndex(o => o.Id == selId);
                //_bs.Position = bsIdx;
                //_tovm = bsIdx >= 0 ? _tovms[bsIdx] : null;
            }
        }

        private void ApplyVmToUi()
        {
            if (_tovm != null)
            {
                WorkOrderNo.Text = _tovm.WorkOrderNo;
                MachineList.Text = _tovm.FullMachineName;
                ModelWorkstation.Text = _tovm.ModelWsName;
                MaintenanceUnit.Text = _tovm.MaintenanceUnitString;
                Engineers.Text = _tovm.EngineerString;
                IssueCategory.Text = _tovm.IssueCategoryString;
                RepairStarted.Text = _tovm.RepairStartedString;
                RepairCompleted.Text = _tovm.RepairCompletedString;
                RepairDuration.Text = _tovm.RepairDurationString;
                OutageStarted.Text = _tovm.OutageStartedString;
                OutageEnded.Text = _tovm.OutageEndedString;
                OutageDuration.Text = _tovm.OutageDurationString;
                RequestingUnit.Text = _tovm.RequestingUnitString;
                Creator.Text = _tovm.CreatorName;
                CreationDate.Text = _tovm.CreationDateTimeString;
                AcceptedTime.Text = _tovm.AcceptedTimeString;
                IssueDescription.Text = _tovm.IssueDescription;
                Details.Text = _tovm.Details;
            }
            else
            {
                WorkOrderNo.Text = "";
                MachineList.Text = "";
                ModelWorkstation.Text = "";
                MaintenanceUnit.Text = "";
                Engineers.Text = "";
                IssueCategory.Text = "";
                RepairStarted.Text = "";
                RepairCompleted.Text = "";
                RepairDuration.Text = "";
                OutageStarted.Text = "";
                OutageEnded.Text = "";
                OutageDuration.Text = "";
                RequestingUnit.Text = "";
                Creator.Text = "";
                CreationDate.Text = "";
                AcceptedTime.Text = "";
                IssueDescription.Text = "";
                Details.Text = "";
            }
        }

        /********************
         * 按鍵行為
         ********************/
        private void ModelWorkstation_ButtonClick(object sender, EventArgs e)
        {
            using (var mSel = _scope.Resolve<MultiSelector>())
            {
                mSel.HideTabHeaders = false;
                mSel.ShowTreeView = true;
                mSel.Title = $"請選擇{PropertyText.Title.ModelName}";
                mSel.TreeViewCaption = "機種";
                mSel.MultiSelection = false;
                mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;
                mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultWS };
                mSel.Initialize();

                if (mSel.ShowDialog() == DialogResult.OK)
                {
                    if (mSel.ResultList.Count > 0)
                    {
                        _defaultWS = mSel.ResultList[0];
                        int idx = ListBoxOrders.SelectedIndex;
                        var ws = _core.GetWorkstation(_defaultWS.Id);
                        _tovms[idx].WorkstationId = ws.Id;
                        _tovms[idx].Workstation = ws;
                        _tovms[idx].Workstation.ModelId = ws != null && ws.ModelId != null
                            ? (int?)_core.GetModel((int)ws.ModelId).Id
                            : null;
                        ModelWorkstation.Text = string.Join(" » ", new string[2] { _defaultWS.Category1, _defaultWS.Name });
                    }
                    else
                    {
                        ModelWorkstation.Text = "";
                    }
                }
            }
        }

        private void MaintenanceUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_tovm == null)
                return;

            if (MaintenanceUnit.SelectedItem is ListViewModel select)
                _tovm.MaintenanceUnitId = select.Id;

            //if (_tovm.RepairStarted == null)
            //    RepairStarted.Text = "";
            //if (_tovm.RepairCompleted == null)
            //    RepairCompleted.Text = "";
            //if (_tovm.OutageStarted == null)
            //    OutageStarted.Text = "";
            //if (_tovm.OutageEnded == null)
            //    OutageEnded.Text = "";
        }

        private void Engineers_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = false;
            _mSel.Title = $"請選擇{PropertyText.Title.Engineer}";
            _mSel.DialogWidth = 600;
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EngineerMultiTabPageCache;
            _mSel.DefaultSelect = _defaultEngineers;
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                _defaultEngineers = _mSel.ResultList;
                List<string> emps = new List<string>();
                foreach (var emp in _defaultEngineers)
                    emps.Add(emp.Name);
                Engineers.Text = string.Join("; ", emps);
            }
        }

        //private void Engineers_NodesSelected(object sender, TreeNodeCollection nodes)
        //{
        //    if (_tovm == null)
        //        return;

        //    _engineerList.Clear();
        //    for (int i = 0; i < nodes.Count; i++)
        //    {
        //        var node = nodes[i];
        //        if (node.Checked)
        //            _engineerList.Add(((ClassifyInfo)node.Tag).Id);
        //    }
        //}

        //private bool _isRepairStartedTyping = false; // 是否使用鍵盤輸入

        //private void RepairStarted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isRepairStartedTyping = true;
        //}

        //private void RepairStarted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isRepairStartedTyping = false;
        //    ValidateAndUpdateRepairStarted();
        //}

        //private void RepairStarted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isRepairStartedTyping) return;
        //    ValidateAndUpdateRepairStarted();
        //}
        //private void ValidateAndUpdateRepairStarted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.RepairStarted = DateTime.TryParse(RepairStarted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateRepairDuration();
        //}

        //private bool _isRepairCompletedTyping = false; // 是否使用鍵盤輸入

        //private void RepairCompleted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isRepairCompletedTyping = true;
        //}

        //private void RepairCompleted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isRepairCompletedTyping = false;
        //    ValidateAndUpdateRepairCompleted();
        //}

        //private void RepairCompleted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isRepairCompletedTyping) return;
        //    ValidateAndUpdateRepairCompleted();
        //}
        //private void ValidateAndUpdateRepairCompleted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.RepairCompleted = DateTime.TryParse(RepairCompleted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateRepairDuration();
        //}

        //private void UpdateRepairDuration()
        //{
        //    if (_tovm.RepairStarted != null)
        //    {
        //        _tovm.RepairDuration = _tovm.RepairCompleted != null
        //            ? (TimeSpan)(_tovm.RepairCompleted - _tovm.RepairStarted)
        //            : (TimeSpan)(DateTime.Now - _tovm.RepairStarted);
        //    }
        //    else
        //    {
        //        _tovm.RepairDuration = TimeSpan.Zero;
        //    }
        //    string days = _tovm.RepairDuration.Days > 0 ? $"{_tovm.RepairDuration.Days}天 " : "";
        //    RepairDuration.Text = $"{days}{_tovm.RepairDuration.Hours:D2}:{_tovm.RepairDuration.Minutes:D2}";
        //}

        //private bool _isOutageStartedTyping = false; // 是否使用鍵盤輸入

        //private void OutageStarted_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isOutageStartedTyping = true;
        //}

        //private void OutageStarted_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isOutageStartedTyping = false;
        //    ValidateAndUpdateOutageStarted();
        //}

        //private void OutageStarted_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isOutageStartedTyping) return;
        //    ValidateAndUpdateOutageStarted();
        //}
        //private void ValidateAndUpdateOutageStarted()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.OutageStarted = DateTime.TryParse(OutageStarted.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateOutageDuration();
        //}

        //private bool _isOutageEndedTyping = false; // 是否使用鍵盤輸入

        //private void OutageEnded_KeyDown(object sender, KeyEventArgs e)
        //{
        //    _isOutageEndedTyping = true;
        //}

        //private void OutageEnded_KeyUp(object sender, KeyEventArgs e)
        //{
        //    _isOutageEndedTyping = false;
        //    ValidateAndUpdateOutageEnded();
        //}

        //private void OutageEnded_ValueChanged(object sender, DateTime value)
        //{
        //    if (_isOutageEndedTyping) return;
        //    ValidateAndUpdateOutageEnded();
        //}

        //private void ValidateAndUpdateOutageEnded()
        //{
        //    if (_tovm != null)
        //    {
        //        _tovm.OutageEnded = DateTime.TryParse(OutageEnded.Text, out DateTime dt)
        //            ? dt
        //            : (DateTime?)null;
        //    }
        //    UpdateOutageDuration();
        //}

        //private void UpdateOutageDuration()
        //{
        //    if (_tovm.OutageStarted != null)
        //    {
        //        _tovm.OutageDuration = _tovm.OutageEnded != null
        //            ? (TimeSpan)(_tovm.OutageEnded - _tovm.OutageStarted)
        //            : (TimeSpan)(DateTime.Now - _tovm.OutageStarted);
        //    }
        //    else
        //    {
        //        _tovm.OutageDuration = TimeSpan.Zero;
        //    }
        //    string days = _tovm.OutageDuration.Days > 0 ? $"{_tovm.OutageDuration.Days}天 " : "";
        //    OutageDuration.Text = $"{days}{_tovm.OutageDuration.Hours:D2}:{_tovm.OutageDuration.Minutes:D2}";
        //}

        private async void button_Completed_Click(object sender, EventArgs ea)
        {
            if (!DataVerify())
                return;

            await SaveToDb();
            if (MessageBox.Show($"確定維護完成？\n工單編號：{_tovm.WorkOrderNo}",
                                "請確定執行",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Question) == DialogResult.OK)
            {
                var to = _context.TaskOrders.FirstOrDefault(t => t.WorkOrderNo == _tovm.WorkOrderNo);
                if (to != null)
                {
                    to.Status = FlowStatus.Pending;
                    to.FillingTime = DateTime.Now;
                    //SaveToCurrentRec(_tovm, to);
                    await _context.SaveChangesAsync();
                    _listSources.RemoveAt(ListBoxOrders.SelectedIndex);
                    _cacheManager.RequestTaskOrderUpdate();

                    // send email
                    StringBuilder mail = new StringBuilder();
                    mail.Append("<table><caption>維護完成</caption>");

                    mail.Append("<tr>");
                    mail.Append("<td>工單</td>");
                    mail.Append($"<td>{to.WorkOrderNo}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append($"<td>{PropertyText.Title.Performer}</td>");
                    mail.Append($"<td>{_user.UserName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護工程師</td>");
                    mail.Append($"<td>{string.Join("<br/>", to.Engineers.Select(emp => emp.EmployeeId + ", " + emp.EmployeeName))}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>機台</td>");
                    mail.Append($"<td>{to.FullMachineName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>機種 » 工站</td>");
                    mail.Append($"<td>{to.ModelWsName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護開始時間</td>");
                    mail.Append($"<td>{to.RepairStartedString}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護完成時間</td>");
                    mail.Append($"<td>{to.RepairCompletedString} ({to.RepairDurationString})</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>停動開始時間</td>");
                    mail.Append($"<td>{to.OutageStartedString}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>停動結束時間</td>");
                    mail.Append($"<td>{to.OutageEndedString} ({to.OutageDurationString})</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>問題描述</td>");
                    mail.Append($"<td>{to.IssueDescription}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護內容</td>");
                    mail.Append($"<td>{to.Details}</td>");
                    mail.Append("</tr>");
                    mail.Append("</table>");

                    mail.AppendLine(@"<p>請生產單位確認，點擊 <a href='\\172.16.254.45\共用區\量產移行用\生技--\TaskPulse\TaskPulse.exe'>此處</a> 開啟維護工單程式。</p>");

                    var mailList = new HashSet<int>() { _user.UserId };
                    var creator = _coreData.Employees.FirstOrDefault(emp => emp.Id == to.CreatorId);
                    if (creator != null)
                        mailList.Add(creator.Id);

                    foreach (var notiEmp in Notification.Text.SplitClean(';', ','))
                    {
                        var emp = _coreData.Employees.FirstOrDefault(em => em.EmployeeName == notiEmp);
                        if (emp != null)
                            mailList.Add(emp.Id);
                    }

                    _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                                   $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][維護完成] {to.WorkOrderNo}: {to.FullMachineName}",
                                   mail.ToString());

                    MessageBox.Show($"維護工單 {to.WorkOrderNo} 已轉換至 {PageCode.FlowConfirmed.GetDescription()}！");

                    // 無記錄則關閉視窗
                    if (_listSources.Count == 0)
                        this.Close();
                    ListBoxOrders_SelectedIndexChanged(ListBoxOrders, EventArgs.Empty);
                }
            }
        }

        private async void btnTransfer_Click(object sender, EventArgs e)
        {
            //SaveToCurrentBuff();
            if (MessageBox.Show($"確定轉移？工單將回至未接單狀態。\n工單編號：{_tovm.WorkOrderNo}",
                               "轉移工單確認",
                               MessageBoxButtons.OKCancel,
                               MessageBoxIcon.Question) == DialogResult.OK)
            {
                var to = await _context.TaskOrders
                    .Include(t => t.Creator)
                    .Include(t => t.TaskOrderEngineers.Select(te => te.Engineer))
                    .Include(t => t.Machine)
                    .Include(t => t.Workstation)
                    .Include(t => t.RequestingUnit)
                    .Include(t => t.MaintenanceUnit)
                    .FirstOrDefaultAsync(t => t.WorkOrderNo == _tovm.WorkOrderNo);
                to.Status = FlowStatus.NewTaskOrder;
                await _context.SaveChangesAsync();
                _cacheManager.RequestTaskOrderUpdate();

                //Initialize();
                //LoadData();
                _listSources.RemoveAt(ListBoxOrders.SelectedIndex);

                // send email
                StringBuilder mail = new StringBuilder();
                mail.Append("<table><caption>轉移工單</caption>");

                mail.Append("<tr>");
                mail.Append($"<td>{PropertyText.Title.Performer}</td>");
                mail.Append($"<td>{_user.UserName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>維護工程師</td>");
                mail.Append($"<td>{string.Join("<br/>", to.Engineers.Select(emp => emp.EmployeeId + ", " + emp.EmployeeName))}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>工單</td>");
                mail.Append($"<td>{to.WorkOrderNo}: {to.FullMachineName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動開始時間</td>");
                mail.Append($"<td>{to.OutageStartedString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>問題描述</td>");
                mail.Append($"<td>{to.IssueDescription}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>維護內容</td>");
                mail.Append($"<td>{to.Details}</td>");
                mail.Append("</tr>");
                mail.Append("</table>");

                var mailList = new HashSet<int>() { _user.UserId };
                var creator = _coreData.Employees.FirstOrDefault(emp => emp.Id == to.CreatorId);
                if (creator != null)
                    mailList.Add(creator.Id);
                _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                               $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][轉移工單] {to.WorkOrderNo}: {to.FullMachineName}",
                               mail.ToString());

                MessageBox.Show($"維護工單 {to.WorkOrderNo} 已轉換至 {FlowStatus.NewTaskOrder.GetDescription()} 狀態！");

                // 無記錄則關閉視窗
                if (_listSources.Count == 0)
                    this.Close();
                ListBoxOrders_SelectedIndexChanged(ListBoxOrders, EventArgs.Empty);
            }
        }

        private void btnQuickCreate_Click(object sender, EventArgs e)
        {
            using (var qc = _scope.Resolve<MF_QuickCreate>())
            {
                qc.ShowDialog();
            }
        }

        private void Notification_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EmployeeMultiTabPageCache;
            _mSel.DefaultSelect = _defaultNotification;
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                _defaultNotification = _mSel.ResultList;
                if (_defaultNotification.Count > 0)
                {
                    List<string> emps = new List<string>();
                    foreach (var emp in _defaultNotification)
                        emps.Add(emp.Name);
                    Notification.Text = string.Join("; ", emps);
                }
                else
                {
                    Notification.Text = "";
                }
            }
        }

        private void Notification_Validated(object sender, EventArgs e)
        {
            UpdateMSelBufferNotification();
        }

        private void UpdateMSelBufferModelWs()
        {
            var wk = _core.GetWorkstation(_tovm.ModelWsName);
            if (wk != null)
                _defaultWS = new ClassifyInfo()
                {
                    Id = wk.Id,
                    Category1 = wk.ModelName,
                    //Category2 = ,
                    Name = wk.WorkstationName,
                };
            else
                _defaultWS = new ClassifyInfo();
        }

        private void UpdateMSelBufferEngineer()
        {
            _defaultEngineers = new List<ClassifyInfo>();
            if (_tovm.Engineers.Count > 0)
                foreach (var eng in _tovm.Engineers)
                {
                    _defaultEngineers.Add(new ClassifyInfo()
                    {
                        Id = eng.Id,
                        Category1 = eng.DepartmentName,
                        Category2 = eng.JobTitleName,
                        Name = eng.EmployeeName,
                    });
                }
        }

        private void UpdateMSelBufferNotification()
        {
            _defaultNotification = new List<ClassifyInfo>();
            foreach (var notiEmp in Notification.Text.SplitClean(';', ','))
            {
                var emp = _coreData.Employees.FirstOrDefault(em => em.EmployeeName == notiEmp);
                _defaultNotification.Add(new ClassifyInfo()
                {
                    Id = emp.Id,
                    Category1 = emp.DepartmentName,
                    Category2 = emp.JobTitleName,
                    Name = emp.EmployeeName,
                });
            }
        }

        private void ModelWorkstation_Validated(object sender, EventArgs e)
        {
            UpdateMSelBufferModelWs();
        }

        private void Engineers_Validated(object sender, EventArgs e)
        {
            UpdateMSelBufferEngineer();
        }
    }
}
