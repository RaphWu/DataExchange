﻿using System;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Entity;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MaintiFlowPage : UserControl
    {
        #region fields

        private readonly IRegionManager _region;
        private readonly INavigationService _navigation;
        private ILifetimeScope _rootScope;
        private ILifetimeScope _currentScope;
        private readonly IPermissionService _permission;
        private readonly ICore _core;

        private UserControl _currentPage;
        private PageCode _currentPageCode = PageCode.None;

        #endregion fields

        public MaintiFlowPage(IRegionManager regionManager,
                              INavigationService navigationService,
                              ILifetimeScope lifetimeScope,
                              ICore core,
                              IPermissionService permissionService)
        {
            InitializeComponent();
            _region = regionManager;
            _navigation = navigationService;
            _rootScope = lifetimeScope;
            _core = core;
            _permission = permissionService;

            _region.RegisterRegion(nameof(MaintiFlowRegion), MaintiFlowRegion);

            CreateMenu();
            SwitchPage(PageCode.MaintiFlow);

            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (sender, e) =>
            {
                CreateMenu();
            });

#if DEBUG
            //csv.Load();
#endif
        }

        /********************
         * Form
         ********************/
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                if (!DesignMode)
                    _currentScope?.Dispose();
            }
            base.Dispose(disposing);
        }

        /********************
         * Menu
         ********************/

        private void CreateMenu()
        {
            TreeNode node1;
            int pageIndex;
            string pageCaption;

            NavMenu.Nodes.Clear();

            pageIndex = (int)PageCode.MaintiFlow;
            pageCaption = PublicConsts.MENU;
            node1 = NavMenu.CreateNode(pageCaption, 98, 24, pageIndex);
            node1.Tag = pageIndex;

            if (_permission.HasControlAccess(PermissionWords.MODULE_MAINTI_FLOW, "*", PermissionWords.PAGE_SUMMARY) ||
                _permission.HasControlAccess(PermissionWords.MODULE_MAINTI_FLOW, "Summary", PermissionWords.PAGE_SUMMARY))
            {
                pageIndex = (int)PageCode.MaintiFlowSummary;
                pageCaption = PageCode.MaintiFlowSummary.GetDescription();
                node1 = NavMenu.CreateNode(pageCaption, 557582, 24, pageIndex);
                node1.Tag = pageIndex;
            }

            //pageIndex = (int)PageCode.FlowTracking;
            //pageCaption = PageCode.FlowTracking.GetDescription();
            //node1 = NavMenu.CreateNode(pageCaption, 361734, 24, pageIndex);
            //node1.Tag = pageIndex;

            //uiTabControl_Content.AddPage(_manitiFlowMain);
            //uiTabControl_Content.AddPage(_manitiFlowSummary);
            ////uiTabControl_Content.AddPage(_flowTracking);
            //uiTabControl_Content.SelectedIndex = 0;

            //pageIndex = (int)PageCode.EditFlow;
            //pageCaption = PageCode.EditFlow.GetDescription();
            //node1 = NavMenu.CreateNode(pageCaption, 108, 24, pageIndex);
            //node1.Tag = pageIndex;
            //uiButton_EditFlow.Text = pageCaption;
            //uiButton_EditFlow.Symbol = 108;

            //pageIndex = (int)PageCode.DeleteFlow;
            //pageCaption = PageCode.DeleteFlow.GetDescription();
            //node1 = NavMenu.CreateNode(pageCaption, 559691, 24, pageIndex);
            //node1.Tag = pageIndex;
            //uiButton_DeleteFlow.Text = pageCaption;
            //uiButton_DeleteFlow.Symbol = 559691;

            //pageIndex = (int)PageCode.CreateFlow;
            //pageCaption = PageCode.CreateFlow.GetDescription();
        }

        /********************
         * Page
         ********************/
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentPageCode == pageCode)
                return;

            switch (pageCode)
            {
                case PageCode.MaintiFlow:
                    _navigation.Navigate<ManitiFlowMain>(nameof(MaintiFlowRegion));
                    break;

                case PageCode.MaintiFlowSummary:
                    _navigation.Navigate<MaintiFlowSummary>(nameof(MaintiFlowRegion));
                    break;

                //case PageCode.FlowTracking:
                //    uiTabControl_Content.SelectedIndex = 2;
                //    break;
                default:
                    return;
            }
            _currentPageCode = pageCode;
        }

        private void NavMenu_MenuItemClick(TreeNode node, NavMenuItem item, int pageIndex)
        {
            SwitchPage((PageCode)Enum.Parse(typeof(PageCode), pageIndex.ToString()));
        }

        private void Panel_Header_Click(object sender, EventArgs e)
        {

        }
    }
}
