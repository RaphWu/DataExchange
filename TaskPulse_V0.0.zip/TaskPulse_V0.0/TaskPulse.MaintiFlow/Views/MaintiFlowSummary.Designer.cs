﻿using Calin.TaskPulse.Core.ADGV;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class MaintiFlowSummary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RequestingUnitFeedback = new Sunny.UI.UIRichTextBox();
            this.IssueDescription = new Sunny.UI.UIRichTextBox();
            this.Details = new Sunny.UI.UIRichTextBox();
            this.Label_FillingTime = new Sunny.UI.UILabel();
            this.uiLabel_Responsible = new Sunny.UI.UILabel();
            this.Responsible = new Sunny.UI.UITextBox();
            this.uiLabel_RequestingUnitResponse = new Sunny.UI.UILabel();
            this.uiLabel_OutageDuration = new Sunny.UI.UILabel();
            this.uiLabel_RepairDuration = new Sunny.UI.UILabel();
            this.uiLabel_FeedbackEmployee = new Sunny.UI.UILabel();
            this.uiLabel_OutageEnded = new Sunny.UI.UILabel();
            this.uiLabel_RequestingUnit = new Sunny.UI.UILabel();
            this.uiLabel_RepairCompleted = new Sunny.UI.UILabel();
            this.uiLabel_RepairStarted = new Sunny.UI.UILabel();
            this.uiLabel_IssueDescription = new Sunny.UI.UILabel();
            this.uiLabel_AcceptedTime = new Sunny.UI.UILabel();
            this.uiLabel_IssueCategory = new Sunny.UI.UILabel();
            this.uiLabel_MaintenanceEngineer = new Sunny.UI.UILabel();
            this.uiLabel_MaintenanceUnit = new Sunny.UI.UILabel();
            this.uiLabel_Status = new Sunny.UI.UILabel();
            this.uiLabel_OutageStarted = new Sunny.UI.UILabel();
            this.uiLabel_ModelWs = new Sunny.UI.UILabel();
            this.uiLabel_MachineList = new Sunny.UI.UILabel();
            this.uiLabel_CreationDate = new Sunny.UI.UILabel();
            this.uiLabel_Creator = new Sunny.UI.UILabel();
            this.uiLabel_WorkOrderNo = new Sunny.UI.UILabel();
            this.WorkOrderNo = new Sunny.UI.UITextBox();
            this.uiLabel_OrderNo = new Sunny.UI.UILabel();
            this.OrderNo = new Sunny.UI.UITextBox();
            this.uiLabel_Details = new Sunny.UI.UILabel();
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.panelDetail = new System.Windows.Forms.Panel();
            this.btnRefresh = new Sunny.UI.UISymbolButton();
            this.btnSave = new Sunny.UI.UISymbolButton();
            this.FeedbackEmployee = new Sunny.UI.UITextBox();
            this.RequestingUnit = new Sunny.UI.UIComboBox();
            this.Status = new Sunny.UI.UIComboBox();
            this.OutageDuration = new Sunny.UI.UITextBox();
            this.RepairDuration = new Sunny.UI.UITextBox();
            this.Engineers = new Sunny.UI.UITextBox();
            this.MaintenanceUnit = new Sunny.UI.UIComboBox();
            this.IssueCategory = new Sunny.UI.UIComboBox();
            this.ModelWs = new Sunny.UI.UITextBox();
            this.MachineCode = new Sunny.UI.UITextBox();
            this.Creator = new Sunny.UI.UITextBox();
            this.EditModeSwitch = new Sunny.UI.UISwitch();
            this.adgvContextMenu = new Sunny.UI.UIContextMenuStrip();
            this.delWorkOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.adgvSearchToolBar = new Calin.TaskPulse.Core.ADGV.AdvancedDataGridViewSearchToolBar();
            this.AcceptedTime = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.CreationDateTime = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.FillingTime = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.RepairCompleted = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.RepairStarted = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.OutageEnded = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.OutageStarted = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.ADGV = new Calin.TaskPulse.Core.ADGV.AdvancedDataGridView();
            this.TLP.SuspendLayout();
            this.panelDetail.SuspendLayout();
            this.adgvContextMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ADGV)).BeginInit();
            this.SuspendLayout();
            // 
            // RequestingUnitFeedback
            // 
            this.RequestingUnitFeedback.Enabled = false;
            this.RequestingUnitFeedback.FillColor = System.Drawing.Color.White;
            this.RequestingUnitFeedback.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnitFeedback.ForeDisableColor = System.Drawing.Color.Black;
            this.RequestingUnitFeedback.Location = new System.Drawing.Point(825, 88);
            this.RequestingUnitFeedback.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnitFeedback.MinimumSize = new System.Drawing.Size(1, 1);
            this.RequestingUnitFeedback.Name = "RequestingUnitFeedback";
            this.RequestingUnitFeedback.Padding = new System.Windows.Forms.Padding(2);
            this.RequestingUnitFeedback.ShowText = false;
            this.RequestingUnitFeedback.Size = new System.Drawing.Size(255, 85);
            this.RequestingUnitFeedback.TabIndex = 37;
            this.RequestingUnitFeedback.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // IssueDescription
            // 
            this.IssueDescription.Enabled = false;
            this.IssueDescription.FillColor = System.Drawing.Color.White;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.ForeDisableColor = System.Drawing.Color.Black;
            this.IssueDescription.Location = new System.Drawing.Point(825, 222);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(2);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(255, 85);
            this.IssueDescription.TabIndex = 36;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Details
            // 
            this.Details.Enabled = false;
            this.Details.FillColor = System.Drawing.Color.White;
            this.Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Details.ForeDisableColor = System.Drawing.Color.Black;
            this.Details.Location = new System.Drawing.Point(825, 317);
            this.Details.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Details.MinimumSize = new System.Drawing.Size(1, 1);
            this.Details.Name = "Details";
            this.Details.Padding = new System.Windows.Forms.Padding(2);
            this.Details.ShowText = false;
            this.Details.Size = new System.Drawing.Size(255, 85);
            this.Details.TabIndex = 35;
            this.Details.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label_FillingTime
            // 
            this.Label_FillingTime.BackColor = System.Drawing.Color.Transparent;
            this.Label_FillingTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_FillingTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_FillingTime.Location = new System.Drawing.Point(371, 361);
            this.Label_FillingTime.Name = "Label_FillingTime";
            this.Label_FillingTime.Size = new System.Drawing.Size(100, 29);
            this.Label_FillingTime.TabIndex = 34;
            this.Label_FillingTime.Text = "填寫時間";
            this.Label_FillingTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_Responsible
            // 
            this.uiLabel_Responsible.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Responsible.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Responsible.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Responsible.Location = new System.Drawing.Point(27, 361);
            this.uiLabel_Responsible.Name = "uiLabel_Responsible";
            this.uiLabel_Responsible.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_Responsible.TabIndex = 12;
            this.uiLabel_Responsible.Text = "責任歸屬";
            this.uiLabel_Responsible.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Responsible
            // 
            this.Responsible.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Responsible.Enabled = false;
            this.Responsible.FillReadOnlyColor = System.Drawing.Color.White;
            this.Responsible.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Responsible.ForeDisableColor = System.Drawing.Color.Black;
            this.Responsible.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Responsible.Location = new System.Drawing.Point(134, 361);
            this.Responsible.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Responsible.MinimumSize = new System.Drawing.Size(1, 16);
            this.Responsible.Name = "Responsible";
            this.Responsible.Padding = new System.Windows.Forms.Padding(5);
            this.Responsible.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Responsible.ShowText = false;
            this.Responsible.Size = new System.Drawing.Size(220, 29);
            this.Responsible.TabIndex = 11;
            this.Responsible.TabStop = false;
            this.Responsible.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Responsible.Watermark = "";
            // 
            // uiLabel_RequestingUnitResponse
            // 
            this.uiLabel_RequestingUnitResponse.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RequestingUnitResponse.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingUnitResponse.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingUnitResponse.Location = new System.Drawing.Point(718, 88);
            this.uiLabel_RequestingUnitResponse.Name = "uiLabel_RequestingUnitResponse";
            this.uiLabel_RequestingUnitResponse.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_RequestingUnitResponse.TabIndex = 33;
            this.uiLabel_RequestingUnitResponse.Text = "需求單位回覆";
            this.uiLabel_RequestingUnitResponse.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_OutageDuration
            // 
            this.uiLabel_OutageDuration.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageDuration.Location = new System.Drawing.Point(371, 283);
            this.uiLabel_OutageDuration.Name = "uiLabel_OutageDuration";
            this.uiLabel_OutageDuration.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_OutageDuration.TabIndex = 32;
            this.uiLabel_OutageDuration.Text = "停動工時";
            this.uiLabel_OutageDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RepairDuration
            // 
            this.uiLabel_RepairDuration.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairDuration.Location = new System.Drawing.Point(371, 166);
            this.uiLabel_RepairDuration.Name = "uiLabel_RepairDuration";
            this.uiLabel_RepairDuration.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_RepairDuration.TabIndex = 28;
            this.uiLabel_RepairDuration.Text = "維護工時";
            this.uiLabel_RepairDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_FeedbackEmployee
            // 
            this.uiLabel_FeedbackEmployee.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_FeedbackEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_FeedbackEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_FeedbackEmployee.Location = new System.Drawing.Point(718, 49);
            this.uiLabel_FeedbackEmployee.Name = "uiLabel_FeedbackEmployee";
            this.uiLabel_FeedbackEmployee.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_FeedbackEmployee.TabIndex = 24;
            this.uiLabel_FeedbackEmployee.Text = "需求單位人員";
            this.uiLabel_FeedbackEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_OutageEnded
            // 
            this.uiLabel_OutageEnded.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageEnded.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageEnded.Location = new System.Drawing.Point(371, 244);
            this.uiLabel_OutageEnded.Name = "uiLabel_OutageEnded";
            this.uiLabel_OutageEnded.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_OutageEnded.TabIndex = 30;
            this.uiLabel_OutageEnded.Text = "停動結束時間";
            this.uiLabel_OutageEnded.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RequestingUnit
            // 
            this.uiLabel_RequestingUnit.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RequestingUnit.Location = new System.Drawing.Point(718, 10);
            this.uiLabel_RequestingUnit.Name = "uiLabel_RequestingUnit";
            this.uiLabel_RequestingUnit.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_RequestingUnit.TabIndex = 22;
            this.uiLabel_RequestingUnit.Text = "需求單位名稱";
            this.uiLabel_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RepairCompleted
            // 
            this.uiLabel_RepairCompleted.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairCompleted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairCompleted.Location = new System.Drawing.Point(371, 127);
            this.uiLabel_RepairCompleted.Name = "uiLabel_RepairCompleted";
            this.uiLabel_RepairCompleted.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_RepairCompleted.TabIndex = 26;
            this.uiLabel_RepairCompleted.Text = "維護完成時間";
            this.uiLabel_RepairCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_RepairStarted
            // 
            this.uiLabel_RepairStarted.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_RepairStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_RepairStarted.Location = new System.Drawing.Point(371, 88);
            this.uiLabel_RepairStarted.Name = "uiLabel_RepairStarted";
            this.uiLabel_RepairStarted.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_RepairStarted.TabIndex = 24;
            this.uiLabel_RepairStarted.Text = "維護開始時間";
            this.uiLabel_RepairStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_IssueDescription
            // 
            this.uiLabel_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueDescription.Location = new System.Drawing.Point(718, 222);
            this.uiLabel_IssueDescription.Name = "uiLabel_IssueDescription";
            this.uiLabel_IssueDescription.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_IssueDescription.TabIndex = 29;
            this.uiLabel_IssueDescription.Text = "問題描述";
            this.uiLabel_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_AcceptedTime
            // 
            this.uiLabel_AcceptedTime.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_AcceptedTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_AcceptedTime.Location = new System.Drawing.Point(27, 166);
            this.uiLabel_AcceptedTime.Name = "uiLabel_AcceptedTime";
            this.uiLabel_AcceptedTime.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_AcceptedTime.TabIndex = 16;
            this.uiLabel_AcceptedTime.Text = "接單時間";
            this.uiLabel_AcceptedTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_IssueCategory
            // 
            this.uiLabel_IssueCategory.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_IssueCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_IssueCategory.Location = new System.Drawing.Point(718, 183);
            this.uiLabel_IssueCategory.Name = "uiLabel_IssueCategory";
            this.uiLabel_IssueCategory.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_IssueCategory.TabIndex = 22;
            this.uiLabel_IssueCategory.Text = "維護類型";
            this.uiLabel_IssueCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_MaintenanceEngineer
            // 
            this.uiLabel_MaintenanceEngineer.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MaintenanceEngineer.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MaintenanceEngineer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MaintenanceEngineer.Location = new System.Drawing.Point(371, 49);
            this.uiLabel_MaintenanceEngineer.Name = "uiLabel_MaintenanceEngineer";
            this.uiLabel_MaintenanceEngineer.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_MaintenanceEngineer.TabIndex = 20;
            this.uiLabel_MaintenanceEngineer.Text = "維護工程師";
            this.uiLabel_MaintenanceEngineer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_MaintenanceUnit
            // 
            this.uiLabel_MaintenanceUnit.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MaintenanceUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MaintenanceUnit.Location = new System.Drawing.Point(371, 10);
            this.uiLabel_MaintenanceUnit.Name = "uiLabel_MaintenanceUnit";
            this.uiLabel_MaintenanceUnit.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_MaintenanceUnit.TabIndex = 18;
            this.uiLabel_MaintenanceUnit.Text = "維護單位";
            this.uiLabel_MaintenanceUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_Status
            // 
            this.uiLabel_Status.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Status.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Status.Location = new System.Drawing.Point(27, 205);
            this.uiLabel_Status.Name = "uiLabel_Status";
            this.uiLabel_Status.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_Status.TabIndex = 16;
            this.uiLabel_Status.Text = "狀態";
            this.uiLabel_Status.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_OutageStarted
            // 
            this.uiLabel_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OutageStarted.Location = new System.Drawing.Point(371, 205);
            this.uiLabel_OutageStarted.Name = "uiLabel_OutageStarted";
            this.uiLabel_OutageStarted.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_OutageStarted.TabIndex = 22;
            this.uiLabel_OutageStarted.Text = "停動開始時間";
            this.uiLabel_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_ModelWs
            // 
            this.uiLabel_ModelWs.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_ModelWs.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_ModelWs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_ModelWs.Location = new System.Drawing.Point(27, 283);
            this.uiLabel_ModelWs.Name = "uiLabel_ModelWs";
            this.uiLabel_ModelWs.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_ModelWs.TabIndex = 18;
            this.uiLabel_ModelWs.Text = "機種";
            this.uiLabel_ModelWs.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_MachineList
            // 
            this.uiLabel_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_MachineList.Location = new System.Drawing.Point(27, 244);
            this.uiLabel_MachineList.Name = "uiLabel_MachineList";
            this.uiLabel_MachineList.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_MachineList.TabIndex = 16;
            this.uiLabel_MachineList.Text = "機台編號";
            this.uiLabel_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_CreationDate
            // 
            this.uiLabel_CreationDate.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_CreationDate.Location = new System.Drawing.Point(27, 127);
            this.uiLabel_CreationDate.Name = "uiLabel_CreationDate";
            this.uiLabel_CreationDate.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_CreationDate.TabIndex = 14;
            this.uiLabel_CreationDate.Text = "建檔日期";
            this.uiLabel_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_Creator
            // 
            this.uiLabel_Creator.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Creator.Location = new System.Drawing.Point(27, 88);
            this.uiLabel_Creator.Name = "uiLabel_Creator";
            this.uiLabel_Creator.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_Creator.TabIndex = 13;
            this.uiLabel_Creator.Text = "建檔人員";
            this.uiLabel_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // uiLabel_WorkOrderNo
            // 
            this.uiLabel_WorkOrderNo.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_WorkOrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_WorkOrderNo.Location = new System.Drawing.Point(27, 49);
            this.uiLabel_WorkOrderNo.Name = "uiLabel_WorkOrderNo";
            this.uiLabel_WorkOrderNo.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_WorkOrderNo.TabIndex = 10;
            this.uiLabel_WorkOrderNo.Text = "維護工單編號";
            this.uiLabel_WorkOrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // WorkOrderNo
            // 
            this.WorkOrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.WorkOrderNo.Enabled = false;
            this.WorkOrderNo.FillReadOnlyColor = System.Drawing.Color.White;
            this.WorkOrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.WorkOrderNo.ForeDisableColor = System.Drawing.Color.Black;
            this.WorkOrderNo.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.WorkOrderNo.Location = new System.Drawing.Point(134, 49);
            this.WorkOrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.WorkOrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.WorkOrderNo.Name = "WorkOrderNo";
            this.WorkOrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.WorkOrderNo.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.WorkOrderNo.ShowText = false;
            this.WorkOrderNo.Size = new System.Drawing.Size(220, 29);
            this.WorkOrderNo.TabIndex = 9;
            this.WorkOrderNo.TabStop = false;
            this.WorkOrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.WorkOrderNo.Watermark = "";
            // 
            // uiLabel_OrderNo
            // 
            this.uiLabel_OrderNo.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_OrderNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_OrderNo.Location = new System.Drawing.Point(27, 10);
            this.uiLabel_OrderNo.Margin = new System.Windows.Forms.Padding(0);
            this.uiLabel_OrderNo.Name = "uiLabel_OrderNo";
            this.uiLabel_OrderNo.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_OrderNo.TabIndex = 8;
            this.uiLabel_OrderNo.Text = "序號";
            this.uiLabel_OrderNo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OrderNo
            // 
            this.OrderNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OrderNo.Enabled = false;
            this.OrderNo.FillReadOnlyColor = System.Drawing.Color.White;
            this.OrderNo.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OrderNo.ForeDisableColor = System.Drawing.Color.Black;
            this.OrderNo.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.OrderNo.Location = new System.Drawing.Point(134, 10);
            this.OrderNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OrderNo.MinimumSize = new System.Drawing.Size(1, 16);
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.Padding = new System.Windows.Forms.Padding(5);
            this.OrderNo.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.OrderNo.ShowText = false;
            this.OrderNo.Size = new System.Drawing.Size(220, 29);
            this.OrderNo.TabIndex = 7;
            this.OrderNo.TabStop = false;
            this.OrderNo.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OrderNo.Watermark = "";
            // 
            // uiLabel_Details
            // 
            this.uiLabel_Details.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel_Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel_Details.Location = new System.Drawing.Point(718, 317);
            this.uiLabel_Details.Name = "uiLabel_Details";
            this.uiLabel_Details.Size = new System.Drawing.Size(100, 29);
            this.uiLabel_Details.TabIndex = 31;
            this.uiLabel_Details.Text = "維護內容";
            this.uiLabel_Details.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 1;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.adgvSearchToolBar, 0, 1);
            this.TLP.Controls.Add(this.panelDetail, 0, 2);
            this.TLP.Controls.Add(this.ADGV, 0, 0);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 3;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 420F));
            this.TLP.Size = new System.Drawing.Size(1255, 566);
            this.TLP.TabIndex = 2;
            // 
            // panelDetail
            // 
            this.panelDetail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.panelDetail.Controls.Add(this.AcceptedTime);
            this.panelDetail.Controls.Add(this.CreationDateTime);
            this.panelDetail.Controls.Add(this.FillingTime);
            this.panelDetail.Controls.Add(this.RepairCompleted);
            this.panelDetail.Controls.Add(this.RepairStarted);
            this.panelDetail.Controls.Add(this.OutageEnded);
            this.panelDetail.Controls.Add(this.OutageStarted);
            this.panelDetail.Controls.Add(this.btnRefresh);
            this.panelDetail.Controls.Add(this.btnSave);
            this.panelDetail.Controls.Add(this.FeedbackEmployee);
            this.panelDetail.Controls.Add(this.RequestingUnit);
            this.panelDetail.Controls.Add(this.Status);
            this.panelDetail.Controls.Add(this.OutageDuration);
            this.panelDetail.Controls.Add(this.RepairDuration);
            this.panelDetail.Controls.Add(this.Engineers);
            this.panelDetail.Controls.Add(this.MaintenanceUnit);
            this.panelDetail.Controls.Add(this.IssueCategory);
            this.panelDetail.Controls.Add(this.ModelWs);
            this.panelDetail.Controls.Add(this.MachineCode);
            this.panelDetail.Controls.Add(this.Creator);
            this.panelDetail.Controls.Add(this.EditModeSwitch);
            this.panelDetail.Controls.Add(this.RequestingUnitFeedback);
            this.panelDetail.Controls.Add(this.OrderNo);
            this.panelDetail.Controls.Add(this.IssueDescription);
            this.panelDetail.Controls.Add(this.uiLabel_Details);
            this.panelDetail.Controls.Add(this.Details);
            this.panelDetail.Controls.Add(this.uiLabel_OrderNo);
            this.panelDetail.Controls.Add(this.WorkOrderNo);
            this.panelDetail.Controls.Add(this.Label_FillingTime);
            this.panelDetail.Controls.Add(this.uiLabel_WorkOrderNo);
            this.panelDetail.Controls.Add(this.uiLabel_Responsible);
            this.panelDetail.Controls.Add(this.uiLabel_Creator);
            this.panelDetail.Controls.Add(this.Responsible);
            this.panelDetail.Controls.Add(this.uiLabel_CreationDate);
            this.panelDetail.Controls.Add(this.uiLabel_RequestingUnitResponse);
            this.panelDetail.Controls.Add(this.uiLabel_MachineList);
            this.panelDetail.Controls.Add(this.uiLabel_OutageDuration);
            this.panelDetail.Controls.Add(this.uiLabel_ModelWs);
            this.panelDetail.Controls.Add(this.uiLabel_RepairDuration);
            this.panelDetail.Controls.Add(this.uiLabel_FeedbackEmployee);
            this.panelDetail.Controls.Add(this.uiLabel_OutageEnded);
            this.panelDetail.Controls.Add(this.uiLabel_OutageStarted);
            this.panelDetail.Controls.Add(this.uiLabel_RequestingUnit);
            this.panelDetail.Controls.Add(this.uiLabel_Status);
            this.panelDetail.Controls.Add(this.uiLabel_RepairCompleted);
            this.panelDetail.Controls.Add(this.uiLabel_MaintenanceUnit);
            this.panelDetail.Controls.Add(this.uiLabel_RepairStarted);
            this.panelDetail.Controls.Add(this.uiLabel_MaintenanceEngineer);
            this.panelDetail.Controls.Add(this.uiLabel_IssueDescription);
            this.panelDetail.Controls.Add(this.uiLabel_IssueCategory);
            this.panelDetail.Controls.Add(this.uiLabel_AcceptedTime);
            this.panelDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDetail.Location = new System.Drawing.Point(3, 149);
            this.panelDetail.Name = "panelDetail";
            this.panelDetail.Size = new System.Drawing.Size(1249, 414);
            this.panelDetail.TabIndex = 3;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefresh.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnRefresh.Location = new System.Drawing.Point(1110, 10);
            this.btnRefresh.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Radius = 10;
            this.btnRefresh.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnRefresh.Size = new System.Drawing.Size(110, 35);
            this.btnRefresh.Symbol = 57386;
            this.btnRefresh.TabIndex = 104;
            this.btnRefresh.Text = "重新整理";
            this.btnRefresh.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnSave
            // 
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnSave.Location = new System.Drawing.Point(1110, 317);
            this.btnSave.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Radius = 10;
            this.btnSave.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnSave.Size = new System.Drawing.Size(110, 35);
            this.btnSave.Symbol = 61639;
            this.btnSave.TabIndex = 100;
            this.btnSave.Text = "儲存";
            this.btnSave.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // FeedbackEmployee
            // 
            this.FeedbackEmployee.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.FeedbackEmployee.Enabled = false;
            this.FeedbackEmployee.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.FeedbackEmployee.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.FeedbackEmployee.ForeDisableColor = System.Drawing.Color.Black;
            this.FeedbackEmployee.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.FeedbackEmployee.Location = new System.Drawing.Point(825, 49);
            this.FeedbackEmployee.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.FeedbackEmployee.MinimumSize = new System.Drawing.Size(1, 16);
            this.FeedbackEmployee.Name = "FeedbackEmployee";
            this.FeedbackEmployee.Padding = new System.Windows.Forms.Padding(5);
            this.FeedbackEmployee.ShowButton = true;
            this.FeedbackEmployee.ShowText = false;
            this.FeedbackEmployee.Size = new System.Drawing.Size(255, 29);
            this.FeedbackEmployee.TabIndex = 55;
            this.FeedbackEmployee.TabStop = false;
            this.FeedbackEmployee.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.FeedbackEmployee.Watermark = "";
            this.FeedbackEmployee.ButtonClick += new System.EventHandler(this.FeedbackEmployee_ButtonClick);
            // 
            // RequestingUnit
            // 
            this.RequestingUnit.DataSource = null;
            this.RequestingUnit.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.RequestingUnit.Enabled = false;
            this.RequestingUnit.FillColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingUnit.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RequestingUnit.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.RequestingUnit.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.RequestingUnit.Location = new System.Drawing.Point(825, 10);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.RequestingUnit.Name = "RequestingUnit";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.RequestingUnit.Size = new System.Drawing.Size(200, 29);
            this.RequestingUnit.SymbolSize = 24;
            this.RequestingUnit.TabIndex = 89;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // Status
            // 
            this.Status.DataSource = null;
            this.Status.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.Status.Enabled = false;
            this.Status.FillColor = System.Drawing.Color.White;
            this.Status.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Status.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Status.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Status.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.Status.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.Status.Location = new System.Drawing.Point(134, 204);
            this.Status.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Status.MinimumSize = new System.Drawing.Size(63, 0);
            this.Status.Name = "Status";
            this.Status.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.Status.Size = new System.Drawing.Size(220, 29);
            this.Status.SymbolSize = 24;
            this.Status.TabIndex = 88;
            this.Status.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Status.Watermark = "";
            // 
            // OutageDuration
            // 
            this.OutageDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageDuration.Enabled = false;
            this.OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageDuration.ForeDisableColor = System.Drawing.Color.Black;
            this.OutageDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageDuration.Location = new System.Drawing.Point(478, 283);
            this.OutageDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageDuration.Name = "OutageDuration";
            this.OutageDuration.Padding = new System.Windows.Forms.Padding(5);
            this.OutageDuration.ReadOnly = true;
            this.OutageDuration.ShowText = false;
            this.OutageDuration.Size = new System.Drawing.Size(220, 29);
            this.OutageDuration.TabIndex = 91;
            this.OutageDuration.TabStop = false;
            this.OutageDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageDuration.Watermark = "";
            // 
            // RepairDuration
            // 
            this.RepairDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairDuration.Enabled = false;
            this.RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairDuration.ForeDisableColor = System.Drawing.Color.Black;
            this.RepairDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairDuration.Location = new System.Drawing.Point(478, 166);
            this.RepairDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairDuration.Name = "RepairDuration";
            this.RepairDuration.Padding = new System.Windows.Forms.Padding(5);
            this.RepairDuration.ReadOnly = true;
            this.RepairDuration.ShowText = false;
            this.RepairDuration.Size = new System.Drawing.Size(220, 29);
            this.RepairDuration.TabIndex = 90;
            this.RepairDuration.TabStop = false;
            this.RepairDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairDuration.Watermark = "";
            // 
            // Engineers
            // 
            this.Engineers.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Engineers.Enabled = false;
            this.Engineers.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Engineers.ForeDisableColor = System.Drawing.Color.Black;
            this.Engineers.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Engineers.Location = new System.Drawing.Point(478, 49);
            this.Engineers.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Engineers.MinimumSize = new System.Drawing.Size(1, 16);
            this.Engineers.Name = "Engineers";
            this.Engineers.Padding = new System.Windows.Forms.Padding(5);
            this.Engineers.ShowButton = true;
            this.Engineers.ShowText = false;
            this.Engineers.Size = new System.Drawing.Size(220, 29);
            this.Engineers.TabIndex = 89;
            this.Engineers.TabStop = false;
            this.Engineers.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Engineers.Watermark = "";
            this.Engineers.ButtonClick += new System.EventHandler(this.Engineers_ButtonClick);
            // 
            // MaintenanceUnit
            // 
            this.MaintenanceUnit.DataSource = null;
            this.MaintenanceUnit.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.MaintenanceUnit.Enabled = false;
            this.MaintenanceUnit.FillColor = System.Drawing.Color.White;
            this.MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaintenanceUnit.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.MaintenanceUnit.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.Location = new System.Drawing.Point(478, 10);
            this.MaintenanceUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaintenanceUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.MaintenanceUnit.Name = "MaintenanceUnit";
            this.MaintenanceUnit.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.MaintenanceUnit.Size = new System.Drawing.Size(220, 29);
            this.MaintenanceUnit.SymbolSize = 24;
            this.MaintenanceUnit.TabIndex = 87;
            this.MaintenanceUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceUnit.Watermark = "";
            // 
            // IssueCategory
            // 
            this.IssueCategory.DataSource = null;
            this.IssueCategory.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.IssueCategory.Enabled = false;
            this.IssueCategory.FillColor = System.Drawing.Color.White;
            this.IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.IssueCategory.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.IssueCategory.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.IssueCategory.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.IssueCategory.Location = new System.Drawing.Point(825, 183);
            this.IssueCategory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueCategory.MinimumSize = new System.Drawing.Size(63, 0);
            this.IssueCategory.Name = "IssueCategory";
            this.IssueCategory.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.IssueCategory.Size = new System.Drawing.Size(200, 29);
            this.IssueCategory.SymbolSize = 24;
            this.IssueCategory.TabIndex = 88;
            this.IssueCategory.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.IssueCategory.Watermark = "";
            // 
            // ModelWs
            // 
            this.ModelWs.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ModelWs.Enabled = false;
            this.ModelWs.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.ModelWs.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelWs.ForeDisableColor = System.Drawing.Color.Black;
            this.ModelWs.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.ModelWs.Location = new System.Drawing.Point(134, 283);
            this.ModelWs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ModelWs.MinimumSize = new System.Drawing.Size(1, 16);
            this.ModelWs.Name = "ModelWs";
            this.ModelWs.Padding = new System.Windows.Forms.Padding(5);
            this.ModelWs.ShowButton = true;
            this.ModelWs.ShowText = false;
            this.ModelWs.Size = new System.Drawing.Size(220, 29);
            this.ModelWs.TabIndex = 55;
            this.ModelWs.TabStop = false;
            this.ModelWs.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ModelWs.Watermark = "";
            this.ModelWs.ButtonClick += new System.EventHandler(this.ModelWs_ButtonClick);
            // 
            // MachineCode
            // 
            this.MachineCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineCode.Enabled = false;
            this.MachineCode.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.MachineCode.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineCode.ForeDisableColor = System.Drawing.Color.Black;
            this.MachineCode.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.MachineCode.Location = new System.Drawing.Point(134, 244);
            this.MachineCode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineCode.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineCode.Name = "MachineCode";
            this.MachineCode.Padding = new System.Windows.Forms.Padding(5);
            this.MachineCode.ShowButton = true;
            this.MachineCode.ShowText = false;
            this.MachineCode.Size = new System.Drawing.Size(220, 29);
            this.MachineCode.TabIndex = 55;
            this.MachineCode.TabStop = false;
            this.MachineCode.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineCode.Watermark = "";
            this.MachineCode.ButtonClick += new System.EventHandler(this.MachineList_ButtonClick);
            // 
            // Creator
            // 
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.Enabled = false;
            this.Creator.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.Black;
            this.Creator.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Creator.Location = new System.Drawing.Point(134, 88);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ShowButton = true;
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(220, 29);
            this.Creator.TabIndex = 54;
            this.Creator.TabStop = false;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            this.Creator.ButtonClick += new System.EventHandler(this.Creator_ButtonClick);
            // 
            // EditModeSwitch
            // 
            this.EditModeSwitch.ActiveText = "編輯";
            this.EditModeSwitch.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.EditModeSwitch.InActiveText = "鎖定";
            this.EditModeSwitch.Location = new System.Drawing.Point(1110, 369);
            this.EditModeSwitch.MinimumSize = new System.Drawing.Size(1, 1);
            this.EditModeSwitch.Name = "EditModeSwitch";
            this.EditModeSwitch.Size = new System.Drawing.Size(110, 33);
            this.EditModeSwitch.SwitchShape = Sunny.UI.UISwitch.UISwitchShape.Square;
            this.EditModeSwitch.TabIndex = 38;
            this.EditModeSwitch.Text = "uiSwitch1";
            this.EditModeSwitch.ValueChanged += new Sunny.UI.UISwitch.OnValueChanged(this.EditModeSwitch_ValueChanged);
            // 
            // adgvContextMenu
            // 
            this.adgvContextMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.adgvContextMenu.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.adgvContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.delWorkOrder});
            this.adgvContextMenu.Name = "adgvContextMenu";
            this.adgvContextMenu.Size = new System.Drawing.Size(139, 28);
            // 
            // delWorkOrder
            // 
            this.delWorkOrder.Name = "delWorkOrder";
            this.delWorkOrder.Size = new System.Drawing.Size(138, 24);
            this.delWorkOrder.Text = "刪除記錄";
            this.delWorkOrder.Click += new System.EventHandler(this.delWorkOrder_Click);
            // 
            // adgvSearchToolBar
            // 
            this.adgvSearchToolBar.AllowMerge = false;
            this.adgvSearchToolBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adgvSearchToolBar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.adgvSearchToolBar.Location = new System.Drawing.Point(0, 119);
            this.adgvSearchToolBar.MaximumSize = new System.Drawing.Size(0, 27);
            this.adgvSearchToolBar.MinimumSize = new System.Drawing.Size(0, 27);
            this.adgvSearchToolBar.Name = "adgvSearchToolBar";
            this.adgvSearchToolBar.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.adgvSearchToolBar.Size = new System.Drawing.Size(1255, 27);
            this.adgvSearchToolBar.TabIndex = 102;
            this.adgvSearchToolBar.Text = "advancedDataGridViewSearchToolBar1";
            this.adgvSearchToolBar.Search += new Calin.TaskPulse.Core.ADGV.AdvancedDataGridViewSearchToolBarSearchEventHandler(this.adgvSearchToolBar_Search);
            // 
            // AcceptedTime
            // 
            this.AcceptedTime.DateFormat = "yyyy/MM/dd HH:mm";
            this.AcceptedTime.DurationControl = null;
            this.AcceptedTime.EndTimeControl = null;
            this.AcceptedTime.FillColor = System.Drawing.Color.White;
            this.AcceptedTime.Location = new System.Drawing.Point(134, 166);
            this.AcceptedTime.Name = "AcceptedTime";
            this.AcceptedTime.Size = new System.Drawing.Size(220, 29);
            this.AcceptedTime.StartTimeControl = null;
            this.AcceptedTime.TabIndex = 112;
            this.AcceptedTime.Value = null;
            // 
            // CreationDateTime
            // 
            this.CreationDateTime.DateFormat = "yyyy/MM/dd HH:mm";
            this.CreationDateTime.DurationControl = null;
            this.CreationDateTime.EndTimeControl = null;
            this.CreationDateTime.FillColor = System.Drawing.Color.White;
            this.CreationDateTime.Location = new System.Drawing.Point(134, 127);
            this.CreationDateTime.Name = "CreationDateTime";
            this.CreationDateTime.Size = new System.Drawing.Size(220, 29);
            this.CreationDateTime.StartTimeControl = null;
            this.CreationDateTime.TabIndex = 111;
            this.CreationDateTime.Value = null;
            // 
            // FillingTime
            // 
            this.FillingTime.DateFormat = "yyyy/MM/dd HH:mm";
            this.FillingTime.DurationControl = null;
            this.FillingTime.EndTimeControl = null;
            this.FillingTime.FillColor = System.Drawing.Color.White;
            this.FillingTime.Location = new System.Drawing.Point(478, 361);
            this.FillingTime.Name = "FillingTime";
            this.FillingTime.Size = new System.Drawing.Size(220, 29);
            this.FillingTime.StartTimeControl = null;
            this.FillingTime.TabIndex = 110;
            this.FillingTime.Value = null;
            // 
            // RepairCompleted
            // 
            this.RepairCompleted.DateFormat = "yyyy/MM/dd HH:mm";
            this.RepairCompleted.DurationControl = this.RepairDuration;
            this.RepairCompleted.EndTimeControl = null;
            this.RepairCompleted.FillColor = System.Drawing.Color.White;
            this.RepairCompleted.Location = new System.Drawing.Point(478, 127);
            this.RepairCompleted.Name = "RepairCompleted";
            this.RepairCompleted.Size = new System.Drawing.Size(220, 29);
            this.RepairCompleted.StartTimeControl = this.RepairStarted;
            this.RepairCompleted.TabIndex = 108;
            this.RepairCompleted.Value = null;
            // 
            // RepairStarted
            // 
            this.RepairStarted.DateFormat = "yyyy/MM/dd HH:mm";
            this.RepairStarted.DurationControl = this.RepairDuration;
            this.RepairStarted.EndTimeControl = this.RepairCompleted;
            this.RepairStarted.FillColor = System.Drawing.Color.White;
            this.RepairStarted.Location = new System.Drawing.Point(478, 88);
            this.RepairStarted.Name = "RepairStarted";
            this.RepairStarted.Size = new System.Drawing.Size(220, 29);
            this.RepairStarted.StartTimeControl = null;
            this.RepairStarted.TabIndex = 107;
            this.RepairStarted.Value = null;
            // 
            // OutageEnded
            // 
            this.OutageEnded.DateFormat = "yyyy/MM/dd HH:mm";
            this.OutageEnded.DurationControl = this.OutageDuration;
            this.OutageEnded.EndTimeControl = null;
            this.OutageEnded.FillColor = System.Drawing.Color.White;
            this.OutageEnded.Location = new System.Drawing.Point(478, 244);
            this.OutageEnded.Name = "OutageEnded";
            this.OutageEnded.Size = new System.Drawing.Size(220, 29);
            this.OutageEnded.StartTimeControl = this.OutageStarted;
            this.OutageEnded.TabIndex = 106;
            this.OutageEnded.Value = null;
            // 
            // OutageStarted
            // 
            this.OutageStarted.DateFormat = "yyyy/MM/dd HH:mm";
            this.OutageStarted.DurationControl = this.OutageDuration;
            this.OutageStarted.EndTimeControl = this.OutageEnded;
            this.OutageStarted.FillColor = System.Drawing.Color.White;
            this.OutageStarted.Location = new System.Drawing.Point(478, 205);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Size = new System.Drawing.Size(220, 29);
            this.OutageStarted.StartTimeControl = null;
            this.OutageStarted.TabIndex = 105;
            this.OutageStarted.Value = null;
            // 
            // ADGV
            // 
            this.ADGV.AllowUserToAddRows = false;
            this.ADGV.AllowUserToDeleteRows = false;
            this.ADGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ADGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ADGV.FilterAndSortEnabled = true;
            this.ADGV.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.ADGV.Location = new System.Drawing.Point(3, 3);
            this.ADGV.MaxFilterButtonImageHeight = 23;
            this.ADGV.Name = "ADGV";
            this.ADGV.ReadOnly = true;
            this.ADGV.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ADGV.RowTemplate.Height = 24;
            this.ADGV.Size = new System.Drawing.Size(1249, 113);
            this.ADGV.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.ADGV.TabIndex = 4;
            this.ADGV.SelectionChanged += new System.EventHandler(this.ADGV_SelectionChanged);
            // 
            // MaintiFlowSummary
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.TLP);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "MaintiFlowSummary";
            this.Size = new System.Drawing.Size(1255, 566);
            this.Load += new System.EventHandler(this.MaintiFlowSummary_Load);
            this.TLP.ResumeLayout(false);
            this.TLP.PerformLayout();
            this.panelDetail.ResumeLayout(false);
            this.adgvContextMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ADGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Sunny.UI.UILabel uiLabel_CreationDate;
        private Sunny.UI.UILabel uiLabel_Creator;
        private Sunny.UI.UILabel uiLabel_WorkOrderNo;
        private Sunny.UI.UITextBox WorkOrderNo;
        private Sunny.UI.UILabel uiLabel_OrderNo;
        private Sunny.UI.UITextBox OrderNo;
        private Sunny.UI.UILabel uiLabel_OutageStarted;
        private Sunny.UI.UILabel uiLabel_ModelWs;
        private Sunny.UI.UILabel uiLabel_MachineList;
        private Sunny.UI.UILabel uiLabel_Status;
        private Sunny.UI.UILabel uiLabel_MaintenanceUnit;
        private Sunny.UI.UILabel uiLabel_MaintenanceEngineer;
        private Sunny.UI.UILabel uiLabel_AcceptedTime;
        private Sunny.UI.UILabel uiLabel_IssueCategory;
        private Sunny.UI.UILabel uiLabel_IssueDescription;
        private Sunny.UI.UILabel uiLabel_Details;
        private Sunny.UI.UILabel uiLabel_RequestingUnit;
        private Sunny.UI.UILabel uiLabel_FeedbackEmployee;
        private Sunny.UI.UILabel uiLabel_RequestingUnitResponse;
        private Sunny.UI.UILabel uiLabel_RepairDuration;
        private Sunny.UI.UILabel uiLabel_RepairCompleted;
        private Sunny.UI.UILabel uiLabel_RepairStarted;
        private Sunny.UI.UILabel uiLabel_OutageDuration;
        private Sunny.UI.UILabel uiLabel_OutageEnded;
        private Sunny.UI.UILabel uiLabel_Responsible;
        private Sunny.UI.UITextBox Responsible;
        private Sunny.UI.UILabel Label_FillingTime;
        private Sunny.UI.UIRichTextBox Details;
        private Sunny.UI.UIRichTextBox IssueDescription;
        private Sunny.UI.UIRichTextBox RequestingUnitFeedback;
        private System.Windows.Forms.TableLayoutPanel TLP;
        private System.Windows.Forms.Panel panelDetail;
        private Sunny.UI.UISwitch EditModeSwitch;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UITextBox ModelWs;
        private Sunny.UI.UITextBox MachineCode;
        private Sunny.UI.UIComboBox IssueCategory;
        private Sunny.UI.UIComboBox MaintenanceUnit;
        private Sunny.UI.UITextBox Engineers;
        private Sunny.UI.UITextBox OutageDuration;
        private Sunny.UI.UITextBox RepairDuration;
        private Sunny.UI.UIComboBox Status;
        private Sunny.UI.UIComboBox RequestingUnit;
        private Sunny.UI.UITextBox FeedbackEmployee;
        private Sunny.UI.UISymbolButton btnSave;
        private AdvancedDataGridView ADGV;
        private AdvancedDataGridViewSearchToolBar adgvSearchToolBar;
        private Sunny.UI.UIContextMenuStrip adgvContextMenu;
        private System.Windows.Forms.ToolStripMenuItem delWorkOrder;
        private Sunny.UI.UISymbolButton btnRefresh;
        private Core.WinForms.UIDurationDateTimePicker OutageEnded;
        private Core.WinForms.UIDurationDateTimePicker OutageStarted;
        private Core.WinForms.UIDurationDateTimePicker AcceptedTime;
        private Core.WinForms.UIDurationDateTimePicker CreationDateTime;
        private Core.WinForms.UIDurationDateTimePicker FillingTime;
        private Core.WinForms.UIDurationDateTimePicker RepairCompleted;
        private Core.WinForms.UIDurationDateTimePicker RepairStarted;
    }
}