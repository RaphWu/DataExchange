﻿namespace Calin.TaskPulse.MaintiFlow.Views
{
    partial class MF_QuickCreate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Engineers = new Sunny.UI.UITextBox();
            this.Label_Details = new Sunny.UI.UILabel();
            this.Details = new Sunny.UI.UIRichTextBox();
            this.IssueDescription = new Sunny.UI.UIRichTextBox();
            this.IssueCategory = new Sunny.UI.UIComboBox();
            this.Label_Creator = new Sunny.UI.UILabel();
            this.Label_CreationDate = new Sunny.UI.UILabel();
            this.MaintenanceUnit = new Sunny.UI.UIComboBox();
            this.Label_RequestingUnit = new Sunny.UI.UILabel();
            this.Label_MachineList = new Sunny.UI.UILabel();
            this.Label_ModelWs = new Sunny.UI.UILabel();
            this.ModelWs = new Sunny.UI.UITextBox();
            this.Label_OutageStarted = new Sunny.UI.UILabel();
            this.OutageDuration = new Sunny.UI.UITextBox();
            this.Label_MaintenanceUnit = new Sunny.UI.UILabel();
            this.RepairDuration = new Sunny.UI.UITextBox();
            this.Label_Engineers = new Sunny.UI.UILabel();
            this.Label_OutageDuration = new Sunny.UI.UILabel();
            this.Label_IssueCategory = new Sunny.UI.UILabel();
            this.Label_RepairDuration = new Sunny.UI.UILabel();
            this.Label_AcceptedTime = new Sunny.UI.UILabel();
            this.Label_OutageEnded = new Sunny.UI.UILabel();
            this.Label_RepairCompleted = new Sunny.UI.UILabel();
            this.Label_IssueDescription = new Sunny.UI.UILabel();
            this.Label_RepairStarted = new Sunny.UI.UILabel();
            this.MachineCode = new Sunny.UI.UITextBox();
            this.RequestingUnit = new Sunny.UI.UIComboBox();
            this.Creator = new Sunny.UI.UITextBox();
            this.btnCreate = new Sunny.UI.UISymbolButton();
            this.btnCancel = new Sunny.UI.UISymbolButton();
            this.Notification = new Sunny.UI.UITextBox();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.RepairStarted = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.RepairCompleted = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.OutageEnded = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.OutageStarted = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.AcceptedTime = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.CreationDateTime = new Calin.TaskPulse.Core.WinForms.UIDurationDateTimePicker();
            this.SuspendLayout();
            // 
            // Engineers
            // 
            this.Engineers.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Engineers.FillDisableColor = System.Drawing.Color.White;
            this.Engineers.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Engineers.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Engineers.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Engineers.Location = new System.Drawing.Point(127, 191);
            this.Engineers.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Engineers.MinimumSize = new System.Drawing.Size(1, 16);
            this.Engineers.Name = "Engineers";
            this.Engineers.Padding = new System.Windows.Forms.Padding(5);
            this.Engineers.ShowButton = true;
            this.Engineers.ShowText = false;
            this.Engineers.Size = new System.Drawing.Size(236, 29);
            this.Engineers.TabIndex = 106;
            this.Engineers.TabStop = false;
            this.Engineers.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Engineers.Watermark = "";
            this.Engineers.ButtonClick += new System.EventHandler(this.Engineers_ButtonClick);
            // 
            // Label_Details
            // 
            this.Label_Details.BackColor = System.Drawing.Color.Transparent;
            this.Label_Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Details.Location = new System.Drawing.Point(375, 346);
            this.Label_Details.Name = "Label_Details";
            this.Label_Details.Size = new System.Drawing.Size(80, 29);
            this.Label_Details.TabIndex = 117;
            this.Label_Details.Text = "維護內容";
            this.Label_Details.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Details
            // 
            this.Details.FillColor = System.Drawing.Color.White;
            this.Details.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Details.Location = new System.Drawing.Point(462, 346);
            this.Details.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Details.MinimumSize = new System.Drawing.Size(1, 1);
            this.Details.Name = "Details";
            this.Details.Padding = new System.Windows.Forms.Padding(2);
            this.Details.ShowText = false;
            this.Details.Size = new System.Drawing.Size(255, 183);
            this.Details.TabIndex = 129;
            this.Details.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // IssueDescription
            // 
            this.IssueDescription.FillColor = System.Drawing.Color.White;
            this.IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueDescription.Location = new System.Drawing.Point(462, 250);
            this.IssueDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.IssueDescription.Name = "IssueDescription";
            this.IssueDescription.Padding = new System.Windows.Forms.Padding(2);
            this.IssueDescription.ShowText = false;
            this.IssueDescription.Size = new System.Drawing.Size(255, 86);
            this.IssueDescription.TabIndex = 128;
            this.IssueDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // IssueCategory
            // 
            this.IssueCategory.DataSource = null;
            this.IssueCategory.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.IssueCategory.FillColor = System.Drawing.Color.White;
            this.IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.IssueCategory.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.IssueCategory.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.IssueCategory.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.IssueCategory.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.IssueCategory.Location = new System.Drawing.Point(127, 230);
            this.IssueCategory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.IssueCategory.MinimumSize = new System.Drawing.Size(63, 0);
            this.IssueCategory.Name = "IssueCategory";
            this.IssueCategory.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.IssueCategory.Size = new System.Drawing.Size(236, 29);
            this.IssueCategory.SymbolSize = 24;
            this.IssueCategory.TabIndex = 127;
            this.IssueCategory.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.IssueCategory.Watermark = "";
            // 
            // Label_Creator
            // 
            this.Label_Creator.BackColor = System.Drawing.Color.Transparent;
            this.Label_Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Creator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Creator.Location = new System.Drawing.Point(375, 94);
            this.Label_Creator.Name = "Label_Creator";
            this.Label_Creator.Size = new System.Drawing.Size(80, 29);
            this.Label_Creator.TabIndex = 98;
            this.Label_Creator.Text = "建檔人員";
            this.Label_Creator.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_CreationDate
            // 
            this.Label_CreationDate.BackColor = System.Drawing.Color.Transparent;
            this.Label_CreationDate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_CreationDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_CreationDate.Location = new System.Drawing.Point(375, 172);
            this.Label_CreationDate.Name = "Label_CreationDate";
            this.Label_CreationDate.Size = new System.Drawing.Size(80, 29);
            this.Label_CreationDate.TabIndex = 99;
            this.Label_CreationDate.Text = "建檔日期";
            this.Label_CreationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MaintenanceUnit
            // 
            this.MaintenanceUnit.DataSource = null;
            this.MaintenanceUnit.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.MaintenanceUnit.FillColor = System.Drawing.Color.White;
            this.MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaintenanceUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaintenanceUnit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MaintenanceUnit.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.MaintenanceUnit.Location = new System.Drawing.Point(127, 152);
            this.MaintenanceUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaintenanceUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.MaintenanceUnit.Name = "MaintenanceUnit";
            this.MaintenanceUnit.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.MaintenanceUnit.Size = new System.Drawing.Size(236, 29);
            this.MaintenanceUnit.SymbolSize = 24;
            this.MaintenanceUnit.TabIndex = 126;
            this.MaintenanceUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaintenanceUnit.Watermark = "";
            // 
            // Label_RequestingUnit
            // 
            this.Label_RequestingUnit.BackColor = System.Drawing.Color.Transparent;
            this.Label_RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RequestingUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RequestingUnit.Location = new System.Drawing.Point(375, 55);
            this.Label_RequestingUnit.Name = "Label_RequestingUnit";
            this.Label_RequestingUnit.Size = new System.Drawing.Size(80, 29);
            this.Label_RequestingUnit.TabIndex = 125;
            this.Label_RequestingUnit.Text = "需求單位";
            this.Label_RequestingUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_MachineList
            // 
            this.Label_MachineList.BackColor = System.Drawing.Color.Transparent;
            this.Label_MachineList.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MachineList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MachineList.Location = new System.Drawing.Point(11, 55);
            this.Label_MachineList.Name = "Label_MachineList";
            this.Label_MachineList.Size = new System.Drawing.Size(109, 29);
            this.Label_MachineList.TabIndex = 102;
            this.Label_MachineList.Text = "機台編號";
            this.Label_MachineList.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_ModelWs
            // 
            this.Label_ModelWs.BackColor = System.Drawing.Color.Transparent;
            this.Label_ModelWs.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_ModelWs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_ModelWs.Location = new System.Drawing.Point(11, 94);
            this.Label_ModelWs.Name = "Label_ModelWs";
            this.Label_ModelWs.Size = new System.Drawing.Size(109, 29);
            this.Label_ModelWs.TabIndex = 107;
            this.Label_ModelWs.Text = "機種";
            this.Label_ModelWs.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ModelWs
            // 
            this.ModelWs.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ModelWs.FillDisableColor = System.Drawing.Color.White;
            this.ModelWs.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.ModelWs.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModelWs.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.ModelWs.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ModelWs.Location = new System.Drawing.Point(127, 94);
            this.ModelWs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ModelWs.MinimumSize = new System.Drawing.Size(1, 16);
            this.ModelWs.Name = "ModelWs";
            this.ModelWs.Padding = new System.Windows.Forms.Padding(5);
            this.ModelWs.ShowButton = true;
            this.ModelWs.ShowText = false;
            this.ModelWs.Size = new System.Drawing.Size(236, 29);
            this.ModelWs.TabIndex = 104;
            this.ModelWs.TabStop = false;
            this.ModelWs.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ModelWs.Watermark = "";
            this.ModelWs.ButtonClick += new System.EventHandler(this.ModelWs_ButtonClick);
            // 
            // Label_OutageStarted
            // 
            this.Label_OutageStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageStarted.Location = new System.Drawing.Point(11, 422);
            this.Label_OutageStarted.Name = "Label_OutageStarted";
            this.Label_OutageStarted.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageStarted.TabIndex = 109;
            this.Label_OutageStarted.Text = "停動開始時間";
            this.Label_OutageStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // OutageDuration
            // 
            this.OutageDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.OutageDuration.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.OutageDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.OutageDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.OutageDuration.Location = new System.Drawing.Point(127, 500);
            this.OutageDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.OutageDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.OutageDuration.Name = "OutageDuration";
            this.OutageDuration.Padding = new System.Windows.Forms.Padding(5);
            this.OutageDuration.ReadOnly = true;
            this.OutageDuration.ShowText = false;
            this.OutageDuration.Size = new System.Drawing.Size(236, 29);
            this.OutageDuration.TabIndex = 118;
            this.OutageDuration.TabStop = false;
            this.OutageDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.OutageDuration.Watermark = "";
            // 
            // Label_MaintenanceUnit
            // 
            this.Label_MaintenanceUnit.BackColor = System.Drawing.Color.Transparent;
            this.Label_MaintenanceUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_MaintenanceUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_MaintenanceUnit.Location = new System.Drawing.Point(11, 152);
            this.Label_MaintenanceUnit.Name = "Label_MaintenanceUnit";
            this.Label_MaintenanceUnit.Size = new System.Drawing.Size(109, 29);
            this.Label_MaintenanceUnit.TabIndex = 105;
            this.Label_MaintenanceUnit.Text = "維護單位";
            this.Label_MaintenanceUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RepairDuration
            // 
            this.RepairDuration.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.RepairDuration.FillDisableColor = System.Drawing.Color.Gainsboro;
            this.RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RepairDuration.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RepairDuration.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.RepairDuration.Location = new System.Drawing.Point(127, 368);
            this.RepairDuration.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RepairDuration.MinimumSize = new System.Drawing.Size(1, 16);
            this.RepairDuration.Name = "RepairDuration";
            this.RepairDuration.Padding = new System.Windows.Forms.Padding(5);
            this.RepairDuration.ReadOnly = true;
            this.RepairDuration.ShowText = false;
            this.RepairDuration.Size = new System.Drawing.Size(236, 29);
            this.RepairDuration.TabIndex = 113;
            this.RepairDuration.TabStop = false;
            this.RepairDuration.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RepairDuration.Watermark = "";
            // 
            // Label_Engineers
            // 
            this.Label_Engineers.BackColor = System.Drawing.Color.Transparent;
            this.Label_Engineers.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_Engineers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_Engineers.Location = new System.Drawing.Point(11, 191);
            this.Label_Engineers.Name = "Label_Engineers";
            this.Label_Engineers.Size = new System.Drawing.Size(109, 29);
            this.Label_Engineers.TabIndex = 108;
            this.Label_Engineers.Text = "維護工程師";
            this.Label_Engineers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageDuration
            // 
            this.Label_OutageDuration.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageDuration.Location = new System.Drawing.Point(11, 500);
            this.Label_OutageDuration.Name = "Label_OutageDuration";
            this.Label_OutageDuration.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageDuration.TabIndex = 119;
            this.Label_OutageDuration.Text = "停動工時";
            this.Label_OutageDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_IssueCategory
            // 
            this.Label_IssueCategory.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueCategory.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueCategory.Location = new System.Drawing.Point(11, 230);
            this.Label_IssueCategory.Name = "Label_IssueCategory";
            this.Label_IssueCategory.Size = new System.Drawing.Size(109, 29);
            this.Label_IssueCategory.TabIndex = 110;
            this.Label_IssueCategory.Text = "維護類型";
            this.Label_IssueCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairDuration
            // 
            this.Label_RepairDuration.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairDuration.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairDuration.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairDuration.Location = new System.Drawing.Point(11, 368);
            this.Label_RepairDuration.Name = "Label_RepairDuration";
            this.Label_RepairDuration.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairDuration.TabIndex = 114;
            this.Label_RepairDuration.Text = "維護工時";
            this.Label_RepairDuration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_AcceptedTime
            // 
            this.Label_AcceptedTime.BackColor = System.Drawing.Color.Transparent;
            this.Label_AcceptedTime.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_AcceptedTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_AcceptedTime.Location = new System.Drawing.Point(375, 211);
            this.Label_AcceptedTime.Name = "Label_AcceptedTime";
            this.Label_AcceptedTime.Size = new System.Drawing.Size(80, 29);
            this.Label_AcceptedTime.TabIndex = 103;
            this.Label_AcceptedTime.Text = "接單時間";
            this.Label_AcceptedTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_OutageEnded
            // 
            this.Label_OutageEnded.BackColor = System.Drawing.Color.Transparent;
            this.Label_OutageEnded.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_OutageEnded.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_OutageEnded.Location = new System.Drawing.Point(11, 461);
            this.Label_OutageEnded.Name = "Label_OutageEnded";
            this.Label_OutageEnded.Size = new System.Drawing.Size(109, 29);
            this.Label_OutageEnded.TabIndex = 116;
            this.Label_OutageEnded.Text = "停動結束時間";
            this.Label_OutageEnded.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairCompleted
            // 
            this.Label_RepairCompleted.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairCompleted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairCompleted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairCompleted.Location = new System.Drawing.Point(11, 329);
            this.Label_RepairCompleted.Name = "Label_RepairCompleted";
            this.Label_RepairCompleted.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairCompleted.TabIndex = 112;
            this.Label_RepairCompleted.Text = "維護完成時間";
            this.Label_RepairCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_IssueDescription
            // 
            this.Label_IssueDescription.BackColor = System.Drawing.Color.Transparent;
            this.Label_IssueDescription.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_IssueDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_IssueDescription.Location = new System.Drawing.Point(375, 250);
            this.Label_IssueDescription.Name = "Label_IssueDescription";
            this.Label_IssueDescription.Size = new System.Drawing.Size(80, 29);
            this.Label_IssueDescription.TabIndex = 115;
            this.Label_IssueDescription.Text = "問題描述";
            this.Label_IssueDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label_RepairStarted
            // 
            this.Label_RepairStarted.BackColor = System.Drawing.Color.Transparent;
            this.Label_RepairStarted.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Label_RepairStarted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Label_RepairStarted.Location = new System.Drawing.Point(11, 290);
            this.Label_RepairStarted.Name = "Label_RepairStarted";
            this.Label_RepairStarted.Size = new System.Drawing.Size(109, 29);
            this.Label_RepairStarted.TabIndex = 111;
            this.Label_RepairStarted.Text = "維護開始時間";
            this.Label_RepairStarted.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MachineCode
            // 
            this.MachineCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MachineCode.FillDisableColor = System.Drawing.Color.White;
            this.MachineCode.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.MachineCode.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MachineCode.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MachineCode.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MachineCode.Location = new System.Drawing.Point(127, 55);
            this.MachineCode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MachineCode.MinimumSize = new System.Drawing.Size(1, 16);
            this.MachineCode.Name = "MachineCode";
            this.MachineCode.Padding = new System.Windows.Forms.Padding(5);
            this.MachineCode.ShowButton = true;
            this.MachineCode.ShowText = false;
            this.MachineCode.Size = new System.Drawing.Size(236, 29);
            this.MachineCode.TabIndex = 105;
            this.MachineCode.TabStop = false;
            this.MachineCode.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MachineCode.Watermark = "";
            this.MachineCode.ButtonClick += new System.EventHandler(this.MachineList_ButtonClick);
            // 
            // RequestingUnit
            // 
            this.RequestingUnit.DataSource = null;
            this.RequestingUnit.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.RequestingUnit.FillColor = System.Drawing.Color.White;
            this.RequestingUnit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.RequestingUnit.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.RequestingUnit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.RequestingUnit.ItemHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.RequestingUnit.ItemSelectForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.RequestingUnit.Location = new System.Drawing.Point(462, 55);
            this.RequestingUnit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.RequestingUnit.MinimumSize = new System.Drawing.Size(63, 0);
            this.RequestingUnit.Name = "RequestingUnit";
            this.RequestingUnit.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.RequestingUnit.Size = new System.Drawing.Size(200, 29);
            this.RequestingUnit.SymbolSize = 24;
            this.RequestingUnit.TabIndex = 127;
            this.RequestingUnit.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.RequestingUnit.Watermark = "";
            // 
            // Creator
            // 
            this.Creator.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Creator.FillDisableColor = System.Drawing.Color.White;
            this.Creator.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.Creator.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Creator.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Creator.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Creator.Location = new System.Drawing.Point(462, 94);
            this.Creator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Creator.MinimumSize = new System.Drawing.Size(1, 16);
            this.Creator.Name = "Creator";
            this.Creator.Padding = new System.Windows.Forms.Padding(5);
            this.Creator.ShowButton = true;
            this.Creator.ShowText = false;
            this.Creator.Size = new System.Drawing.Size(200, 29);
            this.Creator.TabIndex = 107;
            this.Creator.TabStop = false;
            this.Creator.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Creator.Watermark = "";
            this.Creator.ButtonClick += new System.EventHandler(this.Creator_ButtonClick);
            // 
            // btnCreate
            // 
            this.btnCreate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCreate.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCreate.Location = new System.Drawing.Point(462, 546);
            this.btnCreate.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Radius = 10;
            this.btnCreate.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnCreate.Size = new System.Drawing.Size(116, 35);
            this.btnCreate.Symbol = 61639;
            this.btnCreate.TabIndex = 135;
            this.btnCreate.Text = "建立工單";
            this.btnCreate.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.FillHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.FillPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.FillSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.btnCancel.LightColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.btnCancel.Location = new System.Drawing.Point(601, 546);
            this.btnCancel.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Radius = 10;
            this.btnCancel.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnCancel.RectHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(115)))), ((int)(((byte)(115)))));
            this.btnCancel.RectPressColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.None;
            this.btnCancel.Size = new System.Drawing.Size(116, 35);
            this.btnCancel.Style = Sunny.UI.UIStyle.Custom;
            this.btnCancel.Symbol = 361453;
            this.btnCancel.TabIndex = 134;
            this.btnCancel.Text = "取消";
            this.btnCancel.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // Notification
            // 
            this.Notification.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Notification.FillDisableColor = System.Drawing.Color.White;
            this.Notification.FillReadOnlyColor = System.Drawing.Color.Gainsboro;
            this.Notification.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Notification.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Notification.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Notification.Location = new System.Drawing.Point(462, 133);
            this.Notification.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Notification.MinimumSize = new System.Drawing.Size(1, 16);
            this.Notification.Name = "Notification";
            this.Notification.Padding = new System.Windows.Forms.Padding(5);
            this.Notification.ShowButton = true;
            this.Notification.ShowText = false;
            this.Notification.Size = new System.Drawing.Size(200, 29);
            this.Notification.TabIndex = 109;
            this.Notification.TabStop = false;
            this.Notification.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Notification.Watermark = "";
            this.Notification.ButtonClick += new System.EventHandler(this.Notification_ButtonClick);
            // 
            // uiLabel1
            // 
            this.uiLabel1.BackColor = System.Drawing.Color.Transparent;
            this.uiLabel1.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.uiLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.uiLabel1.Location = new System.Drawing.Point(375, 133);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(80, 29);
            this.uiLabel1.TabIndex = 108;
            this.uiLabel1.Text = "通知人員";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RepairStarted
            // 
            this.RepairStarted.DateFormat = "yyyy/MM/dd HH:mm";
            this.RepairStarted.DurationControl = this.RepairDuration;
            this.RepairStarted.EndTimeControl = this.RepairCompleted;
            this.RepairStarted.FillColor = System.Drawing.Color.White;
            this.RepairStarted.Location = new System.Drawing.Point(127, 290);
            this.RepairStarted.Name = "RepairStarted";
            this.RepairStarted.Size = new System.Drawing.Size(236, 29);
            this.RepairStarted.StartTimeControl = null;
            this.RepairStarted.TabIndex = 136;
            this.RepairStarted.Value = null;
            this.RepairStarted.Watermark = "";
            // 
            // RepairCompleted
            // 
            this.RepairCompleted.DateFormat = "yyyy/MM/dd HH:mm";
            this.RepairCompleted.DurationControl = this.RepairDuration;
            this.RepairCompleted.EndTimeControl = null;
            this.RepairCompleted.FillColor = System.Drawing.Color.White;
            this.RepairCompleted.Location = new System.Drawing.Point(127, 329);
            this.RepairCompleted.Name = "RepairCompleted";
            this.RepairCompleted.Size = new System.Drawing.Size(236, 29);
            this.RepairCompleted.StartTimeControl = this.RepairStarted;
            this.RepairCompleted.TabIndex = 137;
            this.RepairCompleted.Value = null;
            this.RepairCompleted.Watermark = "";
            // 
            // OutageEnded
            // 
            this.OutageEnded.DateFormat = "yyyy/MM/dd HH:mm";
            this.OutageEnded.DurationControl = this.OutageDuration;
            this.OutageEnded.EndTimeControl = null;
            this.OutageEnded.FillColor = System.Drawing.Color.White;
            this.OutageEnded.Location = new System.Drawing.Point(127, 461);
            this.OutageEnded.Name = "OutageEnded";
            this.OutageEnded.Size = new System.Drawing.Size(236, 29);
            this.OutageEnded.StartTimeControl = this.RepairStarted;
            this.OutageEnded.TabIndex = 139;
            this.OutageEnded.Value = null;
            this.OutageEnded.Watermark = "";
            // 
            // OutageStarted
            // 
            this.OutageStarted.DateFormat = "yyyy/MM/dd HH:mm";
            this.OutageStarted.DurationControl = this.OutageDuration;
            this.OutageStarted.EndTimeControl = this.OutageEnded;
            this.OutageStarted.FillColor = System.Drawing.Color.White;
            this.OutageStarted.Location = new System.Drawing.Point(127, 422);
            this.OutageStarted.Name = "OutageStarted";
            this.OutageStarted.Size = new System.Drawing.Size(236, 29);
            this.OutageStarted.StartTimeControl = null;
            this.OutageStarted.TabIndex = 138;
            this.OutageStarted.Value = null;
            this.OutageStarted.Watermark = "";
            // 
            // AcceptedTime
            // 
            this.AcceptedTime.DateFormat = "yyyy/MM/dd HH:mm";
            this.AcceptedTime.DurationControl = null;
            this.AcceptedTime.EndTimeControl = null;
            this.AcceptedTime.FillColor = System.Drawing.Color.White;
            this.AcceptedTime.Location = new System.Drawing.Point(462, 211);
            this.AcceptedTime.Name = "AcceptedTime";
            this.AcceptedTime.Size = new System.Drawing.Size(200, 29);
            this.AcceptedTime.StartTimeControl = null;
            this.AcceptedTime.TabIndex = 141;
            this.AcceptedTime.Value = null;
            this.AcceptedTime.Watermark = "";
            // 
            // CreationDateTime
            // 
            this.CreationDateTime.DateFormat = "yyyy/MM/dd HH:mm";
            this.CreationDateTime.DurationControl = null;
            this.CreationDateTime.EndTimeControl = null;
            this.CreationDateTime.FillColor = System.Drawing.Color.White;
            this.CreationDateTime.Location = new System.Drawing.Point(462, 172);
            this.CreationDateTime.Name = "CreationDateTime";
            this.CreationDateTime.Size = new System.Drawing.Size(200, 29);
            this.CreationDateTime.StartTimeControl = null;
            this.CreationDateTime.TabIndex = 140;
            this.CreationDateTime.Value = null;
            this.CreationDateTime.Watermark = "";
            // 
            // MF_QuickCreate
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(746, 600);
            this.Controls.Add(this.AcceptedTime);
            this.Controls.Add(this.CreationDateTime);
            this.Controls.Add(this.OutageEnded);
            this.Controls.Add(this.OutageStarted);
            this.Controls.Add(this.RepairCompleted);
            this.Controls.Add(this.RepairStarted);
            this.Controls.Add(this.Notification);
            this.Controls.Add(this.uiLabel1);
            this.Controls.Add(this.btnCreate);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.Creator);
            this.Controls.Add(this.RequestingUnit);
            this.Controls.Add(this.MachineCode);
            this.Controls.Add(this.Engineers);
            this.Controls.Add(this.Label_Details);
            this.Controls.Add(this.Details);
            this.Controls.Add(this.IssueDescription);
            this.Controls.Add(this.IssueCategory);
            this.Controls.Add(this.Label_Creator);
            this.Controls.Add(this.Label_CreationDate);
            this.Controls.Add(this.MaintenanceUnit);
            this.Controls.Add(this.Label_RequestingUnit);
            this.Controls.Add(this.Label_MachineList);
            this.Controls.Add(this.Label_ModelWs);
            this.Controls.Add(this.ModelWs);
            this.Controls.Add(this.Label_OutageStarted);
            this.Controls.Add(this.OutageDuration);
            this.Controls.Add(this.Label_MaintenanceUnit);
            this.Controls.Add(this.RepairDuration);
            this.Controls.Add(this.Label_Engineers);
            this.Controls.Add(this.Label_OutageDuration);
            this.Controls.Add(this.Label_IssueCategory);
            this.Controls.Add(this.Label_RepairDuration);
            this.Controls.Add(this.Label_AcceptedTime);
            this.Controls.Add(this.Label_OutageEnded);
            this.Controls.Add(this.Label_RepairCompleted);
            this.Controls.Add(this.Label_IssueDescription);
            this.Controls.Add(this.Label_RepairStarted);
            this.EscClose = true;
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MF_QuickCreate";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "補單";
            this.TitleFont = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ZoomScaleRect = new System.Drawing.Rectangle(15, 15, 800, 450);
            this.Load += new System.EventHandler(this.QuickCreate_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Sunny.UI.UITextBox Engineers;
        private Sunny.UI.UILabel Label_Details;
        private Sunny.UI.UIRichTextBox Details;
        private Sunny.UI.UIRichTextBox IssueDescription;
        private Sunny.UI.UIComboBox IssueCategory;
        private Sunny.UI.UILabel Label_Creator;
        private Sunny.UI.UILabel Label_CreationDate;
        private Sunny.UI.UIComboBox MaintenanceUnit;
        private Sunny.UI.UILabel Label_RequestingUnit;
        private Sunny.UI.UILabel Label_MachineList;
        private Sunny.UI.UILabel Label_ModelWs;
        private Sunny.UI.UITextBox ModelWs;
        private Sunny.UI.UILabel Label_OutageStarted;
        private Sunny.UI.UITextBox OutageDuration;
        private Sunny.UI.UILabel Label_MaintenanceUnit;
        private Sunny.UI.UITextBox RepairDuration;
        private Sunny.UI.UILabel Label_Engineers;
        private Sunny.UI.UILabel Label_OutageDuration;
        private Sunny.UI.UILabel Label_IssueCategory;
        private Sunny.UI.UILabel Label_RepairDuration;
        private Sunny.UI.UILabel Label_AcceptedTime;
        private Sunny.UI.UILabel Label_OutageEnded;
        private Sunny.UI.UILabel Label_RepairCompleted;
        private Sunny.UI.UILabel Label_IssueDescription;
        private Sunny.UI.UILabel Label_RepairStarted;
        private Sunny.UI.UITextBox MachineCode;
        private Sunny.UI.UIComboBox RequestingUnit;
        private Sunny.UI.UITextBox Creator;
        private Sunny.UI.UISymbolButton btnCreate;
        private Sunny.UI.UISymbolButton btnCancel;
        private Sunny.UI.UITextBox Notification;
        private Sunny.UI.UILabel uiLabel1;
        private Core.WinForms.UIDurationDateTimePicker RepairStarted;
        private Core.WinForms.UIDurationDateTimePicker RepairCompleted;
        private Core.WinForms.UIDurationDateTimePicker OutageEnded;
        private Core.WinForms.UIDurationDateTimePicker OutageStarted;
        private Core.WinForms.UIDurationDateTimePicker AcceptedTime;
        private Core.WinForms.UIDurationDateTimePicker CreationDateTime;
    }
}