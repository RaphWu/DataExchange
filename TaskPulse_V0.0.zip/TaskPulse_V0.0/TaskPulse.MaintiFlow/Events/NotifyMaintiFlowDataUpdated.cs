﻿namespace Calin.TaskPulse.MaintiFlow.Events
{
    public class NotifyMaintiFlowDataUpdated
    {
        public static readonly NotifyMaintiFlowDataUpdated Instance = new NotifyMaintiFlowDataUpdated();
        private NotifyMaintiFlowDataUpdated() { }
    }
}
