﻿namespace Calin.TaskPulse.MaintiFlow.Events
{
    /// <summary>
    /// 維護資料庫更新訊息。
    /// </summary>
    public class RequestMaintiFlowDataUpdate
    {
        public static readonly RequestMaintiFlowDataUpdate Instance = new RequestMaintiFlowDataUpdate();
        private RequestMaintiFlowDataUpdate() { }
    }
}
