﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 員工清單。
    /// </summary>
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 工號。
        /// </summary>
        [Description("工號")]
        [Required, MaxLength(6)]
        [Index(IsUnique = true)]
        public string EmployeeId { get; set; }

        /// <summary>
        /// 姓名。
        /// </summary>
        [Description("姓名")]
        [Required]
        [MaxLength(20)]
        public string EmployeeName { get; set; }
        [NotMapped]
        public string FullName => string.Join(", ", new string[] { EmployeeId, DepartmentName, EmployeeName });

        /// <summary>
        /// 密碼。
        /// </summary>
        [Description("密碼")]
        [MaxLength(100)]
        public string PasswordHash { get; set; }

        /// <summary>
        /// 部門。
        /// </summary>
        [Description("部門")]
        public virtual Department Department { get; set; }
        public int? DepartmentId { get; set; } // FK
        [NotMapped]
        public string DepartmentName => Department?.DepartmentName ?? string.Empty;

        /// <summary>
        /// 職稱。
        /// </summary>
        [Description("職稱")]
        public virtual JobTitle JobTitle { get; set; }
        public int? JobTitleId { get; set; } // FK
        [NotMapped]
        public string JobTitleName => JobTitle?.JobTitleName ?? string.Empty;

        /// <summary>
        /// 電子郵件。
        /// </summary>
        [Description("Email")]
        public string Email { get; set; }

        /// <summary>
        /// 副本人員。
        /// </summary>
        [Description("副本人員")]
        public virtual ICollection<Employee> CarbonCopies { get; set; }
        public virtual ICollection<Employee> CarbonCopiedBy { get; set; }
        [NotMapped]
        public string CarbonCopyString => string.Join(", ", CarbonCopies.Select(e => e.EmployeeName));
        [NotMapped]
        public string CarbonCopyList => string.Join(Environment.NewLine, CarbonCopies.Select(e => e.EmployeeName));

        /// <summary>
        /// 是否為維護工程師。
        /// </summary>
        [Description("維護工程師")]
        public bool IsEngineer { get; set; } = false;
        [NotMapped]
        public string IsEngineerString => IsEngineer ? "是" : "";

        /// <summary>
        /// 在職/離職/調職...等狀態。
        /// </summary>
        [Description("狀態")]
        public EmployeeStatus Status { get; set; }
        public int StatusId { get; set; } // FK
        [NotMapped]
        public string StatusName => Status.StatusName;

        /// <summary>
        /// 狀態變更日期。
        /// </summary>
        [Description("日期")]
        public DateTime? StatusChangeAt { get; set; }
        [Description("日期")]
        [NotMapped]
        public bool StatusBoolean => StatusChangeAt.HasValue;
        [NotMapped]
        public string StatusChangeAtString
        {
            get => StatusChangeAt?.ToString("yyyy/MM/dd") ?? string.Empty;
            set => StatusChangeAt = (value != null && DateTime.TryParse(value, out var dt)) ? (DateTime?)dt : null;
        }

        //[MaxLength(512)]
        //public string SensitiveData { get; set; } // AES

        public virtual ICollection<TaskOrder> CreaterTaskOrders { get; set; }
        public virtual ICollection<TaskOrderEngineer> TaskOrderEngineers { get; set; }
        public virtual ICollection<TaskOrder> FeedbackEmployeeTaskOrders { get; set; }
        public virtual ICollection<Permission> Permissions { get; set; }
        public virtual ICollection<UserGroup> UserGroups { get; set; }

        public Employee()
        {
            Permissions = new HashSet<Permission>();
            UserGroups = new HashSet<UserGroup>();

            CreaterTaskOrders = new HashSet<TaskOrder>();
            TaskOrderEngineers = new HashSet<TaskOrderEngineer>();
            FeedbackEmployeeTaskOrders = new HashSet<TaskOrder>();

            CarbonCopies = new HashSet<Employee>();
            CarbonCopiedBy = new HashSet<Employee>();
        }
    }
}
