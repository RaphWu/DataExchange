﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.MaintiFlow;
using Calin.TaskPulse.MechaTrack;
using Calin.TaskPulse.ToolQuest;
using Calin.TaskPulse.Views;
using Serilog;

namespace Calin.TaskPulse
{
    internal static class Program
    {
        // P/Invoke 讓已存在程式跳到前景
        private static class NativeMethods
        {
            [DllImport("user32.dll")]
            public static extern bool SetForegroundWindow(IntPtr hWnd);

            [DllImport("user32.dll")]
            public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        }

        private static Mutex _mutex;

        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            _mutex = new Mutex(true, "Calin.TaskPulse.UniqueAppMutex", out bool createdNew);
            if (!createdNew)
            {
                // 找到現有程式，BringToFront
                var current = Process.GetCurrentProcess();
                var existing = Process.GetProcessesByName(current.ProcessName)
                                      .FirstOrDefault(p => p.Id != current.Id);
                if (existing != null)
                {
                    MessageBox.Show("程式已在執行中，將切換到已開啟的視窗。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    NativeMethods.ShowWindow(existing.MainWindowHandle, 5); // SW_SHOW
                    NativeMethods.SetForegroundWindow(existing.MainWindowHandle);
                }
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            MainForm mainForm = null;
            var splash = new SplashScreen();

            // 使用 SynchronizationContext 確保在 UI 執行緒上執行
            var uiContext = SynchronizationContext.Current;

            splash.Show();
            splash.Refresh();

            // 使用背景執行緒進行初始化
            var initTask = Task.Run(() =>
            {
                try
                {
                    SplashMessenger.Post("程式初始化開始...");

                    // DI註冊
                    var builder = new ContainerBuilder();

                    SplashMessenger.Post("註冊日誌服務...");
                    builder.RegisterInstance(Log.Logger).As<ILogger>().SingleInstance();

                    SplashMessenger.Post("註冊導航管理服務...");
                    builder.RegisterType<RegionManager>().As<IRegionManager>().SingleInstance();
                    builder.RegisterType<ViewManager>().As<IViewManager>().SingleInstance();
                    builder.RegisterType<NavigationService>().As<INavigationService>().SingleInstance();

                    builder.RegisterType<MainForm>();
                    builder.RegisterModule(new MaintiFlowModule());
                    builder.RegisterModule(new MechaTrackModule());
                    builder.RegisterModule(new ToolQuestMoudle());
                    builder.RegisterModule(new MainModule());
                    builder.RegisterModule(new CoreModule());

                    /* 因為目前EntityModule內容為空,所以先註解起來 */
                    // 因為Calin.TaskPulse.Entity位於最上層
                    // 所以呼叫不到SplashMessenger
                    // 故改在這裡呼叫
                    //SplashMessenger.Post("載入資料庫模組..."); 
                    //builder.RegisterModule(new EntityModule());

                    var container = builder.Build();

                    SplashMessenger.Post("初始化完成，準備啟動主畫面...");
                    Thread.Sleep(1200);

                    // 在 UI 執行緒上顯示主畫面
                    uiContext.Post(_ =>
                    {
                        try
                        {
                            mainForm = container.Resolve<MainForm>();
                            splash.Close();
                            mainForm.Show();
                            mainForm.Activate();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"啟動主畫面失敗: {ex.Message}\n\n堆疊追蹤:\n{ex.StackTrace}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Application.Exit();
                        }
                    }, null);
                }
                catch (Exception ex)
                {
                    SplashMessenger.Post("錯誤: " + ex.Message);
                    uiContext.Post(_ =>
                    {
                        MessageBox.Show($"初始化失敗: {ex.Message}\n\n堆疊追蹤:\n{ex.StackTrace}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        splash.Close();
                        Application.Exit();
                    }, null);
                }
            });

            // 新增：處理背景執行緒的未預期錯誤
            initTask.ContinueWith(t =>
            {
                if (t.IsFaulted)
                {
                    uiContext.Post(_ =>
                    {
                        MessageBox.Show($"背景初始化發生嚴重錯誤: {t.Exception?.GetBaseException().Message}\n\n堆疊追蹤:\n{t.Exception?.GetBaseException().StackTrace}",
                            "嚴重錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        splash?.Close();
                        Application.Exit();
                    }, null);
                }
            }, TaskScheduler.FromCurrentSynchronizationContext());

            // 啟動訊息迴圈
            Application.Run();
        }
    }
}
