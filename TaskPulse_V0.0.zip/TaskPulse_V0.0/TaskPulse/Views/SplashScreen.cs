﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Services;

namespace Calin.TaskPulse.Views
{
    public partial class SplashScreen : Form
    {
        private List<string> _msg = new List<string>();

        // Importing user32.dll to enable dragging the form without a title bar
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;

        public SplashScreen()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;

            // 啟用整個視窗的拖曳功能
            EnableDragging(this);
        }

        private void SplashScreen_Load(object sender, EventArgs e)
        {
            SplashMessenger.Initialize(SynchronizationContext.Current, msg => AddMessage(msg));
        }

        public void AddMessage(string msg)
        {
            _msg.Insert(0, msg);
            string displayMsg = string.Join(Environment.NewLine, _msg.Take(9).Reverse());

            if (msgList.InvokeRequired)
                msgList.Invoke(new Action(() => msgList.Text = displayMsg));
            else
                msgList.Text = displayMsg;
        }

        private void EnableDragging(Control control)
        {
            control.MouseDown += (s, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    ReleaseCapture();
                    SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                }
            };

            // 遞歸處理子控制項
            foreach (Control child in control.Controls)
            {
                EnableDragging(child);
            }
        }
    }
}
