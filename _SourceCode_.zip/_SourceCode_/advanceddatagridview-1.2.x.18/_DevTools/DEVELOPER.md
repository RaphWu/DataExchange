Developer documentation
===

## _DevTools

**_DevTools** folder is where  you can find all the automation building scripts.

## Git and configuration files

Do not write *personal* settings in files being commited. Instead use **Config Transformation**, add custom trasformation config files to override the main application config file.

## Questions

If you have questions please send a email the to the software author.