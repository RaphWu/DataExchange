﻿using Calin.Infrastructure.MessageSystem.Core;
using Calin.Infrastructure.MessageSystem.Presenter.Dialog;
using Calin.Infrastructure.MessageSystem.Presenter.Tip;
using Calin.Infrastructure.MessageSystem.Presenter.Toast;

namespace Calin.WinFormDemo_Net48
{
    public partial class View1 : UserControl
    {
        public View1()
        {
            InitializeComponent();
        }

        private void MD1_Click(object sender, EventArgs e)
        {
            var dialog = new MessageDialogPresenter();

            // 簡單訊息
            dialog.Show("操作已完成");

            // 帶標題的訊息
            dialog.Show("檔案已儲存成功", "儲存結果");

            // 帶圖示的訊息
            dialog.Show("請確認是否繼續？", "確認", MessageIcon.Question);

            // 便捷方法
            dialog.ShowInformation("這是資訊訊息");
            dialog.ShowWarning("這是警告訊息");
            dialog.ShowError("這是錯誤訊息");

            // 確認對話框
            var result = dialog.ShowConfirm("確定要刪除嗎？");
            if (result == DialogResultValue.Yes)
            {
                // 使用者點擊「是」
            }
        }

        private void MD2_Click(object sender, EventArgs e)
        {
            var dialog = new MessageDialogPresenter();

            // 使用預設按鈕集合
            var result1 = dialog.Show("內容", "標題", MessageIcon.Question, DialogButtonSet.YesNoCancel);

            // 建立自訂按鈕
            var customButtons = DialogButtonSet.Create(
                "儲存", DialogResultValue.Custom1,
                "不儲存", DialogResultValue.Custom2,
                "取消", DialogResultValue.Cancel);

            var result2 = dialog.Show("是否儲存變更？", "儲存", MessageIcon.Question, customButtons);

            switch (result2)
            {
                case DialogResultValue.Custom1:
                    // 儲存
                    break;
                case DialogResultValue.Custom2:
                    // 不儲存
                    break;
                case DialogResultValue.Cancel:
                    // 取消
                    break;
            }
        }

        private void MD3_Click(object sender, EventArgs e)
        {
            var dialog = new MessageDialogPresenter();

            var style = new MessageStyle
            {
                // 標題樣式
                TitleFont = new Font("Microsoft JhengHei", 12f, FontStyle.Bold),
                TitleForeColor = Color.White,
                TitleBackColor = Color.FromArgb(0, 122, 204),
                TitleHeight = 40,

                // 內容樣式
                ContentFont = new Font("Microsoft JhengHei", 10f),
                ContentForeColor = Color.Black,
                ContentBackColor = Color.White,

                // 按鈕樣式
                ButtonFont = new Font("Microsoft JhengHei", 9f),
                ButtonForeColor = Color.White,
                ButtonBackColor = Color.FromArgb(0, 122, 204),
                ButtonHoverBackColor = Color.FromArgb(0, 102, 184),
                ButtonAreaBackColor = Color.FromArgb(240, 240, 240),
                ButtonHeight = 32,
                ButtonSpacing = 10,

                // 佈局
                Padding = new Padding(20),
                Spacing = 15,
                MinWidth = 350,
                MaxWidth = 500,
                BorderColor = Color.FromArgb(0, 122, 204),
                BorderWidth = 2
            };

            dialog.Show("標題", "這是自訂樣式的對話框內容\n這是自訂樣式的對話框內容\n這是自訂樣式的對話框內容", MessageIcon.Information, DialogButtonSet.OK, style);
            dialog.Show("標題", "這是自訂樣式的對話框內容這是自訂樣式的對話框內容這是自訂樣式的對話框內容", MessageIcon.Information, DialogButtonSet.OK, style);
        }

        private void TM1_Click(object sender, EventArgs e)
        {
            // 設定全域預設樣式
            ToastManager.DefaultStyle = new MessageStyle
            {
                // 內容字體設定
                ContentFont = new Font("Microsoft JhengHei", 11f, FontStyle.Regular),

                // 內容顏色設定
                ContentBackColor = Color.FromArgb(40, 40, 40),
                ContentForeColor = Color.LightGreen,

                // 間距設定
                Padding = new Padding(20),
                Spacing = 10,

                // 尺寸限制
                MinWidth = 180,
                MaxWidth = 400
            };

            // 之後所有 Toast 都會使用此樣式
            ToastManager.ShowToast("使用全域樣式");
            ToastManager.ShowToast("這也是全域樣式", 5);

            // 重設為預設樣式
            ToastManager.ResetToDefaultStyle();
        }

        private void TM2_Click(object sender, EventArgs e)
        {
            // 建立成功樣式（綠色）
            var successStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 10f),
                ContentBackColor = Color.FromArgb(39, 174, 96),
                ContentForeColor = Color.White,
                Padding = new Padding(16),
                MinWidth = 150,
                MaxWidth = 350
            };

            // 建立錯誤樣式（紅色）
            var errorStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 10f, FontStyle.Bold),
                ContentBackColor = Color.FromArgb(192, 57, 43),
                ContentForeColor = Color.White,
                Padding = new Padding(16),
                MinWidth = 150,
                MaxWidth = 350
            };

            // 建立警告樣式（黃色）
            var warningStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 10f),
                ContentBackColor = Color.FromArgb(243, 156, 18),
                ContentForeColor = Color.Black,
                Padding = new Padding(16),
                MinWidth = 150,
                MaxWidth = 350
            };

            // 使用不同樣式顯示 Toast
            ToastManager.ShowToast("操作成功！", 3, successStyle);
            ToastManager.ShowToast("發生錯誤！", 5, errorStyle);
            ToastManager.ShowToast("請注意！", 4, warningStyle);
        }

        private void TM3_Click(object sender, EventArgs e)
        {
            // 大字體
            var largeStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 14f, FontStyle.Bold),
                ContentBackColor = Color.FromArgb(50, 50, 50),
                ContentForeColor = Color.White,
                Padding = new Padding(20),
                MinWidth = 200,
                MaxWidth = 400
            };

            // 小字體
            var smallStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 9f),
                ContentBackColor = Color.FromArgb(50, 50, 50),
                ContentForeColor = Color.LightGray,
                Padding = new Padding(12),
                MinWidth = 120,
                MaxWidth = 300
            };

            ToastManager.ShowToast("大字體通知", 3, largeStyle);
            ToastManager.ShowToast("小字體通知", 3, smallStyle);
        }

        private void MT1_Click(object sender, EventArgs e)
        {
            var tip = new MessageTipPresenter();

            // 在控制項下方顯示提示
            tip.ShowBelow(MT1, "請輸入有效的 Email");

            // 在控制項上方顯示提示
            tip.ShowAbove(MT2, "點擊送出表單");

            // 在控制項右側顯示提示
            tip.ShowLeft(MT3, "必填欄位");

            // 隱藏特定控制項的提示
            //tip.Hide(MT1);

            // 隱藏所有提示
            //tip.HideAll();
        }

        private void MT2_Click(object sender, EventArgs e)
        {
            var tip = new MessageTipPresenter();

            var errorTipStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 9f),
                ContentBackColor = Color.FromArgb(255, 200, 200),
                ContentForeColor = Color.DarkRed,
                Padding = new Padding(8),
                BorderColor = Color.Red,
                BorderWidth = 1,
                MinWidth = 100,
                MaxWidth = 250
            };

            tip.Show(MT2, "輸入格式錯誤", TipPosition.Above, 3, errorTipStyle, MessageIcon.Error);
        }

        private void MT3_Click(object sender, EventArgs e)
        {

        }
    }
}
