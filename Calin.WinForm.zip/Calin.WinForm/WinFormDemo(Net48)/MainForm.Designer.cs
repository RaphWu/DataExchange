﻿namespace Calin.WinFormDemo_Net48
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.FLP = new System.Windows.Forms.FlowLayoutPanel();
            this.RbView1 = new System.Windows.Forms.RadioButton();
            this.RbView2 = new System.Windows.Forms.RadioButton();
            this.RbView3 = new System.Windows.Forms.RadioButton();
            this.ContentPanel = new System.Windows.Forms.Panel();
            this.TLP.SuspendLayout();
            this.FLP.SuspendLayout();
            this.SuspendLayout();
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 1;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.TLP.Controls.Add(this.FLP, 0, 1);
            this.TLP.Controls.Add(this.ContentPanel, 0, 0);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 2;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.TLP.Size = new System.Drawing.Size(564, 299);
            this.TLP.TabIndex = 0;
            // 
            // FLP
            // 
            this.FLP.Controls.Add(this.RbView1);
            this.FLP.Controls.Add(this.RbView2);
            this.FLP.Controls.Add(this.RbView3);
            this.FLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FLP.Location = new System.Drawing.Point(3, 258);
            this.FLP.Name = "FLP";
            this.FLP.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.FLP.Size = new System.Drawing.Size(558, 38);
            this.FLP.TabIndex = 0;
            // 
            // RbView1
            // 
            this.RbView1.Appearance = System.Windows.Forms.Appearance.Button;
            this.RbView1.Checked = true;
            this.RbView1.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.RbView1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.RbView1.Location = new System.Drawing.Point(18, 3);
            this.RbView1.Name = "RbView1";
            this.RbView1.Size = new System.Drawing.Size(75, 30);
            this.RbView1.TabIndex = 0;
            this.RbView1.TabStop = true;
            this.RbView1.Text = "View1";
            this.RbView1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RbView1.UseVisualStyleBackColor = true;
            this.RbView1.Click += new System.EventHandler(this.RbView1_Click);
            // 
            // RbView2
            // 
            this.RbView2.Appearance = System.Windows.Forms.Appearance.Button;
            this.RbView2.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.RbView2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.RbView2.Location = new System.Drawing.Point(99, 3);
            this.RbView2.Name = "RbView2";
            this.RbView2.Size = new System.Drawing.Size(75, 30);
            this.RbView2.TabIndex = 1;
            this.RbView2.Text = "View2";
            this.RbView2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RbView2.UseVisualStyleBackColor = true;
            this.RbView2.Click += new System.EventHandler(this.RbView2_Click);
            // 
            // RbView3
            // 
            this.RbView3.Appearance = System.Windows.Forms.Appearance.Button;
            this.RbView3.FlatAppearance.CheckedBackColor = System.Drawing.Color.SandyBrown;
            this.RbView3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.RbView3.Location = new System.Drawing.Point(180, 3);
            this.RbView3.Name = "RbView3";
            this.RbView3.Size = new System.Drawing.Size(75, 30);
            this.RbView3.TabIndex = 2;
            this.RbView3.Text = "View3";
            this.RbView3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RbView3.UseVisualStyleBackColor = true;
            this.RbView3.Click += new System.EventHandler(this.RbView3_Click);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentPanel.Location = new System.Drawing.Point(3, 3);
            this.ContentPanel.Name = "ContentPanel";
            this.ContentPanel.Size = new System.Drawing.Size(558, 249);
            this.ContentPanel.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 299);
            this.Controls.Add(this.TLP);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.TLP.ResumeLayout(false);
            this.FLP.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private TableLayoutPanel TLP;
        private FlowLayoutPanel FLP;
        private RadioButton RbView1;
        private RadioButton RbView2;
        private RadioButton RbView3;
        private Panel ContentPanel;
    }
}
