using Autofac;
using Calin.Infrastructure;
using Calin.Infrastructure.Framework.Navigation;
using Calin.Infrastructure.MessageSystem.Presenter.Dialog;
using Calin.Infrastructure.MessageSystem.Presenter.Tip;

namespace Calin.WinFormDemo_Net48
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var builder = new ContainerBuilder();

            builder.RegisterModule<WinFormModule>();
            builder.RegisterModule<NavigationModule>();

            builder.RegisterType<MessageDialogPresenter>().AsSelf().SingleInstance();
            builder.RegisterType<MessageTipPresenter>().AsSelf().SingleInstance();

            // views
            builder.RegisterType<MainForm>().AsSelf().InstancePerDependency();
            builder.RegisterType<View1>().AsSelf().InstancePerDependency();
            builder.RegisterType<View2>().AsSelf().InstancePerDependency();
            builder.RegisterType<View3>().AsSelf().InstancePerDependency();

            var container = builder.Build();

            Application.Run(container.Resolve<MainForm>());
        }
    }
}