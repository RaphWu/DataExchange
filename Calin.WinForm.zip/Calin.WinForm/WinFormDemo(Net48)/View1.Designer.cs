﻿namespace Calin.WinFormDemo_Net48
{
    partial class View1
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.MT1 = new System.Windows.Forms.Button();
            this.MT2 = new System.Windows.Forms.Button();
            this.MT3 = new System.Windows.Forms.Button();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.TM1 = new System.Windows.Forms.Button();
            this.TM2 = new System.Windows.Forms.Button();
            this.TM3 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.MD1 = new System.Windows.Forms.Button();
            this.MD2 = new System.Windows.Forms.Button();
            this.MD3 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(479, 197);
            this.label1.TabIndex = 0;
            this.label1.Text = "View1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(479, 197);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.label4);
            this.flowLayoutPanel3.Controls.Add(this.MT1);
            this.flowLayoutPanel3.Controls.Add(this.MT2);
            this.flowLayoutPanel3.Controls.Add(this.MT3);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 133);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Padding = new System.Windows.Forms.Padding(20, 5, 0, 0);
            this.flowLayoutPanel3.Size = new System.Drawing.Size(473, 61);
            this.flowLayoutPanel3.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 20);
            this.label4.Margin = new System.Windows.Forms.Padding(3, 0, 9, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "提示訊息框 ";
            // 
            // MT1
            // 
            this.MT1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.MT1.Location = new System.Drawing.Point(105, 8);
            this.MT1.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.MT1.Name = "MT1";
            this.MT1.Size = new System.Drawing.Size(90, 40);
            this.MT1.TabIndex = 0;
            this.MT1.Text = "成功";
            this.MT1.UseVisualStyleBackColor = true;
            this.MT1.Click += new System.EventHandler(this.MT1_Click);
            // 
            // MT2
            // 
            this.MT2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.MT2.Location = new System.Drawing.Point(207, 8);
            this.MT2.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.MT2.Name = "MT2";
            this.MT2.Size = new System.Drawing.Size(90, 40);
            this.MT2.TabIndex = 1;
            this.MT2.Text = "警告";
            this.MT2.UseVisualStyleBackColor = true;
            this.MT2.Click += new System.EventHandler(this.MT2_Click);
            // 
            // MT3
            // 
            this.MT3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.MT3.Location = new System.Drawing.Point(309, 8);
            this.MT3.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.MT3.Name = "MT3";
            this.MT3.Size = new System.Drawing.Size(90, 40);
            this.MT3.TabIndex = 2;
            this.MT3.Text = "錯誤";
            this.MT3.UseVisualStyleBackColor = true;
            this.MT3.Click += new System.EventHandler(this.MT3_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.label3);
            this.flowLayoutPanel2.Controls.Add(this.TM1);
            this.flowLayoutPanel2.Controls.Add(this.TM2);
            this.flowLayoutPanel2.Controls.Add(this.TM3);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 68);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(20, 5, 0, 0);
            this.flowLayoutPanel2.Size = new System.Drawing.Size(473, 59);
            this.flowLayoutPanel2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 0, 9, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "土司訊息框";
            // 
            // TM1
            // 
            this.TM1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.TM1.Location = new System.Drawing.Point(102, 8);
            this.TM1.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.TM1.Name = "TM1";
            this.TM1.Size = new System.Drawing.Size(90, 40);
            this.TM1.TabIndex = 0;
            this.TM1.Text = "成功";
            this.TM1.UseVisualStyleBackColor = true;
            this.TM1.Click += new System.EventHandler(this.TM1_Click);
            // 
            // TM2
            // 
            this.TM2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.TM2.Location = new System.Drawing.Point(204, 8);
            this.TM2.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.TM2.Name = "TM2";
            this.TM2.Size = new System.Drawing.Size(90, 40);
            this.TM2.TabIndex = 1;
            this.TM2.Text = "警告";
            this.TM2.UseVisualStyleBackColor = true;
            this.TM2.Click += new System.EventHandler(this.TM2_Click);
            // 
            // TM3
            // 
            this.TM3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.TM3.Location = new System.Drawing.Point(306, 8);
            this.TM3.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.TM3.Name = "TM3";
            this.TM3.Size = new System.Drawing.Size(90, 40);
            this.TM3.TabIndex = 2;
            this.TM3.Text = "錯誤";
            this.TM3.UseVisualStyleBackColor = true;
            this.TM3.Click += new System.EventHandler(this.TM3_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.MD1);
            this.flowLayoutPanel1.Controls.Add(this.MD2);
            this.flowLayoutPanel1.Controls.Add(this.MD3);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(20, 5, 0, 0);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(473, 59);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(3, 0, 9, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "訊息對話框 ";
            // 
            // MD1
            // 
            this.MD1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.MD1.Location = new System.Drawing.Point(105, 8);
            this.MD1.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.MD1.Name = "MD1";
            this.MD1.Size = new System.Drawing.Size(90, 40);
            this.MD1.TabIndex = 0;
            this.MD1.Text = "成功";
            this.MD1.UseVisualStyleBackColor = true;
            this.MD1.Click += new System.EventHandler(this.MD1_Click);
            // 
            // MD2
            // 
            this.MD2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.MD2.Location = new System.Drawing.Point(207, 8);
            this.MD2.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.MD2.Name = "MD2";
            this.MD2.Size = new System.Drawing.Size(90, 40);
            this.MD2.TabIndex = 1;
            this.MD2.Text = "警告";
            this.MD2.UseVisualStyleBackColor = true;
            this.MD2.Click += new System.EventHandler(this.MD2_Click);
            // 
            // MD3
            // 
            this.MD3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.MD3.Location = new System.Drawing.Point(309, 8);
            this.MD3.Margin = new System.Windows.Forms.Padding(3, 3, 9, 3);
            this.MD3.Name = "MD3";
            this.MD3.Size = new System.Drawing.Size(90, 40);
            this.MD3.TabIndex = 2;
            this.MD3.Text = "錯誤";
            this.MD3.UseVisualStyleBackColor = true;
            this.MD3.Click += new System.EventHandler(this.MD3_Click);
            // 
            // View1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "View1";
            this.Size = new System.Drawing.Size(479, 197);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Label label1;
        private TableLayoutPanel tableLayoutPanel1;
        private FlowLayoutPanel flowLayoutPanel1;
        private Button MD1;
        private Button MD2;
        private Button MD3;
        private FlowLayoutPanel flowLayoutPanel3;
        private Label label4;
        private Button MT1;
        private Button MT2;
        private Button MT3;
        private FlowLayoutPanel flowLayoutPanel2;
        private Label label3;
        private Button TM1;
        private Button TM2;
        private Button TM3;
        private Label label2;
    }
}
