﻿namespace Calin.Infrastructure.Service
{
    public class WinFormService : IWinForm
    {
        #region fields

        private int _errCode = 0;
        private string _errMsg = "";
        private string _callerName = "";

        #endregion fields

        #region Properties

        public bool NoError => _errCode == 0;
        public bool HasError => _errCode != 0;
        public int ErrCode
        {
            get => _errCode;
            set
            {
                _errCode = value;

                if (value == 0)
                {
                    if (_errMsg.Length > 0)
                        _errMsg = "";
                }
                else
                {
                    //if (!Motion.mAcm_GetErrorMessage(value, _errMsg, MaxError))
                    //    _errMsg.Clear().Append($"無法取得錯誤代碼 0x{value:8X} 的訊息，請查閱手冊或詢問原廠。");
                }
            }
        }
        public string ErrMessage => _errMsg;
        public string ErrCallerName => _callerName;

        #endregion Properties

        #region Internal Methods

        /// <inheritdoc/>
        public void SetError(int errCode, string errMsg, string callerName = "")
        {
            _errCode = errCode;
            _errMsg = errMsg;
            _callerName = callerName.Length == 0 ? "" : callerName + "()";
        }

        /// <inheritdoc/>
        public void ClearErr()
        {
            _errCode = 0;

            if (_errMsg.Length > 0)
                _errMsg = "";

            if (_callerName.Length > 0)
                _callerName = "";
        }

        #endregion Internal Methods
    }
}
