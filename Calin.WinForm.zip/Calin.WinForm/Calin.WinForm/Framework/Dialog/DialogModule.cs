using Autofac;

namespace Calin.Infrastructure.Framework.Dialog
{
    /// <summary>
    /// ��ܮؼҲժ� Autofac ���U�C
    /// </summary>
    /// <remarks>
    /// <para>�� Module �t�d���U��ܮج������Ҧ��A�ȡC</para>
    /// <para>
    /// �ϥΤ覡�G
    /// <code>
    /// var builder = new ContainerBuilder();
    /// builder.RegisterModule&lt;DialogModule&gt;();
    /// var container = builder.Build();
    /// 
    /// // ���o�A��
    /// var dialogService = container.Resolve&lt;IDialogService&gt;();
    /// </code>
    /// </para>
    /// </remarks>
    public class DialogModule : Module
    {
        /// <summary>
        /// ���J�Ҳըõ��U�A�ȡC
        /// </summary>
        /// <param name="builder">�e���غc���C</param>
        protected override void Load(ContainerBuilder builder)
        {
            // ���U WinForms ��ܮص����u�t (SingleInstance)
            builder.RegisterType<WinFormsDialogWindowFactory>()
                .As<IDialogWindowFactory>()
                .SingleInstance();

            // ���U DialogService (SingleInstance)
            builder.RegisterType<DialogService>()
                .As<IDialogService>()
                .SingleInstance();
        }
    }
}
