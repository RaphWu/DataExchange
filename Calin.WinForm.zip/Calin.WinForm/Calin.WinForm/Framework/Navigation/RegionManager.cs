using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Calin.Infrastructure.Framework.Navigation
{
    /// <summary>
    /// Region �޲z��@�A�t�d�޲z�Ҧ� Region ���ͩR�g���P���U�C
    /// </summary>
    public class RegionManager : IRegionManager
    {
        private readonly ConcurrentDictionary<string, IRegion> _regions = new ConcurrentDictionary<string, IRegion>(StringComparer.OrdinalIgnoreCase);
        private bool _disposed;

        /// <summary>
        /// ��l�� RegionManager�C
        /// </summary>
        /// <param name="logger">��x�O�����C</param>
        public RegionManager()
        {
        }

        /// <inheritdoc />
        public IEnumerable<string> RegionNames => _regions.Keys.ToList();

        /// <inheritdoc />
        public IRegion RegisterRegion(string regionName, Action<object> activationHandler, Action<object> deactivationHandler = null)
        {
            if (string.IsNullOrEmpty(regionName))
                throw new ArgumentNullException(nameof(regionName));

            if (activationHandler == null)
                throw new ArgumentNullException(nameof(activationHandler));

            ThrowIfDisposed();

            if (_regions.ContainsKey(regionName))
            {
                throw new InvalidOperationException($"Region '{regionName}' �w�g���U�C");
            }

            var region = new Region(regionName)
            {
                ViewActivationHandler = activationHandler,
                ViewDeactivationHandler = deactivationHandler
            };

            if (!_regions.TryAdd(regionName, region))
            {
                throw new InvalidOperationException($"�L�k���U Region '{regionName}'�C");
            }

            return region;
        }

        /// <inheritdoc />
        public void UnregisterRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                throw new ArgumentNullException(nameof(regionName));

            ThrowIfDisposed();

            if (_regions.TryRemove(regionName, out var region))
            {
                region.Dispose();
            }
        }

        /// <inheritdoc />
        public IRegion GetRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                return null;

            _regions.TryGetValue(regionName, out var region);
            return region;
        }

        /// <inheritdoc />
        public bool ContainsRegion(string regionName)
        {
            if (string.IsNullOrEmpty(regionName))
                return false;

            return _regions.ContainsKey(regionName);
        }

        /// <inheritdoc />
        public int? GetActivePageId(string regionName)
        {
            var region = GetRegion(regionName);
            return region?.ActivePageId;
        }

        /// <inheritdoc />
        public IReadOnlyDictionary<string, int?> GetAllActivePageIds()
        {
            return _regions.ToDictionary(
                kvp => kvp.Key,
                kvp => kvp.Value.ActivePageId,
                StringComparer.OrdinalIgnoreCase);
        }

        /// <inheritdoc />
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// ����귽�C
        /// </summary>
        /// <param name="disposing">�O�_���b����C</param>
        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing)
            {
                foreach (var region in _regions.Values)
                {
                    region.Dispose();
                }
                _regions.Clear();
            }

            _disposed = true;
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
                throw new ObjectDisposedException(nameof(RegionManager));
        }
    }
}
