using Autofac;
using Calin.Infrastructure.MessageSystem.Presenter.Dialog;
using Calin.Infrastructure.MessageSystem.Presenter.Tip;

namespace Calin.Infrastructure.MessageSystem
{
    /// <summary>
    /// MessageSystem �� AutoFac �ҲաA���U�Ҧ��T���t�ΪA�ȡC
    /// </summary>
    public class MessageSystemModule : Module
    {
        /// <summary>
        /// ���U�A�ȡC
        /// </summary>
        protected override void Load(ContainerBuilder builder)
        {
            // ���U MessageDialogPresenter�]��ҡ^
            builder.RegisterType<MessageDialogPresenter>()
                .AsSelf()
                .SingleInstance();

            // ���U MessageTipPresenter�]��ҡ^
            builder.RegisterType<MessageTipPresenter>()
                .AsSelf()
                .SingleInstance();

            // ToastManager �O�R�A���O�A���ݭn���U
            // �ϥΤ覡�GToastManager.ShowToast(...)
        }
    }
}
