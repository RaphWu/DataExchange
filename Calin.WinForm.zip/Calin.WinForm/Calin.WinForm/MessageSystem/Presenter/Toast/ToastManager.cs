using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Calin.Infrastructure.MessageSystem.Core;

namespace Calin.Infrastructure.MessageSystem.Presenter.Toast
{
    /// <summary>
    /// Toast �޲z���A�t�d�ͩR�g���޲z�B���|�޲z�P��m�p��C
    /// </summary>
    /// <remarks>
    /// ���|�޿�G
    /// - Toast ���[�J���Ǧs��� _activeToasts�]���[�J���b�e�^
    /// - ��ı�W���[�J����ܦb�U��A��[�J�����|�b�W��
    /// - �����@ Toast �����ɡA���s�p��Ҧ� Toast ����m
    /// </remarks>
    public static class ToastManager
    {
        private static readonly List<ToastEntry> _activeToasts = new List<ToastEntry>();
        private static readonly object _lock = new object();

        private static MessageStyle _defaultStyle;

        private const int ToastMargin = 8;
        private const int ScreenMargin = 12;
        private const int DefaultDurationMs = 3000;

        /// <summary>
        /// ���o�γ]�w�w�]�˦��C
        /// </summary>
        public static MessageStyle DefaultStyle
        {
            get { return _defaultStyle ?? MessageStyle.CreateToastDefault(); }
            set { _defaultStyle = value; }
        }

        /// <summary>
        /// ��� Toast �q���]�ϥιw�]�˦��^�C
        /// </summary>
        /// <param name="message">��ܰT��</param>
        /// <param name="durationSeconds">��ܬ��ơ]�w�] 3 ���^</param>
        public static void ShowToast(string message, int durationSeconds = 3)
        {
            ShowToast(message, durationSeconds, DefaultStyle);
        }

        /// <summary>
        /// ��� Toast �q���]�ϥΦۭq�˦��^�C
        /// </summary>
        /// <param name="message">��ܰT��</param>
        /// <param name="durationSeconds">��ܬ���</param>
        /// <param name="style">�ۭq�˦�</param>
        public static void ShowToast(string message, int durationSeconds, MessageStyle style)
        {
            var durationMs = durationSeconds * 1000;
            if (durationMs <= 0)
            {
                durationMs = DefaultDurationMs;
            }

            var effectiveStyle = style ?? DefaultStyle;
            var entry = ToastEntry.Create(message, durationMs, effectiveStyle, OnEntryCloseRequested);

            lock (_lock)
            {
                _activeToasts.Add(entry);
                PositionToast(entry);
            }

            entry.Show();
        }

        private static void OnEntryCloseRequested(ToastEntry entry)
        {
            CloseToast(entry);
        }

        private static void CloseToast(ToastEntry entry)
        {
            lock (_lock)
            {
                if (!_activeToasts.Contains(entry))
                {
                    return;
                }

                _activeToasts.Remove(entry);
                entry.Close();

                RepositionAllToasts();
            }
        }

        private static void PositionToast(ToastEntry entry)
        {
            var workingArea = Screen.PrimaryScreen.WorkingArea;
            var x = workingArea.Right - entry.Width - ScreenMargin;
            var y = CalculateYPosition(workingArea, entry);

            entry.SetPosition(x, y);
        }

        private static int CalculateYPosition(System.Drawing.Rectangle workingArea, ToastEntry newEntry)
        {
            var bottomY = workingArea.Bottom - ScreenMargin;

            var occupiedHeight = 0;
            foreach (var existingEntry in _activeToasts)
            {
                if (existingEntry != newEntry)
                {
                    occupiedHeight += existingEntry.Height + ToastMargin;
                }
            }

            return bottomY - occupiedHeight - newEntry.Height;
        }

        /// <summary>
        /// ���s�ƦC�Ҧ� Toast ����m�C
        /// </summary>
        private static void RepositionAllToasts()
        {
            if (_activeToasts.Count == 0)
            {
                return;
            }

            var workingArea = Screen.PrimaryScreen.WorkingArea;
            var x = workingArea.Right - ScreenMargin;
            var currentY = workingArea.Bottom - ScreenMargin;

            foreach (var entry in _activeToasts)
            {
                currentY -= entry.Height;
                entry.SetPosition(x - entry.Width, currentY);
                currentY -= ToastMargin;
            }
        }

        /// <summary>
        /// �����Ҧ� Toast�]�Ѵ��թβM�z�Ρ^�C
        /// </summary>
        public static void CloseAll()
        {
            lock (_lock)
            {
                var entriesToClose = new List<ToastEntry>(_activeToasts);
                foreach (var entry in entriesToClose)
                {
                    entry.Close();
                }
                _activeToasts.Clear();
            }
        }

        /// <summary>
        /// ���]���w�]�˦��C
        /// </summary>
        public static void ResetToDefaultStyle()
        {
            _defaultStyle = null;
        }

        /// <summary>
        /// �ʸ� Toast �P������� Timer�A���ѲM�����ͩR�g���޲z�C
        /// </summary>
        private sealed class ToastEntry
        {
            private readonly ToastForm _form;
            private readonly Timer _timer;
            private readonly Action<ToastEntry> _onCloseRequested;
            private bool _isClosed;

            private ToastEntry(ToastForm form, Timer timer, Action<ToastEntry> onCloseRequested)
            {
                _form = form;
                _timer = timer;
                _onCloseRequested = onCloseRequested;
            }

            public int Width => _form.Width;
            public int Height => _form.ToastHeight;

            /// <summary>
            /// �إ� ToastEntry�]�u�t��k�A�T�O��l�Ƭy�{�@�P�^�C
            /// </summary>
            public static ToastEntry Create(string message, int durationMs, MessageStyle style, Action<ToastEntry> onCloseRequested)
            {
                var form = new ToastForm(message, style);
                var timer = new Timer { Interval = durationMs };

                var entry = new ToastEntry(form, timer, onCloseRequested);
                entry.Initialize();

                return entry;
            }

            /// <summary>
            /// ��l�ƨƥ�j�w�C
            /// </summary>
            private void Initialize()
            {
                _form.CloseRequested += OnFormCloseRequested;
                _timer.Tick += OnTimerTick;
            }

            /// <summary>
            /// �]�w��m�C
            /// </summary>
            public void SetPosition(int x, int y)
            {
                _form.SetPosition(x, y);
            }

            /// <summary>
            /// ��� Toast �ñҰʭp�ɾ��C
            /// </summary>
            public void Show()
            {
                _form.ShowWithoutFocus();
                _timer.Start();
            }

            /// <summary>
            /// ���� Toast ������귽�C
            /// </summary>
            public void Close()
            {
                if (_isClosed)
                {
                    return;
                }

                _isClosed = true;

                _timer.Stop();
                _timer.Dispose();

                _form.CloseRequested -= OnFormCloseRequested;
                _form.Close();
            }

            private void OnFormCloseRequested(object sender, EventArgs e)
            {
                _onCloseRequested?.Invoke(this);
            }

            private void OnTimerTick(object sender, EventArgs e)
            {
                _onCloseRequested?.Invoke(this);
            }
        }
    }
}
