using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Calin.Infrastructure.MessageSystem.Core;

namespace Calin.Infrastructure.MessageSystem.Presenter.Tip
{
    /// <summary>
    /// �T������ Presenter�A�t�d�b���������ܴ��ܰT���C
    /// </summary>
    public class MessageTipPresenter
    {
        private readonly Dictionary<Control, TipEntry> _activeTips = new Dictionary<Control, TipEntry>();
        private readonly object _lock = new object();
        private MessageStyle _defaultStyle;

        private const int DefaultDurationMs = 3000;
        private const int TipOffset = 5;

        /// <summary>
        /// ���o�γ]�w�w�]�˦��C
        /// </summary>
        public MessageStyle DefaultStyle
        {
            get { return _defaultStyle ?? MessageStyle.CreateMessageTipDefault(); }
            set { _defaultStyle = value; }
        }

        /// <summary>
        /// �b����U����ܴ��ܡC
        /// </summary>
        /// <param name="control">�ؼб��</param>
        /// <param name="content">���ܤ��e</param>
        /// <param name="durationSeconds">��ܬ��ơ]�w�] 3 ���^</param>
        public void ShowBelow(Control control, string content, int durationSeconds = 3)
        {
            Show(control, content, TipPosition.Below, durationSeconds, DefaultStyle, MessageIcon.None);
        }

        /// <summary>
        /// �b����W����ܴ��ܡC
        /// </summary>
        public void ShowAbove(Control control, string content, int durationSeconds = 3)
        {
            Show(control, content, TipPosition.Above, durationSeconds, DefaultStyle, MessageIcon.None);
        }

        /// <summary>
        /// �b����k����ܴ��ܡC
        /// </summary>
        public void ShowRight(Control control, string content, int durationSeconds = 3)
        {
            Show(control, content, TipPosition.Right, durationSeconds, DefaultStyle, MessageIcon.None);
        }

        /// <summary>
        /// �b���������ܴ��ܡC
        /// </summary>
        public void ShowLeft(Control control, string content, int durationSeconds = 3)
        {
            Show(control, content, TipPosition.Left, durationSeconds, DefaultStyle, MessageIcon.None);
        }

        /// <summary>
        /// ��ܴ��ܡ]����Ѽơ^�C
        /// </summary>
        public void Show(
            Control control,
            string content,
            TipPosition position,
            int durationSeconds,
            MessageStyle style,
            MessageIcon icon)
        {
            if (control == null)
            {
                throw new ArgumentNullException(nameof(control));
            }

            var durationMs = durationSeconds * 1000;
            if (durationMs <= 0)
            {
                durationMs = DefaultDurationMs;
            }

            var effectiveStyle = style ?? DefaultStyle;

            // �������ӱ�����{������
            Hide(control);

            var form = new MessageTipForm(content, effectiveStyle, icon);
            var timer = new Timer { Interval = durationMs };

            var entry = new TipEntry(form, timer, control);

            form.CloseRequested += (s, e) => CloseTip(control);
            timer.Tick += (s, e) => CloseTip(control);

            // �p���m
            var screenPoint = control.PointToScreen(Point.Empty);
            var tipLocation = CalculatePosition(screenPoint, control.Size, form.Size, position);
            form.SetPosition(tipLocation.X, tipLocation.Y);

            lock (_lock)
            {
                _activeTips[control] = entry;
            }

            form.ShowWithoutFocus();
            timer.Start();
        }

        /// <summary>
        /// ���ë��w��������ܡC
        /// </summary>
        public void Hide(Control control)
        {
            if (control == null)
            {
                return;
            }

            CloseTip(control);
        }

        /// <summary>
        /// ���éҦ����ܡC
        /// </summary>
        public void HideAll()
        {
            lock (_lock)
            {
                var controls = new List<Control>(_activeTips.Keys);
                foreach (var control in controls)
                {
                    CloseTipInternal(control);
                }
            }
        }

        private void CloseTip(Control control)
        {
            lock (_lock)
            {
                CloseTipInternal(control);
            }
        }

        private void CloseTipInternal(Control control)
        {
            if (!_activeTips.TryGetValue(control, out var entry))
            {
                return;
            }

            _activeTips.Remove(control);
            entry.Close();
        }

        private Point CalculatePosition(Point screenPoint, Size controlSize, Size tipSize, TipPosition position)
        {
            int x, y;

            switch (position)
            {
                case TipPosition.Above:
                    x = screenPoint.X + (controlSize.Width - tipSize.Width) / 2;
                    y = screenPoint.Y - tipSize.Height - TipOffset;
                    break;

                case TipPosition.Below:
                    x = screenPoint.X + (controlSize.Width - tipSize.Width) / 2;
                    y = screenPoint.Y + controlSize.Height + TipOffset;
                    break;

                case TipPosition.Left:
                    x = screenPoint.X - tipSize.Width - TipOffset;
                    y = screenPoint.Y + (controlSize.Height - tipSize.Height) / 2;
                    break;

                case TipPosition.Right:
                    x = screenPoint.X + controlSize.Width + TipOffset;
                    y = screenPoint.Y + (controlSize.Height - tipSize.Height) / 2;
                    break;

                default:
                    x = screenPoint.X;
                    y = screenPoint.Y + controlSize.Height + TipOffset;
                    break;
            }

            // �T�O�b�ù��d��
            var screen = Screen.FromPoint(screenPoint);
            var workingArea = screen.WorkingArea;

            if (x < workingArea.Left)
            {
                x = workingArea.Left;
            }
            else if (x + tipSize.Width > workingArea.Right)
            {
                x = workingArea.Right - tipSize.Width;
            }

            if (y < workingArea.Top)
            {
                y = workingArea.Top;
            }
            else if (y + tipSize.Height > workingArea.Bottom)
            {
                y = workingArea.Bottom - tipSize.Height;
            }

            return new Point(x, y);
        }

        /// <summary>
        /// ���]���w�]�˦��C
        /// </summary>
        public void ResetToDefaultStyle()
        {
            _defaultStyle = null;
        }

        /// <summary>
        /// ���ܶ��ثʸˡC
        /// </summary>
        private sealed class TipEntry
        {
            private readonly MessageTipForm _form;
            private readonly Timer _timer;
            private readonly Control _control;
            private bool _isClosed;

            public TipEntry(MessageTipForm form, Timer timer, Control control)
            {
                _form = form;
                _timer = timer;
                _control = control;
            }

            public void Close()
            {
                if (_isClosed)
                {
                    return;
                }

                _isClosed = true;

                _timer.Stop();
                _timer.Dispose();
                _form.Close();
            }
        }
    }

    /// <summary>
    /// ���ܦ�m�C
    /// </summary>
    public enum TipPosition
    {
        /// <summary>
        /// ����W��C
        /// </summary>
        Above,

        /// <summary>
        /// ����U��C
        /// </summary>
        Below,

        /// <summary>
        /// ��������C
        /// </summary>
        Left,

        /// <summary>
        /// ����k���C
        /// </summary>
        Right
    }
}
