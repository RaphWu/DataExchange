using System;
using System.Drawing;
using System.Windows.Forms;
using Calin.Infrastructure.MessageSystem.Core;

namespace Calin.Infrastructure.MessageSystem.Presenter.Tip
{
    /// <summary>
    /// �T�����ܵ����]���� ToolTip�A���i�ۭq�˦��^�C
    /// </summary>
    internal class MessageTipForm : Form
    {
        private readonly string _content;
        private readonly MessageStyle _style;
        private readonly MessageLayoutResult _layout;
        private readonly MessageIcon _icon;

        // Windows API �`��
        private const int WS_EX_NOACTIVATE = 0x08000000;
        private const int WS_EX_TOOLWINDOW = 0x00000080;
        private const int WS_EX_TOPMOST = 0x00000008;
        private const int WM_MOUSEACTIVATE = 0x0021;
        private const int MA_NOACTIVATE = 0x0003;

        /// <summary>
        /// ���ݭn������Ĳ�o�C
        /// </summary>
        public event EventHandler CloseRequested;

        /// <summary>
        /// �إ߰T�����ܵ����C
        /// </summary>
        public MessageTipForm(string content, MessageStyle style, MessageIcon icon)
        {
            _content = content ?? string.Empty;
            _style = style ?? MessageStyle.CreateMessageTipDefault();
            _icon = icon ?? MessageIcon.None;

            _layout = MessageLayoutEngine.CalculateFull(_style, null, _content, _icon, null);

            InitializeForm();
        }

        /// <summary>
        /// ���o���ܵ������סC
        /// </summary>
        public int TipHeight => Height;

        /// <summary>
        /// �]�w��ܦ�m�C
        /// </summary>
        public void SetPosition(int x, int y)
        {
            Location = new Point(x, y);
        }

        /// <summary>
        /// ��ܡ]���m�J�I�^�C
        /// </summary>
        public void ShowWithoutFocus()
        {
            Show();
        }

        private void InitializeForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = _style.ContentBackColor;
            Size = _layout.TotalSize;

            SetStyle(ControlStyles.Selectable, false);

            Click += OnFormClick;
            Shown += OnFormShown;
        }

        private void OnFormShown(object sender, EventArgs e)
        {
            // �Y�Ǳ��ҡ]�Ҧp WS_EX_NOACTIVATE + �ֳt���/�����^�i�ण�|�ߧYĲ�o������ø�C
            // �j��w�Ƥ@����ø�A�T�O��r�P Icon �@�w�|�Q�e�X�C
            Invalidate();
            Update();
        }

        private void OnFormClick(object sender, EventArgs e)
        {
            CloseRequested?.Invoke(this, EventArgs.Empty);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;

            // ø�s�I��
            using (var brush = new SolidBrush(_style.ContentBackColor))
            {
                g.FillRectangle(brush, ClientRectangle);
            }

            // ø�s�ϥ�
            if (_layout.HasIcon)
            {
                var iconImage = _icon.GetImage();
                if (iconImage != null)
                {
                    g.DrawImage(iconImage, _layout.IconBounds);
                }
            }

            // ø�s���e��r
            TextRenderer.DrawText(
                g,
                _content,
                _style.ContentFont,
                _layout.ContentBounds,
                _style.ContentForeColor,
                MessageLayoutEngine.GetTextFormatFlags());

            // ø�s���
            if (_style.BorderWidth > 0)
            {
                using (var pen = new Pen(_style.BorderColor, _style.BorderWidth))
                {
                    g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
                }
            }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                cp.ExStyle |= WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW | WS_EX_TOPMOST;
                return cp;
            }
        }

        protected override bool ShowWithoutActivation => true;

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_MOUSEACTIVATE)
            {
                m.Result = (IntPtr)MA_NOACTIVATE;
                return;
            }

            base.WndProc(ref m);
        }
    }
}
