using System.Drawing;
using System.Windows.Forms;
using Calin.Infrastructure.MessageSystem.Core;
using Calin.Infrastructure.MessageSystem.Presenter.Dialog;
using Calin.Infrastructure.MessageSystem.Presenter.Tip;
using Calin.Infrastructure.MessageSystem.Presenter.Toast;

namespace Calin.Infrastructure.MessageSystem.Examples
{
    /// <summary>
    /// MessageSystem �ϥνd�ҡ]�ȨѰѦҡ^�C
    /// </summary>
    internal static class MessageSystemUsageExamples
    {
        #region Toast �d��

        /// <summary>
        /// Toast �򥻨ϥνd�ҡC
        /// </summary>
        public static void ToastBasicUsage()
        {
            // ��ܹw�] 3 ���� Toast
            ToastManager.ShowToast("�ާ@���\�I");

            // ��ܫ��w���ƪ� Toast
            ToastManager.ShowToast("�ɮפw�x�s", 5);

            // �s����ܦh�� Toast�]�|�۰ʩ��W���|�^
            ToastManager.ShowToast("�Ĥ@�h�q��", 4);
            ToastManager.ShowToast("�ĤG�h�q��", 4);
            ToastManager.ShowToast("�ĤT�h�q��", 4);

            // �����Ҧ� Toast
            ToastManager.CloseAll();
        }

        /// <summary>
        /// Toast �ۭq�˦��d�ҡC
        /// </summary>
        public static void ToastCustomStyleExample()
        {
            // ���\�˦��]���^
            var successStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 10f),
                ContentBackColor = Color.FromArgb(39, 174, 96),
                ContentForeColor = Color.White,
                Padding = new Padding(16),
                MinWidth = 150,
                MaxWidth = 350
            };

            // ���~�˦��]����^
            var errorStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 10f, FontStyle.Bold),
                ContentBackColor = Color.FromArgb(192, 57, 43),
                ContentForeColor = Color.White,
                Padding = new Padding(16),
                MinWidth = 150,
                MaxWidth = 350
            };

            // ĵ�i�˦��]����^
            var warningStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 10f),
                ContentBackColor = Color.FromArgb(243, 156, 18),
                ContentForeColor = Color.Black,
                Padding = new Padding(16),
                MinWidth = 150,
                MaxWidth = 350
            };

            ToastManager.ShowToast("�ާ@���\�I", 3, successStyle);
            ToastManager.ShowToast("�o�Ϳ��~�I", 5, errorStyle);
            ToastManager.ShowToast("�Ъ`�N�I", 4, warningStyle);
        }

        /// <summary>
        /// Toast ����˦��]�w�d�ҡC
        /// </summary>
        public static void ToastGlobalStyleExample()
        {
            ToastManager.DefaultStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 11f),
                ContentBackColor = Color.FromArgb(40, 40, 40),
                ContentForeColor = Color.LightGreen,
                Padding = new Padding(20),
                MinWidth = 180,
                MaxWidth = 400
            };

            ToastManager.ShowToast("�ϥΥ���˦�");
            ToastManager.ResetToDefaultStyle();
        }

        #endregion

        #region Dialog �d��

        /// <summary>
        /// Dialog �򥻨ϥνd�ҡC
        /// </summary>
        public static void DialogBasicUsage()
        {
            var dialog = new MessageDialogPresenter();

            // ²��T��
            dialog.Show("�ާ@�w����");

            // �a���D���T��
            dialog.Show("�ɮפw�x�s���\", "�x�s���G");

            // �a�ϥܪ��T��
            dialog.Show("�нT�{�O�_�~��H", "�T�{", MessageIcon.Question);

            // �K����k
            dialog.ShowInformation("�o�O��T�T��");
            dialog.ShowWarning("�o�Oĵ�i�T��");
            dialog.ShowError("�o�O���~�T��");

            // �T�{��ܮ�
            var result = dialog.ShowConfirm("�T�w�n�R���ܡH");
            if (result == DialogResultValue.Yes)
            {
                // �ϥΪ��I���u�O�v
            }
        }

        /// <summary>
        /// DialogButtonSet �ϥνd�ҡC
        /// </summary>
        public static void DialogButtonSetExample()
        {
            var dialog = new MessageDialogPresenter();

            // �ϥιw�]���s���X
            var result1 = dialog.Show("���e", "���D", MessageIcon.Question, DialogButtonSet.YesNoCancel);

            // �إߦۭq���s
            var customButtons = DialogButtonSet.Create(
                "�x�s", DialogResultValue.Custom1,
                "���x�s", DialogResultValue.Custom2,
                "����", DialogResultValue.Cancel);

            var result2 = dialog.Show("�O�_�x�s�ܧ�H", "�x�s", MessageIcon.Question, customButtons);

            switch (result2)
            {
                case DialogResultValue.Custom1:
                    // �x�s
                    break;
                case DialogResultValue.Custom2:
                    // ���x�s
                    break;
                case DialogResultValue.Cancel:
                    // ����
                    break;
            }
        }

        /// <summary>
        /// �ۭq���s�˦��d�ҡC
        /// </summary>
        public static void DialogCustomButtonStyleExample()
        {
            var dialog = new MessageDialogPresenter();

            var buttonSet = new DialogButtonSet();

            buttonSet.Add(new DialogButtonDefinition("�T�w", DialogResultValue.OK)
            {
                IsDefault = true,
                Font = new Font("Microsoft JhengHei", 10f, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(0, 122, 204),
                MinWidth = 100
            });

            buttonSet.Add(new DialogButtonDefinition("����", DialogResultValue.Cancel)
            {
                IsCancel = true,
                Font = new Font("Microsoft JhengHei", 10f),
                ForeColor = Color.Black,
                BackColor = Color.FromArgb(230, 230, 230)
            });

            dialog.Show("�T�w�n����ܡH", "�T�{", MessageIcon.Question, buttonSet);
        }

        /// <summary>
        /// �ۭq��ܮؼ˦��d�ҡC
        /// </summary>
        public static void DialogCustomStyleExample()
        {
            var dialog = new MessageDialogPresenter();

            var style = new MessageStyle
            {
                // ���D�˦�
                TitleFont = new Font("Microsoft JhengHei", 12f, FontStyle.Bold),
                TitleForeColor = Color.White,
                TitleBackColor = Color.FromArgb(0, 122, 204),
                TitleHeight = 40,

                // ���e�˦�
                ContentFont = new Font("Microsoft JhengHei", 10f),
                ContentForeColor = Color.Black,
                ContentBackColor = Color.White,

                // ���s�˦�
                ButtonFont = new Font("Microsoft JhengHei", 9f),
                ButtonForeColor = Color.White,
                ButtonBackColor = Color.FromArgb(0, 122, 204),
                ButtonHoverBackColor = Color.FromArgb(0, 102, 184),
                ButtonAreaBackColor = Color.FromArgb(240, 240, 240),
                ButtonHeight = 32,
                ButtonSpacing = 10,

                // �G��
                Padding = new Padding(20),
                Spacing = 15,
                MinWidth = 350,
                MaxWidth = 500,
                BorderColor = Color.FromArgb(0, 122, 204),
                BorderWidth = 2
            };

            dialog.Show("���D", "�o�O�ۭq�˦�����ܮؤ��e", MessageIcon.Information, DialogButtonSet.OK, style);
        }

        #endregion

        #region MessageTip �d��

        /// <summary>
        /// MessageTip �򥻨ϥνd�ҡC
        /// </summary>
        public static void MessageTipBasicUsage(Control textBox, Control button, Control label)
        {
            var tip = new MessageTipPresenter();

            // �b����U����ܴ���
            tip.ShowBelow(textBox, "�п�J���Ī� Email");

            // �b����W����ܴ���
            tip.ShowAbove(button, "�I���e�X����");

            // �b����k����ܴ���
            tip.ShowRight(label, "�������");

            // ���ïS�w���������
            tip.Hide(textBox);

            // ���éҦ�����
            tip.HideAll();
        }

        /// <summary>
        /// MessageTip �ۭq�˦��d�ҡC
        /// </summary>
        public static void MessageTipCustomStyleExample(Control textBox)
        {
            var tip = new MessageTipPresenter();

            var errorTipStyle = new MessageStyle
            {
                ContentFont = new Font("Microsoft JhengHei", 9f),
                ContentBackColor = Color.FromArgb(255, 200, 200),
                ContentForeColor = Color.DarkRed,
                Padding = new Padding(8),
                BorderColor = Color.Red,
                BorderWidth = 1,
                MinWidth = 100,
                MaxWidth = 250
            };

            tip.Show(textBox, "��J�榡���~", TipPosition.Below, 5, errorTipStyle, MessageIcon.Error);
        }

        #endregion
    }
}

