﻿using Autofac;
using Calin.Infrastructure.Service;

namespace Calin.Infrastructure
{
    public class WinFormModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // Modules

            // services
            builder.RegisterType<WinFormService>().As<IWinForm>().SingleInstance();
        }
    }
}
