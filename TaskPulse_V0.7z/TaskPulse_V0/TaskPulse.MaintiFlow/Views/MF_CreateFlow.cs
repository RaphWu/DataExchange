﻿/*
 * 工程師開單 vs 線上人員開單分開。
 * 
 */

using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.WinForms;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MF_CreateFlow : UIForm
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly IMail _mail;
        private readonly CoreData _coreData;
        private readonly CurrentUserContext _user;
        private readonly MultiSelector _mSel;

        private string _todayPrefix;
        private int _lastWorkOrderNo;

        // ResultList Buffser
        private ClassifyInfo _defaultCreator = new ClassifyInfo();
        private List<ClassifyInfo> _defaultMachine = new List<ClassifyInfo>();
        private ClassifyInfo _defaultModelWs = new ClassifyInfo();

        #endregion fields

        /// <summary>
        /// 標題。
        /// </summary>
        public string Title { set => Text = value; }

        /// <summary>
        /// 新建工單的工單號。
        /// </summary>
        public List<TaskOrder> NewWorkOrderNos { get; set; } = new List<TaskOrder>();

        public MF_CreateFlow(
            Serilog.ILogger logger,
            CoreContext CoreContext,
            ICore core,
            IMail mail,
            CoreData coreData,
            CurrentUserContext currentUserContext,
            MultiSelector multiSelector)
        {
            InitializeComponent();
            _logger = logger;
            _context = CoreContext;
            _core = core;
            _mail = mail;
            _coreData = coreData;
            _user = currentUserContext;
            _mSel = multiSelector;

            //var modelList = _coreData.Models
            //    .Select(m => new ListViewModel()
            //    {
            //        Id = m.Id,
            //        Name = m.ModelName
            //    })
            //    .ToList();
            //modelList.Insert(0, new ListViewModel() { Id = 0, Name = "" });
            //ModelWs.DataSource = modelList;
            //ModelWs.DisplayMember = "Name";
            //ModelWs.ValueMember = "Id";

            var rUnitList = _context.Departments
                .OrderBy(r => r.OrderNo)
                .Select(r => new ListViewModel { Id = r.Id, Name = r.DepartmentName, })
                .ToList();
            RequestingUnit.DataSource = rUnitList;
            RequestingUnit.DisplayMember = "Name";
            RequestingUnit.ValueMember = "Id";

            CommonStyles.SetButton(btnCreate);
            CommonStyles.SetButton(btnCancel, isCancel: true);
            //CommonStyles.SetCheckBox(OutageStartedAvailable);

            this.AcceptButton = btnCreate;
            this.CancelButton = btnCancel;
        }

        private void CreateFlow_Load(object sender, EventArgs e)
        {
            string caption;

            caption = PropertyText.Title.RequestingUnit;
            lblRequestingUnit.Text = caption;
            RequestingUnit.SelectedValue = _user.IsAdmin ? -1 : _user.CurrentUser.DepartmentId;
            RequestingUnit.Watermark = caption;

            caption = PropertyText.Title.Creator;
            lblCreator.Text = caption;
            Creator.Watermark = caption;
            Creator.ButtonFillColor = CommonStyles.BackColor;
            Creator.ButtonFillHoverColor = CommonStyles.HoverColor;
            _defaultCreator = new ClassifyInfo(_user.CurrentUser);
            Creator.Text = _defaultCreator.JobTitle_Id_Name();

            caption = PropertyText.Title.Machine;
            lblMachineList.Text = caption;
            MachineList.Watermark = caption;
            MachineList.ButtonFillColor = CommonStyles.BackColor;
            MachineList.ButtonFillHoverColor = CommonStyles.HoverColor;

            caption = PropertyText.Title.ModelWsName;
            lblModel.Text = caption;
            ModelWs.Watermark = caption;

            caption = PropertyText.Title.OutageStarted;
            Label_OutageStarted.Text = caption;
            OutageStarted.Watermark = caption;
            OutageStarted.Text = "";
            //OutageStartedAvailable.Checked = false;

            caption = PropertyText.Title.MaintiFlowIssueDescription;
            Label_IssueDescription.Text = caption;
        }

        private void CreateFlow_Shown(object sender, EventArgs e)
        {
            SunnyUiHelper.AdjustFormLayout(this, TLP);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private async void btnCreate_Click(object sender, EventArgs ea)
        {
            // 拆解機台編號
            var machineList = MachineList.Text
                .Split(new char[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .ToList();

            var creator = _coreData.Employees.FirstOrDefault(c => c.EmployeeName == (string)Creator.Tag);

            // 錯誤檢查
            StringBuilder err = new StringBuilder();

            if (string.IsNullOrWhiteSpace(RequestingUnit.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.RequestingUnit}！");

            if (string.IsNullOrWhiteSpace(Creator.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.Creator}！");
            else if (creator == null)
                err.AppendLine($"查無此人：{Creator.Text}！");

            if (string.IsNullOrWhiteSpace(MachineList.Text))
            {
                err.AppendLine($"沒有輸入 {PropertyText.Title.Machine}！");
            }
            else
            {
                foreach (var mId in machineList)
                    if (_coreData.Machines.FindIndex(x => x.MachineCode == mId) == -1)
                        err.AppendLine($"{PropertyText.Title.Machine}不存在: {mId}");
            }

            if (string.IsNullOrWhiteSpace(ModelWs.Text))
                err.AppendLine($"沒有輸入 {PropertyText.Title.ModelWsName}！");

            ////if (OutageStartedAvailable.Checked && string.IsNullOrEmpty(OutageStarted.Text))
            //if (string.IsNullOrEmpty(OutageStarted.Text))
            //    err.AppendLine($"沒有輸入 {PropertyText.Title.OutageStarted}！");

            if (err.Length > 0)
            {
                err.Append("\n注意：資料尚未儲存！");
                MessageBox.Show(err.ToString(),
                    "輸入資料不正確",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            try
            {
                var deviceList = new List<Machine>();

                // 計算新工單號
                _todayPrefix = DateTime.Today.ToString("yyyyMMdd");
                var tos = _context.TaskOrders;
                _lastWorkOrderNo = tos
                    .Where(o => o.WorkOrderNo.StartsWith(_todayPrefix))
                    .Select(w => w.WorkOrderNo)
                    .AsEnumerable()
                    .Select(o => int.TryParse(o.Substring(8, 3), out int val) ? val : 0)
                    .DefaultIfEmpty(0)
                    .Max();

                // 加入資料庫
                int rUnitId = (int)RequestingUnit.SelectedValue;

                NewWorkOrderNos.Clear();
                for (int no = 1; no <= machineList.Count; no++)
                {
                    string newWorkOrderNo = $"{_todayPrefix}{(_lastWorkOrderNo + no):D3}";
                    string machineId = machineList[no - 1];
                    var to = new TaskOrder()
                    {
                        WorkOrderNo = newWorkOrderNo,
                        CreationDateTime = DateTime.Now,
                        Machine = _context.Machines.FirstOrDefault(x => x.MachineCode == machineId),
                        IssueDescription = IssueDescription.Text,

                        CreatorId = creator.Id,
                        Engineers = null,
                        Status = FlowStatus.NewTaskOrder,
                        AcceptedTime = null,
                        RequestingUnitId = rUnitId,
                        FeedbackEmployeeId = creator.Id,

                        //OutageStarted = OutageStartedAvailable.Checked
                        //    ? (DateTime?)OutageStarted.Value
                        //    : null,
                        OutageStarted = string.IsNullOrEmpty(OutageStarted.Text)
                            ? (DateTime?)null
                            : DateTime.Parse(OutageStarted.Text),

                        WorkstationId = 0,
                        MaintenanceUnitId = 0,
                        IssueCategoryId = 0,
                        Details = "",
                        Feedback = "",
                        Responsible = "",
                    };
                    var ws = to.GetWorkstationId(ModelWs.Text, _context);
                    to.WorkstationId = _context.Workstations.FirstOrDefault(w => w.Id == ws).Id;

                    _context.TaskOrders.Add(to);
                    NewWorkOrderNos.Add(to);
                }
                await _context.SaveChangesAsync();
                _ = WeakReferenceMessenger.Default.Send(RequestTaskOrderDataUpdate.Instance);
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("資料已儲存。"));

                // send email
                StringBuilder mail = new StringBuilder();
                mail.Append("<table><caption>新建工單</caption>");

                var ruId = NewWorkOrderNos[0].RequestingUnitId;
                mail.Append("<tr>");
                mail.Append("<td>需求單位</td>");
                mail.Append($"<td>{_context.Departments.FirstOrDefault(r => r.Id == ruId).DepartmentName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>工單建立者</td>");
                mail.Append($"<td>{creator.EmployeeName}</td>");
                mail.Append("</tr>");

                List<string> oms = new List<string>();
                foreach (var wo in NewWorkOrderNos)
                    oms.Add($"{wo.WorkOrderNo}: {wo.FullMachineName}");

                mail.Append("<tr>");
                mail.Append("<td>新增工單</td>");
                mail.Append($"<td>{string.Join("<br/>", oms)}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>機種</td>");
                mail.Append($"<td>{ModelWs.Text}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>建立時間</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].CreationDateString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動時間</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].OutageStartedString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>問題描述</td>");
                mail.Append($"<td>{NewWorkOrderNos[0].IssueDescription}</td>");
                mail.Append("</tr>");
                mail.Append("</table>");

                var mailList = new HashSet<int>() { creator.Id };

                var maintenanceHead = _coreData.Employees.FirstOrDefault(e => e.EmployeeName == "蔡孟堅");
                if (maintenanceHead != null)
                    mailList.Add(maintenanceHead.Id);
                var programmer = _coreData.Employees.FirstOrDefault(e => e.EmployeeName == "吳仁中");
                if (programmer != null)
                    mailList.Add(programmer.Id);

                _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                               $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][新建工單] {creator.EmployeeName} 新建 {NewWorkOrderNos.Count} 張維護工單。",
                               mail.ToString());

                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    foreach (var ve in eve.ValidationErrors)
                    {
                        _logger.Fatal("Validation error in {Entity}.{Property}: {ErrorMessage}",
                            eve.Entry.Entity.GetType().Name,
                            ve.PropertyName,
                            ve.ErrorMessage);
                    }
                }

                throw;
            }
            catch (Exception ex)
            {
                _logger.Fatal(ex, "建立維護工單失敗");
                MessageBox.Show(ex.ToString());
            }
        }

        private void Creator_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultCreator };
            _mSel.Initialize();

            //if (Core.Views.MyFormEx.ShowDialogWithMask(_flowLayoutSelector) == DialogResult.OK)
            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultCreator = _mSel.ResultList[0];
                    string displayText = string.IsNullOrWhiteSpace(_defaultCreator.Category2) ? "" : $"{_defaultCreator.Category2} » ";
                    displayText += $"{_defaultCreator.IdString} {_defaultCreator.Name}";

                    Creator.Tag = _defaultCreator.Name;
                    Creator.Text = displayText;
                }
                else
                {
                    Creator.Tag = "";
                    Creator.Text = "";
                }
            }
        }

        private void MachineId_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = false;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.Machine}";
            _mSel.TreeViewCaption = "機台";
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.MachinesMultiTabPageCache;
            _mSel.DefaultSelect = _defaultMachine;
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                _defaultMachine = _mSel.ResultList;
                MachineList.Text = _defaultMachine.Count > 0
                    ? string.Join("; ", _mSel.ResultList.Select(r => r.Name).ToArray())
                    : "";
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Creator.Text = "";
            MachineList.Text = "";
            IssueDescription.Text = "";
            OutageStarted.Text = "";
            //OutageStartedAvailable.Checked = false;
        }

        //private void OutageStartedAvailable_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (OutageStartedAvailable.Checked)
        //    {
        //        OutageStarted.Enabled = true;
        //        OutageStarted.Value = DateTime.Now;
        //    }
        //    else
        //    {
        //        OutageStarted.Enabled = false;
        //        OutageStarted.Text = "";
        //    }
        //}

        private void ModelList_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.Title = $"請選擇{PropertyText.Title.ModelName}";
            _mSel.TreeViewCaption = "機種";
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultModelWs };
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultModelWs = _mSel.ResultList[0];
                    var ws = _core.GetWorkstation(_defaultModelWs.Id);
                    var model = _core.GetModel(ws.ModelId.HasValue ? (int)ws.ModelId : 0);
                    ModelWs.Text = $"{model.ModelName} » {ws.WorkstationName}";
                }
                else
                {
                    ModelWs.Text = "";
                }
            }
        }
    }
}
