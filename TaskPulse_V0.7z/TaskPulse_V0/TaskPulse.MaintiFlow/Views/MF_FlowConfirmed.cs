﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.MaintiFlow;
using Calin.TaskPulse.MaintiFlow.Models;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MF_FlowConfirmed : UIForm
    {
        #region fields

        private readonly ILifetimeScope _rootScope;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly IMail _mail;
        private readonly CurrentUserContext _user;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        private TreeNode _thisNode = null;
        private BindingList<ListViewModel> Orders;

        // ResultList buffers
        private ClassifyInfo _defaultFeedbackEmployee = new ClassifyInfo();

        #endregion fields

        public TaskOrder TaskOrder { get; set; }

        public MF_FlowConfirmed(
            ILifetimeScope lifetimeScope,
            CoreContext coreContext,
            ICore core,
            IMail mail,
            CurrentUserContext currentUserContext,
            MaintiFlowData maintiFlowData,
            CoreData coreData,
            MultiSelector multiSelector)
        {
            InitializeComponent();
            _rootScope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _mail = mail;
            _user = currentUserContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _mSel = multiSelector;

            this.Text = PageCode.FlowConfirmed.GetDescription();

            CommonStyles.SetButton(btnCompleted);
            CommonStyles.SetButton(btnReturn);
            CommonStyles.SetButton(btnCancel, isCancel: true);
            CommonStyles.SetTreeView(OrderList);

            WeakReferenceMessenger.Default.Register<NotifyTaskOrderDataUpdated>(this, (recipient, message) =>
            {
                LoadData();
            });
        }

        private void MF_FlowConfirmed_FormClosing(object sender, FormClosingEventArgs e)
        {
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        private void FT_FlowConfirmed_Load(object sender, System.EventArgs e)
        {
            Label_WorkOrderNo.Text = PropertyText.Title.WorkOrderNo;
            Label_Creator.Text = PropertyText.Title.Creator;
            Label_CreationDate.Text = PropertyText.Title.CreationDateTime;
            Label_MachineList.Text = PropertyText.Title.Machine;
            Label_ModelWorkstation.Text = PropertyText.Title.ModelWsName;
            Label_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
            Label_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
            Label_Engineers.Text = PropertyText.Title.Engineer;
            Label_IssueCategory.Text = PropertyText.Title.MaintiFlowIssueCategory;
            Label_IssueDescription.Text = PropertyText.Title.MaintiFlowIssueDescription;
            Label_Details.Text = PropertyText.Title.Details;
            Label_RepairStarted.Text = PropertyText.Title.RepairStarted;
            Label_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
            Label_RepairDuration.Text = PropertyText.Title.RepairDuration;
            Label_OutageStarted.Text = PropertyText.Title.OutageStarted;
            Label_OutageEnded.Text = PropertyText.Title.OutageEnded;
            Label_OutageDuration.Text = PropertyText.Title.OutageDuration;
            Label_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
            Label_FeedbackEmployee.Text = PropertyText.Title.FeedbackEmployee;
            Label_Feedback.Text = PropertyText.Title.Feedback;

            LoadData();
        }

        private void LoadData()
        {
            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.Text = "資料載入中，請稍候...";
                loadingDialog.Show();

                var user = _coreData.Employees.FirstOrDefault(e => e.Id == _user.UserId);

                // 取得所有唯一的機種名稱並排序
                var sortedModels = _core.SortModelNames(
                    _flowData.TaskOrders.Select(ts => ts.ModelName).Distinct()
                ).ToList();

                // 建立排序索引對照表
                var modelSortIndex = sortedModels
                    .Select((name, index) => new { name, index })
                    .ToDictionary(x => x.name, x => x.index);

                // 使用索引排序
                var tos = _flowData.TaskOrders
                    .Where(ts => ts.Status == FlowStatus.Pending && (
                        _user.IsAdmin
                        || ts.RequestingUnitId == user.DepartmentId
                        || ts.CreatorId == _user.UserId
                        || ts.EngineerList.ContainsKey(_user.UserId)
                    ))
                    .OrderBy(ts => modelSortIndex.ContainsKey(ts.ModelName) ? modelSortIndex[ts.ModelName] : int.MaxValue)
                    .ThenBy(ts => ts.WorkOrderNo)
                    .Select(ts => new ClassifyInfo()
                    {
                        Id = ts.Id,
                        IdString = ts.WorkOrderNo,
                        Category1 = ts.ModelWsName,
                        Name = $"{ts.FullMachineName} ({ts.WorkOrderNo})",
                    })
                    .ToList();

                // 初始化 BindingList 以供後續使用
                Orders = new BindingList<ListViewModel>(
                    tos.Select(to => new ListViewModel()
                    {
                        Id = to.Id,
                        IdString = to.IdString,
                        Name = to.Name
                    }).ToList()
                );

                TreeNode currentRootNode = null;
                string currentCategory = null;

                OrderList.Nodes.Clear();
                foreach (var to in tos)
                {
                    if (currentCategory != to.Category1)
                    {
                        currentCategory = to.Category1;
                        currentRootNode = new TreeNode(to.Category1)
                        {
                            Name = to.Category1,
                            Tag = -1
                        };
                        OrderList.Nodes.Add(currentRootNode);
                    }

                    var childNode = new TreeNode(to.Name)
                    {
                        Name = to.Name,
                        Tag = to.Id
                    };
                    currentRootNode.Nodes.Add(childNode);
                }

                OrderList.CollapseAll();

                loadingDialog.Close();
            }
        }

        private void LoadSelected(TaskOrder taskOrder)
        {
            TaskOrder = taskOrder;

            if (taskOrder == null)
                return;

            WorkOrderNo.Text = TaskOrder.WorkOrderNo;
            Creator.Text = TaskOrder.CreatorName;
            CreationDate.Text = TaskOrder.CreationDateString;
            MachineList.Text = TaskOrder.FullMachineName;
            ModelWorkstation.Text = TaskOrder.ModelWsName;
            AcceptedTime.Text = TaskOrder.AcceptedTimeString;
            MaintenanceUnit.Text = TaskOrder.MaintenanceUnitString;
            Engineers.Text = TaskOrder.EngineerString;
            IssueCategory.Text = TaskOrder.IssueCategoryString;
            IssueDescription.Text = TaskOrder.IssueDescription;
            Details.Text = TaskOrder.Details;
            RepairStarted.Text = TaskOrder.RepairStartedString;
            RepairCompleted.Text = TaskOrder.RepairCompletedString;
            RepairDuration.Text = TaskOrder.RepairDurationString;
            OutageStarted.Text = TaskOrder.OutageStartedString;
            OutageEnded.Text = TaskOrder.OutageEndedString;
            OutageDuration.Text = TaskOrder.OutageDurationString;
            RequestingUnit.Text = TaskOrder.RequestingUnitString;
            FeedbackEmployee.Text = TaskOrder.FeedbackEmployeeString;
            Feedback.Text = TaskOrder.Feedback;
        }

        private void OrderList_AfterSelect(object sender, TreeViewEventArgs e)
        {
            _thisNode = e.Node;
            var selId = (int)_thisNode.Tag;
            if (selId >= 0)
                LoadSelected(_flowData.TaskOrders.FirstOrDefault(to => to.Id == selId));
        }

        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void FeedbackEmployee_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = true;
            _mSel.DialogWidth = 700;
            _mSel.Title = $"請選擇{PropertyText.Title.EmployeeName}";
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = false;
            _mSel.TabPageCache = _coreData.EmployeeSingleTabPageCache;
            _mSel.DefaultSelect = new List<ClassifyInfo>() { _defaultFeedbackEmployee };
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                if (_mSel.ResultList.Count > 0)
                {
                    _defaultFeedbackEmployee = _mSel.ResultList[0];
                    FeedbackEmployee.Text = _defaultFeedbackEmployee.Name;
                }
                else
                {
                    FeedbackEmployee.Text = "";
                }
            }
        }

        private async void btnCompleted_Click(object sender, System.EventArgs e)
        {
            if (TaskOrder == null || _thisNode == null)
                return;

            if (FeedbackEmployee.Text.Trim() == "")
            {
                MessageBox.Show($"請指定回覆人員。", "回覆人員未指定", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_coreData.Employees.FirstOrDefault(emp => emp.EmployeeName == FeedbackEmployee.Text) == null)
            {
                MessageBox.Show($"指定的回覆人員不存在，請重新選擇。", "回覆人員不存在", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show($"確定要將此工單標記為已完成？\n工單編號：{TaskOrder.WorkOrderNo}",
                               "確認完成",
                               MessageBoxButtons.YesNo,
                               MessageBoxIcon.Question) == DialogResult.Yes)
            {
                var to = await _context.TaskOrders.FirstOrDefaultAsync(t => t.Id == TaskOrder.Id);
                if (to != null)
                {
                    to.FeedbackEmployeeId = _context.Employees
                        .FirstOrDefault(emp => emp.EmployeeName == FeedbackEmployee.Text)?.Id;
                    to.Feedback = Feedback.Text;
                    to.Status = FlowStatus.Completed;
                    await _context.SaveChangesAsync();

                    // 從 TreeView 移除節點
                    var parentNode = _thisNode.Parent;
                    parentNode?.Nodes.Remove(_thisNode);

                    // 如果父節點沒有子節點，也移除父節點
                    if (parentNode != null && parentNode.Nodes.Count == 0)
                    {
                        OrderList.Nodes.Remove(parentNode);
                    }

                    // 從 BindingList 移除
                    var orderToRemove = Orders.FirstOrDefault(o => o.Id == TaskOrder.Id);
                    if (orderToRemove != null)
                    {
                        Orders.Remove(orderToRemove);
                    }

                    // send email
                    StringBuilder mail = new StringBuilder();
                    mail.Append("<table><caption>工單完成</caption>");

                    mail.Append("<tr>");
                    mail.Append("<td>工單</td>");
                    mail.Append($"<td>{to.WorkOrderNo}: {to.FullMachineName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append($"<td>{PropertyText.Title.Performer}</td>");
                    mail.Append($"<td>{_user.UserName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>機台</td>");
                    mail.Append($"<td>{to.FullMachineName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>機種 » 工站</td>");
                    mail.Append($"<td>{to.ModelWsName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護開始時間</td>");
                    mail.Append($"<td>{to.RepairStartedString}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護完成時間</td>");
                    mail.Append($"<td>{to.RepairCompletedString} ({to.RepairDurationString})</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>問題描述</td>");
                    mail.Append($"<td>{to.IssueDescription}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護內容</td>");
                    mail.Append($"<td>{to.Details}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>回覆人員</td>");
                    mail.Append($"<td>{to.FeedbackEmployeeFullString}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>回覆內容</td>");
                    mail.Append($"<td>{to.Feedback}</td>");
                    mail.Append("</tr>");
                    mail.Append("</table>");

                    var mailList = new HashSet<int>() { _user.UserId };
                    mailList.Add((int)to.FeedbackEmployeeId);
                    foreach (var engineerId in to.EngineerList.Keys)
                    {
                        mailList.Add(engineerId);
                    }
                    var creator = _coreData.Employees.FirstOrDefault(emp => emp.Id == to.CreatorId);
                    if (creator != null)
                        mailList.Add(creator.Id);
                    _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                                   $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][工單完成] {to.WorkOrderNo}: {to.FullMachineName}",
                                   mail.ToString());

                    MessageBox.Show($"工單 {TaskOrder.WorkOrderNo} 已成功標記為已完成。\n工單已結單。", "已結單", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            // 無記錄則關閉視窗
            if (Orders.Count == 0)
                this.Close();
            else
            {
                // 選擇下一個可用節點
                if (OrderList.Nodes.Count > 0)
                {
                    var firstRootNode = OrderList.Nodes[0];
                    if (firstRootNode.Nodes.Count > 0)
                    {
                        OrderList.SelectedNode = firstRootNode.Nodes[0];
                    }
                }
            }
        }

        private async void btnReturn_Click(object sender, System.EventArgs e)
        {
            if (TaskOrder == null || _thisNode == null)
                return;

            if (MessageBox.Show($"確定要將此工單退回至維修作業？\n工單編號：{TaskOrder.WorkOrderNo}",
                                 "確認退回",
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Question) == DialogResult.Yes)
            {
                var to = await _context.TaskOrders.FirstOrDefaultAsync(t => t.Id == TaskOrder.Id);
                if (to != null)
                {
                    to.Status = FlowStatus.InProgress;
                    to.FillingTime = DateTime.Now;
                    to.RepairCompleted = null;
                    await _context.SaveChangesAsync();

                    // 從 TreeView 移除節點
                    var parentNode = _thisNode.Parent;
                    parentNode?.Nodes.Remove(_thisNode);

                    // 如果父節點沒有子節點，也移除父節點
                    if (parentNode != null && parentNode.Nodes.Count == 0)
                    {
                        OrderList.Nodes.Remove(parentNode);
                    }

                    // 從 BindingList 移除
                    var orderToRemove = Orders.FirstOrDefault(o => o.Id == TaskOrder.Id);
                    if (orderToRemove != null)
                    {
                        Orders.Remove(orderToRemove);
                    }

                    // send email
                    StringBuilder mail = new StringBuilder();
                    mail.Append("<table><caption>工單退回至維修作業</caption>");

                    mail.Append("<tr>");
                    mail.Append($"<td>{PropertyText.Title.Performer}</td>");
                    mail.Append($"<td>{_user.UserName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>退回時間</td>");
                    mail.Append($"<td>{to.FillingTime}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>工單</td>");
                    mail.Append($"<td>{to.WorkOrderNo}: {to.FullMachineName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護開始時間</td>");
                    mail.Append($"<td>{to.RepairStartedString}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>停動開始時間</td>");
                    mail.Append($"<td>{to.OutageStartedString}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>問題描述</td>");
                    mail.Append($"<td>{to.IssueDescription}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護內容</td>");
                    mail.Append($"<td>{to.Details}</td>");
                    mail.Append("</tr>");
                    mail.Append("</table>");

                    var mailList = new HashSet<int>() { _user.UserId };
                    var creator = _coreData.Employees.FirstOrDefault(emp => emp.Id == to.CreatorId);
                    if (creator != null)
                        mailList.Add(creator.Id);
                    _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                                   $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][工單退回] {to.WorkOrderNo}: {to.FullMachineName}",
                                   mail.ToString());

                    MessageBox.Show($"工單 {TaskOrder.WorkOrderNo} 已成功退回至維修作業。", "退回成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            // 無記錄則關閉視窗
            if (Orders.Count == 0)
                this.Close();
            else
            {
                // 選擇下一個可用節點
                if (OrderList.Nodes.Count > 0)
                {
                    var firstRootNode = OrderList.Nodes[0];
                    if (firstRootNode.Nodes.Count > 0)
                    {
                        OrderList.SelectedNode = firstRootNode.Nodes[0];
                    }
                }
            }
        }
    }
}
