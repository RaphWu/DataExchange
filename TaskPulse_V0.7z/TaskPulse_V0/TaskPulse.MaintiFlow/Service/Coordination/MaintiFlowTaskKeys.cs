﻿using Calin.Infrastructure.Coordination;

namespace Calin.TaskPulse.MaintiFlow.Service.Coordination
{
    public static class MaintiFlowTaskKeys
    {
        public static readonly TaskKey WorkOrderUpdate = new TaskKey("TaskPulse.MaintiFlow.WorkOrderUpdate");
    }
}
