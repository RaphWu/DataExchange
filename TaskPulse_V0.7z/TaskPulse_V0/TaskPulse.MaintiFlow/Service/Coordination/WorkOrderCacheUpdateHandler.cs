﻿using System.Threading.Tasks;
using Calin.Infrastructure.Coordination;
using Calin.TaskPulse.MaintiFlow.Contract;

namespace Calin.TaskPulse.MaintiFlow.Service.Coordination
{
    public class WorkOrderCacheUpdateHandler : TaskHandlerBase<CacheUpdateRequest>
    {
        private readonly IMaintiFlow _maintiFlow;

        public override TaskKey TaskKey => MaintiFlowTaskKeys.WorkOrderUpdate;

        public WorkOrderCacheUpdateHandler(IMaintiFlow maintiFlow)
        {
            _maintiFlow = maintiFlow;
        }

        protected override async Task ExecuteAsync(ITaskExecutionContext context, CacheUpdateRequest request)
        {
            await _maintiFlow.UpdateWorkOrdersCache();
        }
    }
}
