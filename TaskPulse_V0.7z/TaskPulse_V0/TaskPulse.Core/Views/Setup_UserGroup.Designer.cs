namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_UserGroup
    {
        /// <summary> 
        /// �]�p�u��һݪ��ܼơC
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region ����]�p�u�㲣�ͪ��{���X

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary> 
        /// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边�ק�
        /// �o�Ӥ�k�����e�C
        /// </summary>
        private void InitializeComponent()
        {
            this.TLP = new System.Windows.Forms.TableLayoutPanel();
            this.dgvGroupMembers = new System.Windows.Forms.DataGridView();
            this.dgvAvailableEmployees = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.UserGroup_Create = new Sunny.UI.UISymbolButton();
            this.UserGroup_Edit = new Sunny.UI.UISymbolButton();
            this.UserGroup_Delete = new Sunny.UI.UISymbolButton();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.UserGroup_Up = new Sunny.UI.UISymbolButton();
            this.UserGroup_Down = new Sunny.UI.UISymbolButton();
            this.lboxUserGroups = new Sunny.UI.UIListBox();
            this.Label_UserGroup = new System.Windows.Forms.Label();
            this.Panel_Permission = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnAddMembers = new Sunny.UI.UISymbolButton();
            this.btnRemoveMembers = new Sunny.UI.UISymbolButton();
            this.TLP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGroupMembers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAvailableEmployees)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // TLP
            // 
            this.TLP.ColumnCount = 8;
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 280F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 350F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 350F));
            this.TLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.Controls.Add(this.dgvGroupMembers, 4, 1);
            this.TLP.Controls.Add(this.dgvAvailableEmployees, 6, 1);
            this.TLP.Controls.Add(this.label1, 6, 0);
            this.TLP.Controls.Add(this.label2, 4, 0);
            this.TLP.Controls.Add(this.flowLayoutPanel1, 2, 2);
            this.TLP.Controls.Add(this.flowLayoutPanel2, 1, 1);
            this.TLP.Controls.Add(this.lboxUserGroups, 2, 1);
            this.TLP.Controls.Add(this.Label_UserGroup, 2, 0);
            this.TLP.Controls.Add(this.Panel_Permission, 2, 3);
            this.TLP.Controls.Add(this.panel4, 5, 1);
            this.TLP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TLP.Location = new System.Drawing.Point(0, 0);
            this.TLP.Name = "TLP";
            this.TLP.RowCount = 4;
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.TLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 210F));
            this.TLP.Size = new System.Drawing.Size(1200, 700);
            this.TLP.TabIndex = 0;
            // 
            // dgvGroupMembers
            // 
            this.dgvGroupMembers.AllowUserToAddRows = false;
            this.dgvGroupMembers.AllowUserToDeleteRows = false;
            this.dgvGroupMembers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGroupMembers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvGroupMembers.Location = new System.Drawing.Point(372, 33);
            this.dgvGroupMembers.Name = "dgvGroupMembers";
            this.TLP.SetRowSpan(this.dgvGroupMembers, 2);
            this.dgvGroupMembers.RowTemplate.Height = 24;
            this.dgvGroupMembers.Size = new System.Drawing.Size(344, 454);
            this.dgvGroupMembers.TabIndex = 12;
            // 
            // dgvAvailableEmployees
            // 
            this.dgvAvailableEmployees.AllowUserToAddRows = false;
            this.dgvAvailableEmployees.AllowUserToDeleteRows = false;
            this.dgvAvailableEmployees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAvailableEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAvailableEmployees.Location = new System.Drawing.Point(782, 33);
            this.dgvAvailableEmployees.Name = "dgvAvailableEmployees";
            this.TLP.SetRowSpan(this.dgvAvailableEmployees, 2);
            this.dgvAvailableEmployees.RowTemplate.Height = 24;
            this.dgvAvailableEmployees.Size = new System.Drawing.Size(344, 454);
            this.dgvAvailableEmployees.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("�з���", 14F);
            this.label1.Location = new System.Drawing.Point(909, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 19);
            this.label1.TabIndex = 10;
            this.label1.Text = "�i�ΤH��";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("�з���", 14F);
            this.label2.Location = new System.Drawing.Point(499, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 19);
            this.label2.TabIndex = 9;
            this.label2.Text = "�s�զ���";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.UserGroup_Create);
            this.flowLayoutPanel1.Controls.Add(this.UserGroup_Edit);
            this.flowLayoutPanel1.Controls.Add(this.UserGroup_Delete);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(137, 455);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // UserGroup_Create
            // 
            this.UserGroup_Create.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.UserGroup_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UserGroup_Create.Font = new System.Drawing.Font("�L�n������", 11F);
            this.UserGroup_Create.Location = new System.Drawing.Point(9, 0);
            this.UserGroup_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.UserGroup_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.UserGroup_Create.Name = "UserGroup_Create";
            this.UserGroup_Create.Size = new System.Drawing.Size(30, 30);
            this.UserGroup_Create.Symbol = 557669;
            this.UserGroup_Create.SymbolSize = 32;
            this.UserGroup_Create.TabIndex = 0;
            this.UserGroup_Create.TipsFont = new System.Drawing.Font("�L�n������", 9F);
            this.UserGroup_Create.Click += new System.EventHandler(this.UserGroup_Create_Click);
            // 
            // UserGroup_Edit
            // 
            this.UserGroup_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.UserGroup_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UserGroup_Edit.Enabled = false;
            this.UserGroup_Edit.Font = new System.Drawing.Font("�L�n������", 11F);
            this.UserGroup_Edit.Location = new System.Drawing.Point(57, 0);
            this.UserGroup_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.UserGroup_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.UserGroup_Edit.Name = "UserGroup_Edit";
            this.UserGroup_Edit.Size = new System.Drawing.Size(30, 30);
            this.UserGroup_Edit.Symbol = 559205;
            this.UserGroup_Edit.SymbolSize = 32;
            this.UserGroup_Edit.TabIndex = 1;
            this.UserGroup_Edit.TipsFont = new System.Drawing.Font("�L�n������", 9F);
            this.UserGroup_Edit.Click += new System.EventHandler(this.UserGroup_Edit_Click);
            // 
            // UserGroup_Delete
            // 
            this.UserGroup_Delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.UserGroup_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UserGroup_Delete.Enabled = false;
            this.UserGroup_Delete.Font = new System.Drawing.Font("�L�n������", 11F);
            this.UserGroup_Delete.Location = new System.Drawing.Point(105, 0);
            this.UserGroup_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.UserGroup_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.UserGroup_Delete.Name = "UserGroup_Delete";
            this.UserGroup_Delete.Size = new System.Drawing.Size(30, 30);
            this.UserGroup_Delete.Symbol = 559506;
            this.UserGroup_Delete.SymbolSize = 26;
            this.UserGroup_Delete.TabIndex = 2;
            this.UserGroup_Delete.TipsFont = new System.Drawing.Font("�L�n������", 9F);
            this.UserGroup_Delete.Click += new System.EventHandler(this.UserGroup_Delete_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel2.AutoSize = true;
            this.flowLayoutPanel2.Controls.Add(this.UserGroup_Up);
            this.flowLayoutPanel2.Controls.Add(this.UserGroup_Down);
            this.flowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(36, 60);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 30, 3, 3);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(30, 96);
            this.flowLayoutPanel2.TabIndex = 1;
            // 
            // UserGroup_Up
            // 
            this.UserGroup_Up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.UserGroup_Up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UserGroup_Up.Enabled = false;
            this.UserGroup_Up.Font = new System.Drawing.Font("�L�n������", 11F);
            this.UserGroup_Up.Location = new System.Drawing.Point(0, 9);
            this.UserGroup_Up.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.UserGroup_Up.MinimumSize = new System.Drawing.Size(1, 1);
            this.UserGroup_Up.Name = "UserGroup_Up";
            this.UserGroup_Up.Size = new System.Drawing.Size(30, 30);
            this.UserGroup_Up.Symbol = 361702;
            this.UserGroup_Up.SymbolSize = 32;
            this.UserGroup_Up.TabIndex = 0;
            this.UserGroup_Up.TipsFont = new System.Drawing.Font("�L�n������", 9F);
            this.UserGroup_Up.Click += new System.EventHandler(this.UserGroup_Up_Click);
            // 
            // UserGroup_Down
            // 
            this.UserGroup_Down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.UserGroup_Down.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UserGroup_Down.Enabled = false;
            this.UserGroup_Down.Font = new System.Drawing.Font("�L�n������", 11F);
            this.UserGroup_Down.Location = new System.Drawing.Point(0, 57);
            this.UserGroup_Down.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.UserGroup_Down.MinimumSize = new System.Drawing.Size(1, 1);
            this.UserGroup_Down.Name = "UserGroup_Down";
            this.UserGroup_Down.Size = new System.Drawing.Size(30, 30);
            this.UserGroup_Down.Symbol = 361703;
            this.UserGroup_Down.SymbolSize = 32;
            this.UserGroup_Down.TabIndex = 1;
            this.UserGroup_Down.TipsFont = new System.Drawing.Font("�L�n������", 9F);
            this.UserGroup_Down.Click += new System.EventHandler(this.UserGroup_Down_Click);
            // 
            // lboxUserGroups
            // 
            this.lboxUserGroups.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lboxUserGroups.Font = new System.Drawing.Font("�L�n������", 11F);
            this.lboxUserGroups.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(200)))), ((int)(((byte)(255)))));
            this.lboxUserGroups.ItemSelectForeColor = System.Drawing.Color.White;
            this.lboxUserGroups.Location = new System.Drawing.Point(73, 35);
            this.lboxUserGroups.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lboxUserGroups.MinimumSize = new System.Drawing.Size(1, 1);
            this.lboxUserGroups.Name = "lboxUserGroups";
            this.lboxUserGroups.Padding = new System.Windows.Forms.Padding(2);
            this.lboxUserGroups.Radius = 1;
            this.lboxUserGroups.ShowText = false;
            this.lboxUserGroups.Size = new System.Drawing.Size(272, 415);
            this.lboxUserGroups.TabIndex = 2;
            this.lboxUserGroups.Text = "uiListBox1";
            this.lboxUserGroups.SelectedIndexChanged += new System.EventHandler(this.lboxUserGroups_SelectedIndexChanged);
            // 
            // Label_UserGroup
            // 
            this.Label_UserGroup.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Label_UserGroup.AutoSize = true;
            this.Label_UserGroup.Font = new System.Drawing.Font("�з���", 14F);
            this.Label_UserGroup.Location = new System.Drawing.Point(154, 11);
            this.Label_UserGroup.Name = "Label_UserGroup";
            this.Label_UserGroup.Size = new System.Drawing.Size(109, 19);
            this.Label_UserGroup.TabIndex = 3;
            this.Label_UserGroup.Text = "�ϥΪ̸s��";
            this.Label_UserGroup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel_Permission
            // 
            this.TLP.SetColumnSpan(this.Panel_Permission, 3);
            this.Panel_Permission.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Panel_Permission.Location = new System.Drawing.Point(72, 493);
            this.Panel_Permission.Name = "Panel_Permission";
            this.Panel_Permission.Size = new System.Drawing.Size(644, 204);
            this.Panel_Permission.TabIndex = 5;
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.Controls.Add(this.btnAddMembers);
            this.panel4.Controls.Add(this.btnRemoveMembers);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(722, 180);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 150, 3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(54, 96);
            this.panel4.TabIndex = 6;
            // 
            // btnAddMembers
            // 
            this.btnAddMembers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.btnAddMembers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddMembers.Enabled = false;
            this.btnAddMembers.Font = new System.Drawing.Font("�L�n������", 11F);
            this.btnAddMembers.Location = new System.Drawing.Point(11, 9);
            this.btnAddMembers.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.btnAddMembers.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnAddMembers.Name = "btnAddMembers";
            this.btnAddMembers.Size = new System.Drawing.Size(30, 30);
            this.btnAddMembers.Symbol = 361700;
            this.btnAddMembers.SymbolSize = 32;
            this.btnAddMembers.TabIndex = 2;
            this.btnAddMembers.TipsFont = new System.Drawing.Font("�L�n������", 9F);
            this.btnAddMembers.Click += new System.EventHandler(this.btnAddMembers_Click);
            // 
            // btnRemoveMembers
            // 
            this.btnRemoveMembers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.btnRemoveMembers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveMembers.Enabled = false;
            this.btnRemoveMembers.Font = new System.Drawing.Font("�L�n������", 11F);
            this.btnRemoveMembers.Location = new System.Drawing.Point(11, 57);
            this.btnRemoveMembers.Margin = new System.Windows.Forms.Padding(0, 9, 0, 9);
            this.btnRemoveMembers.MinimumSize = new System.Drawing.Size(1, 1);
            this.btnRemoveMembers.Name = "btnRemoveMembers";
            this.btnRemoveMembers.Size = new System.Drawing.Size(30, 30);
            this.btnRemoveMembers.Symbol = 361701;
            this.btnRemoveMembers.SymbolOffset = new System.Drawing.Point(3, 0);
            this.btnRemoveMembers.SymbolSize = 32;
            this.btnRemoveMembers.TabIndex = 3;
            this.btnRemoveMembers.TipsFont = new System.Drawing.Font("�L�n������", 9F);
            this.btnRemoveMembers.Click += new System.EventHandler(this.btnRemoveMembers_Click);
            // 
            // Setup_UserGroup
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.TLP);
            this.Name = "Setup_UserGroup";
            this.Size = new System.Drawing.Size(1200, 700);
            this.Load += new System.EventHandler(this.Setup_UserGroup_Load);
            this.TLP.ResumeLayout(false);
            this.TLP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGroupMembers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAvailableEmployees)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel TLP;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Sunny.UI.UISymbolButton UserGroup_Create;
        private Sunny.UI.UISymbolButton UserGroup_Edit;
        private Sunny.UI.UISymbolButton UserGroup_Delete;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private Sunny.UI.UISymbolButton UserGroup_Up;
        private Sunny.UI.UISymbolButton UserGroup_Down;
        private Sunny.UI.UIListBox lboxUserGroups;
        private System.Windows.Forms.Label Label_UserGroup;
        private System.Windows.Forms.Panel Panel_Permission;
        private System.Windows.Forms.Panel panel4;
        private Sunny.UI.UISymbolButton btnAddMembers;
        private Sunny.UI.UISymbolButton btnRemoveMembers;
        private System.Windows.Forms.DataGridView dgvGroupMembers;
        private System.Windows.Forms.DataGridView dgvAvailableEmployees;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}
