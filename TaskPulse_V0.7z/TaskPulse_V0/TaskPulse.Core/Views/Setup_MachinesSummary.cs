﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Core.WinForms;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachinesSummary : UserControl, INavigationAware
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ILifetimeScope _scope;
        private readonly IPermissionService _permission;
        private readonly IEntityCacheManager _cacheManager;
        private readonly ICore _core;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        private List<MachineViewModel> _mdgv;
        //private readonly BindingSource _bs = new BindingSource();

        private bool _editPermission = false;
        private Machine _thisMachine;
        private string _thisMachineCode = "";
        private int _thisCategoryId = 0;
        private int _thisTypeId = 0;
        private int _thisTypeIndex = 0;
        private int _thisMachineNameId = 0;
        private TreeNode _thisNode = null;

        private TreeNode _newNode = null;
        private string _newMachineCode = "";
        private int _originalRowIndex = -1;
        private bool _listUpdated = false; // 僅用於 ListBox，避免 AfterSelect(滑鼠選擇 & 鍵盤移動)與 NodeMouseClick(滑鼠點) 重複觸發

        private bool _prohibitUpdateAdgv = false;

        #endregion fields

        public void OnNavigatedTo()
        {
            UserChanged();
            LoadDataAsync();
        }

        public void OnNavigatedFrom()
        {
            _thisNode = null;
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();

            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        public Setup_MachinesSummary(
            Serilog.ILogger logger,
            ILifetimeScope lifetimeScope,
            IPermissionService permissionService,
            IEntityCacheManager cacheManager,
            ICore core,
            CoreContext coreContext,
            CoreData coreData)
        {
            InitializeComponent();

            _logger = logger;
            _scope = lifetimeScope;
            _permission = permissionService;
            _cacheManager = cacheManager;
            _core = core;
            _context = coreContext;
            _coreData = coreData;

            var ctCondition = _context.MachineConditions
                .Select(m => new ListViewModel()
                {
                    Id = m.Id,
                    Name = m.ConditionName,
                })
                .ToList();
            Condition.DataSource = ctCondition;
            Condition.DisplayMember = "Name";
            Condition.ValueMember = "Id";

            var ctBrand = _context.MachineBrands
                .Select(m => new ListViewModel()
                {
                    Id = m.Id,
                    Name = m.BrandName,
                })
                .ToList();
            Brand.DataSource = ctBrand;
            Brand.DisplayMember = "Name";
            Brand.ValueMember = "Id";

            var ctLoc = _context.MachineLocations
                .Select(m => new ListViewModel()
                {
                    Id = m.Id,
                    Name = m.LocationName,
                })
                .ToList();
            Location.DataSource = ctLoc;
            Location.DisplayMember = "Name";
            Location.ValueMember = "Id";


            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.MachineCode),
                HeaderText = PropertyText.Title.Machine,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            //adgv.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = nameof(MachineViewModel.CategoryName),
            //    HeaderText = PropertyString.Title.MachineCategory,
            //    ValueType = typeof(string),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            //});

            //adgv.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = nameof(MachineViewModel.TypeName),
            //    HeaderText = PropertyString.Title.MachineType,
            //    ValueType = typeof(string),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            //});

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.ModelName),
                HeaderText = PropertyText.Title.MachineModel,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.ConditionName),
                HeaderText = PropertyText.Title.Condition,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.BrandName),
                HeaderText = PropertyText.Title.Brand,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.LocationName),
                HeaderText = PropertyText.Title.Location,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.AssetString),
                HeaderText = PropertyText.Title.Assets,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
                DefaultCellStyle = new DataGridViewCellStyle()
                {
                    WrapMode = DataGridViewTriState.True,
                    //Alignment = DataGridViewContentAlignment.MiddleLeft,
                },
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.SerialNumber),
                HeaderText = PropertyText.Title.SerialNumber,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.ConnectedString),
                HeaderText = PropertyText.Title.Connected,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            adgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = nameof(MachineViewModel.DisposalString),
                HeaderText = PropertyText.Title.Disposal,
                ValueType = typeof(string),
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            });

            //adgv.Columns.Add(new DataGridViewTextBoxColumn
            //{
            //    DataPropertyName = nameof(MachineViewModel.Workstations),
            //    HeaderText = PropertyString.Title.Workstations,
            //    ValueType = typeof(string),
            //    AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells,
            //});

            SwitchEditMode(false);
            string itemName = PropertyText.Title.Machine;
            //headLabel_Machine.Text = $"{PropertyString.Title.MachineCategory} » {PropertyString.Title.MachineType}";
            CommonStyles.SetCrudButton(Machine_Create, "C", itemName);
            CommonStyles.SetCrudButton(Machine_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Machine_Delete, "D", itemName);
            CommonStyles.SetAdvancedDataGridView(adgv, true);
            CommonStyles.SetButton(btnSave);
            CommonStyles.SetButton(btnRefresh);
            CommonStyles.SetTreeView(list_Catelogries);
            EditModeSwitch.ActiveColor = CommonStyles.BackColor;
            EditModeSwitch.InActiveColor = Color.DarkRed;

            list_Catelogries.ContextMenuStrip = new TreeViewContextMenu();

            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (recipient, message) =>
            {
                UserChanged();
            });

            WeakReferenceMessenger.Default.Register<NotifyMachineDataUpdated>(this, (recipient, message) =>
            {
                LoadDataAsync();
            });
        }

        private void Setup_MachinesSummary_Load(object sender, System.EventArgs e)
        {
            UserChanged();
            LoadDataAsync();

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "正在載入資料...";
                loadingDialog.Show();

                //_bs.DataSource = new MachineViewModel();

                label_MachineId.Text = PropertyText.Title.Machine;
                MaincheId.DataBindings.Clear();
                //MaincheId.DataBindings.Add("Text", _bs, PropertyText.Name.MachineCode);

                label_Catelogry.Text = PropertyText.Title.MachineCategory;
                Catelogry.DataBindings.Clear();
                //Catelogry.DataBindings.Add("Text", _bs, PropertyText.Name.MachineCategory);

                label_Type.Text = PropertyText.Title.MachineType;
                Type.DataBindings.Clear();
                //Type.DataBindings.Add("Text", _bs, PropertyText.Name.MachineType);

                label_ModeName.Text = PropertyText.Title.MachineModel;
                ModelNo.DataBindings.Clear();
                //ModelNo.DataBindings.Add("Text", _bs, PropertyText.Name.MachineModel);

                label_Condition.Text = PropertyText.Title.Condition;
                Condition.DataBindings.Clear();
                //Condition.DataBindings.Add("Text", _bs, PropertyText.Name.ConditionName);

                label_Brand.Text = PropertyText.Title.Brand;
                Brand.DataBindings.Clear();
                //Brand.DataBindings.Add("Text", _bs, PropertyText.Name.BrandName);

                label_Location.Text = PropertyText.Title.Location;
                Location.DataBindings.Clear();
                //Location.DataBindings.Add("Text", _bs, PropertyText.Name.LocationName);

                label_Assets.Text = PropertyText.Title.Assets;
                Assets.DataBindings.Clear();
                //Assets.DataBindings.Add("Text", _bs, PropertyText.Name.AssetString);

                label_SerialNumber.Text = PropertyText.Title.SerialNumber;
                SerialNumber.DataBindings.Clear();
                //SerialNumber.DataBindings.Add("Text", _bs, PropertyText.Name.SerialNumber);

                label_Barcode.Text = PropertyText.Title.Barcode;
                Barcode.DataBindings.Clear();
                //Barcode.DataBindings.Add("Text", _bs, PropertyText.Name.Barcode);

                //label_Workstations.Text = PropertyString.Title.Workstations;
                //Workstations.DataBindings.Clear();
                //Workstations.DataBindings.Add("Text", _bs, PropertyString.Name.Workstations);

                label_Remark.Text = PropertyText.Title.Remark;
                Remark.DataBindings.Clear();
                //Remark.DataBindings.Add("Text", _bs, PropertyText.Name.Remark);

                //label_Connected.Text = PropertyText.Title.Connected;
                Connected.DataBindings.Clear();
                //Connected.DataBindings.Add("Checked", _bs, PropertyText.Name.Connected);

                //label_Disposal.Text = PropertyText.Title.Disposal;
                Disposal.DataBindings.Clear();
                //Disposal.DataBindings.Add("Checked", _bs, PropertyText.Name.Disposal);

                loadingDialog.Close();
            }
        }

        private async void LoadDataAsync()
        {
            await UpdateMachinesListAsync();
            await UpdateMachinesViewAsync();
        }

        /********************
         * Permission
         ********************/
        private void UserChanged()
        {
            bool _editPermission = _permission.HasControlAccess(
                PermissionWords.MODULE_SETUP,
                PermissionWords.PAGE_MACHINE_MANAGER,
                "*",
                PermissionWords.ACTION_EDIT);

            btnSave.Visible = _editPermission;
            EditModeSwitch.Visible = _editPermission;

            //ADGV.ContextMenuStrip = allowEdit
            //    ? adgvContextMenu
            //    : null;
        }

        /********************
         * 編輯模式
         ********************/
        private void SwitchEditMode(bool editMode)
        {
            //MaincheId.Enabled = editMode;
            //Catelogry.Enabled = editMode;
            //Type.Enabled = editMode;
            ModelNo.Enabled = editMode;
            Condition.Enabled = editMode;
            Brand.Enabled = editMode;
            Location.Enabled = editMode;

            Workstations.Enabled = editMode;
            Assets.Enabled = editMode;
            SerialNumber.Enabled = editMode;
            Barcode.Enabled = editMode;

            Remark.Enabled = editMode;
            Connected.Enabled = editMode;
            Disposal.Enabled = editMode;

            Machine_Create.Enabled = editMode;
            Machine_Edit.Enabled = editMode;
            Machine_Delete.Enabled = editMode;

            btnSave.Enabled = editMode;
        }

        private void EditModeSwitch_ValueChanged(object sender, bool value)
        {
            SwitchEditMode(value);
        }

        /********************
         * TreeView
         ********************/
        private async Task UpdateMachinesListAsync()
        {
            if (_newNode != null) return;

            using (var loadingDialog = new LoadingDialog())
            {
                loadingDialog.LoadingMessage = "正在更新資料...";
                loadingDialog.Show();

                //var mQuery = await _context.Machines
                //    .Include(m => m.MachineName)
                //    .Include(m => m.MachineName.MachineType)
                //    .Include(m => m.MachineName.MachineType.Category)
                //    .Include(m => m.Brand)
                //    .Include(m => m.Assets)
                //    .Include(m => m.Location)
                //    .Include(m => m.Condition)
                //    .AsNoTracking()
                //    .ToListAsync();

                TreeNode topNode = null;
                TreeNode parent;
                TreeNode child;

                list_Catelogries.Nodes.Clear();
                var categories = await _context.MachineCategories.ToListAsync();
                foreach (var mCat in categories)
                {
                    parent = new TreeNode(mCat.CategoryName);
                    parent.Tag = mCat.Id;
                    list_Catelogries.Nodes.Add(parent);

                    var mTypes = _coreData.MachineTypes
                        .Where(c => c.CategoryId == mCat.Id)
                        .Select(b => new ListViewModel { Id = b.Id, Name = b.TypeName })
                        .ToList();

                    foreach (var mType in mTypes)
                    {
                        child = new TreeNode(mType.Name);
                        child.Tag = mType.Id;
                        parent.Nodes.Add(child);

                        if (topNode == null)
                            topNode = child;
                    }
                }

                //list_Catelogries.ExpandAll();
                //list_Catelogries.SelectedNode = topNode;
                //topNode.EnsureVisible();

                loadingDialog.Close();
            }
        }

        private async void List_Catelogries_AfterSelect(object sender, TreeViewEventArgs e)
        {
            _thisNode = e.Node;
            if (_thisNode.Level > 0)
            {
                Machine_Create.Enabled = true;
            }
            else
            {
                Machine_Create.Enabled = false;
                Machine_Edit.Enabled = false;
                Machine_Delete.Enabled = false;
            }

            //if (!_listUpdated)
            _thisTypeId = (int)(_thisNode?.Tag ?? 0);
            if (_thisNode.Level == 0)
            {
                _thisCategoryId = _thisTypeId;
                _thisTypeId = -1;
            }
            if (_thisNode.Level > 0)
            {
                await UpdateMachinesViewAsync();
                //_listUpdated = false;
            }
        }

        private void List_Catelogries_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
                ((UITreeView)sender).SelectedNode = e.Node;

            //    _thisNode = e.Node;
            //_thisTypeId = (int)(_thisNode?.Tag ?? 0);
            //if (_thisNode.Level == 0)
            //{
            //    _thisCategoryId = _thisTypeId;
            //    _thisTypeId = -1;
            //}

            //if (_thisNode.IsExpanded)
            //    _thisNode.Collapse();
            //else
            //    _thisNode.Expand();
        }

        /********************
         * ADGV
         ********************/
        private async Task UpdateMachinesViewAsync()
        {
            if (_prohibitUpdateAdgv)
                return;

            _prohibitUpdateAdgv = true;
            if (_thisNode != null && _thisNode.Level > 0)
            {
                var query = await _context.Machines
                    .Include(m => m.MachineName.MachineType.Category)
                    .Include(m => m.Brand)
                    .Include(m => m.Location)
                    .Include(m => m.Workstations)
                    .Where(m => m.MachineName.TypeId == _thisTypeId)
                    .ToListAsync();
                _mdgv = query
                   .Select(m => new MachineViewModel
                   {
                       MachineCode = m.MachineCode,
                       CategoryName = m.CategoryName,
                       TypeName = m.TypeName,
                       ModelName = m.MachineName.ModelName,
                       ConditionId = m.ConditionId,
                       ConditionName = m.ConditionName,
                       BrandName = m.Brand.BrandName,
                       LocationName = m.Location.LocationName,
                       //Status = m.MachineName.ModelStatus != null ? m.MachineName.ModelStatus.Status : "",
                       AssetString = m.AssetString,
                       SerialNumber = m.SerialNumber,
                       Barcode = m.Barcode,
                       Connected = m.Connected,
                       ConnectedString = m.ConnectedString,
                       Disposal = m.Disposal,
                       DisposalString = m.DisposalString,
                       Remark = m.Remark,
                       Workstations = string.Join("\n", m.Workstations.Select(w => w.FullWorkstationName)),
                   })
                   .ToList();

                adgv.DataSource = _mdgv.ToDataTable();
                //_bs.DataSource = _mdgv;
                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"共 {_mdgv.Count()} 筆資料"));
            }
            else
            {
                _mdgv = null;
                adgv.DataSource = null;
                //_bs.DataSource = new List<MachineViewModel>();

                Machine_Create.Enabled = false;

                _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage($"沒有資料顯示"));
            }

            if (_mdgv == null || !_mdgv.Any())
            {
                Machine_Edit.Enabled = false;
                Machine_Delete.Enabled = false;

                // 清空所有下方資料區域
                _thisMachine = null;
                _thisMachineCode = "";
                _thisMachineNameId = -1;
                //_thisCategoryId = 0;

                MaincheId.Text = "";
                Catelogry.SelectedIndex = -1;
                Type.SelectedIndex = -1;
                ModelNo.SelectedIndex = -1;
                Condition.Text = "";
                Brand.Text = "";
                Location.Text = "";
                Assets.Text = "";
                SerialNumber.Text = "";
                Barcode.Text = "";
                Workstations.Text = "";
                Remark.Text = "";
                Connected.Checked = false;
                Disposal.Checked = false;
            }

            _prohibitUpdateAdgv = false;
        }

        private void ADGV_SelectionChanged(object sender, System.EventArgs e)
        {
            // 檢查是否有有效的選擇：TreeView 選擇有效 (Level > 0) 且 adgv 有資料且有選擇
            if (_thisNode != null && _thisNode.Level > 0 &&
                _mdgv != null && _mdgv.Any() &&
                adgv.CurrentRow?.DataBoundItem is DataRowView drv)
            {
                _thisMachineCode = drv[PropertyText.Name.MachineCode].ToString();
                _thisMachine = _coreData.Machines.FirstOrDefault(m => m.MachineCode == _thisMachineCode);
                _thisMachineNameId = _thisMachine?.MachineNameId ?? -1;
                _thisTypeId = _thisMachine?.MachineName.TypeId ?? -1;
                _thisTypeIndex = adgv.CurrentCell.RowIndex;
                _thisCategoryId = _thisMachine?.CategoryId ?? -1;

                SetMachineCategoryList();
                SetMachineTypeList();
                SetMachineModelNo();

                if (_thisMachine != null)
                {
                    MaincheId.Text = _thisMachine.MachineCode;
                    Catelogry.SelectedValue = _thisMachine.CategoryId;
                    Type.SelectedValue = _thisMachine.TypeId;
                    ModelNo.SelectedValue = _thisMachine.MachineNameId;
                    Condition.Text = _thisMachine.ConditionName;
                    Brand.Text = _thisMachine.BrandName;
                    Location.Text = _thisMachine.LocationName;
                    Assets.Text = _thisMachine.AssetString;
                    SerialNumber.Text = _thisMachine.SerialNumber;
                    Barcode.Text = _thisMachine.Barcode;
                    Remark.Text = _thisMachine.Remark;
                    Connected.Checked = _thisMachine.Connected;
                    Disposal.Checked = _thisMachine.Disposal;

                    int index = _mdgv?.FindIndex(x => x.MachineCode == _thisMachineCode) ?? -1;
                    if (index >= 0)
                    {
                        Machine_Edit.Enabled = true;
                        Machine_Delete.Enabled = true;
                        return;
                    }
                }
                else
                {
                    _thisMachineCode = "";

                    MaincheId.Text = "";
                    Catelogry.SelectedValue = "";
                    Type.SelectedValue = "";
                    ModelNo.SelectedValue = "";
                    Condition.Text = "";
                    Brand.Text = "";
                    Location.Text = "";
                    Assets.Text = "";
                    SerialNumber.Text = "";
                    Barcode.Text = "";
                    Remark.Text = "";
                    Connected.Checked = false;
                    Disposal.Checked = false;

                    Machine_Edit.Enabled = false;
                    Machine_Delete.Enabled = false;
                }
            }

            // 沒有有效選擇，清空所有欄位
            _thisMachine = null;
            _thisMachineCode = "";
            _thisMachineNameId = -1;
            //_thisCategoryId = 0;

            Machine_Edit.Enabled = false;
            Machine_Delete.Enabled = false;

            MaincheId.Text = "";
            Catelogry.SelectedIndex = -1;
            Type.SelectedIndex = -1;
            ModelNo.SelectedIndex = -1;
            Condition.Text = "";
            Brand.Text = "";
            Location.Text = "";
            Assets.Text = "";
            SerialNumber.Text = "";
            Barcode.Text = "";
            Workstations.Text = "";
            Remark.Text = "";
            Connected.Checked = false;
            Disposal.Checked = false;
        }

        private void SetMachineCategoryList()
        {
            if (_thisNode != null && _thisNode.Level > 0)
            {
                var ctCategory = _context.MachineCategories
                .OrderBy(mc => mc.OrderNo)
                .Select(mc => new ListViewModel()
                {
                    Id = mc.Id,
                    Name = mc.CategoryName,
                })
                .ToList();
                Catelogry.DataSource = ctCategory;
                Catelogry.DisplayMember = "Name";
                Catelogry.ValueMember = "Id";
            }
            else
            {
                Catelogry.DataSource = null;
            }
        }

        private void SetMachineTypeList()
        {
            var ctType = _context.MachineTypes
                .Where(mt => mt.CategoryId == _thisCategoryId)
                .OrderBy(mt => mt.OrderNo)
                .Select(mt => new ListViewModel()
                {
                    Id = mt.Id,
                    Name = mt.TypeName,
                })
                .ToList();
            Type.DataSource = ctType;
            Type.DisplayMember = "Name";
            Type.ValueMember = "Id";

            if (!ctType.Any(ct => ct.Id == _thisTypeId))
                Type.SelectedIndex = -1;
        }

        private void SetMachineModelNo()
        {
            var ctModelNo = _context.MachineNames
                .Where(mn => mn.TypeId == _thisTypeId)
                .OrderBy(mn => mn.OrderNo)
                .Select(mn => new ListViewModel()
                {
                    Id = mn.Id,
                    Name = mn.ModelName,
                })
                .ToList();
            ModelNo.DataSource = ctModelNo;
            ModelNo.DisplayMember = "Name";
            ModelNo.ValueMember = "Id";

            if (!ctModelNo.Any(mn => mn.Id == _thisMachineNameId))
                ModelNo.SelectedIndex = -1;
        }

        /********************
         * BCRUD Buttons
         ********************/
        private async void Machine_Create_Click(object sender, System.EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.Machine}編號";
            string caption = $"新{PropertyText.Title.Machine}編號";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.Machine}編號不可為空白！"),
                input => input.Length <= 10 ? (true, "") : (false, $"{PropertyText.Title.Machine}編號必須小於等於 10 個字元！"),
                input => _coreData.Machines.Any(m => m.CategoryName == input) ? (false, $"{PropertyText.Title.Machine}編號已存在！") : (true, "")
                );

            // 檢查是否有有效的選擇記錄
            bool hasValidRecord = _thisNode != null && _thisNode.Level > 0 &&
                                  _mdgv != null && _mdgv.Any() &&
                                  adgv.CurrentRow != null && _thisMachine != null;

            string appendId = "";

            if (hasValidRecord)
            {
                // 有有效記錄，使用當前選擇的資料 - 保留原始格式
                string codePrefix = Regex.Replace(_thisMachineCode, @"\d+$", "");
                var maxCode = _mdgv
                          .Where(m => m.MachineCode.StartsWith(codePrefix))
                          .Select(m => Regex.Match(m.MachineCode, @"\d+$"))
                          .Where(match => match.Success)
                          .Select(match => int.Parse(match.Value))
                          .DefaultIfEmpty(0)
                          .Max();
                //var maxCode = _mdgv
                //    .Select(s =>
                //    {
                //        if (string.IsNullOrEmpty(s.MachineCode)) return 0;
                //        var match = Regex.Match(s.MachineCode, @"\d+$");
                //        return match.Success ? int.Parse(match.Value) : 0;
                //    })
                //    .DefaultIfEmpty(0)
                //    .Max();
                appendId = codePrefix + (maxCode + 1).ToString();
            }
            else
            {
                // 沒有有效記錄，使用預設值或從 TreeView 取得的類型資訊
                appendId = "";
            }

            using (var editor = _scope.Resolve<MachineEdit>())
            {
                editor.Title = $"請輸入新{PropertyText.Title.Machine}資料";
                editor.CrudType = CrudType.Add;
                editor.MachineValue = new MachineViewModel()
                {
                    MachineCode = appendId,
                    CategoryId = _thisCategoryId,
                    TypeId = _thisTypeId,
                    MachineNameId = _thisMachineNameId,
                    ConditionId = _thisMachine?.ConditionId ?? -1,
                    BrandId = _thisMachine?.BrandId ?? -1,
                    LocationId = _thisMachine?.LocationId ?? -1,
                    AssetString = "",
                    SerialNumber = "",
                    Barcode = "",
                    Connected = _thisMachine?.Connected ?? false,
                    Disposal = false,
                    Remark = "",
                };

                if (editor.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        int idCategory = editor.MachineValue.CategoryId;
                        int idType = editor.MachineValue.TypeId;
                        int idModelName = editor.MachineValue.MachineNameId;

                        var category = await _context.MachineCategories
                            .FirstOrDefaultAsync(c => c.Id == idCategory);
                        if (category == null)
                        {
                            category = new MachineCategory
                            {
                                CategoryName = editor.MachineValue.CategoryName,
                                OrderNo = _context.MachineCategories.Any() ? _context.MachineCategories.Max(c => c.OrderNo) + 1 : 1
                            };
                            var newCategory = _context.MachineCategories.Add(category);
                            await _context.SaveChangesAsync();
                            editor.MachineValue.CategoryId = newCategory.Id;
                        }

                        var machineType = await _context.MachineTypes
                            .FirstOrDefaultAsync(t => t.Id == idType && t.CategoryId == idCategory);
                        if (machineType == null)
                        {
                            machineType = new MachineType
                            {
                                TypeName = editor.MachineValue.TypeName,
                                CategoryId = idCategory,
                                OrderNo = _context.MachineTypes.Any() ? _context.MachineTypes.Max(t => t.OrderNo) + 1 : 1
                            };
                            var newType = _context.MachineTypes.Add(machineType);
                            await _context.SaveChangesAsync();
                            editor.MachineValue.TypeId = newType.Id;
                        }

                        var machineName = await _context.MachineNames
                            .FirstOrDefaultAsync(mn => mn.Id == idModelName && mn.TypeId == idType);
                        if (machineName == null)
                        {
                            machineName = new MachineName
                            {
                                ModelName = editor.MachineValue.ModelName,
                                TypeId = idType,
                                OrderNo = _context.MachineNames.Any() ? _context.MachineNames.Max(mn => mn.OrderNo) + 1 : 1
                            };
                            var newModel = _context.MachineNames.Add(machineName);
                            await _context.SaveChangesAsync();
                            editor.MachineValue.MachineNameId = newModel.Id;
                        }

                        var machine = new Machine();
                        machine.MachineCode = editor.MachineValue.MachineCode;
                        machine.MachineNameId = editor.MachineValue.MachineNameId;
                        machine.ConditionId = editor.MachineValue.ConditionId;
                        machine.BrandId = editor.MachineValue.BrandId;
                        machine.LocationId = editor.MachineValue.LocationId;
                        machine.Connected = editor.MachineValue.Connected;
                        machine.Disposal = editor.MachineValue.Disposal;
                        machine.AssetString = editor.MachineValue.AssetString;
                        machine.SerialNumber = editor.MachineValue.SerialNumber;
                        machine.Barcode = editor.MachineValue.Barcode;
                        machine.Remark = editor.MachineValue.Remark;

                        machine = _context.Machines.Add(machine);
                        await _context.SaveChangesAsync();

                        // 因應沒有選擇型號的處理
                        // 先建立空白的ModelName之後，再填上相關的ID
                        if (idModelName == -1)
                        {
                            machine.MachineNameId = editor.MachineValue.MachineNameId;
                            machine.MachineName.TypeId = editor.MachineValue.TypeId;
                            machine.MachineName.MachineType.CategoryId = editor.MachineValue.CategoryId;
                            await _context.SaveChangesAsync();
                        }

                        _newMachineCode = machine.MachineCode;
                        _cacheManager.RequestMachineUpdate();
                        await UpdateMachinesViewAsync();

                        adgv.SelectRowByMachineCode(_newMachineCode);
                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.Machine}: {editor.MachineValue.MachineCode}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"新增設備失敗: {nameof(Setup_MachinesSummary)} -> {nameof(Machine_Create_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Machine_Edit_Click(object sender, System.EventArgs e)
        {
            using (var editor = _scope.Resolve<MachineEdit>())
            {
                var machine = await _context.Machines
                    .Include(m => m.MachineName.MachineType)
                    .FirstOrDefaultAsync(m => m.MachineCode == _thisMachineCode);

                editor.Title = $"修改此{PropertyText.Title.Machine}資料";
                editor.CrudType = CrudType.Edit;
                editor.MachineValue = new MachineViewModel()
                {
                    MachineCode = machine.MachineCode,
                    CategoryId = machine.CategoryId,
                    TypeId = machine.TypeId,
                    MachineNameId = machine.MachineNameId,
                    ConditionId = machine.ConditionId,
                    BrandId = machine.BrandId ?? -1,
                    LocationId = machine.LocationId ?? -1,
                    AssetString = machine.AssetString,
                    SerialNumber = machine.SerialNumber,
                    Barcode = machine.Barcode,
                    Connected = machine.Connected,
                    Disposal = machine.Disposal,
                    Remark = machine.Remark,
                };

                if (editor.ShowDialog() == DialogResult.OK)
                {
                    machine = await _context.Machines
                        .Include(m => m.MachineName)
                        .FirstOrDefaultAsync(m => m.MachineCode == machine.MachineCode);

                    machine.MachineCode = editor.MachineValue.MachineCode;
                    machine.ConditionId = editor.MachineValue.ConditionId;
                    machine.BrandId = editor.MachineValue.BrandId;
                    machine.LocationId = editor.MachineValue.LocationId;
                    machine.Connected = editor.MachineValue.Connected;
                    machine.Disposal = editor.MachineValue.Disposal;
                    machine.AssetString = editor.MachineValue.AssetString;
                    machine.SerialNumber = editor.MachineValue.SerialNumber;
                    machine.Barcode = editor.MachineValue.Barcode;
                    machine.Remark = editor.MachineValue.Remark;
                    machine.MachineNameId = editor.MachineValue.MachineNameId;

                    //var machineName = await _context.MachineNames
                    //    .FirstOrDefaultAsync(mn => mn.Id == editor.MachineValue.MachineNameId);
                    //if (machineName != null)
                    //{
                    //    machine.MachineName.TypeId = editor.MachineValue.TypeId;
                    //    var machineType = await _context.MachineTypes
                    //        .FirstOrDefaultAsync(t => t.Id == editor.MachineValue.TypeId);
                    //    if (machineType != null)
                    //        machineType.CategoryId = editor.MachineValue.CategoryId;
                    //}

                    await _context.SaveChangesAsync();
                    _newMachineCode = machine.MachineCode;
                    _cacheManager.RequestMachineUpdate();
                    await UpdateMachinesViewAsync();

                    adgv.SelectRowByMachineCode(_newMachineCode);
                    _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已更新{PropertyText.Title.Machine}: {editor.MachineValue.MachineCode}"));
                }
            }
        }

        private async void Machine_Delete_Click(object sender, System.EventArgs e)
        {
            if (_thisMachine != null)
            {
                string target = $"{_thisMachine.MachineCode} » {_thisMachine.ModelName}";
                if (UIMessageBox.ShowAsk2($"確定要刪除 {target} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    var targetmachine = _context.Machines.FirstOrDefault(m => m.Id == _thisMachine.Id);
                    if (targetmachine != null)
                    {
                        _context.Machines.Remove(targetmachine);
                        await _context.SaveChangesAsync();
                        _cacheManager.RequestMachineUpdate();
                        await UpdateMachinesViewAsync();

                        MessageBox.Show($"{target} 已刪除",
                                        $"刪除成功",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);
                    }
                }
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            var machine = _context.Machines
                .FirstOrDefault(m => m.MachineCode == _thisMachineCode);

            if (machine == null)
            {
                MessageBox.Show($"找不到機台資料: {_thisMachineCode}",
                                "更新失敗",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            // 只有在 MachineCode 真正改變時才檢查重覆
            if (machine.MachineCode != MaincheId.Text)
            {
                // 檢查新的編號是否已存在
                if (_coreData.Machines.Any(m => m.MachineCode == MaincheId.Text))
                {
                    MessageBox.Show($"機台編號 {MaincheId.Text} 已存在，無法更新！",
                                    "更新失敗",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }
                // 只有在真正需要更新時才更新 MachineCode
                machine.MachineCode = MaincheId.Text;
            }

            machine.MachineNameId = (int)ModelNo.SelectedValue;
            machine.ConditionId = _context.MachineConditions.FirstOrDefault(mc => mc.ConditionName == Condition.Text)?.Id ?? 0;
            machine.BrandId = _context.MachineBrands.FirstOrDefault(mb => mb.BrandName == Brand.Text)?.Id ?? null;
            machine.LocationId = _context.MachineLocations.FirstOrDefault(ml => ml.LocationName == Location.Text)?.Id ?? null;
            machine.AssetString = Assets.Text;
            machine.SerialNumber = SerialNumber.Text;
            machine.Barcode = Barcode.Text;
            machine.Remark = Remark.Text;
            machine.Connected = Connected.Checked;
            machine.Disposal = Disposal.Checked;

            try
            {
                await _context.SaveChangesAsync();

                // 更新 _mdgv 中對應的 MachineViewModel
                var machineViewModel = _mdgv?.FirstOrDefault(m => m.MachineCode == _thisMachineCode);
                if (machineViewModel != null)
                {
                    var machineName = _context.MachineNames.FirstOrDefault(mn => mn.Id == machine.MachineNameId);

                    machineViewModel.MachineCode = machine.MachineCode;
                    machineViewModel.ModelName = machineName?.ModelName ?? "";
                    machineViewModel.ConditionName = Condition.Text;
                    machineViewModel.BrandName = Brand.Text;
                    machineViewModel.LocationName = Location.Text;
                    machineViewModel.AssetString = machine.AssetString;
                    machineViewModel.SerialNumber = machine.SerialNumber;
                    machineViewModel.Barcode = machine.Barcode;
                    machineViewModel.Remark = machine.Remark;
                    machineViewModel.Connected = machine.Connected;
                    machineViewModel.ConnectedString = machine.ConnectedString;
                    machineViewModel.Disposal = machine.Disposal;
                    machineViewModel.DisposalString = machine.DisposalString;
                }

                // 保存當前選擇的行索引
                int currentRowIndex = adgv.CurrentCell?.RowIndex ?? -1;
                int currentScrollIndex = adgv.FirstDisplayedScrollingRowIndex;

                // 更新 adgv 資料來源
                _prohibitUpdateAdgv = true;
                adgv.DataSource = null;
                adgv.DataSource = _mdgv.ToDataTable();
                _prohibitUpdateAdgv = false;

                // 恢復選擇的行
                if (currentRowIndex >= 0 && currentRowIndex < adgv.Rows.Count)
                {
                    adgv.ClearSelection();
                    if (currentScrollIndex >= 0 && currentScrollIndex < adgv.Rows.Count)
                    {
                        adgv.FirstDisplayedScrollingRowIndex = currentScrollIndex;
                    }
                    adgv.CurrentCell = adgv.Rows[currentRowIndex].Cells[0];
                    adgv.Rows[currentRowIndex].Selected = true;
                }

                // 更新下方 UI 控件
                if (machineViewModel != null)
                {
                    MaincheId.Text = machineViewModel.MachineCode;
                    ModelNo.Text = machineViewModel.ModelName;
                    Condition.Text = machineViewModel.ConditionName;
                    Brand.Text = machineViewModel.BrandName;
                    Location.Text = machineViewModel.LocationName;
                    Assets.Text = machineViewModel.AssetString;
                    SerialNumber.Text = machineViewModel.SerialNumber;
                    Barcode.Text = machineViewModel.Barcode;
                    Remark.Text = machineViewModel.Remark;
                    Connected.Checked = machineViewModel.Connected;
                    Disposal.Checked = machineViewModel.Disposal;
                }

                // 更新 _thisMachineCode 以反映可能的 MachineCode 變更
                _thisMachineCode = machine.MachineCode;
                _cacheManager.RequestMachineUpdate();
                _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已更新 {_thisMachineCode} 的資料"));
            }
            catch (Exception ex)
            {
                string errMsg = $"資料儲存失敗: {nameof(Setup_MachinesSummary)} -> {nameof(btnSave_Click)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, $"儲存失敗", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void btnRefresh_Click(object sender, EventArgs e)
        {
            _cacheManager.UpdateAllCaches();
            await UpdateMachinesViewAsync();
        }
    }
}
