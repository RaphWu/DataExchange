﻿/*
 * 編輯後ListBox不會更新的問題
 * 
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.DataVerification;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Core;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Models : UserControl, INavigationAware
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ICacheManager _cacheManager;
        private readonly ICore _core;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly CRUD _crud;

        private List<ListViewModel> _vmModels = null;
        private ListViewModel _vmModel = null;
        private List<ListViewModel> _vmWss = null;
        private ListViewModel _vmWs = null;
        private List<ListViewModel> _vmModelStatus = null;
        private ListViewModel _vmStatus = null;

        #endregion fields

        public async void OnNavigatedTo()
        {
            await LoadDataAsync();
        }

        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();

            _ = WeakReferenceMessenger.Default.Send(new DbInfoMessage(""));
            WeakReferenceMessenger.Default.UnregisterAll(this);
        }

        public Setup_Models(
            Serilog.ILogger logger,
            ICacheManager cacheManager,
            ICore core,
            CoreContext coreContext,
            CoreData coreData,
            CRUD crud)
        {
            InitializeComponent();

            _logger = logger;
            _cacheManager = cacheManager;
            _core = core;
            _context = coreContext;
            _coreData = coreData;
            _crud = crud;

            //Button_Refresh.FillColor = CommonStyles.BackColor;

            CommonStyles.SetListBox(List_Models);
            CommonStyles.SetCrudButton(Model_Create, $"C", PropertyText.Title.ModelName);
            CommonStyles.SetCrudButton(Model_Edit, $"E", PropertyText.Title.ModelName);
            CommonStyles.SetCrudButton(Model_Modify, $"M", PropertyText.Title.ModelStatus);
            CommonStyles.SetCrudButton(Model_Delete, $"D", PropertyText.Title.ModelName);

            CommonStyles.SetListBox(List_Workstations);
            CommonStyles.SetCrudButton(Workstation_Create, $"C", PropertyText.Title.Workstation);
            CommonStyles.SetCrudButton(Workstation_Edit, $"E", PropertyText.Title.Workstation);
            CommonStyles.SetCrudButton(Workstation_Delete, $"D", PropertyText.Title.Workstation);
            CommonStyles.SetCrudButton(Workstation_Up, $"UP", PropertyText.Title.Workstation);
            CommonStyles.SetCrudButton(Workstation_Down, $"DOWN", PropertyText.Title.Workstation);

            CommonStyles.SetListBox(List_ModelStatus);
            CommonStyles.SetCrudButton(ModelStatus_Create, $"C", PropertyText.Title.ModelStatus);
            CommonStyles.SetCrudButton(ModelStatus_Edit, $"E", PropertyText.Title.ModelStatus);
            CommonStyles.SetCrudButton(ModelStatus_Delete, $"D", PropertyText.Title.ModelStatus);
            CommonStyles.SetCrudButton(ModelStatus_Up, $"UP", PropertyText.Title.ModelStatus);
            CommonStyles.SetCrudButton(ModelStatus_Down, $"DOWN", PropertyText.Title.ModelStatus);

            WeakReferenceMessenger.Default.Register<NotifyModelDataUpdated>(this, async (recipient, message) =>
            {
                await LoadDataAsync();
            });
            WeakReferenceMessenger.Default.Register<NotifyWorkstationDataUpdated>(this, async (recipient, message) =>
            {
                await LoadDataAsync();
            });
        }

        private async Task LoadDataAsync()
        {
            await UpdateModelsViewAsync();
            await UpdateWorkstationsViewAsync();
            await UpdateModelStatusViewAsync();
        }

        #region Models

        private async Task UpdateModelsViewAsync()
        {
            var query = await _context.Models
                .Include(m => m.ModelStatus)
                .ToListAsync();
            _vmModels = query
                .Select(m => new { Original = m, Key = _core.GetModelSortKey(m.ModelName) })
                .OrderBy(x => !x.Key.IsThreeDigits)
                .ThenBy(x => x.Key.SortKey)
                .Select(x => x.Original)
                .Select(m => new ListViewModel
                {
                    Id = m.Id,
                    Name = m.ModelName + (m.ModelStatusId > 1 ? (" (" + m.ModelStatus.Status + ")") : "")
                })
                .ToList();

            List_Models.DataSource = null;
            List_Models.ValueMember = nameof(ListViewModel.Id);
            List_Models.DisplayMember = nameof(ListViewModel.Name);
            List_Models.DataSource = _vmModels;

            Label_Model.Text = $"{PropertyText.Title.ModelName} ({_vmModels.Count()})";
        }

        private async void List_Models_SelectedIndexChanged(object sender, EventArgs e)
        {
            _vmModel = List_Models.SelectedItem as ListViewModel;
            if (_vmModel != null)
            {
                Model_Edit.Enabled = true;
                Model_Modify.Enabled = true;
                await UpdateWorkstationsViewAsync();
            }
            else
            {
                Model_Edit.Enabled = false;
                Model_Modify.Enabled = false;
            }
        }

        private async void Model_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新{PropertyText.Title.ModelName}名稱";
            string caption = $"新{PropertyText.Title.ModelName}名稱";
            var validator = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.ModelName}名稱不可為空白！"),
                input => input.Length <= 10 ? (true, "") : (false, $"{PropertyText.Title.ModelName}名稱必須小於等於 10 個字元！"),
                input => _coreData.Models.Any(m => m.ModelName == input) ? (false, $"{PropertyText.Title.ModelName}名稱已存在！") : (true, "")
                );

            _crud.New_1TextBox(new TextBoxInfo()
            {
                Value = "",
                Caption = caption,
                WaterMark = caption
            }, title, validator);

            if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
            {
                try
                {
                    string newModelName = _crud.Result.StringValue;

                    _context.Models.Add(new Model()
                    {
                        ModelName = newModelName,
                        ModelStatusId = 1,
                    });
                    await _context.SaveChangesAsync();
                    await UpdateModelsViewAsync();
                    _cacheManager.RequestModelNoUpdateDelay();
                    List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Name == newModelName);

                    _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.ModelName}: {newModelName}"));
                }
                catch (Exception ex)
                {
                    string errMsg = $"新增{PropertyText.Title.ModelName}失敗: {nameof(Setup_Models)} -> {nameof(Model_Create_Click)}()";
                    using (LogContext.PushProperty("Category", "Database"))
                    {
                        _logger.Fatal(ex, errMsg);
                    }
                    MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void Model_Edit_Click(object sender, EventArgs e)
        {
            if (_vmModel != null)
            {
                var thisModel = _vmModel;
                string title = $"請輸入新{PropertyText.Title.ModelName}名稱";
                string oldCaption = $"原{PropertyText.Title.ModelName}名稱";
                string newCaption = $"新{PropertyText.Title.ModelName}名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"{PropertyText.Title.ModelName}名稱不可為空白！"),
                    input => input.Length <= 10 ? (true, "") : (false, $"{PropertyText.Title.ModelName}名稱必須小於等於 10 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, $"{PropertyText.Title.ModelName}名稱已存在！") : (true, "")
                    );

                _crud.Edit_1TextBox(new TextBoxInfo()
                {
                    Value = thisModel.Name,
                    Caption = oldCaption,
                    WaterMark = oldCaption,
                }, new TextBoxInfo()
                {
                    Value = "",
                    Caption = newCaption,
                    WaterMark = newCaption,
                }, title, validor);
                if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
                {
                    try
                    {
                        string newModelName = _crud.Result.StringValue;

                        var newModel = _context.Models.FirstOrDefault(m => m.Id == thisModel.Id);
                        if (newModel != null)
                        {
                            newModel.ModelName = newModelName;
                            await _context.SaveChangesAsync();
                            await UpdateModelsViewAsync();
                            _cacheManager.RequestModelNoUpdateDelay();
                            List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Id == newModel.Id);

                            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.ModelName}: {thisModel.Name}，名稱已變更為: {newModelName}"));
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.ModelName}重新命名失敗: {nameof(Setup_Models)} -> {nameof(Model_Edit_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Model_Modify_Click(object sender, EventArgs e)
        {
            if (_vmModel != null)
            {
                string title = $"請切換 {_vmModel.Name} 狀態";
                string caption = $"{PropertyText.Title.ModelName}狀態";
                var model = _context.Models.FirstOrDefault(m => m.Id == _vmModel.Id);

                List<ListViewModel> listSource = await _context.ModelStatuses
                    .OrderBy(s => s.OrderNo)
                    .Select(s => new ListViewModel()
                    {
                        Id = s.Id,
                        Name = s.Status,
                        OrderNo = s.OrderNo,
                    })
                    .ToListAsync();

                _crud.Edit_1ComboBox(new ComboBoxInfo()
                {
                    ListSource = listSource,
                    Id = model.ModelStatusId,
                    Caption = caption,
                    WaterMark = caption
                }, title);

                if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
                {
                    try
                    {
                        var oldStatus = listSource.FirstOrDefault(s => s.Id == model.ModelStatusId);
                        var newStatus = listSource.FirstOrDefault(s => s.Id == _crud.Result.IntValue);

                        model.ModelStatusId = newStatus.Id;
                        await _context.SaveChangesAsync();
                        await UpdateModelsViewAsync();
                        _cacheManager.RequestModelNoUpdateDelay();
                        List_Models.SelectedIndex = _vmModels.FindIndex(m => m.Id == _vmModel.Id);

                        _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.ModelName}: {_vmModel.Name}，狀態已切換: {oldStatus.Name} -> {newStatus.Name}"));
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.ModelName}: {_vmModel.Name} 切換狀態失敗: {nameof(Setup_Models)} -> {nameof(Model_Modify_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void Model_Delete_Click(object sender, EventArgs e)
        {
            if (_vmModel != null)
            {
                var thisModel = _vmModel;
                if (UIMessageBox.ShowAsk2($"確定要刪除{PropertyText.Title.ModelName} {thisModel.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetModel = _context.Models.FirstOrDefault(m => m.Id == thisModel.Id);
                        if (targetModel != null)
                        {
                            // 原沒有刪除 Workstations，但 Cascade Delete 沒效？所以加了此段
                            _context.Workstations.RemoveRange(_context.Workstations.Where(w => w.ModelId == targetModel.Id));
                            _context.Models.Remove(targetModel);
                            await _context.SaveChangesAsync();
                            await UpdateModelsViewAsync();
                            _cacheManager.RequestModelNoUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.ModelName}: {thisModel.Name} 刪除成功",
                                      "刪除成功",
                                      MessageBoxButtons.OK,
                                      MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.ModelName}刪除失敗: {nameof(Setup_Models)} -> {nameof(Model_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        #endregion Models

        #region Workstations

        private async Task UpdateWorkstationsViewAsync()
        {
            List_Workstations.DataSource = null;
            if (_vmModel != null)
            {
                _vmWss = await _context.Workstations
                    .Where(w => w.Model.Id == _vmModel.Id)
                    .OrderBy(w => w.OrderNo)
                    .Select(w => new ListViewModel { Id = w.Id, Name = w.WorkstationName, OrderNo = w.OrderNo })
                    .ToListAsync();
                List_Workstations.ValueMember = nameof(ListViewModel.Id);
                List_Workstations.DisplayMember = nameof(ListViewModel.Name);
                List_Workstations.DataSource = _vmWss;
                Label_Workstation.Text = $"{PropertyText.Title.Workstation} ({_vmWss.Count()})";
            }
            else
            {
                _vmWss = null;
                Label_Workstation.Text = $"{PropertyText.Title.Workstation} (0)";
            }
        }

        private void Workstations_SelectionChanged()
        {
            _vmWs = List_Workstations.SelectedItem as ListViewModel;
            if (_vmWs != null)
            {
                Workstation_Edit.Enabled = true;
                Workstation_Delete.Enabled = true;

                if (List_Workstations.DataSource is List<ListViewModel> vmWss)
                {
                    var wsOrderNo = vmWss.FirstOrDefault(w => w.Id == _vmWs.Id).OrderNo;
                    Workstation_Up.Enabled = wsOrderNo != vmWss.Min(w => w.OrderNo);
                    Workstation_Down.Enabled = wsOrderNo != vmWss.Max(w => w.OrderNo);
                }
                else
                {
                    Workstation_Up.Enabled = false;
                    Workstation_Down.Enabled = false;
                }
            }
            else
            {
                Workstation_Edit.Enabled = false;
                Workstation_Delete.Enabled = false;
                Workstation_Up.Enabled = false;
                Workstation_Down.Enabled = false;
            }
        }

        private void List_Workstations_SelectedIndexChanged(object sender, EventArgs e)
        {
            Workstations_SelectionChanged();
        }

        private async void WorkStation_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新工站名稱";
            string caption = $"新工站名稱";
            var validor = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"工站名稱不可為空白！"),
                input => input.Length <= 20 ? (true, "") : (false, $"工站名稱必須小於等於 20 個字元！"),
                input => _coreData.Workstations
                    .Any(m => m.ModelId == _vmModel.Id && m.WorkstationName == input) ? (false, $"工站名稱已存在！") : (true, "")
                );

            _crud.New_1TextBox(new TextBoxInfo()
            {
                Value = "",
                Caption = caption,
                WaterMark = caption
            }, title, validor);
            if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
            {
                try
                {
                    string newWorkstationName = _crud.Result.StringValue;

                    var model = _coreData.Models.FirstOrDefault(m => m.Id == _vmModel.Id);
                    int maxOrderNo = _coreData.Workstations.Max(w => w.OrderNo);
                    var newWs = _context.Workstations.Add(new Workstation()
                    {
                        WorkstationName = newWorkstationName,
                        ModelId = model.Id,
                        OrderNo = maxOrderNo + 1,
                    });
                    await _context.SaveChangesAsync();
                    await UpdateWorkstationsViewAsync();
                    _cacheManager.RequestWorkstationUpdateDelay();
                    List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Id == newWs.Id);

                    _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.Workstation}: {newWorkstationName}"));
                }
                catch (Exception ex)
                {
                    string errMsg = $"新增{PropertyText.Title.Workstation}失敗: {nameof(Setup_Models)} -> {nameof(WorkStation_Create_Click)}()";
                    using (LogContext.PushProperty("Category", "Database"))
                    {
                        _logger.Fatal(ex, errMsg);
                    }
                    MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void WorkStation_Edit_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                string title = $"請輸入新工站名稱";
                string oldCaption = $"原工站名稱";
                string newCaption = $"新工站名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"工站名稱不可為空白！"),
                    input => input.Length <= 20 ? (true, "") : (false, $"工站名稱必須小於等於 20 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, $"工站名稱已存在！") : (true, "")
                    );

                _crud.Edit_1TextBox(new TextBoxInfo()
                {
                    Value = thisVmWs.Name,
                    Caption = oldCaption,
                    WaterMark = oldCaption
                }, new TextBoxInfo()
                {
                    Value = "",
                    Caption = newCaption,
                    WaterMark = newCaption
                }, title, validor);
                if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
                {
                    try
                    {
                        string newWorkstationName = _crud.Result.StringValue;

                        var ws = _context.Workstations.FirstOrDefault(m => m.Id == thisVmWs.Id);
                        if (ws != null)
                        {
                            ws.WorkstationName = newWorkstationName;
                            await _context.SaveChangesAsync();
                            await UpdateWorkstationsViewAsync();
                            _cacheManager.RequestWorkstationUpdateDelay();
                            List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Id == ws.Id);

                            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.Workstation}: {thisVmWs.Name}，名稱已變更為: {newWorkstationName}"));
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.Workstation}重新命名失敗: {nameof(Setup_Models)} -> {nameof(WorkStation_Edit_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void WorkStation_Delete_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                if (UIMessageBox.ShowAsk2($"確定要刪除工站 {thisVmWs.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetWs = _context.Workstations.FirstOrDefault(m => m.Id == thisVmWs.Id);
                        if (targetWs != null)
                        {
                            _context.Workstations.Remove(targetWs);
                            await _context.SaveChangesAsync();
                            await UpdateWorkstationsViewAsync();
                            _cacheManager.RequestWorkstationUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.Workstation}: {thisVmWs.Name} 刪除成功",
                                "刪除成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.Workstation}刪除失敗: {nameof(Setup_Models)} -> {nameof(WorkStation_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async Task SwapWsOrderNoAsync(int wsKey1, int wsKey2)
        {
            try
            {
                var ws1 = _context.Workstations.FirstOrDefault(w => w.Id == wsKey1);
                var ws2 = _context.Workstations.FirstOrDefault(w => w.Id == wsKey2);

                (ws2.OrderNo, ws1.OrderNo) = (ws1.OrderNo, ws2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateWorkstationsViewAsync();
                _cacheManager.RequestWorkstationUpdateDelay();
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_Models)} -> {nameof(SwapWsOrderNoAsync)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void WorkStation_Up_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                var smallerVmWs = _vmWss.LastOrDefault(w => w.OrderNo < thisVmWs.OrderNo);
                if (smallerVmWs != null)
                {
                    await SwapWsOrderNoAsync(thisVmWs.Id, smallerVmWs.Id);
                    List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        private async void WorkStation_Down_Click(object sender, EventArgs e)
        {
            if (_vmWs != null)
            {
                var thisVmWs = _vmWs;
                var biggerVmWs = _vmWss.FirstOrDefault(w => w.OrderNo > thisVmWs.OrderNo);
                if (biggerVmWs != null)
                {
                    await SwapWsOrderNoAsync(thisVmWs.Id, biggerVmWs.Id);
                    List_Workstations.SelectedIndex = _vmWss.FindIndex(m => m.Id == thisVmWs.Id);
                }
            }
        }

        #endregion Workstations

        #region ModelStatus

        private async Task UpdateModelStatusViewAsync()
        {
            _vmModelStatus = await _context.ModelStatuses
                .OrderBy(w => w.OrderNo)
                .Select(m => new ListViewModel { Id = m.Id, Name = m.Status, OrderNo = m.OrderNo })
                .ToListAsync();
            List_ModelStatus.DataSource = null;
            List_ModelStatus.ValueMember = nameof(ListViewModel.Id);
            List_ModelStatus.DisplayMember = nameof(ListViewModel.Name);
            List_ModelStatus.DataSource = _vmModelStatus;
            Label_ModelStatus.Text = $"{PropertyText.Title.ModelStatus} ({_vmModelStatus.Count()})";
        }

        private void ModelStatuses_SelectionChanged()
        {
            _vmStatus = List_ModelStatus.SelectedItem as ListViewModel;
            // 生產=1, 停產=2 預設不可變，固定在前兩筆
            if (_vmStatus == null || _vmStatus.Name == "生產" || _vmStatus.Name == "停產")
            {
                ModelStatus_Edit.Enabled = false;
                ModelStatus_Delete.Enabled = false;
                ModelStatus_Up.Enabled = false;
                ModelStatus_Down.Enabled = false;
            }
            else
            {
                ModelStatus_Edit.Enabled = true;
                ModelStatus_Delete.Enabled = true;

                if (List_ModelStatus.DataSource is List<ListViewModel> vmStatus)
                {
                    var msOrderNo = vmStatus.FirstOrDefault(w => w.Id == _vmStatus.Id).OrderNo;
                    //ModelStatus_Up.Enabled = msOrderNo != vmStatus.Min(w => w.OrderNo);
                    ModelStatus_Up.Enabled = msOrderNo > 3;
                    ModelStatus_Down.Enabled = msOrderNo >= 3 && msOrderNo < vmStatus.Max(w => w.OrderNo);
                }
                else
                {
                    ModelStatus_Up.Enabled = false;
                    ModelStatus_Down.Enabled = false;
                }
            }
        }

        private void List_ModelStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            ModelStatuses_SelectionChanged();
        }

        private async void ModelStatus_Create_Click(object sender, EventArgs e)
        {
            string title = $"請輸入新運行狀態名稱";
            string caption = $"新運行狀態名稱";
            var validor = Validators.CombineValidators(
                input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"運行狀態名稱不可為空白！"),
                input => input.Length <= 20 ? (true, "") : (false, $"運行狀態名稱必須小於等於 20 個字元！"),
                input => _context.ModelStatuses
                    .Any(m => m.Id == _vmStatus.Id && m.Status == input) ? (false, $"運行狀態名稱已存在！") : (true, "")
                );

            _crud.New_1TextBox(new TextBoxInfo()
            {
                Value = "",
                Caption = caption,
                WaterMark = caption
            }, title, validor);
            if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
            {
                try
                {
                    string newModelStatusName = _crud.Result.StringValue;

                    var model = _coreData.Models.FirstOrDefault(m => m.Id == _vmStatus.Id);
                    int maxOrderNo = _context.ModelStatuses.Max(w => w.OrderNo);
                    var newWs = _context.ModelStatuses.Add(new ModelStatus()
                    {
                        Status = newModelStatusName,
                        OrderNo = maxOrderNo + 1,
                    });
                    await _context.SaveChangesAsync();
                    await UpdateModelStatusViewAsync();
                    _cacheManager.RequestModelNoUpdateDelay();
                    List_ModelStatus.SelectedIndex = _vmWss.FindIndex(m => m.Id == newWs.Id);

                    _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"已增加新{PropertyText.Title.ModelStatus}: {newModelStatusName}"));
                }
                catch (Exception ex)
                {
                    string errMsg = $"新增{PropertyText.Title.ModelStatus}失敗: {nameof(Setup_Models)} -> {nameof(ModelStatus_Create_Click)}()";
                    using (LogContext.PushProperty("Category", "Database"))
                    {
                        _logger.Fatal(ex, errMsg);
                    }
                    MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void ModelStatus_Edit_Click(object sender, EventArgs e)
        {
            if (_vmStatus != null)
            {
                string title = $"請輸入新運行狀態名稱";
                string oldCaption = $"原運行狀態名稱";
                string newCaption = $"新運行狀態名稱";
                var validor = Validators.CombineValidators(
                    input => !string.IsNullOrWhiteSpace(input) ? (true, "") : (false, $"運行狀態名稱不可為空白！"),
                    input => input.Length <= 20 ? (true, "") : (false, $"運行狀態名稱必須小於等於 20 個字元！"),
                    input => _coreData.Models.Any(m => m.ModelName == input) ? (false, $"運行狀態名稱已存在！") : (true, "")
                    );

                _crud.Edit_1TextBox(new TextBoxInfo()
                {
                    Value = _vmStatus.Name,
                    Caption = oldCaption,
                    WaterMark = oldCaption
                }, new TextBoxInfo()
                {
                    Value = "",
                    Caption = newCaption,
                    WaterMark = newCaption
                }, title, validor);
                if (MyFormEx.ShowDialogWithMask(_crud) == DialogResult.OK)
                {
                    try
                    {
                        string newModelStatusName = _crud.Result.StringValue;

                        var ms = _context.ModelStatuses.FirstOrDefault(m => m.Id == _vmStatus.Id);
                        if (ms != null)
                        {
                            ms.Status = newModelStatusName;
                            await _context.SaveChangesAsync();
                            await UpdateModelStatusViewAsync();
                            _cacheManager.RequestModelNoUpdateDelay();
                            List_ModelStatus.SelectedIndex = _vmWss.FindIndex(m => m.Id == ms.Id);

                            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage($"{PropertyText.Title.ModelStatus}: {_vmStatus.Name}，名稱已變更為: {newModelStatusName}"));
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.ModelStatus}重新命名失敗: {nameof(Setup_Models)} -> {nameof(ModelStatus_Edit_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void ModelStatus_Delete_Click(object sender, EventArgs e)
        {
            if (_vmStatus != null)
            {
                if (UIMessageBox.ShowAsk2($"確定要刪除運行狀態 {_vmStatus.Name} 嗎？", true, UIMessageDialogButtons.Cancel))
                {
                    try
                    {
                        var targetMs = _context.ModelStatuses.FirstOrDefault(m => m.Id == _vmStatus.Id);
                        if (targetMs != null)
                        {
                            _context.ModelStatuses.Remove(targetMs);
                            await _context.SaveChangesAsync();
                            await UpdateModelStatusViewAsync();
                            _cacheManager.RequestModelNoUpdateDelay();

                            MessageBox.Show($"{PropertyText.Title.ModelStatus}: {_vmStatus.Name} 刪除成功",
                                "刪除成功",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        string errMsg = $"{PropertyText.Title.ModelStatus}刪除失敗: {nameof(Setup_Models)} -> {nameof(ModelStatus_Delete_Click)}()";
                        using (LogContext.PushProperty("Category", "Database"))
                        {
                            _logger.Fatal(ex, errMsg);
                        }
                        MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private async void ModelStatus_Up_Click(object sender, EventArgs e)
        {
            if (_vmStatus != null)
            {
                var thisVmMs = _vmWs;
                var smallerVmMs = _vmWss.LastOrDefault(w => w.OrderNo < thisVmMs.OrderNo);
                if (smallerVmMs != null)
                {
                    await SwapModelStatusOrderNoAsync(thisVmMs.Id, smallerVmMs.Id);
                    List_ModelStatus.SelectedIndex = _vmWss.FindIndex(m => m.Id == thisVmMs.Id);
                }
            }
        }

        private async void ModelStatus_Down_Click(object sender, EventArgs e)
        {
            if (_vmStatus != null)
            {
                var thisVmMs = _vmStatus;
                var biggerVmMs = _vmModelStatus.FirstOrDefault(w => w.OrderNo > thisVmMs.OrderNo);
                if (biggerVmMs != null)
                {
                    await SwapModelStatusOrderNoAsync(thisVmMs.Id, biggerVmMs.Id);
                    List_ModelStatus.SelectedIndex = _vmModelStatus.FindIndex(m => m.Id == thisVmMs.Id);
                }
            }
        }

        private async Task SwapModelStatusOrderNoAsync(int msKey1, int msKey2)
        {
            try
            {
                var ms1 = _context.ModelStatuses.FirstOrDefault(w => w.Id == msKey1);
                var ms2 = _context.ModelStatuses.FirstOrDefault(w => w.Id == msKey2);

                (ms2.OrderNo, ms1.OrderNo) = (ms1.OrderNo, ms2.OrderNo);
                await _context.SaveChangesAsync();
                await UpdateModelStatusViewAsync();
                _cacheManager.RequestModelNoUpdateDelay();
            }
            catch (Exception ex)
            {
                string errMsg = $"順序調整失敗: {nameof(Setup_Models)} -> {nameof(SwapModelStatusOrderNoAsync)}()";
                using (LogContext.PushProperty("Category", "Database"))
                {
                    _logger.Fatal(ex, errMsg);
                }
                MessageBox.Show(errMsg, "資料庫錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion ModelStatus
    }
}
