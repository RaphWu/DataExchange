﻿namespace Calin.TaskPulse.Core.NavServices
{
    public class NavigationService : INavigationService
    {
        private readonly IRegionManager _regionManager;
        private readonly IViewManager _viewManager;

        public NavigationService(IRegionManager regionManager, IViewManager viewManager)
        {
            _regionManager = regionManager;
            _viewManager = viewManager;
        }

        /// <inheritdoc/>
        public void Navigate<TView>(string regionName, bool alive = true) where TView : class
        {
            var region = _regionManager.GetRegion(regionName);

            // 獲取當前顯示的視圖
            // 某些情境下 Region 內部記錄可能不同步，這裡做一次 UI 回退取得。
            var currentViewObj = region.GetCurrentView() ?? (region.HostControl?.Controls.Count > 0 ? region.HostControl.Controls[0] : null);
            (currentViewObj as INavigationAware)?.OnNavigatedFrom();

            // 導航到新視圖
            var view = _viewManager.Resolve(typeof(TView), alive);
            region.ShowView(view);

            // 如果新視圖實現了 INavigationAware，調用 OnNavigatedTo
            if (view is INavigationAware navigationAwareView)
            {
                navigationAwareView.OnNavigatedTo();
            }
        }
    }
}
