﻿using System.Windows.Forms;

namespace Calin.TaskPulse.Core.NavServices
{
    /// <summary>
    /// 定義區域介面的合約，用於管理視圖的顯示與清理。
    /// </summary>
    public interface IRegion
    {
        /// <summary>
        /// 取得區域的名稱。
        /// </summary>
        string Name { get; }

        /// <summary>
        /// 取得承載視圖的控制項。
        /// </summary>
        Control HostControl { get; }

        /// <summary>
        /// 取得目前顯示的視圖。
        /// </summary>
        /// <returns>目前顯示的視圖物件。</returns>
        object GetCurrentView();

        /// <summary>
        /// 顯示指定的視圖。
        /// </summary>
        /// <param name="view">要顯示的視圖物件。</param>
        void ShowView(object view);

        /// <summary>
        /// 清除區域中的所有視圖。
        /// </summary>
        void Clear();
    }
}