﻿using System.Collections.Generic;
using Calin.Infrastructure.Coordination;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class CacheUpdateMappingStrategy : TaskMappingStrategyBase<CacheUpdateRequest>
    {
        protected override IEnumerable<TaskKey> GetRequiredTasks(CacheUpdateRequest request)
        {
            return request.RequiredTaskKeys;
        }
    }
}
