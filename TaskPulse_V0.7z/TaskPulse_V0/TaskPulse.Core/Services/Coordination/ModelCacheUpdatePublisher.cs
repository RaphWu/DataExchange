﻿using System.Threading.Tasks;
using Calin.Infrastructure.Coordination;
using Calin.TaskPulse.Core.Coordination;
using Calin.TaskPulse.Core.Events;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class ModelCacheUpdatePublisher : ISelectiveResultPublisher
    {
        public string TargetName => nameof(ModelCacheUpdatePublisher);

        public async Task PublishAsync(TaskKey taskKey, ICoordinationResult result)
        {
            _ = WeakReferenceMessenger.Default.Send(NotifyModelDataUpdated.Instance);
            await Task.CompletedTask;
        }
    }
}
