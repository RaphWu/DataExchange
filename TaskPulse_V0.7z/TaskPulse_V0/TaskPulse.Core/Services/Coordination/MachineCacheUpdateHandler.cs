﻿using System.Threading.Tasks;
using Calin.Infrastructure.Coordination;
using Calin.TaskPulse.Core.Contracts;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class MachineCacheUpdateHandler : TaskHandlerBase<CacheUpdateRequest>
    {
        private readonly ICore _core;

        public override TaskKey TaskKey => CoreTaskKeys.MachineUpdate;

        public MachineCacheUpdateHandler(ICore core)
        {
            _core = core;
        }

        protected override async Task ExecuteAsync(ITaskExecutionContext context, CacheUpdateRequest request)
        {
            await _core.UpdateMachinesCache();
        }
    }
}
