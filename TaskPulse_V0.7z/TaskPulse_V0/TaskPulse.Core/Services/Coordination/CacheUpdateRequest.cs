﻿using System.Collections.Generic;
using Calin.Infrastructure.Coordination;

namespace Calin.TaskPulse.Core.Services.Coordination
{
    public class CacheUpdateRequest : CoordinationRequest
    {
        /// <summary>
        /// 指定需要執行的任務集合。
        /// </summary>
        public HashSet<TaskKey> RequiredTaskKeys { get; }

        public CacheUpdateRequest(params TaskKey[] taskKeys)
            : base("CacheUpdate")
        {
            RequiredTaskKeys = new HashSet<TaskKey>(taskKeys);
        }
    }
}
