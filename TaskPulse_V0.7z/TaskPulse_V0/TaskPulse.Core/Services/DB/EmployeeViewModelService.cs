﻿using Calin.TaskPulse.Core.Contracts.DB;

namespace Calin.TaskPulse.Core.Services.DB
{
    public class EmployeeViewModelService : IEmployeeViewModel
    {
    }
}
