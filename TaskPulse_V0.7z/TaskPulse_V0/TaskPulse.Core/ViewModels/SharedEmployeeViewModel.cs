//using System;
//using System.Collections.Generic;
//using System.Collections.ObjectModel;
//using System.Data.Entity;
//using System.Linq;
//using System.Threading.Tasks;
//using Calin.TaskPulse.Core.Models;
//using Calin.TaskPulse.Core.Services;
//using Calin.TaskPulse.Entity.Core;

//namespace Calin.TaskPulse.Core.ViewModels
//{
//    /// <summary>
//    /// ���u�@�� ViewModel - �h�� View �i�P�ɦ@�ΨçY�ɦP�B�C
//    /// �ϥ� INotifyPropertyChanged ��{��Ƹj�w�C
//    /// </summary>
//    public class SharedEmployeeViewModel : BindableBase
//    {
//        private readonly ICacheManager _cacheManager;
//        private readonly CoreData _coreData;

//        private int _id;
//        private string _employeeId;
//        private string _employeeName;
//        private string _passwordHash;
//        private int? _departmentId;
//        private string _departmentName;
//        private int? _jobTitleId;
//        private string _jobTitleName;
//        private string _email;
//        private bool _isEngineer;
//        private int _statusId;
//        private string _statusName;
//        private DateTime? _statusChangeAt;

//        // �h��h���Y
//        private ObservableCollection<int> _permissionIds;
//        private ObservableCollection<int> _userGroupIds;
//        private ObservableCollection<int> _carbonCopyIds;

//        #region ���ݩ�

//        /// <summary>
//        /// ���o�γ]�w���u���ߤ@�ѧO�X�C
//        /// </summary>
//        public int Id
//        {
//            get => _id;
//            set => SetProperty(ref _id, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���u�s���C
//        /// </summary>
//        public string EmployeeId
//        {
//            get => _employeeId;
//            set => SetProperty(ref _employeeId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���u�m�W�C
//        /// </summary>
//        public string EmployeeName
//        {
//            get => _employeeName;
//            set => SetProperty(ref _employeeName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���u�K�X����ȡC
//        /// </summary>
//        public string PasswordHash
//        {
//            get => _passwordHash;
//            set => SetProperty(ref _passwordHash, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�����ѧO�X�C
//        /// </summary>
//        public int? DepartmentId
//        {
//            get => _departmentId;
//            set => SetProperty(ref _departmentId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w�����W�١C
//        /// </summary>
//        public string DepartmentName
//        {
//            get => _departmentName;
//            set => SetProperty(ref _departmentName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w¾���ѧO�X�C
//        /// </summary>
//        public int? JobTitleId
//        {
//            get => _jobTitleId;
//            set => SetProperty(ref _jobTitleId, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w¾�٦W�١C
//        /// </summary>
//        public string JobTitleName
//        {
//            get => _jobTitleName;
//            set => SetProperty(ref _jobTitleName, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���u�q�l�l��a�}�C
//        /// </summary>
//        public string Email
//        {
//            get => _email;
//            set => SetProperty(ref _email, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w��,���X���u�O�_���u�{�v�C
//        /// </summary>
//        public bool IsEngineer
//        {
//            get => _isEngineer;
//            set => SetProperty(ref _isEngineer, value);
//        }

//        /// <summary>
//        /// ���o�γ]�w���u���A�ѧO�X�C
//        /// </summary>
//        public int StatusId
//        {
//            get => _statusId;
//            set => SetProperty(ref _statusId, value);
//        }

//        public string StatusName
//        {
//            get => _statusName;
//            set => SetProperty(ref _statusName, value);
//        }

//        public DateTime? StatusChangeAt
//        {
//            get => _statusChangeAt;
//            set => SetProperty(ref _statusChangeAt, value);
//        }

//        //public string EmployeeId { get; set; }
//        //public string EmployeeName { get; set; }
//        //public int DepartmentId { get; set; }
//        //public string DepartmentName { get; set; }
//        //public int JobTitleId { get; set; }
//        //public string JobTitleName { get; set; }
//        //public string Email { get; set; }
//        //public ICollection<Employee> CarbonCopies { get; set; }
//        //public string CarbonCopyString { get; set; }
//        //public string CarbonCopyList { get; set; }
//        //public bool IsEngineer { get; set; }
//        //public string IsEngineerString { get; set; }
//        //public EmployeeStatus Status { get; set; }
//        //public int StatusId { get; set; }
//        //public string StatusName { get; set; }
//        //public bool StatusBoolean { get; set; }
//        //public DateTime StatusChangeAt { get; set; }
//        //public string StatusChangeAtString { get; set; }

//        #endregion

//        #region �h��h���Y���X

//        public ObservableCollection<int> PermissionIds
//        {
//            get => _permissionIds;
//            set
//            {
//                if (_permissionIds != null)
//                {
//                    _permissionIds.CollectionChanged -= OnCollectionChanged;
//                }
//                SetProperty(ref _permissionIds, value);
//                if (_permissionIds != null)
//                {
//                    _permissionIds.CollectionChanged += OnCollectionChanged;
//                }
//            }
//        }

//        public ObservableCollection<int> UserGroupIds
//        {
//            get => _userGroupIds;
//            set
//            {
//                if (_userGroupIds != null)
//                {
//                    _userGroupIds.CollectionChanged -= OnCollectionChanged;
//                }
//                SetProperty(ref _userGroupIds, value);
//                if (_userGroupIds != null)
//                {
//                    _userGroupIds.CollectionChanged += OnCollectionChanged;
//                }
//            }
//        }

//        public ObservableCollection<int> CarbonCopyIds
//        {
//            get => _carbonCopyIds;
//            set
//            {
//                if (_carbonCopyIds != null)
//                {
//                    _carbonCopyIds.CollectionChanged -= OnCollectionChanged;
//                }
//                SetProperty(ref _carbonCopyIds, value);
//                if (_carbonCopyIds != null)
//                {
//                    _carbonCopyIds.CollectionChanged += OnCollectionChanged;
//                }
//            }
//        }

//        #endregion

//        #region �غc�禡

//        public SharedEmployeeViewModel(
//            ICacheManager entityCacheManager,
//            CoreData coreData)
//        {
//            _cacheManager = entityCacheManager;
//            _coreData = coreData;

//            _permissionIds = new ObservableCollection<int>();
//            _userGroupIds = new ObservableCollection<int>();
//            _carbonCopyIds = new ObservableCollection<int>();

//            _permissionIds.CollectionChanged += OnCollectionChanged;
//            _userGroupIds.CollectionChanged += OnCollectionChanged;
//            _carbonCopyIds.CollectionChanged += OnCollectionChanged;
//        }

//        #endregion

//        #region DTO �ഫ��k

//        /// <summary>
//        /// �q Entity ���J��ƨ� ViewModel
//        /// </summary>
//        public async Task LoadFromEntity(int employeeId)
//        {
//            await _cacheManager.WaitForEmployeeAvailableAsync();
//            var employees = _coreData.Employees.FirstOrDefault(e => e.Id == employeeId);
//            if (employees == null) return;

//            Id = employees.Id;
//            EmployeeId = employees.EmployeeId;
//            EmployeeName = employees.EmployeeName;
//            PasswordHash = employees.PasswordHash;
//            DepartmentId = employees.DepartmentId;
//            DepartmentName = employees.DepartmentName;
//            JobTitleId = employees.JobTitleId;
//            JobTitleName = employees.JobTitleName;
//            Email = employees.Email;
//            IsEngineer = employees.IsEngineer;
//            StatusId = employees.StatusId;
//            StatusName = employees.StatusName;
//            StatusChangeAt = employees.StatusChangeAt;

//            // ���J�h��h���Y
//            PermissionIds = employees.Permissions != null
//                ? new ObservableCollection<int>(employees.Permissions.Select(p => p.Id))
//                : new ObservableCollection<int>();
//            UserGroupIds = employees.UserGroups != null
//                ? new ObservableCollection<int>(employees.UserGroups.Select(u => u.Id))
//                : new ObservableCollection<int>();
//            CarbonCopyIds = employees.CarbonCopies != null
//                ? new ObservableCollection<int>(employees.CarbonCopies.Select(c => c.Id))
//                : new ObservableCollection<int>();
//        }

//        /// <summary>
//        /// �N ViewModel �ഫ�� Entity
//        /// </summary>
//        public Employee ToEntity()
//        {
//            return new Employee
//            {
//                Id = Id,
//                EmployeeId = EmployeeId,
//                EmployeeName = EmployeeName,
//                PasswordHash = PasswordHash,
//                DepartmentId = DepartmentId,
//                Department = DepartmentName,
//                JobTitleId = JobTitleId,
//                JobTitleName = JobTitleName,
//                Email = Email,
//                IsEngineer = IsEngineer,
//                StatusId = StatusId,
//                StatusName = StatusName,
//                StatusChangeAt = StatusChangeAt,
//                PermissionIds = PermissionIds?.ToList(),
//                UserGroupIds = UserGroupIds?.ToList(),
//                CarbonCopyIds = CarbonCopyIds?.ToList()
//            };
//        }

//        #endregion

//        #region INotifyPropertyChanged ��@

//        private void OnCollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
//        {
//            // �����X�ܧ�ɡA�q���Ҧ��q�\��
//            if (sender == _permissionIds)
//                OnPropertyChanged(nameof(PermissionIds));
//            else if (sender == _userGroupIds)
//                OnPropertyChanged(nameof(UserGroupIds));
//            else if (sender == _carbonCopyIds)
//                OnPropertyChanged(nameof(CarbonCopyIds));
//        }

//        #endregion
//    }
//}
