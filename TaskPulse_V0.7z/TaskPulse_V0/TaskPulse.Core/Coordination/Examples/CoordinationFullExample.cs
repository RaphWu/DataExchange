﻿#if DEBUG || OFFLINE

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Autofac;

namespace Calin.Infrastructure.Coordination.Examples
{
    /// <summary>
    /// 完整的流程協調使用範例，示範多個 Handler、策略、執行策略與結果發布者的整合。
    /// 此檔案僅為示範，實際業務邏輯請放在使用者專案中。
    /// • FullFlowRequest 與多個 TaskKey 定義
    /// • 多個 TaskHandler（Validate、Fetch、Transform、Persist、Notify）
    /// • FullFlowMappingStrategy（由 Request 產生 TaskKey 集合）
    /// • ConsoleResultPublisher（將結果輸出到 Console）
    /// • FullFlowApplicationModule（示範如何用 Autofac 註冊 Handler、策略、發布者與自訂執行策略）
    /// • RunAsync() 執行器，示範：成功流程、故意失敗的流程及使用取消令牌取消的流程
    /// </summary>
    public static class CoordinationFullExample
    {
        #region Request & TaskKeys

        public class FullFlowRequest : CoordinationRequest
        {
            public bool CauseFailure { get; }
            public bool RequireNotification { get; }

            public FullFlowRequest(bool causeFailure = false, bool requireNotification = true)
                : base("FullFlow")
            {
                CauseFailure = causeFailure;
                RequireNotification = requireNotification;
            }
        }

        public static class FullFlowTaskKeys
        {
            public static readonly TaskKey Validate = new TaskKey("FullFlow.Validate");
            public static readonly TaskKey Fetch = new TaskKey("FullFlow.Fetch");
            public static readonly TaskKey Transform = new TaskKey("FullFlow.Transform");
            public static readonly TaskKey Persist = new TaskKey("FullFlow.Persist");
            public static readonly TaskKey Notify = new TaskKey("FullFlow.Notify");
        }

        #endregion

        #region Handlers

        public class ValidateHandler : TaskHandlerBase<FullFlowRequest>
        {
            public override TaskKey TaskKey => FullFlowTaskKeys.Validate;

            protected override async Task ExecuteAsync(ITaskExecutionContext context, FullFlowRequest request)
            {
                await Task.Delay(50);
                // 如果需要，可檢查 request 的內容進行驗證
            }
        }

        public class FetchHandler : TaskHandlerBase<FullFlowRequest>
        {
            public override TaskKey TaskKey => FullFlowTaskKeys.Fetch;

            protected override async Task ExecuteAsync(ITaskExecutionContext context, FullFlowRequest request)
            {
                // 模擬非同步資料擷取
                await Task.Delay(150);
            }
        }

        public class TransformHandler : TaskHandlerBase<FullFlowRequest>
        {
            public override TaskKey TaskKey => FullFlowTaskKeys.Transform;

            protected override async Task ExecuteAsync(ITaskExecutionContext context, FullFlowRequest request)
            {
                await Task.Delay(120);
            }
        }

        public class PersistHandler : TaskHandlerBase<FullFlowRequest>
        {
            public override TaskKey TaskKey => FullFlowTaskKeys.Persist;

            protected override async Task ExecuteAsync(ITaskExecutionContext context, FullFlowRequest request)
            {
                await Task.Delay(80);

                // 根據請求來模擬失敗
                if (request.CauseFailure)
                {
                    throw new InvalidOperationException("Persist failed due to simulated error.");
                }

                // 實際邏輯：保存資料
            }
        }

        public class NotifyHandler : TaskHandlerBase<FullFlowRequest>
        {
            public override TaskKey TaskKey => FullFlowTaskKeys.Notify;

            protected override async Task ExecuteAsync(ITaskExecutionContext context, FullFlowRequest request)
            {
                // 通知通常為非阻塞的短程序
                await Task.Delay(30);
            }
        }

        #endregion

        #region Mapping Strategy

        public class FullFlowMappingStrategy : TaskMappingStrategyBase<FullFlowRequest>
        {
            protected override IEnumerable<TaskKey> GetRequiredTasks(FullFlowRequest request)
            {
                // 固定流程
                yield return FullFlowTaskKeys.Validate;
                yield return FullFlowTaskKeys.Fetch;
                yield return FullFlowTaskKeys.Transform;
                yield return FullFlowTaskKeys.Persist;

                // 非必要的通知任務依條件產生
                if (request.RequireNotification)
                    yield return FullFlowTaskKeys.Notify;
            }
        }

        #endregion

        #region Result Publisher

        public class ConsoleResultPublisher : IResultPublisher
        {
            public Task PublishAsync(ICoordinationResult result)
            {
                var s = result.Session;
                Console.WriteLine("----- Coordination Result -----");
                Console.WriteLine($"SessionId: {s.SessionId}");
                Console.WriteLine($"RequestType: {s.Request.RequestType}");
                Console.WriteLine($"State: {s.State}");
                Console.WriteLine($"CreatedAt: {s.CreatedAt}");
                Console.WriteLine($"StartedAt: {s.StartedAt}");
                Console.WriteLine($"FinishedAt: {s.FinishedAt}");
                Console.WriteLine($"Duration: {s.Duration}");
                Console.WriteLine($"Required: {string.Join(", ", s.RequiredTasks.Select(t => t.ToString()))}");
                Console.WriteLine($"Completed: {string.Join(", ", s.CompletedTasks.Select(t => t.ToString()))}");
                Console.WriteLine($"Pending: {string.Join(", ", s.PendingTasks.Select(t => t.ToString()))}");

                if (result.IsSuccess)
                {
                    Console.WriteLine("Status: SUCCESS");
                }
                else
                {
                    Console.WriteLine("Status: FAILED");
                    foreach (var kv in result.Errors)
                    {
                        Console.WriteLine($"Task {kv.Key}: {kv.Value.GetType().Name} - {kv.Value.Message}");
                    }
                }

                Console.WriteLine("-------------------------------");
                return Task.CompletedTask;
            }
        }

        #endregion

        #region Module Registration

        /// <summary>
        /// 使用者專案的範例模組，示範如何註冊所有元件。
        /// </summary>
        public class FullFlowApplicationModule : Module
        {
            protected override void Load(ContainerBuilder builder)
            {
                // 註冊框架
                builder.RegisterModule<CoordinationModule>();

                // 註冊 Handlers
                builder.RegisterTaskHandler<ValidateHandler>();
                builder.RegisterTaskHandler<FetchHandler>();
                builder.RegisterTaskHandler<TransformHandler>();
                builder.RegisterTaskHandler<PersistHandler>();
                builder.RegisterTaskHandler<NotifyHandler>();

                // 註冊 Mapping Strategy
                builder.RegisterTaskMappingStrategy<FullFlowMappingStrategy>();

                // 註冊結果發布者
                builder.RegisterResultPublisher<ConsoleResultPublisher>();

                // 註冊自訂執行策略：例如平行並行度 2
                builder.RegisterInstance(new Policies.ParallelExecutionPolicy(2))
                    .As<IExecutionPolicy>()
                    .SingleInstance();

                // 注意：若不註冊 ITaskHandlerResolver 的實例，框架會以已註冊的 ITaskHandler 建立預設解析器。
                // 這裡示範直接依賴框架提供的解析器：TaskHandlerResolver 已在 CoordinationModule 中註冊為 SingleInstance。
            }
        }

        #endregion

        #region Runner

        /// <summary>
        /// 執行範例流程。
        /// </summary>
        public static async Task RunAsync()
        {
            var cb = new ContainerBuilder();
            cb.RegisterModule<FullFlowApplicationModule>();

            // 建置容器
            using (var container = cb.Build())
            {
                // IMPORTANT: TaskHandlerResolver 需要所有 ITaskHandler 已註冊於容器。
                // Framework 的 TaskHandlerResolver 建構時會從容器解析 ITaskHandler 的集合。
                // 因此在此範例中，TaskHandlerResolver 會被 CoordinationModule 以容器內註冊的 ITaskHandler 建立。

                var coordinator = container.Resolve<ICoordinator>();

                Console.WriteLine("Running successful flow...");
                var request1 = new FullFlowRequest(causeFailure: false, requireNotification: true);
                var result1 = await coordinator.CoordinateAsync(request1);

                Console.WriteLine();

                Console.WriteLine("Running failing flow (simulate persist failure)...");
                var request2 = new FullFlowRequest(causeFailure: true, requireNotification: true);
                var result2 = await coordinator.CoordinateAsync(request2);

                Console.WriteLine();

                Console.WriteLine("Running flow with cancellation...");
                var cts = new CancellationTokenSource();
                var request3 = new FullFlowRequest(causeFailure: false, requireNotification: true);
                var task = coordinator.CoordinateAsync(request3, cts.Token);

                // 取消執行以模擬中斷
                cts.CancelAfter(100);

                try
                {
                    var result3 = await task;
                }
                catch (OperationCanceledException)
                {
                    Console.WriteLine("Coordination was cancelled.");
                }
            }
        }

        #endregion
    }
}

#endif
