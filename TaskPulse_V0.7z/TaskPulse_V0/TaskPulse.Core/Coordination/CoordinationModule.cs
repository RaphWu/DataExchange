using Autofac;
using Calin.Infrastructure.Coordination.Policies;

namespace Calin.Infrastructure.Coordination
{
    /// <summary>
    /// ��ծج[�� Autofac �ҲաC
    /// ���U�Ҧ��ج[�֤ߤ���C
    /// </summary>
    public class CoordinationModule : Module
    {
        private readonly CoordinationModuleOptions _options;

        /// <summary>
        /// ��l�ƨ�ռҲաA�ϥιw�]�ﶵ�C
        /// </summary>
        public CoordinationModule() : this(new CoordinationModuleOptions())
        {
        }

        /// <summary>
        /// ��l�ƨ�ռҲաA�ϥΫ��w�ﶵ�C
        /// </summary>
        /// <param name="options">�Ҳտﶵ�C</param>
        public CoordinationModule(CoordinationModuleOptions options)
        {
            _options = options ?? new CoordinationModuleOptions();
        }

        /// <inheritdoc/>
        protected override void Load(ContainerBuilder builder)
        {
            // ���U Handler �ѪR��
            builder.RegisterType<TaskHandlerResolver>()
                .As<ITaskHandlerResolver>()
                .SingleInstance();

            // ���U��ժ�
            builder.RegisterType<Coordinator>()
                .As<ICoordinator>()
                .InstancePerDependency();

            // ���U�w�]���浦��
            RegisterDefaultExecutionPolicy(builder);

            // ���U�w�]���G�o���̡]�Y�ϥΪ̥����U�^
            RegisterDefaultResultPublisher(builder);
        }

        private void RegisterDefaultExecutionPolicy(ContainerBuilder builder)
        {
            switch (_options.DefaultExecutionPolicy)
            {
                case DefaultExecutionPolicy.Parallel:
                    builder.RegisterType<ParallelExecutionPolicy>()
                        .As<IExecutionPolicy>()
                        .SingleInstance()
                        .IfNotRegistered(typeof(IExecutionPolicy));
                    break;

                case DefaultExecutionPolicy.Sequential:
                default:
                    builder.RegisterType<SequentialExecutionPolicy>()
                        .As<IExecutionPolicy>()
                        .SingleInstance()
                        .IfNotRegistered(typeof(IExecutionPolicy));
                    break;
            }
        }

        private void RegisterDefaultResultPublisher(ContainerBuilder builder)
        {
            builder.RegisterInstance(NullResultPublisher.Instance)
                .As<IResultPublisher>()
                .SingleInstance()
                .IfNotRegistered(typeof(IResultPublisher));
        }
    }

    /// <summary>
    /// ��ռҲժ��ﶵ�]�w�C
    /// </summary>
    public class CoordinationModuleOptions
    {
        /// <summary>
        /// ���o�γ]�w�w�]�����浦���C
        /// </summary>
        public DefaultExecutionPolicy DefaultExecutionPolicy { get; set; } = DefaultExecutionPolicy.Sequential;
    }

    /// <summary>
    /// �w�]���浦�����C�|�C
    /// </summary>
    public enum DefaultExecutionPolicy
    {
        /// <summary>
        /// ���ǰ���C
        /// </summary>
        Sequential,

        /// <summary>
        /// �������C
        /// </summary>
        Parallel
    }
}
