using System;
using System.Collections.Generic;
using System.Linq;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// �w�]�������� Cache �M�g�W�h��@�C
    /// �i�z�L DI �������ۭq��@�C
    /// </summary>
    public class DefaultCacheScenarioMapper : ICacheScenarioMapper
    {
        private readonly Dictionary<string, HashSet<CacheKey>> _scenarioToCache;
        private readonly Dictionary<CacheKey, HashSet<string>> _cacheToSubscribers;

        public DefaultCacheScenarioMapper()
        {
            _scenarioToCache = new Dictionary<string, HashSet<CacheKey>>(StringComparer.OrdinalIgnoreCase);
            _cacheToSubscribers = new Dictionary<CacheKey, HashSet<string>>();

            // �w�]�M�g�W�h
            RegisterScenarioMapping();
            RegisterSubscriberMapping();
        }

        /// <summary>
        /// ���U������ Cache ���M�g�C
        /// </summary>
        protected virtual void RegisterScenarioMapping()
        {
            // ���u�ܧ� -> ���u Cache + �u�� Cache�]�]���u��ޥέ��u�^
            MapScenario(CacheScenarios.EmployeeChanged, CacheKeys.Employee, CacheKeys.TaskOrder);

            // ���x�ܧ� -> ���x Cache + �u�� Cache
            MapScenario(CacheScenarios.MachineChanged, CacheKeys.Machine, CacheKeys.TaskOrder);

            // �����ܧ� -> ���� Cache + �u�� Cache
            MapScenario(CacheScenarios.ModelChanged, CacheKeys.Model, CacheKeys.Workstation);

            // �u���ܧ� -> �u�� Cache
            MapScenario(CacheScenarios.WorkstationChanged, CacheKeys.Workstation);

            // �u���ܧ� -> �u�� Cache
            MapScenario(CacheScenarios.TaskOrderChanged, CacheKeys.TaskOrder);

            // ����]�w�ܧ� -> ���� Cache
            MapScenario(CacheScenarios.GlobalChanged, CacheKeys.Global);

            // �t�Ϊ�l�� -> ���� Cache
            MapScenario(CacheScenarios.SystemInitialize,
                CacheKeys.Employee,
                CacheKeys.Machine,
                CacheKeys.Model,
                CacheKeys.Workstation,
                CacheKeys.TaskOrder,
                CacheKeys.Global);

            // �������� -> �ˬd�������Ī� Cache
            MapScenario(CacheScenarios.PageSwitch,
                CacheKeys.Employee,
                CacheKeys.Machine,
                CacheKeys.Model,
                CacheKeys.Workstation,
                CacheKeys.TaskOrder,
                CacheKeys.Global);

            // �ϥΪ̵n�J
            MapScenario(CacheScenarios.UserLogin,
                CacheKeys.Employee,
                CacheKeys.Global);

            // ��s����
            MapScenario(CacheScenarios.RefreshAll,
                CacheKeys.Employee,
                CacheKeys.Machine,
                CacheKeys.Model,
                CacheKeys.Workstation,
                CacheKeys.TaskOrder,
                CacheKeys.Global);
        }

        /// <summary>
        /// ���U Cache ��q�\�̪��M�g�C
        /// </summary>
        protected virtual void RegisterSubscriberMapping()
        {
            // ���u Cache ��s��q�����q�\��
            MapSubscribers(CacheKeys.Employee, "EmployeeView", "TaskOrderView", "EngineerSelector");

            // ���x Cache ��s��q�����q�\��
            MapSubscribers(CacheKeys.Machine, "MachineView", "TaskOrderView", "MachineSelector");

            // ���� Cache ��s��q�����q�\��
            MapSubscribers(CacheKeys.Model, "ModelView", "WorkstationView", "ModelSelector");

            // �u�� Cache ��s��q�����q�\��
            MapSubscribers(CacheKeys.Workstation, "WorkstationView", "TaskOrderView", "WorkstationSelector");

            // �u�� Cache ��s��q�����q�\��
            MapSubscribers(CacheKeys.TaskOrder, "TaskOrderView", "TaskOrderSummary");

            // ���� Cache ��s��q�����q�\��
            MapSubscribers(CacheKeys.Global, "GlobalSettings", "PermissionView");
        }

        /// <summary>
        /// �s�W������ Cache ���M�g�C
        /// </summary>
        protected void MapScenario(string scenario, params CacheKey[] caches)
        {
            if (!_scenarioToCache.TryGetValue(scenario, out var set))
            {
                set = new HashSet<CacheKey>();
                _scenarioToCache[scenario] = set;
            }

            foreach (var cache in caches)
            {
                set.Add(cache);
            }
        }

        /// <summary>
        /// �s�W Cache ��q�\�̪��M�g�C
        /// </summary>
        protected void MapSubscribers(CacheKey cacheKey, params string[] subscribers)
        {
            if (!_cacheToSubscribers.TryGetValue(cacheKey, out var set))
            {
                set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                _cacheToSubscribers[cacheKey] = set;
            }

            foreach (var subscriber in subscribers)
            {
                set.Add(subscriber);
            }
        }

        /// <inheritdoc/>
        public IEnumerable<CacheKey> ResolveCaches(CacheRequestContext context)
        {
            if (context == null)
                return Enumerable.Empty<CacheKey>();

            var result = new HashSet<CacheKey>();

            foreach (var scenario in context.ScenarioTags)
            {
                if (_scenarioToCache.TryGetValue(scenario, out var caches))
                {
                    foreach (var cache in caches)
                    {
                        result.Add(cache);
                    }
                }
            }

            // ���u�����ǱƧ�
            return result.OrderBy(c => c.Priority);
        }

        /// <inheritdoc/>
        public IEnumerable<string> ResolveSubscribers(IEnumerable<CacheKey> updatedCaches)
        {
            if (updatedCaches == null)
                return Enumerable.Empty<string>();

            var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var cache in updatedCaches)
            {
                if (_cacheToSubscribers.TryGetValue(cache, out var subscribers))
                {
                    foreach (var subscriber in subscribers)
                    {
                        result.Add(subscriber);
                    }
                }
            }

            return result;
        }
    }
}
