using System;
using System.Linq;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache ��s�����q���T���C
    /// </summary>
    public class CacheUpdatedMessage
    {
        public CacheUpdateSession Session { get; }
        public CacheKey[] UpdatedCaches { get; }

        public CacheUpdatedMessage(CacheUpdateSession session, CacheKey[] updatedCaches)
        {
            Session = session;
            UpdatedCaches = updatedCaches;
        }
    }

    /// <summary>
    /// �w�]�� UI �q���A�ȹ�@�C
    /// �ϥ� WeakReferenceMessenger �o�e�T���C
    /// </summary>
    public class DefaultCacheNotificationService : ICacheNotificationService
    {
        /// <inheritdoc/>
        public event EventHandler<CacheUpdateCompletedEventArgs> UpdateCompleted;

        /// <inheritdoc/>
        public Task NotifyUpdateCompletedAsync(CacheUpdateSession session)
        {
            if (session == null)
                return Task.CompletedTask;

            var updatedCaches = session.CompletedCaches.ToList();
            var args = new CacheUpdateCompletedEventArgs(session, updatedCaches.AsReadOnly());

            // Ĳ�o�ƥ�
            UpdateCompleted?.Invoke(this, args);

            // �z�L Messenger �o�e�T��
            var message = new CacheUpdatedMessage(session, updatedCaches.ToArray());
            WeakReferenceMessenger.Default.Send(message);

            return Task.CompletedTask;
        }
    }
}
