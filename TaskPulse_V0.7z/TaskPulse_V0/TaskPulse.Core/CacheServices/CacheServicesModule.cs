using Autofac;
using Calin.TaskPulse.Core.CacheServices.Providers;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache �A�Ȫ� Autofac �ҲաC
    /// �t�d���U�Ҧ� Cache �����A�Ȧ� DI �e���C
    /// </summary>
    public class CacheServicesModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U�����M�g���]��ҡ^
            builder.RegisterType<DefaultCacheScenarioMapper>()
                .As<ICacheScenarioMapper>()
                .SingleInstance();

            // ���U�q���A�ȡ]��ҡ^
            builder.RegisterType<DefaultCacheNotificationService>()
                .As<ICacheNotificationService>()
                .SingleInstance();

            // ���U�Ҧ� Cache Provider�]��ҡ^
            // �s�W Cache �ɥu�ݦb���s�W�@����U
            builder.RegisterType<EmployeeCacheProvider>()
                .As<ICacheProvider>()
                .SingleInstance();

            builder.RegisterType<MachineCacheProvider>()
                .As<ICacheProvider>()
                .SingleInstance();

            builder.RegisterType<ModelCacheProvider>()
                .As<ICacheProvider>()
                .SingleInstance();

            builder.RegisterType<WorkstationCacheProvider>()
                .As<ICacheProvider>()
                .SingleInstance();

            builder.RegisterType<TaskOrderCacheProvider>()
                .As<ICacheProvider>()
                .SingleInstance();

            builder.RegisterType<GlobalCacheProvider>()
                .As<ICacheProvider>()
                .SingleInstance();

            // ���U��ժ̡]��ҡ^
            builder.RegisterType<CacheCoordinator>()
                .As<ICacheCoordinator>()
                .SingleInstance();
        }
    }
}
