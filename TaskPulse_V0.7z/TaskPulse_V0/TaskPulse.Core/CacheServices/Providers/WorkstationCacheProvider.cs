using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.CacheServices.Providers
{
    /// <summary>
    /// �u����� Cache Provider�C
    /// </summary>
    public class WorkstationCacheProvider : CacheProviderBase
    {
        private readonly CoreContext _context;
        private readonly CoreData _coreData;

        public override CacheKey CacheKey => CacheKeys.Workstation;

        public WorkstationCacheProvider(CoreContext context, CoreData coreData)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _coreData = coreData ?? throw new ArgumentNullException(nameof(coreData));
        }

        protected override async Task RefreshCoreAsync(CacheRefreshContext context)
        {
            var tWorkstations = await _context.Workstations
                .Include(w => w.Model)
                .AsNoTracking()
                .ToListAsync();

            _coreData.Workstations = tWorkstations
                .Select(w => new { Original = w, Key = GetWorkstationSortKey(w) })
                .OrderBy(w => w.Key.ModelPriority)
                .ThenBy(w => w.Key.ModelNumber)
                .ThenBy(w => w.Key.OrderNo)
                .Select(w => w.Original)
                .ToList();

            var sortedWorkstations = SortWorkstations(_coreData.Workstations);
            _coreData.ClassifyWorkstations = ClassifyItems(
                sortedWorkstations,
                w => w.Model.ModelName,
                "Workstation",
                w => w.Id,
                w => w.WorkstationName
            );
        }

        private (int ModelPriority, int ModelNumber, int OrderNo) GetWorkstationSortKey(Workstation w)
        {
            var modelName = w.Model?.ModelName ?? "";
            var key = GetModelSortKey(modelName);

            int modelPriority = key.IsThreeDigits ? 0 : 1;
            int modelNumber = key.SortKey;
            int orderNo = w.OrderNo;

            return (modelPriority, modelNumber, orderNo);
        }

        private (bool IsThreeDigits, int SortKey) GetModelSortKey(string modelName)
        {
            var prefix = modelName.Split('-')[0];
            bool isThreeDigits = Regex.IsMatch(prefix, @"^\d{3}$");
            int sortKey = int.TryParse(prefix, out var n) ? n : int.MaxValue;
            return (isThreeDigits, sortKey);
        }

        private List<Workstation> SortWorkstations(IEnumerable<Workstation> workstations)
        {
            return workstations
                .OrderBy(w => GetWorkstationSortKey(w))
                .ToList();
        }

        private static Dictionary<string, Dictionary<string, List<ClassifyInfo>>> ClassifyItems<T>(
            IEnumerable<T> items,
            Func<T, string> categorySelector,
            string typeName,
            Func<T, int> idSelector,
            Func<T, string> nameSelector)
        {
            return items
                .GroupBy(categorySelector)
                .ToDictionary(
                    g => g.Key,
                    g => new Dictionary<string, List<ClassifyInfo>>
                    {
                        {
                            typeName,
                            g.Select(x => new ClassifyInfo
                            {
                                Id = idSelector(x),
                                Category1 = typeName,
                                Name = nameSelector(x)
                            }).ToList()
                        }
                    }
                );
        }
    }
}
