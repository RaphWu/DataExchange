﻿# Calin.TaskPusle Cache Services

## 核心介面與類別 (TaskPulse.Core\CacheServices\):

| 檔案 | 說明 |
|------|------|
| CacheKey.cs | Cache 類型的唯一識別鍵 |
| CacheKeys.cs | 預定義的 Cache 類型常數 |
| ICacheProvider.cs | Cache Provider 介面 |
| CacheProviderBase.cs | Cache Provider 基底類別 |
| CacheRefreshContext.cs | 刷新時的上下文資訊 |
| CacheRefreshResult.cs | 刷新結果 |
| CacheUpdateMode.cs | 更新模式列舉 (Immediate/Batch/Deferred) |
| CacheRequestContext.cs | 請求上下文 (呼叫端使用) |
| CacheScenarios.cs | 預定義的業務場景標籤 |
| CacheUpdateSession.cs | 狀態機/Session (完整追蹤更新流程) |
| CacheUpdateCompletedEventArgs.cs | 完成事件資料 |
| ICacheScenarioMapper.cs | 場景到 Cache 映射介面 |
| DefaultCacheScenarioMapper.cs | 預設映射規則實作 |
| ICacheNotificationService.cs | UI 通知服務介面 |
| DefaultCacheNotificationService.cs | 預設通知服務實作 |
| ICacheCoordinator.cs | 協調者介面 (唯一入口) |
| CacheCoordinator.cs | 協調者實作 |
| CacheCoordinatorExtensions.cs | 便捷擴充方法 |
| CacheServicesModule.cs | Autofac DI 註冊模組 |
| CacheServicesUsageExamples.cs | 使用範例文件 |

## Cache Provider 實作 (TaskPulse.Core\CacheServices\Providers\):

| 檔案 | 說明 |
|------|------|
| EmployeeCacheProvider.cs | 員工資料 Provider |
| MachineCacheProvider.cs | 機台資料 Provider |
| ModelCacheProvider.cs | 機種資料 Provider |
| WorkstationCacheProvider.cs | 工站資料 Provider |
| TaskOrderCacheProvider.cs | 工單資料 Provider |
| GlobalCacheProvider.cs | 全域設定 Provider |

設計特點
1.	唯一入口: ICacheCoordinator 是所有 Cache 更新請求的唯一入口
2.	場景驅動: 呼叫端使用場景標籤 (ScenarioTags)，不直接指定 Cache 類型
3.	狀態機追蹤: CacheUpdateSession 完整追蹤每次更新流程
4.	避免重複更新: 同一次請求中每個 Cache 最多更新一次
5.	統一通知: UI 通知集中在 ICacheNotificationService
6.	可擴充: 新增 Cache 只需新增 Provider 並註冊，無需修改核心邏輯



使用範例

```csharp
// 員工資料變更後
await _cacheCoordinator.RequestEmployeeUpdateAsync(
    sourceId: nameof(EmployeeEditViewModel),
    reason: "員工資料已編輯"
);

// 系統初始化
await _cacheCoordinator.RequestSystemInitializeAsync(
    sourceId: nameof(CoreService)
);

// 自訂請求
var context = new CacheRequestContext("MyService", "批次匯入")
    .WithScenarios(CacheScenarios.EmployeeChanged, CacheScenarios.MachineChanged)
    .WithMode(CacheUpdateMode.Batch);
await _cacheCoordinator.RequestUpdateAsync(context);
```