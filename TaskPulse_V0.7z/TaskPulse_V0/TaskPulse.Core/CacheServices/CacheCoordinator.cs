using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache ��ժ̹�@�C
    /// �t�d��� Cache ��s�y�{�P���A�A�O Cache ��s�ШD���ߤ@�J�f�C
    /// </summary>
    public class CacheCoordinator : ICacheCoordinator
    {
        private readonly IEnumerable<ICacheProvider> _providers;
        private readonly ICacheScenarioMapper _scenarioMapper;
        private readonly ICacheNotificationService _notificationService;
        private readonly ConcurrentDictionary<CacheKey, ICacheProvider> _providerMap;
        private readonly SemaphoreSlim _updateLock = new SemaphoreSlim(1, 1);

        private CacheUpdateSession _currentSession;

        /// <inheritdoc/>
        public CacheUpdateSession CurrentSession => _currentSession;

        /// <summary>
        /// �غc CacheCoordinator�C
        /// </summary>
        /// <param name="providers">�Ҧ����U�� Cache Provider�C</param>
        /// <param name="scenarioMapper">�����M�g���C</param>
        /// <param name="notificationService">�q���A�ȡC</param>
        public CacheCoordinator(
            IEnumerable<ICacheProvider> providers,
            ICacheScenarioMapper scenarioMapper,
            ICacheNotificationService notificationService)
        {
            _providers = providers ?? throw new ArgumentNullException(nameof(providers));
            _scenarioMapper = scenarioMapper ?? throw new ArgumentNullException(nameof(scenarioMapper));
            _notificationService = notificationService ?? throw new ArgumentNullException(nameof(notificationService));

            // �إ� CacheKey �� Provider ���M�g
            _providerMap = new ConcurrentDictionary<CacheKey, ICacheProvider>();
            foreach (var provider in _providers)
            {
                _providerMap[provider.CacheKey] = provider;
            }
        }

        /// <inheritdoc/>
        public async Task<CacheUpdateSession> RequestUpdateAsync(CacheRequestContext context, CancellationToken cancellationToken = default)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            // �إ߷s�� Session
            var session = new CacheUpdateSession(context);

            // �ھڳ����ѪR�ݭn��s�� Cache
            var cachesToUpdate = _scenarioMapper.ResolveCaches(context).ToList();

            if (cachesToUpdate.Count == 0)
            {
                // �S���ݭn��s�� Cache
                session.MarkCompleted();
                return session;
            }

            // �[�J�ݭn��s�� Cache
            session.AddCaches(cachesToUpdate);

            // �ھڧ�s�Ҧ�����
            switch (context.UpdateMode)
            {
                case CacheUpdateMode.Immediate:
                    await ExecuteImmediateUpdateAsync(session, cancellationToken);
                    break;

                case CacheUpdateMode.Batch:
                    await ExecuteBatchUpdateAsync(session, cancellationToken);
                    break;

                case CacheUpdateMode.Deferred:
                    ExecuteDeferredUpdate(session);
                    break;
            }

            return session;
        }

        /// <summary>
        /// �ߧY��s�Ҧ��G�̧ǧ�s�C�� Cache�A�C�ӧ�����i��ܩʳq���C
        /// </summary>
        private async Task ExecuteImmediateUpdateAsync(CacheUpdateSession session, CancellationToken cancellationToken)
        {
            await _updateLock.WaitAsync(cancellationToken);
            try
            {
                _currentSession = session;
                session.MarkStarted();

                var context = session.RequestContext;
                var refreshContext = new CacheRefreshContext
                {
                    ForceRefresh = context.ForceRefresh,
                    RecreateUICache = context.RecreateUICache,
                    SessionId = session.SessionId,
                    Tag = context.Tag
                };

                // ���o�w�ƧǪ� Cache �M��
                var pendingCaches = session.PendingCaches.OrderBy(c => c.Priority).ToList();
                var updatedInThisSession = new HashSet<CacheKey>();

                foreach (var cacheKey in pendingCaches)
                {
                    if (cancellationToken.IsCancellationRequested)
                    {
                        session.MarkCancelled();
                        break;
                    }

                    // �קK���Ƨ�s
                    if (updatedInThisSession.Contains(cacheKey))
                    {
                        session.MarkCacheSkipped(cacheKey);
                        continue;
                    }

                    // �p�G�w�i�ΥB�D�j���s�A�h���L
                    if (!context.ForceRefresh && IsCacheAvailable(cacheKey))
                    {
                        session.MarkCacheSkipped(cacheKey);
                        continue;
                    }

                    // �����s
                    await UpdateSingleCacheAsync(session, cacheKey, refreshContext, cancellationToken);
                    updatedInThisSession.Add(cacheKey);
                }

                session.MarkCompleted();

                // �o�e�Τ@�q��
                await _notificationService.NotifyUpdateCompletedAsync(session);
            }
            finally
            {
                _currentSession = null;
                _updateLock.Release();
            }
        }

        /// <summary>
        /// �妸��s�Ҧ��G���ݩҦ� Cache ��s������Τ@�q���C
        /// </summary>
        private async Task ExecuteBatchUpdateAsync(CacheUpdateSession session, CancellationToken cancellationToken)
        {
            await _updateLock.WaitAsync(cancellationToken);
            try
            {
                _currentSession = session;
                session.MarkStarted();

                var context = session.RequestContext;
                var refreshContext = new CacheRefreshContext
                {
                    ForceRefresh = context.ForceRefresh,
                    RecreateUICache = context.RecreateUICache,
                    SessionId = session.SessionId,
                    Tag = context.Tag
                };

                // ���o�w�ƧǪ� Cache �M��
                var pendingCaches = session.PendingCaches.OrderBy(c => c.Priority).ToList();
                var updatedInThisSession = new HashSet<CacheKey>();

                // �̧ǧ�s�Ҧ� Cache�]�O�����ǥH�B�z�̿����Y�^
                foreach (var cacheKey in pendingCaches)
                {
                    if (cancellationToken.IsCancellationRequested)
                    {
                        session.MarkCancelled();
                        break;
                    }

                    // �קK���Ƨ�s
                    if (updatedInThisSession.Contains(cacheKey))
                    {
                        session.MarkCacheSkipped(cacheKey);
                        continue;
                    }

                    // �p�G�w�i�ΥB�D�j���s�A�h���L
                    if (!context.ForceRefresh && IsCacheAvailable(cacheKey))
                    {
                        session.MarkCacheSkipped(cacheKey);
                        continue;
                    }

                    await UpdateSingleCacheAsync(session, cacheKey, refreshContext, cancellationToken);
                    updatedInThisSession.Add(cacheKey);
                }

                session.MarkCompleted();

                // �妸������Τ@�o�e�q��
                await _notificationService.NotifyUpdateCompletedAsync(session);
            }
            finally
            {
                _currentSession = null;
                _updateLock.Release();
            }
        }

        /// <summary>
        /// �����s�Ҧ��G�u�аO Cache �����ġA���ߧY��s�C
        /// </summary>
        private void ExecuteDeferredUpdate(CacheUpdateSession session)
        {
            session.MarkStarted();

            foreach (var cacheKey in session.PendingCaches)
            {
                if (_providerMap.TryGetValue(cacheKey, out var provider))
                {
                    provider.Invalidate();
                    session.MarkCacheSkipped(cacheKey);
                }
            }

            session.MarkCompleted();
        }

        /// <summary>
        /// ��s��@ Cache�C
        /// </summary>
        private async Task UpdateSingleCacheAsync(
            CacheUpdateSession session,
            CacheKey cacheKey,
            CacheRefreshContext refreshContext,
            CancellationToken cancellationToken)
        {
            if (!_providerMap.TryGetValue(cacheKey, out var provider))
            {
                session.MarkCacheFailed(cacheKey, $"�䤣�� CacheKey [{cacheKey.Name}] ������ Provider");
                return;
            }

            session.MarkCacheStarted(cacheKey);
            var stopwatch = Stopwatch.StartNew();

            try
            {
                var result = await provider.RefreshAsync(refreshContext);
                stopwatch.Stop();

                if (result.Success)
                {
                    session.MarkCacheCompleted(cacheKey);
                }
                else
                {
                    session.MarkCacheFailed(cacheKey, result.ErrorMessage, result.Exception);
                }
            }
            catch (OperationCanceledException)
            {
                stopwatch.Stop();
                session.MarkCacheFailed(cacheKey, "��s�w����");
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                session.MarkCacheFailed(cacheKey, ex.Message, ex);
            }
        }

        /// <inheritdoc/>
        public void InvalidateCache(CacheKey cacheKey)
        {
            if (_providerMap.TryGetValue(cacheKey, out var provider))
            {
                provider.Invalidate();
            }
        }

        /// <inheritdoc/>
        public void InvalidateAllCaches()
        {
            foreach (var provider in _providers)
            {
                provider.Invalidate();
            }
        }

        /// <inheritdoc/>
        public bool IsCacheAvailable(CacheKey cacheKey)
        {
            if (_providerMap.TryGetValue(cacheKey, out var provider))
            {
                return provider.IsAvailable;
            }
            return false;
        }

        /// <inheritdoc/>
        public async Task WaitForCacheAvailableAsync(CacheKey cacheKey, CancellationToken cancellationToken = default)
        {
            while (!IsCacheAvailable(cacheKey))
            {
                cancellationToken.ThrowIfCancellationRequested();
                await Task.Delay(50, cancellationToken);
            }
        }
    }
}
