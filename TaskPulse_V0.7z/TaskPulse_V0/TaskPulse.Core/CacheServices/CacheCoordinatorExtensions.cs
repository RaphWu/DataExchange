using System.Threading;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache ��ժ̪��X�R��k�A���ѫK���� API�C
    /// </summary>
    public static class CacheCoordinatorExtensions
    {
        /// <summary>
        /// �ШD��s���u������ Cache�C
        /// </summary>
        public static Task<CacheUpdateSession> RequestEmployeeUpdateAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            string reason = null,
            CacheUpdateMode mode = CacheUpdateMode.Immediate,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, reason ?? "���u����ܧ�")
                .WithScenario(CacheScenarios.EmployeeChanged)
                .WithMode(mode);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �ШD��s���x������ Cache�C
        /// </summary>
        public static Task<CacheUpdateSession> RequestMachineUpdateAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            string reason = null,
            CacheUpdateMode mode = CacheUpdateMode.Immediate,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, reason ?? "���x����ܧ�")
                .WithScenario(CacheScenarios.MachineChanged)
                .WithMode(mode);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �ШD��s���ج����� Cache�C
        /// </summary>
        public static Task<CacheUpdateSession> RequestModelUpdateAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            string reason = null,
            CacheUpdateMode mode = CacheUpdateMode.Immediate,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, reason ?? "���ظ���ܧ�")
                .WithScenario(CacheScenarios.ModelChanged)
                .WithMode(mode);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �ШD��s�u�������� Cache�C
        /// </summary>
        public static Task<CacheUpdateSession> RequestWorkstationUpdateAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            string reason = null,
            CacheUpdateMode mode = CacheUpdateMode.Immediate,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, reason ?? "�u������ܧ�")
                .WithScenario(CacheScenarios.WorkstationChanged)
                .WithMode(mode);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �ШD��s�u������� Cache�C
        /// </summary>
        public static Task<CacheUpdateSession> RequestTaskOrderUpdateAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            string reason = null,
            CacheUpdateMode mode = CacheUpdateMode.Immediate,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, reason ?? "�u�����ܧ�")
                .WithScenario(CacheScenarios.TaskOrderChanged)
                .WithMode(mode);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �ШD�t�Ϊ�l�ơ]���J�Ҧ� Cache�^�C
        /// </summary>
        public static Task<CacheUpdateSession> RequestSystemInitializeAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, "�t�Ϊ�l��")
                .WithScenario(CacheScenarios.SystemInitialize)
                .WithMode(CacheUpdateMode.Batch)
                .WithForceRefresh(true);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �ШD���������ɪ� Cache ��s�C
        /// </summary>
        public static Task<CacheUpdateSession> RequestPageSwitchUpdateAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, "��������")
                .WithScenario(CacheScenarios.PageSwitch)
                .WithMode(CacheUpdateMode.Batch);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �ШD��s�Ҧ� Cache�C
        /// </summary>
        public static Task<CacheUpdateSession> RequestRefreshAllAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, "��s�Ҧ��֨�")
                .WithScenario(CacheScenarios.RefreshAll)
                .WithMode(CacheUpdateMode.Batch)
                .WithForceRefresh(true);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �����s���u Cache�]�u�аO���ġA���ߧY��s�^�C
        /// </summary>
        public static Task<CacheUpdateSession> DeferEmployeeUpdateAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, "�����s���u")
                .WithScenario(CacheScenarios.EmployeeChanged)
                .WithMode(CacheUpdateMode.Deferred);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }

        /// <summary>
        /// �����s���x Cache�]�u�аO���ġA���ߧY��s�^�C
        /// </summary>
        public static Task<CacheUpdateSession> DeferMachineUpdateAsync(
            this ICacheCoordinator coordinator,
            string sourceId,
            CancellationToken cancellationToken = default)
        {
            var context = new CacheRequestContext(sourceId, "�����s���x")
                .WithScenario(CacheScenarios.MachineChanged)
                .WithMode(CacheUpdateMode.Deferred);

            return coordinator.RequestUpdateAsync(context, cancellationToken);
        }
    }
}
