using System;
using System.Collections.Generic;
using System.Linq;

namespace Calin.TaskPulse.Core.CacheServices
{
    /// <summary>
    /// Cache ��s Session ���A�C
    /// </summary>
    public enum CacheSessionState
    {
        /// <summary>
        /// �|���}�l�C
        /// </summary>
        Pending,

        /// <summary>
        /// ���椤�C
        /// </summary>
        Running,

        /// <summary>
        /// �w�����]���\�^�C
        /// </summary>
        Completed,

        /// <summary>
        /// �w�����]�������ѡ^�C
        /// </summary>
        PartiallyCompleted,

        /// <summary>
        /// �w�����]�������ѡ^�C
        /// </summary>
        Failed,

        /// <summary>
        /// �w�����C
        /// </summary>
        Cancelled
    }

    /// <summary>
    /// ��@ Cache ����s���A�C
    /// </summary>
    public enum CacheItemState
    {
        /// <summary>
        /// ���ݧ�s�C
        /// </summary>
        Pending,

        /// <summary>
        /// ��s���C
        /// </summary>
        Updating,

        /// <summary>
        /// �w�����C
        /// </summary>
        Completed,

        /// <summary>
        /// �w���L�]�w�O�̷s�Τ��ݧ�s�^�C
        /// </summary>
        Skipped,

        /// <summary>
        /// ���ѡC
        /// </summary>
        Failed
    }

    /// <summary>
    /// ��@ Cache ���ت����A�l�ܡC
    /// </summary>
    public class CacheItemStatus
    {
        public CacheKey CacheKey { get; }
        public CacheItemState State { get; private set; }
        public DateTime? StartedAt { get; private set; }
        public DateTime? CompletedAt { get; private set; }
        public TimeSpan? Duration => CompletedAt.HasValue && StartedAt.HasValue
            ? CompletedAt.Value - StartedAt.Value
            : (TimeSpan?)null;
        public string ErrorMessage { get; private set; }
        public Exception Exception { get; private set; }

        public CacheItemStatus(CacheKey cacheKey)
        {
            CacheKey = cacheKey;
            State = CacheItemState.Pending;
        }

        internal void MarkStarted()
        {
            State = CacheItemState.Updating;
            StartedAt = DateTime.Now;
        }

        internal void MarkCompleted()
        {
            State = CacheItemState.Completed;
            CompletedAt = DateTime.Now;
        }

        internal void MarkSkipped()
        {
            State = CacheItemState.Skipped;
            CompletedAt = DateTime.Now;
        }

        internal void MarkFailed(string errorMessage, Exception exception = null)
        {
            State = CacheItemState.Failed;
            CompletedAt = DateTime.Now;
            ErrorMessage = errorMessage;
            Exception = exception;
        }

        public override string ToString()
        {
            var duration = Duration.HasValue ? $" ({Duration.Value.TotalMilliseconds:F0}ms)" : "";
            return $"[{CacheKey.Name}] {State}{duration}";
        }
    }

    /// <summary>
    /// Cache ��s Session�C
    /// �C�@�� Cache ��s�ШD�����@�ӿW�ߪ� Session ��ҡC
    /// �����O�Ω�l�ܾ�ӧ�s�y�{�����A�A�i�Ω� Debug �P Log�C
    /// </summary>
    public class CacheUpdateSession
    {
        private readonly object _lock = new object();
        private readonly Dictionary<CacheKey, CacheItemStatus> _items = new Dictionary<CacheKey, CacheItemStatus>();

        /// <summary>
        /// Session �ߤ@�ѧO�X�C
        /// </summary>
        public Guid SessionId { get; }

        /// <summary>
        /// �ШD�W�U��C
        /// </summary>
        public CacheRequestContext RequestContext { get; }

        /// <summary>
        /// Session �إ߮ɶ��C
        /// </summary>
        public DateTime CreatedAt { get; }

        /// <summary>
        /// Session �}�l����ɶ��C
        /// </summary>
        public DateTime? StartedAt { get; private set; }

        /// <summary>
        /// Session �����ɶ��C
        /// </summary>
        public DateTime? CompletedAt { get; private set; }

        /// <summary>
        /// Session �`�ӮɡC
        /// </summary>
        public TimeSpan? TotalDuration => CompletedAt.HasValue && StartedAt.HasValue
            ? CompletedAt.Value - StartedAt.Value
            : (TimeSpan?)null;

        /// <summary>
        /// Session ���A�C
        /// </summary>
        public CacheSessionState State { get; private set; }

        /// <summary>
        /// �ݭn��s�� Cache ���ءC
        /// </summary>
        public IReadOnlyCollection<CacheItemStatus> Items
        {
            get
            {
                lock (_lock)
                {
                    return _items.Values.ToList().AsReadOnly();
                }
            }
        }

        /// <summary>
        /// �|����s�� Cache�C
        /// </summary>
        public IReadOnlyCollection<CacheKey> PendingCaches
        {
            get
            {
                lock (_lock)
                {
                    return _items.Values
                        .Where(i => i.State == CacheItemState.Pending)
                        .Select(i => i.CacheKey)
                        .ToList()
                        .AsReadOnly();
                }
            }
        }

        /// <summary>
        /// �w������s�� Cache�C
        /// </summary>
        public IReadOnlyCollection<CacheKey> CompletedCaches
        {
            get
            {
                lock (_lock)
                {
                    return _items.Values
                        .Where(i => i.State == CacheItemState.Completed || i.State == CacheItemState.Skipped)
                        .Select(i => i.CacheKey)
                        .ToList()
                        .AsReadOnly();
                }
            }
        }

        /// <summary>
        /// ��s���Ѫ� Cache�C
        /// </summary>
        public IReadOnlyCollection<CacheKey> FailedCaches
        {
            get
            {
                lock (_lock)
                {
                    return _items.Values
                        .Where(i => i.State == CacheItemState.Failed)
                        .Select(i => i.CacheKey)
                        .ToList()
                        .AsReadOnly();
                }
            }
        }

        /// <summary>
        /// �O�_�w����������s�y�{�C
        /// </summary>
        public bool IsCompleted => State == CacheSessionState.Completed
            || State == CacheSessionState.PartiallyCompleted
            || State == CacheSessionState.Failed
            || State == CacheSessionState.Cancelled;

        /// <summary>
        /// �O�_�������\�C
        /// </summary>
        public bool IsFullySucceeded => State == CacheSessionState.Completed;

        public CacheUpdateSession(CacheRequestContext requestContext)
        {
            SessionId = Guid.NewGuid();
            RequestContext = requestContext ?? throw new ArgumentNullException(nameof(requestContext));
            CreatedAt = DateTime.Now;
            State = CacheSessionState.Pending;
        }

        /// <summary>
        /// �[�J�ݭn��s�� Cache�C
        /// </summary>
        internal void AddCache(CacheKey cacheKey)
        {
            lock (_lock)
            {
                if (!_items.ContainsKey(cacheKey))
                {
                    _items[cacheKey] = new CacheItemStatus(cacheKey);
                }
            }
        }

        /// <summary>
        /// �[�J�h�ӻݭn��s�� Cache�C
        /// </summary>
        internal void AddCaches(IEnumerable<CacheKey> cacheKeys)
        {
            foreach (var key in cacheKeys)
            {
                AddCache(key);
            }
        }

        /// <summary>
        /// �аO Session �}�l����C
        /// </summary>
        internal void MarkStarted()
        {
            State = CacheSessionState.Running;
            StartedAt = DateTime.Now;
        }

        /// <summary>
        /// �аO�S�w Cache �}�l��s�C
        /// </summary>
        internal void MarkCacheStarted(CacheKey cacheKey)
        {
            lock (_lock)
            {
                if (_items.TryGetValue(cacheKey, out var status))
                {
                    status.MarkStarted();
                }
            }
        }

        /// <summary>
        /// �аO�S�w Cache ��s�����C
        /// </summary>
        internal void MarkCacheCompleted(CacheKey cacheKey)
        {
            lock (_lock)
            {
                if (_items.TryGetValue(cacheKey, out var status))
                {
                    status.MarkCompleted();
                }
            }
        }

        /// <summary>
        /// �аO�S�w Cache �w���L�C
        /// </summary>
        internal void MarkCacheSkipped(CacheKey cacheKey)
        {
            lock (_lock)
            {
                if (_items.TryGetValue(cacheKey, out var status))
                {
                    status.MarkSkipped();
                }
            }
        }

        /// <summary>
        /// �аO�S�w Cache ��s���ѡC
        /// </summary>
        internal void MarkCacheFailed(CacheKey cacheKey, string errorMessage, Exception exception = null)
        {
            lock (_lock)
            {
                if (_items.TryGetValue(cacheKey, out var status))
                {
                    status.MarkFailed(errorMessage, exception);
                }
            }
        }

        /// <summary>
        /// �аO Session �����C
        /// </summary>
        internal void MarkCompleted()
        {
            CompletedAt = DateTime.Now;

            lock (_lock)
            {
                var failedCount = _items.Values.Count(i => i.State == CacheItemState.Failed);
                var successCount = _items.Values.Count(i => i.State == CacheItemState.Completed || i.State == CacheItemState.Skipped);

                if (failedCount == 0)
                {
                    State = CacheSessionState.Completed;
                }
                else if (successCount == 0)
                {
                    State = CacheSessionState.Failed;
                }
                else
                {
                    State = CacheSessionState.PartiallyCompleted;
                }
            }
        }

        /// <summary>
        /// �аO Session �����C
        /// </summary>
        internal void MarkCancelled()
        {
            State = CacheSessionState.Cancelled;
            CompletedAt = DateTime.Now;
        }

        /// <summary>
        /// ���ͪ��A�K�n�]�Ω� Log�^�C
        /// </summary>
        public string GetSummary()
        {
            lock (_lock)
            {
                var lines = new List<string>
                {
                    $"=== Cache Update Session ===",
                    $"SessionId: {SessionId}",
                    $"Source: {RequestContext.SourceId}",
                    $"Reason: {RequestContext.Reason}",
                    $"Mode: {RequestContext.UpdateMode}",
                    $"State: {State}",
                    $"Duration: {TotalDuration?.TotalMilliseconds:F0}ms",
                    $"Items:"
                };

                foreach (var item in _items.Values.OrderBy(i => i.CacheKey.Priority))
                {
                    lines.Add($"  - {item}");
                }

                return string.Join(Environment.NewLine, lines);
            }
        }

        public override string ToString()
            => $"Session[{SessionId:N}] {State} | {CompletedCaches.Count}/{Items.Count} completed";
    }
}
