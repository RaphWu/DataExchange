﻿using Calin.TaskPulse.Core.Models;
using CommunityToolkit.Mvvm.Messaging.Messages;

namespace Calin.TaskPulse.Core.Events
{
    public class PermissionSettingPageMessage : ValueChangedMessage<PermissionSettingInfo>
    {
        public PermissionSettingPageMessage(PermissionSettingInfo info) : base(info) { }
    }
}
