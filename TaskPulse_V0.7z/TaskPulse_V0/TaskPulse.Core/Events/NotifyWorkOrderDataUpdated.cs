﻿namespace Calin.TaskPulse.Core.Events
{
    public class NotifyWorkOrderDataUpdated
    {
        public static readonly NotifyWorkOrderDataUpdated Instance = new NotifyWorkOrderDataUpdated();
        private NotifyWorkOrderDataUpdated() { }
    }
}
