﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 機種快取已更新通知。
    /// </summary>
    public class NotifyModelDataUpdated
    {
        public static readonly NotifyModelDataUpdated Instance = new NotifyModelDataUpdated();
        private NotifyModelDataUpdated() { }
    }
}
