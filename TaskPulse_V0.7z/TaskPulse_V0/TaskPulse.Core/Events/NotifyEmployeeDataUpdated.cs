﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 員工快取已更新通知。
    /// </summary>
    public class NotifyEmployeeDataUpdated
    {
        public static readonly NotifyEmployeeDataUpdated Instance = new NotifyEmployeeDataUpdated();
        private NotifyEmployeeDataUpdated() { }
    }
}
