﻿using System.ComponentModel;

namespace Calin.TaskPulse.Core.Contants
{
    public static class PermissionWords
    {
        /********************
         * User
         ********************/
        public const string USER_GUEST = "Guest";

        /********************
         * Home
         ********************/
        [Description("主頁")]
        public const string MODULE_HOME = "主頁";


        /********************
         * 系統設定
         ********************/
        [Description("系統設定")]
        public const string MODULE_SETUP = "系統設定";

        [Description("機台管理")]
        public const string PAGE_MACHINE_MANAGER = "機台管理";
        [Description("員工管理")]
        public const string PAGE_EMPLOYEE_MANAGER = "員工管理";
        [Description("工具委託管理")]
        public const string PAGE_TOOL_QUEST_MANAGER = "工具委託管理";
        [Description("專案管理")]
        public const string PAGE_MECHA_TRACK_MANAGER = "專案管理";
        [Description("維護工單管理")]
        public const string PAGE_MAINTI_FLOW_MANAGER = "維護工單管理";

        /********************
         * 工具委託
         ********************/
        public const string MODULE_TOOL_QUEST = "工具委託";



        /********************
         * 專案管理
         ********************/
        [Description("專案管理")]
        public const string MODULE_MECHA_TRACK = "專案管理";



        /********************
         * 維護工單
         ********************/
        [Description("維護工單")]
        public const string MODULE_MAINTI_FLOW = "維護工單";

        [Description("維護總表")]
        public const string PAGE_FLOW_SUMMARY = "維護總表";
        [Description("新建工單")]
        public const string PAGE_CREATE_FLOW = "新建工單";
        [Description("取消工單")]
        public const string PAGE_CANCEL_FLOW = "取消工單";
        [Description("接單")]
        public const string PAGE_ACCEPT_FLOW = "接單";
        [Description("維護作業")]
        public const string PAGE_MAINTI_FLOW = "維護作業";
        [Description("確認作業")]
        public const string PAGE_FLOW_CONFIRM = "確認作業";


        /********************
         * 動作
         ********************/
        [Description("檢視")]
        public const string ACTION_VIEW = "檢視";
        [Description("編輯")]
        public const string ACTION_EDIT = "編輯";
    }
}
