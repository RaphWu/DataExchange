﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Helper;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using CommunityToolkit.Mvvm.Messaging;
using Serilog.Context;
using Sunny.UI;

namespace Calin.TaskPulse.Core.SharedUI
{
    public partial class LoginControl : UserControl
    {
        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);
        private const int WM_SETCURSOR = 0x20;

        #region fields

        private readonly ILifetimeScope _scope;
        private readonly Serilog.ILogger _logger;
        private readonly ICurrentUserService _currentUser;
        private readonly CoreData _coreData;

        private List<ListViewModel> _nameList;
        private int _lastUser = default;

        #endregion fields

        public LoginControl(
            ILifetimeScope lifetimeScope,
            Serilog.ILogger logger,
            ICurrentUserService currentUserService,
            CoreData coreData)
        {
            InitializeComponent();

            _scope = lifetimeScope;
            _logger = logger;
            _currentUser = currentUserService;
            _coreData = coreData;

            CommonStyles.SetButton(btnLogin);
            CommonStyles.SetButton(btnCancel, isCancel: true);

            // 設置 Enter 鍵支援
            //cbUserName.KeyDown += Control_KeyDown;
            tbPassword.KeyDown += Control_KeyDown;
        }

        private void LoginControl_Load(object sender, EventArgs ea)
        {
            _nameList = _coreData.Employees.Select(e => new ListViewModel()
            {
                IdString = e.EmployeeId,
                Name = e.FullName
            }).ToList();
            cbUserName.DataSource = _nameList;
            cbUserName.DisplayMember = "Name";
            cbUserName.ValueMember = "IdString";
            cbUserName.Text = "";
        }

        private void Control_KeyDown(object sender, KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; // 防止嗶聲
                e.Handled = true;
                btnLogin.PerformClick(); // 使用 PerformClick 來觸發按鈕點擊，這會自動設定 DialogResult
            }
        }

        private async void btnLogin_Click(object sender, EventArgs ea)
        {
            var adminUser = ConfigurationManager.AppSettings["AdminUser"].ToLower();
            var appEncryptedPassword = ConfigurationManager.AppSettings["AdminPassword"];
            var appPassword = AESHelper.Decrypt(appEncryptedPassword);
            var password = tbPassword.Text.Trim();
            var employeeId = _nameList.FirstOrDefault(nl => nl.Name == cbUserName.Text.Trim())?.IdString ?? "";

            if (cbUserName.Text.Trim().ToLower() == adminUser)
            {
                if (password == appPassword)
                {
                    _currentUser.AdminLogin();
                    using (LogContext.PushProperty("Category", "UserActivity"))
                    {
                        _logger.Information("管理員登入，登入時間：{0}", DateTime.Now);
                    }
                    CloseParentDialog(DialogResult.OK);
                    return;
                }
                else
                {
                    using (LogContext.PushProperty("Category", "UserActivity"))
                    {
                        _logger.Information("管理員登入錯誤，嘗試時間：{0}", DateTime.Now);
                    }
                }
            }
            else
            {
                var user = _coreData.Employees.FirstOrDefault(e => e.EmployeeId == employeeId);
                if (user != null)
                {
                    var auth = _scope.Resolve<IAuthService>();
                    if (await auth.ActiveDirectoryAsync(employeeId, password))
                    {
                        _currentUser.SwitchCurrentUser(employeeId);
                        Console.WriteLine("LDAP驗證成功");
                        using (LogContext.PushProperty("Category", "UserActivity"))
                        {
                            _logger.Information("登入人員：{0}，登入時間：{1}", user.FullName, DateTime.Now);
                        }
                        CloseParentDialog(DialogResult.OK);
                        return;
                    }
                    else
                    {
                        Console.WriteLine("登入驗證未過");
                        using (LogContext.PushProperty("Category", "UserActivity"))
                        {
                            _logger.Information("登入驗證未過，登入人員：{0}，登入時間：{1}", user.FullName, DateTime.Now);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("User輸入空白。");
                }
            }
            _ = WeakReferenceMessenger.Default.Send(new StatusBarMessage("帳號或密碼錯誤，請重新輸入。"));
        }

        /// <summary>
        /// 關閉父對話框。
        /// </summary>
        /// <param name="result">對話框結果。</param>
        private void CloseParentDialog(DialogResult result)
        {
            // 尋找父 Form 並設定 DialogResult
            Form parentForm = this.FindForm();
            if (parentForm != null)
            {
                parentForm.DialogResult = result;
                parentForm.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            CloseParentDialog(DialogResult.Cancel);
        }

        private void tbPassword_ButtonClick(object sender, EventArgs e)
        {
            tbPassword.Text = "";
        }

        private void cbUserName_TextUpdate(object sender, EventArgs e)
        {
            string text = cbUserName.Text.Trim();

            var filtered = _nameList
                .Where(um => um.Name.Contains(text))
                .ToList();

            cbUserName.BeginUpdate();
            cbUserName.DataSource = filtered;
            cbUserName.DisplayMember = "Name";
            cbUserName.ValueMember = "IdString";
            cbUserName.EndUpdate();

            cbUserName.DroppedDown = true;
            cbUserName.Text = text;
            cbUserName.SelectionStart = text.Length;
            cbUserName.SelectionLength = 0;

            if (filtered.Any())
                cbUserName.SelectedIndex = 0;

            SendMessage(this.Parent.Handle, WM_SETCURSOR, 0, 0);
        }
    }
}
