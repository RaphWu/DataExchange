﻿using System;
using Calin.TaskPulse.Core.Contants;

namespace Calin.TaskPulse.Core.Models
{
    /// <summary>
    /// 權限作業資料結構。
    /// </summary>
    public class PermissionData
    {
        public int Id { get; set; }
        public string Module { get; set; }
        public string Page { get; set; }
        public string Control { get; set; }
        public string Action { get; set; }
        public string PermissionString { get; set; }

        /// <summary>
        /// 權限類型：1=允許(Allow)、2=禁止(Deny)
        /// </summary>
        public PermissionType PermissionType { get; set; } = PermissionType.Allow;

        public override bool Equals(object obj)
        {
            if (obj is PermissionData other)
            {
                // 定義「相等」邏輯：四個欄位都一樣就視為相同
                return string.Equals(Module, other.Module, StringComparison.OrdinalIgnoreCase)
                    && string.Equals(Page, other.Page, StringComparison.OrdinalIgnoreCase)
                    && string.Equals(Control, other.Control, StringComparison.OrdinalIgnoreCase)
                    && string.Equals(Action, other.Action, StringComparison.OrdinalIgnoreCase)
                    && PermissionType == other.PermissionType;
            }
            return false;
        }

        public override int GetHashCode()
        {
            // 用四個主要欄位產生雜湊
            unchecked
            {
                int hash = 17;
                hash = hash * 23 + (Module?.ToLowerInvariant().GetHashCode() ?? 0);
                hash = hash * 23 + (Page?.ToLowerInvariant().GetHashCode() ?? 0);
                hash = hash * 23 + (Control?.ToLowerInvariant().GetHashCode() ?? 0);
                hash = hash * 23 + (Action?.ToLowerInvariant().GetHashCode() ?? 0);
                hash = hash * 23 + PermissionType.GetHashCode();
                return hash;
            }
        }
    }
}
