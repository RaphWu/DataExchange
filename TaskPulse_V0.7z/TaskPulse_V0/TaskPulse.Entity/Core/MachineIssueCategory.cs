﻿//using System.Collections.Generic;
//using System.ComponentModel;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace Calin.TaskPulse.Entity.Core
//{
//    /// <summary>
//    /// 問題分類清單。
//    /// </summary>
//    public class MachineIssueCategory
//    {
//        /// <summary>
//        /// 問題分類代號。
//        /// </summary>
//        [Description("分類代號")]
//        [Key]
//        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
//        public int Id { get; set; }

//        /// <summary>
//        /// 螢幕排序。
//        /// </summary>
//        [Description("編號")]
//        public int OrderNo { get; set; }

//        /// <summary>
//        /// 問題分類名稱。
//        /// </summary>
//        [Description("分類名稱")]
//        public string CategoryName { get; set; }

//        public virtual ICollection<Machine> Machines { get; set; }
//    }
//}
