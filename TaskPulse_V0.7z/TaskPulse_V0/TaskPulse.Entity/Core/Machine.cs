﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using Newtonsoft.Json;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機台資料。
    /// </summary>
    public class Machine
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機台編號。
        /// </summary>
        [Description("編號")]
        [Index(IsUnique = true)]
        [MaxLength(10)]
        public string MachineCode { get; set; }

        /// <summary>
        /// 機台型號。
        /// </summary>
        [Description("型號")]
        public virtual MachineName MachineName { get; set; }
        public int MachineNameId { get; set; } // FK
        [NotMapped]
        public string ModelName => MachineName?.ModelName ?? string.Empty;
        [NotMapped]
        public int TypeId => MachineName?.TypeId ?? -1;
        [NotMapped]
        public string TypeName => MachineName?.MachineType?.TypeName ?? string.Empty;
        [NotMapped]
        public int CategoryId => MachineName?.MachineType?.CategoryId ?? -1;
        [NotMapped]
        public string CategoryName => MachineName?.MachineType?.Category?.CategoryName ?? string.Empty;

        ///// <summary>
        ///// 機台設備別。
        ///// </summary>
        //[Description("設備別")]
        //public virtual MachineType MachineType { get; set; }
        //public int? MachineTypeId { get; set; } // FK

        /// <summary>
        /// 機台狀態。
        /// </summary>
        [Description("狀態")]
        public virtual MachineCondition Condition { get; set; }
        public int ConditionId { get; set; } // FK
        [NotMapped]
        public string ConditionName => Condition?.ConditionName ?? string.Empty;

        /// <summary>
        /// 廠牌。
        /// </summary>
        [Description("廠牌")]
        public virtual MachineBrand Brand { get; set; }
        public int? BrandId { get; set; } // FK
        [NotMapped]
        public string BrandName => Brand?.BrandName ?? string.Empty;

        /// <summary>
        /// 位置。
        /// </summary>
        [Description("位置")]
        public virtual MachineLocation Location { get; set; }
        public int? LocationId { get; set; } // FK
        [NotMapped]
        public string LocationName => Location?.LocationName ?? string.Empty;

        /// <summary>
        /// 資產編號。
        /// </summary>
        [Description("資產編號")]
        public virtual string Assets { get; set; }
        [NotMapped]
        public List<string> AssetList
        {
            get => JsonConvert.DeserializeObject<List<string>>(Assets);
            set => Assets = JsonConvert.SerializeObject(value);
        }
        [NotMapped]
        public string AssetString
        {
            get => AssetList.Count > 0 ? string.Join(Environment.NewLine, AssetList) : string.Empty;
            set => Assets = JsonConvert.SerializeObject(value
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList());
        }

        /// <summary>
        /// 機台序號。
        /// </summary>
        [Description("序號")]
        [MaxLength(20)]
        public string SerialNumber { get; set; }

        /// <summary>
        /// 條碼。
        /// </summary>
        [Description("條碼")]
        [MaxLength(50)]
        public string Barcode { get; set; }

        ///// <summary>
        ///// 維護類型。
        ///// </summary>
        //[Description("維護類型")]
        //public virtual MachineIssueCategory IssueCategory { get; set; }
        //public int? IssueCategoryId { get; set; } // FK

        /// <summary>
        /// 能否連網。
        /// </summary>
        [Description("連網")]
        public bool Connected { get; set; }
        [NotMapped]
        public string ConnectedString
        {
            get => Connected ? "可連網" : "";
            set => Connected = value == "可連網";
        }

        /// <summary>
        /// 機台是否已被處置 (除帳/報廢...)。
        /// </summary>
        [Description("處置")]
        public bool Disposal { get; set; }
        [NotMapped]
        public string DisposalString
        {
            get => Disposal ? "已處置" : "";
            set => Disposal = value == "已處置";
        }

        /// <summary>
        /// 備註。
        /// </summary>
        [Description("備註")]
        public string Remark { get; set; }

        /// <summary>
        /// 工站。
        /// </summary>
        [Description("工站")]
        public virtual ICollection<Workstation> Workstations { get; set; }
        [NotMapped]
        public string WorkstationList => string.Join(Environment.NewLine, Workstations?.Select(a => a.WorkstationName)
            ?? Enumerable.Empty<string>());
    }
}
