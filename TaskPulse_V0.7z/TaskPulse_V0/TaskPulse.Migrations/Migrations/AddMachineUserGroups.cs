﻿using FluentMigrator;

namespace TaskPulse.Migrations.Migrations
{
    [Migration(202301010001)]
    public class AddMachineUserGroups : Migration
    {
        public override void Up()
        {
            Create.Table("MachineUserGroups")
                .WithColumn("MachineId").AsInt32().PrimaryKey().ForeignKey("Machines", "Id")
                .WithColumn("UserGroupId").AsInt32().PrimaryKey().ForeignKey("UserGroups", "Id");
        }

        public override void Down()
        {
            Delete.Table("MachineUserGroups");
        }
    }
}
