﻿using Autofac;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.MechaTrack.Views;

namespace Calin.TaskPulse.MechaTrack
{
    public class MechaTrackModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            SplashMessenger.Post("載入專案管理模組...");

            // views
            builder.RegisterType<MechaTrackPage>().AsSelf().PropertiesAutowired();
        }
    }
}
