﻿using Autofac;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Views;

namespace Calin.TaskPulse
{
    public class MainModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            SplashMessenger.Post("載入主模組...");

            // dialog
            builder.RegisterType<LogoutCountdown>().ExternallyOwned();

            // views
            builder.RegisterType<MainPage>().InstancePerLifetimeScope();
            builder.RegisterType<LoginForm>().InstancePerLifetimeScope();
            builder.RegisterType<SplashScreen>().InstancePerLifetimeScope();
        }
    }
}
