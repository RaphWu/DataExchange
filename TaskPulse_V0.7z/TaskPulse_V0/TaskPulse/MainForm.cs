﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.Views;
using Calin.TaskPulse.Core.WinForms;
using Calin.TaskPulse.Entity;
using Calin.TaskPulse.MaintiFlow.Views;
using Calin.TaskPulse.MechaTrack.Views;
using Calin.TaskPulse.ToolQuest.Views;
using Calin.TaskPulse.Views;
using CommunityToolkit.Mvvm.Messaging;
using Sunny.UI;

namespace Calin.TaskPulse
{
    public partial class MainForm : UIForm, INavigationAware
    {
        #region fields

        private readonly Serilog.ILogger _logger;
        private readonly ICacheManager _cacheManager;
        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly ILifetimeScope _scope;
        private readonly CurrentUserContext _user;
        private readonly ICurrentUserService _currentUser;
        private readonly IPermissionService _permission;

        private bool _isAdmin = false;
        private bool _isGuest = false;
        private TreeNode _setupNode = null;

        private PageCode _currentPageCode = PageCode.None; // 目前選單項目
        private HashSet<PageCode> _availablePageCode = new HashSet<PageCode>();

        private System.Windows.Forms.Timer _messageTimer = new Timer(); // 狀態列訊息計時器，定時清除訊息
        private System.Windows.Forms.Timer _idleTimer; // 無動作計時器
        private bool _idleTriggered = false; // 是否已經觸發過

        private const int WH_KEYBOARD_LL = 13; // 全局鍵盤掛鉤
        private const int WH_MOUSE_LL = 14;    // 全局滑鼠掛鉤

        private IntPtr _keyboardHookId = IntPtr.Zero;
        private IntPtr _mouseHookId = IntPtr.Zero;

        private delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern IntPtr SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll")]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        private HookProc _keyboardProc;
        private HookProc _mouseProc;

        #endregion fields

        #region INavigationAware

        public void OnNavigatedTo()
        {
        }

        public void OnNavigatedFrom()
        {
            if (_cacheManager.HaveCacheNotAvailable)
                _cacheManager.UpdateAllCaches();
        }

        #endregion INavigationAware

        public MainForm(
            Serilog.ILogger logger,
            ICacheManager cacheManager,
            IRegionManager regionManager,
            INavigationService navigationService,
            ILifetimeScope lifetimeScope,
            CurrentUserContext currentUserContext,
            ICurrentUserService currentUserService,
            IPermissionService permissionService)
        {
            InitializeComponent();

            _logger = logger;
            _cacheManager = cacheManager;
            _region = regionManager;
            _nav = navigationService;
            _scope = lifetimeScope;
            _user = currentUserContext;
            _currentUser = currentUserService;
            _permission = permissionService;

            regionManager.RegisterRegion(nameof(MainRegion), MainRegion);

            // 註冊使用者切換事件
            WeakReferenceMessenger.Default.Register<NotifyCurrentUserChanged>(this, (recipient, message) =>
            {
                RecreateMainMenu();
            });

            // 註冊狀態列訊息區顯示
            WeakReferenceMessenger.Default.Register<StatusBarMessage>(this, (recipient, message) =>
            {
                SBMessage.Text = message.Value;
                _messageTimer.ReStart();
            });

            //註冊狀態列進度條顯示
            WeakReferenceMessenger.Default.Register<ProcessBarMessage>(this, (recipient, message) =>
            {
                ProcessBarInfo info = message.Value;
                SetProcessBar(info.Percent);
                if (!string.IsNullOrWhiteSpace(info.Message))
                {
                    SBMessage.Text = info.Message;
                    _messageTimer.ReStart();
                }
                else
                {
                    SBMessage.Text = "";
                }
            });

            //註冊狀態列DB資料顯示訊息
            WeakReferenceMessenger.Default.Register<DbInfoMessage>(this, (recipient, message) =>
            {
                DbInfo.Text = message.Value;
            });

            CommonStyles.SetStyles();

            ResizeScreen();
            SBMessage.Text = "";
            ProgressBar.ShowValue = false;
            ProgressBar.Value = 0;
            DbInfo.Text = "";

            UISettings.ApplyGlobalFont(this);

            //CustomizeTreeNodeColors(rNavBar.Menu);
            //CustomizeTreeNodeColors(lNavBar.Menu);
            rNavBar.MenuHoverColor = CommonStyles.HoverColor;
            lNavBar.MenuHoverColor = CommonStyles.HoverColor;

            // 固定的選單 (設定)
            const string userMenuName = "userMenuItem";
            int pageIndex = (int)PageCode.User;
            TreeNode node1 = rNavBar.CreateNode(PageCode.User.GetDescription(), pageIndex);
            rNavBar.SetNodePageIndex(node1, pageIndex);
            rNavBar.SetNodeSymbol(node1, 361459);
            node1.Name = userMenuName;
            node1.Tag = pageIndex;

            _messageTimer.Interval = 5000; // 5 秒後清除訊息
            _messageTimer.Tick += (s, e) =>
            {
                SBMessage.Text = "";
                _messageTimer.Stop();
            };

            _idleTimer = _user.IsAdmin
                ? new Timer { Interval = 120 * 60 * 1000 } // 120 分鐘
                : new Timer { Interval = 30 * 60 * 1000 }; // 30 分鐘
            //_idleTimer = new Timer { Interval = 5000 }; // for Debug
            _idleTimer.Tick += idleTimer_Tick;
            _idleTimer.Start();

#if !DEBUG
            // 初始化掛鉤
            _keyboardProc = KeyboardHookCallback;
            _mouseProc = MouseHookCallback;

            _keyboardHookId = SetHook(WH_KEYBOARD_LL, _keyboardProc);
            _mouseHookId = SetHook(WH_MOUSE_LL, _mouseProc);
#endif
        }

#if !DEBUG

        private IntPtr SetHook(int idHook, HookProc proc)
        {
            using (var process = System.Diagnostics.Process.GetCurrentProcess())
            using (var module = process.MainModule)
            {
                return SetWindowsHookEx(idHook, proc, GetModuleHandle(module.ModuleName), 0);
            }
        }

        private IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                _idleTriggered = false;
                _idleTimer.ReStart();
            }
            return CallNextHookEx(_keyboardHookId, nCode, wParam, lParam);
        }

        private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                _idleTriggered = false;
                _idleTimer.ReStart();
            }
            return CallNextHookEx(_mouseHookId, nCode, wParam, lParam);
        }

#endif

        private void SetProcessBar(int value)
        {
            if (value >= 0 && value <= 100)
            {
                if (!ProgressBar.ShowValue)
                    ProgressBar.ShowValue = true;
                ProgressBar.Value = value;
            }
            else
            {
                ProgressBar.ShowValue = false;
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            // 停止所有 Timer
            _messageTimer?.Stop();
            _messageTimer?.Dispose();

            _idleTimer?.Stop();
            _idleTimer?.Dispose();

            clockTimer?.Stop();
            clockTimer?.Dispose();

            WeakReferenceMessenger.Default.UnregisterAll(this);

            // 解除掛鉤
            if (_keyboardHookId != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_keyboardHookId);
            }
            if (_mouseHookId != IntPtr.Zero)
            {
                UnhookWindowsHookEx(_mouseHookId);
            }

            // 確保應用程式退出
            Application.Exit();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
#if DEBUG
            // 管理員模式方便測試
            _currentUser.AdminLogin();
            //string aa = AESHelper.Encrypt("Calin880819");
            //var core = scope.Resolve<ICore>();
            //core.UpdateModelsCache();
#else
            // 訪客模式
            _currentUser.SwitchCurrentUserToGuest();
#endif
        }

        /// <summary>
        /// 調整視窗大小。
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1440;
            const int TARGET_HEIGHT = 950;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        /********************
         * 操作模式 & 頁面載入
         ********************/
        /// <summary>
        /// 因應權限變更，設定相關選單與頁面。
        /// </summary>
        private void RecreateMainMenu()
        {
            TreeNode node1, node2;
            int pageIndex;

            _isAdmin = _user.IsAdmin;
            _isGuest = _user.IsGuest;

            /********************
             * 右側副選單
             ********************/
            // 使用者選單
            node1 = rNavBar.Nodes[0];
            node1.Text = _user.UserName;
            node1.Nodes.Clear();

            Console.WriteLine($"{_isAdmin},{_isGuest}");

            if (_isAdmin)
            {
                //node1.BackColor = Color.Red;
                //node1.ForeColor = Color.Red;
                rNavBar.SetNodeSymbol(node1, 362718);
            }
            else if (_isGuest)
            {
                //node1.ForeColor = Color.Gray;
                rNavBar.SetNodeSymbol(node1, 362720);
            }
            else
            {
                //node1.ForeColor = Color.Green;
                rNavBar.SetNodeSymbol(node1, 362716);
            }

            // 使用者選單 -> 登入/登出
            if (_isGuest)
            {
                pageIndex = (int)PageCode.Login;
                node2 = rNavBar.CreateChildNode(node1, PageCode.Login.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 560023);
                node2.Tag = pageIndex;
            }
            else
            {
                pageIndex = (int)PageCode.Logout;
                node2 = rNavBar.CreateChildNode(node1, PageCode.Logout.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 559834);
                node2.Tag = pageIndex;

                pageIndex = (int)PageCode.SwitchUser;
                node2 = rNavBar.CreateChildNode(node1, PageCode.SwitchUser.GetDescription(), pageIndex);
                rNavBar.SetNodeSymbol(node2, 362720);
                node2.Tag = pageIndex;
            }

            //// 設定
            //if (_isAdmin)
            //{
            //    pageIndex = (int)PageCode.Setup;
            //    _pageManager.AddOrReplacePage<SetupPage>(pageIndex);
            //    node2 = rNavBar.CreateChildNode(node1, PageCode.Setup.GetDescription(), pageIndex);
            //    rNavBar.SetNodeSymbol(node2, 361459);
            //    node2.Tag = pageIndex;
            //}

            rNavBar.Refresh();

            /********************
             * 左側主選單
             ********************/
            lNavBar.Nodes.Clear();
            _availablePageCode = new HashSet<PageCode>();

            bool hasToolQuest = _permission.HasControlAccess(PermissionWords.MODULE_TOOL_QUEST);
            bool hasMechaTrack = _permission.HasControlAccess(PermissionWords.MODULE_MECHA_TRACK);
            bool hasMaintiFlow = _permission.HasControlAccess(PermissionWords.MODULE_MAINTI_FLOW);
            bool hasSetup = _permission.HasControlAccess(PermissionWords.MODULE_SETUP);

            // 主頁面
            if (_user.IsGuest || !(hasToolQuest || hasMechaTrack || hasMaintiFlow || hasSetup))
            {
                pageIndex = (int)PageCode.MainPage;
                //_pageManager.AddOrReplacePage<MainPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.MainPage.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 559530);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.MainPage);
            }

            // 維護工單
            if (hasMaintiFlow)
            {
                pageIndex = (int)PageCode.MaintiFlow;
                //_pageManager.AddOrReplacePage<MaintiFlowPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.MaintiFlow.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 361613);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.MaintiFlow);
            }

            // 專案管理
            if (hasMechaTrack)
            {
                pageIndex = (int)PageCode.MechaTrack;
                //_pageManager.AddOrReplacePage<MechaTrackPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.MechaTrack.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 261474);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.MechaTrack);
            }

            // 工具委託
            if (hasToolQuest)
            {
                pageIndex = (int)PageCode.ToolQuest;
                //_pageManager.AddOrReplacePage<ToolQuestPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.ToolQuest.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 362133);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.ToolQuest);
            }

            // 顯示設定頁
            if (hasSetup)
            {
                pageIndex = (int)PageCode.Setup;
                //_pageManager.AddOrReplacePage<SetupPage>(pageIndex);
                node1 = lNavBar.CreateNode(PageCode.Setup.GetDescription(), pageIndex);
                lNavBar.SetNodePageIndex(node1, pageIndex);
                lNavBar.SetNodeSymbol(node1, 361459);
                node1.Tag = pageIndex;
                _availablePageCode.Add(PageCode.Setup);
            }

            if (lNavBar.SelectedIndex == -1)
                lNavBar.SelectedIndex = 0;

            lNavBar.SelectedIndex = 0;
            lNavBar.Refresh();

            if (_availablePageCode.Contains(_currentPageCode))
                SwitchPage(_currentPageCode);
            else
            {
                _currentPageCode = _availablePageCode.First();
                SwitchPage(_currentPageCode);
            }
        }

        /// <summary>
        /// 登入對話框。
        /// </summary>
        private void Login()
        {
            using (var dlg = new LoginForm(_scope.Resolve<LoginControl>()))
                dlg.ShowDialog();

            //DialogInfo user = new DialogInfo();
            //using (var dlg = _lifetimeScope.Resolve<UserLogin>())
            //{
            //    if (dlg.ShowDialog() == DialogResult.OK)
            //    {
            //        user = dlg.Results;
            //        var ret = _currentUser.Authenticate(user.NewName, user.NewPassword);
            //    }
            //}

            //using (var scope = _lifetimeScope.BeginLifetimeScope())
            //{
            //    var _currentUser = scope.Resolve<ICurrentUserService>();
            //    if (!_currentUser.SwitchAuthorityByDialog())
            //    {
            //        SetAuthority(scope.Resolve<CurrentAuthority>());
            //    }
            //}
        }

        /// <summary>
        /// 登出。
        /// </summary>
        private void Logout()
        {
            _currentUser.SwitchCurrentUserToGuest();
        }

        /// <summary>
        /// 點擊右選單。
        /// </summary>
        /// <param name="itemText">選單文字。</param>
        /// <param name="menuIndex">選項索引。</param>
        /// <param name="pageIndex">頁面索引。</param>
        private void NavBar_Right_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            if (Enum.TryParse(pageIndex.ToString(), out PageCode pageCode))
            {
                switch (pageCode)
                {
                    case PageCode.Login:
                        Login();
                        break;

                    case PageCode.Logout:
                        Logout();
                        break;

                    case PageCode.SwitchUser:
                        Login();
                        break;

                    case PageCode.Setup:
                        SwitchPage(pageIndex);
                        break;

                        //case PageCode.SetupTrigger:
                }
            }
        }

        /// <summary>
        /// 點擊導覽列選單。
        /// </summary>
        /// <param name="itemText">選單文字。</param>
        /// <param name="menuIndex">選項索引。</param>
        /// <param name="pageIndex">頁面索引。</param>
        private void NavBar_MenuItemClick(string itemText, int menuIndex, int pageIndex)
        {
            SwitchPage(pageIndex);
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageCode">頁面代碼。</param>
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentPageCode == pageCode && PageCode.Login != pageCode)
                return;

            SwitchPage((int)pageCode);
        }

        /// <summary>
        /// 切換操作頁面。
        /// </summary>
        /// <param name="pageIndex">頁面索引。</param>
        private void SwitchPage(int pageIndex)
        {
            if (Enum.TryParse(pageIndex.ToString(), out PageCode pageCode))
            {
                switch (pageCode)
                {
                    case PageCode.MainPage:
                        _nav.Navigate<MainPage>(nameof(MainRegion), alive: false);
                        break;
                    case PageCode.ToolQuest:
                        _nav.Navigate<ToolQuestPage>(nameof(MainRegion), alive: true);
                        break;
                    case PageCode.MechaTrack:
                        _nav.Navigate<MechaTrackPage>(nameof(MainRegion), alive: true);
                        break;
                    case PageCode.MaintiFlow:
                        _nav.Navigate<MaintiFlowPage>(nameof(MainRegion), alive: true);
                        break;
                    case PageCode.Setup:
                        _nav.Navigate<SetupPage>(nameof(MainRegion), alive: true);
                        break;
                    default:
                        return;
                }
                _currentPageCode = pageCode;
            }
        }

        /********************
         * 無動作偵測
         ********************/
        private void idleTimer_Tick(object sender, EventArgs e)
        {
            _idleTriggered = true;
            _idleTimer.Stop();

            using (var dlg = _scope.Resolve<LogoutCountdown>())
                dlg.ShowDialog();

            _idleTriggered = false;
            _idleTimer.ReStart();
        }

        /********************
         * 系統事件
         ********************/
        private void clockTimer_Tick(object sender, EventArgs e)
        {
            Clock.Text = DateTime.Now.DateTimeString();
        }

        private void CustomizeTreeNodeColors(TreeView treeView)
        {
            treeView.DrawMode = TreeViewDrawMode.OwnerDrawAll; // Change to OwnerDrawAll to ensure full control over drawing
            treeView.DrawNode += (sender, e) =>
            {
                if (e.Node == null) return;

                // Set default colors
                Color foreColor = treeView.ForeColor;
                Color backColor = treeView.BackColor;

                if (e.State.HasFlag(TreeNodeStates.Selected))
                {
                    // Selected color
                    foreColor = Color.White;
                    backColor = Color.Blue;
                }
                else if (e.Bounds.Contains(treeView.PointToClient(Cursor.Position)))
                {
                    // Hover color
                    foreColor = CommonStyles.HoverColor;
                    backColor = Color.LightGray;
                }

                // Fill the background
                using (var backgroundBrush = new SolidBrush(backColor))
                {
                    e.Graphics.FillRectangle(backgroundBrush, e.Bounds);
                }

                // Draw the text
                TextRenderer.DrawText(
                    e.Graphics,
                    e.Node.Text,
                    treeView.Font,
                    e.Bounds,
                    foreColor,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.Left
                );

                // Avoid default drawing
                e.DrawDefault = false;
            };
        }
    }
}
