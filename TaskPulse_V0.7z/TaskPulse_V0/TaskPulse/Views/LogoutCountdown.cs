﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Calin.TaskPulse.Core;
using Sunny.UI;

namespace Calin.TaskPulse.Views
{
    public partial class LogoutCountdown : UIForm
    {
        // Importing user32.dll to enable dragging the form without a title bar
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        #region fields

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HTCAPTION = 0x2;
        private const string ExitApplicationTemplate = "結束程式 ({0})";

        private Serilog.ILogger _logger;
        private int _countdownSeconds;
        private System.Windows.Forms.Timer _countdownTimer;

        #endregion fields

        public LogoutCountdown(Serilog.ILogger logger)
        {
            InitializeComponent();

            _logger = logger;
            EnableDragging(this);
        }

        private void LogoutCountdown_Load(object sender, EventArgs e)
        {
            _countdownSeconds = 10; // 10 秒倒數
            _countdownTimer = new Timer { Interval = 1000 };
            _countdownTimer.Tick += CountdownTimer_Tick;
            _countdownTimer.Start();

            CommonStyles.SetButton(btnReturn);
            CommonStyles.SetButton(btnExit, isCancel: true);
        }

        private void CountdownTimer_Tick(object sender, EventArgs e)
        {
            if (_countdownSeconds <= 0)
            {
                _countdownTimer.Stop();
                _logger.Information("由離線倒數計時對話框強制結束程式。");
                Application.Exit();
            }

            _countdownSeconds--;
            btnExit.Text = string.Format(ExitApplicationTemplate, _countdownSeconds);
            _countdownTimer.ReStart();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            _countdownTimer.Stop();
            _logger.Information("使用者從離線倒數計時對話框結束程式。");
            Application.Exit();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            _countdownTimer.Stop();
            _logger.Information("使用者從離線倒數計時對話框返回主程式。");
            this.Close();
        }

        private void EnableDragging(Control control)
        {
            if (!(control is UIButton))
            {
                control.MouseDown += (s, e) =>
                        {
                            if (e.Button == MouseButtons.Left)
                            {
                                ReleaseCapture();
                                SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
                            }
                        };

                // 遞歸處理子控制項
                foreach (Control child in control.Controls)
                {
                    EnableDragging(child);
                }
            }
        }
    }
}
