﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 使用者群組。
    /// </summary>
    public class UserGroupEntity
    {
        /// <summary>
        /// 使用者群組代號。
        /// </summary>
        [Description("群組代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 群組名稱。
        /// </summary>
        [Description("群組名稱")]
        [MaxLength(50)]
        public string Name { get; set; }

        public virtual ICollection<EmployeeEntity> Members { get; set; } = new HashSet<EmployeeEntity>();
        public virtual ICollection<Permission> Permissions { get; set; } = new HashSet<Permission>();
    }
}
