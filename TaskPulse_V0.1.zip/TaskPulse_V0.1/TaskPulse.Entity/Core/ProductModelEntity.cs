﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 機種。
    /// </summary>
    public class ProductModelEntity
    {
        /// <summary>
        /// 機種代號。
        /// </summary>
        [Description("機種代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 機種名稱。
        /// </summary>
        [Description("機種")]
        [MaxLength(10)]
        public string ModelName { get; set; }

        /// <summary>
        /// 機種狀態。
        /// </summary>
        [Description("狀態")]
        public ModelStatusEntity ModelStatus { get; set; }
        public int ModelStatusId { get; set; } // FK

        public virtual ICollection<WorkstationEntity> Workstations { get; set; }
    }
}
