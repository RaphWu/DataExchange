﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.Core
{
    /// <summary>
    /// 員工狀態。
    /// </summary>
    public class EmployeeStatusEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 顯示排序。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 維護狀態。
        /// </summary>
        [Description("狀態")]
        [Required]
        public string StatusName { get; set; }

        public virtual ICollection<EmployeeEntity> Employees { get; set; }
    }
}
