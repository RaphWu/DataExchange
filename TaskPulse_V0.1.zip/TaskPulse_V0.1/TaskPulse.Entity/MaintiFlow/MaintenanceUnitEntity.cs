﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    /// <summary>
    /// 維護單位清單。
    /// </summary>
    public class MaintenanceUnitEntity
    {
        /// <summary>
        /// 維護單位代號。
        /// </summary>
        [Description("單位代號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// 螢幕排序。
        /// </summary>
        [Description("編號")]
        public int OrderNo { get; set; }

        /// <summary>
        /// 單位名稱。
        /// </summary>
        [Description("單位名稱")]
        public string UnitName { get; set; }

        public virtual ICollection<WorkOrderEntity> TaskOrders { get; set; }
    }
}
