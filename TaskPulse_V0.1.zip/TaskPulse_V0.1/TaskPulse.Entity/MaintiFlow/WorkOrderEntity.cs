﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Entity.MaintiFlow
{
    /// <summary>
    /// 維護工單。
    /// </summary>
    public class WorkOrderEntity
    {
        /// <summary>
        /// 維護工單序號。
        /// </summary>
        [Description("序號")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /********************
         * 工單資料
         ********************/
        /// <summary>
        /// 維護工單編號。
        /// </summary>
        [Description("工單編號")]
        [Required]
        [Index(IsUnique = true)]
        public string WorkOrderNo { get; set; }

        /// <summary>
        /// 維護狀態。
        /// </summary>
        [Description("狀態")]
        [Required]
        public FlowStatus Status { get; set; }

        /// <summary>
        /// 機台編號。
        /// </summary>
        [Description("機台")]
        public virtual MachineEntity Machine { get; set; } // CoreContext
        [Index]
        public int? MachineId { get; set; } // FK

        /// <summary>
        /// 工站。
        /// </summary>
        [Description("工站")]
        public virtual WorkstationEntity Workstation { get; set; } // CoreContext
        [Index]
        public int? WorkstationId { get; set; } // FK

        /// <summary>
        /// 建檔人員。
        /// </summary>
        [Description("建檔人員")]
        public virtual EmployeeEntity Creator { get; set; } // CoreContext
        public int CreatorId { get; set; } // FK

        /// <summary>
        /// 建檔日期。
        /// </summary> 
        [Description("建檔日期")]
        [Required]
        public DateTime CreationDateTime { get; set; }

        /********************
         * 維護部門
         ********************/
        /// <summary>
        /// 維護單位。
        /// </summary>
        [Description("維護單位")]
        public virtual MaintenanceUnitEntity MaintenanceUnit { get; set; }
        public int? MaintenanceUnitId { get; set; } // FK

        /// <summary>
        /// 維護工程師。
        /// </summary>
        [Description("工程師")]
        public virtual ICollection<EmployeeEntity> Engineers { get; set; } // 多對多

        /// <summary>
        /// 接單時間。
        /// </summary>
        [Description("接單時間")]
        [Required]
        public DateTime AcceptedTime { get; set; }

        /********************
         * 維護內容
         ********************/
        /// <summary>
        /// 維護類型。
        /// </summary>
        [Description("維護類型")]
        public virtual IssueCategoryEntity IssueCategory { get; set; }
        public int? IssueCategoryId { get; set; } // FK

        /// <summary>
        /// 問題描述。
        /// </summary>
        [Description("問題描述")]
        public string IssueDescription { get; set; }

        /// <summary>
        /// 維護內容。
        /// </summary>
        [Description("維護內容")]
        public string Details { get; set; }

        /// <summary>
        /// 維護開始時間。
        /// </summary>
        [Description("開始時間")]
        public DateTime? RepairStarted { get; set; }

        /// <summary>
        /// 維修完成時間。
        /// </summary>
        [Description("完成時間")]
        public DateTime? RepairCompleted { get; set; }

        /// <summary>
        /// 維修工時。
        /// </summary>
        [Description("維修工時")]
        public long RepairDurationTick { get; set; }

        /// <summary>
        /// 維護工單內容填寫完成時間。
        /// </summary>
        [Description("填寫時間")]
        public DateTime? FillingTime { get; set; }

        /********************
         * 維護申請資訊
         ********************/
        /// <summary>
        /// 需求單位名稱。
        /// </summary>
        [Description("需求單位")]
        public virtual DepartmentEntity RequestingUnit { get; set; }
        public int? RequestingUnitId { get; set; } // FK

        /// <summary>
        /// 回覆人員。
        /// </summary>
        [Description("回覆人員")]
        public virtual EmployeeEntity FeedbackEmployee { get; set; } // CoreContext
        public int? FeedbackEmployeeId { get; set; } // FK

        /// <summary>
        /// 需求單位回覆內容。
        /// </summary>
        [Description("回覆內容")]
        public string Feedback { get; set; }

        /// <summary>
        /// 停動開始。
        /// </summary>
        [Description("停動開始")]
        public DateTime? OutageStarted { get; set; }

        /// <summary>
        /// 停動結束。
        /// </summary>
        [Description("停動結束")]
        public DateTime? OutageEnded { get; set; }

        /// <summary>
        /// 停動工時。
        /// </summary>
        [Description("停動工時")]
        public long OutageDurationTick { get; set; }

        /********************
         * 其他
         ********************/
        /// <summary>
        /// 責任歸屬。
        /// </summary>
        [Description("責任歸屬")]
        public string Responsible { get; set; }
    }
}
