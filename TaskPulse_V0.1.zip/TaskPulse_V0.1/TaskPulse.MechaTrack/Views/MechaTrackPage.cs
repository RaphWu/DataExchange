﻿namespace Calin.TaskPulse.MechaTrack.Views
{
    public partial class MechaTrackPage : UserControl
    {
        public MechaTrackPage()
        {
            InitializeComponent();
        }
    }
}
