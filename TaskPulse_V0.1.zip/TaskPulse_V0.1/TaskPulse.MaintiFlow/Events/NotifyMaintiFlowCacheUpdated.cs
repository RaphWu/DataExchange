﻿namespace Calin.TaskPulse.MaintiFlow.Events
{
    public class NotifyMaintiFlowCacheUpdated
    {
        public static readonly NotifyMaintiFlowCacheUpdated Instance = new NotifyMaintiFlowCacheUpdated();
        private NotifyMaintiFlowCacheUpdated() { }
    }
}
