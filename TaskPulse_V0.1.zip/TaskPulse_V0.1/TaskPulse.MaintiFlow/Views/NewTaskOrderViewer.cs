﻿using System;
using System.Collections.Generic;
using System.Linq;
using Calin.TaskPulse.Core.Models;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class NewTaskOrderViewer : UIForm
    {
        private readonly MaintiFlowData _flowData;

        public string Title { set => this.Text = value; }

        /// <summary>
        /// 
        /// </summary>
        public List<TaskOrder> NewWorkOrderNos { get; set; }

        public NewTaskOrderViewer(MaintiFlowData maintiFlow)
        {
            InitializeComponent();
            _flowData = maintiFlow;
        }

        public void Initialize()
        {
            if (NewWorkOrderNos == null || NewWorkOrderNos.Count == 0)
                return;

            var newWorkOrderNos = NewWorkOrderNos[0];
            var to0 = _flowData.TaskOrders.FirstOrDefault(x => x.Id == newWorkOrderNos.Id);

            // 單行
            RequestingUnit.Text = to0.RequestingUnitString;
            Label_RequestingUnit.Text = PropertyText.Title.RequestingUnit;

            Creator.Text = to0.FullCreatorName;
            Label_Creator.Text = PropertyText.Title.Creator;

            CreationDate.Text = to0.CreationDateString;
            Label_CreationDate.Text = PropertyText.Title.CreationDateTime;

            OutageStarted.Text = to0.OutageStartedString;
            Label_OutageStarted.Text = PropertyText.Title.OutageStarted;

            IssueDescription.Text = to0.IssueDescription;
            Label_IssueDescription.Text = PropertyText.Title.IssueDescription;

            // 複合
            List<int> nos = new List<int>();
            List<string> orders = new List<string>();
            List<string> machines = new List<string>();

            foreach (var item in NewWorkOrderNos)
            {
                nos.Add(item.Id);
                orders.Add(item.WorkOrderNo);
                machines.Add(item.Machine.MachineCode);
            }

            WorkOrderNo.Multiline = true;
            WorkOrderNo.Lines = orders.ToArray();
            Label_WorkOrderNo.Text = PropertyText.Title.WorkOrderNo;

            MachineList.Text = string.Join("; ", machines);
            Label_MachineList.Text = PropertyText.Title.Machine;
        }

        private void uiButton_Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
