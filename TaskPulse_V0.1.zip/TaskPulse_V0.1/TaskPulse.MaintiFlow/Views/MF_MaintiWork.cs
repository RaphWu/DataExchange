﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Helper;
using Calin.TaskPulse.Core.Messaging;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Calin.TaskPulse.Core.ViewModels;
using Calin.TaskPulse.Entity.Contants;
using Calin.TaskPulse.MaintiFlow.Events;
using Sunny.UI;

namespace Calin.TaskPulse.MaintiFlow.Views
{
    public partial class MF_MaintiWork : UIForm
    {
        #region fields

        private readonly ILifetimeScope _scope;
        private readonly CoreContext _context;
        private readonly ICore _core;
        private readonly IMail _mail;
        private readonly CurrentUserContext _user;
        private readonly MaintiFlowData _flowData;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        private BindingList<TaskOrder> _editBuffs;
        private TaskOrder _editBuff = null;
        private BindingList<ListViewModel> _listSources;

        // UIDatetimePicker無法設定空值。
        // 如果它發現沒有輸入值，在失去焦點時會自動填入下面的日期時間，造成資料錯亂。
        // WinForms的DateTimePicker在網路上有自訂顯示空白的方法，
        // 但UIDatetimePicker拿掉Format屬性還限制了一些屬性設定，所以網路的方法無法使用。
        // 目前用比對法，如果DateTime值是下面這個值，視為沒有輸入。
        //private readonly DateTime ZERO_DATE_TIME = DateTime.Parse("1900/1/1 0:0");

        #endregion fields

        public BindingList<TaskOrder> Orders { get; set; } = new BindingList<TaskOrder>();
        public List<int> EngineerList { get; set; } = new List<int>();

        public MF_MaintiWork(ILifetimeScope lifetimeScope,
                             CoreContext coreContext,
                             ICore core,
                             IMail mail,
                             CurrentUserContext currentUserContext,
                             MaintiFlowData maintiFlowData,
                             CoreData coreData,
                             MultiSelector multiSelector)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _context = coreContext;
            _core = core;
            _mail = mail;
            _user = currentUserContext;
            _flowData = maintiFlowData;
            _coreData = coreData;
            _mSel = multiSelector;

            CommonStyles.SetButton(btnSave);
            CommonStyles.SetButton(btnCompleted);
            CommonStyles.SetButton(btnCancel, isCancel: true);
            CommonStyles.SetButton(btnTransfer, isAccent: true);
            CommonStyles.SetButton(ModelWorkstation);
            CommonStyles.SetButton(Engineers);
            CommonStyles.SetButton(btnQuickCreate);
            CommonStyles.SetListBox(ListBoxOrders);

            btnQuickCreate.Visible = _user.IsAdmin || _user.IsEngineer;
        }

        private void FT_MaintiWork_Load(object sender, System.EventArgs e)
        {
            var lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
            lvm.AddRange(_context.MaintenanceUnits
                .Select(m => new ListViewModel()
                {
                    NullableId = m.Id,
                    Name = m.UnitName,
                })
                .ToList());
            MaintenanceUnit.DataSource = lvm;
            MaintenanceUnit.DisplayMember = "Name";
            MaintenanceUnit.ValueMember = "NullableId";

            lvm = new List<ListViewModel> { new ListViewModel() { NullableId = 0, Name = "" } };
            lvm.AddRange(_context.IssueCategories
                .Select(m => new ListViewModel()
                {
                    NullableId = m.Id,
                    Name = m.CategoryName,
                })
                .ToList());
            IssueCategory.DataSource = lvm;
            IssueCategory.DisplayMember = "Name";
            IssueCategory.ValueMember = "NullableId";

            int tabIndex = 0;
            Label_WorkOrderNo.Text = PropertyText.Title.WorkOrderNo;
            WorkOrderNo.TabIndex = ++tabIndex;
            WorkOrderNo.ReadOnly = true;

            Label_Creator.Text = PropertyText.Title.Creator;
            Creator.TabIndex = ++tabIndex;
            Creator.ReadOnly = true;

            Label_CreationDate.Text = PropertyText.Title.CreationDateTime;
            CreationDate.TabIndex = ++tabIndex;
            CreationDate.ReadOnly = true;

            Label_MachineList.Text = PropertyText.Title.Machine;
            MachineList.TabIndex = ++tabIndex;
            MachineList.ReadOnly = true;

            Label_ModelWorkstation.Text = PropertyText.Title.ModelWsName;
            ModelWorkstation.TabIndex = ++tabIndex;

            Label_AcceptedTime.Text = PropertyText.Title.AcceptedTime;
            AcceptedTime.TabIndex = ++tabIndex;
            AcceptedTime.ReadOnly = true;

            Label_RequestingUnit.Text = PropertyText.Title.RequestingUnit;
            RequestingUnit.TabIndex = ++tabIndex;
            RequestingUnit.ReadOnly = true;

            Label_MaintenanceUnit.Text = PropertyText.Title.MaintenanceUnit;
            MaintenanceUnit.TabIndex = ++tabIndex;

            Label_Engineers.Text = PropertyText.Title.Engineer;
            Engineers.TabIndex = ++tabIndex;

            Label_IssueCategory.Text = PropertyText.Title.IssueCategory;
            IssueCategory.TabIndex = ++tabIndex;

            Label_IssueDescription.Text = PropertyText.Title.IssueDescription;
            IssueDescription.TabIndex = ++tabIndex;

            Label_Details.Text = PropertyText.Title.Details;
            Details.TabIndex = ++tabIndex;

            Label_RepairStarted.Text = PropertyText.Title.RepairStarted;
            RepairStarted.TabIndex = ++tabIndex;

            Label_RepairCompleted.Text = PropertyText.Title.RepairCompleted;
            RepairCompleted.TabIndex = ++tabIndex;

            Label_OutageStarted.Text = PropertyText.Title.OutageStarted;
            OutageStarted.TabIndex = ++tabIndex;
            OutageStarted.ReadOnly = true;

            Label_OutageEnded.Text = PropertyText.Title.OutageEnded;
            OutageEnded.TabIndex = ++tabIndex;

            Label_RepairDuration.Text = PropertyText.Title.RepairDuration;
            RepairDuration.TabIndex = ++tabIndex;
            RepairDuration.ReadOnly = true;

            Label_OutageDuration.Text = PropertyText.Title.OutageDuration;
            OutageDuration.TabIndex = ++tabIndex;
            OutageDuration.ReadOnly = true;

            LoadData();
        }

        private void FT_MaintiWork_Shown(object sender, EventArgs e)
        {
            //SunnyUiHelper.AdjustFormLayout(this, TLP_Content);
        }

        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Button_Save_Click(object sender, EventArgs ea)
        {
            try
            {
                if (!DataVerify())
                    return;

                SaveToCurrentBuff();
                for (int idx = 0; idx < _editBuffs.Count; idx++)
                {
                    var buff = _editBuffs[idx];
                    var to = _context.TaskOrders.FirstOrDefault(t => t.WorkOrderNo == buff.WorkOrderNo);
                    if (to == null)
                        throw new ArgumentNullException(buff.WorkOrderNo);

                    SaveToCurrentRec(buff, to);
                }
                _context.SaveChanges();
                Messenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);
                MessageBox.Show("維護工單已儲存！");
                //Initialize();
                //LoadData();
                //_listSources.RemoveAt(ListBox_Orders.SelectedIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private bool DataVerify()
        {
            List<string> err = new List<string>();

            if (string.IsNullOrEmpty(ModelWorkstation.Text))
                err.Add($"沒有輸入 {PropertyText.Title.ModelWsName}！");

            if (string.IsNullOrEmpty(MaintenanceUnit.Text))
                err.Add($"沒有輸入 {PropertyText.Title.MaintenanceUnit}！");

            if (string.IsNullOrEmpty(Engineers.Text))
                err.Add($"沒有輸入 {PropertyText.Title.Engineer}！");

            if (string.IsNullOrEmpty(IssueCategory.Text))
                err.Add($"沒有輸入 {PropertyText.Title.IssueCategory}！");

            if (string.IsNullOrEmpty(RepairStarted.Text))
                err.Add($"沒有輸入 {PropertyText.Title.RepairStarted}！");

            if (string.IsNullOrEmpty(RepairCompleted.Text))
                err.Add($"沒有輸入 {PropertyText.Title.RepairCompleted}！");

            if (RepairCompleted.Value < RepairStarted.Value)
                err.Add($"{PropertyText.Title.RepairCompleted} 必須大於等於 {PropertyText.Title.RepairStarted}！");

            if (string.IsNullOrEmpty(OutageEnded.Text))
                err.Add($"沒有輸入 {PropertyText.Title.OutageEnded}！");

            if (RepairCompleted.Value < OutageEnded.Value)
                err.Add($"{PropertyText.Title.OutageEnded} 必須大於等於 {PropertyText.Title.RepairCompleted}！");

            if (OutageStarted.Value > OutageEnded.Value)
                err.Add($"{PropertyText.Title.OutageEnded} 必須大於等於 {PropertyText.Title.OutageStarted}！");

            if (err.Count > 0)
            {
                err.Add("\n注意：資料尚未儲存！");
                MessageBox.Show(string.Join(Environment.NewLine, err),
                    "輸入資料不正確",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return false;
            }
            else
            {
                Messenger.Default.Send(new StatusBarMessage("資料已儲存。"));
                return true;
            }
        }

        /********************
         * 
         ********************/
        public void Initialize()
        {
        ReadData:
            var tos1 = _flowData.TaskOrders
                //.Where(t => t.Status == FlowStatus.InProgress && (t.Creator != null || (t.Engineers != null && t.Engineers.Any())))
                .Where(t => t.Status == FlowStatus.InProgress)
                .ToList();
            if (!tos1.Any())
            {
                using (var qc = _scope.Resolve<MF_QuickCreate>())
                {
                    if (qc.ShowDialog() == DialogResult.OK)
                        goto ReadData;
                }
            }

            if (!tos1.Any())
                return;

            Orders = new BindingList<TaskOrder>(tos1);

            var tos2 = tos1
                .Select(o => new ListViewModel()
                {
                    IdString = o.WorkOrderNo,
                    Name = o.WorkOrderNo + " » " + o.MachineCode,
                })
                .ToList();
            _listSources = new BindingList<ListViewModel>(tos2);
        }

        private void LoadData()
        {
            // Load ViewModel
            _editBuffs = new BindingList<TaskOrder>();
            foreach (var rec in Orders)
            {
                _editBuffs.Add(new TaskOrder()
                {
                    Id = rec.Id,
                    WorkOrderNo = rec.WorkOrderNo,
                    Status = rec.Status,
                    Machine = rec.Machine,
                    WorkstationId = rec.WorkstationId,
                    Workstation = rec.Workstation,
                    Creator = rec.Creator,
                    CreationDateTime = rec.CreationDateTime,
                    MaintenanceUnitId = rec.MaintenanceUnitId,
                    MaintenanceUnit = rec.MaintenanceUnit,
                    Engineers = rec.Engineers,
                    AcceptedTime = rec.AcceptedTime,
                    IssueCategoryId = rec.IssueCategoryId,
                    IssueCategory = rec.IssueCategory,
                    IssueDescription = rec.IssueDescription,
                    Details = rec.Details,
                    RepairStarted = rec.RepairStarted,
                    RepairCompleted = rec.RepairCompleted,
                    RepairDuration = rec.RepairDuration,
                    RequestingUnit = rec.RequestingUnit,
                    FeedbackEmployeeId = rec.FeedbackEmployeeId,
                    Feedback = rec.Feedback,
                    OutageStarted = rec.OutageStarted,
                    OutageEnded = rec.OutageEnded,
                    OutageDuration = rec.OutageDuration,
                });
            }

            ListBoxOrders.DisplayMember = "Name";
            ListBoxOrders.ValueMember = "IdString";
            ListBoxOrders.DataSource = _listSources;

            UpdateCurrentBuffIndex();
            ReadCurrentBuff();
        }

        // 讀取新值
        private void ReadCurrentBuff()
        {
            if (_editBuff != null)
            {
                WorkOrderNo.Text = _editBuff.WorkOrderNo;
                Creator.Text = _editBuff.CreatorNameWithDepartment;
                CreationDate.Text = _editBuff.CreationDateString;
                MachineList.Text = _editBuff.FullMachineName;
                ModelWorkstation.Text = _editBuff.ModelWsName;
                AcceptedTime.Text = _editBuff.AcceptedTimeString;
                RequestingUnit.Text = _editBuff.RequestingUnitString;
                MaintenanceUnit.SelectedValue = _editBuff.MaintenanceUnitId ?? 0;
                IssueCategory.SelectedValue = _editBuff.IssueCategoryId ?? 0;
                IssueDescription.Text = _editBuff.IssueDescription;
                Details.Text = _editBuff.Details;
                RepairStarted.Value = _editBuff.RepairStarted ?? DateTime.Now;
                RepairCompleted.Value = _editBuff.RepairCompleted ?? DateTime.Now;
                OutageStarted.Value = _editBuff.OutageStarted ?? DateTime.Now;
                OutageEnded.Value = _editBuff.OutageEnded ?? DateTime.Now;

                RepairDuration.Text = _editBuff.RepairDurationString;
                OutageDuration.Text = _editBuff.OutageDurationString;

                Engineers.Text = _editBuff.EngineerString;
                //var emps = _editBuff.Engineers
                //   .Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                //   .Select(n => n.Trim())
                //   .ToList();
                //foreach (TreeNode node in Engineers.Nodes)
                //    node.Checked = emps.Contains(node.Text);
            }
        }

        private void UpdateCurrentBuffIndex()
        {
            if (ListBoxOrders.SelectedIndex >= 0)
                _editBuff = _editBuffs[ListBoxOrders.SelectedIndex];
            else
                _editBuff = new TaskOrder();
        }

        // 儲存舊值
        private void SaveToCurrentBuff()
        {
            if (_editBuff != null)
            {
                _editBuff.MaintenanceUnitId = (int?)MaintenanceUnit.SelectedValue;
                _editBuff.Engineers = _core.GetEngineers(Engineers.Text);
                _editBuff.IssueCategoryId = (int?)IssueCategory.SelectedValue;
                _editBuff.IssueDescription = IssueDescription.Text;
                _editBuff.Details = Details.Text;

                var ws = _core.GetWorkstation(ModelWorkstation.Text);
                if (ws != null)
                {
                    _editBuff.WorkstationId = ws.Id;
                    _editBuff.Workstation = ws;
                }
                else
                {
                    _editBuff.WorkstationId = 0;
                    _editBuff.Workstation = null;
                }
            }
        }

        private void SaveToCurrentRec(TaskOrder buff, TaskOrder to)
        {

            to.IssueDescription = buff.IssueDescription;
            to.Details = buff.Details;
            to.RepairStarted = buff.RepairStarted;
            to.RepairCompleted = buff.RepairCompleted;
            to.OutageEnded = buff.OutageEnded;

            //to.Workstation = _core.GetWorkstation(buff.WorkstationId ?? 0);

            // FK
            to.WorkstationId = buff.WorkstationId;
            to.MaintenanceUnitId = buff.MaintenanceUnitId;
            to.IssueCategoryId = buff.IssueCategoryId;

            // 多對多 - EngineerString
            to.Engineers.Clear();
            foreach (var emp in buff.Engineers)
            {
                var eng = _context.Employees.Find(emp.Id);
                if (eng != null)
                    to.Engineers.Add(eng);
            }
        }

        private void ListBoxOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaveToCurrentBuff();
            UpdateCurrentBuffIndex();
            ReadCurrentBuff();
        }

        /********************
         * 按鍵行為
         ********************/
        private void ModelWorkstation_ButtonClick(object sender, EventArgs e)
        {
            using (var mSel = _scope.Resolve<MultiSelector>())
            {
                mSel.HideTabHeaders = false;
                mSel.ShowTreeView = true;
                mSel.Title = $"請選擇{PropertyText.Title.ModelName}";
                mSel.TreeViewCaption = "機種";
                mSel.MultiSelection = false;
                mSel.TabPageCache = _coreData.ModelWsSingleTabPageCache;
                mSel.DefaultChecked = new List<string>() { _editBuff.ModelWsName };
                mSel.Initialize();

                if (mSel.ShowDialog() == DialogResult.OK)
                {
                    if (mSel.ResultList.Count > 0)
                    {
                        CategoryInfo info = mSel.ResultList[0];
                        int idx = ListBoxOrders.SelectedIndex;
                        var ws = _core.GetWorkstation(info.Id);
                        _editBuffs[idx].WorkstationId = ws.Id;
                        _editBuffs[idx].Workstation = ws;
                        _editBuffs[idx].Workstation.ModelId = ws != null && ws.ModelId != null
                            ? (int?)_core.GetModel((int)ws.ModelId).Id
                            : null;
                        ModelWorkstation.Text = string.Join(" » ", new string[2] { info.Category1, info.Name });
                    }
                    else
                    {
                        ModelWorkstation.Text = "";
                    }
                }
            }
        }

        private void MaintenanceUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_editBuff == null)
                return;

            if (MaintenanceUnit.SelectedItem is ListViewModel select)
                _editBuff.MaintenanceUnitId = select.Id;
        }

        private void Engineers_ButtonClick(object sender, EventArgs e)
        {
            _mSel.HideTabHeaders = true;
            _mSel.ShowTreeView = false;
            _mSel.Title = $"請選擇{PropertyText.Title.Engineer}";
            _mSel.DialogWidth = 600;
            _mSel.TreeViewCaption = PropertyText.Title.Department;
            _mSel.MultiSelection = true;
            _mSel.TabPageCache = _coreData.EngineerMultiTabPageCache;
            _mSel.DefaultChecked = Engineers.Text
                .Split(new char[] { ';', '»' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();
            _mSel.Initialize();

            if (_mSel.ShowDialog() == DialogResult.OK)
            {
                List<string> emps = new List<string>();
                foreach (var emp in _mSel.ResultList)
                    emps.Add(emp.Name);
                Engineers.Text = string.Join("; ", emps);
            }
        }

        private void Engineers_NodesSelected(object sender, TreeNodeCollection nodes)
        {
            if (_editBuff == null)
                return;

            EngineerList.Clear();
            for (int i = 0; i < nodes.Count; i++)
            {
                var node = nodes[i];
                if (node.Checked)
                    EngineerList.Add(((CategoryInfo)node.Tag).Id);
            }
        }

        private void RepairStarted_ValueChanged(object sender, DateTime value)
        {
            if (_editBuff != null)
            {
                _editBuff.RepairStarted = DateTime.TryParse(RepairStarted.Text, out DateTime dt)
                    ? (DateTime?)dt
                    : null;
            }
            UpdateRepairDuration();
        }

        private void RepairCompleted_ValueChanged(object sender, DateTime value)
        {
            if (_editBuff != null)
            {
                _editBuff.RepairCompleted = DateTime.TryParse(RepairCompleted.Text, out DateTime dt)
                    ? (DateTime?)dt
                    : null;
            }
            UpdateRepairDuration();
        }

        private void UpdateRepairDuration()
        {
            //bool hasStarted = cbRepairStarted.Checked && _editBuff.RepairStarted.HasValue;
            //bool hasCompleted = cbRepairCompleted.Checked && _editBuff.RepairCompleted.HasValue;

            //if (!hasCompleted)
            //    RepairCompleted.Text = "";

            //if (!hasStarted)
            //    RepairStarted.Text = "";

            if (_editBuff.RepairStarted != null)
            {
                _editBuff.RepairDuration = _editBuff.RepairCompleted != null
                    ? (TimeSpan)(_editBuff.RepairCompleted - _editBuff.RepairStarted)
                    : (TimeSpan)(DateTime.Now - _editBuff.RepairStarted);
            }
            else
            {
                _editBuff.RepairDuration = TimeSpan.Zero;
            }
            RepairDuration.Text = _editBuff.RepairDurationString;
        }

        private void OutageStarted_ValueChanged(object sender, DateTime value)
        {
            if (_editBuff != null)
            {
                _editBuff.OutageStarted = DateTime.TryParse(OutageStarted.Text, out DateTime dt)
                    ? (DateTime?)dt
                    : null;
            }
            UpdateOutageDuration();
        }

        private void OutageEnded_ValueChanged(object sender, DateTime value)
        {
            if (_editBuff != null)
            {
                _editBuff.OutageEnded = DateTime.TryParse(OutageEnded.Text, out DateTime dt)
                    ? (DateTime?)dt
                    : null;
            }
            UpdateOutageDuration();
        }

        private void UpdateOutageDuration()
        {
            //bool hasStarted = cbOutageStarted.Checked && _editBuff.OutageStarted.HasValue;
            //bool hasEnded = cbOutageEnded.Checked && _editBuff.OutageEnded.HasValue;

            //if (!hasEnded)
            //    OutageEnded.Text = "";

            //if (!hasStarted)
            //    OutageStarted.Text = "";

            if (_editBuff.OutageStarted != null)
            {
                _editBuff.OutageDuration = _editBuff.OutageEnded != null
                    ? (TimeSpan)(_editBuff.OutageEnded - _editBuff.OutageStarted)
                    : (TimeSpan)(DateTime.Now - _editBuff.OutageStarted);
            }
            else
            {
                _editBuff.OutageDuration = TimeSpan.Zero;
            }
            OutageDuration.Text = _editBuff.OutageDurationString;
        }

        private async void button_Completed_Click(object sender, EventArgs e)
        {
            if (!DataVerify())
                return;

            SaveToCurrentBuff();
            if (MessageBox.Show($"確定維護完成？\n工單編號：{_editBuff.WorkOrderNo}",
                                "請確定執行",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Question) == DialogResult.OK)
            {
                var to = _context.TaskOrders.FirstOrDefault(t => t.WorkOrderNo == _editBuff.WorkOrderNo);
                if (to != null)
                {
                    to.Status = FlowStatus.Pending;
                    to.FillingTime = DateTime.Now;
                    SaveToCurrentRec(_editBuff, to);
                    await _context.SaveChangesAsync();
                    Messenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);

                    //Initialize();
                    //LoadData();
                    _listSources.RemoveAt(ListBoxOrders.SelectedIndex);

                    // send email
                    StringBuilder mail = new StringBuilder();
                    mail.Append("<table><caption>維護完成</caption>");

                    mail.Append("<tr>");
                    mail.Append($"<td>{PropertyText.Title.Performer}</td>");
                    mail.Append($"<td>{_user.UserName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護工程師</td>");
                    mail.Append($"<td>{string.Join("<br/>", to.Engineers.Select(emp => emp.EmployeeId + ", " + emp.EmployeeName))}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>工單</td>");
                    mail.Append($"<td>{to.WorkOrderNo}: {to.FullMachineName}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護開始時間</td>");
                    mail.Append($"<td>{to.RepairStartedString}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護完成時間</td>");
                    mail.Append($"<td>{to.RepairCompletedString} ({to.RepairDurationString})</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>停動開始時間</td>");
                    mail.Append($"<td>{to.OutageStartedString}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>停動結束時間</td>");
                    mail.Append($"<td>{to.OutageEndedString} ({to.OutageDurationString})</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>問題描述</td>");
                    mail.Append($"<td>{to.IssueDescription}</td>");
                    mail.Append("</tr>");

                    mail.Append("<tr>");
                    mail.Append("<td>維護內容</td>");
                    mail.Append($"<td>{to.Details}</td>");
                    mail.Append("</tr>");
                    mail.Append("</table>");

                    //var mailList = new HashSet<int>() { 19 };
                    var mailList = new HashSet<int>(to.Engineers.Select(emp => emp.Id).ToList())
                    {
                        to.CreatorId
                    };
                    _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                                   $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][維護完成] {to.WorkOrderNo}: {to.FullMachineName}",
                                   mail.ToString());

                    MessageBox.Show($"維護工單 {to.WorkOrderNo} 已轉換至 {PageCode.FlowConfirmed.GetDescription()}！");

                    // 無記錄則關閉視窗
                    if (_listSources.Count == 0)
                        this.Close();
                    ListBoxOrders_SelectedIndexChanged(ListBoxOrders, EventArgs.Empty);
                }
            }
        }

        private async void btnTransfer_Click(object sender, EventArgs e)
        {
            SaveToCurrentBuff();
            if (MessageBox.Show($"確定轉移？工單將回至未接單狀態。\n工單編號：{_editBuff.WorkOrderNo}",
                               "轉移工單確認",
                               MessageBoxButtons.OKCancel,
                               MessageBoxIcon.Question) == DialogResult.OK)
            {
                var to = await _context.TaskOrders.FirstOrDefaultAsync(t => t.WorkOrderNo == _editBuff.WorkOrderNo);
                to.Status = FlowStatus.NewTaskOrder;
                await _context.SaveChangesAsync();
                Messenger.Default.Send(NotifyMaintiFlowDataUpdated.Instance);

                //Initialize();
                //LoadData();
                _listSources.RemoveAt(ListBoxOrders.SelectedIndex);

                // send email
                StringBuilder mail = new StringBuilder();
                mail.Append("<table><caption>轉移工單</caption>");

                mail.Append("<tr>");
                mail.Append($"<td>{PropertyText.Title.Performer}</td>");
                mail.Append($"<td>{_user.UserName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>維護工程師</td>");
                mail.Append($"<td>{string.Join("<br/>", to.Engineers.Select(emp => emp.EmployeeId + ", " + emp.EmployeeName))}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>工單</td>");
                mail.Append($"<td>{to.WorkOrderNo}: {to.FullMachineName}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>停動開始時間</td>");
                mail.Append($"<td>{to.OutageStartedString}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>問題描述</td>");
                mail.Append($"<td>{to.IssueDescription}</td>");
                mail.Append("</tr>");

                mail.Append("<tr>");
                mail.Append("<td>維護內容</td>");
                mail.Append($"<td>{to.Details}</td>");
                mail.Append("</tr>");
                mail.Append("</table>");

                //var mailList = new HashSet<int>() { 19 };
                var mailList = new HashSet<int>(to.Engineers.Select(emp => emp.Id).ToList())
                    {
                        to.CreatorId
                    };
                _mail.SendMail($"{PublicConsts.MAINTI_FLOW}{PublicConsts.SUFFIX_SYS}", mailList,
                               $"[{PublicConsts.APP_NAME}][{PublicConsts.MAINTI_FLOW}][轉移工單] {to.WorkOrderNo}: {to.FullMachineName}",
                               mail.ToString());

                MessageBox.Show($"維護工單 {to.WorkOrderNo} 已轉換至 {FlowStatus.NewTaskOrder.GetDescription()} 狀態！");

                // 無記錄則關閉視窗
                if (_listSources.Count == 0)
                    this.Close();
                ListBoxOrders_SelectedIndexChanged(ListBoxOrders, EventArgs.Empty);
            }
        }

        private void btnQuickCreate_Click(object sender, EventArgs e)
        {
            using (var qc = _scope.Resolve<MF_QuickCreate>())
            {
                qc.ShowDialog();
            }
        }
    }
}
