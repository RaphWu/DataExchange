﻿//using System.Data.Entity;
//using Calin.TaskPulse.Core.Models;
//using Calin.TaskPulse.Entity.Core;
//using Calin.TaskPulse.Entity.MaintiFlowMain;

//namespace Calin.TaskPulse.MaintiFlowMain.Models
//{
//    /// <summary>
//    /// 資料庫區。
//    /// </summary>
//    public class MaintiFlowContext : DbContext
//    {
//        private readonly CoreContext _coreContext;

//        public MaintiFlowContext(CoreContext coreContext) : base("name=MaintiFlowContext")
//        {
//            _coreContext = coreContext;

//            //if (System.IO.File.Exists("MaintiFlowDB.db"))
//            //    System.IO.File.Delete("MaintiFlowDB.db");

//            //Database.SetInitializer(new CreateDatabaseIfNotExists<MaintiFlowContext>());
//            //Database.SetInitializer(new DropCreateDatabaseAlways<MaintiFlowContext>());
//            //Database.SetInitializer<MaintiFlowContext>(null);
//            //Database.CreateIfNotExists();
//        }

//        /////***** TaskOrders.Core *****/
//        //public DbSet<Department> Departments { get; set; }
//        //public DbSet<Title> Titles { get; set; }
//        //public DbSet<User> Employees { get; set; }
//        //public DbSet<WorkstationName> Workstations { get; set; }
//        //public DbSet<ModelWorkstation> Models { get; set; }

//        ///***** 需求單位 *****/
//        //public DbSet<RequestingUnitString> RequestingUnits { get; set; }

//        ///***** 維護單位 *****/
//        //public DbSet<IssueCategoryString> IssueCategories { get; set; }
//        //public DbSet<MaintenanceUnit> MaintenanceUnits { get; set; }

//        ///***** TaskOrders *****/
//        //public DbSet<TaskOrders> TaskOrders { get; set; }

//        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
//        //{
//        //    Database.SetInitializer(new MaintiFlowInitializer(modelBuilder, _coreContext));

//        //    var taskorder = modelBuilder.Entity<TaskOrders>();
//        //    taskorder.HasKey(t => t.WorkOrderNo);

//        //    /***** 需求單位 *****/
//        //    // 需求單位 一對多: TaskOrders.RequestingUnitString → RequestingUnitString.TaskOrderEngineers
//        //    taskorder.HasRequired(t => t.RequestingUnitString)
//        //             .WithMany(ru => ru.TaskOrders)
//        //             .HasForeignKey(t => t.RequestingUnitId)
//        //             .WillCascadeOnDelete(false);

//        //    // 回覆人員 一對多: TaskOrders.FeedbackEmployeeString → Core.User.RequestingTaskOrders
//        //    taskorder.HasOptional(t => t.FeedbackEmployeeString)
//        //           .WithMany(ru => ru.FeedbackEmployeeTaskOrders)
//        //           .HasForeignKey(t => t.FeedbackEmployeeId)
//        //           .WillCascadeOnDelete(false);

//        //    /***** 維護單位 *****/
//        //    // 維護類型 一對多: TaskOrderEngineers.IssueCategoryString → IssueCategoryString.TaskOrderEngineers
//        //    taskorder.HasOptional(t => t.IssueCategoryString)
//        //             .WithMany(ic => ic.TaskOrders)
//        //             .HasForeignKey(t => t.IssueCategoryId)
//        //             .WillCascadeOnDelete(false);

//        //    // 維護單位 一對多: TaskOrders.MaintenanceUnit → MaintenanceUnit.TaskOrders
//        //    taskorder.HasOptional(t => t.MaintenanceUnit)
//        //             .WithMany(mu => mu.TaskOrders)
//        //             .HasForeignKey(t => t.Key)
//        //             .WillCascadeOnDelete(false);

//        //    /***** TaskOrders.Core *****/
//        //    // 部門 一對多: User.Department → Department.Employees
//        //    modelBuilder.Entity<User>()
//        //        .HasRequired(t => t.Department)
//        //        .WithMany(e => e.Employees)
//        //        .HasForeignKey(t => t.Key)
//        //        .WillCascadeOnDelete(false);

//        //    // 職稱 一對多: User.Title → Title.Employees
//        //    modelBuilder.Entity<User>()
//        //        .HasOptional(t => t.Title)
//        //        .WithMany(e => e.Employees)
//        //        .HasForeignKey(t => t.Key)
//        //        .WillCascadeOnDelete(false);

//        //    // 建檔人員 一對多: TaskOrders.CreatorName → User.CreatedTaskOrders
//        //    taskorder.HasRequired(t => t.CreatorName)
//        //             .WithMany(e => e.CreaterTaskOrders)
//        //             .HasForeignKey(t => t.CreatorId)
//        //             .WillCascadeOnDelete(false);

//        //    // 維護工程師 多對多 TaskOrders.CreatorName ↔ User.CreatedTaskOrders
//        //    taskorder.HasMany(m => m.Engineer)
//        //             .WithMany(e => e.EngineerTaskOrders)
//        //             .Map(m =>
//        //             {
//        //                 m.ToTable("TaskOrderEngineers");
//        //                 m.MapLeftKey("EmployeeIds");
//        //                 m.MapRightKey("Id");
//        //             });

//        //    // 工站 一對多: TaskOrders.WorkstationName → WorkstationName.TaskOrders
//        //    taskorder
//        //        .HasRequired(t => t.WorkstationName)
//        //        .WithMany(w => w.TaskOrders)
//        //        .HasForeignKey(t => t.Key)
//        //        .WillCascadeOnDelete(false);

//        //    // 機種 一對多: WorkstationName.ModelWorkstation → ModelWorkstation.Workstations
//        //    modelBuilder.Entity<WorkstationName>()
//        //        .HasRequired(w => w.ModelWorkstation)
//        //        .WithMany(m => m.Workstations)
//        //        .HasForeignKey(w => w.Key)
//        //        .WillCascadeOnDelete(false);
//        //}
//    }
//}
