﻿using Calin.TaskPulse.Core.Messaging;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Events
{
    public class PermissionSettingPageMessage : MessageBase<PermissionSettingInfo>
    {
        public PermissionSettingPageMessage(PermissionSettingInfo info) : base(info) { }
    }
}
