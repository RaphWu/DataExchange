﻿namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 要求更新機種快取。
    /// </summary>
    public class RequestModelCacheUpdate
    {
        public static readonly RequestModelCacheUpdate Instance = new RequestModelCacheUpdate();
        private RequestModelCacheUpdate() { }
    }
}
