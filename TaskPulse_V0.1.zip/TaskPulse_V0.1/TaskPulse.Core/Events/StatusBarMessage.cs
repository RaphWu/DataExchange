﻿using Calin.TaskPulse.Core.Messaging;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 狀態列 Message 區顯示訊息。
    /// </summary>
    public class StatusBarMessage : MessageBase<string>
    {
        public StatusBarMessage(string info) : base(info) { }
    }
}
