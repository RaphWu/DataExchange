﻿using Calin.TaskPulse.Core.Messaging;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// ProcessBar 顯示的進度條百分比。
    /// </summary>
    public class ProcessBarMessage : MessageBase<ProcessBarInfo>
    {
        public ProcessBarMessage(ProcessBarInfo info) : base(info) { }
    }
}
