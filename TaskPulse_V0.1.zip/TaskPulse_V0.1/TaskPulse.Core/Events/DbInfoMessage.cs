﻿using Calin.TaskPulse.Core.Messaging;

namespace Calin.TaskPulse.Core.Events
{
    /// <summary>
    /// 狀態列 DB 資料區顯示訊息。
    /// </summary>
    public class DbInfoMessage : MessageBase<string>
    {
        public DbInfoMessage(string info) : base(info) { }
    }
}
