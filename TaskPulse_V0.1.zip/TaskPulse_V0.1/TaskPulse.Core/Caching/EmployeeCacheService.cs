﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contants;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Core.Helper;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Entity.Core;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.Caching
{
    // 輕量化、非 UI 的快取實作
    public class EmployeeCacheService : IEmployeeCacheService
    {
        private readonly CoreContext _context;
        private readonly ConcurrentDictionary<int, TabPageViewModel> _cache
            = new ConcurrentDictionary<int, TabPageViewModel>();

        public EmployeeCacheService(CoreContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        // 在啟動時建立整個快取（可做為 eager 或改為 lazy）
        public async Task InitializeAsync()
        { 
            SplashMessenger.Post("核心模組: 初始化內部訊息");
            PropertyText.Name.EmployeeId = nameof(EmployeeDto.EmployeeId);
            PropertyText.Name.EmployeeName = nameof(EmployeeDto.EmployeeName);
            PropertyText.Name.DepartmentId = nameof(EmployeeDto.DepartmentId);
            PropertyText.Name.Department = nameof(EmployeeDto.DepartmentName);
            PropertyText.Name.JobTitleId = nameof(EmployeeDto.JobTitleId);
            PropertyText.Name.JobTitle = nameof(EmployeeDto.JobTitleName);
            PropertyText.Name.Email = nameof(EmployeeDto.Email);
            PropertyText.Name.CarbonCopies = nameof(EmployeeDto.CarbonCopies);
            PropertyText.Name.CarbonCopyString = nameof(EmployeeDto.CarbonCopyString);
            PropertyText.Name.CarbonCopyList = nameof(EmployeeDto.CarbonCopyList);
            PropertyText.Name.IsEngineer = nameof(EmployeeDto.IsEngineer);
            PropertyText.Name.IsEngineerString = nameof(EmployeeDto.IsEngineerString);
            PropertyText.Name.EmployeeStatus = nameof(EmployeeDto.Status);
            PropertyText.Name.EmployeeStatusId = nameof(EmployeeDto.StatusId);
            PropertyText.Name.EmployeeStatusName = nameof(EmployeeDto.StatusName);
            PropertyText.Name.EmployeeStatusBoolean = nameof(EmployeeDto.StatusBoolean);
            PropertyText.Name.StatusChangeAt = nameof(EmployeeDto.StatusChangeAt);
            PropertyText.Name.StatusChangeAtString = nameof(EmployeeDto.StatusChangeAtString);

            PropertyText.Name.MachineCode = nameof(MachineDto.MachineCode);
            PropertyText.Name.MachineCategory = nameof(MachineCategoryEntity.CategoryName);
            PropertyText.Name.MachineType = nameof(MachineDto.MachineTypeName);
            PropertyText.Name.MachineModelNo = nameof(MachineDto.MachineModelNo);
            PropertyText.Name.ConditionName = nameof(MachineDto.ConditionName);
            PropertyText.Name.BrandName = nameof(MachineDto.BrandName);
            PropertyText.Name.LocationName = nameof(MachineDto.LocationName);
            PropertyText.Name.Assets = nameof(MachineDto.Assets);
            PropertyText.Name.SerialNumber = nameof(MachineDto.SerialNumber);
            PropertyText.Name.Barcode = nameof(MachineDto.Barcode);
            PropertyText.Name.Connected = nameof(MachineDto.Connected);
            PropertyText.Name.Disposal = nameof(MachineDto.Disposal);
            PropertyText.Name.Remark = nameof(MachineDto.Remark);
            PropertyText.Name.Workstations = nameof(MachineDto.Workstations);

            PropertyText.Title.Performer = "執行人員";
            PropertyText.Title.List = "列表";
            PropertyText.Title.CheckList = "清單";

            PropertyText.Title.Setup = EnumHelper.GetDescription<PageCode>(nameof(PageCode.Setup));
            PropertyText.Title.ToolQuest = EnumHelper.GetDescription<PageCode>(nameof(PageCode.ToolQuest));
            PropertyText.Title.MechaTrack = EnumHelper.GetDescription<PageCode>(nameof(PageCode.MechaTrack));
            PropertyText.Title.MaintiFlow = EnumHelper.GetDescription<PageCode>(nameof(PageCode.MaintiFlow));

            PropertyText.Title.Employee = "員工";
            PropertyText.Title.EmployeeId = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.EmployeeId);
            PropertyText.Title.EmployeeName = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.EmployeeName);
            PropertyText.Title.Department = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.Department);
            PropertyText.Title.JobTitle = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.JobTitle);
            PropertyText.Title.Email = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.Email);
            PropertyText.Title.CarbonCopies = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.CarbonCopies);
            PropertyText.Title.IsEngineer = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.IsEngineer);
            PropertyText.Title.EmployeeStatus = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.EmployeeStatus);
            PropertyText.Title.StatusChangeAt = EnumHelper.GetDescription<EmployeeDto>(PropertyText.Name.StatusChangeAt);

            PropertyText.Title.MachineCategory = EnumHelper.GetDescription<MachineCategoryEntity>(PropertyText.Name.MachineCategory);
            PropertyText.Title.MachineType = EnumHelper.GetDescription<MachineType>(PropertyText.Name.MachineType);
            PropertyText.Title.MachineModelNo = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.MachineModelNo);
            PropertyText.Title.MachineModel = EnumHelper.GetDescription<MachineModelNo>(PropertyText.Name.MachineModel);
            PropertyText.Title.Condition = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Condition);
            PropertyText.Title.Brand = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Brand);
            PropertyText.Title.Location = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Location);
            PropertyText.Title.Assets = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Assets);
            PropertyText.Title.SerialNumber = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.SerialNumber);
            PropertyText.Title.Barcode = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Barcode);
            PropertyText.Title.Connected = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Connected);
            PropertyText.Title.Disposal = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Disposal);
            PropertyText.Title.Remark = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Remark);
            PropertyText.Title.Workstations = EnumHelper.GetDescription<MachineDto>(PropertyText.Name.Workstations);

            SplashMessenger.Post("核心模組: 建立快取");
        }

        public Task EvictCacheForEntityAsync(int workOrderId)
        {
            _cache.TryRemove(workOrderId, out _);
            return Task.CompletedTask;
        }

        public async Task RebuildCacheForEntityAsync(int workOrderId)
        {
            var w = await _context.WorkOrders.FirstOrDefaultAsync(x => x.Id == workOrderId);
            if (w == null)
            {
                _cache.TryRemove(workOrderId, out _);
                return;
            }

            var vm = MapWorkOrderToViewModel(w);
            _cache[vm.Id] = vm;
        }

        public IReadOnlyCollection<TabPageViewModel> GetCachedPages()
        {
            return _cache.Values.ToList().AsReadOnly();
        }

        private TabPageViewModel MapWorkOrderToViewModel(WorkOrderEntity w)
        {
            return new TabPageViewModel
            {
                Id = w.Id,
                Title = $"{w.WorkOrderNo} - {w.IssueCategory?.CategoryName ?? ""}",
                Summary = $"{w.Creator?.EmployeeName ?? ""} • {w.CreationDateTime:g}",
                LastUpdated = w.FillingTime ?? (DateTime?)w.CreationDateTime
            };
        }
    }
}
