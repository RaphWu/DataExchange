﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Caching
{
    public interface IEmployeeCacheService
    {
        Task InitializeAsync(); // 在啟動時建立快取
        Task RebuildCacheForEntityAsync(int workOrderId);
        Task EvictCacheForEntityAsync(int workOrderId);
        //IReadOnlyCollection<TabPageViewModel> GetCachedPages();


        IReadOnlyDictionary<string, List<CategoryInfo>> GetClassifyEmployee();
        Task RebuildEmployeesAsync(); // 全部重建
        Task RebuildEmployeeAsync(int employeeId); // 單一失效/重建




        Task RebuildAllAsync();
        Task RebuildForEntityAsync(int entityId);
        // 保留既有 API（CreateEmployeeTabPage 等）以便漸進遷移
        Task CreateEmployeeTabPage();
        Task CreateEngineerTabPage();
        Task CreateMachineTabPage();
        Task CreateModelTabPage();
        Task CreateModelWsTabPage();
    }
}