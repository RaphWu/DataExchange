﻿using System;
using System.Configuration;
using System.Linq;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Helper;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.ViewModels;
using Sunny.UI;

namespace Calin.TaskPulse.Core.SharedUI
{
    /// <summary>
    /// 提供使用者登入功能的控制項，支援管理員及員工登入驗證。
    /// </summary>
    public partial class LoginControl : UserControl
    {
        private readonly ILifetimeScope _scope;
        private readonly ILogService _log;
        private readonly ICurrentUserService _currentUser;

        /// <summary>
        /// 初始化 <see cref="LoginControl"/> 類別的新執行個體。
        /// </summary>
        /// <param name="lifetimeScope">Autofac 生命週期範圍，用於服務解析。</param>
        /// <param name="logService">日誌服務，用於記錄登入事件。</param>
        /// <param name="currentUserService">目前使用者服務，用於管理使用者狀態。</param>
        /// <param name="coreData">核心資料，包含員工資訊。</param>
        public LoginControl(ILifetimeScope lifetimeScope,
                            ILogService logService,
                            ICurrentUserService currentUserService,
                            CoreData coreData)
        {
            InitializeComponent();
            _scope = lifetimeScope;
            _log = logService;
            _currentUser = currentUserService;

            var _nameList = coreData.Employees.Select(e => new ListViewModel()
            {
                IdString = e.EmployeeId,
                Name = e.FullName
            }).ToList();
            uiComboBox_UserName.DataSource = _nameList;
            uiComboBox_UserName.DisplayMember = "Name";
            uiComboBox_UserName.ValueMember = "IdString";

            CommonStyles.SetButton(Button_Login);
            CommonStyles.SetButton(Button_Cancel, isCancel: true);
        }

        /// <summary>
        /// 處理登入按鈕點擊事件，執行使用者驗證流程。
        /// </summary>
        /// <param name="sender">事件來源。</param>
        /// <param name="e">事件參數。</param>
        /// <remarks>
        /// 驗證流程包括：
        /// 1. 管理員帳號驗證（使用設定檔中的加密密碼）
        /// 2. 員工帳號驗證（透過 Active Directory LDAP 驗證）
        /// 驗證失敗時會將使用者切換為訪客模式。
        /// </remarks>
        private async void Button_Login_Click(object sender, EventArgs e)
        {
            var adminUser = ConfigurationManager.AppSettings["AdminUser"];
            var appEncryptedPassword = ConfigurationManager.AppSettings["AdminPassword"];
            var appPassword = AESHelper.Decrypt(appEncryptedPassword);
            var password = uiTextBox_Password.Text.Trim();
            var employeeId = uiComboBox_UserName.SelectedValue != null
                ? uiComboBox_UserName.SelectedValue.ToString()
                : uiComboBox_UserName.Text.Trim();

            if (!string.IsNullOrEmpty(employeeId))
            {
                if (employeeId.ToLower() == adminUser.ToLower())
                {
                    if (password == appPassword)
                    {
                        _currentUser.AdminLogin();
                        await _log.LoginAsync("", "管理員登入", $"登入時間: {DateTime.Now}");
                        return;
                    }
                    else
                    {
                        await _log.LoginAsync("", "管理員登入錯誤", $"嘗試時間: {DateTime.Now}");
                    }
                }
                else
                {
                    var auth = _scope.Resolve<IAuthService>();
                    if (await auth.ActiveDirectoryAsync(employeeId, password))
                    {
                        _currentUser.SwitchCurrentUser(employeeId);
                        Console.WriteLine("LDAP驗證成功");
                        await _log.LoginAsync(employeeId, "登入成功", "");
                        return;
                    }
                    else
                    {
                        Console.WriteLine("使用者不存在於系統中");
                        await _log.LoginAsync(employeeId, "登入失敗", "使用者不存在於系統中");
                    }
                }
            }
            else
            {
                Console.WriteLine("User輸入空白。");
                await _log.LoginAsync(employeeId, "登入失敗", "User輸入空白");
            }
            _currentUser.SwitchCurrentUserToGuest();
        }

        /// <summary>
        /// 處理取消按鈕點擊事件。
        /// </summary>
        /// <param name="sender">事件來源。</param>
        /// <param name="e">事件參數。</param>
        private void Button_Cancel_Click(object sender, EventArgs e)
        {
            //DialogResult = DialogResult.Cancel;
            //this.Close();
        }

        /// <summary>
        /// 處理密碼文字方塊按鈕點擊事件，清除密碼輸入欄位。
        /// </summary>
        /// <param name="sender">事件來源。</param>
        /// <param name="e">事件參數。</param>
        private void uiTextBox_Password_ButtonClick(object sender, EventArgs e)
        {
            uiTextBox_Password.Text = "";
        }
    }
}
