﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.SharedUI
{
    /// <summary>
    /// 提供修正索引變更行為的 TabControl 控制項。
    /// 此控制項可防止自動滾動並支援隱藏標籤頁標題列。
    /// </summary>
    public class FixIndexTabControl : TabControl
    {
        /// <summary>
        /// TabControl 設定當前選取索引的訊息常數。
        /// </summary>
        private const int TCM_SETCURSEL = 0x130C;

        /// <summary>
        /// 用於抑制索引變更處理的旗標，防止遞迴呼叫。
        /// </summary>
        private bool _suppressIndexChange = false;

        /// <summary>
        /// 取得或設定是否隱藏標籤頁標題列。
        /// </summary>
        /// <value>
        /// 如果要隱藏標題列則為 <c>true</c>；否則為 <c>false</c>。預設值為 <c>true</c>。
        /// </value>
        public bool HideTabHeaders { get; set; } = true;

        /// <summary>
        /// 傳送訊息至指定的視窗。
        /// </summary>
        /// <param name="hWnd">視窗控制代碼。</param>
        /// <param name="msg">要傳送的訊息。</param>
        /// <param name="wParam">訊息的第一個參數。</param>
        /// <param name="lParam">訊息的第二個參數。</param>
        /// <returns>訊息處理的結果。</returns>
        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);

        /// <summary>
        /// 處理 Windows 訊息。
        /// 覆寫此方法以防止 TabControl 自動滾動並支援隱藏標籤頁標題列。
        /// </summary>
        /// <param name="m">要處理的 Windows 訊息。</param>
        protected override void WndProc(ref Message m)
        {
            // 防止 TabControl 自動滾動
            if (m.Msg == TCM_SETCURSEL)
            {
                if (_suppressIndexChange)
                {
                    base.WndProc(ref m);
                    return;
                }

                int oldIndex = this.SelectedIndex;
                base.WndProc(ref m);

                if (this.SelectedIndex != oldIndex)
                {
                    _suppressIndexChange = true;
                    try
                    {
                        SendMessage(this.Handle, TCM_SETCURSEL, oldIndex, 0);
                        this.SelectedIndex = oldIndex;
                    }
                    finally
                    {
                        _suppressIndexChange = false;
                    }
                }
                return;
            }

            // 隱藏標籤列
            if (HideTabHeaders && m.Msg == 0x1328 && !DesignMode)
            {
                m.Result = (IntPtr)1;
                return;
            }

            base.WndProc(ref m);
        }
    }
}