﻿using System.Drawing;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.SharedUI
{
    /// <summary>
    /// 提供 Form 的擴充方法和相關輔助類別。
    /// </summary>
    public static class MyFormEx
    {
        /// <summary>
        /// 在顯示對話框時加上遮罩層效果的擴充方法。
        /// 在非 DEBUG 模式下會顯示半透明黑色遮罩層。
        /// </summary>
        /// <param name="form">要顯示的表單。</param>
        /// <returns>對話框的結果。</returns>
        public static DialogResult ShowDialogWithMask(this Form form)
        {
#if !DEBUG
            Point pt = Sunny.UI.SystemEx.GetCursorPos();
            Rectangle screen = Screen.GetBounds(pt);
            using (MaskLayer mask = new MaskLayer())
            {
                mask.Bounds = screen;
                mask.Show();

#endif
            form.ShowInTaskbar = false;
            form.TopMost = true;
            return form.ShowDialog();
#if !DEBUG
            }
#endif
        }

        /// <summary>
        /// 遮罩層表單，用於在顯示對話框時提供半透明背景遮罩效果。
        /// 點擊遮罩或按下 Escape 鍵可關閉遮罩層。
        /// </summary>
        public class MaskLayer : Form
        {
            /// <summary>
            /// 初始化 <see cref="MaskLayer"/> 類別的新執行個體。
            /// 建立一個全螢幕、半透明黑色背景的無邊框表單。
            /// </summary>
            public MaskLayer()
            {
                this.SuspendLayout();
                this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
                this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
                base.BackColor = Color.Black;
                this.ClientSize = new System.Drawing.Size(800, 450);
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                this.Name = "MaskLayer";
                this.Opacity = 0.5D;
                this.ShowInTaskbar = false;
                this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
                this.Text = "MaskLayer";
                this.TopMost = true;
                this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.MaskLayer_MouseClick);
                this.ResumeLayout(false);
            }

            /// <summary>
            /// 處理命令鍵輸入。
            /// 當按下 Escape 鍵時關閉遮罩層。
            /// </summary>
            /// <param name="msg">視窗訊息。</param>
            /// <param name="keyData">按鍵資料。</param>
            /// <returns>如果按鍵已被處理則為 true，否則為 false。</returns>
            protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
            {
                int num = 256;
                int num2 = 260;
                if (msg.Msg == num | msg.Msg == num2)
                {
                    if (keyData == Keys.Escape)
                    {
                        Close();
                    }
                }

                return base.ProcessCmdKey(ref msg, keyData);
            }

            /// <summary>
            /// 處理滑鼠點擊事件。
            /// 當點擊遮罩層時關閉表單。
            /// </summary>
            /// <param name="sender">事件來源。</param>
            /// <param name="e">滑鼠事件引數。</param>
            private void MaskLayer_MouseClick(object sender, MouseEventArgs e)
            {
                Close();
            }

            //private System.ComponentModel.IContainer components = null;

            //protected override void Dispose(bool disposing)
            //{
            //    if (disposing && (components != null))
            //    {
            //        components.Dispose();
            //    }

            //    base.Dispose(disposing);
            //}
        }
    }
}
