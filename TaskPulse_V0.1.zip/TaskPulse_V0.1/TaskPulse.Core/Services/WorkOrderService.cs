using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Core.Mappers;
using Calin.TaskPulse.Core.Repositories;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// ���@�u��~���޿�A�ȹ�@�C
    /// </summary>
    public class WorkOrderService : IWorkOrderService
    {
        private readonly IWorkOrderRepository _repository;
        private readonly IWorkOrderMapper _mapper;

        public WorkOrderService(
            IWorkOrderRepository repository,
            IWorkOrderMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        /// <inheritdoc/>
        public async Task<WorkOrderDto> GetWorkOrderDtoAsync(int workOrderId)
        {
            var entity = await _repository.GetByIdWithRelationsAsync(workOrderId);
            return entity != null ? _mapper.ToDto(entity) : null;
        }

        /// <inheritdoc/>
        public async Task<WorkOrderDto> GetWorkOrderByNoAsync(string workOrderNo)
        {
            var entity = await _repository.GetByWorkOrderNoAsync(workOrderNo);
            return entity != null ? _mapper.ToDto(entity) : null;
        }

        /// <inheritdoc/>
        public async Task<List<WorkOrderDto>> GetAllWorkOrderDtosAsync()
        {
            var entities = await _repository.GetAllAsync();
            return entities.Select(e => _mapper.ToDto(e)).ToList();
        }

        /// <inheritdoc/>
        public async Task<List<WorkOrderDto>> SearchWorkOrdersByNoAsync(string workOrderNo)
        {
            var entities = await _repository.SearchByWorkOrderNoAsync(workOrderNo);
            return entities.Select(e => _mapper.ToDto(e)).ToList();
        }

        /// <inheritdoc/>
        public async Task<WorkOrderDto> AddWorkOrderAsync(WorkOrderDto dto)
        {
            var entity = _mapper.ToEntity(dto);
            var addedEntity = await _repository.AddAsync(entity);

            // �p�G���u�{�v���Y�A�P�B����
            if (dto.EngineerIds != null && dto.EngineerIds.Any())
            {
                await _repository.SyncEngineersAsync(addedEntity, dto.EngineerIds);
            }

            await _repository.SaveChangesAsync();

            return _mapper.ToDto(addedEntity);
        }

        /// <inheritdoc/>
        public async Task UpdateWorkOrderAsync(WorkOrderDto dto)
        {
            var entity = await _repository.GetByIdAsync(dto.Id);
            if (entity == null) return;

            // ��s���ݩ�
            _mapper.UpdateEntity(entity, dto);

            // �P�B�u�{�v���Y
            if (dto.EngineerIds != null)
            {
                await _repository.SyncEngineersAsync(entity, dto.EngineerIds);
            }

            await _repository.SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task DeleteWorkOrderAsync(int workOrderId)
        {
            await _repository.DeleteAsync(workOrderId);
        }

        /// <inheritdoc/>
        public async Task<bool> WorkOrderExistsAsync(int workOrderId)
        {
            return await _repository.ExistsAsync(workOrderId);
        }

        /// <inheritdoc/>
        public async Task<bool> WorkOrderNoExistsAsync(string workOrderNo)
        {
            return await _repository.WorkOrderNoExistsAsync(workOrderNo);
        }
    }
}
