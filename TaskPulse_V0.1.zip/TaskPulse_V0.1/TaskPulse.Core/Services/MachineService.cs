using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Core.Mappers;
using Calin.TaskPulse.Core.Repositories;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// ���x�~���޿�A�ȹ�@�C
    /// </summary>
    public class MachineService : IMachineService
    {
        private readonly IMachineRepository _repository;
        private readonly IMachineMapper _mapper;

        public MachineService(
            IMachineRepository repository,
            IMachineMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        /// <inheritdoc/>
        public async Task<MachineDto> GetMachineDtoAsync(int machineId)
        {
            var entity = await _repository.GetByIdWithRelationsAsync(machineId);
            return entity != null ? _mapper.ToDto(entity) : null;
        }

        /// <inheritdoc/>
        public async Task<MachineDto> GetMachineByCodeAsync(string machineCode)
        {
            var entity = await _repository.GetByMachineCodeAsync(machineCode);
            return entity != null ? _mapper.ToDto(entity) : null;
        }

        /// <inheritdoc/>
        public async Task<List<MachineDto>> GetAllMachineDtosAsync()
        {
            var entities = await _repository.GetAllAsync();
            return entities.Select(e => _mapper.ToDto(e)).ToList();
        }

        /// <inheritdoc/>
        public async Task<List<MachineDto>> SearchMachinesByCodeAsync(string code)
        {
            var entities = await _repository.SearchByCodeAsync(code);
            return entities.Select(e => _mapper.ToDto(e)).ToList();
        }

        /// <inheritdoc/>
        public async Task<MachineDto> AddMachineAsync(MachineDto dto)
        {
            var entity = _mapper.ToEntity(dto);
            var addedEntity = await _repository.AddAsync(entity);

            // �p�G���u�����Y�A�P�B����
            if (dto.WorkstationIds != null && dto.WorkstationIds.Any())
            {
                await _repository.SyncWorkstationsAsync(addedEntity, dto.WorkstationIds);
            }

            await _repository.SaveChangesAsync();

            return _mapper.ToDto(addedEntity);
        }

        /// <inheritdoc/>
        public async Task UpdateMachineAsync(MachineDto dto)
        {
            var entity = await _repository.GetByIdAsync(dto.Id);
            if (entity == null) return;

            // ��s���ݩ�
            _mapper.UpdateEntity(entity, dto);

            // �P�B�u�����Y
            if (dto.WorkstationIds != null)
            {
                await _repository.SyncWorkstationsAsync(entity, dto.WorkstationIds);
            }

            await _repository.SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task DeleteMachineAsync(int machineId)
        {
            await _repository.DeleteAsync(machineId);
        }

        /// <inheritdoc/>
        public async Task<bool> MachineExistsAsync(int machineId)
        {
            return await _repository.ExistsAsync(machineId);
        }

        /// <inheritdoc/>
        public async Task<bool> MachineCodeExistsAsync(string machineCode)
        {
            return await _repository.MachineCodeExistsAsync(machineCode);
        }
    }
}
