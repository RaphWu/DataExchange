﻿namespace Calin.TaskPulse.Core.Services.DB
{
    public class TaskOrderEntityService  
    {
    }
}
