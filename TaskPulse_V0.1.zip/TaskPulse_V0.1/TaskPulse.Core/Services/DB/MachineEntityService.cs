﻿using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Services.DB
{
    public class MachineEntityService
    {
    }
}
