﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;
using MailKit.Net.Smtp;
using MimeKit;

namespace Calin.TaskPulse.Core.Services
{
    /*
     * https://mimekit.net/
     */

    public class MailService : IMail
    {
        private readonly CoreData _coreData;
        private HashSet<Mail> _mailList;
        private HashSet<Mail> _ccList;

        public MailService(CoreData coreData)
        {
            _coreData = coreData;
        }

        /// <inheritdoc/>
        public void SendMail(string senderTitle, ICollection<int> recipient, string subject, string contents)
        {
            HashSet<string> nameList = new HashSet<string>();
            _mailList = new HashSet<Mail>();
            _ccList = new HashSet<Mail>();
            foreach (var empId in recipient)
            {
                var emp = _coreData.Employees.FirstOrDefault(e => e.Id == empId);
                if (emp != null)
                {
                    _mailList.Add(new Mail()
                    {
                        Name = emp.EmployeeName,
                        Email = emp.Email,
                    });

                    foreach (var cc in emp.CarbonCopies)
                    {
                        if (!recipient.Contains(cc.Id))
                            _ccList.Add(new Mail()
                            {
                                Name = cc.EmployeeName,
                                Email = cc.Email,
                            });
                    }
                }
            }

            if (_mailList.Count == 0)
                return;

            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(senderTitle, "sys.automate@calin.com.tw"));

            foreach (var mail in _mailList)
                message.To.Add(new MailboxAddress(mail.Name, mail.Email));

            foreach (var cc in _ccList)
                message.Cc.Add(new MailboxAddress(cc.Name, cc.Email));

            message.Subject = subject;

            contents = Regex.Replace(contents,
                @"<table[^>]*>",
                "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse:collapse; border:1px solid #8c8c8c;'>",
                RegexOptions.IgnoreCase);
            contents = Regex.Replace(contents,
                @"<caption[^>]*>",
                "<caption style='font-weight:bold;margin-bottom:10px;'>",
                RegexOptions.IgnoreCase);
            contents = Regex.Replace(contents,
                @"<td[^>]*>",
                "<td style='border:1px solid #8c8c8c;'>",
                RegexOptions.IgnoreCase);

            string footer = $"<span style='color:#ba372a;'><em><strong>此信件由{senderTitle}自動發送，請勿回覆此信件！</strong></em></span>";

            var builder = new BodyBuilder();
            builder.HtmlBody = $"<p>{contents}</p><p>{footer}</p>";
            message.Body = builder.ToMessageBody();

            _ = Task.Run(async () =>
            {
                try
                {
                    using (var client = new SmtpClient())
                    {
                        await client.ConnectAsync("calin-mails0.calin.com.tw", 25, false);
                        //await client.AuthenticateAsync("sys.automate@calin.com.tw", "#Calin@70848492");
                        await client.SendAsync(message);
                        await client.DisconnectAsync(true);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            });


            //try
            //{
            //    //tsslMsg.Text = "";
            //    System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
            //    message.From = new System.Net.Mail.MailAddress("sys.automate@calin.com.tw");

            //    //讀取收件者
            //    foreach (var emp in _mailList[workName])
            //        message.To.Add(new System.Net.Mail.MailAddress(emp.Email, emp.Name));

            //    message.Subject = subject;
            //    message.IsBodyHtml = true;
            //    contents = Regex.Replace(contents,
            //        @"<table[^>]*>",
            //        "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse:collapse; border:1px solid #8c8c8c;'>",
            //        RegexOptions.IgnoreCase);
            //    contents = Regex.Replace(contents,
            //        @"<caption[^>]*>",
            //        "<caption style='font-weight:bold;margin-bottom:10px;'>",
            //        RegexOptions.IgnoreCase);
            //    contents = Regex.Replace(contents,
            //        @"<td[^>]*>",
            //        "<td style='border:1px solid #8c8c8c;'>",
            //        RegexOptions.IgnoreCase);

            //    message.Body = contents;

            //    //////////////設定郵箱smtp伺服器 埠//////////////
            //    System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
            //    smtp.Port = 25;
            //    smtp.Host = "calin-mails0.calin.com.tw";
            //    //   smtp.EnableSsl = true; //SSL安全連線
            //    smtp.UseDefaultCredentials = false;
            //    smtp.Credentials = new System.Net.NetworkCredential("sys.automate@calin.com.tw", "#Calin@70848492"); //自動寄信公用帳號

            //    //設定郵件傳送格式
            //    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            //    smtp.Send(message);
            //    smtp.Dispose();
            //    message.Dispose();
            //}
            //catch
            //{
            //    //tsslMsg.Text = "EMAIL位址錯誤: " + ex.Message;
            //}
            //finally
            //{

            //}
        }
    }
}
