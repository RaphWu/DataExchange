using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Core.Mappers;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.Repositories;

namespace Calin.TaskPulse.Core.Services
{
    /// <summary>
    /// ���u�~���޿�A�ȹ�@�C
    /// </summary>
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _repository;
        private readonly IEmployeeMapper _mapper;

        public EmployeeService(
            IEmployeeRepository repository,
            IEmployeeMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        /********************
         * 
         ********************/
        /// <inheritdoc/>
        public async Task<EmployeeDto> GetEmployeeDtoAsync(int employeeId)
        {
            var entity = await _repository.GetByIdWithRelationsAsync(employeeId);
            return entity != null ? _mapper.ToDto(entity) : null;
        }

        /// <inheritdoc/>
        public async Task<EmployeeDto> GetEmployeeByEmployeeIdAsync(string employeeId)
        {
            var entity = await _repository.GetByEmployeeIdAsync(employeeId);
            return entity != null ? _mapper.ToDto(entity) : null;
        }

        /// <inheritdoc/>
        public async Task<List<EmployeeDto>> GetAllEmployeeDtosAsync()
        {
            var entities = await _repository.GetAllAsync();
            return entities.Select(e => _mapper.ToDto(e)).ToList();
        }

        /// <inheritdoc/>
        public async Task<List<EmployeeDto>> SearchEmployeesByNameAsync(string name)
        {
            var entities = await _repository.SearchByNameAsync(name);
            return entities.Select(e => _mapper.ToDto(e)).ToList();
        }

        /// <inheritdoc/>
        public async Task<EmployeeDto> AddEmployeeAsync(EmployeeDto dto)
        {
            var entity = _mapper.ToEntity(dto);
            var addedEntity = await _repository.AddAsync(entity);

            // �p�G���h��h���Y�A�P�B����
            if (dto.PermissionIds != null && dto.PermissionIds.Any())
            {
                await _repository.SyncPermissionsAsync(addedEntity, dto.PermissionIds);
            }
            if (dto.UserGroupIds != null && dto.UserGroupIds.Any())
            {
                await _repository.SyncUserGroupsAsync(addedEntity, dto.UserGroupIds);
            }
            if (dto.CarbonCopyIds != null && dto.CarbonCopyIds.Any())
            {
                await _repository.SyncCarbonCopiesAsync(addedEntity, dto.CarbonCopyIds);
            }

            await _repository.SaveChangesAsync();

            return _mapper.ToDto(addedEntity);
        }

        /// <inheritdoc/>
        public async Task UpdateEmployeeAsync(EmployeeDto dto)
        {
            var entity = await _repository.GetByIdAsync(dto.Id);
            if (entity == null) return;

            // ��s���ݩ�
            _mapper.UpdateEntity(entity, dto);

            // �P�B�h��h���Y
            if (dto.PermissionIds != null)
            {
                await _repository.SyncPermissionsAsync(entity, dto.PermissionIds);
            }
            if (dto.UserGroupIds != null)
            {
                await _repository.SyncUserGroupsAsync(entity, dto.UserGroupIds);
            }
            if (dto.CarbonCopyIds != null)
            {
                await _repository.SyncCarbonCopiesAsync(entity, dto.CarbonCopyIds);
            }

            await _repository.SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task DeleteEmployeeAsync(int employeeId)
        {
            await _repository.DeleteAsync(employeeId);
        }

        /// <inheritdoc/>
        public async Task<bool> EmployeeExistsAsync(int employeeId)
        {
            return await _repository.ExistsAsync(employeeId);
        }

        /// <inheritdoc/>
        public async Task<bool> EmployeeIdExistsAsync(string employeeId)
        {
            return await _repository.EmployeeIdExistsAsync(employeeId);
        }

        /********************
         * Caching
         ********************/
        /// <summary>
        /// ���u�W�U�A�w�ư���¾�C
        /// </summary>
        public List<EmployeeDto> Employees { get; set; }

        /// <summary>
        /// �̳���-�m�W�����P�ƧǪ����u�C���C<br/>�榡: Dictionary<����, List<(¾��, �u��, �m�W)>>
        /// </summary>
        public Dictionary<string, List<CategoryInfo>> ClassifyEmployee { get; set; }

        /// <summary>
        /// ���@�u�{�v�W�U�C
        /// </summary>
        public List<EmployeeDto> Engineers { get; set; }




    }
}
