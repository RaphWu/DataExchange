using System;
using System.Collections.Generic;
using Calin.TaskPulse.Entity.Contants;

namespace Calin.TaskPulse.Core.DTO
{
    /// <summary>
    /// ���@�u���ƶǿ骫��C
    /// </summary>
    public class WorkOrderDto
    {
        public int Id { get; set; }
        public string WorkOrderNo { get; set; }
        public FlowStatus Status { get; set; }

        // ���x��T
        public int? MachineId { get; set; }
        public string MachineCode { get; set; }

        // �u����T
        public int? WorkstationId { get; set; }
        public string WorkstationName { get; set; }

        // ���ɤH��
        public int CreatorId { get; set; }
        public string CreatorName { get; set; }
        public DateTime CreationDateTime { get; set; }

        // ���@���
        public int? MaintenanceUnitId { get; set; }
        public string MaintenanceUnitName { get; set; }

        // ���@�u�{�v
        public List<int> EngineerIds { get; set; }
        public List<string> EngineerNames { get; set; }
        public DateTime AcceptedTime { get; set; }

        // ���@���e
        public int? IssueCategoryId { get; set; }
        public string IssueCategoryName { get; set; }
        public string IssueDescription { get; set; }
        public string Details { get; set; }
        public DateTime? RepairStarted { get; set; }
        public DateTime? RepairCompleted { get; set; }
        public long RepairDurationTick { get; set; }
        public DateTime? FillingTime { get; set; }

        // �ݨD����T
        public int? RequestingUnitId { get; set; }
        public string RequestingUnitName { get; set; }
        public int? FeedbackEmployeeId { get; set; }
        public string FeedbackEmployeeName { get; set; }
        public string Feedback { get; set; }
        public DateTime? OutageStarted { get; set; }
        public DateTime? OutageEnded { get; set; }
        public long OutageDurationTick { get; set; }

        // ��L
        public string Responsible { get; set; }
    }
}
