﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.DTO
{
    public class MachineCategoryDto
    {
        public int Id { get; set; }

        public string CategoryName { get; set; }
    }
}
