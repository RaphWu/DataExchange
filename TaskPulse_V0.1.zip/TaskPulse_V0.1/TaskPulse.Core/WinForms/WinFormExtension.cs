﻿using System;
using System.Windows.Forms;

namespace Calin.TaskPulse.Core.WinForms
{
    /// <summary>
    /// WinForm 擴充功能集合，提供在 UI 執行緒上執行委派與 Control 集合清理等常用輔助方法。
    /// </summary>
    /// <remarks>
    /// 此類別僅包含靜態助手方法，方便在非 UI 執行緒中要求在主執行緒執行動作，或統一清除控制項集合。
    /// 方法設計不會建立隱含的 UI 元件；在沒有開啟窗體（例如單元測試情境）下，相關方法會採取安全的替代行為。
    /// </remarks>
    public static class WinFormExtension
    {
        /// <summary>
        /// 在必要時於控制項所屬的 UI 執行緒上同步執行指定的委派。
        /// </summary>
        /// <param name="control">欲作為呼叫錨點的 <see cref="Control"/>。此參數用以判斷是否需跨執行緒呼叫；傳入時應為非 null。</param>
        /// <param name="action">要在 UI 執行緒（或當前執行緒）執行的 <see cref="MethodInvoker"/> 委派。此參數應為非 null。</param>
        /// <remarks>
        /// 行為說明：
        /// - 若 <paramref name="control"/> 的 <see cref="Control.InvokeRequired"/> 為 true，代表目前呼叫執行緒與控制項的建立執行緒不同，
        ///   方法會以 <see cref="Control.Invoke(Delegate)"/> 在控制項的 UI 執行緒上同步執行 <paramref name="action"/>，呼叫會等到 <paramref name="action"/> 完成後才回傳。<br/>
        /// - 若 <paramref name="control"/> 的 <see cref="Control.InvokeRequired"/> 為 false，則直接在目前執行緒上同步執行 <paramref name="action"/>。<br/>
        /// - 本方法不對 <paramref name="control"/> 或 <paramref name="action"/> 執行 null 檢查；若傳入 null，呼叫時會產生例外（例如 <see cref="NullReferenceException"/> 等）。<br/>
        /// - 本方法不會捕捉或封裝 <paramref name="action"/> 所拋出的例外；若需非同步執行或避免阻塞/死結，請改用 <see cref="Control.BeginInvoke(Delegate)"/> 或由呼叫端實作適當的同步/錯誤處理機制。<br/>
        /// </remarks>
        /// <example>
        /// 範例：在背景執行緒中更新 Label 文字
        /// <code>
        /// Task.Run(() =&gt;
        /// {
        ///     myLabel.InvokeIfRequired(() =&gt; myLabel.Text = "更新 UI");
        /// });
        /// </code>
        /// </example>
        public static void InvokeIfRequired(this Control control, MethodInvoker action)
        {
            if (control.InvokeRequired)
                control.Invoke(action);
            else
                action();
        }

        /// <summary>
        /// 在 UI 執行緒上執行指定的 <paramref name="action"/>。
        /// </summary>
        /// <param name="action">要在 UI 執行緒上執行的動作。此參數應為非 null（若為 null，呼叫時將發生例外）。</param>
        /// <remarks>
        /// 執行流程：<br/>
        /// - 若目前沒有任何開啟的窗體（<see cref="Application.OpenForms"/> 為空），則直接在呼叫執行緒同步執行 <paramref name="action"/>。
        ///   這種情況常出現在單元測試或無 UI 的背景服務情境中。<br/>
        /// - 否則，使用第一個開啟的窗體 <c>Application.OpenForms[0]</c> 作為跨執行緒呼叫的錨點：<br/>
        ///   - 若該窗體需要透過其控制項執行呼叫（<c>InvokeRequired</c> 為 true），則以非同步方式呼叫 <c>BeginInvoke</c>，
        ///     將動作排入 UI 訊息佇列並立即回傳（不等待動作完成）。<br/>
        ///   - 否則在同一執行緒上直接同步執行 <paramref name="action"/>。<br/>
        /// 注意事項：<br/>
        /// - 本方法使用 <c>BeginInvoke</c>（非同步）來避免可能的死結；若呼叫端需要等待動作完成，請改用控制項的 <c>Invoke</c>。<br/>
        /// - 此方法不會自行檢查 <paramref name="action"/> 是否為 null，也不會包裝例外；呼叫端應負責例外處理。<br/>
        /// </remarks>
        /// <example>
        /// 範例：
        /// <code>
        /// WinFormExtension.RunOnUIThread(() =&gt;
        /// {
        ///     myLabel.Text = "更新 UI";
        /// });
        /// </code>
        /// </example>
        public static void RunOnUIThread(Action action)
        {
            if (Application.OpenForms.Count == 0)
            {
                action(); // 若沒有開啟的窗體（例如測試模式），直接執行
                return;
            }

            var form = Application.OpenForms[0];
            if (form.InvokeRequired)
                form.BeginInvoke(action);
            else
                action();
        }

        /// <summary>
        /// 清理並釋放指定控制項集合中的所有控制項，然後清空集合並嘗試強制進行垃圾回收。
        /// </summary>
        /// <param name="controls">要清理的 <see cref="Control.ControlCollection"/>。若集合為空則不做任何事。</param>
        /// <remarks>
        /// 行為描述：<br/>
        /// - 逐一呼叫集合中每個 <see cref="Control"/> 的 <see cref="IDisposable.Dispose"/>，以釋放其所持有之非託管資源與事件連線。<br/>
        /// - 在處理完成後呼叫 <c>controls.Clear()</c> 以移除集合內的引用。<br/>
        /// - 隨後呼叫 <c>GC.Collect()</c> 與 <c>GC.WaitForPendingFinalizers()</c> 嘗試促使終結器執行，協助釋放資源。<br/>
        /// 注意事項：<br/>
        /// - 呼叫此方法後，任何仍保有對已處置控制項參考的程式碼都可能發生物件已處置的情況；呼叫端應確保不再使用這些控制項。<br/>
        /// - 此方法不進行 null 檢查，傳入 null 將在執行時發生例外；呼叫端請確保傳入有效集合。<br/>
        /// - 強制 GC 會影響效能，僅在確實需要立即回收資源時使用此方法。
        /// </remarks>
        /// <example>
        /// 範例：
        /// <code>
        /// WinFormExtension.CleanUpControls(panel.Controls);
        /// </code>
        /// </example>
        public static void CleanUpControls(Control.ControlCollection controls)
        {
            if (controls.Count == 0)
                return;

            foreach (Control c in controls)
                c.Dispose();
            controls.Clear();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }
}
