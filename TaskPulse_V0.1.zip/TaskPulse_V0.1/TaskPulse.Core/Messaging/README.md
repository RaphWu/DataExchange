﻿```text
TaskPulse.Core/
├── Messaging/
│   ├── Messenger.cs            (核心 Messenger)
│   ├── MessageBase.cs          (訊息基底類別)
│   └── MessengerExtensions.cs  (擴充方法)
└── Events/
    ├── StatusBarMessage.cs
    ├── DbInfoMessage.cs
    └── ProcessBarMessage.cs   
```

---

## 📋 API 對照表

| CommunityToolkit.Mvvm | 自訂 Messaging |
|----------------------|----------------|
| `Messenger.Default` | `Messenger.Default` |
| `ValueChangedMessage<T>` | `MessageBase<T>` |
| `Register<TMessage>(recipient, handler)` | `Register<TMessage>(recipient, handler)` |
| `Send(message)` | `Send(message)` |
| `UnregisterAll(recipient)` | `UnregisterAll(recipient)` |
| `Unregister<TMessage>(recipient)` | `Unregister<TMessage>(recipient)` |

---

## ✅ 已完成的遷移

- ✅ StatusBarMessage
- ✅ DbInfoMessage
- ✅ ProcessBarMessage

---

## 🔍 需要遷移的檔案

搜尋專案中所有使用以下內容的檔案：
- `using CommunityToolkit.Mvvm.Messaging`
- `WeakReferenceMessenger`
- `ValueChangedMessage`

並按照上述步驟進行替換。

---

## 💡 優勢

1. ✅ **零外部依賴** - 不再依賴 CommunityToolkit.Mvvm
2. ✅ **輕量級** - 只實作必要功能
3. ✅ **完全相容** - API 幾乎相同，易於遷移
4. ✅ **弱引用** - 自動防止記憶體洩漏
5. ✅ **執行緒安全** - 內建 lock 機制