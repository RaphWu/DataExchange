﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Extensions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Calin.TaskPulse.Core.Helper
{
    /// <summary>
    /// 提供格式化與轉換相關的輔助方法，供 UI 與 DTO 之間的資料表示互轉使用。
    /// </summary>
    /// <remarks>
    /// 類別中的方法多為將儲存於資料庫或 DTO 的原始字串（如 JSON 或多行文字）
    /// 轉換為適合顯示或傳輸的格式。所有方法為靜態方法，可直接呼叫而無需建立實例。
    /// </remarks>
    public static class FormattingHelper
    {
        /********************
         * Employee
         ********************/

        public static string CarbonCopyString(List<string> carbonCopyNames)
            => carbonCopyNames == null ? "" : string.Join(Environment.NewLine, carbonCopyNames);


        public static List<string> CarbonCopyToDto(string carbonCopyString)
            => carbonCopyString.SplitClean(new[] { '\n', '\r' });

        const string IsEngineer= "是" ;

        public static string EngineerString(bool isEngineer) => isEngineer ? IsEngineer : "";

        public static bool Engineer(string engineerString) => engineerString == IsEngineer;

        /********************
         * Machine
         ********************/

        /// <summary>
        /// 將儲存在 JSON 格式的資產清單反序列化為人類可閱讀的換行字串。
        /// </summary>
        /// <param name="assets">表示資產字串陣列的 JSON 字串 (例如: <c>["Asset A","Asset B"]</c>)。</param>
        /// <returns>
        /// 傳回將 JSON 陣列元素以作業系統預設換行符號 (<see cref="Environment.NewLine"/>) 串接後的字串。
        /// 若 JSON 陣列為空會回傳空字串；若傳入字串為 <c>null</c> 則會由 <c>JsonConvert.DeserializeObject</c> 的實作決定行為並可能拋出例外。
        /// </returns>
        /// <exception cref="Newtonsoft.Json.JsonReaderException">當 <paramref name="assets"/> 不是有效的 JSON 時會拋出此例外。</exception>
        /// <exception cref="Newtonsoft.Json.JsonSerializationException">當 JSON 無法被序列化為 <c>List&lt;string&gt;</c> 時會拋出此例外。</exception>
        public static string AssetString(string assets)
            => string.Join(Environment.NewLine, JsonConvert.DeserializeObject<List<string>>(assets));

        /// <summary>
        /// 將以換行分隔的資產字串轉換為 JSON 格式的字串陣列 (DTO 表示)。
        /// </summary>
        /// <param name="assetString">包含多行資產名稱的字串，行分隔符號可為 <c>'\n'</c> 或 <c>'\r'</c>。</param>
        /// <returns>
        /// 傳回代表資產字串集合的 JSON 字串 (例如: <c>["Asset A","Asset B"]</c>)。
        /// 內部會先呼叫 <c>SplitClean(new[] { '\n', '\r' })</c> 以移除空白或空的項目，再將結果序列化為 JSON。
        /// </returns>
        /// <remarks>
        /// 本方法會將輸入字串依行分隔並清除空項目，適合將使用者輸入或文本區中的多行資料轉為傳輸用的 JSON DTO。
        /// </remarks>
        /// <exception cref="System.ArgumentNullException">若 <paramref name="assetString"/> 為 <c>null</c>，視 <c>SplitClean</c> 的實作可能會拋出此例外。</exception>
        /// <exception cref="Newtonsoft.Json.JsonSerializationException">序列化過程若失敗會拋出此例外。</exception>
        public static string AssetStringToDto(string assetString)
            => JsonConvert.SerializeObject(assetString.SplitClean(new[] { '\n', '\r' }));

        /// <summary>
        /// 表示「可連線」的靜態文字常數，用於 UI 顯示比對。
        /// </summary>
        /// <remarks>
        /// 此常數之文字為應顯示於介面上的中文「可連線」，並被 <see cref="ConnectedString(bool)"/> 與 <see cref="Connected(string)"/> 使用。
        /// 若需改為其他語系或文字，請在整個專案中使用一致替換以避免比對錯誤。
        /// </remarks>
        const string IsConnected = "可連線";

        /// <summary>
        /// 依布林值回傳代表連線狀態的顯示字串。
        /// </summary>
        /// <param name="connected">若為 <c>true</c> 則回傳 <c>"可連線"</c>，否則回傳空字串。</param>
        /// <returns>代表連線狀態的顯示字串（成功時為 <c>IsConnected</c> 常數，失敗或未連線時為空字串）。</returns>
        public static string ConnectedString(bool connected) => connected ? IsConnected : "";

        /// <summary>
        /// 由顯示用字串判斷是否代表「已連線」狀態。
        /// </summary>
        /// <param name="connectString">顯示用的連線字串（例如來自 UI 或資料），若等於 <c>IsConnected</c> 則視為已連線。</param>
        /// <returns>若 <paramref name="connectString"/> 與 <c>IsConnected</c> 相等則回傳 <c>true</c>；否則回傳 <c>false</c>。</returns>
        public static bool Connected(string connectString) => connectString == IsConnected;

        const string IsDisposal = "已處置";

        public static string DisposalString(bool disposal) => disposal ? IsDisposal : "";
        public static bool Disposal(string disposalString) => disposalString == IsDisposal;


        /********************
         * WorkOrder
         ********************/
    }
}
