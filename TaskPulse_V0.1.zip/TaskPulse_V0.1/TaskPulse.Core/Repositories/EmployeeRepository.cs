using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Repositories
{
    /// <summary>
    /// ���u��Ʀs����@�C
    /// </summary>
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly CoreContext _context;

        public EmployeeRepository(CoreContext context)
        {
            _context = context;
        }

        /// <inheritdoc/>
        public async Task<EmployeeEntity> GetByIdAsync(int id)
        {
            return await _context.Employees
                .FirstOrDefaultAsync(e => e.Id == id);
        }

        /// <inheritdoc/>
        public async Task<EmployeeEntity> GetByIdWithRelationsAsync(int id)
        {
            return await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.JobTitle)
                .Include(e => e.Status)
                .Include(e => e.Permissions)
                .Include(e => e.UserGroups)
                .Include(e => e.CarbonCopies)
                .FirstOrDefaultAsync(e => e.Id == id);
        }

        /// <inheritdoc/>
        public async Task<EmployeeEntity> GetByEmployeeIdAsync(string employeeId)
        {
            return await _context.Employees
                .FirstOrDefaultAsync(e => e.EmployeeId == employeeId);
        }

        /// <inheritdoc/>
        public async Task<List<EmployeeEntity>> GetAllAsync()
        {
            return await _context.Employees.ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<List<EmployeeEntity>> SearchByNameAsync(string name)
        {
            return await _context.Employees
                .Where(e => e.EmployeeName.Contains(name))
                .ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<EmployeeEntity> AddAsync(EmployeeEntity entity)
        {
            _context.Employees.Add(entity);
            await SaveChangesAsync();
            return entity;
        }

        /// <inheritdoc/>
        public async Task UpdateAsync(EmployeeEntity entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task DeleteAsync(int id)
        {
            var entity = await GetByIdAsync(id);
            if (entity != null)
            {
                _context.Employees.Remove(entity);
                await SaveChangesAsync();
            }
        }

        /// <inheritdoc/>
        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Employees.AnyAsync(e => e.Id == id);
        }

        /// <inheritdoc/>
        public async Task<bool> EmployeeIdExistsAsync(string employeeId)
        {
            return await _context.Employees.AnyAsync(e => e.EmployeeId == employeeId);
        }

        /// <inheritdoc/>
        public async Task SyncPermissionsAsync(EmployeeEntity entity, List<int> permissionIds)
        {
            if (entity == null || permissionIds == null) return;

            // ���J�{�����v�����X
            if (entity.Permissions == null)
            {
                await _context.Entry(entity).Collection(e => e.Permissions).LoadAsync();
            }

            // �������b�s�C�������v��
            var permissionsToRemove = entity.Permissions
                .Where(p => !permissionIds.Contains(p.Id))
                .ToList();
            foreach (var permission in permissionsToRemove)
            {
                entity.Permissions.Remove(permission);
            }

            // �s�W�s���v��
            var existingPermissionIds = entity.Permissions.Select(p => p.Id).ToList();
            var permissionIdsToAdd = permissionIds
                .Where(id => !existingPermissionIds.Contains(id))
                .ToList();

            if (permissionIdsToAdd.Any())
            {
                var permissionsToAdd = await _context.Permissions
                    .Where(p => permissionIdsToAdd.Contains(p.Id))
                    .ToListAsync();

                foreach (var permission in permissionsToAdd)
                {
                    entity.Permissions.Add(permission);
                }
            }
        }

        /// <inheritdoc/>
        public async Task SyncUserGroupsAsync(EmployeeEntity entity, List<int> userGroupIds)
        {
            if (entity == null || userGroupIds == null) return;

            // ���J�{�����ϥΪ̸s�ն��X
            if (entity.UserGroups == null)
            {
                await _context.Entry(entity).Collection(e => e.UserGroups).LoadAsync();
            }

            // �������b�s�C�������ϥΪ̸s��
            var userGroupsToRemove = entity.UserGroups
                .Where(ug => !userGroupIds.Contains(ug.Id))
                .ToList();
            foreach (var userGroup in userGroupsToRemove)
            {
                entity.UserGroups.Remove(userGroup);
            }

            // �s�W�s���ϥΪ̸s��
            var existingUserGroupIds = entity.UserGroups.Select(ug => ug.Id).ToList();
            var userGroupIdsToAdd = userGroupIds
                .Where(id => !existingUserGroupIds.Contains(id))
                .ToList();

            if (userGroupIdsToAdd.Any())
            {
                var userGroupsToAdd = await _context.UserGroups
                    .Where(ug => userGroupIdsToAdd.Contains(ug.Id))
                    .ToListAsync();

                foreach (var userGroup in userGroupsToAdd)
                {
                    entity.UserGroups.Add(userGroup);
                }
            }
        }

        /// <inheritdoc/>
        public async Task SyncCarbonCopiesAsync(EmployeeEntity entity, List<int> carbonCopyIds)
        {
            if (entity == null || carbonCopyIds == null) return;

            // ���J�{�����ƥ��H�����X
            if (entity.CarbonCopies == null)
            {
                await _context.Entry(entity).Collection(e => e.CarbonCopies).LoadAsync();
            }

            // �������b�s�C�������ƥ��H��
            var carbonCopiesToRemove = entity.CarbonCopies
                .Where(cc => !carbonCopyIds.Contains(cc.Id))
                .ToList();
            foreach (var carbonCopy in carbonCopiesToRemove)
            {
                entity.CarbonCopies.Remove(carbonCopy);
            }

            // �s�W�s���ƥ��H��
            var existingCarbonCopyIds = entity.CarbonCopies.Select(cc => cc.Id).ToList();
            var carbonCopyIdsToAdd = carbonCopyIds
                .Where(id => !existingCarbonCopyIds.Contains(id))
                .ToList();

            if (carbonCopyIdsToAdd.Any())
            {
                var carbonCopiesToAdd = await _context.Employees
                    .Where(e => carbonCopyIdsToAdd.Contains(e.Id))
                    .ToListAsync();

                foreach (var carbonCopy in carbonCopiesToAdd)
                {
                    entity.CarbonCopies.Add(carbonCopy);
                }
            }
        }

        /// <inheritdoc/>
        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
