using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.Repositories
{
    /// <summary>
    /// ���@�u���Ʀs����@�C
    /// </summary>
    public class WorkOrderRepository : IWorkOrderRepository
    {
        private readonly CoreContext _context;

        public WorkOrderRepository(CoreContext context)
        {
            _context = context;
        }

        /// <inheritdoc/>
        public async Task<WorkOrderEntity> GetByIdAsync(int id)
        {
            return await _context.WorkOrders
                .FirstOrDefaultAsync(w => w.Id == id);
        }

        /// <inheritdoc/>
        public async Task<WorkOrderEntity> GetByIdWithRelationsAsync(int id)
        {
            return await _context.WorkOrders
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.Engineers)
                .Include(w => w.IssueCategory)
                .Include(w => w.RequestingUnit)
                .Include(w => w.FeedbackEmployee)
                .FirstOrDefaultAsync(w => w.Id == id);
        }

        /// <inheritdoc/>
        public async Task<WorkOrderEntity> GetByWorkOrderNoAsync(string workOrderNo)
        {
            return await _context.WorkOrders
                .FirstOrDefaultAsync(w => w.WorkOrderNo == workOrderNo);
        }

        /// <inheritdoc/>
        public async Task<List<WorkOrderEntity>> GetAllAsync()
        {
            return await _context.WorkOrders.ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<List<WorkOrderEntity>> SearchByWorkOrderNoAsync(string workOrderNo)
        {
            return await _context.WorkOrders
                .Where(w => w.WorkOrderNo.Contains(workOrderNo))
                .ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<WorkOrderEntity> AddAsync(WorkOrderEntity entity)
        {
            _context.WorkOrders.Add(entity);
            await SaveChangesAsync();
            return entity;
        }

        /// <inheritdoc/>
        public async Task UpdateAsync(WorkOrderEntity entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task DeleteAsync(int id)
        {
            var entity = await GetByIdAsync(id);
            if (entity != null)
            {
                _context.WorkOrders.Remove(entity);
                await SaveChangesAsync();
            }
        }

        /// <inheritdoc/>
        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.WorkOrders.AnyAsync(w => w.Id == id);
        }

        /// <inheritdoc/>
        public async Task<bool> WorkOrderNoExistsAsync(string workOrderNo)
        {
            return await _context.WorkOrders.AnyAsync(w => w.WorkOrderNo == workOrderNo);
        }

        /// <inheritdoc/>
        public async Task SyncEngineersAsync(WorkOrderEntity entity, List<int> engineerIds)
        {
            if (entity == null || engineerIds == null) return;

            // ���J�{�����u�{�v���X
            if (entity.Engineers == null)
            {
                await _context.Entry(entity).Collection(w => w.Engineers).LoadAsync();
            }

            // �������b�s�C�������u�{�v
            var engineersToRemove = entity.Engineers
                .Where(e => !engineerIds.Contains(e.Id))
                .ToList();
            foreach (var engineer in engineersToRemove)
            {
                entity.Engineers.Remove(engineer);
            }

            // �s�W�s���u�{�v
            var existingEngineerIds = entity.Engineers.Select(e => e.Id).ToList();
            var engineerIdsToAdd = engineerIds
                .Where(id => !existingEngineerIds.Contains(id))
                .ToList();

            if (engineerIdsToAdd.Any())
            {
                var engineersToAdd = await _context.Employees
                    .Where(e => engineerIdsToAdd.Contains(e.Id))
                    .ToListAsync();

                foreach (var engineer in engineersToAdd)
                {
                    entity.Engineers.Add(engineer);
                }
            }
        }

        /// <inheritdoc/>
        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
