using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Repositories
{
    /// <summary>
    /// ���x��Ʀs����@�C
    /// </summary>
    public class MachineRepository : IMachineRepository
    {
        private readonly CoreContext _context;

        public MachineRepository(CoreContext context)
        {
            _context = context;
        }

        /// <inheritdoc/>
        public async Task<MachineEntity> GetByIdAsync(int id)
        {
            return await _context.Machines
                .FirstOrDefaultAsync(m => m.Id == id);
        }

        /// <inheritdoc/>
        public async Task<MachineEntity> GetByIdWithRelationsAsync(int id)
        {
            return await _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Workstations)
                .FirstOrDefaultAsync(m => m.Id == id);
        }

        /// <inheritdoc/>
        public async Task<MachineEntity> GetByMachineCodeAsync(string machineCode)
        {
            return await _context.Machines
                .FirstOrDefaultAsync(m => m.MachineCode == machineCode);
        }

        /// <inheritdoc/>
        public async Task<List<MachineEntity>> GetAllAsync()
        {
            return await _context.Machines.ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<List<MachineEntity>> SearchByCodeAsync(string code)
        {
            return await _context.Machines
                .Where(m => m.MachineCode.Contains(code))
                .ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<MachineEntity> AddAsync(MachineEntity entity)
        {
            _context.Machines.Add(entity);
            await SaveChangesAsync();
            return entity;
        }

        /// <inheritdoc/>
        public async Task UpdateAsync(MachineEntity entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task DeleteAsync(int id)
        {
            var entity = await GetByIdAsync(id);
            if (entity != null)
            {
                _context.Machines.Remove(entity);
                await SaveChangesAsync();
            }
        }

        /// <inheritdoc/>
        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Machines.AnyAsync(m => m.Id == id);
        }

        /// <inheritdoc/>
        public async Task<bool> MachineCodeExistsAsync(string machineCode)
        {
            return await _context.Machines.AnyAsync(m => m.MachineCode == machineCode);
        }

        /// <inheritdoc/>
        public async Task SyncWorkstationsAsync(MachineEntity entity, List<int> workstationIds)
        {
            if (entity == null || workstationIds == null) return;

            // ���J�{�����u�����X
            if (entity.Workstations == null)
            {
                await _context.Entry(entity).Collection(m => m.Workstations).LoadAsync();
            }

            // �������b�s�C�������u��
            var workstationsToRemove = entity.Workstations
                .Where(w => !workstationIds.Contains(w.Id))
                .ToList();
            foreach (var workstation in workstationsToRemove)
            {
                entity.Workstations.Remove(workstation);
            }

            // �s�W�s���u��
            var existingWorkstationIds = entity.Workstations.Select(w => w.Id).ToList();
            var workstationIdsToAdd = workstationIds
                .Where(id => !existingWorkstationIds.Contains(id))
                .ToList();

            if (workstationIdsToAdd.Any())
            {
                var workstationsToAdd = await _context.Workstations
                    .Where(w => workstationIdsToAdd.Contains(w.Id))
                    .ToListAsync();

                foreach (var workstation in workstationsToAdd)
                {
                    entity.Workstations.Add(workstation);
                }
            }
        }

        /// <inheritdoc/>
        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
