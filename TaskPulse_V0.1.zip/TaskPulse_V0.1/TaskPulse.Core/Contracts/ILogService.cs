﻿using System;
using System.Threading.Tasks;

namespace Calin.TaskPulse.Core.Contracts
{
    /// <summary>
    /// 活動記錄。
    /// </summary>
    /// <remarks>用法範例:
    /// <code><![CDATA[
    /// 登入
    /// _log.LoginAsync(user.Id, "Login", new { Username = user.Name });
    /// 
    /// 新增員工
    /// await _log.LoginAsync(currentUserId, "新增員工", new { emp.Id, emp.Name, Phone = phone, Address = address });
    /// 
    /// 編輯員工
    /// await _log.LoginAsync(currentUserId, "編輯員工", emp);
    /// ]]></code></remarks>
    public interface ILogService
    {
        /********************
         * System
         ********************/
        /// <summary>
        /// 系統異常記錄。
        /// </summary>
        /// <param name="message">錯誤訊息。</param>
        /// <param name="ex">例外物件。</param>
        Task ErrorAsync(string message, Exception ex = null);

        /********************
         * User
         ********************/
        /// <summary>
        /// 使用者動作記錄。
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="action"></param>
        /// <param name="dataJson"></param>
        /// <returns></returns>
        Task LoginAsync(string userId, string action, string dataJson);

        /// <summary>
        /// UI 操作記錄。
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="formName"></param>
        /// <param name="controlName"></param>
        /// <param name="action"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        Task UIActionAsync(int userId, string formName, string controlName, string action, object data = null);
    }
}
