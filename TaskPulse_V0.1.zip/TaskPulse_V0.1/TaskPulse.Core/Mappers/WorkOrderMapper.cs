using System.Linq;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Entity.MaintiFlow;

namespace Calin.TaskPulse.Core.Mappers
{
    /// <summary>
    /// ���@�u�����PDTO�������ഫ���C
    /// </summary>
    public class WorkOrderMapper : IWorkOrderMapper
    {
        /// <summary>
        /// �N���@�u������ഫ��DTO�C
        /// </summary>
        public WorkOrderDto ToDto(WorkOrderEntity entity)
        {
            if (entity == null) return null;

            return new WorkOrderDto
            {
                Id = entity.Id,
                WorkOrderNo = entity.WorkOrderNo,
                Status = entity.Status,

                // ���x��T
                MachineId = entity.MachineId,
                MachineCode = entity.Machine?.MachineCode,

                // �u����T
                WorkstationId = entity.WorkstationId,
                WorkstationName = entity.Workstation?.WorkstationName,

                // �إߤH��T
                CreatorId = entity.CreatorId,
                CreatorName = entity.Creator?.EmployeeName,
                CreationDateTime = entity.CreationDateTime,

                // ���@���
                MaintenanceUnitId = entity.MaintenanceUnitId,
                MaintenanceUnitName = entity.MaintenanceUnit?.UnitName,

                // ���@�u�{�v
                EngineerIds = entity.Engineers?.Select(e => e.Id).ToList(),
                EngineerNames = entity.Engineers?.Select(e => e.EmployeeName).ToList(),
                AcceptedTime = entity.AcceptedTime,

                // ���@���e
                IssueCategoryId = entity.IssueCategoryId,
                IssueCategoryName = entity.IssueCategory?.CategoryName,
                IssueDescription = entity.IssueDescription,
                Details = entity.Details,
                RepairStarted = entity.RepairStarted,
                RepairCompleted = entity.RepairCompleted,
                RepairDurationTick = entity.RepairDurationTick,
                FillingTime = entity.FillingTime,

                // �ݨD����T
                RequestingUnitId = entity.RequestingUnitId,
                RequestingUnitName = entity.RequestingUnit?.DepartmentName,
                FeedbackEmployeeId = entity.FeedbackEmployeeId,
                FeedbackEmployeeName = entity.FeedbackEmployee?.EmployeeName,
                Feedback = entity.Feedback,
                OutageStarted = entity.OutageStarted,
                OutageEnded = entity.OutageEnded,
                OutageDurationTick = entity.OutageDurationTick,

                // ��L
                Responsible = entity.Responsible
            };
        }

        /// <summary>
        /// �NDTO�ഫ�����@�u�����]���]�t�ɯ��ݩʡ^�C
        /// </summary>
        public WorkOrderEntity ToEntity(WorkOrderDto dto)
        {
            if (dto == null) return null;

            return new WorkOrderEntity
            {
                Id = dto.Id,
                WorkOrderNo = dto.WorkOrderNo,
                Status = dto.Status,
                MachineId = dto.MachineId,
                WorkstationId = dto.WorkstationId,
                CreatorId = dto.CreatorId,
                CreationDateTime = dto.CreationDateTime,
                MaintenanceUnitId = dto.MaintenanceUnitId,
                AcceptedTime = dto.AcceptedTime,
                IssueCategoryId = dto.IssueCategoryId,
                IssueDescription = dto.IssueDescription,
                Details = dto.Details,
                RepairStarted = dto.RepairStarted,
                RepairCompleted = dto.RepairCompleted,
                RepairDurationTick = dto.RepairDurationTick,
                FillingTime = dto.FillingTime,
                RequestingUnitId = dto.RequestingUnitId,
                FeedbackEmployeeId = dto.FeedbackEmployeeId,
                Feedback = dto.Feedback,
                OutageStarted = dto.OutageStarted,
                OutageEnded = dto.OutageEnded,
                OutageDurationTick = dto.OutageDurationTick,
                Responsible = dto.Responsible
            };
        }

        /// <summary>
        /// ��s�{�����骺�ݩʡ]���]�t�ɯ��ݩʡ^�C
        /// </summary>
        public void UpdateEntity(WorkOrderEntity entity, WorkOrderDto dto)
        {
            if (entity == null || dto == null) return;

            entity.WorkOrderNo = dto.WorkOrderNo;
            entity.Status = dto.Status;
            entity.MachineId = dto.MachineId;
            entity.WorkstationId = dto.WorkstationId;
            entity.CreatorId = dto.CreatorId;
            entity.CreationDateTime = dto.CreationDateTime;
            entity.MaintenanceUnitId = dto.MaintenanceUnitId;
            entity.AcceptedTime = dto.AcceptedTime;
            entity.IssueCategoryId = dto.IssueCategoryId;
            entity.IssueDescription = dto.IssueDescription;
            entity.Details = dto.Details;
            entity.RepairStarted = dto.RepairStarted;
            entity.RepairCompleted = dto.RepairCompleted;
            entity.RepairDurationTick = dto.RepairDurationTick;
            entity.FillingTime = dto.FillingTime;
            entity.RequestingUnitId = dto.RequestingUnitId;
            entity.FeedbackEmployeeId = dto.FeedbackEmployeeId;
            entity.Feedback = dto.Feedback;
            entity.OutageStarted = dto.OutageStarted;
            entity.OutageEnded = dto.OutageEnded;
            entity.OutageDurationTick = dto.OutageDurationTick;
            entity.Responsible = dto.Responsible;
        }
    }
}
