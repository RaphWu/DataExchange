using System.Linq;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Mappers
{
    /// <summary>
    /// ���x����PDTO�������ഫ���C
    /// </summary>
    public class MachineMapper : IMachineMapper
    {
        /// <summary>
        /// �N���x�����ഫ��DTO�C
        /// </summary>
        public MachineDto ToDto(MachineEntity entity)
        {
            if (entity == null) return null;

            bool hasMachineName = entity.MachineName != null;
            bool hasMachineType = hasMachineName && entity.MachineName.MachineType != null;
            bool hasMachineCategory = hasMachineType && entity.MachineName.MachineType.MachineCategory != null;

            return new MachineDto
            {
                Id = entity.Id,
                MachineCode = entity.MachineCode,
                MachineNameId = entity.MachineNameId,
                MachineModelNo = entity.MachineName?.ModelNo ?? string.Empty,
                MachineTypeId = hasMachineType ? entity.MachineName.MachineType.Id : (int?)null,
                MachineTypeName = hasMachineType ? entity.MachineName.MachineType.TypeName : string.Empty,
                MachineCategoryId = hasMachineCategory ? entity.MachineName.MachineType.MachineCategory.Id : (int?)null,
                MachineCategoryName = hasMachineCategory ? entity.MachineName.MachineType.MachineCategory.CategoryName : string.Empty,
                ConditionId = entity.ConditionId,
                ConditionName = entity.Condition?.ConditionName ?? string.Empty,
                BrandId = entity.BrandId,
                BrandName = entity.Brand?.BrandName ?? string.Empty,
                LocationId = entity.LocationId,
                LocationName = entity.Location?.LocationName ?? string.Empty,
                Assets = entity.Assets,
                SerialNumber = entity.SerialNumber,
                Barcode = entity.Barcode,
                Connected = entity.Connected,
                Disposal = entity.Disposal,
                Remark = entity.Remark,
                WorkstationIds = entity.Workstations?.Select(w => w.Id).ToList()
            };
        }

        /// <summary>
        /// �NDTO�ഫ�����x����]���]�t�ɯ��ݩʡ^�C
        /// </summary>
        public MachineEntity ToEntity(MachineDto dto)
        {
            if (dto == null) return null;

            return new MachineEntity
            {
                Id = dto.Id,
                MachineCode = dto.MachineCode,
                MachineNameId = dto.MachineNameId,
                ConditionId = dto.ConditionId,
                BrandId = dto.BrandId,
                LocationId = dto.LocationId,
                Assets = dto.Assets,
                SerialNumber = dto.SerialNumber,
                Barcode = dto.Barcode,
                Connected = dto.Connected,
                Disposal = dto.Disposal,
                Remark = dto.Remark
            };
        }

        /// <summary>
        /// ��s�{�����骺�ݩʡ]���]�t�ɯ��ݩʡ^�C
        /// </summary>
        public void UpdateEntity(MachineEntity entity, MachineDto dto)
        {
            if (entity == null || dto == null) return;

            entity.MachineCode = dto.MachineCode;
            entity.MachineNameId = dto.MachineNameId;
            entity.ConditionId = dto.ConditionId;
            entity.BrandId = dto.BrandId;
            entity.LocationId = dto.LocationId;
            entity.Assets = dto.Assets;
            entity.SerialNumber = dto.SerialNumber;
            entity.Barcode = dto.Barcode;
            entity.Connected = dto.Connected;
            entity.Disposal = dto.Disposal;
            entity.Remark = dto.Remark;
        }
    }
}
