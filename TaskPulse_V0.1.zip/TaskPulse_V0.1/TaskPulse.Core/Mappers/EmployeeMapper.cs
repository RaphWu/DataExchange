using System.Linq;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Entity.Core;

namespace Calin.TaskPulse.Core.Mappers
{
    /// <summary>
    /// ���u����PDTO�������ഫ���C
    /// </summary>
    public class EmployeeMapper : IEmployeeMapper
    {
        /// <summary>
        /// �N���u�����ഫ��DTO�C
        /// </summary>
        public EmployeeDto ToDto(EmployeeEntity entity)
        {
            if (entity == null)
                return null;

            return new EmployeeDto
            {
                Id = entity.Id,
                EmployeeId = entity.EmployeeId,
                EmployeeName = entity.EmployeeName,
                PasswordHash = entity.PasswordHash,
                DepartmentId = entity.DepartmentId,
                DepartmentName = entity.Department?.DepartmentName,
                JobTitleId = entity.JobTitleId,
                JobTitleName = entity.JobTitle?.JobTitleName,
                Email = entity.Email,
                IsEngineer = entity.IsEngineer,
                StatusId = entity.StatusId,
                StatusName = entity.Status?.StatusName,
                StatusChangeAt = entity.StatusChangeAt,
                CarbonCopyIds = entity.CarbonCopies?.Select(cc => cc.Id).ToList(),
                PermissionIds = entity.Permissions?.Select(p => p.Id).ToList(),
                UserGroupIds = entity.UserGroups?.Select(ug => ug.Id).ToList()
            };
        }

        /// <summary>
        /// �NDTO�ഫ�����u����]���]�t�ɯ��ݩʡ^�C
        /// </summary>
        public EmployeeEntity ToEntity(EmployeeDto dto)
        {
            if (dto == null) return null;

            return new EmployeeEntity
            {
                Id = dto.Id,
                EmployeeId = dto.EmployeeId,
                EmployeeName = dto.EmployeeName,
                PasswordHash = dto.PasswordHash,
                DepartmentId = dto.DepartmentId,
                JobTitleId = dto.JobTitleId,
                Email = dto.Email,
                IsEngineer = dto.IsEngineer,
                StatusId = dto.StatusId,
                StatusChangeAt = dto.StatusChangeAt
            };
        }

        /// <summary>
        /// ��s�{�����骺�ݩʡ]���]�t�ɯ��ݩʡ^�C
        /// </summary>
        public void UpdateEntity(EmployeeEntity entity, EmployeeDto dto)
        {
            if (entity == null || dto == null) return;

            entity.EmployeeId = dto.EmployeeId;
            entity.EmployeeName = dto.EmployeeName;

            if (!string.IsNullOrEmpty(dto.PasswordHash))
            {
                entity.PasswordHash = dto.PasswordHash;
            }

            entity.DepartmentId = dto.DepartmentId;
            entity.JobTitleId = dto.JobTitleId;
            entity.Email = dto.Email;
            entity.IsEngineer = dto.IsEngineer;
            entity.StatusId = dto.StatusId;
            entity.StatusChangeAt = dto.StatusChangeAt;
        }
    }
}
