﻿using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class MachineEdit : UIForm
    {

        #region fields

        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        #endregion fields

        public MachineEdit(CoreContext coreContext, CoreData coreData, MultiSelector multiSelector)
        {
            InitializeComponent();
            _context = coreContext;
            _coreData = coreData;
            _mSel = multiSelector;
        }
    }
}
