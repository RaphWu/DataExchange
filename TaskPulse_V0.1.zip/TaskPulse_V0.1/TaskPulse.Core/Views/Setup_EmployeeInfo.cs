﻿using System;
using System.Collections.Generic;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.ViewModels;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_EmployeeInfo : BaseViewModelUserControl<SharedEmployeeViewModel>
    {
        #region fields

        private readonly IRegionManager _region;
        private readonly INavigationService _navigation;
        private readonly ISharedViewModelManager _viewModelManager;

        private List<ListViewModel> _vmDepartments = null;
        private ListViewModel _vmDep = null;
        private List<ListViewModel> _vmTitles = null;
        private ListViewModel _vmTitle = null;

        #endregion fields

        public Setup_EmployeeInfo(IRegionManager regionManager,
                                  INavigationService navigationService,
                                  ISharedViewModelManager viewModelManager)
        {
            InitializeComponent();
            _region = regionManager;
            _navigation = navigationService;
            _viewModelManager = viewModelManager;

            _region.RegisterRegion(nameof(Panel_Permission), Panel_Permission);
            _navigation.Navigate<Setup_Permission>(nameof(Panel_Permission), alive: false);

            string itemName = PropertyText.Title.Department;
            Label_Department.Text = itemName;
            CommonStyles.SetListBox(LB_Departments);
            CommonStyles.SetCrudButton(Department_Create, "C", itemName);
            CommonStyles.SetCrudButton(Department_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Department_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Department_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Department_Down, "DOWN", itemName);

            itemName = PropertyText.Title.JobTitle;
            Label_Title.Text = itemName;
            CommonStyles.SetListBox(LB_Titles);
            CommonStyles.SetCrudButton(Title_Create, "C", itemName);
            CommonStyles.SetCrudButton(Title_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Title_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Title_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Title_Down, "DOWN", itemName);
        }

        protected override void OnViewModelBound()
        {
            throw new NotImplementedException();
        }

        protected override void OnViewModelUnbound()
        {
            base.OnViewModelUnbound();
        }

    }
}
