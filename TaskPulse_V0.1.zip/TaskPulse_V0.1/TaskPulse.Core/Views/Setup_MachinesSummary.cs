﻿using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachinesSummary : UserControl
    {
        #region fields

        private readonly ILifetimeScope _scope;
        private readonly BindingSource _bs = new BindingSource();

        #endregion fields

        public Setup_MachinesSummary(ILifetimeScope lifetimeScope,
                                     IPermissionService permissionService,
                                     CoreContext coreContext,
                                     ICore core,
                                     CoreData coreData)
        {
            InitializeComponent();
            _scope = lifetimeScope;

            string itemName = PropertyText.Title.Machine;
            //headLabel_Machine.Text = $"{PropertyString.Title.MachineCategoryEntity} » {PropertyString.Title.MachineType}";
            CommonStyles.SetCrudButton(Machine_Create, "C", itemName);
            CommonStyles.SetCrudButton(Machine_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Machine_Delete, "D", itemName);

            CommonStyles.SetAdvancedDataGridView(adgv, true);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
            }
            base.Dispose(disposing);
        }

        private void Setup_MachinesSummary_Load(object sender, System.EventArgs e)
        {
            label_MachineId.Text = PropertyText.Title.Machine;
            MaincheId.DataBindings.Clear();
            MaincheId.DataBindings.Add("Text", _bs, PropertyText.Name.MachineCode);

            label_Catelogry.Text = PropertyText.Title.MachineCategory;
            Catelogry.DataBindings.Clear();
            Catelogry.DataBindings.Add("Text", _bs, PropertyText.Name.MachineCategory);

            label_Type.Text = PropertyText.Title.MachineType;
            Type.DataBindings.Clear();
            Type.DataBindings.Add("Text", _bs, PropertyText.Name.MachineType);

            label_ModeName.Text = PropertyText.Title.MachineModel;
            ModeName.DataBindings.Clear();
            ModeName.DataBindings.Add("Text", _bs, PropertyText.Name.MachineModel);

            label_Condition.Text = PropertyText.Title.Condition;
            Condition.DataBindings.Clear();
            Condition.DataBindings.Add("Text", _bs, PropertyText.Name.ConditionName);

            label_Brand.Text = PropertyText.Title.Brand;
            Brand.DataBindings.Clear();
            Brand.DataBindings.Add("Text", _bs, PropertyText.Name.BrandName);

            label_Location.Text = PropertyText.Title.Location;
            Location.DataBindings.Clear();
            Location.DataBindings.Add("Text", _bs, PropertyText.Name.LocationName);

            label_Assets.Text = PropertyText.Title.Assets;
            Assets.DataBindings.Clear();
            Assets.DataBindings.Add("Text", _bs, PropertyText.Name.AssetString);

            label_SerialNumber.Text = PropertyText.Title.SerialNumber;
            SerialNumber.DataBindings.Clear();
            SerialNumber.DataBindings.Add("Text", _bs, PropertyText.Name.SerialNumber);

            label_Barcode.Text = PropertyText.Title.Barcode;
            Barcode.DataBindings.Clear();
            Barcode.DataBindings.Add("Text", _bs, PropertyText.Name.Barcode);

            label_Connected.Text = PropertyText.Title.Connected;
            Connected.DataBindings.Clear();
            Connected.DataBindings.Add("Text", _bs, PropertyText.Name.ConnectedString);

            label_Disposal.Text = PropertyText.Title.Disposal;
            Disposal.DataBindings.Clear();
            Disposal.DataBindings.Add("Text", _bs, PropertyText.Name.DisposalString);

            //label_Workstations.Text = PropertyString.Title.Workstations;
            //Workstations.DataBindings.Clear();
            //Workstations.DataBindings.Add("Text", _bs, PropertyString.Name.Workstations);

            label_Remark.Text = PropertyText.Title.Remark;
            Remark.DataBindings.Clear();
            Remark.DataBindings.Add("Text", _bs, PropertyText.Name.Remark);
        }

    }
}
