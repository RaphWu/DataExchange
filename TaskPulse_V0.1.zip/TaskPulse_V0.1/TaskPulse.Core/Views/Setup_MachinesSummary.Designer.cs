﻿namespace Calin.TaskPulse.Core.Views
{
    partial class Setup_MachinesSummary
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel_Page = new System.Windows.Forms.TableLayoutPanel();
            this.list_Catelogries = new Sunny.UI.UITreeView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_Workstations = new Sunny.UI.UILabel();
            this.Workstations = new Sunny.UI.UITextBox();
            this.label_ModeName = new Sunny.UI.UILabel();
            this.ModeName = new Sunny.UI.UITextBox();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.Machine_Create = new Sunny.UI.UISymbolButton();
            this.Machine_Edit = new Sunny.UI.UISymbolButton();
            this.Machine_Delete = new Sunny.UI.UISymbolButton();
            this.label_Remark = new Sunny.UI.UILabel();
            this.Remark = new Sunny.UI.UIRichTextBox();
            this.label_Connected = new Sunny.UI.UILabel();
            this.label_Disposal = new Sunny.UI.UILabel();
            this.Connected = new Sunny.UI.UITextBox();
            this.Disposal = new Sunny.UI.UITextBox();
            this.Assets = new Sunny.UI.UIRichTextBox();
            this.label_SerialNumber = new Sunny.UI.UILabel();
            this.label_Barcode = new Sunny.UI.UILabel();
            this.SerialNumber = new Sunny.UI.UITextBox();
            this.label_Assets = new Sunny.UI.UILabel();
            this.Barcode = new Sunny.UI.UITextBox();
            this.label_Location = new Sunny.UI.UILabel();
            this.label_Brand = new Sunny.UI.UILabel();
            this.Location = new Sunny.UI.UITextBox();
            this.Brand = new Sunny.UI.UITextBox();
            this.label_Condition = new Sunny.UI.UILabel();
            this.Condition = new Sunny.UI.UITextBox();
            this.label_Type = new Sunny.UI.UILabel();
            this.Type = new Sunny.UI.UITextBox();
            this.label_Catelogry = new Sunny.UI.UILabel();
            this.label_MachineId = new Sunny.UI.UILabel();
            this.Catelogry = new Sunny.UI.UITextBox();
            this.MaincheId = new Sunny.UI.UITextBox();
            this.adgv = new Zuby.ADGV.AdvancedDataGridView();
            this.tableLayoutPanel_Page.SuspendLayout();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel_Page
            // 
            this.tableLayoutPanel_Page.ColumnCount = 2;
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 225F));
            this.tableLayoutPanel_Page.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.Controls.Add(this.list_Catelogries, 0, 0);
            this.tableLayoutPanel_Page.Controls.Add(this.panel1, 1, 1);
            this.tableLayoutPanel_Page.Controls.Add(this.adgv, 1, 0);
            this.tableLayoutPanel_Page.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel_Page.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.tableLayoutPanel_Page.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel_Page.Name = "tableLayoutPanel_Page";
            this.tableLayoutPanel_Page.RowCount = 2;
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel_Page.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 290F));
            this.tableLayoutPanel_Page.Size = new System.Drawing.Size(1154, 675);
            this.tableLayoutPanel_Page.TabIndex = 0;
            // 
            // list_Catelogries
            // 
            this.list_Catelogries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.list_Catelogries.FillColor = System.Drawing.Color.White;
            this.list_Catelogries.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.list_Catelogries.Location = new System.Drawing.Point(4, 2);
            this.list_Catelogries.Margin = new System.Windows.Forms.Padding(4, 2, 4, 3);
            this.list_Catelogries.MinimumSize = new System.Drawing.Size(1, 1);
            this.list_Catelogries.Name = "list_Catelogries";
            this.tableLayoutPanel_Page.SetRowSpan(this.list_Catelogries, 2);
            this.list_Catelogries.ScrollBarStyleInherited = false;
            this.list_Catelogries.ShowText = false;
            this.list_Catelogries.Size = new System.Drawing.Size(217, 670);
            this.list_Catelogries.TabIndex = 9;
            this.list_Catelogries.Text = "uiTreeView1";
            this.list_Catelogries.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label_Workstations);
            this.panel1.Controls.Add(this.Workstations);
            this.panel1.Controls.Add(this.label_ModeName);
            this.panel1.Controls.Add(this.ModeName);
            this.panel1.Controls.Add(this.flowLayoutPanel4);
            this.panel1.Controls.Add(this.label_Remark);
            this.panel1.Controls.Add(this.Remark);
            this.panel1.Controls.Add(this.label_Connected);
            this.panel1.Controls.Add(this.label_Disposal);
            this.panel1.Controls.Add(this.Connected);
            this.panel1.Controls.Add(this.Disposal);
            this.panel1.Controls.Add(this.Assets);
            this.panel1.Controls.Add(this.label_SerialNumber);
            this.panel1.Controls.Add(this.label_Barcode);
            this.panel1.Controls.Add(this.SerialNumber);
            this.panel1.Controls.Add(this.label_Assets);
            this.panel1.Controls.Add(this.Barcode);
            this.panel1.Controls.Add(this.label_Location);
            this.panel1.Controls.Add(this.label_Brand);
            this.panel1.Controls.Add(this.Location);
            this.panel1.Controls.Add(this.Brand);
            this.panel1.Controls.Add(this.label_Condition);
            this.panel1.Controls.Add(this.Condition);
            this.panel1.Controls.Add(this.label_Type);
            this.panel1.Controls.Add(this.Type);
            this.panel1.Controls.Add(this.label_Catelogry);
            this.panel1.Controls.Add(this.label_MachineId);
            this.panel1.Controls.Add(this.Catelogry);
            this.panel1.Controls.Add(this.MaincheId);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(228, 388);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(923, 284);
            this.panel1.TabIndex = 11;
            // 
            // label_Workstations
            // 
            this.label_Workstations.BackColor = System.Drawing.Color.Transparent;
            this.label_Workstations.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Workstations.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Workstations.Location = new System.Drawing.Point(324, 10);
            this.label_Workstations.Margin = new System.Windows.Forms.Padding(0);
            this.label_Workstations.Name = "label_Workstations";
            this.label_Workstations.Size = new System.Drawing.Size(75, 29);
            this.label_Workstations.TabIndex = 47;
            this.label_Workstations.Text = "工站";
            this.label_Workstations.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label_Workstations.Visible = false;
            // 
            // Workstations
            // 
            this.Workstations.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Workstations.FillDisableColor = System.Drawing.Color.White;
            this.Workstations.FillReadOnlyColor = System.Drawing.Color.White;
            this.Workstations.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Workstations.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Workstations.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Workstations.Location = new System.Drawing.Point(403, 10);
            this.Workstations.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Workstations.MinimumSize = new System.Drawing.Size(1, 16);
            this.Workstations.Name = "Workstations";
            this.Workstations.Padding = new System.Windows.Forms.Padding(5);
            this.Workstations.ReadOnly = true;
            this.Workstations.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Workstations.ShowText = false;
            this.Workstations.Size = new System.Drawing.Size(200, 83);
            this.Workstations.TabIndex = 46;
            this.Workstations.TabStop = false;
            this.Workstations.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Workstations.Visible = false;
            this.Workstations.Watermark = "";
            // 
            // label_ModeName
            // 
            this.label_ModeName.BackColor = System.Drawing.Color.Transparent;
            this.label_ModeName.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_ModeName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_ModeName.Location = new System.Drawing.Point(22, 127);
            this.label_ModeName.Margin = new System.Windows.Forms.Padding(0);
            this.label_ModeName.Name = "label_ModeName";
            this.label_ModeName.Size = new System.Drawing.Size(76, 29);
            this.label_ModeName.TabIndex = 44;
            this.label_ModeName.Text = "型號";
            this.label_ModeName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ModeName
            // 
            this.ModeName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ModeName.FillDisableColor = System.Drawing.Color.White;
            this.ModeName.FillReadOnlyColor = System.Drawing.Color.White;
            this.ModeName.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.ModeName.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.ModeName.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.ModeName.Location = new System.Drawing.Point(103, 127);
            this.ModeName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ModeName.MinimumSize = new System.Drawing.Size(1, 16);
            this.ModeName.Name = "ModeName";
            this.ModeName.Padding = new System.Windows.Forms.Padding(5);
            this.ModeName.ReadOnly = true;
            this.ModeName.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.ModeName.ShowText = false;
            this.ModeName.Size = new System.Drawing.Size(200, 29);
            this.ModeName.TabIndex = 43;
            this.ModeName.TabStop = false;
            this.ModeName.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ModeName.Watermark = "";
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.flowLayoutPanel4.AutoSize = true;
            this.flowLayoutPanel4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.flowLayoutPanel4.Controls.Add(this.Machine_Create);
            this.flowLayoutPanel4.Controls.Add(this.Machine_Edit);
            this.flowLayoutPanel4.Controls.Add(this.Machine_Delete);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(357, 243);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(144, 30);
            this.flowLayoutPanel4.TabIndex = 6;
            // 
            // Machine_Create
            // 
            this.Machine_Create.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Machine_Create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Create.Enabled = false;
            this.Machine_Create.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Create.Location = new System.Drawing.Point(9, 0);
            this.Machine_Create.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Create.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Create.Name = "Machine_Create";
            this.Machine_Create.Size = new System.Drawing.Size(30, 30);
            this.Machine_Create.Symbol = 557669;
            this.Machine_Create.SymbolSize = 32;
            this.Machine_Create.TabIndex = 2;
            this.Machine_Create.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // Machine_Edit
            // 
            this.Machine_Edit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Machine_Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Edit.Enabled = false;
            this.Machine_Edit.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Edit.Location = new System.Drawing.Point(57, 0);
            this.Machine_Edit.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Edit.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Edit.Name = "Machine_Edit";
            this.Machine_Edit.Size = new System.Drawing.Size(30, 30);
            this.Machine_Edit.Symbol = 559205;
            this.Machine_Edit.SymbolSize = 32;
            this.Machine_Edit.TabIndex = 3;
            this.Machine_Edit.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // Machine_Delete
            // 
            this.Machine_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Machine_Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Machine_Delete.Enabled = false;
            this.Machine_Delete.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Machine_Delete.Location = new System.Drawing.Point(105, 0);
            this.Machine_Delete.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.Machine_Delete.MinimumSize = new System.Drawing.Size(1, 1);
            this.Machine_Delete.Name = "Machine_Delete";
            this.Machine_Delete.Size = new System.Drawing.Size(30, 30);
            this.Machine_Delete.Symbol = 559506;
            this.Machine_Delete.SymbolSize = 26;
            this.Machine_Delete.TabIndex = 4;
            this.Machine_Delete.TipsFont = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            // 
            // label_Remark
            // 
            this.label_Remark.BackColor = System.Drawing.Color.Transparent;
            this.label_Remark.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Remark.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Remark.Location = new System.Drawing.Point(615, 10);
            this.label_Remark.Margin = new System.Windows.Forms.Padding(0);
            this.label_Remark.Name = "label_Remark";
            this.label_Remark.Size = new System.Drawing.Size(48, 29);
            this.label_Remark.TabIndex = 42;
            this.label_Remark.Text = "備註";
            this.label_Remark.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Remark
            // 
            this.Remark.FillColor = System.Drawing.Color.White;
            this.Remark.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Remark.Location = new System.Drawing.Point(667, 10);
            this.Remark.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Remark.MinimumSize = new System.Drawing.Size(1, 1);
            this.Remark.Name = "Remark";
            this.Remark.Padding = new System.Windows.Forms.Padding(2);
            this.Remark.ReadOnly = true;
            this.Remark.ShowText = false;
            this.Remark.Size = new System.Drawing.Size(237, 146);
            this.Remark.TabIndex = 38;
            this.Remark.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Connected
            // 
            this.label_Connected.BackColor = System.Drawing.Color.Transparent;
            this.label_Connected.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Connected.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Connected.Location = new System.Drawing.Point(619, 166);
            this.label_Connected.Margin = new System.Windows.Forms.Padding(0);
            this.label_Connected.Name = "label_Connected";
            this.label_Connected.Size = new System.Drawing.Size(44, 29);
            this.label_Connected.TabIndex = 41;
            this.label_Connected.Text = "連網";
            this.label_Connected.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Disposal
            // 
            this.label_Disposal.BackColor = System.Drawing.Color.Transparent;
            this.label_Disposal.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Disposal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Disposal.Location = new System.Drawing.Point(619, 205);
            this.label_Disposal.Margin = new System.Windows.Forms.Padding(0);
            this.label_Disposal.Name = "label_Disposal";
            this.label_Disposal.Size = new System.Drawing.Size(44, 29);
            this.label_Disposal.TabIndex = 39;
            this.label_Disposal.Text = "處置";
            this.label_Disposal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Connected
            // 
            this.Connected.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Connected.FillDisableColor = System.Drawing.Color.White;
            this.Connected.FillReadOnlyColor = System.Drawing.Color.White;
            this.Connected.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Connected.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Connected.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Connected.Location = new System.Drawing.Point(667, 166);
            this.Connected.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Connected.MinimumSize = new System.Drawing.Size(1, 16);
            this.Connected.Name = "Connected";
            this.Connected.Padding = new System.Windows.Forms.Padding(5);
            this.Connected.ReadOnly = true;
            this.Connected.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Connected.ShowText = false;
            this.Connected.Size = new System.Drawing.Size(237, 29);
            this.Connected.TabIndex = 40;
            this.Connected.TabStop = false;
            this.Connected.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Connected.Watermark = "";
            // 
            // Disposal
            // 
            this.Disposal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Disposal.FillDisableColor = System.Drawing.Color.White;
            this.Disposal.FillReadOnlyColor = System.Drawing.Color.White;
            this.Disposal.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Disposal.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Disposal.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Disposal.Location = new System.Drawing.Point(667, 205);
            this.Disposal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Disposal.MinimumSize = new System.Drawing.Size(1, 16);
            this.Disposal.Name = "Disposal";
            this.Disposal.Padding = new System.Windows.Forms.Padding(5);
            this.Disposal.ReadOnly = true;
            this.Disposal.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Disposal.ShowText = false;
            this.Disposal.Size = new System.Drawing.Size(237, 29);
            this.Disposal.TabIndex = 38;
            this.Disposal.TabStop = false;
            this.Disposal.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Disposal.Watermark = "";
            // 
            // Assets
            // 
            this.Assets.FillColor = System.Drawing.Color.White;
            this.Assets.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Assets.Location = new System.Drawing.Point(403, 103);
            this.Assets.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Assets.MinimumSize = new System.Drawing.Size(1, 1);
            this.Assets.Name = "Assets";
            this.Assets.Padding = new System.Windows.Forms.Padding(2);
            this.Assets.ReadOnly = true;
            this.Assets.ShowText = false;
            this.Assets.Size = new System.Drawing.Size(200, 53);
            this.Assets.TabIndex = 37;
            this.Assets.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_SerialNumber
            // 
            this.label_SerialNumber.BackColor = System.Drawing.Color.Transparent;
            this.label_SerialNumber.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_SerialNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_SerialNumber.Location = new System.Drawing.Point(324, 166);
            this.label_SerialNumber.Margin = new System.Windows.Forms.Padding(0);
            this.label_SerialNumber.Name = "label_SerialNumber";
            this.label_SerialNumber.Size = new System.Drawing.Size(75, 29);
            this.label_SerialNumber.TabIndex = 28;
            this.label_SerialNumber.Text = "序號";
            this.label_SerialNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Barcode
            // 
            this.label_Barcode.BackColor = System.Drawing.Color.Transparent;
            this.label_Barcode.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Barcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Barcode.Location = new System.Drawing.Point(324, 205);
            this.label_Barcode.Margin = new System.Windows.Forms.Padding(0);
            this.label_Barcode.Name = "label_Barcode";
            this.label_Barcode.Size = new System.Drawing.Size(75, 29);
            this.label_Barcode.TabIndex = 26;
            this.label_Barcode.Text = "條碼";
            this.label_Barcode.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SerialNumber
            // 
            this.SerialNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SerialNumber.FillDisableColor = System.Drawing.Color.White;
            this.SerialNumber.FillReadOnlyColor = System.Drawing.Color.White;
            this.SerialNumber.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.SerialNumber.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.SerialNumber.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.SerialNumber.Location = new System.Drawing.Point(403, 166);
            this.SerialNumber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.SerialNumber.MinimumSize = new System.Drawing.Size(1, 16);
            this.SerialNumber.Name = "SerialNumber";
            this.SerialNumber.Padding = new System.Windows.Forms.Padding(5);
            this.SerialNumber.ReadOnly = true;
            this.SerialNumber.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.SerialNumber.ShowText = false;
            this.SerialNumber.Size = new System.Drawing.Size(200, 29);
            this.SerialNumber.TabIndex = 27;
            this.SerialNumber.TabStop = false;
            this.SerialNumber.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.SerialNumber.Watermark = "";
            // 
            // label_Assets
            // 
            this.label_Assets.BackColor = System.Drawing.Color.Transparent;
            this.label_Assets.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Assets.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Assets.Location = new System.Drawing.Point(324, 103);
            this.label_Assets.Margin = new System.Windows.Forms.Padding(0);
            this.label_Assets.Name = "label_Assets";
            this.label_Assets.Size = new System.Drawing.Size(75, 29);
            this.label_Assets.TabIndex = 24;
            this.label_Assets.Text = "資產編號";
            this.label_Assets.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Barcode
            // 
            this.Barcode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Barcode.FillDisableColor = System.Drawing.Color.White;
            this.Barcode.FillReadOnlyColor = System.Drawing.Color.White;
            this.Barcode.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Barcode.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Barcode.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Barcode.Location = new System.Drawing.Point(403, 205);
            this.Barcode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Barcode.MinimumSize = new System.Drawing.Size(1, 16);
            this.Barcode.Name = "Barcode";
            this.Barcode.Padding = new System.Windows.Forms.Padding(5);
            this.Barcode.ReadOnly = true;
            this.Barcode.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Barcode.ShowText = false;
            this.Barcode.Size = new System.Drawing.Size(200, 29);
            this.Barcode.TabIndex = 25;
            this.Barcode.TabStop = false;
            this.Barcode.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Barcode.Watermark = "";
            // 
            // label_Location
            // 
            this.label_Location.BackColor = System.Drawing.Color.Transparent;
            this.label_Location.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Location.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Location.Location = new System.Drawing.Point(23, 244);
            this.label_Location.Margin = new System.Windows.Forms.Padding(0);
            this.label_Location.Name = "label_Location";
            this.label_Location.Size = new System.Drawing.Size(76, 29);
            this.label_Location.TabIndex = 22;
            this.label_Location.Text = "位置";
            this.label_Location.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_Brand
            // 
            this.label_Brand.BackColor = System.Drawing.Color.Transparent;
            this.label_Brand.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Brand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Brand.Location = new System.Drawing.Point(23, 205);
            this.label_Brand.Margin = new System.Windows.Forms.Padding(0);
            this.label_Brand.Name = "label_Brand";
            this.label_Brand.Size = new System.Drawing.Size(76, 29);
            this.label_Brand.TabIndex = 20;
            this.label_Brand.Text = "廠牌";
            this.label_Brand.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Location
            // 
            this.Location.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Location.FillDisableColor = System.Drawing.Color.White;
            this.Location.FillReadOnlyColor = System.Drawing.Color.White;
            this.Location.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Location.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Location.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Location.Location = new System.Drawing.Point(103, 244);
            this.Location.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Location.MinimumSize = new System.Drawing.Size(1, 16);
            this.Location.Name = "Location";
            this.Location.Padding = new System.Windows.Forms.Padding(5);
            this.Location.ReadOnly = true;
            this.Location.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Location.ShowText = false;
            this.Location.Size = new System.Drawing.Size(200, 29);
            this.Location.TabIndex = 21;
            this.Location.TabStop = false;
            this.Location.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Location.Watermark = "";
            // 
            // Brand
            // 
            this.Brand.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Brand.FillDisableColor = System.Drawing.Color.White;
            this.Brand.FillReadOnlyColor = System.Drawing.Color.White;
            this.Brand.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Brand.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Brand.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Brand.Location = new System.Drawing.Point(103, 205);
            this.Brand.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Brand.MinimumSize = new System.Drawing.Size(1, 16);
            this.Brand.Name = "Brand";
            this.Brand.Padding = new System.Windows.Forms.Padding(5);
            this.Brand.ReadOnly = true;
            this.Brand.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Brand.ShowText = false;
            this.Brand.Size = new System.Drawing.Size(200, 29);
            this.Brand.TabIndex = 19;
            this.Brand.TabStop = false;
            this.Brand.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Brand.Watermark = "";
            // 
            // label_Condition
            // 
            this.label_Condition.BackColor = System.Drawing.Color.Transparent;
            this.label_Condition.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Condition.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Condition.Location = new System.Drawing.Point(22, 166);
            this.label_Condition.Margin = new System.Windows.Forms.Padding(0);
            this.label_Condition.Name = "label_Condition";
            this.label_Condition.Size = new System.Drawing.Size(76, 29);
            this.label_Condition.TabIndex = 18;
            this.label_Condition.Text = "狀態";
            this.label_Condition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Condition
            // 
            this.Condition.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Condition.FillDisableColor = System.Drawing.Color.White;
            this.Condition.FillReadOnlyColor = System.Drawing.Color.White;
            this.Condition.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Condition.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Condition.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Condition.Location = new System.Drawing.Point(103, 166);
            this.Condition.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Condition.MinimumSize = new System.Drawing.Size(1, 16);
            this.Condition.Name = "Condition";
            this.Condition.Padding = new System.Windows.Forms.Padding(5);
            this.Condition.ReadOnly = true;
            this.Condition.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Condition.ShowText = false;
            this.Condition.Size = new System.Drawing.Size(200, 29);
            this.Condition.TabIndex = 17;
            this.Condition.TabStop = false;
            this.Condition.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Condition.Watermark = "";
            // 
            // label_Type
            // 
            this.label_Type.BackColor = System.Drawing.Color.Transparent;
            this.label_Type.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Type.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Type.Location = new System.Drawing.Point(22, 88);
            this.label_Type.Margin = new System.Windows.Forms.Padding(0);
            this.label_Type.Name = "label_Type";
            this.label_Type.Size = new System.Drawing.Size(76, 29);
            this.label_Type.TabIndex = 14;
            this.label_Type.Text = "設備別";
            this.label_Type.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Type
            // 
            this.Type.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Type.FillDisableColor = System.Drawing.Color.White;
            this.Type.FillReadOnlyColor = System.Drawing.Color.White;
            this.Type.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Type.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Type.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Type.Location = new System.Drawing.Point(103, 88);
            this.Type.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Type.MinimumSize = new System.Drawing.Size(1, 16);
            this.Type.Name = "Type";
            this.Type.Padding = new System.Windows.Forms.Padding(5);
            this.Type.ReadOnly = true;
            this.Type.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Type.ShowText = false;
            this.Type.Size = new System.Drawing.Size(200, 29);
            this.Type.TabIndex = 13;
            this.Type.TabStop = false;
            this.Type.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Type.Watermark = "";
            // 
            // label_Catelogry
            // 
            this.label_Catelogry.BackColor = System.Drawing.Color.Transparent;
            this.label_Catelogry.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_Catelogry.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_Catelogry.Location = new System.Drawing.Point(22, 49);
            this.label_Catelogry.Margin = new System.Windows.Forms.Padding(0);
            this.label_Catelogry.Name = "label_Catelogry";
            this.label_Catelogry.Size = new System.Drawing.Size(76, 29);
            this.label_Catelogry.TabIndex = 12;
            this.label_Catelogry.Text = "分類";
            this.label_Catelogry.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label_MachineId
            // 
            this.label_MachineId.BackColor = System.Drawing.Color.Transparent;
            this.label_MachineId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.label_MachineId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.label_MachineId.Location = new System.Drawing.Point(22, 10);
            this.label_MachineId.Margin = new System.Windows.Forms.Padding(0);
            this.label_MachineId.Name = "label_MachineId";
            this.label_MachineId.Size = new System.Drawing.Size(76, 29);
            this.label_MachineId.TabIndex = 10;
            this.label_MachineId.Text = "編號";
            this.label_MachineId.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Catelogry
            // 
            this.Catelogry.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Catelogry.FillDisableColor = System.Drawing.Color.White;
            this.Catelogry.FillReadOnlyColor = System.Drawing.Color.White;
            this.Catelogry.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Catelogry.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.Catelogry.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Catelogry.Location = new System.Drawing.Point(103, 49);
            this.Catelogry.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Catelogry.MinimumSize = new System.Drawing.Size(1, 16);
            this.Catelogry.Name = "Catelogry";
            this.Catelogry.Padding = new System.Windows.Forms.Padding(5);
            this.Catelogry.ReadOnly = true;
            this.Catelogry.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.Catelogry.ShowText = false;
            this.Catelogry.Size = new System.Drawing.Size(200, 29);
            this.Catelogry.TabIndex = 11;
            this.Catelogry.TabStop = false;
            this.Catelogry.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.Catelogry.Watermark = "";
            // 
            // MaincheId
            // 
            this.MaincheId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaincheId.FillDisableColor = System.Drawing.Color.White;
            this.MaincheId.FillReadOnlyColor = System.Drawing.Color.White;
            this.MaincheId.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.MaincheId.ForeDisableColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.MaincheId.ForeReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.MaincheId.Location = new System.Drawing.Point(103, 10);
            this.MaincheId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaincheId.MinimumSize = new System.Drawing.Size(1, 16);
            this.MaincheId.Name = "MaincheId";
            this.MaincheId.Padding = new System.Windows.Forms.Padding(5);
            this.MaincheId.ReadOnly = true;
            this.MaincheId.RectReadOnlyColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.MaincheId.ShowText = false;
            this.MaincheId.Size = new System.Drawing.Size(200, 29);
            this.MaincheId.TabIndex = 9;
            this.MaincheId.TabStop = false;
            this.MaincheId.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.MaincheId.Watermark = "";
            // 
            // adgv
            // 
            this.adgv.AllowUserToAddRows = false;
            this.adgv.AllowUserToDeleteRows = false;
            this.adgv.AllowUserToResizeRows = false;
            this.adgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.adgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adgv.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.adgv.FilterAndSortEnabled = true;
            this.adgv.FilterStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.Location = new System.Drawing.Point(228, 3);
            this.adgv.MaxFilterButtonImageHeight = 23;
            this.adgv.MultiSelect = false;
            this.adgv.Name = "adgv";
            this.adgv.ReadOnly = true;
            this.adgv.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.adgv.RowTemplate.Height = 24;
            this.adgv.Size = new System.Drawing.Size(923, 379);
            this.adgv.SortStringChangedInvokeBeforeDatasourceUpdate = true;
            this.adgv.TabIndex = 10;
            // 
            // Setup_MachinesSummary
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.tableLayoutPanel_Page);
            this.Font = new System.Drawing.Font("微軟正黑體", 11F);
            this.Name = "Setup_MachinesSummary";
            this.Size = new System.Drawing.Size(1154, 675);
            this.Load += new System.EventHandler(this.Setup_MachinesSummary_Load);
            this.tableLayoutPanel_Page.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.adgv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel_Page;
        private Sunny.UI.UITreeView list_Catelogries;
        private Zuby.ADGV.AdvancedDataGridView adgv;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private Sunny.UI.UISymbolButton Machine_Create;
        private Sunny.UI.UISymbolButton Machine_Edit;
        private Sunny.UI.UISymbolButton Machine_Delete;
        private Sunny.UI.UILabel label_Remark;
        private Sunny.UI.UIRichTextBox Remark;
        private Sunny.UI.UILabel label_Connected;
        private Sunny.UI.UILabel label_Disposal;
        private Sunny.UI.UITextBox Connected;
        private Sunny.UI.UITextBox Disposal;
        private Sunny.UI.UIRichTextBox Assets;
        private Sunny.UI.UILabel label_SerialNumber;
        private Sunny.UI.UILabel label_Barcode;
        private Sunny.UI.UITextBox SerialNumber;
        private Sunny.UI.UILabel label_Assets;
        private Sunny.UI.UITextBox Barcode;
        private Sunny.UI.UILabel label_Location;
        private Sunny.UI.UILabel label_Brand;
        private Sunny.UI.UITextBox Location;
        private Sunny.UI.UITextBox Brand;
        private Sunny.UI.UILabel label_Condition;
        private Sunny.UI.UITextBox Condition;
        private Sunny.UI.UILabel label_Type;
        private Sunny.UI.UITextBox Type;
        private Sunny.UI.UILabel label_Catelogry;
        private Sunny.UI.UILabel label_MachineId;
        private Sunny.UI.UITextBox Catelogry;
        private Sunny.UI.UITextBox MaincheId;
        private Sunny.UI.UILabel label_ModeName;
        private Sunny.UI.UITextBox ModeName;
        private Sunny.UI.UILabel label_Workstations;
        private Sunny.UI.UITextBox Workstations;
    }
}
