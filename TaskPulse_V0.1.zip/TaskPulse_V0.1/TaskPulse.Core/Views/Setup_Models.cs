﻿/*
 * 編輯後ListBox不會更新的問題
 * 
 */

using System;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.SharedUI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Models : UserControl
    {
        #region fields

        private readonly CoreContext _context;
        private readonly CRUD _crud;

        #endregion fields

        public Setup_Models(CoreContext coreContext,
                            CRUD crud)
        {
            InitializeComponent();
            _context = coreContext;
            _crud = crud;

            string itemName = PropertyText.Title.ModelName;
            Label_Model.Text = PropertyText.Title.ModelName;
            CommonStyles.SetListBox(List_Models);
            CommonStyles.SetCrudButton(Model_Create, $"C", itemName);
            CommonStyles.SetCrudButton(Model_Edit, $"E", itemName);
            CommonStyles.SetCrudButton(Model_Modify, $"M", PropertyText.Title.ModelStatus);

            itemName = PropertyText.Title.Workstation;
            Label_Workstation.Text = PropertyText.Title.Workstation;
            CommonStyles.SetListBox(List_Workstations);
            CommonStyles.SetCrudButton(Workstation_Create, $"C", itemName);
            CommonStyles.SetCrudButton(Workstation_Edit, $"E", itemName);
            CommonStyles.SetCrudButton(Workstation_Delete, $"D", itemName);
            CommonStyles.SetCrudButton(Workstation_Up, $"UP", itemName);
            CommonStyles.SetCrudButton(Workstation_Down, $"DOWN", itemName);

            itemName = PropertyText.Title.ModelStatus;
            Label_ModelStatus.Text = PropertyText.Title.ModelStatus;
            CommonStyles.SetListBox(List_Workstations);
            CommonStyles.SetCrudButton(ModelStatus_Create, $"C", itemName);
            CommonStyles.SetCrudButton(ModelStatus_Edit, $"E", itemName);
            CommonStyles.SetCrudButton(ModelStatus_Delete, $"D", itemName);
            CommonStyles.SetCrudButton(ModelStatus_Up, $"UP", itemName);
            CommonStyles.SetCrudButton(ModelStatus_Down, $"DOWN", itemName);
        }

        private void Setup_Models_Load(object sender, EventArgs e)
        {
        }

    }
}
