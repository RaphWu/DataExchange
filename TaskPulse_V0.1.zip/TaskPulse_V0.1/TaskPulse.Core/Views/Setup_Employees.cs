﻿using System;
using System.Data;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Models;
using Calin.TaskPulse.Core.NavServices;
using Calin.TaskPulse.Core.SharedUI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Employees : UserControl
    {
        #region fields

        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly CoreContext _context;
        private readonly CoreData _coreData;
        private readonly MultiSelector _mSel;

        private DataTable _dt;
        private DataGridViewComboBoxColumn dgvComboBox;
        private BindingSource _bs = new BindingSource();

        #endregion fields

        public Setup_Employees(IRegionManager regionManager,
                               INavigationService navigationService,
                               CoreContext coreContext,
                               CoreData coreData,
                               MultiSelector multiSelector)
        {
            InitializeComponent();
            _region = regionManager;
            _nav = navigationService;
            _context = coreContext;
            _coreData = coreData;
            _mSel = multiSelector;

            _region.RegisterRegion(nameof(panelPermission), panelPermission);

            // adgv
            _dt = new DataTable();
            _dt.Columns.Add(PropertyText.Name.EmployeeId, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Department, typeof(string));
            _dt.Columns.Add(PropertyText.Name.JobTitle, typeof(string));
            _dt.Columns.Add(PropertyText.Name.EmployeeName, typeof(string));
            _dt.Columns.Add(PropertyText.Name.Email, typeof(string));
            _dt.Columns.Add(PropertyText.Name.IsEngineer, typeof(bool));
            _dt.Columns.Add(PropertyText.Name.EmployeeStatus, typeof(bool));
            _dt.Columns.Add(PropertyText.Name.StatusChangeAt, typeof(DateTime));

            CommonStyles.SetAdvancedDataGridView(adgv, true);
            CommonStyles.SetButton(btnSave);
            CommonStyles.SetListBox(Status);
            CommonStyles.SetCheckBox(IsEngineer);
            CommonStyles.SetButton(CarbonCopies);
        }

    }
}
