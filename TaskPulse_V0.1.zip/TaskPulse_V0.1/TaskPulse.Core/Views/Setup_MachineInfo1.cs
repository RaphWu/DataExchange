﻿using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineInfo1 : UserControl
    {
        #region fields

        private readonly ILifetimeScope _scope;

        #endregion fields

        public Setup_MachineInfo1(ILifetimeScope lifetimeScope, CoreContext coreContext)
        {
            InitializeComponent();
            _scope = lifetimeScope;

            string itemName = PropertyText.Title.Brand;
            HeadLabel_Brand.Text = itemName;
            CommonStyles.SetListBox(List_Brands);
            CommonStyles.SetCrudButton(Brand_Create, "C", itemName);
            CommonStyles.SetCrudButton(Brand_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Brand_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Brand_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Brand_Down, "DOWN", itemName);

            itemName = PropertyText.Title.Location;
            HeadLabel_Location.Text = itemName;
            CommonStyles.SetListBox(List_Locations);
            CommonStyles.SetCrudButton(Location_Create, "C", itemName);
            CommonStyles.SetCrudButton(Location_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Location_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Location_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Location_Down, "DOWN", itemName);

            itemName = PropertyText.Title.Condition;
            HeadLabel_Condition.Text = itemName;
            CommonStyles.SetListBox(List_Conditions);
            CommonStyles.SetCrudButton(Condition_Create, "C", itemName);
            CommonStyles.SetCrudButton(Condition_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Condition_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Condition_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Condition_Down, "DOWN", itemName);
        }

    }
}
