﻿using System;
using System.Windows.Forms;
using Autofac;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_MachineInfo2 : UserControl
    {
        #region fields

        private readonly ILifetimeScope _scope;

        #endregion fields

        public Setup_MachineInfo2(ILifetimeScope lifetimeScope,
                                  CoreContext coreContext,
                                  CoreData coreData)
        {
            InitializeComponent();
            _scope = lifetimeScope;

            string itemName = PropertyText.Title.MachineCategory;
            HeadLabel_Category.Text = itemName;
            CommonStyles.SetListBox(List_Categories);
            CommonStyles.SetCrudButton(Category_Create, "C", itemName);
            CommonStyles.SetCrudButton(Category_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Category_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Category_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Category_Down, "DOWN", itemName);

            itemName = PropertyText.Title.MachineType;
            HeadLabel_Type.Text = itemName;
            CommonStyles.SetListBox(List_Types);
            CommonStyles.SetCrudButton(Type_Create, "C", itemName);
            CommonStyles.SetCrudButton(Type_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Type_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Type_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Type_Down, "DOWN", itemName);

            itemName = PropertyText.Title.MachineName;
            HeadLabel_Name.Text = itemName;
            CommonStyles.SetListBox(List_Names);
            CommonStyles.SetCrudButton(Name_Create, "C", itemName);
            CommonStyles.SetCrudButton(Name_Edit, "E", itemName);
            CommonStyles.SetCrudButton(Name_Delete, "D", itemName);
            CommonStyles.SetCrudButton(Name_Up, "UP", itemName);
            CommonStyles.SetCrudButton(Name_Down, "DOWN", itemName);
        }

        private async void Setup_MachineInfo2_Load(object sender, EventArgs e)
        {
        }

    }
}
