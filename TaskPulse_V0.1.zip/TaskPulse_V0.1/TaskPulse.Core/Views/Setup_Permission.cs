﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Contracts;
using Calin.TaskPulse.Core.Events;
using Calin.TaskPulse.Core.Messaging;
using Calin.TaskPulse.Core.Models;
using Sunny.UI;

namespace Calin.TaskPulse.Core.Views
{
    public partial class Setup_Permission : UserControl, IDisposable
    {
        #region fields

        private const int SYMBOL_CHECK = 61510;
        private const int SYMBOL_UNCHECK = 559445;

        private string _prefix;

        private PermissionSource _permissionSource;
        private HashSet<PermissionData> _permTable;

        private int _rSymbolToolQuest = SYMBOL_UNCHECK;
        private int _rSymbolMechaTrack = SYMBOL_UNCHECK;
        private int _rSymbolMaintiFlow = SYMBOL_UNCHECK;
        private int _rSymbolSetup = SYMBOL_UNCHECK;

        #endregion fields

        public Setup_Permission(CoreContext coreContext,
                                CurrentUserContext currentUserContext,
                                ICurrentUserService currentUserService,
                                IPermissionService permissionService)
        {
            InitializeComponent();

            UISetup(this.Controls);

            Messenger.Default.Register<PermissionSettingPageMessage>(this, msg =>
            {
                //SourceTargetChange(msg.Value);
            });

            NM_Permission.SelectedColor = CommonStyles.AccentColor;
            NM_Permission.SelectedNode = NM_Permission.Nodes[NM_Permission.Nodes.Count - 1];
            TC_Permission.SelectedTab = TP_Setup;

            foreach (var ctl in TP_MaintiFlow.Controls)
            {
                if (ctl is UICheckBox cb)
                {
                    cb.CheckedChanged += (s, e) =>
                    {
                        UICheckBox uICheckBox = s as UICheckBox;
                        if (uICheckBox.Checked)
                        {
                            _rSymbolMaintiFlow = SYMBOL_CHECK;
                            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[2]);
                            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[2], SYMBOL_CHECK);
                        }

                        bool hasChecked = CBr_MaintiFlowSummy.Checked ||
                                          CBe_MaintiFlowSummy.Checked ||
                                          CBe_Create.Checked ||
                                          CBe_Cancel.Checked ||
                                          CBe_Accept.Checked ||
                                          CBe_Maintant.Checked ||
                                          CBe_Confirm.Checked;
                        if (!hasChecked)
                        {
                            _rSymbolMaintiFlow = SYMBOL_UNCHECK;
                            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[3]);
                            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[3], SYMBOL_UNCHECK);
                        }
                    };
                }
            }

            foreach (var ctl in TP_Setup.Controls)
            {
                if (ctl is UICheckBox cb)
                {
                    cb.CheckedChanged += (s, e) =>
                    {
                        UICheckBox uICheckBox = s as UICheckBox;
                        if (uICheckBox.Checked)
                        {
                            _rSymbolSetup = SYMBOL_CHECK;
                            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[3]);
                            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[3], SYMBOL_CHECK);
                        }

                        bool hasChecked = CBr_MachineManager.Checked ||
                                          CBe_MachineManager.Checked ||
                                          CBr_EmployeeManager.Checked ||
                                          CBe_EmployeeManager.Checked;
                        if (!hasChecked)
                        {
                            _rSymbolMaintiFlow = SYMBOL_UNCHECK;
                            NM_Permission.ClearNodeRightSymbol(NM_Permission.Nodes[3]);
                            NM_Permission.AddNodeRightSymbol(NM_Permission.Nodes[3], SYMBOL_UNCHECK);
                        }
                    };
                }
            }
        }

        private void UISetup(ControlCollection controls)
        {
            CommonStyles.SetButton(btn_Save);

            foreach (Control control in controls)
            {
                if (control is UITitlePanel tp)
                {
                    tp.TitleColor = CommonStyles.BackColor;
                }

                if (control is UICheckBox cb)
                {
                    CommonStyles.SetCheckBox(cb);
                }
                else if (control is UIButton btn)
                {
                    CommonStyles.SetButton(btn);
                }
                else if (control is UILine line)
                {
                    line.LineColor = CommonStyles.BackColor;
                }
                else if (control.HasChildren)
                {
                    UISetup(control.Controls);
                }
            }
        }

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                components?.Dispose();
                Messenger.Default.UnregisterAll(this);
            }
            base.Dispose(disposing);
        }

    }
}
