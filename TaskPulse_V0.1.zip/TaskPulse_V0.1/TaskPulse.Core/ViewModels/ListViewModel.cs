﻿namespace Calin.TaskPulse.Core.ViewModels
{
    /// <summary>
    /// 表示清單視圖的資料模型。
    /// </summary>
    public class ListViewModel
    {
        /// <summary>
        /// 取得或設定整數識別碼。
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 取得或設定可為 null 的整數識別碼。
        /// </summary>
        public int? NullableId { get; set; }

        /// <summary>
        /// 取得或設定字串識別碼。
        /// </summary>
        public string IdString { get; set; }

        /// <summary>
        /// 取得或設定布林值識別碼。
        /// </summary>
        public bool BooleanId { get; set; }

        /// <summary>
        /// 取得或設定排序編號。
        /// </summary>
        public int OrderNo { get; set; }

        /// <summary>
        /// 取得或設定名稱。
        /// </summary>
        public string Name { get; set; }
    }
}
