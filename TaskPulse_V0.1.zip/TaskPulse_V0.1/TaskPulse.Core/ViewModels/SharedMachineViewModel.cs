using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using Calin.TaskPulse.Core.DTO;

namespace Calin.TaskPulse.Core.ViewModels
{
    /// <summary>
    /// ���x�@�� ViewModel - �h�� View �i�P�ɦ@�ΨçY�ɦP�B�C
    /// </summary>
    public class SharedMachineViewModel : INotifyPropertyChanged
    {
        private int _id;
        private string _machineCode;
        private int _machineNameId;
        private string _machineName;
        private int _conditionId;
        private string _conditionName;
        private int? _brandId;
        private string _brandName;
        private int? _locationId;
        private string _locationName;
        private string _assets;
        private string _serialNumber;
        private string _barcode;
        private bool _connected;
        private bool _disposal;
        private string _remark;
        private ObservableCollection<int> _workstationIds;

        #region ���ݩ�

        /// <summary>
        /// ���o�γ]�w���x���ߤ@�ѧO�X�C
        /// </summary>
        public int Id
        {
            get => _id;
            set => SetProperty(ref _id, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�N�X�C
        /// </summary>
        public string MachineCode
        {
            get => _machineCode;
            set => SetProperty(ref _machineCode, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�W�٪��ѧO�X�C
        /// </summary>
        public int MachineNameId
        {
            get => _machineNameId;
            set => SetProperty(ref _machineNameId, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�W�١C
        /// </summary>
        public string MachineName
        {
            get => _machineName;
            set => SetProperty(ref _machineName, value);
        }

        /// <summary>
        /// ���o�γ]�w���x���A���ѧO�X�C
        /// </summary>
        public int ConditionId
        {
            get => _conditionId;
            set => SetProperty(ref _conditionId, value);
        }

        /// <summary>
        /// ���o�γ]�w���x���A�W�١C
        /// </summary>
        public string ConditionName
        {
            get => _conditionName;
            set => SetProperty(ref _conditionName, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�~�P���ѧO�X�C
        /// </summary>
        public int? BrandId
        {
            get => _brandId;
            set => SetProperty(ref _brandId, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�~�P�W�١C
        /// </summary>
        public string BrandName
        {
            get => _brandName;
            set => SetProperty(ref _brandName, value);
        }

        /// <summary>
        /// ���o�γ]�w���x��m���ѧO�X�C
        /// </summary>
        public int? LocationId
        {
            get => _locationId;
            set => SetProperty(ref _locationId, value);
        }

        /// <summary>
        /// ���o�γ]�w���x��m�W�١C
        /// </summary>
        public string LocationName
        {
            get => _locationName;
            set => SetProperty(ref _locationName, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�겣�s���C
        /// </summary>
        public string Assets
        {
            get => _assets;
            set => SetProperty(ref _assets, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�Ǹ��C
        /// </summary>
        public string SerialNumber
        {
            get => _serialNumber;
            set => SetProperty(ref _serialNumber, value);
        }

        /// <summary>
        /// ���o�γ]�w���x���X�C
        /// </summary>
        public string Barcode
        {
            get => _barcode;
            set => SetProperty(ref _barcode, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�O�_�w�s�u�C
        /// </summary>
        public bool Connected
        {
            get => _connected;
            set => SetProperty(ref _connected, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�O�_�w���o�C
        /// </summary>
        public bool Disposal
        {
            get => _disposal;
            set => SetProperty(ref _disposal, value);
        }

        /// <summary>
        /// ���o�γ]�w���x�Ƶ��C
        /// </summary>
        public string Remark
        {
            get => _remark;
            set => SetProperty(ref _remark, value);
        }

        #endregion

        #region �h��h���Y

        /// <summary>
        /// ���o�γ]�w���x���p���u�@���ѧO�X���X�C
        /// </summary>
        public ObservableCollection<int> WorkstationIds
        {
            get => _workstationIds;
            set
            {
                if (_workstationIds != null)
                {
                    _workstationIds.CollectionChanged -= OnCollectionChanged;
                }
                SetProperty(ref _workstationIds, value);
                if (_workstationIds != null)
                {
                    _workstationIds.CollectionChanged += OnCollectionChanged;
                }
            }
        }

        #endregion

        #region �غc�禡

        /// <summary>
        /// ��l�� <see cref="SharedMachineViewModel"/> ���O���s�������C
        /// </summary>
        public SharedMachineViewModel()
        {
            _workstationIds = new ObservableCollection<int>();
            _workstationIds.CollectionChanged += OnCollectionChanged;
        }

        /// <summary>
        /// �ϥΫ��w�� DTO ��l�� <see cref="SharedMachineViewModel"/> ���O���s�������C
        /// </summary>
        /// <param name="dto">�]�t���x��ƪ� DTO ����C</param>
        public SharedMachineViewModel(MachineDto dto) : this()
        {
            if (dto == null) return;
            LoadFromDto(dto);
        }

        #endregion

        #region DTO �ഫ

        /// <summary>
        /// �q DTO ������J���x��Ʀܥثe�� ViewModel�C
        /// </summary>
        /// <param name="dto">�]�t���x��ƪ� DTO ����C</param>
        public void LoadFromDto(MachineDto dto)
        {
            if (dto == null) return;

            Id = dto.Id;
            MachineCode = dto.MachineCode;
            MachineNameId = dto.MachineNameId;
            MachineName = dto.MachineModelNo;
            ConditionId = dto.ConditionId;
            ConditionName = dto.ConditionName;
            BrandId = dto.BrandId;
            BrandName = dto.BrandName;
            LocationId = dto.LocationId;
            LocationName = dto.LocationName;
            Assets = dto.Assets;
            SerialNumber = dto.SerialNumber;
            Barcode = dto.Barcode;
            Connected = dto.Connected;
            Disposal = dto.Disposal;
            Remark = dto.Remark;

            if (dto.WorkstationIds != null)
            {
                WorkstationIds = new ObservableCollection<int>(dto.WorkstationIds);
            }
        }

        /// <summary>
        /// �N�ثe�� ViewModel �ഫ�� DTO ����C
        /// </summary>
        /// <returns>�]�t���x��ƪ� DTO ����C</returns>
        public MachineDto ToDto()
        {
            return new MachineDto
            {
                Id = Id,
                MachineCode = MachineCode,
                MachineNameId = MachineNameId,
                MachineModelNo = MachineName,
                ConditionId = ConditionId,
                ConditionName = ConditionName,
                BrandId = BrandId,
                BrandName = BrandName,
                LocationId = LocationId,
                LocationName = LocationName,
                Assets = Assets,
                SerialNumber = SerialNumber,
                Barcode = Barcode,
                Connected = Connected,
                Disposal = Disposal,
                Remark = Remark,
                WorkstationIds = WorkstationIds?.ToList()
            };
        }

        #endregion

        #region INotifyPropertyChanged

        /// <summary>
        /// ���ݩʭ��ܧ�ɵo�͡C
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// �޵o <see cref="PropertyChanged"/> �ƥ�C
        /// </summary>
        /// <param name="propertyName">�w�ܧ��ݩʪ��W�١C</param>
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// �]�w�ݩʭȨæb���ܧ�ɤ޵o <see cref="PropertyChanged"/> �ƥ�C
        /// </summary>
        /// <typeparam name="T">�ݩʪ����O�C</typeparam>
        /// <param name="storage">�ݩʪ�������ѦҡC</param>
        /// <param name="value">�n�]�w���s�ȡC</param>
        /// <param name="propertyName">�ݩʪ��W�١C</param>
        /// <returns>�p�G�Ȥw�ܧ�h�� <c>true</c>�A�_�h�� <c>false</c>�C</returns>
        protected bool SetProperty<T>(ref T storage, T value, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(storage, value))
                return false;

            storage = value;
            OnPropertyChanged(propertyName);
            return true;
        }

        /// <summary>
        /// �B�z���X�ܧ�ƥ�A�ä޵o <see cref="PropertyChanged"/> �ƥ�C
        /// </summary>
        /// <param name="sender">�ƥ�ӷ��C</param>
        /// <param name="e">�]�t�ƥ��ƪ�����C</param>
        private void OnCollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged(nameof(WorkstationIds));
        }

        #endregion
    }
}
