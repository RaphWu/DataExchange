# BaseViewModelUserControl �ϥΫ��n

## ���z

`BaseViewModelUserControl<TViewModel>` �O `BaseViewModelForm<TViewModel>` �� UserControl �����A���ѬۦP�� ViewModel �j�w�\��C

---

## �P BaseViewModelForm ���t��

| �S�� | BaseViewModelForm | BaseViewModelUserControl |
|------|-------------------|--------------------------|
| **�����O** | `Form` | `UserControl` |
| **�ͩR�g��** | `OnFormClosing` | `Dispose` |
| **�γ~** | �W�ߵ��� | �i���Τ��� |
| **��L** | �����ۦP | �����ۦP |

---

## �ֳt�}�l

### �B�J 1�G�إ� UserControl �~�Ӱ����O

```csharp
public partial class EmployeeInfoControl : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    public EmployeeInfoControl()
    {
        InitializeComponent();
    }
}
```

### �B�J 2�G��@ OnViewModelBound

```csharp
protected override void OnViewModelBound()
{
    BindTextBox(txtName, nameof(ViewModel.EmployeeName));
    BindTextBox(txtEmail, nameof(ViewModel.Email));
    BindCheckBox(chkIsEngineer, nameof(ViewModel.IsEngineer));
}
```

### �B�J 3�G�b Form �Ψ�L UserControl ���ϥ�

```csharp
public class MainForm : Form
{
    private EmployeeInfoControl _infoControl;
    private readonly ISharedViewModelManager _viewModelManager;
    
    public MainForm(ISharedViewModelManager viewModelManager)
    {
        InitializeComponent();
        _viewModelManager = viewModelManager;
        
        // �إ� UserControl
        _infoControl = new EmployeeInfoControl();
        this.Controls.Add(_infoControl);
    }
    
    public void LoadEmployee(int employeeId)
    {
        // ���o ViewModel
        var vm = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);
        
        // �j�w�� UserControl
        _infoControl.BindViewModel(vm);
    }
}
```

---

## �ϥγ���

### ���� 1�G�i���Ϊ���ܤ���

```csharp
// ���u��T��� UserControl�]��Ū�^
public partial class EmployeeDisplayControl : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    public EmployeeDisplayControl()
    {
        InitializeComponent();
    }
    
    protected override void OnViewModelBound()
    {
        // �j�w�� Label�]��Ū�^
        BindLabel(lblId, nameof(ViewModel.EmployeeId));
        BindLabel(lblName, nameof(ViewModel.EmployeeName));
        BindLabel(lblEmail, nameof(ViewModel.Email));
    }
}

// �b���� Form ���ϥ�
var displayControl = new EmployeeDisplayControl();
displayControl.BindViewModel(employeeViewModel);
form.Controls.Add(displayControl);
```

### ���� 2�G�i���Ϊ��s�褸��

```csharp
// ���u�s�� UserControl�]�i�s��^
public partial class EmployeeEditControl : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    private readonly ISharedViewModelManager _viewModelManager;
    
    public EmployeeEditControl(ISharedViewModelManager viewModelManager)
    {
        InitializeComponent();
        _viewModelManager = viewModelManager;
    }
    
    public void LoadEmployee(int employeeId)
    {
        var vm = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);
        BindViewModel(vm);
    }
    
    protected override void OnViewModelBound()
    {
        BindTextBox(txtName, nameof(ViewModel.EmployeeName));
        BindTextBox(txtEmail, nameof(ViewModel.Email));
        BindCheckBox(chkIsEngineer, nameof(ViewModel.IsEngineer));
    }
}
```

### ���� 3�G�P�@�� ViewModel�A�h�� UserControl

```csharp
public class EmployeeManagementForm : Form
{
    private EmployeeEditControl _editControl;
    private EmployeeDisplayControl _displayControl;
    private readonly ISharedViewModelManager _viewModelManager;
    
    public void LoadEmployee(int employeeId)
    {
        // ���o�@�� ViewModel
        var vm = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);
        
        // �j�w��h�� UserControl
        _editControl.BindViewModel(vm);
        _displayControl.BindViewModel(vm);
        
        // �b _editControl �s��A_displayControl �Y�ɧ�s�I
    }
}
```

### ���� 4�G�_�� UserControl

```csharp
// �D UserControl �]�t�h�Ӥl UserControl
public partial class EmployeeDetailPanel : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    private EmployeeInfoControl _infoControl;
    private EmployeePermissionControl _permissionControl;
    
    public EmployeeDetailPanel()
    {
        InitializeComponent();
        
        _infoControl = new EmployeeInfoControl();
        _permissionControl = new EmployeePermissionControl();
        
        this.Controls.Add(_infoControl);
        this.Controls.Add(_permissionControl);
    }
    
    protected override void OnViewModelBound()
    {
        // �N ViewModel �ǻ����l UserControl
        _infoControl.BindViewModel(ViewModel);
        _permissionControl.BindViewModel(ViewModel);
    }
    
    protected override void OnViewModelUnbound()
    {
        // �Ѱ��l����j�w
        _infoControl.UnbindViewModel();
        _permissionControl.UnbindViewModel();
        
        base.OnViewModelUnbound();
    }
}
```

### ���� 5�G�ʺA���J UserControl

```csharp
public class DynamicContentForm : Form
{
    private Panel _contentPanel;
    private readonly ISharedViewModelManager _viewModelManager;
    
    public void ShowEmployeeEdit(int employeeId)
    {
        // �M���ª����e
        _contentPanel.Controls.Clear();
        
        // �إ߷s�� UserControl
        var editControl = new EmployeeEditControl(_viewModelManager);
        editControl.Dock = DockStyle.Fill;
        editControl.LoadEmployee(employeeId);
        
        // �[�J�� Panel
        _contentPanel.Controls.Add(editControl);
    }
    
    public void ShowMachineInfo(int machineId)
    {
        _contentPanel.Controls.Clear();
        
        var machineControl = new MachineInfoControl(_viewModelManager);
        machineControl.Dock = DockStyle.Fill;
        machineControl.LoadMachine(machineId);
        
        _contentPanel.Controls.Add(machineControl);
    }
}
```

---

## �i���d��

### ��Ū/�s��Ҧ�����

```csharp
public partial class EmployeeSwitchableControl : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    private bool _isEditMode = false;
    
    public bool IsEditMode
    {
        get => _isEditMode;
        set
        {
            _isEditMode = value;
            UpdateEditMode();
        }
    }
    
    protected override void OnViewModelBound()
    {
        BindTextBox(txtName, nameof(ViewModel.EmployeeName));
        BindTextBox(txtEmail, nameof(ViewModel.Email));
        UpdateEditMode();
    }
    
    private void UpdateEditMode()
    {
        txtName.ReadOnly = !_isEditMode;
        txtEmail.ReadOnly = !_isEditMode;
        btnEdit.Visible = !_isEditMode;
        btnSave.Visible = _isEditMode;
    }
    
    private void btnEdit_Click(object sender, EventArgs e)
    {
        IsEditMode = true;
    }
    
    private void btnSave_Click(object sender, EventArgs e)
    {
        if (!IsViewModelBound) return;
        
        // �x�s�޿�
        IsEditMode = false;
    }
}
```

### �a���Ҫ��s�� UserControl

```csharp
public partial class EmployeeValidatedEditControl : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    private ErrorProvider _errorProvider;
    
    public EmployeeValidatedEditControl()
    {
        InitializeComponent();
        _errorProvider = new ErrorProvider();
    }
    
    protected override void OnViewModelBound()
    {
        BindTextBox(txtName, nameof(ViewModel.EmployeeName));
        BindTextBox(txtEmail, nameof(ViewModel.Email));
        
        // �q�\���Ҩƥ�
        ViewModel.PropertyChanged += OnViewModelPropertyChanged;
    }
    
    protected override void OnViewModelUnbound()
    {
        if (IsViewModelBound)
        {
            ViewModel.PropertyChanged -= OnViewModelPropertyChanged;
        }
        base.OnViewModelUnbound();
    }
    
    private void OnViewModelPropertyChanged(object sender, PropertyChangedEventArgs e)
    {
        // �����޿�
        switch (e.PropertyName)
        {
            case nameof(ViewModel.EmployeeName):
                ValidateName();
                break;
            case nameof(ViewModel.Email):
                ValidateEmail();
                break;
        }
    }
    
    private void ValidateName()
    {
        if (string.IsNullOrWhiteSpace(ViewModel.EmployeeName))
        {
            _errorProvider.SetError(txtName, "�W�٤��i����");
        }
        else
        {
            _errorProvider.SetError(txtName, "");
        }
    }
    
    private void ValidateEmail()
    {
        if (!IsValidEmail(ViewModel.Email))
        {
            _errorProvider.SetError(txtEmail, "Email �榡�����T");
        }
        else
        {
            _errorProvider.SetError(txtEmail, "");
        }
    }
    
    private bool IsValidEmail(string email)
    {
        // Email �����޿�
        return !string.IsNullOrEmpty(email) && email.Contains("@");
    }
}
```

---

## �P DI ��X

### �覡 1�G�غc�禡�`�J�]���ˡ^

```csharp
public partial class EmployeeEditControl : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    private readonly ISharedViewModelManager _viewModelManager;
    private readonly IEmployeeService _employeeService;
    
    // Autofac �|�۰ʪ`�J
    public EmployeeEditControl(
        ISharedViewModelManager viewModelManager,
        IEmployeeService employeeService)
    {
        InitializeComponent();
        _viewModelManager = viewModelManager;
        _employeeService = employeeService;
    }
}

// ���U
builder.RegisterType<EmployeeEditControl>()
    .AsSelf()
    .InstancePerDependency();
```

### �覡 2�G�ݩʪ`�J

```csharp
public partial class EmployeeEditControl : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    // Autofac �|�۰ʳ]�w
    public ISharedViewModelManager ViewModelManager { get; set; }
    public IEmployeeService EmployeeService { get; set; }
    
    public EmployeeEditControl()
    {
        InitializeComponent();
    }
}

// ���U�]�ҥ��ݩʪ`�J�^
builder.RegisterType<EmployeeEditControl>()
    .AsSelf()
    .PropertiesAutowired()
    .InstancePerDependency();
```

### �覡 3�G��ʸѪR�]�b Form ���^

```csharp
public class MainForm : Form
{
    private readonly ILifetimeScope _scope;
    
    public MainForm(ILifetimeScope scope)
    {
        InitializeComponent();
        _scope = scope;
    }
    
    private void ShowEmployeeEdit(int employeeId)
    {
        // �q�e���ѪR UserControl
        var editControl = _scope.Resolve<EmployeeEditControl>();
        editControl.LoadEmployee(employeeId);
        
        this.Controls.Add(editControl);
    }
}
```

---

## �`�N�ƶ�

### ?? �O�o Dispose

```csharp
// UserControl �|�b Dispose �ɦ۰ʸѰ� ViewModel �j�w
// ���p�G��ʫإߡA�O�o��� Dispose

var control = new EmployeeEditControl();
try
{
    // �ϥ� control...
}
finally
{
    control.Dispose(); // �۰ʩI�s UnbindViewModel
}
```

### ?? �_�� UserControl ���j�w����

```csharp
protected override void OnViewModelBound()
{
    // ���j�w�ۤv�����
    BindTextBox(txtName, nameof(ViewModel.EmployeeName));
    
    // �A�j�w�l UserControl
    _childControl.BindViewModel(ViewModel);
}
```

### ?? �ƥ�q�\�n����

```csharp
protected override void OnViewModelUnbound()
{
    // �����Ҧ��ƥ�q�\
    if (IsViewModelBound)
    {
        ViewModel.PropertyChanged -= OnPropertyChanged;
        ViewModel.PermissionIds.CollectionChanged -= OnCollectionChanged;
    }
    
    base.OnViewModelUnbound();
}
```

---

## ������ΡG�{���M�׾�X

### ��y�{���� UserControl

**��y�e�G**
```csharp
public partial class Setup_EmployeeInfo : UserControl
{
    private EmployeeDto _employee;
    
    public void LoadEmployee(EmployeeDto dto)
    {
        _employee = dto;
        
        txtName.Text = dto.EmployeeName;
        txtEmail.Text = dto.Email;
        // ... ��ʳ]�w�C�����
    }
}
```

**��y��G**
```csharp
public partial class Setup_EmployeeInfo : BaseViewModelUserControl<SharedEmployeeViewModel>
{
    private readonly ISharedViewModelManager _viewModelManager;
    
    public Setup_EmployeeInfo(ISharedViewModelManager viewModelManager)
    {
        InitializeComponent();
        _viewModelManager = viewModelManager;
    }
    
    public void LoadEmployee(int employeeId)
    {
        var vm = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);
        BindViewModel(vm);
    }
    
    protected override void OnViewModelBound()
    {
        // �@��d�w�j�w�I
        BindTextBox(txtName, nameof(ViewModel.EmployeeName));
        BindTextBox(txtEmail, nameof(ViewModel.Email));
        // ��Ʒ|�۰ʦP�B
    }
}
```

---

## �����ɮ�

- `TaskPulse.Core/ViewModels/BaseViewModelUserControl.cs` - UserControl �����O
- `TaskPulse.Core/ViewModels/BaseViewModelForm.cs` - Form �����O
- `TaskPulse.Core/Examples/BaseViewModelUserControlExamples.cs` - �ϥνd��
- `TaskPulse.Core/ViewModels/BASEVIEWMODELFORM_GUIDE.md` - Form �������n

---

## �`��

### ? BaseViewModelUserControl �u��

1. **�i����** - �إߤ@���A��B�ϥ�
2. **�զX��** - �i�H�_���զX�h�� UserControl
3. **�Y�ɦP�B** - �h�� UserControl �@�� ViewModel �۰ʦP�B
4. **�Τ@�Ҧ�** - �P BaseViewModelForm �ۦP�� API
5. **DI �䴩** - ���㪺�̿�`�J�䴩

### ?? �ϥήɾ�

| �ϥ� | ���ϥ� |
|------|-------|
| �i���Ϊ� UI ���� | �@���ʪ�²����� |
| �ݭn�զX������ UI | �W�ߪ���ܮ� |
| �ʺA���J�����e�϶� | �R�A���D���� |
| �h�B�ݭn�ۦP��� | ���ݭn�@�ɪ� UI |

### ?? �ֳt�Ѧ�

```csharp
// 1. �~��
public partial class MyControl : BaseViewModelUserControl<MyViewModel>

// 2. ��@
protected override void OnViewModelBound()
{
    BindTextBox(txt, nameof(ViewModel.Property));
}

// 3. �ϥ�
var control = new MyControl();
control.BindViewModel(viewModel);
form.Controls.Add(control);
```
