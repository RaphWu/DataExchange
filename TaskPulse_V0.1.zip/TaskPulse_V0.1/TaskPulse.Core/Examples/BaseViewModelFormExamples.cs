//using System;
//using System.Windows.Forms;
//using Calin.TaskPulse.Core.ViewModels;

//namespace Calin.TaskPulse.Core.Examples
//{
//    /// <summary>
//    /// BaseViewModelForm �ϥνd��
//    /// </summary>
//    public partial class EmployeeEditFormExample : BaseViewModelForm<SharedEmployeeViewModel>
//    {
//        private readonly ISharedViewModelManager _viewModelManager;

//        // �غc�禡�`�J
//        public EmployeeEditFormExample(ISharedViewModelManager viewModelManager)
//        {
//            InitializeComponent();
//            _viewModelManager = viewModelManager;
//        }

//        /// <summary>
//        /// ���J���u���
//        /// </summary>
//        public async System.Threading.Tasks.Task LoadEmployeeAsync(int employeeId)
//        {
//            // ���o ViewModel�]�o�̰��]�w�� DTO�^
//            var viewModel = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);

//            // �j�w ViewModel �����
//            BindViewModel(viewModel);
//        }

//        /// <summary>
//        /// ��@��H��k�G�� ViewModel �j�w������
//        /// </summary>
//        protected override void OnViewModelBound()
//        {
//            // ��k 1�G�ϥλ��U��k�ֳt�j�w
//            BindTextBox(txtEmployeeId, nameof(ViewModel.EmployeeId));
//            BindTextBox(txtEmployeeName, nameof(ViewModel.EmployeeName));
//            BindTextBox(txtEmail, nameof(ViewModel.Email));
//            BindCheckBox(chkIsEngineer, nameof(ViewModel.IsEngineer));

//            // ��k 2�G�ϥγq�θj�w��k�]���F���^
//            BindControl(txtPhone, "Text", nameof(ViewModel.Phone));
//            BindControl(cboStatus, "SelectedValue", nameof(ViewModel.StatusId));

//            // �B�z�h��h���Y�]�v���^
//            ViewModel.PermissionIds.CollectionChanged += OnPermissionsChanged;
//            UpdatePermissionDisplay();
//        }

//        /// <summary>
//        /// �мg�G�� ViewModel �Ѱ��j�w��
//        /// </summary>
//        protected override void OnViewModelUnbound()
//        {
//            // �����q�\�ƥ�
//            if (IsViewModelBound)
//            {
//                ViewModel.PermissionIds.CollectionChanged -= OnPermissionsChanged;
//            }

//            // �I�s�����O�M���j�w
//            base.OnViewModelUnbound();
//        }

//        /// <summary>
//        /// �v�����X�ܧ�B�z
//        /// </summary>
//        private void OnPermissionsChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
//        {
//            UpdatePermissionDisplay();
//        }

//        /// <summary>
//        /// ��s�v�����
//        /// </summary>
//        private void UpdatePermissionDisplay()
//        {
//            if (!IsViewModelBound) return;

//            // ��s CheckedListBox �Ψ�L�v����ܱ��
//            // ...
//        }

//        /// <summary>
//        /// �x�s���s
//        /// </summary>
//        private async void btnSave_Click(object sender, EventArgs e)
//        {
//            if (!IsViewModelBound)
//            {
//                MessageBox.Show("�S���j�w�����");
//                return;
//            }

//            try
//            {
//                // �z�L Service �x�s
//                // var dto = ViewModel.ToDto();
//                // await _employeeService.UpdateEmployeeAsync(dto);

//                MessageBox.Show("�x�s���\�I");
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"�x�s���ѡG{ex.Message}");
//            }
//        }

//        #region Designer Generated Code (���])

//        private TextBox txtEmployeeId;
//        private TextBox txtEmployeeName;
//        private TextBox txtEmail;
//        private TextBox txtPhone;
//        private CheckBox chkIsEngineer;
//        private ComboBox cboStatus;
//        private Button btnSave;

//        private void InitializeComponent()
//        {
//            // Designer �۰ʥͦ�����l�Ƶ{���X
//            this.txtEmployeeId = new TextBox();
//            this.txtEmployeeName = new TextBox();
//            this.txtEmail = new TextBox();
//            this.txtPhone = new TextBox();
//            this.chkIsEngineer = new CheckBox();
//            this.cboStatus = new ComboBox();
//            this.btnSave = new Button();

//            this.btnSave.Text = "�x�s";
//            this.btnSave.Click += btnSave_Click;

//            // ... ��L�����l��
//        }

//        #endregion
//    }

//    // ========================================
//    // ��²�ƪ��d��
//    // ========================================

//    /// <summary>
//    /// ²�ƪ����u�d�ݪ���]��Ū�^
//    /// </summary>
//    public partial class EmployeeViewFormSimple : BaseViewModelForm<SharedEmployeeViewModel>
//    {
//        private readonly ISharedViewModelManager _viewModelManager;

//        public EmployeeViewFormSimple(ISharedViewModelManager viewModelManager)
//        {
//            InitializeComponent();
//            _viewModelManager = viewModelManager;
//        }

//        public void LoadEmployee(int employeeId)
//        {
//            var vm = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);
//            BindViewModel(vm);
//        }

//        protected override void OnViewModelBound()
//        {
//            // �u�ݭn�X��{���X�N�����j�w�I
//            BindTextBox(txtName, nameof(ViewModel.EmployeeName));
//            BindTextBox(txtEmail, nameof(ViewModel.Email));
//            BindLabel(lblStatus, nameof(ViewModel.StatusName));
//            BindCheckBox(chkIsEngineer, nameof(ViewModel.IsEngineer));
//        }

//        #region Designer Code

//        private TextBox txtName;
//        private TextBox txtEmail;
//        private Label lblStatus;
//        private CheckBox chkIsEngineer;

//        private void InitializeComponent()
//        {
//            this.txtName = new TextBox();
//            this.txtEmail = new TextBox();
//            this.lblStatus = new Label();
//            this.chkIsEngineer = new CheckBox();
//        }

//        #endregion
//    }

//    // ========================================
//    // �i���d�ҡG���x����
//    // ========================================

//    /// <summary>
//    /// ���x�s�����d��
//    /// </summary>
//    public partial class MachineEditFormExample : BaseViewModelForm<SharedMachineViewModel>
//    {
//        private readonly ISharedViewModelManager _viewModelManager;

//        public MachineEditFormExample(ISharedViewModelManager viewModelManager)
//        {
//            InitializeComponent();
//            _viewModelManager = viewModelManager;
//        }

//        public void LoadMachine(int machineId)
//        {
//            var vm = _viewModelManager.GetOrCreateMachineViewModel(machineId);
//            BindViewModel(vm);
//        }

//        protected override void OnViewModelBound()
//        {
//            // �����j�w
//            BindTextBox(txtMachineName, nameof(ViewModel.MachineModelNo));
//            BindTextBox(txtCode, nameof(ViewModel.MachineCode));
//            BindComboBox(cboStatus, nameof(ViewModel.StatusId));

//            // �h��h���Y
//            ViewModel.WorkstationIds.CollectionChanged += (s, e) => UpdateWorkstationDisplay();
//            UpdateWorkstationDisplay();
//        }

//        private void UpdateWorkstationDisplay()
//        {
//            // ��s�u�����
//        }

//        #region Designer Code

//        private TextBox txtMachineName;
//        private TextBox txtCode;
//        private ComboBox cboStatus;

//        private void InitializeComponent()
//        {
//            this.txtMachineName = new TextBox();
//            this.txtCode = new TextBox();
//            this.cboStatus = new ComboBox();
//        }

//        #endregion
//    }
//}
