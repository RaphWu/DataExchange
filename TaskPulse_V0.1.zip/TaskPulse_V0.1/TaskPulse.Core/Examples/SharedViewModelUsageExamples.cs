﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calin.TaskPulse.Core.Services;
using Calin.TaskPulse.Core.ViewModels;

namespace Calin.TaskPulse.Core.Examples
{
    /// <summary>
    /// 共享 ViewModel 使用範例（使用 Autofac DI）- 正確的分層架構版本
    /// </summary>
    public class SharedViewModelUsageExamples
    {
        private readonly IEmployeeService _employeeService;
        private readonly IMachineService _machineService;
        private readonly IWorkOrderService _workOrderService;
        private readonly ISharedViewModelManager _viewModelManager;

        // ✅ 透過建構函式注入 Service 層（正確的分層架構）
        public SharedViewModelUsageExamples(
            IEmployeeService employeeService,
            IMachineService machineService,
            IWorkOrderService workOrderService,
            ISharedViewModelManager viewModelManager)
        {
            _employeeService = employeeService;
            _machineService = machineService;
            _workOrderService = workOrderService;
            _viewModelManager = viewModelManager;
        }

        #region 範例 1：載入並綁定員工 ViewModel

        /// <summary>
        /// 範例 1：從資料庫載入員工資料並建立共享 ViewModel
        /// </summary>
        public async Task<SharedEmployeeViewModel> LoadEmployeeViewModelAsync(int employeeId)
        {
            // ✅ 透過 Service 取得 DTO（不直接接觸資料庫）
            var dto = await _employeeService.GetEmployeeDtoAsync(employeeId);
            if (dto == null) return null;

            // ✅ 透過 ViewModel Manager 取得或建立 ViewModel
            var viewModel = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId, dto);

            return viewModel;
        }

        /// <summary>
        /// 在 WinForms 中綁定 ViewModel
        /// </summary>
        public void BindEmployeeToForm(Form form, SharedEmployeeViewModel viewModel)
        {
            // 假設表單有這些控制項
            var txtEmployeeId = form.Controls["txtEmployeeId"] as TextBox;
            var txtEmployeeName = form.Controls["txtEmployeeName"] as TextBox;
            var txtEmail = form.Controls["txtEmail"] as TextBox;
            var chkIsEngineer = form.Controls["chkIsEngineer"] as CheckBox;

            // 綁定資料
            txtEmployeeId.DataBindings.Clear();
            txtEmployeeId.DataBindings.Add("Text", viewModel, nameof(viewModel.EmployeeId),
                true, DataSourceUpdateMode.OnPropertyChanged);

            txtEmployeeName.DataBindings.Clear();
            txtEmployeeName.DataBindings.Add("Text", viewModel, nameof(viewModel.EmployeeName),
                true, DataSourceUpdateMode.OnPropertyChanged);

            txtEmail.DataBindings.Clear();
            txtEmail.DataBindings.Add("Text", viewModel, nameof(viewModel.Email),
                true, DataSourceUpdateMode.OnPropertyChanged);

            chkIsEngineer.DataBindings.Clear();
            chkIsEngineer.DataBindings.Add("Checked", viewModel, nameof(viewModel.IsEngineer),
                true, DataSourceUpdateMode.OnPropertyChanged);
        }

        #endregion

        #region 範例 2：多個 View 共用同一個 ViewModel

        /// <summary>
        /// 範例 2：開啟多個表單，全部綁定到同一個 ViewModel
        /// </summary>
        public async Task OpenMultipleFormsForSameEmployeeAsync(int employeeId)
        {
            // 載入員工資料並建立 ViewModel
            var viewModel = await LoadEmployeeViewModelAsync(employeeId);
            if (viewModel == null) return;

            // 開啟表單 1（編輯用）
            var formEdit = new Form { Text = "編輯員工" };
            BindEmployeeToForm(formEdit, viewModel);
            formEdit.Show();

            // 開啟表單 2（檢視用）
            var formView = new Form { Text = "檢視員工" };
            BindEmployeeToForm(formView, viewModel);
            formView.Show();

            // 開啟表單 3（詳細資訊）
            var formDetail = new Form { Text = "員工詳細資訊" };
            BindEmployeeToForm(formDetail, viewModel);
            formDetail.Show();

            // 現在任何一個表單修改資料，其他表單都會自動更新！
        }

        #endregion

        #region 範例 3：在一個 View 中更新資料，其他 View 自動同步

        /// <summary>
        /// 範例 3：示範資料自動同步
        /// </summary>
        public async Task DemonstrateAutoSyncAsync(int employeeId)
        {
            // 先載入 ViewModel
            var viewModel = await LoadEmployeeViewModelAsync(employeeId);
            if (viewModel == null) return;

            // 在任何地方更新 ViewModel
            viewModel.EmployeeName = "新名字";
            viewModel.Email = "new@example.com";
            viewModel.IsEngineer = true;

            // 所有綁定到此 ViewModel 的 View 都會自動更新顯示！
        }

        #endregion

        #region 範例 4：儲存 ViewModel 到資料庫

        /// <summary>
        /// 範例 4：將 ViewModel 的變更儲存回資料庫
        /// </summary>
        public async Task SaveEmployeeViewModelAsync(SharedEmployeeViewModel viewModel)
        {
            // ✅ 將 ViewModel 轉換為 DTO
            var dto = viewModel.ToDto();

            // ✅ 透過 Service 儲存（Service 會協調 Repository 和 Mapper）
            await _employeeService.UpdateEmployeeAsync(dto);

            // ✅ 更新 ViewModel 管理器中的資料（確保最新）
            _viewModelManager.UpdateEmployeeViewModel(dto.Id, dto);
        }

        #endregion

        #region 範例 5：處理多對多關係

        /// <summary>
        /// 範例 5：更新員工的權限（多對多關係）
        /// </summary>
        public async Task UpdateEmployeePermissionsAsync(int employeeId)
        {
            // 載入 ViewModel
            var viewModel = await LoadEmployeeViewModelAsync(employeeId);
            if (viewModel == null) return;

            // 更新權限 ID（所有綁定的 View 會自動更新）
            viewModel.PermissionIds.Clear();
            viewModel.PermissionIds.Add(1);
            viewModel.PermissionIds.Add(2);
            viewModel.PermissionIds.Add(5);

            // 儲存到資料庫
            await SaveEmployeeViewModelAsync(viewModel);
        }

        #endregion

        #region 範例 6：機台 ViewModel

        /// <summary>
        /// 範例 6：載入並使用機台 ViewModel
        /// </summary>
        public async Task<SharedMachineViewModel> LoadMachineViewModelAsync(int machineId)
        {
            // ✅ 透過 Service 取得 DTO
            var dto = await _machineService.GetMachineDtoAsync(machineId);
            if (dto == null) return null;

            // ✅ 透過 ViewModel Manager 取得或建立 ViewModel
            var viewModel = _viewModelManager.GetOrCreateMachineViewModel(machineId, dto);

            return viewModel;
        }

        /// <summary>
        /// 更新機台的工站關聯
        /// </summary>
        public async Task UpdateMachineWorkstationsAsync(int machineId)
        {
            var viewModel = await LoadMachineViewModelAsync(machineId);
            if (viewModel == null) return;

            // 更新工站
            viewModel.WorkstationIds.Clear();
            viewModel.WorkstationIds.Add(10);
            viewModel.WorkstationIds.Add(20);

            // ✅ 透過 Service 儲存
            var dto = viewModel.ToDto();
            await _machineService.UpdateMachineAsync(dto);

            // 更新 ViewModel 管理器
            _viewModelManager.UpdateMachineViewModel(machineId, dto);
        }

        #endregion

        #region 範例 7：維護工單 ViewModel

        /// <summary>
        /// 範例 7：載入並使用維護工單 ViewModel
        /// </summary>
        public async Task<SharedWorkOrderViewModel> LoadWorkOrderViewModelAsync(int workOrderId)
        {
            // ✅ 透過 Service 取得 DTO
            var dto = await _workOrderService.GetWorkOrderDtoAsync(workOrderId);
            if (dto == null) return null;

            // ✅ 透過 ViewModel Manager 取得或建立 ViewModel
            var viewModel = _viewModelManager.GetOrCreateWorkOrderViewModel(workOrderId, dto);

            return viewModel;
        }

        /// <summary>
        /// 指派工程師到維護工單
        /// </summary>
        public async Task AssignEngineersToWorkOrderAsync(int workOrderId)
        {
            var viewModel = await LoadWorkOrderViewModelAsync(workOrderId);
            if (viewModel == null) return;

            // 更新工程師
            viewModel.EngineerIds.Clear();
            viewModel.EngineerIds.Add(1);
            viewModel.EngineerIds.Add(2);
            viewModel.EngineerIds.Add(3);

            // ✅ 透過 Service 儲存
            var dto = viewModel.ToDto();
            await _workOrderService.UpdateWorkOrderAsync(dto);

            // 更新 ViewModel 管理器
            _viewModelManager.UpdateWorkOrderViewModel(workOrderId, dto);
        }

        #endregion

        #region 範例 8：記憶體管理

        /// <summary>
        /// 範例 8：清理不再使用的 ViewModel
        /// </summary>
        public void CleanupViewModels()
        {
            _viewModelManager.RemoveEmployeeViewModel(1);
            _viewModelManager.RemoveMachineViewModel(10);
            _viewModelManager.RemoveWorkOrderViewModel(100);

            // 或清除所有
            _viewModelManager.ClearAll();
        }

        /// <summary>
        /// 檢查 ViewModel 使用情況
        /// </summary>
        public void CheckViewModelUsage()
        {
            Console.WriteLine($"員工 ViewModel 數量: {_viewModelManager.EmployeeViewModelCount}");
            Console.WriteLine($"機台 ViewModel 數量: {_viewModelManager.MachineViewModelCount}");
            Console.WriteLine($"工單 ViewModel 數量: {_viewModelManager.WorkOrderViewModelCount}");
        }

        #endregion

        #region 範例 9：完整的增刪改查流程

        /// <summary>
        /// 範例 9：完整的 CRUD 流程
        /// </summary>
        public class EmployeeViewExample
        {
            private readonly SharedViewModelUsageExamples _examples;
            private SharedEmployeeViewModel _viewModel;

            public EmployeeViewExample(SharedViewModelUsageExamples examples)
            {
                _examples = examples;
            }

            // 載入
            public async Task LoadAsync(int employeeId)
            {
                _viewModel = await _examples.LoadEmployeeViewModelAsync(employeeId);
            }

            // 編輯
            public void Edit()
            {
                _viewModel.EmployeeName = "修改後的名字";
                _viewModel.Email = "modified@example.com";
                // UI 會自動更新
            }

            // 儲存
            public async Task SaveAsync()
            {
                await _examples.SaveEmployeeViewModelAsync(_viewModel);
            }

            // 刪除
            public async Task DeleteAsync()
            {
                var dto = _viewModel.ToDto();

                // ✅ 透過 Service 刪除
                await _examples._employeeService.DeleteEmployeeAsync(dto.Id);

                // 清除 ViewModel
                _examples._viewModelManager.RemoveEmployeeViewModel(dto.Id);
            }
        }

        #endregion
    }

    #region WinForms 實際使用範例

    /// <summary>
    /// WinForms 表單使用範例（使用 Autofac DI）
    /// </summary>
    public partial class EmployeeEditFormExample : Form
    {
        private readonly ISharedViewModelManager _viewModelManager;
        private readonly IEmployeeService _employeeService;
        private SharedEmployeeViewModel _viewModel;

        // ✅ 建構函式注入（推薦）
        public EmployeeEditFormExample(
            ISharedViewModelManager viewModelManager,
            IEmployeeService employeeService)
        {
            InitializeComponent();

            _viewModelManager = viewModelManager;
            _employeeService = employeeService;
        }

        // 載入員工資料
        public async Task LoadEmployeeAsync(int employeeId)
        {
            // ✅ 透過 Service 取得 DTO
            var dto = await _employeeService.GetEmployeeDtoAsync(employeeId);
            if (dto == null) return;

            // ✅ 透過 ViewModel Manager 取得或建立 ViewModel
            _viewModel = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId, dto);

            BindControls();
        }

        private void BindControls()
        {
            // 綁定控制項到 ViewModel
            txtEmployeeName.DataBindings.Clear();
            txtEmployeeName.DataBindings.Add("Text", _viewModel,
                nameof(_viewModel.EmployeeName),
                true, DataSourceUpdateMode.OnPropertyChanged);

            txtEmail.DataBindings.Clear();
            txtEmail.DataBindings.Add("Text", _viewModel,
                nameof(_viewModel.Email),
                true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            // ✅ 透過 Service 儲存
            var dto = _viewModel.ToDto();
            await _employeeService.UpdateEmployeeAsync(dto);

            MessageBox.Show("儲存成功！");
        }
    }

    /// <summary>
    /// WinForms 表單使用範例（屬性注入 - 適用於設計器）
    /// </summary>
    public partial class EmployeeEditFormExample2 : Form
    {
        // ✅ 屬性注入（Autofac 會自動設定）
        public ISharedViewModelManager ViewModelManager { get; set; }
        public IEmployeeService EmployeeService { get; set; }

        private SharedEmployeeViewModel _viewModel;

        public EmployeeEditFormExample2()
        {
            // 無參數建構函式（設計器需要）
            InitializeComponent();
        }

        public async Task LoadEmployeeAsync(int employeeId)
        {
            // ✅ 透過 Service 取得 DTO
            var dto = await EmployeeService.GetEmployeeDtoAsync(employeeId);
            if (dto == null) return;

            // ✅ 使用注入的 ViewModel Manager
            _viewModel = ViewModelManager.GetOrCreateEmployeeViewModel(employeeId, dto);

            BindControls();
        }

        private void BindControls()
        {
            txtEmployeeName.DataBindings.Add("Text", _viewModel,
                nameof(_viewModel.EmployeeName),
                true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            // ✅ 透過 Service 儲存
            var dto = _viewModel.ToDto();
            await EmployeeService.UpdateEmployeeAsync(dto);

            MessageBox.Show("儲存成功！");
        }
    }

    #endregion
}
