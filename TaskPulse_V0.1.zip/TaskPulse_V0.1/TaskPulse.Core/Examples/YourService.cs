//// 1. �b�z�� Service ���`�J
//public class YourService
//{
//    private readonly IEmployeeMapper _employeeMapper;

//    public YourService(IEmployeeMapper employeeMapper, CoreContext context)
//    {
//        _employeeMapper = employeeMapper;
//    }

//    // 2. �ϥ� Mapper
//    public async Task<EmployeeDto> GetEmployee(int id)
//    {
//        var employee = await _context.Employees
//            .Include(e => e.Department)
//            .Include(e => e.JobTitle)
//            .FirstOrDefaultAsync(e => e.Id == id);

//        return _employeeMapper.ToDto(employee);
//    }

//    // 3. �s�W SyncManyToManyRelationships �d��
//    public async Task SyncRelationships(EmployeeDto employeeDto)
//    {
//        var employee = await _context.Employees
//            .Include(e => e.Permissions)
//            .Include(e => e.UserGroups)
//            .Include(e => e.CarbonCopies)
//            .FirstOrDefaultAsync(e => e.Id == employeeDto.Id);

//        _employeeMapper.SyncManyToManyRelationships(employeeDto, employee);
//        await _context.SaveChangesAsync();
//    }

//    // ��s���u��ƨæP�B�v���B�s�աB�ƥ��H��
//    public async Task UpdateEmployee(int id, EmployeeDto dto)
//    {
//        // 1. ��s���ݩ�
//        var employee = await _context.Employees.FindAsync(id);
//        _employeeMapper.UpdateEntity(employee, dto);

//        // 2. �P�B�h��h���Y�]�Ҧp�u��s�v���^
//        var dto = new EmployeeDto
//        {
//            PermissionIds = new List<int> { 1, 2, 3 }
//        };

//        _employeeMapper.SyncManyToManyRelationships(_context, employee, dto);

//        // 3. �x�s
//        await _context.SaveChangesAsync();
//    }
//}