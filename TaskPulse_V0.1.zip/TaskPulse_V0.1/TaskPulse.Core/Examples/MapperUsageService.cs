using System.Collections.Generic;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Core.Mappers;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Examples
{
    /// <summary>
    /// Mapper �ϥνd�� - �i�ܦp��ϥ� DTO ��s Entity �Φh��h���Y�C
    /// </summary>
    public class MapperUsageService
    {
        private readonly CoreContext _context;
        private readonly IEmployeeMapper _employeeMapper;
        private readonly IMachineMapper _machineMapper;
        private readonly IWorkOrderMapper _workOrderMapper;

        public MapperUsageService(
            CoreContext context,
            IEmployeeMapper employeeMapper,
            IMachineMapper machineMapper,
            IWorkOrderMapper workOrderMapper)
        {
            _context = context;
            _employeeMapper = employeeMapper;
            _machineMapper = machineMapper;
            _workOrderMapper = workOrderMapper;
        }

        #region Employee Examples

        /// <summary>
        /// �d�� 1�G��s���u��ơ]�]�t�h��h���Y�^
        /// </summary>
        public async Task UpdateEmployeeWithRelationshipsAsync(int employeeId, EmployeeDto dto)
        {
            // 1. �q��Ʈw���o����
            var employee = await _context.Employees.FindAsync(employeeId);
            if (employee == null) return;

            // 2. ��s���ݩ�
            _employeeMapper.UpdateEntity(employee, dto);

            // 3. �P�B�h��h���Y�]�v���B�ϥΪ̸s�աB�ƥ��H���^
            _employeeMapper.SyncManyToManyRelationships(_context, employee, dto);

            // 4. �x�s�ܧ�
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// �d�� 2�G�u��s���u���v��
        /// </summary>
        public async Task UpdateEmployeePermissionsAsync(int employeeId, List<int> permissionIds)
        {
            var employee = await _context.Employees.FindAsync(employeeId);
            if (employee == null) return;

            var dto = new EmployeeDto
            {
                PermissionIds = permissionIds,
                // ��L�ݩʬ� null�A���|�Q�B�z
            };

            _employeeMapper.SyncManyToManyRelationships(_context, employee, dto);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// �d�� 3�G��s���u�򥻸�ơA���O�����Y����
        /// </summary>
        public async Task UpdateEmployeeBasicInfoAsync(int employeeId, EmployeeDto dto)
        {
            var employee = await _context.Employees.FindAsync(employeeId);
            if (employee == null) return;

            // �u��s���ݩʡA���I�s SyncManyToManyRelationships
            _employeeMapper.UpdateEntity(employee, dto);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// �d�� 4�G�M�ŭ��u���Ҧ��v��
        /// </summary>
        public async Task ClearEmployeePermissionsAsync(int employeeId)
        {
            var employee = await _context.Employees.FindAsync(employeeId);
            if (employee == null) return;

            var dto = new EmployeeDto
            {
                PermissionIds = new List<int>() // �� List = �M��
            };

            _employeeMapper.SyncManyToManyRelationships(_context, employee, dto);
            await _context.SaveChangesAsync();
        }

        #endregion

        #region Machine Examples

        /// <summary>
        /// �d�� 5�G��s���x��ơ]�]�t�u�����p�^
        /// </summary>
        public async Task UpdateMachineWithWorkstationsAsync(int machineId, MachineDto dto)
        {
            var machine = await _context.Machines.FindAsync(machineId);
            if (machine == null) return;

            // ��s���ݩ�
            _machineMapper.UpdateEntity(machine, dto);

            // �P�B�u�����p
            _machineMapper.SyncManyToManyRelationships(_context, machine, dto);

            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// �d�� 6�G�u��s���x���u�����p
        /// </summary>
        public async Task AssignMachineToWorkstationsAsync(int machineId, List<int> workstationIds)
        {
            var machine = await _context.Machines.FindAsync(machineId);
            if (machine == null) return;

            var dto = new MachineDto
            {
                WorkstationIds = workstationIds
            };

            _machineMapper.SyncManyToManyRelationships(_context, machine, dto);
            await _context.SaveChangesAsync();
        }

        #endregion

        #region WorkOrder Examples

        /// <summary>
        /// �d�� 7�G��s���@�u��]�]�t�����u�{�v�^
        /// </summary>
        public async Task UpdateWorkOrderWithEngineersAsync(int workOrderId, WorkOrderDto dto)
        {
            var workOrder = await _context.WorkOrders.FindAsync(workOrderId);
            if (workOrder == null) return;

            // ��s���ݩ�
            _workOrderMapper.UpdateEntity(workOrder, dto);

            // �P�B�u�{�v����
            _workOrderMapper.SyncManyToManyRelationships(_context, workOrder, dto);

            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// �d�� 8�G�����u�{�v��u��
        /// </summary>
        public async Task AssignEngineersToWorkOrderAsync(int workOrderId, List<int> engineerIds)
        {
            var workOrder = await _context.WorkOrders.FindAsync(workOrderId);
            if (workOrder == null) return;

            var dto = new WorkOrderDto
            {
                EngineerIds = engineerIds
            };

            _workOrderMapper.SyncManyToManyRelationships(_context, workOrder, dto);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// �d�� 9�G�����u�檺�Ҧ��u�{�v
        /// </summary>
        public async Task RemoveAllEngineersFromWorkOrderAsync(int workOrderId)
        {
            var workOrder = await _context.WorkOrders.FindAsync(workOrderId);
            if (workOrder == null) return;

            var dto = new WorkOrderDto
            {
                EngineerIds = new List<int>() // �� List = �M��
            };

            _workOrderMapper.SyncManyToManyRelationships(_context, workOrder, dto);
            await _context.SaveChangesAsync();
        }

        #endregion

        #region Batch Operations

        /// <summary>
        /// �d�� 10�G�妸��s�h�ӭ��u���v��
        /// </summary>
        public async Task BatchUpdateEmployeePermissionsAsync(Dictionary<int, List<int>> employeePermissions)
        {
            foreach (var kvp in employeePermissions)
            {
                var employee = await _context.Employees.FindAsync(kvp.Key);
                if (employee != null)
                {
                    var dto = new EmployeeDto { PermissionIds = kvp.Value };
                    _employeeMapper.SyncManyToManyRelationships(_context, employee, dto);
                }
            }

            // �妸�ާ@�G�ֿn�Ҧ��ܧ��@���x�s
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// �d�� 11�G�妸�����h�x���x��P�@�u��
        /// </summary>
        public async Task BatchAssignMachinesToWorkstationAsync(List<int> machineIds, int workstationId)
        {
            foreach (var machineId in machineIds)
            {
                var machine = await _context.Machines.FindAsync(machineId);
                if (machine != null)
                {
                    var dto = new MachineDto
                    {
                        WorkstationIds = new List<int> { workstationId }
                    };
                    _machineMapper.SyncManyToManyRelationships(_context, machine, dto);
                }
            }

            await _context.SaveChangesAsync();
        }

        #endregion

        #region Transaction Example

        /// <summary>
        /// �d�� 12�G�ϥ� Transaction �T�O��Ƥ@�P��
        /// </summary>
        public async Task UpdateEmployeeWithTransactionAsync(int employeeId, EmployeeDto dto)
        {
            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    var employee = await _context.Employees.FindAsync(employeeId);
                    if (employee == null)
                    {
                        transaction.Rollback();
                        return;
                    }

                    // ��s���ݩ�
                    _employeeMapper.UpdateEntity(employee, dto);

                    // �P�B�h��h���Y
                    _employeeMapper.SyncManyToManyRelationships(_context, employee, dto);

                    // �x�s�ô���
                    await _context.SaveChangesAsync();
                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        #endregion
    }
}
