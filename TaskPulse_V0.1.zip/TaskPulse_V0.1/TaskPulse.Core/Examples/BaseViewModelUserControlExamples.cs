//using System;
//using System.Windows.Forms;
//using Calin.TaskPulse.Core.ViewModels;

//namespace Calin.TaskPulse.Core.Examples
//{
//    /// <summary>
//    /// BaseViewModelUserControl �ϥνd��
//    /// </summary>

//    // ========================================
//    // �d�� 1�G���u��T��� UserControl�]��Ū�^
//    // ========================================

//    public partial class EmployeeInfoDisplayControl : BaseViewModelUserControl<SharedEmployeeViewModel>
//    {
//        public EmployeeInfoDisplayControl()
//        {
//            InitializeComponent();
//        }

//        protected override void OnViewModelBound()
//        {
//            // ²��j�w
//            BindLabel(lblEmployeeId, nameof(ViewModel.EmployeeId));
//            BindLabel(lblEmployeeName, nameof(ViewModel.EmployeeName));
//            BindLabel(lblEmail, nameof(ViewModel.Email));
//            BindLabel(lblIsEngineer, nameof(ViewModel.IsEngineer));
//        }

//        #region Designer Code

//        private Label lblEmployeeId;
//        private Label lblEmployeeName;
//        private Label lblEmail;
//        private Label lblIsEngineer;

//        private void InitializeComponent()
//        {
//            this.lblEmployeeId = new Label();
//            this.lblEmployeeName = new Label();
//            this.lblEmail = new Label();
//            this.lblIsEngineer = new Label();

//            // Layout...
//        }

//        #endregion
//    }

//    // ========================================
//    // �d�� 2�G���u�s�� UserControl�]�i�s��^
//    // ========================================

//    public partial class EmployeeEditControl : BaseViewModelUserControl<SharedEmployeeViewModel>
//    {
//        private readonly ISharedViewModelManager _viewModelManager;

//        public EmployeeEditControl()
//        {
//            InitializeComponent();
//        }

//        // �䴩�غc�禡�`�J
//        public EmployeeEditControl(ISharedViewModelManager viewModelManager) : this()
//        {
//            _viewModelManager = viewModelManager;
//        }

//        /// <summary>
//        /// ���J���u���
//        /// </summary>
//        public void LoadEmployee(int employeeId)
//        {
//            if (_viewModelManager == null)
//                throw new InvalidOperationException("�ݭn�`�J ISharedViewModelManager");

//            var vm = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);
//            BindViewModel(vm);
//        }

//        protected override void OnViewModelBound()
//        {
//            // �j�w�i�s�����
//            BindTextBox(txtEmployeeId, nameof(ViewModel.EmployeeId));
//            BindTextBox(txtEmployeeName, nameof(ViewModel.EmployeeName));
//            BindTextBox(txtEmail, nameof(ViewModel.Email));
//            BindCheckBox(chkIsEngineer, nameof(ViewModel.IsEngineer));

//            // �j�w�v�����X�ܧ�ƥ�
//            ViewModel.PermissionIds.CollectionChanged += OnPermissionsChanged;
//            UpdatePermissionDisplay();
//        }

//        protected override void OnViewModelUnbound()
//        {
//            // �����ƥ�q�\
//            if (IsViewModelBound)
//            {
//                ViewModel.PermissionIds.CollectionChanged -= OnPermissionsChanged;
//            }

//            base.OnViewModelUnbound();
//        }

//        private void OnPermissionsChanged(object sender, 
//            System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
//        {
//            UpdatePermissionDisplay();
//        }

//        private void UpdatePermissionDisplay()
//        {
//            // ��s�v�� UI
//        }

//        #region Designer Code

//        private TextBox txtEmployeeId;
//        private TextBox txtEmployeeName;
//        private TextBox txtEmail;
//        private CheckBox chkIsEngineer;

//        private void InitializeComponent()
//        {
//            this.txtEmployeeId = new TextBox();
//            this.txtEmployeeName = new TextBox();
//            this.txtEmail = new TextBox();
//            this.chkIsEngineer = new CheckBox();
//        }

//        #endregion
//    }

//    // ========================================
//    // �d�� 3�G���x��T UserControl
//    // ========================================

//    public partial class MachineInfoControl : BaseViewModelUserControl<SharedMachineViewModel>
//    {
//        private readonly ISharedViewModelManager _viewModelManager;

//        public MachineInfoControl()
//        {
//            InitializeComponent();
//        }

//        public MachineInfoControl(ISharedViewModelManager viewModelManager) : this()
//        {
//            _viewModelManager = viewModelManager;
//        }

//        public void LoadMachine(int machineId)
//        {
//            var vm = _viewModelManager.GetOrCreateMachineViewModel(machineId);
//            BindViewModel(vm);
//        }

//        protected override void OnViewModelBound()
//        {
//            BindTextBox(txtMachineName, nameof(ViewModel.MachineModelNo));
//            BindTextBox(txtMachineCode, nameof(ViewModel.MachineCode));
//            BindComboBox(cboStatus, nameof(ViewModel.StatusId));

//            // �u�����X
//            ViewModel.WorkstationIds.CollectionChanged += (s, e) => UpdateWorkstations();
//            UpdateWorkstations();
//        }

//        private void UpdateWorkstations()
//        {
//            // ��s�u�����
//        }

//        #region Designer Code

//        private TextBox txtMachineName;
//        private TextBox txtMachineCode;
//        private ComboBox cboStatus;

//        private void InitializeComponent()
//        {
//            this.txtMachineName = new TextBox();
//            this.txtMachineCode = new TextBox();
//            this.cboStatus = new ComboBox();
//        }

//        #endregion
//    }

//    // ========================================
//    // �d�� 4�G�b Form ���ϥ� UserControl
//    // ========================================

//    public partial class EmployeeManagementForm : Form
//    {
//        private readonly ISharedViewModelManager _viewModelManager;
//        private EmployeeEditControl _editControl;
//        private EmployeeInfoDisplayControl _displayControl;

//        public EmployeeManagementForm(ISharedViewModelManager viewModelManager)
//        {
//            InitializeComponent();
//            _viewModelManager = viewModelManager;

//            // �إ� UserControl ���
//            _editControl = new EmployeeEditControl(viewModelManager);
//            _displayControl = new EmployeeInfoDisplayControl();

//            // �[�J�� Form
//            this.Controls.Add(_editControl);
//            this.Controls.Add(_displayControl);
//        }

//        /// <summary>
//        /// ���J���u - ��� UserControl �@�ΦP�@�� ViewModel
//        /// </summary>
//        public void LoadEmployee(int employeeId)
//        {
//            // ���o�@�� ViewModel
//            var vm = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);

//            // �j�w���Ӥ��P�� UserControl
//            _editControl.BindViewModel(vm);
//            _displayControl.BindViewModel(vm);

//            // �{�b�s��ϭק��ơA��ܰϷ|�Y�ɧ�s�I
//        }

//        #region Designer Code

//        private void InitializeComponent()
//        {
//            // Designer code...
//        }

//        #endregion
//    }

//    // ========================================
//    // �d�� 5�G�_�� UserControl
//    // ========================================

//    /// <summary>
//    /// �D UserControl - �]�t�h�Ӥl UserControl
//    /// </summary>
//    public partial class EmployeeDetailPanel : BaseViewModelUserControl<SharedEmployeeViewModel>
//    {
//        private EmployeeInfoDisplayControl _infoControl;
//        private EmployeeEditControl _editControl;

//        public EmployeeDetailPanel()
//        {
//            InitializeComponent();

//            _infoControl = new EmployeeInfoDisplayControl();
//            _editControl = new EmployeeEditControl();

//            this.Controls.Add(_infoControl);
//            this.Controls.Add(_editControl);
//        }

//        protected override void OnViewModelBound()
//        {
//            // �N ViewModel �ǻ����l UserControl
//            _infoControl.BindViewModel(ViewModel);
//            _editControl.BindViewModel(ViewModel);

//            // �Ҧ��l������@�ΦP�@�� ViewModel�I
//        }

//        protected override void OnViewModelUnbound()
//        {
//            // �Ѱ��l����j�w
//            _infoControl.UnbindViewModel();
//            _editControl.UnbindViewModel();

//            base.OnViewModelUnbound();
//        }

//        #region Designer Code

//        private void InitializeComponent()
//        {
//            // Designer code...
//        }

//        #endregion
//    }

//    // ========================================
//    // �d�� 6�G��Ū�P�s��Ҧ�����
//    // ========================================

//    public partial class EmployeeSwitchableControl : BaseViewModelUserControl<SharedEmployeeViewModel>
//    {
//        private bool _isEditMode = false;

//        public EmployeeSwitchableControl()
//        {
//            InitializeComponent();
//        }

//        public bool IsEditMode
//        {
//            get => _isEditMode;
//            set
//            {
//                _isEditMode = value;
//                UpdateEditMode();
//            }
//        }

//        protected override void OnViewModelBound()
//        {
//            BindTextBox(txtName, nameof(ViewModel.EmployeeName));
//            BindTextBox(txtEmail, nameof(ViewModel.Email));
//            UpdateEditMode();
//        }

//        private void UpdateEditMode()
//        {
//            txtName.ReadOnly = !_isEditMode;
//            txtEmail.ReadOnly = !_isEditMode;
//            btnEdit.Visible = !_isEditMode;
//            btnSave.Visible = _isEditMode;
//            btnCancel.Visible = _isEditMode;
//        }

//        private void btnEdit_Click(object sender, EventArgs e)
//        {
//            IsEditMode = true;
//        }

//        private void btnSave_Click(object sender, EventArgs e)
//        {
//            if (!IsViewModelBound) return;

//            // �x�s�޿�...
//            IsEditMode = false;
//        }

//        private void btnCancel_Click(object sender, EventArgs e)
//        {
//            if (!IsViewModelBound) return;

//            // �����ܧ�]���s���J�^
//            // var dto = await _service.GetEmployeeDtoAsync(ViewModel.Id);
//            // ViewModel.LoadFromDto(dto);

//            IsEditMode = false;
//        }

//        #region Designer Code

//        private TextBox txtName;
//        private TextBox txtEmail;
//        private Button btnEdit;
//        private Button btnSave;
//        private Button btnCancel;

//        private void InitializeComponent()
//        {
//            this.txtName = new TextBox();
//            this.txtEmail = new TextBox();
//            this.btnEdit = new Button();
//            this.btnSave = new Button();
//            this.btnCancel = new Button();

//            this.btnEdit.Click += btnEdit_Click;
//            this.btnSave.Click += btnSave_Click;
//            this.btnCancel.Click += btnCancel_Click;
//        }

//        #endregion
//    }

//    // ========================================
//    // �d�� 7�G�ʺA���J UserControl
//    // ========================================

//    public partial class DynamicUserControlForm : Form
//    {
//        private readonly ISharedViewModelManager _viewModelManager;
//        private Panel _contentPanel;

//        public DynamicUserControlForm(ISharedViewModelManager viewModelManager)
//        {
//            InitializeComponent();
//            _viewModelManager = viewModelManager;
//        }

//        /// <summary>
//        /// �ʺA���J����ܭ��u�s�� UserControl
//        /// </summary>
//        public void ShowEmployeeEdit(int employeeId)
//        {
//            // �M���±��
//            _contentPanel.Controls.Clear();

//            // �إ߷s�� UserControl
//            var editControl = new EmployeeEditControl(_viewModelManager);
//            editControl.Dock = DockStyle.Fill;

//            // ���J���
//            editControl.LoadEmployee(employeeId);

//            // �[�J�� Panel
//            _contentPanel.Controls.Add(editControl);
//        }

//        /// <summary>
//        /// �ʺA���J����ܭ��u��T UserControl
//        /// </summary>
//        public void ShowEmployeeInfo(int employeeId)
//        {
//            _contentPanel.Controls.Clear();

//            var infoControl = new EmployeeInfoDisplayControl();
//            infoControl.Dock = DockStyle.Fill;

//            var vm = _viewModelManager.GetOrCreateEmployeeViewModel(employeeId);
//            infoControl.BindViewModel(vm);

//            _contentPanel.Controls.Add(infoControl);
//        }

//        #region Designer Code

//        private void InitializeComponent()
//        {
//            this._contentPanel = new Panel();
//            this.Controls.Add(this._contentPanel);
//        }

//        #endregion
//    }
//}
