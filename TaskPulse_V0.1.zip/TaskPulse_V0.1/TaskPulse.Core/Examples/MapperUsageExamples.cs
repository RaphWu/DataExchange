using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using Calin.TaskPulse.Core.DTO;
using Calin.TaskPulse.Core.Mappers;
using Calin.TaskPulse.Core.Models;

namespace Calin.TaskPulse.Core.Examples
{
    /// <summary>
    /// Mapper�ϥνd�ҡC
    /// </summary>
    public class MapperUsageExamples
    {
        private readonly CoreContext _context;
        private readonly IEmployeeMapper _employeeMapper;
        private readonly IMachineMapper _machineMapper;
        private readonly IWorkOrderMapper _workOrderMapper;

        public MapperUsageExamples(CoreContext context,
                                   IEmployeeMapper employeeMapper,
                                   IMachineMapper machineMapper,
                                   IWorkOrderMapper workOrderMapper)
        {
            _context = context;
            _employeeMapper = employeeMapper;
            _machineMapper = machineMapper;
            _workOrderMapper = workOrderMapper;
        }

        #region Employee Examples

        /// <summary>
        /// �d�ҡG���o���uDTO�C
        /// </summary>
        public async Task<EmployeeDto> GetEmployeeDtoExample(int employeeId)
        {
            var employee = await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.JobTitle)
                .Include(e => e.Status)
                .Include(e => e.Permissions)
                .Include(e => e.UserGroups)
                .Include(e => e.CarbonCopies)
                .FirstOrDefaultAsync(e => e.Id == employeeId);

            return _employeeMapper.ToDto(employee);
        }

        /// <summary>
        /// �d�ҡG�إ߷s���u�C
        /// </summary>
        public async Task<int> CreateEmployeeExample(EmployeeDto dto)
        {
            var employee = _employeeMapper.ToEntity(dto);
            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();
            return employee.Id;
        }

        /// <summary>
        /// �d�ҡG��s���u��ơC
        /// </summary>
        public async Task UpdateEmployeeExample(int employeeId, EmployeeDto dto)
        {
            var employee = await _context.Employees.FindAsync(employeeId);
            if (employee != null)
            {
                _employeeMapper.UpdateEntity(employee, dto);
                await _context.SaveChangesAsync();
            }
        }

        #endregion

        #region Machine Examples

        /// <summary>
        /// �d�ҡG���o���xDTO�C
        /// </summary>
        public async Task<MachineDto> GetMachineDtoExample(int machineId)
        {
            var machine = await _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .Include(m => m.Workstations)
                .FirstOrDefaultAsync(m => m.Id == machineId);

            return _machineMapper.ToDto(machine);
        }

        /// <summary>
        /// �d�ҡG�إ߷s���x�C
        /// </summary>
        public async Task<int> CreateMachineExample(MachineDto dto)
        {
            var machine = _machineMapper.ToEntity(dto);
            _context.Machines.Add(machine);
            await _context.SaveChangesAsync();
            return machine.Id;
        }

        /// <summary>
        /// �d�ҡG��s���x��ơC
        /// </summary>
        public async Task UpdateMachineExample(int machineId, MachineDto dto)
        {
            var machine = await _context.Machines.FindAsync(machineId);
            if (machine != null)
            {
                _machineMapper.UpdateEntity(machine, dto);
                await _context.SaveChangesAsync();
            }
        }

        #endregion

        #region WorkOrder Examples

        /// <summary>
        /// �d�ҡG���o���@�u��DTO�C
        /// </summary>
        public async Task<WorkOrderDto> GetWorkOrderDtoExample(int workOrderId)
        {
            var workOrder = await _context.WorkOrders
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.Engineers)
                .Include(w => w.IssueCategory)
                .Include(w => w.RequestingUnit)
                .Include(w => w.FeedbackEmployee)
                .FirstOrDefaultAsync(w => w.Id == workOrderId);

            return _workOrderMapper.ToDto(workOrder);
        }

        /// <summary>
        /// �d�ҡG�إ߷s���@�u��C
        /// </summary>
        public async Task<int> CreateWorkOrderExample(WorkOrderDto dto)
        {
            var workOrder = _workOrderMapper.ToEntity(dto);
            _context.WorkOrders.Add(workOrder);
            await _context.SaveChangesAsync();
            return workOrder.Id;
        }

        /// <summary>
        /// �d�ҡG��s���@�u���ơC
        /// </summary>
        public async Task UpdateWorkOrderExample(int workOrderId, WorkOrderDto dto)
        {
            var workOrder = await _context.WorkOrders.FindAsync(workOrderId);
            if (workOrder != null)
            {
                _workOrderMapper.UpdateEntity(workOrder, dto);
                await _context.SaveChangesAsync();
            }
        }

        /// <summary>
        /// �d�ҡG���o�Ҧ��u��DTO�C���C
        /// </summary>
        public async Task<System.Collections.Generic.List<WorkOrderDto>> GetAllWorkOrdersExample()
        {
            var workOrders = await _context.WorkOrders
                .Include(w => w.Machine)
                .Include(w => w.Workstation)
                .Include(w => w.Creator)
                .Include(w => w.MaintenanceUnit)
                .Include(w => w.Engineers)
                .Include(w => w.IssueCategory)
                .Include(w => w.RequestingUnit)
                .Include(w => w.FeedbackEmployee)
                .ToListAsync();

            return workOrders.Select(w => _workOrderMapper.ToDto(w)).ToList();
        }

        #endregion

        #region Batch Operations

        /// <summary>
        /// �d�ҡG�妸�ഫ���u�C����DTO�C
        /// </summary>
        public async Task<System.Collections.Generic.List<EmployeeDto>> GetAllEmployeesExample()
        {
            var employees = await _context.Employees
                .Include(e => e.Department)
                .Include(e => e.JobTitle)
                .Include(e => e.Status)
                .ToListAsync();

            return employees.Select(e => _employeeMapper.ToDto(e)).ToList();
        }

        /// <summary>
        /// �d�ҡG�妸�ഫ���x�C����DTO�C
        /// </summary>
        public async Task<System.Collections.Generic.List<MachineDto>> GetAllMachinesExample()
        {
            var machines = await _context.Machines
                .Include(m => m.MachineName)
                .Include(m => m.Condition)
                .Include(m => m.Brand)
                .Include(m => m.Location)
                .ToListAsync();

            return machines.Select(m => _machineMapper.ToDto(m)).ToList();
        }

        #endregion
    }
}
