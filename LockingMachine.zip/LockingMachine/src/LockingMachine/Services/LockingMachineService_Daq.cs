﻿using Calin.Comm.DL_RS1A;
using Calin.Helper;
using Calin.LockingMachine.Models;

namespace Calin.LockingMachine.Services
{
    public partial class LockingMachineService : ILockingMachine_DAQ
    {
        #region Fields

        private readonly string _daqFile = "DAQ.json";

        #endregion Fields

        /// <inheritdoc/>
        public void DaqInit()
        {
            try
            {
                DaqLoadConfig();
                _bindingData.TorqueMeterActive = _lmData.dio.Usb4704DioInit(_daqData.DeviceCode);
            }
            catch (Exception ex)
            {
                _bindingData.TorqueMeterActive = false;
            }
        }

        /// <inheritdoc/>
        public void DaqClose()
        {
            _lmData.dio.Dispose();
            _bindingData.TorqueMeterActive = false;
        }

        /// <inheritdoc/>
        public void DaqSaveConfig(DaqData config)
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _daqFile);
            JsonFileHelper.Save(path, _daqData);
        }

        /// <inheritdoc/>
        public void DaqLoadConfig()
        {
            DaqData config = null;

            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, _daqFile);
            if (File.Exists(path))
            {
                try
                {
                    config = JsonFileHelper.Read<DaqData>(path);
                }
                catch (Exception ex)
                {
                    // 讀取失敗：不要立刻覆寫檔案（避免讀取中出錯就覆蓋原始檔）
                    Console.WriteLine($"DaqLoadConfig: failed to read config file '{path}': {ex}");
                    config = null;
                }
            }

            if (config == null)
            {
                config = new DaqData();

                // 只有當檔案原本不存在時才儲存預設檔，若原本有檔但讀取失敗則不立刻覆蓋
                if (!File.Exists(path))
                {
                    DaqSaveConfig(config);
                }
            }

            _daqData.DeviceCode = config.DeviceCode;
            _daqData.TorqueLimitH = config.TorqueLimitH;
            _daqData.TorqueLimitL = config.TorqueLimitL;
            _daqData.GateMarkPort = config.GateMarkPort;

            _bindingData.TorqueLimitH = _daqData.TorqueLimitH;
            _bindingData.TorqueLimitL = _daqData.TorqueLimitL;
        }
    }
}
