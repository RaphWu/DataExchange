﻿using System;
using Autofac;
using Calin.DAQ.USB4704;
using Calin.LockingMachine.Models;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Services;
using Calin.SerialPort;

namespace Calin.LockingMachine.Services
{
    /// <summary>
    /// 鎖付機服務。
    /// </summary>
    public partial class LockingMachineService : ILockingMachine, IDisposable
    {
        #region Fields

        private readonly ILifetimeScope _scope;
        private readonly IAcm _acm;
        private readonly LmData _lmData;
        private readonly RawData _rawData;
        private readonly BindingData _bindingData;
        private readonly DaqData _daqData;
        private Dlrs1aData _dispData;

        private bool _disposedValue = false;

        #endregion Fields

        #region ctor

        public LockingMachineService(
            ILifetimeScope lifetimeScope,
            IAcm acm,
            IUsb4704Dio usb4704Dio,
            IUsb4704Streaming usb4704Streaming,
            IUsb4704Instant usb4704Instant,
            RawData rawData,
            BindingData bindingData,
            LmData lmData,
            Dlrs1aData dlrs1aData,
            DaqData daqData)
        {
            _scope = lifetimeScope;
            _acm = acm;
            _lmData = lmData;
            _rawData = rawData;
            _bindingData = bindingData;
            _dispData = dlrs1aData;
            _daqData = daqData;

            _lmData.dio = usb4704Dio;
            _lmData.usb4704Streaming = usb4704Streaming;
            _lmData.usb4704Instant = usb4704Instant;
            UpdateComPortList();

            Dlrs1aInit(); // 高度計
            DaqInit(); // USB4704

            PollingStart();

            // 訂閱 Advantech ACM 狀態更新事件
            _acm.AcmStatusUpdated += AcmStatusUpdated;
        }

        #endregion ctor

        #region Methods

        /// <inheritdoc/>
        public void ClearMeasureData()
        {
            _rawData.HeightDisplacementValue = 0.0;
            _rawData.HeightDisplacementMaxValue = 0.0;
            _rawData.HeightDisplacementFinalValue = 0.0;

            _rawData.TorqueValue = 0.0;
            _rawData.TorqueMaxValue = 0.0;
            _rawData.TorqueFinalValue = 0.0;
        }

        /// <inheritdoc/>
        public void UpdateComPortList()
        {
            _lmData.comPortList = SerialPortHelper.GetAvailablePorts();
        }

        #endregion Methods

        #region Events

        private void AcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs e)
        {
        }

        #endregion Events

        #region IDisposable Members

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    // 釋放受控資源
                    _scope?.Dispose();

                    // 解除事件訂閱
                    if (_acm != null)
                        _acm.AcmStatusUpdated -= AcmStatusUpdated;
                }

                // 釋放非受控資源（如果有）

                // TODO: 釋出非受控資源 (非受控物件) 並覆寫完成項
                // TODO: 將大型欄位設為 Null

                _disposedValue = true;
            }
        }

        // // TODO: 僅有當 'Dispose(bool disposing)' 具有會釋出非受控資源的程式碼時，才覆寫完成項
        // ~LockingMachineService()
        // {
        //     // 請勿變更此程式碼。請將清除程式碼放入 'Dispose(bool disposing)' 方法
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // 請勿變更此程式碼。請將清除程式碼放入 'Dispose(bool disposing)' 方法
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        #endregion IDisposable Members
    }
}
