﻿namespace Calin.LockingMachine.Models
{
    public class RawData
    {
        #region 作業狀態

        /// <summary>
        /// 量測中。
        /// </summary>
        public bool IsMeasuring = false;

        #endregion 作業狀態

        #region 軸卡

        /// <summary>
        /// Z軸目前座標。
        /// </summary>
        public double ZAxisCoor;

        /// <summary>
        /// R軸目前轉速(RPM)。
        /// </summary>
        public double RPM;

        /// <summary>
        /// R軸目前角度。
        /// </summary>
        public double Angle;

        #endregion 軸卡

        #region 扭力計

        /// <summary>
        /// 扭力計讀數。
        /// </summary>
        public double TorqueValue;

        /// <summary>
        /// 扭力計最終值。
        /// </summary>
        public double TorqueFinalValue;

        /// <summary>
        /// 扭力計最大值。
        /// </summary>
        public double TorqueMaxValue;

        /// <summary>
        /// 扭力計上限值。
        /// </summary>
        public double TorqueLimitH;

        /// <summary>
        /// 扭力計下限值。
        /// </summary>
        public double TorqueLimitL;

        #endregion 扭力計

        #region 高度計

        /// <summary>
        /// 高度計讀數。
        /// </summary>
        public double HeightDisplacementValue;

        /// <summary>
        /// 高度計最終值。
        /// </summary>
        public double HeightDisplacementFinalValue;

        /// <summary>
        /// 高度計最大值。
        /// </summary>
        public double HeightDisplacementMaxValue;

        /// <summary>
        /// 高度計上限值。
        /// </summary>
        public double HeightDisplacementLimitH;

        /// <summary>
        /// 高度計下限值。
        /// </summary>
        public double HeightDisplacementLimitL;

        /// <summary>
        /// 等待接收高度位移值的次數。
        /// </summary>
        public int WaitForReceiveHeightDisplacement = 0;

        #endregion 高度計

        #region USB4704

        public bool DI0;
        public bool DI1;
        public bool DI2;
        public bool DI3;
        public bool DI4;
        public bool DI5;
        public bool DI6;
        public bool DI7;

        #endregion USB4704

#if DEBUG
        /// <summary>
        /// 扭力計碼表讀取時間。
        /// </summary>
        public double TorqueStopwatch;

        /// <summary>
        /// 高度計碼表讀取時間。
        /// </summary>
        public double HeightDisplacementStopwatch = 0;
#endif
    }
}
