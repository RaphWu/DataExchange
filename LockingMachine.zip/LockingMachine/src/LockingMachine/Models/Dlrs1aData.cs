﻿using Calin.Comm.DL_RS1A;

namespace Calin.LockingMachine.Models
{
    /// <summary>
    /// DL-RS1A 資料模型。
    /// </summary>
    /// <remarks>DL-RS1A 設定，會儲存成 .JSON 檔。</remarks>
    public class Dlrs1aData
    {
        public DL_RS1A_Config Dlrs1aConfig { get; set; } = new DL_RS1A_Config();

        // 高度計
        public double HeightDispLimitH { get; set; } = 20.0;
        public double HeightDispLimitL { get; set; } = 10.0;
    }
}
