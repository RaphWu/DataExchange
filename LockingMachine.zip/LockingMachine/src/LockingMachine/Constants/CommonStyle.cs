﻿using System.Drawing;

namespace Calin.LockingMachine.Constants
{
    public static class CommonStyle
    {
        public static Font TextFont = new Font("微軟正黑體", 9F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(136)));
        public static Font TextFontBold = new Font("微軟正黑體", 9F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(136)));

        public static Color BgDeviceInOperation = Color.Maroon;
        public static Color FgDeviceInOperation = Color.Yellow;

        public static Color BgHeader = Color.LightSkyBlue;
        public static Color FgHeader = SystemColors.ControlText;

        public static Color SignalOn = Color.Gold;
        public static Color SignalOff = Color.Transparent;
    }
}
