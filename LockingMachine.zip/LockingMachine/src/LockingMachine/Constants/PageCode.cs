﻿namespace Calin.LockingMachine.Constants
{
    public enum PageCode
    {
        None,

        MainPage,
        Monitor,
        ProcessFlow,
        Manual,
        Setup,
    }
}
