using System.ComponentModel;
using Calin.LockingMachine.Constants;
using Calin.LockingMachine.Events;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.ProcessFlow.UI;
using Calin.LockingMachine.Views;
using Calin.MotionControl.Advantech.Contracts;
using Calin.Navigation;
using CommunityToolkit.Mvvm.Messaging;

namespace Calin.LockingMachine
{
    public partial class MainForm : Form
    {
        #region Fields

        private readonly IRegionManager _region;
        private readonly INavigationService _nav;
        private readonly IAcm _acm;
        private readonly BindingData _bindingData;

        // ���A�C�T���p�ɾ��A�w�ɲM���T��
        private readonly System.Timers.Timer _messageTimer = new System.Timers.Timer();

        private PageCode _currentPageCode = PageCode.None;

        #endregion Fields

        #region ctor

        public MainForm(
            IRegionManager regionManager,
            INavigationService navigationService,
            IAcm acm,
            BindingData bindingData)
        {
            _region = regionManager;
            _nav = navigationService;
            _acm = acm;
            _bindingData = bindingData;

            InitializeComponent();

            // Region ���U
            _region.RegisterRegion(nameof(ContentPanel), view =>
            {
                ContentPanel.SuspendLayout();
                ContentPanel.Controls.Clear();
                if (view is Control control)
                {
                    control.Dock = DockStyle.Fill;
                    ContentPanel.Controls.Add(control);
                }
                ContentPanel.ResumeLayout();
            });

            // Status Bar
            _bindingData.PropertyChanged += MainFormData_PropertyChanged;

            // ���U���A�C�T�������
            _messageTimer.AutoReset = false;
            _messageTimer.Elapsed += (s, e) => { sbMessage.Text = ""; };
            WeakReferenceMessenger.Default.Register<ShowStatusBarMessage>(this, (recipient, message) =>
            {
                _messageTimer.Stop();
                if (message?.Value != null)
                {
                    sbMessage.Text = message.Value.Message;
                    if (message.Value.Duration > 0)
                    {
                        _messageTimer.Interval = message.Value.Duration;
                        _messageTimer.Start();
                    }
                }
            });

            //���U���A�C�i�ױ����
            //WeakReferenceMessenger.Default.Register<ShowProcessBar>(this, (recipient, message) =>
            //{
            //    ProcessBarInfo info = message.Value;
            //    SetProcessBar(info.Percent);
            //    if (!string.IsNullOrWhiteSpace(info.Message))
            //    {
            //        SBMessage.Text = info.Message;
            //        _messageTimer.ReStart();
            //    }
            //    else
            //    {
            //        SBMessage.Text = "";
            //    }
            //});
        }

        #endregion ctor

        #region Form Events

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_acm.IsBoardInit)
            {
                _acm.PollingStop();
                _acm.BoardClose();
            }

            // ����Ҧ� Timer
            _messageTimer?.Stop();
            _messageTimer?.Dispose();

            ClockTimer?.Stop();
            ClockTimer?.Dispose();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ResizeScreen();
            UpdateStatusBar(); // ��l�ƪ��A�C��ܤ��e

            _acm.BoardOpen();
            if (_acm.IsBoardInit)
            {
                _acm.PollingStart();
                _bindingData.ZAxisActive = true;
                _bindingData.RAxisActive = true;
            }
            else
            {
                _bindingData.ZAxisActive = false;
                _bindingData.RAxisActive = false;
            }
        }

        /// <summary>
        /// �� MainFormData �ݩ��ܧ��Ĳ�o�C
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainFormData_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            UpdateStatusBar(e.PropertyName);
        }

        /// <summary>
        /// ��s���A�C�������e�C
        /// </summary>
        private void UpdateStatusBar()
        {
            UpdateStatusBar("");
        }

        /// <summary>
        /// ��s���A�C��ܤ��e�C
        /// </summary>
        /// <param name="propertyName"></param>
        private void UpdateStatusBar(string propertyName)
        {
            bool updateAll = string.IsNullOrEmpty(propertyName);

            // Z�b
            if (propertyName == nameof(BindingData.ZAxisActive) || updateAll)
            {
                if (_bindingData.ZAxisActive)
                {
                    sbZTitle.BackColor = SystemColors.Control;
                    sbZTitle.ForeColor = SystemColors.ControlText;
                    sbZ.BackColor = SystemColors.Control;
                    sbZ.ForeColor = SystemColors.ControlText;
                }
                else
                {
                    sbZTitle.BackColor = CommonStyle.BgDeviceInOperation;
                    sbZTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                    sbZ.BackColor = CommonStyle.BgDeviceInOperation;
                    sbZ.ForeColor = CommonStyle.FgDeviceInOperation;
                }
            }

            if (propertyName == nameof(BindingData.ZAxisCoor) || updateAll)
                sbZ.Text = _bindingData.ZAxisCoor.ToString("F3");

            // R�b
            if (propertyName == nameof(BindingData.RAxisActive) || updateAll)
            {
                if (_bindingData.RAxisActive)
                {
                    sbRTitle.BackColor = SystemColors.Control;
                    sbRTitle.ForeColor = SystemColors.ControlText;
                    sbR.BackColor = SystemColors.Control;
                    sbR.ForeColor = SystemColors.ControlText;
                }
                else
                {
                    sbRTitle.BackColor = CommonStyle.BgDeviceInOperation;
                    sbRTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                    sbR.BackColor = CommonStyle.BgDeviceInOperation;
                    sbR.ForeColor = CommonStyle.FgDeviceInOperation;
                }
            }

            if (propertyName == nameof(BindingData.Angle) || updateAll)
                sbR.Text = _bindingData.Angle.ToString("F1");

            // ��O�p
            if (propertyName == nameof(BindingData.TorqueMeterActive) || updateAll)
            {
                if (_bindingData.TorqueMeterActive)
                {
                    sbTorqueTitle.BackColor = SystemColors.Control;
                    sbTorqueTitle.ForeColor = SystemColors.ControlText;
                    sbTorque.BackColor = SystemColors.Control;
                    sbTorque.ForeColor = SystemColors.ControlText;
                }
                else
                {
                    sbTorqueTitle.BackColor = CommonStyle.BgDeviceInOperation;
                    sbTorqueTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                    sbTorque.BackColor = CommonStyle.BgDeviceInOperation;
                    sbTorque.ForeColor = CommonStyle.FgDeviceInOperation;
                }
            }

            if (propertyName == nameof(BindingData.TorqueValue) || updateAll)
                sbTorque.Text = _bindingData.TorqueValue.ToString("F3");

            // LD_RS1A
            if (propertyName == nameof(BindingData.HeightDisplacementActive) || updateAll)
            {
                if (_bindingData.HeightDisplacementActive)
                {
                    sbHeightTitle.BackColor = SystemColors.Control;
                    sbHeightTitle.ForeColor = SystemColors.ControlText;
                    sbHeight.BackColor = SystemColors.Control;
                    sbHeight.ForeColor = SystemColors.ControlText;
                }
                else
                {
                    sbHeightTitle.BackColor = CommonStyle.BgDeviceInOperation;
                    sbHeightTitle.ForeColor = CommonStyle.FgDeviceInOperation;
                    sbHeight.BackColor = CommonStyle.BgDeviceInOperation;
                    sbHeight.ForeColor = CommonStyle.FgDeviceInOperation;
                }
            }

            if (propertyName == nameof(BindingData.HeightDisplacementValue) || updateAll)
                sbHeight.Text = _bindingData.HeightDisplacementValue.ToString("F3");
        }

        #endregion Form Events

        #region Form Methods

        /// <summary>
        /// �վ�����j�p�C
        /// </summary>
        private void ResizeScreen()
        {
            const int TARGET_WIDTH = 1024;
            const int TARGET_HEIGHT = 768;
            var screenArea = Screen.PrimaryScreen.WorkingArea;

            if (screenArea.Width > TARGET_WIDTH)
            {
                WindowState = FormWindowState.Normal;
                StartPosition = FormStartPosition.CenterScreen;
                Width = TARGET_WIDTH;
                Height = TARGET_HEIGHT;
                Left = (screenArea.Width - TARGET_WIDTH) / 2;
                Top = (screenArea.Height - TARGET_HEIGHT) / 2;
            }
            else
            {
                WindowState = FormWindowState.Maximized;
            }
        }

        #endregion Form Methods

        #region Timer

        private void ClockTimer_Tick(object sender, EventArgs e)
        {
            sbClock.Text = DateTime.Now.ToString();
        }

        #endregion Timer

        #region Navigation

        /// <summary>
        /// �����ާ@�����C
        /// </summary>
        /// <param name="pageCode">�������ޡC</param>
        private void SwitchPage(PageCode pageCode)
        {
            if (_currentPageCode == pageCode) return;

            switch (pageCode)
            {
                case PageCode.MainPage:
                    _nav.NavigateTo<MainPage>(nameof(ContentPanel), (int)PageCode.MainPage);
                    break;
                case PageCode.ProcessFlow:
                    _nav.NavigateTo<ProcessFlowMainForm>(nameof(ContentPanel), (int)PageCode.ProcessFlow);
                    break;
                case PageCode.Monitor:
                    _nav.NavigateTo<Views.Monitor>(nameof(ContentPanel), (int)PageCode.Monitor);
                    break;
                case PageCode.Setup:
                    _nav.NavigateTo<SetupPage>(nameof(ContentPanel), (int)PageCode.Setup);
                    break;
                default:
                    return;
            }
            _currentPageCode = pageCode;
        }

        private void MenuMain_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.MainPage);
        }

        private void MenuWorkSetup_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.ProcessFlow);
        }

        private void MenuMonitor_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Monitor);
        }

        private void MenuSetup_Click(object sender, EventArgs e)
        {
            SwitchPage(PageCode.Setup);
        }

        #endregion Navigation
    }
}
