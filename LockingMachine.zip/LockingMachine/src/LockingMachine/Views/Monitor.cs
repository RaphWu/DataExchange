﻿using System;
using System.Windows.Forms;
using Advantech.Motion;
using Calin.Extensions;
using Calin.LockingMachine.Constants;
using Calin.LockingMachine.Ext;
using Calin.LockingMachine.Models;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.MotionControl.Advantech.Services;
using Calin.Navigation;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class Monitor : UserControl
    {
        #region Fields

        private readonly IAcm _acm;
        private readonly BindingData _bindingData;

        // 軸狀態旗標Buffers
        private bool STA_AX_DISABLE = false;
        private bool STA_AX_READY = false;
        private bool STA_AX_STOPPING = false;
        private bool STA_AX_ERROR_STOP = false;
        private bool STA_AX_HOMING = false;
        private bool STA_AX_PTP_MOTION = false;
        private bool STA_AX_CONTI_MOTION = false;
        private bool STA_AX_SYNC_MOTION = false;
        private bool STA_AX_EXT_JOG = false;
        private bool STA_AX_EXT_MPG = false;
        private bool STA_AX_PAUSE = false;
        private bool STA_AX_BUSY = false;
        private bool STA_AX_WAIT_DI = false;
        private bool STA_AX_WAIT_PTP = false;
        private bool STA_AX_WAIT_VEL = false;
        private bool STA_AX_EXT_JOG_READY = false;

        // 軸運動旗標Buffers
        private bool Stop = false;
        private bool WaitERC = false;
        private bool CorrectBksh = false;
        private bool InFA = false;
        private bool InFL = false;
        private bool InACC = false;
        private bool InFH = false;
        private bool InDEC = false;
        private bool WaitINP = false;

        // 軸的運動 I/O 旗標Buffers
        private bool RDY = false;
        private bool ALM = false;
        private bool LMT_Positive = false;
        private bool LMT_Negative = false;
        private bool ORG = false;
        private bool DIR = false;
        private bool EMG = false;
        private bool PCS = false;
        private bool ERC = false;
        private bool EZ = false;
        private bool CLR = false;
        private bool LTC = false;
        private bool SD = false;
        private bool INP = false;
        private bool SVON = false;
        private bool ALRM = false;
        private bool SLMT_Positive = false;
        private bool SLMT_Negative = false;
        private bool CMP = false;
        private bool CAMDO = false;

        #endregion Fields

        public Monitor(IAcm acm, BindingData bindingData)
        {
            _acm = acm;
            _bindingData = bindingData;

            InitializeComponent();

            pbDI0.BindBackColorToBool(_bindingData, nameof(BindingData.DI0), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI1.BindBackColorToBool(_bindingData, nameof(BindingData.DI1), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI2.BindBackColorToBool(_bindingData, nameof(BindingData.DI2), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI3.BindBackColorToBool(_bindingData, nameof(BindingData.DI3), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI4.BindBackColorToBool(_bindingData, nameof(BindingData.DI4), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI5.BindBackColorToBool(_bindingData, nameof(BindingData.DI5), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI6.BindBackColorToBool(_bindingData, nameof(BindingData.DI6), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            pbDI7.BindBackColorToBool(_bindingData, nameof(BindingData.DI7), CommonStyle.SignalOn, CommonStyle.SignalOff, true);

            _acm.AcmStatusUpdated += OnAcmStatusUpdated;
        }

        private void OnAcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs asue)
        {
            ThreadExt.RunOnUiThread(() =>
            {
            int axisNo = asue.AxisNo;
            var parsedAxisState = asue.ParsedAxisState;

            // 軸狀態
            var axisState = parsedAxisState.AxisStateFlags;
            if (STA_AX_DISABLE != parsedAxisState.STA_AX_DISABLE)

        private bool STA_AX_READY = false;
        private bool STA_AX_STOPPING = false;
        private bool STA_AX_ERROR_STOP = false;
        private bool STA_AX_HOMING = false;
        private bool STA_AX_PTP_MOTION = false;
        private bool STA_AX_CONTI_MOTION = false;
        private bool STA_AX_SYNC_MOTION = false;
        private bool STA_AX_EXT_JOG = false;
        private bool STA_AX_EXT_MPG = false;
        private bool STA_AX_PAUSE = false;
        private bool STA_AX_BUSY = false;
        private bool STA_AX_WAIT_DI = false;
        private bool STA_AX_WAIT_PTP = false;
        private bool STA_AX_WAIT_VEL = false;
        private bool STA_AX_EXT_JOG_READY = false;

    });
        }
    }
}
