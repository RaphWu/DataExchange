﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Calin.Extensions;
using Calin.Helpers;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.SharedUI.StatusIndicator;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;
using Calin.MotionControl.Advantech.Services;
using Calin.Navigation;

namespace Calin.LockingMachine.Views
{
    internal struct SingleMapping
    {
        public int Index;
        public string Description;
    }

    [ViewLifetime(IsAlive = true)]
    public partial class Monitor : UserControl
    {
        #region Fields

        private readonly IAcm _acm;

        Dictionary<AxisStateFlags, SingleMapping> axisStatusCaptin = new Dictionary<AxisStateFlags, SingleMapping>();
        Dictionary<AxisMotionFlags, SingleMapping> axisMotionStatusCaption = new Dictionary<AxisMotionFlags, SingleMapping>();
        Dictionary<AxisIoFlags, SingleMapping> axisIoStatusCaption = new Dictionary<AxisIoFlags, SingleMapping>();

        // 軸狀態旗標Buffers
        private bool[] STA_AX_DISABLE;
        private bool[] STA_AX_READY;
        private bool[] STA_AX_STOPPING;
        private bool[] STA_AX_ERROR_STOP;
        private bool[] STA_AX_HOMING;
        private bool[] STA_AX_PTP_MOTION;
        private bool[] STA_AX_CONTI_MOTION;
        private bool[] STA_AX_SYNC_MOTION;
        private bool[] STA_AX_EXT_JOG;
        private bool[] STA_AX_EXT_MPG;
        private bool[] STA_AX_PAUSE;
        private bool[] STA_AX_BUSY;
        private bool[] STA_AX_WAIT_DI;
        private bool[] STA_AX_WAIT_PTP;
        private bool[] STA_AX_WAIT_VEL;
        private bool[] STA_AX_EXT_JOG_READY;

        // 軸運動旗標Buffers
        private bool[] Stop;
        private bool[] CorrectBksh;
        private bool[] InFA;
        private bool[] InFL;
        private bool[] InACC;
        private bool[] InFH;
        private bool[] InDEC;
        private bool[] WaitINP;

        // 軸的運動 I/O 旗標Buffers
        private bool[] RDY;
        private bool[] ALM;
        private bool[] LMT_Positive;
        private bool[] LMT_Negative;
        private bool[] ORG;
        private bool[] DIR;
        private bool[] EMG;
        private bool[] EZ;
        private bool[] LTC;
        private bool[] INP;
        private bool[] SVON;
        private bool[] ALRM;
        private bool[] SLMT_Positive;
        private bool[] SLMT_Negative;

        #endregion Fields

        public Monitor(IAcm acm, BindingData bindingData)
        {
            _acm = acm;

            InitializeComponent();

            // 軸狀態旗標Buffers
            STA_AX_DISABLE = new bool[2];
            STA_AX_READY = new bool[2];
            STA_AX_STOPPING = new bool[2];
            STA_AX_ERROR_STOP = new bool[2];
            STA_AX_HOMING = new bool[2];
            STA_AX_PTP_MOTION = new bool[2];
            STA_AX_CONTI_MOTION = new bool[2];
            STA_AX_SYNC_MOTION = new bool[2];
            STA_AX_EXT_JOG = new bool[2];
            STA_AX_EXT_MPG = new bool[2];
            STA_AX_PAUSE = new bool[2];
            STA_AX_BUSY = new bool[2];
            STA_AX_WAIT_DI = new bool[2];
            STA_AX_WAIT_PTP = new bool[2];
            STA_AX_WAIT_VEL = new bool[2];
            STA_AX_EXT_JOG_READY = new bool[2];

            // 軸運動旗標Buffers
            Stop = new bool[2];
            CorrectBksh = new bool[2];
            InFA = new bool[2];
            InFL = new bool[2];
            InACC = new bool[2];
            InFH = new bool[2];
            InDEC = new bool[2];
            WaitINP = new bool[2];

            // 軸的運動 I/O 旗標Buffers
            RDY = new bool[2];
            ALM = new bool[2];
            LMT_Positive = new bool[2];
            LMT_Negative = new bool[2];
            ORG = new bool[2];
            DIR = new bool[2];
            EMG = new bool[2];
            EZ = new bool[2];
            LTC = new bool[2];
            INP = new bool[2];
            SVON = new bool[2];
            ALRM = new bool[2];
            SLMT_Positive = new bool[2];
            SLMT_Negative = new bool[2];

            // 初始化軸卡狀態指示燈
            int idx = 0;
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_DISABLE, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_DISABLE.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_READY, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_READY.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_STOPPING, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_STOPPING.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_ERROR_STOP, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_ERROR_STOP.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_HOMING, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_HOMING.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_PTP_MOTION, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_PTP_MOTION.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_CONTI_MOTION, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_CONTI_MOTION.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_SYNC_MOTION, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_SYNC_MOTION.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_EXT_JOG, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_EXT_JOG.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_EXT_MPG, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_EXT_MPG.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_PAUSE, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_PAUSE.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_BUSY, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_BUSY.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_WAIT_DI, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_WAIT_DI.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_WAIT_PTP, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_WAIT_PTP.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_WAIT_VEL, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_WAIT_VEL.GetDescription() });
            axisStatusCaptin.Add(AxisStateFlags.STA_AX_EXT_JOG_READY, new SingleMapping { Index = idx++, Description = AxisStateFlags.STA_AX_EXT_JOG_READY.GetDescription() });

            axisMotionStatusCaption.Add(AxisMotionFlags.Stop, new SingleMapping { Index = idx++, Description = AxisMotionFlags.Stop.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.CorrectBksh, new SingleMapping { Index = idx++, Description = AxisMotionFlags.CorrectBksh.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InFA, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InFA.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InFL, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InFL.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InACC, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InACC.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InFH, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InFH.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.InDEC, new SingleMapping { Index = idx++, Description = AxisMotionFlags.InDEC.GetDescription() });
            axisMotionStatusCaption.Add(AxisMotionFlags.WaitINP, new SingleMapping { Index = idx++, Description = AxisMotionFlags.WaitINP.GetDescription() });

            axisIoStatusCaption.Add(AxisIoFlags.RDY, new SingleMapping { Index = idx++, Description = AxisIoFlags.RDY.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.ALM, new SingleMapping { Index = idx++, Description = AxisIoFlags.ALM.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.LMT_Positive, new SingleMapping { Index = idx++, Description = AxisIoFlags.LMT_Positive.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.LMT_Negative, new SingleMapping { Index = idx++, Description = AxisIoFlags.LMT_Negative.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.ORG, new SingleMapping { Index = idx++, Description = AxisIoFlags.ORG.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.DIR, new SingleMapping { Index = idx++, Description = AxisIoFlags.DIR.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.EMG, new SingleMapping { Index = idx++, Description = AxisIoFlags.EMG.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.EZ, new SingleMapping { Index = idx++, Description = AxisIoFlags.EZ.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.LTC, new SingleMapping { Index = idx++, Description = AxisIoFlags.LTC.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.INP, new SingleMapping { Index = idx++, Description = AxisIoFlags.INP.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.SVON, new SingleMapping { Index = idx++, Description = AxisIoFlags.SVON.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.ALRM, new SingleMapping { Index = idx++, Description = AxisIoFlags.ALRM.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.SLMT_Positive, new SingleMapping { Index = idx++, Description = AxisIoFlags.SLMT_Positive.GetDescription() });
            axisIoStatusCaption.Add(AxisIoFlags.SLMT_Negative, new SingleMapping { Index = idx++, Description = AxisIoFlags.SLMT_Negative.GetDescription() });

            var axisColumnCount = new List<int>
            {
                axisStatusCaptin.Count(),
                axisMotionStatusCaption.Count(),
                axisIoStatusCaption.Count()
            };
            var axisColumnHeaderName = new List<string>
            {
                "軸狀態",
                "運動狀態",
                "軸I/O"
            };

            axis1Indicator.Columns = axisColumnCount;
            axis1Indicator.ColumnHeaders = axisColumnHeaderName;
            var axis1ItemList = new List<MultiCircularIndicator.IndicatorItem>();
            foreach (var item in axisStatusCaptin)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            foreach (var item in axisMotionStatusCaption)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            foreach (var item in axisIoStatusCaption)
                axis1ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            axis1Indicator.SetIndicators(axis1ItemList);
            axis1Indicator.Size = axis1Indicator.GetPreferredSize();

            axis2Indicator.Columns = axisColumnCount;
            axis2Indicator.ColumnHeaders = axisColumnHeaderName;
            var axis2ItemList = new List<MultiCircularIndicator.IndicatorItem>();
            foreach (var item in axisStatusCaptin)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            foreach (var item in axisMotionStatusCaption)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            foreach (var item in axisIoStatusCaption)
                axis2ItemList.Add(new MultiCircularIndicator.IndicatorItem { Text = item.Value.Description });
            axis2Indicator.SetIndicators(axis2ItemList);
            axis2Indicator.Size = axis2Indicator.GetPreferredSize();

            //pbDI0.BindBackColorToBool(_bindingData, nameof(BindingData.DI0), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI1.BindBackColorToBool(_bindingData, nameof(BindingData.DI1), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI2.BindBackColorToBool(_bindingData, nameof(BindingData.DI2), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI3.BindBackColorToBool(_bindingData, nameof(BindingData.DI3), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI4.BindBackColorToBool(_bindingData, nameof(BindingData.DI4), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI5.BindBackColorToBool(_bindingData, nameof(BindingData.DI5), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI6.BindBackColorToBool(_bindingData, nameof(BindingData.DI6), CommonStyle.SignalOn, CommonStyle.SignalOff, true);
            //pbDI7.BindBackColorToBool(_bindingData, nameof(BindingData.DI7), CommonStyle.SignalOn, CommonStyle.SignalOff, true);

            _acm.AcmStatusUpdated += OnAcmStatusUpdated;
        }

        /// <summary>
        /// 軸狀態更新事件處理程序。
        /// </summary>
        private void OnAcmStatusUpdated(object sender, AcmStatusUpdatedEventArgs asue)
        {
            ThreadExt.RunOnUiThread(() =>
            {
                int axisNo = asue.AxisNo;
                var parsedAxisState = asue.ParsedAxisState;

                if (axisNo == 0)
                    axis1Indicator.BeginUpdate();
                else
                    axis2Indicator.BeginUpdate();

                int index = default;

                // 軸狀態
                var axisState = parsedAxisState.AxisStateFlags;
                if (STA_AX_DISABLE[axisNo] != parsedAxisState.STA_AX_DISABLE)
                {
                    STA_AX_DISABLE[axisNo] = parsedAxisState.STA_AX_DISABLE;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_DISABLE].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_READY[axisNo] != parsedAxisState.STA_AX_READY)
                {
                    STA_AX_READY[axisNo] = parsedAxisState.STA_AX_READY;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_READY].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_STOPPING[axisNo] != parsedAxisState.STA_AX_STOPPING)
                {
                    STA_AX_STOPPING[axisNo] = parsedAxisState.STA_AX_STOPPING;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_STOPPING].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_ERROR_STOP[axisNo] != parsedAxisState.STA_AX_ERROR_STOP)
                {
                    STA_AX_ERROR_STOP[axisNo] = parsedAxisState.STA_AX_ERROR_STOP;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_ERROR_STOP].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_HOMING[axisNo] != parsedAxisState.STA_AX_HOMING)
                {
                    STA_AX_HOMING[axisNo] = parsedAxisState.STA_AX_HOMING;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_HOMING].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_PTP_MOTION[axisNo] != parsedAxisState.STA_AX_PTP_MOTION)
                {
                    STA_AX_PTP_MOTION[axisNo] = parsedAxisState.STA_AX_PTP_MOTION;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_PTP_MOTION].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_CONTI_MOTION[axisNo] != parsedAxisState.STA_AX_CONTI_MOTION)
                {
                    STA_AX_CONTI_MOTION[axisNo] = parsedAxisState.STA_AX_CONTI_MOTION;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_CONTI_MOTION].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_SYNC_MOTION[axisNo] != parsedAxisState.STA_AX_SYNC_MOTION)
                {
                    STA_AX_SYNC_MOTION[axisNo] = parsedAxisState.STA_AX_SYNC_MOTION;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_SYNC_MOTION].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_EXT_JOG[axisNo] != parsedAxisState.STA_AX_EXT_JOG)
                {
                    STA_AX_EXT_JOG[axisNo] = parsedAxisState.STA_AX_EXT_JOG;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_EXT_JOG].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_EXT_MPG[axisNo] != parsedAxisState.STA_AX_EXT_MPG)
                {
                    STA_AX_EXT_MPG[axisNo] = parsedAxisState.STA_AX_EXT_MPG;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_EXT_MPG].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_PAUSE[axisNo] != parsedAxisState.STA_AX_PAUSE)
                {
                    STA_AX_PAUSE[axisNo] = parsedAxisState.STA_AX_PAUSE;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_PAUSE].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_BUSY[axisNo] != parsedAxisState.STA_AX_BUSY)
                {
                    STA_AX_BUSY[axisNo] = parsedAxisState.STA_AX_BUSY;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_BUSY].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_WAIT_DI[axisNo] != parsedAxisState.STA_AX_WAIT_DI)
                {
                    STA_AX_WAIT_DI[axisNo] = parsedAxisState.STA_AX_WAIT_DI;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_WAIT_DI].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_WAIT_PTP[axisNo] != parsedAxisState.STA_AX_WAIT_PTP)
                {
                    STA_AX_WAIT_PTP[axisNo] = parsedAxisState.STA_AX_WAIT_PTP;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_WAIT_PTP].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_WAIT_VEL[axisNo] != parsedAxisState.STA_AX_WAIT_VEL)
                {
                    STA_AX_WAIT_VEL[axisNo] = parsedAxisState.STA_AX_WAIT_VEL;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_WAIT_VEL].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (STA_AX_EXT_JOG_READY[axisNo] != parsedAxisState.STA_AX_EXT_JOG_READY)
                {
                    STA_AX_EXT_JOG_READY[axisNo] = parsedAxisState.STA_AX_EXT_JOG_READY;
                    index = axisStatusCaptin[AxisStateFlags.STA_AX_EXT_JOG_READY].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }

                // 軸運動狀態
                var axisMotionState = parsedAxisState.AxisMotionFlags;
                if (Stop[axisNo] != parsedAxisState.Stop)
                {
                    Stop[axisNo] = parsedAxisState.Stop;
                    index = axisMotionStatusCaption[AxisMotionFlags.Stop].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (CorrectBksh[axisNo] != parsedAxisState.CorrectBksh)
                {
                    CorrectBksh[axisNo] = parsedAxisState.CorrectBksh;
                    index = axisMotionStatusCaption[AxisMotionFlags.CorrectBksh].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (InFA[axisNo] != parsedAxisState.InFA)
                {
                    InFA[axisNo] = parsedAxisState.InFA;
                    index = axisMotionStatusCaption[AxisMotionFlags.InFA].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (InFL[axisNo] != parsedAxisState.InFL)
                {
                    InFL[axisNo] = parsedAxisState.InFL;
                    index = axisMotionStatusCaption[AxisMotionFlags.InFL].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (InACC[axisNo] != parsedAxisState.InACC)
                {
                    InACC[axisNo] = parsedAxisState.InACC;
                    index = axisMotionStatusCaption[AxisMotionFlags.InACC].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (InACC[axisNo] != parsedAxisState.InACC)
                {
                    InACC[axisNo] = parsedAxisState.InACC;
                    index = axisMotionStatusCaption[AxisMotionFlags.InACC].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (InFH[axisNo] != parsedAxisState.InFH)
                {
                    InFH[axisNo] = parsedAxisState.InFH;
                    index = axisMotionStatusCaption[AxisMotionFlags.InFH].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (InDEC[axisNo] != parsedAxisState.InDEC)
                {
                    InDEC[axisNo] = parsedAxisState.InDEC;
                    index = axisMotionStatusCaption[AxisMotionFlags.InDEC].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (WaitINP[axisNo] != parsedAxisState.WaitINP)
                {
                    WaitINP[axisNo] = parsedAxisState.WaitINP;
                    index = axisMotionStatusCaption[AxisMotionFlags.WaitINP].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }

                // 軸 I/O
                var axisIoState = parsedAxisState.AxisIoFlags;
                if (RDY[axisNo] != parsedAxisState.RDY)
                {
                    RDY[axisNo] = parsedAxisState.RDY;
                    index = axisIoStatusCaption[AxisIoFlags.RDY].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (ALM[axisNo] != parsedAxisState.ALM)
                {
                    ALM[axisNo] = parsedAxisState.ALM;
                    index = axisIoStatusCaption[AxisIoFlags.ALM].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (LMT_Positive[axisNo] != parsedAxisState.LMT_Positive)
                {
                    LMT_Positive[axisNo] = parsedAxisState.LMT_Positive;
                    index = axisIoStatusCaption[AxisIoFlags.LMT_Positive].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (LMT_Negative[axisNo] != parsedAxisState.LMT_Negative)
                {
                    LMT_Negative[axisNo] = parsedAxisState.LMT_Negative;
                    index = axisIoStatusCaption[AxisIoFlags.LMT_Negative].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (ORG[axisNo] != parsedAxisState.ORG)
                {
                    ORG[axisNo] = parsedAxisState.ORG;
                    index = axisIoStatusCaption[AxisIoFlags.ORG].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (DIR[axisNo] != parsedAxisState.DIR)
                {
                    DIR[axisNo] = parsedAxisState.DIR;
                    index = axisIoStatusCaption[AxisIoFlags.DIR].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (EMG[axisNo] != parsedAxisState.EMG)
                {
                    EMG[axisNo] = parsedAxisState.EMG;
                    index = axisIoStatusCaption[AxisIoFlags.EMG].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (EZ[axisNo] != parsedAxisState.EZ)
                {
                    EZ[axisNo] = parsedAxisState.EZ;
                    index = axisIoStatusCaption[AxisIoFlags.EZ].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (LTC[axisNo] != parsedAxisState.LTC)
                {
                    LTC[axisNo] = parsedAxisState.LTC;
                    index = axisIoStatusCaption[AxisIoFlags.LTC].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (INP[axisNo] != parsedAxisState.INP)
                {
                    INP[axisNo] = parsedAxisState.INP;
                    index = axisIoStatusCaption[AxisIoFlags.INP].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (SVON[axisNo] != parsedAxisState.SVON)
                {
                    SVON[axisNo] = parsedAxisState.SVON;
                    index = axisIoStatusCaption[AxisIoFlags.SVON].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (ALRM[axisNo] != parsedAxisState.ALRM)
                {
                    ALRM[axisNo] = parsedAxisState.ALRM;
                    index = axisIoStatusCaption[AxisIoFlags.ALRM].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (SLMT_Positive[axisNo] != parsedAxisState.SLMT_Positive)
                {
                    SLMT_Positive[axisNo] = parsedAxisState.SLMT_Positive;
                    index = axisIoStatusCaption[AxisIoFlags.SLMT_Positive].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }
                if (SLMT_Negative[axisNo] != parsedAxisState.SLMT_Negative)
                {
                    SLMT_Negative[axisNo] = parsedAxisState.SLMT_Negative;
                    index = axisIoStatusCaption[AxisIoFlags.SLMT_Negative].Index;
                    if (axisNo == 0)
                        axis1Indicator.UpdateIndicator(index, true);
                    else
                        axis2Indicator.UpdateIndicator(index, true);
                }

                if (axisNo == 0)
                    axis1Indicator.EndUpdate();
                else
                    axis2Indicator.EndUpdate();
            });
        }
    }
}
