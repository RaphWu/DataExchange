﻿namespace Calin.LockingMachine.Views
{
    partial class Monitor
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.pbDI0 = new System.Windows.Forms.PictureBox();
            this.pbDI1 = new System.Windows.Forms.PictureBox();
            this.pbDI3 = new System.Windows.Forms.PictureBox();
            this.pbDI2 = new System.Windows.Forms.PictureBox();
            this.pbDI7 = new System.Windows.Forms.PictureBox();
            this.pbDI6 = new System.Windows.Forms.PictureBox();
            this.pbDI5 = new System.Windows.Forms.PictureBox();
            this.pbDI4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI4)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(62, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "DI0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(62, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "DI1";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(62, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "DI2";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(62, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 21);
            this.label7.TabIndex = 11;
            this.label7.Text = "DI5";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(62, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 21);
            this.label9.TabIndex = 9;
            this.label9.Text = "DI4";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(62, 91);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 21);
            this.label11.TabIndex = 7;
            this.label11.Text = "DI3";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(62, 179);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 21);
            this.label13.TabIndex = 15;
            this.label13.Text = "DI7";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(62, 157);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(42, 21);
            this.label15.TabIndex = 13;
            this.label15.Text = "DI6";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pbDI0
            // 
            this.pbDI0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDI0.Location = new System.Drawing.Point(39, 25);
            this.pbDI0.Name = "pbDI0";
            this.pbDI0.Size = new System.Drawing.Size(21, 21);
            this.pbDI0.TabIndex = 16;
            this.pbDI0.TabStop = false;
            // 
            // pbDI1
            // 
            this.pbDI1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDI1.Location = new System.Drawing.Point(39, 47);
            this.pbDI1.Name = "pbDI1";
            this.pbDI1.Size = new System.Drawing.Size(21, 21);
            this.pbDI1.TabIndex = 17;
            this.pbDI1.TabStop = false;
            // 
            // pbDI3
            // 
            this.pbDI3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDI3.Location = new System.Drawing.Point(39, 91);
            this.pbDI3.Name = "pbDI3";
            this.pbDI3.Size = new System.Drawing.Size(21, 21);
            this.pbDI3.TabIndex = 19;
            this.pbDI3.TabStop = false;
            // 
            // pbDI2
            // 
            this.pbDI2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDI2.Location = new System.Drawing.Point(39, 69);
            this.pbDI2.Name = "pbDI2";
            this.pbDI2.Size = new System.Drawing.Size(21, 21);
            this.pbDI2.TabIndex = 18;
            this.pbDI2.TabStop = false;
            // 
            // pbDI7
            // 
            this.pbDI7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDI7.Location = new System.Drawing.Point(39, 179);
            this.pbDI7.Name = "pbDI7";
            this.pbDI7.Size = new System.Drawing.Size(21, 21);
            this.pbDI7.TabIndex = 23;
            this.pbDI7.TabStop = false;
            // 
            // pbDI6
            // 
            this.pbDI6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDI6.Location = new System.Drawing.Point(39, 157);
            this.pbDI6.Name = "pbDI6";
            this.pbDI6.Size = new System.Drawing.Size(21, 21);
            this.pbDI6.TabIndex = 22;
            this.pbDI6.TabStop = false;
            // 
            // pbDI5
            // 
            this.pbDI5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDI5.Location = new System.Drawing.Point(39, 135);
            this.pbDI5.Name = "pbDI5";
            this.pbDI5.Size = new System.Drawing.Size(21, 21);
            this.pbDI5.TabIndex = 21;
            this.pbDI5.TabStop = false;
            // 
            // pbDI4
            // 
            this.pbDI4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDI4.Location = new System.Drawing.Point(39, 113);
            this.pbDI4.Name = "pbDI4";
            this.pbDI4.Size = new System.Drawing.Size(21, 21);
            this.pbDI4.TabIndex = 20;
            this.pbDI4.TabStop = false;
            // 
            // Monitor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pbDI7);
            this.Controls.Add(this.pbDI6);
            this.Controls.Add(this.pbDI5);
            this.Controls.Add(this.pbDI4);
            this.Controls.Add(this.pbDI3);
            this.Controls.Add(this.pbDI2);
            this.Controls.Add(this.pbDI1);
            this.Controls.Add(this.pbDI0);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Monitor";
            this.Size = new System.Drawing.Size(1000, 660);
            ((System.ComponentModel.ISupportInitialize)(this.pbDI0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDI4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Label label2;
        private Label label3;
        private Label label5;
        private Label label7;
        private Label label9;
        private Label label11;
        private Label label13;
        private Label label15;
        private PictureBox pbDI0;
        private PictureBox pbDI1;
        private PictureBox pbDI3;
        private PictureBox pbDI2;
        private PictureBox pbDI7;
        private PictureBox pbDI6;
        private PictureBox pbDI5;
        private PictureBox pbDI4;
    }
}
