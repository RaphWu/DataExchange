﻿using System.Windows.Forms;
using Calin.Navigation;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class ManualPage : UserControl
    {
        public ManualPage()
        {
            InitializeComponent();
        }
    }
}
