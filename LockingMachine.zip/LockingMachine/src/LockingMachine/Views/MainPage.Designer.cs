﻿using System.Windows.Forms;

namespace Calin.LockingMachine.Views
{
    partial class MainPage
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.gbHeightDisplacement = new System.Windows.Forms.GroupBox();
            this.lbHeightDisplacementMaxValue = new System.Windows.Forms.Label();
            this.lbHeightDisplacementFinalValue = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbHeightDisplacementValue = new System.Windows.Forms.Label();
            this.lbHeightDisplacementLimitL = new System.Windows.Forms.Label();
            this.lbHeightDisplacementLimitH = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.gbTorqueMeter = new System.Windows.Forms.GroupBox();
            this.lbTorqueMaxValue = new System.Windows.Forms.Label();
            this.lbTorqueFinalValue = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbTorqueValue = new System.Windows.Forms.Label();
            this.lbTorqueLimitL = new System.Windows.Forms.Label();
            this.lbTorqueLimitH = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.cbIsMeasuring = new System.Windows.Forms.CheckBox();
            this.btnTest1 = new System.Windows.Forms.Button();
            this.btnTest2 = new System.Windows.Forms.Button();
            this.ButtonPanel = new System.Windows.Forms.Panel();
            this.BtnStopEmg = new System.Windows.Forms.Button();
            this.BtnStopDec = new System.Windows.Forms.Button();
            this.gbHeightDisplacement.SuspendLayout();
            this.gbTorqueMeter.SuspendLayout();
            this.ButtonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbHeightDisplacement
            // 
            this.gbHeightDisplacement.Controls.Add(this.lbHeightDisplacementMaxValue);
            this.gbHeightDisplacement.Controls.Add(this.lbHeightDisplacementFinalValue);
            this.gbHeightDisplacement.Controls.Add(this.label10);
            this.gbHeightDisplacement.Controls.Add(this.lbHeightDisplacementValue);
            this.gbHeightDisplacement.Controls.Add(this.lbHeightDisplacementLimitL);
            this.gbHeightDisplacement.Controls.Add(this.lbHeightDisplacementLimitH);
            this.gbHeightDisplacement.Controls.Add(this.label14);
            this.gbHeightDisplacement.Controls.Add(this.label15);
            this.gbHeightDisplacement.Controls.Add(this.label16);
            this.gbHeightDisplacement.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.gbHeightDisplacement.Location = new System.Drawing.Point(27, 165);
            this.gbHeightDisplacement.Margin = new System.Windows.Forms.Padding(4);
            this.gbHeightDisplacement.Name = "gbHeightDisplacement";
            this.gbHeightDisplacement.Padding = new System.Windows.Forms.Padding(4);
            this.gbHeightDisplacement.Size = new System.Drawing.Size(450, 130);
            this.gbHeightDisplacement.TabIndex = 11;
            this.gbHeightDisplacement.TabStop = false;
            this.gbHeightDisplacement.Text = "高度 (mm)";
            // 
            // lbHeightDisplacementMaxValue
            // 
            this.lbHeightDisplacementMaxValue.BackColor = System.Drawing.Color.White;
            this.lbHeightDisplacementMaxValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHeightDisplacementMaxValue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbHeightDisplacementMaxValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbHeightDisplacementMaxValue.Location = new System.Drawing.Point(271, 33);
            this.lbHeightDisplacementMaxValue.Name = "lbHeightDisplacementMaxValue";
            this.lbHeightDisplacementMaxValue.Size = new System.Drawing.Size(100, 38);
            this.lbHeightDisplacementMaxValue.TabIndex = 13;
            this.lbHeightDisplacementMaxValue.Text = "888.888";
            this.lbHeightDisplacementMaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbHeightDisplacementFinalValue
            // 
            this.lbHeightDisplacementFinalValue.BackColor = System.Drawing.Color.White;
            this.lbHeightDisplacementFinalValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHeightDisplacementFinalValue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbHeightDisplacementFinalValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbHeightDisplacementFinalValue.Location = new System.Drawing.Point(271, 75);
            this.lbHeightDisplacementFinalValue.Name = "lbHeightDisplacementFinalValue";
            this.lbHeightDisplacementFinalValue.Size = new System.Drawing.Size(100, 38);
            this.lbHeightDisplacementFinalValue.TabIndex = 12;
            this.lbHeightDisplacementFinalValue.Text = "888.888";
            this.lbHeightDisplacementFinalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label10.Location = new System.Drawing.Point(373, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 38);
            this.label10.TabIndex = 11;
            this.label10.Text = "最終值";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbHeightDisplacementValue
            // 
            this.lbHeightDisplacementValue.BackColor = System.Drawing.Color.White;
            this.lbHeightDisplacementValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHeightDisplacementValue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbHeightDisplacementValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbHeightDisplacementValue.Location = new System.Drawing.Point(165, 33);
            this.lbHeightDisplacementValue.Name = "lbHeightDisplacementValue";
            this.lbHeightDisplacementValue.Size = new System.Drawing.Size(100, 80);
            this.lbHeightDisplacementValue.TabIndex = 8;
            this.lbHeightDisplacementValue.Text = "888.888";
            this.lbHeightDisplacementValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbHeightDisplacementLimitL
            // 
            this.lbHeightDisplacementLimitL.BackColor = System.Drawing.Color.White;
            this.lbHeightDisplacementLimitL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHeightDisplacementLimitL.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbHeightDisplacementLimitL.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbHeightDisplacementLimitL.Location = new System.Drawing.Point(59, 75);
            this.lbHeightDisplacementLimitL.Name = "lbHeightDisplacementLimitL";
            this.lbHeightDisplacementLimitL.Size = new System.Drawing.Size(100, 38);
            this.lbHeightDisplacementLimitL.TabIndex = 7;
            this.lbHeightDisplacementLimitL.Text = "888.888";
            this.lbHeightDisplacementLimitL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbHeightDisplacementLimitH
            // 
            this.lbHeightDisplacementLimitH.BackColor = System.Drawing.Color.White;
            this.lbHeightDisplacementLimitH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbHeightDisplacementLimitH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbHeightDisplacementLimitH.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbHeightDisplacementLimitH.Location = new System.Drawing.Point(59, 33);
            this.lbHeightDisplacementLimitH.Name = "lbHeightDisplacementLimitH";
            this.lbHeightDisplacementLimitH.Size = new System.Drawing.Size(100, 38);
            this.lbHeightDisplacementLimitH.TabIndex = 6;
            this.lbHeightDisplacementLimitH.Text = "888.888";
            this.lbHeightDisplacementLimitH.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label14.Location = new System.Drawing.Point(373, 33);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 38);
            this.label14.TabIndex = 5;
            this.label14.Text = "最大值";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label15.Location = new System.Drawing.Point(7, 75);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 38);
            this.label15.TabIndex = 3;
            this.label15.Text = "下限";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label16.Location = new System.Drawing.Point(7, 33);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 38);
            this.label16.TabIndex = 2;
            this.label16.Text = "上限";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gbTorqueMeter
            // 
            this.gbTorqueMeter.Controls.Add(this.lbTorqueMaxValue);
            this.gbTorqueMeter.Controls.Add(this.lbTorqueFinalValue);
            this.gbTorqueMeter.Controls.Add(this.label12);
            this.gbTorqueMeter.Controls.Add(this.lbTorqueValue);
            this.gbTorqueMeter.Controls.Add(this.lbTorqueLimitL);
            this.gbTorqueMeter.Controls.Add(this.lbTorqueLimitH);
            this.gbTorqueMeter.Controls.Add(this.label19);
            this.gbTorqueMeter.Controls.Add(this.label20);
            this.gbTorqueMeter.Controls.Add(this.label21);
            this.gbTorqueMeter.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.gbTorqueMeter.Location = new System.Drawing.Point(27, 27);
            this.gbTorqueMeter.Margin = new System.Windows.Forms.Padding(4);
            this.gbTorqueMeter.Name = "gbTorqueMeter";
            this.gbTorqueMeter.Padding = new System.Windows.Forms.Padding(4);
            this.gbTorqueMeter.Size = new System.Drawing.Size(450, 130);
            this.gbTorqueMeter.TabIndex = 12;
            this.gbTorqueMeter.TabStop = false;
            this.gbTorqueMeter.Text = "扭力";
            // 
            // lbTorqueMaxValue
            // 
            this.lbTorqueMaxValue.BackColor = System.Drawing.Color.White;
            this.lbTorqueMaxValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueMaxValue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbTorqueMaxValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbTorqueMaxValue.Location = new System.Drawing.Point(271, 33);
            this.lbTorqueMaxValue.Name = "lbTorqueMaxValue";
            this.lbTorqueMaxValue.Size = new System.Drawing.Size(100, 38);
            this.lbTorqueMaxValue.TabIndex = 13;
            this.lbTorqueMaxValue.Text = "888.888";
            this.lbTorqueMaxValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTorqueFinalValue
            // 
            this.lbTorqueFinalValue.BackColor = System.Drawing.Color.White;
            this.lbTorqueFinalValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueFinalValue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbTorqueFinalValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbTorqueFinalValue.Location = new System.Drawing.Point(271, 75);
            this.lbTorqueFinalValue.Name = "lbTorqueFinalValue";
            this.lbTorqueFinalValue.Size = new System.Drawing.Size(100, 38);
            this.lbTorqueFinalValue.TabIndex = 12;
            this.lbTorqueFinalValue.Text = "888.888";
            this.lbTorqueFinalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label12.Location = new System.Drawing.Point(373, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 38);
            this.label12.TabIndex = 11;
            this.label12.Text = "最終值";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbTorqueValue
            // 
            this.lbTorqueValue.BackColor = System.Drawing.Color.White;
            this.lbTorqueValue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueValue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbTorqueValue.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbTorqueValue.Location = new System.Drawing.Point(165, 33);
            this.lbTorqueValue.Name = "lbTorqueValue";
            this.lbTorqueValue.Size = new System.Drawing.Size(100, 80);
            this.lbTorqueValue.TabIndex = 8;
            this.lbTorqueValue.Text = "888.888";
            this.lbTorqueValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTorqueLimitL
            // 
            this.lbTorqueLimitL.BackColor = System.Drawing.Color.White;
            this.lbTorqueLimitL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueLimitL.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbTorqueLimitL.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbTorqueLimitL.Location = new System.Drawing.Point(59, 75);
            this.lbTorqueLimitL.Name = "lbTorqueLimitL";
            this.lbTorqueLimitL.Size = new System.Drawing.Size(100, 38);
            this.lbTorqueLimitL.TabIndex = 7;
            this.lbTorqueLimitL.Text = "888.888";
            this.lbTorqueLimitL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbTorqueLimitH
            // 
            this.lbTorqueLimitH.BackColor = System.Drawing.Color.White;
            this.lbTorqueLimitH.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbTorqueLimitH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lbTorqueLimitH.Font = new System.Drawing.Font("Tahoma", 16F);
            this.lbTorqueLimitH.Location = new System.Drawing.Point(59, 33);
            this.lbTorqueLimitH.Name = "lbTorqueLimitH";
            this.lbTorqueLimitH.Size = new System.Drawing.Size(100, 38);
            this.lbTorqueLimitH.TabIndex = 6;
            this.lbTorqueLimitH.Text = "888.888";
            this.lbTorqueLimitH.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label19.Location = new System.Drawing.Point(373, 33);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 38);
            this.label19.TabIndex = 5;
            this.label19.Text = "最大值";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label20.Location = new System.Drawing.Point(7, 75);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(50, 38);
            this.label20.TabIndex = 3;
            this.label20.Text = "下限";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("微軟正黑體", 14F);
            this.label21.Location = new System.Drawing.Point(7, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(50, 38);
            this.label21.TabIndex = 2;
            this.label21.Text = "上限";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Location = new System.Drawing.Point(922, 634);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 13;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // cbIsMeasuring
            // 
            this.cbIsMeasuring.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cbIsMeasuring.AutoSize = true;
            this.cbIsMeasuring.Location = new System.Drawing.Point(922, 608);
            this.cbIsMeasuring.Name = "cbIsMeasuring";
            this.cbIsMeasuring.Size = new System.Drawing.Size(62, 20);
            this.cbIsMeasuring.TabIndex = 14;
            this.cbIsMeasuring.Text = "鎖付中";
            this.cbIsMeasuring.UseVisualStyleBackColor = true;
            this.cbIsMeasuring.Click += new System.EventHandler(this.cbIsMeasuring_Click);
            // 
            // btnTest1
            // 
            this.btnTest1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTest1.Location = new System.Drawing.Point(841, 634);
            this.btnTest1.Name = "btnTest1";
            this.btnTest1.Size = new System.Drawing.Size(75, 23);
            this.btnTest1.TabIndex = 15;
            this.btnTest1.Text = "Test 1";
            this.btnTest1.UseVisualStyleBackColor = true;
            this.btnTest1.Click += new System.EventHandler(this.btnTest1_Click);
            // 
            // btnTest2
            // 
            this.btnTest2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTest2.Location = new System.Drawing.Point(760, 634);
            this.btnTest2.Name = "btnTest2";
            this.btnTest2.Size = new System.Drawing.Size(75, 23);
            this.btnTest2.TabIndex = 16;
            this.btnTest2.Text = "Test 2";
            this.btnTest2.UseVisualStyleBackColor = true;
            this.btnTest2.Click += new System.EventHandler(this.btnTest2_Click);
            // 
            // ButtonPanel
            // 
            this.ButtonPanel.Controls.Add(this.BtnStopEmg);
            this.ButtonPanel.Controls.Add(this.BtnStopDec);
            this.ButtonPanel.Location = new System.Drawing.Point(772, 27);
            this.ButtonPanel.Name = "ButtonPanel";
            this.ButtonPanel.Size = new System.Drawing.Size(200, 97);
            this.ButtonPanel.TabIndex = 69;
            // 
            // BtnStopEmg
            // 
            this.BtnStopEmg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnStopEmg.BackColor = System.Drawing.Color.LightSalmon;
            this.BtnStopEmg.Location = new System.Drawing.Point(47, 56);
            this.BtnStopEmg.Margin = new System.Windows.Forms.Padding(4);
            this.BtnStopEmg.Name = "BtnStopEmg";
            this.BtnStopEmg.Size = new System.Drawing.Size(110, 30);
            this.BtnStopEmg.TabIndex = 69;
            this.BtnStopEmg.Text = "緊急停止";
            this.BtnStopEmg.UseVisualStyleBackColor = false;
            // 
            // BtnStopDec
            // 
            this.BtnStopDec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnStopDec.Location = new System.Drawing.Point(47, 12);
            this.BtnStopDec.Margin = new System.Windows.Forms.Padding(4);
            this.BtnStopDec.Name = "BtnStopDec";
            this.BtnStopDec.Size = new System.Drawing.Size(110, 30);
            this.BtnStopDec.TabIndex = 68;
            this.BtnStopDec.Text = "減速停止";
            this.BtnStopDec.UseVisualStyleBackColor = true;
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ButtonPanel);
            this.Controls.Add(this.btnTest2);
            this.Controls.Add(this.btnTest1);
            this.Controls.Add(this.cbIsMeasuring);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.gbHeightDisplacement);
            this.Controls.Add(this.gbTorqueMeter);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainPage";
            this.Size = new System.Drawing.Size(1000, 660);
            this.gbHeightDisplacement.ResumeLayout(false);
            this.gbTorqueMeter.ResumeLayout(false);
            this.ButtonPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private GroupBox gbHeightDisplacement;
        private Label lbHeightDisplacementValue;
        private Label lbHeightDisplacementLimitL;
        private Label lbHeightDisplacementLimitH;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label lbHeightDisplacementFinalValue;
        private Label label10;
        private Label lbHeightDisplacementMaxValue;
        private GroupBox gbTorqueMeter;
        private Label lbTorqueMaxValue;
        private Label lbTorqueFinalValue;
        private Label label12;
        private Label lbTorqueValue;
        private Label lbTorqueLimitL;
        private Label lbTorqueLimitH;
        private Label label19;
        private Label label20;
        private Label label21;
        private Button btnReset;
        private CheckBox cbIsMeasuring;
        private Button btnTest1;
        private Button btnTest2;
        private Panel ButtonPanel;
        private Button BtnStopEmg;
        private Button BtnStopDec;
    }
}
