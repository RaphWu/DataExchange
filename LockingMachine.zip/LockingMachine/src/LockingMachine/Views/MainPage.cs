﻿using Calin.LockingMachine.Ext;
using Calin.LockingMachine.Models;
using Calin.LockingMachine.Services;
using Calin.Navigation;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class MainPage : UserControl
    {
        private readonly ILockingMachine _lockingMachine;
        private readonly BindingData _bindingData;

        private readonly Color _belowColor = Color.Transparent;
        private readonly Color _betweenColor = Color.LightGreen;
        private readonly Color _aboveColor = Color.Red;

        public MainPage(ILockingMachine lockingMachine, BindingData bindingData)
        {
            _lockingMachine = lockingMachine;
            _bindingData = bindingData;

            InitializeComponent();

            lbTorqueLimitH.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueLimitH), true);
            lbTorqueLimitL.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueLimitL), true);
            lbTorqueValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueValue), true);
            lbTorqueFinalValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueFinalValue), true);
            lbTorqueMaxValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueMaxValue), true);

            lbTorqueValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.TorqueValue),
                nameof(BindingData.TorqueLimitL),
                nameof(BindingData.TorqueLimitH),
                _betweenColor, _aboveColor, _belowColor);
            lbTorqueFinalValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.TorqueFinalValue),
                nameof(BindingData.TorqueLimitL),
                nameof(BindingData.TorqueLimitH),
                _betweenColor, _aboveColor, _belowColor);
            lbTorqueMaxValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.TorqueMaxValue),
                nameof(BindingData.TorqueLimitL),
                nameof(BindingData.TorqueLimitH),
                _betweenColor, _aboveColor, _belowColor);

            lbHeightDisplacementLimitH.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementLimitH), true);
            lbHeightDisplacementLimitL.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementLimitL), true);
            lbHeightDisplacementValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementValue), true);
            lbHeightDisplacementFinalValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementFinalValue), true);
            lbHeightDisplacementMaxValue.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementMaxValue), true);

            lbHeightDisplacementValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.HeightDisplacementValue),
                nameof(BindingData.HeightDisplacementLimitL),
                nameof(BindingData.HeightDisplacementLimitH),
                _betweenColor, _aboveColor, _belowColor);
            lbHeightDisplacementFinalValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.HeightDisplacementFinalValue),
                nameof(BindingData.HeightDisplacementLimitL),
                nameof(BindingData.HeightDisplacementLimitH),
                _betweenColor, _aboveColor, _belowColor);
            lbHeightDisplacementMaxValue.BindBackColorToThresholds(_bindingData,
                nameof(BindingData.HeightDisplacementMaxValue),
                nameof(BindingData.HeightDisplacementLimitL),
                nameof(BindingData.HeightDisplacementLimitH),
                _betweenColor, _aboveColor, _belowColor);

#if DEBUG
            var lbHeightDisplacementStopwatch = new Label();
            lbHeightDisplacementStopwatch.Font = new Font("Consolas", 9F);
            lbHeightDisplacementStopwatch.Location = new Point(7, 121);
            lbHeightDisplacementStopwatch.BackColor = Color.Transparent;
            lbHeightDisplacementStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.HeightDisplacementStopwatch), true);
            gbHeightDisplacement.Controls.Add(lbHeightDisplacementStopwatch);

            var lbTorqueStopwatch = new Label();
            lbTorqueStopwatch.Font = new Font("Consolas", 9F);
            lbTorqueStopwatch.Location = new Point(7, 121);
            lbTorqueStopwatch.BackColor = Color.Transparent;
            lbTorqueStopwatch.BindTextToDoubleWith3Digits(_bindingData,
                nameof(BindingData.TorqueStopwatch), true);
            gbTorqueMeter.Controls.Add(lbTorqueStopwatch);
#endif
        }

        private void cbIsMeasuring_CheckedChanged(object sender, EventArgs e)
        {
            _bindingData.IsMeasuring = cbIsMeasuring.Checked;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            _lockingMachine.ClearMeasureData();
        }
    }
}
