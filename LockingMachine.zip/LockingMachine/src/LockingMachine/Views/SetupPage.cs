﻿using Calin.LockingMachine.Models;
using Calin.LockingMachine.Services;
using Calin.Navigation;
using Calin.SerialPort;

namespace Calin.LockingMachine.Views
{
    [ViewLifetime(IsAlive = true)]
    public partial class SetupPage : UserControl
    {
        #region Fields

        private readonly ILockingMachine _lockingMachine;
        private readonly LmData _lmData;
        private readonly BindingData _bindingData;
        private readonly Dlrs1aData _dispData;
        private readonly DaqData _daqData;

        private bool _isUpdateBackground = true;

        #endregion Fields

        #region ctor

        public SetupPage(
            ILockingMachine device,
            LmData lmData,
            BindingData bindingData,
            Dlrs1aData dlrs1aData,
            DaqData daqData)
        {
            _lockingMachine = device;
            _lmData = lmData;
            _bindingData = bindingData;
            _dispData = dlrs1aData;
            _daqData = daqData;

            InitializeComponent();

            CbHeightDispCom.Items.Clear();
            if (_lmData.comPortList.Count > 0)
                CbHeightDispCom.Items.AddRange(_lmData.comPortList.ToArray());
            //CbDlrs1aBaudRate.Items.AddRange(_dispData.heightDispConfig.BaudRateList.Select(x => x.ToString()).ToArray());
            //CbDlrs1aDataBits.Items.AddRange(_dispData.heightDispConfig.DataBitsList.Select(x => x.ToString()).ToArray());
            CbHeightDispBaudRate.Items.AddRange([4800, 9600, 19200, 38400, 57600, 115200]);
            CbHeightDispDataBits.Items.AddRange([5, 6, 7, 8, 9]);
            CbHeightDispParity.Items.AddRange(Enum.GetNames(typeof(Parity)));
            CbHeightDispStopBits.Items.AddRange(Enum.GetNames(typeof(StopBits)));

            Dlrs1aLoad();
            DaqLoad();
        }

        #endregion ctor

        #region Height Displacement

        private void Dlrs1aLoad()
        {
            _isUpdateBackground = true;

            tbUsb4704DeviceCode.Text = _daqData.DeviceCode;

            CbHeightDispCom.Text = _dispData.Dlrs1aConfig.PortName;
            CbHeightDispBaudRate.Text = _dispData.Dlrs1aConfig.BaudRate.ToString();
            CbHeightDispDataBits.Text = _dispData.Dlrs1aConfig.DataBits.ToString();
            CbHeightDispParity.Text = _dispData.Dlrs1aConfig.Parity.ToString();
            CbHeightDispStopBits.Text = _dispData.Dlrs1aConfig.StopBits.ToString();

            tbHeightDispLimitH.Value = (decimal)_dispData.HeightDispLimitH;
            tbHeightDispLimitL.Value = (decimal)_dispData.HeightDispLimitL;

            _isUpdateBackground = false;
        }

        private void CbHeightDispCom_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            if (_dispData.Dlrs1aConfig.PortName != CbHeightDispCom.Text)
            {
                _dispData.Dlrs1aConfig.PortName = CbHeightDispCom.Text;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void CbHeightDispBaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var baudRate = int.Parse(CbHeightDispBaudRate.Text);
            if (_dispData.Dlrs1aConfig.BaudRate != baudRate)
            {
                _dispData.Dlrs1aConfig.BaudRate = baudRate;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void CbHeightDispParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var parity = (Parity)Enum.Parse(typeof(Parity), CbHeightDispParity.Text);
            if (_dispData.Dlrs1aConfig.Parity != parity)
            {
                _dispData.Dlrs1aConfig.Parity = parity;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void CbHeightDispDataBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var dataBits = int.Parse(CbHeightDispDataBits.Text);
            if (_dispData.Dlrs1aConfig.DataBits != dataBits)
            {
                _dispData.Dlrs1aConfig.DataBits = dataBits;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void CbHeightDispStopBits_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var stopBits = (StopBits)Enum.Parse(typeof(StopBits), CbHeightDispStopBits.Text);
            if (_dispData.Dlrs1aConfig.StopBits != stopBits)
            {
                _dispData.Dlrs1aConfig.StopBits = stopBits;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void TbHeightDispLimitH_ValueChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var height = (double)tbHeightDispLimitH.Value;
            if (_dispData.HeightDispLimitH != height)
            {
                _dispData.HeightDispLimitH = height;
                _bindingData.HeightDisplacementLimitH = height;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }
        private void TbHeightDispLimitL_ValueChanged(object sender, EventArgs e)
        {
            if (_isUpdateBackground) return;
            var height = (double)tbHeightDispLimitL.Value;
            if (_dispData.HeightDispLimitL != height)
            {
                _dispData.HeightDispLimitL = height;
                _bindingData.HeightDisplacementLimitL = height;
                _lockingMachine.Dlrs1aSaveConfig(_dispData);
            }
        }

        private void BtnHeightDispReconnect_Click(object sender, EventArgs e)
        {
            _lockingMachine.Dlrs1aClose();
            _lockingMachine.Dlrs1aInit();
        }

        private void BtnUpdatePortNames_Click(object sender, EventArgs e)
        {
            _lockingMachine.UpdateComPortList();

            var com = CbHeightDispCom.Text;
            CbHeightDispCom.Items.Clear();
            if (_lmData.comPortList.Count > 0)
                CbHeightDispCom.Items.AddRange(_lmData.comPortList.ToArray());

            if (_lmData.comPortList.Contains(com))
                CbHeightDispCom.Text = com;
        }

        #endregion Height Displacement

        #region DAQ/尋邊

        private void DaqLoad()
        {
            tbTorqueLimitH.Value = (decimal)_daqData.TorqueLimitH;
            tbTorqueLimitL.Value = (decimal)_daqData.TorqueLimitL;
            cbGateMarkCylinder.Text = _daqData.GateMarkPort;
        }

        private void TbTorqueLimitH_ValueChanged(object sender, EventArgs e)
        {
            _daqData.TorqueLimitH = (double)tbTorqueLimitH.Value;
            _bindingData.TorqueLimitH = _daqData.TorqueLimitH;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void TbTorqueLimitL_ValueChanged(object sender, EventArgs e)
        {
            _daqData.TorqueLimitL = (double)tbTorqueLimitL.Value;
            _bindingData.TorqueLimitL = _daqData.TorqueLimitL;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void CbGateMarkCylinder_SelectedIndexChanged(object sender, EventArgs e)
        {
            _daqData.GateMarkPort = cbGateMarkCylinder.Text;
            _lockingMachine.DaqSaveConfig(_daqData);
        }

        private void BtnGateMarkExtend_Click(object sender, EventArgs e)
        {
            // TODO: 目前只針對USB4704，需修改支援軸卡
            int index = 0;
            string input = cbGateMarkCylinder.Text;
            while (index < input.Length && !char.IsDigit(input[index]))
                index++;

            string portName = input.Substring(0, index);
            byte portNumber = byte.Parse(input.Substring(index));
            _lmData.dio.WriteDigital(0, (byte)(1 << portNumber));
        }

        private void BtnGateMarkRetract_Click(object sender, EventArgs e)
        {
            _lmData.dio.WriteDigital(0, 0);
        }

        #endregion DAQ/尋邊
    }
}
