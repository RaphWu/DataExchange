﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Calin.LockingMachine
{
    internal static class Program
    {
        // P/Invoke 讓已存在程式跳到前景
        private static class NativeMethods
        {
            [DllImport("user32.dll")]
            public static extern bool SetForegroundWindow(IntPtr hWnd);

            [DllImport("user32.dll")]
            public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        }

        // 用於確保單一實例執行的 Mutex
        private static Mutex _mutex;

        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            // 確保單一實例執行
            _mutex = new Mutex(true, "Calin.LockingMachine.UniqueAppMutex", out bool createdNew);
            if (!createdNew)
            {
                // 找到現有程式，BringToFront
                var current = Process.GetCurrentProcess();
                var existing = Process.GetProcessesByName(current.ProcessName)
                                      .FirstOrDefault(p => p.Id != current.Id);
                if (existing != null)
                {
                    MessageBox.Show("LockingMachine 已在執行中，將切換到已開啟的視窗。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    NativeMethods.ShowWindow(existing.MainWindowHandle, 5); // SW_SHOW
                    NativeMethods.SetForegroundWindow(existing.MainWindowHandle);
                }
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new AppStartupContext());

            _mutex.Dispose();
        }
    }
}
