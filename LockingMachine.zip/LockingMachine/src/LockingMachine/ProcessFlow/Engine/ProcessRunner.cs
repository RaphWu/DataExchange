using Autofac;
using Calin.LockingMachine.ProcessFlow.Core;

namespace Calin.LockingMachine.ProcessFlow.Engine
{
    /// <summary>
    /// �y�{���澹�A�̧ǰ���u�ǡC
    /// </summary>
    /// <remarks>
    /// <para>�� OrderNo �̧ǰ���AEnabled = false ���u�Ƿ|���L�C</para>
    /// <para>�z�L IProcessHandler ����A�䴩 CancellationToken�C</para>
    /// <para>���̿���� UI ���O�C</para>
    /// </remarks>
    public class ProcessRunner
    {
        private readonly ILifetimeScope _scope;

        /// <summary>
        /// �u�Ƕ}�l�����Ĳ�o�C
        /// </summary>
        public event EventHandler<ProcessStepExecutingEventArgs> StepExecuting;

        /// <summary>
        /// �u�ǰ��槹����Ĳ�o�C
        /// </summary>
        public event EventHandler<ProcessStepCompletedEventArgs> StepCompleted;

        public ProcessRunner(ILifetimeScope scope)
        {
            _scope = scope ?? throw new ArgumentNullException(nameof(scope));
        }

        /// <summary>
        /// ����y�{�C
        /// </summary>
        /// <param name="steps">�u�ǨB�J���X�C</param>
        /// <param name="cancellationToken">�����v���C</param>
        /// <returns>�y�{���浲�G�C</returns>
        public async Task<ProcessFlowResult> RunAsync(IEnumerable<ProcessStepEntity> steps, CancellationToken cancellationToken = default)
        {
            if (steps == null)
                throw new ArgumentNullException(nameof(steps));

            var orderedSteps = steps.OrderBy(s => s.OrderNo).ToList();
            var enabledSteps = orderedSteps.Where(s => s.Enabled).ToList();
            var totalSteps = enabledSteps.Count;
            var executedSteps = 0;

            for (int i = 0; i < enabledSteps.Count; i++)
            {
                var step = enabledSteps[i];

                if (cancellationToken.IsCancellationRequested)
                {
                    return ProcessFlowResult.Cancelled(totalSteps, executedSteps);
                }

                try
                {
                    OnStepExecuting(new ProcessStepExecutingEventArgs(step, totalSteps, i));

                    var handler = _scope.ResolveKeyed<IProcessHandler>(step.ProcessId);
                    var result = await handler.ExecuteAsync(step.ParamJson, cancellationToken);

                    OnStepCompleted(new ProcessStepCompletedEventArgs(step, result, totalSteps, i));

                    if (!result.Success)
                    {
                        return ProcessFlowResult.Failed(totalSteps, executedSteps, i, result.ErrorMessage, result.Exception);
                    }

                    executedSteps++;
                }
                catch (OperationCanceledException)
                {
                    return ProcessFlowResult.Cancelled(totalSteps, executedSteps);
                }
                catch (Exception ex)
                {
                    var failedResult = ProcessExecutionResult.Failed(ex);
                    OnStepCompleted(new ProcessStepCompletedEventArgs(step, failedResult, totalSteps, i));
                    return ProcessFlowResult.Failed(totalSteps, executedSteps, i, ex.Message, ex);
                }
            }

            return ProcessFlowResult.Succeeded(totalSteps, executedSteps);
        }

        protected virtual void OnStepExecuting(ProcessStepExecutingEventArgs e)
        {
            StepExecuting?.Invoke(this, e);
        }

        protected virtual void OnStepCompleted(ProcessStepCompletedEventArgs e)
        {
            StepCompleted?.Invoke(this, e);
        }
    }
}
