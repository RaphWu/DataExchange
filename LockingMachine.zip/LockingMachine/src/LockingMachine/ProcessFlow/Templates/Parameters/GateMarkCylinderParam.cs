﻿namespace Calin.LockingMachine.ProcessFlow.Templates.Parameters
{
    /// <summary>
    /// 尋邊氣缸操作參數。
    /// </summary>
    public class GateMarkCylinderParam
    {
        /// <summary>
        /// 氣缸伸出。
        /// </summary>
        public bool CylinderExtend { get; set; } = false;

        /// <summary>
        /// 氣缸收回。
        /// </summary>
        public bool CylinderRetract { get; set; } = false;
    }
}
