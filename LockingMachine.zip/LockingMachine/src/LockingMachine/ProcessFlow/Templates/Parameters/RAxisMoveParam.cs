﻿namespace Calin.LockingMachine.ProcessFlow.Templates.Parameters
{
    public class RAxisMoveParam
    {
        /// <summary>
        /// 軸代號。
        /// </summary>
        public string AxisId { get; set; } = "R";

        /// <summary>
        /// 是否為回原點？
        /// </summary>
        public bool IsHome { get; set; } = false;

        /// <summary>
        /// 目標角度。
        /// </summary>
        public double TargetAngle { get; set; } = 0.0;

        /// <summary>
        /// 是否為絕對移動？
        /// </summary>
        public bool IsAbsolute { get; set; } = true;

        /// <summary>
        /// 移動速度（單位：mm/s）。
        /// </summary>
        public double Speed { get; set; } = 100;

        /// <summary>
        /// 加速度（單位：mm/s2）。
        /// </summary>
        public double Acceleration { get; set; } = 500;
    }
}
