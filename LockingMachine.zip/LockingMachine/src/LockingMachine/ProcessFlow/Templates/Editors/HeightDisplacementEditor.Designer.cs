﻿using System.Windows.Forms;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    partial class HeightDisplacementEditor
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.numMinValue = new System.Windows.Forms.NumericUpDown();
            this.lblTargetPosition = new System.Windows.Forms.Label();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.numMaxValue = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbInRangeAction = new System.Windows.Forms.ComboBox();
            this.cmbOutOfRangeAction = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.numMinValue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMaxValue)).BeginInit();
            this.SuspendLayout();
            // 
            // numMinValue
            // 
            this.numMinValue.DecimalPlaces = 3;
            this.numMinValue.Location = new System.Drawing.Point(103, 15);
            this.numMinValue.Margin = new System.Windows.Forms.Padding(4);
            this.numMinValue.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numMinValue.Name = "numMinValue";
            this.numMinValue.Size = new System.Drawing.Size(135, 23);
            this.numMinValue.TabIndex = 7;
            // 
            // lblTargetPosition
            // 
            this.lblTargetPosition.Location = new System.Drawing.Point(21, 15);
            this.lblTargetPosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTargetPosition.Name = "lblTargetPosition";
            this.lblTargetPosition.Size = new System.Drawing.Size(74, 23);
            this.lblTargetPosition.TabIndex = 6;
            this.lblTargetPosition.Text = "最小值";
            this.lblTargetPosition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSpeed
            // 
            this.lblSpeed.Location = new System.Drawing.Point(21, 46);
            this.lblSpeed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(74, 23);
            this.lblSpeed.TabIndex = 8;
            this.lblSpeed.Text = "最大值";
            this.lblSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // numMaxValue
            // 
            this.numMaxValue.DecimalPlaces = 1;
            this.numMaxValue.Location = new System.Drawing.Point(103, 46);
            this.numMaxValue.Margin = new System.Windows.Forms.Padding(4);
            this.numMaxValue.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numMaxValue.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numMaxValue.Name = "numMaxValue";
            this.numMaxValue.Size = new System.Drawing.Size(135, 23);
            this.numMaxValue.TabIndex = 9;
            this.numMaxValue.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(21, 77);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 23);
            this.label1.TabIndex = 10;
            this.label1.Text = "範圍內動作";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(21, 107);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 23);
            this.label2.TabIndex = 11;
            this.label2.Text = "範圍外動作";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbInRangeAction
            // 
            this.cmbInRangeAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInRangeAction.FormattingEnabled = true;
            this.cmbInRangeAction.Location = new System.Drawing.Point(103, 76);
            this.cmbInRangeAction.Name = "cmbInRangeAction";
            this.cmbInRangeAction.Size = new System.Drawing.Size(174, 24);
            this.cmbInRangeAction.TabIndex = 12;
            // 
            // cmbOutOfRangeAction
            // 
            this.cmbOutOfRangeAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOutOfRangeAction.FormattingEnabled = true;
            this.cmbOutOfRangeAction.Location = new System.Drawing.Point(103, 106);
            this.cmbOutOfRangeAction.Name = "cmbOutOfRangeAction";
            this.cmbOutOfRangeAction.Size = new System.Drawing.Size(174, 24);
            this.cmbOutOfRangeAction.TabIndex = 13;
            // 
            // HeightDisplacementEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cmbOutOfRangeAction);
            this.Controls.Add(this.cmbInRangeAction);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numMinValue);
            this.Controls.Add(this.lblTargetPosition);
            this.Controls.Add(this.lblSpeed);
            this.Controls.Add(this.numMaxValue);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "HeightDisplacementEditor";
            this.Size = new System.Drawing.Size(320, 159);
            ((System.ComponentModel.ISupportInitialize)(this.numMinValue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMaxValue)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private NumericUpDown numMinValue;
        private Label lblTargetPosition;
        private Label lblSpeed;
        private NumericUpDown numMaxValue;
        private Label label1;
        private Label label2;
        private ComboBox cmbInRangeAction;
        private ComboBox cmbOutOfRangeAction;
    }
}
