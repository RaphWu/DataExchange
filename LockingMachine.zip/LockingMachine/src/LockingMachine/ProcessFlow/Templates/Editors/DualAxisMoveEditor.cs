﻿using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// 兩軸移動參數編輯器。
    /// </summary>
    public partial class DualAxisMoveEditor : ProcessEditorBase
    {
        public override string ProcessId => ProcessIds.DUAL_AXIS_MOVE;

        public DualAxisMoveEditor()
        {
            InitializeComponent();

            cbDualAxisHome.CheckedChanged += (s, e) => OnParamChanged();

            rbAxis1Abs.CheckedChanged += (s, e) => OnParamChanged();
            rbAxis1Res.CheckedChanged += (s, e) => OnParamChanged();
            numAxis1TargetPosition.ValueChanged += (s, e) => OnParamChanged();
            numAxis1Speed.ValueChanged += (s, e) => OnParamChanged();
            numAxis1Acceleration.ValueChanged += (s, e) => OnParamChanged();

            rbAxis2Abs.CheckedChanged += (s, e) => OnParamChanged();
            rbAxis2Res.CheckedChanged += (s, e) => OnParamChanged();
            numAxis2TargetAngle.ValueChanged += (s, e) => OnParamChanged();
            numAxis2Speed.ValueChanged += (s, e) => OnParamChanged();
            numAxis2Acceleration.ValueChanged += (s, e) => OnParamChanged();
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new DualAxisMoveParam()
                : JsonConvert.DeserializeObject<DualAxisMoveParam>(paramJson) ?? new DualAxisMoveParam();

            if (param.IsAxis1Absolute)
                rbAxis1Abs.Checked = true;
            else
                rbAxis1Res.Checked = true;
            numAxis1TargetPosition.Value = (decimal)param.Axis1TargetPosition;
            numAxis1Speed.Value = (decimal)param.Axis1Speed;
            numAxis1Acceleration.Value = (decimal)param.Axis1Acceleration;

            if (param.IsAxis2Absolute)
                rbAxis2Abs.Checked = true;
            else
                rbAxis2Res.Checked = true;
            numAxis2TargetAngle.Value = (decimal)param.Axis2TargetAngle;
            numAxis2Speed.Value = (decimal)param.Axis2Speed;
            numAxis2Acceleration.Value = (decimal)param.Axis2Acceleration;

            cbDualAxisHome.Checked = param.DualAxisHome;
        }

        public override string Save()
        {
            var param = new DualAxisMoveParam
            {
                DualAxisHome = cbDualAxisHome.Checked,

                IsAxis1Absolute = rbAxis1Abs.Checked,
                Axis1TargetPosition = (double)numAxis1TargetPosition.Value,
                Axis1Speed = (double)numAxis1Speed.Value,
                Axis1Acceleration = (double)numAxis1Acceleration.Value,

                IsAxis2Absolute = rbAxis2Abs.Checked,
                Axis2TargetAngle = (double)numAxis2TargetAngle.Value,
                Axis2Speed = (double)numAxis2Speed.Value,
                Axis2Acceleration = (double)numAxis2Acceleration.Value
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            if (numAxis1Speed.Value <= 0)
                return "速度必須大於 0";

            if (numAxis1Acceleration.Value <= 0)
                return "加速度必須大於 0";

            if (numAxis2Speed.Value <= 0)
                return "速度必須大於 0";

            if (numAxis2Acceleration.Value <= 0)
                return "加速度必須大於 0";

            return null;
        }

        private void cbDualAxisHome_CheckedChanged(object sender, EventArgs e)
        {
            if (cbDualAxisHome.Checked)
            {
                gbAxis1MoveParams.Enabled = false;
                gbAxis2MoveParams.Enabled = false;
            }
            else
            {
                gbAxis1MoveParams.Enabled = true;
                gbAxis2MoveParams.Enabled = true;
            }
        }

        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        // 解除事件訂閱
        //        cbDualAxisHome.CheckedChanged -= (s, e) => OnParamChanged();

        //        rbAxis1Abs.CheckedChanged -= (s, e) => OnParamChanged();
        //        rbAxis1Res.CheckedChanged -= (s, e) => OnParamChanged();
        //        numAxis1TargetPosition.ValueChanged -= (s, e) => OnParamChanged();
        //        numAxis1Speed.ValueChanged -= (s, e) => OnParamChanged();
        //        numAxis1Acceleration.ValueChanged -= (s, e) => OnParamChanged();

        //        rbAxis2Abs.CheckedChanged -= (s, e) => OnParamChanged();
        //        rbAxis2Res.CheckedChanged -= (s, e) => OnParamChanged();
        //        numAxis2TargetAngle.ValueChanged -= (s, e) => OnParamChanged();
        //        numAxis2Speed.ValueChanged -= (s, e) => OnParamChanged();
        //        numAxis2Acceleration.ValueChanged -= (s, e) => OnParamChanged();
        //    }

        //    base.Dispose(disposing);
        //}
    }
}
