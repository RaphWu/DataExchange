﻿using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    /// <summary>
    /// 尋邊氣缸操作參數編輯器。
    /// </summary>
    public partial class GateMarkCylinderEditor : ProcessEditorBase
    {
        public override string ProcessId => ProcessIds.GATE_MARK_CYLINDER;

        public GateMarkCylinderEditor()
        {
            InitializeComponent();

            rbCylinderRetract.CheckedChanged += (s, e) => OnParamChanged();
            rbCylinderExtend.CheckedChanged += (s, e) => OnParamChanged();
        }

        public override void Load(string paramJson)
        {
            var param = string.IsNullOrEmpty(paramJson)
                ? new GateMarkCylinderParam()
                : JsonConvert.DeserializeObject<GateMarkCylinderParam>(paramJson) ?? new GateMarkCylinderParam();

            rbCylinderRetract.Checked = param.CylinderRetract;
            rbCylinderExtend.Checked = !param.CylinderRetract;
        }

        public override string Save()
        {
            var param = new GateMarkCylinderParam
            {
                CylinderRetract = rbCylinderRetract.Checked,
                CylinderExtend = rbCylinderExtend.Checked,
            };

            return JsonConvert.SerializeObject(param);
        }

        public override string Validate()
        {
            return null;
        }
    }
}
