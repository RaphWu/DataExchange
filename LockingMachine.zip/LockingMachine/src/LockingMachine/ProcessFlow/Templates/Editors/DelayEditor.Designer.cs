﻿using System.Windows.Forms;

namespace Calin.LockingMachine.ProcessFlow.Templates.Editors
{
    partial class DelayEditor
    {
        /// <summary> 
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary> 
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.numDelayMs = new System.Windows.Forms.NumericUpDown();
            this.lblTargetPosition = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbDescription = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numDelayMs)).BeginInit();
            this.SuspendLayout();
            // 
            // numDelayMs
            // 
            this.numDelayMs.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numDelayMs.Location = new System.Drawing.Point(86, 16);
            this.numDelayMs.Margin = new System.Windows.Forms.Padding(4);
            this.numDelayMs.Maximum = new decimal(new int[] {
            60000,
            0,
            0,
            0});
            this.numDelayMs.Name = "numDelayMs";
            this.numDelayMs.Size = new System.Drawing.Size(135, 23);
            this.numDelayMs.TabIndex = 5;
            // 
            // lblTargetPosition
            // 
            this.lblTargetPosition.Location = new System.Drawing.Point(23, 15);
            this.lblTargetPosition.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTargetPosition.Name = "lblTargetPosition";
            this.lblTargetPosition.Size = new System.Drawing.Size(61, 23);
            this.lblTargetPosition.TabIndex = 4;
            this.lblTargetPosition.Text = "延遲時間";
            this.lblTargetPosition.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(224, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 23);
            this.label1.TabIndex = 6;
            this.label1.Text = "ms";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(23, 52);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "說明";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbDescription
            // 
            this.tbDescription.Location = new System.Drawing.Point(86, 52);
            this.tbDescription.Name = "tbDescription";
            this.tbDescription.Size = new System.Drawing.Size(196, 23);
            this.tbDescription.TabIndex = 8;
            // 
            // DelayEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tbDescription);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numDelayMs);
            this.Controls.Add(this.lblTargetPosition);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "DelayEditor";
            this.Size = new System.Drawing.Size(320, 100);
            ((System.ComponentModel.ISupportInitialize)(this.numDelayMs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private NumericUpDown numDelayMs;
        private Label lblTargetPosition;
        private Label label1;
        private Label label2;
        private TextBox tbDescription;
    }
}
