using System.Collections.Generic;
using System.Text;
using Calin.LockingMachine.ProcessFlow.Core;
using Calin.LockingMachine.ProcessFlow.Templates.Editors;
using Calin.LockingMachine.ProcessFlow.Templates.Handlers;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates
{
    /// <summary>
    /// �u�ǼҪO���U���A�t�d���ѩҦ��u�Ǵy�z�C
    /// </summary>
    public static class ProcessTemplateRegistry
    {
        /// <summary>
        /// ���o�Ҧ��u�Ǵy�z�C
        /// </summary>
        public static IEnumerable<ProcessDescriptor> GetAllDescriptors()
        {
            yield return CreateZAxisMoveDescriptor();
            yield return CreateRAxisMoveDescriptor();
            yield return CreateDualAxisMoveDescriptor();
            yield return CreateGateMarkSearchDescriptor();
            yield return CreateGateMarkCylinderDescriptor();
            yield return CreateHeightDisplacementDescriptor();
            yield return CreateDelayDescriptor();
        }

        private static ProcessDescriptor CreateZAxisMoveDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.Z_AXIS_MOVE,
                DisplayName = "Z�b����",
                Description = "Z�b�^���I�Ψ̫��w�t�ײ��ʨ���w�y��",
                HandlerType = typeof(ZAxisMoveHandler),
                EditorType = typeof(ZAxisMoveEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new ZAxisMoveParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<ZAxisMoveParam>(paramJson);
                        if (p.IsHome)
                            return $"Z�b�^���I";
                        else if (p.IsSafetyHeight)
                            return $"Z�b���ʨ�w�����סA�t��:{p.Speed}\n�Y�w�b�w�����פ��W�A�h������";
                        else
                        {
                            StringBuilder sb = new StringBuilder("Z�b");
                            sb.Append(p.IsAbsolute ? "����" : "�۹�");
                            sb.Append($"����, �ؼЦ�m:{p.TargetPosition}, �t��:{p.Speed}, �[�t��:{p.Acceleration}");
                            return sb.ToString();
                        }
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateRAxisMoveDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.R_AXIS_MOVE,
                DisplayName = "R�b����",
                Description = "R�b�^���I�Ψ̫��w�t�ױ������w����",
                HandlerType = typeof(RAxisMoveHandler),
                EditorType = typeof(RAxisMoveEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new RAxisMoveParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<RAxisMoveParam>(paramJson);
                        if (p.IsHome)
                            return $"R�b�^���I";
                        else
                        {
                            StringBuilder sb = new StringBuilder("R�b");
                            sb.Append(p.IsAbsolute ? "����" : "�۹�");
                            sb.Append($"����, �ؼШ���:{p.TargetAngle}, �t��:{p.Speed}, �[�t��:{p.Acceleration}");
                            return sb.ToString();
                        }
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateDualAxisMoveDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.DUAL_AXIS_MOVE,
                DisplayName = "��b����",
                Description = "��b�̦w������P���w�t�ײ��ʨ���w�y��",
                HandlerType = typeof(DualAxisMoveHandler),
                EditorType = typeof(DualAxisMoveEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new DualAxisMoveParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<DualAxisMoveParam>(paramJson);
                        if (p.DualAxisHome)
                            return "��b�^���I\n(Z�b�|�����ܦw�����סA�A��b���I)";
                        else
                        {
                            StringBuilder sb = new StringBuilder();
                            sb.Append("�bZ: ");
                            sb.Append(p.IsAxis1Absolute ? "����" : "�۹�");
                            sb.AppendLine($"��m:{p.Axis1TargetPosition}, �t��:{p.Axis1Speed}, �[�t��:{p.Axis1Acceleration}");
                            sb.Append("�bR: ");
                            sb.Append(p.IsAxis2Absolute ? "����" : "�۹�");
                            sb.AppendLine($"����:{p.Axis2TargetAngle}, �t��:{p.Axis2Speed}, �[�t��:{p.Axis2Acceleration}");
                            sb.Append("(Z�b�|�����ܦw�����סA�A��b����)");
                            return sb.ToString();
                        }
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateGateMarkSearchDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.GATE_MARK_SEARCH,
                DisplayName = "�M��",
                Description = "�M��S�w�аO��m",
                HandlerType = typeof(GateMarkSearchHandler),
                EditorType = typeof(GateMarkSearchEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new GateMarkSearchParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<GateMarkSearchParam>(paramJson);
                        return $"���v����: {p.AngleCompensation}�X";
                        //return $"�j�M����:{p.SearchAttempts}, �W�ɮɶ�:{p.TimeoutMilliseconds} ms";
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateGateMarkCylinderDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.GATE_MARK_CYLINDER,
                DisplayName = "�M����",
                Description = "�M�����ާ@",
                HandlerType = typeof(GateMarkCylinderHandler),
                EditorType = typeof(GateMarkCylinderEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new GateMarkCylinderParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<GateMarkCylinderParam>(paramJson);
                        return "���v����" + (p.CylinderRetract ? "���^" : "���X");
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateHeightDisplacementDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.HEIGHT_DISPLACEMENT,
                DisplayName = "���׭p",
                Description = "Ū�����׭p�A�P�_�O�_���b���w�d��",
                HandlerType = typeof(HeightDisplacementHandler),
                EditorType = typeof(HeightDisplacementEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new HeightDisplacementParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<HeightDisplacementParam>(paramJson);
                        return $"�d��:{p.MinValue}~{p.MaxValue}";
                    }
                    catch { return null; }
                }
            };
        }

        private static ProcessDescriptor CreateDelayDescriptor()
        {
            return new ProcessDescriptor
            {
                ProcessId = ProcessIds.DELAY,
                DisplayName = "���𵥫�",
                Description = "������w�ɶ����~�����",
                HandlerType = typeof(DelayHandler),
                EditorType = typeof(DelayEditor),
                DefaultParamJson = JsonConvert.SerializeObject(new DelayParam()),
                SummaryFormatter = paramJson =>
                {
                    try
                    {
                        var p = JsonConvert.DeserializeObject<DelayParam>(paramJson);
                        var desc = string.IsNullOrEmpty(p.Description) ? "" : $" ({p.Description})";
                        return $"���� {p.DelayMilliseconds} ms{desc}";
                    }
                    catch { return null; }
                }
            };
        }
    }
}
