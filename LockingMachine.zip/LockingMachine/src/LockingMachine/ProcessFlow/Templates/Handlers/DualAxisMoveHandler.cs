using System;
using System.Threading;
using System.Threading.Tasks;
using Calin.LockingMachine.ProcessFlow.Engine;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Handlers
{
    /// <summary>
    /// ��b���ʤu�ǳB�z���C
    /// </summary>
    public class DualAxisMoveHandler : IProcessHandler
    {
        public async Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken cancellationToken)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<DualAxisMoveParam>(paramJson);
                if (param == null)
                    return ProcessExecutionResult.Failed("�ѼƸѪR����");

                // ������b���ʡ]������Τ����I�s���x���� API�^
                var distance1 = Math.Abs(param.Axis1TargetPosition);
                var distance2 = Math.Abs(param.Axis2TargetAngle);
                var maxDistance = Math.Max(distance1, distance2);
                var moveTime = maxDistance / param.Axis1Speed * 1000;
                var simulatedDelay = Math.Min((int)moveTime, 2000);

                await Task.Delay(simulatedDelay, cancellationToken);

                return ProcessExecutionResult.Succeeded();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                return ProcessExecutionResult.Failed(ex);
            }
        }

        public string ValidateParam(string paramJson)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<DualAxisMoveParam>(paramJson);
                if (param == null)
                    return "�ѼƤ��i����";

                if (string.IsNullOrEmpty(param.Axis1Id))
                    return "�Ĥ@�b�N�����i����";

                if (string.IsNullOrEmpty(param.Axis2Id))
                    return "�ĤG�b�N�����i����";

                if (param.Axis1Id == param.Axis2Id)
                    return "��b�N�����i�ۦP";

                if (param.Axis1Speed <= 0)
                    return "�t�ץ����j�� 0";

                if (param.Axis1Acceleration <= 0)
                    return "�[�t�ץ����j�� 0";

                return null;
            }
            catch (Exception ex)
            {
                return $"�ѼƮ榡���~: {ex.Message}";
            }
        }
    }
}
