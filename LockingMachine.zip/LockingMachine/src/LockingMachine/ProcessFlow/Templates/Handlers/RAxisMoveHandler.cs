﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Calin.LockingMachine.ProcessFlow.Engine;
using Calin.LockingMachine.ProcessFlow.Templates.Parameters;
using Newtonsoft.Json;

namespace Calin.LockingMachine.ProcessFlow.Templates.Handlers
{
    public class RAxisMoveHandler : IProcessHandler
    {
        public async Task<ProcessExecutionResult> ExecuteAsync(string paramJson, CancellationToken cancellationToken)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<RAxisMoveParam>(paramJson);
                if (param == null)
                    return ProcessExecutionResult.Failed("參數解析失敗");

                // 模擬軸移動（實際應用中應呼叫機台控制 API）
                var moveTime = Math.Abs(param.TargetAngle) / param.Speed * 1000; // TODO
                var simulatedDelay = Math.Min((int)moveTime, 2000);

                await Task.Delay(simulatedDelay, cancellationToken);

                return ProcessExecutionResult.Succeeded();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                return ProcessExecutionResult.Failed(ex);
            }
        }

        public string ValidateParam(string paramJson)
        {
            try
            {
                var param = JsonConvert.DeserializeObject<RAxisMoveParam>(paramJson);
                if (param == null)
                    return "參數不可為空";

                if (param.Speed <= 0)
                    return "速度必須大於 0";

                if (param.Acceleration <= 0)
                    return "加速度必須大於 0";

                return null;
            }
            catch (Exception ex)
            {
                return $"參數格式錯誤: {ex.Message}";
            }
        }
    }
}
