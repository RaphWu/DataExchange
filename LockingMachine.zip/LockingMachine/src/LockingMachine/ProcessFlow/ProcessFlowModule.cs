using Autofac;
using Calin.LockingMachine.ProcessFlow.Editor;
using Calin.LockingMachine.ProcessFlow.Engine;
using Calin.LockingMachine.ProcessFlow.Registry;
using Calin.LockingMachine.ProcessFlow.Templates;
using Calin.LockingMachine.ProcessFlow.Templates.Editors;
using Calin.LockingMachine.ProcessFlow.Templates.Handlers;

namespace Calin.LockingMachine.ProcessFlow
{
    /// <summary>
    /// ProcessFlow �ҲաA�t�d���U�Ҧ��u�Ǭ������A�ȡC
    /// </summary>
    public class ProcessFlowModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            // ���U ProcessRegistry
            builder.Register(c =>
            {
                var registry = new ProcessRegistry();
                foreach (var descriptor in ProcessTemplateRegistry.GetAllDescriptors())
                {
                    registry.Register(descriptor);
                }
                return registry;
            })
            .As<IProcessRegistry>()
            .SingleInstance();

            // ���U ProcessRunner
            builder.RegisterType<ProcessRunner>()
                .AsSelf()
                .InstancePerDependency();

            // �ϥ� Keyed ���U Handler & Editor
            builder.RegisterType<ZAxisMoveHandler>()
                .Keyed<IProcessHandler>(ProcessIds.Z_AXIS_MOVE)
                .InstancePerDependency();
            builder.RegisterType<ZAxisMoveEditor>()
                .Keyed<IProcessEditor>(ProcessIds.Z_AXIS_MOVE)
                .InstancePerDependency();

            builder.RegisterType<RAxisMoveHandler>()
                .Keyed<IProcessHandler>(ProcessIds.R_AXIS_MOVE)
                .InstancePerDependency();
            builder.RegisterType<RAxisMoveEditor>()
                .Keyed<IProcessEditor>(ProcessIds.R_AXIS_MOVE)
                .InstancePerDependency();

            builder.RegisterType<DualAxisMoveHandler>()
                .Keyed<IProcessHandler>(ProcessIds.DUAL_AXIS_MOVE)
                .InstancePerDependency();
            builder.RegisterType<DualAxisMoveEditor>()
                .Keyed<IProcessEditor>(ProcessIds.DUAL_AXIS_MOVE)
                .InstancePerDependency();

            builder.RegisterType<HeightDisplacementHandler>()
                .Keyed<IProcessHandler>(ProcessIds.HEIGHT_DISPLACEMENT)
                .InstancePerDependency();
            builder.RegisterType<HeightDisplacementEditor>()
                .Keyed<IProcessEditor>(ProcessIds.HEIGHT_DISPLACEMENT)
                .InstancePerDependency();

            builder.RegisterType<GateMarkSearchHandler>()
                .Keyed<IProcessHandler>(ProcessIds.GATE_MARK_SEARCH)
                .InstancePerDependency();
            builder.RegisterType<GateMarkSearchEditor>()
                .Keyed<IProcessEditor>(ProcessIds.GATE_MARK_SEARCH)
                .InstancePerDependency();

            builder.RegisterType<GateMarkCylinderHandler>()
                .Keyed<IProcessHandler>(ProcessIds.GATE_MARK_CYLINDER)
                .InstancePerDependency();
            builder.RegisterType<GateMarkCylinderEditor>()
                .Keyed<IProcessEditor>(ProcessIds.GATE_MARK_CYLINDER)
                .InstancePerDependency();

            builder.RegisterType<DelayHandler>()
                .Keyed<IProcessHandler>(ProcessIds.DELAY)
                .InstancePerDependency();
            builder.RegisterType<DelayEditor>()
                .Keyed<IProcessEditor>(ProcessIds.DELAY)
                .InstancePerDependency();
        }
    }
}
