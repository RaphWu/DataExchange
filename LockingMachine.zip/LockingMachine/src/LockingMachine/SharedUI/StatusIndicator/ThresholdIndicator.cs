﻿using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.LockingMachine.SharedUI.StatusIndicator
{
    /// <summary> 
    /// 比較類型列舉，用於指定數值比較的方式。 
    /// </summary> 
    public enum ComparisonType { GreaterThan, GreaterThanOrEqual, LessThan, LessThanOrEqual }

    [DefaultProperty("Value")]
    public class ThresholdIndicator : UserControl
    {
        private readonly Label _label;

        public ThresholdIndicator()
        {
            _label = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold)
            };
            Controls.Add(_label);

            Size = new Size(60, 25);
            BorderStyle = BorderStyle.FixedSingle;
            TabStop = false;
            UpdateDisplay();
        }

        private double _value = 0;
        [Category("Data"), Description("顯示的數值")]
        public double Value
        {
            get => _value;
            set { _value = value; UpdateDisplay(); }
        }

        private int _decimalPlaces = 3;
        [Category("Appearance"), Description("數值顯示的小數位數")]
        public int DecimalPlaces
        {
            get => _decimalPlaces;
            set { _decimalPlaces = value; UpdateDisplay(); }
        }

        private ComparisonType _aboveComparison = ComparisonType.GreaterThan;
        [Category("Behavior"), Description("ABOVE 判斷方式")]
        public ComparisonType AboveComparison
        {
            get => _aboveComparison;
            set { _aboveComparison = value; UpdateDisplay(); }
        }

        private ComparisonType _belowComparison = ComparisonType.LessThan;
        [Category("Behavior"), Description("BELOW 判斷方式")]
        public ComparisonType BelowComparison
        {
            get => _belowComparison;
            set { _belowComparison = value; UpdateDisplay(); }
        }

        private double _thresholdAbove = 100;
        [Category("Behavior"), Description("大於此值顯示 ABOVE 顏色")]
        public double ThresholdAbove
        {
            get => _thresholdAbove;
            set { _thresholdAbove = value; UpdateDisplay(); }
        }

        private double _thresholdBelow = 0;
        [Category("Behavior"), Description("小於此值顯示 BELOW 顏色")]
        public double ThresholdBelow
        {
            get => _thresholdBelow;
            set { _thresholdBelow = value; UpdateDisplay(); }
        }

        // ABOVE 顏色
        private Color _aboveBackColor = Color.Firebrick;
        [Category("Appearance"), Description("數值大於 ThresholdA 時背景顏色")]
        public Color AboveBackColor
        {
            get => _aboveBackColor;
            set { _aboveBackColor = value; UpdateDisplay(); }
        }

        private Color _aboveForeColor = Color.White;
        [Category("Appearance"), Description("數值大於 ThresholdA 時文字顏色")]
        public Color AboveForeColor
        {
            get => _aboveForeColor;
            set { _aboveForeColor = value; UpdateDisplay(); }
        }

        // BETWEEN 顏色
        private Color _betweenBackColor = Color.LimeGreen;
        [Category("Appearance"), Description("數值介於 ThresholdB 與 ThresholdA 之間時背景顏色")]
        public Color BetweenBackColor
        {
            get => _betweenBackColor;
            set { _betweenBackColor = value; UpdateDisplay(); }
        }

        private Color _betweenForeColor = Color.Black;
        [Category("Appearance"), Description("數值介於 ThresholdB 與 ThresholdA 之間時文字顏色")]
        public Color BetweenForeColor
        {
            get => _betweenForeColor;
            set { _betweenForeColor = value; UpdateDisplay(); }
        }

        // BELOW 顏色
        private Color _belowBackColor = Color.Gainsboro;
        [Category("Appearance"), Description("數值小於 ThresholdB 時背景顏色")]
        public Color BelowBackColor
        {
            get => _belowBackColor;
            set { _belowBackColor = value; UpdateDisplay(); }
        }

        private Color _belowForeColor = Color.Black;
        [Category("Appearance"), Description("數值小於 ThresholdB 時文字顏色")]
        public Color BelowForeColor
        {
            get => _belowForeColor;
            set { _belowForeColor = value; UpdateDisplay(); }
        }

        private Color _borderColor = Color.Black;
        [Category("Appearance"), Description("邊框顏色")]
        public Color BorderColor
        {
            get => _borderColor;
            set { _borderColor = value; Invalidate(); }
        }

        private bool _autoScaleText = false;
        [Category("Appearance"), Description("文字自動縮放")]
        public bool AutoScaleText
        {
            get => _autoScaleText;
            set { _autoScaleText = value; UpdateDisplay(); }
        }

        private void UpdateDisplay()
        {
            // 計算顏色
            Color backColor, foreColor;
            bool isAbove = _aboveComparison == ComparisonType.GreaterThan ? Value > ThresholdAbove : Value >= ThresholdAbove;
            bool isBelow = _belowComparison == ComparisonType.LessThan ? Value < ThresholdBelow : Value <= ThresholdBelow;

            if (isAbove)
            {
                backColor = AboveBackColor;
                foreColor = AboveForeColor;
            }
            else if (isBelow)
            {
                backColor = BelowBackColor;
                foreColor = BelowForeColor;
            }
            else
            {
                backColor = BetweenBackColor;
                foreColor = BetweenForeColor;
            }

            _label.BackColor = backColor;
            _label.ForeColor = foreColor;

            string text = Value.ToString($"F{DecimalPlaces}");
            _label.Text = text;

            if (AutoScaleText)
            {
                _label.Font = GetAutoScaledFont(text, _label.ClientSize, _label.Font);
            }

            // 邊框
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            using (var pen = new Pen(BorderColor))
            {
                Rectangle rect = new Rectangle(0, 0, Width - 1, Height - 1);
                e.Graphics.DrawRectangle(pen, rect);
            }
        }

        private Font GetAutoScaledFont(string text, Size bounds, Font originalFont)
        {
            float minSize = 2f;
            float maxSize = originalFont.Size;
            float bestSize = minSize;

            using (Graphics g = CreateGraphics())
            {
                while (minSize <= maxSize)
                {
                    float mid = (minSize + maxSize) / 2;
                    using (var testFont = new Font(originalFont.FontFamily, mid, originalFont.Style))
                    {
                        Size size = TextRenderer.MeasureText(g, text, testFont);
                        if (size.Width <= bounds.Width && size.Height <= bounds.Height)
                        {
                            bestSize = mid;
                            minSize = mid + 0.5f;
                        }
                        else
                        {
                            maxSize = mid - 0.5f;
                        }
                    }
                }
            }
            return new Font(originalFont.FontFamily, bestSize, originalFont.Style);
        }
    }
}
