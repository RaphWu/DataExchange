﻿using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Calin.LockingMachine.SharedUI.StatusIndicator
{
    [DefaultProperty("DisplayText")]
    [DefaultEvent("Click")]
    public class RectangularIndicator : Label
    {
        private Color _onColor = Color.Lime;
        [Category("Appearance"), Description("指示燈亮起顏色")]
        public Color OnColor
        {
            get => _onColor;
            set { if (_onColor != value) { _onColor = value; UpdateAppearance(); } }
        }

        private Color _offColor = Color.DimGray;
        [Category("Appearance"), Description("指示燈關閉顏色")]
        public Color OffColor
        {
            get => _offColor;
            set { if (_offColor != value) { _offColor = value; UpdateAppearance(); } }
        }

        // BorderColor 保留但不能改（Label 只能用固定邊框）
        private Color _borderColor = Color.Black;
        [Category("Appearance"), Description("邊框顏色 (Label 無法自訂)")]
        public Color BorderColor
        {
            get => _borderColor;
            set { _borderColor = value; }
        }

        private Color _onTextColor = Color.Black;
        [Category("Appearance"), Description("文字亮起顏色")]
        public Color OnTextColor
        {
            get => _onTextColor;
            set { if (_onTextColor != value) { _onTextColor = value; UpdateAppearance(); } }
        }

        private Color _offTextColor = Color.White;
        [Category("Appearance"), Description("文字關閉顏色")]
        public Color OffTextColor
        {
            get => _offTextColor;
            set { if (_offTextColor != value) { _offTextColor = value; UpdateAppearance(); } }
        }

        private bool _isOn = false;
        [Category("Behavior"), Description("指示燈是否亮起")]
        public bool IsOn
        {
            get => _isOn;
            set { if (_isOn != value) { _isOn = value; UpdateAppearance(); } }
        }

        private string _displayText = "";
        [Category("Appearance"), Description("顯示文字")]
        public string DisplayText
        {
            get => _displayText;
            set { if (_displayText != value) { _displayText = value; UpdateAppearance(); } }
        }

        private bool _autoScaleText = false;
        [Category("Appearance"), Description("文字自動縮放")]
        public bool AutoScaleText
        {
            get => _autoScaleText;
            set { if (_autoScaleText != value) { _autoScaleText = value; UpdateAppearance(); } }
        }

        public RectangularIndicator()
        {
            AutoSize = false;
            TextAlign = ContentAlignment.MiddleCenter;
            BorderStyle = BorderStyle.FixedSingle;
            Size = new Size(50, 20);
            TabStop = false;

            UpdateAppearance();
        }

        private void UpdateAppearance()
        {
            BackColor = IsOn ? OnColor : OffColor;
            ForeColor = IsOn ? OnTextColor : OffTextColor;
            Text = DisplayText;

            if (AutoScaleText)
            {
                AutoSize = false;
                AdjustFontToFit();
            }
        }

        private void AdjustFontToFit()
        {
            if (string.IsNullOrEmpty(Text)) return;

            float minSize = 2f;
            float maxSize = Font.Size;
            float bestSize = minSize;

            using (Graphics g = CreateGraphics())
            {
                while (minSize <= maxSize)
                {
                    float mid = (minSize + maxSize) / 2;
                    using (var testFont = new Font(Font.FontFamily, mid, Font.Style))
                    {
                        Size size = TextRenderer.MeasureText(g, Text, testFont);
                        if (size.Width <= Width && size.Height <= Height)
                        {
                            bestSize = mid;
                            minSize = mid + 0.5f;
                        }
                        else
                        {
                            maxSize = mid - 0.5f;
                        }
                    }
                }
            }

            Font = new Font(Font.FontFamily, bestSize, Font.Style);
        }
    }
}
