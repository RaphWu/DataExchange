﻿using System;
using System.ComponentModel;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 軸運動旗標列舉。
    /// </summary>
    [Flags]
    public enum AxisMotionFlags : uint
    {
        [Description("運動停止")]
        Stop = 1 << 0,

        [Description("背隙補償")]
        CorrectBksh = 1 << 4,

        [Description("處於特定速度中")]
        InFA = 1 << 6,

        [Description("處於低速中")]
        InFL = 1 << 7,

        [Description("加速中")]
        InACC = 1 << 8,

        [Description("處於最大速度中")]
        InFH = 1 << 9,

        [Description("減速中")]
        InDEC = 1 << 10,

        [Description("到位INP等待")]
        WaitINP = 1 << 11,
    }
}
