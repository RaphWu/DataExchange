﻿using Advantech.Motion;

namespace Calin.MotionControl.Advantech.Models
{
    /// <summary>
    /// 運動狀態資料模型 (Snapshot Buffer)。
    /// </summary>
    public struct RawAxisState
    {
        /// <summary>
        /// 軸命令位置。
        /// </summary>
        public double CmdPosition;

        /// <summary>
        /// 軸實際位置。
        /// </summary>
        public double ActPosition;

        /// <summary>
        /// 軸當前狀態。
        /// </summary>
        public AxisState AxisState;

        /// <summary>
        /// 軸當前運動狀態。
        /// </summary>
        public uint AxisMotionStatus;

        /// <summary>
        /// 軸的運動 I/O 狀態。
        /// </summary>
        public uint AxisIoStatus;

        /// <summary>
        /// 軸數位輸入狀態。
        /// </summary>
        public byte[] AxisDi;

        /// <summary>
        /// 軸數位輸出狀態。
        /// </summary>
        public byte[] AxisDo;
    }
}