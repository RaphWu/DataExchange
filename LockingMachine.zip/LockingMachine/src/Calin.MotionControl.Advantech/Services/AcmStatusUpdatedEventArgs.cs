﻿using System;
using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Services
{
    /// <summary>
    /// 軸狀態有更新事件。
    /// </summary>
    public sealed class AcmStatusUpdatedEventArgs : EventArgs
    {
        /// <summary>
        /// 軸編號。
        /// </summary>
        public int AxisNo { get; }

        /// <summary>
        /// 軸狀態。
        /// </summary>
        public ParsedAxisState ParsedAxisState { get; }

        public AcmStatusUpdatedEventArgs(int axisNo, ParsedAxisState parsedAxisState)
        {
            AxisNo = axisNo;
            ParsedAxisState = parsedAxisState;
        }
    }
}
