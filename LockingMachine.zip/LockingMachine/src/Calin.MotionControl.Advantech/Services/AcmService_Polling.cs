﻿using System;
using System.Diagnostics;
using System.Threading;
using Advantech.Motion;
using Calin.MotionControl.Advantech.Contracts;
using Calin.MotionControl.Advantech.Models;

namespace Calin.MotionControl.Advantech.Services
{
    // 控制卡狀態讀取/更新服務。
    public partial class AcmService : IAcmService_Polling
    {
        #region Fields

        private Thread _motionCardStatusThread;
        private Thread _parseThread;
        private CancellationTokenSource _pollingCts;

        #endregion Fields

        #region Properties

        public event EventHandler<AcmStatusUpdatedEventArgs> AcmStatusUpdated;

        #endregion Properties

        #region Methods

        /// <inheritdoc/>
        public void PollingStop()
        {
            /*
             - 以 CancellationToken 與 WaitHandle 進行喚醒/等待。
             - 先發出取消，接著以 Join 等待兩條執行緒結束。
             - 最後才 Dispose CancellationTokenSource。
            */

            // 發出取消通知（若已被 Dispose，忽略例外）
            try
            {
                _pollingCts?.Cancel();
            }
            catch (ObjectDisposedException)
            {
                // Cancellation token source 已被處置，忽略
            }

            const int JoinTimeoutMs = 2000;

            // 等待 monitoring 執行緒結束
            try
            {
                if (_motionCardStatusThread != null && _motionCardStatusThread.IsAlive)
                    _motionCardStatusThread.Join(JoinTimeoutMs);
            }
            catch (Exception)
            {
                // 忽略等待期間可能的例外
            }

            // 等待 parse 執行緒結束
            try
            {
                if (_parseThread != null && _parseThread.IsAlive)
                    _parseThread.Join(JoinTimeoutMs);
            }
            catch (Exception)
            {
                // 忽略等待期間可能的例外
            }

            // 清理 CancellationTokenSource（在 Join 完成後再 Dispose）
            try
            {
                _pollingCts?.Dispose();
            }
            catch (ObjectDisposedException)
            {
                // 已被處置，忽略
            }
            finally
            {
                _pollingCts = null;
            }

            // 清除執行緒引用
            _motionCardStatusThread = null;
            _parseThread = null;
        }

        /// <inheritdoc/>
        public void PollingStart()
        {
            _pollingCts = new CancellationTokenSource();

            _motionCardStatusThread = new Thread(() => MotionCardStatusProc(_pollingCts.Token));
            _motionCardStatusThread.IsBackground = true;
            _motionCardStatusThread.Priority = ThreadPriority.Highest;
            _motionCardStatusThread.Start();

            _parseThread = new Thread(() => ParseProc(_pollingCts.Token));
            _parseThread.IsBackground = true;
            _parseThread.Priority = ThreadPriority.Normal;
            _parseThread.Start();
        }

        #endregion Methods

        #region Polling Procedures

        /// <summary>
        /// 控制卡狀態讀取程序。
        /// </summary>
        /// <param name="token">取消令牌。</param>
        private void MotionCardStatusProc(CancellationToken token)
        {
            var sw = Stopwatch.StartNew();
            long ticksPerMs = Stopwatch.Frequency / 3;
            long nextTick = sw.ElapsedTicks;
            var spin = new SpinWait();

            while (!token.IsCancellationRequested)
            {
                long now = sw.ElapsedTicks;
                if (now >= nextTick)
                {
                    nextTick += ticksPerMs;
                    spin.Reset();

                    for (int axisNo = 0; axisNo < _axisCount; axisNo++)
                    {
                        var axisState = _rawAxisStates[axisNo];

                        double cmdPos = default;
                        ErrCode = Motion.mAcm_AxGetCmdPosition(_axisHandles[axisNo], ref cmdPos);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的命令位置！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.CmdPosition = cmdPos;

                        double actPos = default;
                        ErrCode = Motion.mAcm_AxGetActualPosition(_axisHandles[axisNo], ref actPos);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的實際位置！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.ActPosition = actPos;

                        // 軸IO狀態
                        ushort acmAxisState = default;
                        ErrCode = Motion.mAcm_AxGetState(_axisHandles[axisNo], ref acmAxisState);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.AxisState = (AxisState)acmAxisState;

                        // 軸運動狀態
                        uint acmAxisMotionStatus = default;
                        ErrCode = Motion.mAcm_AxGetMotionStatus(_axisHandles[axisNo], ref acmAxisMotionStatus);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的運動狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.AxisMotionStatus = acmAxisMotionStatus;

                        // 軸IO狀態
                        uint acmAxisIoStatus = default;
                        ErrCode = Motion.mAcm_AxGetMotionIO(_axisHandles[axisNo], ref acmAxisIoStatus);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的 I/O 狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.AxisIoStatus = acmAxisIoStatus;

                        // DI狀態
                        byte[] daqDiStatus = new byte[8];
                        ErrCode = Motion.mAcm_DaqDiGetBytes(_axisHandles[axisNo], 0, 7, daqDiStatus);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的 DI 狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.AxisDi = daqDiStatus;

                        // DO狀態
                        byte[] daqDoStatus = new byte[8];
                        ErrCode = Motion.mAcm_DaqDoGetBytes(_axisHandles[axisNo], 0, 7, daqDoStatus);
                        if (CheckErr($"{nameof(IAcmService_Polling)}.{nameof(MotionCardStatusProc)}", $"無法取得軸 {axisNo + 1} 的 DI 狀態！"))
                        {
                            token.ThrowIfCancellationRequested();
                            continue;
                        }
                        axisState.AxisDo = daqDoStatus;

                        _rawAxisStates[axisNo] = axisState;
                    }

                    // 用於須快速反應的停止條件
                    //if (torque >= TorqueLimit)
                    //{
                    //    EmergencyStop();
                    //}
                }
                else
                {
                    spin.SpinOnce();
                }
            }
        }

        /// <summary>
        /// 解析程序。
        /// </summary>
        /// <param name="token">取消令牌。</param>
        private void ParseProc(CancellationToken token)
        {
            int axisNo = 0;
            while (!token.IsCancellationRequested)
            {
                var parsedState = _parsedAxisStates[axisNo];

                parsedState.CmdPosition = _rawAxisStates[axisNo].CmdPosition;
                parsedState.ActPosition = _rawAxisStates[axisNo].ActPosition;

                // 軸狀態
                var axisState = (AxisStateFlags)_rawAxisStates[axisNo].AxisState;
                parsedState.AxisStateFlags = axisState;
                parsedState.STA_AX_DISABLE = axisState == AxisStateFlags.STA_AX_DISABLE;
                parsedState.STA_AX_READY = axisState == AxisStateFlags.STA_AX_READY;
                parsedState.STA_AX_STOPPING = axisState == AxisStateFlags.STA_AX_STOPPING;
                parsedState.STA_AX_ERROR_STOP = axisState == AxisStateFlags.STA_AX_ERROR_STOP;
                parsedState.STA_AX_HOMING = axisState == AxisStateFlags.STA_AX_HOMING;
                parsedState.STA_AX_PTP_MOTION = axisState == AxisStateFlags.STA_AX_PTP_MOTION;
                parsedState.STA_AX_CONTI_MOTION = axisState == AxisStateFlags.STA_AX_CONTI_MOTION;
                parsedState.STA_AX_SYNC_MOTION = axisState == AxisStateFlags.STA_AX_SYNC_MOTION;
                parsedState.STA_AX_EXT_JOG = axisState == AxisStateFlags.STA_AX_EXT_JOG;
                parsedState.STA_AX_EXT_MPG = axisState == AxisStateFlags.STA_AX_EXT_MPG;
                parsedState.STA_AX_PAUSE = axisState == AxisStateFlags.STA_AX_PAUSE;
                parsedState.STA_AX_BUSY = axisState == AxisStateFlags.STA_AX_BUSY;
                parsedState.STA_AX_WAIT_DI = axisState == AxisStateFlags.STA_AX_WAIT_DI;
                parsedState.STA_AX_WAIT_PTP = axisState == AxisStateFlags.STA_AX_WAIT_PTP;
                parsedState.STA_AX_WAIT_VEL = axisState == AxisStateFlags.STA_AX_WAIT_VEL;
                parsedState.STA_AX_EXT_JOG_READY = axisState == AxisStateFlags.STA_AX_EXT_JOG_READY;

                // 軸運動狀態
                const uint AxisMotionMask = (uint)(
                    AxisMotionFlags.Stop | AxisMotionFlags.WaitERC | AxisMotionFlags.CorrectBksh |
                    AxisMotionFlags.InFA | AxisMotionFlags.InFL | AxisMotionFlags.InACC |
                    AxisMotionFlags.InFH | AxisMotionFlags.InDEC | AxisMotionFlags.WaitINP);
                var axisMotionFlags = _rawAxisStates[axisNo].AxisMotionStatus & AxisMotionMask;
                parsedState.AxisMotionFlags = (AxisMotionFlags)axisMotionFlags;
                parsedState.Stop = (axisMotionFlags & (uint)AxisMotionFlags.Stop) != 0;
                parsedState.WaitERC = (axisMotionFlags & (uint)AxisMotionFlags.WaitERC) != 0;
                parsedState.CorrectBksh = (axisMotionFlags & (uint)AxisMotionFlags.CorrectBksh) != 0;
                parsedState.InFA = (axisMotionFlags & (uint)AxisMotionFlags.InFA) != 0;
                parsedState.InFL = (axisMotionFlags & (uint)AxisMotionFlags.InFL) != 0;
                parsedState.InACC = (axisMotionFlags & (uint)AxisMotionFlags.InACC) != 0;
                parsedState.InFH = (axisMotionFlags & (uint)AxisMotionFlags.InFH) != 0;
                parsedState.InDEC = (axisMotionFlags & (uint)AxisMotionFlags.InDEC) != 0;
                parsedState.WaitINP = (axisMotionFlags & (uint)AxisMotionFlags.WaitINP) != 0;

                // 軸IO
                const uint AxisIoMask = (uint)(
                    AxisIoFlags.RDY | AxisIoFlags.ALM | AxisIoFlags.LMT_Positive | AxisIoFlags.LMT_Negative |
                    AxisIoFlags.ORG | AxisIoFlags.DIR | AxisIoFlags.EMG | AxisIoFlags.PCS |
                    AxisIoFlags.ERC | AxisIoFlags.EZ | AxisIoFlags.CLR | AxisIoFlags.LTC |
                    AxisIoFlags.SD | AxisIoFlags.INP | AxisIoFlags.SVON | AxisIoFlags.ALRM |
                    AxisIoFlags.SLMT_Positive | AxisIoFlags.SLMT_Negative | AxisIoFlags.CMP | AxisIoFlags.CAMDO);
                var axisIoFlags = _rawAxisStates[axisNo].AxisIoStatus & AxisIoMask;
                parsedState.AxisIoFlags = (AxisIoFlags)axisIoFlags;
                parsedState.RDY = (axisIoFlags & (uint)AxisIoFlags.RDY) != 0;
                parsedState.ALM = (axisIoFlags & (uint)AxisIoFlags.ALM) != 0;
                parsedState.LMT_Positive = (axisIoFlags & (uint)AxisIoFlags.LMT_Positive) != 0;
                parsedState.LMT_Negative = (axisIoFlags & (uint)AxisIoFlags.LMT_Negative) != 0;
                parsedState.ORG = (axisIoFlags & (uint)AxisIoFlags.ORG) != 0;
                parsedState.DIR = (axisIoFlags & (uint)AxisIoFlags.DIR) != 0;
                parsedState.EMG = (axisIoFlags & (uint)AxisIoFlags.EMG) != 0;
                parsedState.PCS = (axisIoFlags & (uint)AxisIoFlags.PCS) != 0;
                parsedState.ERC = (axisIoFlags & (uint)AxisIoFlags.ERC) != 0;
                parsedState.EZ = (axisIoFlags & (uint)AxisIoFlags.EZ) != 0;
                parsedState.CLR = (axisIoFlags & (uint)AxisIoFlags.CLR) != 0;
                parsedState.LTC = (axisIoFlags & (uint)AxisIoFlags.LTC) != 0;
                parsedState.SD = (axisIoFlags & (uint)AxisIoFlags.SD) != 0;
                parsedState.INP = (axisIoFlags & (uint)AxisIoFlags.INP) != 0;
                parsedState.SVON = (axisIoFlags & (uint)AxisIoFlags.SVON) != 0;
                parsedState.ALRM = (axisIoFlags & (uint)AxisIoFlags.ALRM) != 0;
                parsedState.SLMT_Positive = (axisIoFlags & (uint)AxisIoFlags.SLMT_Positive) != 0;
                parsedState.SLMT_Negative = (axisIoFlags & (uint)AxisIoFlags.SLMT_Negative) != 0;
                parsedState.CMP = (axisIoFlags & (uint)AxisIoFlags.CMP) != 0;
                parsedState.CAMDO = (axisIoFlags & (uint)AxisIoFlags.CAMDO) != 0;

                if (_parsedAxisStates[axisNo] != parsedState)
                {
                    _parsedAxisStates[axisNo] = parsedState;
                    AcmStatusUpdated?.Invoke(this, new AcmStatusUpdatedEventArgs(axisNo, parsedState));
                }

                // 下一軸
                if (++axisNo >= _axisCount)
                    axisNo = 0;

                try
                {
                    if (token.WaitHandle.WaitOne(25))
                        break; // 已取消
                }
                catch (ObjectDisposedException)
                {
                    // 若 token 已被處置，則跳出
                    break;
                }
            }
        }

        #endregion Polling Procedures

        /// <summary>
        /// 緊急停止。
        /// </summary>
        /// <remarks></remarks>
        private void EmergencyStop()
        {
            // 只做停機，不寫 log，不更新 UI
        }

        /// <summary>
        /// 
        /// </summary>
        private void StopWhenConditions()
        {

        }
    }
}
